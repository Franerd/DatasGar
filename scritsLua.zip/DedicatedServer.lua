DedicatedServer = {}
DedicatedServer.PAUSE_MODE_NO = 1
DedicatedServer.PAUSE_MODE_INSTANT = 2
DedicatedServer.MIN_FRAME_LIMIT = 5
DedicatedServer.MAX_FRAME_LIMIT = 60
local v_u_1 = Class(DedicatedServer)
function DedicatedServer.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.filename = ""
	v4.name = "Farming Simulator Dedicated Game"
	v4.password = ""
	v4.savegame = 1
	v4.maxPlayer = g_serverMaxCapacity
	v4.ip = ""
	v4.port = 10823
	v4.crossplayAllowed = true
	v4.mapName = ""
	v4.mapFileName = ""
	v4.adminPassword = ""
	v4.pauseGameIfEmpty = true
	v4.mpLanguageCode = "en"
	v4.autoSaveInterval = 0
	v4.gameStatsInterval = 60
	v4.mods = {}
	v4.gameStatsPath = nil
	v4.economicDifficulty = 1
	v4.initialMoney = 100000
	v4.initialLoan = 0
	v4.hasStartFarm = false
	return v4
end
function DedicatedServer.load(p5, p6)
	local v7 = XMLFile.load("DedicatedServerConfig", p6)
	if v7 ~= nil then
		p5.filename = p6
		p5.name = v7:getString("gameserver.settings.game_name", p5.name)
		p5.password = v7:getString("gameserver.settings.game_password", p5.password)
		local v8 = v7:getInt("gameserver.settings.savegame_index", p5.savegame)
		local v9 = SavegameController.NUM_SAVEGAMES
		p5.savegame = math.clamp(v8, 1, v9)
		local v10 = v7:getInt("gameserver.settings.max_player", p5.maxPlayer)
		local v11 = g_serverMinCapacity
		local v12 = g_serverMaxCapacity
		p5.maxPlayer = math.clamp(v10, v11, v12)
		p5.ip = v7:getString("gameserver.settings.ip", p5.ip)
		p5.port = v7:getInt("gameserver.settings.port", p5.port)
		p5.crossplayAllowed = v7:getBool("gameserver.settings.crossplay_allowed", p5.crossplayAllowed)
		local v13 = v7:getInt("gameserver.settings.economicDifficulty", p5.economicDifficulty)
		p5.economicDifficulty = math.clamp(v13, 1, 3)
		p5.initialMoney = v7:getInt("gameserver.settings.initialMoney", p5.initialMoney)
		p5.initialLoan = v7:getInt("gameserver.settings.initialLoan", p5.initialLoan)
		p5.mapName = v7:getString("gameserver.settings.mapID", p5.mapName)
		p5.mapFileName = v7:getString("gameserver.settings.mapFilename", p5.mapFileName)
		p5.adminPassword = v7:getString("gameserver.settings.admin_password", p5.adminPassword)
		if p5.adminPassword == "" then
			Logging.info("Starting dedicated server without an admin password!")
		end
		p5.mpLanguageCode = v7:getString("gameserver.settings.language", p5.mpLanguageCode)
		p5.pauseGameIfEmpty = v7:getInt("gameserver.settings.pause_game_if_empty", DedicatedServer.PAUSE_MODE_INSTANT) == DedicatedServer.PAUSE_MODE_INSTANT
		local v14 = v7:getInt("gameserver.settings.auto_save_interval", p5.autoSaveInterval)
		p5.autoSaveInterval = math.clamp(v14, 0, 360)
		local v15 = v7:getInt("gameserver.settings.stats_interval", p5.gameStatsInterval)
		p5.gameStatsInterval = math.max(v15, 10)
		for _, v16 in v7:iterator("gameserver.mods.mod") do
			local v17 = v7:getString(v16 .. "#filename")
			if v7:getBool(v16 .. "#isDlc") and g_dlcModNameHasPrefix[v17] then
				v17 = g_uniqueDlcNamePrefix .. v17
			end
			local v18 = p5.mods
			table.insert(v18, v17)
		end
		v7:delete()
	end
	CaptionUtil.addText(string.format(" - ServerName: \'%s\'", p5.name))
	p5.gameStatsInterval = p5.gameStatsInterval * 1000
	if string.endsWith(p5.mapFileName, ".dlc") and not string.startsWith(p5.mapFileName, "pdlc_") then
		p5.mapFileName = "pdlc_" .. p5.mapFileName
	end
	for v19 = 0, getNumOfLanguages() - 1 do
		if getLanguageCode(v19) == p5.mpLanguageCode then
			g_gameSettings:setValue(GameSettings.SETTING.MP_LANGUAGE, v19)
			return
		end
	end
end
function DedicatedServer.lowerFramerate(_)
	local v20 = DedicatedServer.MIN_FRAME_LIMIT
	Logging.devInfo("DedicatedServer:raiseFramerate: set framerate to %d", v20)
	setFramerateLimiter(true, v20)
end
function DedicatedServer.raiseFramerate(_)
	local v21 = DedicatedServer.MAX_FRAME_LIMIT
	local v22
	if g_isDevelopmentVersion then
		local v23 = StartParams.getValue
		v22 = tonumber(v23("serverFrameRateLimit"))
		if v22 == nil then
			v22 = v21
		end
	else
		v22 = v21
	end
	Logging.devInfo("DedicatedServer:raiseFramerate: set framerate to %d", v22)
	setFramerateLimiter(true, v22)
end
function DedicatedServer.updateServerInfo(p24, p25, p26, p27)
	if p24.filename ~= nil then
		local v28 = XMLFile.load("DedicatedServerConfig", p24.filename)
		v28:setString("gameserver.settings.game_name", p25)
		v28:setString("gameserver.settings.game_password", p26)
		v28:setInt("gameserver.settings.max_player", p27)
		v28:save()
		v28:delete()
	end
end
function DedicatedServer.start(_)
	g_gui:setIsMultiplayer(true)
	g_gui:showGui("CareerScreen")
	g_gameSettings:setValue(GameSettings.SETTING.ONLINE_PRESENCE_NAME, "Server")
end
function DedicatedServer.setGameStatsPath(p29, p30)
	p29.gameStatsPath = p30
end

local v_u_1 = {}
local v_u_2 = false
local v_u_3 = 1
local v_u_4 = 2
local v_u_5 = 3
local v_u_6 = 4
local v_u_7 = 5
local v_u_8 = 6
local v_u_9 = 7
local v_u_10 = 8
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
function onProfileUiResolutionScalingChanged()
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_14, (ref) v_u_13
	local v15 = 1
	local v16 = v15 * g_screenWidth
	local v17 = v15 * g_screenHeight
	v_u_11 = 1 / v16
	v_u_12 = 1 / v17
	local v18, v19 = getNormalizedScreenValues(53, 103)
	v_u_14 = v18
	v_u_13 = v19
	local v20, v21 = getNormalizedScreenValues(20, 20)
	CORNER_WIDTH = v20
	CORNER_HEIGHT = v21
end
local function v_u_22()
	-- upvalues: (copy) v_u_1, (ref) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
	v_u_1[1] = createImageOverlay("dataS/menu/base/graph_pixel.png")
	if Platform.isMobile then
		v_u_1[2] = Overlay.new(g_baseUIFilename, 0, 0, 0, 0)
		v_u_1[2]:setUVs(GuiUtils.getUVs({
			229,
			388,
			53,
			103
		}))
		v_u_1[4] = Overlay.new(g_baseUIFilename, 0, 0, 0, 0)
		v_u_1[4]:setUVs(GuiUtils.getUVs({
			282,
			388,
			-53,
			103
		}))
		v_u_1[3] = Overlay.new(g_baseUIFilename, 0, 0, 0, 0)
		v_u_1[3]:setUVs(GuiUtils.getUVs({
			284,
			388,
			1,
			103
		}))
	end
	v_u_1[5] = Overlay.new("dataS/menu/base/roundCorner.png", 0, 0, 0, 0)
	v_u_1[5]:setUVs(GuiUtils.getUVs({
		7,
		7,
		20,
		20
	}, { 64, 64 }))
	v_u_1[6] = Overlay.new("dataS/menu/base/roundCorner.png", 0, 0, 0, 0)
	v_u_1[6]:setUVs(GuiUtils.getUVs({
		37,
		7,
		20,
		20
	}, { 64, 64 }))
	v_u_1[7] = Overlay.new("dataS/menu/base/roundCorner.png", 0, 0, 0, 0)
	v_u_1[7]:setUVs(GuiUtils.getUVs({
		7,
		37,
		20,
		20
	}, { 64, 64 }))
	v_u_1[8] = Overlay.new("dataS/menu/base/roundCorner.png", 0, 0, 0, 0)
	v_u_1[8]:setUVs(GuiUtils.getUVs({
		37,
		37,
		20,
		20
	}, { 64, 64 }))
	onProfileUiResolutionScalingChanged()
	v_u_2 = true
end
function deleteDrawingOverlays()
	-- upvalues: (copy) v_u_1, (ref) v_u_2
	for _, v23 in pairs(v_u_1) do
		if type(v23) == "table" then
			v23:delete()
		else
			delete(v23)
		end
	end
	v_u_2 = false
end
function drawFilledRect(p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35)
	-- upvalues: (ref) v_u_2, (copy) v_u_22, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (copy) v_u_3
	if not v_u_2 then
		v_u_22()
	end
	local v36 = v_u_1[1]
	if p26 ~= 0 and p27 ~= 0 then
		local v37, v38 = GuiUtils.alignToScreenPixels(p24, p25)
		local v39, v40 = GuiUtils.alignToScreenPixels(p26, p27)
		local v41 = v_u_11
		local v42 = math.max(v39, v41)
		local v43 = v_u_12
		local v44 = math.max(v40, v43)
		if p32 ~= nil then
			local v45 = v37 + v42
			local v46 = v38 + v44
			v37 = math.max(v37, p32)
			v38 = math.max(v38, p33)
			local v47 = math.min(v45, p34) - v37
			v42 = math.max(v47, 0)
			local v48 = math.min(v46, p35) - v38
			v44 = math.max(v48, 0)
			if v42 == 0 or v44 == 0 then
				return
			end
		end
		setOverlayColor(v36, p28, p29, p30, p31)
		renderOverlay(v36, v37, v38, v42, v44)
	end
end
function drawOutlineRect(p49, p50, p51, p52, p53, p54, p55, p56, p57, p58)
	-- upvalues: (ref) v_u_2, (copy) v_u_22, (copy) v_u_1, (copy) v_u_3
	if not v_u_2 then
		v_u_22()
	end
	local v59 = v_u_1[1]
	setOverlayColor(v59, p55, p56, p57, p58)
	renderOverlay(v59, p49, p50, p51, p54)
	renderOverlay(v59, p49, p50, p53, p52)
	renderOverlay(v59, p49 + p51 - p53, p50, p53, p52)
	renderOverlay(v59, p49, p50 + p52 - p54, p51, p54)
end
function drawPoint(p60, p61, p62, p63, p64, p65, p66, p67)
	-- upvalues: (ref) v_u_2, (copy) v_u_22, (copy) v_u_1, (copy) v_u_3
	if not v_u_2 then
		v_u_22()
	end
	local v68 = v_u_1[1]
	setOverlayColor(v68, p64, p65, p66, p67)
	renderOverlay(v68, p60 - p62 / 2, p61 - p63 / 2, p62, p63)
end
function drawTouchButton(p69, p70, p71, p72, _, p73, p74, p75, p76, p77, p78, p79, p80)
	-- upvalues: (ref) v_u_2, (copy) v_u_22, (ref) v_u_11, (ref) v_u_13, (copy) v_u_1, (ref) v_u_14, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6
	if not v_u_2 then
		v_u_22()
	end
	local v81 = p69 / v_u_11
	local v82 = math.floor(v81) * v_u_11
	local v83 = p71 / v_u_11
	local v84 = math.floor(v83) * v_u_11
	local v85 = p70 - v_u_13 * 0.5
	if p72 then
		local v86 = p73 * 0.8
		p73 = math.min(1, v86)
		local v87 = p74 * 0.8
		p74 = math.min(1, v87)
		local v88 = p75 * 0.8
		p75 = math.min(1, v88)
	end
	local v89 = v_u_1[2]
	v89:setPosition(v82, v85)
	v89:setDimension(v_u_14, v_u_13)
	v89:setColor(p73, p74, p75, p76)
	v89:render(p77, p78, p79, p80)
	local v90 = v_u_1[3]
	v90:setPosition(v82 + v_u_14, v85)
	v90:setDimension(v84 - 2 * v_u_14, v_u_13)
	v90:setColor(p73, p74, p75, p76)
	v90:render(p77, p78, p79, p80)
	local v91 = v_u_1[4]
	v91:setPosition(v82 + v84 - v_u_14, v85)
	v91:setDimension(v_u_14, v_u_13)
	v91:setColor(p73, p74, p75, p76)
	v91:render(p77, p78, p79, p80)
end
function drawLine2D(p92, p93, p94, p95, p96, p97, p98, p99, p100)
	-- upvalues: (ref) v_u_2, (copy) v_u_22, (copy) v_u_1, (copy) v_u_3
	if not v_u_2 then
		v_u_22()
	end
	local v101 = p94 - p92
	local v102 = (p95 - p93) / g_screenAspectRatio
	local v103 = v101 * v101 + v102 * v102
	local v104 = math.sqrt(v103)
	if v104 ~= 0 then
		local v105 = v101 / v104
		local v106 = math.acos(v105)
		if v102 < 0 then
			v106 = 6.283185307179586 - v106
		end
		local v107 = v_u_1[1]
		setOverlayColor(v107, p97, p98, p99, p100)
		setOverlayRotation(v107, v106, 0, 0)
		renderOverlay(v107, p92, p93, v104, p96)
		setOverlayRotation(v107, 0, 0, 0)
	end
end
function drawOutlineCircle2D(p108, p109, p110, p111, p112, p113, p114, p115, p116)
	drawPoint(p108, p109, 4 * g_pixelSizeX, 4 * g_pixelSizeY, 0, 0, 1, 1)
	local v117 = p110 * g_screenAspectRatio
	local v118 = p108 + p110
	local v119 = 6.283185307179586 / p112
	local v120 = p109
	for v121 = 1, p112 do
		local v122 = v119 * v121
		local v123 = p108 + p110 * math.cos(v122)
		local v124 = v119 * v121
		local v125 = p109 + v117 * math.sin(v124)
		drawLine2D(v118, v120, v123, v125, p111, p113, p114, p115, p116)
		v120 = v125
		v118 = v123
	end
end
function drawFilledRectRound(p126, p127, p128, p129, p130, p131, p132, p133, p134, p135, p136, p137, p138, p139)
	-- upvalues: (ref) v_u_2, (copy) v_u_22, (copy) v_u_1, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
	if not v_u_2 then
		v_u_22()
	end
	if p128 ~= 0 and p129 ~= 0 then
		local v140 = CORNER_WIDTH * p130
		local v141 = CORNER_HEIGHT * p130
		if not p139 then
			v140, v141 = GuiUtils.alignToScreenPixels(CORNER_WIDTH * p130, CORNER_HEIGHT * p130)
			p126, p127 = GuiUtils.alignToScreenPixels(p126, p127)
			p128, p129 = GuiUtils.alignToScreenPixels(p128, p129)
		end
		local v142 = v140 * 2
		local v143 = math.max(p128, v142)
		local v144 = v141 * 2
		local v145 = math.max(p129, v144)
		drawFilledRect(p126, p127 + v141, v140, v145 - 2 * v141, p131, p132, p133, p134, p135, p136, p137, p138)
		drawFilledRect(p126 + v140, p127, v143 - 2 * v140, v145, p131, p132, p133, p134, p135, p136, p137, p138)
		drawFilledRect(p126 + v143 - v140, p127 + v141, v140, v145 - 2 * v141, p131, p132, p133, p134, p135, p136, p137, p138)
		local v146 = v_u_1[5]
		v146:setPosition(p126, p127 + v145 - v141)
		v146:setDimension(v140, v141)
		v146:setColor(p131, p132, p133, p134)
		v146:render(p135, p136, p137, p138)
		local v147 = v_u_1[6]
		v147:setPosition(p126 + v143 - v140, p127 + v145 - v141)
		v147:setDimension(v140, v141)
		v147:setColor(p131, p132, p133, p134)
		v147:render(p135, p136, p137, p138)
		local v148 = v_u_1[7]
		v148:setPosition(p126, p127)
		v148:setDimension(v140, v141)
		v148:setColor(p131, p132, p133, p134)
		v148:render(p135, p136, p137, p138)
		local v149 = v_u_1[8]
		v149:setPosition(p126 + v143 - v140, p127)
		v149:setDimension(v140, v141)
		v149:setColor(p131, p132, p133, p134)
		v149:render(p135, p136, p137, p138)
	end
end
function drawDashedLine(p150, p151, p152, p153, p154, p155, p156, p157, p158, p159, p160)
	local v161 = 0
	if not p160 then
		while math.abs(v161) < p153 do
			if p154 <= 0 then
				::l11::
				local v162 = v161 + p154
				local v163 = -p153
				v165 = math.max(v162, v163)
				goto l12
			end
			local v164 = v161 + p154
			local v165 = math.min(v164, p153)
			if not v165 then
				goto l11
			end
			::l12::
			drawLine2D(p150, p151 + v161, p150, p151 + v165, p152, p156, p157, p158, p159)
			v161 = v165 + p155
		end
		goto l4
	end
	while true do
		if math.abs(v161) >= p152 then
			::l4::
			return
		end
		if p154 <= 0 then
			break
		end
		local v166 = v161 + p154
		v169 = math.min(v166, p152)
		if not v169 then
			break
		end
		::l7::
		drawLine2D(p150 + v161, p151, p150 + v169, p151, p153, p156, p157, p158, p159)
		v161 = v169 + p155
	end
	local v167 = v161 + p154
	local v168 = -p152
	local v169 = math.max(v167, v168)
	goto l7
end

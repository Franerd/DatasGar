StartMissionInfo = {}
local v_u_1 = Class(StartMissionInfo)
function StartMissionInfo.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4:reset()
	return v4
end
function StartMissionInfo.reset(p5)
	p5.isMultiplayer = false
	p5.createGame = false
	p5.canStart = false
	p5.mapId = "MapUS"
	p5.economicDifficulty = EconomicDifficulty.EASY
	p5.initialMoney = 100000
	p5.initialLoan = 0
	p5.hasStartFarm = true
	p5.startWithGuidedTour = true
end

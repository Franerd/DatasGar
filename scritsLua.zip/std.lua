GS_IS_EDITOR = _G.getSelection ~= nil
GS_INPUT_HELP_MODE_AUTO = 1
GS_INPUT_HELP_MODE_KEYBOARD = 2
GS_INPUT_HELP_MODE_GAMEPAD = 3
GS_INPUT_HELP_MODE_TOUCH = 4
GS_PRIO_VERY_HIGH = 1
GS_PRIO_HIGH = 2
GS_PRIO_NORMAL = 3
GS_PRIO_LOW = 4
GS_PRIO_VERY_LOW = 5
GS_MONEY_EURO = 1
GS_MONEY_DOLLAR = 2
GS_MONEY_POUND = 3
function loadfile() end
function load()
	return nil, "invalid function"
end
if setFileLogPrefixTimestamp == nil then
	function setFileLogPrefixTimestamp(_) end
end
local v_u_1 = {}
if addConsoleCommand ~= nil then
	local v_u_2 = addConsoleCommand
	function addConsoleCommand(p3, p4, p5, p6, p7, ...)
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		if v_u_1[p3] == nil then
			v_u_2(p3, p4, p5, p6, p7, ...)
			local v8
			if p7 == nil then
				v8 = nil
			else
				v8 = string.split(p7, ";")
				for v9, v10 in ipairs(v8) do
					v8[v9] = string.trim(v10)
				end
			end
			v_u_1[p3] = {
				["description"] = p4,
				["arguments"] = v8
			}
		else
			printError(string.format("Error: Failed to register console command \'%s. Command was already registered!", p3))
		end
	end
end
if removeConsoleCommand ~= nil then
	local v_u_11 = removeConsoleCommand
	function removeConsoleCommand(p12, ...)
		-- upvalues: (copy) v_u_11, (copy) v_u_1
		v_u_11(p12, ...)
		v_u_1[p12] = nil
	end
end
function consoleCommandListCommands()
	-- upvalues: (copy) v_u_1
	local v13 = {}
	local v14 = 0
	for v17, _ in pairs(v_u_1) do
		v13[#v13 + 1] = v17
		local v16 = v_u_1[v17]
		if v16.arguments ~= nil then
			local v17 = string.format("%s %s", v17, table.concat(v16.arguments, ", "))
		end
		local v18 = string.len(v17)
		v14 = math.max(v14, v18)
	end
	table.sort(v13)
	setFileLogPrefixTimestamp(false)
	for _, v22 in ipairs(v13) do
		local v20 = v_u_1[v22]
		local v21 = v_u_1[v22]
		if v21.arguments ~= nil then
			local v22 = string.format("%s %s", v22, table.concat(v21.arguments, ", "))
		end
		local v23 = v22 .. string.rep(" ", v14 - string.len(v22))
		print(string.format("%s   %s", v23, v20.description))
	end
	print(string.format("# Listed %d script-based console commands. Use \'help\' to get all commands", #v13))
	setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
end
function consoleCommandSearchCommands(p24)
	-- upvalues: (copy) v_u_1
	local v25 = {}
	local v26 = {}
	if p24 == nil or p24 == "" then
		return "Error: no search string given"
	end
	local v27 = string.upper(p24)
	for v28, _ in pairs(v_u_1) do
		if string.contains(string.upper(v28), v27) then
			if v26[v28] == nil then
				local v29 = v_u_1[v28]
				if v29 == nil then
					printError("No command with name %q", v28)
				else
					table.insert(v25, { v28, v29 })
					v26[v28] = true
				end
			end
		end
	end
	for v30, v31 in pairs(v_u_1) do
		if string.contains(string.upper(v31.description), v27) then
			if v26[v30] == nil then
				local v32 = v_u_1[v30]
				if v32 == nil then
					printError("No command with name %q", v30)
				else
					table.insert(v25, { v30, v32 })
					v26[v30] = true
				end
			end
		end
	end
	for v33, v34 in pairs(v_u_1) do
		if v34.arguments ~= nil then
			for _, v35 in ipairs(v34.arguments) do
				if string.contains(string.upper(v35), v27) then
					if v26[v33] == nil then
						local v36 = v_u_1[v33]
						if v36 == nil then
							printError("No command with name %q", v33)
						else
							table.insert(v25, { v33, v36 })
							v26[v33] = true
						end
					end
				end
			end
		end
	end
	if #v25 == 0 then
		return "Error: no results\nTry a different search term or use \'help\' to list all commands"
	end
	setFileLogPrefixTimestamp(false)
	for _, v37 in ipairs(v25) do
		local v38 = v37[1]
		local v39 = v37[2].arguments == nil and "" or (" " .. table.concat(v37[2].arguments, ", ") or "")
		local v40 = v37[2].description
		print(v38 .. v39 .. "\n        " .. v40)
	end
	print(string.format("Listed %d script-defined console commands for search \'%s\'. Use \'help\' to get all available commands", #v25, v27))
	setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
end
if addConsoleCommand ~= nil then
	addConsoleCommand("gsScriptCommandsList", "Lists script-based console commands. Use \'help\' to get all commands", "consoleCommandListCommands", nil)
	addConsoleCommand("gsSearch", "Searches for script-based console commands containing the given string (name and description). Use \'help\' to get all commands", "consoleCommandSearchCommands", nil)
end
function log(...)
	local v41 = ""
	for v42 = 1, select("#", ...) do
		local v43 = select
		v41 = v41 .. " " .. tostring(v43(v42, ...))
	end
	print(v41)
end
local function v_u_54(p44, p45, p46, p47)
	-- upvalues: (copy) v_u_54
	local v48 = p45 or "  "
	local v49 = p46 or 0
	local v50 = p47 or 3
	if v50 >= v49 then
		local v51 = ""
		for v52, v53 in pairs(p44) do
			print(v48 .. tostring(v52) .. " :: " .. tostring(v53))
			if type(v53) == "table" then
				v_u_54(v53, v48 .. "    ", v49 + 1, v50)
			end
		end
		return v51
	end
end
function print_r(p55, p56)
	-- upvalues: (copy) v_u_54
	if p55 == nil then
		print("table: nil")
		return
	elseif type(p55) == "table" then
		if next(p55) == nil then
			print("table: empty")
		else
			setFileLogPrefixTimestamp(false)
			v_u_54(p55, "  ", 0, p56 or 5)
			setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
		end
	else
		print("table: no such table")
		return
	end
end
function printf(p57, ...)
	print(string.format(p57, ...))
end
function ipairs_reverse(p_u_58)
	if type(p_u_58) ~= "table" then
		error(string.format("invalid argument #1 (%s) to \'ipairs_reverse\' (table expected)", (type(p_u_58))), 2)
	end
	local v_u_59 = #p_u_58
	return function()
		-- upvalues: (ref) v_u_59, (copy) p_u_58
		if v_u_59 < 1 then
			return nil
		end
		local v60 = p_u_58[v_u_59]
		if v60 == nil then
			return nil
		end
		v_u_59 = v_u_59 - 1
		return v_u_59 + 1, v60
	end
end
function assertWithCallstack(p61, p62)
	if not p61 then
		if p62 == nil or type(p62) ~= "string" then
			printError("Error: assertion failed!")
		else
			printError("Error: assertion failed: " .. p62)
		end
		printCallstack()
		error("Assertion failed")
	end
end
function registerObjectClassName(p63, p64)
	if g_currentMission ~= nil then
		g_currentMission.objectsToClassName[p63] = p64
	end
end
function unregisterObjectClassName(p65)
	if g_currentMission ~= nil then
		g_currentMission.objectsToClassName[p65] = nil
	end
end
function getNormalizedScreenValues(p66, p67)
	if p66 == nil or p67 == nil then
		printCallstack()
	end
	return p66 / g_referenceScreenWidth * g_aspectScaleX, p67 / g_referenceScreenHeight * g_aspectScaleY
end
function getCorrectTextSize(p68)
	if g_aspectScaleY == nil then
		return p68
	else
		return p68 * g_aspectScaleY
	end
end
function calculateFovY(p69)
	local v70 = getFovY(p69)
	if GS_IS_EDITOR then
		return v70
	end
	local v71 = v70 + (g_gameSettings:getValue(GameSettings.SETTING.FOV_Y) - g_fovYDefault)
	local v72 = g_fovYMin
	local v73 = g_fovYMax
	return math.clamp(v71, v72, v73)
end
if GS_IS_EDITOR then
	function getUserName()
		return ""
	end
	function addConsoleCommand() end
	function removeConsoleCommand() end
	function getAppBasePath()
		return ""
	end
	function getUserProfileAppPath()
		return ""
	end
	function isHeadTrackingAvailable()
		return false
	end
	function getNumDlcPaths()
		return 0
	end
end
if getHasGamepadAxisForceFeedback == nil then
	function getHasGamepadAxisForceFeedback()
		return false
	end
end
if setGamepadAxisForceFeedback == nil then
	function setGamepadAxisForceFeedback() end
end

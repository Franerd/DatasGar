IntroductionHelpSystem = {}
local v_u_1 = Class(IntroductionHelpSystem)
IntroductionHelpSystem.FILENAME = "dataS/introductionHints.xml"
function IntroductionHelpSystem.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.registeredElements = {}
	v4.registeredHints = {}
	v4.shownHints = {}
	v4.drawHelpQueue = {}
	v4.currentElementName = nil
	g_messageCenter:subscribe(MessageType.GUI_BEFORE_OPEN, v4.onMenuOpen, v4)
	g_messageCenter:subscribe(MessageType.APP_SUSPENDED, v4.onAppSuspended, v4)
	return v4
end
function IntroductionHelpSystem.delete(p5)
	g_messageCenter:unsubscribeAll(p5)
end
function IntroductionHelpSystem.registerHelp(p6, p7, p8, p9, p10, p11, p12)
	if p9 == nil then
		Logging.devError("Could not register introduction help. Drawfunction is not defined!")
		printCallstack()
	else
		local v13 = p6.registeredElements[p7]
		if v13 == nil then
			v13 = {
				["name"] = p7,
				["alreadyShown"] = false,
				["waitingForDraw"] = false,
				["canReset"] = true
			}
			p6.registeredElements[p7] = v13
		end
		v13.drawFunction = p9
		v13.availableFunction = p10
		v13.registerCustomInputFunction = p11
		v13.unregisterCustomInputFunction = p12
		v13.target = p8
	end
end
function IntroductionHelpSystem.registerHint(p14, p15, p16, p17)
	if p14.registeredHints[p15] == nil then
		local v18 = {
			["name"] = p15,
			["text"] = p16,
			["alreadyShown"] = Utils.getNoNil(p17, false)
		}
		if p17 then
			local v19 = p14.shownHints
			table.insert(v19, p16)
		end
		p14.registeredHints[p15] = v18
	end
end
function IntroductionHelpSystem.loadShownElements(p20)
	local v21 = g_currentMission.missionInfo
	local v22 = v21 == nil and "" or v21.introductionHelpShownElements
	local v23 = string.split(v22, " ")
	for _, v24 in ipairs(v23) do
		if v24 ~= "" then
			if p20.registeredElements[v24] == nil then
				p20.registeredElements[v24] = {}
			end
			p20.registeredElements[v24].alreadyShown = true
			p20.registeredElements[v24].canReset = false
		end
	end
	local v25 = v21 == nil and "" or v21.introductionHelpShownHints
	local v26 = string.split(v25, " ")
	for _, v27 in ipairs(v26) do
		if v27 ~= "" and p20.registeredHints[v27] == false then
			p20.registeredHints[v27].alreadyShown = true
			local v28 = p20.shownHints
			local v29 = p20.registeredHints[v27].text
			table.insert(v28, v29)
		end
	end
end
function IntroductionHelpSystem.loadHelpElementsFromXML(p_u_30)
	local v_u_31 = XMLFile.load("introductionHelpElementsXML", IntroductionHelpSystem.FILENAME)
	if v_u_31 then
		v_u_31:iterate("hints.hint", function(_, p32)
			-- upvalues: (copy) v_u_31, (copy) p_u_30
			local v33 = v_u_31:getString(p32 .. "#id")
			local v34 = v_u_31:getString(p32 .. "#text")
			if v33 ~= nil and v34 ~= nil then
				p_u_30:registerHint(v33, g_i18n:convertText(v34), (v_u_31:getBool(p32 .. "#initialActive", false)))
			end
		end)
		v_u_31:delete()
	end
end
function IntroductionHelpSystem.saveShownElements(p35)
	local v36 = ""
	for v37, v38 in pairs(p35.registeredElements) do
		if v38.alreadyShown then
			v36 = v36 .. v37 .. " "
		end
	end
	local v39 = g_currentMission.missionInfo
	if v39 ~= nil then
		v39.introductionHelpShownElements = v36
	end
	local v40 = ""
	for _, v41 in pairs(p35.registeredHints) do
		if v41.alreadyShown then
			v40 = v40 .. v41.name .. " "
		end
	end
	if v39 ~= nil then
		v39.introductionHelpShownHints = v40
	end
end
function IntroductionHelpSystem.setIsActive(_, p42)
	local v43 = g_currentMission.missionInfo
	if v43 ~= nil then
		v43.introductionHelpActive = p42
	end
end
function IntroductionHelpSystem.getIsActive(_)
	local v44 = not g_guidedTourManager:getIsTourRunning()
	if v44 then
		v44 = g_currentMission.missionInfo.introductionHelpActive
	end
	return v44
end
function IntroductionHelpSystem.getIsHelpVisible(p45)
	return p45.currentElement ~= nil
end
function IntroductionHelpSystem.showHelp(p46, p47, p48, p49, p50, p51, p52)
	local v53 = p46.registeredElements[p47]
	if v53 == nil or v53.drawFunction == nil or (v53.alreadyShown or v53.waitingForDraw) and not p48 then
		if p51 ~= nil then
			p51(p52)
		end
	else
		v53.waitingForDraw = true
		v53.blockInput = Utils.getNoNil(p49, true)
		v53.customText = p50
		v53.callback = p51
		v53.callbackTarget = p52
		table.addElement(p46.drawHelpQueue, v53)
	end
end
function IntroductionHelpSystem.hideHelp(p54, p55, p56)
	local v57 = p54.registeredElements[p55]
	if v57 ~= nil and (v57.canReset or p56) then
		v57.waitingForDraw = false
		table.removeElement(p54.drawHelpQueue, v57)
		if v57 == p54.currentElement then
			p54:revertInputContext()
			if p54.currentElement.callback ~= nil then
				p54.currentElement.callback(p54.currentElement.callbackTarget)
			end
			p54.currentElement = nil
		end
	end
end
function IntroductionHelpSystem.hideAll(p58)
	for _, v59 in ipairs(p58.drawHelpQueue) do
		p58.registeredElements[v59.name].alreadyShown = true
	end
	p58:saveShownElements()
	p58.drawHelpQueue = {}
	if p58.currentElement ~= nil then
		p58:onContinueNext()
	end
end
function IntroductionHelpSystem.showHint(p60, p61, p62, p63)
	local v64 = p60.registeredHints[p61]
	if v64 ~= nil and not v64.alreadyShown then
		InfoDialog.show(v64.text, p62, p63)
		local v65 = p60.shownHints
		local v66 = v64.text
		table.insert(v65, v66)
		v64.alreadyShown = true
		p60:saveShownElements()
	end
end
function IntroductionHelpSystem.resetElement(p67, p68, p69)
	local v70 = p67.registeredElements[p68]
	if v70 ~= nil and (v70.canReset or p69) then
		v70.alreadyShown = false
		v70.waitingForDraw = false
		table.removeElement(p67.drawHelpQueue, v70)
		if v70 == p67.currentElement then
			p67:revertInputContext()
			if p67.currentElement.callback ~= nil then
				p67.currentElement.callback(p67.currentElement.callbackTarget)
			end
			p67.currentElement = nil
		end
	end
end
function IntroductionHelpSystem.getCanShowHelp(_)
	if g_gui:getIsGuiVisible() then
		return false
	else
		return not g_appIsSuspended
	end
end
function IntroductionHelpSystem.update(p71, _)
	if p71.currentElement == nil and p71:getCanShowHelp() then
		while #p71.drawHelpQueue > 0 do
			local v72 = table.remove(p71.drawHelpQueue, 1)
			p71.registeredElements[v72.name].alreadyShown = true
			p71:saveShownElements()
			if v72.availableFunction ~= nil and not v72.availableFunction(v72.target) then
				v72 = nil
			end
			if v72 ~= nil then
				if v72.blockInput then
					if v72.registerCustomInputFunction == nil then
						g_inputBinding:setContext(v72.name)
						local _, v73 = g_inputBinding:registerActionEvent(InputAction.INTRODUCTION_HELP_SKIP, p71, p71.onContinueNext, false, true, false, true)
						g_inputBinding:setActionEventText(v73, g_i18n:getText("button_continue"))
						if g_touchHandler ~= nil then
							g_touchHandler:setCustomContext(v72.name, true)
							p71.currentTouchArea = g_touchHandler:registerTouchArea(0, 0, 1, 1, 0, 0, TouchHandler.TRIGGER_UP, p71.onContinueNextTouch, p71)
						end
					else
						v72.registerCustomInputFunction(v72.target)
					end
				end
				p71.currentElement = v72
				break
			end
		end
	end
	if p71.currentElement ~= nil and (p71.currentElement.availableFunction ~= nil and not p71.currentElement.availableFunction(p71.currentElement.target)) then
		p71:onContinueNext()
	end
end
function IntroductionHelpSystem.draw(p74)
	if p74.currentElement ~= nil then
		new2DLayer()
		p74.currentElement.drawFunction(p74.currentElement.target, p74.currentElement.customText)
	end
end
function IntroductionHelpSystem.onMenuOpen(p75)
	local _ = p75.currentElement == nil
end
function IntroductionHelpSystem.onAppSuspended(p76)
	local _ = p76.currentElement == nil
end
function IntroductionHelpSystem.revertInputContext(p77)
	local v78 = p77.currentElement
	if v78 ~= nil and v78.blockInput then
		if v78.unregisterCustomInputFunction == nil then
			if g_touchHandler ~= nil then
				g_touchHandler:revertCustomContext()
				if p77.currentTouchArea ~= nil then
					g_touchHandler:removeTouchArea(p77.currentTouchArea)
					p77.currentTouchArea = nil
				end
			end
			g_inputBinding:removeActionEventsByTarget(p77)
			g_inputBinding:revertContext()
			return
		end
		v78.unregisterCustomInputFunction(v78.target)
	end
end
function IntroductionHelpSystem.onContinueNextTouch(p79)
	if not g_gui:getIsGuiVisible() then
		p79:onContinueNext()
	end
end
function IntroductionHelpSystem.onContinueNext(p80)
	if p80.currentElement ~= nil then
		p80.currentElement.canReset = false
		p80:revertInputContext()
		if p80.currentElement.callback ~= nil then
			p80.currentElement.callback(p80.currentElement.callbackTarget)
		end
		p80.currentElement = nil
	end
end
function IntroductionHelpSystem.getShownHints(p81)
	return p81.shownHints
end
function IntroductionHelpSystem.resetHelpSystem(p82)
	for _, v83 in pairs(p82.registeredElements) do
		v83.alreadyShown = false
		if v83.waitingForDraw ~= nil then
			v83.waitingForDraw = false
		end
	end
end
function IntroductionHelpSystem.resetHelpSystemWithDraw(p84)
	for _, v85 in pairs(p84.registeredElements) do
		if v85.alreadyShown == true then
			v85.waitingForDraw = true
			v85.alreadyShown = false
			local v86 = p84.drawHelpQueue
			table.insert(v86, v85)
		end
	end
end

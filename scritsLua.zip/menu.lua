function OnLoadingScreen(p_u_1, p_u_2, p_u_3)
	local v4 = Utils.getModNameAndBaseDirectory(p_u_1.scriptFilename)
	source(p_u_1.scriptFilename, v4)
	if v4 == nil or ClassUtil.getClassModName(p_u_1.scriptClass) == v4 then
		local v_u_5 = ClassUtil.getClassObject(p_u_1.scriptClass)
		if v_u_5 == nil then
			printError("Error: mission class " .. p_u_1.scriptClass .. " could not be found.")
			OnInGameMenuMenu()
		else
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) v_u_5, (copy) p_u_1
				if g_server ~= nil or g_client ~= nil then
					g_currentMission = v_u_5.new(p_u_1.baseDirectory, nil)
					g_masterServerConnection:setCallbackTarget(g_currentMission)
				end
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_3
				if g_server ~= nil or g_client ~= nil then
					g_currentMission:initialize()
					g_currentMission:setLoadingScreen(p_u_3)
				end
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_1, (copy) p_u_2
				if g_server ~= nil or g_client ~= nil then
					g_currentMission:setMissionInfo(p_u_1, p_u_2)
				end
			end, "menu - OnLoadingScreen - setMissionInfo")
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_2
				if g_server ~= nil or g_client ~= nil then
					if not g_currentMission.cancelLoading then
						if p_u_2.isMultiplayer then
							if p_u_2.isClient then
								g_client:setNetworkListener(g_currentMission)
								g_client:start(p_u_2.serverAddress, p_u_2.serverPort, p_u_2.relayHeader)
								g_masterServerConnection:disconnectFromMasterServer()
							else
								g_server:setNetworkListener(g_currentMission)
								g_client:setNetworkListener(g_currentMission)
							end
						else
							g_server:setNetworkListener(g_currentMission)
							g_client:setNetworkListener(g_currentMission)
							g_server:startLocal()
						end
						if g_server ~= nil then
							g_server:init()
						end
						if not (p_u_2.isMultiplayer and p_u_2.isClient) then
							g_client:startLocal()
						end
					end
				end
			end)
		end
	else
		printError("Error: mission class " .. p_u_1.scriptClass .. " does not match expected mod name " .. v4)
		OnInGameMenuMenu()
		return
	end
end
function OnInGameMenuMenu(p6, p7)
	saveReadSavegameFinish("", nil)
	startFrameRepeatMode()
	setPresenceMode(PresenceModes.PRESENCE_IDLE)
	if g_currentMission ~= nil then
		g_currentMission.cancelLoading = true
	end
	cancelAllStreamedI3DFiles()
	cancelAllStreamedI3DFiles()
	g_asyncTaskManager:flushAllTasks()
	g_asyncTaskManager:flushAllTasks()
	setStreamLowPriorityI3DFiles(true)
	if g_currentMission ~= nil and (g_currentMission.missionDynamicInfo ~= nil and g_currentMission.missionDynamicInfo.isMultiplayer) then
		netSetIsEventProcessingEnabled(true)
	end
	g_masterServerConnection:disconnectFromMasterServer()
	g_masterServerConnection:setCallbackTarget(nil)
	if g_client ~= nil then
		g_client:stop()
	end
	if g_server ~= nil then
		g_server:stop()
	end
	local v8 = false
	local v9
	if g_currentMission == nil then
		v9 = false
		v8 = true
	else
		v9 = g_currentMission.missionInfo == nil and true or g_currentMission.missionInfo:isa(FSCareerMissionInfo)
	end
	if g_currentMission ~= nil then
		g_gui:showGui("")
		g_currentMission:delete()
	end
	g_currentMission = nil
	g_server = nil
	g_client = nil
	g_connectionManager:shutdownAll()
	g_i3DManager:clearEntireSharedI3DFileCache(g_isDevelopmentVersion)
	g_mpLoadingScreen:unloadGameRelatedData()
	g_gameStateManager:setGameState(GameState.MENU_MAIN)
	forceEndFrameRepeatMode()
	if p7 and GS_PLATFORM_PLAYSTATION then
		ConnectionFailedDialog.showMasterServerConnectionFailedReason(MasterServerConnection.FAILED_CONNECTION_LOST, "MainScreen")
	else
		if v9 then
			local v10 = RestartManager.START_SCREEN_MAIN
			if p6 then
				v10 = RestartManager.START_SCREEN_GAMEPAD_SIGNIN
			end
			RestartManager:setStartScreen(v10)
			doRestart(false, "")
			return
		end
		if v8 then
			g_gui:showGui("MainScreen")
		else
			g_gameSettings:save()
			if p6 then
				g_gui:showGui("GamepadSigninScreen")
			else
				g_gui:showGui("MainScreen")
			end
		end
	end
	g_inputBinding:setShowMouseCursor(true)
	simulatePhysics(false)
end

FileSystemUtil = {}
function FileSystemUtil.getItems(p_u_1, p_u_2)
	local v_u_3 = {}
	if not string.endsWith(p_u_1, "/") then
		p_u_1 = p_u_1 .. "/"
	end
	local v8 = {
		["FileSystemUtilystemItemCallback"] = function(_, p4, p5)
			-- upvalues: (copy) p_u_2, (ref) p_u_1, (copy) v_u_3
			local v6 = {}
			if p_u_2 then
				p4 = p_u_1 .. p4 or p4
			end
			v6.filename = p4
			v6.isDirectory = p5
			local v7 = v_u_3
			table.insert(v7, v6)
		end
	}
	getFiles(p_u_1, "FileSystemUtilystemItemCallback", v8)
	return v_u_3
end
function FileSystemUtil.getFiles(p_u_9, p_u_10, p_u_11, p_u_12)
	local v_u_13 = {}
	if not string.endsWith(p_u_9, "/") then
		p_u_9 = p_u_9 .. "/"
	end
	local v19 = {
		["FileSystemUtilystemItemCallback"] = function(_, p14, p15)
			-- upvalues: (copy) p_u_12, (ref) p_u_9, (copy) p_u_10, (copy) p_u_11, (copy) v_u_13
			if p15 then
				if p_u_12 then
					for _, v16 in ipairs(FileSystemUtil.getFiles(p_u_9 .. p14, p_u_10, p_u_11, p_u_12)) do
						local v17 = v_u_13
						table.insert(v17, v16)
					end
				end
				return
			elseif p_u_11 == nil or string.match(p14, p_u_11) then
				if p_u_10 then
					p14 = p_u_9 .. p14 or p14
				end
				local v18 = v_u_13
				table.insert(v18, p14)
			end
		end
	}
	getFiles(p_u_9, "FileSystemUtilystemItemCallback", v19)
	return v_u_13
end
function FileSystemUtil.getDirectories(p_u_20, p_u_21, p_u_22)
	local v_u_23 = {}
	if not string.endsWith(p_u_20, "/") then
		p_u_20 = p_u_20 .. "/"
	end
	local v27 = {
		["FileSystemUtilystemItemCallback"] = function(_, p24, p25)
			-- upvalues: (copy) p_u_22, (copy) p_u_21, (ref) p_u_20, (copy) v_u_23
			if p25 then
				if p_u_22 == nil or string.match(p24, p_u_22) then
					if p_u_21 then
						p24 = p_u_20 .. p24 or p24
					end
					local v26 = v_u_23
					table.insert(v26, p24)
				end
			else
				return
			end
		end
	}
	getFiles(p_u_20, "FileSystemUtilystemItemCallback", v27)
	return v_u_23
end

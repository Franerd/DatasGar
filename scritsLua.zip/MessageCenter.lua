MessageCenter = {}
local v_u_1 = Class(MessageCenter)
source("dataS/scripts/MessageType.lua")
function MessageCenter.new(_)
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3.subscribers = {}
	v3.queue = {}
	return v3
end
function MessageCenter.delete(_) end
function MessageCenter.update(p4, _)
	if #p4.queue > 0 then
		local v5 = 1
		while true do
			local v6 = p4.queue[v5]
			if v6 == nil then
				break
			end
			if v6.targetUpdateLoopIndex == nil or g_updateLoopIndex >= v6.targetUpdateLoopIndex then
				local v7 = v6.messageType
				local v8 = v6.arguments
				p4:publish(v7, unpack(v8))
				table.remove(p4.queue, v5)
			else
				v5 = v5 + 1
			end
		end
	end
end
function MessageCenter.subscribe(p9, p10, p11, p12, p13, p14)
	if p10 == nil then
		Logging.warning("Tried subscribing to a message with a nil-value message type. Check subscribe() function call arguments at:")
		printCallstack()
		return
	elseif p11 == nil then
		Logging.warning("Tried subscribing to a message with a nil-value callback. Check subscribe() function call arguments at:")
		printCallstack()
	else
		assertWithCallstack(type(p11) == "function", "Error: MessageCenter:subscribe(): given argument \'callback\' is not a function")
		local v15 = p9.subscribers[p10]
		if v15 == nil then
			v15 = {}
			p9.subscribers[p10] = v15
		end
		local v16 = {
			["callback"] = p11,
			["callbackTarget"] = p12,
			["argument"] = p13,
			["isOneShot"] = Utils.getNoNil(p14, false)
		}
		table.insert(v15, v16)
	end
end
function MessageCenter.subscribeOneshot(p17, p18, p19, p20, p21)
	p17:subscribe(p18, p19, p20, p21, true)
end
function MessageCenter.unsubscribe(p22, p23, p24)
	local v25 = p22.subscribers[p23]
	if v25 ~= nil then
		for v26 = #v25, 1, -1 do
			if v25[v26].callbackTarget == p24 then
				table.remove(v25, v26)
			end
		end
		if #v25 == 0 then
			p22.subscribers[p23] = nil
		end
	end
end
function MessageCenter.unsubscribeAll(p27, p28)
	for v29, v30 in pairs(p27.subscribers) do
		for v31 = #v30, 1, -1 do
			if v30[v31].callbackTarget == p28 then
				table.remove(v30, v31)
			end
		end
		if #v30 == 0 then
			p27.subscribers[v29] = nil
		end
	end
end
function MessageCenter.publish(p32, p33, ...)
	if p33 == nil then
		Logging.warning("Tried publishing a message with a nil-value message type. Check publish() function call arguments at:")
		printCallstack()
	else
		local v34 = p32.subscribers[p33]
		if v34 ~= nil then
			local v35 = 1
			while true do
				local v36 = v34[v35]
				if v36 == nil then
					break
				end
				if v36.callbackTarget == nil then
					if v36.argument == nil then
						v36.callback(...)
					else
						v36.callback(v36.argument, ...)
					end
				elseif v36.argument == nil then
					v36.callback(v36.callbackTarget, ...)
				else
					v36.callback(v36.callbackTarget, v36.argument, ...)
				end
				if v36.isOneShot then
					table.remove(v34, v35)
				else
					v35 = v35 + 1
				end
			end
		end
	end
end
function MessageCenter.publishDelayed(p37, p38, ...)
	if p38 == nil then
		Logging.warning("Tried publishing a message with a nil-value message type. Check publish() function call arguments at:")
		printCallstack()
	else
		p37:publishDelayedAfterFrames(p38, 1, ...)
	end
end
function MessageCenter.publishDelayedAfterFrames(p39, p40, p41, ...)
	if p40 == nil then
		Logging.warning("Tried publishing a message with a nil-value message type. Check publish() function call arguments at:")
		printCallstack()
	else
		local v42 = {
			["messageType"] = p40,
			["targetUpdateLoopIndex"] = g_updateLoopIndex + p41,
			["arguments"] = { ... }
		}
		local v43 = p39.queue
		table.insert(v43, v42)
	end
end
function MessageCenter.consoleCommandShowActiveSubscribers(p44)
	local v45 = 0
	local v46 = 0
	for v47, v48 in pairs(p44.subscribers) do
		local v49 = nil
		if type(v47) == "number" then
			for v50, v51 in pairs(MessageType) do
				if v51 == v47 then
					v49 = v50
					break
				end
			end
			if v49 == nil then
				for v52, v53 in pairs(MessageType.SETTING_CHANGED) do
					if v53 == v47 then
						for v54, v55 in pairs(GameSettings.SETTING) do
							if v52 == v55 then
								v49 = v54
								break
							end
						end
						break
					end
				end
			end
		else
			v49 = ClassUtil.getClassName(v47)
		end
		if v49 == nil then
			v49 = type(v47) .. " " .. tostring(v47)
		end
		log("Message Subscribers for \'" .. v49 .. "\':")
		for _, v56 in ipairs(v48) do
			local v57 = v56.callbackTarget
			if v57 ~= nil then
				v57 = ClassUtil.getClassNameByObject(v57)
			end
			log("    ", v57 or (v56.callback or "Unknown"))
			v45 = v45 + 1
		end
		v46 = v46 + 1
	end
	log("\n Total Messages:" .. v46)
	log("Total Subscribers: " .. v45)
end

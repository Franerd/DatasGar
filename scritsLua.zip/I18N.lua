I18N = {}
local v_u_1 = Class(I18N)
I18N.L10N_FILES_DIRECTORY = "dataS/l10n/"
I18N.MONEY_MAX_DISPLAY_VALUE = 999999999
I18N.MONEY_MIN_DISPLAY_VALUE = -999999999
g_xmlManager:addEarlyCreateSchemaFunction(function()
	I18N.xmlSchema = XMLSchema.new("l18n")
	I18N.registerXMLPaths(I18N.xmlSchema)
end)
function I18N.registerXMLPaths(p2)
	p2:register(XMLValueType.FLOAT, "l10n.fluid#factor", "", 1)
	p2:register(XMLValueType.FLOAT, "l10n.power#factor", "", 1)
	p2:register(XMLValueType.STRING, "l10n.elements.e(?)#k", "The name of the string", nil)
	p2:register(XMLValueType.STRING, "l10n.elements.e(?)#v", "The text of the string", nil)
end
function I18N.new()
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1
	local v4 = setmetatable({}, v3)
	v4.texts = {}
	v4.modEnvironments = {}
	if g_addTestCommands then
		addConsoleCommand("gsI18nVerify", "Checks all localization files for empty or \'TODO\' texts, warns if placeholders mismatch between languages", "consoleCommandVerifyAll", v4)
	end
	v4.debugActive = StartParams.getIsSet("debugI18N")
	if v4.debugActive then
		print("debugI18N active")
		v4.usedTexts = {}
		v4.printedWarnings = {}
		v4:loadUsedKeysFromXML()
		addConsoleCommand("gsI18nSaveUsedKeysXml", "", "saveUsedKeysToXML", v4)
		g_messageCenter:subscribe(MessageType.GUI_INGAME_OPEN, v4.saveUsedKeysToXML, v4)
		g_messageCenter:subscribe(MessageType.GUI_MAIN_SCREEN_OPEN, v4.saveUsedKeysToXML, v4)
	end
	return v4
end
function I18N.load(p5)
	p5.texts = {}
	if not g_isDevelopmentVersion and g_languageShort ~= "en" then
		local v6 = XMLFile.load("l10n_en", I18N.L10N_FILES_DIRECTORY .. "l10n_en.xml")
		p5:loadEntriesFromXML(v6, p5.texts, true)
		v6:delete()
	end
	local v7 = XMLFile.load("l10n" .. g_languageSuffix, I18N.L10N_FILES_DIRECTORY .. "l10n" .. g_languageSuffix .. ".xml")
	p5:loadEntriesFromXML(v7, p5.texts, true)
	p5:mergePlatformText(p5.texts)
	p5.fluidFactor = v7:getFloat("l10n.fluid#factor", 1)
	p5.powerFactorHP = v7:getFloat("l10n.power#factor", 1)
	p5.powerFactorKW = 0.735499
	p5.moneyUnit = GS_MONEY_EURO
	p5.useMiles = false
	p5.useFahrenheit = false
	p5.useAcre = false
	v7:delete()
	p5.thousandsGroupingChar = p5:getText("unit_digitGroupingSymbol")
	if p5.thousandsGroupingChar ~= " " and (p5.thousandsGroupingChar ~= "." and p5.thousandsGroupingChar ~= ",") then
		p5.thousandsGroupingChar = " "
	end
	p5.decimalSeparator = p5:getText("unit_decimalSymbol") or "."
	if g_gameSettings ~= nil then
		p5.moneyUnit = g_gameSettings:getValue(GameSettings.SETTING.MONEY_UNIT)
		p5.useMiles = g_gameSettings:getValue(GameSettings.SETTING.USE_MILES)
		p5.useFahrenheit = g_gameSettings:getValue(GameSettings.SETTING.USE_FAHRENHEIT)
		p5.useAcre = g_gameSettings:getValue(GameSettings.SETTING.USE_ACRE)
	end
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.MONEY_UNIT], p5.setMoneyUnit, p5)
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.USE_MILES], p5.setUseMiles, p5)
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.USE_ACRE], p5.setUseAcre, p5)
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.USE_FAHRENHEIT], p5.setUseFahrenheit, p5)
end
function I18N.delete(p8)
	g_messageCenter:unsubscribeAll(p8)
end
function I18N.loadEntriesFromXML(_, p9, p10, p11)
	for _, v12 in p9:iterator("l10n.elements.e") do
		local v13 = p9:getString(v12 .. "#k")
		if string.isNilOrWhitespace(v13) then
			Logging.xmlWarning(p9, "Node at path %q is missing a name (k attribute)", v12)
		elseif p10[v13] == nil or p11 then
			local v14 = p9:getString(v12 .. "#v")
			if string.isNilOrWhitespace(v14) then
				Logging.xmlWarning(p9, "Node at path %q is missing a text (v attribute)", v12)
			else
				p10[v13] = string.gsub(v14, "\r\n", "\n")
			end
		end
	end
end
function I18N.mergePlatformText(_, p15)
	for v16, v17 in pairs(p15) do
		for _, v18 in ipairs(Platform.l10nPostfixes) do
			local v19 = v16 .. v18
			if p15[v19] ~= nil then
				p15[v16] = p15[v19]
				break
			end
		end
		if p15[v16] ~= v17 then
			Logging.devInfo("I18N platform specific text %s: \'%s\'", v16, p15[v16])
		end
	end
end
function I18N.saveUsedKeysToXML(p20)
	local v21 = getUserProfileAppPath() .. "l10n_usedKeys.xml"
	local v22 = createXMLFile("l10n_usedKeys", v21, "l10n")
	if v22 == 0 then
		Logging.error("Failed to create l10n_usedKeys xml file")
	else
		local v23 = 0
		for v24 in pairs(p20.usedTexts) do
			setXMLString(v22, string.format("l10n.used(%d)#k", v23), v24)
			v23 = v23 + 1
		end
		saveXMLFile(v22)
		delete(v22)
		local v25 = table.size(p20.texts)
		local v26 = v25 - v23
		print(string.format("I18N debug: saved \'%s\': %i unused, %i used, %i total keys ", v21, v26, v23, v25))
	end
end
function I18N.loadUsedKeysFromXML(p_u_27)
	local v28 = getUserProfileAppPath() .. "l10n_usedKeys.xml"
	local v_u_29 = XMLFile.loadIfExists("l10n_usedKeys", v28)
	if v_u_29 then
		v_u_29:iterate("l10n.used", function(_, p30)
			-- upvalues: (copy) p_u_27, (copy) v_u_29
			p_u_27.usedTexts[v_u_29:getString(p30 .. "#k")] = true
		end)
		print(string.format("I18N debug: loaded \'%s\': %i used keys ", v28, table.size(p_u_27.usedTexts)))
		v_u_29:delete()
	else
		Logging.devWarning("I18N debug: Unable to load used loca keys file %s", v28)
	end
end
function I18N.addModI18N(p_u_31, p_u_32)
	local v33 = {
		["texts"] = {}
	}
	setmetatable(v33, {
		["__index"] = p_u_31
	})
	local v34 = v33.texts
	local v35 = {
		["__index"] = p_u_31.texts
	}
	setmetatable(v34, v35)
	p_u_31.modEnvironments[p_u_32] = v33
	function v33.setText(p36, p37, p38)
		p36.texts[p37] = p38
	end
	function v33.hasModText(p39, p40)
		return p39.texts[p40] ~= nil
	end
	function v33.setGlobalText(_, p41, p42)
		-- upvalues: (copy) p_u_32, (copy) p_u_31
		local v43 = p_u_32 .. "." .. p41
		if p_u_31.texts[v43] == nil then
			p_u_31.texts[v43] = p42
		end
	end
	return v33
end
function I18N.getText(p44, p45, p46)
	local v47 = nil
	if p46 ~= nil then
		local v48 = p44.modEnvironments[p46]
		if v48 ~= nil then
			v47 = v48.texts[p45]
		end
	end
	if v47 == nil then
		v47 = p44.texts[p45]
		if v47 == nil then
			v47 = string.format("Missing \'%s\' in l10n%s.xml", p45, g_languageSuffix)
			if g_showDevelopmentWarnings then
				Logging.devWarning(v47)
			end
		end
	end
	if p44.debugActive then
		p44.usedTexts[p45] = true
	end
	if string.trim(utf8ToUpper(v47)) ~= "TODO" then
		return v47
	end
	if p44.debugActive and p44.printedWarnings[p45] == nil then
		Logging.devWarning("TODO text set for loca key \'%s\'", p45)
		p44.printedWarnings[p45] = true
	end
	return "TODO:" .. p45
end
function I18N.hasText(p49, p50, p51)
	if p50 == nil then
		return false
	end
	local v52 = nil
	if p51 ~= nil then
		local v53 = p49.modEnvironments[p51]
		if v53 ~= nil then
			v52 = v53.texts[p50]
		end
	end
	if v52 == nil then
		v52 = p49.texts[p50]
	end
	return v52 ~= nil
end
function I18N.setText(p54, p55, p56)
	p54.texts[p55] = p56
end
function I18N.setMoneyUnit(p57, p58)
	p57.moneyUnit = p58
end
function I18N.setUseMiles(p59, p60)
	p59.useMiles = p60
end
function I18N.setUseFahrenheit(p61, p62)
	p61.useFahrenheit = p62
end
function I18N.setUseAcre(p63, p64)
	p63.useAcre = p64
end
function I18N.getCurrency(p65, p66)
	return p66 * p65:getCurrencyFactor()
end
function I18N.getCurrencyFactor(p67)
	return p67.moneyUnit == GS_MONEY_EURO and 1 or (p67.moneyUnit == GS_MONEY_POUND and 0.79 or 1.34)
end
function I18N.getMeasuringUnit(p68, p69)
	local v70 = p69 and "" or "Short"
	if p68.useMiles then
		return p68.texts["unit_miles" .. v70]
	else
		return p68.texts["unit_km" .. v70]
	end
end
function I18N.getVolumeUnit(p71, p72)
	return p71.texts["unit_liter" .. (p72 and "" or "Short")]
end
function I18N.getVolume(_, p73)
	return p73
end
function I18N.getSpeedMeasuringUnit(p74)
	if p74.useMiles then
		return p74.texts.unit_mph
	else
		return p74.texts.unit_kmh
	end
end
function I18N.getSpeed(p75, p76)
	if p75.useMiles then
		return p76 * 0.62137
	else
		return p76
	end
end
function I18N.getTemperature(p77, p78)
	if p77.useFahrenheit then
		return p78 * 1.8 + 32
	else
		return p78
	end
end
function I18N.formatTemperature(p79, p80, p81, p82)
	local v83 = p79:getTemperature(p80)
	local v84 = p79:getTemperatureUnit(p82)
	return string.format("%1." .. (p81 or 0) .. "f%s", v83, v84)
end
function I18N.getTemperatureUnit(p85, p86)
	local v87 = p86 and "" or "Short"
	if p85.useFahrenheit then
		return p85.texts["unit_fahrenheit" .. v87]
	else
		return p85.texts["unit_celsius" .. v87]
	end
end
function I18N.getAreaUnit(p88, p89)
	local v90 = p89 and "" or "Short"
	if p88.useAcre then
		return p88.texts["unit_acre" .. v90]
	else
		return p88.texts["unit_ha" .. v90]
	end
end
function I18N.getArea(p91, p92)
	if p91.useAcre then
		return p92 * 2.4711
	else
		return p92
	end
end
function I18N.formatArea(p93, p94, p95, p96)
	local v97 = p93:getArea(p94)
	local v98 = p93:getAreaUnit(p96)
	local v99 = MathUtil.round(v97, p95) .. " " .. v98
	return tostring(v99)
end
function I18N.getDistanceUnit(p100, p101)
	local v102 = p101 and "" or "Short"
	if p100.useMiles then
		return p100.texts["unit_ft" .. v102]
	else
		return p100.texts["unit_m" .. v102]
	end
end
function I18N.getDistance(p103, p104, p105)
	if p103.useMiles then
		if p105 then
			return p104 * 3.28084
		else
			return p104 * 0.62137
		end
	else
		return p104
	end
end
function I18N.formatDistance(p106, p107, p108, p109)
	local v110 = p106:getDistance(p107, true)
	local v111 = p106:getDistanceUnit(p109)
	local v112 = MathUtil.round(v110, p108) .. " " .. v111
	return tostring(v112)
end
function I18N.getFluid(p113, p114)
	return p114 * p113.fluidFactor
end
function I18N.formatFluid(p115, p116)
	return string.format("%s %s", p115:formatNumber(p115:getFluid(p116)), g_i18n:getText("unit_literShort"))
end
function I18N.formatVolume(p117, p118, p119, p120)
	return string.format("%s %s", p117:formatNumber(p117:getVolume(p118), p119), p120 or p117:getVolumeUnit())
end
function I18N.formatMass(p121, p122, p123, p124)
	local v125 = "unit_tonsShort"
	local v126 = 1
	if p124 ~= false then
		if p122 < 1 and (p123 == nil or p123 == 0) then
			p122 = p122 * 1000
			v126 = 0
			v125 = "unit_kg"
		elseif p122 < 1 and (p123 ~= nil and p123 ~= 0) then
			p122 = p122 * 1000
			p123 = p123 * 1000
			v126 = 0
			v125 = "unit_kg"
		end
	end
	if p123 == nil or p123 == 0 then
		return string.format("%s %s", p121:formatNumber(MathUtil.round(p122, v126), v126), g_i18n:getText(v125))
	else
		return string.format("%s-%s %s", p121:formatNumber(MathUtil.round(p122, v126), v126), p121:formatNumber(MathUtil.round(p123, v126), v126), g_i18n:getText(v125))
	end
end
function I18N.getPower(p127, p128)
	return p128 * p127.powerFactorHP, p128 * p127.powerFactorKW
end
function I18N.formatNumber(p129, p130, p131, p132)
	local v133 = p131 or 0
	if v133 == 0 then
		if p130 == nil then
			printCallstack()
		end
		if p130 < 0 then
			p130 = math.ceil(p130)
		else
			p130 = math.floor(p130)
		end
	end
	local v134 = MathUtil.round
	local v135 = tostring(v134(p130, v133))
	local v136, v137, v138 = string.match(v135, "^([^%d]*%d)(%d*)[.]?(%d*)")
	local v139 = v136 .. v137:reverse():gsub("(%d%d%d)", "%1" .. p129.thousandsGroupingChar):reverse()
	if v133 > 0 then
		local v140 = v138:len()
		if v140 > 0 and (v138 ~= string.rep("0", v140) or p132) then
			v139 = v139 .. p129.decimalSeparator .. v138:sub(1, v133)
		end
	end
	return v139
end
function I18N.formatMoney(p141, p142, p143, p144, p145)
	local v146 = I18N.MONEY_MIN_DISPLAY_VALUE
	local v147 = I18N.MONEY_MAX_DISPLAY_VALUE
	local v148 = p141:formatNumber(math.clamp(p142, v146, v147), p143)
	if p144 == nil or p144 then
		if p145 == nil or not p145 then
			return v148 .. "\194\160" .. p141:getCurrencySymbol(true)
		end
		v148 = p141:getCurrencySymbol(true) .. "\194\160" .. v148
	end
	return v148
end
function I18N.getCurrencySymbol(p149, p150)
	local v151 = p150 and "Short" or ""
	if p149.moneyUnit == GS_MONEY_EURO then
		return p149:getText("unit_euro" .. v151)
	elseif p149.moneyUnit == GS_MONEY_POUND then
		return p149:getText("unit_pound" .. v151)
	else
		return p149:getText("unit_dollar" .. v151)
	end
end
function I18N.convertText(_, p152, p153)
	if p152 ~= nil then
		if string.startsWith(p152, "$l10n_") then
			p152 = g_i18n:getText(p152:sub(7), p153)
		end
		return p152
	end
	Logging.warning("Text to convert is nil")
	printCallstack()
	return nil
end
function I18N.insertTextParams(p154, p155, p156, p157, p158)
	local _, v159 = string.gsub(p155, "%%s", "")
	local v160 = string.split(p156, "|")
	if #v160 == v159 then
		for v161 = 1, #v160 do
			v160[v161] = p154:convertText(v160[v161], p157)
		end
		return string.format(p155, unpack(v160))
	elseif p158 == nil then
		Logging.warning("Unable to insert parameters into text. Invalid number of params. (%d found in string \'%s\', %d params given in \'%s\')", v159, p155, #v160, p156)
		return p155
	else
		Logging.xmlWarning(p158, "Unable to insert parameters into text. Invalid number of params. (%d found in string \'%s\', %d params given in \'%s\')", v159, p155, #v160, p156)
		return p155
	end
end
function I18N.getCurrentDate(_)
	if g_languageShort == "en" then
		return getDate("%Y-%m-%d")
	elseif g_languageShort == "de" then
		return getDate("%d.%m.%Y")
	elseif g_languageShort == "jp" then
		return getDate("%Y/%m/%d")
	else
		return getDate("%d/%m/%Y")
	end
end
function I18N.consoleCommandVerifyAll(p162, p163, p164, p165)
	p162:verifyLocaFiles(Utils.stringToBoolean(p163), p164 or I18N.L10N_FILES_DIRECTORY, p165 or "l10n_")
end
function I18N.verifyLocaFiles(p166, p167, p168, p169)
	print("Verifying i18n files:")
	setFileLogPrefixTimestamp(false)
	if p167 then
		printWarning("Warning: Ignoring \'TODO\' and \'\' texts")
	end
	print("loading lang files")
	local v170 = {}
	local v171 = {}
	local v172 = nil
	for v173 = 0, getNumOfLanguages() - 1 do
		local v174 = getLanguageCode(v173)
		local v175 = p169 .. v174 .. ".xml"
		if v174 == "en" then
			v172 = v175
		end
		local v176 = p168 .. v175
		if fileExists(v176) then
			local v177 = {}
			local v178 = XMLFile.load("l10n" .. g_languageSuffix, v176)
			p166:loadEntriesFromXML(v178, v177)
			v178:delete()
			p166:mergePlatformText(v177)
			v170[v175] = v177
			for v179, _ in pairs(v177) do
				v171[v179] = true
			end
			print(string.format("loaded %d entries from %s", table.size(v177), v176))
		else
			printWarning(string.format("Warning: unable to find xml file %s for langIndex %d", v176, v173))
		end
	end
	if next(v170) == nil then
		return "Error: no l10n entries were loaded"
	end
	for v180, _ in pairs(v171) do
		for v181, v182 in pairs(v170) do
			local v183 = v182[v180]
			if v183 == nil then
				printWarning(string.format("Warning: Missing text for %s in %s", v180, v181))
			elseif not p167 and (v183:trim() == "" or v183:find("TODO")) then
				printWarning(string.format("Warning: Empty or todo text for %s in %s", v180, v181))
			end
		end
	end
	local v184 = {}
	for v185, v186 in pairs(v170[v172]) do
		local v187 = ""
		for v188, _ in v186:gmatch("%%%d?%.?%d*%a") do
			v187 = v187 .. v188
		end
		local v189
		if v187 == "" then
			v187 = nil
			v189 = nil
		else
			local _, v190 = v186:gsub("%%", "")
			v189 = v190 % 2
		end
		if v187 ~= nil then
			v184[v185] = { v187, v189 }
			local _, v191 = string.gsub(v187, "%%", "")
			if v191 > 1 then
				printError(string.format("Error: Multiple unnamed format specifiers (%s) in %q", v187, v185))
			end
		end
	end
	for v192, v193 in pairs(v170) do
		if v192 ~= v172 then
			print(v192)
			for v194, v_u_195 in pairs(v193) do
				getTextHeight(1, v_u_195)
				local v196 = ""
				for v197, _ in v_u_195:gmatch("%%%d?%.?%d*%a") do
					v196 = v196 .. v197
				end
				local v198
				if v196 == "" then
					v198 = nil
					v196 = nil
				else
					local _, v199 = v_u_195:gsub("%%", "")
					v198 = v199 % 2
				end
				local v200 = v184[v194]
				if v200 then
					v200 = v184[v194][1]
				end
				local v201 = v184[v194]
				if v201 then
					v201 = v184[v194][2]
				end
				if v196 then
					if utf8ToUpper(v_u_195) ~= "TODO" then
						local v202 = v170[v172][v194]
						if v196 ~= v200 then
							printError(string.format("Error: Mismatching format strings for key \'%s\' in %s: \'%s\' <-> \'%s\'", v194, v192, v200 or "no placeholder", v196 or "no placeholder"))
							print(string.format("    %s: %s", v172, v202))
							print(string.format("    %s: %s", v192, v_u_195))
						end
						if v198 ~= v201 then
							printError(string.format("Error: Mismatching \'%%\' characters (possible unescaped \'%%\') for key \'%s\' in %s", v194, v192))
							print(string.format("    %s: %s", v172, v202))
							print(string.format("    %s: %s", v192, v_u_195))
						end
					end
					if v184[v194] and not pcall(function()
						-- upvalues: (copy) v_u_195
						string.format(v_u_195, 1, 2, 3, 4, 5, 6, 7, 8, 9)
					end) then
						local v203 = v170[v172][v194]
						printError(string.format("Error: String format cannot be applied on string \'%s\' in %s:\n    en: \'%s\'\n<->\n    %s: \'%s\'", v194, v192, v203, v192, v_u_195))
					end
				end
			end
		end
	end
	setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
	return "Verified all i18n files"
end
function I18N.formatMinutes(p204, p205)
	if p205 == nil then
		return p204:getText("ui_hours_none")
	end
	local v206 = p205 / 60
	local v207 = math.floor(v206)
	local v208 = p205 - v207 * 60
	return string.format(p204:getText("ui_hours"), v207, v208)
end
function I18N.formatPeriod(p209, p210, p211)
	local v212
	if g_currentMission == nil or g_currentMission.environment == nil then
		v212 = false
	else
		v212 = g_currentMission.environment.daylight.latitude < 0
		if p210 == nil then
			p210 = g_currentMission.environment.currentPeriod
		end
	end
	if p210 == nil then
		return nil
	end
	local v213 = p210 + 2
	if v212 then
		v213 = v213 + 6
	end
	return p209:getText("ui_month" .. (v213 - 1) % 12 + 1 .. (p211 and "_short" or ""))
end
function I18N.formatDayInPeriod(p214, p215, p216, p217)
	if g_currentMission == nil or g_currentMission.environment == nil then
		return nil
	else
		if p215 == nil then
			p215 = g_currentMission.environment.currentDayInPeriod
		end
		if p216 == nil then
			p216 = g_currentMission.environment.currentPeriod
		end
		local v218 = p214:formatPeriod(p216, p217)
		if g_currentMission.environment.daysPerPeriod == 1 then
			return v218
		else
			return string.format("%s %d", v218, p215)
		end
	end
end
function I18N.formatNumMonth(p219, p220)
	local v221 = p220 == 1 and "ui_month" or "ui_months"
	return string.format("%d %s", p220, p219:getText(v221))
end
function I18N.formatNumDay(p222, p223)
	local v224 = p223 == 1 and "ui_day" or "ui_days"
	return string.format("%d %s", p223, p222:getText(v224))
end
function I18N.formatCurrentTime(_, _)
	if g_currentMission ~= nil and g_currentMission.environment ~= nil then
		local v225 = g_currentMission.environment.dayTime / 3600000
		local v226 = math.floor(v225)
		local v227 = (v225 - v226) * 60
		local v228 = math.floor(v227)
		return string.format("%02d:%02d", v226, v228)
	end
end

TestI3DManager = {}
function TestI3DManager.init()
	local v1 = TestI3DManager
	v1.file = "data/vehicles/fendt/vario900/vario900.i3d"
	v1.sharedLoadRequestIds = {}
end
function TestI3DManager.update(_) end
function TestI3DManager.draw()
	g_i3DManager:drawDebug()
end
function TestI3DManager.mouseEvent(_, _, _, _, _) end
function TestI3DManager.keyEvent(_, p2, _, p3)
	if not p3 then
		local v4 = TestI3DManager
		if p2 == Input.KEY_m then
			local v5 = g_i3DManager:loadSharedI3DFileAsync(v4.file, false, false, v4.finishedLoading, TestI3DManager, {
				["file"] = v4.file
			})
			local v6 = v4.sharedLoadRequestIds
			table.insert(v6, v5)
			return
		end
		if p2 == Input.KEY_n then
			local v7 = table.remove(v4.sharedLoadRequestIds, 1)
			if v7 ~= nil then
				g_i3DManager:releaseSharedI3DFile(v7)
				return
			end
		elseif p2 == Input.KEY_q then
			restartApplication(false, "")
		end
	end
end
function TestI3DManager.finishedLoading(_, p8, _, _)
	log("loaded", getName(p8))
	delete(p8)
end

I3DUtil = {}
function I3DUtil.checkChildIndex(p1, p2)
	if getNumOfChildren(p1) > p2 then
		return true
	end
	local v3 = Logging.error
	local v4 = tostring(p2)
	local v5 = I3DUtil.getNodePath(p1)
	local v6 = getNumOfChildren
	v3("Failed to find child %d from node %q, only %s children given", v4, v5, (tostring(v6(p1))))
	printCallstack()
	return false
end
function I3DUtil.indexToObject(p7, p8, p9, p10)
	if p8 == nil or p7 == nil then
		return nil
	end
	local v11
	if p9 == nil then
		v11 = p8
	else
		v11 = p9[p8]
		if v11 == nil then
			v11 = p8
		elseif type(v11) == "table" then
			return v11.nodeId, v11.rootNode
		end
	end
	local v12, v13 = string.find(v11, ">", 1, true)
	local v14 = v12 == nil and 1 or v13 + 1
	local v15
	if type(p7) == "table" then
		local v16
		if v12 == nil then
			v16 = 1
		else
			local v17 = v12 - 1
			local v18 = string.sub(v11, 1, v17)
			local v19 = tonumber(v18)
			if v19 == nil then
				Logging.error("Invalid index format: %s", v11)
			end
			v16 = v19 + 1
		end
		if p7[v16] == nil then
			if (p10 or #p7) < v16 then
				Logging.error("Invalid compound index: %s", v11)
			end
			return nil
		end
		v15 = p7[v16].node
	else
		v15 = p7
	end
	if v12 ~= nil and v13 == string.len(v11) then
		return v15, v15
	end
	if type(p7) ~= "table" and v12 ~= nil then
		Logging.error("Invalid usage of \'>\'! Works with vehicle & placeable components table only. Please replace \'>\' with \'|\' in the xml config. Referenced node: \'%s\'", v11)
		printCallstack()
		return nil
	end
	local v20, v21 = string.find(v11, "|", v14, true)
	local v22 = v15
	while v20 ~= nil do
		local v23 = v20 - 1
		local v24 = string.sub(v11, v14, v23)
		local v25 = tonumber(v24)
		if v25 == nil or not I3DUtil.checkChildIndex(v15, v25) then
			Logging.error("Index not found: %s", v11)
			return nil
		end
		v15 = getChildAt(v15, v25)
		v14 = v21 + 1
		v20, v21 = string.find(v11, "|", v14, true)
	end
	local v26 = string.sub(v11, v14)
	local v27 = tonumber(v26)
	if v27 ~= nil and I3DUtil.checkChildIndex(v15, v27) then
		return getChildAt(v15, v27), v22
	end
	Logging.error("Index not found: %s", v11)
	return nil
end
function I3DUtil.setNumberShaderByValue(p28, p29, p30, p31)
	if p28 ~= nil then
		local v32 = p29 * 10 ^ p30
		local v33 = math.floor(v32)
		for v34 = 0, getNumOfChildren(p28) - 1 do
			local v35 = getChildAt(p28, v34)
			if v33 > 0 then
				local v36 = v33 / 10
				local v37 = v33 - math.floor(v36) * 10
				v33 = (v33 - v37) / 10
				setShaderParameter(v35, "number", v37, 0, 0, 0, false)
			elseif p31 and v34 <= p30 then
				setShaderParameter(v35, "number", 0, 0, 0, 0, false)
			else
				setShaderParameter(v35, "number", -1, 0, 0, 0, false)
			end
		end
	end
end
function I3DUtil.wakeUpObject(p38)
	addImpulse(p38, 0, 0.001, 0, 0, 0, 0, true)
end
function I3DUtil.setWorldDirection(p39, p40, p41, p42, p43, p44, p45, p46, p47, p48)
	local v49 = getParent(p39)
	if p40 == p40 and (p41 == p41 and p42 == p42) then
		if v49 ~= 0 then
			p40, p41, p42 = worldDirectionToLocal(v49, p40, p41, p42)
			p43, p44, p45 = worldDirectionToLocal(v49, p43, p44, p45)
		end
		if p46 ~= nil then
			if p46 == 1 then
				p40 = 0
				if p47 ~= nil then
					p42, p41 = MathUtil.getRotationLimitedVector2(p42, p41, p47, p48)
				end
			elseif p46 == 2 then
				p41 = 0
				if p47 ~= nil then
					p42, p40 = MathUtil.getRotationLimitedVector2(p42, p40, p47, p48)
				end
			else
				p42 = 0
				if p47 ~= nil then
					p40, p41 = MathUtil.getRotationLimitedVector2(p40, p41, p47, p48)
				end
			end
		end
		if p40 * p40 + p41 * p41 + p42 * p42 > 0.0001 then
			setDirection(p39, p40, p41, p42, p43, p44, p45)
		end
	else
		Logging.error("Failed to set world direction: Object \'%s\' dir %.2f %.2f %.2f up %.2f %.2f %.2f", getName(p39), p40, p41, p42, p43, p44, p45)
	end
end
function I3DUtil.setDirection(p50, p51, p52, p53, p54, p55, p56)
	if MathUtil.vector3LengthSq(p51, p52, p53) > 0.0001 then
		setDirection(p50, p51, p52, p53, p54, p55, p56)
	end
end
function I3DUtil.setShaderParameterRec(p57, p58, p59, p60, p61, p62)
	if getHasClassId(p57, ClassIds.SHAPE) and getHasShaderParameter(p57, p58) then
		setShaderParameter(p57, p58, p59, p60, p61, p62, false)
	end
	for v63 = 0, getNumOfChildren(p57) - 1 do
		I3DUtil.setShaderParameterRec(getChildAt(p57, v63), p58, p59, p60, p61, p62)
	end
end
function I3DUtil.setMaterialSlotShaderParameterRec(p64, p65, p66, p67, p68, p69, p70)
	if getHasClassId(p64, ClassIds.SHAPE) and getHasShaderParameter(p64, p66) then
		for v71 = 1, getNumOfMaterials(p64) do
			if getMaterialSlotName(p64, v71 - 1) == p65 then
				setShaderParameter(p64, p66, p67, p68, p69, p70, false, v71 - 1)
			end
		end
	end
	for v72 = 1, getNumOfChildren(p64) do
		I3DUtil.setMaterialSlotShaderParameterRec(getChildAt(p64, v72 - 1), p65, p66, p67, p68, p69, p70)
	end
end
function I3DUtil.setShaderParameter(p73, p74, p75, p76, p77, p78, p79)
	if getHasClassId(p73, ClassIds.SHAPE) then
		setShaderParameter(p73, p74, p75, p76, p77, p78, p79, -1)
	end
end
function I3DUtil.setHideByIndexRec(p80, p81)
	if getHasClassId(p80, ClassIds.SHAPE) and getHasShaderParameter(p80, "hideByIndex") then
		local v82 = getUserAttribute(p80, "hideByIndexMaxIndex")
		if v82 == nil then
			Logging.warning("Try to set hideByIndex on node \'%s\', but \'hideByIndexMaxIndex\' user attribute is missing!", getName(p80))
			printCallstack()
		else
			local v83 = getUserAttribute(p80, "hideByIndexOffset") or 0
			setShaderParameter(p80, "hideByIndex", (1 - p81) * v82 - v83, 0, 0, 0, false)
		end
	end
	for v84 = 0, getNumOfChildren(p80) - 1 do
		I3DUtil.setHideByIndexRec(getChildAt(p80, v84), p81)
	end
end
function I3DUtil.setShapeBonesRec(p85, p86, p87, p88)
	if getHasClassId(p85, ClassIds.SHAPE) then
		setShapeBones(p85, p86, p87, p88)
	end
	local v89 = getNumOfChildren(p85)
	if v89 > 0 then
		for v90 = 0, v89 - 1 do
			I3DUtil.setShapeBonesRec(getChildAt(p85, v90), p86, p87, p88)
		end
	end
end
function I3DUtil.setShapeCastShadowmapRec(p91, p92)
	if getHasClassId(p91, ClassIds.SHAPE) then
		setShapeCastShadowmap(p91, p92)
	end
	local v93 = getNumOfChildren(p91)
	if v93 > 0 then
		for v94 = 0, v93 - 1 do
			I3DUtil.setShapeCastShadowmapRec(getChildAt(p91, v94), p92)
		end
	end
end
function I3DUtil.getHasShaderParameterRec(p95, p96)
	if getHasClassId(p95, ClassIds.SHAPE) and getHasShaderParameter(p95, p96) then
		return true
	end
	local v97 = getNumOfChildren(p95)
	if v97 > 0 then
		for v98 = 0, v97 - 1 do
			if I3DUtil.getHasShaderParameterRec(getChildAt(p95, v98), p96) then
				return true
			end
		end
	end
	return false
end
function I3DUtil.getShaderParameterRec(p99, p100)
	if getHasClassId(p99, ClassIds.SHAPE) and getHasShaderParameter(p99, p100) then
		return getShaderParameter(p99, p100)
	end
	local v101 = getNumOfChildren(p99)
	if v101 > 0 then
		for v102 = 0, v101 - 1 do
			local v103, v104, v105, v106 = I3DUtil.getShaderParameterRec(getChildAt(p99, v102), p100)
			if v103 ~= nil then
				return v103, v104, v105, v106
			end
		end
	end
	return nil, nil, nil, nil
end
function I3DUtil.getNodesByShaderParam(p107, p108, p109, p110)
	local v111 = p109 == nil and {} or p109
	if getHasClassId(p107, ClassIds.SHAPE) and getHasShaderParameter(p107, p108) then
		if p110 == nil or not p110 then
			v111[p107] = p107
		else
			table.insert(v111, p107)
		end
	end
	local v112 = getNumOfChildren(p107)
	if v112 > 0 then
		for v113 = 0, v112 - 1 do
			I3DUtil.getNodesByShaderParam(getChildAt(p107, v113), p108, v111, p110)
		end
	end
	return v111
end
function I3DUtil.getNodesByShaderParameters(p114, p115, p116, p117)
	local v118 = p116 == nil and {} or p116
	if getHasClassId(p114, ClassIds.SHAPE) then
		for _, v119 in ipairs(p115) do
			if getHasShaderParameter(p114, v119) then
				if p117 == nil or not p117 then
					v118[p114] = p114
				else
					table.insert(v118, p114)
				end
				break
			end
		end
	end
	local v120 = getNumOfChildren(p114)
	if v120 > 0 then
		for v121 = 0, v120 - 1 do
			I3DUtil.getNodesByShaderParameters(getChildAt(p114, v121), p115, v118, p117)
		end
	end
	return v118
end
function I3DUtil.printChildren(p122, p123, p124)
	local v125 = p123 or "    "
	local v126 = p124 or 0
	for v127 = 0, getNumOfChildren(p122) - 1 do
		local v128 = getChildAt(p122, v127)
		log(string.rep(v125, v126), v128, getName(v128))
		I3DUtil.printChildren(v128, v125, v126 + 1)
	end
end
function I3DUtil.hasNamedChildren(p129, p130)
	for v131 = 0, getNumOfChildren(p129) - 1 do
		local v132 = getChildAt(p129, v131)
		if getName(v132) == p130 or I3DUtil.hasNamedChildren(v132, p130) then
			return true
		end
	end
	return false
end
function I3DUtil.getChildByName(p133, p134)
	for v135 = 0, getNumOfChildren(p133) - 1 do
		local v136 = getChildAt(p133, v135)
		if getName(v136) == p134 then
			return v136
		end
		local v137 = I3DUtil.getChildByName(v136, p134)
		if v137 ~= nil then
			return v137
		end
	end
	return nil
end
function I3DUtil.iterateRecursively(p138, p139, p140)
	if p140 and p139(p138, 0) == false then
		return false
	end
	local function v_u_146(p141, p142, p143)
		-- upvalues: (copy) v_u_146
		for v144 = 0, getNumOfChildren(p141) - 1 do
			local v145 = getChildAt(p141, v144)
			if p142(v145, p143) == false then
				return false
			end
			if v_u_146(v145, p142, p143 + 1) == false then
				return false
			end
		end
		return true
	end
	return v_u_146(p138, p139, 0)
end
function I3DUtil.iteratorChildren(p_u_147)
	if p_u_147 == nil or not entityExists(p_u_147) then
		return function() end
	elseif getHasClassId(p_u_147, ClassIds.TRANSFORM_GROUP) then
		local v_u_148 = 0
		local v_u_149 = getNumOfChildren(p_u_147)
		return function()
			-- upvalues: (ref) v_u_148, (copy) v_u_149, (copy) p_u_147
			if v_u_149 <= v_u_148 then
				return nil
			end
			v_u_148 = v_u_148 + 1
			return v_u_148, getChildAt(p_u_147, v_u_148 - 1)
		end
	else
		Logging.error("I3DUtil.iteratorChildren() called with non-transform entity %q (%d)", getName(p_u_147), p_u_147)
		printCallstack()
		return function() end
	end
end
function I3DUtil.iterateShaderParameterNodesRecursively(p150, p151, p152, p153)
	if getHasClassId(p150, ClassIds.SHAPE) and getHasShaderParameter(p150, p151) then
		if p153 == nil then
			p152(p150)
		else
			p152(p153, p150)
		end
	end
	for v154 = 0, getNumOfChildren(p150) - 1 do
		I3DUtil.iterateShaderParameterNodesRecursively(getChildAt(p150, v154), p151, p152, p153)
	end
end
function I3DUtil.iterateShaderParametersNodesRecursively(p155, p156, p157, p158)
	if getHasClassId(p155, ClassIds.SHAPE) then
		for _, v159 in ipairs(p156) do
			if getHasShaderParameter(p155, v159) then
				if p158 == nil then
					p157(p155)
				else
					p157(p158, p155)
				end
				break
			end
		end
	end
	for v160 = 0, getNumOfChildren(p155) - 1 do
		I3DUtil.iterateShaderParametersNodesRecursively(getChildAt(p155, v160), p156, p157, p158)
	end
end
function I3DUtil.getIsLinkedToNode(p161, p162)
	while p162 ~= 0 do
		if p161 == p162 then
			return true
		end
		p162 = getParent(p162)
	end
	return false
end
function I3DUtil.getIsSpline(p163)
	local v164 = getHasClassId(p163, ClassIds.SHAPE)
	if v164 then
		if getGeometry(p163) == 0 then
			v164 = false
		else
			v164 = getHasClassId(getGeometry(p163), ClassIds.SPLINE)
		end
	end
	return v164
end
function I3DUtil.getSupportsLOD(p165)
	return getHasClassId(p165, ClassIds.SHAPE) and not getIsNonRenderable(p165) and not I3DUtil.getIsSpline(p165) or (getHasClassId(p165, ClassIds.LIGHT_SOURCE) or getHasClassId(p165, ClassIds.AUDIO_SOURCE))
end
function I3DUtil.getNodePath(p166, p167, p168)
	local v169 = getParent(p166)
	if v169 == 0 or p166 == p167 then
		return getName(p166)
	else
		local v170, v171 = getReferenceInfo(v169)
		if v170 then
			if p168 then
				return "(Ref:" .. Utils.getFilenameFromPath(v171) .. ")|" .. getName(p166)
			else
				return I3DUtil.getNodePath(v169, p167, p168) .. "(Ref:" .. v171 .. ")|" .. getName(p166)
			end
		else
			return I3DUtil.getNodePath(v169, p167, p168) .. "|" .. getName(p166)
		end
	end
end
function I3DUtil.getNodePathIndices(p172)
	local v173 = getParent(p172)
	if v173 == 0 or (v173 == nil or getChildIndex(v173) == -1) then
		return getChildIndex(p172)
	else
		return I3DUtil.getNodePathIndices(v173) .. "|" .. getChildIndex(p172)
	end
end
function I3DUtil.getRelativeNodePathIndices(p174, p175)
	local v176 = getParent(p174)
	if v176 == 0 or v176 == p175 then
		return getChildIndex(p174)
	else
		return I3DUtil.getRelativeNodePathIndices(v176, p175) .. "|" .. getChildIndex(p174)
	end
end
function I3DUtil.getNodeNameAndIndexPath(p177)
	return string.format("%s (%s)", I3DUtil.getNodePath(p177), I3DUtil.getNodePathIndices(p177))
end
function I3DUtil.checkForChildCollisions(p178, p179, ...)
	local v180 = getRigidBodyType(p178)
	if v180 == RigidBodyType.STATIC or (v180 == RigidBodyType.DYNAMIC or getIsCompoundChild(p178)) then
		p179(p178, ...)
	end
	for v181 = 0, getNumOfChildren(p178) - 1 do
		I3DUtil.checkForChildCollisions(getChildAt(p178, v181), p179, ...)
	end
end
function I3DUtil.registerI3dMappingXMLPaths(p182, p183)
	p182:register(XMLValueType.STRING, p183 .. ".i3dMappings.i3dMapping(?)#id", "Identifier to be used in xml")
	p182:register(XMLValueType.STRING, p183 .. ".i3dMappings.i3dMapping(?)#node", "Index path to node in i3d file")
end
function I3DUtil.loadI3DMapping(p_u_184, p185, p_u_186, p187, p_u_188)
	local v189 = p185 or p_u_184:getRootName()
	local v_u_190 = p187 or {}
	p_u_184:iterate(v189 .. ".i3dMappings.i3dMapping", function(_, p191)
		-- upvalues: (copy) p_u_184, (copy) p_u_186, (copy) p_u_188, (ref) v_u_190
		local v192 = p_u_184:getString(p191 .. "#id")
		local v193 = p_u_184:getString(p191 .. "#node")
		if v192 ~= nil and v193 ~= nil then
			local v194, v195 = I3DUtil.indexToObject(p_u_186, v193, nil, p_u_188)
			if v194 ~= nil then
				v_u_190[v192] = {
					["nodeId"] = v194,
					["rootNode"] = v195
				}
				return
			end
			v_u_190[v192] = v193
		end
	end)
	return v_u_190
end
function I3DUtil.loadI3DComponents(p196, p197)
	local v198 = p197 or {}
	for v199 = 0, getNumOfChildren(p196) - 1 do
		local v200 = {
			["node"] = getChildAt(p196, v199)
		}
		table.insert(v198, v200)
	end
	return v198
end

I3DManager = {}
I3DManager.VERBOSE_LOADING = true
I3DManager.DEBUG_LOADING_CHECKS = {}
local v_u_1 = Class(I3DManager)
function I3DManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	addConsoleCommand("gsI3DLoadingDelaySet", "Sets loading delay for i3d files", "consoleCommandSetLoadingDelay", v4, "minDelaySec; [maxDelaySec]; [minDelayCachedSec]; [maxDelayCachedSec]")
	addConsoleCommand("gsI3DCacheShow", "Show active i3d cache", "consoleCommandShowCache", v4)
	addConsoleCommand("gsI3DPrintActiveLoadings", "Print active loadings", "consoleCommandPrintActiveLoadings", v4)
	return v4
end
function I3DManager.init(p5)
	local v6 = StartParams.getValue
	local v7 = tonumber(v6("i3dLoadingDelay"))
	if v7 ~= nil and v7 > 0 then
		CaptionUtil.addText("- I3D Delay (" .. v7 .. "ms)")
		p5:setLoadingDelay(v7 / 1000)
	end
	if StartParams.getIsSet("scriptDebug") then
		p5:setupDebugLoading()
	end
end
function I3DManager.drawDebug(_)
	if I3DManager.showCache then
		local v8 = getUserProfileAppPath()
		local v9 = getNumOfSharedI3DFiles()
		local v10 = table.create(v9)
		for v11 = 0, v9 - 1 do
			local v12, v13 = getSharedI3DFilesData(v11)
			local v14 = {
				["filename"] = string.gsub(v12, v8, ""),
				["numRefs"] = v13
			}
			table.insert(v10, v14)
		end
		table.sort(v10, function(p15, p16)
			return p15.filename < p16.filename
		end)
		local v17 = 0.01
		local v18 = 0.99
		for _, v19 in ipairs(v10) do
			setTextAlignment(RenderText.ALIGN_LEFT)
			local v20 = renderText
			local v21 = v19.numRefs
			v20(v17, v18, 0.01, "Refcount: " .. tostring(v21))
			local v22 = renderText
			local v23 = v17 + 0.04
			local v24 = v19.filename
			v22(v23, v18, 0.01, "File: " .. tostring(v24))
			v18 = v18 - 0.011
			if v18 < 0 then
				v17 = v17 + 0.3
				v18 = 0.99
			end
		end
	end
end
function I3DManager.loadSharedI3DFile(_, p25, p26, p27)
	local v28 = Utils.getNoNil(p26, false)
	local v29 = Utils.getNoNil(p27, false)
	local v30, v31, v32 = loadSharedI3DFile(p25, v29, v28, I3DManager.VERBOSE_LOADING)
	return v30, v31, v32
end
function I3DManager.loadSharedI3DFileAsync(p33, p34, p35, p36, p37, p38, p39)
	local v40 = p34 ~= nil
	assert(v40, "I3DManager:loadSharedI3DFileAsync - missing filename")
	local v41 = p37 ~= nil
	assert(v41, "I3DManager:loadSharedI3DFileAsync - missing callback function")
	local v42 = type(p37) == "function"
	assert(v42, "I3DManager:loadSharedI3DFileAsync - Callback value is not a function")
	local v43 = Utils.getNoNil(p35, false)
	local v44 = Utils.getNoNil(p36, false)
	return streamSharedI3DFile(p34, "loadSharedI3DFileAsyncFinished", p33, {
		["asyncCallbackFunction"] = p37,
		["asyncCallbackObject"] = p38,
		["asyncCallbackArguments"] = p39
	}, v44, v43, I3DManager.VERBOSE_LOADING)
end
function I3DManager.loadSharedI3DFileAsyncFinished(_, p45, p46, p47)
	p47.asyncCallbackFunction(p47.asyncCallbackObject, p45, p46, p47.asyncCallbackArguments)
end
function I3DManager.loadI3DFile(_, p48, p49, p50)
	local v51 = Utils.getNoNil(p49, false)
	local v52 = Utils.getNoNil(p50, false)
	return loadI3DFile(p48, v52, v51, I3DManager.VERBOSE_LOADING)
end
function I3DManager.loadI3DFileAsync(p53, p54, p55, p56, p57, p58, p59)
	local v60 = p54 ~= nil
	assert(v60, "I3DManager:loadI3DFileAsync - missing filename")
	local v61 = p57 ~= nil
	assert(v61, "I3DManager:loadI3DFileAsync - missing callback function")
	local v62 = type(p57) == "function"
	assert(v62, "I3DManager:loadI3DFileAsync - Callback value is not a function")
	local v63 = Utils.getNoNil(p55, false)
	local v64 = Utils.getNoNil(p56, false)
	return streamI3DFile(p54, "loadSharedI3DFileFinished", p53, {
		["asyncCallbackFunction"] = p57,
		["asyncCallbackObject"] = p58,
		["asyncCallbackArguments"] = p59
	}, v64, v63, I3DManager.VERBOSE_LOADING)
end
function I3DManager.loadSharedI3DFileFinished(_, p65, p66, p67)
	p67.asyncCallbackFunction(p67.asyncCallbackObject, p65, p66, p67.asyncCallbackArguments)
end
function I3DManager.cancelStreamI3DFile(_, p68)
	if p68 == nil then
		Logging.error("I3DManager:cancelStreamedI3dFile - loadingRequestId is nil")
		printCallstack()
	else
		cancelStreamI3DFile(p68)
	end
end
function I3DManager.releaseSharedI3DFile(_, p69, p70)
	if p69 == nil then
		Logging.error("I3DManager:releaseSharedI3DFile - sharedLoadRequestId is nil")
		printCallstack()
	else
		local v71 = Utils.getNoNil(p70, false)
		local _ = g_isDevelopmentVersion
		releaseSharedI3DFile(p69, v71)
	end
end
function I3DManager.pinSharedI3DFileInCache(_, p72)
	if p72 == nil then
		Logging.error("I3DManager:pinSharedI3DFileInCache - Filename is nil")
		printCallstack()
	elseif getSharedI3DFileRefCount(p72) < 0 then
		pinSharedI3DFileInCache(p72, true)
		return
	end
end
function I3DManager.unpinSharedI3DFileInCache(_, p73)
	if p73 == nil then
		Logging.error("I3DManager:unpinSharedI3DFileInCache - filename is nil")
		printCallstack()
	else
		unpinSharedI3DFileInCache(p73)
	end
end
function I3DManager.clearEntireSharedI3DFileCache(_, p74)
	if p74 == true then
		local v75 = getNumOfSharedI3DFiles()
		Logging.devInfo("I3DManager: Deleting %s shared i3d files", v75)
		for v76 = 0, v75 - 1 do
			local v77, v78 = getSharedI3DFilesData(v76)
			Logging.devWarning("    NumRef: %d - File: %s", v78, v77)
		end
	end
	Logging.devInfo("I3DManager: Deleted shared i3d files")
	clearEntireSharedI3DFileCache()
end
function I3DManager.setLoadingDelay(_, p79, p80, p81, p82)
	local v83 = p79 or 0
	local v84 = p80 or v83
	local v85 = p81 or v83
	local v86 = p82 or v84
	setStreamI3DFileDelay(v83, v84)
	setStreamSharedI3DFileDelay(v83, v84, v85, v86)
	Logging.info("Set new loading delay. MinDelay: %.2fs, MaxDelay: %.2fs, MinDelayCached: %.2fs, MaxDelayCached: %.2fs", v83, v84, v85, v86)
end
function I3DManager.consoleCommandSetLoadingDelay(p87, p88, p89, p90, p91)
	local v92 = tonumber(p88) or 0
	local v93 = tonumber(p89) or v92
	p87:setLoadingDelay(v92, v93, tonumber(p90) or v92, tonumber(p91) or v93)
end
function I3DManager.consoleCommandShowCache(p94)
	I3DManager.showCache = not I3DManager.showCache
	if g_debugManager ~= nil then
		if I3DManager.showCache then
			g_debugManager:addDrawable(p94)
		else
			g_debugManager:removeDrawable(p94)
		end
	end
	local v95 = I3DManager.showCache
	return "showCache=" .. tostring(v95)
end
function I3DManager.consoleCommandPrintActiveLoadings(_)
	print("Non-Shared loading tasks:")
	local v96 = getAllStreamI3DFileRequestIds()
	if #v96 == 0 then
		print("none")
	else
		for _, v97 in ipairs(v96) do
			local v98, v99, v100, v101, v102, v103 = getStreamI3DFileProgressInfo(v97)
			local v104 = string.format("%03d: Progress: %s | Time %.3fs | File: %s | Callback: %s | Target: %s | Args: %s", v97, v98, v99, v100, v101, tostring(v102), (tostring(v103)))
			print(v104)
		end
	end
	print("")
	print("Shared loading tasks:")
	local v105 = getAllSharedI3DFileRequestIds()
	if #v105 == 0 then
		print("none")
	else
		for _, v106 in ipairs(v105) do
			local v107, v108, v109, v110, v111, v112 = getSharedI3DFileProgressInfo(v106)
			local v113 = string.format("%03d: Progress: %s | Time %.3fs | File: %s | Callback: %s | Target: %s | Args: %s", v106, v107, v108, v109, v110, tostring(v111), (tostring(v112)))
			print(v113)
		end
	end
end
g_i3DManager = I3DManager.new()
function I3DManager.addDebugLoadingCheck(p114, p115)
	if StartParams and StartParams.getIsSet("scriptDebug") then
		local v116 = I3DManager.DEBUG_LOADING_CHECKS
		table.insert(v116, {
			["checkFunc"] = p115,
			["name"] = p114
		})
	end
end
function I3DManager.setupDebugLoading(p_u_117)
	printWarning("\n\n  ##################   Warning: I3D-Manager Debug checks are active!   ##################\n\n")
	p_u_117.debugTracingActive = StartParams.getIsSet("i3dTracing")
	if p_u_117.debugTracingActive then
		printWarning("\n\n  ##################   Warning: I3D-Manager Debug tracing is active !   ##################\n\n")
		p_u_117.debugPendingRequests = {}
	end
	local function v_u_123(p118, p119, p120, p121)
		-- upvalues: (copy) p_u_117
		log(p118, "requestId", p121.loadRequestId, p121.filename, "nodeId", p119, "failedReason", I3DManager.getFailedReasonName(p120), "updateLoopIndex", g_updateLoopIndex)
		local v122 = p121.loadRequestId
		print("    pendingRequestIds (including current callback): " .. table.concat(p_u_117.debugPendingRequests, " "))
		if not table.removeElement(p_u_117.debugPendingRequests, v122) then
			printError(string.format("    Error: unable to remove requestId %d from pendingRequests, no pending request for this id", v122))
		end
		if #p_u_117.debugPendingRequests == 0 then
			print("    no more pending requests")
		end
	end
	function I3DManager.checkRecursive(p124, p125, p126)
		local v127 = 0
		if p126(p124, p125) then
			v127 = v127 + 1
		end
		for v128 = 0, getNumOfChildren(p125) - 1 do
			v127 = v127 + I3DManager.checkRecursive(p124, getChildAt(p125, v128), p126)
		end
		return v127
	end
	local v_u_129 = loadI3DFile
	function loadI3DFile(p130, ...)
		-- upvalues: (copy) v_u_129
		local v131, _, _ = v_u_129(p130, ...)
		if v131 > 0 then
			for _, v132 in ipairs(I3DManager.DEBUG_LOADING_CHECKS) do
				local v133 = I3DManager.checkRecursive(p130, v131, v132.checkFunc)
				if v133 > 0 then
					Logging.devInfo("Finished \'%s\' check with %d matches for \'%s\'", v132.name, v133, p130 or "")
				end
			end
		end
		return v131
	end
	local v_u_134 = loadSharedI3DFile
	function loadSharedI3DFile(p135, ...)
		-- upvalues: (copy) v_u_134
		local v136, v137, v138 = v_u_134(p135, ...)
		if v136 > 0 then
			for _, v139 in ipairs(I3DManager.DEBUG_LOADING_CHECKS) do
				local v140 = I3DManager.checkRecursive(p135, v136, v139.checkFunc)
				if v140 > 0 then
					Logging.devInfo("Finished \'%s\' check with \'%d\' matches for \'%s\'", v139.name, v140, p135 or "")
				end
			end
		end
		return v136, v137, v138
	end
	local v_u_141 = streamI3DFile
	function streamI3DFile(p142, p143, p144, p145, ...)
		-- upvalues: (copy) v_u_141, (copy) p_u_117
		local v146 = {
			["target"] = p144,
			["callbackFunc"] = p143,
			["params"] = p145,
			["filename"] = p142
		}
		local v147 = v_u_141(p142, "streamI3DCallback", nil, v146, ...)
		if p_u_117.debugTracingActive then
			log("streamI3DFile", "requestId", v147, p142, "callback", v146.callbackFunc, "updateLoopIndex", g_updateLoopIndex)
			v146.filename = p142
			v146.loadRequestId = v147
			local v148 = p_u_117.debugPendingRequests
			table.insert(v148, v147)
		end
		return v147
	end
	function streamI3DCallback(p149, p150, p151)
		-- upvalues: (copy) p_u_117, (copy) v_u_123
		local v152 = p151.target
		local v153 = p151.callbackFunc
		local v154 = p151.params or {}
		if p_u_117.debugTracingActive then
			v_u_123("streamI3DCallback", p149, p150, p151)
		end
		if p149 > 0 then
			for _, v155 in ipairs(I3DManager.DEBUG_LOADING_CHECKS) do
				local v156 = I3DManager.checkRecursive(p151.filename or "", p149, v155.checkFunc)
				if v156 > 0 then
					Logging.devInfo("Finished \'%s\' check with \'%d\' matches for \'%s\'", v155.name, v156, p151.filename or "")
				end
			end
		end
		v152[v153](v152, p149, p150, v154)
	end
	local v_u_157 = streamSharedI3DFile
	function streamSharedI3DFile(p158, p159, p160, p161, ...)
		-- upvalues: (copy) v_u_157, (copy) p_u_117
		local v162 = {
			["target"] = p160,
			["callbackFunc"] = p159,
			["filename"] = p158,
			["params"] = p161
		}
		local v163 = v_u_157(p158, "streamSharedI3DCallback", nil, v162, ...)
		if p_u_117.debugTracingActive then
			log("streamSharedI3DFile", "requestId", v163, p158, "callback", v162.callbackFunc, "updateLoopIndex", g_updateLoopIndex)
			v162.filename = p158
			v162.loadRequestId = v163
			local v164 = p_u_117.debugPendingRequests
			table.insert(v164, v163)
		end
		return v163
	end
	function streamSharedI3DCallback(p165, p166, p167)
		-- upvalues: (copy) p_u_117, (copy) v_u_123
		local v168 = p167.target
		local v169 = p167.callbackFunc
		local v170 = p167.params or {}
		if p_u_117.debugTracingActive then
			v_u_123("streamSharedI3DCallback", p165, p166, p167)
		end
		if p165 > 0 then
			for _, v171 in ipairs(I3DManager.DEBUG_LOADING_CHECKS) do
				local v172 = I3DManager.checkRecursive(p167.filename or "", p165, v171.checkFunc)
				if v172 > 0 then
					Logging.devInfo("Finished \'%s\' check with \'%d\' matches for \'%s\'", v171.name, v172, p167.filename or "")
				end
			end
		end
		v168[v169](v168, p165, p166, v170)
	end
	if p_u_117.debugTracingActive then
		local v_u_173 = cancelStreamI3DFile
		function cancelStreamI3DFile(p174)
			-- upvalues: (copy) p_u_117, (copy) v_u_173
			log("cancelStreamI3DFile", p174, "updateLoopIndex", g_updateLoopIndex)
			table.removeElement(p_u_117.debugPendingRequests, p174)
			return v_u_173(p174)
		end
		local v_u_175 = releaseSharedI3DFile
		function releaseSharedI3DFile(p176, ...)
			-- upvalues: (copy) p_u_117, (copy) v_u_175
			log("releaseSharedI3DFile", p176, "updateLoopIndex", g_updateLoopIndex)
			if getSharedI3DFileProgressInfo(p176) ~= "PROGRESS_UNKNOWN" then
				printWarning("    releaseSharedI3DFile while request was still pending, same effect as cancelStreamI3DFile")
				table.removeElement(p_u_117.debugPendingRequests, p176)
			end
			return v_u_175(p176, ...)
		end
	end
end
function I3DManager.getFailedReasonName(p177)
	for v178, v179 in pairs(LoadI3DFailedReason) do
		if v179 == p177 then
			return v178
		end
	end
	return string.format("<undefined failedReason \'%s\'>", p177)
end
I3DManager.addDebugLoadingCheck("Directional-Lights", function(_, p180)
	if not getHasClassId(p180, ClassIds.LIGHT_SOURCE) or (g_currentMission == nil or (getLightType(p180) ~= LightType.DIRECTIONAL or p180 == g_currentMission.environment.lighting.sunLightId)) then
		return false
	end
	if getName(p180) == "licensePlateCreationBoxLight" then
		return false
	end
	printWarning(string.format("    Light-Check: Found directional light \'%s\'", I3DUtil.getNodePath(p180)))
	return true
end)
I3DManager.addDebugLoadingCheck("Collision mask check", function(_, p181)
	if getHasClassId(p181, ClassIds.SHAPE) and getHasCollision(p181) then
		local v182 = getRigidBodyType(p181)
		if v182 == RigidBodyType.NONE then
			return false
		end
		local v183 = getCollisionFilterGroup(p181)
		if v182 ~= RigidBodyType.DYNAMIC then
			local v184 = CollisionFlag.DYNAMIC_OBJECT
			if bit32.btest(v183, v184) and g_currentMission:getNodeObject(p181) == nil then
				Logging.i3dWarning(p181, "non-dynamic collision has \'DYNAMIC_OBJECT\' collision group bit set")
				return true
			end
		end
	end
	return false
end)
I3DManager.addDebugLoadingCheck("tip col properties", function(_, p185)
	local v186 = false
	if getHasClassId(p185, ClassIds.SHAPE) then
		local v187 = string.contains(getName(p185):upper(), "TIPCOL")
		if v187 then
			if not CollisionFlag.getHasGroupFlagSet(p185, CollisionFlag.GROUND_TIP_BLOCKING) then
				Logging.warning("node is named tipcol but does not have %s set: %s", CollisionFlag.getBitAndName(CollisionFlag.GROUND_TIP_BLOCKING), I3DUtil.getNodePath(p185))
				v186 = true
			end
			if getRigidBodyType(p185) ~= RigidBodyType.STATIC then
				Logging.warning("tip col not static %s", I3DUtil.getNodePath(p185))
				v186 = true
			end
		end
		if CollisionFlag.getHasGroupFlagSet(p185, CollisionFlag.GROUND_TIP_BLOCKING) then
			if v187 then
				local v188 = getRigidBodyType(p185)
				if v188 ~= RigidBodyType.STATIC then
					Logging.warning("node %q has tip col flag but is not STATIC but %s", I3DUtil.getNodePath(p185), EnumUtil.getName(RigidBodyType, v188))
					v186 = true
				end
				if getCollisionFilterMask(p185) ~= 1 then
					Logging.warning("node %q has tip col flag mask is not 1", I3DUtil.getNodePath(p185))
					v186 = true
				end
				if CollisionFlag.getHasGroupFlagSet(p185, CollisionFlag.STATIC_OBJECT) then
					Logging.warning("node %q has STATIC_OBJECT flag set", I3DUtil.getNodePath(p185))
					v186 = true
				end
			end
			for v189 = 0, getNumOfUserAttributes(p185) - 1 do
				local _, v190, v191 = getUserAttributeByIndex(p185, v189)
				if v190 == "collisionHeight" and v191 ~= UserAttributeType.FLOAT then
					Logging.warning("node %q has tip col flag with user attribute %q of wrong type %q. Only \'collisionHeight\' of type \'Float\' is supported", I3DUtil.getNodePath(p185), v190, EnumUtil.getName(UserAttributeType, v191))
					v186 = true
				end
			end
		end
	end
	return v186
end)
I3DManager.addDebugLoadingCheck("LOD Checks", function(_, p192)
	local v193 = getLODTransformGroup(p192)
	if v193 == 0 or (v193 ~= getParent(p192) or getVisibility(p192) and getVisibility(getParent(p192))) then
		return false
	end
	Logging.warning("LOD is hidden - Node: %s   NodeIndex: %s", I3DUtil.getNodePath(p192), I3DUtil.getNodePathIndices(p192))
	return true
end)
I3DManager.addDebugLoadingCheck("Occluder Checks", function(_, p194)
	if getHasClassId(p194, ClassIds.SHAPE) then
		local v195 = getName(p194)
		local v196 = getIsOccluderMesh(p194)
		local v197 = string.contains(v195:upper(), "OCCLUDER")
		if v197 or v196 then
			local v198 = false
			if v197 and not v196 then
				Logging.warning("Mesh is named occluder but does not have the occluder mesh flag set - Node: %s", I3DUtil.getNodePath(p194))
				v198 = true
			elseif not v197 and v196 then
				Logging.warning("Mesh has occluder flag set but is not named \'occluder\' - Node: %s", I3DUtil.getNodePath(p194))
				v198 = true
			end
			if v196 then
				if not (getVisibility(p194) and getVisibility(getParent(p194))) then
					Logging.warning("Occluder mesh is not visible and will not function. Use \'non-renderable\' flag for hiding instead - Node: %s", I3DUtil.getNodePath(p194))
					v198 = true
				end
				local _, _, _, v199 = getShapeBoundingSphere(p194)
				if v199 < 3 then
					Logging.warning("Occluder is very small and should probably be removed, bounding radius %.3f - Node: %s", v199, I3DUtil.getNodePath(p194))
					v198 = true
				end
			end
			return v198
		end
	end
	return false
end)
I3DManager.addDebugLoadingCheck("ScaledTrees", function(_, p200)
	local v201 = false
	if getHasClassId(p200, ClassIds.MESH_SPLIT_SHAPE) then
		local v202 = getParent(p200)
		if v202 ~= 0 then
			local v203, v204, v205 = getScale(v202)
			if v203 ~= 1 or (v204 ~= 1 or v205 ~= 1) then
				Logging.warning("Scaled tree shape found - Node: %s", I3DUtil.getNodePath(p200))
				v201 = true
			end
		end
	end
	return v201
end)
I3DManager.addDebugLoadingCheck("TerrainDecal", function(_, p206)
	if not getHasClassId(p206, ClassIds.SHAPE) or (not getIsTerrainDecal(p206) or (getIsNonRenderable(p206) or not getIsRenderedInViewports(p206))) then
		return false
	end
	Logging.warning("Terrain decal without nonRenderable==true or getIsRenderedInViewports==false - Node: %s", I3DUtil.getNodePath(p206))
	return true
end)
I3DManager.addDebugLoadingCheck("DecalLayerGrids", function(_, p207)
	if not getHasClassId(p207, ClassIds.SHAPE) or (getShapeDecalLayer(p207) == 0 or not (string.contains(string.lower(getName(p207)), "grid") or (string.contains(string.lower(getName(p207)), "alphapart") or string.contains(string.lower(getName(p207)), "alpha_decal")))) or string.contains(string.lower(getName(p207)), "sticker") then
		return false
	end
	Logging.warning("Alpha part or grid node found with decal layer set to %d - Node: %s", getShapeDecalLayer(p207), I3DUtil.getNodePath(p207))
	return true
end)

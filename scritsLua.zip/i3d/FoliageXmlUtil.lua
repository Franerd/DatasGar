FoliageXmlUtil = {}
function FoliageXmlUtil.printFoliageCtor(p1)
	local v2 = p1:getName()
	local v3, v4 = p1:getDensityMapInfo()
	local v5 = p1:getNumLayers()
	print("Name: " .. v2)
	print("Density Map: BPP " .. v3 .. " TYPE " .. v4)
	print("Num layers: " .. v5)
	for v6 = 1, v5 do
		local v7 = v6 - 1
		local v8 = p1:getNameForLayer(v7)
		local v9 = p1:getTypeIndexForLayer(v7)
		local v10 = p1:getShapeSourceForLayer(v7)
		local v11, v12 = p1:getDensityChannelsForLayer(v7)
		local v13 = p1:getCellSizeForLayer(v7)
		local v14 = p1:getObjectMaskForLayer(v7)
		local v15 = p1:getDecalLayerForLayer(v7)
		local v16 = p1:getMaxNumStatesForLayer(v7)
		local v17 = p1:getNumStatesForLayer(v7)
		print("Layer " .. v7 .. ":")
		print("  Name: " .. v8)
		print("  Type index: " .. v9)
		print("  Shape Source: " .. tostring(v10))
		print("  Density map: CH off " .. v11 .. " BPP " .. v12)
		print("  Cell size: " .. v13)
		print("  Object mask: " .. v14)
		print("  Decal layer: " .. v15)
		print("  Max states: " .. v16)
		print("  Num states: " .. v17)
		for v18 = 1, v17 do
			local v19 = v18 - 1
			local v20 = p1:getNameForState(v7, v19)
			local v21, v22 = p1:getDistanceMapForState(v7, v19)
			local v23, v24 = p1:getWidthAndVarianceForState(v7, v19)
			local v25, v26 = p1:getHeightAndVarianceForState(v7, v19)
			local v27 = p1:getPositionVarianceForState(v7, v19)
			local v28 = p1:getNumShapesForState(v7, v19)
			local v29 = p1:getBlocksPerUnitForState(v7)
			print("  State " .. v19 .. ":")
			print("    Name: " .. v20)
			print("    Distance map: " .. v21 .. " layer " .. v22)
			print("    Width: " .. v23 .. " var " .. v24)
			print("    Height: " .. v25 .. " var " .. v26)
			print("    Pos var: " .. v27)
			print("    Num shapes: " .. v28)
			print("    Blocks per unit " .. v29)
			for v30 = 1, v28 do
				local v31 = v30 - 1
				for v32 = 1, p1:getNumLodsForShape(v7, v19, v31) do
					local v33 = v32 - 1
					local v34 = p1:getViewDistanceForLod(v7, v19, v31, v33)
					local v35 = p1:getShapeForLod(v7, v19, v31, v33)
					local v36 = p1:getAtlasSizeForLod(v7, v19, v31, v33)
					local v37, v38 = p1:getAtlasOffsetForLod(v7, v19, v31, v33)
					local v39, v40, v41, v42 = p1:getTexCoordsForLod(v7, v19, v31, v33)
					print("    Lod " .. v33)
					print("      ViewDistance " .. tostring(v34))
					print("      Shape " .. tostring(v35))
					print("      Atlas size: " .. v36)
					print("      Atlas offset: " .. v37 .. " " .. v38)
					print("      Tex coords: " .. v39 .. " " .. v40 .. " " .. v41 .. " " .. v42)
				end
			end
		end
	end
end

AdsSystem = {}
local v_u_1 = Class(AdsSystem)
AdsSystem.OCCLUSION_GROUP = {}
AdsSystem.OCCLUSION_GROUP.UI = 0
function AdsSystem.new()
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3.groups = {}
	local v4 = 0
	for v5, v6 in pairs(AdsSystem.OCCLUSION_GROUP) do
		if v4 == 32 then
			Logging.warning("AdsSystem: Occclusion group limit (32) reached!")
			break
		end
		v3.groups[v6] = {
			["id"] = v6,
			["name"] = v5,
			["regions"] = {},
			["isActive"] = false
		}
		v4 = v4 + 1
	end
	if g_isDevelopmentVersion then
		addConsoleCommand("gsAdsSystemShowOcclusionRegions", "Renders occlusion areas", "consoleCommandShowOcclusionRegions", v3)
	end
	v3.renderOcclusionRegions = false
	return v3
end
function AdsSystem.delete(p7)
	removeConsoleCommand("gsAdsSystemShowOcclusionRegions")
	p7.groups = {}
end
function AdsSystem.drawDebug(p8)
	for _, v9 in pairs(p8.groups) do
		local v10 = v9.id
		if adsGetIsOcclusionRegionGroupActive(v10) then
			for v11, _ in ipairs(v9.regions) do
				local v12, v13, v14, v15 = adsGetOcclusionRegion(v10, v11 - 1)
				drawFilledRect(v12, v13, v14 - v12, v15 - v13, 1, 0, 0, 0.3, nil, nil, nil, nil)
				setTextColor(1, 1, 1, 1)
				setTextAlignment(RenderText.ALIGN_LEFT)
				local v16 = 5 * g_pixelSizeX
				local v17 = 5 * g_pixelSizeY
				local v18 = renderText
				local v19 = v12 + v16
				local v20 = v13 + v17
				local v21 = v9.name
				v18(v19, v20, 0.02, (tostring(v21)))
			end
		end
	end
end
function AdsSystem.clearGroupRegion(p22, p23)
	local v24 = p22.groups[p23]
	if v24 == nil then
		Logging.warning("AdsSystem: GroupId \'%s\' not defined!", (tostring(p23)))
		return false
	end
	v24.regions = {}
	adsClearOcclusionRegionGroup(p23)
	return true
end
function AdsSystem.addGroupRegion(p25, p26, p27, p28, p29, p30)
	local v31 = p25.groups[p26]
	if v31 == nil then
		Logging.warning("AdsSystem: GroupId \'%s\' not defined!", (tostring(p26)))
		return false
	end
	if #v31.regions == 4 then
		Logging.warning("AdsSystem: Region limit (4) per group already reached!")
		return false
	end
	local v32 = v31.regions
	table.insert(v32, {
		["x"] = p27,
		["y"] = p28,
		["width"] = p29,
		["height"] = p30
	})
	adsAddOcclusionRegion(p26, p27, p28, p27 + p29, p28 + p30)
	return true
end
function AdsSystem.setGroupActive(p33, p34, p35)
	local v36 = p33.groups[p34]
	if v36 == nil then
		Logging.warning("AdsSystem: GroupId \'%s\' not defined!", (tostring(p34)))
		return false
	end
	v36.isActive = p35
	adsSetIsOcclusionRegionGroupActive(p34, p35)
	return false
end
function AdsSystem.consoleCommandShowOcclusionRegions(p37)
	p37.renderOcclusionRegions = not p37.renderOcclusionRegions
	if p37.renderOcclusionRegions then
		g_debugManager:addDrawable(p37)
	else
		g_debugManager:removeDrawable(p37)
	end
	return string.format("ShowOcclusionRegions=%s", p37.renderOcclusionRegions)
end

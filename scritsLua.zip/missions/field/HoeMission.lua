HoeMission = {}
HoeMission.NAME = "hoeMission"
local v_u_1 = Class(HoeMission, AbstractFieldMission)
InitStaticObjectClass(HoeMission, "HoeMission")
function HoeMission.registerXMLPaths(p2, p3)
	HoeMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function HoeMission.registerSavegameXMLPaths(p4, p5)
	HoeMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#targetWeedState", "Target weed state")
end
function HoeMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_hoe_title")
	local v10 = g_i18n:getText("contract_field_hoe_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.workAreaTypes = {
		[WorkAreaType.WEEDER] = true
	}
	v11.targetWeedState = 0
	return v11
end
function HoeMission.init(p12, p13, p14)
	p12.targetWeedState = p14
	return HoeMission:superClass().init(p12, p13)
end
function HoeMission.saveToXMLFile(p15, p16, p17)
	HoeMission:superClass().saveToXMLFile(p15, p16, p17)
	p16:setValue(p17 .. "#targetWeedState", p15.targetWeedState)
end
function HoeMission.loadFromXMLFile(p18, p19, p20)
	p18.targetWeedState = p19:getValue(p20 .. "#targetWeedState", p18.targetWeedState)
	return HoeMission:superClass().loadFromXMLFile(p18, p19, p20)
end
function HoeMission.createModifier(p21)
	local v22, v23, v24 = g_currentMission.weedSystem:getDensityMapData()
	p21.completionModifier = DensityMapModifier.new(v22, v23, v24, g_terrainNode)
	p21.completionFilter = DensityMapFilter.new(p21.completionModifier)
	p21.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, p21.targetWeedState)
end
function HoeMission.getFieldFinishTask(p25)
	p25.field:getFieldState().weedState = p25.targetWeedState
	return HoeMission:superClass().getFieldFinishTask(p25)
end
function HoeMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(HoeMission.NAME).rewardPerHa
end
function HoeMission.getMissionTypeName(_)
	return HoeMission.NAME
end
function HoeMission.validate(p26, p27)
	if HoeMission:superClass().validate(p26, p27) then
		return (p26:getIsFinished() or HoeMission.isAvailableForField(p26.field, p26)) and true or false
	else
		return false
	end
end
function HoeMission.loadMapData(p28, p29, _)
	g_missionManager:getMissionTypeDataByName(HoeMission.NAME).rewardPerHa = p28:getFloat(p29 .. "#rewardPerHa", 1500)
	return true
end
function HoeMission.tryGenerateMission()
	if HoeMission.canRun() then
		local v30 = g_fieldManager:getFieldForMission()
		if v30 == nil then
			return
		end
		if v30.currentMission ~= nil then
			return
		end
		if not HoeMission.isAvailableForField(v30, nil) then
			return
		end
		local v31 = v30:getFieldState().weedState
		local v32 = g_currentMission.weedSystem:getWeederReplacements(true).weed.replacements[v31]
		local v33 = HoeMission.new(true, g_client ~= nil)
		if v33:init(v30, v32) then
			v33:setDefaultEndDate()
			return v33
		end
		v33:delete()
	end
	return nil
end
function HoeMission.isAvailableForField(p34, p35)
	if p35 == nil then
		local v36 = p34:getFieldState()
		if not v36.isValid then
			return false
		end
		local v37 = v36.fruitTypeIndex
		if v37 == FruitType.UNKNOWN then
			return false
		end
		local v38 = g_fruitTypeManager:getFruitTypeByIndex(v37)
		if v38:getIsCatchCrop() then
			return false
		end
		if v36.weedState == 0 then
			return false
		end
		if not v38:getIsHoeable(v36.growthState) then
			return false
		end
		if not g_currentMission.weedSystem:getCanBeHoed(v36.weedState) then
			return false
		end
	end
	local v39 = g_currentMission.environment
	return v39 == nil or v39.currentSeason ~= Season.WINTER
end
function HoeMission.canRun()
	local v40 = g_missionManager:getMissionTypeDataByName(HoeMission.NAME)
	if v40.numInstances >= v40.maxNumInstances then
		return false
	elseif g_currentMission.growthSystem:getIsGrowingInProgress() then
		return false
	elseif g_currentMission.weedSystem:getMapHasWeed() then
		return g_currentMission.missionInfo.weedsEnabled and true or false
	else
		return false
	end
end
g_missionManager:registerMissionType(HoeMission, HoeMission.NAME, 2)

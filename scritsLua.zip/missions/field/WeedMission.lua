WeedMission = {}
WeedMission.NAME = "weedMission"
local v_u_1 = Class(WeedMission, AbstractFieldMission)
InitStaticObjectClass(WeedMission, "WeedMission")
function WeedMission.registerXMLPaths(p2, p3)
	WeedMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function WeedMission.registerSavegameXMLPaths(p4, p5)
	WeedMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#targetWeedState", "Target weed state")
end
function WeedMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_weed_title")
	local v10 = g_i18n:getText("contract_field_weed_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.workAreaTypes = {
		[WorkAreaType.WEEDER] = true
	}
	v11.targetWeedState = 0
	return v11
end
function WeedMission.init(p12, p13, p14)
	p12.targetWeedState = p14
	return WeedMission:superClass().init(p12, p13)
end
function WeedMission.saveToXMLFile(p15, p16, p17)
	WeedMission:superClass().saveToXMLFile(p15, p16, p17)
	p16:setValue(p17 .. "#targetWeedState", p15.targetWeedState)
end
function WeedMission.loadFromXMLFile(p18, p19, p20)
	p18.targetWeedState = p19:getValue(p20 .. "#targetWeedState", p18.targetWeedState)
	return WeedMission:superClass().loadFromXMLFile(p18, p19, p20)
end
function WeedMission.createModifier(p21)
	local v22, v23, v24 = g_currentMission.weedSystem:getDensityMapData()
	p21.completionModifier = DensityMapModifier.new(v22, v23, v24, g_terrainNode)
	p21.completionFilter = DensityMapFilter.new(p21.completionModifier)
	p21.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, p21.targetWeedState)
end
function WeedMission.getFieldFinishTask(p25)
	p25.field:getFieldState().weedState = p25.targetWeedState
	return WeedMission:superClass().getFieldFinishTask(p25)
end
function WeedMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(WeedMission.NAME).rewardPerHa
end
function WeedMission.getMissionTypeName(_)
	return WeedMission.NAME
end
function WeedMission.validate(p26, p27)
	if WeedMission:superClass().validate(p26, p27) then
		return (p26:getIsFinished() or WeedMission.isAvailableForField(p26.field, p26)) and true or false
	else
		return false
	end
end
function WeedMission.loadMapData(p28, p29, _)
	g_missionManager:getMissionTypeDataByName(WeedMission.NAME).rewardPerHa = p28:getFloat(p29 .. "#rewardPerHa", 2000)
	return true
end
function WeedMission.tryGenerateMission()
	if WeedMission.canRun() then
		local v30 = g_fieldManager:getFieldForMission()
		if v30 == nil then
			return
		end
		if v30.currentMission ~= nil then
			return
		end
		if not WeedMission.isAvailableForField(v30, nil) then
			return
		end
		local v31 = v30:getFieldState().weedState
		local v32 = g_currentMission.weedSystem:getWeederReplacements(false).weed.replacements[v31]
		local v33 = WeedMission.new(true, g_client ~= nil)
		if v33:init(v30, v32) then
			v33:setDefaultEndDate()
			return v33
		end
		v33:delete()
	end
	return nil
end
function WeedMission.isAvailableForField(p34, p35)
	if p35 == nil then
		local v36 = p34:getFieldState()
		if not v36.isValid then
			return false
		end
		local v37 = v36.fruitTypeIndex
		if v37 == FruitType.UNKNOWN then
			return false
		end
		local v38 = g_fruitTypeManager:getFruitTypeByIndex(v37)
		if v38:getIsCatchCrop() then
			return false
		end
		if v36.weedState == 0 then
			return false
		end
		if not v38:getIsWeedable(v36.growthState) then
			return false
		end
		if not g_currentMission.weedSystem:getCanBeWeeded(v36.weedState) then
			return false
		end
	end
	local v39 = g_currentMission.environment
	return v39 == nil or v39.currentSeason ~= Season.WINTER
end
function WeedMission.canRun()
	local v40 = g_missionManager:getMissionTypeDataByName(WeedMission.NAME)
	if v40.numInstances >= v40.maxNumInstances then
		return false
	elseif g_currentMission.growthSystem:getIsGrowingInProgress() then
		return false
	elseif g_currentMission.weedSystem:getMapHasWeed() then
		return g_currentMission.missionInfo.weedsEnabled and true or false
	else
		return false
	end
end
g_missionManager:registerMissionType(WeedMission, WeedMission.NAME, 2)

TedderMission = {}
TedderMission.NAME = "tedderMission"
local v_u_1 = Class(TedderMission, AbstractFieldMission)
InitStaticObjectClass(TedderMission, "TedderMission")
function TedderMission.registerXMLPaths(p2, p3)
	TedderMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function TedderMission.registerSavegameXMLPaths(p4, p5)
	TedderMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#spawnedLiters", "Spawned grass liters")
	p4:register(XMLValueType.INT, p5 .. "#grassSegmentIndex", "Current grass segment index")
	p4:register(XMLValueType.BOOL, p5 .. "#finishedGrassSpawning", "If grass spawning is finished")
end
function TedderMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_tedder_title")
	local v10 = g_i18n:getText("contract_field_tedder_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.workAreaTypes = {
		[WorkAreaType.TEDDER] = true
	}
	v11.finishedGrassSpawning = false
	v11.initializedGrassSpawning = false
	v11.currentGrassSegmentIndex = nil
	v11.spawnedLiters = 0
	return v11
end
function TedderMission.saveToXMLFile(p12, p13, p14)
	TedderMission:superClass().saveToXMLFile(p12, p13, p14)
	p13:setValue(p14 .. "#spawnedLiters", p12.spawnedLiters)
	if not p12.finishedGrassSpawning and p12.currentGrassSegmentIndex ~= nil then
		p13:setValue(p14 .. "#grassSegmentIndex", p12.currentGrassSegmentIndex)
	end
	p13:setValue(p14 .. "#finishedGrassSpawning", p12.finishedGrassSpawning)
end
function TedderMission.loadFromXMLFile(p15, p16, p17)
	p15.spawnedLiters = p16:getValue(p17 .. "#spawnedLiters", p15.spawnedLiters)
	p15.currentGrassSegmentIndex = p16:getValue(p17 .. "#grassSegmentIndex", p15.currentGrassSegmentIndex)
	p15.finishedGrassSpawning = p16:getValue(p17 .. "#finishedGrassSpawning", p15.finishedGrassSpawning)
	if p15.finishedGrassSpawning then
		p15.initializedGrassSpawning = true
	end
	return TedderMission:superClass().loadFromXMLFile(p15, p16, p17)
end
function TedderMission.getFieldPreparingTask(p18)
	local v19 = FruitType.GRASS
	local v20 = g_fruitTypeManager:getFruitTypeByIndex(v19)
	local v21 = FieldUpdateTask.new()
	v21:setArea(p18.field:getDensityMapPolygon())
	v21:setField(p18.field)
	v21:setFruit(v19, v20.cutState)
	if v20.harvestGroundType ~= nil then
		v21:setGroundType(v20.harvestGroundType)
	end
	return v21
end
function TedderMission.getIsPrepared(p22)
	if TedderMission:superClass().getIsPrepared(p22) then
		return p22.finishedGrassSpawning
	else
		return false
	end
end
function TedderMission.getFieldFinishTask(p23)
	local v24 = TedderMission:superClass().getFieldFinishTask(p23)
	if v24 ~= nil then
		v24:clearHeight()
	end
	return v24
end
function TedderMission.update(p_u_25, p26)
	if p_u_25.isServer and (p_u_25.status == MissionStatus.PREPARING and (p_u_25.fieldPreparingTask == nil or p_u_25.fieldPreparingTask:getIsFinished())) and not p_u_25.initializedGrassSpawning then
		local v27 = g_fruitTypeManager:getFruitTypeByIndex(FruitType.GRASS)
		local v28 = v27.windrowLiterPerSqm or v27.literPerSqm
		local v29 = g_densityMapHeightManager:getMinValidLiterValuePerSqm(FillType.GRASS_WINDROW)
		local v_u_30 = math.max(v28, v29)
		local v_u_31 = 3
		local v32, v33 = p_u_25.field:getCenterOfFieldWorldPosition()
		local v34 = FieldCourseSettings.new()
		v34.implementWidth = 4
		v34.numHeadlands = 1
		local v_u_35 = DensityMapModifier.new(DensityMapHeightUtil.terrainDetailHeightId, DensityMapHeightUtil.heightFirstChannel, DensityMapHeightUtil.heightNumChannels)
		local v_u_36 = DensityMapModifier.new(DensityMapHeightUtil.terrainDetailHeightId, DensityMapHeightUtil.typeFirstChannel, DensityMapHeightUtil.typeNumChannels)
		local v_u_37 = g_densityMapHeightManager:getDensityMapHeightTypeIndexByFillTypeIndex(FillType.GRASS_WINDROW)
		local v_u_38 = 0
		local function v57(p39, p40, p41, p42, _, p43, _, _)
			-- upvalues: (ref) v_u_38, (copy) p_u_25, (copy) v_u_36, (copy) v_u_35, (copy) v_u_37, (ref) v_u_30, (copy) v_u_31
			v_u_38 = v_u_38 + 1
			if p43 == nil and (p_u_25.currentGrassSegmentIndex == nil or v_u_38 > p_u_25.currentGrassSegmentIndex) then
				local v44, v45 = MathUtil.vector2Normalize(p41 - p39, p42 - p40)
				local v46, _, v47 = MathUtil.transform(p39, 0, p40, v44, 0, v45, 0, 1, 0, -1.5, 0, 0)
				local v48, _, v49 = MathUtil.transform(p39, 0, p40, v44, 0, v45, 0, 1, 0, 1.5, 0, 0)
				local v50, _, v51 = MathUtil.transform(p41, 0, p42, v44, 0, v45, 0, 1, 0, -1.5, 0, 0)
				v_u_36:setParallelogramWorldCoords(v46, v47, v48, v49, v50, v51, DensityCoordType.POINT_POINT_POINT)
				v_u_35:setParallelogramWorldCoords(v46, v47, v48, v49, v50, v51, DensityCoordType.POINT_POINT_POINT)
				local _, _, v52 = v_u_36:executeSetWithStats(v_u_37)
				local v53 = MathUtil.areaToHa(v52, g_currentMission:getFruitPixelsToSqm())
				local v54 = MathUtil.haToSqm(v53)
				local v55 = v_u_30 / v54
				v_u_35:executeSet((math.ceil(v55)))
				local v56 = v_u_30 * v54
				p_u_25.spawnedLiters = p_u_25.spawnedLiters + v56
				p_u_25.currentGrassSegmentIndex = v_u_38
			end
		end
		FieldCourseIterator.new(v32, v33, v34, v57, function()
			-- upvalues: (copy) p_u_25
			p_u_25.finishedGrassSpawning = true
		end)
		p_u_25.initializedGrassSpawning = true
	end
	TedderMission:superClass().update(p_u_25, p26)
end
function TedderMission.createModifier(p58)
	local v59 = g_densityMapHeightManager:getDensityMapHeightTypeByFillTypeIndex(FillType.GRASS_WINDROW)
	if v59 ~= nil then
		p58.completionModifier = DensityMapModifier.new(DensityMapHeightUtil.terrainDetailHeightId, DensityMapHeightUtil.heightFirstChannel, DensityMapHeightUtil.heightNumChannels)
		p58.completionFilter = DensityMapFilter.new(DensityMapHeightUtil.terrainDetailHeightId, DensityMapHeightUtil.typeFirstChannel, DensityMapHeightUtil.typeNumChannels)
		p58.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, v59.index)
	end
end
function TedderMission.getFieldCompletion(p60)
	TedderMission:superClass().getFieldCompletion(p60)
	local v61 = 0
	for _, v62 in ipairs(p60.completionPartitions) do
		v61 = v61 + v62.sumPixels
	end
	local v63 = 1 - v61 * g_densityMapHeightManager:getMinValidLiterValue(FillType.GRASS_WINDROW) / p60.spawnedLiters
	p60.fieldPercentageDone = math.clamp(v63, 0, 1)
	return p60.fieldPercentageDone
end
function TedderMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(TedderMission.NAME).rewardPerHa
end
function TedderMission.getMissionTypeName(_)
	return TedderMission.NAME
end
function TedderMission.validate(p64, p65)
	if TedderMission:superClass().validate(p64, p65) then
		return (p64:getIsFinished() or TedderMission.isAvailableForField(p64.field, p64)) and true or false
	else
		return false
	end
end
function TedderMission.loadMapData(p66, p67, _)
	g_missionManager:getMissionTypeDataByName(TedderMission.NAME).rewardPerHa = p66:getFloat(p67 .. "#rewardPerHa", 1500)
	return true
end
function TedderMission.tryGenerateMission()
	if TedderMission.canRun() then
		local v68 = g_fieldManager:getFieldForMission()
		if v68 == nil then
			return
		end
		if v68.currentMission ~= nil then
			return
		end
		if not TedderMission.isAvailableForField(v68, nil) then
			return
		end
		local v69 = TedderMission.new(true, g_client ~= nil)
		if v69:init(v68) then
			v69:setDefaultEndDate()
			return v69
		end
		v69:delete()
	end
	return nil
end
function TedderMission.isAvailableForField(p70, p71)
	if p71 == nil then
		local v72 = p70:getFieldState()
		if not v72.isValid then
			return false
		end
		local v73 = v72.fruitTypeIndex
		if v73 ~= FruitType.GRASS then
			return false
		end
		if not g_fruitTypeManager:getFruitTypeByIndex(v73):getIsHarvestable(v72.growthState) then
			return false
		end
	end
	local v74 = g_currentMission.environment
	return v74 == nil or v74.currentSeason ~= Season.WINTER
end
function TedderMission.canRun()
	local v75 = g_missionManager:getMissionTypeDataByName(TedderMission.NAME)
	return v75.numInstances < v75.maxNumInstances
end
g_missionManager:registerMissionType(TedderMission, TedderMission.NAME, 2)

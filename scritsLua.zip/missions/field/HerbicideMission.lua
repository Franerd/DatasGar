HerbicideMission = {}
HerbicideMission.NAME = "herbicideMission"
local v_u_1 = Class(HerbicideMission, AbstractFieldMission)
InitStaticObjectClass(HerbicideMission, "HerbicideMission")
function HerbicideMission.registerXMLPaths(p2, p3)
	HerbicideMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function HerbicideMission.registerSavegameXMLPaths(p4, p5)
	HerbicideMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#targetWeedState", "Target weed state")
end
function HerbicideMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_herbicide_title")
	local v10 = g_i18n:getText("contract_field_herbicide_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.workAreaTypes = {
		[WorkAreaType.SPRAYER] = true
	}
	v11.fillTypeTitle = g_fillTypeManager:getFillTypeTitleByIndex(FillType.HERBICIDE)
	return v11
end
function HerbicideMission.init(p12, p13, p14)
	p12.targetWeedState = p14
	return HerbicideMission:superClass().init(p12, p13)
end
function HerbicideMission.saveToXMLFile(p15, p16, p17)
	HerbicideMission:superClass().saveToXMLFile(p15, p16, p17)
	p16:setValue(p17 .. "#targetWeedState", p15.targetWeedState)
end
function HerbicideMission.loadFromXMLFile(p18, p19, p20)
	p18.targetWeedState = p19:getValue(p20 .. "#targetWeedState", p18.targetWeedState)
	return HerbicideMission:superClass().loadFromXMLFile(p18, p19, p20)
end
function HerbicideMission.createModifier(p21)
	local v22, v23, v24 = g_currentMission.weedSystem:getDensityMapData()
	p21.completionModifier = DensityMapModifier.new(v22, v23, v24, g_terrainNode)
	p21.completionFilter = DensityMapFilter.new(p21.completionModifier)
	p21.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, p21.targetWeedState)
end
function HerbicideMission.getFieldFinishTask(p25)
	p25.field:getFieldState().weedState = p25.targetWeedState
	return HerbicideMission:superClass().getFieldFinishTask(p25)
end
function HerbicideMission.calculateReimbursement(p26)
	HerbicideMission:superClass().calculateReimbursement(p26)
	local v27 = 0
	for _, v28 in pairs(p26.vehicles) do
		if v28.spec_fillUnit ~= nil then
			for v29, _ in pairs(v28:getFillUnits()) do
				local v30 = v28:getFillUnitFillType(v29)
				if v30 == FillType.HERBICIDE then
					v27 = v27 + v28:getFillUnitFillLevel(v29) * g_fillTypeManager:getFillTypeByIndex(v30).pricePerLiter
				end
			end
		end
	end
	p26.reimbursement = p26.reimbursement + v27 * AbstractMission.REIMBURSEMENT_FACTOR
end
function HerbicideMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(HerbicideMission.NAME).rewardPerHa
end
function HerbicideMission.getMissionTypeName(_)
	return HerbicideMission.NAME
end
function HerbicideMission.validate(p31, p32)
	if HerbicideMission:superClass().validate(p31, p32) then
		return (p31:getIsFinished() or HerbicideMission.isAvailableForField(p31.field, p31)) and true or false
	else
		return false
	end
end
function HerbicideMission.loadMapData(p33, p34, _)
	g_missionManager:getMissionTypeDataByName(HerbicideMission.NAME).rewardPerHa = p33:getFloat(p34 .. "#rewardPerHa", 1500)
	return true
end
function HerbicideMission.tryGenerateMission()
	if HerbicideMission.canRun() then
		local v35 = g_fieldManager:getFieldForMission()
		if v35 == nil then
			return
		end
		if v35.currentMission ~= nil then
			return
		end
		if not HerbicideMission.isAvailableForField(v35, nil) then
			return
		end
		local v36 = v35:getFieldState().weedState
		local v37 = g_currentMission.weedSystem:getHerbicideReplacements().weed.replacements[v36]
		local v38 = HerbicideMission.new(true, g_client ~= nil)
		if v38:init(v35, v37) then
			v38:setDefaultEndDate()
			return v38
		end
		v38:delete()
	end
	return nil
end
function HerbicideMission.isAvailableForField(p39, p40)
	if p40 == nil then
		local v41 = p39:getFieldState()
		if not v41.isValid then
			return false
		end
		local v42 = v41.fruitTypeIndex
		if v42 == FruitType.UNKNOWN then
			return false
		end
		if v42 == FruitType.GRASS or v42 == FruitType.MEADOW then
			return false
		end
		local v43 = g_fruitTypeManager:getFruitTypeByIndex(v42)
		if v43:getIsCatchCrop() then
			return false
		end
		if v41.weedState == 0 then
			return false
		end
		local v44 = v41.growthState
		if v43:getIsHarvestable(v44) then
			return false
		end
		if v43:getIsWeedable(v44) then
			return false
		end
		if v43:getIsHoeable(v44) then
			return false
		end
		local v45 = v41.weedState
		local v46 = g_currentMission.weedSystem:getHerbicideReplacements().weed.replacements[v45]
		if v46 == nil or v46 == 0 then
			return false
		end
	end
	local v47 = g_currentMission.environment
	return v47 == nil or v47.currentSeason ~= Season.WINTER
end
function HerbicideMission.canRun()
	local v48 = g_missionManager:getMissionTypeDataByName(HerbicideMission.NAME)
	if v48.numInstances >= v48.maxNumInstances then
		return false
	elseif g_currentMission.growthSystem:getIsGrowingInProgress() then
		return false
	elseif g_currentMission.weedSystem:getMapHasWeed() then
		return g_currentMission.missionInfo.weedsEnabled and true or false
	else
		return false
	end
end
g_missionManager:registerMissionType(HerbicideMission, HerbicideMission.NAME, 2)

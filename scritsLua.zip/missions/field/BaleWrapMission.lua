BaleWrapMission = {}
BaleWrapMission.NAME = "baleWrapMission"
local v_u_1 = Class(BaleWrapMission, AbstractFieldMission)
InitStaticObjectClass(BaleWrapMission, "BaleWrapMission")
function BaleWrapMission.registerXMLPaths(p2, p3)
	BaleWrapMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerBale", "Reward per bale")
end
function BaleWrapMission.registerSavegameXMLPaths(p4, p5)
	BaleWrapMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#baleTypeIndex", "Bale type")
	p4:register(XMLValueType.INT, p5 .. "#numOfBales", "Bale count")
	p4:register(XMLValueType.STRING, p5 .. ".bale(?)#uniqueId", "Spawned bale")
end
function BaleWrapMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_baleWrap_title")
	local v10 = g_i18n:getText("contract_field_baleWrap_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.bales = {}
	v11.balesToLoadByUniqueId = nil
	return v11
end
function BaleWrapMission.init(p12, p13, p14, p15)
	p12.baleTypeIndex = p14
	p12.numOfBales = p15
	return BaleWrapMission:superClass().init(p12, p13)
end
function BaleWrapMission.writeStream(p16, p17, p18)
	BaleWrapMission:superClass().writeStream(p16, p17, p18)
	streamWriteUIntN(p17, p16.baleTypeIndex, BaleManager.SEND_NUM_BITS)
	streamWriteUInt16(p17, p16.numOfBales)
end
function BaleWrapMission.readStream(p19, p20, p21)
	BaleWrapMission:superClass().readStream(p19, p20, p21)
	p19.baleTypeIndex = streamReadUIntN(p20, BaleManager.SEND_NUM_BITS)
	p19.numOfBales = streamReadUInt16(p20)
end
function BaleWrapMission.saveToXMLFile(p22, p23, p24)
	BaleWrapMission:superClass().saveToXMLFile(p22, p23, p24)
	for v25, v26 in ipairs(p22.bales) do
		p23:setValue(string.format("%s.bale(%d)", p24, v25 - 1) .. "#uniqueId", v26:getUniqueId())
	end
	p23:setValue(p24 .. "#baleTypeIndex", p22.baleTypeIndex)
	p23:setValue(p24 .. "#numOfBales", p22.numOfBales)
end
function BaleWrapMission.loadFromXMLFile(p27, p28, p29)
	for _, v30 in p28:iterator(p29 .. ".bale") do
		local v31 = p28:getValue(v30 .. "#uniqueId")
		if p27.balesToLoadByUniqueId == nil then
			p27.balesToLoadByUniqueId = {}
		end
		local v32 = p27.balesToLoadByUniqueId
		table.insert(v32, v31)
	end
	p27.baleTypeIndex = p28:getValue(p29 .. "#baleTypeIndex")
	if p27.baleTypeIndex == nil then
		return false
	end
	p27.numOfBales = p28:getValue(p29 .. "#numOfBales")
	if p27.numOfBales == nil then
		return false
	end
	p27.finishedBaleSpawning = true
	return BaleWrapMission:superClass().loadFromXMLFile(p27, p28, p29)
end
function BaleWrapMission.prepareField(p_u_33)
	BaleWrapMission:superClass().prepareField(p_u_33)
	if p_u_33.isServer then
		local v34 = FruitType.GRASS
		local v35 = g_fruitTypeManager:getFruitTypeByIndex(v34)
		local v36 = v35.windrowLiterPerSqm or v35.literPerSqm
		local v_u_37 = MathUtil.haToSqm(p_u_33.field:getAreaHa()) * v36
		local v38, v39 = p_u_33.field:getCenterOfFieldWorldPosition()
		local v40 = FieldCourseSettings.new()
		v40.implementWidth = 8
		v40.numHeadlands = 2
		local v_u_41 = v35.windrowFillType.index
		local v_u_42 = g_baleManager:getBaleXMLFilenameByIndex(p_u_33.baleTypeIndex)
		local v_u_43 = g_baleManager:getBaleCapacityByBaleIndex(p_u_33.baleTypeIndex, v_u_41)
		local v_u_44 = g_baleManager:getBaleDescByIndex(p_u_33.baleTypeIndex)
		local v_u_45 = g_baleManager:getIsRoundBale(p_u_33.baleTypeIndex)
		local v_u_46 = v_u_43
		local function v_u_63(p47, p48, p49, p50, p51, p52)
			-- upvalues: (copy) v_u_44, (copy) v_u_45, (copy) p_u_33, (copy) v_u_42, (copy) v_u_41, (copy) v_u_43
			local v53 = p51 * p52
			local v54, v55 = MathUtil.vector2Normalize(p49 - p47, p50 - p48)
			local v56 = p47 + v54 * v53
			local v57 = p48 + v55 * v53
			local v58 = MathUtil.getYRotationFromDirection(v54, v55) + 1.5707963267948966
			local v59 = v_u_44.diameter
			if not v_u_45 then
				v58 = v58 + 1.5707963267948966
				v59 = v_u_44.height
			end
			local v60 = getTerrainHeightAtWorldPos(g_terrainNode, v56, 0, v57) + v59 * 0.5
			local v61 = Bale.new(p_u_33.isServer, p_u_33.isClient)
			if v61:loadFromConfigXML(v_u_42, v56, v60, v57, 0, v58, 0) then
				v61:setFillType(v_u_41)
				v61:setFillLevel(v_u_43)
				v61:setOwnerFarmId(p_u_33.field:getOwner(), true)
				v61:register()
				local v62 = p_u_33.bales
				table.insert(v62, v61)
			end
		end
		local v_u_64 = 0
		local v_u_65 = nil
		local v_u_66 = nil
		local v_u_67 = nil
		local v_u_68 = nil
		local v_u_69 = nil
		local function v79(p70, p71, p72, p73, _, _, _, p74)
			-- upvalues: (copy) v_u_37, (ref) v_u_64, (ref) v_u_65, (ref) v_u_66, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (ref) v_u_46, (copy) v_u_43, (copy) v_u_63
			local v75 = MathUtil.vector2Length(p72 - p70, p73 - p71)
			local v76 = v75 * (v_u_37 / p74)
			v_u_64 = v76
			v_u_65 = p70
			v_u_66 = p71
			v_u_67 = p72
			v_u_68 = p73
			v_u_69 = v75
			while v_u_64 > 0 do
				if v_u_64 <= v_u_46 then
					v_u_46 = v_u_46 - v_u_64
					v_u_64 = 0
				else
					local v77 = v_u_46 - v_u_64
					v_u_64 = math.abs(v77)
					local v78 = 1 - v_u_64 / v76
					v_u_46 = v_u_43
					v_u_63(p70, p71, p72, p73, v75, v78)
				end
			end
		end
		local function v80()
			-- upvalues: (ref) v_u_64, (copy) v_u_63, (ref) v_u_65, (ref) v_u_66, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) p_u_33
			if v_u_64 > 0 then
				v_u_63(v_u_65, v_u_66, v_u_67, v_u_68, v_u_69, 1)
			end
			p_u_33.finishedBaleSpawning = true
		end
		FieldCourseIterator.new(v38, v39, v40, v79, v80)
	end
end
function BaleWrapMission.getFieldPreparingTask(p81)
	local v82 = FruitType.GRASS
	local v83 = g_fruitTypeManager:getFruitTypeByIndex(v82)
	local v84 = FieldUpdateTask.new()
	v84:setArea(p81.field:getDensityMapPolygon())
	v84:setField(p81.field)
	v84:setFruit(v82, v83.cutState)
	if v83.harvestGroundType ~= nil then
		v84:setGroundType(v83.harvestGroundType)
	end
	return v84
end
function BaleWrapMission.getIsPrepared(p85)
	if BaleWrapMission:superClass().getIsPrepared(p85) then
		return p85.finishedBaleSpawning
	else
		return false
	end
end
function BaleWrapMission.finishField(p86)
	if p86.isServer then
		for _, v87 in ipairs(p86.bales) do
			v87:delete()
		end
		p86.bales = {}
	end
	BaleWrapMission:superClass().finishField(p86)
end
function BaleWrapMission.update(p88, p89)
	if p88.isServer and p88.balesToLoadByUniqueId ~= nil then
		for _, v90 in ipairs(p88.balesToLoadByUniqueId) do
			local v91 = g_currentMission.itemSystem:getItemByUniqueId(v90)
			if v91 ~= nil then
				local v92 = p88.bales
				table.insert(v92, v91)
			end
		end
		p88.balesToLoadByUniqueId = nil
		local v93 = #p88.bales
		if v93 ~= p88.numOfBales then
			Logging.error("Could not load all bales from savegame")
			p88.numOfBales = v93
		end
	end
	BaleWrapMission:superClass().update(p88, p89)
end
function BaleWrapMission.getCompletion(p94)
	local v95 = 0
	local v96 = 0
	local v97 = true
	for _, v98 in ipairs(p94.bales) do
		v95 = v95 + v98.wrappingState
		if v98:getIsMounted() then
			v97 = false
		end
	end
	if p94.balesToLoadByUniqueId == nil then
		local v99 = #p94.bales
		local v100 = v99 <= 0 and 1 or v95 / v99
		v96 = v100 * 0.99
		if v100 == 1 and v97 then
			v96 = v96 + 0.01
		end
	end
	return v96
end
function BaleWrapMission.getRewardPerHa(_)
	return 1
end
function BaleWrapMission.getReward(p101)
	local v102 = g_missionManager:getMissionTypeDataByName(BaleWrapMission.NAME)
	local v103 = 1.3 - 0.1 * g_currentMission.missionInfo.economicDifficulty
	return BaleWrapMission:superClass().getReward(p101) + v102.rewardPerBale * p101.numOfBales * v103
end
function BaleWrapMission.getDetails(p104)
	local v105 = BaleWrapMission:superClass().getDetails(p104)
	local v106
	if g_baleManager:getIsRoundBale(p104.baleTypeIndex) then
		v106 = g_i18n:getText("contract_details_bale_type_round")
	else
		v106 = g_i18n:getText("contract_details_bale_type_square")
	end
	local v107 = {
		["title"] = g_i18n:getText("contract_details_bale_type"),
		["value"] = v106
	}
	table.insert(v105, v107)
	return v105
end
function BaleWrapMission.getVehicleVariant(p108)
	return g_baleManager:getIsRoundBale(p108.baleTypeIndex) and "ROUNDBALE" or "SQUAREBALE"
end
function BaleWrapMission.getVariant(p109)
	return g_baleManager:getIsRoundBale(p109.baleTypeIndex) and "ROUNDBALER" or "SQUAREBALER"
end
function BaleWrapMission.getMissionTypeName(_)
	return BaleWrapMission.NAME
end
function BaleWrapMission.validate(p110, p111)
	if BaleWrapMission:superClass().validate(p110, p111) then
		return (p110:getIsFinished() or BaleWrapMission.isAvailableForField(p110.field, p110)) and true or false
	else
		return false
	end
end
function BaleWrapMission.loadMapData(p112, p113, _)
	g_missionManager:getMissionTypeDataByName(BaleWrapMission.NAME).rewardPerBale = p112:getFloat(p113 .. "#rewardPerBale", 300)
	return true
end
function BaleWrapMission.tryGenerateMission()
	if BaleWrapMission.canRun() then
		local v114 = g_fieldManager:getFieldForMission()
		if v114 == nil then
			return
		end
		if v114.currentMission ~= nil then
			return
		end
		if not BaleWrapMission.isAvailableForField(v114, nil) then
			return
		end
		local v115
		if math.random() > 0.5 then
			v115 = g_baleManager:getBaleIndex(FillType.GRASS_WINDROW, true, 1.2, 0, 0, 1.5, "")
		else
			v115 = g_baleManager:getBaleIndex(FillType.GRASS_WINDROW, false, 1.2, 0.9, 1.8, 0, "")
		end
		if v115 == nil then
			return
		end
		local v116 = g_fruitTypeManager:getFruitTypeByIndex(FruitType.GRASS).literPerSqm
		local v117 = MathUtil.haToSqm(v114:getAreaHa())
		local v118 = g_baleManager:getBaleCapacityByBaleIndex(v115, FillType.GRASS_WINDROW)
		local v119 = v117 * v116 / v118
		local v120 = math.floor(v119)
		if v120 == 0 then
			return
		end
		local v121 = BaleWrapMission.new(true, g_client ~= nil)
		if v121:init(v114, v115, v120) then
			v121:setDefaultEndDate()
			return v121
		end
		v121:delete()
	end
	return nil
end
function BaleWrapMission.isAvailableForField(p122, p123)
	if p123 == nil then
		local v124 = p122:getFieldState()
		if not v124.isValid then
			return false
		end
		local v125 = v124.fruitTypeIndex
		if v125 ~= FruitType.GRASS then
			return false
		end
		if not g_fruitTypeManager:getFruitTypeByIndex(v125):getIsHarvestable(v124.growthState) then
			return false
		end
	end
	local v126 = g_currentMission.environment
	return v126 == nil or v126.currentSeason ~= Season.WINTER
end
function BaleWrapMission.canRun()
	local v127 = g_missionManager:getMissionTypeDataByName(BaleWrapMission.NAME)
	return v127.numInstances < v127.maxNumInstances
end
g_missionManager:registerMissionType(BaleWrapMission, BaleWrapMission.NAME, 2)

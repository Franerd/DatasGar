AbstractFieldMission = {}
source("dataS/scripts/missions/field/AbstractFieldMissionHotspot.lua")
local v_u_1 = Class(AbstractFieldMission, AbstractMission)
InitStaticObjectClass(AbstractFieldMission, "AbstractFieldMission")
AbstractFieldMission.FIELD_SIZE_MEDIUM = 1.5
AbstractFieldMission.FIELD_SIZE_LARGE = 4
AbstractFieldMission.SQM_PER_PARTITION = 2500
function AbstractFieldMission.registerSavegameXMLPaths(p2, p3)
	AbstractFieldMission:superClass().registerSavegameXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. ".field#id", "Field id")
	p2:register(XMLValueType.STRING, p3 .. ".field.preparingTask#className")
	FieldUpdateTask.registerXMLPaths(p2, p3 .. ".field.preparingTask")
end
function AbstractFieldMission.new(p4, p5, p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = AbstractMission.new(p4, p5, p6, p7, p8 or v_u_1)
	v9.workAreaTypes = {}
	v9.moneyMultiplier = 1
	v9.isInMissionMap = false
	v9.fieldPercentageDone = 0
	v9.completionModifier = nil
	v9.completionFilter = nil
	v9.isHotspotAdded = false
	v9.mapHotspot = nil
	return v9
end
function AbstractFieldMission.init(p10, p11)
	p10:setField(p11)
	return AbstractFieldMission:superClass().init(p10)
end
function AbstractFieldMission.setField(p12, p13)
	p12.field = p13
	p13:setMission(p12)
	local v14 = p13:getId()
	if v14 ~= nil then
		p12.progressTitle = string.format("%s (%s %d)", p12.title, g_i18n:getText("contract_details_field"), v14)
	end
	g_fieldManager:onFieldMissionStarted()
	p12:createMapHotspot()
end
function AbstractFieldMission.createMapHotspot(p15)
	if p15.mapHotspot == nil then
		p15.mapHotspot = AbstractFieldMissionHotspot.new()
	end
	p15.mapHotspot:setField(p15.field)
	p15.mapHotspots = { p15.mapHotspot }
end
function AbstractFieldMission.getField(p16)
	return p16.field
end
function AbstractFieldMission.getMapHotspots(p17)
	return p17.mapHotspots
end
function AbstractFieldMission.getWorldPosition(p18)
	return p18.field:getIndicatorPosition()
end
function AbstractFieldMission.getLocation(p19)
	local v20 = p19.field:getName()
	return string.format(g_i18n:getText("contract_farmland"), v20)
end
function AbstractFieldMission.reactivate(p21)
	p21:createModifier()
	AbstractFieldMission:superClass().reactivate(p21)
end
function AbstractFieldMission.delete(p22)
	p22:removeFromMissionMap()
	p22:removeHotspot()
	if p22.mapHotspot ~= nil then
		p22.mapHotspot:delete()
		p22.mapHotspot = nil
	end
	p22.mapHotspots = nil
	if p22.field ~= nil then
		p22.field:setMission(nil)
		g_fieldManager:onFieldMissionDeleted()
	end
	AbstractFieldMission:superClass().delete(p22)
end
function AbstractFieldMission.saveToXMLFile(p23, p24, p25)
	AbstractFieldMission:superClass().saveToXMLFile(p23, p24, p25)
	p24:setValue(p25 .. ".field#id", p23.field:getId())
	if p23.status == MissionStatus.PREPARING and (p23.fieldPreparingTask ~= nil and p23.fieldPreparingTask:getIsFinished()) then
		local v26 = p25 .. ".field.preparingTask"
		p24:setValue(v26 .. "#className", ClassUtil.getClassNameByObject(p23.fieldPreparingTask))
		p23.fieldPreparingTask:saveToXMLFile(p24, v26)
	end
end
function AbstractFieldMission.loadFromXMLFile(p27, p28, p29)
	local v30 = p28:getValue(p29 .. ".field#id")
	local v31 = g_fieldManager:getFieldById(v30)
	if v31 == nil then
		Logging.xmlWarning(p28, "Mission \'%s\' field \'%s\' is not available.", p29, v30)
		return false
	end
	p27:setField(v31)
	if not AbstractFieldMission:superClass().loadFromXMLFile(p27, p28, p29) then
		return false
	end
	local v32 = p29 .. ".field.preparingTask"
	if p28:hasProperty(v32) then
		local v33 = p28:getValue(v32 .. "#className", "FieldUpdateTask")
		local v34 = ClassUtil.getClassObject(v33)
		if v34 == nil then
			Logging.xmlWarning(p28, "Class \'%s\' not defined for update task \'%s\'", v33, v32)
		else
			local v35 = v34.new()
			if v35:loadFromXMLFile(p28, v32) then
				v35:setNeedsSaving(false)
				v35:enqueue()
				p27.fieldPreparingTask = v35
			end
		end
	end
	if p27.status == MissionStatus.PREPARING or p27.status == MissionStatus.RUNNING then
		p27:addToMissionMap()
	end
	return true
end
function AbstractFieldMission.writeStream(p36, p37, p38)
	streamWriteInt32(p37, p36.field:getId())
	AbstractFieldMission:superClass().writeStream(p36, p37, p38)
end
function AbstractFieldMission.readStream(p39, p40, p41)
	local v42 = streamReadInt32(p40)
	p39:setField((g_fieldManager:getFieldById(v42)))
	AbstractFieldMission:superClass().readStream(p39, p40, p41)
	if p39.status == MissionStatus.PREPARING or p39.status == MissionStatus.RUNNING then
		p39:addToMissionMap()
	end
end
function AbstractFieldMission.update(p43, p44)
	AbstractFieldMission:superClass().update(p43, p44)
	if p43.status == MissionStatus.RUNNING and (g_localPlayer ~= nil and (g_localPlayer.farmId == p43.farmId and not p43.isHotspotAdded)) then
		p43:addHotspots()
	end
end
function AbstractFieldMission.start(p45, p46)
	if not AbstractFieldMission:superClass().start(p45, p46) then
		return false
	end
	p45:addToMissionMap()
	return true
end
function AbstractFieldMission.prepare(p47, p48)
	AbstractFieldMission:superClass().prepare(p47, p48)
	p47:prepareField()
	p47:createModifier()
end
function AbstractFieldMission.prepareField(p49)
	if p49.isServer then
		p49.fieldPreparingTask = p49:getFieldPreparingTask()
		if p49.fieldPreparingTask ~= nil then
			p49.fieldPreparingTask:setNeedsSaving(false)
			g_fieldManager:addFieldUpdateTask(p49.fieldPreparingTask)
		end
	end
end
function AbstractFieldMission.getFieldPreparingTask(p50)
	local v51 = p50.field:getFieldState()
	if v51.isValid then
		local v52 = v51:createFieldUpdateTask()
		v52:clearHeight()
		v52:setField(p50.field)
		return v52
	end
end
function AbstractFieldMission.getIsPrepared(p53)
	if AbstractFieldMission:superClass().getIsPrepared(p53) then
		return p53.fieldPreparingTask == nil and true or p53.fieldPreparingTask:getIsFinished()
	else
		return false
	end
end
function AbstractFieldMission.finishField(p54)
	if p54.isServer then
		local v55 = p54:getFieldFinishTask()
		if v55 ~= nil then
			v55:setField(p54.field)
			g_fieldManager:addFieldUpdateTask(v55)
		end
	end
end
function AbstractFieldMission.getFieldFinishTask(p56)
	local v57 = p56.field:getFieldState()
	if v57.isValid then
		return v57:createFieldUpdateTask()
	else
		return nil
	end
end
function AbstractFieldMission.started(p58)
	p58:addToMissionMap()
end
function AbstractFieldMission.finish(p59, p60)
	AbstractFieldMission:superClass().finish(p59, p60)
	p59:removeHotspot()
	local v61 = g_currentMission
	if v61:getFarmId() == p59.farmId then
		if p60 == MissionFinishState.SUCCESS then
			v61:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, string.format(g_i18n:getText("contract_field_finished"), p59.field:getId()))
			return
		end
		if p60 == MissionFinishState.FAILED then
			v61:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("contract_field_failed"), p59.field:getId()))
			return
		end
		if p60 == MissionFinishState.TIMED_OUT then
			v61:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("contract_field_timedOut"), p59.field:getId()))
		end
	end
end
function AbstractFieldMission.dismiss(p62)
	p62:finishField()
	AbstractFieldMission:superClass().dismiss(p62)
end
function AbstractFieldMission.removeAccess(p63)
	p63:removeFromMissionMap()
	AbstractFieldMission:superClass().removeAccess(p63)
end
function AbstractFieldMission.validate(p64)
	if AbstractFieldMission:superClass().validate(p64) then
		if p64.field == nil then
			return false
		else
			return not p64.field:getHasOwner()
		end
	else
		return false
	end
end
function AbstractFieldMission.showCompletionNotification(p65)
	local v66 = g_currentMission
	local v67 = string.format(g_i18n:getText("contract_field_completionNotification"), p65.field:getId(), p65.completion * 100)
	v66:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, v67)
end
function AbstractFieldMission.createModifier(_) end
function AbstractFieldMission.initializeModifier(p68)
	if p68.completionModifier == nil then
		::l2::
	else
		p68.field:getDensityMapPolygon():applyToModifier(p68.completionModifier)
		p68.completionPartitions = {}
		local v69, v70 = p68.completionModifier:getPolygonMinMaxZ()
		if v69 == nil then
			local v71 = p68.completionPartitions
			table.insert(v71, {
				["wasCalculated"] = false,
				["percentageDone"] = 0,
				["sumPixels"] = 0,
				["area"] = 0,
				["totalArea"] = 0
			})
			goto l2
		end
		local v72 = MathUtil.haToSqm(p68.field:getAreaHa()) / AbstractFieldMission.SQM_PER_PARTITION
		local v73 = math.ceil(v72)
		local v74 = (v70 - v69) / v73
		local v75 = nil
		local v76 = nil
		for _ = 1, v73 do
			if v75 == nil then
				v76 = v69
			end
			local v77 = v76 + v74
			local v78 = math.ceil(v77)
			local v79 = {
				["wasCalculated"] = false,
				["percentageDone"] = 0,
				["sumPixels"] = 0,
				["area"] = 0,
				["totalArea"] = 0,
				["minZ"] = v76,
				["maxZ"] = math.min(v78, v70)
			}
			local v80 = p68.completionPartitions
			table.insert(v80, v79)
			if v76 == nil or v70 <= v78 then
				goto l2
			end
			v75 = v76
			v76 = v78
		end
	end
end
function AbstractFieldMission.setPartitionRegion(p81, p82)
	if #p81.completionPartitions ~= 1 then
		if p81.completionModifier ~= nil then
			local v83 = p81.completionPartitions[p82]
			p81.completionModifier:setPolygonClipRegion(v83.minZ, v83.maxZ)
		end
	end
end
function AbstractFieldMission.getPartitionCompletion(p84, p85)
	p84:setPartitionRegion(p85)
	if p84.completionModifier == nil then
		return 0, 0, 0
	end
	local v86, v87, v88 = p84.completionModifier:executeGet(p84.completionFilter)
	return v86, v87, v88
end
function AbstractFieldMission.getCompletion(p89)
	return p89:getFieldCompletion() / AbstractMission.SUCCESS_FACTOR
end
function AbstractFieldMission.getFieldCompletion(p90)
	if not p90.isFieldCompletionInitialized then
		p90:initializeModifier()
		p90.isFieldCompletionInitialized = true
	end
	if p90.currentPartitionCompletionIndex == nil then
		p90.currentPartitionCompletionIndex = 1
	end
	local v91, v92, v93 = p90:getPartitionCompletion(p90.currentPartitionCompletionIndex)
	if v92 ~= nil and v93 > 0 then
		local v94 = p90.completionPartitions[p90.currentPartitionCompletionIndex]
		v94.wasCalculated = true
		v94.percentageDone = v92 / v93
		v94.sumPixels = v91
		v94.area = v92
		v94.totalArea = v93
	end
	local v95 = 0
	local v96 = true
	for _, v97 in ipairs(p90.completionPartitions) do
		if not v97.wasCalculated then
			v96 = false
		end
		v95 = v95 + v97.percentageDone
	end
	if v96 then
		p90.fieldPercentageDone = v95 / #p90.completionPartitions
	end
	p90.currentPartitionCompletionIndex = p90.currentPartitionCompletionIndex + 1
	if p90.currentPartitionCompletionIndex > #p90.completionPartitions then
		p90.currentPartitionCompletionIndex = 1
	end
	return p90.fieldPercentageDone
end
function AbstractFieldMission.getVehicleSize(p98)
	local v99 = p98.field:getAreaHa()
	return AbstractFieldMission.FIELD_SIZE_LARGE < v99 and "large" or (AbstractFieldMission.FIELD_SIZE_MEDIUM < v99 and "medium" or "small")
end
function AbstractFieldMission.getDetails(p100)
	local v101 = AbstractFieldMission:superClass().getDetails(p100)
	local v102 = {
		["title"] = g_i18n:getText("contract_details_field"),
		["value"] = p100.field:getName()
	}
	table.insert(v101, v102)
	local v103 = {
		["title"] = g_i18n:getText("contract_details_fieldSize"),
		["value"] = g_i18n:formatArea(p100.field:getAreaHa(), 2)
	}
	table.insert(v101, v103)
	return v101
end
function AbstractFieldMission.getRewardPerHa(_)
	return 1
end
function AbstractFieldMission.getReward(p104)
	local v105 = 1.3 - 0.1 * g_currentMission.missionInfo.economicDifficulty
	local v106 = p104.field:getAreaHa()
	return AbstractFieldMission:superClass().getReward(p104) + p104:getRewardPerHa() * v106 * v105
end
function AbstractFieldMission.getFarmlandId(p107)
	local v108 = p107.field
	if v108 == nil then
		return nil
	else
		return v108:getId()
	end
end
function AbstractFieldMission.addToMissionMap(p109)
	if not p109.isInMissionMap then
		p109:updateMissionMap(p109.activeMissionId)
		p109.isInMissionMap = true
	end
end
function AbstractFieldMission.removeFromMissionMap(p110)
	if p110.isInMissionMap then
		p110:updateMissionMap(0)
		p110.isInMissionMap = false
	end
end
function AbstractFieldMission.updateMissionMap(p111, p112)
	local v113 = p111.field:getDensityMapPolygon()
	g_missionManager:setMissionMapActiveMissionId(v113, p112)
end
function AbstractFieldMission.getNPC(p114)
	return p114.field.farmland:getNPC()
end
function AbstractFieldMission.getIsWorkAllowed(p115, _, _, _, p116, _)
	local v117 = p115:getIsRunning()
	if v117 then
		v117 = p116 == nil and true or p115.workAreaTypes[p116]
	end
	return v117
end
function AbstractFieldMission.addHotspots(p118)
	if p118.mapHotspot ~= nil then
		p118.isHotspotAdded = true
		g_currentMission:addMapHotspot(p118.mapHotspot)
	end
end
function AbstractFieldMission.removeHotspot(p119)
	if p119.mapHotspot ~= nil then
		g_currentMission:removeMapHotspot(p119.mapHotspot)
		p119.isHotspotAdded = false
	end
end

MowMission = {}
MowMission.NAME = "mowMission"
local v_u_1 = Class(MowMission, AbstractFieldMission)
InitStaticObjectClass(MowMission, "MowMission")
function MowMission.registerXMLPaths(p2, p3)
	MowMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function MowMission.registerSavegameXMLPaths(p4, p5)
	MowMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.STRING, p5 .. "#fruitType", "Name of the fruit type")
end
function MowMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_mow_title")
	local v10 = g_i18n:getText("contract_field_mow_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.workAreaTypes = {
		[WorkAreaType.MOWER] = true
	}
	v11.fruitTypeIndex = nil
	return v11
end
function MowMission.init(p12, p13, p14)
	p12.fruitTypeIndex = p14
	p12.fillTypeIndex = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(p14)
	return MowMission:superClass().init(p12, p13)
end
function MowMission.onSavegameLoaded(p15)
	if p15.field:getFieldState().fruitTypeIndex == p15.fruitTypeIndex then
		MowMission:superClass().onSavegameLoaded(p15)
	else
		local v16 = g_fruitTypeManager:getFruitTypeByIndex(p15.fruitTypeIndex)
		if v16 == nil then
			Logging.error("FruitType \'%s\' is not defined for mow mission", p15.fruitTypeIndex)
		else
			Logging.error("FruitType \'%s\' is not present on field \'%s\' for mow mission", v16.name, p15.field:getName())
		end
		g_missionManager:markMissionForDeletion(p15)
	end
end
function MowMission.saveToXMLFile(p17, p18, p19)
	MowMission:superClass().saveToXMLFile(p17, p18, p19)
	p18:setValue(p19 .. "#fruitType", g_fruitTypeManager:getFruitTypeNameByIndex(p17.fruitTypeIndex))
end
function MowMission.loadFromXMLFile(p20, p21, p22)
	if not MowMission:superClass().loadFromXMLFile(p20, p21, p22) then
		return false
	end
	local v23 = p21:getValue(p22 .. "#fruitType")
	local v24 = g_fruitTypeManager:getFruitTypeByName(v23)
	if v24 == nil then
		Logging.xmlError(p21, "FruitType \'%s\' not defined", v23)
		return false
	end
	p20.fruitTypeIndex = v24.index
	p20.fillTypeIndex = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(p20.fruitTypeIndex)
	return true
end
function MowMission.createModifier(p25)
	local v26 = g_fruitTypeManager:getFruitTypeByIndex(p25.fruitTypeIndex)
	if v26 ~= nil and v26.terrainDataPlaneId ~= nil then
		p25.completionModifier = DensityMapModifier.new(v26.terrainDataPlaneId, v26.startStateChannel, v26.numStateChannels, g_terrainNode)
		p25.completionFilter = DensityMapFilter.new(p25.completionModifier)
		p25.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, v26.cutState)
	end
end
function MowMission.getFieldFinishTask(p27)
	local v28 = g_fruitTypeManager:getFruitTypeByIndex(p27.fruitTypeIndex)
	if v28 ~= nil then
		local v29 = p27.field:getFieldState()
		v29.fruitTypeIndex = p27.fruitTypeIndex
		v29.growthState = v28.cutState
	end
	local v30 = MowMission:superClass().getFieldFinishTask(p27)
	if v30 ~= nil then
		v30:clearHeight()
	end
	return v30
end
function MowMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(MowMission.NAME).rewardPerHa
end
function MowMission.getMissionTypeName(_)
	return MowMission.NAME
end
function MowMission.validate(p31, p32)
	if MowMission:superClass().validate(p31, p32) then
		return (p31:getIsFinished() or MowMission.isAvailableForField(p31.field, p31)) and true or false
	else
		return false
	end
end
function MowMission.loadMapData(p33, p34, _)
	local v35 = g_missionManager:getMissionTypeDataByName(MowMission.NAME)
	v35.rewardPerHa = p33:getFloat(p34 .. "#rewardPerHa", 2500)
	v35.fruitTypeIndices = {}
	v35.fruitTypeIndices[FruitType.GRASS] = true
	return true
end
function MowMission.tryGenerateMission()
	if MowMission.canRun() then
		local v36 = g_fieldManager:getFieldForMission()
		if v36 == nil then
			return
		end
		if v36.currentMission ~= nil then
			return
		end
		if not MowMission.isAvailableForField(v36, nil) then
			return
		end
		local v37 = v36:getFieldState().fruitTypeIndex
		local v38 = MowMission.new(true, g_client ~= nil)
		if v38:init(v36, v37) then
			v38:setDefaultEndDate()
			return v38
		end
		v38:delete()
	end
	return nil
end
function MowMission.isAvailableForField(p39, p40)
	if p40 == nil then
		local v41 = p39:getFieldState()
		if not v41.isValid then
			return false
		end
		local v42 = g_missionManager:getMissionTypeDataByName(MowMission.NAME)
		local v43 = v41.fruitTypeIndex
		if v42.fruitTypeIndices[v43] == nil then
			return false
		end
		if not g_fruitTypeManager:getFruitTypeByIndex(v43):getIsHarvestable(v41.growthState) then
			return false
		end
	end
	local v44 = g_currentMission.environment
	return v44 == nil or v44.currentSeason ~= Season.WINTER
end
function MowMission.canRun()
	local v45 = g_missionManager:getMissionTypeDataByName(MowMission.NAME)
	return v45.numInstances < v45.maxNumInstances
end
g_missionManager:registerMissionType(MowMission, MowMission.NAME, 3)

StonePickMission = {}
StonePickMission.NAME = "stonePickMission"
local v_u_1 = Class(StonePickMission, AbstractFieldMission)
InitStaticObjectClass(StonePickMission, "StonePickMission")
function StonePickMission.registerXMLPaths(p2, p3)
	StonePickMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function StonePickMission.new(p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = g_i18n:getText("contract_field_stonePick_title")
	local v8 = g_i18n:getText("contract_field_stonePick_description")
	local v9 = AbstractFieldMission.new(p4, p5, v7, v8, p6 or v_u_1)
	v9.workAreaTypes = {
		[WorkAreaType.STONEPICKER] = true
	}
	v9.stoneValue = 3
	v9.spawnedPixels = 0
	return v9
end
function StonePickMission.init(p10, p11)
	return StonePickMission:superClass().init(p10, p11)
end
function StonePickMission.getFieldPreparingTask(p12)
	if p12.isServer then
		p12.field:getFieldState().stoneLevel = p12.stoneValue
	end
	return StonePickMission:superClass().getFieldPreparingTask(p12)
end
function StonePickMission.getFieldFinishTask(p13)
	if p13.isServer then
		p13.field:getFieldState().stoneLevel = 0
	end
	return StonePickMission:superClass().getFieldFinishTask(p13)
end
function StonePickMission.createModifier(p14)
	local v15, v16, v17 = g_currentMission.stoneSystem:getDensityMapData()
	local _, v18 = g_currentMission.stoneSystem:getMinMaxValues()
	p14.completionModifier = DensityMapModifier.new(v15, v16, v17, g_terrainNode)
	p14.completionModifierUnmasked = DensityMapModifier.new(v15, v16, v17, g_terrainNode)
	p14.completionFilter = DensityMapFilter.new(p14.completionModifier)
	p14.completionFilter:setValueCompareParams(DensityValueCompareType.NOTEQUAL, v18)
	p14.completionFilterMasked = DensityMapFilter.new(p14.completionModifier)
	p14.completionFilterMasked:setValueCompareParams(DensityValueCompareType.GREATER, 0)
	p14.completionFilterUnmasked = DensityMapFilter.new(p14.completionModifier)
	p14.completionFilterUnmasked:setValueCompareParams(DensityValueCompareType.EQUAL, 0)
end
function StonePickMission.getPartitionCompletion(p19, p20)
	p19:setPartitionRegion(p20)
	if p19.completionModifier == nil then
		return 0, 0, 0
	end
	local v21, v22, v23 = p19.completionModifier:executeGet(p19.completionFilter, p19.completionFilterMasked)
	local _, v24, _ = p19.completionModifierUnmasked:executeGet(p19.completionFilterUnmasked)
	return v21, v22, v23 - v24
end
function StonePickMission.initializeModifier(p25)
	StonePickMission:superClass().initializeModifier(p25)
	if p25.completionModifierUnmasked ~= nil then
		p25.field:getDensityMapPolygon():applyToModifier(p25.completionModifierUnmasked)
	end
end
function StonePickMission.setPartitionRegion(p26, p27)
	StonePickMission:superClass().setPartitionRegion(p26, p27)
	if #p26.completionPartitions ~= 1 then
		if p26.completionModifierUnmasked ~= nil then
			local v28 = p26.completionPartitions[p27]
			p26.completionModifierUnmasked:setPolygonClipRegion(v28.minZ, v28.maxZ)
		end
	end
end
function StonePickMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(StonePickMission.NAME).rewardPerHa
end
function StonePickMission.getMissionTypeName(_)
	return StonePickMission.NAME
end
function StonePickMission.validate(p29, p30)
	if StonePickMission:superClass().validate(p29, p30) then
		return (p29:getIsFinished() or StonePickMission.isAvailableForField(p29.field, p29)) and true or false
	else
		return false
	end
end
function StonePickMission.loadMapData(p31, p32, _)
	g_missionManager:getMissionTypeDataByName(StonePickMission.NAME).rewardPerHa = p31:getFloat(p32 .. "#rewardPerHa", 2200)
	return true
end
function StonePickMission.tryGenerateMission()
	if StonePickMission.canRun() then
		local v33 = g_fieldManager:getFieldForMission()
		if v33 == nil then
			return
		end
		if v33.currentMission ~= nil then
			return
		end
		if not StonePickMission.isAvailableForField(v33, nil) then
			return
		end
		local v34 = StonePickMission.new(true, g_client ~= nil)
		if v34:init(v33) then
			v34:setDefaultEndDate()
			return v34
		end
		v34:delete()
	end
	return nil
end
function StonePickMission.isAvailableForField(p35, p36)
	if p36 == nil then
		local v37 = p35:getFieldState()
		if not v37.isValid then
			return false
		end
		if v37.fruitTypeIndex ~= FruitType.UNKNOWN then
			return false
		end
		local v38 = v37.groundType
		if v38 ~= FieldGroundType.PLOWED and v38 ~= FieldGroundType.CULTIVATED then
			return false
		end
	end
	local v39 = g_currentMission.environment
	return v39 == nil or v39.currentSeason ~= Season.WINTER
end
function StonePickMission.canRun()
	local v40 = g_missionManager:getMissionTypeDataByName(StonePickMission.NAME)
	return v40.numInstances < v40.maxNumInstances
end
g_missionManager:registerMissionType(StonePickMission, StonePickMission.NAME, 1)

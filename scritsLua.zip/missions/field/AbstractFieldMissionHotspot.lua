AbstractFieldMissionHotspot = {}
local v_u_1 = Class(AbstractFieldMissionHotspot, MapHotspot)
function AbstractFieldMissionHotspot.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = MapHotspot.new(p2 or v_u_1)
	local v4, v5 = getNormalizedScreenValues(50, 50)
	v3.width = v4
	v3.height = v5
	local v6 = Utils.getFilename("$dataS/menu/hud/hud_elements.png", AbstractFieldMissionHotspot.MOD_DIRECTORY)
	local v7 = GuiUtils.getUVs({
		48,
		291,
		256,
		256
	}, { 1024, 1024 })
	v3.circle = Overlay.new(v6, 0, 0, v3.width, v3.height)
	v3.circle:setUVs(v7)
	v3.circle:setColor(0.5089, 0.016, 0.016, 1)
	v3.worldRadius = 50
	v3.forceNoRotation = true
	return v3
end
function AbstractFieldMissionHotspot.delete(p8)
	AbstractFieldMissionHotspot:superClass().delete(p8)
	if p8.circle ~= nil then
		p8.circle:delete()
		p8.circle = nil
	end
end
function AbstractFieldMissionHotspot.setField(p9, p10)
	p9.field = p10
	local v11, v12 = p10:getIndicatorPosition()
	p9:setWorldPosition(v11, v12)
end
function AbstractFieldMissionHotspot.setWorldRadius(p13, p14)
	p13.worldRadius = p14
end
function AbstractFieldMissionHotspot.updateCircleSize(p15)
	local v16 = g_currentMission.hud:getIngameMap()
	local v17, v18 = v16.layout:getMapSize()
	local v19 = p15.worldRadius / v16.worldSizeX * v17
	local v20 = p15.worldRadius / v16.worldSizeZ * v18
	p15.circle:setDimension(v19, v20)
end
function AbstractFieldMissionHotspot.getWidth(p21)
	if p21.circle == nil then
		return 0
	end
	p21:updateCircleSize()
	return p21.circle.width
end
function AbstractFieldMissionHotspot.getHeight(p22)
	if p22.circle == nil then
		return 0
	end
	p22:updateCircleSize()
	return p22.circle.height
end
function AbstractFieldMissionHotspot.getDimension(p23)
	if p23.circle == nil then
		return 0, 0
	end
	p23:updateCircleSize()
	return p23.circle.width, p23.circle.height
end
function AbstractFieldMissionHotspot.setScale(_, _) end
function AbstractFieldMissionHotspot.getCategory(_)
	return MapHotspot.CATEGORY_MISSION
end
function AbstractFieldMissionHotspot.getIsPersistent(_)
	return false
end
function AbstractFieldMissionHotspot.getRenderLast(_)
	return false
end
function AbstractFieldMissionHotspot.render(p24, p25, p26, _, _)
	local v27 = p24.circle
	if v27 ~= nil then
		v27:setPosition(p25, p26)
		v27:setColor(nil, nil, nil, IngameMap.alpha)
		v27:render()
		local _ = p25 + v27.width * 0.5
		local _ = p26 + v27.height * 0.5
	end
end

CultivateMission = {}
CultivateMission.NAME = "cultivateMission"
local v_u_1 = Class(CultivateMission, AbstractFieldMission)
InitStaticObjectClass(CultivateMission, "CultivateMission")
function CultivateMission.registerXMLPaths(p2, p3)
	CultivateMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function CultivateMission.new(p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = g_i18n:getText("contract_field_cultivate_title")
	local v8 = g_i18n:getText("contract_field_cultivate_description")
	local v9 = AbstractFieldMission.new(p4, p5, v7, v8, p6 or v_u_1)
	v9.workAreaTypes = {
		[WorkAreaType.CULTIVATOR] = true
	}
	return v9
end
function CultivateMission.createModifier(p10)
	local v11, v12, v13 = g_currentMission.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
	local v14 = FieldGroundType.getValueByType(FieldGroundType.STUBBLE_TILLAGE)
	local v15 = FieldGroundType.getValueByType(FieldGroundType.CULTIVATED)
	p10.completionModifier = DensityMapModifier.new(v11, v12, v13, g_terrainNode)
	p10.completionFilter = DensityMapFilter.new(p10.completionModifier)
	p10.completionFilter:setValueCompareParams(DensityValueCompareType.BETWEEN, v14, v15)
end
function CultivateMission.getFieldFinishTask(p16)
	local v17 = p16.field:getFieldState()
	v17.fruitTypeIndex = FruitType.UNKNOWN
	v17.groundType = FieldGroundType.CULTIVATED
	return CultivateMission:superClass().getFieldFinishTask(p16)
end
function CultivateMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(CultivateMission.NAME).rewardPerHa
end
function CultivateMission.getMissionTypeName(_)
	return CultivateMission.NAME
end
function CultivateMission.validate(p18, p19)
	if CultivateMission:superClass().validate(p18, p19) then
		return (p18:getIsFinished() or CultivateMission.isAvailableForField(p18.field, p18)) and true or false
	else
		return false
	end
end
function CultivateMission.loadMapData(p20, p21, _)
	g_missionManager:getMissionTypeDataByName(CultivateMission.NAME).rewardPerHa = p20:getFloat(p21 .. "#rewardPerHa", 2300)
	return true
end
function CultivateMission.tryGenerateMission()
	if CultivateMission.canRun() then
		local v22 = g_fieldManager:getFieldForMission()
		if v22 == nil then
			return
		end
		if v22.currentMission ~= nil then
			return
		end
		if not CultivateMission.isAvailableForField(v22, nil) then
			return
		end
		local v23 = CultivateMission.new(true, g_client ~= nil)
		if v23:init(v22) then
			v23:setDefaultEndDate()
			return v23
		end
		v23:delete()
	end
	return nil
end
function CultivateMission.isAvailableForField(p24, p25)
	if p25 == nil then
		local v26 = p24:getFieldState()
		if not v26.isValid then
			return false
		end
		local v27 = v26.fruitTypeIndex
		if v27 == FruitType.UNKNOWN then
			return false
		end
		local v28 = v26.growthState
		local v29 = g_fruitTypeManager:getFruitTypeByIndex(v27)
		if v29:getIsCatchCrop() and v28 <= 1 then
			return false
		end
		if not (v29:getIsCut(v28) or v29:getIsWithered(v28)) then
			return false
		end
	end
	return true
end
function CultivateMission.canRun()
	local v30 = g_missionManager:getMissionTypeDataByName(CultivateMission.NAME)
	return v30.numInstances < v30.maxNumInstances
end
g_missionManager:registerMissionType(CultivateMission, CultivateMission.NAME, 3)

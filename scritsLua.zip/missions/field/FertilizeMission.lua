FertilizeMission = {}
FertilizeMission.NAME = "fertilizeMission"
local v_u_1 = Class(FertilizeMission, AbstractFieldMission)
InitStaticObjectClass(FertilizeMission, "FertilizeMission")
function FertilizeMission.registerXMLPaths(p2, p3)
	FertilizeMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function FertilizeMission.registerSavegameXMLPaths(p4, p5)
	FertilizeMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#targetSprayLevel", "Target spray level")
end
function FertilizeMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_fertilize_title")
	local v10 = g_i18n:getText("contract_field_fertilize_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.workAreaTypes = {
		[WorkAreaType.SPRAYER] = true
	}
	v11.validFertilizerFillTypes = {}
	v11.validFertilizerFillTypes[FillType.FERTILIZER] = true
	v11.validFertilizerFillTypes[FillType.LIQUIDFERTILIZER] = true
	v11.validFertilizerFillTypes[FillType.LIQUIDMANURE] = true
	v11.validFertilizerFillTypes[FillType.MANURE] = true
	v11.filLTypeTitle = g_fillTypeManager:getFillTypeTitleByIndex(FillType.FERTILIZER)
	v11.targetSprayLevel = nil
	return v11
end
function FertilizeMission.init(p12, p13, p14)
	p12.targetSprayLevel = p14
	return FertilizeMission:superClass().init(p12, p13)
end
function FertilizeMission.saveToXMLFile(p15, p16, p17)
	FertilizeMission:superClass().saveToXMLFile(p15, p16, p17)
	p16:setValue(p17 .. "#targetSprayLevel", p15.targetSprayLevel)
end
function FertilizeMission.loadFromXMLFile(p18, p19, p20)
	if not FertilizeMission:superClass().loadFromXMLFile(p18, p19, p20) then
		return false
	end
	p18.targetSprayLevel = p19:getValue(p20 .. "#targetSprayLevel")
	return true
end
function FertilizeMission.createModifier(p21)
	local v22, v23, v24 = g_currentMission.fieldGroundSystem:getDensityMapData(FieldDensityMap.SPRAY_LEVEL)
	p21.completionModifier = DensityMapModifier.new(v22, v23, v24, g_terrainNode)
	p21.completionFilter = DensityMapFilter.new(p21.completionModifier)
	p21.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, p21.targetSprayLevel)
end
function FertilizeMission.getFieldFinishTask(p25)
	p25.field:getFieldState().sprayLevel = p25.targetSprayLevel
	return FertilizeMission:superClass().getFieldFinishTask(p25)
end
function FertilizeMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(FertilizeMission.NAME).rewardPerHa
end
function FertilizeMission.calculateReimbursement(p26)
	FertilizeMission:superClass().calculateReimbursement(p26)
	local v27 = 0
	for _, v28 in pairs(p26.vehicles) do
		if v28.spec_fillUnit ~= nil then
			for v29, _ in pairs(v28:getFillUnits()) do
				local v30 = v28:getFillUnitFillType(v29)
				if p26.validFertilizerFillTypes[v30] ~= nil then
					v27 = v27 + v28:getFillUnitFillLevel(v29) * g_fillTypeManager:getFillTypeByIndex(v30).pricePerLiter
				end
			end
		end
	end
	p26.reimbursement = p26.reimbursement + v27 * AbstractMission.REIMBURSEMENT_FACTOR
end
function FertilizeMission.getMissionTypeName(_)
	return FertilizeMission.NAME
end
function FertilizeMission.validate(p31, p32)
	if FertilizeMission:superClass().validate(p31, p32) then
		return (p31:getIsFinished() or FertilizeMission.isAvailableForField(p31.field, p31)) and true or false
	else
		return false
	end
end
function FertilizeMission.loadMapData(p33, p34, _)
	g_missionManager:getMissionTypeDataByName(FertilizeMission.NAME).rewardPerHa = p33:getFloat(p34 .. "#rewardPerHa", 1500)
	return true
end
function FertilizeMission.tryGenerateMission()
	if FertilizeMission.canRun() then
		local v35 = g_fieldManager:getFieldForMission()
		if v35 == nil then
			return
		end
		if v35.currentMission ~= nil then
			return
		end
		if not FertilizeMission.isAvailableForField(v35, nil) then
			return
		end
		local v36 = v35:getFieldState().sprayLevel + 1
		local v37 = FertilizeMission.new(true, g_client ~= nil)
		if v37:init(v35, v36) then
			v37:setDefaultEndDate()
			return v37
		end
		v37:delete()
	end
	return nil
end
function FertilizeMission.isAvailableForField(p38, p39)
	if p39 == nil then
		local v40 = p38:getFieldState()
		if not v40.isValid then
			return false
		end
		if v40.sprayType ~= FieldSprayType.NONE then
			return false
		end
		local v41 = v40.fruitTypeIndex
		if v41 == FruitType.UNKNOWN then
			return false
		end
		if g_currentMission.fieldGroundSystem:getMaxValue(FieldDensityMap.SPRAY_LEVEL) <= v40.sprayLevel then
			return false
		end
		local v42 = v40.growthState
		if v42 ~= nil and v42 <= 1 then
			return false
		end
		local v43 = g_fruitTypeManager:getFruitTypeByIndex(v41)
		if v43:getIsCatchCrop() then
			return false
		end
		if v43:getIsHarvestable(v42) then
			return false
		end
	end
	local v44 = g_currentMission.environment
	return v44 == nil or v44.currentSeason ~= Season.WINTER
end
function FertilizeMission.canRun()
	local v45 = g_missionManager:getMissionTypeDataByName(FertilizeMission.NAME)
	if v45.numInstances >= v45.maxNumInstances then
		return false
	else
		return not g_currentMission.growthSystem:getIsGrowingInProgress()
	end
end
g_missionManager:registerMissionType(FertilizeMission, FertilizeMission.NAME, 3)

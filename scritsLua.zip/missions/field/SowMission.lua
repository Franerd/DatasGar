SowMission = {}
SowMission.NAME = "sowMission"
local v_u_1 = Class(SowMission, AbstractFieldMission)
InitStaticObjectClass(SowMission, "SowMission")
function SowMission.registerXMLPaths(p2, p3)
	SowMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function SowMission.registerSavegameXMLPaths(p4, p5)
	SowMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.STRING, p5 .. "#fruitType", "Name of the fruit type")
end
function SowMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_sow_title")
	local v10 = g_i18n:getText("contract_field_sow_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.workAreaTypes = {
		[WorkAreaType.SOWINGMACHINE] = true,
		[WorkAreaType.RIDGEMARKER] = true
	}
	v11.fruitTypeIndex = nil
	v11.fruitTypeTitle = nil
	v11.growthState = 1
	return v11
end
function SowMission.init(p12, p13, p14)
	p12.fruitTypeIndex = p14
	p12.fruitTypeTitle = g_fruitTypeManager:getFillTypeByFruitTypeIndex(p14).title
	return SowMission:superClass().init(p12, p13)
end
function SowMission.saveToXMLFile(p15, p16, p17)
	SowMission:superClass().saveToXMLFile(p15, p16, p17)
	local v18 = g_fruitTypeManager:getFruitTypeNameByIndex(p15.fruitTypeIndex)
	p16:setValue(p17 .. "#fruitType", v18)
end
function SowMission.loadFromXMLFile(p19, p20, p21)
	local v22 = p20:getValue(p21 .. "#fruitType")
	p19.fruitTypeIndex = g_fruitTypeManager:getFruitTypeIndexByName(v22)
	return SowMission:superClass().loadFromXMLFile(p19, p20, p21)
end
function SowMission.writeStream(p23, p24, p25)
	SowMission:superClass().writeStream(p23, p24, p25)
	streamWriteUIntN(p24, p23.fruitTypeIndex or 0, FruitTypeManager.SEND_NUM_BITS)
end
function SowMission.readStream(p26, p27, p28)
	SowMission:superClass().readStream(p26, p27, p28)
	p26.fruitTypeIndex = streamReadUIntN(p27, FruitTypeManager.SEND_NUM_BITS)
end
function SowMission.getFieldFinishTask(p29)
	local v30 = p29.field:getFieldState()
	v30.fruitTypeIndex = p29.fruitTypeIndex
	v30.growthState = p29.growthState
	v30.groundType = FieldGroundType.SOWN
	return SowMission:superClass().getFieldFinishTask(p29)
end
function SowMission.getVehicleVariant(p31)
	local v32 = p31.fruitTypeIndex
	return (v32 == FruitType.SUNFLOWER or v32 == FruitType.MAIZE) and "MAIZE" or (v32 == FruitType.SUGARBEET and "SUGARBEET" or (v32 == FruitType.POTATO and "POTATO" or (v32 == FruitType.COTTON and "COTTON" or (v32 == FruitType.SUGARCANE and "SUGARCANE" or ((v32 == FruitType.CARROT or (v32 == FruitType.PARSNIP or v32 == FruitType.BEETROOT)) and "VEGETABLES" or "GRAIN")))))
end
function SowMission.getVariant(p33)
	local v34 = p33.fruitTypeIndex
	return v34 == FruitType.BEETROOT and "BEETROOT" or (v34 == FruitType.CARROT and "CARROT" or (v34 == FruitType.MAIZE and "MAIZE" or (v34 == FruitType.COTTON and "COTTON" or (v34 == FruitType.GREENBEAN and "GREENBEAN" or (v34 == FruitType.PARSNIP and "PARSNIP" or (v34 == FruitType.PEA and "PEA" or (v34 == FruitType.POPLAR and "POPLAR" or (v34 == FruitType.POTATO and "POTATO" or (v34 == FruitType.RICE and "RICE" or (v34 == FruitType.RICELONGGRAIN and "RICELONGGRAIN" or (v34 == FruitType.SPINACH and "SPINACH" or (v34 == FruitType.SUGARCANE and "SUGARCANE" or (v34 == FruitType.SUGARBEET and "SUGARBEET" or (v34 == FruitType.SUNFLOWER and "SUNFLOWER" or "GRAIN"))))))))))))))
end
function SowMission.createModifier(p35)
	local v36 = g_fruitTypeManager:getFruitTypeByIndex(p35.fruitTypeIndex)
	if v36 ~= nil and v36.terrainDataPlaneId ~= nil then
		p35.completionModifier = DensityMapModifier.new(v36.terrainDataPlaneId, v36.startStateChannel, v36.numStateChannels, g_terrainNode)
		p35.completionFilter = DensityMapFilter.new(p35.completionModifier)
		p35.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, p35.growthState)
	end
end
function SowMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(SowMission.NAME).rewardPerHa
end
function SowMission.calculateReimbursement(p37)
	SowMission:superClass().calculateReimbursement(p37)
	local v38 = 0
	for _, v39 in pairs(p37.vehicles) do
		if v39.spec_fillUnit ~= nil then
			for v40, _ in pairs(v39:getFillUnits()) do
				local v41 = v39:getFillUnitFillType(v40)
				if v41 == FillType.SEEDS then
					v38 = v38 + v39:getFillUnitFillLevel(v40) * g_fillTypeManager:getFillTypeByIndex(v41).pricePerLiter
				end
			end
		end
	end
	local v42 = v38 + g_fruitTypeManager:getFruitTypeByIndex(p37.fruitTypeIndex).seedUsagePerSqm * 10000 * g_currentMission.economyManager:getCostPerLiter(FillType.SEEDS) * p37.field.areaHa
	p37.reimbursement = p37.reimbursement + v42 * AbstractMission.REIMBURSEMENT_FACTOR
end
function SowMission.getDetails(p43)
	local v44 = SowMission:superClass().getDetails(p43)
	local v45 = g_fruitTypeManager:getFruitTypeByIndex(p43.fruitTypeIndex)
	local v46 = {
		["title"] = g_i18n:getText("contract_details_sow_crop"),
		["value"] = v45.fillType.title
	}
	table.insert(v44, v46)
	return v44
end
function SowMission.getMissionTypeName(_)
	return SowMission.NAME
end
function SowMission.validate(p47, p48)
	if not p47:getWasStarted() then
		local v49 = g_fruitTypeManager:getFruitTypeByIndex(p47.fruitTypeIndex)
		if v49 == nil or not v49:getIsPlantableInPeriod(g_currentMission.missionInfo.growthMode, g_currentMission.environment.currentPeriod) then
			return false
		end
	end
	if SowMission:superClass().validate(p47, p48) then
		return (p47:getIsFinished() or SowMission.isAvailableForField(p47.field, p47)) and true or false
	else
		return false
	end
end
function SowMission.loadMapData(p50, p51, _)
	g_missionManager:getMissionTypeDataByName(SowMission.NAME).rewardPerHa = p50:getFloat(p51 .. "#rewardPerHa", 2000)
	return true
end
function SowMission.tryGenerateMission()
	if SowMission.canRun() then
		local v52 = g_fieldManager:getFieldForMission()
		if v52 == nil then
			return
		end
		if v52.currentMission ~= nil then
			return
		end
		if not SowMission.isAvailableForField(v52, nil) then
			return
		end
		local v53 = v52:getPlannedFruitTypeIndex()
		local v54 = SowMission.new(true, g_client ~= nil)
		if v54:init(v52, v53) then
			v54:setDefaultEndDate()
			return v54
		end
		v54:delete()
	end
	return nil
end
function SowMission.isAvailableForField(p55, p56)
	local v57 = p55:getFieldState()
	if not v57.isValid then
		return false
	end
	if v57.fruitTypeIndex ~= FruitType.UNKNOWN then
		return false
	end
	if p56 == nil then
		local v58 = p55:getPlannedFruitTypeIndex()
		if v58 == 0 then
			return
		end
		if not g_fruitTypeManager:getFruitTypeByIndex(v58):getIsPlantableInPeriod(g_currentMission.missionInfo.growthMode, g_currentMission.environment.currentPeriod) then
			return false
		end
	end
	return true
end
function SowMission.canRun()
	local v59 = g_missionManager:getMissionTypeDataByName(SowMission.NAME)
	return v59.numInstances < v59.maxNumInstances
end
g_missionManager:registerMissionType(SowMission, SowMission.NAME, 5)

HarvestMissionHotspot = {}
local v_u_1 = Class(HarvestMissionHotspot, MapHotspot)
function HarvestMissionHotspot.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = MapHotspot.new(p2 or v_u_1)
	local v4, v5 = getNormalizedScreenValues(50, 50)
	v3.width = v4
	v3.height = v5
	local v6 = Utils.getFilename("$dataS/menu/hud/hud_elements.png", HarvestMissionHotspot.MOD_DIRECTORY)
	local v7 = GuiUtils.getUVs({
		48,
		291,
		256,
		256
	}, { 1024, 1024 })
	v3.circle = Overlay.new(v6, 0, 0, v3.width, v3.height)
	v3.circle:setUVs(v7)
	v3.circle:setColor(0.5089, 0.016, 0.016, 1)
	v3.worldRadius = 50
	v3.forceNoRotation = true
	return v3
end
function HarvestMissionHotspot.delete(p8)
	HarvestMissionHotspot:superClass().delete(p8)
	if p8.circle ~= nil then
		p8.circle:delete()
		p8.circle = nil
	end
end
function HarvestMissionHotspot.setWorldRadius(p9, p10)
	p9.worldRadius = p10
end
function HarvestMissionHotspot.updateCircleSize(p11)
	local v12 = g_currentMission.hud:getIngameMap()
	local v13, v14 = v12.layout:getMapSize()
	local v15 = p11.worldRadius / v12.worldSizeX * v13
	local v16 = p11.worldRadius / v12.worldSizeZ * v14
	p11.circle:setDimension(v15, v16)
end
function HarvestMissionHotspot.getWidth(p17)
	if p17.circle == nil then
		return 0
	end
	p17:updateCircleSize()
	return p17.circle.width
end
function HarvestMissionHotspot.getHeight(p18)
	if p18.circle == nil then
		return 0
	end
	p18:updateCircleSize()
	return p18.circle.height
end
function HarvestMissionHotspot.getDimension(p19)
	if p19.circle == nil then
		return 0, 0
	end
	p19:updateCircleSize()
	return p19.circle.width, p19.circle.height
end
function HarvestMissionHotspot.setScale(_, _) end
function HarvestMissionHotspot.getCategory(_)
	return MapHotspot.CATEGORY_MISSION
end
function HarvestMissionHotspot.getIsPersistent(_)
	return false
end
function HarvestMissionHotspot.getRenderLast(_)
	return false
end
function HarvestMissionHotspot.render(p20, p21, p22, _, _)
	local v23 = p20.circle
	if v23 ~= nil then
		v23:setPosition(p21, p22)
		v23:setColor(nil, nil, nil, IngameMap.alpha)
		v23:render()
		local _ = p21 + v23.width * 0.5
		local _ = p22 + v23.height * 0.5
	end
end

BaleMission = {}
BaleMission.NAME = "baleMission"
BaleMission.THRESHOLD_LITERS = 1500
local v_u_1 = Class(BaleMission, AbstractFieldMission)
InitStaticObjectClass(BaleMission, "BaleMission")
function BaleMission.registerXMLPaths(p2, p3)
	BaleMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function BaleMission.registerSavegameXMLPaths(p4, p5)
	BaleMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.STRING, p5 .. "#fruitType", "Name of the bale fruit type")
	p4:register(XMLValueType.BOOL, p5 .. "#needRoundbaler", "If target bale type should be roundbale")
	p4:register(XMLValueType.FLOAT, p5 .. "#spawnedLiters", "Spawned windrow liters")
	p4:register(XMLValueType.INT, p5 .. "#swathSegmentIndex", "Current swath segment index")
	p4:register(XMLValueType.BOOL, p5 .. "#finishedSwathSpawning", "If swath spawning is finished")
	p4:register(XMLValueType.STRING, p5 .. ".createdBale(?)#uniqueId", "UniqueId of created bale")
end
function BaleMission.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = g_i18n:getText("contract_field_bale_title")
	local v10 = g_i18n:getText("contract_field_bale_description")
	local v11 = AbstractFieldMission.new(p6, p7, v9, v10, p8 or v_u_1)
	v11.workAreaTypes = {
		[WorkAreaType.BALER] = true
	}
	v11.finishedSwathSpawning = false
	v11.initializedSwathSpawning = false
	v11.needRoundbaler = false
	v11.spawnedLiters = 0
	v11.bales = {}
	v11.balesToLoadByUniqueId = {}
	return v11
end
function BaleMission.init(p12, p13, p14, p15)
	p12:setFruitType(p14)
	p12.needRoundbaler = p15
	if p15 then
		p12.description = g_i18n:getText("contract_field_bale_descriptionRound")
	end
	return BaleMission:superClass().init(p12, p13)
end
function BaleMission.getDetails(p16)
	local v17 = BaleMission:superClass().getDetails(p16)
	local v18
	if p16.needRoundbaler then
		v18 = g_i18n:getText("contract_details_bale_type_round")
	else
		v18 = g_i18n:getText("contract_details_bale_type_square")
	end
	local v19 = {
		["title"] = g_i18n:getText("contract_details_bale_type"),
		["value"] = v18
	}
	table.insert(v17, v19)
	return v17
end
function BaleMission.setFruitType(p20, p21)
	p20.fruitTypeIndex = p21
	p20.fruitTypeTitle = g_fruitTypeManager:getFillTypeByFruitTypeIndex(p21).title
	p20.windrowFillTypeIndex = g_fruitTypeManager:getWindrowFillTypeIndexByFruitTypeIndex(p20.fruitTypeIndex)
	if p20.fruitTypeIndex == FruitType.GRASS then
		p20.windrowFillTypeIndex = FillType.DRYGRASS_WINDROW
	end
end
function BaleMission.saveToXMLFile(p22, p23, p24)
	BaleMission:superClass().saveToXMLFile(p22, p23, p24)
	local v25 = g_fruitTypeManager:getFruitTypeNameByIndex(p22.fruitTypeIndex)
	p23:setValue(p24 .. "#fruitType", v25)
	p23:setValue(p24 .. "#needRoundbaler", p22.needRoundbaler)
	p23:setValue(p24 .. "#spawnedLiters", p22.spawnedLiters)
	if not p22.finishedSwathSpawning and p22.currentSwathSegmentIndex ~= nil then
		p23:setValue(p24 .. "#swathSegmentIndex", p22.currentSwathSegmentIndex)
	end
	p23:setValue(p24 .. "#finishedSwathSpawning", p22.finishedSwathSpawning)
	for v26, v27 in ipairs(p22.bales) do
		p23:setValue(string.format("%s.createdBale(%d)", p24, v26 - 1) .. "#uniqueId", v27:getUniqueId())
	end
end
function BaleMission.loadFromXMLFile(p28, p29, p30)
	local v31 = p29:getValue(p30 .. "#fruitType")
	p28:setFruitType((g_fruitTypeManager:getFruitTypeIndexByName(v31)))
	p28.needRoundbaler = p29:getValue(p30 .. "#needRoundbaler", p28.needRoundbaler)
	p28.spawnedLiters = p29:getValue(p30 .. "#spawnedLiters", p28.spawnedLiters)
	if p28.needRoundbaler then
		p28.description = g_i18n:getText("contract_field_bale_descriptionRound")
	end
	for _, v32 in p29:iterator(p30 .. ".createdBale") do
		local v33 = p29:getValue(v32 .. "#uniqueId")
		local v34 = p28.balesToLoadByUniqueId
		table.insert(v34, v33)
	end
	p28.currentSwathSegmentIndex = p29:getValue(p30 .. "#swathSegmentIndex", p28.currentSwathSegmentIndex)
	p28.finishedSwathSpawning = p29:getValue(p30 .. "#finishedSwathSpawning", p28.finishedSwathSpawning)
	if p28.finishedSwathSpawning then
		p28.initializedSwathSpawning = true
	end
	return BaleMission:superClass().loadFromXMLFile(p28, p29, p30)
end
function BaleMission.writeStream(p35, p36, p37)
	BaleMission:superClass().writeStream(p35, p36, p37)
	streamWriteUIntN(p36, p35.fruitTypeIndex or 0, FruitTypeManager.SEND_NUM_BITS)
	streamWriteBool(p36, p35.needRoundbaler)
end
function BaleMission.readStream(p38, p39, p40)
	BaleMission:superClass().readStream(p38, p39, p40)
	p38:setFruitType((streamReadUIntN(p39, FruitTypeManager.SEND_NUM_BITS)))
	p38.needRoundbaler = streamReadBool(p39)
end
function BaleMission.getIsPrepared(p41)
	if BaleMission:superClass().getIsPrepared(p41) then
		return p41.finishedSwathSpawning
	else
		return false
	end
end
function BaleMission.getFieldPreparingTask(p42)
	if p42.isServer then
		local v43 = g_fruitTypeManager:getFruitTypeByIndex(p42.fruitTypeIndex)
		local v44 = p42.field:getFieldState()
		v44.fruitTypeIndex = p42.fruitTypeIndex
		v44.growthState = v43.cutState
		v44.weedState = 0
		if v43.harvestGroundType ~= nil then
			v44.groundType = v43.harvestGroundType
		end
	end
	return BaleMission:superClass().getFieldPreparingTask(p42)
end
function BaleMission.getFieldFinishTask(p45)
	local v46 = BaleMission:superClass().getFieldFinishTask(p45)
	if v46 ~= nil then
		v46:clearHeight()
	end
	return v46
end
function BaleMission.finishField(p47)
	if p47.isServer then
		for _, v48 in ipairs(p47.bales) do
			v48:delete()
		end
		p47.bales = {}
	end
	BaleMission:superClass().finishField(p47)
end
function BaleMission.removeAccess(p49)
	if p49.isServer then
		for _, v50 in ipairs(p49.vehicles) do
			if v50.spec_baler ~= nil then
				v50.spec_baler.dropBalesOnDelete = false
			end
		end
	end
	BaleMission:superClass().removeAccess(p49)
end
function BaleMission.update(p_u_51, p52)
	if p_u_51.isServer and (p_u_51.status == MissionStatus.PREPARING and (p_u_51.fieldPreparingTask == nil or p_u_51.fieldPreparingTask:getIsFinished())) and not p_u_51.initializedSwathSpawning then
		local v53 = g_fruitTypeManager:getFruitTypeByIndex(p_u_51.fruitTypeIndex)
		local v54 = v53.windrowLiterPerSqm or v53.literPerSqm
		local v55 = p_u_51.field:getAreaHa()
		local v_u_56 = MathUtil.haToSqm(v55) * v54
		local v57 = v55 > 6 and 12 or 9
		local v58, v59 = p_u_51.field:getCenterOfFieldWorldPosition()
		local v60 = FieldCourseSettings.new()
		v60.implementWidth = v57
		v60.numHeadlands = 2
		local v_u_61 = 0
		local function v71(p62, p63, p64, p65, _, _, _, p66)
			-- upvalues: (ref) v_u_61, (copy) p_u_51, (copy) v_u_56
			v_u_61 = v_u_61 + 1
			if p_u_51.currentSwathSegmentIndex == nil or v_u_61 > p_u_51.currentSwathSegmentIndex then
				local v67 = MathUtil.vector2Length(p64 - p62, p65 - p63)
				local v68 = p_u_51.windrowFillTypeIndex
				local v69 = v67 * (v_u_56 / p66)
				local v70, _ = DensityMapHeightUtil.tipToGroundAroundLine(p_u_51, v69, v68, p62, 0, p63, p64, 0, p65, 0.5, 0.5, 0, false, nil, false, true)
				p_u_51.spawnedLiters = p_u_51.spawnedLiters + v70
				p_u_51.currentSwathSegmentIndex = v_u_61
			end
		end
		FieldCourseIterator.new(v58, v59, v60, v71, function()
			-- upvalues: (copy) p_u_51
			p_u_51.finishedSwathSpawning = true
		end)
		p_u_51.initializedSwathSpawning = true
	end
	if p_u_51.balesToLoadByUniqueId ~= nil then
		for _, v72 in ipairs(p_u_51.balesToLoadByUniqueId) do
			local v73 = g_currentMission.itemSystem:getItemByUniqueId(v72)
			if v73 ~= nil then
				local v74 = p_u_51.bales
				table.insert(v74, v73)
			end
		end
		p_u_51.balesToLoadByUniqueId = nil
	end
	BaleMission:superClass().update(p_u_51, p52)
end
function BaleMission.addBale(p75, p76)
	if p76 ~= nil and p76:getFillType() == p75.windrowFillTypeIndex then
		local v77 = p75.bales
		table.insert(v77, p76)
		p76:setOwnerFarmId(AccessHandler.NOBODY)
	end
end
function BaleMission.getFieldCompletion(p78)
	BaleMission:superClass().getFieldCompletion(p78)
	local v79 = 0
	local v80 = true
	for _, v81 in ipairs(p78.completionPartitions) do
		if not v81.wasCalculated then
			v80 = false
		end
		v79 = v79 + v81.sumPixels
	end
	local v82 = v79 * g_densityMapHeightManager:getMinValidLiterValue(p78.windrowFillTypeIndex)
	if v80 then
		local v83 = 1 - v82 / p78.spawnedLiters
		p78.fieldPercentageDone = math.clamp(v83, 0, 1)
	end
	return p78.fieldPercentageDone
end
function BaleMission.createModifier(p84)
	local v85 = g_densityMapHeightManager:getDensityMapHeightTypeByFillTypeIndex(p84.windrowFillTypeIndex)
	if v85 ~= nil then
		p84.completionModifier = DensityMapModifier.new(DensityMapHeightUtil.terrainDetailHeightId, DensityMapHeightUtil.heightFirstChannel, DensityMapHeightUtil.heightNumChannels)
		p84.completionFilter = DensityMapFilter.new(DensityMapHeightUtil.terrainDetailHeightId, DensityMapHeightUtil.typeFirstChannel, DensityMapHeightUtil.typeNumChannels)
		p84.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, v85.index)
	end
end
function BaleMission.getCompletion(p86)
	return p86:getFieldCompletion()
end
function BaleMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(BaleMission.NAME).rewardPerHa
end
function BaleMission.getMissionTypeName(_)
	return BaleMission.NAME
end
function BaleMission.validate(p87, p88)
	if BaleMission:superClass().validate(p87, p88) then
		return (p87:getIsFinished() or BaleMission.isAvailableForField(p87.field, p87)) and true or false
	else
		return false
	end
end
function BaleMission.getIsWorkAllowed(p89, p90, p91, p92, p93, p94)
	if not BaleMission:superClass().getIsWorkAllowed(p89, p90, p91, p92, p93, p94) then
		return false
	end
	local v95
	if p94 == nil or p94.getIsRoundBaler == nil then
		v95 = false
	else
		v95 = p94:getIsRoundBaler()
	end
	return v95 == p89.needRoundbaler
end
function BaleMission.getVehicleVariant(p96)
	return p96.needRoundbaler and "ROUNDBALER" or "SQUAREBALER"
end
function BaleMission.getVariant(p97)
	return p97.needRoundbaler and "ROUNDBALER" or "SQUAREBALER"
end
function BaleMission.loadMapData(p98, p99, _)
	g_missionManager:getMissionTypeDataByName(BaleMission.NAME).rewardPerHa = p98:getFloat(p99 .. "#rewardPerHa", 2200)
	return true
end
function BaleMission.tryGenerateMission()
	if BaleMission.canRun() then
		local v100 = g_fieldManager:getFieldForMission()
		if v100 == nil then
			return
		end
		if v100.currentMission ~= nil then
			return
		end
		if not BaleMission.isAvailableForField(v100, nil) then
			return
		end
		local v101 = v100:getFieldState()
		local v102 = math.random() > 0.5
		local v103 = BaleMission.new(true, g_client ~= nil)
		if v103:init(v100, v101.fruitTypeIndex, v102) then
			v103:setDefaultEndDate()
			return v103
		end
		v103:delete()
	end
	return nil
end
function BaleMission.isAvailableForField(p104, p105)
	if p105 == nil then
		local v106 = p104:getFieldState()
		if not v106.isValid then
			return false
		end
		local v107 = v106.fruitTypeIndex
		if v107 == FruitType.UNKNOWN then
			return false
		end
		local v108 = g_fruitTypeManager:getFruitTypeByIndex(v107)
		if not v108:getIsHarvestable(v106.growthState) then
			return false
		end
		if not v108.hasWindrow then
			return false
		end
		local v109 = g_fruitTypeManager:getWindrowFillTypeIndexByFruitTypeIndex(v108.index)
		if v109 ~= FillType.STRAW and v109 ~= FillType.DRYGRASS_WINDROW then
			return false
		end
	end
	local v110 = g_currentMission.environment
	return v110 == nil or v110.currentSeason ~= Season.WINTER
end
function BaleMission.canRun()
	local v111 = g_missionManager:getMissionTypeDataByName(BaleMission.NAME)
	return v111.numInstances < v111.maxNumInstances
end
g_missionManager:registerMissionType(BaleMission, BaleMission.NAME, 3)

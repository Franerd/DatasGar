PlowMission = {}
PlowMission.NAME = "plowMission"
local v_u_1 = Class(PlowMission, AbstractFieldMission)
InitStaticObjectClass(PlowMission, "PlowMission")
function PlowMission.registerXMLPaths(p2, p3)
	PlowMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
end
function PlowMission.new(p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = g_i18n:getText("contract_field_plow_title")
	local v8 = g_i18n:getText("contract_field_plow_description")
	local v9 = AbstractFieldMission.new(p4, p5, v7, v8, p6 or v_u_1)
	v9.workAreaTypes = {
		[WorkAreaType.PLOW] = true
	}
	return v9
end
function PlowMission.createModifier(p10)
	local v11, v12, v13 = g_currentMission.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
	local v14 = FieldGroundType.getValueByType(FieldGroundType.PLOWED)
	p10.completionModifier = DensityMapModifier.new(v11, v12, v13, g_terrainNode)
	p10.completionFilter = DensityMapFilter.new(p10.completionModifier)
	p10.completionFilter:setValueCompareParams(DensityValueCompareType.EQUAL, v14)
end
function PlowMission.getFieldFinishTask(p15)
	local v16 = p15.field:getFieldState()
	v16.fruitTypeIndex = FruitType.UNKNOWN
	v16.groundType = FieldGroundType.PLOWED
	return PlowMission:superClass().getFieldFinishTask(p15)
end
function PlowMission.getRewardPerHa(_)
	return g_missionManager:getMissionTypeDataByName(PlowMission.NAME).rewardPerHa
end
function PlowMission.getMissionTypeName(_)
	return PlowMission.NAME
end
function PlowMission.validate(p17, p18)
	if PlowMission:superClass().validate(p17, p18) then
		return (p17:getIsFinished() or PlowMission.isAvailableForField(p17.field, p17)) and true or false
	else
		return false
	end
end
function PlowMission.loadMapData(p19, p20, _)
	g_missionManager:getMissionTypeDataByName(PlowMission.NAME).rewardPerHa = p19:getFloat(p20 .. "#rewardPerHa", 2800)
	return true
end
function PlowMission.tryGenerateMission()
	if PlowMission.canRun() then
		local v21 = g_fieldManager:getFieldForMission()
		if v21 == nil then
			return
		end
		if v21.currentMission ~= nil then
			return
		end
		if not PlowMission.isAvailableForField(v21, nil) then
			return
		end
		local v22 = PlowMission.new(true, g_client ~= nil)
		if v22:init(v21) then
			v22:setDefaultEndDate()
			return v22
		end
		v22:delete()
	end
	return nil
end
function PlowMission.isAvailableForField(p23, p24)
	if p24 == nil then
		local v25 = p23:getFieldState()
		if not v25.isValid then
			return false
		end
		if g_currentMission.fieldGroundSystem:getMaxValue(FieldDensityMap.PLOW_LEVEL) <= v25.plowLevel then
			return false
		end
		local v26 = v25.fruitTypeIndex
		if v26 == FruitType.UNKNOWN then
			return false
		end
		local v27 = v25.growthState
		local v28 = g_fruitTypeManager:getFruitTypeByIndex(v26)
		if v28:getIsCatchCrop() and v27 <= 1 then
			return false
		end
		if not (v28:getIsCut(v27) or v28:getIsWithered(v27)) then
			return false
		end
	end
	return true
end
function PlowMission.canRun()
	local v29 = g_missionManager:getMissionTypeDataByName(PlowMission.NAME)
	return v29.numInstances < v29.maxNumInstances
end
g_missionManager:registerMissionType(PlowMission, PlowMission.NAME, 2)

HarvestMission = {}
source("dataS/scripts/missions/field/HarvestMissionHotspot.lua")
HarvestMission.NAME = "harvestMission"
HarvestMission.SUCCESS_FACTOR = 0.93
local v_u_1 = Class(HarvestMission, AbstractFieldMission)
InitStaticObjectClass(HarvestMission, "HarvestMission")
function HarvestMission.registerXMLPaths(p2, p3)
	HarvestMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#rewardPerHa", "Reward per ha")
	p2:register(XMLValueType.STRING, p3 .. ".fruitType#name", "Fruit type")
	p2:register(XMLValueType.INT, p3 .. ".fruitType#value", "Reward per ha")
	p2:register(XMLValueType.FLOAT, p3 .. "#failureCostFactor", "Failure cost factor")
	p2:register(XMLValueType.FLOAT, p3 .. "#failureCostOfTotal", "Failure cost of total")
end
function HarvestMission.registerSavegameXMLPaths(p4, p5)
	HarvestMission:superClass().registerSavegameXMLPaths(p4, p5)
	local v6 = string.format("%s.harvest", p5)
	p4:register(XMLValueType.STRING, v6 .. "#fruitType", "Name of the fruit type")
	p4:register(XMLValueType.FLOAT, v6 .. "#expectedLiters", "Expected liters")
	p4:register(XMLValueType.FLOAT, v6 .. "#depositedLiters", "Deposited liters")
	p4:register(XMLValueType.STRING, v6 .. "#sellingStationPlaceableUniqueId", "Unique id of the selling point")
	p4:register(XMLValueType.INT, v6 .. "#unloadingStationIndex", "Index of the unloading station")
end
function HarvestMission.new(p7, p8, p9)
	-- upvalues: (copy) v_u_1
	local v10 = g_i18n:getText("contract_field_harvest_title")
	local v11 = g_i18n:getText("contract_field_harvest_description")
	local v12 = AbstractFieldMission.new(p7, p8, v10, v11, p9 or v_u_1)
	v12.workAreaTypes = {
		[WorkAreaType.CUTTER] = true,
		[WorkAreaType.COMBINECHOPPER] = true,
		[WorkAreaType.COMBINESWATH] = true,
		[WorkAreaType.FRUITPREPARER] = true
	}
	v12.pendingSellingStationId = nil
	v12.sellingStation = nil
	v12.fillTypeIndex = nil
	v12.depositedLiters = 0
	v12.expectedLiters = 0
	v12.reimbursementPerHa = 0
	v12.lastSellChange = -1
	return v12
end
function HarvestMission.init(p13, p14, p15, p16)
	p13.fruitTypeIndex = p15
	p13.fillTypeIndex = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(p15)
	local v17 = HarvestMission:superClass().init(p13, p14)
	p13:setSellingStation(p16)
	return v17
end
function HarvestMission.onSavegameLoaded(p18)
	if p18.field:getFieldState().fruitTypeIndex == p18.fruitTypeIndex then
		local v19 = g_currentMission.placeableSystem:getPlaceableByUniqueId(p18.sellingStationPlaceableUniqueId)
		if v19 == nil then
			Logging.error("Selling station placeable with uniqueId \'%s\' not available for harvest mission", p18.sellingStationPlaceableUniqueId)
			g_missionManager:markMissionForDeletion(p18)
			return
		else
			local v20 = g_currentMission.storageSystem:getPlaceableUnloadingStation(v19, p18.unloadingStationIndex)
			if v20 == nil then
				Logging.error("Unable to retrieve unloadingStation %d for placeable %s for harvest mission", p18.unloadingStationIndex, v19.configFileName)
				g_missionManager:markMissionForDeletion(p18)
			else
				p18:setSellingStation(v20)
				if p18:getWasStarted() and not p18:getIsFinished() then
					v20.missions[p18] = p18
				end
				HarvestMission:superClass().onSavegameLoaded(p18)
			end
		end
	else
		local v21 = g_fruitTypeManager:getFruitTypeByIndex(p18.fruitTypeIndex)
		Logging.error("FruitType \'%s\' is not present on field \'%s\' for harvest mission", v21.name, p18.field:getName())
		g_missionManager:markMissionForDeletion(p18)
		return
	end
end
function HarvestMission.delete(p22)
	if p22.sellingStation ~= nil then
		p22.sellingStation.missions[p22] = nil
	end
	if p22.sellingStationMapHotspot ~= nil then
		table.removeElement(p22.mapHotspots, p22.sellingStationMapHotspot)
		g_currentMission:removeMapHotspot(p22.sellingStationMapHotspot)
		p22.sellingStationMapHotspot:delete()
		p22.sellingStationMapHotspot = nil
	end
	HarvestMission:superClass().delete(p22)
end
function HarvestMission.writeStream(p23, p24, p25)
	NetworkUtil.writeNodeObject(p24, p23.sellingStation)
	streamWriteUIntN(p24, p23.fillTypeIndex, FillTypeManager.SEND_NUM_BITS)
	HarvestMission:superClass().writeStream(p23, p24, p25)
end
function HarvestMission.readStream(p26, p27, p28)
	p26.pendingSellingStationId = NetworkUtil.readNodeObjectId(p27)
	p26.fillTypeIndex = streamReadUIntN(p27, FillTypeManager.SEND_NUM_BITS)
	HarvestMission:superClass().readStream(p26, p27, p28)
end
function HarvestMission.saveToXMLFile(p29, p30, p31)
	local v32 = string.format("%s.harvest", p31)
	p30:setValue(v32 .. "#fruitType", g_fruitTypeManager:getFruitTypeNameByIndex(p29.fruitTypeIndex))
	p30:setValue(v32 .. "#expectedLiters", p29.expectedLiters)
	p30:setValue(v32 .. "#depositedLiters", p29.depositedLiters)
	local v33 = p29.sellingStation.owningPlaceable
	if v33 == nil then
		local v34 = p29.sellingStation.getName and p29.sellingStation:getName() or "unknown"
		Logging.xmlWarning(p30, "Unable to retrieve placeable of sellingStation \'%s\' for saving harvest mission \'%s\' ", v34, p31)
		return
	else
		local v35 = g_currentMission.storageSystem:getPlaceableUnloadingStationIndex(v33, p29.sellingStation)
		if v35 == nil then
			local v36 = p29.sellingStation.getName and p29.sellingStation:getName() or (v33.getName and v33:getName() or "unknown")
			Logging.xmlWarning(p30, "Unable to retrieve unloading station index of sellingStation \'%s\' for saving harvest mission \'%s\' ", v36, p31)
		else
			p30:setValue(v32 .. "#sellingStationPlaceableUniqueId", v33:getUniqueId())
			p30:setValue(v32 .. "#unloadingStationIndex", v35)
			HarvestMission:superClass().saveToXMLFile(p29, p30, p31)
		end
	end
end
function HarvestMission.loadFromXMLFile(p37, p38, p39)
	if not HarvestMission:superClass().loadFromXMLFile(p37, p38, p39) then
		return false
	end
	local v40 = string.format("%s.harvest", p39)
	local v41 = p38:getValue(v40 .. "#fruitType")
	local v42 = g_fruitTypeManager:getFruitTypeByName(v41)
	if v42 == nil then
		Logging.xmlError(p38, "FruitType \'%s\' not defined", v41)
		return false
	end
	p37.fruitTypeIndex = v42.index
	p37.fillTypeIndex = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(p37.fruitTypeIndex)
	p37.expectedLiters = p38:getValue(v40 .. "#expectedLiters", p37.expectedLiters)
	p37.depositedLiters = p38:getValue(v40 .. "#depositedLiters", p37.depositedLiters)
	local v43 = p38:getValue(v40 .. "#sellingStationPlaceableUniqueId")
	if v43 == nil then
		Logging.xmlError(p38, "No sellingStationPlaceable uniqueId given for harvest mission at \'%s\'", v40)
		return false
	end
	local v44 = p38:getValue(v40 .. "#unloadingStationIndex")
	if v44 == nil then
		Logging.xmlError(p38, "No unloadting station index given for harvest mission at \'%s\'", v40)
		return false
	end
	p37.sellingStationPlaceableUniqueId = v43
	p37.unloadingStationIndex = v44
	return true
end
function HarvestMission.update(p45, p46)
	HarvestMission:superClass().update(p45, p46)
	if p45.pendingSellingStationId ~= nil then
		p45:tryToResolveSellingStation()
	end
	if p45.lastSellChange > 0 then
		p45.lastSellChange = p45.lastSellChange - 1
		if p45.lastSellChange == 0 then
			local v47 = p45.expectedLiters * AbstractMission.SUCCESS_FACTOR
			local v48 = p45.depositedLiters / v47 * 100
			local v49 = math.floor(v48)
			g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, string.format(g_i18n:getText("contract_field_harvest_progress_transporting_forField"), v49, p45.field.farmland:getId()))
		end
	end
end
function HarvestMission.createModifier(p50)
	local v51 = g_fruitTypeManager:getFruitTypeByIndex(p50.fruitTypeIndex)
	if v51 ~= nil and v51.terrainDataPlaneId ~= nil then
		local v52 = DensityMapModifier.new(v51.terrainDataPlaneId, v51.startStateChannel, v51.numStateChannels, g_terrainNode)
		local v53 = DensityMapFilter.new(v52)
		p50.completionModifier = DensityMapMultiModifier.new()
		for v54, _ in pairs(v51.cutStates) do
			v53:setValueCompareParams(DensityValueCompareType.EQUAL, v54)
			p50.completionModifier:addExecuteGet("cutState", v52, v53)
		end
	end
end
function HarvestMission.tryToResolveSellingStation(p55)
	if p55.pendingSellingStationId ~= nil and p55.sellingStation == nil then
		local v56 = NetworkUtil.getObject(p55.pendingSellingStationId)
		if v56 ~= nil then
			p55:setSellingStation(v56)
		end
	end
end
function HarvestMission.setSellingStation(p57, p58)
	if p58 ~= nil then
		p57.pendingSellingStationId = nil
		p57.sellingStation = p58
		local v59 = p58.owningPlaceable
		if v59 ~= nil and v59.getHotspot ~= nil then
			local v60 = v59:getHotspot()
			if v60 ~= nil then
				p57.sellingStationMapHotspot = HarvestMissionHotspot.new()
				p57.sellingStationMapHotspot:setWorldPosition(v60:getWorldPosition())
				table.addElement(p57.mapHotspots, p57.sellingStationMapHotspot)
				if p57.addSellingStationHotSpot then
					g_currentMission:addMapHotspot(p57.sellingStationMapHotspot)
				end
			end
		end
	end
end
function HarvestMission.addHotspots(p61)
	HarvestMission:superClass().addHotspots(p61)
	p61.addSellingStationHotSpot = true
	if p61.sellingStationMapHotspot ~= nil then
		g_currentMission:addMapHotspot(p61.sellingStationMapHotspot)
	end
end
function HarvestMission.removeHotspot(p62)
	HarvestMission:superClass().removeHotspot(p62)
	if p62.sellingStationMapHotspot ~= nil then
		g_currentMission:removeMapHotspot(p62.sellingStationMapHotspot)
	end
	p62.addSellingStationHotSpot = false
end
function HarvestMission.start(p63, p64)
	if p63.pendingSellingStationId ~= nil then
		p63:tryToResolveSellingStation()
	end
	if p63.sellingStation == nil then
		return false
	end
	p63.sellingStation.missions[p63] = p63
	return HarvestMission:superClass().start(p63, p64)
end
function HarvestMission.finishedPreparing(p65)
	HarvestMission:superClass().finishedPreparing(p65)
	p65.expectedLiters = p65:getMaxCutLiters()
end
function HarvestMission.finish(p66, p67)
	HarvestMission:superClass().finish(p66, p67)
	if p66.sellingStation ~= nil then
		p66.sellingStation.missions[p66] = nil
	end
end
function HarvestMission.getFieldFinishTask(p68)
	local v69 = g_fruitTypeManager:getFruitTypeByIndex(p68.fruitTypeIndex)
	local v70 = p68.field:getFieldState()
	v70.fruitTypeIndex = p68.fruitTypeIndex
	v70.growthState = v69.cutState
	return HarvestMission:superClass().getFieldFinishTask(p68)
end
function HarvestMission.getPartitionCompletion(p71, p72)
	p71:setPartitionRegion(p72)
	if p71.completionModifier == nil then
		return 0, 0, 0
	end
	p71.completionModifier:resetStats()
	local _, v73, _, v74 = p71.completionModifier:execute(nil)
	return 0, v73, v74
end
function HarvestMission.getCompletion(p75)
	local v76 = p75.depositedLiters / p75.expectedLiters / HarvestMission.SUCCESS_FACTOR
	local v77 = math.min(v76, 1)
	local v78 = p75:getFieldCompletion() / AbstractMission.SUCCESS_FACTOR
	local v79 = 0.8 * math.min(v78, 1) + 0.2 * v77
	return math.min(1, v79)
end
function HarvestMission.getVehicleVariant(p80)
	local v81 = p80.fruitTypeIndex
	return (v81 == FruitType.SUNFLOWER or v81 == FruitType.MAIZE) and "MAIZE" or (v81 == FruitType.SUGARBEET and "SUGARBEET" or (v81 == FruitType.POTATO and "POTATO" or (v81 == FruitType.COTTON and "COTTON" or (v81 == FruitType.SUGARCANE and "SUGARCANE" or (v81 == FruitType.PEA and "PEA" or (v81 == FruitType.SPINACH and "SPINACH" or (v81 == FruitType.GREENBEAN and "GREENBEAN" or ((v81 == FruitType.CARROT or (v81 == FruitType.PARSNIP or v81 == FruitType.BEETROOT)) and "VEGETABLES" or "GRAIN"))))))))
end
function HarvestMission.getVariant(p82)
	local v83 = p82.fruitTypeIndex
	return v83 == FruitType.BEETROOT and "BEETROOT" or (v83 == FruitType.CARROT and "CARROT" or (v83 == FruitType.MAIZE and "MAIZE" or (v83 == FruitType.COTTON and "COTTON" or (v83 == FruitType.GREENBEAN and "GREENBEAN" or (v83 == FruitType.PARSNIP and "PARSNIP" or (v83 == FruitType.PEA and "PEA" or (v83 == FruitType.POPLAR and "POPLAR" or (v83 == FruitType.POTATO and "POTATO" or (v83 == FruitType.RICE and "RICE" or (v83 == FruitType.RICELONGGRAIN and "RICELONGGRAIN" or (v83 == FruitType.SPINACH and "SPINACH" or (v83 == FruitType.SUGARCANE and "SUGARCANE" or (v83 == FruitType.SUGARBEET and "SUGARBEET" or (v83 == FruitType.SUNFLOWER and "SUNFLOWER" or "GRAIN"))))))))))))))
end
function HarvestMission.getDetails(p84)
	local v85 = HarvestMission:superClass().getDetails(p84)
	local v86 = nil
	if p84.pendingSellingStationId ~= nil then
		p84:tryToResolveSellingStation()
	end
	if p84.sellingStation ~= nil then
		v86 = p84.sellingStation:getName()
	end
	if v86 ~= nil then
		local v87 = {
			["title"] = g_i18n:getText("contract_details_harvesting_sellingStation"),
			["value"] = v86
		}
		table.insert(v85, v87)
	end
	local v88 = {
		["title"] = g_i18n:getText("contract_details_harvesting_crop"),
		["value"] = g_fillTypeManager:getFillTypeTitleByIndex(p84.fillTypeIndex)
	}
	table.insert(v85, v88)
	return v85
end
function HarvestMission.getExtraProgressText(p89)
	if p89.completion < 0.1 then
		return ""
	end
	local v90 = "Unknown"
	if p89.pendingSellingStationId ~= nil then
		p89:tryToResolveSellingStation()
	end
	if p89.sellingStation ~= nil then
		v90 = p89.sellingStation:getName()
	end
	return string.format(g_i18n:getText("contract_field_harvest_nextUnloadDesc"), g_fillTypeManager:getFillTypeTitleByIndex(p89.fillTypeIndex), v90)
end
function HarvestMission.fillSold(p91, p92)
	local v93 = p91.depositedLiters + p92
	local v94 = p91.expectedLiters
	p91.depositedLiters = math.min(v93, v94)
	if p91.expectedLiters * AbstractMission.SUCCESS_FACTOR <= p91.depositedLiters then
		p91.sellingStation.missions[p91] = nil
	end
	p91.lastSellChange = 30
end
function HarvestMission.getRewardPerHa(p95)
	local v96 = g_missionManager:getMissionTypeDataByName(HarvestMission.NAME)
	return v96.rewardPerFruitHa[p95.fruitTypeIndex] or v96.rewardPerHa
end
function HarvestMission.getStealingCosts(p97)
	if p97.finishState ~= MissionFinishState.SUCCESS and p97.isServer then
		local v98 = g_missionManager:getMissionTypeDataByName(HarvestMission.NAME)
		local v99 = g_fruitTypeManager:getFruitTypeByIndex(p97.fruitTypeIndex).fillType.index
		local v100 = p97.expectedLiters * p97:getFieldCompletion()
		for _, v101 in pairs(p97.vehicles) do
			if v101.spec_fillUnit ~= nil then
				for v102, _ in pairs(v101:getFillUnits()) do
					if v101:getFillUnitFillType(v102) == p97.fillType then
						v100 = v100 - v101:getFillUnitFillLevel(v102)
					end
				end
			end
		end
		local v103 = v100 - p97.depositedLiters
		if v100 * v98.failureCostFactor < v103 then
			local _, v104 = HarvestMission.getSellingStationWithHighestPrice(v99)
			return v103 * v98.failureCostOfTotal * v104
		end
	end
	return 0
end
function HarvestMission.getMaxCutLiters(p105)
	local v106 = p105.field:getFieldState()
	local v107 = v106.fruitTypeIndex
	g_fruitTypeManager:getFruitTypeByIndex(v107)
	local v108 = v106:getHarvestScaleMultiplier()
	local v109 = p105.field:getAreaHa() * v108
	local v110 = MathUtil.haToSqm(v109) / g_currentMission:getFruitPixelsToSqm()
	return g_fruitTypeManager:getFruitTypeAreaLiters(v107, v110, false)
end
function HarvestMission.getMissionTypeName(_)
	return HarvestMission.NAME
end
function HarvestMission.validate(p111, p112)
	if HarvestMission:superClass().validate(p111, p112) then
		return (p111:getIsFinished() or HarvestMission.isAvailableForField(p111.field, p111)) and true or false
	else
		return false
	end
end
function HarvestMission.loadMapData(p_u_113, p114, _)
	local v_u_115 = g_missionManager:getMissionTypeDataByName(HarvestMission.NAME)
	v_u_115.rewardPerHa = p_u_113:getFloat(p114 .. ".rewardPerHa", 2500)
	v_u_115.rewardPerFruitHa = {}
	p_u_113:iterate(p114 .. ".fruitType", function(_, p116)
		-- upvalues: (copy) p_u_113, (copy) v_u_115
		local v117 = p_u_113:getString(p116 .. "#name")
		local v118 = p_u_113:getFloat(p116 .. "#value", v_u_115.rewardPerHa)
		local v119 = g_fruitTypeManager:getFruitTypeIndexByName(v117)
		if v119 == nil then
			Logging.xmlWarning(p_u_113, "Harvestmission rewardPerHa fruitType \'%s\' is not defined for \'%s\'", v117, p116)
		else
			v_u_115.rewardPerFruitHa[v119] = v118
		end
	end)
	v_u_115.failureCostFactor = p_u_113:getFloat(p114 .. "#failureCostFactor", 0.1)
	v_u_115.failureCostOfTotal = p_u_113:getFloat(p114 .. "#failureCostOfTotal", 0.95)
	return true
end
function HarvestMission.tryGenerateMission()
	if HarvestMission.canRun() then
		local v120 = g_fieldManager:getFieldForMission()
		if v120 == nil then
			return
		end
		if v120.currentMission ~= nil then
			return
		end
		if not HarvestMission.isAvailableForField(v120, nil) then
			return
		end
		local v121 = v120:getFieldState().fruitTypeIndex
		local v122 = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v121)
		local v123, _ = HarvestMission.getSellingStationWithHighestPrice(v122)
		if not HarvestMission.isAvailableForSellingStation(v123) then
			return
		end
		local v124 = HarvestMission.new(true, g_client ~= nil)
		if v124:init(v120, v121, v123) then
			v124:setDefaultEndDate()
			return v124
		end
		v124:delete()
	end
	return nil
end
function HarvestMission.getSellingStationWithHighestPrice(p125)
	local v126 = 0
	local v127 = nil
	for _, v128 in pairs(g_currentMission.storageSystem:getUnloadingStations()) do
		if v128.owningPlaceable ~= nil and (v128.isSellingPoint and (v128.allowMissions and v128.acceptedFillTypes[p125])) then
			local v129 = v128:getEffectiveFillTypePrice(p125)
			if v126 < v129 then
				v127 = v128
				v126 = v129
			end
		end
	end
	return v127, v126
end
function HarvestMission.isAvailableForSellingStation(p130)
	return p130 ~= nil
end
function HarvestMission.isAvailableForField(p131, p132)
	if p132 == nil then
		local v133 = p131:getFieldState()
		if not v133.isValid then
			return false
		end
		local v134 = v133.fruitTypeIndex
		if v134 == FruitType.UNKNOWN then
			return false
		end
		local v135 = g_fruitTypeManager:getFruitTypeByIndex(v134)
		if v135:getIsCatchCrop() then
			return false
		end
		if not v135:getIsHarvestReady(v133.growthState) then
			return false
		end
	end
	return true
end
function HarvestMission.canRun()
	local v136 = g_missionManager:getMissionTypeDataByName(HarvestMission.NAME)
	if v136.numInstances >= v136.maxNumInstances then
		return false
	else
		return not g_currentMission.growthSystem:getIsGrowingInProgress()
	end
end
g_missionManager:registerMissionType(HarvestMission, HarvestMission.NAME, 10)

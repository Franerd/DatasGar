MissionStartEvent = {}
local v_u_1 = Class(MissionStartEvent, Event)
InitStaticEventClass(MissionStartEvent, "MissionStartEvent")
function MissionStartEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function MissionStartEvent.new(p2, p3, p4)
	local v5 = MissionStartEvent.emptyNew()
	v5.mission = p2
	v5.farmId = p3
	v5.spawnVehicles = p4 or false
	return v5
end
function MissionStartEvent.newServerToClient(p6, p7)
	local v8 = MissionStartEvent.emptyNew()
	v8.startState = p6
	v8.spawnVehicles = p7 or false
	return v8
end
function MissionStartEvent.writeStream(p9, p10, p11)
	if p11:getIsServer() then
		NetworkUtil.writeNodeObject(p10, p9.mission)
		streamWriteUIntN(p10, p9.farmId, FarmManager.FARM_ID_SEND_NUM_BITS)
		streamWriteBool(p10, p9.spawnVehicles)
	else
		MissionStartState.writeStream(p10, p9.startState)
		streamWriteBool(p10, p9.spawnVehicles)
	end
end
function MissionStartEvent.readStream(p12, p13, p14)
	if p14:getIsServer() then
		p12.startState = MissionStartState.readStream(p13)
		p12.spawnVehicles = streamReadBool(p13)
	else
		p12.mission = NetworkUtil.readNodeObject(p13)
		p12.farmId = streamReadUIntN(p13, FarmManager.FARM_ID_SEND_NUM_BITS)
		p12.spawnVehicles = streamReadBool(p13)
	end
	p12:run(p14)
end
function MissionStartEvent.run(p15, p16)
	if p16:getIsServer() then
		g_messageCenter:publish(MissionStartEvent, p15.startState, p15.spawnVehicles)
		return
	else
		local v17 = g_currentMission
		local v18 = v17.userManager:getUserIdByConnection(p16)
		if v17:getHasPlayerPermission("manageContracts", p16, g_farmManager:getFarmByUserId(v18).farmId) then
			local v19 = g_missionManager:startMission(p15.mission, p15.farmId, p15.spawnVehicles)
			p16:sendEvent(MissionStartEvent.newServerToClient(v19, p15.spawnVehicles))
		else
			p16:sendEvent(MissionStartEvent.newServerToClient(MissionStartState.NO_PERMISSION, p15.spawnVehicles))
		end
	end
end

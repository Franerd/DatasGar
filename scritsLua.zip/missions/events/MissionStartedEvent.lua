MissionStartedEvent = {}
local v_u_1 = Class(MissionStartedEvent, Event)
InitStaticEventClass(MissionStartedEvent, "MissionStartedEvent")
function MissionStartedEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function MissionStartedEvent.new(p2)
	local v3 = MissionStartedEvent.emptyNew()
	v3.mission = p2
	return v3
end
function MissionStartedEvent.writeStream(p4, p5, p6)
	if not p6:getIsServer() then
		NetworkUtil.writeNodeObject(p5, p4.mission)
		MissionStatus.writeStream(p5, p4.mission.status)
		streamWriteUIntN(p5, p4.mission.farmId, FarmManager.FARM_ID_SEND_NUM_BITS)
		streamWriteInt32(p5, p4.mission.activeMissionId)
	end
end
function MissionStartedEvent.readStream(p7, p8, p9)
	if p9:getIsServer() then
		p7.mission = NetworkUtil.readNodeObject(p8)
		p7.mission.status = MissionStatus.readStream(p8)
		p7.mission.farmId = streamReadUIntN(p8, FarmManager.FARM_ID_SEND_NUM_BITS)
		p7.mission.activeMissionId = streamReadInt32(p8)
	end
	p7:run(p9)
end
function MissionStartedEvent.run(p10, p11)
	if p11:getIsServer() then
		p10.mission:started()
		g_messageCenter:publish(MissionStartedEvent, p10.mission)
	end
end

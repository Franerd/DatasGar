MissionFinishedEvent = {}
local v_u_1 = Class(MissionFinishedEvent, Event)
InitStaticEventClass(MissionFinishedEvent, "MissionFinishedEvent")
function MissionFinishedEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function MissionFinishedEvent.new(p2, p3, p4)
	local v5 = MissionFinishedEvent.emptyNew()
	v5.mission = p2
	v5.finishState = p3
	v5.stealingCost = p4
	return v5
end
function MissionFinishedEvent.writeStream(p6, p7, _)
	NetworkUtil.writeNodeObject(p7, p6.mission)
	MissionFinishState.writeStream(p7, p6.finishState)
	streamWriteFloat32(p7, p6.stealingCost)
end
function MissionFinishedEvent.readStream(p8, p9, p10)
	p8.mission = NetworkUtil.readNodeObject(p9)
	p8.finishState = MissionFinishState.readStream(p9)
	p8.stealingCost = streamReadFloat32(p9)
	p8:run(p10)
end
function MissionFinishedEvent.run(p11, p12)
	if p12:getIsServer() then
		p11.mission.stealingCost = p11.stealingCost
		p11.mission:finish(p11.finishState)
	end
end

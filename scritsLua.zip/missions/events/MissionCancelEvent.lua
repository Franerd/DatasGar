MissionCancelEvent = {}
local v_u_1 = Class(MissionCancelEvent, Event)
InitStaticEventClass(MissionCancelEvent, "MissionCancelEvent")
function MissionCancelEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function MissionCancelEvent.new(p2)
	local v3 = MissionCancelEvent.emptyNew()
	v3.mission = p2
	return v3
end
function MissionCancelEvent.newServerToClient(p4)
	local v5 = MissionCancelEvent.emptyNew()
	v5.success = p4
	return v5
end
function MissionCancelEvent.writeStream(p6, p7, p8)
	if p8:getIsServer() then
		NetworkUtil.writeNodeObject(p7, p6.mission)
	else
		streamWriteBool(p7, p6.success)
	end
end
function MissionCancelEvent.readStream(p9, p10, p11)
	if p11:getIsServer() then
		p9.success = streamReadBool(p10)
	else
		p9.mission = NetworkUtil.readNodeObject(p10)
	end
	p9:run(p11)
end
function MissionCancelEvent.run(p12, p13)
	if p13:getIsServer() then
		g_messageCenter:publish(MissionCancelEvent, p12.success)
		return
	else
		local v14 = p12.mission
		if v14 == nil then
			p13:sendEvent(MissionCancelEvent.newServerToClient(false))
		else
			local v15 = g_currentMission
			local v16 = v15.userManager
			local v17 = v16:getUserIdByConnection(p13)
			local v18 = g_farmManager:getFarmByUserId(v17)
			local v19 = p13:getIsLocal() or v16:getIsConnectionMasterUser(p13)
			local v20
			if v15:getHasPlayerPermission("manageContracts", p13, v18.farmId) and (v14.farmId == v18.farmId or v19) then
				v20 = g_missionManager:cancelMission(v14)
			else
				v20 = false
			end
			p13:sendEvent(MissionCancelEvent.newServerToClient(v20))
		end
	end
end

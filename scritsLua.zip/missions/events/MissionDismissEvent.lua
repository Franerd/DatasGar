MissionDismissEvent = {}
local v_u_1 = Class(MissionDismissEvent, Event)
InitStaticEventClass(MissionDismissEvent, "MissionDismissEvent")
function MissionDismissEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function MissionDismissEvent.new(p2)
	local v3 = MissionDismissEvent.emptyNew()
	v3.mission = p2
	return v3
end
function MissionDismissEvent.newServerToClient(p4, p5)
	local v6 = MissionDismissEvent.emptyNew()
	v6.missionObjectId = p4
	v6.success = p5
	return v6
end
function MissionDismissEvent.writeStream(p7, p8, p9)
	if p9:getIsServer() then
		NetworkUtil.writeNodeObject(p8, p7.mission)
	else
		NetworkUtil.writeNodeObjectId(p8, p7.missionObjectId)
		streamWriteBool(p8, p7.success)
	end
end
function MissionDismissEvent.readStream(p10, p11, p12)
	if p12:getIsServer() then
		p10.missionObjectId = NetworkUtil.readNodeObjectId(p11)
		p10.success = streamReadBool(p11)
	else
		p10.mission = NetworkUtil.readNodeObject(p11)
	end
	p10:run(p12)
end
function MissionDismissEvent.run(p13, p14)
	if p14:getIsServer() then
		local v15 = NetworkUtil.getObject(p13.missionObjectId)
		if v15 ~= nil then
			g_missionManager:removeMission(v15)
		end
		g_messageCenter:publish(MissionDismissEvent, p13.success)
		return
	else
		local v16 = p13.mission
		if v16 ~= nil then
			local v17 = g_currentMission
			local v18 = v17.userManager
			local v19 = v18:getUserIdByConnection(p14)
			local v20 = g_farmManager:getFarmByUserId(v19)
			local v21 = p14:getIsLocal() or v18:getIsConnectionMasterUser(p14)
			local v22 = NetworkUtil.getObjectId(v16)
			local v23
			if v17:getHasPlayerPermission("manageContracts", p14, v20.farmId) and (p13.mission.farmId == v20.farmId or v21) then
				v23 = g_missionManager:dismissMission(p13.mission)
			else
				v23 = false
			end
			p14:sendEvent(MissionDismissEvent.newServerToClient(v22, v23))
		end
	end
end

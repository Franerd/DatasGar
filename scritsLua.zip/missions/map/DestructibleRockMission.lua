DestructibleRockMission = {}
source("dataS/scripts/missions/map/DestructibleRockMissionHotspot.lua")
source("dataS/scripts/missions/map/WrongRockDestroyedEvent.lua")
DestructibleRockMission.COLLISION_MASK = CollisionFlag.STATIC_OBJECT
DestructibleRockMission.NAME = "destructibleRockMission"
local v_u_1 = Class(DestructibleRockMission, AbstractMission)
InitStaticObjectClass(DestructibleRockMission, "DestructibleRockMission")
function DestructibleRockMission.registerXMLPaths(p2, p3)
	DestructibleRockMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#minNumRocks", "Min number of rocks")
	p2:register(XMLValueType.INT, p3 .. "#maxNumRocks", "Min number of rocks")
	p2:register(XMLValueType.INT, p3 .. "#maxNumInstances", "Max number of instances")
	p2:register(XMLValueType.INT, p3 .. "#rewardPerRock", "Reward per tree")
	p2:register(XMLValueType.INT, p3 .. "#penaltyPerRock", "Penalty per tree")
	p2:register(XMLValueType.STRING, p3 .. ".spots#filename", "Filename to rock spots")
	p2:register(XMLValueType.STRING, p3 .. ".marker#filename", "Filename to rock marker")
end
function DestructibleRockMission.registerSavegameXMLPaths(p4, p5)
	DestructibleRockMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#spotIndex", "Spot index")
	p4:register(XMLValueType.INT, p5 .. "#numRocksDestroyed", "Number of destroyed rocks")
	p4:register(XMLValueType.INT, p5 .. ".destructible(?)#groupId", "Rock groupd id")
	p4:register(XMLValueType.INT, p5 .. ".destructible(?)#index", "Rock index")
	p4:register(XMLValueType.BOOL, p5 .. ".destructible(?)#isPartOfMission", "Rock is part of mission")
end
function DestructibleRockMission.registerMetaXMLPaths(p6, p7)
	DestructibleRockMission:superClass().registerMetaXMLPaths(p6, p7)
	p6:register(XMLValueType.INT, p7 .. "#nextDay", "Earliest day a new mission can spawn")
end
function DestructibleRockMission.new(p8, p9, p10)
	-- upvalues: (copy) v_u_1
	local v11 = g_i18n:getText("contract_map_destructibleRock_title")
	local v12 = g_i18n:getText("contract_map_destructibleRock_description")
	local v13 = AbstractMission.new(p8, p9, v11, v12, p10 or v_u_1)
	v13.spot = nil
	v13.rocks = {}
	v13.rocksKeys = {}
	v13.rocksAll = {}
	v13.rocksAllKeys = {}
	v13.rockToMarker = {}
	v13.markerRootNode = nil
	v13.numRocksDestroyed = 0
	v13.wronglyDestroyedRocksPenalty = 0
	v13.mapHotspot = nil
	v13.isHotspotAdded = false
	g_currentMission.destructibleMapObjectSystem:registerDestructibleDestroyedListener(v13, v13.onRockDestroyed)
	local v14 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	table.addElement(v14.activeMissions, v13)
	return v13
end
function DestructibleRockMission.init(p15, p16, p17)
	local v18 = DestructibleRockMission:superClass().init(p15)
	if p16 == nil then
		return false
	end
	p15:setSpot(p16)
	local v19 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	for _, v20 in ipairs(p17) do
		local v21 = #p15.rocks >= v19.maxNumRocks
		local v22 = #p15.rocks >= v19.minNumRocks and not v21 and true or false
		if v22 then
			v22 = Utils.getCoinToss()
		end
		p15:addDestructible(v20, v22)
	end
	local v23 = v19.rewardPerRock
	p15.reward = #p15.rocks * v23
	return v18
end
function DestructibleRockMission.addDestructible(p24, p25, p26)
	if p26 then
		local v27 = p24.rocks
		table.insert(v27, p25)
		p24.rocksKeys[p25] = true
	end
	local v28 = p24.rocksAll
	table.insert(v28, p25)
	p24.rocksAllKeys[p25] = true
end
function DestructibleRockMission.setSpot(p29, p30)
	p29.spot = p30
	p30.isInUse = true
	p29.farmlandId = p30.farmlandId
	if p29.mapHotspot == nil then
		p29.mapHotspot = DestructibleRockMissionHotspot.new()
	end
	local v31 = p29.spot.x
	local v32 = p29.spot.z
	local v33 = p29.spot.radius
	p29.mapHotspot:setWorldPosition(v31, v32)
	p29.mapHotspot:setWorldRadius(v33 + 3)
	p29.mapHotspots = { p29.mapHotspot }
end
function DestructibleRockMission.delete(p34)
	DestructibleRockMission:superClass().delete(p34)
	local v35 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	if v35 ~= nil then
		table.removeElement(v35.activeMissions, p34)
		if p34.spot ~= nil then
			v35.spotsDisabled[p34.spot] = nil
		end
	end
	p34:removeHotspot()
	for _, v36 in ipairs(p34.rocksAll) do
		g_currentMission.destructibleMapObjectSystem:restoreDestructible(v36)
	end
	for _, v37 in pairs(p34.rockToMarker) do
		delete(v37)
	end
	p34.rockToMarker = nil
	if p34.markerRootNode ~= nil then
		delete(p34.markerRootNode)
		p34.markerRootNode = nil
	end
	g_currentMission.destructibleMapObjectSystem:unregisterDestructibleDestroyedListener(p34)
	if p34.spot ~= nil then
		p34.spot.isInUse = false
		p34.spot = nil
	end
	if p34.mapHotspot ~= nil then
		p34.mapHotspot:delete()
		p34.mapHotspot = nil
	end
	p34.mapHotspots = nil
end
function DestructibleRockMission.saveToXMLFile(p38, p39, p40)
	DestructibleRockMission:superClass().saveToXMLFile(p38, p39, p40)
	p39:setValue(p40 .. "#spotIndex", p38.spot.index)
	p39:setValue(p40 .. "#numRocksDestroyed", p38.numRocksDestroyed)
	for v41, v42 in ipairs(p38.rocksAll) do
		local v43 = string.format("%s.destructible(%d)", p40, v41 - 1)
		local v44, v45 = g_currentMission.destructibleMapObjectSystem:getGroupAndIndexForDestructible(v42)
		p39:setValue(v43 .. "#groupId", v44.groupId)
		p39:setValue(v43 .. "#index", v45)
		if p38.rocksKeys[v42] == nil then
			p39:setValue(v43 .. "#isPartOfMission", false)
		end
	end
end
function DestructibleRockMission.loadFromXMLFile(p46, p47, p48)
	DestructibleRockMission:superClass().loadFromXMLFile(p46, p47, p48)
	local v49 = p47:getValue(p48 .. "#spotIndex") or 0
	local v50 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME).spots[v49]
	if v50 == nil then
		return false
	end
	p46:setSpot(v50)
	p46.numRocksDestroyed = p47:getValue(p48 .. "#numRocksDestroyed")
	for _, v51 in p47:iterator(p48 .. ".destructible") do
		local v52 = p47:getValue(v51 .. "#groupId")
		local v53 = p47:getValue(v51 .. "#index")
		local v54 = p47:getValue(v51 .. "#isPartOfMission", true)
		local v55 = g_currentMission.destructibleMapObjectSystem:getGroupRootById(v52)
		p46:addDestructible(getChildAt(v55, v53), v54)
	end
	return true
end
function DestructibleRockMission.writeStream(p56, p57, p58)
	DestructibleRockMission:superClass().writeStream(p56, p57, p58)
	streamWriteUInt8(p57, p56.spot.index)
	streamWriteUInt8(p57, p56.numRocksDestroyed)
	streamWriteUInt8(p57, #p56.rocksAll)
	for _, v59 in ipairs(p56.rocksAll) do
		local v60, v61 = g_currentMission.destructibleMapObjectSystem:getGroupAndIndexForDestructible(v59)
		streamWriteUIntN(p57, v60.groupId, DestructibleMapObjectSystem.GROUP_ID_NUM_BITS)
		streamWriteUIntN(p57, v61, DestructibleMapObjectSystem.CHILD_INDEX_NUM_BITS)
		streamWriteBool(p57, p56.rocksKeys[v59] ~= nil)
	end
end
function DestructibleRockMission.readStream(p62, p63, p64)
	DestructibleRockMission:superClass().readStream(p62, p63, p64)
	local v65 = streamReadUInt8(p63)
	p62:setSpot(g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME).spots[v65])
	p62.numRocksDestroyed = streamReadUInt8(p63)
	for _ = 1, streamReadUInt8(p63) do
		local v66 = streamReadUIntN(p63, DestructibleMapObjectSystem.GROUP_ID_NUM_BITS)
		local v67 = streamReadUIntN(p63, DestructibleMapObjectSystem.CHILD_INDEX_NUM_BITS)
		local v68 = streamReadBool(p63)
		local v69 = g_currentMission.destructibleMapObjectSystem:getGroupRootById(v66)
		p62:addDestructible(getChildAt(v69, v67), v68)
	end
end
function DestructibleRockMission.readUpdateStream(p70, p71, p72, p73)
	DestructibleRockMission:superClass().readUpdateStream(p70, p71, p72, p73)
	p70.numRocksDestroyed = streamReadUInt8(p71)
end
function DestructibleRockMission.writeUpdateStream(p74, p75, p76, p77)
	DestructibleRockMission:superClass().writeUpdateStream(p74, p75, p76, p77)
	streamWriteUInt8(p75, p74.numRocksDestroyed)
end
function DestructibleRockMission.update(p78, p79)
	if p78.status == MissionStatus.RUNNING and (g_localPlayer ~= nil and (g_localPlayer.farmId == p78.farmId and not p78.isHotspotAdded)) then
		p78:addHotspot()
	end
	if not p78.markersAdded and p78.status == MissionStatus.RUNNING then
		p78:addRockMarkers()
	end
	DestructibleRockMission:superClass().update(p78, p79)
end
function DestructibleRockMission.getDestructibleIsInMissionArea(p80, p81, p82)
	if p80.status == MissionStatus.RUNNING and p80.farmId == p82 then
		return p80.rocksAllKeys[p81] ~= nil
	else
		return false
	end
end
function DestructibleRockMission.onRockDestroyed(p83, p84)
	if p83.status == MissionStatus.RUNNING then
		if p83.rocksAllKeys[p84] then
			if p83.rocksKeys[p84] then
				local v85 = p83.rockToMarker[p84]
				if v85 then
					setVisibility(v85, false)
				end
				if p83.isServer then
					p83.numRocksDestroyed = p83.numRocksDestroyed + 1
					return
				end
			elseif p83.isServer then
				local v86 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
				p83.wronglyDestroyedRocksPenalty = p83.wronglyDestroyedRocksPenalty + v86.penaltyPerRock
				g_currentMission:broadcastEventToFarm(WrongRockDestroyedEvent.new(), p83.farmId, true)
			end
		end
	else
		return
	end
end
function DestructibleRockMission.rockMarkerRaycastCallback(p87, p88, p89, p90, p91)
	if p88 ~= 0 and p88 ~= g_terrainNode then
		if p87.rockToMarker == nil or p87.status ~= MissionStatus.RUNNING then
			return false
		end
		local v92 = g_currentMission.destructibleMapObjectSystem:getDestructibleFromNode(p88)
		if v92 then
			local v93 = p87.rockToMarker[v92]
			if v93 then
				setWorldTranslation(v93, p89, p90 - 0.15, p91)
				setWorldRotation(v93, 0, 0, 0)
			end
			return false
		end
	end
	return true
end
function DestructibleRockMission.addRockMarkers(p94)
	if not p94.markersAdded then
		if p94.markerRootNode == nil then
			p94.markerRootNode = createTransformGroup("destructibleRockMissionMarkers")
			link(getRootNode(), p94.markerRootNode)
		end
		local v95 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
		for _, v96 in pairs(p94.rocks) do
			if getEffectiveVisibility(v96) then
				local v97 = clone(v95.markerNode, false, false, false)
				link(p94.markerRootNode, v97)
				p94.rockToMarker[v96] = v97
				local v98, v99, v100 = getWorldTranslation(v96)
				raycastAll(v98, v99 + 10, v100, 0, -1, 0, 10, "rockMarkerRaycastCallback", p94, DestructibleRockMission.COLLISION_MASK)
			end
		end
		p94.markersAdded = true
	end
end
function DestructibleRockMission.getLocation(p101)
	return string.format(g_i18n:getText("contract_farmland"), p101.farmlandId)
end
function DestructibleRockMission.getMapHotspots(p102)
	return p102.mapHotspots
end
function DestructibleRockMission.getWorldPosition(p103)
	local v104 = p103.spot
	if v104 == nil then
		return g_farmlandManager:getFarmlandById(p103.farmlandId):getIndicatorPosition()
	else
		return v104.x, v104.z
	end
end
function DestructibleRockMission.finish(p105, p106)
	p105:removeHotspot()
	local v107 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	if #p105.rocksAll - p105.numRocksDestroyed < v107.minNumRocks then
		v107.spotsDisabled[p105.spot] = true
	end
	local v108 = g_currentMission
	if v108:getFarmId() == p105.farmId then
		if p106 == MissionFinishState.SUCCESS then
			v108:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, string.format(g_i18n:getText("contract_map_destructibleRock_completed"), p105.farmlandId))
		elseif p106 == MissionFinishState.FAILED then
			v108:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("contract_map_destructibleRock_failed"), p105.farmlandId))
		elseif p106 == MissionFinishState.TIMED_OUT then
			v108:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("contract_map_destructibleRock_timedOut"), p105.farmlandId))
		end
	end
	DestructibleRockMission:superClass().finish(p105, p106)
end
function DestructibleRockMission.addHotspot(p109)
	if p109.mapHotspot ~= nil then
		p109.isHotspotAdded = true
		g_currentMission:addMapHotspot(p109.mapHotspot)
	end
end
function DestructibleRockMission.removeHotspot(p110)
	if p110.mapHotspot ~= nil then
		g_currentMission:removeMapHotspot(p110.mapHotspot)
		p110.isHotspotAdded = false
	end
end
function DestructibleRockMission.showCompletionNotification(p111)
	local v112 = string.format(g_i18n:getText("contract_map_destructibleRock_completionNotification"), p111.farmlandId, p111.completion * 100)
	g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, v112)
end
function DestructibleRockMission.validate(p113)
	local v114 = DestructibleRockMission:superClass().validate(p113)
	if v114 then
		if g_farmlandManager:getFarmlandById(p113.farmlandId).isOwned then
			return false
		else
			return v114
		end
	else
		return false
	end
end
function DestructibleRockMission.dismiss(p115)
	if p115.isServer then
		local v116 = (p115.finishState ~= MissionFinishState.SUCCESS and 0 or p115:getReward()) - p115.wronglyDestroyedRocksPenalty
		if v116 ~= 0 then
			g_currentMission:addMoney(v116, p115.farmId, MoneyType.MISSIONS, true, true)
		end
	end
end
function DestructibleRockMission.getNPC(p117)
	local v118 = g_farmlandManager:getFarmlandById(p117.farmlandId)
	return g_npcManager:getNPCByIndex(v118.npcIndex)
end
function DestructibleRockMission.getExtraProgressText(p119)
	local v120 = #p119.rocks - p119.numRocksDestroyed
	if v120 == 1 then
		return g_i18n:getText("contract_map_destructibleRock_oneRemainingRock")
	else
		return string.format(g_i18n:getText("contract_map_destructibleRock_remainingRocks"), v120)
	end
end
function DestructibleRockMission.getCompletion(p121)
	return p121.numRocksDestroyed / #p121.rocks
end
function DestructibleRockMission.getReward(p122)
	return p122.reward
end
function DestructibleRockMission.getFarmlandId(p123)
	return p123.farmlandId
end
function DestructibleRockMission.getDetails(p124)
	local v125 = DestructibleRockMission:superClass().getDetails(p124)
	local v126 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	local v127 = {
		["title"] = g_i18n:getText("contract_details_farmland"),
		["value"] = p124.farmlandId
	}
	table.insert(v125, v127)
	local v128 = {
		["title"] = g_i18n:getText("contract_map_destructibleRock_details_reward"),
		["value"] = g_i18n:formatMoney(v126.rewardPerRock, 0, true)
	}
	table.insert(v125, v128)
	local v129 = {
		["title"] = g_i18n:getText("contract_map_destructibleRock_details_penalty"),
		["value"] = g_i18n:formatMoney(v126.penaltyPerRock, 0, true)
	}
	table.insert(v125, v129)
	local v130 = {
		["title"] = g_i18n:getText("contract_map_destructibleRock_details_totalNumRocks"),
		["value"] = #p124.rocks
	}
	table.insert(v125, v130)
	if p124.status ~= MissionStatus.CREATED then
		local v131 = {
			["title"] = g_i18n:getText("contract_map_destructibleRock_details_destroyedNumRocks"),
			["value"] = p124.numRocksDestroyed
		}
		table.insert(v125, v131)
	end
	return v125
end
function DestructibleRockMission.calculateStealingCost(p132)
	return p132.wronglyDestroyedRocksPenalty
end
function DestructibleRockMission.getMissionTypeName(_)
	return DestructibleRockMission.NAME
end
function DestructibleRockMission.loadMapData(p133, p134, p135)
	if p133:hasProperty(p134) then
		local v136 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
		v136.spots = {}
		v136.spotsDisabled = {}
		v136.activeMissions = {}
		v136.minNumRocks = p133:getFloat(p134 .. "#minNumRocks") or 4
		v136.maxNumRocks = p133:getFloat(p134 .. "#maxNumRocks") or 10
		v136.maxNumInstances = p133:getInt(p134 .. "#maxNumInstances") or 1
		v136.rewardPerRock = p133:getFloat(p134 .. "#rewardPerRock") or 550
		v136.penaltyPerRock = p133:getFloat(p134 .. "#penaltyPerRock") or 1000
		local v137 = p133:getString(p134 .. ".spots#filename")
		if v137 == nil then
			Logging.xmlWarning(p133, "Missing spot definition file for destructible rock mission (%s)", p134)
			return false
		end
		local v138 = Utils.getFilename(v137, p135)
		local v139 = g_i3DManager:loadI3DFile(v138, false, false)
		if v139 == 0 then
			return false
		end
		local v140 = getChildAt(v139, 0)
		link(getRootNode(), v140)
		for v141 = 0, getNumOfChildren(v140) - 1 do
			local v142 = getChildAt(v140, v141)
			local v143, v144, v145 = getTranslation(v142)
			local v146 = getUserAttribute
			local v147 = tonumber(v146(v142, "radius"))
			if v147 == nil then
				Logging.xmlWarning(p133, "No radius defined for destructible rock mission spot \'%s\'!", getName(v142))
			else
				local v148 = g_farmlandManager:getFarmlandIdAtWorldPosition(v143, v145)
				local v149
				if v148 == nil then
					v149 = false
				else
					v149 = v148 ~= FarmlandManager.NOT_BUYABLE_FARM_ID
				end
				if v149 then
					local v150 = getTerrainHeightAtWorldPos(g_terrainNode, v143, v144, v145)
					local v151 = {
						["index"] = #v136.spots + 1,
						["x"] = v143,
						["y"] = v150,
						["z"] = v145,
						["radius"] = v147,
						["isInUse"] = false,
						["farmlandId"] = v148
					}
					local v152 = v136.spots
					table.insert(v152, v151)
				else
					local v153 = v148 ~= FarmlandManager.NOT_BUYABLE_FARM_ID and "Not defined" or string.format("Not buyable (%d)", v148)
					Logging.xmlWarning(p133, "Invalid farmland \'%s\' found for destructible rock mission spot \'%s\' at %d %d!", v153, getName(v142), v143, v145)
				end
			end
		end
		v136.spotRoot = v140
		delete(v139)
		local v154 = p133:getString(p134 .. ".marker#filename")
		if v154 == nil then
			Logging.xmlWarning(p133, "Missing marker file for destructible rock mission (%s)", p134)
			return false
		end
		local v155 = Utils.getFilename(v154, p135)
		local v156 = g_i3DManager:loadI3DFile(v155, false, false)
		if v156 == 0 then
			return false
		end
		v136.markerNode = getChildAt(v156, 0)
		unlink(v136.markerNode)
		delete(v156)
		return true
	end
end
function DestructibleRockMission.unloadMapData()
	local v157 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	if v157.spotRoot ~= nil then
		delete(v157.spotRoot)
	end
	if v157.markerNode ~= nil then
		delete(v157.markerNode)
	end
end
function DestructibleRockMission.loadMetaDataFromXMLFile(p158, p159)
	g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME).nextMissionDay = p158:getValue(p159 .. "#nextDay")
end
function DestructibleRockMission.saveMetaDataToXMLFile(p160, p161)
	local v162 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	if v162.nextMissionDay ~= nil then
		p160:setValue(p161 .. "#nextDay", v162.nextMissionDay)
	end
end
function DestructibleRockMission.onFinishCallback()
	g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME).rockCheck.isRunning = false
end
function DestructibleRockMission.onRockCallback(_, p163, _, p164)
	if p163 ~= 0 and getHasClassId(p163, ClassIds.SHAPE) then
		local v165 = g_currentMission.destructibleMapObjectSystem:getDestructibleFromNode(p163)
		if v165 ~= nil then
			local v166, _, v167 = getWorldTranslation(p163)
			local v168 = g_farmlandManager:getFarmlandIdAtWorldPosition(v166, v167)
			local v169 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME).rockCheck
			if v168 == v169.farmlandId then
				local v170 = v169.rocks
				table.insert(v170, v165)
			end
		end
	end
	if p164 then
		DestructibleRockMission.onFinishCallback()
	end
	return true
end
function DestructibleRockMission.tryGenerateMission()
	if not DestructibleRockMission.canRun() then
		return nil
	end
	local v171 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	local v172 = v171.rockCheck
	if v172 ~= nil then
		if v172.isRunning then
			return nil
		end
		if #v172.rocks < v171.minNumRocks then
			v171.spotsDisabled[v172.spot] = true
			v171.rockCheck = nil
			return nil
		end
		local v173 = DestructibleRockMission.new(true, g_client ~= nil)
		if v173:init(v172.spot, v172.rocks) then
			local v174 = g_currentMission.environment
			v173:setEndDate(v174.currentMonotonicDay + 2, MathUtil.hoursToMs(math.random(10, 18)))
			v171.nextMissionDay = v174.currentMonotonicDay + math.random(4, 9)
		else
			v173:delete()
			v173 = nil
		end
		v171.rockCheck = nil
		return v173
	end
	local v175 = v171.spots
	Utils.shuffle(v175)
	local v176 = {}
	for _, v177 in ipairs(v171.activeMissions) do
		v176[v177.spot.farmlandId] = true
	end
	local v178 = nil
	for _, v179 in ipairs(v175) do
		if v171.spotsDisabled[v179] == nil and (not v179.isInUse and (v176[v179.farmlandId] == nil and g_farmlandManager:getFarmlandOwner(v179.farmlandId) == FarmlandManager.NO_OWNER_FARM_ID)) then
			v178 = v179
			break
		end
	end
	if v178 == nil then
		return nil
	end
	local v180 = {
		["spot"] = v178,
		["isRunning"] = true,
		["rocks"] = {},
		["farmlandId"] = v178.farmlandId
	}
	local v181 = v178.x
	local v182 = v178.y
	local v183 = v178.z
	local v184 = v178.radius
	local v185 = DestructibleRockMission.COLLISION_MASK
	local v186 = v178.height or 20
	overlapCylinderAsync(v181, v182, v183, v184, v186, Axis.Y, "onRockCallback", DestructibleRockMission, v185)
	v171.rockCheck = v180
	return nil
end
function DestructibleRockMission.canRun()
	local v187 = g_missionManager:getMissionTypeDataByName(DestructibleRockMission.NAME)
	if v187.spots == nil then
		return false
	elseif #v187.spots == 0 then
		return false
	elseif v187.numInstances >= v187.maxNumInstances then
		return false
	else
		return v187.nextMissionDay == nil or g_currentMission.environment.currentMonotonicDay >= v187.nextMissionDay
	end
end
g_missionManager:registerMissionType(DestructibleRockMission, DestructibleRockMission.NAME, 2)

TreeTransportMissionHotspot = {}
local v_u_1 = Class(TreeTransportMissionHotspot, MapHotspot)
function TreeTransportMissionHotspot.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = MapHotspot.new(p2 or v_u_1)
	local v4, v5 = getNormalizedScreenValues(50, 50)
	v3.width = v4
	v3.height = v5
	v3.icon = g_overlayManager:createOverlay("mapHotspots.contractWoodTransport", 0, 0, v3.width, v3.height)
	local v6 = Utils.getFilename("$dataS/menu/hud/hud_elements.png", TreeTransportMissionHotspot.MOD_DIRECTORY)
	local v7 = GuiUtils.getUVs({
		48,
		291,
		256,
		256
	}, { 1024, 1024 })
	v3.circle = Overlay.new(v6, 0, 0, v3.width, v3.height)
	v3.circle:setUVs(v7)
	v3.circle:setColor(0.5089, 0.016, 0.016, 1)
	v3.worldRadius = 50
	v3.forceNoRotation = true
	return v3
end
function TreeTransportMissionHotspot.delete(p8)
	TreeTransportMissionHotspot:superClass().delete(p8)
	if p8.icon ~= nil then
		p8.icon:delete()
		p8.icon = nil
	end
	if p8.circle ~= nil then
		p8.circle:delete()
		p8.circle = nil
	end
end
function TreeTransportMissionHotspot.setWorldRadius(p9, p10)
	p9.worldRadius = p10
end
function TreeTransportMissionHotspot.updateCircleSize(p11)
	local v12 = g_currentMission.hud:getIngameMap()
	local v13, v14 = v12.layout:getMapSize()
	local v15 = p11.worldRadius / v12.worldSizeX * v13
	local v16 = p11.worldRadius / v12.worldSizeZ * v14
	p11.circle:setDimension(v15, v16)
end
function TreeTransportMissionHotspot.getWidth(p17)
	if p17.circle == nil then
		return p17.lastRenderedIcon == nil and 0 or p17.lastRenderedIcon.width
	end
	p17:updateCircleSize()
	return p17.circle.width
end
function TreeTransportMissionHotspot.getHeight(p18)
	if p18.circle == nil then
		return p18.lastRenderedIcon == nil and 0 or p18.lastRenderedIcon.height
	end
	p18:updateCircleSize()
	return p18.circle.height
end
function TreeTransportMissionHotspot.getDimension(p19)
	if p19.circle == nil then
		if p19.lastRenderedIcon == nil then
			return 0, 0
		else
			return p19.lastRenderedIcon.width, p19.lastRenderedIcon.height
		end
	else
		p19:updateCircleSize()
		return p19.circle.width, p19.circle.height
	end
end
function TreeTransportMissionHotspot.setScale(p20, p21)
	if p20.icon ~= nil then
		p20.icon:setScale(p21, p21)
	end
end
function TreeTransportMissionHotspot.getCategory(_)
	return MapHotspot.CATEGORY_MISSION
end
function TreeTransportMissionHotspot.getIsPersistent(_)
	return false
end
function TreeTransportMissionHotspot.getRenderLast(_)
	return false
end
function TreeTransportMissionHotspot.render(p22, p23, p24, _, _)
	local v25 = p22.icon
	local v26 = p22.circle
	if v26 ~= nil then
		v26:setPosition(p23, p24)
		v26:setColor(nil, nil, nil, IngameMap.alpha)
		v26:render()
		p23 = p23 + v26.width * 0.5
		p24 = p24 + v26.height * 0.5
		if v25 ~= nil then
			p23 = p23 - v25.width * 0.5
			p24 = p24 - v25.height * 0.5
		end
	end
	if v25 ~= nil then
		v25:setPosition(p23, p24)
		v25:setColor(nil, nil, nil, p22.isBlinking and (p22:getCanBlink() and IngameMap.alpha) or 1)
		v25:render()
	end
end

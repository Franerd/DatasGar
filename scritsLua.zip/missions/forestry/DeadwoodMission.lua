DeadwoodMission = {}
source("dataS/scripts/missions/forestry/DeadwoodMissionHotspot.lua")
source("dataS/scripts/missions/forestry/DeadwoodMissionTreeEvent.lua")
source("dataS/scripts/missions/forestry/DeadwoodMissionWrongTreeEvent.lua")
DeadwoodMission.NAME = "deadwoodMission"
local v_u_1 = Class(DeadwoodMission, AbstractMission)
InitStaticObjectClass(DeadwoodMission, "DeadwoodMission")
function DeadwoodMission.registerXMLPaths(p2, p3)
	DeadwoodMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#maxNumInstances", "Max number of instances")
	p2:register(XMLValueType.INT, p3 .. "#rewardPerTree", "Reward per tree")
	p2:register(XMLValueType.INT, p3 .. "#penaltyPerTree", "Penalty per tree")
	p2:register(XMLValueType.STRING, p3 .. "#treeType", "Tree type")
	p2:register(XMLValueType.STRING, p3 .. ".spots#filename", "Filename to tree spots")
end
function DeadwoodMission.registerSavegameXMLPaths(p4, p5)
	DeadwoodMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#spotIndex", "Spot index")
	p4:register(XMLValueType.INT, p5 .. ".originalTree(?)#splitShapePart1", "Part1 of the original tree")
	p4:register(XMLValueType.INT, p5 .. ".originalTree(?)#splitShapePart2", "Part2 of the original tree")
	p4:register(XMLValueType.INT, p5 .. ".originalTree(?)#splitShapePart3", "Part3 of the original tree")
	p4:register(XMLValueType.INT, p5 .. ".deadTree(?)#splitShapePart1", "Part1 of the dead tree")
	p4:register(XMLValueType.INT, p5 .. ".deadTree(?)#splitShapePart2", "Part2 of the dead tree")
	p4:register(XMLValueType.INT, p5 .. ".deadTree(?)#splitShapePart3", "Part3 of the dead tree")
	p4:register(XMLValueType.BOOL, p5 .. ".deadTree(?)#cutDown", "If the tree was cut down")
	p4:register(XMLValueType.INT, p5 .. ".cutSplitShape(?)#splitShapePart1", "Part1 of the cut split shape")
	p4:register(XMLValueType.INT, p5 .. ".cutSplitShape(?)#splitShapePart2", "Part2 of the cut split shape")
	p4:register(XMLValueType.INT, p5 .. ".cutSplitShape(?)#splitShapePart3", "Part3 of the cut split shape")
end
function DeadwoodMission.registerMetaXMLPaths(p6, p7)
	DeadwoodMission:superClass().registerMetaXMLPaths(p6, p7)
	p6:register(XMLValueType.INT, p7 .. "#nextDay", "Earliest day a new mission can spawn")
end
function DeadwoodMission.new(p8, p9, p10)
	-- upvalues: (copy) v_u_1
	local v11 = g_i18n:getText("contract_forestry_deadwood_title")
	local v12 = g_i18n:getText("contract_forestry_deadwood_description")
	local v13 = AbstractMission.new(p8, p9, v11, v12, p10 or v_u_1)
	v13.spot = nil
	v13.deadTrees = {}
	v13.deadTreeShapeToTree = {}
	v13.deadTreeCutSplitShapes = {}
	v13.pendingOriginalTrees = {}
	v13.originalTrees = {}
	v13.numDeadTrees = 0
	v13.numCutDownTrees = 0
	v13.wronglyCutDownTreesReward = 0
	v13.resolveOriginalTreeServerIds = false
	v13.resolveDeadTreeServerIds = false
	v13.isHotspotAdded = false
	v13.mapHotspot = nil
	g_messageCenter:subscribe(MessageType.SPLIT_SHAPE, v13.onTreeShapeCut, v13)
	local v14 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
	table.addElement(v14.activeMissions, v13)
	return v13
end
function DeadwoodMission.init(p15, p16, p17, p18)
	local v19 = DeadwoodMission:superClass().init(p15)
	if p16 == nil then
		return false
	end
	p15:setSpot(p16)
	local v20 = #p17
	local v21 = #p18
	if v20 + v21 == 0 then
		return false
	end
	if v21 < 10 then
		local v22 = math.min(5, v20)
		local v23 = math.min(10, v20)
		v21 = v21 + math.random(v22, v23)
	end
	p15.numDeadTrees = v21
	local v24 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME).rewardPerTree
	p15.reward = p15.numDeadTrees * v24
	Utils.shuffle(p17)
	for _, v25 in ipairs(p18) do
		local v26 = p15.originalTrees
		table.insert(v26, v25)
	end
	for _, v27 in ipairs(p17) do
		if #p15.originalTrees == p15.numDeadTrees then
			break
		end
		local v28 = p15.originalTrees
		table.insert(v28, v27)
	end
	return v19
end
function DeadwoodMission.setSpot(p29, p30)
	p29.spot = p30
	p30.isInUse = true
	p29.farmlandId = p30.farmlandId
	if p29.mapHotspot == nil then
		p29.mapHotspot = DeadwoodMissionHotspot.new()
	end
	local v31 = p29.spot.x
	local v32 = p29.spot.z
	local v33 = p29.spot.radius
	p29.mapHotspot:setWorldPosition(v31, v32)
	p29.mapHotspot:setWorldRadius(v33)
	p29.mapHotspots = { p29.mapHotspot }
end
function DeadwoodMission.delete(p34)
	DeadwoodMission:superClass().delete(p34)
	p34:removeHotspot()
	p34:destroyTrees()
	g_messageCenter:unsubscribeAll(p34)
	if p34.spot ~= nil then
		p34.spot.isInUse = false
		p34.spot = nil
	end
	if p34.mapHotspot ~= nil then
		p34.mapHotspot:delete()
		p34.mapHotspot = nil
	end
	p34.mapHotspots = nil
	local v35 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
	if v35 ~= nil then
		table.removeElement(v35.activeMissions, p34)
	end
end
function DeadwoodMission.saveToXMLFile(p36, p37, p38)
	DeadwoodMission:superClass().saveToXMLFile(p36, p37, p38)
	p37:setValue(p38 .. "#spotIndex", p36.spot.index)
	local v39 = 0
	for _, v40 in ipairs(p36.originalTrees) do
		local v41 = string.format("%s.originalTree(%d)", p38, v39)
		if entityExists(v40) then
			local v42, v43, v44 = getSaveableSplitShapeId(v40)
			if v42 ~= 0 and v42 ~= nil then
				p37:setValue(v41 .. "#splitShapePart1", v42)
				p37:setValue(v41 .. "#splitShapePart2", v43)
				p37:setValue(v41 .. "#splitShapePart3", v44)
			end
		end
		v39 = v39 + 1
	end
	local v45 = 0
	for _, v46 in pairs(p36.deadTrees) do
		local v47 = string.format("%s.deadTree(%d)", p38, v45)
		p37:setBool(v47 .. "#cutDown", v46.cutDown)
		if v46.splitShapeId ~= nil and entityExists(v46.splitShapeId) then
			local v48, v49, v50 = getSaveableSplitShapeId(v46.splitShapeId)
			if v48 ~= 0 and v48 ~= nil then
				p37:setValue(v47 .. "#splitShapePart1", v48)
				p37:setValue(v47 .. "#splitShapePart2", v49)
				p37:setValue(v47 .. "#splitShapePart3", v50)
			end
		end
		v45 = v45 + 1
	end
	local v51 = 0
	for v52, _ in pairs(p36.deadTreeCutSplitShapes) do
		local v53 = string.format("%s.cutSplitShape(%d)", p38, v51)
		if entityExists(v52) then
			local v54, v55, v56 = getSaveableSplitShapeId(v52)
			if v54 ~= 0 and v54 ~= nil then
				p37:setValue(v53 .. "#splitShapePart1", v54)
				p37:setValue(v53 .. "#splitShapePart2", v55)
				p37:setValue(v53 .. "#splitShapePart3", v56)
				v51 = v51 + 1
			end
		end
	end
end
function DeadwoodMission.loadFromXMLFile(p57, p58, p59)
	DeadwoodMission:superClass().loadFromXMLFile(p57, p58, p59)
	local v60 = p58:getValue(p59 .. "#spotIndex") or 0
	local v61 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME).spots[v60]
	if v61 == nil then
		return false
	end
	p57:setSpot(v61)
	p57.pendingSavegameData = {
		["originalTrees"] = {},
		["deadTrees"] = {},
		["deadTreeCutSplitShapes"] = {}
	}
	for _, v62 in p58:iterator(p59 .. ".originalTree") do
		local v63 = p58:getValue(v62 .. "#splitShapePart1")
		local v64 = p58:getValue(v62 .. "#splitShapePart2")
		local v65 = p58:getValue(v62 .. "#splitShapePart3")
		local v66 = p57.pendingSavegameData.originalTrees
		table.insert(v66, {
			["splitShapePart1"] = v63,
			["splitShapePart2"] = v64,
			["splitShapePart3"] = v65
		})
	end
	for _, v67 in p58:iterator(p59 .. ".deadTree") do
		local v68 = p58:getBool(v67 .. "#cutDown")
		local v69 = p58:getValue(v67 .. "#splitShapePart1")
		local v70 = p58:getValue(v67 .. "#splitShapePart2")
		local v71 = p58:getValue(v67 .. "#splitShapePart3")
		local v72 = p57.pendingSavegameData.deadTrees
		table.insert(v72, {
			["splitShapePart1"] = v69,
			["splitShapePart2"] = v70,
			["splitShapePart3"] = v71,
			["cutDown"] = v68
		})
	end
	for _, v73 in p58:iterator(p59 .. ".cutSplitShape") do
		local v74 = p58:getValue(v73 .. "#splitShapePart1")
		local v75 = p58:getValue(v73 .. "#splitShapePart2")
		local v76 = p58:getValue(v73 .. "#splitShapePart3")
		local v77 = p57.pendingSavegameData.deadTreeCutSplitShapes
		table.insert(v77, {
			["splitShapePart1"] = v74,
			["splitShapePart2"] = v75,
			["splitShapePart3"] = v76
		})
	end
	return true
end
function DeadwoodMission.writeStream(p78, p79, p80)
	DeadwoodMission:superClass().writeStream(p78, p79, p80)
	streamWriteUInt8(p79, p78.spot.index)
	streamWriteUInt8(p79, p78.numCutDownTrees)
	streamWriteUInt8(p79, p78.numDeadTrees)
	streamWriteUInt8(p79, #p78.originalTrees)
	for _, v81 in ipairs(p78.originalTrees) do
		writeSplitShapeIdToStream(p79, v81)
	end
	p78:writeDeadTreesStream(p79)
end
function DeadwoodMission.readStream(p82, p83, p84)
	DeadwoodMission:superClass().readStream(p82, p83, p84)
	local v85 = streamReadUInt8(p83)
	p82:setSpot(g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME).spots[v85])
	p82.numCutDownTrees = streamReadUInt8(p83)
	p82.numDeadTrees = streamReadUInt8(p83)
	for _ = 1, streamReadUInt8(p83) do
		local v86, v87, v88 = readSplitShapeIdFromStream(p83)
		if v86 == 0 then
			if v87 ~= 0 then
				local v89 = p82.pendingOriginalTrees
				table.insert(v89, { v87, v88 })
			end
		else
			local v90 = p82.originalTrees
			table.insert(v90, v86)
		end
	end
	p82.resolveOriginalTreeServerIds = true
	p82:readDeadTreesStream(p83)
end
function DeadwoodMission.readUpdateStream(p91, p92, p93, p94)
	DeadwoodMission:superClass().readUpdateStream(p91, p92, p93, p94)
	p91.numCutDownTrees = streamReadUInt8(p92)
end
function DeadwoodMission.writeUpdateStream(p95, p96, p97, p98)
	DeadwoodMission:superClass().writeUpdateStream(p95, p96, p97, p98)
	streamWriteUInt8(p96, p95.numCutDownTrees)
end
function DeadwoodMission.readDeadTreesStream(p99, p100)
	for _ = 1, streamReadUInt8(p100) do
		local v101 = {
			["cutDown"] = false,
			["splitShapeId"] = nil
		}
		if not streamReadBool(p100) then
			local v102, v103, v104 = readSplitShapeIdFromStream(p100)
			if v102 == 0 then
				if v103 ~= 0 then
					v101.serverSplitShapePart1 = v103
					v101.serverSplitShapePart2 = v104
				end
			else
				v101.splitShapeId = v102
			end
		end
		local v105 = p99.deadTrees
		table.insert(v105, v101)
	end
	p99.resolveDeadTreeServerIds = true
end
function DeadwoodMission.writeDeadTreesStream(p106, p107)
	streamWriteUInt8(p107, #p106.deadTrees)
	for _, v108 in ipairs(p106.deadTrees) do
		if not streamWriteBool(p107, v108.cutDown) then
			writeSplitShapeIdToStream(p107, v108.splitShapeId)
		end
	end
end
function DeadwoodMission.update(p109, p110)
	if p109.isServer then
		if p109.pendingSavegameData ~= nil then
			for _, v111 in ipairs(p109.pendingSavegameData.originalTrees) do
				if v111.splitShapePart1 ~= nil then
					local v112 = getShapeFromSaveableSplitShapeId(v111.splitShapePart1, v111.splitShapePart2, v111.splitShapePart3)
					if v112 ~= 0 and v112 ~= nil then
						local v113 = p109.originalTrees
						table.insert(v113, v112)
					end
				end
			end
			p109.numDeadTrees = #p109.originalTrees
			p109.numCutDownTrees = 0
			for _, v114 in ipairs(p109.pendingSavegameData.deadTrees) do
				local v115 = nil
				local v116 = nil
				local v117 = nil
				local v118 = nil
				local v119
				if v114.splitShapePart1 == nil then
					v119 = nil
				else
					v119 = getShapeFromSaveableSplitShapeId(v114.splitShapePart1, v114.splitShapePart2, v114.splitShapePart3)
					if v119 == 0 or v119 == nil then
						v119 = nil
					else
						local v120
						v116, v120, v117 = getWorldTranslation(v119)
						local v121, v122
						v121, v118, v122 = getWorldRotation(v119)
						v115 = getParent(v119)
					end
				end
				if v114.cutDown then
					p109.numCutDownTrees = p109.numCutDownTrees + 1
				end
				local v123 = {
					["x"] = v116,
					["z"] = v117,
					["rotY"] = v118,
					["cutDown"] = v114.cutDown,
					["splitShapeId"] = v119,
					["rootNode"] = v115
				}
				if v119 ~= nil then
					p109.deadTreeShapeToTree[v119] = v123
				end
				local v124 = p109.deadTrees
				table.insert(v124, v123)
			end
			for _, v125 in ipairs(p109.pendingSavegameData.deadTreeCutSplitShapes) do
				if v125.splitShapePart1 ~= nil then
					local v126 = getShapeFromSaveableSplitShapeId(v125.splitShapePart1, v125.splitShapePart2, v125.splitShapePart3)
					if v126 ~= 0 and v126 ~= nil then
						p109.deadTreeCutSplitShapes[v126] = true
					end
				end
			end
			if p109.status ~= MissionStatus.CREATED then
				for _, v127 in ipairs(p109.originalTrees) do
					p109:setTreeVisibility(v127, false)
				end
			end
			if p109.status == MissionStatus.RUNNING then
				p109:addTreeMarker()
			end
			p109.pendingSavegameData = nil
		end
	else
		if p109.resolveDeadTreeServerIds then
			local v128 = true
			for _, v129 in ipairs(p109.deadTrees) do
				if v129.serverSplitShapePart1 ~= nil and v129.serverSplitShapePart2 ~= nil then
					local v130 = resolveStreamSplitShapeId(v129.serverSplitShapePart1, v129.serverSplitShapePart2)
					if v130 == 0 then
						v128 = false
					else
						v129.splitShapeId = v130
						v129.serverSplitShapePart1 = nil
						v129.serverSplitShapePart2 = nil
					end
				end
			end
			if v128 then
				p109.resolveDeadTreeServerIds = false
				if p109.status == MissionStatus.RUNNING then
					p109:addTreeMarker()
				end
			end
		end
		if p109.resolveOriginalTreeServerIds then
			for v131 = #p109.pendingOriginalTrees, 1, -1 do
				local v132 = p109.pendingOriginalTrees[v131]
				local v133 = resolveStreamSplitShapeId(v132[1], v132[2])
				if v133 ~= 0 then
					table.remove(p109.pendingOriginalTrees, v131)
					local v134 = p109.originalTrees
					table.insert(v134, v133)
				end
			end
			if #p109.pendingOriginalTrees == 0 then
				p109.resolveOriginalTreeServerIds = false
				if p109.status == MissionStatus.RUNNING then
					for _, v135 in ipairs(p109.originalTrees) do
						p109:setTreeVisibility(v135, false)
					end
				end
			end
		end
	end
	DeadwoodMission:superClass().update(p109, p110)
	if p109.status == MissionStatus.RUNNING and (g_localPlayer ~= nil and (g_localPlayer.farmId == p109.farmId and not p109.isHotspotAdded)) then
		p109:addHotspots()
	end
end
function DeadwoodMission.setTreeVisibility(_, p136, p137)
	if entityExists(p136) then
		local v138 = getParent(p136)
		setVisibility(v138, p137)
		if p137 then
			addToPhysics(v138)
		else
			removeFromPhysics(v138)
		end
	else
		return
	end
end
function DeadwoodMission.getLocation(p139)
	return string.format(g_i18n:getText("contract_farmland"), p139.farmlandId)
end
function DeadwoodMission.getMapHotspots(p140)
	return p140.mapHotspots
end
function DeadwoodMission.getWorldPosition(p141)
	local v142 = p141.spot
	if v142 == nil then
		return g_farmlandManager:getFarmlandById(p141.farmlandId):getIndicatorPosition()
	else
		return v142.x, v142.z
	end
end
function DeadwoodMission.addMissionTree(p143, p144)
	local v145 = getParent(p144)
	local v146, v147, v148 = getWorldTranslation(v145)
	local v149, v150, v151 = getWorldRotation(v145)
	local v152 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME).treeIndex
	local v153 = g_treePlantManager:plantTree(v152, v146, v147, v148, v149, v150, v151, 1, 1, false)
	local v154 = SplitShapeUtil.getSplitShapeId(v153)
	if v154 ~= nil then
		local v155 = {
			["rootNode"] = v153,
			["splitShapeId"] = v154,
			["x"] = v146,
			["z"] = v148,
			["rotY"] = v150,
			["cutDown"] = false
		}
		local v156 = p143.deadTrees
		table.insert(v156, v155)
		p143.deadTreeShapeToTree[v154] = v155
	end
end
function DeadwoodMission.prepare(p157, p158)
	DeadwoodMission:superClass().prepare(p157, p158)
	for _, v159 in ipairs(p157.originalTrees) do
		p157:setTreeVisibility(v159, false)
		p157:addMissionTree(v159)
	end
	p157:addTreeMarker()
	g_server:broadcastEvent(DeadwoodMissionTreeEvent.new(p157))
end
function DeadwoodMission.started(p160)
	DeadwoodMission:superClass().started(p160)
	for _, v161 in ipairs(p160.originalTrees) do
		p160:setTreeVisibility(v161, false)
	end
end
function DeadwoodMission.destroyTrees(p162)
	for _, v163 in ipairs(p162.deadTrees) do
		if v163.rootNode ~= nil and entityExists(v163.rootNode) then
			for v164 = getNumOfChildren(v163.rootNode), 1, -1 do
				delete(getChildAt(v163.rootNode, v164 - 1))
			end
		end
	end
	p162.deadTrees = {}
	p162.deadTreeShapeToTree = {}
	for v165, _ in pairs(p162.deadTreeCutSplitShapes) do
		if entityExists(v165) then
			delete(v165)
			p162.deadTreeCutSplitShapes[v165] = nil
		end
	end
	for _, v166 in ipairs(p162.originalTrees) do
		p162:setTreeVisibility(v166, true)
	end
end
function DeadwoodMission.addTreeMarker(p167)
	local v168 = g_currentMission.treeMarkerSystem
	if v168 == nil then
		return
	else
		local v169 = v168:getTreeMarkerTypeByName("EXCLAMATION")
		if v169 ~= nil then
			for _, v170 in pairs(p167.deadTrees) do
				if v170.splitShapeId ~= nil then
					v168:addTreeMarkerByWorldDirection(v170.splitShapeId, v169.index, 0.7084, 0.0212, 0.0006, 1, 0, 1, 2, 0.7, true)
				end
			end
		end
	end
end
function DeadwoodMission.finish(p171, p172)
	p171:removeHotspot()
	local v173 = g_currentMission
	if v173:getFarmId() == p171.farmId then
		if p172 == MissionFinishState.SUCCESS then
			v173:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, string.format(g_i18n:getText("contract_forestry_deadwood_completed"), p171.farmlandId))
		elseif p172 == MissionFinishState.FAILED then
			v173:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("contract_forestry_deadwood_failed"), p171.farmlandId))
		elseif p172 == MissionFinishState.TIMED_OUT then
			v173:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("contract_forestry_deadwood_timedOut"), p171.farmlandId))
		end
	end
	DeadwoodMission:superClass().finish(p171, p172)
end
function DeadwoodMission.getIsMissionSplitShape(p174, p175)
	if p175 == nil or p175 == 0 then
		return false
	elseif p174.status == MissionStatus.RUNNING then
		return p174.deadTreeCutSplitShapes[p175] ~= nil and true or p174.deadTreeShapeToTree[p175] ~= nil
	else
		return false
	end
end
function DeadwoodMission.addHotspots(p176)
	if p176.mapHotspot ~= nil then
		p176.isHotspotAdded = true
		g_currentMission:addMapHotspot(p176.mapHotspot)
	end
end
function DeadwoodMission.removeHotspot(p177)
	if p177.mapHotspot ~= nil then
		g_currentMission:removeMapHotspot(p177.mapHotspot)
		p177.isHotspotAdded = false
	end
end
function DeadwoodMission.showCompletionNotification(p178)
	local v179 = string.format(g_i18n:getText("contract_forestry_deadwood_completionNotification"), p178.farmlandId, p178.completion * 100)
	g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, v179)
end
function DeadwoodMission.validate(p180)
	local v181 = DeadwoodMission:superClass().validate(p180)
	if v181 then
		if g_farmlandManager:getFarmlandById(p180.farmlandId).isOwned then
			return false
		else
			return v181
		end
	else
		return false
	end
end
function DeadwoodMission.dismiss(p182)
	if p182.isServer then
		local v183 = (p182.finishState ~= MissionFinishState.SUCCESS and 0 or p182:getReward()) - p182.wronglyCutDownTreesReward
		if v183 ~= 0 then
			g_currentMission:addMoney(v183, p182.farmId, MoneyType.MISSIONS, true, true)
		end
	end
end
function DeadwoodMission.getNPC(p184)
	local v185 = g_farmlandManager:getFarmlandById(p184.farmlandId)
	return g_npcManager:getNPCByIndex(v185.npcIndex)
end
function DeadwoodMission.getExtraProgressText(p186)
	local v187 = p186.numDeadTrees - p186.numCutDownTrees
	if v187 == 1 then
		return g_i18n:getText("contract_forestry_deadwood_oneRemainingTree")
	else
		return string.format(g_i18n:getText("contract_forestry_deadwood_remainingTrees"), v187)
	end
end
function DeadwoodMission.getDetails(p188)
	local v189 = DeadwoodMission:superClass().getDetails(p188)
	local v190 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
	local v191 = {
		["title"] = g_i18n:getText("contract_details_farmland"),
		["value"] = p188.farmlandId
	}
	table.insert(v189, v191)
	local v192 = {
		["title"] = g_i18n:getText("contract_forestry_details_rewardPerTree"),
		["value"] = g_i18n:formatMoney(v190.rewardPerTree, 0, true)
	}
	table.insert(v189, v192)
	local v193 = {
		["title"] = g_i18n:getText("contract_forestry_details_penaltyPerTree"),
		["value"] = g_i18n:formatMoney(v190.penaltyPerTree, 0, true)
	}
	table.insert(v189, v193)
	local v194 = {
		["title"] = g_i18n:getText("contract_forestry_details_totalNumTrees"),
		["value"] = p188.numDeadTrees
	}
	table.insert(v189, v194)
	if p188.status ~= MissionStatus.CREATED then
		local v195 = {
			["title"] = g_i18n:getText("contract_forestry_deadwood_details_cutNumTrees"),
			["value"] = p188.numCutDownTrees
		}
		table.insert(v189, v195)
	end
	return v189
end
function DeadwoodMission.getCompletion(p196)
	return p196.numCutDownTrees / p196.numDeadTrees
end
function DeadwoodMission.getReward(p197)
	return p197.reward
end
function DeadwoodMission.getFarmlandId(p198)
	return p198.farmlandId
end
function DeadwoodMission.calculateStealingCost(p199)
	return p199.wronglyCutDownTreesReward
end
function DeadwoodMission.onTreeShapeCut(p200, p201, p202)
	if p200.status == MissionStatus.RUNNING then
		if p200.isServer then
			local v203 = p200.deadTreeShapeToTree[p201.shape]
			if v203 ~= nil then
				v203.cutDown = true
				p200.numCutDownTrees = p200.numCutDownTrees + 1
				for _, v204 in ipairs(p202) do
					p200.deadTreeCutSplitShapes[v204.shape] = true
				end
				return
			end
			if p200.deadTreeCutSplitShapes[p201.shape] ~= nil then
				for _, v205 in ipairs(p202) do
					p200.deadTreeCutSplitShapes[v205.shape] = true
				end
				return
			end
			if p201.alreadySplit then
				return
			end
			if g_missionManager:getMissionBySplitShape(p201.shape) ~= nil then
				return
			end
			if g_farmlandManager:getFarmlandIdAtWorldPosition(p201.x, p201.z) == p200.farmlandId then
				local v206 = p201.volume
				local v207 = g_splitShapeManager:getSplitTypeByIndex(p201.splitTypeIndex)
				local v208 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME).penaltyPerTree
				local v209 = v206 * 1000 * v207.pricePerLiter
				local v210 = math.max(v208, v209)
				p200.wronglyCutDownTreesReward = p200.wronglyCutDownTreesReward + v210
				g_currentMission:broadcastEventToFarm(DeadwoodMissionWrongTreeEvent.new(), p200.farmId, true)
			end
		end
	end
end
function DeadwoodMission.getIsShapeCutAllowed(p211, p212, p213, p214, p215)
	if p211.farmId == p215 and g_farmlandManager:getFarmlandIdAtWorldPosition(p213, p214) == p211.farmlandId then
		if p211.status == MissionStatus.FINISHED then
			local v216 = getHasClassId(p212, ClassIds.MESH_SPLIT_SHAPE)
			if v216 then
				v216 = getIsSplitShapeSplit(p212)
			end
			return v216
		end
		if p211.status == MissionStatus.RUNNING then
			return true
		end
	end
	return nil
end
function DeadwoodMission.getMissionTypeName(_)
	return DeadwoodMission.NAME
end
function DeadwoodMission.loadMapData(p217, p218, p219)
	if p217:hasProperty(p218) then
		local v220 = p217:getString(p218 .. "#treeType")
		local v221 = g_treePlantManager:getTreeTypeDescFromName(v220)
		if v221 == nil then
			Logging.xmlWarning(p217, "Missing or undefined treeType \'%s\' for deadwood mission (%s)!", v220, p218)
			return false
		end
		local v222 = p217:getString(p218 .. ".spots#filename")
		if v222 == nil then
			Logging.xmlWarning(p217, "Missing spot definition file for deadwood mission (%s)", p218)
			return false
		end
		local v223 = Utils.getFilename(v222, p219)
		local v224 = g_i3DManager:loadI3DFile(v223, false, false)
		if v224 == 0 then
			return false
		end
		local v225 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
		v225.spots = {}
		v225.spotsDisabled = {}
		v225.activeMissions = {}
		v225.maxNumInstances = p217:getInt(p218 .. "#maxNumInstances") or 1
		v225.treeIndex = v221.index
		v225.rewardPerTree = p217:getFloat(p218 .. "#rewardPerTree") or 150
		v225.penaltyPerTree = p217:getFloat(p218 .. "#penaltyPerTree") or 2000
		v225.deadwoodSplitTypeIndex = g_splitShapeManager:getSplitTypeIndexByName("DEADWOOD")
		local v226 = getChildAt(v224, 0)
		link(getRootNode(), v226)
		for v227 = 0, getNumOfChildren(v226) - 1 do
			local v228 = getChildAt(v226, v227)
			local v229, v230, v231 = getTranslation(v228)
			local v232 = getUserAttribute
			local v233 = tonumber(v232(v228, "radius"))
			if v233 == nil then
				Logging.xmlWarning(p217, "No radius defined for deadwood mission spot \'%s\'!", getName(v228))
			else
				local v234 = g_farmlandManager:getFarmlandIdAtWorldPosition(v229, v231)
				local v235
				if v234 == nil then
					v235 = false
				else
					v235 = v234 ~= FarmlandManager.NOT_BUYABLE_FARM_ID
				end
				if v235 then
					local v236 = getTerrainHeightAtWorldPos(g_terrainNode, v229, v230, v231)
					local v237 = {
						["index"] = #v225.spots + 1,
						["x"] = v229,
						["y"] = v236,
						["z"] = v231,
						["radius"] = v233,
						["isInUse"] = false,
						["farmlandId"] = v234
					}
					local v238 = v225.spots
					table.insert(v238, v237)
				else
					local v239 = v234 ~= FarmlandManager.NOT_BUYABLE_FARM_ID and "Not defined" or string.format("Not buyable (%d)", v234)
					Logging.xmlWarning(p217, "Invalid farmland \'%s\' found for deadwood mission spot \'%s\' at %d %d!", v239, getName(v228), v229, v231)
				end
			end
		end
		v225.spotRoot = v226
		delete(v224)
		return true
	end
end
function DeadwoodMission.unloadMapData()
	local v240 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
	if v240.spotRoot ~= nil then
		delete(v240.spotRoot)
	end
end
function DeadwoodMission.loadMetaDataFromXMLFile(p241, p242)
	g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME).nextMissionDay = p241:getValue(p242 .. "#nextDay")
end
function DeadwoodMission.saveMetaDataToXMLFile(p243, p244)
	local v245 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
	if v245.nextMissionDay ~= nil then
		p243:setValue(p244 .. "#nextDay", v245.nextMissionDay)
	end
end
function DeadwoodMission.onFinishCallback()
	g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME).treeCheck.isRunning = false
end
function DeadwoodMission.onTreeCallback(_, p246, _, p247)
	if p246 ~= 0 and getHasClassId(p246, ClassIds.MESH_SPLIT_SHAPE) then
		local v248 = getSplitType(p246)
		if v248 ~= 0 and not getIsSplitShapeSplit(p246) then
			local v249, _, v250 = getWorldTranslation(p246)
			local v251 = g_farmlandManager:getFarmlandIdAtWorldPosition(v249, v250)
			local v252 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
			local v253 = v252.treeCheck
			if v251 == v253.farmlandId then
				if v248 == v252.deadwoodSplitTypeIndex then
					local v254 = v253.preplacedDeadwood
					table.insert(v254, p246)
				else
					local v255 = v253.trees
					table.insert(v255, p246)
				end
			end
		end
	end
	if p247 then
		DeadwoodMission.onFinishCallback()
	end
	return true
end
function DeadwoodMission.tryGenerateMission()
	if not DeadwoodMission.canRun() then
		return nil
	end
	local v256 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
	local v257 = v256.treeCheck
	if v257 ~= nil then
		if v257.isRunning then
			return nil
		end
		local v258 = nil
		if #v257.trees + #v257.preplacedDeadwood > 0 then
			v258 = DeadwoodMission.new(true, g_client ~= nil)
			if v258:init(v257.spot, v257.trees, v257.preplacedDeadwood) then
				v258:setEndDate(g_currentMission.environment.currentMonotonicDay + 2, MathUtil.hoursToMs(math.random(10, 18)))
			else
				v258:delete()
				v258 = nil
			end
		else
			log("disable spot: no trees found")
			v256.spotsDisabled[v257.spot] = true
		end
		v256.treeCheck = nil
		return v258
	end
	local v259 = v256.spots
	Utils.shuffle(v259)
	local v260 = {}
	for _, v261 in ipairs(v256.activeMissions) do
		v260[v261.spot.farmlandId] = true
	end
	local v262 = nil
	for _, v263 in ipairs(v259) do
		if v256.spotsDisabled[v263] == nil and (not v263.isInUse and (v260[v263.farmlandId] == nil and g_farmlandManager:getFarmlandOwner(v263.farmlandId) == FarmlandManager.NO_OWNER_FARM_ID)) then
			v262 = v263
			break
		end
	end
	if v262 == nil then
		return nil
	end
	local v264 = {
		["spot"] = v262,
		["isRunning"] = true,
		["trees"] = {},
		["preplacedDeadwood"] = {},
		["farmlandId"] = v262.farmlandId
	}
	local v265 = v262.x
	local v266 = v262.y
	local v267 = v262.z
	local v268 = v262.radius
	local v269 = CollisionFlag.TREE
	local v270 = v262.height or 30
	overlapCylinderAsync(v265, v266, v267, v268, v270, Axis.Y, "onTreeCallback", DeadwoodMission, v269)
	v256.treeCheck = v264
	return nil
end
function DeadwoodMission.canRun()
	local v271 = g_missionManager:getMissionTypeDataByName(DeadwoodMission.NAME)
	if v271.spots == nil then
		return false
	elseif #v271.spots == 0 then
		return false
	elseif v271.treeIndex == nil then
		return false
	elseif v271.numInstances >= v271.maxNumInstances then
		return false
	else
		return v271.nextMissionDay == nil or g_currentMission.environment.currentMonotonicDay >= v271.nextMissionDay
	end
end
g_missionManager:registerMissionType(DeadwoodMission, DeadwoodMission.NAME, 1)

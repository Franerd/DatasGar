TreeTransportMission = {}
source("dataS/scripts/missions/forestry/TreeTransportMissionHotspot.lua")
source("dataS/scripts/missions/forestry/TreeTransportMissionTreeCutEvent.lua")
source("dataS/scripts/missions/forestry/TreeTransportMissionWrongSellingStationEvent.lua")
TreeTransportMission.NAME = "treeTransportMission"
local v_u_1 = Class(TreeTransportMission, AbstractMission)
InitStaticObjectClass(TreeTransportMission, "TreeTransportMission")
function TreeTransportMission.registerXMLPaths(p2, p3)
	TreeTransportMission:superClass().registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#maxNumInstances", "Max number of instances")
	p2:register(XMLValueType.INT, p3 .. "#rewardPerTree", "Reward per tree")
	p2:register(XMLValueType.INT, p3 .. "#penaltyPerTree", "Penalty per tree")
	p2:register(XMLValueType.STRING, p3 .. "#treeType", "Tree type")
	p2:register(XMLValueType.STRING, p3 .. ".spots#filename", "Filename to tree spots")
end
function TreeTransportMission.registerSavegameXMLPaths(p4, p5)
	TreeTransportMission:superClass().registerSavegameXMLPaths(p4, p5)
	p4:register(XMLValueType.INT, p5 .. "#spotIndex", "Spot index")
	p4:register(XMLValueType.INT, p5 .. "#numTrees", "Number of trees")
	p4:register(XMLValueType.INT, p5 .. "#numDeliveredTrees", "Number of delivered trees")
	p4:register(XMLValueType.INT, p5 .. "#numDeletedTrees", "Number of deleted trees")
	p4:register(XMLValueType.INT, p5 .. ".tree(?)#splitShapePart1", "Part1 of the tree")
	p4:register(XMLValueType.INT, p5 .. ".tree(?)#splitShapePart2", "Part2 of the tree")
	p4:register(XMLValueType.INT, p5 .. ".tree(?)#splitShapePart3", "Part3 of the tree")
	p4:register(XMLValueType.VECTOR_TRANS, p5 .. ".tree(?)#position", "Position of the tree")
	p4:register(XMLValueType.VECTOR_ROT, p5 .. ".tree(?)#rotation", "Rotation of the tree")
	p4:register(XMLValueType.INT, p5 .. ".cutSplitShape(?)#splitShapePart1", "Part1 of the cut split shape")
	p4:register(XMLValueType.INT, p5 .. ".cutSplitShape(?)#splitShapePart2", "Part2 of the cut split shape")
	p4:register(XMLValueType.INT, p5 .. ".cutSplitShape(?)#splitShapePart3", "Part3 of the cut split shape")
	p4:register(XMLValueType.STRING, p5 .. ".sellingStation#uniqueId", "UniqueId of the selling station")
	p4:register(XMLValueType.INT, p5 .. ".sellingStation#unloadingStationIndex", "Index of the unloading station")
end
function TreeTransportMission.registerMetaXMLPaths(p6, p7)
	TreeTransportMission:superClass().registerMetaXMLPaths(p6, p7)
	p6:register(XMLValueType.INT, p7 .. "#nextDay", "Earliest day a new mission can spawn")
end
function TreeTransportMission.new(p8, p9, p10)
	-- upvalues: (copy) v_u_1
	local v11 = g_i18n:getText("contract_forestry_treeTransport_title")
	local v12 = g_i18n:getText("contract_forestry_treeTransport_description")
	local v13 = AbstractMission.new(p8, p9, v11, v12, p10 or v_u_1)
	v13.spot = nil
	v13.trees = {}
	v13.pendingTrees = {}
	v13.treeShapeToTree = {}
	v13.cutSplitShapes = {}
	v13.resolveServerIds = false
	v13.hasCollision = false
	v13.numDeliveredTrees = 0
	v13.numDeletedTrees = 0
	v13.numTrees = 0
	v13.mapHotspot = nil
	v13.isHotspotAdded = false
	v13.pendingSellingStationId = nil
	v13.sellingStation = nil
	g_messageCenter:subscribe(MessageType.SPLIT_SHAPE, v13.onTreeShapeCut, v13)
	local v14 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
	table.addElement(v14.activeMissions, v13)
	return v13
end
function TreeTransportMission.init(p15, p16, p17)
	if p16 == nil then
		return false
	end
	p15:setSpot(p16)
	if not p15:canSpawnTrees() then
		return false
	end
	p15.numTrees = getNumOfChildren(p16.node)
	local v18 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME).rewardPerTree
	p15.reward = p15.numTrees * v18
	p15:setSellingStation(p17)
	return TreeTransportMission:superClass().init(p15)
end
function TreeTransportMission.onSavegameLoaded(p19)
	local v20 = g_currentMission.placeableSystem:getPlaceableByUniqueId(p19.sellingStationPlaceableUniqueId)
	if v20 == nil then
		Logging.error("Selling station placeable with uniqueId \'%s\' not available for tree transport mission", p19.sellingStationPlaceableUniqueId)
		g_missionManager:markMissionForDeletion(p19)
		return
	else
		local v21 = g_currentMission.storageSystem:getPlaceableUnloadingStation(v20, p19.unloadingStationIndex)
		if v21 == nil then
			Logging.error("Unable to retrieve unloadingStation %d for placeable %s for tree transport mission", p19.unloadingStationIndex, v20.configFileName)
			g_missionManager:markMissionForDeletion(p19)
		else
			p19:setSellingStation(v21)
			if p19:getWasStarted() and not p19:getIsFinished() then
				v21.missions[p19] = p19
			end
			TreeTransportMission:superClass().onSavegameLoaded(p19)
		end
	end
end
function TreeTransportMission.setSpot(p22, p23)
	p22.spot = p23
	p23.isInUse = true
	p22.farmlandId = p23.farmlandId
	if p22.mapHotspot == nil then
		p22.mapHotspot = TreeTransportMissionHotspot.new()
	end
	local v24 = p22.spot.x
	local v25 = p22.spot.z
	p22.mapHotspot:setWorldPosition(v24, v25)
	p22.mapHotspots = { p22.mapHotspot }
end
function TreeTransportMission.delete(p26)
	TreeTransportMission:superClass().delete(p26)
	p26:removeHotspot()
	p26:deleteTrees()
	g_messageCenter:unsubscribeAll(p26)
	if p26.spot ~= nil then
		p26.spot.isInUse = false
		p26.spot = nil
	end
	if p26.mapHotspot ~= nil then
		p26.mapHotspot:delete()
		p26.mapHotspot = nil
	end
	if p26.sellingStationMapHotspot ~= nil then
		p26.sellingStationMapHotspot:delete()
		p26.sellingStationMapHotspot = nil
	end
	if p26.sellingStation ~= nil then
		p26.sellingStation.missions[p26] = nil
	end
	local v27 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
	if v27 ~= nil then
		table.removeElement(v27.activeMissions, p26)
	end
end
function TreeTransportMission.saveToXMLFile(p28, p29, p30)
	TreeTransportMission:superClass().saveToXMLFile(p28, p29, p30)
	p29:setValue(p30 .. "#spotIndex", p28.spot.index)
	p29:setValue(p30 .. "#numTrees", p28.numTrees)
	p29:setValue(p30 .. "#numDeliveredTrees", p28.numDeliveredTrees)
	p29:setValue(p30 .. "#numDeletedTrees", p28.numDeletedTrees)
	if p28.status == MissionStatus.RUNNING then
		local v31 = 0
		for _, v32 in ipairs(p28.trees) do
			local v33 = string.format("%s.tree(%d)", p30, v31)
			if entityExists(v32) then
				local v34, v35, v36 = getSaveableSplitShapeId(v32)
				if v34 ~= 0 then
					p29:setValue(v33 .. "#splitShapePart1", v34)
					p29:setValue(v33 .. "#splitShapePart2", v35)
					p29:setValue(v33 .. "#splitShapePart3", v36)
					local v37, v38, v39 = getWorldTranslation(v32)
					local v40, v41, v42 = getWorldRotation(v32)
					p29:setValue(v33 .. "#position", v37, v38, v39)
					p29:setValue(v33 .. "#rotation", v40, v41, v42)
					v31 = v31 + 1
				end
			end
		end
		local v43 = 0
		for v44, _ in pairs(p28.cutSplitShapes) do
			local v45 = string.format("%s.cutSplitShape(%d)", p30, v43)
			if entityExists(v44) then
				local v46, v47, v48 = getSaveableSplitShapeId(v44)
				if v46 ~= 0 then
					p29:setValue(v45 .. "#splitShapePart1", v46)
					p29:setValue(v45 .. "#splitShapePart2", v47)
					p29:setValue(v45 .. "#splitShapePart3", v48)
					v43 = v43 + 1
				end
			end
		end
	end
	local v49 = p28.sellingStation.owningPlaceable
	if v49 == nil then
		local v50 = p28.sellingStation.getName and p28.sellingStation:getName() or "unknown"
		Logging.xmlWarning(p29, "Unable to retrieve placeable of sellPoint \'%s\' for saving tree transport mission \'%s\' ", v50, p30)
		return
	else
		local v51 = g_currentMission.storageSystem:getPlaceableUnloadingStationIndex(v49, p28.sellingStation)
		if v51 == nil then
			local v52 = p28.sellingStation.getName and p28.sellingStation:getName() or (v49.getName and v49:getName() or "unknown")
			Logging.xmlWarning(p29, "Unable to retrieve unloading station index of sellPoint \'%s\' for saving tree transport mission \'%s\' ", v52, p30)
		else
			p29:setValue(p30 .. ".sellingStation#uniqueId", v49:getUniqueId())
			p29:setValue(p30 .. ".sellingStation#unloadingStationIndex", v51)
		end
	end
end
function TreeTransportMission.loadFromXMLFile(p53, p54, p55)
	TreeTransportMission:superClass().loadFromXMLFile(p53, p54, p55)
	local v56 = p54:getValue(p55 .. "#spotIndex") or 0
	local v57 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME).spots[v56]
	if v57 == nil then
		return false
	end
	p53:setSpot(v57)
	p53.numDeliveredTrees = p54:getValue(p55 .. "#numDeliveredTrees") or 0
	p53.numDeletedTrees = p54:getValue(p55 .. "#numDeletedTrees") or 0
	p53.numTrees = p54:getValue(p55 .. "#numTrees") or p53.numTrees
	if p53.status == MissionStatus.RUNNING then
		p53.pendingSavegameData = {
			["trees"] = {},
			["cutSplitShapes"] = {}
		}
		for _, v58 in p54:iterator(p55 .. ".tree") do
			local v59 = p54:getValue(v58 .. "#splitShapePart1")
			local v60 = p54:getValue(v58 .. "#splitShapePart2")
			local v61 = p54:getValue(v58 .. "#splitShapePart3")
			local v62, v63, v64 = p54:getValue(v58 .. "#position")
			local v65, v66, v67 = p54:getValue(v58 .. "#rotation")
			local v68 = p53.pendingSavegameData.trees
			table.insert(v68, {
				["splitShapeId1"] = v59,
				["splitShapeId2"] = v60,
				["splitShapeId3"] = v61,
				["x"] = v62 or 0,
				["y"] = v63 or 0,
				["z"] = v64 or 0,
				["rx"] = v65 or 0,
				["ry"] = v66 or 0,
				["rz"] = v67 or 0
			})
		end
		for _, v69 in p54:iterator(p55 .. ".cutSplitShape") do
			local v70 = p54:getValue(v69 .. "#splitShapePart1")
			local v71 = p54:getValue(v69 .. "#splitShapePart2")
			local v72 = p54:getValue(v69 .. "#splitShapePart3")
			local v73 = p53.pendingSavegameData.cutSplitShapes
			table.insert(v73, {
				["splitShapePart1"] = v70,
				["splitShapePart2"] = v71,
				["splitShapePart3"] = v72
			})
		end
	end
	local v74 = p54:getValue(p55 .. ".sellingStation#uniqueId")
	if v74 == nil then
		Logging.xmlError(p54, "No sellPointPlaceable uniqueId given for tree transport mission at \'%s\'", p55)
		return false
	end
	local v75 = p54:getValue(p55 .. ".sellingStation#unloadingStationIndex")
	if v75 == nil then
		Logging.xmlError(p54, "No unloadting station index given for tree transport mission at \'%s\'", p55)
		return false
	end
	p53.sellingStationPlaceableUniqueId = v74
	p53.unloadingStationIndex = v75
	return true
end
function TreeTransportMission.writeStream(p76, p77, p78)
	TreeTransportMission:superClass().writeStream(p76, p77, p78)
	streamWriteUInt8(p77, p76.spot.index)
	streamWriteUInt8(p77, p76.numTrees)
	streamWriteUInt8(p77, p76.numDeletedTrees)
	streamWriteUInt8(p77, p76.numDeliveredTrees)
	streamWriteUInt8(p77, #p76.trees)
	for _, v79 in ipairs(p76.trees) do
		if entityExists(v79) then
			writeSplitShapeIdToStream(p77, v79)
		end
	end
	NetworkUtil.writeNodeObject(p77, p76.sellingStation)
end
function TreeTransportMission.readStream(p80, p81, p82)
	TreeTransportMission:superClass().readStream(p80, p81, p82)
	local v83 = streamReadUInt8(p81)
	p80:setSpot(g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME).spots[v83])
	p80.numTrees = streamReadUInt8(p81)
	p80.numDeletedTrees = streamReadUInt8(p81)
	p80.numDeliveredTrees = streamReadUInt8(p81)
	for _ = 1, streamReadUInt8(p81) do
		local v84, v85, v86 = readSplitShapeIdFromStream(p81)
		if v84 == 0 then
			if v85 ~= 0 then
				local v87 = p80.pendingTrees
				table.insert(v87, { v85, v86 })
			end
		else
			local v88 = p80.trees
			table.insert(v88, v84)
		end
	end
	p80.pendingSellingStationId = NetworkUtil.readNodeObjectId(p81)
	p80.resolveServerIds = true
end
function TreeTransportMission.writeUpdateStream(p89, p90, p91, p92)
	TreeTransportMission:superClass().writeUpdateStream(p89, p90, p91, p92)
	streamWriteUInt8(p90, p89.numDeletedTrees)
	streamWriteUInt8(p90, p89.numDeliveredTrees)
end
function TreeTransportMission.readUpdateStream(p93, p94, p95, p96)
	TreeTransportMission:superClass().readUpdateStream(p93, p94, p95, p96)
	p93.numDeletedTrees = streamReadUInt8(p94)
	p93.numDeliveredTrees = streamReadUInt8(p94)
end
function TreeTransportMission.update(p97, p98)
	if p97.isServer then
		if p97.pendingSellingStationId ~= nil then
			p97:tryToResolveSellingStation()
		end
		if p97.pendingSavegameData ~= nil then
			local v99 = 0
			local v100 = 0
			local v101 = false
			for _, v102 in ipairs(p97.pendingSavegameData.trees) do
				v99 = v99 + 1
				if v102.splitShapeId1 ~= nil then
					local v103 = getShapeFromSaveableSplitShapeId(v102.splitShapeId1, v102.splitShapeId2, v102.splitShapeId3)
					if v103 ~= 0 then
						setWorldTranslation(v103, v102.x, v102.y, v102.z)
						setWorldRotation(v103, v102.rx, v102.ry, v102.rz)
						local v104 = TreeTransportMissionTree.new(p97.isServer, p97.isClient)
						v104:setNodeId(v103)
						v104:register()
						p97.treeShapeToTree[v103] = v104
						local v105 = p97.trees
						table.insert(v105, v103)
						v100 = v100 + 1
						v101 = true
					end
				end
			end
			if v101 then
				local v106 = v99 - v100
				p97.numDeletedTrees = p97.numDeletedTrees + v106
			end
			for _, v107 in ipairs(p97.pendingSavegameData.cutSplitShapes) do
				if v107.splitShapeId1 ~= nil then
					local v108 = getShapeFromSaveableSplitShapeId(v107.splitShapeId1, v107.splitShapeId2, v107.splitShapeId3)
					if v108 ~= 0 then
						p97.cutSplitShapes[v108] = true
					end
				end
			end
			p97.pendingSavegameData = nil
		end
		for v109, _ in pairs(p97.treeShapeToTree) do
			if not entityExists(v109) then
				p97:onMissionTreeCut(v109)
			end
		end
	end
	TreeTransportMission:superClass().update(p97, p98)
	if not p97.isServer and p97.pendingTrees ~= nil then
		for v110 = #p97.pendingTrees, 1, -1 do
			local v111 = p97.pendingTrees[v110]
			local v112 = resolveStreamSplitShapeId(v111[1], v111[2])
			if v112 ~= 0 then
				table.remove(p97.pendingTrees, v110)
				local v113 = p97.trees
				table.insert(v113, v112)
			end
		end
		if #p97.pendingTrees == 0 then
			p97.pendingTrees = nil
		end
	end
	if p97.status == MissionStatus.RUNNING and (g_localPlayer ~= nil and (g_localPlayer.farmId == p97.farmId and not p97.isHotspotAdded)) then
		p97:addHotspots()
	end
end
function TreeTransportMission.tryToResolveSellingStation(p114)
	if p114.pendingSellingStationId ~= nil and p114.sellingStation == nil then
		local v115 = NetworkUtil.getObject(p114.pendingSellingStationId)
		if v115 ~= nil then
			p114:setSellingStation(v115)
		end
	end
end
function TreeTransportMission.setSellingStation(p116, p117)
	if p117 ~= nil then
		p116.pendingSellingStationId = nil
		p116.sellingStation = p117
		local v118 = p117.owningPlaceable
		if v118 ~= nil and v118.getHotspot ~= nil then
			local v119 = v118:getHotspot()
			if v119 ~= nil then
				p116.sellingStationMapHotspot = HarvestMissionHotspot.new()
				p116.sellingStationMapHotspot:setWorldPosition(v119:getWorldPosition())
				table.addElement(p116.mapHotspots, p116.sellingStationMapHotspot)
				if p116.addSellingStationHotSpot then
					g_currentMission:addMapHotspot(p116.sellingStationMapHotspot)
				end
			end
		end
	end
end
function TreeTransportMission.createTree(p120, p121, p122, p123, p124, p125, p126)
	local v127 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
	local v128 = g_treePlantManager:plantTree(v127.treeIndex, p121, p122, p123, p124, p125, p126, 1, 1, false, nil)
	if v128 == nil then
		return nil
	end
	local v129 = SplitShapeUtil.getSplitShapeId(v128)
	local v130 = TreeTransportMissionTree.new(p120.isServer, p120.isClient)
	v130:setNodeId(v129)
	v130:register()
	p120.treeShapeToTree[v129] = v130
	local v131 = p120.trees
	table.insert(v131, v129)
	return v128
end
function TreeTransportMission.deleteTrees(p132)
	for _, v133 in ipairs(p132.trees) do
		if entityExists(v133) then
			local v134 = getParent(v133)
			if entityExists(v134) then
				delete(v134)
			end
		end
	end
	for v135, _ in pairs(p132.cutSplitShapes) do
		if entityExists(v135) then
			delete(v135)
			p132.cutSplitShapes[v135] = nil
		end
	end
end
function TreeTransportMission.start(p136, p137)
	if p136.pendingSellingStationId ~= nil then
		p136:tryToResolveSellingStation()
	end
	if p136.sellingStation == nil then
		return false
	else
		p136.sellingStation.missions[p136] = p136
		if TreeTransportMission:superClass().start(p136, p137) then
			return p136:canSpawnTrees() and true or false
		else
			return false
		end
	end
end
function TreeTransportMission.prepare(p138, p139)
	TreeTransportMission:superClass().prepare(p138, p139)
	if p138.isServer then
		for v140 = 0, p138.numTrees - 1 do
			local v141 = getChildAt(p138.spot.node, v140)
			local v142, v143, v144 = getWorldTranslation(v141)
			local v145, v146, v147 = getWorldRotation(v141)
			p138:createTree(v142, v143, v144, v145, v146, v147)
		end
	end
end
function TreeTransportMission.finish(p148, p149)
	if p148.sellingStation ~= nil then
		p148.sellingStation.missions[p148] = nil
	end
	p148:removeHotspot()
	local v150 = g_currentMission
	if v150:getFarmId() == p148.farmId then
		if p149 == MissionFinishState.SUCCESS then
			v150:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, string.format(g_i18n:getText("contract_forestry_treeTransport_finished"), p148.farmlandId))
		elseif p149 == MissionFinishState.FAILED then
			v150:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("contract_forestry_treeTransport_failed"), p148.farmlandId))
		elseif p149 == MissionFinishState.TIMED_OUT then
			v150:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("contract_forestry_treeTransport_timedOut"), p148.farmlandId))
		end
	end
	TreeTransportMission:superClass().finish(p148, p149)
end
function TreeTransportMission.addHotspots(p151)
	if p151.mapHotspot ~= nil then
		p151.isHotspotAdded = true
		g_currentMission:addMapHotspot(p151.mapHotspot)
	end
	if p151.sellingStationMapHotspot ~= nil then
		g_currentMission:addMapHotspot(p151.sellingStationMapHotspot)
	end
	p151.addSellingStationHotSpot = true
end
function TreeTransportMission.removeHotspot(p152)
	if p152.mapHotspot ~= nil then
		g_currentMission:removeMapHotspot(p152.mapHotspot)
		p152.isHotspotAdded = false
	end
	if p152.sellingStationMapHotspot ~= nil then
		g_currentMission:removeMapHotspot(p152.sellingStationMapHotspot)
	end
	p152.addSellingStationHotSpot = false
end
function TreeTransportMission.onMissionTreeCut(p153, p154)
	local v155 = p153.treeShapeToTree[p154]
	if v155 ~= nil then
		v155:delete()
		p153.treeShapeToTree[p154] = nil
		p153.numDeletedTrees = p153.numDeletedTrees + 1
		g_currentMission:broadcastEventToFarm(TreeTransportMissionTreeCutEvent.new(), p153.farmId, true)
	end
end
function TreeTransportMission.onTreeShapeCut(p156, p157, p158)
	if p156.status == MissionStatus.RUNNING then
		if p156.isServer then
			if p156.treeShapeToTree[p157.shape] then
				p156:onMissionTreeCut(p157.shape)
				for _, v159 in ipairs(p158) do
					p156.cutSplitShapes[v159.shape] = true
				end
				return
			end
			if p156.cutSplitShapes[p157.shape] ~= nil then
				for _, v160 in ipairs(p158) do
					p156.cutSplitShapes[v160.shape] = true
				end
				return
			end
		end
	end
end
function TreeTransportMission.showCompletionNotification(p161)
	local v162 = string.format(g_i18n:getText("contract_forestry_treeTransport_completionNotification"), p161.farmlandId, p161.completion * 100)
	g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, v162)
end
function TreeTransportMission.validate(p163)
	local v164 = TreeTransportMission:superClass().validate(p163)
	if v164 then
		if g_farmlandManager:getFarmlandById(p163.farmlandId).isOwned then
			return false
		else
			return v164
		end
	else
		return false
	end
end
function TreeTransportMission.getLocation(p165)
	return string.format(g_i18n:getText("contract_farmland"), p165.farmlandId)
end
function TreeTransportMission.getMapHotspots(p166)
	return p166.mapHotspots
end
function TreeTransportMission.getWorldPosition(p167)
	local v168 = p167.spot
	if v168 == nil then
		return g_farmlandManager:getFarmlandById(p167.farmlandId):getIndicatorPosition()
	else
		return v168.x, v168.z
	end
end
function TreeTransportMission.getVehicleSize(p169)
	local v170 = p169.numTrees
	return v170 > 20 and "large" or (v170 >= 10 and "medium" or "small")
end
function TreeTransportMission.getDetails(p171)
	local v172 = TreeTransportMission:superClass().getDetails(p171)
	local v173 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
	local v174 = p171.numTrees - p171.numDeletedTrees
	local v175 = {
		["title"] = g_i18n:getText("contract_details_farmland"),
		["value"] = p171.farmlandId
	}
	table.insert(v172, v175)
	local v176 = nil
	if p171.pendingSellingStationId ~= nil then
		p171:tryToResolveSellingStation()
	end
	if p171.sellingStation ~= nil then
		v176 = p171.sellingStation:getName()
	end
	if v176 ~= nil then
		local v177 = {
			["title"] = g_i18n:getText("contract_forestry_details_sellingStation"),
			["value"] = v176
		}
		table.insert(v172, v177)
	end
	local v178 = {
		["title"] = g_i18n:getText("contract_forestry_details_rewardPerTree"),
		["value"] = g_i18n:formatMoney(v173.rewardPerTree, 0, true)
	}
	table.insert(v172, v178)
	local v179 = {
		["title"] = g_i18n:getText("contract_forestry_details_penaltyPerTree"),
		["value"] = g_i18n:formatMoney(v173.penaltyPerTree, 0, true)
	}
	table.insert(v172, v179)
	local v180 = {
		["title"] = g_i18n:getText("contract_forestry_details_totalNumTrees"),
		["value"] = v174
	}
	table.insert(v172, v180)
	if p171.status ~= MissionStatus.CREATED then
		local v181 = {
			["title"] = g_i18n:getText("contract_forestry_treeTransport_details_deliveredNumTrees"),
			["value"] = p171.numDeliveredTrees
		}
		table.insert(v172, v181)
	end
	return v172
end
function TreeTransportMission.getNPC(p182)
	local v183 = g_farmlandManager:getFarmlandById(p182.farmlandId)
	return g_npcManager:getNPCByIndex(v183.npcIndex)
end
function TreeTransportMission.getExtraProgressText(p184)
	local v185 = p184.numTrees - (p184.numDeliveredTrees + p184.numDeletedTrees)
	local v186 = math.max(0, v185)
	return string.format(g_i18n:getText("contract_forestry_treeTransport_remainingTrees"), v186)
end
function TreeTransportMission.getCompletion(p187)
	return p187.numTrees <= 0 and 1 or (p187.numDeliveredTrees + p187.numDeletedTrees) / p187.numTrees
end
function TreeTransportMission.getReward(p188)
	return p188.reward
end
function TreeTransportMission.getFarmlandId(p189)
	return p189.farmlandId
end
function TreeTransportMission.calculateStealingCost(p190)
	local v191 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
	return p190.numDeletedTrees * v191.penaltyPerTree
end
function TreeTransportMission.dismiss(p192)
	if p192.isServer then
		local v193 = (p192.finishState ~= MissionFinishState.SUCCESS and 0 or p192:getReward()) - p192:calculateStealingCost()
		if v193 ~= 0 then
			g_currentMission:addMoney(v193, p192.farmId, MoneyType.MISSIONS, true, true)
		end
	end
end
function TreeTransportMission.getIsShapeCutAllowed(p194, p195, _, _, _)
	if p194.status == MissionStatus.CREATED or p194.treeShapeToTree[p195] == nil then
		return nil
	else
		return false
	end
end
function TreeTransportMission.onTriggerProcessedWood(p196, p197, p198, _, _)
	if not p196.isServer then
		return
	end
	if p196.treeShapeToTree[p198] == nil then
		return
	end
	if p196.pendingSellingStationId ~= nil then
		p196:tryToResolveSellingStation()
	end
	local v199 = false
	if p196.sellingStation ~= nil then
		local v200 = p197:getTarget()
		while v200 ~= nil do
			if v200 == p196.sellingStation then
				v199 = true
				break
			end
			if v200.getTarget == nil then
				break
			end
			v200 = v200:getTarget()
		end
	end
	if v199 then
		p196.numDeliveredTrees = p196.numDeliveredTrees + 1
	else
		g_currentMission:broadcastEventToFarm(TreeTransportMissionWrongSellingStationEvent.new(), p196.farmId, true)
		p196.numDeletedTrees = p196.numDeletedTrees + 1
	end
	p196.treeShapeToTree[p198]:delete()
	p196.treeShapeToTree[p198] = nil
end
function TreeTransportMission.getIsMissionSplitShape(p201, p202)
	if p202 == nil or p202 == 0 then
		return false
	elseif p201.status == MissionStatus.RUNNING then
		return p201.treeShapeToTree[p202] ~= nil
	else
		return false
	end
end
function TreeTransportMission.canSpawnTrees(p203)
	local v204 = p203.spot
	local v205 = v204.sizeX * 0.5
	local v206 = v204.sizeY * 0.5
	local v207 = v204.sizeZ * 0.5
	local v208, v209, v210 = localToWorld(v204.node, v205 - 0.15, v206 - 0.15, v207 - 0.15)
	local v211, v212, v213 = getWorldRotation(v204.node)
	local v214 = CollisionFlag.VEHICLE + CollisionFlag.PLAYER + CollisionFlag.DYNAMIC_OBJECT
	p203.hasCollision = false
	overlapBox(v208, v209, v210, v211, v212, v213, v205 + 0.15, v206 + 0.15, v207 + 0.15, "onSpotCollision", p203, v214, true, true, true, true)
	return not p203.hasCollision
end
function TreeTransportMission.onSpotCollision(p215, p216)
	if p216 ~= g_terrainNode and not getHasTrigger(p216) then
		p215.hasCollision = true
	end
end
function TreeTransportMission.getMissionTypeName(_)
	return TreeTransportMission.NAME
end
function TreeTransportMission.loadMapData(p217, p218, p219)
	if p217:hasProperty(p218) then
		local v220 = p217:getString(p218 .. "#treeType")
		local v221 = g_treePlantManager:getTreeTypeDescFromName(v220)
		if v221 == nil then
			Logging.xmlWarning(p217, "Missing or undefined treeType \'%s\' for treeTransport mission (%s)!", v220, p218)
			return false
		end
		local v222 = p217:getString(p218 .. ".spots#filename")
		if v222 == nil then
			Logging.xmlWarning(p217, "Missing spot definition file for treeTransport mission (%s)", p218)
			return false
		end
		local v223 = Utils.getFilename(v222, p219)
		local v224 = g_i3DManager:loadI3DFile(v223, false, false)
		if v224 == 0 then
			return false
		end
		local v225 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
		v225.spots = {}
		v225.activeMissions = {}
		v225.treeIndex = v221.index
		v225.maxNumInstances = p217:getInt(p218 .. "#maxNumInstances") or 1
		v225.rewardPerTree = p217:getFloat(p218 .. "#rewardPerTree") or 550
		v225.penaltyPerTree = p217:getFloat(p218 .. "#penaltyPerTree") or 2000
		local v226 = getChildAt(v224, 0)
		link(getRootNode(), v226)
		for v227 = 0, getNumOfChildren(v226) - 1 do
			local v228 = getChildAt(v226, v227)
			local v229, v230, v231 = getTranslation(v228)
			local v232 = g_farmlandManager:getFarmlandIdAtWorldPosition(v229, v231)
			local v233
			if v232 == nil then
				v233 = false
			else
				v233 = v232 ~= FarmlandManager.NOT_BUYABLE_FARM_ID
			end
			if v233 then
				local v234 = getTerrainHeightAtWorldPos(g_terrainNode, v229, v230, v231)
				local v235 = getUserAttribute
				local v236 = tonumber(v235(v228, "sizeX")) or 1
				local v237 = getUserAttribute
				local v238 = tonumber(v237(v228, "sizeY")) or 1
				local v239 = getUserAttribute
				local v240 = tonumber(v239(v228, "sizeZ")) or 1
				local v241 = {
					["node"] = v228,
					["index"] = #v225.spots + 1,
					["x"] = v229,
					["y"] = v234,
					["z"] = v231,
					["isInUse"] = false,
					["farmlandId"] = v232,
					["sizeX"] = v236,
					["sizeY"] = v238,
					["sizeZ"] = v240
				}
				local v242 = v225.spots
				table.insert(v242, v241)
			else
				local v243 = v232 ~= FarmlandManager.NOT_BUYABLE_FARM_ID and "Not defined" or string.format("Not buyable (%d)", v232)
				Logging.xmlWarning(p217, "Invalid farmland \'%s\' found for tree transport mission spot \'%s\' at %d %d!", v243, getName(v228), v229, v231)
			end
		end
		v225.spotRoot = v226
		delete(v224)
		return true
	end
end
function TreeTransportMission.unloadMapData()
	local v244 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
	if v244.spotRoot ~= nil then
		delete(v244.spotRoot)
	end
end
function TreeTransportMission.loadMetaDataFromXMLFile(p245, p246)
	g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME).nextMissionDay = p245:getValue(p246 .. "#nextDay")
end
function TreeTransportMission.saveMetaDataToXMLFile(p247, p248)
	local v249 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
	if v249.nextMissionDay ~= nil then
		p247:setValue(p248 .. "#nextDay", v249.nextMissionDay)
	end
end
function TreeTransportMission.getSellPointWithHighestPrice()
	local v250 = 0
	local v251 = nil
	for _, v252 in pairs(g_currentMission.storageSystem:getUnloadingStations()) do
		local v253 = v252.owningPlaceable
		local v254 = v252.isSellingPoint
		local v255 = v252.allowMissions
		if v253 ~= nil and (v254 and (v255 and v252.acceptedFillTypes[FillType.WOOD])) then
			local v256 = false
			for _, v257 in ipairs(v252.unloadTriggers) do
				if v257:isa(WoodUnloadTrigger) then
					v256 = true
					break
				end
			end
			if v256 then
				local v258 = v252:getEffectiveFillTypePrice(FillType.WOOD)
				if v250 < v258 then
					v251 = v252
					v250 = v258
				end
			end
		end
	end
	return v251, v250
end
function TreeTransportMission.tryGenerateMission()
	if TreeTransportMission.canRun() then
		local v259 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
		local v260 = v259.spots
		Utils.shuffle(v260)
		local v261 = {}
		for _, v262 in ipairs(v259.activeMissions) do
			v261[v262.spot.farmlandId] = true
		end
		local v263 = nil
		for _, v264 in ipairs(v260) do
			if not v264.isInUse and (v261[v264.farmlandId] == nil and g_farmlandManager:getFarmlandOwner(v264.farmlandId) == FarmlandManager.NO_OWNER_FARM_ID) then
				v263 = v264
				break
			end
		end
		if not v263 then
			return
		end
		local v265, _ = TreeTransportMission.getSellPointWithHighestPrice()
		if v265 == nil then
			return
		end
		local v266 = TreeTransportMission.new(true, g_client ~= nil)
		if v266:init(v263, v265) then
			v266:setEndDate(g_currentMission.environment.currentMonotonicDay + 2, MathUtil.hoursToMs(math.random(10, 18)))
			return v266
		end
		v266:delete()
	end
	return nil
end
function TreeTransportMission.canRun()
	local v267 = g_missionManager:getMissionTypeDataByName(TreeTransportMission.NAME)
	if v267.spots == nil then
		return false
	elseif #v267.spots == 0 then
		return false
	elseif v267.treeIndex == nil then
		return false
	elseif v267.numInstances >= v267.maxNumInstances then
		return false
	else
		return v267.nextMissionDay == nil or g_currentMission.environment.currentMonotonicDay >= v267.nextMissionDay
	end
end
g_missionManager:registerMissionType(TreeTransportMission, TreeTransportMission.NAME, 1)

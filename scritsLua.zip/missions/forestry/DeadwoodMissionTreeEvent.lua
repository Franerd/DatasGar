DeadwoodMissionTreeEvent = {}
local v_u_1 = Class(DeadwoodMissionTreeEvent, Event)
InitStaticEventClass(DeadwoodMissionTreeEvent, "DeadwoodMissionTreeEvent")
function DeadwoodMissionTreeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function DeadwoodMissionTreeEvent.new(p2)
	local v3 = DeadwoodMissionTreeEvent.emptyNew()
	v3.mission = p2
	return v3
end
function DeadwoodMissionTreeEvent.readStream(p4, p5, _)
	p4.mission = NetworkUtil.readNodeObject(p5)
	p4.mission:readDeadTreesStream(p5)
	p4.mission:raiseActive()
end
function DeadwoodMissionTreeEvent.writeStream(p6, p7, p8)
	local v9 = not p8:getIsServer()
	assert(v9, "DeadwoodMissionTreeEvent is a server to client event")
	NetworkUtil.writeNodeObject(p7, p6.mission)
	p6.mission:writeDeadTreesStream(p7)
end

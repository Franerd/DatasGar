TreeTransportMissionTreeCutEvent = {}
local v_u_1 = Class(TreeTransportMissionTreeCutEvent, Event)
InitStaticEventClass(TreeTransportMissionTreeCutEvent, "TreeTransportMissionTreeCutEvent")
function TreeTransportMissionTreeCutEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TreeTransportMissionTreeCutEvent.new()
	return TreeTransportMissionTreeCutEvent.emptyNew()
end
function TreeTransportMissionTreeCutEvent.readStream(p2, _, p3)
	p2:run(p3)
end
function TreeTransportMissionTreeCutEvent.writeStream(_, _, _) end
function TreeTransportMissionTreeCutEvent.run(_, _)
	g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, g_i18n:getText("ingameNotification_treeTransportCutWarning"))
end

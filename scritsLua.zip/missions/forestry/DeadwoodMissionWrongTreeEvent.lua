DeadwoodMissionWrongTreeEvent = {}
local v_u_1 = Class(DeadwoodMissionWrongTreeEvent, Event)
InitStaticEventClass(DeadwoodMissionWrongTreeEvent, "DeadwoodMissionWrongTreeEvent")
function DeadwoodMissionWrongTreeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function DeadwoodMissionWrongTreeEvent.new()
	return DeadwoodMissionWrongTreeEvent.emptyNew()
end
function DeadwoodMissionWrongTreeEvent.readStream(p2, _, p3)
	p2:run(p3)
end
function DeadwoodMissionWrongTreeEvent.writeStream(_, _, _) end
function DeadwoodMissionWrongTreeEvent.run(_, _)
	g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, g_i18n:getText("ingameNotification_wrongMissionTreeCutDown"))
end

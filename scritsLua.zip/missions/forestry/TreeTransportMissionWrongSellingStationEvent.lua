TreeTransportMissionWrongSellingStationEvent = {}
local v_u_1 = Class(TreeTransportMissionWrongSellingStationEvent, Event)
InitStaticEventClass(TreeTransportMissionWrongSellingStationEvent, "TreeTransportMissionWrongSellingStationEvent")
function TreeTransportMissionWrongSellingStationEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TreeTransportMissionWrongSellingStationEvent.new()
	return TreeTransportMissionWrongSellingStationEvent.emptyNew()
end
function TreeTransportMissionWrongSellingStationEvent.readStream(p2, _, p3)
	p2:run(p3)
end
function TreeTransportMissionWrongSellingStationEvent.writeStream(_, _, _) end
function TreeTransportMissionWrongSellingStationEvent.run(_, _)
	g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, g_i18n:getText("ingameNotification_treeTransportWrongSellingStationWarning"))
end

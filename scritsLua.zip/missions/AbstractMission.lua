AbstractMission = {}
local v_u_1 = Class(AbstractMission, Object)
InitStaticObjectClass(AbstractMission, "AbstractMission")
AbstractMission.SUCCESS_FACTOR = 0.98
AbstractMission.VEHICLE_USE_COST = 200
AbstractMission.REIMBURSEMENT_FACTOR = 0.95
AbstractMission.NOTIFICATION_DELAY = 60000
function AbstractMission.registerXMLPaths(_, _) end
function AbstractMission.registerSavegameXMLPaths(p2, p3)
	p2:register(XMLValueType.STRING, p3 .. "#uniqueId", "Mission unique id")
	MissionStatus.registerXMLPath(p2, p3 .. "#status", "Status of the mission", nil, false)
	MissionFinishState.registerXMLPath(p2, p3 .. "#finishState", "Finish state of the mission", nil, false)
	p2:register(XMLValueType.INT, p3 .. "#farmId", "FarmId of the mission")
	p2:register(XMLValueType.INT, p3 .. "#activeId", "Name active id")
	p2:register(XMLValueType.INT, p3 .. ".info#reward", "Reward of the mission")
	p2:register(XMLValueType.FLOAT, p3 .. ".info#reimbursement", "Reimbursement of the mission")
	p2:register(XMLValueType.FLOAT, p3 .. ".info#stealingCost", "Stealing costs")
	p2:register(XMLValueType.FLOAT, p3 .. ".info#completion", "Completion factor of the mission")
	p2:register(XMLValueType.INT, p3 .. ".vehicles#group", "Vehicle group id")
	p2:register(XMLValueType.BOOL, p3 .. ".vehicles#spawned", "If vehicles were spawned")
	p2:register(XMLValueType.STRING, p3 .. ".vehicles.vehicle(?)#uniqueId", "Vehicle unique id")
	p2:register(XMLValueType.INT, p3 .. ".endDate#endDay", "End day of the mission")
	p2:register(XMLValueType.INT, p3 .. ".endDate#endDayTime", "End daytime of the mission")
end
function AbstractMission.registerMetaXMLPaths(_, _) end
function AbstractMission.new(p4, p5, p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = Object.new(p4, p5, p8 or v_u_1)
	v9.title = p6
	v9.progressTitle = p6
	v9.description = p7
	v9.status = MissionStatus.CREATED
	v9.finishState = MissionFinishState.NONE
	v9.reward = 0
	v9.reimbursement = 0
	v9.completion = 0
	v9.notificationTimer = 0
	v9.lastNotificationCompletion = 0
	v9.vehicles = {}
	v9.info = {}
	v9.spawnedVehicles = false
	v9.uniqueId = nil
	v9.missionDirtyFlag = v9:getNextDirtyFlag()
	g_messageCenter:subscribe(MessageType.FARM_DELETED, v9.farmDestroyed, v9)
	g_messageCenter:subscribe(MessageType.SAVEGAME_LOADED, v9.onSavegameLoaded, v9, nil, false)
	local v10 = g_missionManager:getMissionTypeDataByName(v9:getMissionTypeName())
	v10.numInstances = v10.numInstances + 1
	return v9
end
function AbstractMission.init(p11)
	local v12, v13 = p11:getVehicleGroup()
	p11.vehiclesToLoad = v12
	p11.vehicleGroupIdentifier = v13
	return true
end
function AbstractMission.onSavegameLoaded(p14)
	if p14.status == MissionStatus.RUNNING or p14.status == MissionStatus.PREPARING then
		p14:reactivate()
	end
end
function AbstractMission.reactivate(p15)
	if p15.spawnedVehicles then
		g_messageCenter:subscribe(MessageType.VEHICLE_RESET, p15.onVehicleReset, p15)
	end
end
function AbstractMission.getMapHotspots(_)
	return nil
end
function AbstractMission.delete(p16)
	AbstractMission:superClass().delete(p16)
	p16:removeAccess()
	g_messageCenter:unsubscribeAll(p16)
	g_messageCenter:publish(MessageType.MISSION_DELETED, p16)
	g_missionManager:removeMission(p16)
	local v17 = g_missionManager:getMissionTypeDataByName(p16:getMissionTypeName())
	if v17 ~= nil then
		local v18 = v17.numInstances - 1
		v17.numInstances = math.max(v18, 0)
	end
end
function AbstractMission.saveToXMLFile(p19, p20, p21)
	p20:setValue(p21 .. "#uniqueId", p19.uniqueId)
	MissionStatus.saveToXMLFile(p20, p21 .. "#status", p19.status)
	MissionFinishState.saveToXMLFile(p20, p21 .. "#finishState", p19.finishState)
	if p19.farmId ~= nil then
		p20:setValue(p21 .. "#farmId", p19.farmId)
	end
	if p19.activeMissionId ~= nil then
		p20:setValue(p21 .. "#activeId", p19.activeMissionId)
	end
	p20:setValue(p21 .. ".info#reward", p19.reward)
	p20:setValue(p21 .. ".info#reimbursement", p19.reimbursement)
	p20:setValue(p21 .. ".info#completion", p19.completion)
	if p19.stealingCost ~= nil then
		p20:setValue(p21 .. ".info#stealingCost", p19.stealingCost)
	end
	p20:setValue(p21 .. ".vehicles#spawned", p19.spawnedVehicles)
	p20:setValue(p21 .. ".vehicles#group", p19.vehicleGroupIdentifier)
	for v22, v23 in ipairs(p19.vehicles) do
		p20:setValue(string.format(p21 .. ".vehicles.vehicle(%d)#uniqueId", v22 - 1), v23.uniqueId)
	end
	if p19.endDate ~= nil then
		p20:setValue(p21 .. ".endDate#endDay", p19.endDate.endDay)
		p20:setValue(p21 .. ".endDate#endDayTime", p19.endDate.endDayTime)
	end
end
function AbstractMission.loadFromXMLFile(p24, p25, p26)
	p24.activeMissionId = p25:getValue(p26 .. "#activeId")
	p24.status = MissionStatus.loadFromXMLFile(p25, p26 .. "#status")
	if p24.status == nil then
		Logging.xmlError(p25, "Invalid mission status for \'%s\'", p26)
		return false
	end
	p24.finishState = MissionFinishState.loadFromXMLFile(p25, p26 .. "#finishState") or MissionFinishState.NONE
	local v27 = p25:getValue(p26 .. "#uniqueId", nil)
	if v27 ~= nil then
		p24:setUniqueId(v27)
	end
	p24.farmId = p25:getValue(p26 .. "#farmId")
	p24.reward = p25:getValue(p26 .. ".info#reward") or p24.reward
	p24.reimbursement = p25:getValue(p26 .. ".info#reimbursement") or p24.reimbursement
	p24.completion = p25:getValue(p26 .. ".info#completion") or p24.completion
	p24.stealingCost = p25:getValue(p26 .. ".info#stealingCost")
	local v28 = p25:getValue(p26 .. ".endDate#endDay")
	local v29 = p25:getValue(p26 .. ".endDate#endDayTime")
	if v28 ~= nil and v29 ~= nil then
		p24:setEndDate(v28, v29)
	end
	p24.spawnedVehicles = p25:getValue(p26 .. ".vehicles#spawned", p24.spawnedVehicles)
	p24.vehicleGroupIdentifier = p25:getValue(p26 .. ".vehicles#group")
	p24.vehiclesToLoad = p24:getVehicleGroupFromIdentifier(p24.vehicleGroupIdentifier)
	if p24.spawnedVehicles then
		p24.tryToAddMissingVehicles = true
	end
	for _, v30 in p25:iterator(p26 .. ".vehicles.vehicle") do
		local v31 = p25:getValue(v30 .. "#uniqueId")
		if p24.pendingVehicleUniqueIds == nil then
			p24.pendingVehicleUniqueIds = {}
		end
		local v32 = p24.pendingVehicleUniqueIds
		table.insert(v32, v31)
	end
	return true
end
function AbstractMission.writeStream(p33, p34, p35)
	AbstractMission:superClass().writeStream(p33, p34, p35)
	streamWriteUInt8(p34, p33.type.typeId)
	streamWriteFloat32(p34, p33.reward)
	streamWriteFloat32(p34, p33.reimbursement)
	MissionStatus.writeStream(p34, p33.status)
	streamWriteBool(p34, p33.spawnedVehicles)
	streamWriteInt32(p34, p33.vehicleGroupIdentifier)
	if p33.status == MissionStatus.RUNNING or p33.status == MissionStatus.PREPARING then
		streamWriteUIntN(p34, p33.farmId, FarmManager.FARM_ID_SEND_NUM_BITS)
		streamWriteInt32(p34, p33.activeMissionId)
	elseif p33.status == MissionStatus.FINISHED then
		streamWriteFloat32(p34, p33.stealingCost or 0)
		MissionFinishState.writeStream(p34, p33.finishState)
	end
end
function AbstractMission.readStream(p36, p37, p38)
	AbstractMission:superClass().readStream(p36, p37, p38)
	p36.type = g_missionManager:getMissionTypeById(streamReadUInt8(p37))
	p36.reward = streamReadFloat32(p37)
	p36.reimbursement = streamReadFloat32(p37)
	p36.status = MissionStatus.readStream(p37)
	p36.spawnedVehicles = streamReadBool(p37)
	p36.vehicleGroupIdentifier = streamReadInt32(p37)
	p36.vehiclesToLoad = p36:getVehicleGroupFromIdentifier(p36.vehicleGroupIdentifier)
	if p36.status == MissionStatus.RUNNING or p36.status == MissionStatus.PREPARING then
		p36.farmId = streamReadUIntN(p37, FarmManager.FARM_ID_SEND_NUM_BITS)
		p36.activeMissionId = streamReadInt32(p37)
	elseif p36.status == MissionStatus.FINISHED then
		p36.stealingCost = streamReadFloat32(p37)
		p36.finishState = MissionFinishState.readStream(p37)
	end
	g_missionManager:assignGenerationTime(p36)
	local v39 = g_missionManager.missions
	table.insert(v39, p36)
	g_messageCenter:publishDelayed(MessageType.MISSION_GENERATED, p36)
end
function AbstractMission.writeUpdateStream(p40, p41, _, _)
	MissionStatus.writeStream(p41, p40.status)
	streamWriteFloat32(p41, p40.completion)
end
function AbstractMission.readUpdateStream(p42, p43, _, _)
	p42.status = MissionStatus.readStream(p43)
	p42.completion = streamReadFloat32(p43)
end
function AbstractMission.update(p44, p45)
	local v46 = g_currentMission
	if p44.pendingVehicleUniqueIds ~= nil then
		for v47 = #p44.pendingVehicleUniqueIds, 1, -1 do
			local v48 = p44.pendingVehicleUniqueIds[v47]
			local v49 = v46.vehicleSystem:getVehicleByUniqueId(v48)
			if v49 ~= nil then
				table.remove(p44.pendingVehicleUniqueIds, v47)
				local v50 = p44.vehicles
				table.insert(v50, v49)
			end
		end
		if #p44.pendingVehicleUniqueIds == 0 then
			p44.pendingVehicleUniqueIds = nil
		end
	end
	if p44.tryToAddMissingVehicles and p44.pendingVehicleUniqueIds == nil then
		if #p44.vehicles ~= #p44.vehiclesToLoad then
			for _, v51 in ipairs(p44.vehiclesToLoad) do
				local v52 = false
				for _, v53 in ipairs(p44.vehicles) do
					if v51.filename == v53.configFileName then
						v52 = true
						break
					end
				end
				if not v52 then
					p44:spawnVehicle(v51)
				end
			end
		end
		p44.tryToAddMissingVehicles = false
	end
	if p44.isServer and (p44.status == MissionStatus.PREPARING and p44:getIsPrepared()) then
		p44:finishedPreparing()
	end
	if p44.status == MissionStatus.RUNNING then
		if p44.isServer then
			if p44:isTimedOut() then
				p44:finish(MissionFinishState.TIMED_OUT)
			elseif not p44:validate() then
				p44:finish(MissionFinishState.FAILED)
			end
		end
		p44:updateCompletionNotification(p45)
		if p44.progressBar == nil then
			p44.progressBar = v46.hud:addSideNotificationProgressBar(g_i18n:getText("contract_title"), p44.progressTitle, p44.completion)
		end
		p44.progressBar.progress = p44.completion
		if g_localPlayer ~= nil and g_localPlayer.farmId == p44.farmId then
			v46.hud:markSideNotificationProgressBarForDrawing(p44.progressBar)
		end
	end
	if p44.status == MissionStatus.RUNNING or p44.status == MissionStatus.PREPARING then
		p44:raiseActive()
	end
end
function AbstractMission.updateTick(p54, _)
	if p54.isServer and p54.status == MissionStatus.RUNNING then
		local v55 = g_currentMission
		if p54.lastCompletion == nil then
			p54.lastCompletion = v55.time
		elseif p54.lastCompletion < v55.time - 2500 then
			p54.completion = p54:getCompletion()
			if p54.completion >= 0.995 then
				p54:finish(MissionFinishState.SUCCESS)
			end
		end
		if p54.lastCompletion ~= p54.completion then
			p54:raiseDirtyFlags(p54.missionDirtyFlag)
		end
	end
end
function AbstractMission.updateCompletionNotification(p56, p57)
	p56.notificationTimer = p56.notificationTimer + p57
	if p56.completion > p56.lastNotificationCompletion + 0.1 and p56.notificationTimer > AbstractMission.NOTIFICATION_DELAY then
		p56.notificationTimer = 0
		p56.lastNotificationCompletion = p56.completion
		local v58 = g_currentMission
		if p56.farmId == v58:getFarmId() then
			p56:showCompletionNotification(p56.completion)
		end
	end
end
function AbstractMission.showCompletionNotification(_) end
function AbstractMission.start(p59, p60)
	p59:prepare(p60)
	p59:raiseActive()
	g_server:broadcastEvent(MissionStartedEvent.new(p59))
	return true
end
function AbstractMission.prepare(p61, p62)
	p61.status = MissionStatus.PREPARING
	if p61.isServer and (p62 and p61.vehiclesToLoad ~= nil) then
		p61:spawnVehicles()
		g_messageCenter:subscribe(MessageType.VEHICLE_RESET, p61.onVehicleReset, p61)
	end
end
function AbstractMission.getIsPrepared(p63)
	return not p63.spawnedVehicles and true or #p63.vehiclesToLoad == #p63.vehicles
end
function AbstractMission.finishedPreparing(p64)
	p64.status = MissionStatus.RUNNING
end
function AbstractMission.started(_) end
function AbstractMission.finish(p65, p66)
	p65.status = MissionStatus.FINISHED
	p65.finishState = p66
	if p66 ~= MissionFinishState.SUCCESS then
		p65:removeAccess()
	end
	local v67 = g_currentMission
	if v67:getIsServer() then
		if p66 == MissionFinishState.SUCCESS then
			g_farmManager:getFarmById(p65.farmId).stats:updateMissionDone()
		end
		p65.stealingCost = p65:calculateStealingCost()
		g_server:broadcastEvent(MissionFinishedEvent.new(p65, p66, p65.stealingCost))
	end
	v67.hud:removeSideNotificationProgressBar(p65.progressBar)
	g_messageCenter:publish(MissionFinishedEvent, p65, p66)
end
function AbstractMission.dismiss(p68)
	p68.status = MissionStatus.DISMISSED
	if p68.finishState == MissionFinishState.SUCCESS then
		p68:removeAccess()
	end
	if p68.isServer then
		local v69 = p68:getTotalReward()
		if v69 ~= 0 then
			g_currentMission:addMoney(v69, p68.farmId, MoneyType.MISSIONS, true, true)
		end
	end
end
function AbstractMission.calculateStealingCost(_)
	return 0
end
function AbstractMission.getUniqueId(p70)
	return p70.uniqueId
end
function AbstractMission.setUniqueId(p71, p72)
	p71.uniqueId = p72
end
function AbstractMission.spawnVehicles(p73)
	for _, v74 in ipairs(p73.vehiclesToLoad) do
		p73:spawnVehicle(v74)
	end
	p73.spawnedVehicles = #p73.vehiclesToLoad > 0
end
function AbstractMission.spawnVehicle(p75, p76)
	local v77 = VehicleLoadingData.new()
	v77:setFilename(p76.filename)
	if v77.isValid then
		if p76.configurations ~= nil then
			v77:setConfigurations(p76.configurations)
		end
		local v78 = g_currentMission
		v77:setLoadingPlace(v78.storeSpawnPlaces, v78.usedStorePlaces)
		v77:setPropertyState(VehiclePropertyState.MISSION)
		v77:setOwnerFarmId(p75.farmId)
		v77:load(p75.onSpawnedVehicle, p75, nil)
	end
end
function AbstractMission.onSpawnedVehicle(p79, p80, p81, _)
	if p81 == VehicleLoadingState.OK then
		for _, v82 in ipairs(p80) do
			v82:addWearAmount(math.random() * 0.3 + 0.1)
			v82:setOperatingTime(3600000 * (math.random() * 40 + 30))
			local v83 = p79.vehicles
			table.insert(v83, v82)
		end
	else
		for _, v84 in ipairs(p80) do
			v84:delete()
		end
	end
end
function AbstractMission.getStealingCosts(_)
	return 0
end
function AbstractMission.getVehicleCosts(p85)
	if p85.vehiclesToLoad == nil then
		return 0
	end
	local v86 = #p85.vehiclesToLoad
	local v87 = 0.7 + 0.3 * g_currentMission.missionInfo.economicDifficulty
	return v86 * AbstractMission.VEHICLE_USE_COST * v87
end
function AbstractMission.getReward(_)
	return 0
end
function AbstractMission.getReimbursement(p88)
	return p88.reimbursement
end
function AbstractMission.calculateReimbursement(_) end
function AbstractMission.getActualVehicleCosts(p89)
	return not p89.spawnedVehicles and 0 or p89:getVehicleCosts()
end
function AbstractMission.getActualReward(p90)
	return p90.finishState ~= MissionFinishState.SUCCESS and 0 or p90:getReward()
end
function AbstractMission.getActualStealingCosts(p91)
	return p91:getStealingCosts()
end
function AbstractMission.getTotalReward(p92)
	local v93 = p92:getActualReward()
	local v94 = p92:getActualVehicleCosts()
	local v95 = p92:getActualStealingCosts()
	local v96 = p92:getReimbursement()
	return v93 - v94 - v95 + v96
end
function AbstractMission.validate(p97, _)
	return not p97:isTimedOut()
end
function AbstractMission.isTimedOut(p98)
	local v99 = p98:getMinutesLeft()
	if v99 == nil then
		return false
	else
		return v99 <= 0
	end
end
function AbstractMission.getMinutesLeft(p100)
	local v101 = p100.endDate
	if v101 == nil then
		return nil
	end
	local v102 = g_currentMission.environment
	local v103 = v102.currentMonotonicDay
	local v104 = v102.dayTime
	local v105 = 86400000
	local v106 = v101.endDay
	local v107 = v101.endDayTime
	local v108 = 0
	if v104 < v107 then
		v108 = v107 - v104
	elseif v103 < v106 then
		v108 = v104 + (v105 - v107)
		v103 = v103 + 1
	end
	return (v108 + (v106 - v103) * 86400000) / 60000
end
function AbstractMission.setDefaultEndDate(p109)
	local v110 = g_currentMission.environment
	local v111 = v110.currentMonotonicDay
	p109:setEndDate(v111 + (v110.daysPerPeriod - v110:getDayInPeriodFromDay(v111)), 86399999)
end
function AbstractMission.setEndDateByOffset(p112, p113)
	local v114 = g_currentMission.environment
	local v115, v116 = v114:getDayAndDayTime(p113, v114.currentMonotonicDay)
	p112:setEndDate(v115, v116)
end
function AbstractMission.setEndDate(p117, p118, p119)
	p117.endDate = {
		["endDay"] = p118,
		["endDayTime"] = p119
	}
end
function AbstractMission.getIsInProgress(p120)
	return p120.status == MissionStatus.PREPARING and true or p120.status == MissionStatus.RUNNING
end
function AbstractMission.getIsRunning(p121)
	return p121.status == MissionStatus.RUNNING
end
function AbstractMission.getIsReadyToStart(p122)
	return p122.status == MissionStatus.CREATED
end
function AbstractMission.getWasStarted(p123)
	return p123.status ~= MissionStatus.CREATED
end
function AbstractMission.getIsFinished(p124)
	return p124.status == MissionStatus.FINISHED
end
function AbstractMission.getInfo(p125)
	return p125.info
end
function AbstractMission.getLocation(_)
	return ""
end
function AbstractMission.getDescription(p126)
	return p126.description
end
function AbstractMission.getDetails(p127)
	local v128 = {}
	if not p127:getWasStarted() or p127.spawnedVehicles then
		local v129 = {
			["title"] = g_i18n:getText("contract_vehicleCosts"),
			["value"] = g_i18n:formatMoney(p127:getVehicleCosts(), 0, true, true)
		}
		table.insert(v128, v129)
	end
	return v128
end
function AbstractMission.getFinishedDetails(p130)
	local v131 = {}
	local v132 = {
		["title"] = g_i18n:getText("contract_reward"),
		["value"] = g_i18n:formatMoney(p130:getActualReward(), 0, true, true)
	}
	table.insert(v131, v132)
	local v133 = {
		["title"] = g_i18n:getText("contract_reimbursement"),
		["value"] = g_i18n:formatMoney(p130:getReimbursement(), 0, true, true)
	}
	table.insert(v131, v133)
	local v134 = {
		["title"] = g_i18n:getText("contract_vehicleCosts"),
		["value"] = g_i18n:formatMoney(-p130:getActualVehicleCosts(), 0, true, true)
	}
	table.insert(v131, v134)
	local v135 = {
		["title"] = g_i18n:getText("contract_stealing"),
		["value"] = g_i18n:formatMoney(-p130:getActualStealingCosts(), 0, true, true)
	}
	table.insert(v131, v135)
	return v131
end
function AbstractMission.getTitle(p136)
	return p136.title
end
function AbstractMission.getNPC(_)
	return nil
end
function AbstractMission.getExtraProgressText(_)
	return ""
end
function AbstractMission.getCompletion(_)
	return 0
end
function AbstractMission.farmDestroyed(p137, p138)
	if p138 == p137.farmId then
		g_missionManager:markMissionForDeletion(p137)
	end
end
function AbstractMission.getMissionTypeName(_)
	return nil
end
function AbstractMission.onVehicleReset(p139, p140, p141)
	if p139.isServer and table.removeElement(p139.vehicles, p140) then
		table.addElement(p139.vehicles, p141)
	end
end
function AbstractMission.getVehicleSize(_)
	return "small"
end
function AbstractMission.getVehicleGroupFromIdentifier(p142, p143)
	return g_missionManager:getVehicleGroupFromIdentifier(p142.type.name, p142:getVehicleSize(), p143)
end
function AbstractMission.getVehicleGroup(p144)
	return g_missionManager:getRandomVehicleGroup(p144:getMissionTypeName(), p144:getVehicleSize(), p144:getVehicleVariant())
end
function AbstractMission.getVehicleVariant(_)
	return nil
end
function AbstractMission.getVariant(_)
	return nil
end
function AbstractMission.removeAccess(p145)
	if p145.isServer then
		p145:calculateReimbursement()
		for _, v146 in ipairs(p145.vehicles) do
			if not v146:getIsBeingDeleted() then
				v146:delete()
			end
		end
		p145.vehicles = {}
	end
end
function AbstractMission.hasLeasableVehicles(p147)
	return p147.vehiclesToLoad ~= nil
end
function AbstractMission.isSpawnSpaceAvailable(p148)
	local v149 = g_currentMission
	local v150 = v149.storeSpawnPlaces
	local v151 = v149.usedStorePlaces
	local v152 = {}
	local v153 = true
	for _, v154 in ipairs(p148.vehiclesToLoad) do
		local v155 = g_storeManager:getItemByXMLFilename(v154.filename)
		local v156 = StoreItemUtil.getSizeValues(v154.filename, "vehicle", v155.rotation, v154.configurations)
		local v157, _, _, v158, v159, _ = PlacementUtil.getPlace(v150, v156, v151)
		if v157 == nil then
			v153 = false
			break
		end
		PlacementUtil.markPlaceUsed(v151, v158, v159)
		table.insert(v152, v158)
	end
	for _, v160 in ipairs(v152) do
		PlacementUtil.unmarkPlaceUsed(v151, v160)
	end
	return v153
end
function AbstractMission.getIsWorkAllowed(_, _, _, _, _, _)
	return true
end
function AbstractMission.getWorldPosition(_)
	return 0, 0
end
function AbstractMission.loadMapData(_, _) end
function AbstractMission.unloadMapData() end
function AbstractMission.tryGenerateMission() end
function AbstractMission.canRun() end

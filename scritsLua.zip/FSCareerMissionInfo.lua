FSCareerMissionInfo = {}
local v_u_1 = Class(FSCareerMissionInfo, MissionInfo)
FSCareerMissionInfo.SavegameRevision = 2
if GS_PLATFORM_PLAYSTATION then
	FSCareerMissionInfo.MaxSavegameSize = 52428800
else
	FSCareerMissionInfo.MaxSavegameSize = 26214400
end
function FSCareerMissionInfo.new(p2, p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = FSCareerMissionInfo:superClass().new(p2, p3, p5 or v_u_1)
	v6.savegameIndex = p4
	v6.savegameDirectory = v6:getSavegameDirectory(v6.savegameIndex)
	v6.displayName = g_i18n:getText("ui_savegame") .. " " .. v6.savegameIndex
	v6.xmlKey = "careerSavegame"
	v6.tipTypeMappings = {}
	return v6
end
function FSCareerMissionInfo.delete(p7)
	if p7.xmlFile ~= nil then
		delete(p7.xmlFile)
	end
end
function FSCareerMissionInfo.loadDefaults(p8)
	FSCareerMissionInfo:superClass().loadDefaults(p8)
	p8.supportsSaving = true
	p8.isValid = false
	p8.initialLoan = 0
	p8.initialMoney = 100000
	p8.money = nil
	p8.economicDifficulty = EconomicDifficulty.NORMAL
	p8.hasInitiallyOwnedFarmlands = true
	p8.loadDefaultFarm = true
	p8.startWithGuidedTour = true
	p8.playTime = 0
	p8.isInvalidUser = false
	p8.isCorruptFile = false
	p8.savegameName = g_i18n:getText("defaultSavegameName")
	p8.saveDateFormatted = "--/--/--"
	p8.creationDate = getDate("%Y-%m-%d")
	p8.saveDate = nil
	p8.mapId = nil
	p8.stopAndGoBraking = true
	p8.trailerFillLimit = false
	p8.fruitDestruction = true
	p8.automaticMotorStartEnabled = true
	p8.isSnowEnabled = Platform.gameplay.supportSnow
	p8.growthMode = Platform.gameplay.supportSeasonalGrowth and GrowthSystem.MODE.SEASONAL or GrowthSystem.MODE.DAILY
	p8.fixedSeasonalVisuals = nil
	p8.helperBuyFuel = true
	p8.helperBuySeeds = true
	p8.helperBuyFertilizer = true
	p8.helperSlurrySource = 2
	p8.helperManureSource = 2
	p8.plowingRequiredEnabled = Utils.getNoNil(Platform.gameplay.defaultPlowingRequiredEnabled, false)
	p8.stonesEnabled = true
	p8.autoSaveInterval = AutoSaveManager.DEFAULT_INTERVAL
	p8.trafficEnabled = true
	p8.introductionHelpShownElements = ""
	p8.introductionHelpShownHints = ""
	p8.introductionHelpActive = false
	p8.disasterDestructionState = DisasterDestructionState.ENABLED
	p8.slotUsage = 0
	p8.plannedDaysPerPeriod = 1
	p8.timeScale = Platform.gameplay.defaultTimeScale
	p8.timeScaleMultiplier = 1
	p8.dirtInterval = 3
	p8.weedsEnabled = true
	p8.limeRequired = true
	p8.fuelUsage = 2
	p8.foundHelpIcons = "00000000000000000000"
	p8.vehiclesXML = nil
	p8.itemsXML = nil
	p8.placeablesXML = nil
	p8.handToolsXML = nil
	p8.aiSystemXML = nil
	p8.onCreateObjectsXML = nil
	p8.environmentXML = nil
	p8.vehicleSaleXML = nil
	p8.economyXML = nil
	p8.farmlandXML = nil
	p8.npcXML = nil
	p8.missionsXML = nil
	p8.guidedTourXML = nil
	p8.fieldsXML = nil
	p8.destructibleMapObjectsXML = nil
	p8.farmsXML = nil
	p8.treeMarkerXML = nil
	p8.playersXML = nil
	p8.densityMapHeightXML = nil
	p8.treePlantXML = nil
	p8.navigationSystemXML = nil
	p8.densityMapRevision = -1
	p8.terrainTextureRevision = -1
	p8.terrainLodTextureRevision = -1
	p8.splitShapesRevision = -1
	p8.tipCollisionRevision = -1
	p8.placementCollisionRevision = -1
	p8.navigationCollisionRevision = -1
	p8.mapDensityMapRevision = 1
	p8.mapTerrainTextureRevision = 1
	p8.mapTerrainLodTextureRevision = 1
	p8.mapSplitShapesRevision = 1
	p8.mapTipCollisionRevision = 1
	p8.mapPlacementCollisionRevision = 1
	p8.mapNavigationCollisionRevision = 1
	p8.tipTypeMappings = {}
	p8.mods = {}
end
function FSCareerMissionInfo.loadFromXML(p9, p10)
	local v11 = p9.xmlKey
	if getXMLInt(p10, v11 .. "#revision") ~= FSCareerMissionInfo.SavegameRevision then
		return false
	end
	p9.isValid = getXMLBool(p10, v11 .. "#valid")
	if p9.isValid == nil then
		return false
	end
	if p9.isValid then
		local v12 = getXMLString(p10, v11 .. ".settings.mapId")
		if v12 == nil then
			return false
		end
		p9.mapTitle = getXMLString(p10, v11 .. ".settings.mapTitle")
		p9:setMapId(v12)
		p9.isInvalidUser = false
		p9.savegameName = Utils.getNoNil(getXMLString(p10, v11 .. ".settings.savegameName"), p9.savegameName)
		p9.creationDate = Utils.getNoNil(getXMLString(p10, v11 .. ".settings.creationDate"), p9.creationDate)
		p9.economicDifficulty = EconomicDifficulty.loadFromXMLFile(p10, v11 .. ".settings.economicDifficulty") or p9.economicDifficulty
		p9.initialLoan = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.initialLoan"), p9.initialLoan)
		p9.initialMoney = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.initialMoney"), p9.initialMoney)
		p9.hasInitiallyOwnedFarmlands = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.hasInitiallyOwnedFarmlands"), p9.hasInitiallyOwnedFarmlands)
		p9.loadDefaultFarm = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.loadDefaultFarm"), p9.loadDefaultFarm)
		p9.startWithGuidedTour = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.startWithGuidedTour"), p9.startWithGuidedTour)
		p9.densityMapRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.densityMapRevision"), p9.densityMapRevision)
		p9.terrainTextureRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.terrainTextureRevision"), p9.terrainTextureRevision)
		p9.terrainLodTextureRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.terrainLodTextureRevision"), p9.terrainLodTextureRevision)
		p9.splitShapesRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.splitShapesRevision"), p9.splitShapesRevision)
		p9.tipCollisionRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.tipCollisionRevision"), p9.tipCollisionRevision)
		p9.placementCollisionRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.placementCollisionRevision"), p9.placementCollisionRevision)
		p9.navigationCollisionRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.navigationCollisionRevision"), p9.navigationCollisionRevision)
		p9.mapDensityMapRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.mapDensityMapRevision"), p9.mapDensityMapRevision)
		p9.mapTerrainTextureRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.mapTerrainTextureRevision"), p9.mapTerrainTextureRevision)
		p9.mapTerrainLodTextureRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.mapTerrainLodTextureRevision"), p9.mapTerrainLodTextureRevision)
		p9.mapSplitShapesRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.mapSplitShapesRevision"), p9.mapSplitShapesRevision)
		p9.mapTipCollisionRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.mapTipCollisionRevision"), p9.mapTipCollisionRevision)
		p9.mapPlacementCollisionRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.mapPlacementCollisionRevision"), p9.mapPlacementCollisionRevision)
		p9.mapNavigationCollisionRevision = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.mapNavigationCollisionRevision"), p9.mapNavigationCollisionRevision)
		p9.stopAndGoBraking = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.stopAndGoBraking"), p9.stopAndGoBraking)
		p9.trailerFillLimit = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.trailerFillLimit"), p9.trailerFillLimit)
		p9.fruitDestruction = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.fruitDestruction"), p9.fruitDestruction)
		p9.plowingRequiredEnabled = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.plowingRequiredEnabled"), p9.plowingRequiredEnabled)
		p9.stonesEnabled = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.stonesEnabled"), p9.stonesEnabled)
		p9.weedsEnabled = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.weedsEnabled"), p9.weedsEnabled)
		p9.limeRequired = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.limeRequired"), p9.limeRequired)
		p9.automaticMotorStartEnabled = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.automaticMotorStartEnabled"), p9.automaticMotorStartEnabled)
		p9.fuelUsage = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.fuelUsage"), p9.fuelUsage)
		p9.helperBuyFuel = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.helperBuyFuel"), p9.helperBuyFuel)
		p9.helperBuySeeds = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.helperBuySeeds"), p9.helperBuySeeds)
		p9.helperBuyFertilizer = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.helperBuyFertilizer"), p9.helperBuyFertilizer)
		p9.helperSlurrySource = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.helperSlurrySource"), p9.helperSlurrySource)
		p9.helperManureSource = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.helperManureSource"), p9.helperManureSource)
		p9.saveDate = Utils.getNoNil(getXMLString(p10, v11 .. ".settings.saveDate"), nil)
		p9.saveDateFormatted = Utils.getNoNil(getXMLString(p10, v11 .. ".settings.saveDateFormatted"), p9.saveDate)
		p9.timeScale = Utils.getNoNil(getXMLFloat(p10, v11 .. ".settings.timeScale"), Platform.gameplay.defaultTimeScale)
		p9.trafficEnabled = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.trafficEnabled"), p9.trafficEnabled)
		p9.dirtInterval = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.dirtInterval"), p9.dirtInterval)
		p9.growthMode = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.growthMode"), p9.growthMode)
		p9.isSnowEnabled = Utils.getNoNil(getXMLBool(p10, v11 .. ".settings.isSnowEnabled"), p9.isSnowEnabled)
		p9.fixedSeasonalVisuals = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.fixedSeasonalVisuals"), p9.fixedSeasonalVisuals)
		p9.plannedDaysPerPeriod = Utils.getNoNil(getXMLInt(p10, v11 .. ".settings.plannedDaysPerPeriod"), p9.plannedDaysPerPeriod)
		p9.autoSaveInterval = Utils.getNoNil(getXMLFloat(p10, v11 .. ".settings.autoSaveInterval"), p9.autoSaveInterval)
		p9.foundHelpIcons = Utils.getNoNil(getXMLString(p10, v11 .. ".map.foundHelpIcons"), p9.foundHelpIcons)
		p9.playTime = Utils.getNoNil(getXMLFloat(p10, v11 .. ".statistics.playTime"), p9.playTime)
		local v13 = Utils.getNoNil
		local v14 = getXMLString
		local v15 = v11 .. ".statistics.money"
		p9.money = v13(tonumber(v14(p10, v15)), p9.money)
		p9.slotUsage = Utils.getNoNil(getXMLInt(p10, v11 .. ".slotSystem#slotUsage"), p9.slotUsage)
		p9.disasterDestructionState = DisasterDestructionState.loadFromXMLFile(p10, v11 .. ".settings.disasterDestructionState") or p9.disasterDestructionState
		p9.introductionHelpActive = Utils.getNoNil(getXMLBool(p10, v11 .. ".introductionHelp#active"), p9.introductionHelpActive)
		p9.introductionHelpShownElements = Utils.getNoNil(getXMLString(p10, v11 .. ".introductionHelp.shownElements"), p9.introductionHelpShownElements)
		p9.introductionHelpShownHints = Utils.getNoNil(getXMLString(p10, v11 .. ".introductionHelp.shownHints"), p9.introductionHelpShownHints)
		p9.mapsSplitShapeFileIds = {}
		for v16 = 1, Utils.getNoNil(getXMLInt(p10, v11 .. ".mapsSplitShapeFileIds#count"), 0) do
			local v17 = string.format("%s.mapsSplitShapeFileIds.id(%d)", v11, v16 - 1)
			local v18 = Utils.getNoNil(getXMLInt(p10, v17 .. "#id"), -1)
			local v19 = p9.mapsSplitShapeFileIds
			table.insert(v19, v18)
		end
		local v20
		if p9.mapId == nil then
			v20 = nil
		else
			v20 = p9.mapId:split(".")
		end
		p9.foliageTypes = {}
		local v21 = 0
		while true do
			local v22 = string.format("careerSavegame.foliageTypes.foliageType(%d)", v21)
			if not hasXMLProperty(p10, v22) then
				break
			end
			local v23 = getXMLString(p10, v22 .. "#name")
			local v24 = getXMLString(p10, v22 .. "#filename")
			if v23 ~= nil and v24 ~= nil then
				local v25 = NetworkUtil.convertFromNetworkFilename(v24)
				local v26 = p9.foliageTypes
				table.insert(v26, {
					["name"] = v23,
					["filename"] = v25
				})
			end
			v21 = v21 + 1
		end
		p9.mods = {}
		local v27 = 0
		while true do
			local v28 = v11 .. string.format(".mod(%d)", v27)
			if not hasXMLProperty(p10, v28) then
				break
			end
			local v29 = getXMLString(p10, v28 .. "#modName")
			local v30 = getXMLString(p10, v28 .. "#title")
			local v31 = getXMLString(p10, v28 .. "#version")
			local v32 = getXMLString(p10, v28 .. "#fileHash")
			local v33 = Utils.getNoNil(getXMLBool(p10, v28 .. "#required"), true)
			if v29 ~= nil and v30 ~= nil then
				local v34 = p9.mods
				table.insert(v34, {
					["modName"] = v29,
					["title"] = v30,
					["version"] = v31,
					["fileHash"] = v32,
					["required"] = v33
				})
			end
			if p9.mapTitle == nil and (v20 ~= nil and (#v20 == 2 and v29 == v20[1])) then
				p9.mapTitle = v30 .. " - " .. v20[2]
			end
			v27 = v27 + 1
		end
	end
	return true
end
function FSCareerMissionInfo.saveToXMLFile(p35)
	if p35.xmlFile ~= nil then
		delete(p35.xmlFile)
	end
	local v36 = createXMLFile("careerSavegameXML", "", "careerSavegame")
	if v36 == 0 then
		Logging.error("Failed to create careerSavegame xml file")
	else
		p35.xmlFile = v36
		local v37 = p35.xmlKey
		setXMLInt(v36, v37 .. "#revision", FSCareerMissionInfo.SavegameRevision)
		setXMLBool(v36, v37 .. "#valid", p35.isValid)
		if p35.isValid then
			setXMLString(v36, v37 .. ".settings.savegameName", p35.savegameName)
			setXMLString(v36, v37 .. ".settings.creationDate", p35.creationDate)
			setXMLString(v36, v37 .. ".settings.mapId", p35.mapId)
			setXMLString(v36, v37 .. ".settings.mapTitle", p35.map.title)
			setXMLString(v36, v37 .. ".settings.saveDateFormatted", p35.saveDateFormatted)
			setXMLString(v36, v37 .. ".settings.saveDate", p35.saveDate)
			setXMLInt(v36, v37 .. ".settings.initialMoney", p35.initialMoney)
			setXMLInt(v36, v37 .. ".settings.initialLoan", p35.initialLoan)
			EconomicDifficulty.saveToXMLFile(v36, v37 .. ".settings.economicDifficulty", p35.economicDifficulty)
			setXMLBool(v36, v37 .. ".settings.hasInitiallyOwnedFarmlands", p35.hasInitiallyOwnedFarmlands)
			setXMLBool(v36, v37 .. ".settings.loadDefaultFarm", p35.loadDefaultFarm)
			setXMLBool(v36, v37 .. ".settings.startWithGuidedTour", p35.startWithGuidedTour)
			setXMLBool(v36, v37 .. ".settings.trafficEnabled", p35.trafficEnabled)
			setXMLBool(v36, v37 .. ".settings.stopAndGoBraking", p35.stopAndGoBraking)
			setXMLBool(v36, v37 .. ".settings.trailerFillLimit", p35.trailerFillLimit)
			setXMLBool(v36, v37 .. ".settings.automaticMotorStartEnabled", p35.automaticMotorStartEnabled)
			setXMLInt(v36, v37 .. ".settings.growthMode", p35.growthMode)
			if p35.fixedSeasonalVisuals ~= nil then
				setXMLInt(v36, v37 .. ".settings.fixedSeasonalVisuals", p35.fixedSeasonalVisuals)
			end
			setXMLInt(v36, v37 .. ".settings.plannedDaysPerPeriod", p35.plannedDaysPerPeriod)
			setXMLBool(v36, v37 .. ".settings.fruitDestruction", p35.fruitDestruction)
			setXMLBool(v36, v37 .. ".settings.plowingRequiredEnabled", p35.plowingRequiredEnabled)
			setXMLBool(v36, v37 .. ".settings.stonesEnabled", p35.stonesEnabled)
			setXMLBool(v36, v37 .. ".settings.weedsEnabled", p35.weedsEnabled)
			setXMLBool(v36, v37 .. ".settings.limeRequired", p35.limeRequired)
			setXMLBool(v36, v37 .. ".settings.isSnowEnabled", p35.isSnowEnabled)
			setXMLInt(v36, v37 .. ".settings.fuelUsage", p35.fuelUsage)
			setXMLBool(v36, v37 .. ".settings.helperBuyFuel", p35.helperBuyFuel)
			setXMLBool(v36, v37 .. ".settings.helperBuySeeds", p35.helperBuySeeds)
			setXMLBool(v36, v37 .. ".settings.helperBuyFertilizer", p35.helperBuyFertilizer)
			setXMLInt(v36, v37 .. ".settings.helperSlurrySource", p35.helperSlurrySource)
			setXMLInt(v36, v37 .. ".settings.helperManureSource", p35.helperManureSource)
			setXMLInt(v36, v37 .. ".settings.densityMapRevision", p35.densityMapRevision)
			setXMLInt(v36, v37 .. ".settings.terrainTextureRevision", p35.terrainTextureRevision)
			setXMLInt(v36, v37 .. ".settings.terrainLodTextureRevision", p35.terrainLodTextureRevision)
			setXMLInt(v36, v37 .. ".settings.splitShapesRevision", p35.splitShapesRevision)
			setXMLInt(v36, v37 .. ".settings.tipCollisionRevision", p35.tipCollisionRevision)
			setXMLInt(v36, v37 .. ".settings.placementCollisionRevision", p35.placementCollisionRevision)
			setXMLInt(v36, v37 .. ".settings.navigationCollisionRevision", p35.navigationCollisionRevision)
			setXMLInt(v36, v37 .. ".settings.mapDensityMapRevision", p35.mapDensityMapRevision)
			setXMLInt(v36, v37 .. ".settings.mapTerrainTextureRevision", p35.mapTerrainTextureRevision)
			setXMLInt(v36, v37 .. ".settings.mapTerrainLodTextureRevision", p35.mapTerrainLodTextureRevision)
			setXMLInt(v36, v37 .. ".settings.mapSplitShapesRevision", p35.mapSplitShapesRevision)
			setXMLInt(v36, v37 .. ".settings.mapTipCollisionRevision", p35.mapTipCollisionRevision)
			setXMLInt(v36, v37 .. ".settings.mapPlacementCollisionRevision", p35.mapPlacementCollisionRevision)
			setXMLInt(v36, v37 .. ".settings.mapNavigationCollisionRevision", p35.mapNavigationCollisionRevision)
			DisasterDestructionState.saveToXMLFile(v36, v37 .. ".settings.disasterDestructionState", p35.disasterDestructionState)
			setXMLInt(v36, v37 .. ".settings.dirtInterval", p35.dirtInterval)
			setXMLFloat(v36, v37 .. ".settings.timeScale", p35.timeScale)
			setXMLFloat(v36, v37 .. ".settings.autoSaveInterval", g_autoSaveManager:getInterval())
			setXMLString(v36, v37 .. ".map.foundHelpIcons", p35.foundHelpIcons)
			setXMLBool(v36, v37 .. ".introductionHelp#active", p35.introductionHelpActive)
			setXMLString(v36, v37 .. ".introductionHelp.shownElements", p35.introductionHelpShownElements)
			setXMLString(v36, v37 .. ".introductionHelp.shownHints", p35.introductionHelpShownHints)
			local v38 = 0
			local v39 = 0
			for _, v40 in ipairs(g_farmManager.farms) do
				if not v40.isSpectator then
					v38 = v38 + v40.money
					local v41 = v40.stats
					v39 = math.max(v39, v41:getTotalValue("playTime"))
				end
			end
			local v42 = setXMLString
			local v43 = v37 .. ".statistics.money"
			local v44 = v38 + 0.0001
			local v45 = math.floor(v44)
			v42(v36, v43, (tostring(v45)))
			setXMLFloat(v36, v37 .. ".statistics.playTime", v39)
			setXMLInt(v36, v37 .. ".mapsSplitShapeFileIds#count", #p35.mapsSplitShapeFileIds)
			for v46, v47 in ipairs(p35.mapsSplitShapeFileIds) do
				setXMLInt(v36, string.format("%s.mapsSplitShapeFileIds.id(%d)", v37, v46 - 1) .. "#id", v47)
			end
			local v48 = {}
			local v49 = ClassUtil.getClassModName(p35.mapId)
			if v49 ~= nil then
				v48[v49] = v49
			end
			local v50 = g_currentMission
			if v50 ~= nil then
				v50.slotSystem:saveToXMLFile(v36, v37 .. ".slotSystem")
				v50.navigationSystem:saveToXMLFile(p35.navigationSystemXML)
				v50.collectiblesSystem:saveToXMLFile(p35.savegameDirectory .. "/collectibles.xml")
				local v51 = createXMLFile("environmentXMLFile", p35.environmentXML, "environment")
				if v51 == 0 then
					Logging.error("Failed to create environment xml file")
				else
					v50.environment:saveToXMLFile(v51, "environment")
					v50.snowSystem:saveToXMLFile(v51, "environment.snow")
					v50.growthSystem:saveToXMLFile(v51, "environment.growth")
					saveXMLFile(v51)
					delete(v51)
				end
				v50.placeableSystem:save(p35.placeablesXML, v48)
				v50.vehicleSystem:save(p35.vehiclesXML, v48)
				v50.handToolSystem:save(p35.handToolsXML, v48)
				v50.itemSystem:save(p35.itemsXML, v48)
				v50.aiSystem:save(p35.aiSystemXML, v48)
				v50.onCreateObjectSystem:save(p35.onCreateObjectsXML, v48)
				local v52 = createXMLFile("economyXML", p35.economyXML, "economy")
				if v52 == 0 then
					Logging.error("Failed to create economy xml file")
				else
					v50.economyManager:saveToXMLFile(v52, "economy")
					saveXMLFile(v52)
					delete(v52)
				end
				v50.playerSystem:saveToXMLFile(p35.playersXML)
				v50.vehicleSaleSystem:saveToXMLFile(p35.vehicleSaleXML)
				v50.foliageSystem:saveToXMLFile(v36)
				v50.treeMarkerSystem:saveToXMLFile(p35.treeMarkerXML)
				v50.destructibleMapObjectSystem:saveToXMLFile(p35.destructibleMapObjectsXML)
				for _, v53 in pairs(v50.missionDynamicInfo.mods) do
					v48[v53.modName] = v53.modName
				end
			end
			g_farmlandManager:saveToXMLFile(p35.farmlandXML)
			g_guidedTourManager:saveToXMLFile(p35.guidedTourXML)
			g_npcManager:saveToXMLFile(p35.npcXML)
			g_fieldManager:saveToXMLFile(p35.fieldsXML)
			g_missionManager:saveToXMLFile(p35.missionsXML)
			g_farmManager:saveToXMLFile(p35.farmsXML)
			g_densityMapHeightManager:saveToXMLFile(p35.densityMapHeightXML)
			g_treePlantManager:saveToXMLFile(p35.treePlantXML)
			local v54 = 0
			for v55, _ in pairs(v48) do
				local v56 = g_modManager:getModByName(v55)
				if v56 ~= nil then
					local v57 = v55 == v49
					setXMLString(v36, v37 .. string.format(".mod(%d)#modName", v54), v56.modName)
					setXMLString(v36, v37 .. string.format(".mod(%d)#title", v54), v56.title)
					setXMLString(v36, v37 .. string.format(".mod(%d)#version", v54), v56.version)
					setXMLBool(v36, v37 .. string.format(".mod(%d)#required", v54), v57)
					local v58 = setXMLString
					local v59 = v37 .. string.format(".mod(%d)#fileHash", v54)
					local v60 = v56.fileHash
					v58(v36, v59, (tostring(v60)))
					v54 = v54 + 1
				end
			end
			saveXMLFile(v36)
		end
	end
end
function FSCareerMissionInfo.loadFromMission(p61, p62)
	p61.mapDensityMapRevision = p62.mapDensityMapRevision
	p61.mapTerrainTextureRevision = p62.mapTerrainTextureRevision
	p61.mapTerrainLodTextureRevision = p62.mapTerrainLodTextureRevision
	p61.mapSplitShapesRevision = p62.mapSplitShapesRevision
	p61.mapTipCollisionRevision = p62.mapTipCollisionRevision
	p61.mapPlacementCollisionRevision = p62.mapPlacementCollisionRevision
	p61.mapNavigationCollisionRevision = p62.mapNavigationCollisionRevision
	p61.mapsSplitShapeFileIds = {}
	for _, v63 in ipairs(p62.mapsSplitShapeFileIds) do
		local v64 = p61.mapsSplitShapeFileIds
		table.insert(v64, v63)
	end
	p61.saveDate = getDate("%Y-%m-%d")
	p61.saveDateFormatted = g_i18n:getCurrentDate()
end
function FSCareerMissionInfo.setSavegameDirectory(p65, p66)
	p65.savegameDirectory = p66
	if p66 ~= nil then
		p65.vehiclesXML = p66 .. "/vehicles.xml"
		p65.itemsXML = p66 .. "/items.xml"
		p65.placeablesXML = p66 .. "/placeables.xml"
		p65.handToolsXML = p66 .. "/handTools.xml"
		p65.aiSystemXML = p66 .. "/aiSystem.xml"
		p65.onCreateObjectsXML = p66 .. "/onCreateObjects.xml"
		p65.environmentXML = p66 .. "/environment.xml"
		p65.vehicleSaleXML = p66 .. "/sales.xml"
		p65.economyXML = p66 .. "/economy.xml"
		p65.farmlandXML = p66 .. "/farmland.xml"
		p65.npcXML = p66 .. "/npc.xml"
		p65.missionsXML = p66 .. "/missions.xml"
		p65.fieldsXML = p66 .. "/fields.xml"
		p65.guidedTourXML = p66 .. "/guidedTour.xml"
		p65.farmsXML = p66 .. "/farms.xml"
		p65.destructibleMapObjectsXML = p66 .. "/destructibleMapObjectSystem.xml"
		p65.treeMarkerXML = p66 .. "/treeMarker.xml"
		p65.playersXML = p66 .. "/players.xml"
		p65.densityMapHeightXML = p66 .. "/densityMapHeight.xml"
		p65.treePlantXML = p66 .. "/treePlant.xml"
		p65.navigationSystemXML = p66 .. "/navigationSystem.xml"
	end
end
function FSCareerMissionInfo.getSavegameDirectory(_, p67)
	return getUserProfileAppPath() .. "savegame" .. p67
end
function FSCareerMissionInfo.getSavegameAutoBackupBasePath(_)
	return getUserProfileAppPath() .. "savegameBackup"
end
function FSCareerMissionInfo.getSavegameAutoBackupDirectoryBase(_, p68)
	return "savegame" .. p68 .. "_backup"
end
function FSCareerMissionInfo.getSavegameAutoBackupLatestFilename(_, p69)
	return "savegame" .. p69 .. "_backupLatest.txt"
end
function FSCareerMissionInfo.getStateI18NKey(p70)
	return p70.hasConflict and not p70.isSoftConflict and "savegame_state_conflicted" or (p70.uploadState == UploadState.UPLOADED and "savegame_state_uploaded" or (p70.uploadState == UploadState.NOT_UPLOADED and "savegame_state_not_uploaded" or (p70.uploadState == UploadState.UPLOADING and "savegame_state_uploading" or nil)))
end
function FSCareerMissionInfo.applyStartInfo(p71, p72)
	p71.initialLoan = p72.initialLoan
	p71.initialMoney = p72.initialMoney
	p71.economicDifficulty = p72.economicDifficulty
	p71.hasInitiallyOwnedFarmlands = p72.hasStartFarm
	p71.loadDefaultFarm = p72.hasStartFarm
	p71.startWithGuidedTour = p72.startWithGuidedTour
	p71:setMapId(p72.mapId)
end
function FSCareerMissionInfo.setMapId(p73, p74)
	p73.mapId = p74
	local v75 = g_mapManager:getMapById(p73.mapId)
	if v75 == nil then
		return false
	end
	p73.map = v75
	p73.mapTitle = v75.title
	p73.scriptFilename = v75.scriptFilename
	p73.scriptClass = v75.className
	p73.mapXMLFilename = v75.mapXMLFilename
	p73.defaultVehiclesXMLFilename = v75.defaultVehiclesXMLFilename
	p73.defaultHandToolsXMLFilename = v75.defaultHandToolsXMLFilename
	p73.defaultItemsXMLFilename = v75.defaultItemsXMLFilename
	p73.defaultPlaceablesXMLFilename = v75.defaultPlaceablesXMLFilename
	p73.customEnvironment = v75.customEnvironment
	p73.baseDirectory = v75.baseDirectory
	return true
end
function FSCareerMissionInfo.getIsDensityMapValid(p76, p77)
	local v78 = p76.isValid
	if v78 then
		if p76.densityMapRevision == g_densityMapRevision then
			v78 = p76.mapDensityMapRevision == p77.mapDensityMapRevision
		else
			v78 = false
		end
	end
	return v78
end
function FSCareerMissionInfo.getIsTerrainTextureValid(p79, p80)
	local v81 = p79.isValid
	if v81 then
		if p79.terrainTextureRevision == g_terrainTextureRevision then
			v81 = p79.mapTerrainTextureRevision == p80.mapTerrainTextureRevision
		else
			v81 = false
		end
	end
	return v81
end
function FSCareerMissionInfo.getIsTerrainLodTextureValid(p82, p83)
	local v84 = p82.isValid
	if v84 then
		if p82.terrainLodTextureRevision == g_terrainLodTextureRevision then
			v84 = p82.mapTerrainLodTextureRevision == p83.mapTerrainLodTextureRevision
		else
			v84 = false
		end
	end
	return v84
end
function FSCareerMissionInfo.getAreSplitShapesValid(p85, p86)
	local v87 = p85.isValid
	if v87 then
		if p85.splitShapesRevision == g_splitShapesRevision then
			v87 = p85.mapSplitShapesRevision == p86.mapSplitShapesRevision
		else
			v87 = false
		end
	end
	return v87
end
function FSCareerMissionInfo.getIsTipCollisionValid(p88, p89)
	local v90 = p88.isValid
	if v90 then
		if p88.tipCollisionRevision == g_tipCollisionRevision then
			v90 = p88.mapTipCollisionRevision == p89.mapTipCollisionRevision
		else
			v90 = false
		end
	end
	return v90
end
function FSCareerMissionInfo.getIsPlacementCollisionValid(p91, p92)
	local v93 = p91.isValid
	if v93 then
		if p91.placementCollisionRevision == g_placementCollisionRevision then
			v93 = p91.mapPlacementCollisionRevision == p92.mapPlacementCollisionRevision
		else
			v93 = false
		end
	end
	return v93
end
function FSCareerMissionInfo.getIsNavigationCollisionValid(p94, p95)
	local v96 = p94.isValid
	if v96 then
		if p94.navigationCollisionRevision == g_navigationCollisionRevision then
			v96 = p94.mapNavigationCollisionRevision == p95.mapNavigationCollisionRevision
		else
			v96 = false
		end
	end
	return v96
end
function FSCareerMissionInfo.getIsLoadedFromSavegame(p97)
	return p97.isValid
end
function FSCareerMissionInfo.getEffectiveTimeScale(p98)
	return p98.timeScale * (p98.timeScaleMultiplier or 1)
end

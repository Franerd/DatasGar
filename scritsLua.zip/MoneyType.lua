MoneyType = {}
local v_u_1 = 0
local v_u_2 = {}
local function v7(p3, p4, p5)
	-- upvalues: (ref) v_u_1, (copy) v_u_2
	v_u_1 = v_u_1 + 1
	local v6 = {
		["id"] = v_u_1,
		["statistic"] = p3,
		["title"] = p4,
		["customEnv"] = p5
	}
	v_u_2[v_u_1] = v6
	return v6
end
MoneyType.register = v7
local function v14(p8, p9, p10, p11)
	-- upvalues: (copy) v_u_2, (ref) v_u_1
	local v12 = v_u_2[p8]
	if v12 == nil then
		v12 = {
			["id"] = p8,
			["statistic"] = p9,
			["title"] = p10,
			["customEnv"] = p11
		}
		v_u_2[p8] = v12
	end
	local v13 = v_u_1
	v_u_1 = math.max(v13, p8)
	return v12
end
MoneyType.registerWithId = v14
function MoneyType.getMoneyTypeById(p15)
	-- upvalues: (copy) v_u_2
	return v_u_2[p15]
end
function MoneyType.getMoneyTypeByName(p16)
	if p16 == nil then
		return nil
	end
	local v17 = string.upper(p16)
	return MoneyType[v17]
end
local function v18()
	-- upvalues: (ref) v_u_1
	v_u_1 = MoneyType.LAST_ID
end
MoneyType.reset = v18
MoneyType.OTHER = MoneyType.register("other", "finance_other")
MoneyType.SHOP_VEHICLE_BUY = MoneyType.register("newVehiclesCost", "finance_newVehiclesCost")
MoneyType.SHOP_VEHICLE_SELL = MoneyType.register("soldVehicles", "finance_soldVehicles")
MoneyType.SHOP_PROPERTY_BUY = MoneyType.register("constructionCost", "finance_constructionCost")
MoneyType.SHOP_PROPERTY_SELL = MoneyType.register("soldBuildings", "finance_soldBuildings")
MoneyType.SHOP_HANDTOOL_BUY = MoneyType.register("newHandtoolsCost", "finance_newHandtoolsCost")
MoneyType.SHOP_HANDTOOL_SELL = MoneyType.register("soldHandtools", "finance_soldHandtools")
MoneyType.SOLD_MILK = MoneyType.register("soldMilk", "finance_soldMilk")
MoneyType.HARVEST_INCOME = MoneyType.register("harvestIncome", "finance_harvestIncome")
MoneyType.AI = MoneyType.register("wagePayment", "finance_wagePayment")
MoneyType.MISSIONS = MoneyType.register("missionIncome", "finance_missionIncome")
MoneyType.SOLD_ANIMALS = MoneyType.register("soldAnimals", "finance_soldAnimals")
MoneyType.NEW_ANIMALS_COST = MoneyType.register("newAnimalsCost", "finance_newAnimalsCost")
MoneyType.ANIMAL_UPKEEP = MoneyType.register("animalUpkeep", "finance_animalUpkeep")
MoneyType.PURCHASE_SEEDS = MoneyType.register("purchaseSeeds", "finance_purchaseSeeds")
MoneyType.PURCHASE_FERTILIZER = MoneyType.register("purchaseFertilizer", "finance_purchaseFertilizer")
MoneyType.PURCHASE_FUEL = MoneyType.register("purchaseFuel", "finance_purchaseFuel")
MoneyType.PURCHASE_SAPLINGS = MoneyType.register("purchaseSaplings", "finance_purchaseSaplings")
MoneyType.PURCHASE_WATER = MoneyType.register("purchaseWater", "finance_purchaseWater")
MoneyType.PURCHASE_BALES = MoneyType.register("purchaseBales", "finance_purchaseBales")
MoneyType.PURCHASE_PALLETS = MoneyType.register("purchasePallets", "finance_purchasePallets")
MoneyType.PURCHASE_CONSUMABLES = MoneyType.register("purchaseConsumable", "finance_purchaseConsumable")
MoneyType.FIELD_BUY = MoneyType.register("fieldPurchase", "finance_fieldPurchase")
MoneyType.FIELD_SELL = MoneyType.register("fieldSelling", "finance_fieldSelling")
MoneyType.LEASING_COSTS = MoneyType.register("vehicleLeasingCost", "finance_vehicleLeasingCost")
MoneyType.LOAN_INTEREST = MoneyType.register("loanInterest", "finance_loanInterest")
MoneyType.VEHICLE_RUNNING_COSTS = MoneyType.register("vehicleRunningCost", "finance_vehicleRunningCost")
MoneyType.VEHICLE_REPAIR = MoneyType.register("vehicleRunningCost", "finance_vehicleRunningCost")
MoneyType.PROPERTY_MAINTENANCE = MoneyType.register("propertyMaintenance", "finance_propertyMaintenance")
MoneyType.PROPERTY_INCOME = MoneyType.register("propertyIncome", "finance_propertyIncome")
MoneyType.LOAN = MoneyType.register("loan", "finance_other")
MoneyType.PRODUCTION_COSTS = MoneyType.register("productionCosts", "finance_productionCosts")
MoneyType.SOLD_PRODUCTS = MoneyType.register("soldProducts", "finance_soldProducts")
MoneyType.INCOME_BGA = MoneyType.register("incomeBga", "finance_incomeBga")
MoneyType.SOLD_WOOD = MoneyType.register("soldWood", "finance_soldWood")
MoneyType.SOLD_BALES = MoneyType.register("soldBales", "finance_soldBales")
MoneyType.BOUGHT_MATERIALS = MoneyType.register("expenses", "finance_other")
MoneyType.TRANSFER = MoneyType.register("other", "finance_transfer")
MoneyType.COLLECTIBLE = MoneyType.register("other", "finance_collectible")
MoneyType.LAST_ID = v_u_1

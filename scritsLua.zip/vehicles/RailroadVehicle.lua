RailroadVehicle = {}
local v_u_1 = Class(RailroadVehicle, Vehicle)
InitStaticObjectClass(RailroadVehicle, "RailroadVehicle")
function RailroadVehicle.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "setTrainSystem", RailroadVehicle.setTrainSystem)
	RailroadVehicle:superClass().registerFunctions(p2)
end
function RailroadVehicle.new(p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = Vehicle.new(p3, p4, p5 or v_u_1)
	v6.trainSystem = nil
	return v6
end
function RailroadVehicle.setTrainSystem(p7, p8)
	p7.trainSystem = p8
	p7.synchronizePosition = false
end
function RailroadVehicle.update(p9, ...)
	if p9.isServer and p9.trainSystem == nil then
		p9:delete()
	else
		RailroadVehicle:superClass().update(p9, ...)
	end
end

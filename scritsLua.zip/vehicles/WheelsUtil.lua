WheelsUtil = {}
WheelsUtil.GROUND_ROAD = 1
WheelsUtil.GROUND_HARD_TERRAIN = 2
WheelsUtil.GROUND_SOFT_TERRAIN = 3
WheelsUtil.GROUND_FIELD = 4
WheelsUtil.NUM_GROUNDS = 4
WheelsUtil.tireTypes = {}
function WheelsUtil.registerTireType(p1, p2, p3, p4)
	local v5 = p1:upper()
	if WheelsUtil.getTireType(v5) == nil then
		local function v10(p6)
			local v7 = {}
			if p6[1] == nil then
				v7[1] = 1.15
				for v8 = 2, WheelsUtil.NUM_GROUNDS do
					if p6[v8] ~= nil then
						v7[1] = p6[v8]
						break
					end
				end
			else
				v7[1] = p6[1]
			end
			for v9 = 2, WheelsUtil.NUM_GROUNDS do
				v7[v9] = p6[v9] or p6[v9 - 1]
			end
			return v7
		end
		local v11 = {
			["name"] = v5,
			["frictionCoeffs"] = v10(p2),
			["frictionCoeffsWet"] = v10(p3 or p2)
		}
		v11.frictionCoeffsSnow = v10(p4 or v11.frictionCoeffsWet)
		local v12 = WheelsUtil.tireTypes
		table.insert(v12, v11)
	else
		printWarning("Warning: Tire type \'" .. v5 .. "\' already registered, ignoring this definition")
	end
end
function WheelsUtil.unregisterTireType(p13)
	local v14 = p13:upper()
	for v15, v16 in ipairs(WheelsUtil.tireTypes) do
		if v16.name == v14 then
			table.remove(WheelsUtil.tireTypes, v15)
			return
		end
	end
end
function WheelsUtil.getTireType(p17)
	local v18 = p17:upper()
	for v19, v20 in pairs(WheelsUtil.tireTypes) do
		if v20.name == v18 then
			return v19
		end
	end
	return nil
end
function WheelsUtil.getTireTypeName(p21)
	return WheelsUtil.tireTypes[p21] == nil and "unknown" or WheelsUtil.tireTypes[p21].name
end
local v22 = {
	[WheelsUtil.GROUND_ROAD] = 1.15,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.1,
	[WheelsUtil.GROUND_FIELD] = 0.95
}
local v23 = {
	[WheelsUtil.GROUND_ROAD] = 1.05,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.05,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1,
	[WheelsUtil.GROUND_FIELD] = 0.7
}
local v24 = {
	[WheelsUtil.GROUND_ROAD] = 0.45,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 0.45,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 0.4,
	[WheelsUtil.GROUND_FIELD] = 0.35
}
WheelsUtil.registerTireType("mud", v22, v23, v24)
local v25 = {
	[WheelsUtil.GROUND_ROAD] = 1.2,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.05,
	[WheelsUtil.GROUND_FIELD] = 1
}
local v26 = {
	[WheelsUtil.GROUND_ROAD] = 1.05,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 0.95,
	[WheelsUtil.GROUND_FIELD] = 0.6
}
local v27 = {
	[WheelsUtil.GROUND_ROAD] = 0.45,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 0.4,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 0.35,
	[WheelsUtil.GROUND_FIELD] = 0.3
}
WheelsUtil.registerTireType("offRoad", v25, v26, v27)
local v28 = {
	[WheelsUtil.GROUND_ROAD] = 1.25,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1,
	[WheelsUtil.GROUND_FIELD] = 0.9
}
local v29 = {
	[WheelsUtil.GROUND_ROAD] = 1.15,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 0.85,
	[WheelsUtil.GROUND_FIELD] = 0.45
}
local v30 = {
	[WheelsUtil.GROUND_ROAD] = 0.55,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 0.4,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 0.3,
	[WheelsUtil.GROUND_FIELD] = 0.35
}
WheelsUtil.registerTireType("street", v28, v29, v30)
local v31 = {
	[WheelsUtil.GROUND_ROAD] = 1.15,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_FIELD] = 1.15
}
local v32 = {
	[WheelsUtil.GROUND_ROAD] = 1.05,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.05,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.05,
	[WheelsUtil.GROUND_FIELD] = 0.85
}
local v33 = {
	[WheelsUtil.GROUND_ROAD] = 0.65,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 0.65,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 0.65,
	[WheelsUtil.GROUND_FIELD] = 0.65
}
WheelsUtil.registerTireType("crawler", v31, v32, v33)
local v34 = {
	[WheelsUtil.GROUND_ROAD] = 1.15,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_FIELD] = 1.15
}
local v35 = {
	[WheelsUtil.GROUND_ROAD] = 1.05,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.05,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.05,
	[WheelsUtil.GROUND_FIELD] = 0.95
}
local v36 = {
	[WheelsUtil.GROUND_ROAD] = 1.05,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.05,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.05,
	[WheelsUtil.GROUND_FIELD] = 1.05
}
WheelsUtil.registerTireType("chains", v34, v35, v36)
local v37 = {
	[WheelsUtil.GROUND_ROAD] = 1.15,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_FIELD] = 1.15
}
local v38 = {
	[WheelsUtil.GROUND_ROAD] = 1.15,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_FIELD] = 1.15
}
local v39 = {
	[WheelsUtil.GROUND_ROAD] = 1.15,
	[WheelsUtil.GROUND_HARD_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_SOFT_TERRAIN] = 1.15,
	[WheelsUtil.GROUND_FIELD] = 1.15
}
WheelsUtil.registerTireType("metalSpikes", v37, v38, v39)
local v_u_40 = 0.002
function WheelsUtil.getSmoothedAcceleratorAndBrakePedals(p41, p42, p43, p44)
	-- upvalues: (copy) v_u_40
	if p41.wheelsUtilSmoothedAcceleratorPedal == nil then
		p41.wheelsUtilSmoothedAcceleratorPedal = 0
	end
	local v45 = 0
	if p42 > 0 then
		if p41.wheelsUtilSmoothedAcceleratorPedal < p42 then
			local v46 = p41.wheelsUtilSmoothedAcceleratorPedal + 0.002 * p44
			local v47 = math.max(v46, 0.002)
			v45 = math.min(v47, p42)
		else
			v45 = p42
		end
		p41.wheelsUtilSmoothedAcceleratorPedal = v45
	elseif p42 < 0 then
		if p42 < p41.wheelsUtilSmoothedAcceleratorPedal then
			local v48 = p41.wheelsUtilSmoothedAcceleratorPedal - 0.002 * p44
			local v49 = math.min(v48, -0.002)
			v45 = math.max(v49, p42)
		else
			v45 = p42
		end
		p41.wheelsUtilSmoothedAcceleratorPedal = v45
	else
		local v50 = 0.0005 + 0.001 * p43
		if p41.wheelsUtilSmoothedAcceleratorPedal > 0 then
			local v51 = p41.wheelsUtilSmoothedAcceleratorPedal - v50 * p44
			p41.wheelsUtilSmoothedAcceleratorPedal = math.max(v51, 0)
		else
			local v52 = p41.wheelsUtilSmoothedAcceleratorPedal + v50 * p44
			p41.wheelsUtilSmoothedAcceleratorPedal = math.min(v52, 0)
		end
	end
	if p41.wheelsUtilSmoothedBrakePedal == nil then
		p41.wheelsUtilSmoothedBrakePedal = 0
	end
	local v53 = 0
	if p43 > 0 then
		if p41.wheelsUtilSmoothedBrakePedal < p43 then
			local v54 = p41.wheelsUtilSmoothedBrakePedal + 0.0025 * p44
			p43 = math.min(v54, p43)
		end
		p41.wheelsUtilSmoothedBrakePedal = p43
		return v45, p43
	end
	local v55 = 0.0005 + 0.001 * p42
	local v56 = p41.wheelsUtilSmoothedBrakePedal - v55 * p44
	p41.wheelsUtilSmoothedBrakePedal = math.max(v56, 0)
	return v45, v53
end
function WheelsUtil.updateWheelsPhysics(p57, p58, p59, p60, p61, p62)
	local v63 = 0
	local v64 = 0
	local v65 = p57.spec_drivable == nil and 1 or p57.spec_drivable.reverserDirection
	local v66 = p57.spec_motorized.motor
	local v67 = v66.backwardGears ~= nil and true or v66.forwardGears ~= nil
	local v68 = v67 and v66.gearShiftMode ~= VehicleMotor.SHIFT_MODE_AUTOMATIC and true or v66.directionChangeMode == VehicleMotor.DIRECTION_CHANGE_MODE_MANUAL
	if v68 then
		v68 = p57:getIsManualDirectionChangeAllowed()
	end
	local v69
	if v68 then
		v69 = p60 * v66.currentDirection
	else
		v69 = p60 * v65
	end
	local v70 = math.abs(p59)
	local v71 = math.sign(v69)
	p57.nextMovingDirection = p57.nextMovingDirection or 0
	p57.nextMovingDirectionTimer = p57.nextMovingDirectionTimer or 0
	local v72 = false
	if math.abs(v69) < 0.001 then
		v72 = true
		if p62 or p59 * p57.nextMovingDirection < 0.0003 then
			p57.nextMovingDirection = 0
		end
	else
		if p57.nextMovingDirection * p59 < -0.0014 then
			p57.nextMovingDirection = 0
		end
		if v71 == p57.nextMovingDirection or p59 * v71 > -0.0003 and (p62 or p57.nextMovingDirection == 0) then
			local v73 = p57.nextMovingDirectionTimer - p58
			p57.nextMovingDirectionTimer = math.max(v73, 0)
			if p57.nextMovingDirectionTimer == 0 then
				p57.nextMovingDirection = v71
				v63 = v69
				v64 = 0
			else
				v64 = math.abs(v69)
				v63 = 0
			end
		else
			v63 = 0
			v64 = math.abs(v69)
			if p62 then
				p57.nextMovingDirectionTimer = 100
			end
		end
	end
	if v68 and (v63 ~= 0 and math.sign(v63) ~= v66.currentDirection) then
		v64 = math.abs(v63)
		v63 = 0
	end
	local v74, v75 = v66:updateGear(v72 and 0 or v63, v64, p58)
	if v66.gear == 0 and v66.targetGear ~= 0 then
		local v76 = v66.targetGear
		v72 = p59 * math.sign(v76) < 0 and true or v72
	end
	if v66.gearShiftMode == VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH and v67 then
		v72 = false
	end
	if v71 ~= 0 and v66.lowBrakeForceLocked then
		v66.lowBrakeForceLocked = false
	end
	if v72 then
		local v77 = v70 < v66.lowBrakeForceSpeedLimit
		local v78
		if p57.spec_articulatedAxis == nil or p57.spec_articulatedAxis.componentJoint == nil then
			v78 = false
		else
			local v79 = p57.rotatedTime
			v78 = math.abs(v79) > 0.01
		end
		if (v77 or p61) and not v78 or v66.lowBrakeForceLocked then
			v75 = 1
			if not v66.lowBrakeForceLocked and v71 == 0 then
				v66.lowBrakeForceLocked = true
			end
		else
			local v80 = v70 / 0.001
			local v81 = math.min(v80, 1)
			v75 = MathUtil.lerp(1, v66.lowBrakeForceScale, v81)
		end
	end
	SpecializationUtil.raiseEvent(p57, "onVehiclePhysicsUpdate", v74, v75, v72, p59)
	local v82, v83 = WheelsUtil.getSmoothedAcceleratorAndBrakePedals(p57, v74, v75, p58)
	local v84 = v66:getMaximumForwardSpeed() * 3.6
	if p57.movingDirection < 0 then
		v84 = v66:getMaximumBackwardSpeed() * 3.6
	end
	local v85 = p57:getLastSpeed()
	local v86 = v66:getSpeedLimit()
	local v87 = v85 - math.min(v86, v84)
	local v88
	if v87 > 0 then
		if v87 > 0.3 then
			local v89 = v66.overSpeedTimer + p58
			v66.overSpeedTimer = math.min(v89, 2000)
		else
			local v90 = v66.overSpeedTimer - p58
			v66.overSpeedTimer = math.max(v90, 0)
		end
		local v91 = v87 * (0.5 + v66.overSpeedTimer / 2000 * 1)
		local v92 = math.pow(v91, 2)
		local v93 = math.min(v92, 1)
		v83 = math.max(v93, v83)
		local v94 = 1 - v87 / 0.2
		v88 = 0.2 * math.max(v94, 0) * v82
	else
		local v95 = math.abs(v87) / 0.3 + 0.2
		v88 = v82 * math.min(v95, 1)
		v66.overSpeedTimer = 0
	end
	if next(p57.spec_motorized.differentials) ~= nil and p57.spec_motorized.motorizedNode ~= nil then
		local v96 = math.abs(v88)
		local v97, v98 = v66:getMinMaxGearRatio()
		local v99
		if v98 >= 0 then
			v99 = v66:getMaximumForwardSpeed()
		else
			v99 = v66:getMaximumBackwardSpeed()
		end
		local v100 = v66:getSpeedLimit() / 3.6
		local v101 = math.min(v99, v100)
		local v102 = v66:getAccelerationLimit()
		local v103 = v66:getMotorRotationAccelerationLimit()
		local v104, v105 = v66:getRequiredMotorRpmRange()
		local v106, v107 = PowerConsumer.getTotalConsumedPtoTorque(p57)
		local v108 = v106 / v66:getPtoMotorRpmRatio()
		local v109 = v97 == 0 and v98 == 0 and true or v66:getManualClutchPedal() > 0.9
		v66:setExternalTorqueVirtualMultiplicator(v107)
		if v109 then
			p57:controlVehicle(0, 0, 0, 0, (1 / 0), 0, 0, 0, 0, 0)
			v83 = math.max(v83, 0.03)
		else
			p57:controlVehicle(v96, v101, v102, v104 * 3.141592653589793 / 30, v105 * 3.141592653589793 / 30, v103, v97, v98, v66:getMaxClutchTorque(), v108)
		end
	end
	p57:brake(v83)
end
function WheelsUtil.computeDifferentialRotSpeedNonMotor(p110)
	if not p110.isServer or (p110.spec_wheels == nil or #p110.spec_wheels.wheels == 0) then
		return p110.lastSpeedReal * 1000
	end
	local v111 = 0
	local v112 = 0
	for _, v113 in pairs(p110.spec_wheels.wheels) do
		local v114 = getWheelShapeAxleSpeed(v113.node, v113.physics.wheelShape)
		if v113.physics.hasGroundContact then
			v111 = v111 + v114 * v113.physics.radius
			v112 = v112 + 1
		end
	end
	return v112 <= 0 and 0 or v111 / v112
end
function WheelsUtil.getTireFriction(p115, p116, p117, p118)
	local v119 = p117 == nil and 0 or p117
	local v120 = WheelsUtil.tireTypes[p115].frictionCoeffs[p116]
	local v121 = WheelsUtil.tireTypes[p115].frictionCoeffsWet[p116]
	local v122 = WheelsUtil.tireTypes[p115].frictionCoeffsSnow[p116]
	return v120 + (v121 - v120) * v119 + (v122 - v120) * p118
end
function WheelsUtil.getGroundType(p123, p124, p125)
	if p123 then
		return WheelsUtil.GROUND_FIELD
	elseif p124 or p125 < 0.1 then
		return WheelsUtil.GROUND_ROAD
	elseif p125 > 0.8 then
		return WheelsUtil.GROUND_SOFT_TERRAIN
	else
		return WheelsUtil.GROUND_HARD_TERRAIN
	end
end

AnimationValueFloat = {}
local v_u_1 = Class(AnimationValueFloat)
AnimationValueFloat.TANGENT_TYPE_LINEAR = 0
AnimationValueFloat.TANGENT_TYPE_SPLINE = 1
AnimationValueFloat.TANGENT_TYPE_STEP = 2
function AnimationValueFloat.new(p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)
	-- upvalues: (copy) v_u_1
	local v13 = p12 or v_u_1
	local v14 = setmetatable({}, v13)
	v14.vehicle = p2
	v14.animation = p3
	v14.part = p4
	v14.startName = p5
	v14.endName = p6
	v14.name = p7
	v14.initialUpdate = p8
	v14.get = p9
	v14.set = p10
	v14.extraLoad = p11
	v14.warningInfo = v14.name
	v14.compareParams = {}
	v14.oldCurValues = {}
	v14.oldSpeed = {}
	v14.curValue = nil
	v14.speed = nil
	return v14
end
function AnimationValueFloat.load(p15, p16, p17)
	if p15.startName ~= "" then
		p15.startValue = p16:getValue(p17 .. "#" .. p15.startName, nil, true)
		local v18 = p15.startValue
		if type(v18) == "number" then
			p15.startValue = { p15.startValue }
		else
			local v19 = p15.startValue
			if type(v19) == "boolean" then
				p15.startValue = { p15.startValue and 1 or 0 }
			else
				local v20 = p15.startValue
				if type(v20) == "string" then
					local v21 = {}
					local v22 = p15.startValue
					__set_list(v21, 1, {tonumber(v22) or 0})
					p15.startValue = v21
				else
					local v23 = p15.startValue
					if type(v23) == "table" then
						for v24 = 1, #p15.startValue do
							local v25 = p15.startValue[v24]
							if type(v25) == "string" then
								local v26 = p15.startValue
								local v27 = p15.startValue[v24]
								v26[v24] = tonumber(v27) or 0
							end
						end
					end
				end
			end
		end
	end
	if p15.endName ~= "" then
		p15.endValue = p16:getValue(p17 .. "#" .. p15.endName, nil, true)
		local v28 = p15.endValue
		if type(v28) == "number" then
			p15.endValue = { p15.endValue }
		else
			local v29 = p15.endValue
			if type(v29) == "boolean" then
				p15.endValue = { p15.endValue and 1 or 0 }
			else
				local v30 = p15.endValue
				if type(v30) == "string" then
					local v31 = {}
					local v32 = p15.endValue
					__set_list(v31, 1, {tonumber(v32) or 0})
					p15.endValue = v31
				else
					local v33 = p15.endValue
					if type(v33) == "table" then
						for v34 = 1, #p15.endValue do
							local v35 = p15.endValue[v34]
							if type(v35) == "string" then
								local v36 = p15.endValue
								local v37 = p15.endValue[v34]
								v36[v34] = tonumber(v37) or 0
							end
						end
					end
				end
			end
		end
	end
	if p15.endValue ~= nil or p15.endName == "" then
		p15.warningInfo = p17
		p15.xmlFile = p16
		if p15:extraLoad(p16, p17) then
			local v38 = "TANGENT_TYPE_" .. p16:getValue(p17 .. "#tangentType", "linear"):upper()
			if AnimationValueFloat[v38] == nil then
				p15.tangentType = AnimationValueFloat.TANGENT_TYPE_LINEAR
			else
				p15.tangentType = AnimationValueFloat[v38]
			end
			p15.curStartValue = {}
			p15.curRealValue = {}
			for v39 = 1, #(p15.startValue or p15.endValue) do
				p15.curStartValue[v39] = 0
				p15.curRealValue[v39] = 0
			end
			return true
		end
	end
	return false
end
function AnimationValueFloat.addCompareParameters(p40, ...)
	for _, v41 in pairs({ ... }) do
		local v42 = p40.compareParams
		table.insert(v42, v41)
	end
end
function AnimationValueFloat.setWarningInformation(p43, p44)
	p43.warningInfo = p44
end
function AnimationValueFloat.init(p45, p46, p47)
	for v48 = p46 + 1, p47 do
		local v49 = p45.animation.parts[v48]
		if p45.part.direction == v49.direction then
			local v50 = nil
			for v51 = 1, #v49.animationValues do
				local v52 = v49.animationValues[v51]
				if v52.endName == p45.endName then
					local v53 = true
					for v54 = 1, #p45.compareParams do
						local v55 = p45.compareParams[v54]
						if v52[v55] ~= p45[v55] then
							v53 = false
						end
					end
					if v53 then
						v50 = v52
					end
				end
			end
			if v50 ~= nil then
				if p45.part.startTime + p45.part.duration > v49.startTime + 0.001 then
					Logging.xmlWarning(p45.xmlFile, "Overlapping %s parts for \'%s\' in animation \'%s\'", p45.name, p45.warningInfo, p45.animation.name)
				end
				p45.nextPart = v50.part
				v50.prevPart = p45.part
				if v50.startValue == nil then
					local v56 = {}
					local v57 = p45.endValue
					__set_list(v56, 1, {unpack(v57)})
					v50.startValue = v56
					return
				end
				break
			end
		end
	end
end
function AnimationValueFloat.postInit(p58)
	if p58.endValue ~= nil and p58.startValue == nil then
		p58.startValue = { p58:get() }
	end
end
function AnimationValueFloat.reset(p59)
	p59.oldCurValues = p59.curValue or p59.oldCurValues
	p59.oldSpeed = p59.speed or p59.oldSpeed
	p59.curValue = nil
	p59.speed = nil
end
function AnimationValueFloat.initValues(p60, p61, p62, p63, ...)
	p60.curValue = p60.curValue or p60.oldCurValues
	local v64 = select("#", ...)
	for v65 = 1, v64 do
		p60.curValue[v65] = select(v65, ...)
	end
	local v66 = 1 / math.max(p62, 0.001)
	p60.speed = {}
	for v67 = 1, #p60.curValue do
		p60.speed[v67] = (p61[v67] - p60.curValue[v67]) * v66
		p60.curStartValue[v67] = p60.curValue[v67]
		p60.curRealValue[v67] = p60.curValue[v67]
	end
	if p63 == true then
		if p60.animation.currentSpeed < 0 then
			for v68 = 1, v64 do
				p60.curStartValue[v68] = p60.endValue[v68]
			end
		else
			for v69 = 1, v64 do
				p60.curStartValue[v69] = p60.startValue[v69]
			end
		end
	end
	p60.curTargetValue = p61
	return p60.initialUpdate
end
function AnimationValueFloat.update(p70, p71, _, p72, p73)
	if p70.startValue ~= nil and (p71 > 0 or AnimatedVehicle.getNextPartIsPlaying(p70.nextPart, p70.prevPart, p70.animation, true)) then
		local v74 = p70.endValue
		if p70.animation.currentSpeed < 0 then
			v74 = p70.startValue
		end
		local v75
		if p70.curValue == nil then
			v75 = p70:initValues(v74, p71, p73, p70:get())
		else
			v75 = false
		end
		if AnimatedVehicle.setMovedLimitedValuesN(#p70.curValue, p70.curValue, v74, p70.speed, p72) or v75 then
			if p70.tangentType == AnimationValueFloat.TANGENT_TYPE_LINEAR then
				local v76 = p70.curValue
				p70:set(unpack(v76))
			elseif p70.tangentType == AnimationValueFloat.TANGENT_TYPE_SPLINE then
				for v77 = 1, #p70.curValue do
					local v78 = 0
					if p73 == true then
						if p70.part.duration ~= 0 then
							local v79 = (p71 - p72) / p70.part.duration
							v78 = 1 - math.clamp(v79, 0, 1)
						end
					else
						local v80 = p70.curTargetValue[v77] - p70.curStartValue[v77]
						if v80 ~= 0 then
							v78 = (p70.curValue[v77] - p70.curStartValue[v77]) / v80
						end
					end
					if v78 >= 0 and v78 <= 1 then
						local v81 = p70.curRealValue
						local v82 = 3.141592653589793 * v78 / 2
						local v83 = math.cos(v82)
						v81[v77] = (1 - math.pow(v83, 2)) * (p70.curTargetValue[v77] - p70.curStartValue[v77]) + p70.curStartValue[v77]
					else
						p70.curRealValue[v77] = p70.curValue[v77]
					end
				end
				local v84 = p70.curRealValue
				p70:set(unpack(v84))
			elseif p70.tangentType == AnimationValueFloat.TANGENT_TYPE_STEP then
				for v85 = 1, #p70.curValue do
					if (p70.curValue[v85] - p70.curStartValue[v85]) / (p70.curTargetValue[v85] - p70.curStartValue[v85]) >= 1 then
						p70.curRealValue[v85] = p70.curValue[v85]
					else
						p70.curRealValue[v85] = p70.curStartValue[v85]
					end
				end
				local v86 = p70.curRealValue
				p70:set(unpack(v86))
			end
			return true
		end
	end
	return false
end

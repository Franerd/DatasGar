VehiclePropertyState = {}
VehiclePropertyState.NONE = 1
VehiclePropertyState.OWNED = 2
VehiclePropertyState.LEASED = 3
VehiclePropertyState.MISSION = 4
VehiclePropertyState.SHOP_CONFIG = 5
Enum(VehiclePropertyState)

VehicleLeaveEvent = {}
local v_u_1 = Class(VehicleLeaveEvent, Event)
InitStaticEventClass(VehicleLeaveEvent, "VehicleLeaveEvent")
function VehicleLeaveEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1, NetworkNode.CHANNEL_MAIN)
end
function VehicleLeaveEvent.new(p2, p3)
	local v4 = VehicleLeaveEvent.emptyNew()
	v4.vehicle = p2
	v4.userId = p3
	return v4
end
function VehicleLeaveEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.userId = User.streamReadUserId(p6)
	p5:run(p7)
end
function VehicleLeaveEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	User.streamWriteUserId(p9, p8.userId)
end
function VehicleLeaveEvent.run(p10, p11)
	if p10.vehicle == nil or not p10.vehicle:getIsSynchronized() then
		Logging.devInfo("VehicleLeaveEvent.run: Vehicle not found or not synchronized yet")
	else
		if not p11:getIsServer() then
			if p10.vehicle:getOwnerConnection() ~= nil then
				p10.vehicle:setOwnerConnection(nil)
				p10.vehicle.controllerFarmId = nil
			end
			g_server:broadcastEvent(VehicleLeaveEvent.new(p10.vehicle, p10.userId), nil, p11, p10.vehicle)
		end
		local v12 = g_currentMission.playerSystem:getPlayerByUserId(p10.userId)
		if v12 ~= nil then
			v12:leaveVehicle(p10.vehicle, true)
		end
	end
end
function VehicleLeaveEvent.sendEvent(p13, p14, p15)
	if p15 == nil or p15 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(VehicleLeaveEvent.new(p13, p14), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(VehicleLeaveEvent.new(p13, p14))
	end
end

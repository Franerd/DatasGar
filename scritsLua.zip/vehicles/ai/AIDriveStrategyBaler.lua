AIDriveStrategyBaler = {}
local v_u_1 = Class(AIDriveStrategyBaler, AIDriveStrategy)
function AIDriveStrategyBaler.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = AIDriveStrategy.new(p2, p3 or v_u_1)
	v4.balers = {}
	v4.slowDownFillLevel = 200
	v4.slowDownStartSpeed = 20
	return v4
end
function AIDriveStrategyBaler.setAIVehicle(p5, p6)
	AIDriveStrategyBaler:superClass().setAIVehicle(p5, p6)
	if SpecializationUtil.hasSpecialization(Baler, p5.vehicle.specializations) then
		local v7 = p5.balers
		local v8 = p5.vehicle
		table.insert(v7, v8)
	end
	for _, v9 in pairs(p5.vehicle:getAttachedAIImplements()) do
		if SpecializationUtil.hasSpecialization(Baler, v9.object.specializations) then
			local v10 = p5.balers
			local v11 = v9.object
			table.insert(v10, v11)
		end
	end
end
function AIDriveStrategyBaler.update(_, _) end
function AIDriveStrategyBaler.getDriveData(p12, _, _, _, _)
	local v13 = true
	local v14 = (1 / 0)
	for _, v15 in pairs(p12.balers) do
		local v16 = v15.spec_baler
		if v16.nonStopBaling then
			if v16.platformDropInProgress then
				v14 = v16.platformAIDropSpeed
				if VehicleDebug.state == VehicleDebug.DEBUG_AI then
					p12.vehicle:addAIDebugText(string.format("BALER -> Platform dropping active, reducing speed to %.1f km/h", v16.platformAIDropSpeed))
				end
			end
		else
			local v17 = v15:getFillUnitFillLevel(v16.fillUnitIndex)
			local v18 = v15:getFillUnitCapacity(v16.fillUnitIndex)
			local v19 = v18 - v17
			if v19 < p12.slowDownFillLevel then
				v14 = 2 + v19 / p12.slowDownFillLevel * p12.slowDownStartSpeed
				if VehicleDebug.state == VehicleDebug.DEBUG_AI then
					p12.vehicle:addAIDebugText(string.format("BALER -> Slow down because nearly full: %.2f", v14))
				end
			end
			if v17 == v18 or v16.unloadingState ~= Baler.UNLOADING_CLOSED then
				v13 = false
			end
		end
	end
	if v13 then
		return nil, nil, nil, v14, nil
	else
		return 0, 1, true, 0, (1 / 0)
	end
end
function AIDriveStrategyBaler.updateDriving(_, _) end

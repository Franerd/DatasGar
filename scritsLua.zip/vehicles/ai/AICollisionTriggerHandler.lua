AICollisionTriggerHandler = {}
local v_u_1 = Class(AICollisionTriggerHandler)
AICollisionTriggerHandler.UPDATE_INTERVAL = 5
AICollisionTriggerHandler.TRIGGER_SUBDIVISIONS = 1
AICollisionTriggerHandler.COLLISION_MASK = CollisionFlag.AI_BLOCKING + CollisionFlag.PLAYER + CollisionFlag.TREE + CollisionFlag.VEHICLE
function AICollisionTriggerHandler.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.numCollidingVehicles = {}
	v4.vehicleIgnoreList = {}
	v4.collisionTriggerByVehicle = {}
	v4.maxUpdateIndex = 1
	v4.hasStaticCollision = false
	v4.isBlocked = false
	v4.dynamicHitPointDistance = (1 / 0)
	v4.staticHitPointDistance = (1 / 0)
	return v4
end
function AICollisionTriggerHandler.init(p5, p6, p7)
	p5.vehicle = p6
	p5.strategy = p7
	if p6.isServer then
		p5.collisionTriggerByVehicle = {}
		p5.rootVehicle = p6.rootVehicle
		local v8 = p5.rootVehicle.childVehicles
		for v9 = 1, #v8 do
			local v10 = v8[v9]
			if v10.getAICollisionTriggers ~= nil then
				v10:getAICollisionTriggers(p5.collisionTriggerByVehicle)
			end
			if v10.getAIImplementCollisionTriggers ~= nil then
				v10:getAIImplementCollisionTriggers(p5.collisionTriggerByVehicle)
			end
		end
		local v11 = 1
		for v12, v13 in pairs(p5.collisionTriggerByVehicle) do
			v13.vehicle = v12
			v13.updateIndex = v11
			v13.hasCollision = false
			v13.hasStaticCollision = false
			v13.isValid = true
			v13.hitCounter = 0
			v13.hitStaticCounter = 0
			v13.curTriggerLength = 5
			v13.curTriggerDirection = 1
			v13.dynamicHitPoint = { 0, 0, 0 }
			v13.dynamicHitPointValid = false
			v13.dynamicHitPointDistance = (1 / 0)
			v13.dynamicHitPointInitialDistance = 0
			v13.staticHitPoint = { 0, 0, 0 }
			v13.staticHitPointValid = false
			v13.staticHitPointDistance = (1 / 0)
			v13.staticHitPointInitialDistance = 0
			v13.positions = {}
			for _ = 1, (AICollisionTriggerHandler.TRIGGER_SUBDIVISIONS + 1) * 3 do
				local v14 = v13.positions
				table.insert(v14, 0)
			end
			v11 = v11 + AICollisionTriggerHandler.UPDATE_INTERVAL
		end
		p5.maxUpdateIndex = v11
	end
end
function AICollisionTriggerHandler.update(p15, _, p16)
	local v17 = g_updateLoopIndex % p15.maxUpdateIndex
	local v18 = (1 / 0)
	local v19 = (1 / 0)
	for v20, v21 in pairs(p15.collisionTriggerByVehicle) do
		if v21.dynamicHitPointValid then
			local v22, v23, v24 = getWorldTranslation(v21.node)
			local v25 = v21.length - MathUtil.vector3Length(v21.dynamicHitPoint[1] - v22, v21.dynamicHitPoint[2] - v23, v21.dynamicHitPoint[3] - v24) - v21.dynamicHitPointInitialDistance
			v21.dynamicHitPointDistance = math.max(v25, 0)
		end
		if v21.staticHitPointValid then
			local v26, v27, v28 = getWorldTranslation(v21.node)
			local v29 = v21.length - MathUtil.vector3Length(v21.staticHitPoint[1] - v26, v21.staticHitPoint[2] - v27, v21.staticHitPoint[3] - v28) - v21.staticHitPointInitialDistance
			v21.staticHitPointDistance = math.max(v29, 0)
		end
		local v30 = v21.dynamicHitPointDistance
		v18 = math.min(v30, v18)
		local v31 = v21.staticHitPointDistance
		v19 = math.min(v31, v19)
		if v21.updateIndex == v17 then
			p15:generateTriggerPath(v20, v21, p16)
			if v21.isValid then
				v21.hitCounter = 0
				v21.hitStaticCounter = 0
				local v32, v33, v34 = localDirectionToWorld(v21.node, 0, 0, v21.curTriggerDirection)
				getVehicleCollisionDistance(v21.positions, v32, v33, v34, v21.width, v21.height, "onVehicleCollisionDistanceCallback", p15, v21, AICollisionTriggerHandler.COLLISION_MASK, true, true, true, true)
			end
		end
	end
	p15.dynamicHitPointDistance = v18
	p15.staticHitPointDistance = v19
	if p15.collisionDistanceCallback ~= nil then
		local v35 = p15.collisionDistanceCallback
		local v36 = p15.dynamicHitPointDistance
		local v37 = p15.staticHitPointDistance
		v35((math.min(v36, v37)))
	end
	if VehicleDebug.state == VehicleDebug.DEBUG_AI then
		for v38, v39 in pairs(p15.collisionTriggerByVehicle) do
			p15:generateTriggerPath(v38, v39, p16)
			if v39.isValid then
				for v40 = 1, #v39.positions - 3, 3 do
					drawDebugLine(v39.positions[v40 + 0], v39.positions[v40 + 1] + 2, v39.positions[v40 + 2], 1, 0, 0, v39.positions[v40 + 3], v39.positions[v40 + 4] + 2, v39.positions[v40 + 5], 0, 1, 0, true)
				end
				local v41, v42, v43 = localDirectionToWorld(v39.node, 0, 0, 1)
				debugDrawVehicleCollision(v39.positions, v41, v42, v43, v39.width, v39.height)
			end
		end
	end
end
function AICollisionTriggerHandler.setStaticCollisionCallback(p44, p45)
	p44.staticCollisionCallback = p45
end
function AICollisionTriggerHandler.updateStaticCollisionCallback(p46)
	local v47 = false
	for _, v48 in pairs(p46.collisionTriggerByVehicle) do
		if v48.hasStaticCollision then
			v47 = true
			break
		end
	end
	if v47 ~= p46.hasStaticCollision then
		p46.hasStaticCollision = v47
		if p46.staticCollisionCallback ~= nil then
			p46.staticCollisionCallback(v47)
		end
	end
end
function AICollisionTriggerHandler.setIsBlockedCallback(p49, p50)
	p49.isBlockedCallback = p50
end
function AICollisionTriggerHandler.updateBlockedCallback(p51)
	local v52 = false
	for _, v53 in pairs(p51.collisionTriggerByVehicle) do
		if v53.hasCollision then
			v52 = true
			break
		end
	end
	if v52 ~= p51.isBlocked then
		p51.isBlocked = v52
		if p51.isBlockedCallback ~= nil then
			p51.isBlockedCallback(v52)
		end
	end
end
function AICollisionTriggerHandler.setCollisionDistanceCallback(p54, p55)
	p54.collisionDistanceCallback = p55
end
function AICollisionTriggerHandler.generateTriggerPath(_, _, p56, p57)
	local v58 = p57 >= 0 and p56.node or (p56.backNode or p56.node)
	p56.curTriggerDirection = p57 < 0 and p56.backNode ~= p56.node and (p56.backNodeDirection or 1) or 1
	for v59 = 0, AICollisionTriggerHandler.TRIGGER_SUBDIVISIONS * 3, 3 do
		local v60, v61, v62 = localToWorld(v58, 0, 0, v59 / AICollisionTriggerHandler.TRIGGER_SUBDIVISIONS / 3 * p56.length * p56.curTriggerDirection)
		p56.positions[v59 + 1] = v60
		p56.positions[v59 + 2] = getTerrainHeightAtWorldPos(g_terrainNode, v60, v61, v62) + p56.height * 0.5
		p56.positions[v59 + 3] = v62
	end
	p56.isValid = true
end
function AICollisionTriggerHandler.onVehicleCollisionDistanceCallback(p63, _, p64, _, p65, p66)
	if g_currentMission ~= nil and p63.collisionTriggerByVehicle ~= nil then
		for v67, _ in pairs(p63.collisionTriggerByVehicle) do
			if v67.isDeleted or v67.isDeleting then
				return false
			end
		end
		if p64 ~= 0 then
			if g_currentMission.playerSystem:getPlayerByRootNode(p64) == nil then
				local v68 = g_currentMission.nodeToObject[p64]
				if (v68 == nil or p63.collisionTriggerByVehicle[v68] == nil) and (not getHasTrigger(p64) and (v68 == nil or (v68.getRootVehicle == nil or v68:getRootVehicle() ~= p63.rootVehicle))) then
					if getRigidBodyType(p64) == RigidBodyType.DYNAMIC then
						if bitAND(getCollisionFilterGroup(p64), CollisionFlag.VEHICLE) ~= 0 then
							p66.hitCounter = p66.hitCounter + 1
						end
					else
						p66.hitStaticCounter = p66.hitStaticCounter + 1
					end
				end
			else
				p66.hitCounter = p66.hitCounter + 1
			end
		end
		if p64 ~= 0 and not p65 then
			return true
		end
		local v69 = p66.hitCounter > 0
		if v69 ~= p66.hasCollision then
			p66.hasCollision = v69
			if v69 then
				p66.dynamicHitPointValid = true
				local v70 = p66.dynamicHitPoint
				local v71 = p66.dynamicHitPoint
				local v72 = p66.dynamicHitPoint
				local v73, v74, v75 = getWorldTranslation(p66.node)
				v70[1] = v73
				v71[2] = v74
				v72[3] = v75
				p66.dynamicHitPointInitialDistance = p66.vehicle.lastSpeedReal * g_physicsDt * AICollisionTriggerHandler.UPDATE_INTERVAL
			else
				p66.dynamicHitPointValid = false
				p66.dynamicHitPointDistance = (1 / 0)
			end
			p63:updateBlockedCallback()
		end
		local v76 = p66.hitStaticCounter > 0
		if v76 ~= p66.hasStaticCollision then
			p66.hasStaticCollision = v76
			if v76 then
				p66.staticHitPointValid = true
				local v77 = p66.staticHitPoint
				local v78 = p66.staticHitPoint
				local v79 = p66.staticHitPoint
				local v80, v81, v82 = getWorldTranslation(p66.node)
				v77[1] = v80
				v78[2] = v81
				v79[3] = v82
				p66.staticHitPointInitialDistance = p66.vehicle.lastSpeedReal * g_physicsDt * AICollisionTriggerHandler.UPDATE_INTERVAL
			else
				p66.staticHitPointValid = false
				p66.staticHitPointDistance = (1 / 0)
			end
			p63:updateStaticCollisionCallback()
		end
		return false
	end
end

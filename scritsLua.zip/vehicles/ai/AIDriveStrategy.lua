AIDriveStrategy = {}
local v_u_1 = Class(AIDriveStrategy)
function AIDriveStrategy.new(_, p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	return setmetatable({}, v3)
end
function AIDriveStrategy.delete(_) end
function AIDriveStrategy.setAIVehicle(p4, p5)
	p4.vehicle = p5
end
function AIDriveStrategy.update(_, _) end
function AIDriveStrategy.getDriveData(_, _, _, _, _)
	return nil, nil, nil, nil, nil
end
function AIDriveStrategy.updateDriving(_, _) end
function AIDriveStrategy.debugPrint(_, p6, ...)
	if VehicleDebug.state == VehicleDebug.DEBUG_AI then
		print(string.format("AI DEBUG: %s", string.format(p6, ...)))
	end
end

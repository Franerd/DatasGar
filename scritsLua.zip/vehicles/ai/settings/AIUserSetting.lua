AIUserSetting = {}
local v_u_1 = Class(AIUserSetting)
function AIUserSetting.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.unitText = nil
	v4.defaultPostFix = nil
	v4.isVineyardSetting = false
	return v4
end
function AIUserSetting.getIsDisabled(_, _)
	return false
end
function AIUserSetting.init(p5, p6, _, _, _)
	if p6 == nil then
		local v_u_10 = {
			["setting"] = p5,
			["callback"] = function(_, p7, _)
				-- upvalues: (ref) v_u_10
				v_u_10.value = p7
				if type(p7) == "string" then
					local v8 = v_u_10
					local v9 = string.split(p7, " ")[1]
					v8.value = tonumber(v9)
				end
				return true
			end
		}
		v_u_10.target = v_u_10
		p6 = v_u_10
	end
	return p6
end
function AIUserSetting.apply(_, _, _, _) end
function AIUserSetting.onSettingsChanged(_, _, _)
	return false
end
function AIUserSetting.loadFromXML(p11, p12, p13, p14)
	p14.loadedValue = p12:getValue(string.format("%s#%s", p13, p11.identifier), p14.value)
end
function AIUserSetting.saveToXML(p15, p16, p17, p18)
	p16:setValue(string.format("%s#%s", p17, p15.identifier), p18.value)
end
function AIUserSetting.registerXMLPath(p19, p20, p21)
	p20:register(XMLValueType.FLOAT, string.format("%s#%s", p21, p19.identifier), p19.title)
end

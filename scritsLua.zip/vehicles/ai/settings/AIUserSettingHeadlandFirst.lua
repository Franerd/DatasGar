AIUserSettingHeadlandFirst = {}
local v_u_1 = Class(AIUserSettingHeadlandFirst, AIUserSetting)
function AIUserSettingHeadlandFirst.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AIUserSetting.new(p2 or v_u_1)
	v3.identifier = "headlandFirst"
	v3.title = g_i18n:getText("ai_settingHeadlandFirst")
	v3.texts = {}
	local v4 = v3.texts
	local v5 = g_i18n
	table.insert(v4, v5:getText("ai_settingHeadlandFirstValue1"))
	local v6 = v3.texts
	local v7 = g_i18n
	table.insert(v6, v7:getText("ai_settingHeadlandFirstValue2"))
	v3.textMapping = {}
	v3.textMapping[1] = false
	v3.textMapping[2] = true
	return v3
end
function AIUserSettingHeadlandFirst.getIsDisabled(p8, p9)
	for _, v10 in pairs(p9) do
		if v10.setting.identifier == "workHeadlands" and not v10.value then
			return true
		end
	end
	return AIUserSettingHeadlandFirst:superClass().getIsDisabled(p8, p9)
end
function AIUserSettingHeadlandFirst.init(p11, p12, p13, p14, p15)
	local v_u_16 = AIUserSettingHeadlandFirst:superClass().init(p11, p12, p13, p14, p15)
	function v_u_16.callback(_, _, p17)
		-- upvalues: (ref) v_u_16
		v_u_16.value = v_u_16.setting.textMapping[p17]
		return false
	end
	if p13 == nil then
		v_u_16.value = Utils.getNoNil(v_u_16.loadedValue, false)
	else
		v_u_16.value = Utils.getNoNil(v_u_16.loadedValue, p13.headlandsFirst)
		if p15 then
			v_u_16.defaultValue = p13.headlandsFirst
		end
	end
	v_u_16.loadedValue = nil
	return v_u_16
end
function AIUserSettingHeadlandFirst.apply(_, p18, p19, p20)
	if p20 == AIModeSelection.MODE.WORKER then
		p19.headlandsFirst = p18.value
	end
end
function AIUserSettingHeadlandFirst.registerXMLPath(p21, p22, p23)
	p22:register(XMLValueType.BOOL, string.format("%s#%s", p23, p21.identifier), p21.title)
end

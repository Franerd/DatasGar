AIUserSettingSideOffset = {}
local v_u_1 = Class(AIUserSettingSideOffset, AIUserSetting)
function AIUserSettingSideOffset.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AIUserSetting.new(p2 or v_u_1)
	v3.identifier = "sideOffset"
	v3.title = g_i18n:getText("ai_settingSideOffset")
	v3.unitText = g_i18n:getText("unit_mShort")
	v3.defaultPostFix = g_i18n:getText("ai_settingDefaultPostFix")
	v3.inputDelay = 100
	return v3
end
function AIUserSettingSideOffset.init(p4, p5, p6, p7, p8)
	local v_u_9 = AIUserSettingSideOffset:superClass().init(p4, p5, p6, p7, p8)
	function v_u_9.callback(_, p10, _)
		-- upvalues: (ref) v_u_9
		v_u_9.value = p10
		if type(p10) == "string" then
			local v11 = v_u_9
			local v12 = string.split(p10, " ")[1]
			v11.value = tonumber(v12)
		end
		return false
	end
	v_u_9.step = 0.1
	v_u_9.max = 5
	v_u_9.min = -v_u_9.max
	if p6 == nil then
		v_u_9.value = MathUtil.round(v_u_9.loadedValue or 0, 1)
	else
		v_u_9.value = MathUtil.round(v_u_9.loadedValue or p6.sideOffset, 1)
		if p8 then
			v_u_9.defaultValue = p6.sideOffset
		end
	end
	v_u_9.loadedValue = nil
	return v_u_9
end
function AIUserSettingSideOffset.apply(_, p13, p14, _)
	p14.sideOffset = p13.value
end

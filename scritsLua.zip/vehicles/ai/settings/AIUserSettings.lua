AIUserSettings = {}
local v_u_1 = Class(AIUserSettings)
source("dataS/scripts/vehicles/ai/settings/AIUserSetting.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettingHeadlandFirst.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettingImplementWidth.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettingNumHeadlands.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettingShowLines.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettingSideOffset.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettingSkipNumLines.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettingWorkDirection.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettingWorkHeadlands.lua")
AIUserSettings.SETTINGS = {}
AIUserSettings.SETTINGS[AIModeSelection.MODE.WORKER] = {
	AIUserSettingImplementWidth.new(),
	AIUserSettingNumHeadlands.new(),
	AIUserSettingWorkHeadlands.new(),
	AIUserSettingHeadlandFirst.new(),
	AIUserSettingSkipNumLines.new()
}
AIUserSettings.SETTINGS[AIModeSelection.MODE.STEERING_ASSIST] = {
	AIUserSettingImplementWidth.new(),
	AIUserSettingNumHeadlands.new(),
	AIUserSettingWorkDirection.new(),
	AIUserSettingSideOffset.new(),
	AIUserSettingShowLines.new()
}
function AIUserSettings.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1
	local v4 = setmetatable({}, v3)
	v4.settings = {}
	for v5, v6 in pairs(AIUserSettings.SETTINGS) do
		v4.settings[v5] = {}
		for v7, v8 in ipairs(v6) do
			v4.settings[v5][v7] = v8:init(nil, p2, v5, true)
		end
	end
	return v4
end
function AIUserSettings.reinitialize(p9, p10, p11)
	for v12, v13 in pairs(p9.settings) do
		for v14, v15 in ipairs(v13) do
			v13[v14] = v15.setting:init(v15, p10, v12, p11)
		end
	end
end
function AIUserSettings.apply(p16, p17, p18)
	for v19, v20 in pairs(p16.settings) do
		if v19 ~= p18 then
			for _, v21 in ipairs(v20) do
				v21.setting:apply(v21, p17, p18)
			end
		end
	end
	for _, v22 in ipairs(p16.settings[p18]) do
		v22.setting:apply(v22, p17, p18)
	end
end
function AIUserSettings.adjustToCourse(p23, p24, p25)
	for _, v26 in ipairs(p23.settings[p25]) do
		if v26.setting.adjustToCourse ~= nil then
			v26.setting:adjustToCourse(v26, p24, p25)
		end
	end
end
function AIUserSettings.loadFromXML(p27, p28, p29)
	for v30, v31 in pairs(p27.settings) do
		local v32 = p29 .. string.format(".%s", string.lower(AIModeSelection.MODE.getName(v30)))
		for _, v33 in ipairs(v31) do
			v33.setting:loadFromXML(p28, v32, v33)
		end
	end
end
function AIUserSettings.saveToXML(p34, p35, p36)
	for v37, v38 in pairs(p34.settings) do
		local v39 = p36 .. string.format(".%s", string.lower(AIModeSelection.MODE.getName(v37)))
		for _, v40 in ipairs(v38) do
			v40.setting:saveToXML(p35, v39, v40)
		end
	end
end
function AIUserSettings.registerXMLPaths(p41, p42)
	for v43, v44 in pairs(AIUserSettings.SETTINGS) do
		local v45 = p42 .. string.format(".%s", string.lower(AIModeSelection.MODE.getName(v43)))
		for _, v46 in ipairs(v44) do
			v46:registerXMLPath(p41, v45)
		end
	end
end

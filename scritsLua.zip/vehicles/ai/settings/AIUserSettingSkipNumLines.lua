AIUserSettingSkipNumLines = {}
local v_u_1 = Class(AIUserSettingSkipNumLines, AIUserSetting)
function AIUserSettingSkipNumLines.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AIUserSetting.new(p2 or v_u_1)
	v3.identifier = "skipNumLines"
	v3.title = g_i18n:getText("ai_settingSkipNumLines")
	return v3
end
function AIUserSettingSkipNumLines.init(p4, p5, p6, p7, p8)
	local v_u_9 = AIUserSettingSkipNumLines:superClass().init(p4, p5, p6, p7, p8)
	function v_u_9.callback(_, p10, _)
		-- upvalues: (ref) v_u_9
		v_u_9.value = tonumber(p10)
		return false
	end
	if p6 == nil then
		v_u_9.value = v_u_9.loadedValue or 0
	else
		v_u_9.value = v_u_9.loadedValue or (p6.skipNumLines or 0)
	end
	v_u_9.min = 0
	v_u_9.max = 5
	v_u_9.step = 1
	v_u_9.loadedValue = nil
	return v_u_9
end
function AIUserSettingSkipNumLines.apply(_, p11, p12, p13)
	if p13 == AIModeSelection.MODE.WORKER then
		p12.skipNumLines = p11.value
	else
		p12.skipNumLines = 0
	end
end
function AIUserSettingSkipNumLines.registerXMLPath(p14, p15, p16)
	p15:register(XMLValueType.INT, string.format("%s#%s", p16, p14.identifier), p14.title)
end

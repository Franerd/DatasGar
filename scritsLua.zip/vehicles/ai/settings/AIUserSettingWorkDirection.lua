AIUserSettingWorkDirection = {}
local v_u_1 = Class(AIUserSettingWorkDirection, AIUserSetting)
function AIUserSettingWorkDirection.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AIUserSetting.new(p2 or v_u_1)
	v3.identifier = "workDirection"
	v3.title = g_i18n:getText("ai_settingWorkDirection")
	v3.texts = {}
	v3.textMapping = {}
	local v4 = v3.texts
	local v5 = g_i18n
	table.insert(v4, v5:getText("ai_settingAutomatic"))
	v3.textMapping[1] = -57.29577951308232
	for v6 = 0, 175, 5 do
		local v7 = v3.texts
		local v8 = string.format
		table.insert(v7, v8("%d \194\176", v6))
		v3.textMapping[#v3.texts] = v6
	end
	v3.inputDelay = 100
	return v3
end
function AIUserSettingWorkDirection.init(p9, p10, p11, p12, p13)
	local v_u_14 = AIUserSettingWorkDirection:superClass().init(p9, p10, p11, p12, p13)
	function v_u_14.callback(_, _, p15)
		-- upvalues: (ref) v_u_14
		v_u_14.value = v_u_14.setting.textMapping[p15]
		return true
	end
	if p11 == nil then
		v_u_14.value = v_u_14.loadedValue or -57.29577951308232
	else
		local v16 = v_u_14.loadedValue
		if not v16 then
			local v17 = p11.workDirection
			v16 = math.deg(v17)
		end
		v_u_14.value = v16
	end
	v_u_14.loadedValue = nil
	return v_u_14
end
function AIUserSettingWorkDirection.apply(_, p18, p19, p20)
	if p20 == AIModeSelection.MODE.STEERING_ASSIST then
		if p18.value == nil then
			p19.workDirection = -1
		else
			local v21 = p18.value
			p19.workDirection = math.rad(v21)
		end
	else
		p19.workDirection = -1
		return
	end
end
function AIUserSettingWorkDirection.registerXMLPath(p22, p23, p24)
	p23:register(XMLValueType.INT, string.format("%s#%s", p24, p22.identifier), p22.title)
end

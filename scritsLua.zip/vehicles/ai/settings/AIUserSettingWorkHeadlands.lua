AIUserSettingWorkHeadlands = {}
local v_u_1 = Class(AIUserSettingWorkHeadlands, AIUserSetting)
function AIUserSettingWorkHeadlands.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AIUserSetting.new(p2 or v_u_1)
	v3.identifier = "workHeadlands"
	v3.title = g_i18n:getText("ai_settingWorkHeadlands")
	return v3
end
function AIUserSettingWorkHeadlands.init(p4, p5, p6, p7, p8)
	local v_u_9 = AIUserSettingWorkHeadlands:superClass().init(p4, p5, p6, p7, p8)
	function v_u_9.callback(_, p10, _)
		-- upvalues: (ref) v_u_9
		v_u_9.value = p10
		return false
	end
	if p6 == nil then
		v_u_9.value = Utils.getNoNil(v_u_9.loadedValue, true)
	else
		v_u_9.value = Utils.getNoNil(v_u_9.loadedValue, p6.workHeadlands)
	end
	v_u_9.loadedValue = nil
	return v_u_9
end
function AIUserSettingWorkHeadlands.apply(_, p11, p12, p13)
	if p13 == AIModeSelection.MODE.WORKER then
		p12.workHeadlands = p11.value
	else
		p12.workHeadlands = true
	end
end
function AIUserSettingWorkHeadlands.onSettingsChanged(p14, p15, p16)
	AIUserSettingWorkHeadlands:superClass().onSettingsChanged(p14, p15, p16)
	for _, v17 in pairs(p16) do
		if v17.setting.identifier == "headlandFirst" then
			if p15.value then
				v17.value = Utils.getNoNil(v17.defaultValue, false)
			else
				v17.value = false
			end
		end
	end
	return true
end
function AIUserSettingWorkHeadlands.registerXMLPath(p18, p19, p20)
	p19:register(XMLValueType.BOOL, string.format("%s#%s", p20, p18.identifier), p18.title)
end

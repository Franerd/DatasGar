AIUserSettingNumHeadlands = {}
local v_u_1 = Class(AIUserSettingNumHeadlands, AIUserSetting)
function AIUserSettingNumHeadlands.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AIUserSetting.new(p2 or v_u_1)
	v3.identifier = "numHeadlands"
	v3.title = g_i18n:getText("ai_settingNumHeadlands")
	v3.defaultPostFix = g_i18n:getText("ai_settingDefaultPostFix")
	return v3
end
function AIUserSettingNumHeadlands.init(p4, p5, p6, p7, p8)
	local v9 = AIUserSettingNumHeadlands:superClass().init(p4, p5, p6, p7, p8)
	if p6 == nil then
		v9.value = v9.loadedValue or 1
		v9.min = 1
		v9.max = 5
		v9.step = 1
	else
		v9.value = v9.loadedValue or p6.numHeadlands
		if p8 then
			v9.defaultValue = p6.numHeadlands
		end
		if p7 == AIModeSelection.MODE.WORKER then
			local v10 = v9.defaultValue or p6.numHeadlands
			v9.min = v10
			local v11 = v10 * 2
			v9.max = math.ceil(v11)
		else
			v9.min = 1
			v9.max = 5
		end
		v9.step = 1
	end
	v9.useSlider = true
	v9.loadedValue = nil
	return v9
end
function AIUserSettingNumHeadlands.apply(_, p12, p13, _)
	p13.numHeadlands = p12.value
end
function AIUserSettingNumHeadlands.adjustToCourse(_, p14, p15, _)
	local v16 = #p15.courseField.headlandBoundaries
	if v16 < p14.value then
		p14.value = v16
	end
end
function AIUserSettingNumHeadlands.registerXMLPath(p17, p18, p19)
	p18:register(XMLValueType.INT, string.format("%s#%s", p19, p17.identifier), p17.title)
end

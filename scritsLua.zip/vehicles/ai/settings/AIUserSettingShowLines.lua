AIUserSettingShowLines = {}
local v_u_1 = Class(AIUserSettingShowLines, AIUserSetting)
function AIUserSettingShowLines.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AIUserSetting.new(p2 or v_u_1)
	v3.identifier = "showLines"
	v3.title = g_i18n:getText("ai_settingShowLines")
	v3.isVineyardSetting = true
	return v3
end
function AIUserSettingShowLines.init(p4, p5, p6, p7, p8)
	local v_u_9 = AIUserSettingShowLines:superClass().init(p4, p5, p6, p7, p8)
	function v_u_9.callback(_, p10, _)
		-- upvalues: (ref) v_u_9
		v_u_9.value = p10
		return false
	end
	v_u_9.value = g_gameSettings:getValue(GameSettings.SETTING.STEERING_ASSIST_LINES)
	return v_u_9
end
function AIUserSettingShowLines.apply(_, p11, _, _)
	g_gameSettings:setValue(GameSettings.SETTING.STEERING_ASSIST_LINES, p11.value, true)
end
function AIUserSettingShowLines.registerXMLPath(p12, p13, p14)
	p13:register(XMLValueType.BOOL, string.format("%s#%s", p14, p12.identifier), p12.title)
end

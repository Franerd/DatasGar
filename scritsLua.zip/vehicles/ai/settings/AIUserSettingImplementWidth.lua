AIUserSettingImplementWidth = {}
local v_u_1 = Class(AIUserSettingImplementWidth, AIUserSetting)
function AIUserSettingImplementWidth.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AIUserSetting.new(p2 or v_u_1)
	v3.identifier = "implementWidth"
	v3.title = g_i18n:getText("ai_settingImplementWidth")
	v3.unitText = g_i18n:getText("unit_mShort")
	v3.defaultPostFix = g_i18n:getText("ai_settingDefaultPostFix")
	v3.valueTexts = {}
	v3.valueToTextIndex = {}
	v3.min = 5
	v3.max = 600
	v3.step = 1
	for v4 = v3.min, v3.max, v3.step do
		local v5 = v3.valueTexts
		local v6 = string.format
		local v7 = v4 * 0.1
		table.insert(v5, v6("%.1f m", v7))
		v3.valueToTextIndex[v4] = #v3.valueTexts
	end
	v3.inputDelay = 1
	return v3
end
function AIUserSettingImplementWidth.init(p8, p9, p10, p11, p12)
	local v_u_13 = AIUserSettingImplementWidth:superClass().init(p8, p9, p10, p11, p12)
	function v_u_13.callback(_, p14, _)
		-- upvalues: (ref) v_u_13
		local v15 = v_u_13
		local v16 = string.split(p14, " ")[1]
		v15.value = (tonumber(v16) or 1) * 10
		return true
	end
	if p10 == nil then
		v_u_13.value = v_u_13.loadedValue or 30
		v_u_13.min = p8.min
		v_u_13.max = p8.max
	else
		local v17 = MathUtil.round(p10.implementWidth * 10)
		local v18 = p8.min
		local v19 = p8.max
		local v20 = math.clamp(v17, v18, v19)
		v_u_13.value = MathUtil.round(v_u_13.loadedValue or v20)
		if p12 then
			v_u_13.defaultValue = v20
		end
		if p11 == AIModeSelection.MODE.WORKER then
			local v21 = MathUtil.round
			local v22 = v20 * 0.5
			local v23 = p8.min
			local v24 = p8.max
			v_u_13.min = v21((math.clamp(v22, v23, v24)))
			local v25 = MathUtil.round
			local v26 = v20 * 2
			local v27 = p8.min
			local v28 = p8.max
			v_u_13.max = v25((math.clamp(v26, v27, v28)))
		else
			v_u_13.min = p8.min
			v_u_13.max = p8.max
		end
	end
	v_u_13.loadedValue = nil
	return v_u_13
end
function AIUserSettingImplementWidth.apply(_, p29, p30, _)
	p30.implementWidth = p29.value * 0.1
end

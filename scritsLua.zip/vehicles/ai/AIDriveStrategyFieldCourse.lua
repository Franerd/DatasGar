AIDriveStrategyFieldCourse = {}
source("dataS/scripts/vehicles/ai/AICollisionTriggerHandler.lua")
local v_u_1 = Class(AIDriveStrategyFieldCourse, AIDriveStrategy)
function AIDriveStrategyFieldCourse.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = AIDriveStrategy.new(p2, p3 or v_u_1)
	v4.collisionHandler = AICollisionTriggerHandler.new()
	v4.isBlocked = false
	v4.hasStaticCollision = false
	v4.hasStaticCollisionTimer = 0
	v4.collisionDistance = (1 / 0)
	v4.lastContinueWorkState = false
	v4.lastContinueWorkBlockedTime = (-1 / 0)
	v4.reconstructionData = p2
	return v4
end
function AIDriveStrategyFieldCourse.delete(p5)
	AIDriveStrategyFieldCourse:superClass().delete(p5)
	for _, v6 in ipairs(p5.vehicle:getAttachedAIImplements()) do
		v6.object:aiImplementEndLine()
		v6.object.rootVehicle:raiseStateChange(VehicleStateChange.AI_END_LINE)
	end
end
function AIDriveStrategyFieldCourse.setAIVehicle(p_u_7, p8)
	AIDriveStrategyFieldCourse:superClass().setAIVehicle(p_u_7, p8)
	p_u_7.collisionHandler:init(p8, p_u_7)
	p_u_7.vehicleAISteeringNode = p_u_7.vehicle:getAISteeringNode()
	p_u_7.vehicleAISteeringNodeReverse = p_u_7.vehicle:getAIReverserNode()
	p_u_7.reverserDirectionNode = AIVehicleUtil.getAIToolReverserDirectionNode(p_u_7.vehicle)
	p_u_7.reverserDirectionNodeRefNode = p_u_7.reverserDirectionNode
	if p_u_7.reverserDirectionNodeRefNode == nil then
		if p_u_7.vehicle.getAIToolReverserDirectionNode ~= nil then
			p_u_7.reverserDirectionNodeRefNode = p_u_7.vehicle:getAIToolReverserDirectionNode()
		end
		if p_u_7.reverserDirectionNodeRefNode == nil and p_u_7.vehicleAISteeringNodeReverse ~= p_u_7.vehicleAISteeringNode then
			p_u_7.reverserDirectionNodeRefNode = p_u_7.vehicleAISteeringNodeReverse
		end
	end
	p_u_7.vehicle.aiDriveDirection = { 0, 1 }
	p_u_7.vehicle.aiDriveTarget = { 0, 0 }
	p_u_7.lastVehiclePosition = { 0, 0, 0 }
	p_u_7.lastTargetPosition = { 0, 0, 1 }
	p_u_7.lastMovingDirection = 1
	p_u_7.lastSegmentIsTurn = false
	p_u_7.nextSegmentTurnSide = nil
	p_u_7.vehicle:initializeLoadedAIModeUserSettings()
	p_u_7.fieldCourseSettings = p_u_7.vehicle:getAIModeFieldCourseSettings()
	local v9, v10 = FieldCourseSettings.generate(p_u_7.vehicle)
	p_u_7.fieldCourseSettings = p_u_7.fieldCourseSettings or v9
	p_u_7.implementData = v10
	p_u_7.fieldCourseSettings:print(p_u_7.debugPrint, p_u_7)
	local v11
	if p_u_7.reconstructionData == nil or p_u_7.reconstructionData.aiFieldCourseReconstructionData == nil then
		v11 = true
	else
		Logging.devInfo("Using field course data from savegame")
		local v12, _, v13 = localToWorld(p_u_7.vehicle:getAIDirectionNode(), 0, 0, 0)
		p_u_7.fieldDetectionInProgress = true
		if p_u_7.reconstructionData.aiFieldCourseReconstructionData:apply(p_u_7, p_u_7.onFieldCourseLoadedCallback, v12, v13) then
			v11 = false
		else
			p_u_7.fieldDetectionInProgress = nil
			v11 = true
		end
	end
	if v11 then
		local v14 = false
		if AIDriveStrategyFieldCourse.fieldDetectionPosition == nil then
			local v15, v16
			v15, v16, v14 = FieldCourse.findClosestField(nil, nil, nil, nil, p_u_7.vehicle:getAIJobFarmId(), p_u_7.vehicle, 2)
			p_u_7.fieldDetectionX = v15
			p_u_7.fieldDetectionZ = v16
		else
			local v17 = AIDriveStrategyFieldCourse.fieldDetectionPosition[1]
			local v18 = AIDriveStrategyFieldCourse.fieldDetectionPosition[2]
			p_u_7.fieldDetectionX = v17
			p_u_7.fieldDetectionZ = v18
		end
		if p_u_7.fieldDetectionX == nil or v14 ~= false then
			if v14 then
				p_u_7.fieldNotOwned = true
			end
		else
			p_u_7.fieldDetectionInProgress = true
			g_fieldCourseManager:generateFieldCourseAtWorldPos(p_u_7.fieldDetectionX, p_u_7.fieldDetectionZ, p_u_7.fieldCourseSettings, p_u_7.onFieldCourseLoadedCallback, p_u_7)
		end
	end
	p_u_7.collisionHandler:setStaticCollisionCallback(function(p19)
		-- upvalues: (copy) p_u_7
		p_u_7.hasStaticCollision = p19
	end)
	p_u_7.collisionHandler:setIsBlockedCallback(function(p20)
		-- upvalues: (copy) p_u_7
		p_u_7.isBlocked = p20
		if g_server ~= nil then
			g_server:broadcastEvent(AIVehicleIsBlockedEvent.new(p_u_7.vehicle, p20), true, nil, p_u_7.vehicle)
		end
	end)
	p_u_7.collisionHandler:setCollisionDistanceCallback(function(p21)
		-- upvalues: (copy) p_u_7
		p_u_7.collisionDistance = p21
	end)
end
function AIDriveStrategyFieldCourse.onFieldCourseLoadedCallback(p_u_22, p23)
	if p_u_22.vehicle.isDeleted or p_u_22.vehicle.isDeleting then
		return
	elseif p23 == nil then
		p_u_22.vehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
		p_u_22:debugPrint("Stopping AIVehicle - Field boundary not detected")
		return
	else
		local v_u_24
		if ClassUtil.getClassObjectByObject(p23) == FieldCourse then
			v_u_24 = AIFieldCourse.new(p23)
		else
			local v25 = p23.fieldCourse
			v_u_24 = p23
			p23 = v25
		end
		if p23.isVineyardCourse then
			p_u_22.vehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
			p_u_22:debugPrint("Stopping AIVehicle - Vineyard course not supported")
		else
			local v26 = p_u_22.vehicle:getAIDirectionNode()
			local v27, _, v28 = localToWorld(v26, 0, 0, 0)
			p_u_22.startX = v27
			p_u_22.startZ = v28
			local v29, _, v30 = localDirectionToWorld(v26, 0, 0, 1)
			p_u_22.startYRot = MathUtil.getYRotationFromDirection(v29, v30)
			local v_u_31 = p_u_22.vehicle:getAttachedAIImplements()
			v_u_24:setStartPosition(p_u_22.startX, p_u_22.startZ, p_u_22.startYRot)
			local v32 = p_u_22.startX
			local v33 = p_u_22.startZ
			local v34 = p_u_22.startYRot
			p_u_22:debugPrint("  Start Position: %.3f %.3f (%.3f\194\176)", v32, v33, (math.deg(v34)))
			p_u_22.aiFieldCourse = v_u_24
			v_u_24:setInitialSegmentCallback(function()
				-- upvalues: (copy) p_u_22
				p_u_22.initialSegmentFinished = true
				if not p_u_22.fieldCourseSettings.workInitialSegment then
					p_u_22.vehicle:raiseAIEvent("onAIFieldWorkerPrepareForWork", "onAIImplementPrepareForWork")
				end
			end)
			v_u_24:setSegmentAreaValidityFunction(function(p35, p36, p37, p38, p39, p40)
				-- upvalues: (copy) v_u_31
				for _, v41 in ipairs(v_u_31) do
					local v42, v43 = AIVehicleUtil.getAIAreaOfVehicle(v41.object, p35, p36, p37, p38, p39, p40)
					if v43 > 0 and v42 / v43 > 0 then
						return true
					end
				end
				return false
			end)
			if p_u_22.fieldCourseSettings.workInitialSegment then
				p_u_22.vehicle:raiseAIEvent("onAIFieldWorkerPrepareForWork", "onAIImplementPrepareForWork")
			end
			v_u_24:finalize(function()
				-- upvalues: (ref) v_u_24, (copy) p_u_22
				if #v_u_24.fieldCourse.segments == 0 then
					p_u_22.vehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
				else
					p_u_22.fieldDetectionInProgress = false
				end
			end)
		end
	end
end
function AIDriveStrategyFieldCourse.update(p44, p45)
	p44.collisionHandler:update(p45, p44.lastMovingDirection)
	if p44.aiFieldCourse ~= nil then
		p44.aiFieldCourse:update(p45)
		if VehicleDebug.state == VehicleDebug.DEBUG_AI and p44.vehicle.isActiveForInputIgnoreSelectionIgnoreAI then
			p44.aiFieldCourse:draw()
			p44.fieldCourseSettings:draw()
		end
		local v46 = p44.vehicle:getAttachedAIImplements()
		local v47, v48, v49, _, _, _ = p44.aiFieldCourse:getActiveSegmentData()
		if v47 ~= nil then
			local v50, v51 = p44.aiFieldCourse:getNextSegmentData()
			if not v50 and v51 ~= nil then
				local v52 = v51 > 0
				if v52 ~= p44.nextSegmentTurnSide then
					p44.vehicle:aiFieldWorkerSideOffsetChanged(v52, v48)
					p44.nextSegmentTurnSide = v52
				end
			end
			if not v48 or p44.fieldCourseSettings.workInitialSegment then
				if v47 == p44.lastSegmentIsTurn then
					if v47 then
						p44.vehicle:aiFieldWorkerTurnProgress(v49, p44.nextSegmentTurnSide, p44.lastMovingDirection)
					end
				else
					if v47 then
						p44.vehicle:aiFieldWorkerStartTurn(p44.nextSegmentTurnSide, nil)
					else
						p44.vehicle:aiFieldWorkerEndTurn(p44.nextSegmentTurnSide, nil)
					end
					p44.lastSegmentIsTurn = v47
				end
				for v53, v54 in ipairs(v46) do
					local v55 = p44.implementData[v53]
					if p44.fieldCourseSettings.toolAlwaysActive then
						local v56 = not v47
						if v56 then
							v56 = p44.lastMovingDirection >= 0
						end
						v55.isLowered = v56
					else
						local v57 = false
						local v58
						if v47 or p44.lastMovingDirection < 0 then
							v55.isLowered = false
							v58 = (not (p44.fieldCourseSettings.canTurnBackward or p44.fieldCourseSettings.allowStraightReversing) or p44.fieldCourseSettings.workInitialSegment and (v48 and p44.lastMovingDirection > 0)) and true or v57
						else
							v58 = g_time - p44.lastContinueWorkBlockedTime > 1000
						end
						if v58 then
							local v59, v60, v61, v62 = v54.object:getAIMarkers()
							local _, _, v63 = localToLocal(v59, v61, 0, 0, 0)
							local v64 = 3 + v63
							local v65 = -v63
							local v66 = 0.2
							local v67 = -0.2
							if v62 then
								v67 = -v67
								v66 = -v66
							end
							local v68, _, v69 = localToWorld(v59, v67, 0, v65)
							local v70, _, v71 = localToWorld(v59, v67, 0, v65 + v64)
							local v72, _, v73 = localToWorld(v60, v66, 0, v65)
							local v74, v75 = AIVehicleUtil.getAIAreaOfVehicle(v54.object, v68, v69, v72, v73, v70, v71)
							if v75 > 0 and v74 / v75 > 0 then
								v55.isLowered = true
							else
								v55.isLowered = false
							end
							if VehicleDebug.state == VehicleDebug.DEBUG_AI then
								local v76, v77, v78, v79, v80, v81 = MathUtil.getXZWidthAndHeight(v68, v69, v72, v73, v70, v71)
								DebugUtil.drawDebugParallelogram(v76, v77, v78, v79, v80, v81, 0.2, v55.isLowered and 0 or 1, v55.isLowered and 1 or 0, 0, 1)
							end
						end
					end
					while v55.parentAIImplement ~= nil do
						if v55.isLowered and not v55.parentAIImplement.isLowered then
							v55.parentAIImplement.isLowered = true
						end
						v55 = v55.parentAIImplement
					end
				end
			end
		end
		for v82, v83 in ipairs(v46) do
			local v84 = p44.implementData[v82]
			if v84.isLowered then
				if v84.wasLowered ~= true then
					v83.object:aiImplementStartLine()
					v83.object:getRootVehicle():raiseStateChange(VehicleStateChange.AI_START_LINE)
				end
			elseif v84.wasLowered ~= false then
				v83.object:aiImplementEndLine()
				v83.object:getRootVehicle():raiseStateChange(VehicleStateChange.AI_END_LINE)
			end
			v84.wasLowered = v84.isLowered
		end
		local v85 = p44.lastVehiclePosition[1]
		local v86 = p44.lastVehiclePosition[2]
		local v87 = p44.lastVehiclePosition[3]
		local v88 = p44.lastTargetPosition[1]
		local v89 = p44.lastTargetPosition[2]
		local v90 = p44.lastTargetPosition[3]
		local v91, v92 = MathUtil.vector2Normalize(v88 - v85, v90 - v87)
		local v93, v94, v95
		if p44.lastMovingDirection < 0 then
			v93 = 1
			v94 = 0
			v95 = 0
		else
			v93 = 0
			v94 = 1
			v95 = 0
		end
		drawDebugTriangle(v85 + v92 * 0.25, v86 + 4, v87 - v91 * 0.25, v85 - v92 * 0.25, v86 + 4, v87 + v91 * 0.25, v88, v89 + 4, v90, v93, v94, v95, 0.2, true)
		if p44.hasStaticCollision and p44.lastContinueWorkState then
			if p44.vehicle:getLastSpeed() >= 1 then
				p44.hasStaticCollisionTimer = 0
				return
			end
			p44.hasStaticCollisionTimer = p44.hasStaticCollisionTimer + p45
			if p44.hasStaticCollisionTimer > 5000 then
				p44.hasStaticCollisionTimer = 0
				p44.aiFieldCourse:skipCurrentSubSegment(25)
				p44:debugPrint("AIVehicle blocked - skip current sub segment")
				return
			end
		else
			p44.hasStaticCollisionTimer = 0
		end
	end
end
function AIDriveStrategyFieldCourse.getDriveData(p96, p97, _, _, _)
	if p96.fieldDetectionInProgress == nil then
		if p96.fieldNotOwned then
			p96.vehicle:stopCurrentAIJob(AIMessageErrorFieldNotOwned.new())
			p96:debugPrint("Stopping AIVehicle - Field not owned")
		else
			p96.vehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
			p96:debugPrint("Stopping AIVehicle - Failed to start field detection")
		end
	else
		local v98
		if p96.aiFieldCourse == nil then
			v98 = false
		else
			local v99, v100, v101, v102, v103
			v98, v99, v100, v101, v102, v103 = p96.aiFieldCourse:getActiveSegmentData()
		end
		local v104 = 0
		local v105 = 0
		local v106 = true
		local v107 = 0
		local v108 = 0
		local v109, v110, v111 = p96.vehicle:getCanAIFieldWorkerContinueWork(v98)
		if v109 then
			p96.lastContinueWorkState = true
			if VehicleDebug.state == VehicleDebug.DEBUG_AI then
				if p96.aiFieldCourse ~= nil then
					p96.aiFieldCourse:addDebugTexts(p96.vehicle)
				end
				p96.vehicle:addAIDebugText(string.format(" Has Static Collision: %s", p96.hasStaticCollision))
				p96.vehicle:addAIDebugText(string.format(" Collision Distance: dynamic: %.1f static: %.1f", p96.collisionHandler.dynamicHitPointDistance, p96.collisionHandler.staticHitPointDistance))
				p96.vehicle:addAIDebugText(string.format(" Is Blocked: %s", p96.isBlocked))
				p96.vehicle:addAIDebugText(string.format(" Distance To Collision: %s", p96.collisionDistance))
				if p96.aiFieldCourse ~= nil then
					local v112 = p96.vehicle:getAttachedAIImplements()
					for _, v113 in ipairs(v112) do
						local v114, v115, v116, _ = v113.object:getAIMarkers()
						local v117, _, v118 = getWorldTranslation(v114)
						local v119, _, v120 = getWorldTranslation(v115)
						local v121 = p96.aiFieldCourse:getPositionOffsetToActiveSegment(v117, v118)
						local v122 = p96.aiFieldCourse:getPositionOffsetToActiveSegment(v119, v120)
						local _, _, v123 = localToLocal(v114, p96.vehicleAISteeringNode, 0, 0, 0)
						local _, _, v124 = localToLocal(v116, p96.vehicleAISteeringNode, 0, 0, 0)
						p96.vehicle:addAIDebugText(string.format("%s", v113.object:getName()))
						p96.vehicle:addAIDebugText(string.format("    Side Drift: %.2fm | Width: %.2fm", (v121 + v122) * 0.5 * -1, calcDistanceFrom(v114, v115)))
						p96.vehicle:addAIDebugText(string.format("    zOffset: %.2fm / %.2fm", v124, v123))
					end
					p96.vehicle:addAIDebugText(string.format(" Segment Side Offset: %.2f", p96.aiFieldCourse:getActiveSegmentSideOffset()))
				end
			end
			if p96.isBlocked then
				return v104, v105, v106, v107, v108
			end
			if p96.aiFieldCourse ~= nil then
				local v125, v126, v127 = getWorldTranslation(p96.lastMovingDirection > 0 and p96.vehicleAISteeringNode or p96.vehicleAISteeringNodeReverse)
				v104, v105, v106, v107, v108 = p96.aiFieldCourse:getDriveData(p97, v125, v126, v127, p96.vehicle:getLastSpeed(), 4, p96.reverserDirectionNodeRefNode)
				if v104 ~= nil and (v104 ~= 0 or v105 ~= 0) then
					if not v106 and p96.reverserDirectionNode ~= nil then
						local v128, _, v129 = worldToLocal(p96.reverserDirectionNode, v104, v126, v105)
						local v130 = Utils.getYRotationBetweenNodes(p96.vehicleAISteeringNodeReverse, p96.reverserDirectionNode)
						local v131 = math.cos(v130) * v128 - math.sin(v130) * v129
						local v132 = math.sin(v130) * v128 + math.cos(v130) * v129
						local v133 = -v131
						local v134
						v104, v134, v105 = localToWorld(p96.vehicleAISteeringNodeReverse, v133, 0, v132)
					end
					if VehicleDebug.state == VehicleDebug.DEBUG_AI then
						local _, _, v135, v136, v137, v138 = p96.aiFieldCourse:getActiveSegmentData()
						if v135 ~= nil then
							p96.vehicle:addAIDebugText(string.format("Segment Position: %.1f%% of %.1fm", v135 * 100, v136))
							if v138 ~= v136 then
								p96.vehicle:addAIDebugText(string.format("Sub Segment Position: %.1f%% of %.1fm", v137 * 100, v138))
							end
						end
					end
					p96.lastVehiclePosition[1] = v125
					p96.lastVehiclePosition[2] = v126
					p96.lastVehiclePosition[3] = v127
					p96.lastTargetPosition[1] = v104
					p96.lastTargetPosition[2] = v126
					p96.lastTargetPosition[3] = v105
					p96.lastMovingDirection = v106 and 1 or -1
				end
			end
			if p96.collisionDistance ~= (1 / 0) and v106 then
				local v139 = p96.collisionDistance * 2
				local v140 = math.max(v139, 1)
				v107 = math.min(v107, v140)
			end
			return v104, v105, v106, v107, v108
		else
			p96.lastContinueWorkState = false
			p96.lastContinueWorkBlockedTime = g_time
			if VehicleDebug.state == VehicleDebug.DEBUG_AI then
				p96.vehicle:addAIDebugText("- Wait for turn on (getCanAIFieldWorkerContinueWork)")
			end
			local v141 = 0
			if v110 then
				p96.vehicle:stopCurrentAIJob(v111 or AIMessageErrorUnknown.new())
				p96:debugPrint("Stopping AIVehicle - cannot continue work")
			end
			return v104, v105, v106, v141, v108
		end
	end
end
function AIDriveStrategyFieldCourse.fillReconstructionData(p142, p143)
	if p142.aiFieldCourse ~= nil then
		p143.aiFieldCourseReconstructionData = AIFieldCourseReconstructionData.new()
		p143.aiFieldCourseReconstructionData:setDataByAIFieldCourse(p142.aiFieldCourse)
	end
end
function AIDriveStrategyFieldCourse.saveToXML(p144, p145, p146)
	if p144.aiFieldCourseReconstructionData ~= nil then
		p144.aiFieldCourseReconstructionData:saveToXML(p145, p146 .. ".strategyFieldCourse")
	end
end
function AIDriveStrategyFieldCourse.loadFromXML(p147, p148, p149)
	p147.aiFieldCourseReconstructionData = AIFieldCourseReconstructionData.new()
	if not p147.aiFieldCourseReconstructionData:loadFromXML(p148, p149 .. ".strategyFieldCourse") then
		p147.aiFieldCourseReconstructionData = nil
	end
end
function AIDriveStrategyFieldCourse.registerSavegameXMLPaths(p150, p151)
	AIFieldCourseReconstructionData.registerXMLPaths(p150, p151 .. ".strategyFieldCourse")
end

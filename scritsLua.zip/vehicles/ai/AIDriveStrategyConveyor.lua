AIDriveStrategyConveyor = {}
local v_u_1 = Class(AIDriveStrategyConveyor, AIDriveStrategy)
function AIDriveStrategyConveyor.new(p2, p3)
	-- upvalues: (copy) v_u_1
	return AIDriveStrategy.new(p2, p3 or v_u_1)
end
function AIDriveStrategyConveyor.setAIVehicle(p4, p5)
	AIDriveStrategyConveyor:superClass().setAIVehicle(p4, p5)
	local _, v6, v7 = localToLocal(p4.vehicle.wheels[p4.vehicle.aiConveyorBelt.backWheelIndex].repr, p4.vehicle.components[1].node, 0, 0, 0)
	local v8, v9, v10 = localToWorld(p4.vehicle.components[1].node, 0, v6, v7)
	local v11, v12, v13 = getWorldTranslation(p4.vehicle.wheels[p4.vehicle.aiConveyorBelt.centerWheelIndex].repr)
	local v14 = MathUtil.vector3Length(v8 - v11, v9 - v12, v10 - v13)
	local v15 = p4.vehicle.aiConveyorBelt.currentAngle / 2
	local v16 = math.rad(v15)
	local v17 = v14 * math.sin(v16)
	local v18 = math.pow(v14, 2) - math.pow(v17, 2)
	local v19 = math.sqrt(v18)
	local v20 = p4.vehicle.aiConveyorBelt.currentAngle
	p4.distanceToMove = math.rad(v20) * v14 / 2
	p4.currentTarget = 1
	p4.worldTarget = {}
	p4.worldTarget[1] = { localToWorld(p4.vehicle.wheels[p4.vehicle.aiConveyorBelt.centerWheelIndex].repr, v17, 0, -v19) }
	p4.worldTarget[2] = { localToWorld(p4.vehicle.wheels[p4.vehicle.aiConveyorBelt.centerWheelIndex].repr, -v17, 0, -v19) }
	p4.lastPos = { v8, v9, v10 }
	p4.distanceMoved = 0
	p4.fistTimeChange = true
end
function AIDriveStrategyConveyor.update(_, _) end
function AIDriveStrategyConveyor.getDriveData(p21, _, _, _, _)
	local _, v22, v23 = localToLocal(p21.vehicle.wheels[p21.vehicle.aiConveyorBelt.backWheelIndex].repr, p21.vehicle.components[1].node, 0, 0, 0)
	local v24, v25, v26 = localToWorld(p21.vehicle.components[1].node, 0, v22, v23)
	local v27 = MathUtil.vector2Length(v24 - p21.lastPos[1], v26 - p21.lastPos[3])
	p21.distanceMoved = p21.distanceMoved + v27
	p21.lastPos = { v24, v25, v26 }
	if p21.distanceMoved >= p21.distanceToMove then
		if p21.fistTimeChange then
			p21.distanceToMove = p21.distanceToMove * 2
			p21.fistTimeChange = false
		end
		p21.distanceMoved = 0
		if p21.currentTarget == 1 then
			p21.currentTarget = 2
		else
			p21.currentTarget = 1
		end
	end
	local v28 = p21.distanceMoved / p21.distanceToMove * 3.14
	local v29 = math.sin(v28)
	local v30 = math.clamp(v29, 0.1, 0.5) * 2
	local v31 = true
	if p21.currentTarget == 2 then
		v31 = not v31
	end
	return p21.worldTarget[p21.currentTarget][1], p21.worldTarget[p21.currentTarget][3], v31, p21.vehicle.aiConveyorBelt.speed * v30, 100
end

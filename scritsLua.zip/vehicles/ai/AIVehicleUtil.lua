AIVehicleUtil = {}
AIVehicleUtil.VALID_AREA_THRESHOLD = 0.02
AIVehicleUtil.AREA_OVERLAP = 0.26
function AIVehicleUtil.driveToPoint(p1, p2, p3, p4, p5, p6, p7, p8, p9)
	if p1.finishedFirstUpdate then
		if p4 then
			local v10 = p6 * 0.5
			local v11 = p7 * 0.5
			local v12 = -v10
			local v13
			if p6 > 0 then
				v13 = -v11
				v12 = v10
			else
				v13 = v11
			end
			local v14, _, v15 = MathUtil.getLineLineIntersection2D(v10, v11, v13, v12, 0, 0, p6, 0)
			if p9 == nil or not p9 then
				local v16
				if v14 and math.abs(v15) < 100000 then
					v16 = p1:getSteeringRotTimeByCurvature(1 / (p6 * v15))
					if p1:getReverserDirection() < 0 then
						v16 = -v16
					end
				else
					v16 = 0
				end
				local v17
				if v16 >= 0 then
					local v18 = p1.maxRotTime
					v17 = math.min(v16, v18)
				else
					local v19 = p1.minRotTime
					v17 = math.max(v16, v19)
				end
				if p1.rotatedTime < v17 then
					local v20 = p1.rotatedTime + p2 * p1:getAISteeringSpeed()
					p1.rotatedTime = math.min(v20, v17)
				else
					local v21 = p1.rotatedTime - p2 * p1:getAISteeringSpeed()
					p1.rotatedTime = math.max(v21, v17)
				end
				local v22 = v17 - p1.rotatedTime
				local v23 = math.abs(v22)
				local v24 = p1.maxRotTime
				local v25 = -p1.minRotTime
				local v26 = v23 / math.max(v24, v25)
				local v27 = 1 - math.pow(v26, 0.25)
				if p8 * v27 < 1 then
					v27 = 1 / p8
					p3 = 0
				end
				p8 = p8 * v27
			end
		end
		p1:getMotor():setSpeedLimit((math.min(p8, p1:getCruiseControlSpeed())))
		if p1:getCruiseControlState() ~= Drivable.CRUISECONTROL_STATE_ACTIVE then
			p1:setCruiseControlState(Drivable.CRUISECONTROL_STATE_ACTIVE)
		end
		local v28 = not p4 and 0 or p3
		if not p5 then
			v28 = -v28
		end
		WheelsUtil.updateWheelsPhysics(p1, p2, p1.lastSpeedReal * p1.movingDirection, v28, not p4, true)
	end
end
function AIVehicleUtil.driveAlongCurvature(p29, p30, p31, p32, p33)
	local v34 = p32 or (1 / 0)
	p29.rotatedTime = -(p29:getSteeringRotTimeByCurvature(p31) * p29:getSteeringDirection())
	if p29.finishedFirstUpdate then
		if v34 > 0 then
			if p29:getCruiseControlState() ~= Drivable.CRUISECONTROL_STATE_ACTIVE then
				p29:setCruiseControlState(Drivable.CRUISECONTROL_STATE_ACTIVE)
			end
		else
			p33 = 0
		end
		p29:getMotor():setSpeedLimit(v34)
		WheelsUtil.updateWheelsPhysics(p29, p30, p29.lastSpeedReal * p29.movingDirection, p33, v34 > 0, true)
	end
end
function AIVehicleUtil.driveInDirection(p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46)
	local v47
	if p43 == nil or p44 == nil then
		v47 = 0
	else
		local v48 = math.acos(p44)
		v47 = math.deg(v48)
		if v47 < 0 then
			v47 = v47 + 180
		end
		local v49 = p43 > 0.00001
		if not p42 then
			v49 = not v49
		end
		local v50
		if v49 then
			local v51 = p35.maxRotTime
			local v52 = v47 / p37
			v50 = v51 * math.min(v52, 1)
		else
			local v53 = p35.minRotTime
			local v54 = v47 / p37
			v50 = v53 * math.min(v54, 1)
		end
		if p35.rotatedTime < v50 then
			local v55 = p35.rotatedTime + p36 * p35:getAISteeringSpeed()
			p35.rotatedTime = math.min(v55, v50)
		else
			local v56 = p35.rotatedTime - p36 * p35:getAISteeringSpeed()
			p35.rotatedTime = math.max(v56, v50)
		end
	end
	if p35.finishedFirstUpdate then
		if p45 == nil or p45 == 0 then
			if p40 > math.abs(v47) then
				p39 = p38
			end
		else
			if p40 <= math.abs(v47) then
				p45 = p45 * p46
			end
			p35.motor:setSpeedLimit(p45)
			if p35.cruiseControl.state == Drivable.CRUISECONTROL_STATE_ACTIVE then
				p39 = p38
			else
				p35:setCruiseControlState(Drivable.CRUISECONTROL_STATE_ACTIVE)
				p39 = p38
			end
		end
		local v57 = not p41 and 0 or p39
		if not p42 then
			v57 = -v57
		end
		WheelsUtil.updateWheelsPhysics(p35, p36, p35.lastSpeedReal * p35.movingDirection, v57, not p41, true)
	end
end
function AIVehicleUtil.getDriveDirection(p58, p59, p60, p61)
	local v62, _, v63 = worldToLocal(p58, p59, p60, p61)
	local v64 = MathUtil.vector2Length(v62, v63)
	if v64 > 0.00001 then
		local v65 = 1 / v64
		v62 = v62 * v65
		v63 = v63 * v65
	end
	return v62, v63
end
function AIVehicleUtil.getAverageDriveDirection(p66, p67, p68, p69, p70, p71, p72)
	local v73, _, v74 = worldToLocal(p66, (p67 + p70) * 0.5, (p68 + p71) * 0.5, (p69 + p72) * 0.5)
	local v75 = MathUtil.vector2Length(v73, v74)
	if v75 > 0.00001 then
		v73 = v73 / v75
		v74 = v74 / v75
	end
	return v73, v74, v75
end
function AIVehicleUtil.getAttachedImplementsAllowTurnBackward(p76)
	if p76.getAIAllowTurnBackward ~= nil and not p76:getAIAllowTurnBackward() then
		return false
	end
	if p76.getAttachedImplements ~= nil then
		for _, v77 in pairs(p76:getAttachedImplements()) do
			local v78 = v77.object
			if v78 ~= nil then
				if v78.getAIAllowTurnBackward ~= nil and not v78:getAIAllowTurnBackward() then
					return false
				end
				if not AIVehicleUtil.getAttachedImplementsAllowTurnBackward(v78) then
					return false
				end
			end
		end
	end
	return true
end
function AIVehicleUtil.getAttachedImplementsBlockTurnBackward(p79)
	if p79.getAIBlockTurnBackward ~= nil and p79:getAIBlockTurnBackward() then
		return true
	end
	if p79.getAttachedImplements ~= nil then
		for _, v80 in pairs(p79:getAttachedImplements()) do
			local v81 = v80.object
			if v81 ~= nil then
				if v81.getAIBlockTurnBackward ~= nil and v81:getAIBlockTurnBackward() then
					return true
				end
				if AIVehicleUtil.getAttachedImplementsBlockTurnBackward(v81) then
					return true
				end
			end
		end
	end
	return false
end
function AIVehicleUtil.getAttachedImplementsMaxTurnRadius(p82)
	local v83 = -1
	if p82.getAttachedImplements ~= nil then
		for _, v84 in pairs(p82:getAttachedImplements()) do
			local v85 = v84.object
			if v85 ~= nil then
				local v86
				if v85.getAITurnRadiusLimitation == nil then
					v86 = v83
				else
					v86 = v85:getAITurnRadiusLimitation()
					if v86 == nil then
						v86 = v83
					elseif v83 >= v86 then
						v86 = v83
					end
				end
				v83 = AIVehicleUtil.getAttachedImplementsMaxTurnRadius(v85)
				if v86 >= v83 then
					v83 = v86
				end
			end
		end
	end
	return v83
end
function AIVehicleUtil.getAIToolReverserDirectionNode(p87)
	for _, v88 in pairs(p87:getAttachedImplements()) do
		if v88.object ~= nil and v88.object.getAIToolReverserDirectionNode ~= nil then
			local v89 = v88.object:getAIToolReverserDirectionNode() or AIVehicleUtil.getAIToolReverserDirectionNode(v88.object)
			if v89 ~= nil then
				return v89
			end
		end
	end
	return nil
end
function AIVehicleUtil.getMaxToolRadius(p90)
	local _, v91, v92, v93 = p90.object:getAITurnRadiusLimitation()
	local v94 = p90.object.rootVehicle
	local v95 = AIVehicleUtil.getAttachedImplementsMaxTurnRadius(v94)
	local v96 = v95 == -1 and 0 or v95
	if v91 then
		local v97 = p90.object:getActiveInputAttacherJoint()
		for _, v98 in pairs(p90.object:getInputAttacherJoints()) do
			if v91 == v98.node then
				v91 = v97.node
				break
			end
		end
		local v99, _, v100 = localToLocal(v91, p90.object.components[1].node, 0, 0, 0)
		for _, v101 in pairs(v92) do
			local v102, _, v103 = localToLocal(v101.repr, p90.object.components[1].node, 0, 0, 0)
			local v104 = v102 - v99
			local v105 = v103 - v100
			local v106 = nil
			if v91 == v97.node then
				local v107 = p90.object:getAttacherVehicle():getAttacherJointDescFromObject(p90.object)
				local v108 = v107.upperRotLimit[2]
				local v109 = v107.lowerRotLimit[2]
				v106 = math.max(v108, v109) * v97.lowerRotLimitScale[2]
			else
				for _, v110 in pairs(p90.object.componentJoints) do
					if v91 == v110.jointNode then
						local v111 = v110.rotLimit[1]
						local v112 = math.max(v106 or 0, v111) or 0
						local v113 = v110.rotLimit[2]
						local v114 = math.max(v112, v113) or 0
						local v115 = v110.rotLimit[3]
						v106 = math.max(v114, v115)
						break
					end
				end
			end
			if v106 == nil then
				Logging.warning("AI rotation node \'%s\' could not be found as component joint or attacher joint on \'%s\'", getName(v91), p90.object.configFileName)
			else
				local v116 = v106 * v93
				local v117 = v104 * math.cos(v116) - v105 * math.sin(v116)
				local v118 = v104 * math.sin(v116) + v105 * math.cos(v116)
				local v119 = -v118
				local v120, v121
				if v101.steering.steeringAxleScale == 0 or v101.steering.steeringAxleRotMax == 0 then
					v120 = v117
					v121 = v119
				else
					local v122 = v101.steering.steeringAxleRotMax
					local v123 = v119 * math.cos(v122)
					local v124 = v101.steering.steeringAxleRotMax
					v121 = v123 - v117 * math.sin(v124)
					local v125 = v101.steering.steeringAxleRotMax
					local v126 = v119 * math.sin(v125)
					local v127 = v101.steering.steeringAxleRotMax
					v120 = v126 + v117 * math.cos(v127)
				end
				local v128, v129, _ = MathUtil.getLineLineIntersection2D(0, 0, 1, 0, v117, v118, v121, v120)
				if v128 then
					local v130 = math.abs(v129)
					v96 = math.max(v96, v130)
				end
			end
		end
	end
	return v96
end
function AIVehicleUtil.updateInvertLeftRightMarkers(p131, p132)
	if p132.getAIMarkers ~= nil then
		local v133, v134, _ = p132:getAIMarkers()
		if v133 ~= nil and v134 ~= nil then
			local v135, _, _ = localToLocal(v133, p131:getAIDirectionNode(), 0, 0, 0)
			local v136, _, _ = localToLocal(v134, p131:getAIDirectionNode(), 0, 0, 0)
			if v135 < v136 then
				p132:setAIMarkersInverted()
			end
		end
	end
end
function AIVehicleUtil.getValidityOfTurnDirections(p137, p138)
	local v139 = p137:getAIDirectionNode()
	local v140 = p137:getAttachedAIImplements()
	local v141 = (1 / 0)
	local v142 = (-1 / 0)
	local v143 = 5
	local v144 = 0
	local v145 = 0
	for _, v146 in pairs(v140) do
		local v147, v148, v149 = v146.object:getAIMarkers()
		local _, _, v150 = localToLocal(v147, v139, 0, 0, 0)
		local _, _, v151 = localToLocal(v148, v139, 0, 0, 0)
		local _, _, v152 = localToLocal(v149, v139, 0, 0, 0)
		v141 = math.min(v141, v150, v151, v152)
		v142 = math.max(v142, v150, v151, v152)
	end
	local v153
	if p138 == nil then
		v153 = (1 / 0)
		for _, v154 in pairs(v140) do
			local v155, v156, _ = v154.object:getAIMarkers()
			local v157, _, _ = localToLocal(v155, v139, 0, 0, 0)
			local v158, _, _ = localToLocal(v156, v139, 0, 0, 0)
			local v159 = v157 - v158
			local v160 = math.abs(v159)
			v153 = math.min(v153, v160)
		end
	else
		local v161 = p138.sideOffsetRight - p138.sideOffsetLeft
		v153 = math.abs(v161)
	end
	local v162 = p137.aiDriveDirection[1]
	local v163 = p137.aiDriveDirection[2]
	local v164 = -v163
	local v165 = v162
	for _, v166 in pairs(v140) do
		local v167, v168, _ = v166.object:getAIMarkers()
		local v169, v170, _ = localToLocal(v167, v139, 0, 0, 0)
		local v171, v172, _ = localToLocal(v168, v139, 0, 0, 0)
		local v173 = v169 - v171
		local v174 = math.abs(v173)
		local v175 = v143 + (v142 - v141)
		local v176 = v153 * 1.3 + 2
		local v177 = v175 + math.max(v176, 5)
		local v178, _, v179 = localToWorld(v139, v169, v170, v142 + 5)
		local v180, _, v181 = localToWorld(v139, v171, v172, v142 + 5)
		local v182 = v178 - v164 * v174
		local v183 = v179 - v162 * v174
		local v184 = v178 - v165 * v177
		local v185 = v179 - v163 * v177
		local v186 = v180 + v164 * v174
		local v187 = v181 + v162 * v174
		local v188 = v180 - v165 * v177
		local v189 = v181 - v163 * v177
		local v190, v191 = AIVehicleUtil.getAIAreaOfVehicle(v166.object, v178, v179, v182, v183, v184, v185)
		local v192, v193 = AIVehicleUtil.getAIAreaOfVehicle(v166.object, v180, v181, v186, v187, v188, v189)
		if v191 > 0 then
			v144 = v144 + v190 / v191
		end
		if v193 > 0 then
			v145 = v145 + v192 / v193
		end
		if VehicleDebug.state == VehicleDebug.DEBUG_AI then
			local v194 = getTerrainHeightAtWorldPos(g_terrainNode, v178, 0, v179) + 2
			local v195 = getTerrainHeightAtWorldPos(g_terrainNode, v182, 0, v183) + 2
			local v196 = getTerrainHeightAtWorldPos(g_terrainNode, v184, 0, v185) + 2
			local v197 = getTerrainHeightAtWorldPos(g_terrainNode, v180, 0, v181) + 2
			local v198 = getTerrainHeightAtWorldPos(g_terrainNode, v186, 0, v187) + 2
			p137:addAIDebugLine({ v178, v194, v179 }, { v182, v195, v183 }, { 0.5, 0.5, 0.5 })
			p137:addAIDebugLine({ v178, v194, v179 }, { v184, v196, v185 }, { 0.5, 0.5, 0.5 })
			p137:addAIDebugLine({ v180, v197, v181 }, { v186, v198, v187 }, { 0.5, 0.5, 0.5 })
			p137:addAIDebugLine({ v180, v197, v181 }, { v188, getTerrainHeightAtWorldPos(g_terrainNode, v188, 0, v189) + 2, v189 }, { 0.5, 0.5, 0.5 })
		end
	end
	return v144 / #v140, v145 / #v140
end
function AIVehicleUtil.checkImplementListForValidGround(p199, p200, p201)
	local v202 = false
	for _, v203 in pairs(p199:getAttachedAIImplements()) do
		local v204, v205, _ = v203.object:getAIMarkers()
		local v206, _, v207 = getWorldTranslation(v204)
		local v208, _, v209 = getWorldTranslation(v205)
		local v210 = v206 + p199.aiDriveDirection[1] * p200
		local v211 = v207 + p199.aiDriveDirection[2] * p200
		local v212 = v208 + p199.aiDriveDirection[1] * p200
		local v213 = v209 + p199.aiDriveDirection[2] * p200
		local v214 = v210 + p199.aiDriveDirection[1] * p201
		local v215 = v211 + p199.aiDriveDirection[2] * p201
		local v216, v217 = AIVehicleUtil.getAIAreaOfVehicle(v203.object, v210, v211, v212, v213, v214, v215)
		if VehicleDebug.state == VehicleDebug.DEBUG_AI then
			p199:addAIDebugText(string.format("area=%.1f areaTotal=%.1f", v216, v217))
			local v218 = getTerrainHeightAtWorldPos(g_terrainNode, v210, 0, v211) + 2
			p199:addAIDebugLine({ v210, v218, v211 }, { v212, getTerrainHeightAtWorldPos(g_terrainNode, v212, 0, v213) + 2, v213 }, { 1, 0, 0 })
			p199:addAIDebugLine({ v210, v218, v211 }, { v214, getTerrainHeightAtWorldPos(g_terrainNode, v214, 0, v215) + 2, v215 }, { 1, 0, 0 })
		end
		v202 = v202 or v216 > 0
	end
	return v202
end
function AIVehicleUtil.getAreaDimensions(p219, p220, p221, p222, p223, p224, p225, p226)
	local v227
	if p226 == nil or p226 then
		v227 = -p223
	else
		v227 = p223
	end
	local v228, _, v229 = localToWorld(p221, v227, 0, p224)
	local v230, _, v231 = localToWorld(p222, p223, 0, p224)
	return v228 - 0.5 * p219, v229 - 0.5 * p220, v230 - 0.5 * p219, v231 - 0.5 * p220, v228 + p225 * p219, v229 + p225 * p220
end
function AIVehicleUtil.getIsAreaOwned(p232, p233, p234, p235, p236, _, _)
	local v237 = p232:getAIJobFarmId()
	local v238 = (p233 + p235) * 0.5
	local v239 = (p234 + p236) * 0.5
	return g_farmlandManager:getIsOwnedByFarmAtWorldPosition(v237, v238, v239) and true or (g_missionManager:getIsMissionWorkAllowed(v237, v238, v239, nil, p232) and true or false)
end
function AIVehicleUtil.getAIAreaOfVehicle(p240, p241, p242, p243, p244, p245, p246)
	if #p240:getAIDensityHeightTypeRequirements() > 0 then
		local v247 = p240:getAIDensityHeightTypeRequirements()
		return AIVehicleUtil.getAIDensityHeightArea(p241, p242, p243, p244, p245, p246, v247)
	else
		local v248, v249 = p240:getFieldCropsQuery()
		if v249 then
			return AIVehicleUtil.getAIFruitArea(p241, p242, p243, p244, p245, p246, v248)
		else
			return 0, 0
		end
	end
end
function AIVehicleUtil.getAIFruitArea(p250, p251, p252, p253, p254, p255, p256)
	local v257, v258, v259, v260, v261, v262 = MathUtil.getXZWidthAndHeight(p250, p251, p252, p253, p254, p255)
	return p256:getParallelogram(v257, v258, v259, v260, v261, v262, false)
end
function AIVehicleUtil.getAIDensityHeightArea(p263, p264, p265, p266, p267, p268, p269)
	local _, v270, _ = FSDensityMapUtil.getFieldDensity(p263, p264, p265, p266, p267, p268)
	if v270 == 0 then
		return 0, 0
	end
	local v271 = 0
	local v272 = 0
	for _, v273 in pairs(p269) do
		if v273.fillType ~= FillType.UNKNOWN then
			local v274, v275
			v274, v275, v272 = DensityMapHeightUtil.getFillLevelAtArea(v273.fillType, p263, p264, p265, p266, p267, p268)
			v271 = v271 + v275
		end
	end
	return v271, v272
end

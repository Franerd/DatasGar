AIDriveStrategyCombine = {}
local v_u_1 = Class(AIDriveStrategyCombine, AIDriveStrategy)
function AIDriveStrategyCombine.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = AIDriveStrategy.new(p2, p3 or v_u_1)
	v4.combines = {}
	v4.notificationFullGrainTankShown = false
	v4.notificationGrainTankWarningShown = false
	v4.beaconLightsActive = false
	v4.slowDownFillLevel = 200
	v4.slowDownStartSpeed = 20
	v4.forageHarvesterFoundTimer = 0
	v4.waitForStrawModeActive = false
	v4.waitForStrawModeStartPosition = { 0, 0 }
	v4.waitForStrawModeLastPosition = { 0, 0 }
	v4.waitForStrawModeReturnToStart = false
	v4.waitForStrawModeReturnToStartDistance = 0
	return v4
end
function AIDriveStrategyCombine.setAIVehicle(p5, p6)
	AIDriveStrategyCombine:superClass().setAIVehicle(p5, p6)
	for _, v7 in pairs(p5.vehicle.rootVehicle.childVehicles) do
		if SpecializationUtil.hasSpecialization(Combine, v7.specializations) then
			local v8 = p5.combines
			table.insert(v8, v7)
		end
	end
end
function AIDriveStrategyCombine.update(p9, _)
	for _, v10 in pairs(p9.combines) do
		if v10.spec_pipe ~= nil then
			local v11 = v10:getCurrentDischargeNode()
			if (v11 == nil and 0 or v10:getFillUnitCapacity(v11.fillUnitIndex)) == (1 / 0) then
				local v12 = p9.vehicle.rootVehicle
				if v12.getAIFieldWorkerIsTurning ~= nil and not v12:getAIFieldWorkerIsTurning() then
					local v13 = NetworkUtil.getObject(v10.spec_pipe.nearestObjectInTriggers.objectId)
					if v13 ~= nil then
						local v14 = v10.spec_pipe.nearestObjectInTriggers.fillUnitIndex
						if v10:getDischargeFillType(v11) == FillType.UNKNOWN then
							local v15 = v13:getFillUnitFillType(v14)
							if v15 == FillType.UNKNOWN then
								v15 = v13:getFillUnitFirstSupportedFillType(v14)
							end
							v10:setForcedFillTypeIndex(v15)
						else
							v10:setForcedFillTypeIndex(nil)
						end
					end
				end
			end
		end
	end
end
function AIDriveStrategyCombine.getDriveData(p16, _, p17, _, p18)
	local v19 = p16.vehicle.rootVehicle
	local v20
	if v19.getAIFieldWorkerIsTurning == nil then
		v20 = false
	else
		v20 = v19:getAIFieldWorkerIsTurning()
	end
	local v21 = true
	local v22 = false
	local v23 = (1 / 0)
	for _, v24 in pairs(p16.combines) do
		if v24.spec_pipe ~= nil then
			local v25 = false
			local v26 = false
			local v27 = v24:getCurrentDischargeNode()
			local v28, v29
			if v27 == nil then
				v28 = 0
				v29 = 0
			else
				v29 = v24:getFillUnitFillLevel(v27.fillUnitIndex)
				v28 = v24:getFillUnitCapacity(v27.fillUnitIndex)
			end
			local v30 = NetworkUtil.getObject(v24.spec_pipe.nearestObjectInTriggers.objectId) ~= nil and true or v25
			local v31 = v24.spec_pipe.nearestObjectInTriggerIgnoreFillLevel and true or v26
			local v32 = v24.spec_pipe.targetState
			local v33 = v24.spec_pipe.currentState
			local v34 = v24.spec_pipe.turnOnAllowedStates
			if next(v34) == nil then
				v34 = nil
			end
			if v28 == (1 / 0) then
				if v32 ~= 2 then
					v24:setPipeState(2)
				end
				if not v20 then
					local v35, _ = v24:getDischargeTargetObject(v27)
					if v30 then
						v21 = v35 ~= nil
					else
						v21 = v30
					end
					if VehicleDebug.state == VehicleDebug.DEBUG_AI then
						if v30 then
							if v30 and v35 == nil then
								p16.vehicle:addAIDebugText("COMBINE -> Waiting for pipe hitting the trailer")
							end
						else
							p16.vehicle:addAIDebugText("COMBINE -> Waiting for trailer enter the trigger")
						end
					end
				end
			else
				if 0.8 * v28 < v29 then
					if not p16.beaconLightsActive then
						p16.vehicle:setAIMapHotspotBlinking(true)
						p16.vehicle:setBeaconLightsVisibility(true)
						p16.beaconLightsActive = true
					end
					if not p16.notificationGrainTankWarningShown and p16.vehicle:getOwnerFarmId() == g_localPlayer.farmId then
						g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("ai_messageErrorGrainTankIsNearlyFull"), p16.vehicle:getCurrentHelper().name))
						p16.notificationGrainTankWarningShown = true
					end
				else
					if p16.beaconLightsActive then
						p16.vehicle:setAIMapHotspotBlinking(false)
						p16.vehicle:setBeaconLightsVisibility(false)
						p16.beaconLightsActive = false
					end
					p16.notificationGrainTankWarningShown = false
				end
				local v36
				if v29 == v28 then
					v36 = 2
					p16.wasCompletelyFull = true
					if not p16.notificationFullGrainTankShown and p16.vehicle:getOwnerFarmId() == g_localPlayer.farmId then
						g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("ai_messageErrorGrainTankIsFull"), p16.vehicle:getCurrentHelper().name))
						p16.notificationFullGrainTankShown = true
					end
				else
					p16.notificationFullGrainTankShown = false
					v36 = v32
				end
				if v30 then
					v36 = (v34 == nil or v34[2] == true) and 2 or (v29 > 0.1 and 2 or v36)
				end
				if not v30 and v29 < v28 * 0.8 then
					p16.wasCompletelyFull = false
					if not v24:getIsTurnedOn() and v24:getCanBeTurnedOn() then
						v24:aiImplementStartLine()
						for _, v37 in ipairs(p16.vehicle:getAttachedAIImplements()) do
							v37.object:aiImplementStartLine()
						end
					end
				end
				local v38 = not v30 and (not v31 and v29 < v28) and 1 or v36
				if v29 < 0.1 then
					if not v24.spec_pipe.aiFoldedPipeUsesTrailerSpace then
						v38 = not (v30 or v31) and 1 or v38
						if not v24:getIsTurnedOn() and v24:getCanBeTurnedOn() then
							v24:aiImplementStartLine()
							for _, v39 in ipairs(p16.vehicle:getAttachedAIImplements()) do
								v39.object:aiImplementStartLine()
							end
						end
					end
					p16.wasCompletelyFull = false
				end
				if v32 ~= v38 then
					v24:setPipeState(v38)
				end
				v21 = v29 < v28
				if v34 ~= nil and v34[v33] ~= true then
					v21 = false
					if VehicleDebug.state == VehicleDebug.DEBUG_AI then
						p16.vehicle:addAIDebugText("COMBINE -> Stopping AI because we cannot overload while harvesting")
					end
				end
				if v38 == 2 and p16.wasCompletelyFull then
					v21 = false
					if VehicleDebug.state == VehicleDebug.DEBUG_AI then
						p16.vehicle:addAIDebugText("COMBINE -> Waiting for trailer to unload")
					end
				end
				local v40 = v28 - v29
				if v40 < p16.slowDownFillLevel then
					v23 = 2 + v40 / p16.slowDownFillLevel * p16.slowDownStartSpeed
					if VehicleDebug.state == VehicleDebug.DEBUG_AI then
						p16.vehicle:addAIDebugText(string.format("COMBINE -> Slow down because nearly full: %.2f", v23))
					end
				end
			end
			if v20 and (v30 and (v28 ~= (1 / 0) and v24:getCanDischargeToObject(v27))) then
				local v41 = v24.spec_combine
				if v41.loadingDelay > 0 then
					for v42 = 1, #v41.loadingDelaySlots do
						local v43 = v41.loadingDelaySlots[v42]
						if v43.valid then
							v29 = v29 + v43.fillLevelDelta
						end
					end
				end
				if v29 > 0 then
					v21 = false
				end
				if VehicleDebug.state == VehicleDebug.DEBUG_AI and not v21 then
					p16.vehicle:addAIDebugText("COMBINE -> Unload to trailer on headland")
				end
			end
			if not v30 and (v24.spec_combine.isSwathActive and v24.spec_combine.strawPSenabled) then
				v22 = true
			end
		end
	end
	if v20 and v22 then
		if not p16.waitForStrawModeActive then
			p16.waitForStrawModeActive = true
			local v44 = p16.waitForStrawModeStartPosition
			local v45 = p16.waitForStrawModeStartPosition
			v44[1] = p17
			v45[2] = p18
		end
		if VehicleDebug.state == VehicleDebug.DEBUG_AI then
			p16.vehicle:addAIDebugText("COMBINE -> Waiting for straw to drop")
		end
		local v46, _, v47 = localToWorld(p16.vehicle:getAIDirectionNode(), 0, 0, -10)
		return v46, v47, false, 6, MathUtil.vector2Length(p17 - v46, p18 - v47)
	else
		if p16.waitForStrawModeActive then
			p16.waitForStrawModeActive = false
			p16.waitForStrawModeReturnToStart = true
			local v48 = p16.waitForStrawModeLastPosition
			local v49 = p16.waitForStrawModeLastPosition
			v48[1] = p17
			v49[2] = p18
			p16.waitForStrawModeReturnToStartDistance = MathUtil.vector2Length(p17 - p16.waitForStrawModeStartPosition[1], p18 - p16.waitForStrawModeStartPosition[2])
		end
		if p16.waitForStrawModeReturnToStart then
			local v50 = MathUtil.vector2Length(p17 - p16.waitForStrawModeLastPosition[1], p18 - p16.waitForStrawModeLastPosition[2])
			local v51 = p16.waitForStrawModeLastPosition
			local v52 = p16.waitForStrawModeLastPosition
			v51[1] = p17
			v52[2] = p18
			p16.waitForStrawModeReturnToStartDistance = p16.waitForStrawModeReturnToStartDistance - v50
			if p16.waitForStrawModeReturnToStartDistance >= 0 then
				if VehicleDebug.state == VehicleDebug.DEBUG_AI then
					p16.vehicle:addAIDebugText(string.format("COMBINE -> Returning to turn start position (%.1fm)", p16.waitForStrawModeReturnToStartDistance))
				end
				local v53 = p16.waitForStrawModeStartPosition[1]
				local v54 = p16.waitForStrawModeStartPosition[2]
				return v53, v54, true, 10, MathUtil.vector2Length(p17 - v53, p18 - v54)
			end
			p16.waitForStrawModeReturnToStart = false
		end
		if v21 then
			return nil, nil, nil, v23, nil
		else
			return 0, 1, true, 0, (1 / 0)
		end
	end
end
function AIDriveStrategyCombine.updateDriving(_, _) end

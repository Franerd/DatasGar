AIDriveStrategyStonePicker = {}
local v_u_1 = Class(AIDriveStrategyStonePicker, AIDriveStrategy)
function AIDriveStrategyStonePicker.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = AIDriveStrategy.new(p2, p3 or v_u_1)
	v4.stonePickers = {}
	v4.notificationFullTankShown = false
	return v4
end
function AIDriveStrategyStonePicker.setAIVehicle(p5, p6)
	AIDriveStrategyStonePicker:superClass().setAIVehicle(p5, p6)
	if SpecializationUtil.hasSpecialization(StonePicker, p5.vehicle.specializations) then
		local v7 = p5.stonePickers
		local v8 = p5.vehicle
		table.insert(v7, v8)
	end
	for _, v9 in pairs(p5.vehicle:getAttachedAIImplements()) do
		if SpecializationUtil.hasSpecialization(StonePicker, v9.object.specializations) then
			local v10 = p5.stonePickers
			local v11 = v9.object
			table.insert(v10, v11)
		end
	end
end
function AIDriveStrategyStonePicker.update(_, _) end
function AIDriveStrategyStonePicker.getDriveData(p12, _, _, _, _)
	local v13 = true
	for _, v14 in pairs(p12.stonePickers) do
		local v15 = v14.spec_stonePicker
		local v16 = v14:getFillUnitFillLevel(v15.fillUnitIndex)
		local v17 = v14:getFillUnitCapacity(v15.fillUnitIndex)
		if v14.getDischargeState ~= nil and v14:getDischargeState() ~= Dischargeable.DISCHARGE_STATE_OFF then
			v13 = false
			local v18 = v14:getCurrentDischargeNode()
			if v18 ~= nil then
				local v19, _ = v14:getDischargeTargetObject(v18)
				if v19 == nil or v16 <= 0 then
					v14:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF)
				end
			end
		end
		if v14.getTipState ~= nil and v14:getTipState() ~= Trailer.TIPSTATE_CLOSED then
			v13 = false
		end
		if v17 <= v16 then
			v13 = false
			if VehicleDebug.state == VehicleDebug.DEBUG_AI then
				p12.vehicle:addAIDebugText(string.format("STONE PICKER -> full"))
			end
			if p12.notificationFullTankShown ~= true then
				g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("ai_messageErrorTankIsFull"), p12.vehicle:getCurrentHelper().name))
				p12.notificationFullTankShown = true
			end
			if v14.getCurrentDischargeNode ~= nil then
				local v20 = v14:getCurrentDischargeNode()
				if v20 ~= nil then
					local v21, _ = v14:getDischargeTargetObject(v20)
					if v21 ~= nil then
						v14:setDischargeState(Dischargeable.DISCHARGE_STATE_OBJECT)
					end
				end
			end
		else
			p12.notificationFullTankShown = false
		end
	end
	if v13 then
		return nil, nil, nil, (1 / 0), nil
	else
		return 0, 1, true, 0, (1 / 0)
	end
end
function AIDriveStrategyStonePicker.updateDriving(_, _) end

VehicleLoadingData = {}
VehicleLoadingData.MIN_SPAWN_PLACE_WIDTH = 4
VehicleLoadingData.MIN_SPAWN_PLACE_LENGTH = 4
VehicleLoadingData.MIN_SPAWN_PLACE_HEIGHT = 3
VehicleLoadingData.SPAWN_WIDTH_OFFSET = 1
local v_u_1 = Class(VehicleLoadingData)
function VehicleLoadingData.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.isValid = false
	v4.validLocation = true
	v4.storeItem = nil
	v4.vehicles = {}
	v4.vehiclesToLoad = 0
	v4.loadingVehicles = {}
	v4.loadedVehicles = {}
	v4.loadingState = nil
	v4.savegameData = nil
	v4.configurations = {}
	v4.boughtConfigurations = {}
	v4.saleItem = nil
	v4.propertyState = VehiclePropertyState.OWNED
	v4.ownerFarmId = AccessHandler.EVERYONE
	v4.isRegistered = true
	v4.forceServer = false
	v4.isSaved = true
	v4.addToPhysics = true
	v4.price = nil
	v4.position = { 0, 0, 0 }
	v4.rotation = { 0, 0, 0 }
	v4.ignoreShopOffset = false
	v4.centerVehicle = true
	v4.customParameters = {}
	return v4
end
function VehicleLoadingData.setFilename(p5, p6)
	local v7 = g_storeManager:getItemByXMLFilename(p6)
	if v7 == nil then
		Logging.error("Unable to find vehicle storeitem for \'%s\'", p6)
		printCallstack()
	else
		p5:setStoreItem(v7)
	end
end
function VehicleLoadingData.setStoreItem(p8, p9)
	if p9 ~= nil then
		p8.storeItem = p9
		p8.rotation[2] = p9.rotation
		p8.vehicles = {}
		if p8.storeItem.bundleInfo == nil then
			local v10 = p8.vehicles
			local v11 = {
				["xmlFilename"] = p9.xmlFilename
			}
			table.insert(v10, v11)
		else
			p8.attacherInfo = p8.storeItem.bundleInfo.attacherInfo
			for _, v12 in pairs(p8.storeItem.bundleInfo.bundleItems) do
				local v13 = p8.vehicles
				local v14 = {
					["xmlFilename"] = v12.xmlFilename,
					["offset"] = v12.offset,
					["rotationOffset"] = v12.rotationOffset
				}
				table.insert(v13, v14)
			end
		end
	end
	p8.isValid = #p8.vehicles > 0
end
function VehicleLoadingData.setPropertyState(p15, p16)
	p15.propertyState = p16
end
function VehicleLoadingData.setOwnerFarmId(p17, p18)
	p17.ownerFarmId = p18
end
function VehicleLoadingData.setSaleItem(p19, p20)
	p19.saleItem = p20
	if p20 ~= nil then
		for v21, v22 in pairs(p20.boughtConfigurations) do
			if p19.boughtConfigurations[v21] == nil then
				p19.boughtConfigurations[v21] = {}
			end
			for v23, _ in pairs(v22) do
				p19.boughtConfigurations[v21][v23] = true
			end
		end
	end
end
function VehicleLoadingData.setSavegameData(p_u_24, p_u_25)
	p_u_24.savegameData = p_u_25
	if p_u_24.storeItem ~= nil and (p_u_25 ~= nil and p_u_25.xmlFile ~= 0) then
		p_u_25.xmlFile:iterate(p_u_25.key .. ".configuration", function(_, p26)
			-- upvalues: (copy) p_u_25, (copy) p_u_24
			local v27 = p_u_25.xmlFile:getValue(p26 .. "#name")
			local v28 = p_u_25.xmlFile:getValue(p26 .. "#id")
			p_u_24.configurations[v27] = ConfigurationUtil.getConfigIdBySaveId(p_u_24.storeItem.xmlFilename, v27, v28)
		end)
	end
end
function VehicleLoadingData.setConfigurations(p29, p30)
	if p30 == nil then
		p29.configurations = {}
	else
		p29.configurations = p30
	end
end
function VehicleLoadingData.setBoughtConfigurations(p31, p32)
	if p32 == nil then
		p31.boughtConfigurations = {}
	else
		p31.boughtConfigurations = p32
	end
end
function VehicleLoadingData.getConfigurations(p33, p34)
	local v35 = table.clone(p33.configurations)
	local v36 = table.clone(p33.boughtConfigurations)
	local v37 = g_storeManager:getItemByXMLFilename(p34)
	if v37 ~= nil and v37 ~= p33.storeItem then
		for v38, v39 in pairs(v35) do
			local v40 = true
			if v37.configurations == nil or v37.configurations[v38] == nil then
				v40 = false
			elseif v37.configurations[v38][v39] == nil then
				v40 = false
			end
			if not v40 then
				v35[v38] = nil
				v36[v38] = nil
			end
		end
	end
	if v37 ~= nil and v37.configurations ~= nil then
		for v41, v42 in pairs(v37.configurations) do
			local v43 = v35[v41]
			if v43 == nil then
				v43 = ConfigurationUtil.getDefaultConfigIdFromItems(v42)
				v35[v41] = v43
			end
			if v42[v43] ~= nil then
				local v44 = v42[v43]
				if v44.dependentConfigurations ~= nil then
					for _, v45 in ipairs(v44.dependentConfigurations) do
						v35[v45.name] = v45.index
					end
				end
			end
		end
	end
	return v35, v36
end
function VehicleLoadingData.setIsRegistered(p46, p47)
	p46.isRegistered = p47
end
function VehicleLoadingData.setForceServer(p48, p49)
	p48.forceServer = p49
end
function VehicleLoadingData.setIsSaved(p50, p51)
	p50.isSaved = p51
end
function VehicleLoadingData.setAddToPhysics(p52, p53)
	p52.addToPhysics = p53
end
function VehicleLoadingData.setCustomParameter(p54, p55, p56)
	p54.customParameters[p55] = p56
end
function VehicleLoadingData.getCustomParameter(p57, p58)
	return p57.customParameters[p58]
end
function VehicleLoadingData.setPosition(p59, p60, p61, p62, p63)
	if p61 == nil then
		p61 = getTerrainHeightAtWorldPos(g_terrainNode, p60, 0, p62) + (p63 or 0)
	end
	local v64 = p59.position
	local v65 = p59.position
	local v66 = p59.position
	v64[1] = p60
	v65[2] = p61
	v66[3] = p62
end
function VehicleLoadingData.setRotation(p67, p68, p69, p70)
	local v71 = p67.rotation
	local v72 = p67.rotation
	local v73 = p67.rotation
	v71[1] = p68
	v72[2] = p69
	v73[3] = p70
end
function VehicleLoadingData.setSpawnNode(p74, p75)
	local v76 = p74.position
	local v77 = p74.position
	local v78 = p74.position
	local v79, v80, v81 = getWorldTranslation(p75)
	v76[1] = v79
	v77[2] = v80
	v78[3] = v81
	local v82 = p74.rotation
	local v83 = p74.rotation
	local v84 = p74.rotation
	local v85, v86, v87 = getWorldRotation(p75)
	v82[1] = v85
	v83[2] = v86
	v84[3] = v87
end
function VehicleLoadingData.setIgnoreShopOffset(p88, p89)
	p88.ignoreShopOffset = p89
end
function VehicleLoadingData.setComponentPositionData(p90, p91)
	p90.componentPositionData = {}
	for v92, v93 in ipairs(p91.components) do
		p90.componentPositionData[v92] = {
			["translation"] = { getWorldTranslation(v93.node) },
			["rotation"] = { getWorldRotation(v93.node) }
		}
	end
end
function VehicleLoadingData.applyPositionData(p94, p95)
	if not p94.validLocation then
		return false
	end
	if p94.componentPositionData ~= nil then
		for v96 = 1, #p95.components do
			local v97 = p94.componentPositionData[v96]
			if v97 == nil then
				p95:setDefaultComponentPosition(v96)
			else
				p95:setWorldPosition(v97.translation[1], v97.translation[2], v97.translation[3], v97.rotation[1], v97.rotation[2], v97.rotation[3], v96, true)
			end
		end
		return true
	end
	if p94.savegameData == nil then
		local v98, v99, v100, v101, v102, v103 = p94:getPositionAndRotation(p95)
		p95:setAbsolutePosition(v98, v99, v100, v101, v102, v103)
		return true
	end
	local v104 = p94.savegameData
	if v104.useNewPosition then
		return p94:resetVehiclePosition(p95)
	end
	if v104.resetVehicles and not v104.keepPosition then
		return p94:resetVehiclePosition(p95)
	end
	local v105 = {}
	for _, v106 in v104.xmlFile:iterator(v104.key .. ".component") do
		local v107 = v104.xmlFile:getValue(v106 .. "#index")
		local v108, v109, v110 = v104.xmlFile:getValue(v106 .. "#position")
		local v111, v112, v113 = v104.xmlFile:getValue(v106 .. "#rotation")
		if v108 == nil or (v109 == nil or (v110 == nil or (v111 == nil or (v112 == nil or v113 == nil)))) then
			Logging.xmlWarning(v104.xmlFile, "Invalid component position in \'%s\' (%s)!", v104.key, p95.configFileName)
			return p94:resetVehiclePosition(p95)
		end
		if v105[v107] == nil then
			v105[v107] = {
				["x"] = v108,
				["y"] = v109,
				["z"] = v110,
				["xRot"] = v111,
				["yRot"] = v112,
				["zRot"] = v113
			}
		else
			Logging.xmlWarning(v104.xmlFile, "Duplicate component index \'%s\' in \'%s\' (%s)!", v107, v104.key, p95.configFileName)
		end
	end
	if next(v105) == nil then
		return p94:resetVehiclePosition(p95)
	end
	for v114 = 1, #p95.components do
		local v115 = v105[v114]
		if v115 == nil then
			p95:setDefaultComponentPosition(v114)
		else
			p95:setWorldPosition(v115.x, v115.y, v115.z, v115.xRot, v115.yRot, v115.zRot, v114, true)
		end
	end
	return true
end
function VehicleLoadingData.resetVehiclePosition(p116, p117)
	if not p116:setLoadingPlace(g_currentMission:getResetPlaces(), g_currentMission.usedLoadPlaces) then
		return false
	end
	p117:setAbsolutePosition(p116.position[1], p116.position[2], p116.position[3], p116.rotation[1], p116.rotation[2], p116.rotation[3])
	return true
end
function VehicleLoadingData.getPositionAndRotation(p118, p119)
	local v120 = nil
	local v121 = nil
	for v122, v123 in ipairs(p118.loadingVehicles) do
		if v123 == p119 then
			v120 = p118.vehicles[v122].offset
			v121 = p118.vehicles[v122].rotationOffset
		end
	end
	local v124, v125
	if p118.ignoreShopOffset or p118.storeItem == nil then
		v124 = v121
		v125 = v120
	else
		v125 = p118.storeItem.shopTranslationOffset
		if v125 == nil then
			v125 = v120
		elseif v120 ~= nil then
			v125 = v120
		end
		v124 = p118.storeItem.shopRotationOffset
		if v124 == nil then
			v124 = v121
		elseif v121 ~= nil then
			v124 = v121
		end
	end
	local v126 = p118.position[1]
	local v127 = p118.position[2]
	local v128 = p118.position[3]
	local v129 = p118.rotation[1]
	local v130 = p118.rotation[2]
	local v131 = p118.rotation[3]
	if v125 ~= nil or v124 ~= nil then
		local v132 = createTransformGroup("tempPositionNode")
		setWorldTranslation(v132, v126, v127, v128)
		setWorldRotation(v132, v129, v130, v131)
		if v125 ~= nil then
			local v133 = v125[1]
			local v134 = v125[2]
			local v135 = v125[3]
			if p118.centerVehicle then
				local v136 = StoreItemUtil.getSizeValues(p118.storeItem.xmlFilename, "vehicle", p118.storeItem.rotation, p118.configurations)
				v133 = v133 - v136.widthOffset
				v135 = v135 - v136.lengthOffset
			end
			v126, v127, v128 = localToWorld(v132, v133, v134, v135)
		end
		if v124 ~= nil then
			v129, v130, v131 = localRotationToWorld(v132, v124[1], v124[2], v124[3])
		end
		delete(v132)
	end
	return v126, v127, v128, v129, v130, v131
end
function VehicleLoadingData.setLoadingPlace(p137, p138, p139, p140, p141)
	if p137.storeItem == nil then
		Logging.error("No store item set before VehicleLoadingData:setLoadingPlace call")
		printCallstack()
		return false
	end
	local v142 = StoreItemUtil.getSizeValues(p137.storeItem.xmlFilename, "vehicle", p137.storeItem.rotation, p137.configurations)
	if p141 ~= true then
		local v143 = v142.width
		local v144 = VehicleLoadingData.MIN_SPAWN_PLACE_WIDTH
		v142.width = math.max(v143, v144)
		local v145 = v142.length
		local v146 = VehicleLoadingData.MIN_SPAWN_PLACE_LENGTH
		v142.length = math.max(v145, v146)
		local v147 = v142.height
		local v148 = VehicleLoadingData.MIN_SPAWN_PLACE_HEIGHT
		v142.height = math.max(v147, v148)
	end
	v142.width = v142.width + (p140 or VehicleLoadingData.SPAWN_WIDTH_OFFSET)
	local v149, v150, v151, v152, v153, _ = PlacementUtil.getPlace(p138, v142, p139, true, true, false, true)
	if v149 == nil then
		p137.validLocation = false
		return false
	end
	PlacementUtil.markPlaceUsed(p139, v152, v153)
	local v154 = p137.position
	local v155 = p137.position
	local v156 = p137.position
	v154[1] = v149
	v155[2] = v150
	v156[3] = v151
	p137.rotation[2] = p137.rotation[2] + MathUtil.getYRotationFromDirection(v152.dirPerpX, v152.dirPerpZ)
	return true
end
function VehicleLoadingData.load(p157, p158, p159, p160)
	g_currentMission.vehicleSystem:addPendingVehicleLoad(p157)
	p157.callback = p158
	p157.callbackTarget = p159
	p157.callbackArguments = p160
	p157.vehiclesToLoad = #p157.vehicles
	p157.loadingVehicles = {}
	p157.loadedVehicles = {}
	p157.loadingState = VehicleLoadingState.OK
	for _, v161 in ipairs(p157.vehicles) do
		local v162, v163 = g_vehicleTypeManager:getObjectTypeFromXML(v161.xmlFilename)
		v161.vehicleType = v162
		v161.vehicleClass = v163
		if v161.vehicleType == nil or v161.vehicleClass == nil then
			p157.loadingState = VehicleLoadingState.ERROR
			if p157.callback ~= nil then
				p157.callback(p157.callbackTarget, p157.loadedVehicles, p157.loadingState, p157.callbackArguments)
			end
			g_currentMission.vehicleSystem:removePendingVehicleLoad(p157)
			return
		end
	end
	for _, v164 in ipairs(p157.vehicles) do
		p157:loadVehicle(v164)
	end
end
function VehicleLoadingData.loadVehicle(p165, p166)
	local v167 = p165.forceServer or g_currentMission:getIsServer()
	local v168 = p165.forceServer or g_currentMission:getIsClient()
	local v169 = p166.vehicleClass.new(v167, v168)
	v169:setFilename(p166.xmlFilename)
	v169:setConfigurations(p165:getConfigurations(p166.xmlFilename))
	v169:setType(p166.vehicleType)
	v169:setLoadCallback(p165.onVehicleLoaded, p165, nil)
	v169:load(p165)
	local v170 = p165.loadingVehicles
	table.insert(v170, v169)
end
function VehicleLoadingData.cancelLoading(p171)
	p171.canceledLoading = true
	for _, v172 in ipairs(p171.loadingVehicles) do
		v172:delete()
	end
	if p171.callback ~= nil then
		p171.callback(p171.callbackTarget, {}, VehicleLoadingState.CANCELED, p171.callbackArguments)
	end
	g_currentMission.vehicleSystem:removePendingVehicleLoad(p171)
end
function VehicleLoadingData.loadVehicleOnClient(p_u_173, p174, p_u_175, _)
	local v176 = p_u_173.vehicles[1]
	local v177, _ = g_vehicleTypeManager:getObjectTypeFromXML(v176.xmlFilename)
	if v177 ~= nil then
		g_currentMission.vehicleSystem:addPendingVehicleLoad(p_u_173)
		p174:setFilename(v176.xmlFilename)
		p174:setConfigurations(p_u_173:getConfigurations(v176.xmlFilename))
		p174:setType(v177)
		p174:setLoadCallback(function(...)
			-- upvalues: (copy) p_u_173, (copy) p_u_175
			g_currentMission.vehicleSystem:removePendingVehicleLoad(p_u_173)
			p_u_175(...)
		end, p_u_173, nil)
		p174:load(p_u_173)
	end
end
function VehicleLoadingData.onVehicleLoaded(p178, p179, p180)
	if p178.canceledLoading then
		return
	end
	if p180 == VehicleLoadingState.OK then
		local v181 = p178.loadedVehicles
		table.insert(v181, p179)
		p179:setVisibility(false)
		p179:removeFromPhysics()
	else
		p178.loadingState = p180
		p179:delete()
	end
	p178.vehiclesToLoad = p178.vehiclesToLoad - 1
	if p178.vehiclesToLoad <= 0 then
		if p178.attacherInfo ~= nil then
			for _, v182 in pairs(p178.attacherInfo) do
				if p178.loadedVehicles[v182.bundleElement0] == nil or p178.loadedVehicles[v182.bundleElement1] == nil then
					Logging.error("Not all vehicles for bundle item could be loaded")
					p178.loadingState = VehicleLoadingState.ERROR
					break
				end
			end
		end
		if p178.loadingState == VehicleLoadingState.OK then
			for _, v183 in ipairs(p178.loadedVehicles) do
				v183:setVisibility(true)
				if p178.addToPhysics then
					v183:addToPhysics()
				end
				if p178.saleItem ~= nil then
					SpecializationUtil.raiseEvent(v183, "onSaleItemSet", p178.saleItem)
					v183.operatingTime = p178.saleItem.operatingTime
					v183.age = p178.saleItem.age
				end
				g_messageCenter:publish(MessageType.VEHICLE_LOADED, v183)
			end
			if p178.attacherInfo ~= nil then
				for _, v184 in pairs(p178.attacherInfo) do
					p178.loadedVehicles[v184.bundleElement0]:attachImplement(p178.loadedVehicles[v184.bundleElement1], v184.inputAttacherJointIndex, v184.attacherJointIndex, true, nil, false, true)
				end
			end
		else
			for v185 = #p178.loadedVehicles, 1, -1 do
				p178.loadedVehicles[v185]:delete()
				p178.loadedVehicles[v185] = nil
			end
		end
		if p178.callback ~= nil then
			p178.callback(p178.callbackTarget, p178.loadedVehicles, p178.loadingState, p178.callbackArguments)
		end
		g_currentMission.vehicleSystem:removePendingVehicleLoad(p178)
	end
end

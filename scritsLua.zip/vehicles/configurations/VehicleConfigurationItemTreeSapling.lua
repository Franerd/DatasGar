VehicleConfigurationItemTreeSapling = {}
VehicleConfigurationItemTreeSapling.SELECTOR = ConfigurationUtil.SELECTOR_MULTIOPTION
local v_u_1 = Class(VehicleConfigurationItemTreeSapling, VehicleConfigurationItem)
function VehicleConfigurationItemTreeSapling.new(p2, _)
	-- upvalues: (copy) v_u_1
	return VehicleConfigurationItemTreeSapling:superClass().new(p2, v_u_1)
end
function VehicleConfigurationItemTreeSapling.loadFromXML(p3, p4, p5, p6, p7, p8)
	if not VehicleConfigurationItemTreeSapling:superClass().loadFromXML(p3, p4, p5, p6, p7, p8) then
		return false
	end
	p3.useMapTreeTypes = p4:getValue(p6 .. "#useMapTreeTypes", false)
	if p3.useMapTreeTypes then
		p3.numSaplings = p4:getInt("vehicle.storeData.specs.capacity", 0)
	end
	p3.fillUnitIndex = p4:getValue(p6 .. "#fillUnitIndex", 1)
	p3.treeTypeName = p4:getValue(p6 .. "#treeType", "spruce")
	p3.variationName = p4:getValue(p6 .. "#variationName")
	p3.filename = p4:getValue(p6 .. "#filename", nil, p7)
	return true
end
function VehicleConfigurationItemTreeSapling.postLoad(p9, p10, p11, p12, p13, p14, p15, p16)
	VehicleConfigurationItemTreeSapling:superClass().postLoad(p9, p10, p11, p12, p13, p14, p15, p16)
	for _, v17 in ipairs(p14) do
		if v17.useMapTreeTypes then
			VehicleConfigurationItemTreeSapling.generateConfigurations(p14, p9, p16, v17)
			return
		end
	end
end
function VehicleConfigurationItemTreeSapling.generateConfigurations(p18, _, p19, p20)
	for v21 = #p18, 1, -1 do
		p18[v21] = nil
	end
	for _, v22 in ipairs(g_treePlantManager.treeTypes) do
		if #v22.stages > 1 then
			local v23 = VehicleConfigurationItemTreeSapling.new(p19)
			v23.name = v22.title
			v23.price = v22.saplingPrice * p20.numSaplings
			v23.saveId = v22.name
			v23.fillUnitIndex = p20.fillUnitIndex
			v23.treeTypeName = v22.name
			v23.variationName = p20.variationName
			v23.filename = nil
			table.insert(p18, v23)
			v23:setIndex(#p18)
			v23.configKey = p20.configKey
		end
	end
end
function VehicleConfigurationItemTreeSapling.registerXMLPaths(p24, p25, p26)
	VehicleConfigurationItemTreeSapling:superClass().registerXMLPaths(p24, p25, p26)
	p24:register(XMLValueType.BOOL, p26 .. "#useMapTreeTypes", "Create configuration for each tree type on the map", false)
	p24:register(XMLValueType.INT, p26 .. "#fillUnitIndex", "Index of the saplings fill unit", 1)
	p24:register(XMLValueType.STRING, p26 .. "#treeType", "Tree Type Name", "spruce")
	p24:register(XMLValueType.STRING, p26 .. "#variationName", "Stage variation name to use", "DEFAULT")
	p24:register(XMLValueType.FILENAME, p26 .. "#filename", "Custom tree sapling i3d file")
end

VehicleConfigurationDataObjectChange = {}
function VehicleConfigurationDataObjectChange.registerXMLPaths(p1, p2, p3)
	p1:register(XMLValueType.BOOL, p2 .. "#postLoadObjectChange", "Defines if the object changes are applied before or after post load (can be helpful if you manipulate wheel nodes, which is only possible before postLoad)", false)
	ObjectChangeUtil.registerObjectChangeXMLPaths(p1, p3)
end
function VehicleConfigurationDataObjectChange.loadConfigItem(p4, p5, p6, _, _, _)
	p4.postLoadObjectChange = p5:getValue(p6 .. "#postLoadObjectChange", false)
end
function VehicleConfigurationDataObjectChange.onLoad(p7, p8, p9)
	if not p8.postLoadObjectChange then
		local v10 = g_vehicleConfigurationManager:getConfigurationDescByName(p8.configName)
		ObjectChangeUtil.updateObjectChanges(p7.xmlFile, v10.configurationKey, p9, p7.components, p7)
	end
end
function VehicleConfigurationDataObjectChange.onPostLoad(p11, p12, p13)
	if p12.postLoadObjectChange then
		local v14 = g_vehicleConfigurationManager:getConfigurationDescByName(p12.configName)
		ObjectChangeUtil.updateObjectChanges(p11.xmlFile, v14.configurationKey, p13, p11.components, p11)
	end
end
VehicleConfigurationItem.registerGlobalConfigurationData(VehicleConfigurationDataObjectChange)

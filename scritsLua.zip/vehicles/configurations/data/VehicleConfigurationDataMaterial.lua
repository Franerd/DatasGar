VehicleConfigurationDataMaterial = {}
function VehicleConfigurationDataMaterial.registerXMLPaths(p1, _, p2)
	p1:setXMLSharedRegistration("VehicleConfigurationDataMaterial", p2)
	local v3 = p2 .. ".material(?)"
	VehicleMaterial.registerXMLPaths(p1, v3)
	p1:register(XMLValueType.BOOL, v3 .. "#ignoreWarning", "If set to \'true\' there is no warning if the material is not found.", false)
	p1:register(XMLValueType.NODE_INDEX, v3 .. "#node", "If defined, the \'targetMaterialSlotName\' is only replaced for this node")
	p1:register(XMLValueType.STRING, v3 .. "#sourceMaterialSlotName", "Material with this slot name replaces the material defined with \'targetMaterialSlotName\'")
	p1:register(XMLValueType.STRING, v3 .. "#targetMaterialSlotName", "Material with this slot name is replaced the material defined with \'sourceMaterialSlotName\'")
	p1:resetXMLSharedRegistration("VehicleConfigurationDataMaterial", p2)
end
function VehicleConfigurationDataMaterial.onLoadFinished(p_u_4, p_u_5, _, ...)
	local v_u_6
	if p_u_5:isa(VehicleConfigurationItemColor) then
		v_u_6 = p_u_5:getColor()
	else
		v_u_6 = nil
	end
	p_u_4.xmlFile:iterate(p_u_5.configKey .. ".material", function(_, p7)
		-- upvalues: (copy) p_u_4, (ref) v_u_6, (copy) p_u_5
		XMLUtil.checkDeprecatedXMLElements(p_u_4.xmlFile, p7 .. "#refNode", p7 .. "#sourceMaterialSlotName")
		if p_u_4.xmlFile:getValue(p7 .. "#materialSlotName") == nil then
			local v8 = p_u_4.xmlFile:getValue(p7 .. "#node", nil, p_u_4.components, p_u_4.i3dMappings)
			local v9 = p_u_4.xmlFile:getValue(p7 .. "#sourceMaterialSlotName")
			local v10 = p_u_4.xmlFile:getValue(p7 .. "#targetMaterialSlotName")
			if v9 ~= nil and v10 ~= nil then
				local v11 = nil
				for _, v12 in pairs(p_u_4.components) do
					v11 = MaterialUtil.getMaterialBySlotName(v12.node, v10)
					if v11 ~= nil then
						break
					end
				end
				local v13 = nil
				for _, v14 in pairs(p_u_4.components) do
					v13 = MaterialUtil.getMaterialBySlotName(v14.node, v9)
					if v13 ~= nil then
						break
					end
				end
				if v11 == nil then
					Logging.xmlWarning(p_u_4.xmlFile, "Unable to find targetMaterialSlotName \'%s\' in \'%s\'", v10, p_u_5.configKey)
					return
				elseif v13 == nil then
					Logging.xmlWarning(p_u_4.xmlFile, "Unable to find sourceMaterialSlotName \'%s\' in \'%s\'", v9, p_u_5.configKey)
					return
				elseif v8 == nil then
					for _, v15 in pairs(p_u_4.components) do
						MaterialUtil.replaceMaterialRec(v15.node, v11, v13)
					end
				else
					MaterialUtil.replaceMaterialRec(v8, v11, v13)
				end
			end
			if v9 ~= nil or v10 ~= nil then
				Logging.xmlWarning(p_u_4.xmlFile, "Both \'sourceMaterialSlotName\' and \'targetMaterialSlotName\' need to be defined in \'%s\'", p7)
			end
		else
			local v16 = VehicleMaterial.new(p_u_4.baseDirectory)
			v16:setColor(v_u_6)
			v16:loadFromXML(p_u_4.xmlFile, p7, p_u_4.customEnvironment)
			if v16.targetMaterialSlotName ~= nil and not (v16:applyToVehicle(p_u_4) or p_u_4.xmlFile:getValue(p7 .. "#ignoreWarning", false)) then
				Logging.xmlWarning(p_u_4.xmlFile, "Failed to find material by material slot name \'%s\' in \'%s\'", v16.targetMaterialSlotName, p7)
				return
			end
		end
	end)
end
VehicleConfigurationItem.registerGlobalConfigurationData(VehicleConfigurationDataMaterial)

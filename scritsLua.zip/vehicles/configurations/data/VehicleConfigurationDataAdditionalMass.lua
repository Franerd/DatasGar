VehicleConfigurationDataAdditionalMass = {}
function VehicleConfigurationDataAdditionalMass.registerXMLPaths(p1, _, p2)
	p1:setXMLSharedRegistration("VehicleConfigurationDataAdditionalMass", p2)
	p1:register(XMLValueType.NODE_INDEX, p2 .. ".component#node", "Component node")
	p1:register(XMLValueType.NODE_INDEX, p2 .. ".component#additionalMassNode", "At this position, the additional mass will be applied to the component")
	p1:register(XMLValueType.VECTOR_TRANS, p2 .. ".component#additionalMassOffset", "Offset to the component node to apply the mass there")
	p1:register(XMLValueType.FLOAT, p2 .. ".component#additionalMass", "Additional mass that is added to the component")
	p1:register(XMLValueType.BOOL, p2 .. ".component#useTotalMassReference", "Use total mass of vehicle as reference for center of mass adjustment. Otherwise just the mass of the component itself", true)
	p1:register(XMLValueType.INT, p2 .. ".component.dependentComponentJoint#index", "Index of the component joint to influence")
	p1:register(XMLValueType.FLOAT, p2 .. ".component.dependentComponentJoint#transSpringFactor", "Factor that is applied to the trans spring of the component joint")
	p1:register(XMLValueType.FLOAT, p2 .. ".component.dependentComponentJoint#transDampingFactor", "Factor that is applied to the trans damping of the component joint")
	p1:resetXMLSharedRegistration("VehicleConfigurationDataAdditionalMass", p2)
end
function VehicleConfigurationDataAdditionalMass.onLoad(p3, p4, _)
	if p4.configKey ~= "" then
		local v5 = p3.xmlFile:getValue(p4.configKey .. ".component#node", nil, p3.components, p3.i3dMappings)
		local v6 = p3.xmlFile:getValue(p4.configKey .. ".component#additionalMass", 0) * 0.001
		if v5 ~= nil and v6 ~= 0 then
			local v7 = p3.xmlFile:getValue(p4.configKey .. ".component#additionalMassNode", nil, p3.components, p3.i3dMappings)
			local v8 = p3.xmlFile:getValue(p4.configKey .. ".component#additionalMassOffset", nil, true)
			local v9 = p3.xmlFile:getValue(p4.configKey .. ".component#useTotalMassReference", true)
			local v10 = p3.xmlFile:getValue(p4.configKey .. ".component.dependentComponentJoint#index", nil)
			if v10 ~= nil then
				local v11 = p3.xmlFile:getValue(p4.configKey .. ".component.dependentComponentJoint#transSpringFactor", 1)
				local v12 = p3.xmlFile:getValue(p4.configKey .. ".component.dependentComponentJoint#transDampingFactor", 1)
				if p3.setDependentComponentJointBaseFactors ~= nil then
					p3:setDependentComponentJointBaseFactors(v10, v11, v12)
				end
			end
			local v13 = 0
			for _, v14 in ipairs(p3.components) do
				v13 = v13 + v14.defaultMass
			end
			for _, v15 in ipairs(p3.components) do
				if v15.node == v5 then
					if v7 ~= nil or v8 ~= nil then
						local v16, v17, v18 = getCenterOfMass(v5)
						local v19, v20, v21
						if v7 == nil then
							v19 = v8[1]
							v20 = v8[2]
							v21 = v8[3]
						else
							v19, v20, v21 = localToLocal(v7, v5, 0, 0, 0)
						end
						local v22 = v6 / (v9 and v13 and v13 or v15.defaultMass)
						local v23 = 1 - v22
						local v24 = v16 * v23 + v19 * v22
						local v25 = v17 * v23 + v20 * v22
						local v26 = v18 * v23 + v21 * v22
						setCenterOfMass(v5, v24, v25, v26)
					end
					v15.defaultMass = v15.defaultMass + v6
					return
				end
			end
		end
	end
end
VehicleConfigurationItem.registerGlobalConfigurationData(VehicleConfigurationDataAdditionalMass)

VehicleConfigurationDataDependentConfig = {}
function VehicleConfigurationDataDependentConfig.registerXMLPaths(p1, _, p2)
	p1:register(XMLValueType.STRING, p2 .. ".dependentConfiguration(?)#name", "Name of the other configuration to set")
	p1:register(XMLValueType.INT, p2 .. ".dependentConfiguration(?)#index", "Index of the configuration to use")
end
function VehicleConfigurationDataDependentConfig.loadConfigItem(p3, p4, _, p5, _, _)
	p3.dependentConfigurations = {}
	for _, v6 in p4:iterator(p5 .. ".dependentConfiguration") do
		local v7 = {
			["name"] = p4:getValue(v6 .. "#name"),
			["index"] = p4:getValue(v6 .. "#index")
		}
		if v7.name ~= nil and v7.index ~= nil then
			local v8 = p3.dependentConfigurations
			table.insert(v8, v7)
		end
	end
end
VehicleConfigurationItem.registerGlobalConfigurationData(VehicleConfigurationDataDependentConfig)

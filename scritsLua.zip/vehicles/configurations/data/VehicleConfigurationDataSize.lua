VehicleConfigurationDataSize = {}
function VehicleConfigurationDataSize.registerXMLPaths(p1, _, p2)
	p1:setXMLSharedRegistration("VehicleConfigurationDataSize", p2)
	local v3 = p2 .. ".size"
	p1:register(XMLValueType.FLOAT, v3 .. "#width", "occupied width of the vehicle when loaded in this configuration")
	p1:register(XMLValueType.FLOAT, v3 .. "#length", "occupied length of the vehicle when loaded in this configuration")
	p1:register(XMLValueType.FLOAT, v3 .. "#height", "occupied height of the vehicle when loaded in this configuration")
	p1:register(XMLValueType.FLOAT, v3 .. "#widthOffset", "width offset")
	p1:register(XMLValueType.FLOAT, v3 .. "#lengthOffset", "length offset")
	p1:register(XMLValueType.FLOAT, v3 .. "#heightOffset", "height offset")
	p1:resetXMLSharedRegistration("VehicleConfigurationDataSize", p2)
end
function VehicleConfigurationDataSize.onSizeLoad(p4, p5, p6)
	local v7 = p4.configKey .. ".size"
	p6.width = p5:getValue(v7 .. "#width", p6.width)
	p6.length = p5:getValue(v7 .. "#length", p6.length)
	p6.height = p5:getValue(v7 .. "#height", p6.height)
	p6.widthOffset = p5:getValue(v7 .. "#widthOffset", p6.widthOffset)
	p6.lengthOffset = p5:getValue(v7 .. "#lengthOffset", p6.lengthOffset)
	p6.heightOffset = p5:getValue(v7 .. "#heightOffset", p6.heightOffset)
end
VehicleConfigurationItem.registerGlobalConfigurationData(VehicleConfigurationDataSize)

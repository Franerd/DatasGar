VehicleConfigurationDataAttacherJoint = {}
function VehicleConfigurationDataAttacherJoint.registerXMLPaths(p1, _, p2)
	AttacherJoints.registerAttacherJointXMLPaths(p1, p2)
end
function VehicleConfigurationDataAttacherJoint.onPrePostLoad(p3, p4, _)
	if p3.spec_attacherJoints ~= nil then
		for _, v5 in p3.xmlFile:iterator(p4.configKey .. ".attacherJoint") do
			local v6 = {}
			if p3:loadAttacherJointFromXML(v6, p3.xmlFile, v5, 0) then
				local v7 = p3.spec_attacherJoints.attacherJoints
				table.insert(v7, v6)
			end
		end
	end
end
VehicleConfigurationItem.registerGlobalConfigurationData(VehicleConfigurationDataAttacherJoint)

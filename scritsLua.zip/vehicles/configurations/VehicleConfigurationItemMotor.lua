VehicleConfigurationItemMotor = {}
VehicleConfigurationItemMotor.SELECTOR = ConfigurationUtil.SELECTOR_MULTIOPTION
local v_u_1 = Class(VehicleConfigurationItemMotor, VehicleConfigurationItem)
function VehicleConfigurationItemMotor.new(p2, _)
	-- upvalues: (copy) v_u_1
	return VehicleConfigurationItemMotor:superClass().new(p2, v_u_1)
end
function VehicleConfigurationItemMotor.loadFromXML(p3, p4, p5, p6, p7, p8)
	if not VehicleConfigurationItemMotor:superClass().loadFromXML(p3, p4, p5, p6, p7, p8) then
		return false
	end
	p3.power = p4:getValue(p6 .. "#hp")
	p3.maxSpeed = p4:getValue(p6 .. "#maxSpeed")
	p3.consumerConfigurationIndex = p4:getValue(p6 .. "#consumerConfigurationIndex")
	return true
end
function VehicleConfigurationItemMotor.registerXMLPaths(p9, p10, p11)
	VehicleConfigurationItemMotor:superClass().registerXMLPaths(p9, p10, p11)
	p9:register(XMLValueType.FLOAT, p11 .. "#hp", "Horse power to be shown in the shop")
	p9:register(XMLValueType.FLOAT, p11 .. "#maxSpeed", "Max. speed to be shown in the shop")
	p9:register(XMLValueType.INT, p11 .. "#consumerConfigurationIndex", "Index of consumer configuration to be used")
end

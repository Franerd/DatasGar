VehicleConfigurationItem = {}
VehicleConfigurationItem.SELECTOR = ConfigurationUtil.SELECTOR_MULTIOPTION
VehicleConfigurationItem.GLOBAL_DATA = {}
function VehicleConfigurationItem.registerGlobalConfigurationData(p1)
	local v2 = VehicleConfigurationItem.GLOBAL_DATA
	table.insert(v2, p1)
end
source("dataS/scripts/vehicles/configurations/data/VehicleConfigurationDataAdditionalMass.lua")
source("dataS/scripts/vehicles/configurations/data/VehicleConfigurationDataAttacherJoint.lua")
source("dataS/scripts/vehicles/configurations/data/VehicleConfigurationDataDependentConfig.lua")
source("dataS/scripts/vehicles/configurations/data/VehicleConfigurationDataMaterial.lua")
source("dataS/scripts/vehicles/configurations/data/VehicleConfigurationDataObjectChange.lua")
source("dataS/scripts/vehicles/configurations/data/VehicleConfigurationDataSize.lua")
local v_u_3 = Class(VehicleConfigurationItem)
function VehicleConfigurationItem.new(p4, p5)
	-- upvalues: (copy) v_u_3
	local v6 = p5 or v_u_3
	local v7 = setmetatable({}, v6)
	v7.configName = p4
	v7.name = ""
	v7.index = -1
	v7.hasDefaultName = false
	v7.configKey = ""
	v7.desc = nil
	v7.price = 0
	v7.dailyUpkeep = 0
	v7.isDefault = false
	v7.isSelectable = true
	v7.saveId = nil
	v7.isYesNoOption = false
	return v7
end
function VehicleConfigurationItem.loadFromXML(p8, p9, p10, p11, p12, p13)
	p8.name = p9:getValue(p11 .. "#name", p8.name, p13, false)
	local v14 = p9:getValue(p11 .. "#params")
	if v14 ~= nil then
		p8.name = g_i18n:insertTextParams(p8.name, v14, p13, p9)
	end
	if p8.name == "" then
		local v15 = p8.index
		p8.name = tostring(v15)
		p8.hasDefaultName = true
	end
	p8.configKey = p11
	p8.desc = p9:getValue(p11 .. "#desc", p8.desc, p13, false)
	p8.price = p9:getValue(p11 .. "#price", p8.price)
	p8.dailyUpkeep = p9:getValue(p11 .. "#dailyUpkeep", p8.dailyUpkeep)
	p8.isDefault = p9:getValue(p11 .. "#isDefault", p8.isDefault)
	p8.isSelectable = p9:getValue(p11 .. "#isSelectable", p8.isSelectable)
	p8.saveId = p9:getValue(p11 .. "#saveId", p8.saveId)
	p8.overwrittenTitle = p9:getValue(p10 .. "#title", nil, p13, false)
	p8.isYesNoOption = p9:getValue(p10 .. "#isYesNoOption", p8.isYesNoOption)
	local v16 = p9:getValue(p11 .. "#vehicleBrand")
	p8.vehicleBrand = g_brandManager:getBrandIndexByName(v16)
	p8.vehicleName = p9:getValue(p11 .. "#vehicleName", nil, p13, false)
	local v17 = p9:getValue(p11 .. "#vehicleIcon")
	if v17 ~= nil then
		p8.vehicleIcon = Utils.getFilename(v17, p12)
		if not textureFileExists(p8.vehicleIcon) then
			Logging.xmlWarning(p9, "Custom configuration vehicle icon \'%s\' not found.", p8.vehicleIcon)
			p8.vehicleIcon = nil
		end
	end
	local v18 = p9:getValue(p11 .. "#displayBrand")
	p8.brandIndex = g_brandManager:getBrandIndexByName(v18)
	for _, v19 in ipairs(VehicleConfigurationItem.GLOBAL_DATA) do
		if v19.loadConfigItem ~= nil then
			v19.loadConfigItem(p8, p9, p10, p11, p12, p13)
		end
	end
	return true
end
function VehicleConfigurationItem.setIndex(p20, p21)
	p20.index = p21
	if p20.saveId == nil then
		p20.saveId = tostring(p21)
	end
end
function VehicleConfigurationItem.getNeedsRenaming(p22, p23)
	return p22.name == p23.name
end
function VehicleConfigurationItem.onPreLoad(p24, p25, p26)
	for _, v27 in ipairs(VehicleConfigurationItem.GLOBAL_DATA) do
		if v27.onPreLoad ~= nil then
			v27.onPreLoad(p25, p24, p26)
		end
	end
end
function VehicleConfigurationItem.onLoad(p28, p29, p30)
	for _, v31 in ipairs(VehicleConfigurationItem.GLOBAL_DATA) do
		if v31.onLoad ~= nil then
			v31.onLoad(p29, p28, p30)
		end
	end
end
function VehicleConfigurationItem.onPrePostLoad(p32, p33, p34)
	for _, v35 in ipairs(VehicleConfigurationItem.GLOBAL_DATA) do
		if v35.onPrePostLoad ~= nil then
			v35.onPrePostLoad(p33, p32, p34)
		end
	end
end
function VehicleConfigurationItem.onPostLoad(p36, p37, p38)
	for _, v39 in ipairs(VehicleConfigurationItem.GLOBAL_DATA) do
		if v39.onPostLoad ~= nil then
			v39.onPostLoad(p37, p36, p38)
		end
	end
end
function VehicleConfigurationItem.onLoadFinished(p40, p41, p42)
	for _, v43 in ipairs(VehicleConfigurationItem.GLOBAL_DATA) do
		if v43.onLoadFinished ~= nil then
			v43.onLoadFinished(p41, p40, p42)
		end
	end
end
function VehicleConfigurationItem.onSizeLoad(p44, p45, p46)
	for _, v47 in ipairs(VehicleConfigurationItem.GLOBAL_DATA) do
		if v47.onSizeLoad ~= nil then
			v47.onSizeLoad(p44, p45, p46)
		end
	end
end
function VehicleConfigurationItem.postLoad(p48, _, _, _, _, p49, _)
	for v50 = 1, #p49 do
		local v51 = 0
		for v52 = 1, #p49 do
			if p49[v50] ~= p49[v52] then
				if p49[v50]:getNeedsRenaming(p49[v52]) then
					p49[v50].renameIndex = (p49[v52].renameIndex or v51) + 1
				end
				if p49[v50].saveId ~= nil and p49[v50].saveId == p49[v52].saveId then
					Logging.xmlWarning(p48, "Duplicated saveId \'%s\' in \'%s\' configurations", p49[v50].saveId, p49[v50].configName)
				end
			end
		end
	end
	for v53 = 1, #p49 do
		if p49[v53].renameIndex ~= nil and p49[v53].renameIndex > 1 then
			p49[v53].name = string.format("%s\194\160(%d)", p49[v53].name, p49[v53].renameIndex)
			p49[v53].renameIndex = nil
		end
	end
end
function VehicleConfigurationItem.registerXMLPaths(p54, p55, p56)
	p54:register(XMLValueType.L10N_STRING, p55 .. "#title", "configuration title to display in shop")
	p54:register(XMLValueType.BOOL, p55 .. "#isYesNoOption", "UI in the shop will just show a yes/no slider element", false)
	p54:register(XMLValueType.L10N_STRING, p56 .. "#name", "Configuration name")
	p54:register(XMLValueType.STRING, p56 .. "#params", "Extra parameters to insert in #name text")
	p54:register(XMLValueType.L10N_STRING, p56 .. "#desc", "Configuration description")
	p54:register(XMLValueType.FLOAT, p56 .. "#price", "Price of configuration", 0)
	p54:register(XMLValueType.FLOAT, p56 .. "#dailyUpkeep", "Daily up keep with this configuration", 0)
	p54:register(XMLValueType.BOOL, p56 .. "#isDefault", "Is selected by default in shop config screen", false)
	p54:register(XMLValueType.BOOL, p56 .. "#isSelectable", "Configuration can be selected in the shop", true)
	p54:register(XMLValueType.STRING, p56 .. "#saveId", "Custom save id", "Number of configuration")
	p54:register(XMLValueType.STRING, p56 .. "#displayBrand", "If defined a brand icon is displayed in the shop config screen")
	p54:register(XMLValueType.STRING, p56 .. "#vehicleBrand", "Custom brand to display after bought with this configuration")
	p54:register(XMLValueType.L10N_STRING, p56 .. "#vehicleName", "Custom vehicle name to display after bought with this configuration")
	p54:register(XMLValueType.STRING, p56 .. "#vehicleIcon", "Custom icon to display after bought with this configuration")
	for _, v57 in ipairs(VehicleConfigurationItem.GLOBAL_DATA) do
		if v57.registerXMLPaths ~= nil then
			v57.registerXMLPaths(p54, p55, p56)
		end
	end
end

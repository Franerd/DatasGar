VehicleConfigurationItemWheel = {}
VehicleConfigurationItemWheel.SELECTOR = ConfigurationUtil.SELECTOR_MULTIOPTION
local v_u_1 = Class(VehicleConfigurationItemWheel, VehicleConfigurationItem)
function VehicleConfigurationItemWheel.new(p2, _)
	-- upvalues: (copy) v_u_1
	return VehicleConfigurationItemWheel:superClass().new(p2, v_u_1)
end
function VehicleConfigurationItemWheel.loadFromXML(p_u_3, p_u_4, p5, p6, p_u_7, p8)
	if not VehicleConfigurationItemWheel:superClass().loadFromXML(p_u_3, p_u_4, p5, p6, p_u_7, p8) then
		return false
	end
	local v9 = p_u_4:getValue(p6 .. "#brand")
	p_u_3.wheelBrandKey = p6
	if v9 ~= nil then
		local v10 = g_brandManager:getBrandByName(v9)
		if v10 == nil then
			Logging.xmlWarning(p_u_4, "Wheel brand \'%s\' is not defined for \'%s\'!", v9, p6)
		else
			p_u_3.wheelBrandName = v10.title
			p_u_3.wheelBrandIconFilename = v10.image
		end
	end
	p_u_3.maxForwardSpeed = p_u_4:getValue(p6 .. "#maxForwardSpeed")
	p_u_3.maxForwardSpeedShop = p_u_4:getValue(p6 .. "#maxForwardSpeedShop")
	local v_u_11 = Wheels.createConfigToParentConfigMapping(p_u_4)
	p_u_3.baseWheelData = {}
	p_u_4:iterate(p6 .. ".wheels.wheel", function(p12, _)
		-- upvalues: (copy) p_u_4, (copy) v_u_11, (copy) p_u_7, (copy) p_u_3
		local v13 = WheelXMLObject.new(p_u_4, "vehicle.wheels.wheelConfigurations.wheelConfiguration", 1, string.format(".wheels.wheel(%d)", p12 - 1), v_u_11)
		v13:setXMLLoadKey("")
		local v14 = nil
		local v15 = v13:getLocalValue("#dimensions")
		if v15 ~= nil then
			local v16 = v15:split(" ")
			if #v16 > 0 then
				v14 = v16[1]
			end
		end
		local v17 = v13:getLocalValue(".physics#xOffset", 0)
		local v18 = v13:getLocalValue("#rimOffset", 0)
		local v19 = nil
		local v20 = nil
		if v14 == nil then
			local v21 = v13:getLocalValue("#filename")
			if v21 ~= nil then
				local v22 = Utils.getFilename(v21, p_u_7)
				v19, v20 = g_wheelManager:getWheelRadiusAndWidthFromFilename(v22)
			end
		else
			v19, v20 = g_wheelManager:getWheelRadiusAndWidthFromDimension(v14)
		end
		v13:delete()
		if v19 ~= nil and v20 ~= nil then
			p_u_3.baseWheelData[p12] = {
				["radius"] = v19,
				["width"] = v20,
				["xOffset"] = v17,
				["rimOffset"] = v18
			}
		end
	end)
	local v_u_23 = {}
	local v_u_24 = 0
	p_u_4:iterate(p6 .. ".wheels.wheel", function(p25, _)
		-- upvalues: (copy) p_u_4, (copy) p_u_3, (copy) v_u_11, (copy) v_u_23, (ref) v_u_24
		local v26 = WheelXMLObject.new(p_u_4, "vehicle.wheels.wheelConfigurations.wheelConfiguration", p_u_3.index, string.format(".wheels.wheel(%d)", p25 - 1), v_u_11)
		v26:setXMLLoadKey("")
		local v27 = v26:getLocalValue("#dimensions")
		if v27 ~= nil then
			local v28 = v27:split(" ")
			for v29, v30 in ipairs(v28) do
				if v_u_23[v29] == nil then
					v_u_23[v29] = {}
				end
				local v31 = v_u_23[v29]
				table.insert(v31, p25, v30)
			end
		end
		v26:delete()
		v_u_24 = v_u_24 + 1
	end)
	local v32 = v_u_24
	for _, v33 in pairs(v_u_23) do
		for v34 = 1, v32 do
			if v33[v34] == nil then
				v33[v34] = "-"
			end
		end
	end
	if #v_u_23 == 0 then
		return true
	end
	if p_u_3.wheelBrandName ~= nil then
		Logging.xmlWarning(p_u_4, "Wheel brand defined for dynamic configuration, this is not allowed! (%s)", p6)
		return true
	end
	local v35 = p_u_4:getValue("vehicle.wheels.wheelConfigurations#customBrandOrder", nil, true)
	if v35 ~= nil then
		p_u_3.customBrandOrder = {}
		for v36, v37 in ipairs(v35) do
			p_u_3.customBrandOrder[string.upper(v37)] = v36
		end
	end
	local v38 = p_u_4:getValue(p6 .. "#tireCategories") or p_u_4:getValue("vehicle.wheels.wheelConfigurations#tireCategories")
	if v38 ~= nil then
		local v39 = v38:split(" ")
		if #v39 > 0 then
			p_u_3.tireCategories = {}
			for _, v40 in ipairs(v39) do
				p_u_3.tireCategories[v40] = true
			end
		end
	end
	p_u_3.whitelistedCombinations = {}
	p_u_4:iterate("vehicle.wheels.wheelConfigurations.tireCombination", function(_, p41)
		-- upvalues: (copy) p_u_4, (copy) p_u_3
		local v42 = p_u_4:getValue(p41 .. "#brand")
		local v43 = g_brandManager:getBrandByName(v42)
		if v43 ~= nil then
			local v44 = p_u_4:getValue(p41 .. "#names")
			if v44 ~= nil then
				if v44 == "-" then
					local v45 = p_u_3.whitelistedCombinations
					table.insert(v45, {
						["brand"] = v43,
						["names"] = {}
					})
					return
				end
				local v46 = v44:split(" ")
				if #v46 > 0 then
					local v47 = p_u_3.whitelistedCombinations
					table.insert(v47, {
						["brand"] = v43,
						["names"] = v46
					})
				end
			end
		end
	end)
	local v_u_48 = {}
	local function v_u_58(p49)
		-- upvalues: (copy) v_u_11, (copy) v_u_58, (copy) p_u_4, (copy) v_u_48
		local v50 = v_u_11[p49]
		if v50 ~= nil then
			v_u_58(v50)
		end
		p_u_4:iterate(string.format("vehicle.wheels.wheelConfigurations.wheelConfiguration(%d).tireCombination", p49 - 1), function(_, p51)
			-- upvalues: (ref) p_u_4, (ref) v_u_48
			local v52 = p_u_4:getValue(p51 .. "#brand")
			local v53 = g_brandManager:getBrandByName(v52)
			if v53 ~= nil then
				local v54 = p_u_4:getValue(p51 .. "#names")
				if v54 ~= nil then
					if v54 == "-" then
						local v55 = v_u_48
						table.insert(v55, {
							["brand"] = v53,
							["names"] = {}
						})
						return
					end
					local v56 = v54:split(" ")
					if #v56 > 0 then
						local v57 = v_u_48
						table.insert(v57, {
							["brand"] = v53,
							["names"] = v56
						})
					end
				end
			end
		end)
	end
	v_u_58(p_u_3.index)
	p_u_3.numDynamicConfigurations = p_u_4:getValue(p6 .. "#numDynamicConfigurations", (1 / 0))
	for _, v59 in ipairs(v_u_48) do
		for v60 = #p_u_3.whitelistedCombinations, 1, -1 do
			if p_u_3.whitelistedCombinations[v60].brand == v59.brand then
				table.remove(p_u_3.whitelistedCombinations, v60)
			end
		end
	end
	for _, v61 in ipairs(v_u_48) do
		local v62 = p_u_3.whitelistedCombinations
		table.insert(v62, v61)
	end
	p_u_3.dimensionCombinations = v_u_23
	return true
end
function VehicleConfigurationItemWheel.getNeedsRenaming(p63, p64)
	if p63.wheelBrandName == p64.wheelBrandName then
		return VehicleConfigurationItemWheel:superClass().getNeedsRenaming(p63, p64)
	else
		return false
	end
end
function VehicleConfigurationItemWheel.onSizeLoad(p65, p66, p67)
	VehicleConfigurationItemWheel:superClass().onSizeLoad(p65, p66, p67)
	if p65.isDynamicConfig then
		p65:applyGeneratedConfiguration(p66)
		local v68 = Wheels.createConfigToParentConfigMapping(p66)
		local v69 = 0
		for v70, v71 in ipairs(p65.tireCombination.wheels) do
			if v71.path ~= nil then
				local v72 = string.format(".wheels.wheel(%d)", v70 - 1)
				local v73 = v71.width
				local v74, v75
				if p65.baseConfigItem.baseWheelData == nil or p65.baseConfigItem.baseWheelData[v70] == nil then
					v74 = 0
					v75 = 0
				else
					v73 = p65.baseConfigItem.baseWheelData[v70].width
					v74 = p65.baseConfigItem.baseWheelData[v70].xOffset
					v75 = p65.baseConfigItem.baseWheelData[v70].rimOffset
				end
				local v76 = WheelXMLObject.new(p66, "vehicle.wheels.wheelConfigurations.wheelConfiguration", p65.index, v72, v68)
				v76:setXMLLoadKey("")
				local v77 = (v76:getLocalValue(".physics#xOffset", 0) - v74) * 2 + (v76:getLocalValue("#rimOffset", 0) - v75) * 2
				local v78 = v71.width - v73 + v77
				v69 = math.max(v69, v78)
				local v79 = 0
				while true do
					local v80 = string.format(".additionalWheel(%d)", v79)
					local v81, _ = v76:getXMLFileAndPropertyKey(v80)
					if v81 == nil then
						break
					end
					local v82 = (v76:getLocalValue(v80 .. "#offset", 0) + v71.width) * 2 + (v71.width - v73) + v77
					v69 = math.max(v69, v82)
					v79 = v79 + 1
				end
				v76:delete()
			end
		end
		p67.width = p67.width + v69
	end
end
function VehicleConfigurationItemWheel.postLoad(p83, p84, p85, p86, p87, p88, p89, p90)
	VehicleConfigurationItemWheel:superClass().postLoad(p83, p84, p85, p86, p87, p88, p89, p90)
	for _, v91 in ipairs(p88) do
		if v91.dimensionCombinations ~= nil and v91.isSelectable then
			v91.isSelectable = false
			VehicleConfigurationItemWheel.generateConfigurations(p88, p83, p90, v91)
		end
	end
	local v92 = false
	for _, v93 in ipairs(p88) do
		if v93.wheelBrandName ~= nil then
			v92 = true
			break
		end
	end
	if v92 then
		for _, v94 in ipairs(p88) do
			if v94.isSelectable and v94.wheelBrandName == nil then
				Logging.xmlWarning(p83, "Wheel brand missing for wheel configuration \'%s\'!", v94.wheelBrandKey)
			end
		end
	end
end
function VehicleConfigurationItemWheel.getFallbackConfigId(p95, p96, _, _)
	local v97 = p96:split("_")
	local v98 = 0
	local v99 = nil
	for _, v100 in pairs(p95) do
		local v101 = v100.saveId:split("_")
		local v102 = #v97
		local v103 = #v101
		local v104 = 0
		for v105 = 1, math.min(v102, v103) do
			if v97[v105] ~= v101[v105] then
				break
			end
			v104 = v104 + 1
		end
		if v98 < v104 then
			v99 = v100
			v98 = v104
		end
	end
	if v99 == nil then
		return nil, nil
	else
		return v99.index, v99.saveId
	end
end
function VehicleConfigurationItemWheel.generateConfigurations(p106, _, p107, p108)
	local v109 = g_wheelManager:getTiresForDimensionCombinations(p108.dimensionCombinations, p108.tireCategories, p108.whitelistedCombinations, p108.numDynamicConfigurations, p108.customBrandOrder)
	for _, v110 in ipairs(v109) do
		local v111 = VehicleConfigurationItemWheel.new(p107)
		v111.name = p108.name
		if v110.index > 1 then
			v111.name = string.format("%s (%d)", v111.name, v110.index)
		end
		v111.price = p108.price
		v111.wheelBrandName = v110.wheelBrand.name
		v111.wheelBrandIconFilename = v110.wheelBrand.image
		v111.isDefault = p108.isDefault
		v111.saveId = p108.saveId .. "_" .. v110.wheelSaveId
		v111.isDynamicConfig = true
		v111.tireCombination = v110
		v111.baseConfigItem = p108
		v111.maxForwardSpeed = p108.maxForwardSpeed
		v111.maxForwardSpeedShop = p108.maxForwardSpeedShop
		table.insert(p106, v111)
		local v112 = #p106
		v111:setIndex(v112)
		v111.configKey = string.format("vehicle.wheels.wheelConfigurations.wheelConfiguration(%d)", v112 - 1)
	end
end
function VehicleConfigurationItemWheel.applyGeneratedConfiguration(p113, p114)
	if p113.isDynamicConfig then
		p114:copyTree(p113.baseConfigItem.configKey, p113.configKey, true, ".wheel")
		p114:setValue(p113.configKey .. ".wheels#baseConfig", p113.baseConfigItem.saveId)
		local v115 = Wheels.createConfigToParentConfigMapping(p114)
		for v116, v117 in ipairs(p113.tireCombination.wheels) do
			local v118 = string.format(".wheels.wheel(%d)", v116 - 1)
			local v119 = WheelXMLObject.new(p114, "vehicle.wheels.wheelConfigurations.wheelConfiguration", p113.baseConfigItem.index, v118, v115)
			v119:setXMLLoadKey("")
			if v117.path == nil then
				p114:setBool(p113.configKey .. v118 .. "#temp", true)
			else
				p114:setValue(p113.configKey .. v118 .. "#filename", v117.path)
				local v120 = v117.radius
				if p113.baseConfigItem.baseWheelData ~= nil and p113.baseConfigItem.baseWheelData[v116] ~= nil then
					v120 = p113.baseConfigItem.baseWheelData[v116].radius
				end
				local v121 = v119:getLocalValue(".physics#yOffset") or 0
				p114:setValue(p113.configKey .. v118 .. ".physics#yOffset", v121 - (v120 - v117.radius))
			end
			v119:delete()
		end
	end
end
function VehicleConfigurationItemWheel.applyObjectChanges(p122, p123, p124, p125)
	local v126 = p124[p125 or p122.index]
	if v126 ~= nil then
		p122:applyObjectChanges(p123, p124, v126)
	end
	local v127 = string.format("vehicle.wheels.wheelConfigurations.wheelConfiguration(%d)", (p125 or p122.index) - 1)
	local v128 = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p123.xmlFile, v127, v128, p123.components, p123)
	ObjectChangeUtil.setObjectChanges(v128, true, p123, p123.setMovingToolDirty)
end
function VehicleConfigurationItemWheel.registerXMLPaths(p129, p130, p131)
	VehicleConfigurationItemWheel:superClass().registerXMLPaths(p129, p130, p131)
	p129:register(XMLValueType.STRING, p131 .. "#brand", "Name of wheel brand")
	p129:register(XMLValueType.FLOAT, p131 .. "#maxForwardSpeed", "Max. speed to set on the transmission")
	p129:register(XMLValueType.FLOAT, p131 .. "#maxForwardSpeedShop", "Max. speed to display in the shop")
end

VehicleConfigurationItemColor = {}
VehicleConfigurationItemColor.SELECTOR = ConfigurationUtil.SELECTOR_COLOR
local v_u_1 = Class(VehicleConfigurationItemColor, VehicleConfigurationItem)
function VehicleConfigurationItemColor.new(p2, _)
	-- upvalues: (copy) v_u_1
	return VehicleConfigurationItemColor:superClass().new(p2, v_u_1)
end
function VehicleConfigurationItemColor.loadFromXML(p3, p4, p5, p6, p7, p8)
	if not VehicleConfigurationItemColor:superClass().loadFromXML(p3, p4, p5, p6, p7, p8) then
		return false
	end
	local v9 = p4:getValue(p6 .. "#color", nil, true)
	local v10, v11 = g_vehicleMaterialManager:getMaterialTemplateColorAndTitleByName(v9, p8)
	if v10 == nil then
		p3.color = string.getVector(v9)
		if p3.color ~= nil and #p3.color ~= 3 then
			Logging.xmlWarning(p4, "Invalid rgb color \'%s\' in \'%s\'", v9, p6)
			p3.color = nil
		end
	else
		if p3.hasDefaultName then
			p3.name = v11 or p3.name
		end
		p3.color = v10
	end
	p3.uiColor = p4:getValue(p6 .. "#uiColor", nil, true)
	p3.customEnvironment = p8
	p3.materialTemplateName = p4:getValue(p6 .. "#materialTemplateName")
	p3.isMetallic = p4:getValue(p6 .. "#isMetallic", false)
	if p3.materialTemplateName ~= nil then
		local v12 = p3.materialTemplateName:lower()
		if v12:contains("silver") or (v12:contains("copper") or (v12:contains("gold") or (v12:contains("bronze") or v12:contains("chrome")))) then
			p3.isMetallic = true
		end
		local v13, v14 = g_vehicleMaterialManager:getMaterialTemplateColorAndTitleByName(p3.materialTemplateName, p8)
		if v13 == nil then
			Logging.xmlWarning(p4, "Material template \'%s\' not defined for \'%s\'", p3.materialTemplateName, p6)
		else
			p3.color = v13
			if p3.hasDefaultName then
				p3.name = v14 or p3.name
			end
		end
	end
	if p3.color == nil then
		p3.color = { 1, 1, 1 }
	end
	p3.uiColor = p3.uiColor or p3.color
	return true
end
function VehicleConfigurationItemColor.updateMaterial(p15)
	if p15.material == nil then
		p15.material = VehicleMaterial.new()
		if p15.materialTemplateName ~= nil then
			p15.material:setTemplateName(p15.materialTemplateName, nil, p15.customEnvironment)
		end
		p15.material:setColor(p15.color)
	end
end
function VehicleConfigurationItemColor.getColor(p16)
	return { p16.color[1], p16.color[2], p16.color[3] }
end
function VehicleConfigurationItemColor.getMaterial(p17)
	p17:updateMaterial()
	return p17.material
end
function VehicleConfigurationItemColor.onSizeLoad(p18, p19, p20)
	if p18.configKey ~= "" then
		VehicleConfigurationItemColor:superClass().onSizeLoad(p18, p19, p20)
	end
end
function VehicleConfigurationItemColor.onPostLoad(p_u_21, p_u_22, p23)
	VehicleConfigurationItemColor:superClass().onPostLoad(p_u_21, p_u_22, p23)
	local v24 = g_vehicleConfigurationManager:getConfigurationDescByName(p_u_21.configName)
	p_u_22.xmlFile:iterate(v24.configurationsKey .. ".material", function(_, p25)
		-- upvalues: (copy) p_u_22, (copy) p_u_21
		local v26 = VehicleMaterial.new(p_u_22.baseDirectory)
		if not p_u_22.xmlFile:getValue(p25 .. "#materialTemplateUseColorOnly", false) then
			v26:setTemplateName(p_u_21.materialTemplateName, nil, p_u_22.customEnvironment)
		end
		v26:setColor(p_u_21.color)
		v26:loadFromXML(p_u_22.xmlFile, p25, p_u_22.customEnvironment)
		if v26.targetMaterialSlotName == nil then
			Logging.xmlWarning(p_u_22.xmlFile, "Missing material slot name in \'%s\'", p25)
		elseif not v26:applyToVehicle(p_u_22) then
			Logging.xmlWarning(p_u_22.xmlFile, "Failed to find material by material slot name \'%s\' in \'%s\'", v26.targetMaterialSlotName, p25)
			return
		end
	end)
end
function VehicleConfigurationItemColor.postLoad(p27, p28, p29, p30, p31, p32, p33, p34)
	VehicleConfigurationItemColor:superClass().postLoad(p27, p28, p29, p30, p31, p32, p33, p34)
	local v35 = p27:getValue(p28 .. "#defaultColorIndex")
	if p27:getValue(p28 .. "#useDefaultColors", false) then
		local v36 = p27:getValue(p28 .. "#price", 0)
		local v37 = p27:getValue(p28 .. "#defaultColorMaterialTemplateName", "calibratedPaint")
		for _, v38 in ipairs(p32) do
			if v38.materialTemplateName == nil then
				v38.materialTemplateName = v37
			end
		end
		for v39, v40 in pairs(VehicleConfigurationItemColor.DEFAULT_COLORS) do
			local v41, v42 = g_vehicleMaterialManager:getMaterialTemplateColorAndTitleByName(v40, p30)
			if v41 ~= nil then
				local v43 = VehicleConfigurationItemColor.new(p34)
				v43.name = v42 or v43.name
				if v39 == v35 then
					v43.isDefault = true
					v43.price = 0
				else
					v43.price = v36
				end
				v43.color = v41
				v43.uiColor = v41
				v43.materialTemplateName = v37
				table.insert(p32, v43)
				v43:setIndex(#p32)
			end
		end
	end
	if v35 == nil then
		local v44 = false
		for _, v45 in ipairs(p32) do
			if v45.isDefault ~= nil and v45.isDefault then
				v44 = true
			end
		end
		if not v44 and #p32 > 0 then
			p32[1].isDefault = true
			p32[1].price = 0
		end
	end
end
function VehicleConfigurationItemColor.getMaterialByColorConfiguration(p46, p47)
	local v48 = p46.configurations[p47]
	if v48 ~= nil then
		local v49 = g_storeManager:getItemByXMLFilename(p46.configFileName)
		if v49.configurations ~= nil then
			local v50 = v49.configurations[p47]
			if v50 ~= nil then
				local v51 = v50[v48]
				if v51 ~= nil and v51:isa(VehicleConfigurationItemColor) then
					return v51:getMaterial()
				end
			end
		end
	end
	return nil
end
function VehicleConfigurationItemColor.registerXMLPaths(p52, p53, p54)
	VehicleConfigurationItemColor:superClass().registerXMLPaths(p52, p53, p54)
	p52:register(XMLValueType.INT, p53 .. "#defaultColorIndex", "Default color index on start")
	p52:register(XMLValueType.BOOL, p53 .. "#useDefaultColors", "Use default colors", false)
	p52:register(XMLValueType.INT, p53 .. "#price", "Price of the default colors", 0)
	p52:register(XMLValueType.STRING, p53 .. "#defaultColorMaterialTemplateName", "Base template for all default colors and for configs that have just a \'color\' attribute defined", "calibratedPaint")
	VehicleMaterial.registerXMLPaths(p52, p53 .. ".material(?)")
	p52:register(XMLValueType.STRING, p54 .. "#color", "Configuration color", "1 1 1 1")
	p52:register(XMLValueType.COLOR, p54 .. "#uiColor", "Configuration UI color", "1 1 1 1")
	p52:register(XMLValueType.BOOL, p54 .. "#isMetallic", "Color is metallic color (Only for UI)", false)
	p52:register(XMLValueType.STRING, p54 .. "#materialTemplateName", "Name of material template to use")
end
VehicleConfigurationItemColor.DEFAULT_COLORS = {
	"SHARED_WHITE2",
	"SHARED_SILVER",
	"SHARED_GREYLIGHT",
	"SHARED_GREY",
	"SHARED_GREYDARK",
	"SHARED_BLACKONYX",
	"SHARED_BLACKJET",
	"JOHNDEERE_YELLOW1",
	"JCB_YELLOW1",
	"CHALLENGER_YELLOW1",
	"SCHOUTEN_ORANGE1",
	"FENDT_RED1",
	"CASEIH_RED1",
	"MASSEYFERGUSON_RED",
	"HARDI_RED",
	"NEWHOLLAND_BLUE2",
	"RABE_BLUE1",
	"LEMKEN_BLUE1",
	"NEWHOLLAND_BLUE1",
	"BOECKMANN_BLUE1",
	"GOLDHOFER_BLUE",
	"SHARED_BLUENAVY",
	"LIZARD_PURPLE1",
	"VALTRA_GREEN2",
	"DEUTZ_GREEN4",
	"JOHNDEERE_GREEN1",
	"FENDT_NEWGREEN1",
	"FENDT_OLDGREEN1",
	"KOTTE_GREEN2",
	"CLAAS_GREEN1",
	"LIZARD_OLIVE1",
	"LIZARD_ECRU1",
	"SHARED_BROWN",
	"SHARED_REDCRIMSON",
	"LIZARD_PINK1"
}

VehicleConfigurationItemVehicleType = {}
VehicleConfigurationItemVehicleType.SELECTOR = ConfigurationUtil.SELECTOR_MULTIOPTION
local v_u_1 = Class(VehicleConfigurationItemVehicleType, VehicleConfigurationItem)
function VehicleConfigurationItemVehicleType.new(p2, _)
	-- upvalues: (copy) v_u_1
	return VehicleConfigurationItemVehicleType:superClass().new(p2, v_u_1)
end
function VehicleConfigurationItemVehicleType.loadFromXML(p3, p4, p5, p6, p7, p8)
	if not VehicleConfigurationItemVehicleType:superClass().loadFromXML(p3, p4, p5, p6, p7, p8) then
		return false
	end
	p3.vehicleType = p4:getValue(p6 .. "#vehicleType")
	return true
end
function VehicleConfigurationItemVehicleType.registerXMLPaths(p9, p10, p11)
	VehicleConfigurationItemVehicleType:superClass().registerXMLPaths(p9, p10, p11)
	p9:register(XMLValueType.STRING, p11 .. "#vehicleType", "Vehicle type to be used")
end

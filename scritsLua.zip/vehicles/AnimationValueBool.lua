AnimationValueBool = {}
local v_u_1 = Class(AnimationValueBool, AnimationValueFloat)
function AnimationValueBool.new(p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)
	-- upvalues: (copy) v_u_1
	return AnimationValueFloat.new(p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12 or v_u_1)
end
function AnimationValueBool.load(p13, p14, p15)
	p13.value = p14:getValue(p15 .. "#" .. p13.startName)
	p13.warningInfo = p15
	p13.xmlFile = p14
	local v16
	if p13.value == nil then
		v16 = false
	else
		v16 = p13:extraLoad(p14, p15)
	end
	return v16
end
function AnimationValueBool.init(_, _, _) end
function AnimationValueBool.postInit(_) end
function AnimationValueBool.reset(p17)
	p17.curValue = nil
end
function AnimationValueBool.update(p18, _, _, _)
	if p18.curValue == nil then
		p18.curValue = p18:get()
	end
	if p18.value == p18.curValue then
		return false
	end
	p18.curValue = p18.value
	p18:set(p18.value)
	return true
end

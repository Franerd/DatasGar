VehicleLoadingState = {}
VehicleLoadingState.OK = 1
VehicleLoadingState.ERROR = 2
VehicleLoadingState.NO_SPACE = 3
VehicleLoadingState.CANCELED = 4
Enum(VehicleLoadingState)

LicensePlate = {}
local v_u_1 = Class(LicensePlate)
function LicensePlate.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.variationIndex = 1
	v4.characters = ""
	v4.manager = g_licensePlateManager
	return v4
end
function LicensePlate.loadFromXML(p_u_5, p6, p7, p_u_8, p_u_9, p10)
	local v11 = p_u_9:getValue(p10 .. "#type", "ELONGATED")
	if v11 ~= nil then
		p_u_5.type = LicensePlateManager.PLATE_TYPE[v11]
		if p_u_5.type == nil then
			return false
		end
		p_u_5.node = p6
		p_u_5.filename = p7
		p_u_5.width = p_u_9:getValue(p10 .. "#width", 1)
		p_u_5.height = p_u_9:getValue(p10 .. "#height", 0.3)
		p_u_5.fontSize = p_u_9:getValue(p10 .. ".font#size", 0.1)
		p_u_5.fontScaleX = p_u_9:getValue(p10 .. ".font#scaleX", 1)
		p_u_5.fontScaleY = p_u_9:getValue(p10 .. ".font#scaleY", 1)
		p_u_5.widthOffsetLeft = 0
		p_u_5.widthOffsetRight = 0
		p_u_5.heightOffsetTop = 0
		p_u_5.heightOffsetBot = 0
		p_u_5.font = g_licensePlateManager:getFont()
		if p_u_5.font == nil then
			Logging.error("LicensePlate: Unable to get font from LicensePlateManager, possibly not initialized/loaded yet")
			printCallstack()
			return false
		end
		p_u_5.fontMaxWidthRatio = p_u_5.font:getFontMaxWidthRatio()
		p_u_5.variations = {}
		p_u_9:iterate(p10 .. ".variations.variation", function(_, p12)
			-- upvalues: (copy) p_u_9, (copy) p_u_5, (copy) p_u_8
			local v_u_13 = {
				["values"] = {}
			}
			local v_u_14 = 0
			p_u_9:iterate(p12 .. ".value", function(p15, p16)
				-- upvalues: (ref) v_u_14, (ref) p_u_9, (ref) p_u_5, (copy) v_u_13
				local v17 = {
					["index"] = p15,
					["realIndex"] = v_u_14 + 1,
					["nodePath"] = p_u_9:getValue(p16 .. "#node")
				}
				v17.node = I3DUtil.indexToObject(p_u_5.node, v17.nodePath)
				v17.nextSection = p_u_9:getValue(p16 .. "#nextSection", false)
				if v17.nodePath ~= nil and v17.node ~= nil then
					local v18, v19, v20 = getTranslation(v17.node)
					v17.posX = p_u_9:getValue(p16 .. "#posX", v18)
					v17.posY = p_u_9:getValue(p16 .. "#posY", v19)
					v17.posZ = p_u_9:getValue(p16 .. "#posZ", v20)
					v17.character = p_u_9:getValue(p16 .. "#character")
					v17.numerical = p_u_9:getValue(p16 .. "#numerical", false)
					v17.alphabetical = p_u_9:getValue(p16 .. "#alphabetical", false)
					v17.special = p_u_9:getValue(p16 .. "#special", false)
					local v21 = p_u_9
					local v22 = p16 .. "#isStatic"
					local v23 = not (v17.numerical or (v17.alphabetical or v17.special))
					if v23 then
						v23 = v17.character == nil
					end
					v17.isStatic = v21:getValue(v22, v23)
					v17.locked = p_u_9:getValue(p16 .. "#locked", v17.character ~= nil)
					v17.maxWidthRatio = p_u_5.font:getFontMaxWidthRatio(v17.alphabetical, v17.numerical, v17.special)
					local v24 = p_u_9:getValue(p16 .. "#position", "ANY")
					local v25 = LicensePlateManager.PLATE_POSITION[v24:upper()]
					if v25 == nil then
						Logging.xmlError(p_u_9, "Unknown position \'%s\' in \'%s\'", v24, p16)
					end
					v17.position = v25 or LicensePlateManager.PLATE_POSITION.ANY
					if not v17.isStatic then
						v_u_14 = v_u_14 + 1
					end
					I3DUtil.setShapeCastShadowmapRec(v17.node, false)
					local v26 = v_u_13.values
					table.insert(v26, v17)
				end
			end)
			v_u_13.materials = {}
			p_u_9:iterate(p12 .. ".material", function(_, p27)
				-- upvalues: (ref) p_u_9, (ref) p_u_8, (copy) v_u_13
				local v28 = VehicleMaterial.new()
				if v28:loadFromXML(p_u_9, p27, p_u_8) then
					local v29 = v_u_13.materials
					table.insert(v29, v28)
				end
			end)
			if #v_u_13.values > 0 then
				local v30 = p_u_5.variations
				table.insert(v30, v_u_13)
			end
		end)
		p_u_5.frame = {}
		p_u_5.frame.node = p_u_9:getValue(p10 .. ".frame#node")
		p_u_5.frame.widthOffset = p_u_9:getValue(p10 .. ".frame#widthOffset", 0)
		p_u_5.frame.heightOffsetTop = p_u_9:getValue(p10 .. ".frame#heightOffsetTop", 0)
		p_u_5.frame.heightOffsetBot = p_u_9:getValue(p10 .. ".frame#heightOffsetBot", 0)
		if p_u_5.frame.node == nil or I3DUtil.indexToObject(p_u_5.node, p_u_5.frame.node) == nil then
			p_u_5.frame = nil
		end
	end
	return true
end
function LicensePlate.delete(p31)
	delete(p31.node)
end
function LicensePlate.clone(p32, p33)
	local v34 = LicensePlate.new()
	v34.node = clone(p32.node, false, false, false)
	v34.type = p32.type
	v34.filename = p32.filename
	v34.width = p32.width
	v34.height = p32.height
	v34.fontSize = p32.fontSize
	v34.fontScaleX = p32.fontScaleX
	v34.fontScaleY = p32.fontScaleY
	v34.rawWidth = p32.width
	v34.rawHeight = p32.height
	v34.widthOffsetLeft = 0
	v34.widthOffsetRight = 0
	v34.heightOffsetTop = 0
	v34.heightOffsetBot = 0
	v34.font = p32.font
	v34.fontMaxWidthRatio = p32.fontMaxWidthRatio
	v34.variations = table.clone(p32.variations, 10)
	for v35 = 1, #v34.variations do
		local v36 = v34.variations[v35]
		for v37 = 1, #v36.values do
			local v38 = v36.values[v37]
			v38.node = I3DUtil.indexToObject(v34.node, v38.nodePath)
		end
	end
	v34.frame = table.clone(p32.frame, 10)
	if v34.frame ~= nil then
		local v39 = p33 == true
		local v40 = I3DUtil.indexToObject(v34.node, v34.frame.node)
		if v40 ~= nil then
			setVisibility(v40, v39)
			if v39 then
				v34.width = v34.width + 2 * v34.frame.widthOffset
				v34.height = v34.height + v34.frame.heightOffsetTop + v34.frame.heightOffsetBot
				v34.widthOffsetLeft = v34.frame.widthOffset
				v34.widthOffsetRight = v34.frame.widthOffset
				v34.heightOffsetTop = v34.frame.heightOffsetTop
				v34.heightOffsetBot = v34.frame.heightOffsetBot
			end
		end
	end
	v34:setVariation(p32.variationIndex)
	return v34
end
function LicensePlate.updateData(p41, p42, p43, p44, p45)
	if p42 ~= p41.variationIndex then
		p41:setVariation(p42)
	end
	if p45 == true then
		p44 = p41:validateLicensePlateCharacters(p44)
	end
	p41.characters = p44
	local v46 = p41.variations[p41.variationIndex]
	if v46 ~= nil then
		local v47 = 1
		for v48 = 1, #v46.values do
			local v49 = v46.values[v48]
			if v49.node ~= nil then
				setTranslation(v49.node, v49.posX, v49.posY, v49.posZ)
				local v50
				if v49.position == LicensePlateManager.PLATE_POSITION.ANY or v49.position == p43 then
					v50 = v49.position ~= LicensePlateManager.PLATE_POSITION.NONE
				else
					v50 = false
				end
				local v51 = v49.character
				if not v49.locked then
					v51 = p44:sub(v47, v47) or v51
				end
				if v49.isStatic or (v51 == "" or (v51 == "_" or not v50)) then
					if v49.isStatic and v50 then
						setVisibility(v49.node, true)
					else
						setVisibility(v49.node, false)
					end
				else
					v49.characterLine:setText(v51)
					setVisibility(v49.node, true)
				end
				if not v49.isStatic then
					v47 = v47 + 1
				end
			end
		end
	end
end
function LicensePlate.setVariation(p52, p53)
	local v54 = p52.variations[p53]
	if v54 ~= nil then
		local v55 = p52.variations[p52.variationIndex]
		for v56 = 1, #v55.values do
			local v57 = v55.values[v56]
			if not v57.isStatic then
				for v58 = 1, getNumOfChildren(v57.node) do
					delete(getChildAt(v57.node, v58 - 1))
				end
			end
		end
		p52.variationIndex = p53
		for v59 = 1, #v54.values do
			local v60 = v54.values[v59]
			if not v60.isStatic then
				v60.characterLine = CharacterLine.new(v60.node, p52.font, 1)
				v60.characterLine:setSizeAndScale(p52.fontSize, p52.fontScaleX, p52.fontScaleY)
				v60.characterLine:setTextAlignment(RenderText.ALIGN_CENTER)
				v60.characterLine:setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_MIDDLE)
			end
		end
		for v61 = 1, #v54.materials do
			v54.materials[v61]:apply(p52.node)
		end
	end
end
function LicensePlate.getFontSize(p62)
	return p62.fontSize * p62.fontMaxWidthRatio, p62.fontSize
end
function LicensePlate.setColorIndex(p63, p64)
	local v65, _ = p63.manager:getAvailableColors()
	local v66 = v65[p64]
	if v66 ~= nil then
		p63:setColor(v66.color[1], v66.color[2], v66.color[3])
	end
end
function LicensePlate.getColor(p67, p68)
	local v69, _ = p67.manager:getAvailableColors()
	local v70 = v69[p68]
	if v70 == nil then
		return nil
	else
		return v70.color
	end
end
function LicensePlate.setColor(p71, p72, p73, p74)
	local v75 = VehicleMaterial.new()
	v75:setColor(p72, p73, p74)
	v75:apply(p71.node, g_licensePlateManager.materialNamePlate)
	for v76 = 1, #p71.variations do
		for v77 = 1, #p71.variations[v76].values do
			local v78 = p71.variations[v76].values[v77]
			if not v78.isStatic and v78.node ~= nil then
				I3DUtil.setShaderParameterRec(v78.node, g_licensePlateManager.shaderParameterCharacters, p72, p73, p74)
			end
		end
	end
end
function LicensePlate.getRandomCharacters(p79, p80)
	local v81 = {}
	local v82 = true
	local v83 = p79.variations[p80]
	if v83 ~= nil then
		for v84 = 1, #v83.values do
			local v85 = v83.values[v84]
			if not v85.isStatic then
				if v85.character == nil then
					local v86 = math.random()
					local v87 = p79.font.characters
					if v85.alphabetical then
						v87 = p79.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.ALPHABETICAL]
					elseif v85.numerical then
						v87 = p79.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.NUMERICAL]
					elseif v85.special then
						v87 = p79.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.SPECIAL]
					end
					if v87 == nil or #v87 <= 0 then
						table.insert(v81, "0")
					else
						local v88 = v86 * #v87
						local v89 = math.floor(v88)
						local v90 = math.max(v89, 1)
						if v85.numerical and v82 then
							v90 = v90 == 1 and #v87 > 1 and 2 or v90
							v82 = false
						end
						local v91 = v87[v90].value
						table.insert(v81, v91)
					end
				else
					local v92 = v85.character
					table.insert(v81, v92)
				end
			end
		end
	end
	return v81
end
function LicensePlate.validateLicensePlateCharacters(p93, p94)
	local v95 = type(p94) == "table"
	local v96, v97
	if v95 then
		v96 = table.concat(p94, "")
		v97 = #p94
	else
		v97 = p94:len()
		v96 = p94
	end
	local v98 = p93.variations[p93.variationIndex]
	local v99 = filterText(v96, false, false)
	for v100 = 1, v97 do
		local v101 = v99:sub(v100, v100)
		local v102
		if v95 then
			v102 = p94[v100]
		else
			v102 = p94:sub(v100, v100)
		end
		if v101 ~= v102 then
			local v103 = v98.values[v100]
			if v103 ~= nil then
				local v104 = p93.font.characters
				if v103.alphabetical then
					v104 = p93.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.ALPHABETICAL]
				elseif v103.numerical then
					v104 = p93.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.NUMERICAL]
				elseif v103.special then
					v104 = p93.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.SPECIAL]
				end
				if v95 then
					p94[v100] = v104[1].value
				else
					p94 = v99:sub(1, v100 - 1) .. v104[1].value .. v99:sub(v100 + 1)
				end
			end
		end
	end
	return p94
end
function LicensePlate.changeCharacter(p105, p106, p107, p108, p109)
	local v110 = p105.variations[p106]
	if v110 ~= nil then
		local v111 = v110.values[p108]
		local v112 = p107[v111.realIndex]
		local v113 = {}
		if v111.alphabetical then
			local v114 = p105.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.ALPHABETICAL]
			table.insert(v113, v114)
		end
		if v111.numerical then
			local v115 = p105.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.NUMERICAL]
			table.insert(v113, v115)
		end
		if v111.special then
			local v116 = p105.font.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.SPECIAL]
			table.insert(v113, v116)
		end
		local v117 = nil
		local v118 = 1
		for v119 = 1, #v113 do
			local v120 = v113[v119]
			for v121 = 1, #v120 do
				if v120[v121].value == v112 then
					v118 = v121 + p109
					if #v120 < v118 then
						v117 = v113[v119 + 1]
						if v117 == nil then
							v118 = #v120
							v117 = v120
						else
							v118 = 1
						end
					elseif v118 < 1 then
						v117 = v113[v119 - 1]
						if v117 == nil then
							v117 = v120
							v118 = 1
						else
							v118 = #v117
						end
					else
						v117 = v120
					end
				end
			end
		end
		if v117 ~= nil and v117[v118] ~= nil then
			p107[v111.realIndex] = v117[v118].value
		end
	end
	return p107
end
function LicensePlate.getFormattedString(p122)
	if p122.characters == "" then
		return nil
	end
	local v123 = ""
	local v124 = p122.variations[p122.variationIndex]
	if v124 ~= nil then
		for v125 = 1, #v124.values do
			local v126 = v124.values[v125]
			if not v126.isStatic then
				local v127 = p122.characters:sub(v125, v125) or ""
				if v127 ~= "_" then
					if v126.nextSection then
						v123 = v123 .. " " .. v127
					else
						v123 = v123 .. v127
					end
				end
			end
		end
	end
	return v123
end
function LicensePlate.registerXMLPaths(p128, p129)
	p128:register(XMLValueType.STRING, p129 .. "#filename", "License plate i3d filename")
	p128:register(XMLValueType.NODE_INDEX, p129 .. "#node", "License plate node")
	p128:register(XMLValueType.STRING, p129 .. "#type", "License plate type \'SQUARISH\' or \'ELONGATED\'", "ELONGATED")
	p128:register(XMLValueType.FLOAT, p129 .. "#width", "Width of license plate", 1)
	p128:register(XMLValueType.FLOAT, p129 .. "#height", "Height of license plate", 0.2)
	p128:register(XMLValueType.FLOAT, p129 .. ".font#size", "Size of font", 0.1)
	p128:register(XMLValueType.FLOAT, p129 .. ".font#scaleX", "Additional scaling of font X", 1)
	p128:register(XMLValueType.FLOAT, p129 .. ".font#scaleY", "Additional scaling of font Y", 1)
	p128:register(XMLValueType.STRING, p129 .. ".variations.variation(?).value(?)#node", "Value mesh index")
	p128:register(XMLValueType.FLOAT, p129 .. ".variations.variation(?).value(?)#posX", "X translation of value node")
	p128:register(XMLValueType.FLOAT, p129 .. ".variations.variation(?).value(?)#posY", "Y translation of value node")
	p128:register(XMLValueType.FLOAT, p129 .. ".variations.variation(?).value(?)#posZ", "Z translation of value node")
	p128:register(XMLValueType.BOOL, p129 .. ".variations.variation(?).value(?)#nextSection", "Is start character for next section", false)
	p128:register(XMLValueType.STRING, p129 .. ".variations.variation(?).value(?)#character", "Pre defined character of node")
	p128:register(XMLValueType.BOOL, p129 .. ".variations.variation(?).value(?)#numerical", "Node supports numeric characters", false)
	p128:register(XMLValueType.BOOL, p129 .. ".variations.variation(?).value(?)#alphabetical", "Node supports alphabetical characters", false)
	p128:register(XMLValueType.BOOL, p129 .. ".variations.variation(?).value(?)#special", "Node supports special characters", false)
	p128:register(XMLValueType.BOOL, p129 .. ".variations.variation(?).value(?)#isStatic", "Node is only static without applying of characters", "is static if \'numerical\' and \'alphabetical\' are both on false and no fixed character is given")
	p128:register(XMLValueType.BOOL, p129 .. ".variations.variation(?).value(?)#locked", "Character value can not be changed", "locked when character is defined")
	p128:register(XMLValueType.STRING, p129 .. ".variations.variation(?).value(?)#position", "Value will be hidden of position differs from placement position", "ANY")
	VehicleMaterial.registerXMLPaths(p128, p129 .. ".variations.variation(?).material(?)")
	p128:register(XMLValueType.STRING, p129 .. ".frame#node", "Frame node that can be toggled")
	p128:register(XMLValueType.FLOAT, p129 .. ".frame#widthOffset", "Width of frame on each side", 0)
	p128:register(XMLValueType.FLOAT, p129 .. ".frame#heightOffsetTop", "Height of frame on top", 0)
	p128:register(XMLValueType.FLOAT, p129 .. ".frame#heightOffsetBot", "Height of frame at bottom", 0)
end

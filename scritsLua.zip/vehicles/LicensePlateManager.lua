LicensePlateManager = {}
LicensePlateManager.PLATE_TYPE = {}
LicensePlateManager.PLATE_TYPE.SQUARISH = 0
LicensePlateManager.PLATE_TYPE.ELONGATED = 1
LicensePlateManager.PLATE_POSITION = {}
LicensePlateManager.PLATE_POSITION.NONE = 0
LicensePlateManager.PLATE_POSITION.FRONT = 1
LicensePlateManager.PLATE_POSITION.BACK = 2
LicensePlateManager.PLATE_POSITION.ANY = 3
LicensePlateManager.CHARACTER_TYPE = {}
LicensePlateManager.CHARACTER_TYPE.NUMERICAL = 0
LicensePlateManager.CHARACTER_TYPE.ALPHABETICAL = 1
LicensePlateManager.CHARACTER_TYPE.SPECIAL = 2
LicensePlateManager.PLACEMENT_OPTION = {}
LicensePlateManager.PLACEMENT_OPTION.NONE = 0
LicensePlateManager.PLACEMENT_OPTION.BOTH = 1
LicensePlateManager.PLACEMENT_OPTION.BACK_ONLY = 2
LicensePlateManager.PLACEMENT_OPTION_TEXT = {}
LicensePlateManager.PLACEMENT_OPTION_TEXT[LicensePlateManager.PLACEMENT_OPTION.NONE] = "ui_licensePlatePlacementNone"
LicensePlateManager.PLACEMENT_OPTION_TEXT[LicensePlateManager.PLACEMENT_OPTION.BOTH] = "ui_licensePlatePlacementBoth"
LicensePlateManager.PLACEMENT_OPTION_TEXT[LicensePlateManager.PLACEMENT_OPTION.BACK_ONLY] = "ui_licensePlatePlacementBackOnly"
LicensePlateManager.SEND_NUM_BITS_VARIATION = 4
LicensePlateManager.SEND_NUM_BITS_COLOR = 6
LicensePlateManager.SEND_NUM_BITS_CHARACTER = 8
LicensePlateManager.SEND_NUM_BITS_PLACEMENT = 2
LicensePlateManager.xmlSchema = nil
local v_u_1 = Class(LicensePlateManager, AbstractManager)
function LicensePlateManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function LicensePlateManager.initDataStructures(p3)
	p3.licensePlates = {}
	p3.colorConfigurations = {}
	p3.licensePlatesAvailable = false
	p3.sharedLoadRequestIds = {}
end
function LicensePlateManager.loadMapData(p4, p5, _, p6)
	LicensePlateManager:superClass().loadMapData(p4)
	p4.baseDirectory = p6
	LicensePlateManager.createLicensePlateXMLSchema()
	local v7 = getXMLString(p5, "map.licensePlates#filename")
	if v7 ~= nil then
		p4.xmlFilename = Utils.getFilename(v7, p6)
		p4.licensePlateXML = XMLFile.load("mapLicensePlates", p4.xmlFilename, LicensePlateManager.xmlSchema)
		if p4.licensePlateXML ~= nil then
			p4.xmlReferences = 0
			p4:loadLicensePlatesFromXML(p4.licensePlateXML, p6)
			if p4.licensePlateXML ~= nil and p4.xmlReferences == 0 then
				p4.licensePlateXML:delete()
				p4.licensePlateXML = nil
			end
		end
	end
	return true
end
function LicensePlateManager.unloadMapData(p8)
	for v9 = 1, #p8.licensePlates do
		p8.licensePlates[v9]:delete()
	end
	if p8.sharedLoadRequestIds ~= nil then
		for _, v10 in ipairs(p8.sharedLoadRequestIds) do
			g_i3DManager:releaseSharedI3DFile(v10)
		end
		p8.sharedLoadRequestIds = nil
	end
	if p8.licensePlateXML ~= nil then
		p8.licensePlateXML:delete()
		p8.licensePlateXML = nil
	end
	LicensePlateManager:superClass().unloadMapData(p8)
end
function LicensePlateManager.loadLicensePlatesFromXML(p_u_11, p_u_12, p_u_13)
	local v_u_14, _ = Utils.getModNameAndBaseDirectory(p_u_13)
	p_u_11.fontName = p_u_12:getValue("licensePlates.font#name", "GENERIC")
	p_u_11.customEnvironment = v_u_14
	p_u_12:iterate("licensePlates.licensePlate", function(_, p15)
		-- upvalues: (copy) p_u_12, (copy) p_u_11, (copy) p_u_13, (copy) v_u_14
		local v16 = p_u_12:getValue(p15 .. "#filename")
		if v16 == nil then
			Logging.xmlError(p_u_12, "Missing filename for license plate \'%s\'", p15)
		else
			p_u_11.xmlReferences = p_u_11.xmlReferences + 1
			local v17 = Utils.getFilename(v16, p_u_13)
			local v18 = {
				["filename"] = v17,
				["xmlFile"] = p_u_12,
				["plateKey"] = p15,
				["customEnvironment"] = v_u_14
			}
			local v19 = g_i3DManager:loadSharedI3DFileAsync(v17, false, false, p_u_11.licensePlateI3DFileLoaded, p_u_11, v18)
			local v20 = p_u_11.sharedLoadRequestIds
			table.insert(v20, v19)
		end
	end)
	p_u_11.materialNamePlate = p_u_12:getValue("licensePlates.colorConfigurations#materialName", "licensePlateColored_mat")
	p_u_11.shaderParameterCharacters = p_u_12:getValue("licensePlates.colorConfigurations#shaderParameterCharacters", "colorScale")
	p_u_11.useDefaultColors = p_u_12:getValue("licensePlates.colorConfigurations#useDefaultColors", false)
	p_u_11.defaultColorIndex = p_u_12:getValue("licensePlates.colorConfigurations#defaultColorIndex")
	p_u_11.defaultColorMaxBrightness = p_u_12:getValue("licensePlates.colorConfigurations#defaultColorMaxBrightness", 0.55)
	local v_u_21 = 1
	p_u_12:iterate("licensePlates.colorConfigurations.colorConfiguration", function(p22, p23)
		-- upvalues: (copy) p_u_12, (copy) p_u_11, (ref) v_u_21
		local v24 = p_u_12:getValue(p23 .. "#name", "", p_u_11.customEnvironment, false)
		local v25 = p_u_12:getValue(p23 .. "#color", nil, true)
		local v26 = p_u_12:getValue(p23 .. "#isDefault", false)
		if v25 ~= nil then
			if v26 then
				v_u_21 = p22
			end
			local v27 = p_u_11.colorConfigurations
			table.insert(v27, {
				["name"] = v24,
				["color"] = v25,
				["isDefault"] = v26
			})
		end
	end)
	if p_u_11.defaultColorIndex == nil then
		p_u_11.defaultColorIndex = v_u_21
	else
		p_u_11.defaultColorIndex = p_u_11.defaultColorIndex + #p_u_11.colorConfigurations
	end
	p_u_11.colors = {}
	for v28 = 1, #p_u_11.colorConfigurations do
		local v29 = p_u_11.colors
		local v30 = p_u_11.colorConfigurations[v28]
		table.insert(v29, v30)
	end
	if p_u_11.useDefaultColors then
		for v31 = 1, #VehicleConfigurationItemColor.DEFAULT_COLORS do
			local v32 = VehicleConfigurationItemColor.DEFAULT_COLORS[v31]
			local v33, v34 = g_vehicleMaterialManager:getMaterialTemplateColorAndTitleByName(v32, v_u_14)
			if v33 ~= nil then
				local v35 = {
					["name"] = v34 or "",
					["color"] = v33
				}
				if MathUtil.getBrightnessFromColor(v33[1], v33[2], v33[3]) < p_u_11.defaultColorMaxBrightness then
					local v36 = p_u_11.colors
					table.insert(v36, v35)
				end
			end
		end
	end
	p_u_11.defaultPlacementIndex = LicensePlateManager.PLACEMENT_OPTION.BOTH
	local v37 = p_u_12:getValue("licensePlates.placement#defaultType")
	if v37 ~= nil then
		p_u_11.defaultPlacementIndex = LicensePlateManager.PLACEMENT_OPTION[v37:upper()] or p_u_11.defaultPlacementIndex
	end
end
function LicensePlateManager.licensePlateI3DFileLoaded(p38, p39, _, p40)
	local v41 = p40.filename
	local v42 = p40.xmlFile
	local v43 = p40.plateKey
	local v44 = p40.customEnvironment
	if p39 ~= nil and p39 ~= 0 then
		local v45 = v42:getValue(v43 .. "#node", nil, p39)
		if v45 ~= nil then
			unlink(v45)
			local v46 = LicensePlate.new()
			if v46:loadFromXML(v45, v41, v44, v42, v43) then
				local v47 = p38.licensePlates
				table.insert(v47, v46)
			end
		end
		delete(p39)
	end
	p38.xmlReferences = p38.xmlReferences - 1
	if p38.xmlReferences == 0 then
		v42:delete()
		p38.licensePlatesAvailable = #p38.licensePlates > 0
		if v42 == p38.licensePlateXML then
			p38.licensePlateXML = nil
		end
	end
end
function LicensePlateManager.getAreLicensePlatesAvailable(p48)
	local v49 = p48.licensePlatesAvailable
	if v49 then
		v49 = g_materialManager:getFontMaterial(p48.fontName, p48.customEnvironment)
	end
	return v49
end
function LicensePlateManager.getLicensePlate(p50, p51, p52)
	local v53 = p50.licensePlates[1]
	for v54 = 1, #p50.licensePlates do
		if p50.licensePlates[v54].type == p51 then
			v53 = p50.licensePlates[v54]
		end
	end
	if v53 == nil then
		return nil
	else
		return v53:clone(p52)
	end
end
function LicensePlateManager.getLicensePlateValues(_, p55, p56)
	local v57 = p55.variations[p56]
	if v57 == nil then
		return nil
	else
		return v57.values
	end
end
function LicensePlateManager.getRandomLicensePlateData(p58)
	local v59 = p58.licensePlates[1]
	return v59 == nil and {
		["variation"] = 1,
		["characters"] = nil,
		["colorIndex"] = nil,
		["placementIndex"] = p58:getDefaultPlacementIndex()
	} or {
		["variation"] = 1,
		["characters"] = v59:getRandomCharacters(1),
		["colorIndex"] = p58.defaultColorIndex,
		["placementIndex"] = p58:getDefaultPlacementIndex()
	}
end
function LicensePlateManager.getAvailableColors(p60)
	return p60.colors, p60.defaultColorIndex
end
function LicensePlateManager.getDefaultPlacementIndex(p61)
	return p61.defaultPlacementIndex
end
function LicensePlateManager.getFont(p62)
	return g_materialManager:getFontMaterial(p62.fontName, p62.customEnvironment)
end
function LicensePlateManager.readLicensePlateData(p63, _)
	local v64 = {
		["variation"] = 1,
		["characters"] = nil,
		["colorIndex"] = nil,
		["placementIndex"] = 1
	}
	if streamReadBool(p63) then
		v64.variation = streamReadUIntN(p63, LicensePlateManager.SEND_NUM_BITS_VARIATION)
		v64.colorIndex = streamReadUIntN(p63, LicensePlateManager.SEND_NUM_BITS_COLOR)
		v64.placementIndex = streamReadUIntN(p63, LicensePlateManager.SEND_NUM_BITS_PLACEMENT)
		local v65 = g_licensePlateManager:getFont()
		v64.characters = {}
		for _ = 1, streamReadUIntN(p63, LicensePlateManager.SEND_NUM_BITS_CHARACTER) do
			local v66 = v65:getCharacterByCharacterIndex((streamReadUIntN(p63, LicensePlateManager.SEND_NUM_BITS_CHARACTER))) or "_"
			local v67 = v64.characters
			table.insert(v67, v66)
		end
	end
	return v64
end
function LicensePlateManager.writeLicensePlateData(p68, _, p69)
	local v70 = streamWriteBool
	local v71
	if p69 == nil or (p69.variation == nil or (p69.characters == nil or p69.colorIndex == nil)) then
		v71 = false
	else
		v71 = p69.placementIndex ~= nil
	end
	if v70(p68, v71) then
		streamWriteUIntN(p68, p69.variation, LicensePlateManager.SEND_NUM_BITS_VARIATION)
		streamWriteUIntN(p68, p69.colorIndex, LicensePlateManager.SEND_NUM_BITS_COLOR)
		streamWriteUIntN(p68, p69.placementIndex, LicensePlateManager.SEND_NUM_BITS_PLACEMENT)
		local v72 = g_licensePlateManager:getFont()
		streamWriteUIntN(p68, #p69.characters, LicensePlateManager.SEND_NUM_BITS_CHARACTER)
		for v73 = 1, #p69.characters do
			local v74 = v72:getCharacterIndexByCharacter(p69.characters[v73])
			streamWriteUIntN(p68, v74, LicensePlateManager.SEND_NUM_BITS_CHARACTER)
		end
	end
end
function LicensePlateManager.loadLicensePlateDataFromXML(p75, p76, p77)
	if not p75:hasProperty(p76 .. "#variation") then
		return nil
	end
	local v78 = {}
	if p77 then
		v78.xmlFilename = p75:getString(p76 .. "#configuration")
	else
		v78.xmlFilename = NetworkUtil.convertFromNetworkFilename(p75:getString(p76 .. "#configuration"))
	end
	v78.variation = p75:getInt(p76 .. "#variation")
	v78.colorIndex = p75:getInt(p76 .. "#color")
	v78.placementIndex = p75:getInt(p76 .. "#placement")
	v78.characters = {}
	local v79 = p75:getString(p76 .. "#characters")
	for v80 = 1, v79:len() do
		local v81 = v78.characters
		table.insert(v81, v79:sub(v80, v80))
	end
	return v78
end
function LicensePlateManager.saveLicensePlateDataToXML(p82, p83, p84, p85)
	local v86
	if p84 == nil or (p84.variation == nil or (p84.characters == nil or p84.colorIndex == nil)) then
		v86 = false
	else
		v86 = p84.placementIndex ~= nil
	end
	if v86 then
		p82:setInt(p83 .. "#variation", p84.variation)
		p82:setInt(p83 .. "#color", p84.colorIndex)
		p82:setInt(p83 .. "#placement", p84.placementIndex)
		p82:setString(p83 .. "#characters", table.concat(p84.characters, ""))
		if p85 then
			p82:setString(p83 .. "#configuration", p84.xmlFilename)
			return
		end
		p82:setString(p83 .. "#configuration", NetworkUtil.convertToNetworkFilename(p84.xmlFilename))
	end
end
function LicensePlateManager.createLicensePlateAIIcons(_, p87, p88, p89, p90)
	if LicensePlateManager.licensePlatesIconRootNode == nil then
		local v91 = tonumber(p87) or 3
		local v92 = tonumber(p88) or 10
		local v93 = tonumber(p89) or 1
		local v94 = LicensePlateManager.PLATE_POSITION[(p90 or "BACK"):upper()] or LicensePlateManager.PLATE_POSITION.BACK
		LicensePlateManager.licensePlatesIconRootNode = createTransformGroup("licensePlatesIconRootNode")
		link(getRootNode(), LicensePlateManager.licensePlatesIconRootNode)
		setTranslation(LicensePlateManager.licensePlatesIconRootNode, 0, -10, 0)
		local v95 = g_licensePlateManager:getLicensePlate(LicensePlateManager.PLATE_TYPE.ELONGATED)
		if v95 ~= nil then
			local _ = v95.height / v95.width
			local v96 = v92 * v95.height
			local v97 = v91 * v95.width
			for v98 = 1, v92 do
				for v99 = 1, v91 do
					local v100 = g_licensePlateManager:getLicensePlate(LicensePlateManager.PLATE_TYPE.ELONGATED)
					if v100 ~= nil then
						link(LicensePlateManager.licensePlatesIconRootNode, v100.node)
						setTranslation(v100.node, (v99 - 1) * v95.width + v95.width * 0.5, (v98 - 1) * v95.height + v95.height * 0.5, 0)
						setRotation(v100.node, 0, 0, 0)
						local v101 = v100:getRandomCharacters(v93)
						v100:updateData(v93, v94, table.concat(v101, ""))
					end
				end
			end
			local v102 = createCamera("licensePlatesIconCamera", 3437.746770784939, 0.1, 12)
			link(LicensePlateManager.licensePlatesIconRootNode, v102)
			setTranslation(v102, v97 * 0.5, v96 * 0.5, 10)
			setIsOrthographic(v102, true)
			setOrthographicHeight(v102, v96)
			LicensePlateManager.licensePlatesIconLastCamera = g_cameraManager:getActiveCamera()
			g_cameraManager:addCamera(v102)
			g_cameraManager:setActiveCamera(v102)
			g_currentMission.hud:setIsVisible(false)
			g_noHudModeEnabled = true
		end
	else
		delete(LicensePlateManager.licensePlatesIconRootNode)
		LicensePlateManager.licensePlatesIconRootNode = nil
		g_cameraManager:setActiveCamera(LicensePlateManager.licensePlatesIconLastCamera)
		LicensePlateManager.licensePlatesIconLastCamera = nil
		g_currentMission.hud:setIsVisible(true)
	end
end
addConsoleCommand("gsLicensePlateCreateAIIcons", "Create license plate icons for AI vehicles", "createLicensePlateAIIcons", LicensePlateManager, "numX; numY; variationIndex; position")
function LicensePlateManager.createLicensePlateXMLSchema()
	if LicensePlateManager.xmlSchema == nil then
		local v103 = XMLSchema.new("mapLicensePlates")
		LicensePlate.registerXMLPaths(v103, "licensePlates.licensePlate(?)")
		v103:register(XMLValueType.STRING, "licensePlates.font#name", "License plate font name", "GENERIC")
		v103:register(XMLValueType.STRING, "licensePlates.colorConfigurations#materialName", "Name of colored license plate material", "licensePlateColored_mat")
		v103:register(XMLValueType.STRING, "licensePlates.colorConfigurations#shaderParameterCharacters", "Color shader parameter of characters", "colorSale")
		v103:register(XMLValueType.BOOL, "licensePlates.colorConfigurations#useDefaultColors", "License plate can be colored with all available default colors", false)
		v103:register(XMLValueType.INT, "licensePlates.colorConfigurations#defaultColorIndex", "Default selected color")
		v103:register(XMLValueType.FLOAT, "licensePlates.colorConfigurations#defaultColorMaxBrightness", "Default colors with higher brightness will be skipped", 0.55)
		v103:register(XMLValueType.L10N_STRING, "licensePlates.colorConfigurations.colorConfiguration(?)#name", "Name of color to display")
		v103:register(XMLValueType.COLOR, "licensePlates.colorConfigurations.colorConfiguration(?)#color", "Color values")
		v103:register(XMLValueType.BOOL, "licensePlates.colorConfigurations.colorConfiguration(?)#isDefault", "Color is default selected")
		v103:register(XMLValueType.STRING, "licensePlates.placement#defaultType", "Default type of placement (none/both/back_only)", "both")
		LicensePlateManager.xmlSchema = v103
	end
end
g_licensePlateManager = LicensePlateManager.new()

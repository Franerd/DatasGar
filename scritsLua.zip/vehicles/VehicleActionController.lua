VehicleActionController = {}
local v_u_1 = Class(VehicleActionController)
source("dataS/scripts/vehicles/VehicleActionControllerAction.lua")
function VehicleActionController.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.vehicle = p2
	v5.actions = {}
	v5.actionsByPrio = {}
	v5.sortedActions = {}
	v5.sortedActionsRev = {}
	v5.currentSequenceActions = {}
	v5.actionEvents = {}
	v5.lastDirection = -1
	v5.pendingControllerReactivation = false
	v5.loadedNumActions = 0
	return v5
end
function VehicleActionController.saveToXMLFile(p6, p7, p8, _)
	if #p6.actions > 0 then
		p7:setValue(p8 .. "#lastDirection", p6.lastDirection)
		p7:setValue(p8 .. "#numActions", #p6.actions)
		local v9 = 0
		for _, v10 in ipairs(p6.actions) do
			if v10:getIsSaved() then
				local v11 = string.format("%s.action(%d)", p8, v9)
				p7:setValue(v11 .. "#name", v10.name)
				p7:setValue(v11 .. "#identifier", v10.identifier)
				p7:setValue(v11 .. "#lastDirection", v10:getLastDirection())
				v9 = v9 + 1
			end
		end
	end
end
function VehicleActionController.load(p12, p13)
	if p13 ~= nil and not p13.resetVehicles then
		p12.lastDirection = p13.xmlFile:getValue(p13.key .. ".actionController#lastDirection", p12.lastDirection)
		p12.loadedNumActions = p13.xmlFile:getValue(p13.key .. ".actionController#numActions", 0)
		p12.loadTime = g_time
		p12.loadedActions = {}
		local v14 = 0
		local v15 = false
		while true do
			local v16 = string.format("%s.actionController.action(%d)", p13.key, v14)
			if not p13.xmlFile:hasProperty(v16) then
				break
			end
			local v17 = {
				["name"] = p13.xmlFile:getValue(v16 .. "#name"),
				["identifier"] = p13.xmlFile:getValue(v16 .. "#identifier"),
				["lastDirection"] = p13.xmlFile:getValue(v16 .. "#lastDirection")
			}
			v15 = v17.lastDirection > 0 and true or v15
			local v18 = p12.loadedActions
			table.insert(v18, v17)
			v14 = v14 + 1
		end
		if not v15 then
			p12.loadedNumActions = 0
			p12.loadedActions = {}
		end
	end
end
function VehicleActionController.registerAction(p19, p20, p21, p22)
	local v23 = VehicleActionControllerAction.new(p19, p20, p21, p22)
	p19:addAction(v23)
	return v23
end
function VehicleActionController.addAction(p24, p25)
	local v26 = p24.actions
	table.insert(v26, p25)
	p24:updateSortedActions()
	p24.actionsDirty = true
	p24.vehicle:requestActionEventUpdate()
end
function VehicleActionController.removeAction(p27, p28)
	if Platform.gameplay.automaticVehicleControl and (p28:getLastDirection() == 1 and p28:getDoResetOnDeactivation()) then
		p28:doAction()
	end
	for v29, v30 in ipairs(p27.actions) do
		if v30 == p28 then
			table.remove(p27.actions, v29)
			break
		end
	end
	if #p27.actions == 0 then
		p27.lastDirection = -1
	end
	p27:updateSortedActions()
end
function VehicleActionController.updateSortedActions(p31)
	p31.actionsByPrio = {}
	local v32 = {}
	for _, v33 in ipairs(p31.actions) do
		if v32[v33.priority] == nil then
			local v34 = { v33 }
			local v35 = p31.actionsByPrio
			table.insert(v35, v34)
			v32[v33.priority] = v34
		else
			local v36 = v32[v33.priority]
			table.insert(v36, v33)
		end
	end
	p31.sortedActions = table.clone(p31.actionsByPrio)
	table.sort(p31.sortedActions, function(p37, p38)
		return p37[1].priority > p38[1].priority
	end)
	p31.sortedActionsRev = table.clone(p31.actionsByPrio)
	table.sort(p31.sortedActionsRev, function(p39, p40)
		return p39[1].priority < p40[1].priority
	end)
end
function VehicleActionController.activate(p41)
	if p41.pendingControllerReactivation then
		if p41.vehicle == p41.vehicle.rootVehicle then
			p41.lastDirection = -p41.lastDirection
			p41:startActionSequence(true)
		end
		p41.pendingControllerReactivation = false
	end
end
function VehicleActionController.deactivate(p42)
	if p42.vehicle == p42.vehicle.rootVehicle and p42.lastDirection > 0 then
		p42.pendingControllerReactivation = true
	end
end
function VehicleActionController.registerActionEvents(p43, p44, p45)
	if #p43.actions > 0 and p43.vehicle.rootVehicle == p43.vehicle then
		p43.vehicle:clearActionEventsTable(p43.actionEvents)
		for _, v46 in ipairs(p43.actions) do
			v46:registerActionEvents(p43, p43.vehicle, p43.actionEvents, p44, p45)
		end
		if p43.actionEventId ~= nil then
			g_inputBinding:removeActionEvent(p43.actionEventId)
		end
		local _, v47, _ = g_inputBinding:registerActionEvent(InputAction.VEHICLE_ACTION_CONTROL, p43, VehicleActionController.actionSequenceEvent, false, true, false, true)
		p43.actionEventId = v47
	end
end
function VehicleActionController.actionEvent(p48, _, _, p49, _)
	p48:doAction(p49)
end
function VehicleActionController.doAction(p50, p51, p52, p53)
	local v54 = p50:getActionsByIndex(p51, p52)
	if v54 == nil then
		return false
	end
	local v55 = false
	for _, v56 in ipairs(v54) do
		v55 = v55 or v56:doAction(p53)
	end
	return v55
end
function VehicleActionController.actionSequenceEvent(p57)
	if p57.loadedNumActions == 0 then
		if p57.vehicle.getAreControlledActionsAccessible == nil or p57.vehicle:getAreControlledActionsAccessible() then
			if p57.vehicle.getAreControlledActionsAvailable ~= nil then
				if not p57.vehicle:getAreControlledActionsAvailable() then
					return
				end
				local v58, v59 = p57.vehicle:getAreControlledActionsAllowed()
				if not v58 then
					if v59 ~= nil then
						g_currentMission:showBlinkingWarning(v59, 2500)
					end
					return
				end
			end
			p57:startActionSequence()
		end
	else
		return
	end
end
function VehicleActionController.startActionSequence(p60, p61)
	local v62 = -p60.lastDirection
	p60.currentSequenceActions = p60.sortedActionsRev
	if v62 > 0 then
		p60.currentSequenceActions = p60.sortedActions
	end
	if not p61 then
		local v63 = true
		for _, v64 in ipairs(p60.currentSequenceActions) do
			for _, v65 in ipairs(v64) do
				local v66 = v65.lastValidDirection == v62
				v63 = v63 and v66
			end
		end
		if v63 then
			p60.lastDirection = v62
			p60:startActionSequence(true)
			return
		end
	end
	if p60.currentSequenceIndex == nil then
		p60.currentSequenceIndex = 1
		p60.currentMaxSequenceIndex = #p60.currentSequenceActions
	else
		p60.currentSequenceIndex = p60.currentMaxSequenceIndex - (p60.currentSequenceIndex - 1)
	end
	p60.lastDirection = v62
	if not p60:doAction(p60.currentSequenceIndex, p60.currentSequenceActions, p60.lastDirection) then
		if p60.currentMaxSequenceIndex == 1 then
			p60.lastDirection = -v62
			p60:stopActionSequence()
			return
		end
		p60:continueActionSequence()
	end
end
function VehicleActionController.continueActionSequence(p67)
	p67.currentSequenceIndex = p67.currentSequenceIndex + 1
	local v68 = p67:doAction(p67.currentSequenceIndex, p67.currentSequenceActions, p67.lastDirection)
	if p67.currentSequenceIndex >= p67.currentMaxSequenceIndex then
		p67:stopActionSequence()
	elseif not v68 then
		p67:continueActionSequence()
	end
end
function VehicleActionController.stopActionSequence(p69)
	p69.currentSequenceActions = nil
	p69.currentSequenceIndex = nil
	p69.currentMaxSequenceIndex = nil
end
function VehicleActionController.getActionsByIndex(p70, p71, p72)
	if p72 == nil then
		return p70.actionsByPrio[p71]
	else
		return p72[p71]
	end
end
function VehicleActionController.getAreControlledActionsAvailable(p73)
	for v74 = 1, #p73.actions do
		if not p73.actions[v74]:isAvailable() then
			return false
		end
	end
	return #p73.actions > 0
end
function VehicleActionController.getAreControlledActionsAccessible(p75)
	for v76 = 1, #p75.actions do
		if not p75.actions[v76]:isAccessible() then
			return false
		end
	end
	return #p75.actions > 0
end
function VehicleActionController.getControlledActionIcons(p77)
	for v78 = 1, #p77.actions do
		local v79, v80, v81 = p77.actions[v78]:getControlledActionIcons()
		if v79 ~= nil then
			return v79, v80, v81
		end
	end
	return nil
end
function VehicleActionController.playControlledActions(p82)
	if p82.loadedNumActions == 0 then
		p82:startActionSequence()
	end
end
function VehicleActionController.resetCurrentState(p83)
	p83.lastDirection = -1
end
function VehicleActionController.getActionControllerDirection(p84)
	return -p84.lastDirection
end
function VehicleActionController.update(p85, p86)
	if p85.currentSequenceIndex ~= nil and p85.currentSequenceIndex <= p85.currentMaxSequenceIndex then
		local v87 = p85:getActionsByIndex(p85.currentSequenceIndex, p85.currentSequenceActions)
		if v87 ~= nil then
			local v88 = true
			for _, v89 in ipairs(v87) do
				if not v89:getIsFinished(p85.lastDirection) then
					v88 = false
					break
				end
			end
			if v88 then
				if p85.currentSequenceIndex < p85.currentMaxSequenceIndex then
					p85:continueActionSequence()
				else
					p85:stopActionSequence()
				end
			end
		end
	end
	for _, v90 in ipairs(p85.actions) do
		v90:update(p86)
	end
	if p85.loadedNumActions ~= 0 and (p85.loadedNumActions == #p85.actions and p85.loadTime + 500 < g_time) and (p85.vehicle.getIsMotorStarted == nil or p85.vehicle:getIsMotorStarted()) then
		for _, v91 in ipairs(p85.loadedActions) do
			for _, v92 in ipairs(p85.actions) do
				if v92.name == v91.name and (v92.identifier == v91.identifier and v92:getLastDirection() ~= v91.lastDirection) then
					v92:doAction()
				end
			end
		end
		p85.loadedNumActions = 0
		p85.actionsDirty = false
	end
	if p85.actionsDirty and p85.loadedNumActions == 0 then
		for _, v93 in ipairs(p85.actions) do
			if v93:getLastDirection() ~= p85.lastDirection then
				v93:doAction()
			end
		end
		p85.actionsDirty = nil
	end
end
function VehicleActionController.updateForAI(p94, p95)
	for _, v96 in ipairs(p94.actions) do
		v96:updateForAI(p95)
	end
end
function VehicleActionController.onAIEvent(p97, p98, p99)
	for _, v100 in ipairs(p97.actions) do
		if v100:getSourceVehicle() == p98 then
			v100:onAIEvent(p99)
		end
	end
end
function VehicleActionController.drawDebugRendering(p101)
	local function v_u_107(p102, p103, p104, p105, p106)
		setTextColor(0, 0, 0, 0.75)
		renderText(p102, p103 - 0.0015, p104, p105)
		setTextColor(unpack(p106 or {
			1,
			1,
			1,
			1
		}))
		renderText(p102, p103, p104, p105)
	end
	local function v118(p108, p109, p110, p111, p112)
		-- upvalues: (copy) v_u_107
		if p109 ~= nil and #p109 > 0 then
			setTextBold(false)
			setTextAlignment(RenderText.ALIGN_CENTER)
			local v113 = 0
			for v114 = #p109, 1, -1 do
				local v115 = p109[v114]
				setTextBold(p110 == v114)
				local v116 = v114 < p110 and {
					0,
					1,
					0,
					1
				} or (v114 == p110 and {
					1,
					0.5,
					0,
					1
				} or nil)
				for _, v117 in ipairs(v115) do
					v_u_107(p111, p112 + v113, 0.012, v117:getDebugText(), v116)
					v113 = v113 + 0.014
				end
				v_u_107(p111, p112 + v113 + 0.007, 0.012, "__________________________")
				v113 = v113 + 0.014
			end
			v_u_107(p111, p112 + v113 + 0.007, 0.018000000000000002, p108)
			setTextBold(false)
			setTextAlignment(RenderText.ALIGN_LEFT)
		end
	end
	v118(string.format("Controlled Actions (%s)", p101.lastDirection == 1 and "On" or "Off"), p101.sortedActions, -1, 0.2, 0.3)
	local v119 = p101.lastDirection == 1 and "TurnOn" or "TurnOff"
	v118(string.format("Current Action Sequence (%s)", v119), p101.currentSequenceActions, p101.currentSequenceIndex, 0.4, 0.3)
end
function VehicleActionController.registerXMLPaths(p120, p121)
	p120:register(XMLValueType.INT, p121 .. "#lastDirection", "Last action controller direction")
	p120:register(XMLValueType.INT, p121 .. "#numActions", "Action controller actions")
	p120:register(XMLValueType.STRING, p121 .. ".action(?)#name", "Action name")
	p120:register(XMLValueType.STRING, p121 .. ".action(?)#identifier", "Action identifier")
	p120:register(XMLValueType.INT, p121 .. ".action(?)#lastDirection", "Last action direction")
end

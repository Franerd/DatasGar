WheelSteering = {}
function WheelSteering.new(p1)
	local v2 = {
		["__index"] = WheelSteering
	}
	local v3 = setmetatable({}, v2)
	v3.wheel = p1
	v3.vehicle = p1.vehicle
	v3.steeringNodeMaxRot = 1
	v3.steeringNodeMinRot = -1
	return v3
end
function WheelSteering.loadFromXML(p4, p5)
	p4.steeringNode = p5:getValue(".steering#node", nil, p4.vehicle.components, p4.vehicle.i3dMappings)
	p4.steeringRotNode = p5:getValue(".steering#rotNode", nil, p4.vehicle.components, p4.vehicle.i3dMappings)
	p4.steeringNodeMinTransX = p5:getValue(".steering#nodeMinTransX")
	p4.steeringNodeMaxTransX = p5:getValue(".steering#nodeMaxTransX")
	p4.steeringNodeMinRotY = p5:getValue(".steering#nodeMinRotY")
	p4.steeringNodeMaxRotY = p5:getValue(".steering#nodeMaxRotY")
	p4.fenders = {}
	local v6 = 0
	while true do
		local v7 = string.format(".fender(%d)", v6)
		local v8, _ = p5:getXMLFileAndPropertyKey(v7)
		if v8 == nil then
			break
		end
		local v9 = {
			["node"] = p5:getValue(v7 .. "#node", nil, p4.vehicle.components, p4.vehicle.i3dMappings)
		}
		if v9.node ~= nil then
			v9.rotMax = p5:getValue(v7 .. "#rotMax")
			v9.rotMin = p5:getValue(v7 .. "#rotMin")
			local v10 = p4.fenders
			table.insert(v10, v9)
		end
		v6 = v6 + 1
	end
	p4.steeringAxleScale = p5:getValue(".steeringAxle#scale", 0)
	p4.steeringAxleRotMax = p5:getValue(".steeringAxle#rotMax", 0)
	p4.steeringAxleRotMin = p5:getValue(".steeringAxle#rotMin", -0)
	return true
end
function WheelSteering.setSteeringValues(p11, p12, p13, _, _, p14)
	if p11.steeringAxleScale ~= 0 then
		if p14 then
			p11.steeringAxleScale = -p11.steeringAxleScale
		end
		p11.steeringAxleRotMax = p13
		p11.steeringAxleRotMin = p12
	end
	for v15 = 1, #p11.fenders do
		local v16 = p11.fenders[v15]
		v16.rotMax = v16.rotMax or p13
		v16.rotMin = v16.rotMin or p12
	end
	local v17 = p11.steeringAxleRotMax
	p11.steeringNodeMaxRot = math.max(p13, v17)
	local v18 = p11.steeringAxleRotMin
	p11.steeringNodeMinRot = math.min(p12, v18)
end
function WheelSteering.update(p19, _, _, _, _, _, p20, _)
	if p19.steeringNode ~= nil then
		local v21 = p19.steeringNodeMaxRot
		local v22 = p19.steeringNodeMaxTransX
		local v23 = p19.steeringNodeMaxRotY
		if p20 < 0 then
			v21 = p19.steeringNodeMinRot
			v22 = p19.steeringNodeMinTransX
			v23 = p19.steeringNodeMinRotY
		end
		local v24 = v21 == 0 and 0 or p20 / v21
		if p19.steeringNodeMinTransX ~= nil then
			local _, v25, v26 = getTranslation(p19.steeringNode)
			local v27 = v22 * v24
			setTranslation(p19.steeringNode, v27, v25, v26)
		end
		if p19.steeringNodeMinRotY ~= nil then
			local v28, _, v29 = getRotation(p19.steeringRotNode or p19.steeringNode)
			local v30 = v23 * v24
			setRotation(p19.steeringRotNode or p19.steeringNode, v28, v30, v29)
		end
	end
	for v31 = 1, #p19.fenders do
		local v32 = p19.fenders[v31]
		local v33 = 0
		if v32.rotMax < p20 then
			v33 = v32.rotMax - p20
		elseif p20 < v32.rotMin then
			v33 = v32.rotMin - p20
		end
		setRotation(v32.node, 0, v33, 0)
	end
end
function WheelSteering.registerXMLPaths(p34, p35)
	p34:register(XMLValueType.NODE_INDEX, p35 .. ".steering#node", "Steering node")
	p34:register(XMLValueType.NODE_INDEX, p35 .. ".steering#rotNode", "Steering rot node")
	p34:register(XMLValueType.FLOAT, p35 .. ".steering#nodeMinTransX", "Min. X translation")
	p34:register(XMLValueType.FLOAT, p35 .. ".steering#nodeMaxTransX", "Max. X translation")
	p34:register(XMLValueType.ANGLE, p35 .. ".steering#nodeMinRotY", "Min. Y rotation")
	p34:register(XMLValueType.ANGLE, p35 .. ".steering#nodeMaxRotY", "Max. Y rotation")
	p34:register(XMLValueType.NODE_INDEX, p35 .. ".fender(?)#node", "Fender node")
	p34:register(XMLValueType.ANGLE, p35 .. ".fender(?)#rotMax", "Max. rotation")
	p34:register(XMLValueType.ANGLE, p35 .. ".fender(?)#rotMin", "Min. rotation")
	p34:register(XMLValueType.FLOAT, p35 .. ".steeringAxle#scale", "Steering axle scale")
	p34:register(XMLValueType.ANGLE, p35 .. ".steeringAxle#rotMax", "Max. rotation")
	p34:register(XMLValueType.ANGLE, p35 .. ".steeringAxle#rotMin", "Min. rotation")
end

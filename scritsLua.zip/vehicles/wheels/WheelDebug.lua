WheelDebug = {}
function WheelDebug.new(p1)
	local v2 = {
		["__index"] = WheelDebug
	}
	local v3 = setmetatable({}, v2)
	v3.wheel = p1
	v3.vehicle = p1.vehicle
	return v3
end
function WheelDebug.delete(p4)
	if p4.lateralFrictionGraph ~= nil then
		p4.lateralFrictionGraph:delete()
	end
	if p4.longitudalFrictionGraph ~= nil then
		p4.longitudalFrictionGraph:delete()
	end
	if p4.longitudalFrictionSlipOverlay ~= nil then
		delete(p4.longitudalFrictionSlipOverlay)
	end
	if p4.lateralFrictionSlipOverlay ~= nil then
		delete(p4.lateralFrictionSlipOverlay)
	end
end
function WheelDebug.drawSlipGraphs(p5)
	local v6, v7 = getWheelShapeSlip(p5.wheel.node, p5.wheel.physics.wheelShape)
	local v8 = getWheelShapeContactForce(p5.wheel.node, p5.wheel.physics.wheelShape)
	local v9
	if v8 == nil then
		v9 = 0
	else
		local v10, v11, v12 = getWheelShapeContactNormal(p5.wheel.node, p5.wheel.physics.wheelShape)
		local v13, v14, v15 = localDirectionToWorld(p5.wheel.node, 0, -1, 0)
		local v16 = -v8 * MathUtil.dotProduct(v13, v14, v15, v10, v11, v12)
		local v17 = v11 * 9.81
		v9 = v16 + math.max(v17, 0) * p5.wheel.physics.mass
	end
	local v18 = 0.11
	local v19 = 0.15
	local v20 = 0.028 + 0.138 * (p5.wheel.wheelIndex - 1)
	local v21 = 0.837
	local v22 = 0.6739999999999999
	if p5.longitudalFrictionGraph == nil then
		p5.longitudalFrictionGraph = Graph.new(20, v20, 0.837, 0.11, 0.15, 0, 0.0001, true, "", Graph.STYLE_LINES)
		p5.longitudalFrictionGraph:setColor(1, 1, 1, 1)
	else
		local v23 = p5.longitudalFrictionGraph
		local v24 = p5.longitudalFrictionGraph
		local v25 = p5.longitudalFrictionGraph
		local v26 = p5.longitudalFrictionGraph
		v23.left = v20
		v24.bottom = v21
		v25.width = v18
		v26.height = v19
	end
	p5.longitudalFrictionGraph.maxValue = 0.01
	for v27 = 1, 20 do
		local v28, _ = computeWheelShapeTireForces(p5.wheel.node, p5.wheel.physics.wheelShape, (v27 - 1) / 19 * 1, v7, v9)
		p5.longitudalFrictionGraph:setValue(v27, v28)
		local v29 = p5.longitudalFrictionGraph
		local v30 = p5.longitudalFrictionGraph.maxValue
		v29.maxValue = math.max(v30, v28)
	end
	if p5.lateralFrictionGraph == nil then
		p5.lateralFrictionGraph = Graph.new(20, v20, 0.6739999999999999, 0.11, 0.15, 0, 0.0001, true, "", Graph.STYLE_LINES)
		p5.lateralFrictionGraph:setColor(1, 1, 1, 1)
	else
		local v31 = p5.lateralFrictionGraph
		local v32 = p5.lateralFrictionGraph
		local v33 = p5.lateralFrictionGraph
		local v34 = p5.lateralFrictionGraph
		v31.left = v20
		v32.bottom = v22
		v33.width = v18
		v34.height = v19
	end
	p5.lateralFrictionGraph.maxValue = 0.01
	for v35 = 1, 20 do
		local _, v36 = computeWheelShapeTireForces(p5.wheel.node, p5.wheel.physics.wheelShape, v6, (v35 - 1) / 19 * 0.9, v9)
		local v37 = math.abs(v36)
		p5.lateralFrictionGraph:setValue(v35, v37)
		local v38 = p5.lateralFrictionGraph
		local v39 = p5.lateralFrictionGraph.maxValue
		v38.maxValue = math.max(v39, v37)
	end
	if p5.longitudalFrictionSlipOverlay == nil then
		p5.longitudalFrictionSlipOverlay = createImageOverlay("dataS/menu/base/graph_pixel.png")
		setOverlayColor(p5.longitudalFrictionSlipOverlay, 0, 1, 0, 0.2)
	end
	if p5.lateralFrictionSlipOverlay == nil then
		p5.lateralFrictionSlipOverlay = createImageOverlay("dataS/menu/base/graph_pixel.png")
		setOverlayColor(p5.lateralFrictionSlipOverlay, 0, 1, 0, 0.2)
	end
	p5.longitudalFrictionGraph:draw()
	p5.lateralFrictionGraph:draw()
	local v40, v41 = computeWheelShapeTireForces(p5.wheel.node, p5.wheel.physics.wheelShape, v6, v7, v9)
	local v42 = renderOverlay
	local v43 = p5.longitudalFrictionSlipOverlay
	local v44 = math.abs(v6) / 1
	local v45 = v18 * math.min(v44, 1)
	local v46 = math.abs(v40) / p5.longitudalFrictionGraph.maxValue
	v42(v43, v20, 0.837, v45, v19 * math.min(v46, 1))
	local v47 = renderOverlay
	local v48 = p5.lateralFrictionSlipOverlay
	local v49 = math.abs(v7) / 0.9
	local v50 = v18 * math.min(v49, 1)
	local v51 = math.abs(v41) / p5.lateralFrictionGraph.maxValue
	v47(v48, v20, 0.6739999999999999, v50, v19 * math.min(v51, 1))
end
function WheelDebug.getDebugValueHeader()
	return {
		"\n",
		"loSlip\n",
		"laSlip\n",
		"load\n",
		"frict.\n",
		"comp.\n",
		"rpm\n",
		"steer.\n",
		"radius\n",
		"loStiff\n",
		"laStiff\n",
		"mass[t]\n",
		"type\n",
		"deform\n",
		"contact\n"
	}
end
function WheelDebug.fillDebugValues(p52, p53)
	local v54 = p52.wheel.physics
	local v55 = 100 * (v54.netInfo.y - (v54.positionY + v54.deltaY - 1.2 * v54.suspTravel)) / v54.suspTravel - 20
	local v56 = getWheelShapeAxleSpeed(p52.wheel.node, v54.wheelShape) * 30 / 3.141592653589793
	local v57, v58 = getWheelShapeSlip(p52.wheel.node, v54.wheelShape)
	local v59 = getWheelShapeContactForce(p52.wheel.node, v54.wheelShape)
	local v60
	if v59 == nil then
		v60 = 0
	else
		local v61, v62, v63 = getWheelShapeContactNormal(p52.wheel.node, v54.wheelShape)
		local v64, v65, v66 = localDirectionToWorld(p52.wheel.node, v54.directionX, v54.directionY, v54.directionZ)
		local v67 = -v59 * MathUtil.dotProduct(v64, v65, v66, v61, v62, v63)
		local v68 = v62 * 9.81
		v60 = v67 + math.max(v68, 0) * p52.wheel:getMass()
	end
	p53[1] = p53[1] .. string.format("%d:\n", p52.wheel.wheelIndex)
	p53[2] = p53[2] .. string.format("%2.2f\n", v57)
	p53[3] = p53[3] .. string.format("%2.2f\n", v58)
	p53[4] = p53[4] .. string.format("%2.2f\n", v60 / 9.81)
	p53[5] = p53[5] .. string.format("%2.2f\n", v54.frictionScale * v54.tireGroundFrictionCoeff)
	p53[6] = p53[6] .. string.format("%1.0f%%\n", v55)
	p53[7] = p53[7] .. string.format("%3.1f\n", v56)
	local v69 = p53[8]
	local v70 = string.format
	local v71 = v54.steeringAngle
	p53[8] = v69 .. v70("%6.3f\n", (math.deg(v71)))
	p53[9] = p53[9] .. string.format("%.2f\n", v54.radius)
	p53[10] = p53[10] .. string.format("%.2f\n", v54.maxLongStiffness)
	p53[11] = p53[11] .. string.format("%.2f\n", v54.maxLatStiffness)
	p53[12] = p53[12] .. string.format("%.2f\n", v54.mass)
	p53[13] = p53[13] .. string.format("%s\n", WheelsUtil.getTireTypeName(v54.tireType))
	local v72 = nil
	for _, v73 in ipairs(p52.wheel.visualWheels) do
		for _, v74 in ipairs(v73.visualParts) do
			if v74.deformation ~= nil then
				local v75 = v74.deformation
				v72 = math.max(v75, v72 or 0)
			end
		end
	end
	if v72 == nil then
		p53[14] = p53[14] .. "-\n"
	else
		p53[14] = p53[14] .. string.format("%.3f\n", v72)
	end
	p53[15] = p53[15] .. string.format("%s\n", WheelContactType.getName(v54.contact))
end

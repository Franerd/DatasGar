WheelPhysics = {}
WheelPhysics.COLLISION_GROUP = CollisionFlag.VEHICLE
local v1 = WheelPhysics
local v2 = CollisionMask.ALL
local v3 = CollisionFlag.WATER
local v4 = CollisionFlag.AI_BLOCKING
local v5 = CollisionFlag.GROUND_TIP_BLOCKING
local v6 = CollisionFlag.PLACEMENT_BLOCKING
local v7 = CollisionFlag.CAMERA_BLOCKING
local v8 = CollisionFlag.PRECIPITATION_BLOCKING
local v9 = CollisionFlag.ANIMAL_POSITIONING
local v10 = CollisionFlag.ANIMAL_NAV_MESH_BLOCKING
local v11 = CollisionFlag.TRAFFIC_VEHICLE_BLOCKING
v1.COLLISION_MASK = v2 - bit32.bor(v3, v4, v5, v6, v7, v8, v9, v10, v11)
WheelPhysics.X_DRIVE_MAX_REAL_VALUE = 0.08726646259971647
WheelPhysics.X_DRIVE_NUM_BITS = 9
WheelPhysics.X_DRIVE_MAX_VALUE = 2 ^ WheelPhysics.X_DRIVE_NUM_BITS - 1
WheelPhysics.MAX_SINK = {}
WheelPhysics.MAX_SINK[FieldGroundType.STUBBLE_TILLAGE] = 0.07
WheelPhysics.MAX_SINK[FieldGroundType.CULTIVATED] = 0.08
WheelPhysics.MAX_SINK[FieldGroundType.SEEDBED] = 0.07
WheelPhysics.MAX_SINK[FieldGroundType.PLOWED] = 0.12
WheelPhysics.MAX_SINK[FieldGroundType.ROLLED_SEEDBED] = 0.05
WheelPhysics.MAX_SINK[FieldGroundType.RIDGE] = 0.1
WheelPhysics.MAX_SINK[FieldGroundType.SOWN] = 0.05
WheelPhysics.MAX_SINK[FieldGroundType.DIRECT_SOWN] = 0.05
WheelPhysics.MAX_SINK[FieldGroundType.PLANTED] = 0.05
WheelPhysics.MAX_SINK[FieldGroundType.RIDGE_SOWN] = 0.1
WheelPhysics.MAX_SINK[FieldGroundType.ROLLER_LINES] = 0.05
WheelPhysics.MAX_SINK[FieldGroundType.HARVEST_READY] = 0.05
WheelPhysics.MAX_SINK[FieldGroundType.HARVEST_READY_OTHER] = 0.05
WheelPhysics.MAX_SINK[FieldGroundType.GRASS] = 0.05
WheelPhysics.MAX_SINK[FieldGroundType.GRASS_CUT] = 0.05
WheelPhysics.WATER_SINK = 0.15
function WheelPhysics.new(p12)
	local v13 = {
		["__index"] = WheelPhysics
	}
	local v14 = setmetatable({}, v13)
	v14.wheel = p12
	v14.vehicle = p12.vehicle
	v14.wheelShape = 0
	v14.wheelShapeCreationFrameIndex = (1 / 0)
	v14.wheelShapeCreated = false
	v14.torque = 0
	v14.dirtAmount = 0
	v14.trackAlpha = 0
	v14.groundColor = { 0, 0, 0 }
	v14.fieldGroundColor = { 0, 0, 0 }
	v14.trackColor = { 0, 0, 0 }
	v14.groundDepth = 0
	v14.colorBlendWithTerrain = 1
	v14.lastTerrainAttribute = 0
	v14.xDriveOffset = 0
	v14.contact = WheelContactType.NONE
	v14.hasWaterContact = false
	v14.hasSnowContact = false
	v14.snowScale = 0
	v14.lastSnowScale = 0
	v14.steeringAngle = 0
	v14.hasGroundContact = false
	v14.lastContactObjectAllowsTireTracks = true
	v14.densityBits = 0
	v14.densityType = FieldGroundType.NONE
	v14.sink = 0
	v14.sinkTarget = 0
	v14.hasSoilContact = false
	v14.tireGroundFrictionCoeff = 1
	return v14
end
function WheelPhysics.loadFromXML(p15, p16)
	p15.radius = p16:getValue(".physics#radius")
	if p15.radius == nil then
		p16:xmlWarning(".physics#radius", "No radius defined for wheel! Using default value of 0.5!")
		p15.radius = 0.5
	end
	p15.radiusOriginal = p15.radius
	p15.width = p16:getValue(".physics#width")
	if p15.width == nil then
		p16:xmlWarning(".physics#width", "No width defined for wheel! Using default value of 0.5!")
		p15.width = 0.5
	end
	p15.wheelShapeWidth = p15.width
	p15.wheelShapeWidthOffset = 0
	p15.mass = p16:getValue(".physics#mass", 0.1)
	p15.baseMass = p15.mass
	p15.restLoad = p16:getValue(".physics#restLoad", 1)
	p15.frictionScale = p16:getValue(".physics#frictionScale", 1)
	if p15.frictionScale <= 0 then
		p15.frictionScale = 0.01
		p16:xmlWarning(".physics#frictionScale", "Wheel \'frictionScale\' set to \'0\'. This is not allowed!")
	end
	p15.maxLongStiffness = p16:getValue(".physics#maxLongStiffness", 30)
	p15.maxLatStiffness = p16:getValue(".physics#maxLatStiffness", 40)
	p15.maxLatStiffnessLoad = p16:getValue(".physics#maxLatStiffnessLoad", 2)
	p15.xOffset = p16:getValue(".physics#xOffset", 0)
	p15.yOffset = p16:getValue(".physics#yOffset", 0)
	p15.zOffset = p16:getValue(".physics#zOffset", 0)
	p15.useReprOffset = p16:getValue(".physics#useReprOffset", false)
	if p15.xOffset ~= 0 or (p15.yOffset ~= 0 or p15.zOffset ~= 0) then
		if p15.useReprOffset then
			setTranslation(p15.wheel.repr, localToLocal(p15.wheel.repr, getParent(p15.wheel.repr), p15.wheel.isLeft and p15.xOffset or -p15.xOffset, p15.yOffset, p15.zOffset))
		else
			setTranslation(p15.wheel.driveNode, localToLocal(p15.wheel.driveNode, getParent(p15.wheel.driveNode), p15.wheel.isLeft and p15.xOffset or -p15.xOffset, p15.yOffset, p15.zOffset))
		end
	end
	p15.showSteeringAngle = p16:getValue(".physics#showSteeringAngle")
	p15.suspTravel = p16:getValue(".physics#suspTravel", 0.01)
	local v17 = p16:getValue(".physics#initialCompression")
	if v17 == nil then
		p15.deltaY = p16:getValue(".physics#deltaY", 0)
	else
		p15.deltaY = (1 - v17 * 0.01) * p15.suspTravel
	end
	p15.deltaYOriginal = p15.deltaY
	p15.spring = p16:getValue(".physics#spring", 0) * Vehicle.SPRING_SCALE
	p15.brakeFactor = p16:getValue(".physics#brakeFactor", 1)
	p15.autoHoldBrakeFactor = p16:getValue(".physics#autoHoldBrakeFactor", p15.brakeFactor)
	p15.damperCompressionLowSpeed = p16:getValue(".physics#damperCompressionLowSpeed")
	p15.damperRelaxationLowSpeed = p16:getValue(".physics#damperRelaxationLowSpeed")
	if p15.damperRelaxationLowSpeed == nil then
		p15.damperRelaxationLowSpeed = p16:getValue(".physics#damper", p15.damperCompressionLowSpeed or 0)
	end
	p15.damperRelaxationHighSpeed = p16:getValue(".physics#damperRelaxationHighSpeed", p15.damperRelaxationLowSpeed * 0.7)
	if p15.damperCompressionLowSpeed == nil then
		p15.damperCompressionLowSpeed = p15.damperRelaxationLowSpeed * 0.9
	end
	p15.damperCompressionHighSpeed = p16:getValue(".physics#damperCompressionHighSpeed", p15.damperCompressionLowSpeed * 0.2)
	p15.damperCompressionLowSpeedThreshold = p16:getValue(".physics#damperCompressionLowSpeedThreshold", 0.1016)
	p15.damperRelaxationLowSpeedThreshold = p16:getValue(".physics#damperRelaxationLowSpeedThreshold", 0.1524)
	p15.forcePointRatio = p16:getValue(".physics#forcePointRatio", 0)
	if p15.forcePointRatio < 0 or p15.forcePointRatio > 1 then
		p16:xmlWarning(".physics#forcePointRatio", "Invalid value for \'forcePointRatio\'. Must be between 0 and 1. Defaulting to 0!")
		p15.forcePointRatio = 0
	end
	p15.driveMode = p16:getValue(".physics#driveMode", 0)
	p15.isSynchronized = p16:getValue(".physics#isSynchronized", true)
	p15.tipOcclusionAreaGroupId = p16:getValue(".physics#tipOcclusionAreaGroupId")
	p15.useReprDirection = p16:getValue(".physics#useReprDirection", false)
	p15.useDriveNodeDirection = p16:getValue(".physics#useDriveNodeDirection", false)
	p15.rotationDamping = p16:getValue(".physics#rotationDamping", p15.mass * 0.035)
	local v18 = p16:getValue(".physics#tireType", "mud")
	p15.tireType = WheelsUtil.getTireType(v18)
	if p15.tireType == nil then
		p16:xmlWarning(".physics#tireType", "Failed to find tire type \'%s\'. Defaulting to \'mud\'!", v18)
		p15.tireType = WheelsUtil.getTireType("mud")
	end
	p15.fieldDirtMultiplier = p16:getValue(".physics#fieldDirtMultiplier", 75)
	p15.streetDirtMultiplier = p16:getValue(".physics#streetDirtMultiplier", -150)
	p15.waterWetnessFactor = p16:getValue(".physics#waterWetnessFactor", 20)
	p15.minDirtPercentage = p16:getValue(".physics#minDirtPercentage", 0.35)
	p15.maxDirtOffset = p16:getValue(".physics#maxDirtOffset", 0.5)
	p15.dirtColorChangeSpeed = 1 / (p16:getValue(".physics#dirtColorChangeSpeed", 20) * 1000)
	p15.versatileYRot = p16:getValue(".physics#versatileYRot", false)
	p15.forceVersatility = p16:getValue(".physics#forceVersatility", false)
	local v19 = p16:getValue(".physics#supportsWheelSink", true)
	if v19 then
		v19 = p15.vehicle.isServer
	end
	p15.supportsWheelSink = v19
	if not (Platform.gameplay.wheelTerrainDisplacement and p15.supportsWheelSink) then
		local v20 = WheelPhysics.COLLISION_MASK
		local v21 = CollisionFlag.TERRAIN_DISPLACEMENT
		local v22 = bit32.bnot(v21)
		p15.collisionMask = bit32.band(v20, v22)
	end
	p15.extraSinkSupported = p16:getValue(".physics.extraSink#supported", false)
	p15.extraSinkMaxValue = p16:getValue(".physics.extraSink#maxValue", p15.radius * 0.2)
	p15.rotSpeed = p16:getValue(".physics#rotSpeed", 0)
	p15.rotSpeedNeg = p16:getValue(".physics#rotSpeedNeg", 0)
	p15.rotMax = p16:getValue(".physics#rotMax", 0)
	p15.rotMin = p16:getValue(".physics#rotMin", 0)
	p15.invertRotLimit = p16:getValue(".physics#invertRotLimit", false)
	p15.rotSpeedLimit = p16:getValue(".physics#rotSpeedLimit")
	local v23 = p16:getValue(".physics#maxInnerSpacing")
	if v23 ~= nil then
		local v24 = p15.width * 0.5 - v23
		if v24 > 0 then
			local v25, v26, v27 = localToLocal(p15.wheel.driveNode, getParent(p15.wheel.driveNode), p15.wheel.isLeft and v24 and v24 or -v24, 0, 0)
			setTranslation(p15.wheel.driveNode, v25, v26, v27)
		end
	end
	local v28, v29, v30 = localToLocal(p15.wheel.driveNode, p15.wheel.node, 0, 0, 0)
	p15.positionX = v28
	p15.positionY = v29
	p15.positionZ = v30
	if p15.useReprDirection then
		local v31, v32, v33 = localDirectionToLocal(p15.wheel.repr, p15.wheel.node, 0, -1, 0)
		p15.directionX = v31
		p15.directionY = v32
		p15.directionZ = v33
		local v34, v35, v36 = localDirectionToLocal(p15.wheel.repr, p15.wheel.node, 1, 0, 0)
		p15.axleX = v34
		p15.axleY = v35
		p15.axleZ = v36
	elseif p15.useDriveNodeDirection then
		local v37, v38, v39 = localDirectionToLocal(p15.wheel.driveNodeDirectionNode, p15.wheel.node, 0, -1, 0)
		p15.directionX = v37
		p15.directionY = v38
		p15.directionZ = v39
		local v40, v41, v42 = localDirectionToLocal(p15.wheel.driveNodeDirectionNode, p15.wheel.node, 1, 0, 0)
		p15.axleX = v40
		p15.axleY = v41
		p15.axleZ = v42
	else
		p15.directionX = 0
		p15.directionY = -1
		p15.directionZ = 0
		p15.axleX = 1
		p15.axleY = 0
		p15.axleZ = 0
	end
	p15.steeringCenterOffsetX = 0
	p15.steeringCenterOffsetY = 0
	p15.steeringCenterOffsetZ = 0
	if p15.wheel.repr ~= p15.wheel.driveNode then
		local v43, v44, v45 = localToLocal(p15.wheel.driveNode, p15.wheel.repr, 0, 0, 0)
		p15.steeringCenterOffsetX = v43
		p15.steeringCenterOffsetY = v44
		p15.steeringCenterOffsetZ = v45
		p15.steeringCenterOffsetX = -p15.steeringCenterOffsetX
		p15.steeringCenterOffsetY = -p15.steeringCenterOffsetY
		p15.steeringCenterOffsetZ = -p15.steeringCenterOffsetZ
	end
	return true
end
function WheelPhysics.loadAdditionalWheel(p46, p47)
	p46.mass = p46.mass + p47:getValue(".physics#mass", 0)
	p46.maxLatStiffness = p46.maxLatStiffness + p47:getValue(".physics#maxLatStiffness", 0)
	p46.maxLongStiffness = p46.maxLongStiffness + p47:getValue(".physics#maxLongStiffness", 0)
end
function WheelPhysics.finalize(p48)
	local v49 = p48.positionY + p48.deltaY
	p48.netInfo = {}
	p48.netInfo.xDrive = 0
	p48.netInfo.xDriveDiff = 0
	p48.netInfo.xDriveSpeed = 0
	p48.netInfo.x = p48.positionX
	p48.netInfo.y = v49
	p48.netInfo.z = p48.positionZ
	p48.netInfo.suspensionLength = p48.deltaY
	p48.netInfo.lastSpeedSmoothed = 0
	p48.netInfo.slip = 0
	p48.netInfo.sync = {
		["yMin"] = -5,
		["yRange"] = 10
	}
	p48.netInfo.yMin = v49 - 1.2 * p48.suspTravel
	local v50 = p48.vehicle.vehicleNodes[p48.wheel.node]
	if v50 ~= nil and (v50.component ~= nil and v50.component.motorized == nil) then
		v50.component.motorized = true
	end
	local v51 = p48.wheel:getMass() - p48.baseMass
	p48.restLoad = p48.restLoad + v51
	p48.maxLatStiffness = p48.maxLatStiffness * p48.restLoad
	p48.maxLatStiffnessLoad = p48.maxLatStiffnessLoad * p48.restLoad
	p48.networkInterpolators = {}
	p48.networkInterpolators.xDriveDiff = InterpolatorValue.new(0)
	p48.networkInterpolators.position = InterpolatorPosition.new(p48.netInfo.x, p48.netInfo.y, p48.netInfo.z)
	p48.networkInterpolators.suspensionLength = InterpolatorValue.new(p48.netInfo.suspensionLength)
end
function WheelPhysics.readStream(p52, p53, p54)
	local v55 = streamReadBool(p53) and 1 or -1
	local v56 = (1 - (1 - streamReadUIntN(p53, WheelPhysics.X_DRIVE_NUM_BITS) / WheelPhysics.X_DRIVE_MAX_VALUE) ^ 0.25) * WheelPhysics.X_DRIVE_MAX_REAL_VALUE * v55
	if p54 then
		p52.networkInterpolators.xDriveDiff:setValue(v56)
	else
		p52.networkInterpolators.xDriveDiff:setTargetValue(v56)
	end
	local v57 = streamReadUIntN(p53, 8) / 255 * p52.netInfo.sync.yRange + p52.netInfo.sync.yMin
	if p54 then
		p52.netInfo.y = v57
		p52.networkInterpolators.position:setPosition(p52.netInfo.x, v57, p52.netInfo.z)
	else
		p52.networkInterpolators.position:setTargetPosition(p52.netInfo.x, v57, p52.netInfo.z)
	end
	local v58 = streamReadUIntN(p53, 7)
	if p54 then
		p52.netInfo.suspensionLength = v58 / 100
		p52.networkInterpolators.suspensionLength:setValue(v58 / 100)
	else
		p52.networkInterpolators.suspensionLength:setTargetValue(v58 / 100)
	end
	if p52.wheel.syncContactState then
		p52.contact = streamReadUIntN(p53, 2) + 1
		p52.lastContactObjectAllowsTireTracks = streamReadBool(p53)
	end
	if p52.versatileYRot then
		p52.steeringAngle = streamReadUIntN(p53, 9) / 511 * 3.141592653589793 * 2
	end
	p52.hasSoilContact = streamReadBool(p53)
end
function WheelPhysics.writeStream(p59, p60)
	local v61 = p59.netInfo.xDriveDiff
	local v62 = math.abs(v61) / WheelPhysics.X_DRIVE_MAX_REAL_VALUE
	local v63 = math.clamp(v62, 0, 1)
	streamWriteBool(p60, p59.netInfo.xDriveDiff >= 0)
	local v64 = 1 - (1 - v63) ^ 4
	streamWriteUIntN(p60, v64 * WheelPhysics.X_DRIVE_MAX_VALUE, WheelPhysics.X_DRIVE_NUM_BITS)
	local v65 = streamWriteUIntN
	local v66 = (p59.netInfo.y - p59.netInfo.sync.yMin) / p59.netInfo.sync.yRange * 255
	local v67 = math.floor(v66)
	v65(p60, math.clamp(v67, 0, 255), 8)
	local v68 = streamWriteUIntN
	local v69 = p59.netInfo.suspensionLength * 100
	v68(p60, math.clamp(v69, 0, 128), 7)
	if p59.wheel.syncContactState then
		streamWriteUIntN(p60, p59.contact - 1, 2)
		streamWriteBool(p60, p59.lastContactObjectAllowsTireTracks)
	end
	if p59.versatileYRot then
		local v70 = p59.steeringAngle % 6.283185307179586
		local v71 = streamWriteUIntN
		local v72 = v70 / 6.283185307179586 * 511
		local v73 = math.floor(v72)
		v71(p60, math.clamp(v73, 0, 511), 9)
	end
	streamWriteBool(p60, p59.hasSoilContact)
end
function WheelPhysics.updateContact(p74)
	local v75 = p74.netInfo.x
	local v76 = p74.netInfo.y
	local v77 = p74.netInfo.z
	local v78, v79, v80 = localToWorld(p74.wheel.node, v75, v76, v77)
	raycastClosestAsync(v78, v79, v80, 0, -1, 0, p74.radius + 0.25, "waterRaycastCallback", p74, CollisionFlag.WATER)
	local v81, v82, v83 = localToWorld(p74.wheel.node, v75, v76 - p74.radius, v77)
	local v84 = g_currentMission
	if g_updateLoopIndex - p74.wheelShapeCreationFrameIndex > 2 then
		p74.wheelShapeCreated = true
		local v85, v86, v87, _ = getWheelShapeContactPoint(p74.wheel.node, p74.wheelShape)
		p74.hasGroundContact = v85 ~= nil
		if p74.hasGroundContact then
			p74.lastContactX = v85
			p74.lastContactY = v86
			p74.lastContactZ = v87
		end
		local v88, _ = getWheelShapeContactObject(p74.wheel.node, p74.wheelShape)
		if v88 == 0 then
			p74.contact = WheelContactType.NONE
			p74.lastContactObjectAllowsTireTracks = false
		elseif getDensityMapHeightTypeAtWorldPos(g_densityMapHeightManager.terrainDetailHeightUpdater, v81, v82, v83, 0) == 0 then
			if v88 == g_terrainNode then
				p74.contact = WheelContactType.GROUND
				p74.lastContactObjectAllowsTireTracks = true
			elseif p74.hasGroundContact then
				p74.contact = WheelContactType.OBJECT
				local v89
				if getRigidBodyType(v88) == RigidBodyType.STATIC then
					v89 = getUserAttribute(v88, "noTireTracks") ~= true
				else
					v89 = false
				end
				p74.lastContactObjectAllowsTireTracks = v89
			else
				p74.contact = WheelContactType.NONE
				p74.lastContactObjectAllowsTireTracks = false
			end
		else
			p74.contact = WheelContactType.GROUND_HEIGHT
			p74.lastContactObjectAllowsTireTracks = true
		end
	end
	if p74.contact == WheelContactType.GROUND then
		local v90, v91, v92 = v84.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
		p74.densityBits = getDensityAtWorldPos(v90, v81, v82, v83)
		local v93 = bitAND(bitShiftRight(p74.densityBits, v91), 2 ^ v92 - 1)
		p74.densityType = FieldGroundType.getTypeByValue(v93)
	else
		p74.densityBits = 0
		p74.densityType = FieldGroundType.NONE
	end
	if p74.contact == WheelContactType.GROUND_HEIGHT then
		local v94 = getDensityAtWorldPos(v84.terrainDetailHeightId, v81, v82, v83)
		local v95 = g_densityMapHeightManager.heightTypeNumChannels
		p74.hasSnowContact = bitAND(v94, 2 ^ v95 - 1) == v84.snowSystem.snowHeightTypeIndex
	else
		p74.hasSnowContact = false
	end
end
function WheelPhysics.updateSink(p96, p97, _)
	if p96.wheelShape ~= 0 then
		local v98 = p96.sinkTarget
		local v99 = p96.vehicle:getLastSpeed()
		local v100 = 1
		if p96.contact == WheelContactType.NONE or v99 <= 0.3 then
			if p96.contact == WheelContactType.NONE then
				v98 = 0
				v99 = 10
				v100 = 0.075
			end
		else
			local v101 = WheelPhysics.MAX_SINK[p96.densityType] or 0
			if p96.hasWaterContact and v101 ~= 0 then
				local v102 = WheelPhysics.WATER_SINK
				v101 = math.max(v101, v102)
			end
			local v103 = p96.extraSinkMaxValue
			v98 = math.min(v101, v103)
		end
		if p96.sinkTarget < v98 then
			local v104 = p96.sinkTarget
			local v105 = v99 - 0.2
			local v106 = math.max(0, v105)
			local v107 = v104 + 0.05 * math.min(30, v106) * (p97 / 1000) * v100
			p96.sinkTarget = math.min(v98, v107)
		elseif v98 < p96.sinkTarget then
			local v108 = p96.sinkTarget
			local v109 = v99 - 0.2
			local v110 = math.max(0, v109)
			local v111 = v108 - 0.05 * math.min(30, v110) * (p97 / 1000) * v100
			p96.sinkTarget = math.max(v98, v111)
		end
		local v112 = p96.sink - p96.sinkTarget
		if math.abs(v112) > 0.001 then
			p96.sink = p96.sinkTarget
			local v113 = p96.deltaYOriginal + p96.sink
			if v113 ~= p96.deltaY then
				p96.deltaY = v113
				p96.isPositionDirty = true
			end
		end
	end
end
function WheelPhysics.updateFriction(p114, _, p115)
	local v116 = p114.densityType ~= FieldGroundType.NONE
	local v117
	if p114.hasSnowContact then
		p115 = 0
		v117 = 1
	else
		v117 = 0
	end
	local v118 = WheelsUtil.getGroundType(v116, p114.contact ~= WheelContactType.GROUND, p114.groundDepth)
	local v119 = WheelsUtil.getTireFriction(p114.tireType, v118, p115, v117)
	if p114.vehicle:getLastSpeed() > 0.2 and v119 ~= p114.tireGroundFrictionCoeff then
		p114.tireGroundFrictionCoeff = v119
		p114.isFrictionDirty = true
	end
end
function WheelPhysics.updateBase(p120)
	if p120.vehicle.isServer and p120.vehicle.isAddedToPhysics then
		local v121 = p120.positionX - p120.directionX * p120.deltaY
		local v122 = p120.positionY - p120.directionY * p120.deltaY
		local v123 = p120.positionZ - p120.directionZ * p120.deltaY
		if p120.wheelShape == 0 then
			p120.wheelShapeCreationFrameIndex = g_updateLoopIndex
			p120.wheelShapeCreated = false
		end
		local v124 = WheelPhysics.COLLISION_GROUP
		local v125 = p120.collisionMask or WheelPhysics.COLLISION_MASK
		p120.wheelShape = createWheelShape(p120.wheel.node, v121, v122, v123, p120.radius, p120.suspTravel, p120.spring, p120.damperCompressionLowSpeed, p120.damperCompressionHighSpeed, p120.damperCompressionLowSpeedThreshold, p120.damperRelaxationLowSpeed, p120.damperRelaxationHighSpeed, p120.damperRelaxationLowSpeedThreshold, p120.wheel:getMass(), v124, v125, p120.wheelShape)
		local v126 = v122 - p120.radius * p120.forcePointRatio
		local v127, v128, v129 = localToLocal(getParent(p120.wheel.repr), p120.wheel.node, p120.wheel.startPositionX, p120.wheel.startPositionY + p120.deltaY, p120.wheel.startPositionZ)
		setWheelShapeForcePoint(p120.wheel.node, p120.wheelShape, p120.positionX, v126, v123)
		setWheelShapeSteeringCenter(p120.wheel.node, p120.wheelShape, v127, v128, v129)
		setWheelShapeDirection(p120.wheel.node, p120.wheelShape, p120.directionX, p120.directionY, p120.directionZ, p120.axleX, p120.axleY, p120.axleZ)
		setWheelShapeWidth(p120.wheel.node, p120.wheelShape, p120.wheelShapeWidth, p120.wheelShapeWidthOffset)
		p120.isPositionDirty = false
	end
end
function WheelPhysics.updateShapePosition(p130)
	local v131, v132, v133 = localToLocal(getParent(p130.wheel.repr), p130.wheel.node, p130.wheel.startPositionX - p130.steeringCenterOffsetX, p130.wheel.startPositionY - p130.steeringCenterOffsetY, p130.wheel.startPositionZ - p130.steeringCenterOffsetZ)
	p130.positionX = v131
	p130.positionY = v132
	p130.positionZ = v133
	if p130.useReprDirection then
		local v134, v135, v136 = localDirectionToLocal(p130.wheel.repr, p130.wheel.node, 0, -1, 0)
		p130.directionX = v134
		p130.directionY = v135
		p130.directionZ = v136
		local v137, v138, v139 = localDirectionToLocal(p130.wheel.repr, p130.wheel.node, 1, 0, 0)
		p130.axleX = v137
		p130.axleY = v138
		p130.axleZ = v139
	elseif p130.useDriveNodeDirection then
		local v140, v141, v142 = localDirectionToLocal(p130.wheel.driveNodeDirectionNode, p130.wheel.node, 0, -1, 0)
		p130.directionX = v140
		p130.directionY = v141
		p130.directionZ = v142
		local v143, v144, v145 = localDirectionToLocal(p130.wheel.driveNodeDirectionNode, p130.wheel.node, 1, 0, 0)
		p130.axleX = v143
		p130.axleY = v144
		p130.axleZ = v145
	end
	p130.isPositionDirty = true
end
function WheelPhysics.updateTireFriction(p146)
	if p146.vehicle.isServer and p146.vehicle.isAddedToPhysics then
		setWheelShapeTireFriction(p146.wheel.node, p146.wheelShape, p146.maxLongStiffness, p146.maxLatStiffness, p146.maxLatStiffnessLoad, p146.frictionScale * p146.tireGroundFrictionCoeff)
		p146.isFrictionDirty = false
	end
end
function WheelPhysics.updatePhysics(p147, p148, p149)
	if p147.vehicle.isServer and p147.vehicle.isAddedToPhysics then
		setWheelShapeProps(p147.wheel.node, p147.wheelShape, p149 or p147.torque, (p148 or 0) * p147.brakeFactor, p147.steeringAngle, p147.rotationDamping)
		setWheelShapeAutoHoldBrakeForce(p147.wheel.node, p147.wheelShape, (p148 or 0) * p147.autoHoldBrakeFactor)
	end
end
function WheelPhysics.updateNetInfo(p150, p151)
	if p150.updateWheel then
		local v152, v153, v154, v155, v156 = getWheelShapePosition(p150.wheel.node, p150.wheelShape)
		local v157 = v155 + p150.xDriveOffset
		if p150.dirtyFlag ~= nil and (p150.netInfo.x ~= v152 or p150.netInfo.z ~= v154) then
			p150.vehicle:raiseDirtyFlags(p150.dirtyFlag)
		end
		p150.netInfo.x = v152
		p150.netInfo.y = v153
		p150.netInfo.z = v154
		p150.netInfo.xDrive = v157
		p150.netInfo.xDriveDiff = 0
		p150.netInfo.suspensionLength = v156
		p150:updateXDriveSpeed(p151)
	else
		p150.updateWheel = true
	end
end
function WheelPhysics.updateSteeringAngle(p158, p159)
	local v160 = p158.steeringAngle
	local v161 = p158.vehicle.rotatedTime
	if p158.wheel.steering.steeringAxleScale == nil or p158.wheel.steering.steeringAxleScale == 0 then
		if p158.versatileYRot and p158.vehicle:getIsVersatileYRotActive(p158.wheel) then
			if p158.vehicle.isServer and (p158.forceVersatility or p158.hasGroundContact) then
				v160 = Utils.getVersatileRotation(p158.wheel.repr, p158.wheel.node, p159, p158.positionX, p158.positionY, p158.positionZ, p158.steeringAngle, p158.rotMin, p158.rotMax)
			end
		elseif p158.rotSpeed ~= 0 and (p158.rotMax ~= nil and p158.rotMin ~= nil) or p158.wheel.forceSteeringAngleUpdate then
			if v161 > 0 or p158.rotSpeedNeg == nil then
				v160 = v161 * p158.rotSpeed
			else
				v160 = v161 * p158.rotSpeedNeg
			end
			if p158.rotMax < v160 then
				v160 = p158.rotMax
			elseif v160 < p158.rotMin then
				v160 = p158.rotMin
			end
			if p158.vehicle.customSteeringAngleFunction then
				v160 = p158.vehicle:updateSteeringAngle(p158.wheel, p159, v160)
			end
		end
	else
		local v162 = (p158.vehicle.spec_attachable == nil and 0 or p158.vehicle.spec_attachable.steeringAxleAngle) * p158.wheel.steering.steeringAxleScale
		local v163 = p158.wheel.steering.steeringAxleRotMin
		local v164 = p158.wheel.steering.steeringAxleRotMax
		v160 = math.clamp(v162, v163, v164)
	end
	p158.steeringAngle = v160
end
function WheelPhysics.addToPhysics(p165, p166)
	p165.xDriveOffset = p165.netInfo.xDrive
	p165.updateWheel = false
	p165:updateBase()
	p165:updateTireFriction()
	p165:updatePhysics(p166, 0)
end
function WheelPhysics.removeFromPhysics(p167)
	p167.wheelShape = 0
	p167.wheelShapeCreationFrameIndex = (1 / 0)
	p167.wheelShapeCreated = false
end
function WheelPhysics.setSteeringValues(p168, p169, p170, p171, p172, p173)
	p168.rotMin = p169
	p168.rotMax = p170
	if p168.invertRotLimit then
		p173 = not p173
	end
	local v174
	if p173 then
		v174 = -p172
		p172 = -p171
	else
		v174 = p171
	end
	p168.rotSpeed = v174
	p168.rotSpeedNeg = p172
end
function WheelPhysics.setWheelShapeWidth(p175, p176, p177)
	local v178 = p176 or p175.wheelShapeWidth
	local v179 = p177 or p175.wheelShapeWidthOffset
	p175.wheelShapeWidth = v178
	p175.wheelShapeWidthOffset = v179
	p175.isPositionDirty = true
end
function WheelPhysics.getVisualInfo(p180)
	local v181 = p180.showSteeringAngle == false and 0 or p180.steeringAngle
	return p180.netInfo.x, p180.netInfo.y, p180.netInfo.z, p180.netInfo.xDrive, p180.netInfo.suspensionLength - p180.deltaYOriginal, v181
end
function WheelPhysics.serverUpdate(p182, p183, p184, p185)
	if p182.vehicle.isActive then
		if p184 == p182.wheel.updateIndex then
			p182:updateContact()
		end
		if p182.extraSinkSupported then
			p182:updateSink(p183, p185)
		end
		if p182.vehicle.isServer then
			p182:updateFriction(p183, p185)
		end
		p182:updatePhysics(p182.wheel.brakePedal <= 0 and 0 or p182.vehicle:getBrakeForce() * p182.wheel.brakePedal)
		p182:updateSteeringAngle(p183)
	end
	p182:updateNetInfo(p183)
end
function WheelPhysics.updateTick(p186, p187, p188)
	if p186.rotSpeedLimit ~= nil then
		local v189 = p186:getLastSpeed() <= p186.rotSpeedLimit and 1 or -1
		local v190 = p186.currentRotSpeedAlpha + v189 * (p187 / 1000)
		p186.currentRotSpeedAlpha = math.clamp(v190, 0, 1)
		p186.rotSpeed = p186.rotSpeedDefault * p186.currentRotSpeedAlpha
		p186.rotSpeedNeg = p186.rotSpeedNegDefault * p186.currentRotSpeedAlpha
	end
	p186.hasSoilContact = false
	local v191, v192, v193 = getWorldTranslation(p186.wheel.driveNode)
	local v194 = 0
	local v195 = 0
	if p186.contact == WheelContactType.GROUND then
		local v196 = 1
		local v197, v198
		if p186.densityType ~= FieldGroundType.NONE then
			local v199, v200, v201
			v199, v200, v201, v197 = g_currentMission.fieldGroundSystem:getFieldGroundTyreTrackColor(p186.densityBits)
			v198 = 1
			v194 = 1
			if p186.densityType == FieldGroundType.GRASS then
				v194 = 0.7
			elseif p186.densityType == FieldGroundType.GRASS_CUT then
				v194 = 0.6
			else
				p186.hasSoilContact = true
			end
			p186.fieldGroundColor[1] = v199
			p186.fieldGroundColor[2] = v200
			p186.fieldGroundColor[3] = v201
			v196 = 0.75
		else
			local v202, v203, v204
			v202, v203, v204, v197, v198 = getTerrainAttributesAtWorldPos(g_terrainNode, v191, v192, v193, true, true, true, true, false)
			p186.groundColor[1] = v202
			p186.groundColor[2] = v203
			p186.groundColor[3] = v204
			if v197 > 0 then
				v195 = 0.5
			end
		end
		p186.groundDepth = v197
		p186.colorBlendWithTerrain = v196
		p186.lastTerrainAttribute = v198
	elseif p186.contact == WheelContactType.GROUND_HEIGHT then
		p186.groundDepth = 1
		p186.colorBlendWithTerrain = 0
		v195 = 1
	elseif p186.contact == WheelContactType.OBJECT then
		p186.groundDepth = 0
	end
	if v194 ~= p186.dirtAmount then
		if v194 < p186.dirtAmount then
			local v205 = 30 * (1 + p188)
			local v206 = p186.vehicle:getLastSpeed()
			local v207 = v205 * (2 - math.min(v206, 20) / 20)
			local v208 = p186.dirtAmount - p186.vehicle.lastMovedDistance / v207
			p186.dirtAmount = math.max(v208, v194)
		else
			local v209 = p186.dirtAmount + p186.vehicle.lastMovedDistance
			p186.dirtAmount = math.min(v209, v194)
		end
	end
	if v195 ~= p186.trackAlpha then
		if p186.trackAlpha < v195 then
			local v210 = p186.trackAlpha + p186.vehicle.lastMovedDistance * 2
			p186.trackAlpha = math.min(v210, v195)
		else
			local v211 = p186.trackAlpha - p186.vehicle.lastMovedDistance * 2
			p186.trackAlpha = math.max(v211, v195)
		end
	end
	if p186.groundDepth > 0 then
		for v212 = 1, 3 do
			p186.trackColor[v212] = p186.fieldGroundColor[v212] * p186.dirtAmount + p186.groundColor[v212] * (1 - p186.dirtAmount)
		end
	else
		p186.trackColor[1] = p186.fieldGroundColor[1]
		p186.trackColor[2] = p186.fieldGroundColor[2]
		p186.trackColor[3] = p186.fieldGroundColor[3]
	end
end
function WheelPhysics.postUpdate(p213, _)
	if p213.isPositionDirty then
		p213:updateBase()
	end
	if p213.isFrictionDirty then
		p213:updateTireFriction()
	end
end
function WheelPhysics.clientUpdate(p214, p215, p216)
	local v217 = p214.netInfo
	local v218 = p214.netInfo
	local v219 = p214.netInfo
	local v220, v221, v222 = p214.networkInterpolators.position:getInterpolatedValues(p216)
	v217.x = v220
	v218.y = v221
	v219.z = v222
	p214.netInfo.suspensionLength = p214.networkInterpolators.suspensionLength:getInterpolatedValue(p216)
	local v223 = p214.networkInterpolators.xDriveDiff:getInterpolatedValue(p216)
	p214.netInfo.xDrive = (p214.netInfo.xDrive + v223 * p215) % 6.283185307179586
	p214:updateXDriveSpeed(p215)
	p214:updateSteeringAngle(p215)
end
function WheelPhysics.updateXDriveSpeed(p224, p225)
	local v226 = p224.netInfo.xDrive
	if p224.netInfo.xDriveBefore == nil then
		p224.netInfo.xDriveBefore = v226
	end
	local v227 = v226 - p224.netInfo.xDriveBefore
	if v227 > 3.141592653589793 then
		p224.netInfo.xDriveBefore = p224.netInfo.xDriveBefore + 6.283185307179586
	elseif v227 < -3.141592653589793 then
		p224.netInfo.xDriveBefore = p224.netInfo.xDriveBefore - 6.283185307179586
	end
	p224.netInfo.xDriveDiff = (v226 - p224.netInfo.xDriveBefore) / p225
	p224.netInfo.xDriveSpeed = p224.netInfo.xDriveDiff * 1000
	p224.netInfo.xDriveBefore = v226
	local v228 = MathUtil.rpmToMps(p224.netInfo.xDriveSpeed / 6.283185 * 60, p224.radius)
	p224.netInfo.lastSpeedSmoothed = p224.netInfo.lastSpeedSmoothed * 0.9 + v228 * 0.1
	local v229 = p224.netInfo
	local v230 = p224.netInfo.lastSpeedSmoothed
	local v231 = p224.vehicle.lastSpeedSmoothed
	local v232 = v230 / math.max(v231, 1e-8)
	v229.slip = math.clamp(v232, 1, 2) - 1
end
function WheelPhysics.getGroundAttributes(p233)
	local v234 = p233.trackColor[1]
	local v235 = p233.trackColor[2]
	local v236 = p233.trackColor[3]
	local v237 = p233.groundDepth
	local v238 = p233.lastTerrainAttribute
	local v239 = p233.trackAlpha
	local v240 = p233.dirtAmount
	return v234, v235, v236, v237, v238, math.max(v239, v240), p233.colorBlendWithTerrain
end
function WheelPhysics.getIsOnField(p241)
	local v242 = p241.hasSnowContact
	return p241.densityType ~= FieldGroundType.NONE and (p241.densityType ~= FieldGroundType.GRASS and p241.densityType ~= FieldGroundType.GRASS_CUT) and true or v242
end
function WheelPhysics.getSurfaceSoundAttributes(p243)
	if p243.contact == WheelContactType.GROUND then
		if p243.hasWaterContact then
			return "shallowWater", nil
		elseif p243.densityType == FieldGroundType.NONE then
			return nil, p243.lastTerrainAttribute
		else
			return "field", nil
		end
	else
		if p243.contact == WheelContactType.GROUND_HEIGHT then
			if p243.hasSnowContact then
				return "snow", nil
			end
		elseif p243.contact == WheelContactType.OBJECT then
			return "asphalt", nil
		end
		return nil, nil
	end
end
function WheelPhysics.waterRaycastCallback(p244, p245, p246, p247, p248, _, _, _, _, _, _, p249, ...)
	if p245 == 0 then
		if p249 then
			p244.hasWaterContact = false
		end
		return
	elseif getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, p246, 0, p248) < p247 then
		p244.hasWaterContact = true
	else
		p244.hasWaterContact = false
	end
end
function WheelPhysics.registerXMLPaths(p250, p251)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#xOffset", "Moves the default position of the drive node on the X axis", 0)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#yOffset", "Moves the default position of the drive node on the Y axis", 0)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#zOffset", "Moves the default position of the drive node on the Z axis", 0)
	p250:register(XMLValueType.BOOL, p251 .. ".physics#useReprOffset", "Defines if the x/y/z offset attribute is applied to the repr or driveNode", false)
	p250:register(XMLValueType.BOOL, p251 .. ".physics#showSteeringAngle", "Show steering angle", true)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#suspTravel", "Suspension travel", 0.01)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#initialCompression", "Initial compression value")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#deltaY", "Delta Y", 0)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#spring", "Spring", 0)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#brakeFactor", "Brake factor", 1)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#autoHoldBrakeFactor", "Auto hold brake factor", "brakeFactor")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#damper", "Damper", 0)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#damperCompressionLowSpeed", "Damper compression on low speeds")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#damperCompressionHighSpeed", "Damper compression on high speeds")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#damperCompressionLowSpeedThreshold", "Damper compression on low speeds threshold", 0.1016)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#damperRelaxationLowSpeed", "Damper relaxation on low speeds")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#damperRelaxationHighSpeed", "Damper relaxation on high speeds")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#damperRelaxationLowSpeedThreshold", "Damper relaxation on low speeds threshold", 0.1524)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#forcePointRatio", "Force point ratio", 0)
	p250:register(XMLValueType.INT, p251 .. ".physics#driveMode", "Drive mode", 0)
	p250:register(XMLValueType.BOOL, p251 .. ".physics#isSynchronized", "Wheel is synchronized in multiplayer", true)
	p250:register(XMLValueType.INT, p251 .. ".physics#tipOcclusionAreaGroupId", "Tip occlusion area group id")
	p250:register(XMLValueType.BOOL, p251 .. ".physics#useReprDirection", "Use repr direction instead of component direction", false)
	p250:register(XMLValueType.BOOL, p251 .. ".physics#useDriveNodeDirection", "Use drive node direction instead of component direction", false)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#mass", "Wheel mass (to.)", 0.1)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#radius", "Wheel radius", 0.5)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#width", "Wheel width", 0.6)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#visualOffset", "Radius offset of visual wheel in percentage (0-1). Not used on the game.")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#widthOffset", "Wheel width offset", 0)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#restLoad", "Wheel load while resting", 1)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#maxLongStiffness", "Max. longitude stiffness")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#maxLatStiffness", "Max. latitude stiffness")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#maxLatStiffnessLoad", "Max. latitude stiffness load")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#frictionScale", "Wheel friction scale", 1)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#rotationDamping", "Rotation damping ", "mass * 0.035")
	p250:register(XMLValueType.STRING, p251 .. ".physics#tireType", "Tire type (mud, offRoad, street, crawler)")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#fieldDirtMultiplier", "Field dirt multiplier", 75)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#streetDirtMultiplier", "Street dirt multiplier", -150)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#waterWetnessFactor", "Factor for wheel wetness while driving in water", 20)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#minDirtPercentage", "Min. dirt scale while cleaning on street drive", 0.35)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#maxDirtOffset", "Max. dirt amount offset to global dirt node", 0.5)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#dirtColorChangeSpeed", "Defines speed to change the dirt color (sec)", 20)
	p250:register(XMLValueType.BOOL, p251 .. ".physics#versatileYRot", "Do versatile Y rotation", false)
	p250:register(XMLValueType.BOOL, p251 .. ".physics#forceVersatility", "Force versatility, also if no ground contact", false)
	p250:register(XMLValueType.BOOL, p251 .. ".physics#supportsWheelSink", "The wheel is allowed to deform the terrain displacement collision and \'sink\' into the terrain", true)
	p250:register(XMLValueType.BOOL, p251 .. ".physics.extraSink#supported", "Additional sinking into the terrain independent of the adjustment of the terrain displacement. (FS22 in prior style)", false)
	p250:register(XMLValueType.FLOAT, p251 .. ".physics.extraSink#maxValue", "Max. sink value in meter", "20% of the wheel radius")
	p250:register(XMLValueType.ANGLE, p251 .. ".physics#rotSpeed", "Rotation speed")
	p250:register(XMLValueType.ANGLE, p251 .. ".physics#rotSpeedNeg", "Rotation speed in negative direction")
	p250:register(XMLValueType.ANGLE, p251 .. ".physics#rotMax", "Max. rotation")
	p250:register(XMLValueType.ANGLE, p251 .. ".physics#rotMin", "Min. rotation")
	p250:register(XMLValueType.BOOL, p251 .. ".physics#invertRotLimit", "Invert the rotation limits")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#rotSpeedLimit", "Rotation speed limit")
	p250:register(XMLValueType.FLOAT, p251 .. ".physics#maxInnerSpacing", "Defines a maximum spacing to the inside which is now allowed to be exceeded by the tire, if so, the tire will be moved out automatically")
end
function WheelPhysics.registerAdditionalWheelXMLPaths(p252, p253)
	p252:register(XMLValueType.FLOAT, p253 .. ".physics#mass", "Wheel mass (to.)", 0)
	p252:register(XMLValueType.FLOAT, p253 .. ".physics#maxLongStiffness", "Max. longitude stiffness")
	p252:register(XMLValueType.FLOAT, p253 .. ".physics#maxLatStiffness", "Max. latitude stiffness")
end

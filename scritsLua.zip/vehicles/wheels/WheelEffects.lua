WheelEffects = {}
WheelEffects.PARTICLE_SYSTEM_PATH = "data/effects/wheel/wheelEmitterShape.i3d"
WheelEffects.WATER_EFFECTS = "data/effects/wheel/water/water.i3d"
WheelEffects.WATER_EFFECT_FADE_IN_TIME = 0.001
WheelEffects.WATER_EFFECT_FADE_OUT_TIME = 0.002
WheelEffects.PARTICLE_SYSTEM_STATES = {}
WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_DUST = 1
WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_DRY = 2
WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_WET = 3
WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_SNOW = 4
WheelEffects.GROUND_PARTICLES = {}
WheelEffects.GROUND_PARTICLES[1] = true
WheelEffects.GROUND_PARTICLES[2] = false
WheelEffects.GROUND_PARTICLES[3] = true
WheelEffects.GROUND_PARTICLES[4] = false
WheelEffects.GROUND_PARTICLES[5] = true
WheelEffects.GROUND_PARTICLES[6] = true
WheelEffects.GROUND_PARTICLES[7] = false
WheelEffects.MAX_MUD_AMOUNT = {}
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.STUBBLE_TILLAGE] = 0.5
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.CULTIVATED] = 1
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.SEEDBED] = 1
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.PLOWED] = 1
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.ROLLED_SEEDBED] = 1
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.RIDGE] = 1
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.SOWN] = 1
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.DIRECT_SOWN] = 0.5
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.PLANTED] = 1
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.RIDGE_SOWN] = 0.5
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.ROLLER_LINES] = 0.5
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.HARVEST_READY] = 0.2
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.HARVEST_READY_OTHER] = 1
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.GRASS] = 0.2
WheelEffects.MAX_MUD_AMOUNT[FieldGroundType.GRASS_CUT] = 0.2
function WheelEffects.new(p1)
	local v2 = {
		["__index"] = WheelEffects
	}
	local v3 = setmetatable({}, v2)
	v3.wheel = p1
	v3.vehicle = p1.vehicle
	v3.sharedLoadRequestIds = {}
	v3.driveGroundParticleSystems = {}
	v3.waterEffects = {}
	v3.waterEffectsLoaded = false
	v3.waterEffectsActive = false
	v3.waterEffectScale = 0
	v3.waterEffectReferenceRadius = nil
	v3.speedSmooth = 0
	v3.wheelSpeedSmooth = 0
	return v3
end
function WheelEffects.delete(p4)
	for _, v5 in pairs(p4.driveGroundParticleSystems) do
		ParticleUtil.deleteParticleSystem(v5)
	end
	for _, v6 in ipairs(p4.sharedLoadRequestIds) do
		g_i3DManager:releaseSharedI3DFile(v6)
	end
	p4.sharedLoadRequestIds = {}
	p4:removeWaterEffects()
end
function WheelEffects.loadFromXML(p7, p8)
	p7.hasTireTracks = p8:getValue("#hasTireTracks", false)
	p7.hasParticles = p8:getValue("#hasParticles", false)
	p7.hasWaterParticles = p8:getValue("#hasWaterParticles")
	p7.waterParticleDirection = p8:getValue("#waterParticleDirection", 0)
	p7.isShallowWaterObstacle = p8:getValue("#isShallowWaterObstacle", true)
	p7.tireTrackAtlasIndex = p8:getValue(".tire#tireTrackAtlasIndex", 0)
	p7.offset = p8:getValue(".wheelParticleSystem#psOffset", "0 0 0", true)
	p7.minSpeed = p8:getValue(".wheelParticleSystem#minSpeed", 3) / 3600
	p7.maxSpeed = p8:getValue(".wheelParticleSystem#maxSpeed", 20) / 3600
	p7.minScale = p8:getValue(".wheelParticleSystem#minScale", 0.1)
	p7.maxScale = p8:getValue(".wheelParticleSystem#maxScale", 1)
	p7.direction = p8:getValue(".wheelParticleSystem#direction", 0)
	p7.onlyActiveOnGroundContact = p8:getValue(".wheelParticleSystem#onlyActiveOnGroundContact", true)
	return true
end
function WheelEffects.finalize(p9)
	for _, v10 in ipairs(p9.wheel.visualWheels) do
		if p9.hasParticles then
			for v11, v12 in pairs(WheelEffects.PARTICLE_SYSTEM_STATES) do
				local v13 = g_particleSystemManager:getParticleSystem(v11)
				if v13 ~= nil then
					local v14 = {
						["name"] = v11,
						["state"] = v12,
						["wheelNode"] = v10.node,
						["width"] = v10.width,
						["radius"] = v10.radius,
						["sourceParticleSystem"] = v13,
						["sizeScale"] = 2 * v10.width * v10.radius
					}
					local v15 = p9.vehicle:loadSubSharedI3DFile(WheelEffects.PARTICLE_SYSTEM_PATH, false, false, p9.onWheelParticleSystemI3DLoaded, p9, v14)
					local v16 = p9.sharedLoadRequestIds
					table.insert(v16, v15)
				end
			end
		end
		if p9.hasWaterParticles ~= false then
			local v17 = {
				["wheelNode"] = v10.node,
				["width"] = v10.width,
				["radius"] = v10.radius
			}
			local v18 = p9.vehicle:loadSubSharedI3DFile(WheelEffects.WATER_EFFECTS, false, false, p9.onWheelWaterEffectI3DLoaded, p9, v17)
			local v19 = p9.sharedLoadRequestIds
			table.insert(v19, v18)
		end
		if p9.hasTireTracks and Platform.gameplay.wheelTireTracks then
			p9.tireTrackNodeIndex = p9.vehicle:addTireTrackNode(p9.wheel, p9.wheel.driveNodeDirectionNode, v10.node, p9.tireTrackAtlasIndex, v10.width, v10.radius, v10:getIsTireInverted())
			p9.wheel.syncContactState = true
		end
		if p9.isShallowWaterObstacle then
			v10:addShallowWaterObstacle()
		end
	end
	if #p9.wheel.visualWheels == 0 then
		if p9.hasParticles then
			for v20, v21 in pairs(WheelEffects.PARTICLE_SYSTEM_STATES) do
				local v22 = g_particleSystemManager:getParticleSystem(v20)
				if v22 ~= nil then
					local v23 = {
						["name"] = v20,
						["state"] = v21,
						["wheelNode"] = p9.wheel.driveNode,
						["width"] = p9.wheel.physics.width,
						["radius"] = p9.wheel.physics.radius,
						["sourceParticleSystem"] = v22,
						["sizeScale"] = 2 * p9.wheel.physics.width * p9.wheel.physics.radius
					}
					local v24 = p9.vehicle:loadSubSharedI3DFile(WheelEffects.PARTICLE_SYSTEM_PATH, false, false, p9.onWheelParticleSystemI3DLoaded, p9, v23)
					local v25 = p9.sharedLoadRequestIds
					table.insert(v25, v24)
				end
			end
		end
		if p9.hasWaterParticles == true then
			p9:addWaterEffectsToPhysicsData()
		end
		if p9.hasTireTracks and Platform.gameplay.wheelTireTracks then
			p9.tireTrackNodeIndex = p9.vehicle:addTireTrackNode(p9.wheel, p9.wheel.driveNodeDirectionNode, p9.wheel.driveNode, p9.tireTrackAtlasIndex, p9.wheel.physics.width, p9.wheel.physics.radius, false)
			p9.wheel.syncContactState = true
		end
	end
end
function WheelEffects.onWheelParticleSystemI3DLoaded(p26, p27, _, p28)
	if p27 ~= 0 then
		local v29 = getChildAt(p27, 0)
		link(p26.wheel.repr, v29)
		delete(p27)
		local v30 = ParticleUtil.copyParticleSystem(nil, nil, p28.sourceParticleSystem, v29)
		v30.state = p28.state
		v30.i3dFilename = p28.i3dFilename
		v30.particleSpeed = ParticleUtil.getParticleSystemSpeed(v30)
		v30.particleRandomSpeed = ParticleUtil.getParticleSystemSpeedRandom(v30)
		v30.sizeScale = p28.sizeScale
		v30.alpha = 0
		v30.isTintable = Utils.getNoNil(getUserAttribute(v30.shape, "tintable"), true)
		local v31, v32, v33 = worldToLocal(p26.wheel.repr, getWorldTranslation(p28.wheelNode))
		setTranslation(v30.emitterShape, v31 + p26.offset[1], v32 + p26.offset[2], v33 + p26.offset[3])
		setRotation(v30.emitterShape, localRotationToLocal(p28.wheelNode, getParent(v30.emitterShape), 0, 0, 0))
		setScale(v30.emitterShape, p28.width, p28.radius * 2, p28.radius * 2)
		local v34 = p26.driveGroundParticleSystems
		table.insert(v34, v30)
	end
end
function WheelEffects.onWheelWaterEffectI3DLoaded(p35, p36, _, p37)
	if p36 ~= 0 and p35.hasWaterParticles ~= false then
		local v38 = getChildAt(p36, 0)
		local v39 = getChildAt(p36, 1)
		local v40 = getChildAt(p36, 2)
		local v41 = getChildAt(p36, 3)
		local v42 = createTransformGroup("waterEffectNode")
		link(p35.wheel.node, v42)
		setWorldTranslation(v42, getWorldTranslation(p37.wheelNode))
		setWorldRotation(v42, getWorldRotation(p37.wheelNode))
		link(v42, v38)
		link(v42, v39)
		link(v42, v40)
		link(v42, v41)
		setTranslation(v38, 0, 0, p37.radius * 0.65)
		setTranslation(v39, 0, 0, p37.radius * 0.65)
		setTranslation(v40, 0, 0, -p37.radius * 0.35)
		setTranslation(v41, 0, 0, -p37.radius * 0.35)
		local v43 = p37.radius * p37.width
		local v44 = math.min(v43, 1)
		setShaderParameter(v38, "fadeProgress", nil, nil, v44, 0, false)
		setShaderParameter(v39, "fadeProgress", nil, nil, v44, 0, false)
		setShaderParameter(v40, "fadeProgress", nil, nil, v44, 0, false)
		setShaderParameter(v41, "fadeProgress", nil, nil, v44, 0, false)
		setVisibility(v42, false)
		p35.waterEffectsActive = false
		local v45 = p35.waterEffects
		table.insert(v45, {
			["wheelData"] = p37,
			["waterEffectNode"] = v42,
			["waterFront"] = v38,
			["waterFrontFoam"] = v39,
			["waterBack"] = v40,
			["waterBackFoam"] = v41
		})
		p35.waterEffectsLoaded = true
		delete(p36)
	end
end
function WheelEffects.addWaterEffectsToPhysicsData(p46)
	p46.hasWaterParticles = true
	local v47 = {
		["wheelNode"] = p46.wheel.driveNode,
		["width"] = p46.wheel.physics.width,
		["radius"] = p46.wheel.physics.radius
	}
	local v48 = p46.vehicle:loadSubSharedI3DFile(WheelEffects.WATER_EFFECTS, false, false, p46.onWheelWaterEffectI3DLoaded, p46, v47)
	local v49 = p46.sharedLoadRequestIds
	table.insert(v49, v48)
end
function WheelEffects.removeWaterEffects(p50)
	for _, v51 in ipairs(p50.waterEffects) do
		delete(v51.waterEffectNode)
	end
	p50.waterEffects = {}
	p50.waterEffectsLoaded = false
	p50.hasWaterParticles = false
end
function WheelEffects.getDriveGroundParticleSystemsScale(p52, _, p53)
	local v54 = p52.wheel
	if not v54.physics.hasSnowContact then
		if p52.onlyActiveOnGroundContact and v54.physics.contact ~= WheelContactType.GROUND then
			return 0
		end
		if not WheelEffects.GROUND_PARTICLES[v54.physics.lastTerrainAttribute] then
			return 0
		end
		if v54.physics.densityType == FieldGroundType.GRASS then
			return 0
		end
	end
	local v55 = p52.minSpeed
	local v56 = p52.direction
	if v55 >= p53 or v56 ~= 0 and v56 > 0 ~= (p52.vehicle.movingDirection > 0) then
		return 0
	end
	local v57 = p52.maxSpeed
	local v58 = (p53 - v55) / (v57 - v55)
	local v59 = math.min(v58, 1)
	return MathUtil.lerp(p52.minScale, p52.maxScale, v59)
end
function WheelEffects.update(p60, p61, _, _)
	if p60.waterEffectsLoaded then
		local v62 = p60.wheel.physics
		if VehicleDebug.wheelEffectDebugState then
			v62.hasWaterContact = true
			v62.netInfo.lastSpeedSmoothed = 0.005555555555555556
			p60.waterEffectScale = 1
			p60.vehicle.lastSpeedSmoothed = 0.005555555555555556
		end
		if v62.hasWaterContact then
			local v63 = p60.waterEffectScale + p61 * WheelEffects.WATER_EFFECT_FADE_IN_TIME
			p60.waterEffectScale = math.min(v63, 1)
		else
			local v64 = p60.waterEffectScale - p61 * WheelEffects.WATER_EFFECT_FADE_OUT_TIME
			p60.waterEffectScale = math.max(v64, 0)
		end
		local v65
		if p60.waterEffectScale > 0 then
			v65 = v62.lastContactX ~= nil
		else
			v65 = false
		end
		if v65 then
			local v66 = v62.lastContactX
			local v67 = v62.lastContactY
			local v68 = v62.lastContactZ
			if v67 > 0 then
				local v69 = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, v66, 0, v68)
				v67 = math.max(v67, v69)
			end
			local v70 = v62.netInfo.lastSpeedSmoothed < -0.000277 and -1 or 1
			local v71 = p60.vehicle.lastSpeedSmoothed * 3600
			local v72 = v62.netInfo.lastSpeedSmoothed
			local v73 = math.abs(v72) * 3600
			local v74 = 1 + v62.netInfo.slip
			local v75 = (v71 - 1) / 11
			local v76 = math.min(v75, 1)
			local v77 = math.max(v76, 0) * p60.waterEffectScale
			local v78 = (v71 - 11) / 21 * math.min(v74, 2)
			local v79 = math.min(v78, 1)
			local v80 = math.max(v79, 0) * p60.waterEffectScale
			local v81 = (v73 - 1) / 11
			local v82 = math.min(v81, 1)
			local v83 = math.max(v82, 0) * p60.waterEffectScale
			local v84 = (v73 - 11) / 21 * math.min(v74, 2)
			local v85 = math.min(v84, 1)
			local v86 = math.max(v85, 0) * p60.waterEffectScale
			if p60.waterParticleDirection ~= 0 then
				if p60.waterParticleDirection > 0 == (v70 > 0) then
					v86 = 0
					v83 = 0
				else
					v80 = 0
					v77 = 0
				end
			end
			for _, v87 in ipairs(p60.waterEffects) do
				if not p60.waterEffectsActive then
					setVisibility(v87.waterEffectNode, true)
				end
				local v88, _, v89 = localToLocal(v87.wheelData.wheelNode, p60.wheel.node, 0, 0, 0)
				local _, v90, _ = worldToLocal(p60.wheel.node, v66, v67, v68)
				setTranslation(v87.waterEffectNode, v88, v90, v89)
				local v91, _, v92 = getWorldTranslation(v87.waterEffectNode)
				local v93, v94
				if v62.useReprDirection or (v62.useDriveNodeDirection or v62.rotSpeed ~= 0) then
					local v95, v96, v97 = localToLocal(v87.waterEffectNode, p60.wheel.driveNodeDirectionNode, 0, 0, 0)
					local v98
					v93, v98, v94 = localToWorld(p60.wheel.driveNodeDirectionNode, v95, v96, v97 - v70 * 0.25)
				else
					local v99, v100, v101 = localToLocal(v87.waterEffectNode, p60.wheel.node, 0, 0, 0)
					local v102
					v93, v102, v94 = localToWorld(p60.wheel.node, v99, v100, v101 - v70 * 0.25)
				end
				if v87.worldTargetPosition == nil then
					v87.worldTargetPosition = { v93, v94 }
				end
				v87.worldTargetPosition[1] = v87.worldTargetPosition[1] * 0.8 + v93 * 0.2
				v87.worldTargetPosition[2] = v87.worldTargetPosition[2] * 0.8 + v94 * 0.2
				local v103 = v91 - v87.worldTargetPosition[1]
				local v104 = v92 - v87.worldTargetPosition[2]
				local v105 = MathUtil.vector3Length(v103, 0, v104)
				if v105 > 0 then
					local v106 = v103 / v105
					local v107 = v104 / v105
					local v108, v109, v110 = worldDirectionToLocal(getParent(v87.waterEffectNode), v106, 0, v107)
					local v111, v112, v113 = worldDirectionToLocal(getParent(v87.waterEffectNode), 0, 1, 0)
					setDirection(v87.waterEffectNode, v108, v109, v110, v111, v112, v113)
				end
				if VehicleDebug.wheelEffectDebugState then
					local _, v114, _ = getWorldTranslation(v87.waterEffectNode)
					drawDebugLine(v91, v114 + 2, v92, 1, 0, 0, v87.worldTargetPosition[1], v114 + 2, v87.worldTargetPosition[2], 1, 0, 0, true)
				end
				local v115 = p60.waterEffectReferenceRadius or v87.wheelData.radius
				local v116 = v71 / 25
				local v117 = math.min(v116, 1)
				local v118 = v115 * math.max(v117, 0.25)
				local v119 = v73 * math.min(v74, 3) / 25
				local v120 = math.min(v119, 1)
				local v121 = v115 * math.max(v120, 0.25)
				local v122 = v87.wheelData.width * 1.2
				setScale(v87.waterFront, v122, v118, v118)
				setScale(v87.waterFrontFoam, v122, v118, v118)
				setScale(v87.waterBack, v122, v121, v121)
				setScale(v87.waterBackFoam, v122, v121, v121)
				setShaderParameter(v87.waterFront, "density", v77, nil, nil, nil, false)
				setShaderParameter(v87.waterFrontFoam, "density", v80, nil, nil, nil, false)
				setShaderParameter(v87.waterBack, "density", v83, nil, nil, nil, false)
				setShaderParameter(v87.waterBackFoam, "density", v86, nil, nil, nil, false)
			end
		elseif p60.waterEffectsActive then
			for _, v123 in ipairs(p60.waterEffects) do
				setVisibility(v123.waterEffectNode, false)
			end
		end
		p60.waterEffectsActive = v65
	end
end
function WheelEffects.updateTick(p124, p125, p126)
	local v127 = p124.wheel.physics
	local v128 = v127.groundColor
	local v129 = v127.hasSoilContact
	local v130 = 0
	if v127.hasSnowContact then
		v130 = WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_SNOW
	elseif v129 then
		if p126 > 0.2 then
			v130 = WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_WET
		else
			v130 = WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_DRY
		end
	elseif p126 <= 0.2 then
		v130 = WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_DUST
	end
	local v131 = v127.netInfo.lastSpeedSmoothed
	local v132 = 1 + v127.netInfo.slip
	for _, v133 in ipairs(p124.driveGroundParticleSystems) do
		if v133.state == v130 then
			local v134
			if v133.state == WheelEffects.PARTICLE_SYSTEM_STATES.WHEEL_DUST then
				v134 = p124:getDriveGroundParticleSystemsScale(v133, p124.vehicle.lastSpeedSmoothed)
			else
				v134 = p124:getDriveGroundParticleSystemsScale(v133, v131) * v132
			end
			if v133.isTintable then
				if v133.lastColor == nil then
					v133.lastColor = { v128[1], v128[2], v128[3] }
					v133.targetColor = { v128[1], v128[2], v128[3] }
					v133.currentColor = { v128[1], v128[2], v128[3] }
					v133.alpha = 1
				end
				if v133.alpha ~= 1 then
					local v135 = v133.alpha + p125 * 0.001
					v133.alpha = math.min(v135, 1)
					v133.currentColor = { MathUtil.vector3ArrayLerp(v133.lastColor, v133.targetColor, v133.alpha) }
					if v133.alpha == 1 then
						v133.lastColor[1] = v133.currentColor[1]
						v133.lastColor[2] = v133.currentColor[2]
						v133.lastColor[3] = v133.currentColor[3]
					end
				end
				if v133.alpha == 1 and (v128[1] ~= v133.targetColor[1] and (v128[2] ~= v133.targetColor[2] and v128[3] ~= v133.targetColor[3])) then
					v133.alpha = 0
					v133.targetColor[1] = v128[1]
					v133.targetColor[2] = v128[2]
					v133.targetColor[3] = v128[3]
				end
			end
			if v134 > 0 then
				ParticleUtil.setEmittingState(v133, true)
				if v133.isTintable then
					I3DUtil.setShaderParameterRec(v133.shape, "colorAlpha", v133.currentColor[1], v133.currentColor[2], v133.currentColor[3], 1)
				end
			else
				ParticleUtil.setEmittingState(v133, false)
			end
			local v136 = 13.88888888888889 / v127.radiusOriginal
			local v137 = v134 * ((v127.netInfo.xDriveSpeed or 0) / v136) * v133.sizeScale
			local v138 = ParticleUtil.setEmitCountScale
			local v139 = p124.minScale
			local v140 = p124.maxScale
			v138(v133, (math.clamp(v137, v139, v140)))
			ParticleUtil.setParticleSystemSpeed(v133, v133.particleSpeed)
			ParticleUtil.setParticleSystemSpeedRandom(v133, v133.particleRandomSpeed)
		else
			ParticleUtil.setEmittingState(v133, false)
		end
	end
end
function WheelEffects.onUpdateEnd(p141, _)
	for _, v142 in ipairs(p141.driveGroundParticleSystems) do
		ParticleUtil.setEmittingState(v142, false)
	end
end
function WheelEffects.registerXMLPaths(p143, p144)
	p143:register(XMLValueType.BOOL, p144 .. "#hasTireTracks", "Has tire tracks", false)
	p143:register(XMLValueType.BOOL, p144 .. "#hasParticles", "Has particles", false)
	p143:register(XMLValueType.BOOL, p144 .. "#hasWaterParticles", "Has water particles", "true if visual wheel is defined")
	p143:register(XMLValueType.INT, p144 .. "#waterParticleDirection", "The direction in which the water particles should only be active (0: both, 1: only the front, -1: only the back)", 0)
	p143:register(XMLValueType.BOOL, p144 .. "#isShallowWaterObstacle", "The visual wheels will interact with the shallow water simulation", true)
	p143:register(XMLValueType.FLOAT, p144 .. ".tire#tireTrackAtlasIndex", "Tire track atlas index", 0)
	p143:register(XMLValueType.VECTOR_TRANS, p144 .. ".wheelParticleSystem#psOffset", "Translation offset", "0 0 0")
	p143:register(XMLValueType.FLOAT, p144 .. ".wheelParticleSystem#minSpeed", "Min. speed for activation", 3)
	p143:register(XMLValueType.FLOAT, p144 .. ".wheelParticleSystem#maxSpeed", "Max. speed for activation", 20)
	p143:register(XMLValueType.FLOAT, p144 .. ".wheelParticleSystem#minScale", "Min. scale", 0.1)
	p143:register(XMLValueType.FLOAT, p144 .. ".wheelParticleSystem#maxScale", "Max. scale", 1)
	p143:register(XMLValueType.INT, p144 .. ".wheelParticleSystem#direction", "Moving direction for activation", 0)
	p143:register(XMLValueType.BOOL, p144 .. ".wheelParticleSystem#onlyActiveOnGroundContact", "Only active while wheel has ground contact", true)
end

WheelChock = {}
local v_u_1 = Class(WheelChock)
function WheelChock.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.wheel = p2
	v5.isInParkingPosition = false
	v5.wheelRadiusOffset = 0
	return v5
end
function WheelChock.delete(p6)
	if p6.node ~= nil then
		delete(p6.node)
		p6.node = nil
	end
	if p6.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(p6.sharedLoadRequestId)
		p6.sharedLoadRequestId = nil
	end
end
function WheelChock.loadFromXML(p7, p8, p9)
	local v10 = p7.wheel.vehicle
	p7.filename = p8:getValue(p9 .. "#filename", "$data/shared/assets/wheelChocks/wheelChock01.i3d")
	p7.filename = Utils.getFilename(p7.filename, p7.wheel.baseDirectory)
	if p7.filename == nil then
		p8:xmlWarning(p9 .. "#filename", "Invalid filename given for wheel chock")
		return false
	end
	p7.parkingNode = p8:getValue(p9 .. "#parkingNode", nil, v10.components, v10.i3dMappings)
	p7.scale = p8:getValue(p9 .. "#scale", "1 1 1", true)
	p7.isInverted = p8:getValue(p9 .. "#isInverted", false)
	p7.isParked = p8:getValue(p9 .. "#isParked", false)
	p7.offset = p8:getValue(p9 .. "#offset", "0 0 0", true)
	local v11 = VehicleMaterial.new(p7.wheel.baseDirectory)
	if v11:loadFromXML(p8, p9, p7.wheel.vehicle.customEnvironment) then
		p7.material = v11
	end
	p7.sharedLoadRequestId = v10:loadSubSharedI3DFile(p7.filename, false, false, p7.onI3DLoaded, p7)
	return true
end
function WheelChock.onI3DLoaded(p12, p13, _, _)
	if p13 ~= 0 then
		p12.node = getChildAt(p13, 0)
		local v14 = I3DUtil.indexToObject(p12.node, getUserAttribute(p12.node, "posRefNode"))
		if v14 == nil then
			Logging.warning("Missing \'posRefNode\'-userattribute for wheel-chock \'%s\'!", p12.filename)
		else
			local _, v15, v16 = localToLocal(v14, p12.node, 0, 0, 0)
			p12.height = v15
			p12.zOffset = v16
			p12.height = p12.height * p12.scale[2]
			p12.zOffset = p12.zOffset * p12.scale[3]
			setScale(p12.node, p12.scale[1], p12.scale[2], p12.scale[3])
			p12.parkedNode = I3DUtil.indexToObject(p12.node, getUserAttribute(p12.node, "parkedNode"))
			p12.linkedNode = I3DUtil.indexToObject(p12.node, getUserAttribute(p12.node, "linkedNode"))
			if p12.material ~= nil then
				p12.material:apply(p12.node, "wheelChock_main_mat")
			end
			p12:update()
		end
		delete(p13)
	end
end
function WheelChock.update(p17, p18)
	if p17.node ~= nil then
		if p18 == nil then
			p18 = p17.isInParkingPosition
		end
		p17.isInParkingPosition = p18
		if p18 then
			if p17.parkingNode == nil then
				setVisibility(p17.node, false)
			else
				setTranslation(p17.node, 0, 0, 0)
				setRotation(p17.node, 0, 0, 0)
				link(p17.parkingNode, p17.node)
				setVisibility(p17.node, true)
			end
		else
			setVisibility(p17.node, true)
			setScale(p17.node, 1, 1, 1)
			local v19 = p17.wheel
			local v20 = v19.physics.radius - p17.wheelRadiusOffset - p17.height
			local v21 = math.max(v20, 0.01) / v19.physics.radius
			local v22 = math.acos(v21)
			local v23 = -(v19.physics.radius * math.sin(v22)) - p17.zOffset
			link(v19.node, p17.node)
			local _, v24, _ = localRotationToLocal(getParent(v19.repr), v19.node, getRotation(v19.repr))
			if p17.isInverted then
				v24 = v24 + 3.141592653589793
			end
			setRotation(p17.node, 0, v24, 0)
			local v25, v26, v27 = localDirectionToLocal(p17.node, v19.node, 0, 0, 1)
			local v28, v29, v30 = localDirectionToLocal(p17.node, v19.node, 1, 0, 0)
			local v31, v32, v33 = localToLocal(v19.driveNode, v19.node, 0, 0, 0)
			local v34 = v31 + v28 * p17.offset[1] + v25 * (v23 + p17.offset[3])
			local v35 = v32 + v29 * p17.offset[1] + v26 * (v23 + p17.offset[3]) - v19.physics.radius + p17.wheelRadiusOffset + p17.offset[2]
			local v36 = v33 + v30 * p17.offset[1] + v27 * (v23 + p17.offset[3])
			setTranslation(p17.node, v34, v35, v36)
			setScale(p17.node, p17.scale[1], p17.scale[2], p17.scale[3])
		end
		if p17.parkedNode ~= nil then
			setVisibility(p17.parkedNode, p18)
		end
		if p17.linkedNode ~= nil then
			setVisibility(p17.linkedNode, not p18)
		end
		return true
	end
end
function WheelChock.registerXMLPaths(p37, p38)
	p37:register(XMLValueType.STRING, p38 .. "#filename", "Path to wheel chock i3d", "$data/shared/assets/wheelChocks/wheelChock01.i3d")
	p37:register(XMLValueType.VECTOR_SCALE, p38 .. "#scale", "Scale", "1 1 1")
	p37:register(XMLValueType.NODE_INDEX, p38 .. "#parkingNode", "Parking node")
	p37:register(XMLValueType.BOOL, p38 .. "#isInverted", "Is inverted (In front or back of the wheel)", false)
	p37:register(XMLValueType.BOOL, p38 .. "#isParked", "Default is parked", false)
	p37:register(XMLValueType.VECTOR_TRANS, p38 .. "#offset", "Translation offset", "0 0 0")
	VehicleMaterial.registerXMLPaths(p37, p38)
end

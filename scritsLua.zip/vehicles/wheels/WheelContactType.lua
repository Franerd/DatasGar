WheelContactType = {}
WheelContactType.NONE = 1
WheelContactType.OBJECT = 2
WheelContactType.GROUND = 3
WheelContactType.GROUND_HEIGHT = 4
Enum(WheelContactType)

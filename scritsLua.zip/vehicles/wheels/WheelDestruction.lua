WheelDestruction = {}
function WheelDestruction.new(p1)
	local v2 = {
		["__index"] = WheelDestruction
	}
	local v3 = setmetatable({}, v2)
	v3.wheel = p1
	v3.vehicle = p1.vehicle
	v3.destructionNodes = {}
	v3.wheelSmoothAccumulation = 0
	return v3
end
function WheelDestruction.loadFromXML(p4, p5)
	p5:checkDeprecatedXMLElements(".tire#isCareWheel", "#isCareWheel")
	p4.isCareWheel = p5:getValue("#isCareWheel", false)
	local v6 = p4.wheel.physics.width * 0.75
	p4.smoothGroundRadius = p5:getValue(".physics#smoothGroundRadius", (math.max(0.6, v6)))
	return true
end
function WheelDestruction.finalize(p7)
	for _, v8 in ipairs(p7.wheel.visualWheels) do
		local v9 = {
			["node"] = v8.node,
			["width"] = v8.width,
			["radius"] = v8.radius
		}
		local v10 = p7.destructionNodes
		table.insert(v10, v9)
	end
	if #p7.wheel.visualWheels == 0 then
		local v11 = {
			["node"] = p7.wheel.driveNode,
			["width"] = p7.wheel.physics.width,
			["radius"] = p7.wheel.physics.radius
		}
		local v12 = p7.destructionNodes
		table.insert(v12, v11)
	end
end
function WheelDestruction.update(p13, p14, p15)
	if p15 then
		local v16 = p13.wheel.physics.contact ~= WheelContactType.NONE
		local v17
		if v16 then
			v17 = not p13.isCareWheel
		else
			v17 = v16
		end
		if v16 then
			v16 = p13.wheel.physics.hasSnowContact
		end
		if v17 or v16 then
			for _, v18 in ipairs(p13.destructionNodes) do
				local v19 = p13.wheel.repr
				local v20 = 0.5 * v18.width
				local v21 = 0.5 * v18.width
				local v22 = math.min(0.5, v21)
				local v23, v24, v25 = localToLocal(v18.node, v19, 0, 0, 0)
				if v17 then
					local v26, _, v27 = localToWorld(v19, v23 + v20, v24, v25 - v22)
					local v28, _, v29 = localToWorld(v19, v23 - v20, v24, v25 - v22)
					local v30, _, v31 = localToWorld(v19, v23 + v20, v24, v25 + v22)
					if g_farmlandManager:getIsOwnedByFarmAtWorldPosition(p13.vehicle:getActiveFarm(), v26, v27) then
						p13:destroyFruitArea(v26, v27, v28, v29, v30, v31)
					end
				end
				if v16 then
					local v32 = v18.radius * 0.75 * p13.vehicle.movingDirection
					local v33, _, v34 = localToWorld(v19, v23 + v20, v24, v25 - v22 + v32)
					local v35, _, v36 = localToWorld(v19, v23 - v20, v24, v25 - v22 + v32)
					local v37, _, v38 = localToWorld(v19, v23 + v20, v24, v25 + v22 + v32)
					p13:destroySnowArea(v33, v34, v35, v36, v37, v38)
				end
			end
		end
	end
	if Platform.gameplay.wheelDensityHeightSmooth then
		local v39 = 0
		if p13.vehicle.lastSpeedReal > 0.0002 then
			local v40 = p13.wheelSmoothAccumulation
			local v41 = p13.vehicle.lastMovedDistance * 1.2
			local v42 = 0.0003 * p14
			v39 = v40 + math.max(v41, v42)
			p13.wheelSmoothAccumulation = v39 - DensityMapHeightUtil.getRoundedHeightValue(v39)
		else
			p13.wheelSmoothAccumulation = 0
		end
		if v39 > 0 then
			for _, v43 in ipairs(p13.destructionNodes) do
				local v44, _, _ = localToLocal(v43.node, p13.wheel.repr, 0, 0, 0)
				local v45, v46, v47 = localToLocal(p13.wheel.node, p13.wheel.repr, p13.wheel.physics.netInfo.x, p13.wheel.physics.netInfo.y, p13.wheel.physics.netInfo.z)
				local v48, v49, v50 = localToWorld(p13.wheel.repr, v45 + v44, v46 - p13.wheel.physics.radius, v47)
				p13:smoothHeightAtPosition(v48, v49, v50, p13.smoothGroundRadius, v39)
			end
		end
	end
end
function WheelDestruction.destroyFruitArea(_, p51, p52, p53, p54, p55, p56)
	FSDensityMapUtil.updateWheelDestructionArea(p51, p52, p53, p54, p55, p56)
end
function WheelDestruction.destroySnowArea(_, p57, p58, p59, p60, p61, p62)
	local v63 = g_currentMission.snowSystem
	local v64 = v63.height
	local v65 = v63:getSnowHeightAtArea(p57, p58, p59, p60, p61, p62)
	local v66 = MathUtil.equalEpsilon(v64, v65, 0.005)
	local v67
	if v64 < 0.005 then
		v67 = v65 > 1
	else
		v67 = false
	end
	if SnowSystem.MIN_LAYER_HEIGHT < v65 and (v66 or v67) then
		local v68 = 0.7 * v64
		if v67 then
			v68 = 0.1 * v65
		end
		local v69 = math.min(v68, v65) / SnowSystem.MIN_LAYER_HEIGHT
		local v70 = math.floor(v69)
		if v70 > 0 then
			v63:removeSnow(p57, p58, p59, p60, p61, p62, v70)
		end
	end
end
function WheelDestruction.smoothHeightAtPosition(_, p71, p72, p73, p74, p75)
	local v76 = DensityMapHeightUtil.getHeightTypeDescAtWorldPos(p71, p72, p73, p74)
	if v76 ~= nil and v76.allowsSmoothing then
		local v77 = g_densityMapHeightManager:getTerrainDetailHeightUpdater()
		if v77 ~= nil then
			local v78 = getTerrainHeightAtWorldPos(g_terrainNode, p71, p72, p73)
			local v79 = p72 - v78
			local v80 = (v79 + v76.collisionBaseOffset) / v76.collisionScale
			local v81 = v79 + v76.minCollisionOffset
			local v82 = math.max(v80, v81)
			local v83 = v79 + v76.maxCollisionOffset
			local v84 = math.min(v82, v83) + -0.1
			local v85 = v78 + math.max(v84, 0)
			smoothDensityMapHeightAtWorldPos(v77, p71, v85, p73, p75, v76.index, 0, p74, p74 + 1.2, 0)
			if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
				DebugUtil.drawDebugCircle(p71, v85, p73, p74, 10)
			end
		end
	end
end
function WheelDestruction.drawAreas(p86)
	if not p86.isCareWheel then
		for _, v87 in ipairs(p86.wheel.visualWheels) do
			local v88 = p86.wheel.repr
			local v89 = 0.5 * v87.width
			local v90 = 0.5 * v87.width
			local v91 = math.min(0.5, v90)
			local v92, v93, v94 = localToLocal(v87.node, v88, 0, 0, 0)
			local v95, v96, v97 = localToWorld(v88, v92 + v89, v93, v94 - v91)
			local v98, _, v99 = localToWorld(v88, v92 - v89, v93, v94 - v91)
			local v100, _, v101 = localToWorld(v88, v92 + v89, v93, v94 + v91)
			local v102, v103, v104, v105, v106, v107 = MathUtil.getXZWidthAndHeight(v95, v97, v98, v99, v100, v101)
			DebugUtil.drawDebugParallelogram(v102, v103, v104, v105, v106, v107, v96, 1, 1, 0, 0.05, true)
		end
		if #p86.wheel.visualWheels == 0 then
			local v108 = p86.wheel.repr
			local v109 = 0.5 * p86.wheel.physics.width
			local v110 = 0.5 * p86.wheel.physics.width
			local v111 = math.min(0.5, v110)
			local v112, v113, v114 = localToLocal(p86.wheel.driveNode, v108, 0, 0, 0)
			local v115, v116, v117 = localToWorld(v108, v112 + v109, v113, v114 - v111)
			local v118, _, v119 = localToWorld(v108, v112 - v109, v113, v114 - v111)
			local v120, _, v121 = localToWorld(v108, v112 + v109, v113, v114 + v111)
			local v122, v123, v124, v125, v126, v127 = MathUtil.getXZWidthAndHeight(v115, v117, v118, v119, v120, v121)
			DebugUtil.drawDebugParallelogram(v122, v123, v124, v125, v126, v127, v116, 1, 1, 0, 0.05, true)
		end
	end
end
function WheelDestruction.setIsCareWheel(p128, p129)
	p128.isCareWheel = p129
end
function WheelDestruction.registerXMLPaths(p130, p131)
	p130:register(XMLValueType.BOOL, p131 .. "#isCareWheel", "Is care wheel", false)
	p130:register(XMLValueType.FLOAT, p131 .. ".physics#smoothGroundRadius", "Smooth ground radius", "width * 0.75")
end

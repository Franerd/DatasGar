WheelVisualPartTire = {}
local v_u_1 = Class(WheelVisualPartTire, WheelVisualPart)
function WheelVisualPartTire.new(p2, p3, p4, _)
	-- upvalues: (copy) v_u_1
	local v5 = WheelVisualPart.new(p2, p3, p4, v_u_1)
	v5.deformation = 0
	v5.derformationPrevDirty = false
	return v5
end
function WheelVisualPartTire.loadFromXML(p6, p7, p8)
	if not WheelVisualPartTire:superClass().loadFromXML(p6, p7, p8) then
		return false
	end
	p6.maxDeformation = p7:getValue(p8 .. "#maxDeformation", 0)
	local v9 = p8 .. "#initialDeformation"
	local v10 = p6.maxDeformation * 0.6
	p6.initialDeformation = p7:getValue(v9, (math.min(0.04, v10)))
	return true
end
function WheelVisualPartTire.update(p11, _, _, _, _, p12, _, p13)
	if p11.node ~= nil and Platform.gameplay.wheelVisualPressure then
		local v14 = p11.initialDeformation - p12
		local v15 = p11.maxDeformation
		local v16 = math.clamp(v14, 0, v15)
		local v17 = v16 - p11.deformation
		local v18, v19
		if math.abs(v17) > Platform.gameplay.wheelVisualPressureUpdateThreshold then
			v18 = p11.deformation
			p11.deformation = v16
			p11.derformationPrevDirty = true
			v19 = v16
			p13 = true
		else
			v19 = nil
			v18 = nil
		end
		if v19 == nil and p11.derformationPrevDirty then
			v18 = p11.deformation
			v19 = p11.deformation
			p11.derformationPrevDirty = false
		end
		if v19 ~= nil then
			for _, v20 in ipairs(p11.tireNodes) do
				setShaderParameter(v20, "morphPos", nil, nil, nil, v19, false)
				setShaderParameter(v20, "prevMorphPos", nil, nil, nil, v18, false)
			end
		end
		p12 = p12 + v16
	end
	return p13, p12
end
function WheelVisualPartTire.setNode(p_u_21, p22)
	WheelVisualPartTire:superClass().setNode(p_u_21, p22)
	p_u_21.tireNodes = {}
	if getHasClassId(p_u_21.node, ClassIds.SHAPE) and (getHasShaderParameter(p_u_21.node, "morphPos") or getHasShaderParameter(p_u_21.node, "morphPosition")) then
		local v23 = p_u_21.tireNodes
		local v24 = p_u_21.node
		table.insert(v23, v24)
	end
	I3DUtil.iterateRecursively(p22, function(p25)
		-- upvalues: (copy) p_u_21
		if getHasClassId(p25, ClassIds.SHAPE) and (getHasShaderParameter(p25, "morphPos") or getHasShaderParameter(p25, "morphPosition")) then
			local v26 = p_u_21.tireNodes
			table.insert(v26, p25)
		end
	end)
	for _, v27 in ipairs(p_u_21.tireNodes) do
		if getHasShaderParameter(v27, "morphPos") then
			local v28, v29, v30, _ = getShaderParameter(v27, "morphPos")
			setShaderParameter(v27, "morphPos", nil, nil, nil, 0, false)
			setShaderParameter(v27, "prevMorphPos", v28, v29, v30, 0, false)
		elseif getHasShaderParameter(v27, "morphPosition") then
			local v31, v32, v33, _ = getShaderParameter(v27, "morphPosition")
			setShaderParameter(v27, "morphPos", v31, v32, v33, 0, false)
			setShaderParameter(v27, "prevMorphPos", v31, v32, v33, 0, false)
		end
	end
end
function WheelVisualPartTire.registerXMLPaths(p34, p35, p36)
	WheelVisualPart.registerXMLPaths(p34, p35, p36)
	p34:register(XMLValueType.FLOAT, p35 .. "#maxDeformation", "Max. deformation", 0)
	p34:register(XMLValueType.FLOAT, p35 .. "#initialDeformation", "Tire deformation at initial compression value", "min. 0.04 and max. 60% of the deformation")
	p34:register(XMLValueType.BOOL, p35 .. "#hasMudMesh", "Tire has a mud mesh included", false)
end

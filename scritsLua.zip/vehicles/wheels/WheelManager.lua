WheelManager = {}
WheelManager.DEFAULT_FILENAME = "data/shared/wheels/wheels.xml"
WheelManager.BRAND_TO_SORT_INDEX = {}
WheelManager.BRAND_TO_SORT_INDEX.TRELLEBORG = 1
WheelManager.BRAND_TO_SORT_INDEX.MICHELIN = 2
WheelManager.BRAND_TO_SORT_INDEX.CONTINENTAL = 3
WheelManager.BRAND_TO_SORT_INDEX.MITAS = 4
WheelManager.BRAND_TO_SORT_INDEX.BKT = 5
WheelManager.BRAND_TO_SORT_INDEX.VREDESTEIN = 6
WheelManager.BRAND_TO_SORT_INDEX.NOKIAN = 7
local v_u_1 = Class(WheelManager, AbstractManager)
function WheelManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function WheelManager.initDataStructures(p3)
	p3.wheels = {}
	p3.wheelsByBasePath = {}
	p3.sortedTypedWheels = {}
	p3.wheelFilenameToAttributes = {}
end
function WheelManager.loadMapData(p4, _, _, p5)
	WheelManager:superClass().loadMapData(p4)
	p4.baseDirectory = p5
	local v6 = XMLFile.load("wheelsXML", WheelManager.DEFAULT_FILENAME)
	if v6 ~= nil then
		p4:loadWheelsFromXML(v6, "wheels", p5)
		v6:delete()
	end
	return true
end
function WheelManager.loadWheelsFromXML(p_u_7, p_u_8, p9, p_u_10)
	p_u_8:iterate(p9 .. ".wheel", function(_, p11)
		-- upvalues: (copy) p_u_8, (copy) p_u_10, (copy) p_u_7
		local v12 = {
			["path"] = p_u_8:getString(p11 .. "#filename")
		}
		if v12.path == nil then
			Logging.xmlWarning(p_u_8, "Missing filename for wheel \'%s\'", p11)
			return
		else
			v12.path = Utils.getFilename(v12.path, p_u_10)
			v12.radius = p_u_8:getFloat(p11 .. "#radius")
			if v12.radius == nil then
				Logging.xmlWarning(p_u_8, "Missing radius for wheel \'%s\'", p11)
				return
			else
				v12.width = p_u_8:getFloat(p11 .. "#width")
				if v12.width == nil then
					Logging.xmlWarning(p_u_8, "Missing width for wheel \'%s\'", p11)
				else
					v12.category = p_u_8:getString(p11 .. "#category", "UNKNOWN")
					v12.allowMixture = p_u_8:getBool(p11 .. "#allowMixture", true)
					v12.priority = p_u_8:getInt(p11 .. "#priority", 1)
					v12.filename = Utils.getFilenameFromPath(v12.path)
					v12.filename = string.split(v12.filename, ".")[1]
					v12.basePath = Utils.getDirectory(v12.path)
					local v13 = v12.basePath:split("/")
					v12.wheelBrand = g_brandManager:getBrandByName(v13[#v13 - 2]) or g_brandManager:getBrandByIndex(Brand.NONE)
					v12.wheelName = v13[#v13 - 1] or "Unknown"
					if p_u_7.wheelFilenameToAttributes[v12.filename] == nil then
						p_u_7.wheelFilenameToAttributes[v12.filename] = {
							["baseFilename"] = v12.path,
							["radius"] = v12.radius,
							["width"] = v12.width
						}
					else
						local v14 = p_u_7.wheelFilenameToAttributes[v12.filename]
						local v15 = v12.radius - v14.radius
						if math.abs(v15) > 0.001 then
							Logging.xmlWarning(p_u_8, "Invalid radius for wheel \'%s\'. Does not equal the default radius for this tire size. (Base: %.3f from %s)", v12.path, v14.radius, v14.baseFilename)
						end
						local v16 = v12.width - v14.width
						if math.abs(v16) > 0.001 then
							Logging.xmlWarning(p_u_8, "Invalid width for wheel \'%s\'. Does not equal the default width for this tire size. (Base: %.3f from %s)", v12.path, v14.width, v14.baseFilename)
						end
					end
					local v17 = p_u_7.wheels
					table.insert(v17, v12)
					if p_u_7.wheelsByBasePath[v12.basePath] == nil then
						p_u_7.wheelsByBasePath[v12.basePath] = {}
						local v18 = p_u_7.sortedTypedWheels
						local v19 = p_u_7.wheelsByBasePath[v12.basePath]
						table.insert(v18, v19)
					end
					local v20 = p_u_7.wheelsByBasePath[v12.basePath]
					table.insert(v20, v12)
				end
			end
		end
	end)
	table.sort(p_u_7.sortedTypedWheels, function(p21, p22)
		if p21[1].wheelBrand.name == p22[1].wheelBrand.name then
			if p21[1].priority == p22[1].priority then
				return p21[1].wheelName < p22[1].wheelName
			else
				return p21[1].priority > p22[1].priority
			end
		else
			return p21[1].wheelBrand.name < p22[1].wheelBrand.name
		end
	end)
end
function WheelManager.getTiresForDimensionCombinations(p23, p24, p25, p26, p27, p28)
	local v29 = {}
	local v30 = {}
	for _, v31 in ipairs(p24) do
		for _, v32 in ipairs(p23.sortedTypedWheels) do
			local v33
			if #p26 > 0 then
				local v34 = false
				local v35 = false
				for _, v36 in pairs(p26) do
					if v36.brand == v32[1].wheelBrand then
						v34 = true
						for _, v37 in ipairs(v36.names) do
							if v37 == v32[1].wheelName then
								v35 = true
							end
						end
					end
				end
				v33 = not v34 or v34 and v35
			else
				v33 = true
			end
			if v33 then
				local v38 = {
					["wheels"] = {},
					["wheelBrand"] = nil,
					["wheelSaveId"] = ""
				}
				for v39, v40 in ipairs(v31) do
					for _, v41 in ipairs(v32) do
						if v41.filename == v40 and (p25 == nil or p25[v41.category] == true) then
							v38.wheels[v39] = v41
							break
						end
						if v40 == "-" then
							v38.wheels[v39] = {}
						end
					end
				end
				local v42 = table.size(v38.wheels)
				local v43
				if v42 > 0 and v42 ~= #v31 then
					p23:fillCombinationWithMixedTires(v31, v38, p25, p26)
					v43 = true
				else
					v43 = false
				end
				if table.size(v38.wheels) == #v31 then
					local v44 = nil
					for _, v45 in pairs(v38.wheels) do
						if v45.wheelBrand ~= nil then
							v44 = v45
						end
					end
					local v46 = v44 ~= nil
					if p27 ~= (1 / 0) then
						local v47 = 0
						for _, v48 in ipairs(v29) do
							if v48.wheelBrand == v44.wheelBrand then
								v47 = v47 + 1
								if p27 <= v47 then
									v46 = false
									break
								end
							end
						end
					end
					if v43 then
						for _, v49 in ipairs(v29) do
							local v50 = true
							for v51 = 1, #v38.wheels do
								if v38.wheels[v51].path ~= v49.wheels[v51].path then
									v50 = false
									break
								end
							end
							if v50 then
								v46 = false
							end
						end
					end
					if v46 then
						v30[v44.wheelBrand] = (v30[v44.wheelBrand] or 0) + 1
						v38.index = v30[v44.wheelBrand]
						v38.wheelBrand = v44.wheelBrand
						v38.wheelSaveId = v44.wheelBrand.name .. "_" .. v44.wheelName
						local v52 = 0
						if p28 ~= nil then
							v52 = p28[v44.wheelBrand.name] or v52
						end
						if v52 == 0 then
							v52 = 100 + (WheelManager.BRAND_TO_SORT_INDEX[v44.wheelBrand.name] or (1 / 0))
						end
						v38.sortIndex = v52 + v38.index * 0.01
						table.insert(v29, v38)
					end
				end
			end
		end
	end
	table.sort(v29, function(p53, p54)
		return p53.sortIndex < p54.sortIndex
	end)
	return v29
end
function WheelManager.fillCombinationWithMixedTires(p55, p56, p57, p58, p59)
	local v60 = p57.wheels[next(p57.wheels)]
	if not v60.allowMixture then
		return
	end
	local v61 = v60.wheelBrand
	local v62 = v60.wheelName
	local v63 = nil
	if #p59 > 0 then
		local v64 = false
		for _, v65 in pairs(p59) do
			if v65.brand == v61 then
				v64 = true
				for _, v66 in ipairs(v65.names) do
					if v66 == v62 then
						v63 = v65.names
					end
				end
			end
		end
		if v63 == nil and v64 then
			return
		end
	end
	for _, v67 in ipairs(p55.sortedTypedWheels) do
		for v68, v69 in ipairs(p56) do
			if p57.wheels[v68] == nil then
				for _, v70 in ipairs(v67) do
					if v70.allowMixture and (v70.filename == v69 and (v70.wheelBrand == v61 and (p58 == nil or (p58[v70.category] == true or v63 ~= nil)))) then
						local v71 = v63 == nil
						if v63 ~= nil then
							for _, v72 in ipairs(v63) do
								if v72 == v70.wheelName then
									v71 = true
									break
								end
							end
						end
						if v71 then
							p57.wheels[v68] = v70
						end
					end
				end
			end
		end
	end
end
function WheelManager.getWheelRadiusAndWidthFromDimension(p73, p74)
	for _, v75 in ipairs(p73.sortedTypedWheels) do
		for _, v76 in ipairs(v75) do
			if v76.filename == p74 then
				return v76.radius, v76.width
			end
		end
	end
	return nil, nil
end
function WheelManager.getWheelRadiusAndWidthFromFilename(p77, p78)
	for _, v79 in ipairs(p77.sortedTypedWheels) do
		for _, v80 in ipairs(v79) do
			if v80.path == p78 then
				return v80.radius, v80.width
			end
		end
	end
	return nil, nil
end
g_wheelManager = WheelManager.new()

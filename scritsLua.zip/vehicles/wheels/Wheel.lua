Wheel = {}
Wheel.VISUAL_WHEEL_UPDATE_DISTANCE = 300
Wheel.STEERING_ANGLE_THRESHOLD = 0.00034
Wheel.SUSPENSION_THRESHOLD = 0.001
source("dataS/scripts/vehicles/wheels/WheelXMLObject.lua")
source("dataS/scripts/vehicles/wheels/WheelPhysics.lua")
source("dataS/scripts/vehicles/wheels/WheelDestruction.lua")
source("dataS/scripts/vehicles/wheels/WheelEffects.lua")
source("dataS/scripts/vehicles/wheels/WheelSteering.lua")
source("dataS/scripts/vehicles/wheels/WheelVisual.lua")
source("dataS/scripts/vehicles/wheels/WheelDebug.lua")
source("dataS/scripts/vehicles/wheels/WheelChock.lua")
local v_u_1 = Class(Wheel)
function Wheel.new(p2, p3, p4, p5, p6, p7, p8, p9, p10)
	-- upvalues: (copy) v_u_1
	local v11 = p10 or v_u_1
	local v12 = setmetatable({}, v11)
	v12.vehicle = p2
	v12.xmlFile = p3
	v12.xmlObject = WheelXMLObject.new(p3, p4, p7, p5, p8)
	v12.baseDirectory = p9
	v12.name = v12.xmlObject.externalWheelName
	v12.wheelIndex = p6
	v12.updateIndex = (p6 - 1) % 4 + 1
	v12.brakePedal = 0
	v12.syncContactState = false
	v12.lastSteeringAngle = 0
	v12.lastXDrive = 0
	v12.lastSuspensionLength = 0
	v12.additionalMass = 0
	v12.physics = WheelPhysics.new(v12)
	v12.steering = WheelSteering.new(v12)
	v12.destruction = WheelDestruction.new(v12)
	v12.effects = WheelEffects.new(v12)
	v12.debug = WheelDebug.new(v12)
	return v12
end
function Wheel.loadFromXML(p13)
	p13.repr = p13.xmlObject:getValue(".physics#repr", nil, p13.vehicle.components, p13.vehicle.i3dMappings)
	if p13.repr == nil then
		p13.xmlObject:xmlWarning(".physics#repr", "Failed to load wheel! Missing repr node.")
		return false
	end
	if not p13.vehicle:getIsNodeActive(p13.repr) then
		return false
	end
	p13.isLeft = p13.xmlObject:getValue("#isLeft", true)
	p13.rimOffset = p13.xmlObject:getValue("#rimOffset", 0)
	p13.node = p13.vehicle:getParentComponent(p13.repr)
	if p13.node == 0 then
		p13.xmlObject:xmlWarning("", "Invalid repr for wheel. Needs to be a child of a collision!")
		return false
	end
	p13.driveNode = p13.xmlObject:getValue(".physics#driveNode", nil, p13.vehicle.components, p13.vehicle.i3dMappings)
	if p13.driveNode == p13.repr then
		p13.xmlObject:xmlWarning("", "repr and driveNode may not be equal. Using default driveNode instead!")
		p13.driveNode = nil
	end
	p13.linkNode = p13.xmlObject:getValue(".physics#linkNode", nil, p13.vehicle.components, p13.vehicle.i3dMappings)
	if p13.driveNode == nil then
		local v14 = createTransformGroup("wheelReprNode")
		local v15 = getChildIndex(p13.repr)
		link(getParent(p13.repr), v14, v15)
		setTranslation(v14, getTranslation(p13.repr))
		setRotation(v14, getRotation(p13.repr))
		setScale(v14, getScale(p13.repr))
		p13.driveNode = p13.repr
		link(v14, p13.driveNode)
		setTranslation(p13.driveNode, 0, 0, 0)
		setRotation(p13.driveNode, 0, 0, 0)
		setScale(p13.driveNode, 1, 1, 1)
		p13.repr = v14
	end
	if p13.driveNode ~= nil then
		local v16 = createTransformGroup("driveNodeDirectionNode")
		link(p13.repr, v16)
		setWorldTranslation(v16, getWorldTranslation(p13.driveNode))
		setWorldRotation(v16, getWorldRotation(p13.driveNode))
		p13.driveNodeDirectionNode = v16
		local v17, v18, v19 = getRotation(p13.driveNode)
		if math.abs(v17) > 0.0001 or (math.abs(v18) > 0.0001 or math.abs(v19) > 0.0001) then
			p13.xmlObject:xmlWarning("", "Rotation of driveNode \'%s\' is not 0/0/0 in the i3d file (%.1f/%.1f/%.1f).", getName(p13.driveNode), math.deg(v17), math.deg(v18), (math.deg(v19)))
		end
	end
	if p13.linkNode == nil then
		p13.linkNode = p13.driveNode
	end
	p13.transRatio = p13.xmlObject:getValue(".physics#transRatio", 0)
	if not p13.physics:loadFromXML(p13.xmlObject) then
		return false
	end
	if not p13.steering:loadFromXML(p13.xmlObject) then
		return false
	end
	if not p13.destruction:loadFromXML(p13.xmlObject) then
		return false
	end
	if not p13.effects:loadFromXML(p13.xmlObject) then
		return false
	end
	local v20, v21, v22 = getTranslation(p13.repr)
	p13.startPositionX = v20
	p13.startPositionY = v21
	p13.startPositionZ = v22
	local v23, v24, v25 = getTranslation(p13.driveNode)
	p13.driveNodeStartPosX = v23
	p13.driveNodeStartPosY = v24
	p13.driveNodeStartPosZ = v25
	p13.xmlObject:checkDeprecatedXMLElements(".tire#widthOffset", ".tire#offset")
	p13.color = p13.xmlObject:getValue("#color", nil, true)
	p13.material = p13.xmlObject:getValue("#material")
	p13.additionalColor = p13.xmlObject:getValue("#additionalColor", nil, true)
	p13.additionalMaterial = p13.xmlObject:getValue("#additionalMaterial")
	p13.wheelChocks = {}
	local v26 = 0
	while true do
		local v27 = string.format(".wheelChock(%d)", v26)
		local v28, _ = p13.xmlObject:getXMLFileAndPropertyKey(v27)
		if v28 == nil then
			break
		end
		local v29 = WheelChock.new(p13)
		if v29:loadFromXML(p13.xmlObject, v27) then
			local v30 = p13.wheelChocks
			table.insert(v30, v29)
		end
		v26 = v26 + 1
	end
	p13.visualWheels = {}
	local v31 = WheelVisual.new(p13.vehicle, p13, p13.linkNode, p13.isLeft, p13.rimOffset, p13.baseDirectory)
	if v31:loadFromXML(p13.xmlObject) then
		p13.additionalMass = p13.additionalMass + v31:getAdditionalMass()
		local v32 = p13.visualWheels
		table.insert(v32, v31)
	else
		v31:delete()
	end
	local v33 = p13.xmlObject:getValue("#filename")
	local v34 = 0
	while true do
		local v35 = string.format(".additionalWheel(%d)", v34)
		local v36, _ = p13.xmlObject:getXMLFileAndPropertyKey(v35)
		if v36 == nil then
			break
		end
		p13.xmlObject:setXMLLoadKey(v35, v33)
		local v37 = p13.xmlObject:getValue("#isLeft", p13.isLeft)
		local v38 = WheelVisual.new(p13.vehicle, p13, p13.linkNode, v37, 0, p13.baseDirectory)
		if v38:loadFromXML(p13.xmlObject) then
			p13.additionalMass = p13.additionalMass + v38:getAdditionalMass()
			local v39 = p13.visualWheels[#p13.visualWheels]
			if v39 ~= nil then
				v38:setConnectedWheel(v39, p13.rimOffset + p13.xmlObject:getValue("#offset", 0))
			end
			p13.physics:loadAdditionalWheel(p13.xmlObject)
			local v40 = p13.visualWheels
			table.insert(v40, v38)
		else
			v38:delete()
		end
		v34 = v34 + 1
	end
	return true
end
function Wheel.finalize(p41)
	local v42 = (1 / 0)
	local v43 = (-1 / 0)
	for _, v44 in ipairs(p41.visualWheels) do
		local v45, v46 = v44:getWidthAndOffset()
		local v47 = v46 - v45 * 0.5
		v42 = math.min(v42, v47)
		local v48 = v46 + v45 * 0.5
		v43 = math.max(v43, v48)
	end
	if v42 ~= (1 / 0) then
		local v49 = v43 - v42
		local v50 = v42 + v49 * 0.5
		p41.physics:setWheelShapeWidth(v49, v50)
	end
	p41.physics:finalize()
	p41.destruction:finalize()
	p41.effects:finalize()
	if p41.xmlObject ~= nil then
		p41.xmlObject:delete()
		p41.xmlObject = nil
	end
end
function Wheel.postLoad(p51)
	for _, v52 in ipairs(p51.visualWheels) do
		v52:postLoad()
	end
end
function Wheel.delete(p53)
	for _, v54 in ipairs(p53.visualWheels) do
		v54:delete()
	end
	for _, v55 in ipairs(p53.wheelChocks) do
		v55:delete()
	end
	p53.effects:delete()
	p53.debug:delete()
	if p53.xmlObject ~= nil then
		p53.xmlObject:delete()
		p53.xmlObject = nil
	end
end
function Wheel.readStream(p56, p57, p58)
	p56.physics:readStream(p57, p58)
end
function Wheel.writeStream(p59, p60)
	p59.physics:writeStream(p60)
end
function Wheel.update(p61, p62, p63, p64)
	if p61.vehicle.isServer and p61.vehicle.isAddedToPhysics then
		p61.physics:serverUpdate(p62, p63, p64)
	end
	if p61.vehicle.currentUpdateDistance < Wheel.VISUAL_WHEEL_UPDATE_DISTANCE then
		local v65, v66, v67, v68, v69, v70 = p61.physics:getVisualInfo()
		local v71 = v70 - p61.lastSteeringAngle
		local v72
		if math.abs(v71) > Wheel.STEERING_ANGLE_THRESHOLD then
			setRotation(p61.repr, 0, v70, 0)
			p61.lastSteeringAngle = v70
			v72 = true
		else
			v72 = false
		end
		local v73 = v68 - p61.lastXDrive
		if math.abs(v73) > Wheel.STEERING_ANGLE_THRESHOLD then
			setRotation(p61.driveNode, v68, 0, 0)
			p61.lastXDrive = v68
			v72 = true
		end
		local v74 = v69
		for _, v75 in ipairs(p61.visualWheels) do
			v72, v74 = v75:update(v65, v66, v67, v68, v69, v70, v72)
		end
		local v76 = v74 - v69
		local v77 = p61.lastSuspensionLength - v74
		if math.abs(v77) > Wheel.SUSPENSION_THRESHOLD then
			local v78, v79, v80 = localDirectionToLocal(p61.repr, getParent(p61.repr), 0, -1, 0)
			local v81 = v74 * p61.transRatio
			setTranslation(p61.repr, p61.startPositionX + v78 * v81, p61.startPositionY + v79 * v81, p61.startPositionZ + v80 * v81)
			if p61.transRatio < 1 then
				local v82 = v74 * (1 - p61.transRatio)
				setTranslation(p61.driveNode, p61.driveNodeStartPosX + v78 * v82, p61.driveNodeStartPosY + v79 * v82, p61.driveNodeStartPosZ + v80 * v82)
			end
			p61.lastSuspensionLength = v74
			v72 = true
		end
		p61.steering:update(v65, v66, v67, v68, v74, v70, v72)
		if v72 then
			for _, v83 in ipairs(p61.wheelChocks) do
				if not v83.isInParkingPosition then
					v83.wheelRadiusOffset = v76
					v83:update()
				end
			end
		end
		p61.effects:update(p62, p64, p63)
	end
end
function Wheel.clientUpdate(p84, p85, p86)
	p84.physics:clientUpdate(p85, p86)
end
function Wheel.updateTick(p87, p88, p89)
	p87.physics:updateTick(p88, p89)
	p87.effects:updateTick(p88, p89)
end
function Wheel.postUpdate(p90, p91)
	p90.physics:postUpdate(p91)
end
function Wheel.onUpdateEnd(p92, p93)
	p92.effects:onUpdateEnd(p93)
end
function Wheel.onPreAttach(p94)
	for _, v95 in ipairs(p94.wheelChocks) do
		v95:update(true)
	end
end
function Wheel.onPostDetach(p96)
	for _, v97 in ipairs(p96.wheelChocks) do
		v97:update(false)
	end
end
function Wheel.addToPhysics(p98, p99)
	p98.physics:addToPhysics(p99)
end
function Wheel.updatePhysics(p100, p101)
	p100.physics:updatePhysics(p101)
end
function Wheel.removeFromPhysics(p102)
	p102.physics:removeFromPhysics()
end
function Wheel.getMass(p103)
	return p103.physics.mass + p103.additionalMass
end
function Wheel.setSteeringValues(p104, p105, p106, p107, p108, p109)
	p104.physics:setSteeringValues(p105, p106, p107, p108, p109)
	p104.steering:setSteeringValues(p105, p106, p107, p108, p109)
end
function Wheel.setBrakePedal(p110, p111)
	p110.brakePedal = p111
	p110.physics:updatePhysics(p110.vehicle:getBrakeForce() * p110.brakePedal)
end
function Wheel.setIsCareWheel(p112, p113)
	p112.destruction:setIsCareWheel(p113)
end
function Wheel.registerXMLPaths(p114, p115)
	p114:register(XMLValueType.NODE_INDEX, p115 .. ".physics#repr", "Repr node")
	p114:register(XMLValueType.NODE_INDEX, p115 .. ".physics#driveNode", "Drive node")
	p114:register(XMLValueType.NODE_INDEX, p115 .. ".physics#linkNode", "Link node")
	p114:register(XMLValueType.FLOAT, p115 .. ".physics#transRatio", "Suspension translation ratio between repr and drive node (1: repr only, 0: drive node only)", 0)
	p114:register(XMLValueType.COLOR, p115 .. "#color", "Wheel color")
	p114:register(XMLValueType.INT, p115 .. "#material", "Wheel material id")
	p114:register(XMLValueType.COLOR, p115 .. "#additionalColor", "Additional wheel color")
	p114:register(XMLValueType.INT, p115 .. "#additionalMaterial", "Additional wheel material id")
	p114:register(XMLValueType.BOOL, p115 .. "#isLeft", "Is left", true)
	p114:register(XMLValueType.FLOAT, p115 .. "#rimOffset", "Offset that is only applied to the outer rim and the wheel itself, inner rim stays the same.", 0)
	p114:register(XMLValueType.STRING, p115 .. "#filename", "Filename")
	p114:registerAutoCompletionDataSource(p115 .. "#filename", "data/shared/wheels/wheels.xml", "wheels.wheel#filename")
	p114:register(XMLValueType.STRING, p115 .. "#dimensions", "List of dimensions for automatic branded wheel configuration generation")
	p114:register(XMLValueType.STRING, p115 .. "#configId", "Wheel config id", "default")
	WheelPhysics.registerXMLPaths(p114, p115)
	WheelSteering.registerXMLPaths(p114, p115)
	WheelDestruction.registerXMLPaths(p114, p115)
	WheelEffects.registerXMLPaths(p114, p115)
	WheelVisual.registerXMLPaths(p114, p115)
	local v116 = p115 .. ".additionalWheel(?)"
	p114:register(XMLValueType.STRING, v116 .. "#filename", "Filename")
	p114:registerAutoCompletionDataSource(v116 .. "#filename", "data/shared/wheels/wheels.xml", "wheels.wheel#filename")
	p114:register(XMLValueType.BOOL, v116 .. "#isLeft", "Is left", "Same value as parent wheel")
	p114:register(XMLValueType.STRING, v116 .. "#configId", "Wheel config id", "default")
	p114:register(XMLValueType.FLOAT, v116 .. "#offset", "X Offset of additional wheel")
	WheelVisual.registerXMLPaths(p114, v116)
	WheelPhysics.registerAdditionalWheelXMLPaths(p114, v116)
	WheelChock.registerXMLPaths(p114, p115 .. ".wheelChock(?)")
end

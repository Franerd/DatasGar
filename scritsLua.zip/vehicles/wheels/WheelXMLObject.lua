WheelXMLObject = {}
local v_u_1 = Class(WheelXMLObject)
function WheelXMLObject.new(p2, p3, p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = v_u_1
	local v8 = setmetatable({}, v7)
	v8.xmlFile = p2
	v8.baseKey = p3
	v8.configIndex = p4
	v8.baseWheelKey = p5
	v8.wheelKey = p5
	v8.indexToParentIndex = p6
	v8:setXMLLoadKey("")
	return v8
end
function WheelXMLObject.delete(p9)
	if p9.externalXMLFile ~= nil then
		p9.externalXMLFile:delete()
		p9.externalXMLFile = nil
	end
end
function WheelXMLObject.getXMLFileAndKey(p10, p11, p12, p13, p14)
	local v15 = p10.baseKey
	local v16 = p11 - 1
	local v17 = v15 .. "(" .. tostring(v16) .. ")" .. p10.wheelKey .. p12
	if p10.xmlFile:getString(v17) ~= nil then
		return p10.xmlFile, v17
	end
	if p13 ~= nil then
		local v18 = p10.baseKey
		local v19 = p11 - 1
		local v20 = v18 .. "(" .. tostring(v19) .. ")" .. p10.wheelKey .. p13
		if p10.xmlFile:getString(v20) ~= nil then
			return p10.xmlFile, v20
		end
	end
	local v21 = p10.indexToParentIndex[p11]
	if v21 ~= nil then
		return p10:getXMLFileAndKey(v21, p12, p13, p14)
	end
	if p10.externalFilename ~= nil and not p14 then
		if p10.externalXMLFile == nil and not p10:loadExternalXMLFile() then
			return nil
		end
		if p10.externalConfigKey ~= nil then
			local v22 = p10.externalConfigKey .. p12
			if p10.externalXMLFile:getString(v22) ~= nil then
				return p10.externalXMLFile, v22
			end
			if p13 ~= nil then
				local v23 = p10.externalConfigKey .. p13
				if p10.externalXMLFile:getString(v23) ~= nil then
					return p10.externalXMLFile, v23
				end
			end
		end
		local v24 = "wheel.default" .. p12
		if p10.externalXMLFile:getString(v24) ~= nil then
			return p10.externalXMLFile, v24
		end
		if p13 ~= nil then
			local v25 = "wheel.default" .. p13
			if p10.externalXMLFile:getString(v25) ~= nil then
				return p10.externalXMLFile, v25
			end
		end
	end
	return nil
end
function WheelXMLObject.getXMLFileAndPropertyKey(p26, p27, p28)
	local v29 = p28 or p26.configIndex
	local v30 = p26.baseKey
	local v31 = v29 - 1
	local v32 = v30 .. "(" .. tostring(v31) .. ")" .. p26.wheelKey .. p27
	if p26.xmlFile:hasProperty(v32) then
		return p26.xmlFile, v32
	end
	local v33 = p26.indexToParentIndex[v29]
	if v33 ~= nil then
		return p26:getXMLFileAndPropertyKey(p27, v33)
	end
	if p26.externalFilename ~= nil then
		if p26.externalXMLFile == nil and not p26:loadExternalXMLFile() then
			return nil
		end
		if p26.externalConfigKey ~= nil then
			local v34 = p26.externalConfigKey .. p27
			if p26.externalXMLFile:hasProperty(v34) then
				return p26.externalXMLFile, v34
			end
		end
		local v35 = "wheel.default" .. p27
		if p26.externalXMLFile:hasProperty(v35) then
			return p26.externalXMLFile, v35
		end
	end
	return nil
end
function WheelXMLObject.getValue(p36, p37, ...)
	local v38, v39 = p36:getXMLFileAndKey(p36.configIndex, p37)
	if v38 == nil then
		local v40 = p36.baseKey
		local v41 = p36.configIndex - 1
		local v42 = v40 .. "(" .. tostring(v41) .. ")" .. p36.wheelKey .. p37
		return p36.xmlFile:getValue(v42, ...)
	elseif v38:getString(v39) == "-" then
		return nil
	else
		return v38:getValue(v39, ...)
	end
end
function WheelXMLObject.getLocalValue(p43, p44, ...)
	local v45, v46 = p43:getXMLFileAndKey(p43.configIndex, p44, nil, true)
	if v45 == nil then
		local v47 = p43.baseKey
		local v48 = p43.configIndex - 1
		local v49 = v47 .. "(" .. tostring(v48) .. ")" .. p43.wheelKey .. p44
		return p43.xmlFile:getValue(v49, ...)
	elseif v45:getString(v46) == "-" then
		return nil
	else
		return v45:getValue(v46, ...)
	end
end
function WheelXMLObject.getValueAlternative(p50, p51, p52, ...)
	local v53, v54 = p50:getXMLFileAndKey(p50.configIndex, p51, p52)
	if v53 == nil then
		local v55 = p50.baseKey
		local v56 = p50.configIndex - 1
		local v57 = v55 .. "(" .. tostring(v56) .. ")" .. p50.wheelKey .. p51
		return p50.xmlFile:getValue(v57, ...)
	elseif v53:getString(v54) == "-" then
		return nil
	else
		return v53:getValue(v54, ...)
	end
end
function WheelXMLObject.getValueStatic(p58, p59, p60, p61, p62, p63, ...)
	local v64 = p58 - 1
	local v65 = p61 .. "(" .. tostring(v64) .. ")" .. p62 .. p63
	local v66 = p60:getString(v65)
	if v66 == nil then
		local v67 = p59[p58]
		if v67 ~= nil then
			return WheelXMLObject.getValueStatic(v67, p59, p60, p61, p62, p63, ...)
		end
		local v68 = p58 - 1
		return p60:getValue(p61 .. "(" .. tostring(v68) .. ")" .. p62 .. p63, ...)
	elseif v66 == "-" then
		return nil
	else
		return p60:getValue(v65, ...)
	end
end
function WheelXMLObject.xmlWarning(p69, p70, p71, ...)
	local v72 = Logging.xmlWarning
	local v73 = p69.xmlFile
	local v74 = p69.baseKey
	local v75 = p69.configIndex - 1
	v72(v73, p71 .. " (" .. v74 .. "(" .. tostring(v75) .. ")" .. p69.wheelKey .. p70 .. ")", ...)
end
function WheelXMLObject.checkDeprecatedXMLElements(p76, p77, p78)
	local v79 = p76.baseKey
	local v80 = p76.configIndex - 1
	local v81 = v79 .. "(" .. tostring(v80) .. ")" .. p76.wheelKey
	XMLUtil.checkDeprecatedXMLElements(p76.xmlFile, v81 .. p77, v81 .. p78)
end
function WheelXMLObject.setXMLLoadKey(p82, p83, p84)
	p82.wheelKey = p82.baseWheelKey .. p83
	local v85 = p82:getLocalValue("#filename", p84)
	if v85 == nil or v85 == "" then
		if p82.externalXMLFile ~= nil then
			p82.externalXMLFile:delete()
			p82.externalXMLFile = nil
		end
		p82.externalFilename = nil
		p82.externalConfigId = nil
	else
		p82:setExternalFilename(v85, (p82:getLocalValue("#configId", "default")))
	end
end
function WheelXMLObject.setExternalFilename(p86, p87, p88)
	local v89 = Utils.getFilename(p87, p86.baseDirectory)
	if v89 ~= p86.externalFilename or p88 ~= p86.externalConfigId then
		p86.externalFilename = v89
		p86.externalConfigId = p88
		if p86.externalXMLFile ~= nil then
			p86.externalXMLFile:delete()
			p86.externalXMLFile = nil
		end
		p86.externalWheelName = nil
	end
end
function WheelXMLObject.loadExternalXMLFile(p_u_90)
	if p_u_90.externalXMLFile ~= nil then
		p_u_90.externalXMLFile:delete()
		p_u_90.externalXMLFile = nil
	end
	local v_u_91 = XMLFile.load("wheelXML", p_u_90.externalFilename, Wheels.xmlSchema)
	if v_u_91 == nil then
		p_u_90.externalFilename = nil
		p_u_90.externalXMLFile = nil
		p_u_90.externalConfigId = nil
		return false
	else
		p_u_90.externalXMLFile = v_u_91
		p_u_90.externalWheelName = p_u_90.externalXMLFile:getValue("wheel.metadata#name")
		v_u_91:iterate("wheel.configurations.configuration", function(_, p92)
			-- upvalues: (copy) v_u_91, (copy) p_u_90
			if v_u_91:getValue(p92 .. "#id") == p_u_90.externalConfigId then
				p_u_90.externalConfigKey = p92
			end
		end)
		return true
	end
end
WheelXMLObject.wheelMassCache = {}
function WheelXMLObject.cacheWheelMass(p93)
	local v94 = p93:getLocalValue(".physics#mass", nil)
	if v94 ~= nil then
		return v94
	end
	if p93.externalFilename == nil then
		return 0.1
	end
	if WheelXMLObject.wheelMassCache[p93.externalFilename] == nil then
		WheelXMLObject.wheelMassCache[p93.externalFilename] = {}
	end
	local v95 = WheelXMLObject.wheelMassCache[p93.externalFilename][p93.externalConfigId]
	if v95 ~= nil then
		return v95
	end
	local v96 = p93:getValue(".physics#mass", 0.1)
	for v97, _ in pairs(WheelVisual.PARTS) do
		local v98 = 0
		while true do
			local v99 = string.format(".%s(%d)", v97, v98)
			local v100, _ = p93:getXMLFileAndPropertyKey(v99)
			if v100 == nil then
				break
			end
			v96 = v96 + p93:getValue(v99 .. "#mass", 0)
			v98 = v98 + 1
		end
	end
	if p93.externalFilename == nil or p93.externalConfigId == nil then
		return 0
	end
	WheelXMLObject.wheelMassCache[p93.externalFilename][p93.externalConfigId] = v96
	return v96
end

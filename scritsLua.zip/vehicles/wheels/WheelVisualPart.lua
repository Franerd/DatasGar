WheelVisualPart = {}
local v_u_1 = Class(WheelVisualPart)
function WheelVisualPart.new(p2, p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = p5 or v_u_1
	local v7 = setmetatable({}, v6)
	v7.name = p2
	v7.visualWheel = p3
	v7.linkNode = p4
	return v7
end
function WheelVisualPart.delete(p8)
	if p8.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(p8.sharedLoadRequestId)
	end
end
function WheelVisualPart.loadFromXML(p9, p10, p11)
	p9.filename = p10:getValue(p11 .. "#filename")
	if p9.filename == nil then
		return false
	end
	p9.filename = Utils.getFilename(p9.filename, p9.visualWheel.baseDirectory)
	if p9.filename:contains(".xml") then
		local v12 = XMLFile.load("visualPartXML", p9.filename)
		if v12 == nil then
			p10:xmlWarning(p11 .. "#filename", "Unable to load visual wheel part from xml file \'%s\'!", p9.filename)
			return false
		end
		local v13 = v12:getRootName()
		p9.filename = v12:getString(v13 .. ".file#name")
		if p9.filename == nil then
			Logging.xmlError(v12, "Unable to load visual wheel part from xml file. Missing file definition.")
			return false
		end
		p9.filename = Utils.getFilename(p9.filename, p9.visualWheel.baseDirectory)
		if p9.filename == nil then
			Logging.xmlError(v12, "Unable to load visual wheel part from xml file. Unknown i3d file.")
			return false
		end
		if p9.visualWheel.isLeft then
			p9.indexPath = v12:getString(v13 .. ".file#leftNode")
		else
			p9.indexPath = v12:getString(v13 .. ".file#rightNode")
		end
		if p9.indexPath == nil then
			Logging.xmlError(v12, "Unable to load visual wheel part from xml file. Missing node definition.")
			return false
		end
		v12:delete()
	end
	if p9.visualWheel.isLeft then
		p9.indexPath = p10:getValueAlternative(p11 .. "#nodeLeft", p11 .. "#node", p9.indexPath)
	else
		p9.indexPath = p10:getValueAlternative(p11 .. "#nodeRight", p11 .. "#node", p9.indexPath)
	end
	p9.widthAndDiam = p10:getValue(p11 .. "#widthAndDiam", nil, true)
	p9.offset = p10:getValue(p11 .. "#offset", 0)
	p9.scale = p10:getValue(p11 .. "#scale", nil, true)
	p9.mass = p10:getValue(p11 .. "#mass")
	p9.isInverted = p10:getValue(p11 .. "#isInverted", false)
	p9.materials = {}
	local v14 = 0
	while true do
		local v15 = string.format("%s.material(%d)", p11, v14)
		local v16, _ = p10:getXMLFileAndPropertyKey(v15)
		if v16 == nil then
			break
		end
		local v17 = VehicleMaterial.new(p9.visualWheel.baseDirectory)
		if v17:loadFromXML(p10, v15, p9.visualWheel.vehicle.customEnvironment) then
			local v18 = p9.materials
			table.insert(v18, v17)
		end
		v14 = v14 + 1
	end
	local v19 = VehicleMaterial.new(p9.visualWheel.baseDirectory)
	if v19:loadShortFromXML(p10, p11, p9.visualWheel.vehicle.customEnvironment) then
		v19.targetMaterialSlotName = v19.targetMaterialSlotName or p9:getDefaultMaterialSlotName()
		local v20 = p9.materials
		table.insert(v20, v19)
	end
	p9.sharedLoadRequestId = p9.visualWheel.vehicle:loadSubSharedI3DFile(p9.filename, false, false, p9.onPartI3DLoaded, p9)
	return true
end
function WheelVisualPart.postLoad(p21)
	for _, v22 in ipairs(p21.materials) do
		v22:apply(p21.node)
	end
end
function WheelVisualPart.getDefaultMaterialSlotName(p23)
	if p23.name == "innerRim" then
		return "rim_inner_mat"
	end
	if p23.name == "outerRim" then
		return "rim_outer_mat"
	end
	if p23.name == "additional" then
		return "rim_additional_mat"
	end
	if p23.name == "connector" then
		return "rim_bolt_mat"
	end
end
function WheelVisualPart.onPartI3DLoaded(p24, p25, _, _)
	if p25 ~= 0 then
		local v26 = I3DUtil.indexToObject(p25, p24.indexPath)
		if v26 ~= nil then
			p24:setNode(v26)
		end
		delete(p25)
	end
end
function WheelVisualPart.setNode(p27, p28)
	p27.node = p28
	link(p27.linkNode, p27.node)
	local v29 = p27.visualWheel.isLeft and 1 or -1
	setTranslation(p27.node, p27.offset * v29, 0, 0)
	if p27.scale ~= nil then
		setScale(p27.node, p27.scale[1], p27.scale[2], p27.scale[3])
	end
	if p27.widthAndDiam ~= nil then
		if p27:getHasShaderParameterRec(p27.node, "widthAndDiam") then
			p27:setShaderParameterRec(p27.node, "widthAndDiam", p27.widthAndDiam[1], p27.widthAndDiam[2], 0, 0)
		else
			local v30 = MathUtil.inchToM(p27.widthAndDiam[1])
			local v31 = MathUtil.inchToM(p27.widthAndDiam[2])
			setScale(p27.node, v30, v31, v31)
		end
	end
	if p27.isInverted then
		setRotation(p27.node, 0, 0, 3.141592653589793)
	end
end
function WheelVisualPart.setShaderParameterRec(p32, p33, p34, p35, p36, p37, p38)
	if getHasClassId(p33, ClassIds.SHAPE) then
		setShaderParameter(p33, p34, p35, p36, p37, p38, false, -1)
	end
	for v39 = 1, getNumOfChildren(p33) do
		p32:setShaderParameterRec(getChildAt(p33, v39 - 1), p34, p35, p36, p37, p38)
	end
end
function WheelVisualPart.getHasShaderParameterRec(p40, p41, p42)
	if getHasClassId(p41, ClassIds.SHAPE) and getHasShaderParameter(p41, "widthAndDiam") then
		return true
	end
	for v43 = 1, getNumOfChildren(p41) do
		if p40:getHasShaderParameterRec(getChildAt(p41, v43 - 1), p42) then
			return true
		end
	end
	return false
end
function WheelVisualPart.getMass(p44)
	return p44.mass or 0
end
function WheelVisualPart.registerXMLPaths(p45, p46, p47)
	p45:register(XMLValueType.STRING, p46 .. "#filename", p47 .. " - Path to i3d file")
	p45:register(XMLValueType.STRING, p46 .. "#node", p47 .. " - Index in i3d file", "0|0")
	p45:register(XMLValueType.STRING, p46 .. "#nodeLeft", p47 .. " - Left index in i3d file", "0|0")
	p45:register(XMLValueType.STRING, p46 .. "#nodeRight", p47 .. " - Right index in i3d file", "0|0")
	p45:register(XMLValueType.VECTOR_2, p46 .. "#widthAndDiam", p47 .. " - Width and diameter")
	p45:register(XMLValueType.VECTOR_SCALE, p46 .. "#scale", p47 .. " - Scale")
	p45:register(XMLValueType.FLOAT, p46 .. "#offset", p47 .. " - Offset", false)
	p45:register(XMLValueType.FLOAT, p46 .. "#mass", p47 .. " - Mass")
	p45:register(XMLValueType.BOOL, p46 .. "#isInverted", p47 .. " - Node is inverted", false)
	VehicleMaterial.registerXMLPaths(p45, p46 .. ".material(?)")
	VehicleMaterial.registerShortXMLPaths(p45, p46)
end

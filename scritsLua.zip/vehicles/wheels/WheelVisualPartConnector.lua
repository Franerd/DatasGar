WheelVisualPartConnector = {}
local v_u_1 = Class(WheelVisualPartConnector, WheelVisualPart)
function WheelVisualPartConnector.new(p2, p3, p4, _)
	-- upvalues: (copy) v_u_1
	return WheelVisualPart.new(p2, p3, p4, v_u_1)
end
function WheelVisualPartConnector.loadFromXML(p5, p6, p7)
	if not WheelVisualPartConnector:superClass().loadFromXML(p5, p6, p7) then
		return false
	end
	p5.useWidthAndDiam = p6:getValue(p7 .. "#useWidthAndDiam", false)
	p5.usePosAndScale = p6:getValue(p7 .. "#usePosAndScale", false)
	p5.diameter = p6:getValue(p7 .. "#diameter")
	p5.additionalOffset = p6:getValue(p7 .. "#offset", 0)
	p5.width = p6:getValue(p7 .. "#width")
	p5.startPos = p6:getValue(p7 .. "#startPos")
	p5.endPos = p6:getValue(p7 .. "#endPos")
	p5.startPosOffset = p6:getValue(p7 .. "#startPosOffset")
	p5.endPosOffset = p6:getValue(p7 .. "#endPosOffset")
	p5.uniformScale = p6:getValue(p7 .. "#uniformScale")
	return true
end
function WheelVisualPartConnector.setNode(p8, p9)
	WheelVisualPartConnector:superClass().setNode(p8, p9)
	local v10 = p8.visualWheel.connectedVisualWheel
	if v10 ~= nil then
		setTranslation(p9, localToLocal(v10.node, getParent(p9), 0, 0, 0))
		local v11 = p8.visualWheel.connectedVisualWheelOffsetDirection
		local v12 = MathUtil.mToInch(p8.visualWheel.width)
		local v13 = MathUtil.mToInch(p8.visualWheel.connectedVisualWheelOffset)
		local v14 = MathUtil.mToInch(v10.width)
		if p8.useWidthAndDiam then
			local v15 = v11 * ((0.5 * v14 + 0.5 * v13) * 0.0254 + p8.additionalOffset)
			local v16 = p8.diameter or (p8.visualWheel.rimDiameter or 0)
			local v17, v18, v19 = getTranslation(p9)
			setTranslation(p9, v17 + v15, v18, v19)
			p8:setShaderParameterRec(p9, "widthAndDiam", p8.width, v16, nil, nil)
		else
			p8:setShaderParameterRec(p9, "connectorPos", 0, v12 + (p8.startPosOffset or 0), v13 + (p8.endPosOffset or 0), v12)
			p8:setShaderParameterRec(p9, "widthAndDiam", nil, p8.visualWheel.rimDiameter or 0, nil, nil)
		end
		if p8.usePosAndScale then
			p8:setShaderParameterRec(p9, "connectorPosAndScale", p8.startPos, p8.endPos, p8.uniformScale, nil)
		end
	end
end
function WheelVisualPartConnector.registerXMLPaths(p20, p21, p22)
	WheelVisualPart.registerXMLPaths(p20, p21, p22)
	p20:register(XMLValueType.BOOL, p21 .. "#useWidthAndDiam", "Use width and diameter from connector definition", false)
	p20:register(XMLValueType.BOOL, p21 .. "#usePosAndScale", "Use position and scale from connector definition", false)
	p20:register(XMLValueType.FLOAT, p21 .. "#diameter", "Diameter for shader")
	p20:register(XMLValueType.FLOAT, p21 .. "#offset", "Additional connector X offset", 0)
	p20:register(XMLValueType.FLOAT, p21 .. "#width", "Width for shader")
	p20:register(XMLValueType.FLOAT, p21 .. "#startPos", "Start pos for shader")
	p20:register(XMLValueType.FLOAT, p21 .. "#endPos", "End pos for shader")
	p20:register(XMLValueType.FLOAT, p21 .. "#startPosOffset", "Start pos offset for shader (will be added on top if it\'s automatically calculated)")
	p20:register(XMLValueType.FLOAT, p21 .. "#endPosOffset", "End pos offset for shader (will be added on top if it\'s automatically calculated)")
	p20:register(XMLValueType.FLOAT, p21 .. "#uniformScale", "Uniform scale for shader")
end

WheelVisual = {}
source("dataS/scripts/vehicles/wheels/WheelVisualPart.lua")
source("dataS/scripts/vehicles/wheels/WheelVisualPartConnector.lua")
source("dataS/scripts/vehicles/wheels/WheelVisualPartTire.lua")
local v1 = WheelVisual
local v2 = {
	["tire"] = {
		["class"] = WheelVisualPartTire,
		["name"] = "Tire"
	},
	["outerRim"] = {
		["class"] = WheelVisualPart,
		["name"] = "Outer Rim"
	},
	["innerRim"] = {
		["class"] = WheelVisualPart,
		["name"] = "Inner Rim"
	},
	["additional"] = {
		["class"] = WheelVisualPart,
		["name"] = "Additional"
	},
	["connector"] = {
		["class"] = WheelVisualPartConnector,
		["name"] = "Connector"
	}
}
v1.PARTS = v2
local v_u_3 = Class(WheelVisual)
function WheelVisual.new(p4, p5, p6, p7, p8, p9, p10)
	-- upvalues: (copy) v_u_3
	local v11 = p10 or v_u_3
	local v12 = setmetatable({}, v11)
	v12.vehicle = p4
	v12.wheel = p5
	v12.isLeft = p7
	v12.rimOffset = p8
	v12.baseDirectory = p9
	v12.width = 0.5
	v12.radius = 0.5
	v12.mass = 0
	v12.linkNode = p6
	v12.node = createTransformGroup("visualWheel")
	link(p6, v12.node)
	v12.visualParts = {}
	return v12
end
function WheelVisual.delete(p13)
	for _, v14 in ipairs(p13.visualParts) do
		v14:delete()
	end
	p13:removeShallowWaterObstacle()
	delete(p13.node)
end
function WheelVisual.loadFromXML(p15, p16)
	if p16.externalXMLFile ~= nil then
		p15.externalXMLFilename = p16.externalXMLFile.filename
	end
	p15.externalConfigId = p16.externalConfigId
	p15.width = p16:getValue(".physics#width", p15.width)
	p15.radius = p16:getValue(".physics#radius", p15.radius)
	local v17 = p16:getValue(".outerRim(0)#widthAndDiam", nil, true)
	if v17 ~= nil then
		p15.rimDiameter = v17[2]
	end
	local v18 = p16:getValue("#rimMaterialTemplateName")
	if v18 ~= nil then
		local v19 = VehicleMaterial.new()
		if v19:setTemplateName(v18, nil, p15.vehicle.customEnvironment) then
			p15.rimMaterial = v19
		end
	end
	for v20, v21 in pairs(WheelVisual.PARTS) do
		local v22 = 0
		while true do
			local v23 = string.format(".%s(%d)", v20, v22)
			local v24, _ = p16:getXMLFileAndPropertyKey(v23)
			if v24 == nil then
				break
			end
			local v25 = v21.class.new(v20, p15, p15.node)
			if v25:loadFromXML(p16, v23) then
				if v20 ~= "innerRim" and v20 ~= "additional" then
					v25.offset = v25.offset + p15.rimOffset
				end
				local v26 = p15.visualParts
				table.insert(v26, v25)
			end
			v22 = v22 + 1
		end
	end
	return #p15.visualParts > 0
end
function WheelVisual.postLoad(p27)
	for _, v28 in ipairs(p27.visualParts) do
		if p27.rimMaterial ~= nil and (v28.name == "innerRim" or v28.name == "outerRim") then
			p27.rimMaterial:apply(v28.node, v28:getDefaultMaterialSlotName())
		end
		v28:postLoad()
	end
end
function WheelVisual.setConnectedWheel(p29, p30, p31)
	p29.connectedVisualWheel = p30
	p29.connectedVisualWheelOffset = p31
	local v32, _, _ = getTranslation(p30.node)
	local v33 = p31 < 0
	local v34 = p31 + p29.width * 0.5 + p30.width * 0.5
	if not p29.isLeft then
		v34 = -v34
	end
	if v33 then
		v34 = -v34
	end
	p29.connectedVisualWheelOffsetDirection = math.sign(v34)
	setTranslation(p29.node, v32 + v34, 0, 0)
end
function WheelVisual.getWidthAndOffset(p35)
	local v36, _, _ = getTranslation(p35.node)
	for _, v37 in ipairs(p35.visualParts) do
		if v37:isa(WheelVisualPartTire) then
			return p35.width, v36 + (p35.isLeft and v37.offset or -v37.offset)
		end
	end
	return p35.width, v36
end
function WheelVisual.getIsTireInverted(p38)
	for _, v39 in ipairs(p38.visualParts) do
		if v39:isa(WheelVisualPartTire) then
			return p38.isInverted
		end
	end
	return false
end
function WheelVisual.getAdditionalMass(p40)
	local v41 = 0
	for _, v42 in ipairs(p40.visualParts) do
		v41 = v41 + v42:getMass()
	end
	return v41
end
function WheelVisual.update(p43, p44, p45, p46, p47, p48, p49, p50)
	for _, v51 in ipairs(p43.visualParts) do
		if v51.update ~= nil then
			p50, p48 = v51:update(p44, p45, p46, p47, p48, p49, p50)
		end
	end
	return p50, p48
end
function WheelVisual.addShallowWaterObstacle(p52)
	if g_currentMission.shallowWaterSimulation == nil then
		return
	elseif p52.vehicle.propertyState ~= VehiclePropertyState.SHOP_CONFIG then
		if p52.wheel == nil then
			p52.shallowWaterRotationNode = createTransformGroup("shallowWaterRotationNode")
			link(getParent(p52.linkNode), p52.shallowWaterRotationNode)
			setWorldTranslation(p52.shallowWaterRotationNode, getWorldTranslation(p52.node))
			setWorldRotation(p52.shallowWaterRotationNode, getWorldRotation(p52.node))
		else
			p52.shallowWaterRotationNode = p52.wheel.driveNodeDirectionNode
		end
		p52.shallowWaterObstacle = g_currentMission.shallowWaterSimulation:addObstacle(p52.node, p52.width, p52.radius * 2, p52.radius * 1.75, p52.getShallowWaterParameters, p52)
	end
end
function WheelVisual.removeShallowWaterObstacle(p53)
	if p53.shallowWaterObstacle ~= nil then
		g_currentMission.shallowWaterSimulation:removeObstacle(p53.shallowWaterObstacle)
		p53.shallowWaterObstacle = nil
	end
end
function WheelVisual.getShallowWaterParameters(p54)
	local v55 = p54.vehicle.lastSignedSpeed * 1000
	local v56 = 0
	local v57 = 0
	if p54.wheel.physics ~= nil then
		local v58 = p54.wheel.physics.netInfo.slip
		if v58 > 0.1 then
			v56 = math.random() * 2 - 1 * v58
			v57 = math.random() * 2 - 1 * v58
		end
	end
	if v56 == 0 and math.abs(v55) > 0.27 then
		v56 = math.random() * 2 - 1
		v57 = math.random() * 2 - 1
	end
	local v59, _, v60 = localDirectionToWorld(p54.shallowWaterRotationNode, 0, 0, 1)
	local v61 = MathUtil.getYRotationFromDirection(v59, v60)
	local v62 = v59 * v55
	local v63 = v60 * v55
	return v62 + v56, v63 + v57, v61
end
function WheelVisual.registerXMLPaths(p64, p65)
	p64:register(XMLValueType.FLOAT, p65 .. ".physics#radius", "Wheel radius", 0.5)
	p64:register(XMLValueType.FLOAT, p65 .. ".physics#width", "Wheel width", 0.6)
	p64:register(XMLValueType.STRING, p65 .. "#rimMaterialTemplateName", "Material template to apply to the inner and outer rim")
	for v66, v67 in pairs(WheelVisual.PARTS) do
		v67.class.registerXMLPaths(p64, p65 .. "." .. v66 .. "(?)", v67.name)
	end
end

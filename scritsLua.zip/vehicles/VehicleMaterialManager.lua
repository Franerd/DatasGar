VehicleMaterialManager = {}
VehicleMaterialManager.DEFAULT_TEMPLATES_FILENAME = "data/shared/detailLibrary/materialTemplates.xml"
VehicleMaterialManager.DEFAULT_BRAND_TEMPLATES_FILENAME = "data/shared/brandMaterialTemplates.xml"
VehicleMaterialManager.xmlSchema = nil
source("dataS/scripts/vehicles/VehicleMaterial.lua")
local v_u_1 = Class(VehicleMaterialManager, AbstractManager)
function VehicleMaterialManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AbstractManager.new(p2 or v_u_1)
	VehicleMaterialManager.xmlSchema = XMLSchema.new("materialTemplates")
	VehicleMaterialManager.registerXMLPaths(VehicleMaterialManager.xmlSchema, "templates")
	return v3
end
function VehicleMaterialManager.initDataStructures(p4)
	p4.materialTemplates = {}
	p4.materialTemplatesByName = {}
	p4.modMaterialTemplatesToLoad = {}
end
function VehicleMaterialManager.loadMapData(p5, _, _, _)
	p5:loadMaterialTemplates(VehicleMaterialManager.DEFAULT_TEMPLATES_FILENAME)
	p5:loadMaterialTemplates(VehicleMaterialManager.DEFAULT_BRAND_TEMPLATES_FILENAME)
	for v6 = #p5.modMaterialTemplatesToLoad, 1, -1 do
		local v7 = p5.modMaterialTemplatesToLoad[v6]
		local v8 = XMLFile.load("ModFile", v7.xmlFilename, g_modDescSchema)
		if v8 ~= nil then
			p5:loadMaterialTemplatesFromXML(v8, v7.key, v7.baseDirectory, v7.customEnvironment, "metalPainted")
			v8:delete()
		end
		table.remove(p5.modMaterialTemplatesToLoad, v6)
	end
end
function VehicleMaterialManager.addModMaterialTemplatesToLoad(p9, p10, p11, p12, p13)
	local v14 = p9.modMaterialTemplatesToLoad
	table.insert(v14, {
		["xmlFilename"] = p10,
		["key"] = p11,
		["baseDirectory"] = p12,
		["customEnvironment"] = p13
	})
end
function VehicleMaterialManager.loadMaterialTemplates(p15, p16, p17, p18)
	local v19 = XMLFile.load("templates", p16, VehicleMaterialManager.xmlSchema)
	if v19 ~= nil then
		p15:loadMaterialTemplatesFromXML(v19, "templates", p17, p18)
		v19:delete()
	end
end
function VehicleMaterialManager.loadMaterialTemplatesFromXML(p_u_20, p_u_21, p22, p_u_23, p_u_24, p25)
	local v_u_26 = p_u_21:getValue(p22 .. "#parentTemplateDefault", p25)
	p_u_21:iterate(p22 .. ".template", function(_, p27)
		-- upvalues: (copy) p_u_21, (copy) p_u_24, (ref) v_u_26, (copy) p_u_20, (copy) p_u_23
		local v28 = p_u_21:getValue(p27 .. "#name")
		if v28 == nil then
			Logging.xmlWarning(p_u_21, "Missing name attribute for \'%s\'", p27)
			return
		else
			local v29
			if p_u_24 == nil then
				v29 = string.upper(v28)
			else
				v29 = string.upper(p_u_24 .. "." .. v28)
			end
			local v30 = p_u_21:getValue(p27 .. "#parentTemplate", v_u_26)
			local v31
			if v30 == nil then
				v31 = nil
			else
				v31 = p_u_20.materialTemplatesByName[v30:upper()]
				if v31 == nil then
					Logging.xmlWarning(p_u_21, "Unable to find parent template \'%s\' for \'%s\'", v30, p27)
					return
				end
			end
			local v32 = p_u_20.materialTemplatesByName[v29]
			local v33 = v32 == nil and {} or v32
			v33.name = v29
			v33.parentTemplate = v31 or v33
			v33.customEnvironment = p_u_24
			local v34 = p_u_21:getValue(p27 .. "#brand")
			if v34 ~= nil then
				v33.brand = g_brandManager:getBrandByName(v34)
				if v33.brand == nil then
					Logging.xmlWarning(p_u_21, "Unknown brand \'%s\' defined in material template \'%s\'", v34, p27)
				end
			end
			v33.titleL10N = p_u_21:getValue(p27 .. "#title")
			v33.colorScale = p_u_21:getValue(p27 .. "#colorScale", nil, true)
			v33.smoothnessScale = p_u_21:getValue(p27 .. "#smoothnessScale")
			v33.metalnessScale = p_u_21:getValue(p27 .. "#metalnessScale")
			v33.clearCoatSmoothness = p_u_21:getValue(p27 .. "#clearCoatSmoothness")
			v33.clearCoatIntensity = p_u_21:getValue(p27 .. "#clearCoatIntensity")
			v33.porosity = p_u_21:getValue(p27 .. "#porosity")
			v33.detailDiffuse = p_u_21:getValue(p27 .. "#detailDiffuse")
			if v33.detailDiffuse ~= nil then
				v33.detailDiffuse = Utils.getFilename(v33.detailDiffuse, p_u_23)
				if not textureFileExists(v33.detailDiffuse) then
					Logging.xmlWarning(p_u_21, "Unable to find detail texture \'%s\' in \'%s\'", v33.detailDiffuse, p27)
					v33.detailDiffuse = nil
				end
			end
			if v33.detailDiffuse == nil and v33.parentTemplate.detailDiffuse == nil then
				Logging.xmlWarning(p_u_21, "Missing detail diffuse texture for \'%s\'", p27)
				return
			else
				v33.detailNormal = p_u_21:getValue(p27 .. "#detailNormal")
				if v33.detailNormal ~= nil then
					v33.detailNormal = Utils.getFilename(v33.detailNormal, p_u_23)
					if not textureFileExists(v33.detailNormal) then
						Logging.xmlWarning(p_u_21, "Unable to find detail texture \'%s\' in \'%s\'", v33.detailNormal, p27)
						v33.detailNormal = nil
					end
				end
				if v33.detailNormal == nil and v33.parentTemplate.detailNormal == nil then
					Logging.xmlWarning(p_u_21, "Missing detail normal texture for \'%s\'", p27)
					return
				else
					v33.detailSpecular = p_u_21:getValue(p27 .. "#detailSpecular")
					if v33.detailSpecular ~= nil then
						v33.detailSpecular = Utils.getFilename(v33.detailSpecular, p_u_23)
						if not textureFileExists(v33.detailSpecular) then
							Logging.xmlWarning(p_u_21, "Unable to find detail texture \'%s\' in \'%s\'", v33.detailSpecular, p27)
							v33.detailSpecular = nil
						end
					end
					if v33.detailSpecular == nil and v33.parentTemplate.detailSpecular == nil then
						Logging.xmlWarning(p_u_21, "Missing detail specular texture for \'%s\'", p27)
					else
						local v35 = p_u_20.materialTemplates
						table.insert(v35, v33)
						p_u_20.materialTemplatesByName[v29] = v33
					end
				end
			end
		end
	end)
end
function VehicleMaterialManager.getMaterialTemplateByName(p36, p37, p38)
	if p37 == nil then
		return nil
	end
	if p38 ~= nil then
		local v39 = p36.materialTemplatesByName[string.upper(p38 .. "." .. p37)]
		if v39 ~= nil then
			return v39
		end
	end
	return p36.materialTemplatesByName[p37:upper()]
end
function VehicleMaterialManager.getMaterialTemplateColorByName(p40, p41, p42)
	if p41 ~= nil then
		local v43 = p40:getMaterialTemplateByName(p41:upper(), p42)
		if v43 ~= nil and v43.colorScale ~= nil then
			return {
				v43.colorScale[1],
				v43.colorScale[2],
				v43.colorScale[3],
				0
			}
		end
	end
	return nil
end
function VehicleMaterialManager.getMaterialTemplateColorAndTitleByName(p44, p45, p46)
	if p45 ~= nil then
		local v47 = p44:getMaterialTemplateByName(p45:upper(), p46)
		if v47 ~= nil then
			local v48
			if v47.brand == nil then
				v48 = nil
			else
				v48 = v47.brand.title
			end
			if v47.titleL10N ~= nil then
				v48 = (v48 == nil and "" or v48 .. " ") .. g_i18n:convertText(v47.titleL10N, v47.customEnvironment)
			end
			if v47.colorScale == nil then
				return { 1, 1, 1 }, v48
			else
				return table.clone(v47.colorScale), v48
			end
		end
	end
	return nil, nil
end
function VehicleMaterialManager.registerXMLPaths(p49, p50)
	p49:register(XMLValueType.STRING, p50 .. "#id", "File Identifier")
	p49:register(XMLValueType.STRING, p50 .. "#name", "File Name")
	p49:register(XMLValueType.STRING, p50 .. "#parentTemplateDefault", "Name of default parent template")
	p49:register(XMLValueType.STRING, p50 .. "#parentTemplateFilename", "Path to parent template file")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#name", "Name of template")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#title", "Name of the color to display in the shop")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#description", "Descrpition text of the template")
	p49:register(XMLValueType.INT, p50 .. ".template(?)#usage", "Usage of the color")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#parentTemplate", "Name of parent template", "templates#parentTemplateDefault")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#brand", "Brand identifier")
	p49:register(XMLValueType.VECTOR_3, p50 .. ".template(?)#colorScale", "Color values (sRGB)")
	p49:register(XMLValueType.FLOAT, p50 .. ".template(?)#smoothnessScale")
	p49:register(XMLValueType.FLOAT, p50 .. ".template(?)#metalnessScale")
	p49:register(XMLValueType.FLOAT, p50 .. ".template(?)#clearCoatSmoothness")
	p49:register(XMLValueType.FLOAT, p50 .. ".template(?)#clearCoatIntensity")
	p49:register(XMLValueType.FLOAT, p50 .. ".template(?)#porosity")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#category", "Category name (Used by DCC Tool)")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#iconFilename", "Icon filename (Used by DCC Tool)")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#detailDiffuse", "Detail diffuse texture")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#detailNormal", "Detail normal texture")
	p49:register(XMLValueType.STRING, p50 .. ".template(?)#detailSpecular", "Detail specular texture")
	p49:register(XMLValueType.STRING, p50 .. ".template(?).colorScan#filename", "Path to scan reference")
	p49:register(XMLValueType.BOOL, p50 .. ".template(?).colorScan#channelR", "Calibrate red channel", true)
	p49:register(XMLValueType.BOOL, p50 .. ".template(?).colorScan#channelG", "Calibrate green channel", true)
	p49:register(XMLValueType.BOOL, p50 .. ".template(?).colorScan#channelB", "Calibrate blue channel", true)
	p49:register(XMLValueType.BOOL, p50 .. ".template(?).colorScan#channelSmoothness", "Calibrate smoothness", true)
	p49:register(XMLValueType.BOOL, p50 .. ".template(?).colorScan#channelMetalness", "Calibrate metalness", true)
end
g_vehicleMaterialManager = VehicleMaterialManager.new()

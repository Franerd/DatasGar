VehicleAttachRequestEvent = {}
local v_u_1 = Class(VehicleAttachRequestEvent, Event)
InitStaticEventClass(VehicleAttachRequestEvent, "VehicleAttachRequestEvent")
function VehicleAttachRequestEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleAttachRequestEvent.new(p2)
	local v3 = VehicleAttachRequestEvent.emptyNew()
	v3.attacherVehicle = p2.attacherVehicle
	v3.attachable = p2.attachable
	v3.attacherVehicleJointDescIndex = p2.attacherVehicleJointDescIndex
	v3.attachableJointDescIndex = p2.attachableJointDescIndex
	return v3
end
function VehicleAttachRequestEvent.readStream(p4, p5, p6)
	p4.attacherVehicle = NetworkUtil.readNodeObject(p5)
	p4.attachable = NetworkUtil.readNodeObject(p5)
	p4.attacherVehicleJointDescIndex = streamReadUIntN(p5, 7)
	p4.attachableJointDescIndex = streamReadUIntN(p5, 7)
	p4:run(p6)
end
function VehicleAttachRequestEvent.writeStream(p7, p8, _)
	NetworkUtil.writeNodeObject(p8, p7.attacherVehicle)
	NetworkUtil.writeNodeObject(p8, p7.attachable)
	streamWriteUIntN(p8, p7.attacherVehicleJointDescIndex, 7)
	streamWriteUIntN(p8, p7.attachableJointDescIndex, 7)
end
function VehicleAttachRequestEvent.run(p9, p10)
	if not p10:getIsServer() and (p9.attacherVehicle ~= nil and p9.attacherVehicle:getIsSynchronized()) then
		p9.attacherVehicle:attachImplementFromInfo(p9)
	end
end

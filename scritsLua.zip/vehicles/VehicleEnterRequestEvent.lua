VehicleEnterRequestEvent = {}
local v_u_1 = Class(VehicleEnterRequestEvent, Event)
InitStaticEventClass(VehicleEnterRequestEvent, "VehicleEnterRequestEvent")
function VehicleEnterRequestEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1, NetworkNode.CHANNEL_MAIN)
end
function VehicleEnterRequestEvent.new(p2, p3, p4, p5)
	local v6 = VehicleEnterRequestEvent.emptyNew()
	v6.object = p2
	v6.objectId = NetworkUtil.getObjectId(v6.object)
	v6.farmId = p4
	v6.playerStyle = p3
	v6.force = Utils.getNoNil(p5, false)
	return v6
end
function VehicleEnterRequestEvent.writeStream(p7, p8, p9)
	NetworkUtil.writeNodeObjectId(p8, p7.objectId)
	streamWriteUIntN(p8, p7.farmId, FarmManager.FARM_ID_SEND_NUM_BITS)
	p7.playerStyle:writeStream(p8, p9)
	streamWriteBool(p8, p7.force)
end
function VehicleEnterRequestEvent.readStream(p10, p11, p12)
	p10.objectId = NetworkUtil.readNodeObjectId(p11)
	p10.farmId = streamReadUIntN(p11, FarmManager.FARM_ID_SEND_NUM_BITS)
	if p10.playerStyle == nil then
		p10.playerStyle = PlayerStyle.new()
	end
	p10.playerStyle:readStream(p11, p12)
	p10.force = streamReadBool(p11)
	p10.object = NetworkUtil.getObject(p10.objectId)
	p10:run(p12)
end
function VehicleEnterRequestEvent.run(p13, p14)
	if p13.object == nil or not p13.object:getIsSynchronized() then
		return
	elseif p13.force or g_server:hasGhostObject(p14, p13.object) then
		local v15 = p13.object.spec_enterable
		if v15 ~= nil and not v15.isControlled then
			local v16 = g_currentMission.userManager:getUserIdByConnection(p14)
			p13.object:setOwnerConnection(p14)
			p13.object.controllerFarmId = p13.farmId
			p13.object.controllerUserId = v16
			g_server:broadcastEvent(VehicleEnterResponseEvent.new(p13.objectId, false, p13.playerStyle, p13.farmId, v16), true, p14)
			p14:sendEvent(VehicleEnterResponseEvent.new(p13.objectId, true, p13.playerStyle, p13.farmId, v16))
		end
	else
		Logging.warning("Vehicle %q is not fully synchronized to on client", p13.object.configFileName)
		return
	end
end

TireTrackSystem = {}
local v_u_1 = Class(TireTrackSystem)
TireTrackSystem.maxNumTracks = 512
TireTrackSystem.maxNumSegments = 4096
TireTrackSystem.atlasSize = 32
function TireTrackSystem.onCreateTireTrackSystem(_, p2)
	if g_currentMission.tireTrackSystem == nil then
		local v3 = TireTrackSystem.new()
		if v3:load(p2) then
			g_currentMission.tireTrackSystem = v3
		else
			v3:delete()
		end
	else
		return
	end
end
function TireTrackSystem.new(p4)
	-- upvalues: (copy) v_u_1
	local v5 = p4 or v_u_1
	local v6 = setmetatable({}, v5)
	v6.tireTrackSystemId = 0
	return v6
end
function TireTrackSystem.load(p7, p8)
	p7.tireTrackSystemId = createTyreTrackSystem(getRootNode(), p8, TireTrackSystem.maxNumTracks, TireTrackSystem.maxNumSegments, TireTrackSystem.atlasSize, g_terrainNode)
	if g_addTestCommands then
		addConsoleCommand("gsTireTracksRemoveAll", "Remove all tire tracks from terrain", "TireTrackSystem.consoleCommandRemoveAllTireTracks", nil)
		addConsoleCommand("gsTireTracksDebug", "Toggle tire track debug mode with permanently active and colored tracks", "TireTrackSystem.consoleCommandTireTrackDebug", nil)
	end
	return p7.tireTrackSystemId ~= 0
end
function TireTrackSystem.delete(p9)
	if p9.tireTrackSystemId ~= 0 then
		delete(p9.tireTrackSystemId)
	end
	removeConsoleCommand("gsTireTracksRemoveAll")
	removeConsoleCommand("gsTireTracksDebug")
end
function TireTrackSystem.createTrack(p10, p11, p12)
	return createTrack(p10.tireTrackSystemId, p11, p12)
end
function TireTrackSystem.destroyTrack(p13, p14)
	destroyTrack(p13.tireTrackSystemId, p14)
end
function TireTrackSystem.addTrackPoint(p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30)
	addTrackPoint(p15.tireTrackSystemId, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30)
end
function TireTrackSystem.cutTrack(p31, p32)
	cutTrack(p31.tireTrackSystemId, p32)
end
function TireTrackSystem.eraseParallelogram(p33, p34, p35, p36, p37, p38, p39)
	eraseParallelogram(p33.tireTrackSystemId, p34, p35, p36, p37, p38, p39)
end
function TireTrackSystem.erasePolygon(p40, p41)
	erasePolygon(p40.tireTrackSystemId, p41)
end
function TireTrackSystem.consoleCommandRemoveAllTireTracks(_)
	if g_currentMission.tireTrackSystem ~= nil then
		local v42 = g_currentMission.terrainSize / 2 + 1
		g_currentMission.tireTrackSystem:eraseParallelogram(-v42, -v42, v42, -v42, -v42, v42)
		executeConsoleCommand("vtRedrawAll")
		return "Removed all tiretracks!"
	end
	printError("Error: no tireTrackSystem found!")
end
function TireTrackSystem.consoleCommandTireTrackDebug(p_u_43)
	if g_currentMission.tireTrackSystem == nil then
		return "Error: no tireTrackSystem found!"
	elseif p_u_43.addTrackPointFuncBackup == nil then
		p_u_43.addTrackPointFuncBackup = addTrackPoint
		function addTrackPoint(p44, p45, p46, p47, p48, p49, p50, p51, _, _, _, p52, p53, p54, p55, p56)
			-- upvalues: (copy) p_u_43
			local v57, v58, v59 = DebugUtil.getDebugColor(p45):unpack()
			p_u_43.addTrackPointFuncBackup(p44, p45, p46, p47, p48, p49, p50, p51, v57, v58, v59, p52, p53, p54, p55, p56)
		end
		return "Enabled TireTrack debug"
	else
		addTrackPoint = p_u_43.addTrackPointFuncBackup
		p_u_43.addTrackPointFuncBackup = nil
		return "Disabled TireTrack debug"
	end
end

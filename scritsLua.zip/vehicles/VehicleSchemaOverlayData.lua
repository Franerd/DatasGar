VehicleSchemaOverlayData = {}
local v_u_1 = Class(VehicleSchemaOverlayData)
function VehicleSchemaOverlayData.new(p2, p3, p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = v_u_1
	local v8 = setmetatable({}, v7)
	v8.offsetX = p2 or 0
	v8.offsetY = p3 or 0
	v8.schemaName = p4
	v8.invisibleBorderRight = p5 or 0.05
	v8.invisibleBorderLeft = p6 or 0.05
	v8.attacherJoints = nil
	return v8
end
function VehicleSchemaOverlayData.addAttacherJoint(p9, p10, p11, p12, p13, p14, p15)
	if not p9.attacherJoints then
		p9.attacherJoints = {}
	end
	local v16 = p9.attacherJoints
	table.insert(v16, {
		["x"] = p10 or 0,
		["y"] = p11 or 0,
		["rotation"] = p12 or 0,
		["invertX"] = p13 and true or false,
		["liftedOffsetX"] = p14 or 0,
		["liftedOffsetY"] = p15 or 5
	})
end
VehicleSchemaOverlayData.SCHEMA_OVERLAY = {}
VehicleSchemaOverlayData.SCHEMA_OVERLAY.VEHICLE = "VEHICLE"
VehicleSchemaOverlayData.SCHEMA_OVERLAY.HARVESTER = "HARVESTER"
VehicleSchemaOverlayData.SCHEMA_OVERLAY.TRUCK = "TRUCK"
VehicleSchemaOverlayData.SCHEMA_OVERLAY.CAR = "CAR"
VehicleSchemaOverlayData.SCHEMA_OVERLAY.LOADER = "LOADER"
VehicleSchemaOverlayData.SCHEMA_OVERLAY.IMPLEMENT = "IMPLEMENT"
VehicleSchemaOverlayData.SCHEMA_OVERLAY.TRAILER = "TRAILER"
VehicleSchemaOverlayData.SCHEMA_OVERLAY.COMBINE_HEADER = "COMBINE_HEADER"
VehicleSchemaOverlayData.SCHEMA_OVERLAY.FRONTLOADER = "FRONTLOADER"

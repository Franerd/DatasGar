VehicleEnterResponseEvent = {}
local v_u_1 = Class(VehicleEnterResponseEvent, Event)
InitStaticEventClass(VehicleEnterResponseEvent, "VehicleEnterResponseEvent")
function VehicleEnterResponseEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1, NetworkNode.CHANNEL_MAIN)
end
function VehicleEnterResponseEvent.new(p2, p3, p4, p5, p6)
	local v7 = VehicleEnterResponseEvent.emptyNew()
	v7.id = p2
	v7.isOwner = p3
	v7.playerStyle = p4
	v7.farmId = p5
	v7.userId = p6
	return v7
end
function VehicleEnterResponseEvent.readStream(p8, p9, p10)
	p8.id = NetworkUtil.readNodeObjectId(p9)
	p8.isOwner = streamReadBool(p9)
	if p8.playerStyle == nil then
		p8.playerStyle = PlayerStyle.new()
	end
	p8.playerStyle:readStream(p9, p10)
	p8.farmId = streamReadUIntN(p9, FarmManager.FARM_ID_SEND_NUM_BITS)
	p8.userId = User.streamReadUserId(p9)
	p8:run(p10)
end
function VehicleEnterResponseEvent.writeStream(p11, p12, p13)
	NetworkUtil.writeNodeObjectId(p12, p11.id)
	streamWriteBool(p12, p11.isOwner)
	p11.playerStyle:writeStream(p12, p13)
	streamWriteUIntN(p12, p11.farmId, FarmManager.FARM_ID_SEND_NUM_BITS)
	User.streamWriteUserId(p12, p11.userId)
end
function VehicleEnterResponseEvent.run(p14, _)
	local v15 = NetworkUtil.getObject(p14.id)
	if v15 ~= nil and v15:getIsSynchronized() then
		g_currentMission.playerSystem:getPlayerByUserId(p14.userId):onEnterVehicle(v15)
	end
end

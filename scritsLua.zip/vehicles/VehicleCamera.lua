VehicleCamera = {}
local v_u_1 = Class(VehicleCamera)
VehicleCamera.doCameraSmoothing = false
VehicleCamera.raycastMask = CollisionFlag.TERRAIN + CollisionFlag.CAMERA_BLOCKING + CollisionFlag.WATER
function VehicleCamera.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.vehicle = p2
	v5.isActivated = false
	v5.limitRotXDelta = 0
	v5.cameraNode = nil
	v5.raycastDistance = 0
	v5.normalX = 0
	v5.normalY = 0
	v5.normalZ = 0
	v5.raycastNodes = {}
	v5.disableCollisionTime = -1
	v5.lookAtPosition = { 0, 0, 0 }
	v5.lookAtLastTargetPosition = { 0, 0, 0 }
	v5.position = { 0, 0, 0 }
	v5.lastTargetPosition = { 0, 0, 0 }
	v5.upVector = { 0, 0, 0 }
	v5.lastUpVector = { 0, 0, 0 }
	v5.lastInputValues = {}
	v5.lastInputValues.upDown = 0
	v5.lastInputValues.leftRight = 0
	v5.isCollisionEnabled = true
	if g_modIsLoaded.FS22_disableVehicleCameraCollision or g_isDevelopmentVersion then
		v5.isCollisionEnabled = g_gameSettings:getValue(GameSettings.SETTING.CAMERA_CHECK_COLLISION)
		g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.CAMERA_CHECK_COLLISION], v5.onCameraCollisionDetectionSettingChanged, v5)
	end
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.ACTIVE_SUSPENSION_CAMERA], v5.onActiveCameraSuspensionSettingChanged, v5)
	return v5
end
function VehicleCamera.loadFromXML(p_u_6, p7, p8, p9, p10)
	XMLUtil.checkDeprecatedXMLElements(p7, p_u_6.vehicle.configFileName, p8 .. "#index", "#node")
	p_u_6.cameraNode = p7:getValue(p8 .. "#node", nil, p_u_6.vehicle.components, p_u_6.vehicle.i3dMappings)
	if p_u_6.cameraNode == nil or not getHasClassId(p_u_6.cameraNode, ClassIds.CAMERA) then
		Logging.xmlWarning(p7, "Invalid camera node for camera \'%s\'. Must be a camera type!", p8)
		return false
	end
	p_u_6.shadowFocusBoxNode = p7:getValue(p8 .. "#shadowFocusBox", nil, p_u_6.vehicle.components, p_u_6.vehicle.i3dMappings)
	if p_u_6.shadowFocusBoxNode ~= nil and not (getHasClassId(p_u_6.shadowFocusBoxNode, ClassIds.SHAPE) and getShapeIsCPUMesh(p_u_6.shadowFocusBoxNode)) then
		Logging.xmlWarning(p7, "Invalid camera shadow focus box \'%s\'. Must be a shape and cpu mesh", getName(p_u_6.shadowFocusBoxNode))
		p_u_6.shadowFocusBoxNode = nil
	end
	if Platform.gameplay.hasShadowFocusBox then
		if p_u_6.isInside and p_u_6.shadowFocusBoxNode == nil then
			Logging.xmlDevWarning(p7, "Missing shadow focus box for indoor camera \'%s\'", p8)
		end
	elseif p_u_6.shadowFocusBoxNode ~= nil then
		Logging.xmlDevWarning(p7, "Shadow focus box for camera \'%s\' not allowed on this platform", p8)
		p_u_6.shadowFocusBoxNode = nil
	end
	p_u_6.isInside = p7:getValue(p8 .. "#isInside", false)
	p_u_6.allowHeadTracking = p7:getValue(p8 .. "#allowHeadTracking", p_u_6.isInside)
	p_u_6.useOutdoorSounds = p7:getValue(p8 .. "#useOutdoorSounds", not p_u_6.isInside)
	local v11 = p_u_6.isInside
	local v12
	if p_u_6.isInside then
		v12 = nil
	else
		v12 = g_depthOfFieldManager:createInfo(0.5, 1, 0.3, 400, 1400, false)
	end
	g_cameraManager:addCamera(p_u_6.cameraNode, p_u_6.shadowFocusBoxNode, false, v11, v12)
	if p_u_6.isInside then
		p_u_6.collisionNodes = {}
		I3DUtil.iterateRecursively(p_u_6.vehicle.rootNode, function(p13)
			-- upvalues: (copy) p_u_6
			if getHasClassId(p13, ClassIds.SHAPE) and (getRigidBodyType(p13) ~= RigidBodyType.NONE or getIsCompoundChild(p13)) then
				local v14 = getCollisionFilterGroup(p13)
				local v15 = CollisionFlag.VEHICLE
				if bit32.btest(v14, v15) then
					local v16 = p_u_6.collisionNodes
					table.insert(v16, p13)
				end
			end
		end, true)
	end
	p_u_6.fovY = calculateFovY(p_u_6.cameraNode)
	setFovY(p_u_6.cameraNode, p_u_6.fovY)
	p_u_6.isRotatable = p7:getValue(p8 .. "#rotatable", false)
	p_u_6.limit = p7:getValue(p8 .. "#limit", false)
	if p_u_6.limit then
		p_u_6.rotMinX = p7:getValue(p8 .. "#rotMinX")
		p_u_6.rotMaxX = p7:getValue(p8 .. "#rotMaxX")
		p_u_6.transMin = p7:getValue(p8 .. "#transMin")
		p_u_6.transMax = p7:getValue(p8 .. "#transMax")
		if p_u_6.transMax ~= nil then
			local v17 = p_u_6.transMin
			local v18 = p_u_6.transMax * Platform.gameplay.maxCameraZoomFactor
			p_u_6.transMax = math.max(v17, v18)
		end
		if p_u_6.rotMinX == nil or (p_u_6.rotMaxX == nil or (p_u_6.transMin == nil or p_u_6.transMax == nil)) then
			Logging.xmlWarning(p7, "Missing \'rotMinX\', \'rotMaxX\', \'transMin\' or \'transMax\' for camera \'%s\'", p8)
			return false
		end
	end
	if p_u_6.isRotatable then
		p_u_6.rotateNode = p7:getValue(p8 .. "#rotateNode", nil, p_u_6.vehicle.components, p_u_6.vehicle.i3dMappings)
		p_u_6.hasExtraRotationNode = p_u_6.rotateNode ~= nil
	end
	local v19 = p7:getValue(p8 .. "#rotation", nil, true)
	if v19 ~= nil then
		local v20 = p_u_6.cameraNode
		if p_u_6.rotateNode ~= nil then
			v20 = p_u_6.rotateNode
		end
		setRotation(v20, unpack(v19))
	end
	local v21 = p7:getValue(p8 .. "#translation", nil, true)
	if v21 ~= nil then
		setTranslation(p_u_6.cameraNode, unpack(v21))
	end
	local v22
	if p_u_6.rotateNode == nil then
		v22 = false
	else
		v22 = p_u_6.rotateNode ~= p_u_6.cameraNode
	end
	p_u_6.allowTranslation = v22
	p_u_6.useMirror = p7:getValue(p8 .. "#useMirror", false)
	p_u_6.useWorldXZRotation = p7:getValue(p8 .. "#useWorldXZRotation")
	p_u_6.resetCameraOnVehicleSwitch = p7:getValue(p8 .. "#resetCameraOnVehicleSwitch")
	p_u_6.suspensionNodeIndex = p7:getValue(p8 .. "#suspensionNodeIndex")
	if not Platform.gameplay.useWorldCameraInside and p_u_6.isInside or not (Platform.gameplay.useWorldCameraOutside or p_u_6.isInside) then
		p_u_6.useWorldXZRotation = false
	end
	p_u_6.positionSmoothingParameter = 0
	p_u_6.lookAtSmoothingParameter = 0
	if p7:getValue(p8 .. "#useDefaultPositionSmoothing", true) then
		if p_u_6.isInside then
			p_u_6.positionSmoothingParameter = 0.128
			p_u_6.lookAtSmoothingParameter = 0.176
		else
			p_u_6.positionSmoothingParameter = 0.016
			p_u_6.lookAtSmoothingParameter = 0.022
		end
	end
	p_u_6.positionSmoothingParameter = p7:getValue(p8 .. "#positionSmoothingParameter", p_u_6.positionSmoothingParameter)
	p_u_6.lookAtSmoothingParameter = p7:getValue(p8 .. "#lookAtSmoothingParameter", p_u_6.lookAtSmoothingParameter)
	local v23 = g_gameSettings:getValue(GameSettings.SETTING.IS_HEAD_TRACKING_ENABLED) and isHeadTrackingAvailable()
	if v23 then
		v23 = p_u_6.allowHeadTracking
	end
	if v23 then
		p_u_6.positionSmoothingParameter = 0
		p_u_6.lookAtSmoothingParameter = 0
	end
	p_u_6.cameraPositionNode = p_u_6.cameraNode
	if p_u_6.positionSmoothingParameter > 0 then
		p_u_6.cameraPositionNode = createTransformGroup("cameraPositionNode")
		local v24 = getChildIndex(p_u_6.cameraNode)
		link(getParent(p_u_6.cameraNode), p_u_6.cameraPositionNode, v24)
		local v25, v26, v27 = getTranslation(p_u_6.cameraNode)
		local v28, v29, v30 = getRotation(p_u_6.cameraNode)
		setTranslation(p_u_6.cameraPositionNode, v25, v26, v27)
		setRotation(p_u_6.cameraPositionNode, v28, v29, v30)
		p_u_6.cameraWorldParent = createTransformGroup("cameraWorldParent")
		link(p_u_6.cameraWorldParent, p_u_6.cameraNode)
	end
	p_u_6.rotYSteeringRotSpeed = p7:getValue(p8 .. "#rotYSteeringRotSpeed", 0)
	if p_u_6.rotateNode == nil or p_u_6.rotateNode == p_u_6.cameraNode then
		p_u_6.rotateNode = p_u_6.cameraPositionNode
	end
	if v23 then
		local v31, _, v32 = localDirectionToLocal(p_u_6.cameraPositionNode, getParent(p_u_6.cameraPositionNode), 0, 0, 1)
		local v33, v34, v35 = localToLocal(p_u_6.cameraPositionNode, getParent(p_u_6.cameraPositionNode), 0, 0, 0)
		p_u_6.headTrackingNode = createTransformGroup("headTrackingNode")
		link(getParent(p_u_6.cameraPositionNode), p_u_6.headTrackingNode)
		setTranslation(p_u_6.headTrackingNode, v33, v34, v35)
		if math.abs(v31) + math.abs(v32) > 0.0001 then
			setDirection(p_u_6.headTrackingNode, v31, 0, v32, 0, 1, 0)
		else
			setRotation(p_u_6.headTrackingNode, 0, 0, 0)
		end
	end
	local v36, v37, v38 = getRotation(p_u_6.rotateNode)
	p_u_6.origRotX = v36
	p_u_6.origRotY = v37
	p_u_6.origRotZ = v38
	p_u_6.rotX = p_u_6.origRotX
	p_u_6.rotY = p_u_6.origRotY
	p_u_6.rotZ = p_u_6.origRotZ
	local v39, v40, v41 = getTranslation(p_u_6.cameraPositionNode)
	p_u_6.origTransX = v39
	p_u_6.origTransY = v40
	p_u_6.origTransZ = v41
	p_u_6.transX = p_u_6.origTransX
	p_u_6.transY = p_u_6.origTransY
	p_u_6.transZ = p_u_6.origTransZ
	local v42 = MathUtil.vector3Length(p_u_6.origTransX, p_u_6.origTransY, p_u_6.origTransZ) + 0.00001
	p_u_6.zoom = v42
	p_u_6.zoomTarget = v42
	p_u_6.zoomDefault = v42
	p_u_6.zoomLimitedTarget = -1
	local v43 = 1 / v42
	p_u_6.transDirX = v43 * p_u_6.origTransX
	p_u_6.transDirY = v43 * p_u_6.origTransY
	p_u_6.transDirZ = v43 * p_u_6.origTransZ
	if p_u_6.allowTranslation and v42 <= 0.01 then
		Logging.xmlWarning(p7, "Invalid camera translation for camera \'%s\'. Distance needs to be bigger than 0.01", p8)
	end
	local v44 = p_u_6.raycastNodes
	local v45 = p_u_6.rotateNode
	table.insert(v44, v45)
	for _, v46 in p7:iterator(p8 .. ".raycastNode") do
		XMLUtil.checkDeprecatedXMLElements(p7, p_u_6.vehicle.configFileName, v46 .. "#index", v46 .. "#node")
		local v47 = p7:getValue(v46 .. "#node", nil, p_u_6.vehicle.components, p_u_6.vehicle.i3dMappings)
		if v47 ~= nil then
			local v48 = p_u_6.raycastNodes
			table.insert(v48, v47)
		end
	end
	local v49, v50, v51 = getScale(p_u_6.cameraNode)
	if v49 ~= 1 or (v50 ~= 1 or v51 ~= 1) then
		Logging.xmlWarning(p7, "Vehicle camera with scale found for camera \'%s\'. Resetting to scale 1", p8)
		setScale(p_u_6.cameraNode, 1, 1, 1)
	end
	p_u_6.changeObjects = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p7, p8, p_u_6.changeObjects, p_u_6.vehicle.components, p_u_6.vehicle)
	ObjectChangeUtil.setObjectChanges(p_u_6.changeObjects, false, p_u_6.vehicle, p_u_6.vehicle.setMovingToolDirty)
	if (not g_gameSettings:getValue(GameSettings.SETTING.RESET_CAMERA) or g_currentMission.vehicleSystem.isReloadRunning) and (p9 ~= nil and not p9.resetVehicles) then
		local v52 = string.format(p9.key .. ".enterable.camera(%d)", p10)
		if p9.xmlFile:hasProperty(v52) then
			local v53, v54, v55 = p9.xmlFile:getValue(v52 .. "#rotation", { p_u_6.rotX, p_u_6.rotY, p_u_6.rotZ })
			if not (MathUtil.isNan(v53) or (MathUtil.isNan(v54) or MathUtil.isNan(v55))) then
				p_u_6.rotX = v53
				p_u_6.rotY = v54
				p_u_6.rotZ = v55
				if p_u_6.allowTranslation then
					local v56, v57, v58 = p9.xmlFile:getValue(v52 .. "#translation", { p_u_6.transX, p_u_6.transY, p_u_6.transZ })
					p_u_6.transX = v56
					p_u_6.transY = v57
					p_u_6.transZ = v58
					p_u_6.zoom = p9.xmlFile:getValue(v52 .. "#zoom", p_u_6.zoom)
					p_u_6.zoomTarget = p_u_6.zoom
				end
				setTranslation(p_u_6.cameraPositionNode, p_u_6.transX, p_u_6.transY, p_u_6.transZ)
				setRotation(p_u_6.rotateNode, p_u_6.rotX, p_u_6.rotY, p_u_6.rotZ)
				if g_currentMission.vehicleSystem.isReloadRunning then
					local v59 = p9.xmlFile:getValue(v52 .. "#fovY")
					if v59 ~= nil then
						setFovY(p_u_6.cameraNode, v59)
					end
				end
				p_u_6.lodDebugModeLoaded = p9.xmlFile:getValue(v52 .. "#lodDebugActive", false)
				if p_u_6.lodDebugModeLoaded then
					p_u_6.loadDebugZoom = p9.xmlFile:getValue(v52 .. "#lodDebugZoom", p_u_6.zoom)
				end
			end
		end
	end
	return true
end
function VehicleCamera.onPostLoad(p60, _)
	p60.suspensionNode = nil
	if p60.suspensionNodeIndex ~= nil and p60.vehicle.getSuspensionNodeFromIndex ~= nil then
		p60.suspensionNode = p60.vehicle:getSuspensionNodeFromIndex(p60.suspensionNodeIndex)
		if p60.suspensionNode == nil then
			Logging.warning("Vehicle Camera \'%s\' with invalid suspensionIndex \'%s\' found.", getName(p60.cameraNode), p60.suspensionNodeIndex)
		end
	end
	if p60.suspensionNode ~= nil then
		if p60.suspensionNode.node ~= nil then
			p60.cameraSuspensionParentNode = createTransformGroup("cameraSuspensionParentNode")
			link(p60.suspensionNode.node, p60.cameraSuspensionParentNode)
			setWorldTranslation(p60.cameraSuspensionParentNode, getWorldTranslation(getParent(p60.cameraPositionNode)))
			setWorldQuaternion(p60.cameraSuspensionParentNode, getWorldQuaternion(getParent(p60.cameraPositionNode)))
			p60.cameraBaseParentNode = getParent(p60.cameraPositionNode)
			p60.lastActiveCameraSuspensionSetting = false
			return
		end
		Logging.warning("Vehicle Camera \'%s\' with invalid suspensionIndex \'%s\' found. CharacterTorso suspensions are not allowed.", getName(p60.cameraNode), p60.suspensionNodeIndex)
		p60.suspensionNode = nil
	end
end
function VehicleCamera.saveToXMLFile(p61, p62, p63, _)
	p62:setValue(p63 .. "#rotation", p61.rotX, p61.rotY, p61.rotZ)
	p62:setValue(p63 .. "#translation", p61.transX, p61.transY, p61.transZ)
	p62:setValue(p63 .. "#zoom", p61.zoom)
	p62:setValue(p63 .. "#fovY", getFovY(p61.cameraNode))
	if p61.lodDebugMode then
		p62:setValue(p63 .. "#lodDebugActive", true)
		p62:setValue(p63 .. "#lodDebugZoom", p61.loadDebugZoom)
	end
end
function VehicleCamera.delete(p64)
	g_cameraManager:removeCamera(p64.cameraNode)
	p64:onDeactivate()
	if p64.cameraNode ~= nil and p64.positionSmoothingParameter > 0 then
		delete(p64.cameraNode)
		p64.cameraNode = nil
	end
	if p64.cameraWorldParent ~= nil then
		delete(p64.cameraWorldParent)
		p64.cameraWorldParent = nil
	end
	g_messageCenter:unsubscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.ACTIVE_SUSPENSION_CAMERA], p64)
	g_messageCenter:unsubscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.CAMERA_CHECK_COLLISION], p64)
end
function VehicleCamera.zoomSmoothly(p65, p66)
	local v67 = p65.transMin
	local v68 = p65.transMax
	if p65.lodDebugMode then
		p66 = p66 * 10
	end
	local v69 = p65.zoomTarget
	if v67 ~= nil and (v68 ~= nil and v67 ~= v68) then
		local v70 = p65.zoomTarget + p66
		local v71 = math.max(v67, v70)
		v69 = math.min(v68, v71)
	end
	p65.zoomTarget = v69
end
function VehicleCamera.raycastCallback(p72, p73, _, _, _, p74, p75, p76, p77)
	p72.raycastDistance = p74
	p72.normalX = p75
	p72.normalY = p76
	p72.normalZ = p77
	p72.raycastTransformId = p73
end
function VehicleCamera.update(p78, p79)
	local v80 = p78.zoomTarget
	if p78.zoomLimitedTarget >= 0 then
		local v81 = p78.zoomLimitedTarget
		local v82 = p78.zoomTarget
		v80 = math.min(v81, v82)
	end
	p78.zoom = v80 + math.pow(0.99579, p79) * (p78.zoom - v80)
	if p78.lastInputValues.upDown ~= 0 then
		local v83 = p78.lastInputValues.upDown * g_gameSettings:getValue(GameSettings.SETTING.CAMERA_SENSITIVITY)
		p78.lastInputValues.upDown = 0
		if g_gameSettings:getValue(GameSettings.SETTING.INVERT_Y_LOOK) then
			v83 = -v83 or v83
		end
		if p78.isRotatable and (p78.isActivated and not g_gui:getIsGuiVisible()) then
			if p78.limitRotXDelta > 0.001 then
				local v84 = p78.rotX - v83
				local v85 = p78.rotX
				p78.rotX = math.min(v84, v85)
			elseif p78.limitRotXDelta < -0.001 then
				local v86 = p78.rotX - v83
				local v87 = p78.rotX
				p78.rotX = math.max(v86, v87)
			else
				p78.rotX = p78.rotX - v83
			end
			if p78.limit then
				local v88 = p78.rotMaxX
				local v89 = p78.rotMinX
				local v90 = p78.rotX
				local v91 = math.max(v89, v90)
				p78.rotX = math.min(v88, v91)
			end
		end
	end
	if p78.lastInputValues.leftRight ~= 0 or p78.autoRotateOverride then
		local v92 = p78.autoRotateOverride or p78.lastInputValues.leftRight * g_gameSettings:getValue(GameSettings.SETTING.CAMERA_SENSITIVITY)
		p78.lastInputValues.leftRight = 0
		if p78.isRotatable and (p78.isActivated and not g_gui:getIsGuiVisible()) then
			p78.rotY = p78.rotY - v92
		end
	end
	if g_gameSettings:getValue(GameSettings.SETTING.IS_HEAD_TRACKING_ENABLED) and (isHeadTrackingAvailable() and (p78.allowHeadTracking and p78.headTrackingNode ~= nil)) then
		local v93, v94, v95 = getHeadTrackingTranslation()
		local v96, v97, v98 = getHeadTrackingRotation()
		if v96 ~= nil then
			local v99 = getParent(p78.cameraNode)
			local v100, v101, v102, v103, v104, v105
			if v99 == 0 then
				v100, v101, v102 = localToWorld(p78.headTrackingNode, v93, v94, v95)
				v103, v104, v105 = localRotationToWorld(p78.headTrackingNode, v96, v97, v98)
			else
				v100, v101, v102 = localToLocal(p78.headTrackingNode, v99, v93, v94, v95)
				v103, v104, v105 = localRotationToLocal(p78.headTrackingNode, v99, v96, v97, v98)
			end
			setRotation(p78.cameraNode, v103, v104, v105)
			setTranslation(p78.cameraNode, v100, v101, v102)
		end
	else
		p78:updateRotateNodeRotation()
		if p78.limit then
			if p78.isRotatable and (p78.useWorldXZRotation == nil and g_gameSettings:getValue(GameSettings.SETTING.USE_WORLD_CAMERA) or p78.useWorldXZRotation) then
				for _ = 1, 4 do
					local v106 = p78.transDirX * p78.zoom
					local v107 = p78.transDirY * p78.zoom
					local v108 = p78.transDirZ * p78.zoom
					local v109, v110, v111 = localToWorld(getParent(p78.cameraPositionNode), v106, v107, v108)
					local v112 = DensityMapHeightUtil.getHeightAtWorldPos(v109, 0, v111) + 0.9
					if v110 >= v112 then
						break
					end
					local v113 = p78.rotX
					local v114 = (math.sin(v113) * p78.zoom - (v112 - v110)) / p78.zoom
					local v115 = math.clamp(v114, -1, 1)
					p78.rotX = math.asin(v115)
					p78:updateRotateNodeRotation()
				end
			end
			if p78.allowTranslation then
				p78.limitRotXDelta = 0
				local v116, v117, v118, v119, v120, v121 = p78:getCollisionDistance()
				if v116 then
					local v122
					if v121 == nil then
						v122 = 0.1
					else
						local v123 = math.abs(v121)
						v122 = MathUtil.lerp(1.2, 0.1, v123 * v123 * (3 - 2 * v123))
					end
					local v124 = v117 - v122
					local v125 = math.max(v124, 0.01)
					p78.disableCollisionTime = g_currentMission.time + 400
					p78.zoomLimitedTarget = v125
					if v125 < p78.zoom then
						p78.zoom = v125
					end
					if p78.isRotatable and (v118 ~= nil and v125 < p78.transMin) then
						local _, v126, _ = worldDirectionToLocal(p78.rotateNode, v118, v119, v120)
						if v126 > 0.5 then
							p78.limitRotXDelta = 1
						elseif v126 < -0.5 then
							p78.limitRotXDelta = -1
						end
					end
				elseif p78.disableCollisionTime <= g_currentMission.time then
					p78.zoomLimitedTarget = -1
				end
			end
		end
		local v127 = p78.transDirX * p78.zoom
		local v128 = p78.transDirY * p78.zoom
		local v129 = p78.transDirZ * p78.zoom
		p78.transX = v127
		p78.transY = v128
		p78.transZ = v129
		setTranslation(p78.cameraPositionNode, p78.transX, p78.transY, p78.transZ)
		if p78.positionSmoothingParameter > 0 then
			local v130 = g_physicsDt
			if p78.vehicle.spec_rideable ~= nil then
				v130 = p78.vehicle.spec_rideable.interpolationDt
			end
			if g_server ~= nil then
				p79 = v130
			end
			if p79 > 0 then
				local v131, v132, v133 = getWorldTranslation(p78.rotateNode)
				local v134 = p78.lookAtPosition
				local v135 = p78.lookAtLastTargetPosition
				local v136, v137, v138 = p78:getSmoothed(p78.lookAtSmoothingParameter, v134[1], v134[2], v134[3], v131, v132, v133, v135[1], v135[2], v135[3], p79)
				v134[1] = v136
				v134[2] = v137
				v134[3] = v138
				v135[1] = v131
				v135[2] = v132
				v135[3] = v133
				local v139, v140, v141 = getWorldTranslation(p78.cameraPositionNode)
				local v142 = p78.position
				local v143 = p78.lastTargetPosition
				local v144, v145, v146 = p78:getSmoothed(p78.positionSmoothingParameter, v142[1], v142[2], v142[3], v139, v140, v141, v143[1], v143[2], v143[3], p79)
				v142[1] = v144
				v142[2] = v145
				v142[3] = v146
				v143[1] = v139
				v143[2] = v140
				v143[3] = v141
				local v147, v148, v149 = localDirectionToWorld(p78.rotateNode, p78:getTiltDirectionOffset(), 1, 0)
				local v150 = p78.upVector
				local v151 = p78.lastUpVector
				local v152, v153, v154 = p78:getSmoothed(p78.positionSmoothingParameter, v150[1], v150[2], v150[3], v147, v148, v149, v151[1], v151[2], v151[3], p79)
				v150[1] = v152
				v150[2] = v153
				v150[3] = v154
				v151[1] = v147
				v151[2] = v148
				v151[3] = v149
				p78:setSeparateCameraPose()
			end
		end
	end
	if MathUtil.isNan(p78.rotX) or (MathUtil.isNan(p78.rotY) or MathUtil.isNan(p78.rotZ)) then
		p78:resetCamera()
	end
end
function VehicleCamera.getSmoothed(_, p155, p156, p157, p158, p159, p160, p161, p162, p163, p164, p165)
	local v166 = p165 - 6
	local v167 = math.floor(v166)
	local v168 = math.max(v167, 0)
	local v169 = p165 - v168
	local v170 = 1 / p165
	local v171 = (p159 - p162) * v170
	local v172 = (p160 - p163) * v170
	local v173 = (p161 - p164) * v170
	local v174 = 1 - p155
	local v175 = 1 + v169
	local v176 = math.pow(v174, v175) + (1 + v169) * p155 - 1
	local v177 = 1 - p155
	local v178 = math.pow(v177, v169)
	local v179 = (v176 * v171 + p155 * (v178 * (p156 - p162) + p162)) / p155
	local v180 = (v176 * v172 + p155 * (v178 * (p157 - p163) + p163)) / p155
	local v181 = (v176 * v173 + p155 * (v178 * (p158 - p164) + p164)) / p155
	for v182 = 1, v168 do
		v179 = v179 + (p162 + v171 * (v182 + v169) - v179) * p155
		v180 = v180 + (p163 + v172 * (v182 + v169) - v180) * p155
		v181 = v181 + (p164 + v173 * (v182 + v169) - v181) * p155
	end
	return v179, v180, v181
end
function VehicleCamera.onActivate(p183)
	if p183.cameraNode ~= nil then
		if g_addCheatCommands then
			addConsoleCommand("gsCameraAutoRotate", "Auto rotate vehicle outdoor camera", "consoleCommandSetAutoRotate", p183, "speed")
			addConsoleCommand("gsCameraOffset", "Offset vehicle outdoor camera target", "consoleCommandSetOffset", p183, "x; y; z")
			addConsoleCommand("gsCameraRotationSaveLoad", "Save and load current camera rotation + zoom", "consoleCommandRotationSaveLoad", p183)
		end
		p183:onActiveCameraSuspensionSettingChanged(g_gameSettings:getValue(GameSettings.SETTING.ACTIVE_SUSPENSION_CAMERA))
		p183.isActivated = true
		if not g_currentMission.vehicleSystem.isReloadRunning and (p183.resetCameraOnVehicleSwitch == nil and g_gameSettings:getValue(GameSettings.SETTING.RESET_CAMERA) or p183.resetCameraOnVehicleSwitch) then
			p183:resetCamera()
		end
		if g_cameraManager:getActiveCamera() ~= p183.cameraNode then
			g_cameraManager:setActiveCamera(p183.cameraNode)
		end
		local v184, v185, v186 = getWorldRotation(p183.rotateNode)
		if MathUtil.isNan(v184) or (MathUtil.isNan(v185) or MathUtil.isNan(v186)) then
			p183:resetCamera()
		end
		if p183.positionSmoothingParameter > 0 then
			local v187, v188, v189 = getWorldTranslation(p183.rotateNode)
			local v190 = v187 + (p183.offsetX or 0)
			local v191 = v188 + (p183.offsetY or 0)
			local v192 = v189 + (p183.offsetZ or 0)
			p183.lookAtPosition[1] = v190
			p183.lookAtPosition[2] = v191
			p183.lookAtPosition[3] = v192
			p183.lookAtLastTargetPosition[1] = v190
			p183.lookAtLastTargetPosition[2] = v191
			p183.lookAtLastTargetPosition[3] = v192
			local v193, v194, v195 = getWorldTranslation(p183.cameraPositionNode)
			p183.position[1] = v193
			p183.position[2] = v194
			p183.position[3] = v195
			p183.lastTargetPosition[1] = v193
			p183.lastTargetPosition[2] = v194
			p183.lastTargetPosition[3] = v195
			local v196, v197, v198 = localDirectionToWorld(p183.rotateNode, p183:getTiltDirectionOffset(), 1, 0)
			p183.upVector[1] = v196
			p183.upVector[2] = v197
			p183.upVector[3] = v198
			p183.lastUpVector[1] = v196
			p183.lastUpVector[2] = v197
			p183.lastUpVector[3] = v198
			setWorldRotation(p183.cameraNode, v184, v185, v186)
			setWorldTranslation(p183.cameraNode, v193, v194, v195)
		end
		p183.lastInputValues = {}
		p183.lastInputValues.upDown = 0
		p183.lastInputValues.leftRight = 0
		local _, v199 = g_inputBinding:registerActionEvent(InputAction.AXIS_LOOK_UPDOWN_VEHICLE, p183, VehicleCamera.actionEventLookUpDown, false, false, true, true, nil)
		local _, v200 = g_inputBinding:registerActionEvent(InputAction.AXIS_LOOK_LEFTRIGHT_VEHICLE, p183, VehicleCamera.actionEventLookLeftRight, false, false, true, true, nil)
		g_inputBinding:setActionEventTextVisibility(v199, false)
		g_inputBinding:setActionEventTextVisibility(v200, false)
		ObjectChangeUtil.setObjectChanges(p183.changeObjects, true, p183.vehicle, p183.vehicle.setMovingToolDirty)
		p183:updatePrecipitationCollisions(true)
		if g_touchHandler ~= nil then
			p183.touchListenerPinch = g_touchHandler:registerGestureListener(TouchHandler.GESTURE_PINCH, VehicleCamera.touchEventZoomInOut, p183)
			p183.touchListenerY = g_touchHandler:registerGestureListener(TouchHandler.GESTURE_AXIS_Y, VehicleCamera.touchEventLookUpDown, p183)
			p183.touchListenerX = g_touchHandler:registerGestureListener(TouchHandler.GESTURE_AXIS_X, VehicleCamera.touchEventLookLeftRight, p183)
		end
		g_activeVehicleCamera = p183
		if p183.lodDebugModeLoaded then
			p183:setLODDebugState(p183.lodDebugModeLoaded, p183.loadDebugZoom)
			p183.lodDebugModeLoaded = nil
		end
	end
end
function VehicleCamera.setLODDebugState(p201, p202, p203)
	if p202 ~= p201.lodDebugMode then
		p201.lodDebugMode = p202
		if p201.lodDebugMode then
			p201.transMaxOrig = p201.transMax
			p201.transMax = 350
			p201.loadDebugZoom = p203 or p201.zoom
			setViewDistanceCoeff(1)
			setLODDistanceCoeff(1)
			setTerrainLODDistanceCoeff(1)
			return
		end
		p201.transMax = p201.transMaxOrig
		p201.zoomTarget = p201.zoomDefault
		p201.zoom = p201.zoomDefault
		setFovY(p201.cameraNode, p201.fovY)
		setViewDistanceCoeff(g_settingsModel.percentValues[g_settingsModel:getValue(SettingsModel.SETTING.OBJECT_DRAW_DISTANCE)])
		setLODDistanceCoeff(g_settingsModel.percentValues[g_settingsModel:getValue(SettingsModel.SETTING.LOD_DISTANCE)])
		setTerrainLODDistanceCoeff(g_settingsModel.percentValues[g_settingsModel:getValue(SettingsModel.SETTING.TERRAIN_LOD_DISTANCE)])
	end
end
function VehicleCamera.setCameraYDebugState(p204, p205, p206)
	if p205 ~= p204.cameraYDebugMode then
		p204.cameraYDebugMode = p205
		if p204.cameraYDebugMode then
			p204.cameraYDebugHeight = tonumber(p206) or 5
			p204.cameraYDebugZoom = p204.zoom
			p204.rotX = 0
			p204.rotY = 1.5707963267948966
			p204.rotZ = 0
			setRotation(p204.rotateNode, p204.rotX, p204.rotY, p204.rotZ)
			setIsOrthographic(p204.cameraNode, true)
			setOrthographicHeight(p204.cameraNode, tonumber(p206) or 5)
			p204.isRotatable = false
			g_depthOfFieldManager:setManipulatedParams(0)
			g_currentMission.hud:setIsVisible(false)
			return
		end
		p204.isRotatable = true
		setIsOrthographic(p204.cameraNode, false)
		if p204 == g_activeVehicleCamera then
			g_depthOfFieldManager:setManipulatedParams(DepthOfFieldManager.DEFAULT_VALUES[1])
			g_currentMission.hud:setIsVisible(true)
		end
	end
end
function VehicleCamera.onDeactivate(p207)
	p207.isActivated = false
	removeConsoleCommand("gsCameraAutoRotate")
	removeConsoleCommand("gsCameraOffset")
	removeConsoleCommand("gsCameraRotationSaveLoad")
	g_inputBinding:removeActionEventsByTarget(p207)
	ObjectChangeUtil.setObjectChanges(p207.changeObjects, false, p207.vehicle, p207.vehicle.setMovingToolDirty)
	p207:updatePrecipitationCollisions(false)
	if g_touchHandler ~= nil then
		g_touchHandler:removeGestureListener(p207.touchListenerPinch)
		g_touchHandler:removeGestureListener(p207.touchListenerY)
		g_touchHandler:removeGestureListener(p207.touchListenerX)
	end
	if p207.lodDebugMode then
		p207:setLODDebugState(false)
	end
	if g_activeVehicleCamera == p207 then
		g_activeVehicleCamera = nil
	end
end
function VehicleCamera.updatePrecipitationCollisions(p208, p209)
	if p208.collisionNodes ~= nil then
		for _, v210 in ipairs(p208.collisionNodes) do
			local v211 = getCollisionFilterGroup(v210)
			local v212
			if p209 then
				local v213 = CollisionFlag.PRECIPITATION_BLOCKING
				v212 = bit32.bor(v211, v213)
			else
				local v214 = CollisionFlag.PRECIPITATION_BLOCKING
				local v215 = bit32.bnot(v214)
				v212 = bit32.band(v211, v215)
			end
			setCollisionFilterGroup(v210, v212)
		end
	end
end
function VehicleCamera.actionEventLookUpDown(p216, _, p217, _, _, p218)
	local v219
	if p218 then
		v219 = p217 * 0.001 * 16.666
	else
		v219 = p217 * 0.001 * g_currentDt
	end
	p216.lastInputValues.upDown = p216.lastInputValues.upDown + v219
end
function VehicleCamera.touchEventLookUpDown(p220, p221)
	if p220.isActivated then
		local v222 = g_screenHeight * g_pixelSizeX * -75
		VehicleCamera.actionEventLookUpDown(p220, nil, p221 * v222, nil, nil, false)
	end
end
function VehicleCamera.touchEventZoomInOut(p223, p224)
	if p223.isActivated then
		p223:zoomSmoothly(p224 * 15)
	end
end
function VehicleCamera.touchEventLookLeftRight(p225, p226)
	if p225.isActivated then
		local v227 = g_screenAspectRatio * 75
		VehicleCamera.actionEventLookLeftRight(p225, nil, p226 * v227, nil, nil, false)
	end
end
function VehicleCamera.actionEventLookLeftRight(p228, _, p229, _, _, p230)
	local v231
	if p230 then
		v231 = p229 * 0.001 * 16.666
	else
		v231 = p229 * 0.001 * g_currentDt
	end
	p228.lastInputValues.leftRight = p228.lastInputValues.leftRight + v231
end
function VehicleCamera.resetCamera(p232)
	p232.rotX = p232.origRotX
	p232.rotY = p232.origRotY
	p232.rotZ = p232.origRotZ
	p232.transX = p232.origTransX
	p232.transY = p232.origTransY
	p232.transZ = p232.origTransZ
	local v233 = MathUtil.vector3Length(p232.origTransX, p232.origTransY, p232.origTransZ)
	p232.zoom = v233
	p232.zoomTarget = v233
	p232.zoomLimitedTarget = -1
	p232:updateRotateNodeRotation()
	setTranslation(p232.cameraPositionNode, p232.transX, p232.transY, p232.transZ)
	if p232.positionSmoothingParameter > 0 then
		local v234, v235, v236 = getWorldTranslation(p232.rotateNode)
		p232.lookAtPosition[1] = v234 + (p232.offsetX or 0)
		p232.lookAtPosition[2] = v235 + (p232.offsetY or 0)
		p232.lookAtPosition[3] = v236 + (p232.offsetZ or 0)
		local v237, v238, v239 = getWorldTranslation(p232.cameraPositionNode)
		p232.position[1] = v237
		p232.position[2] = v238
		p232.position[3] = v239
		p232:setSeparateCameraPose()
	end
end
function VehicleCamera.updateRotateNodeRotation(p240)
	local v241 = p240.rotY
	if p240.rotYSteeringRotSpeed ~= nil and (p240.rotYSteeringRotSpeed ~= 0 and (p240.vehicle.spec_articulatedAxis ~= nil and p240.vehicle.spec_articulatedAxis.interpolatedRotatedTime ~= nil)) then
		v241 = v241 + p240.vehicle.spec_articulatedAxis.interpolatedRotatedTime * p240.rotYSteeringRotSpeed
	end
	if p240.useWorldXZRotation == nil and g_gameSettings:getValue(GameSettings.SETTING.USE_WORLD_CAMERA) or p240.useWorldXZRotation then
		local v242, _, v243 = localDirectionToWorld(getParent(p240.rotateNode), 0, 0, 1)
		local v244, v245 = MathUtil.vector2Normalize(v242, v243)
		local v246 = p240.rotX
		local v247 = math.cos(v246) * (math.cos(v241) * v244 + math.sin(v241) * v245)
		local v248 = p240.rotX
		local v249 = -math.sin(v248)
		local v250 = p240.rotX
		local v251 = math.cos(v250) * (-math.sin(v241) * v244 + math.cos(v241) * v245)
		local v252, v253, v254 = worldDirectionToLocal(getParent(p240.rotateNode), v247, v249, v251)
		local v255, v256, v257 = worldDirectionToLocal(getParent(p240.rotateNode), 0, 1, 0)
		local v258 = MathUtil.dotProduct(v252, v253, v254, v255, v256, v257)
		if math.abs(v258) > 0.99 * MathUtil.vector3Length(v252, v253, v254) * MathUtil.vector3Length(v255, v256, v257) then
			setRotation(p240.rotateNode, p240.rotX, v241, p240.rotZ)
		else
			setDirection(p240.rotateNode, v252, v253, v254, v255, v256, v257)
		end
	else
		setRotation(p240.rotateNode, p240.rotX, v241, p240.rotZ)
		return
	end
end
function VehicleCamera.setSeparateCameraPose(p259)
	if p259.rotateNode == p259.cameraPositionNode then
		local v260, v261, v262 = localDirectionToWorld(p259.rotateNode, 0, 0, 1)
		local v263, v264, v265 = localDirectionToWorld(p259.rotateNode, p259:getTiltDirectionOffset(), 1, 0)
		setWorldDirection(p259.cameraNode, v260, v261, v262, v263, v264, v265)
	else
		local v266 = p259.position[1] - p259.lookAtPosition[1]
		local v267 = p259.position[2] - p259.lookAtPosition[2]
		local v268 = p259.position[3] - p259.lookAtPosition[3]
		local v269, v270 = MathUtil.vector2Normalize(v266, v268)
		setDirection(p259.cameraWorldParent, v269, 0, v270, 0, 1, 0)
		local v271 = p259.upVector
		local v272, v273, v274 = unpack(v271)
		local v275 = v272 == 0 and (v273 == 0 and v274 == 0) and 1 or v273
		local v276 = math.abs(v266) < 0.001 and math.abs(v268) < 0.001 and 0.1 or v272
		local v277, v278, v279 = MathUtil.vector3Normalize(v266, v267, v268)
		local v280, v281, v282 = MathUtil.vector3Normalize(v276, v275, v274)
		setWorldDirection(p259.cameraNode, v277, v278, v279, v280, v281, v282)
	end
	setWorldTranslation(p259.cameraNode, p259.position[1], p259.position[2], p259.position[3])
	if p259.lodDebugMode then
		local _, _, v283 = localToLocal(p259.cameraNode, p259.rotateNode, 0, 0, 0)
		local v284 = p259.fovY
		local v285 = math.atan(v284) * p259.loadDebugZoom
		local v286, v287 = g_inputBinding:getMouseButtonState()
		if v287 and v286 == Input.MOUSE_BUTTON_MIDDLE then
			setFovY(p259.cameraNode, p259.fovY)
		else
			local v288 = setFovY
			local v289 = p259.cameraNode
			local v290 = v285 / math.max(v283, v285)
			v288(v289, (math.tan(v290)))
		end
		setTextAlignment(RenderText.ALIGN_CENTER)
		renderText(0.5, 0.1, 0.04, string.format("Distance: %d", p259.zoom))
		setTextAlignment(RenderText.ALIGN_LEFT)
	end
end
function VehicleCamera.getTiltDirectionOffset(p291)
	if p291.isInside or not (g_gameSettings:getValue(GameSettings.SETTING.CAMERA_TILTING) and getHasTouchpad()) then
		return 0
	end
	local v292, v293, v294 = getGravityDirection()
	return MathUtil.getHorizontalRotationFromDeviceGravity(v292, v293, v294)
end
function VehicleCamera.getCollisionDistance(p295)
	if not p295.isCollisionEnabled then
		return false, nil, nil, nil, nil, nil
	end
	local v296 = VehicleCamera.raycastMask
	local v297, v298, v299 = localToWorld(p295.rotateNode, p295.transDirX * p295.zoomTarget, p295.transDirY * p295.zoomTarget, p295.transDirZ * p295.zoomTarget)
	local v300 = -1
	local v301 = nil
	local v302 = nil
	local v303 = nil
	local v304 = nil
	local v305 = false
	for _, v306 in ipairs(p295.raycastNodes) do
		local v307, v308, v309 = getWorldTranslation(v306)
		local v310 = v297 - v307
		local v311 = v298 - v308
		local v312 = v299 - v309
		local v313 = MathUtil.vector3Length(v310, v311, v312)
		local v314 = v310 / v313
		local v315 = v311 / v313
		local v316 = v312 / v313
		local v317 = p295.transMin
		local v318 = v309
		local v319 = v307
		local v320 = v308
		local v321 = 0
		v305 = false
		while true do
			if v313 - v321 <= 0 then
				v322 = v304
				break
			end
			p295.raycastDistance = 0
			raycastClosest(v307, v308, v309, v314, v315, v316, v313 - v321, "raycastCallback", p295, v296)
			if p295.raycastDistance == 0 then
				v322 = v304
				break
			end
			v321 = v321 + p295.raycastDistance + 0.001
			local v322 = MathUtil.dotProduct(p295.normalX, p295.normalY, p295.normalZ, v314, v315, v316)
			local v323 = g_currentMission:getNodeObject(p295.raycastTransformId)
			local v324 = v323 == p295.vehicle
			if v323 ~= nil and not v324 then
				v324 = v323.rootVehicle == p295.vehicle.rootVehicle and true or v324
				if not v324 then
					local v325 = p295.vehicle:getChildVehicles()
					for v326 = 1, #v325 do
						local v327 = v325[v326]
						if v323 ~= v327 then
							local v328 = v323.dynamicMountObject or (v323.tensionMountObject or v323.mountObject)
							if v328 ~= nil and (v328 == v327 or v328.rootVehicle == v327) then
								v324 = true
								break
							end
						end
					end
				end
			end
			local v329 = not v324 and getHasClassId(p295.raycastTransformId, ClassIds.MESH_SPLIT_SHAPE) and true or v324
			if (v329 or not getHasTrigger(p295.raycastTransformId)) and not v329 then
				v305 = true
				if v306 == p295.rotateNode then
					v301 = p295.normalX
					v302 = p295.normalY
					v303 = p295.normalZ
					if getRigidBodyType(p295.raycastTransformId) == RigidBodyType.STATIC then
						v300 = v321
					else
						local v330 = p295.transMin
						v300 = math.max(v330, v321)
					end
				else
					v322 = v304
				end
				break
			end
			if v322 > 0 then
				v317 = math.max(v317, v321)
			end
			v307 = v319 + v314 * v321
			v308 = v320 + v315 * v321
			v309 = v318 + v316 * v321
		end
		if not v305 then
			v304 = v322
		end
		v304 = v322
	end
	return v305, v300, v301, v302, v303, v304
end
function VehicleCamera.onActiveCameraSuspensionSettingChanged(p331, p332)
	if p331.suspensionNode ~= nil and p331.lastActiveCameraSuspensionSetting ~= p332 then
		if p332 then
			link(p331.cameraSuspensionParentNode, p331.cameraPositionNode)
		else
			link(p331.cameraBaseParentNode, p331.cameraPositionNode)
		end
		p331.lastActiveCameraSuspensionSetting = p332
	end
end
function VehicleCamera.onCameraCollisionDetectionSettingChanged(p333, p334)
	p333.isCollisionEnabled = p334
end
function VehicleCamera.consoleCommandSetAutoRotate(p335, p336)
	local v337 = tonumber(p336)
	if v337 == nil or v337 == 0 then
		p335.autoRotateOverride = nil
	else
		p335.autoRotateOverride = v337 * 0.01
	end
	return string.format("VehicleCamera.autoRotateOverride %s", v337)
end
function VehicleCamera.consoleCommandSetOffset(p338, p339, p340, p341)
	if p338.rotNodePosBackup == nil then
		local v342, v343, v344 = getTranslation(p338.rotateNode)
		p338.rotNodePosBackup = { v342, v343, v344 }
	end
	local v345 = tonumber(p339) or 0
	local v346 = tonumber(p340) or 0
	local v347 = tonumber(p341) or 0
	local v348 = p338.rotNodePosBackup
	local v349, v350, v351 = unpack(v348)
	setTranslation(p338.rotateNode, v349 + v345, v350 + v346, v351 + v347)
end
function VehicleCamera.consoleCommandRotationSaveLoad(p352, p353)
	if not p353 then
		p352.rotBackup = { p352.rotX, p352.rotY, p352.rotZ }
		p352.transBackup = { p352.transX, p352.transY, p352.transZ }
		p352.zoomBackup = MathUtil.vector3Length(p352.transX, p352.transY, p352.transZ) + 0.00001
		return "Saved current rotation for this vehicle. Use \'gsCameraRotationSaveLoad load\' to load"
	end
	if p352.rotBackup == nil then
		return "Error: no position/rotation saved yet"
	end
	local v354 = p352.rotBackup
	local v355, v356, v357 = unpack(v354)
	p352.rotX = v355
	p352.rotY = v356
	p352.rotZ = v357
	local v358 = p352.transBackup
	local v359, v360, v361 = unpack(v358)
	p352.transX = v359
	p352.transY = v360
	p352.transZ = v361
	p352.zoom = p352.zoomBackup
	p352.zoomTarget = p352.zoomBackup
	return "Loaded rotation"
end
function VehicleCamera.registerCameraXMLPaths(p362, p363)
	p362:register(XMLValueType.NODE_INDEX, p363 .. "#node", "Camera node")
	p362:register(XMLValueType.BOOL, p363 .. "#rotatable", "Camera is rotatable", false)
	p362:register(XMLValueType.BOOL, p363 .. "#limit", "Has limits", false)
	p362:register(XMLValueType.FLOAT, p363 .. "#rotMinX", "Min. X rotation")
	p362:register(XMLValueType.FLOAT, p363 .. "#rotMaxX", "Max. X rotation")
	p362:register(XMLValueType.FLOAT, p363 .. "#transMin", "Min. Z translation")
	p362:register(XMLValueType.FLOAT, p363 .. "#transMax", "Max. Z translation")
	p362:register(XMLValueType.BOOL, p363 .. "#isInside", "Is camera inside. Used for camera smoothing and fallback/default value for \'useOutdoorSounds\'", false)
	p362:register(XMLValueType.BOOL, p363 .. "#allowHeadTracking", "Allow head tracking", "isInside value")
	p362:register(XMLValueType.NODE_INDEX, p363 .. "#shadowFocusBox", "Shadow focus box")
	p362:register(XMLValueType.BOOL, p363 .. "#useOutdoorSounds", "Use outdoor sounds", "false for \'isInside\' cameras, otherwise true")
	p362:register(XMLValueType.NODE_INDEX, p363 .. "#rotateNode", "Rotate node")
	p362:register(XMLValueType.VECTOR_ROT, p363 .. "#rotation", "Camera rotation")
	p362:register(XMLValueType.VECTOR_TRANS, p363 .. "#translation", "Camera translation")
	p362:register(XMLValueType.BOOL, p363 .. "#useMirror", "Use mirrors", false)
	p362:register(XMLValueType.BOOL, p363 .. "#useWorldXZRotation", "Use world XZ rotation")
	p362:register(XMLValueType.BOOL, p363 .. "#resetCameraOnVehicleSwitch", "Reset camera on vehicle switch")
	p362:register(XMLValueType.INT, p363 .. "#suspensionNodeIndex", "Index of seat suspension node")
	p362:register(XMLValueType.BOOL, p363 .. "#useDefaultPositionSmoothing", "Use default position smoothing parameters", true)
	p362:register(XMLValueType.FLOAT, p363 .. "#positionSmoothingParameter", "Position smoothing parameter", "0.128 for indoor / 0.016 for outside")
	p362:register(XMLValueType.FLOAT, p363 .. "#lookAtSmoothingParameter", "Look at smoothing parameter", "0.176 for indoor / 0.022 for outside")
	p362:register(XMLValueType.ANGLE, p363 .. "#rotYSteeringRotSpeed", "Rot Y steering rotation speed", 0)
	p362:register(XMLValueType.NODE_INDEX, p363 .. ".raycastNode(?)#node", "Raycast node")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p362, p363)
end
function VehicleCamera.registerCameraSavegameXMLPaths(p364, p365)
	p364:register(XMLValueType.VECTOR_ROT, p365 .. "#rotation", "Camera rotation")
	p364:register(XMLValueType.VECTOR_TRANS, p365 .. "#translation", "Camera translation")
	p364:register(XMLValueType.FLOAT, p365 .. "#zoom", "Camera zoom")
	p364:register(XMLValueType.ANGLE, p365 .. "#fovY", "Custom Field of View Y")
	p364:register(XMLValueType.BOOL, p365 .. "#lodDebugActive", "LOD Debug Mode Active")
	p364:register(XMLValueType.FLOAT, p365 .. "#lodDebugZoom", "LOD Debug Mode Zoom Ref")
	p364:register(XMLValueType.BOOL, p365 .. "#cameraYDebugActive", "Camera Y Debug Mode Active")
	p364:register(XMLValueType.FLOAT, p365 .. "#cameraYDebugHeight", "Camera Y Debug Mode orthographic height")
end
function VehicleCamera.consoleCommandLODDebug()
	if g_activeVehicleCamera == nil then
		return "Enter a vehicle first!"
	end
	g_activeVehicleCamera:setLODDebugState(not g_activeVehicleCamera.lodDebugMode)
	return string.format("(%s) Vehicle Camera LOD Debug: %s", g_activeVehicleCamera.vehicle:getName(), g_activeVehicleCamera.lodDebugMode)
end
function VehicleCamera.consoleCommandCameraYDebug(p366)
	if g_activeVehicleCamera == nil then
		return "Enter a vehicle first!"
	end
	g_activeVehicleCamera:setCameraYDebugState(not g_activeVehicleCamera.cameraYDebugMode, p366)
	return string.format("(%s) Vehicle Camera Y Debug: %s", g_activeVehicleCamera.vehicle:getName(), g_activeVehicleCamera.cameraYDebugMode)
end
addConsoleCommand("gsVehicleDebugLOD", "Enables vehicle LOD debug", "consoleCommandLODDebug", VehicleCamera)

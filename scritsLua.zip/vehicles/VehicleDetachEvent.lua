VehicleDetachEvent = {}
local v_u_1 = Class(VehicleDetachEvent, Event)
InitStaticEventClass(VehicleDetachEvent, "VehicleDetachEvent")
function VehicleDetachEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleDetachEvent.new(p2, p3)
	local v4 = VehicleDetachEvent.emptyNew()
	v4.implement = p3
	v4.vehicle = p2
	return v4
end
function VehicleDetachEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.implement = NetworkUtil.readNodeObject(p6)
	if p5.vehicle ~= nil and p5.vehicle:getIsSynchronized() then
		if p7:getIsServer() then
			p5.vehicle:detachImplementByObject(p5.implement, true)
			return
		end
		p5.vehicle:detachImplementByObject(p5.implement)
	end
end
function VehicleDetachEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	NetworkUtil.writeNodeObject(p9, p8.implement)
end
function VehicleDetachEvent.run(_, _) end

VehicleStateRecorder = {}
VehicleStateRecorder.currentInstance = nil
local v_u_1 = Class(VehicleStateRecorder)
function VehicleStateRecorder.new(p2, p3, p4, p_u_5)
	-- upvalues: (copy) v_u_1
	local v6 = v_u_1
	local v_u_7 = setmetatable({}, v6)
	v_u_7.vehicle = p2
	v_u_7.name = p3 or p_u_5
	v_u_7.duration = (p4 or (1 / 0)) * 1000
	if v_u_7.name == nil then
		v_u_7.name = "vehicleState_" .. getDate("%Y_%m_%d_%H_%M")
	end
	v_u_7.nodeState = {}
	if p_u_5 == nil then
		g_currentMission:addUpdateable(v_u_7)
		v_u_7.isActive = true
		v_u_7.startTime = g_time
		v_u_7:recordVehicle()
		Logging.info("Start vehicle state recording for \'%s\'", v_u_7.vehicle.configFileNameClean)
		return v_u_7
	end
	if VehicleStateRecorder.defaultRaiseEvent == nil then
		VehicleStateRecorder.defaultRaiseEvent = SpecializationUtil.raiseEvent
		function SpecializationUtil.raiseEvent(p8, p9, p10, ...)
			-- upvalues: (copy) v_u_7, (copy) p_u_5
			VehicleStateRecorder.defaultRaiseEvent(p8, p9, p10, ...)
			if p8 == v_u_7.vehicle and p10 == p_u_5 then
				if p9 == "onPlayAnimation" then
					if not v_u_7.isActive then
						g_currentMission:addUpdateable(v_u_7)
						v_u_7.isActive = true
						v_u_7.startTime = g_time
						v_u_7:recordVehicle()
						Logging.info("Start vehicle state recording for \'%s\'", v_u_7.vehicle.configFileNameClean)
						return
					end
				elseif p9 == "onFinishAnimation" and v_u_7.isActive then
					v_u_7:finish()
				end
			end
		end
		return v_u_7
	end
	Logging.warning("VehicleStateRecorder is already active. Only one recording at a time is supported.")
end
function VehicleStateRecorder.update(p11, _)
	if g_time - p11.startTime > p11.duration then
		p11:finish()
	else
		p11:recordVehicle()
		setTextAlignment(RenderText.ALIGN_CENTER)
		setTextColor(1, 1, 1, 0.5)
		renderText(0.5, 0.03, 0.03, string.format("Vehicle State Recording for \'%s\' (%.1f sec)", p11.vehicle.configFileNameClean, (g_time - p11.startTime) * 0.001))
		setTextAlignment(RenderText.ALIGN_LEFT)
		setTextColor(1, 1, 1, 1)
	end
end
function VehicleStateRecorder.finish(p12)
	Logging.info("Finish vehicle state recording for \'%s\' (%.1fsec)", p12.vehicle.configFileNameClean, (g_time - (p12.startTime or 0)) * 0.001)
	local v13 = getAppBasePath() .. Utils.getDirectory(p12.vehicle.configFileName) .. "giantsTools"
	createFolder(v13)
	local v14 = string.format(v13 .. "/%s.xml", p12.name)
	local v15 = XMLFile.create("vehicleState", v14, "vehicleState", nil)
	local v16 = 0
	for v17, v18 in pairs(p12.nodeState) do
		if #v18 > 0 then
			local v19 = string.format("vehicleState.node(%d)", v16)
			v15:setString(v19 .. "#name", v18[1].name)
			v15:setString(v19 .. "#className", v18[1].className)
			v15:setString(v19 .. "#indexPath", v17)
			for v20, v21 in ipairs(v18) do
				local v22 = string.format("%s.s(%d)", v19, v20 - 1)
				v15:setFloat(v22 .. "#t", v21.time * 0.001)
				local v23 = v18[v20 - 1]
				if v23 == nil or (v23.translation[1] ~= v21.translation[1] or (v23.translation[2] ~= v21.translation[2] or v23.translation[3] ~= v21.translation[3])) then
					v15:setString(v22 .. "#tr", string.format("%.5f %.5f %.5f", v21.translation[1], v21.translation[2], v21.translation[3]))
				end
				if v23 == nil or (v23.rotation[1] ~= v21.rotation[1] or (v23.rotation[2] ~= v21.rotation[2] or v23.rotation[3] ~= v21.rotation[3])) then
					local v24 = v22 .. "#ro"
					local v25 = string.format
					local v26 = v21.rotation[1]
					local v27 = math.deg(v26)
					local v28 = v21.rotation[2]
					local v29 = math.deg(v28)
					local v30 = v21.rotation[3]
					v15:setString(v24, v25("%.4f %.4f %.4f", v27, v29, (math.deg(v30))))
				end
				if v23 == nil or v23.visibility ~= v21.visibility then
					v15:setBool(v22 .. "#vi", v21.visibility)
				end
			end
			v16 = v16 + 1
		end
	end
	v15:save()
	v15:delete()
	Logging.info("Save recording to \'%s\'", v14)
	g_currentMission:removeUpdateable(VehicleStateRecorder.currentInstance)
	if VehicleStateRecorder.defaultRaiseEvent ~= nil then
		SpecializationUtil.raiseEvent = VehicleStateRecorder.defaultRaiseEvent
		VehicleStateRecorder.defaultRaiseEvent = nil
	end
end
function VehicleStateRecorder.recordVehicle(p31)
	for v32, v33 in ipairs(p31.vehicle.components) do
		local v34 = v33.node
		local v35 = v32 - 1
		p31:recordNode(v34, tostring(v35), ">")
	end
end
function VehicleStateRecorder.recordNode(p36, p37, p38, p39)
	if p36.vehicle.i3dMappings[getName(p37)] ~= nil then
		local v40, v41, v42 = getTranslation(p37)
		local v43, v44, v45 = getRotation(p37)
		local v46 = getVisibility(p37)
		local v47 = false
		local v48
		if p36.nodeState[p38] == nil then
			p36.nodeState[p38] = {}
			v48 = true
		else
			local v49 = p36.nodeState[p38]
			local v50 = v49[#v49]
			local v51 = (v50.translation[1] ~= v40 or (v50.translation[2] ~= v41 or v50.translation[3] ~= v42)) and true or v47
			local v52 = (v50.rotation[1] ~= v43 or (v50.rotation[2] ~= v44 or v50.rotation[3] ~= v45)) and true or v51
			v48 = v50.visibility ~= v46 and true or v52
		end
		if v48 then
			local v53 = {
				["translation"] = { v40, v41, v42 },
				["rotation"] = { v43, v44, v45 },
				["visibility"] = v46,
				["time"] = g_time - p36.startTime
			}
			if #p36.nodeState[p38] == 0 then
				v53.name = getName(p37)
				for v54, v55 in pairs(ClassIds) do
					if getHasClassId(p37, v55) then
						v53.className = v54
						break
					end
				end
			end
			local v56 = p36.nodeState[p38]
			table.insert(v56, v53)
		end
	end
	for v57 = 1, getNumOfChildren(p37) do
		p36:recordNode(getChildAt(p37, v57 - 1), p38 .. (p39 or "|") .. v57 - 1)
	end
end
function VehicleStateRecorder.consoleCommand(_, p58, p59)
	if VehicleStateRecorder.currentInstance == nil then
		if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
			local v60 = g_localPlayer:getCurrentVehicle()
			local v61 = v60:getSelectedVehicle() or v60
			VehicleStateRecorder.currentInstance = VehicleStateRecorder.new(v61, p58, p59)
			return
		end
	else
		VehicleStateRecorder.currentInstance:finish()
		VehicleStateRecorder.currentInstance = nil
	end
end
function VehicleStateRecorder.consoleCommandAnimation(_, p62)
	if VehicleStateRecorder.currentInstance == nil then
		if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
			local v63 = g_localPlayer:getCurrentVehicle()
			local v64 = v63:getSelectedVehicle() or v63
			VehicleStateRecorder.currentInstance = VehicleStateRecorder.new(v64, nil, nil, p62)
			return
		end
	else
		VehicleStateRecorder.currentInstance:finish()
		VehicleStateRecorder.currentInstance = nil
	end
end
addConsoleCommand("gsVehicleRecordState", "Starts and stops vehicle state recording", "VehicleStateRecorder.consoleCommand", nil)
addConsoleCommand("gsVehicleRecordAnimation", "Turns on the state recording for the given animationName", "VehicleStateRecorder.consoleCommandAnimation", nil)

VehicleActionControllerAction = {}
local v_u_1 = Class(VehicleActionControllerAction)
function VehicleActionControllerAction.new(p2, p3, p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = p6 or v_u_1
	local v8 = setmetatable({}, v7)
	v8.parent = p2
	v8.name = p3
	v8.inputAction = p4
	v8.priority = p5
	v8.lastDirection = -1
	v8.lastValidDirection = 0
	v8.isSaved = false
	v8.resetOnDeactivation = true
	v8.identifier = ""
	v8.aiEventListener = {}
	return v8
end
function VehicleActionControllerAction.remove(p9)
	p9.parent:removeAction(p9)
end
function VehicleActionControllerAction.updateParent(p10, p11)
	if p11 ~= p10.parent then
		p10.parent:removeAction(p10)
		p11:addAction(p10)
	end
	p10.parent = p11
end
function VehicleActionControllerAction.setCallback(p12, p13, p14, p15)
	p12.callbackTarget = p13
	p12.inputCallback = p14
	p12.inputCallbackRev = p15
	p12.identifier = p13.configFileName or ""
end
function VehicleActionControllerAction.setFinishedFunctions(p16, p17, p18, p19, p20, p21)
	p16.finishedFunctionTarget = p17
	p16.finishedFunc = p18
	p16.finishedFuncRev = p21
	p16.finishedResult = p19
	p16.finishedResultRev = p20
end
function VehicleActionControllerAction.setDeactivateFunction(p22, p23, p24, p25)
	p22.deactivateFunctionTarget = p23
	p22.deactivateFunc = p24
	p22.inverseDeactivateFunc = Utils.getNoNil(p25, false)
end
function VehicleActionControllerAction.setIsAvailableFunction(p26, p27)
	p26.availableFunc = p27
end
function VehicleActionControllerAction.setIsAccessibleFunction(p28, p29)
	p28.accessibleFunc = p29
end
function VehicleActionControllerAction.setActionIcons(p30, p31, p32, p33)
	p30.iconPos = p31
	p30.iconNeg = p32
	p30.iconChangeColor = p33
end
function VehicleActionControllerAction.setResetOnDeactivation(p34, p35)
	p34.resetOnDeactivation = p35
end
function VehicleActionControllerAction.setIsSaved(p36, p37)
	p36.isSaved = p37
end
function VehicleActionControllerAction.getIsSaved(p38)
	return p38.isSaved
end
function VehicleActionControllerAction.isAvailable(p39)
	return p39.availableFunc == nil and true or p39.availableFunc()
end
function VehicleActionControllerAction.isAccessible(p40)
	return p40.accessibleFunc == nil and true or p40.accessibleFunc()
end
function VehicleActionControllerAction.getControlledActionIcons(p41)
	return p41.iconPos, p41.iconNeg, p41.iconChangeColor
end
function VehicleActionControllerAction.getLastDirection(p42)
	return p42.lastDirection
end
function VehicleActionControllerAction.getDoResetOnDeactivation(p43)
	return p43.resetOnDeactivation
end
function VehicleActionControllerAction.addAIEventListener(p44, p45, p46, p47, p48)
	p44.sourceVehicle = p45
	local v49 = p44.aiEventListener
	table.insert(v49, {
		["eventName"] = p46,
		["direction"] = p47,
		["forceUntilFinished"] = p48
	})
end
function VehicleActionControllerAction.registerActionEvents(_, _, _, _, _, _) end
function VehicleActionControllerAction.actionEvent(p50, _, _, _, _)
	p50:doAction()
end
function VehicleActionControllerAction.doAction(p51, p52, p53)
	if p52 == nil then
		p52 = -p51.lastDirection
	end
	p51.lastDirection = p52
	local v54 = p51.inputCallback(p51.callbackTarget, p52, p53)
	if v54 then
		p51.lastValidDirection = p51.lastDirection
	end
	return v54
end
function VehicleActionControllerAction.getIsFinished(p55, p56)
	if p55.finishedFunc == nil then
		return true
	elseif p56 > 0 then
		return p55.finishedFunc(p55.finishedFunctionTarget) == p55.finishedResult
	else
		return p55.finishedFunc(p55.finishedFunctionTarget) == p55.finishedResultRev
	end
end
function VehicleActionControllerAction.getSourceVehicle(p57)
	return p57.sourceVehicle
end
function VehicleActionControllerAction.onAIEvent(p58, p59)
	for _, v60 in ipairs(p58.aiEventListener) do
		if v60.eventName == p59 then
			if p58:doAction(v60.direction, true) or not v60.forceUntilFinished then
				if p58.forceDirectionUntilFinished ~= nil and v60.direction ~= p58.forceDirectionUntilFinished then
					p58.forceDirectionUntilFinished = nil
				end
				p58.parent:stopActionSequence()
			else
				p58.forceDirectionUntilFinished = v60.direction
			end
		end
	end
end
function VehicleActionControllerAction.update(p61, _)
	if p61.deactivateFunc ~= nil and (p61.lastDirection == 1 and (p61.deactivateFunc(p61.deactivateFunctionTarget) == not p61.inverseDeactivateFunc and (p61.parent.currentSequenceIndex == nil and p61.forceDirectionUntilFinished == nil))) then
		p61.parent:startActionSequence()
	end
end
function VehicleActionControllerAction.updateForAI(p62, _)
	if p62.forceDirectionUntilFinished ~= nil and p62:doAction(p62.forceDirectionUntilFinished) then
		p62.forceDirectionUntilFinished = nil
		p62.parent:stopActionSequence()
	end
end
function VehicleActionControllerAction.getDebugText(p63)
	local v64
	if p63.finishedFunc == nil then
		v64 = "?"
	else
		v64 = p63.finishedFunc(p63.finishedFunctionTarget)
		if type(v64) == "number" then
			v64 = string.format("%.1f", v64)
		end
	end
	local v65 = p63.callbackTarget == nil and "Unknown Vehicle" or p63.callbackTarget:getName()
	return string.format("Prio \'%d\' - Vehicle \'%s\' - Action \'%s\' (%s/%s)", p63.priority, v65, p63.name, v64, p63.lastDirection == 1 and p63.finishedResult or p63.finishedResultRev)
end

DashboardValueType = {}
local v_u_1 = Class(DashboardValueType)
function DashboardValueType.new(p2, p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = p4 or v_u_1
	local v6 = setmetatable({}, v5)
	v6.specName = p2
	v6.name = p3
	v6.fullName = p2 .. "." .. p3
	v6.valueObject = nil
	v6.loadFunction = nil
	v6.stateFunction = nil
	v6.valueFactor = 1
	v6.valueCompare = nil
	v6.idleValue = nil
	v6.functions = {}
	v6.value = 0
	v6.min = 0
	v6.max = 1
	return v6
end
function DashboardValueType.setXMLKey(p7, p8)
	p7.xmlKey = p8
end
function DashboardValueType.loadFromXML(p9, p10, p11)
	if p9.xmlKey == nil then
		p11:loadDashboardsFromXML(p10, p10:getRootName() .. "." .. p9.specName .. ".dashboards", p9)
	else
		p11:loadDashboardsFromXML(p10, p9.xmlKey, p9)
	end
end
function DashboardValueType.setAdditionalFunctions(p12, p13, p14)
	p12.loadFunction = p13
	p12.stateFunction = p14
end
function DashboardValueType.setValueFactor(p15, p16)
	p15.valueFactor = p16
end
function DashboardValueType.setValueCompare(p17, ...)
	p17.valueCompare = {}
	for v18 = 1, select("#", ...) do
		p17.valueCompare[select(v18, ...)] = true
	end
end
function DashboardValueType.setIdleValue(p19, p20)
	p19.idleValue = p20
end
function DashboardValueType.setValue(p21, p22, p23)
	p21:setFunction("value", p22, p23)
end
function DashboardValueType.setCenter(p24, p25)
	p24:setFunction("center", p24.valueObject, p25)
end
function DashboardValueType.setRange(p26, p27, p28)
	p26:setFunction("min", p26.valueObject, p27)
	p26:setFunction("max", p26.valueObject, p28)
end
function DashboardValueType.setInterpolationSpeed(p29, p30)
	p29:setFunction("interpolationSpeed", p29.valueObject, p30)
end
function DashboardValueType.getInterpolationSpeed(p31, p32)
	return p31:getFunctionValue("interpolationSpeed", p32)
end
function DashboardValueType.getValue(p33, p34)
	local v35 = p33:getFunctionValue("value", p34)
	if p33.valueCompare ~= nil then
		v35 = p33.valueCompare[v35] == true
	end
	local v36 = type(v35) == "number"
	local v37, v38, v39
	if v36 then
		if p33.valueFactor ~= nil then
			v35 = v35 * p33.valueFactor
		end
		v37 = p33:getFunctionValue("min", p34)
		v38 = p33:getFunctionValue("max", p34)
		v39 = p33:getFunctionValue("center", p34)
	else
		v37 = nil
		v38 = nil
		v39 = nil
	end
	return v35, v37, v38, v39, v36
end
function DashboardValueType.setFunction(p40, p41, p42, p43)
	p40.valueObject = p42
	local v44 = {
		["valueObject"] = p42,
		["valueFunction"] = p43
	}
	local v45 = v44.valueFunction
	local v46
	if type(v45) == "number" then
		v46 = true
	else
		local v47 = v44.valueFunction
		v46 = type(v47) == "boolean"
	end
	v44.isValue = v46
	local v48 = v44.valueFunction
	v44.isFunction = type(v48) == "function"
	local v49 = v44.valueFunction
	v44.isString = type(v49) == "string"
	if v44.isString then
		local v50 = v44.valueObject[v44.valueFunction]
		local v51
		if type(v50) == "number" then
			v51 = true
		else
			local v52 = v44.valueObject[v44.valueFunction]
			v51 = type(v52) == "boolean"
		end
		v44.isSubValue = v51
		local v53 = v44.valueObject[v44.valueFunction]
		v44.isSubFunction = type(v53) == "function"
	end
	p40.functions[p41] = v44
end
function DashboardValueType.getFunctionValue(p54, p55, p56)
	local v57 = p54.functions[p55]
	if v57 ~= nil then
		if v57.isValue then
			return v57.valueFunction
		end
		if v57.isFunction then
			return v57.valueFunction(v57.valueObject, p56)
		end
		if v57.isString then
			if v57.isSubValue then
				return v57.valueObject[v57.valueFunction]
			end
			if v57.isSubFunction then
				return v57.valueObject[v57.valueFunction](v57.valueObject, p56)
			end
		end
	end
	return nil
end

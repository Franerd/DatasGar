VehicleSetIsReconfiguratingEvent = {}
local v_u_1 = Class(VehicleSetIsReconfiguratingEvent, Event)
InitStaticEventClass(VehicleSetIsReconfiguratingEvent, "VehicleSetIsReconfiguratingEvent")
function VehicleSetIsReconfiguratingEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleSetIsReconfiguratingEvent.new(p2)
	local v3 = VehicleSetIsReconfiguratingEvent.emptyNew()
	v3.object = p2
	return v3
end
function VehicleSetIsReconfiguratingEvent.readStream(p4, p5, _)
	p4.object = NetworkUtil.readNodeObject(p5)
	if p4.object ~= nil and p4.object:getIsSynchronized() then
		p4.object.isReconfigurating = true
	end
end
function VehicleSetIsReconfiguratingEvent.writeStream(p6, p7, _)
	NetworkUtil.writeNodeObject(p7, p6.object)
end

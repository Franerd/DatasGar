VehicleBrokenEvent = {}
local v_u_1 = Class(VehicleBrokenEvent, Event)
InitStaticEventClass(VehicleBrokenEvent, "VehicleBrokenEvent")
function VehicleBrokenEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleBrokenEvent.new(p2)
	local v3 = VehicleBrokenEvent.emptyNew()
	v3.object = p2
	return v3
end
function VehicleBrokenEvent.readStream(p4, p5, p6)
	p4.object = NetworkUtil.readNodeObject(p5)
	p4:run(p6)
end
function VehicleBrokenEvent.writeStream(p7, p8, _)
	NetworkUtil.writeNodeObject(p8, p7.object)
end
function VehicleBrokenEvent.run(p9, _)
	if p9.object ~= nil and p9.object:getIsSynchronized() then
		p9.object:setBroken()
	end
end

VehicleCharacter = {}
VehicleCharacter.DEFAULT_MAX_UPDATE_DISTANCE = 35
VehicleCharacter.DEFAULT_CLIP_DISTANCE = 75
VehicleCharacter.SPINE_ROTATION = { -1.5707963267948966, -0.2461786909938002, 1.5707963267948966 }
local v_u_1 = Class(VehicleCharacter)
function VehicleCharacter.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.vehicle = p2
	v5.characterNode = nil
	v5.allowUpdate = true
	v5.ikChainTargets = {}
	v5.animationCharsetId = nil
	v5.animationPlayer = nil
	v5.useAnimation = false
	v5.isVisible = false
	return v5
end
function VehicleCharacter.load(p6, p7, p8)
	XMLUtil.checkDeprecatedXMLElements(p7, p8 .. "#index", p8 .. "#node")
	p6.characterNode = p7:getValue(p8 .. "#node", nil, p6.vehicle.components, p6.vehicle.i3dMappings)
	if p6.characterNode == nil then
		return false
	end
	p6.parentComponent = p6.vehicle:getParentComponent(p6.characterNode)
	p6.characterCameraMinDistance = p7:getValue(p8 .. "#cameraMinDistance", 1.5)
	p6.characterDistanceRefNodeCustom = p7:getValue(p8 .. "#distanceRefNode", nil, p6.vehicle.components, p6.vehicle.i3dMappings)
	p6.characterDistanceRefNode = p6.characterDistanceRefNodeCustom or p6.characterNode
	setVisibility(p6.characterNode, false)
	p6.useAnimation = p7:getValue(p8 .. "#useAnimation", false)
	local v9 = p8 .. "#useIdleAnimation"
	local v10 = not p6.useAnimation
	if v10 then
		v10 = Platform.gameplay.hasVehicleCharacterIdleAnimations
	end
	p6.useIdleAnimation = p7:getValue(v9, v10)
	if not p6.useAnimation then
		p6.ikChainTargets = {}
		IKUtil.loadIKChainTargets(p7, p8, p6.vehicle.components, p6.ikChainTargets, p6.vehicle.i3dMappings)
	end
	p6.characterSpineRotationOffset = p7:getValue(p8 .. "#spineRotationOffset", nil, true)
	p6.characterSpineSpeedDepended = p7:getValue(p8 .. "#speedDependedSpine", false)
	p6.characterSpineNodeMinRot = p7:getValue(p8 .. "#spineNodeMinRot", 10)
	p6.characterSpineNodeMaxRot = p7:getValue(p8 .. "#spineNodeMaxRot", -10)
	p6.characterSpineNodeMinAcc = p7:getValue(p8 .. "#spineNodeMinAcc", -1) / 1000000
	p6.characterSpineNodeMaxAcc = p7:getValue(p8 .. "#spineNodeMaxAcc", 1) / 1000000
	p6.characterSpineNodeAccDeadZone = p7:getValue(p8 .. "#spineNodeAccDeadZone", 0.2) / 1000000
	p6.characterSpineLastRotation = 0
	p6:setCharacterVisibility(p6.isVisible)
	p6.maxUpdateDistance = p7:getValue(p8 .. "#maxUpdateDistance", VehicleCharacter.DEFAULT_MAX_UPDATE_DISTANCE)
	setClipDistance(p6.characterNode, p7:getValue(p8 .. "#clipDistance", VehicleCharacter.DEFAULT_CLIP_DISTANCE))
	return true
end
function VehicleCharacter.getParentComponent(p11)
	return p11.parentComponent
end
function VehicleCharacter.loadCharacter(p12, p13, p14, p15, p16)
	if p13 == nil then
		p15(p14, false, p16)
	else
		if p12.playerModel ~= nil then
			p12.playerModel:delete()
		end
		p12.playerModel = HumanModel.new()
		p12.playerModel:load(p13.xmlFilename, false, false, p12.useAnimation, p12.characterLoaded, p12, {
			["asyncCallbackObject"] = p14,
			["asyncCallbackFunction"] = p15,
			["asyncCallbackArguments"] = p16,
			["playerStyle"] = p13
		})
	end
end
function VehicleCharacter.characterLoaded(p_u_17, p18, p19)
	if p18 == HumanModelLoadingState.OK then
		if p_u_17.playerModel.rootNode == nil then
			return
		end
		p_u_17.isStyleLoaded = false
		local v20 = Utils.getNoNil(p_u_17.characterNode, p_u_17.vehicle.rootNode)
		link(v20, p_u_17.playerModel.rootNode)
		for v21, v22 in pairs(p_u_17.ikChainTargets) do
			IKUtil.setTarget(p_u_17.playerModel:getIKChains(), v21, v22)
		end
		if p_u_17.playerModel.thirdPersonHipsNode ~= nil then
			local v23 = VehicleCharacter.SPINE_ROTATION[1]
			local v24 = VehicleCharacter.SPINE_ROTATION[2]
			local v25 = VehicleCharacter.SPINE_ROTATION[3]
			if p_u_17.characterSpineRotationOffset ~= nil then
				v23 = p_u_17.characterSpineRotationOffset[1] + v23
				v24 = p_u_17.characterSpineRotationOffset[2] + v24
				v25 = p_u_17.characterSpineRotationOffset[3] + v25
			end
			setRotation(p_u_17.playerModel.thirdPersonHipsNode, v23, v24, v25)
		end
		p_u_17.characterDistanceRefNode = p_u_17.characterDistanceRefNodeCustom or p_u_17.playerModel.thirdPersonHeadNode
		if p_u_17.playerModel.skeleton ~= nil and getNumOfChildren(p_u_17.playerModel.skeleton) > 0 then
			if p_u_17.useAnimation then
				local v26 = p_u_17.playerModel.skeleton
				local v27 = g_animCache:getNode(AnimationCache.CHARACTER)
				cloneAnimCharacterSet(getChildAt(v27, 0), v26)
				p_u_17.animationCharsetId = getAnimCharacterSet(getChildAt(v26, 0))
				local v28 = createConditionalAnimation()
				if v28 ~= 0 then
					p_u_17.animationPlayer = v28
				end
				if p_u_17.animationCharsetId == 0 then
					p_u_17.animationCharsetId = nil
					Logging.devError("-- [VehicleCharacter:loadCharacter] Could not load animation CharSet from: [%s/%s]", getName(getParent(v26)), getName(v26))
					printScenegraph(getParent(v26))
				end
			elseif p_u_17.useIdleAnimation then
				local v29 = p_u_17.playerModel.skeleton
				local v30 = g_animCache:getNode(AnimationCache.VEHICLE_CHARACTER)
				cloneAnimCharacterSet(getChildAt(v30, 0), v29)
				p_u_17.animationCharsetId = getAnimCharacterSet(v29)
				if p_u_17.animationCharsetId == 0 then
					p_u_17.useIdleAnimation = false
					p_u_17.animationCharsetId = nil
					Logging.devError("-- [VehicleCharacter:loadCharacter] Could not load animation CharSet from: [%s/%s]", getName(getParent(v29)), getName(v29))
				else
					p_u_17.idleClipIndex = getAnimClipIndex(p_u_17.animationCharsetId, "idle1Source")
					clearAnimTrackClip(p_u_17.animationCharsetId, 0)
					assignAnimTrackClip(p_u_17.animationCharsetId, 0, p_u_17.idleClipIndex)
					setAnimTrackLoopState(p_u_17.animationCharsetId, 0, true)
					p_u_17.idleAnimationState = false
				end
			end
		end
		local v31 = p19.playerStyle
		p_u_17.playerModel:loadFromStyleAsync(v31, function(_, p32, _)
			-- upvalues: (copy) p_u_17
			if p32 == HumanModelLoadingState.OK then
				p_u_17.isStyleLoaded = true
				p_u_17:setDirty(true)
				p_u_17:setCharacterVisibility(p_u_17.isVisible)
			end
		end, nil, nil)
	else
		p_u_17.playerModel:delete()
		p_u_17.playerModel = nil
		Logging.error("Failed to load vehicleCharacter")
	end
	local v33 = p19.asyncCallbackObject
	local v34 = p19.asyncCallbackFunction
	local v35 = p19.asyncCallbackArguments
	if v34 ~= nil then
		v34(v33, p18, v35)
	end
end
function VehicleCharacter.delete(p36)
	p36:unloadCharacter()
end
function VehicleCharacter.unloadCharacter(p37)
	if p37.playerModel ~= nil then
		p37.characterDistanceRefNode = p37.characterDistanceRefNodeCustom or p37.characterNode
		p37.playerModel:delete()
		p37.playerModel = nil
		if p37.animationPlayer ~= nil then
			delete(p37.animationPlayer)
			p37.animationPlayer = nil
		end
	end
end
function VehicleCharacter.setDirty(p38, p39)
	if p38.playerModel ~= nil then
		for v40, v41 in pairs(p38.ikChainTargets) do
			if v41.setDirty or p39 then
				IKUtil.setIKChainDirty(p38.playerModel:getIKChains(), v40)
			end
		end
	end
end
function VehicleCharacter.updateIKChains(p42)
	IKUtil.updateIKChains(p42.playerModel:getIKChains(), true)
end
function VehicleCharacter.setIKChainPoseByTarget(p43, p44, p45)
	if p43.playerModel ~= nil then
		local v46 = p43.playerModel:getIKChains()
		local v47 = IKUtil.getIKChainByTarget(v46, p44)
		if v47 ~= nil then
			IKUtil.setIKChainPose(v46, v47.id, p45)
		end
	end
end
function VehicleCharacter.setSpineDirty(p48, p49)
	local v50 = ((math.abs(p49) < p48.characterSpineNodeAccDeadZone and 0 or p49) - p48.characterSpineNodeMinAcc) / (p48.characterSpineNodeMaxAcc - p48.characterSpineNodeMinAcc)
	local v51 = math.clamp(v50, 0, 1)
	local v52 = MathUtil.lerp(p48.characterSpineNodeMinRot, p48.characterSpineNodeMaxRot, v51)
	if v52 ~= p48.characterSpineLastRotation then
		p48.characterSpineLastRotation = p48.characterSpineLastRotation * 0.95 + v52 * 0.05
		setRotation(p48.player.spineNode, p48.characterSpineLastRotation, 0, 0)
		p48:setDirty()
	end
end
function VehicleCharacter.updateVisibility(p53)
	if p53.isStyleLoaded and (entityExists(p53.characterDistanceRefNode) and entityExists(g_cameraManager:getActiveCamera())) then
		p53:setCharacterVisibility(calcDistanceFrom(p53.characterDistanceRefNode, g_cameraManager:getActiveCamera()) >= p53.characterCameraMinDistance)
	end
end
function VehicleCharacter.setCharacterVisibility(p54, p55)
	if p54.characterNode ~= nil then
		setVisibility(p54.characterNode, p55)
	end
	if p54.playerModel ~= nil and p54.playerModel.isLoaded then
		p54.playerModel:setVisibility(p55)
	end
	p54.isVisible = p55
end
function VehicleCharacter.setAllowCharacterUpdate(p56, p57)
	p56.allowUpdate = p57
end
function VehicleCharacter.getAllowCharacterUpdate(p58)
	return p58.allowUpdate
end
function VehicleCharacter.update(p59, _)
	if p59.playerModel ~= nil and p59.playerModel.isLoaded then
		if Platform.gameplay.allowVehicleCharacterIKDirtyUpdate and (p59.vehicle.currentUpdateDistance < p59.maxUpdateDistance and p59.isVisible) then
			if p59:getAllowCharacterUpdate() then
				p59:setDirty(false)
			end
			p59:updateIKChains()
		end
		if p59.useIdleAnimation then
			if p59.vehicle.currentUpdateDistance < p59.maxUpdateDistance then
				if not p59.idleAnimationState then
					p59.idleAnimationState = true
					enableAnimTrack(p59.animationCharsetId, 0)
					return
				end
			elseif p59.idleAnimationState then
				p59.idleAnimationState = false
				disableAnimTrack(p59.animationCharsetId, 0)
			end
		end
	end
end
function VehicleCharacter.getIKChainTargets(p60)
	return p60.ikChainTargets
end
function VehicleCharacter.setIKChainTargets(p61, p62, p63)
	if p61.ikChainTargets ~= p62 or p63 then
		p61.ikChainTargets = p62
		if p61.playerModel ~= nil then
			for v64, v65 in pairs(p61.ikChainTargets) do
				IKUtil.setTarget(p61.playerModel:getIKChains(), v64, v65)
			end
			p61:setDirty(true)
		end
	end
end
function VehicleCharacter.getPlayerStyle(p66)
	if p66.playerModel == nil then
		return nil
	else
		return p66.playerModel.style
	end
end
function VehicleCharacter.registerCharacterXMLPaths(p67, p68, _)
	p67:register(XMLValueType.NODE_INDEX, p68 .. "#node", "Character root node")
	p67:register(XMLValueType.FLOAT, p68 .. "#cameraMinDistance", "Min. distance until character is hidden", 1.5)
	p67:register(XMLValueType.NODE_INDEX, p68 .. "#distanceRefNode", "Distance reference node", "Character root node")
	p67:register(XMLValueType.BOOL, p68 .. "#useAnimation", "Use animation instead of ik chains", false)
	p67:register(XMLValueType.BOOL, p68 .. "#useIdleAnimation", "Apply character idle animation additionally to ik chain control", "set if #useAnimation not set")
	p67:register(XMLValueType.VECTOR_ROT, p68 .. "#spineRotationOffset", "Spine rotation offset")
	p67:register(XMLValueType.BOOL, p68 .. "#speedDependedSpine", "Speed dependent spine", false)
	p67:register(XMLValueType.ANGLE, p68 .. "#spineNodeMinRot", "Spine node min. rotation", 10)
	p67:register(XMLValueType.ANGLE, p68 .. "#spineNodeMaxRot", "Spine node max. rotation", -10)
	p67:register(XMLValueType.FLOAT, p68 .. "#spineNodeMinAcc", "Spine node min. acceleration", -1)
	p67:register(XMLValueType.FLOAT, p68 .. "#spineNodeMaxAcc", "Spine node max. acceleration", 1)
	p67:register(XMLValueType.FLOAT, p68 .. "#spineNodeAccDeadZone", "Spine node acceleration dead zone", 0.2)
	p67:register(XMLValueType.FLOAT, p68 .. "#maxUpdateDistance", "Max. distance to vehicle root to update ik chains of character", VehicleCharacter.DEFAULT_MAX_UPDATE_DISTANCE)
	p67:register(XMLValueType.FLOAT, p68 .. "#clipDistance", "Clip distance of character", VehicleCharacter.DEFAULT_CLIP_DISTANCE)
	IKUtil.registerIKChainTargetsXMLPaths(p67, p68)
end

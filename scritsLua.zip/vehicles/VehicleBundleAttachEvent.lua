VehicleBundleAttachEvent = {}
local v_u_1 = Class(VehicleBundleAttachEvent, Event)
InitStaticEventClass(VehicleBundleAttachEvent, "VehicleBundleAttachEvent")
function VehicleBundleAttachEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleBundleAttachEvent.new(p2)
	local v3 = VehicleBundleAttachEvent.emptyNew()
	v3.bundles = p2
	return v3
end
function VehicleBundleAttachEvent.readStream(_, p4, _)
	for _ = 1, streamReadUInt8(p4) do
		local v5 = NetworkUtil.readNodeObjectId(p4)
		local v6 = NetworkUtil.readNodeObjectId(p4)
		local v7 = streamReadUIntN(p4, 7)
		local v8 = streamReadUIntN(p4, 7)
		local v9 = g_currentMission.vehicleSystem.vehiclesToAttach
		table.insert(v9, {
			["v1id"] = v5,
			["v2id"] = v6,
			["inputJointIndex"] = v7,
			["jointIndex"] = v8
		})
	end
end
function VehicleBundleAttachEvent.writeStream(p10, p11, _)
	streamWriteUInt8(p11, #p10.bundles)
	for v12 = 1, #p10.bundles do
		local v13 = p10.bundles[v12]
		NetworkUtil.writeNodeObjectId(p11, NetworkUtil.getObjectId(v13.v1))
		NetworkUtil.writeNodeObjectId(p11, NetworkUtil.getObjectId(v13.v2))
		streamWriteUIntN(p11, v13.input, 7)
		streamWriteUIntN(p11, v13.attacher, 7)
	end
end
function VehicleBundleAttachEvent.run(p14, p15)
	if p14.object ~= nil and p14.object:getIsSynchronized() then
		p14.object:attachImplement(p14.implement, p14.inputJointIndex, p14.jointIndex, true, nil, p14.startLowered)
	end
	if not p15:getIsServer() then
		g_server:broadcastEvent(p14, nil, p15, p14.object)
	end
end

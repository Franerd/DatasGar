VehicleLowerImplementEvent = {}
local v_u_1 = Class(VehicleLowerImplementEvent, Event)
InitStaticEventClass(VehicleLowerImplementEvent, "VehicleLowerImplementEvent")
function VehicleLowerImplementEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleLowerImplementEvent.new(p2, p3, p4)
	local v5 = VehicleLowerImplementEvent.emptyNew()
	v5.jointIndex = p3
	v5.vehicle = p2
	v5.moveDown = p4
	return v5
end
function VehicleLowerImplementEvent.readStream(p6, p7, p8)
	p6.vehicle = NetworkUtil.readNodeObject(p7)
	p6.jointIndex = streamReadInt8(p7)
	p6.moveDown = streamReadBool(p7)
	p6:run(p8)
end
function VehicleLowerImplementEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.vehicle)
	streamWriteInt8(p10, p9.jointIndex)
	streamWriteBool(p10, p9.moveDown)
end
function VehicleLowerImplementEvent.run(p11, p12)
	if p11.vehicle ~= nil and p11.vehicle:getIsSynchronized() then
		p11.vehicle:setJointMoveDown(p11.jointIndex, p11.moveDown, true)
	end
	if not p12:getIsServer() then
		g_server:broadcastEvent(VehicleLowerImplementEvent.new(p11.vehicle, p11.jointIndex, p11.moveDown), nil, p12, p11.vehicle)
	end
end
function VehicleLowerImplementEvent.sendEvent(p13, p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(VehicleLowerImplementEvent.new(p13, p14, p15), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(VehicleLowerImplementEvent.new(p13, p14, p15))
	end
end

Vehicle = {}
local v_u_1 = Class(Vehicle, Object)
Vehicle.defaultWidth = 6
Vehicle.defaultLength = 8
Vehicle.defaultHeight = 4
Vehicle.DEFAULT_SIZE = {
	["width"] = Vehicle.defaultWidth,
	["length"] = Vehicle.defaultLength,
	["height"] = Vehicle.defaultHeight,
	["widthOffset"] = 0,
	["lengthOffset"] = 0,
	["heightOffset"] = 0
}
Vehicle.SPRING_SCALE = 10
Vehicle.NUM_INTERACTION_FLAGS = 0
Vehicle.INTERACTION_FLAG_NONE = 0
Vehicle.NUM_STATE_CHANGES = 0
Vehicle.DAMAGED_SPEEDLIMIT_REDUCTION = 0.3
Vehicle.INPUT_CONTEXT_NAME = "VEHICLE"
Vehicle.xmlSchema = nil
Vehicle.xmlSchemaSounds = nil
Vehicle.xmlSchemaSavegame = nil
Vehicle.DEBUG_NETWORK_READ_WRITE = false
Vehicle.DEBUG_NETWORK_READ_WRITE_UPDATE = false
InitStaticObjectClass(Vehicle, "Vehicle")
source("dataS/scripts/vehicles/VehicleDebug.lua")
source("dataS/scripts/vehicles/VehicleStateRecorder.lua")
source("dataS/scripts/vehicles/VehicleSchemaOverlayData.lua")
source("dataS/scripts/vehicles/VehicleBrokenEvent.lua")
source("dataS/scripts/vehicles/VehiclePropertyState.lua")
source("dataS/scripts/vehicles/VehicleStateChange.lua")
source("dataS/scripts/vehicles/VehicleSetIsReconfiguratingEvent.lua")
function Vehicle.registerInteractionFlag(p2)
	local v3 = "INTERACTION_FLAG_" .. string.upper(p2)
	if Vehicle[v3] == nil then
		Vehicle.NUM_INTERACTION_FLAGS = Vehicle.NUM_INTERACTION_FLAGS + 1
		Vehicle[v3] = Vehicle.NUM_INTERACTION_FLAGS
	end
	return Vehicle[v3]
end
function Vehicle.registerEvents(p4)
	SpecializationUtil.registerEvent(p4, "onPreLoad")
	SpecializationUtil.registerEvent(p4, "onLoad")
	SpecializationUtil.registerEvent(p4, "onPostLoad")
	SpecializationUtil.registerEvent(p4, "onPreInitComponentPlacement")
	SpecializationUtil.registerEvent(p4, "onPreLoadFinished")
	SpecializationUtil.registerEvent(p4, "onLoadFinished")
	SpecializationUtil.registerEvent(p4, "onLoadEnd")
	SpecializationUtil.registerEvent(p4, "onRegistered")
	SpecializationUtil.registerEvent(p4, "onPreDelete")
	SpecializationUtil.registerEvent(p4, "onDelete")
	SpecializationUtil.registerEvent(p4, "onSave")
	SpecializationUtil.registerEvent(p4, "onReadStream")
	SpecializationUtil.registerEvent(p4, "onWriteStream")
	SpecializationUtil.registerEvent(p4, "onReadUpdateStream")
	SpecializationUtil.registerEvent(p4, "onWriteUpdateStream")
	SpecializationUtil.registerEvent(p4, "onReadPositionUpdateStream")
	SpecializationUtil.registerEvent(p4, "onWritePositionUpdateStream")
	SpecializationUtil.registerEvent(p4, "onHandToolTaken")
	SpecializationUtil.registerEvent(p4, "onHandToolPlaced")
	SpecializationUtil.registerEvent(p4, "onPreUpdate")
	SpecializationUtil.registerEvent(p4, "onUpdate")
	SpecializationUtil.registerEvent(p4, "onUpdateInterpolation")
	SpecializationUtil.registerEvent(p4, "onUpdateDebug")
	SpecializationUtil.registerEvent(p4, "onPostUpdate")
	SpecializationUtil.registerEvent(p4, "onUpdateTick")
	SpecializationUtil.registerEvent(p4, "onPostUpdateTick")
	SpecializationUtil.registerEvent(p4, "onUpdateEnd")
	SpecializationUtil.registerEvent(p4, "onDraw")
	SpecializationUtil.registerEvent(p4, "onDrawUIInfo")
	SpecializationUtil.registerEvent(p4, "onActivate")
	SpecializationUtil.registerEvent(p4, "onDeactivate")
	SpecializationUtil.registerEvent(p4, "onStateChange")
	SpecializationUtil.registerEvent(p4, "onPreRegisterActionEvents")
	SpecializationUtil.registerEvent(p4, "onRegisterActionEvents")
	SpecializationUtil.registerEvent(p4, "onRootVehicleChanged")
	SpecializationUtil.registerEvent(p4, "onSelect")
	SpecializationUtil.registerEvent(p4, "onUnselect")
	SpecializationUtil.registerEvent(p4, "onSetBroken")
	SpecializationUtil.registerEvent(p4, "onSaleItemSet")
end
function Vehicle.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "register", Vehicle.register)
	SpecializationUtil.registerFunction(p5, "setOwnerFarmId", Vehicle.setOwnerFarmId)
	SpecializationUtil.registerFunction(p5, "loadSubSharedI3DFile", Vehicle.loadSubSharedI3DFile)
	SpecializationUtil.registerFunction(p5, "drawUIInfo", Vehicle.drawUIInfo)
	SpecializationUtil.registerFunction(p5, "raiseActive", Vehicle.raiseActive)
	SpecializationUtil.registerFunction(p5, "setLoadingState", Vehicle.setLoadingState)
	SpecializationUtil.registerFunction(p5, "setLoadingStep", Vehicle.setLoadingStep)
	SpecializationUtil.registerFunction(p5, "addToPhysics", Vehicle.addToPhysics)
	SpecializationUtil.registerFunction(p5, "removeFromPhysics", Vehicle.removeFromPhysics)
	SpecializationUtil.registerFunction(p5, "setVisibility", Vehicle.setVisibility)
	SpecializationUtil.registerFunction(p5, "setRelativePosition", Vehicle.setRelativePosition)
	SpecializationUtil.registerFunction(p5, "setAbsolutePosition", Vehicle.setAbsolutePosition)
	SpecializationUtil.registerFunction(p5, "getLimitedVehicleYPosition", Vehicle.getLimitedVehicleYPosition)
	SpecializationUtil.registerFunction(p5, "setWorldPosition", Vehicle.setWorldPosition)
	SpecializationUtil.registerFunction(p5, "setWorldPositionQuaternion", Vehicle.setWorldPositionQuaternion)
	SpecializationUtil.registerFunction(p5, "setDefaultComponentPosition", Vehicle.setDefaultComponentPosition)
	SpecializationUtil.registerFunction(p5, "getIsNodeActive", Vehicle.getIsNodeActive)
	SpecializationUtil.registerFunction(p5, "updateVehicleSpeed", Vehicle.updateVehicleSpeed)
	SpecializationUtil.registerFunction(p5, "getUpdatePriority", Vehicle.getUpdatePriority)
	SpecializationUtil.registerFunction(p5, "getPrice", Vehicle.getPrice)
	SpecializationUtil.registerFunction(p5, "getSellPrice", Vehicle.getSellPrice)
	SpecializationUtil.registerFunction(p5, "getDailyUpkeep", Vehicle.getDailyUpkeep)
	SpecializationUtil.registerFunction(p5, "getIsOnField", Vehicle.getIsOnField)
	SpecializationUtil.registerFunction(p5, "getParentComponent", Vehicle.getParentComponent)
	SpecializationUtil.registerFunction(p5, "getLastSpeed", Vehicle.getLastSpeed)
	SpecializationUtil.registerFunction(p5, "getDeactivateOnLeave", Vehicle.getDeactivateOnLeave)
	SpecializationUtil.registerFunction(p5, "getOwnerConnection", Vehicle.getOwnerConnection)
	SpecializationUtil.registerFunction(p5, "getIsVehicleNode", Vehicle.getIsVehicleNode)
	SpecializationUtil.registerFunction(p5, "getIsOperating", Vehicle.getIsOperating)
	SpecializationUtil.registerFunction(p5, "getIsActive", Vehicle.getIsActive)
	SpecializationUtil.registerFunction(p5, "getIsActiveForInput", Vehicle.getIsActiveForInput)
	SpecializationUtil.registerFunction(p5, "getIsActiveForSound", Vehicle.getIsActiveForSound)
	SpecializationUtil.registerFunction(p5, "getIsLowered", Vehicle.getIsLowered)
	SpecializationUtil.registerFunction(p5, "updateWaterInfo", Vehicle.updateWaterInfo)
	SpecializationUtil.registerFunction(p5, "onWaterRaycastCallback", Vehicle.onWaterRaycastCallback)
	SpecializationUtil.registerFunction(p5, "setBroken", Vehicle.setBroken)
	SpecializationUtil.registerFunction(p5, "getVehicleDamage", Vehicle.getVehicleDamage)
	SpecializationUtil.registerFunction(p5, "getRepairPrice", Vehicle.getRepairPrice)
	SpecializationUtil.registerFunction(p5, "getRepaintPrice", Vehicle.getRepaintPrice)
	SpecializationUtil.registerFunction(p5, "setMassDirty", Vehicle.setMassDirty)
	SpecializationUtil.registerFunction(p5, "updateMass", Vehicle.updateMass)
	SpecializationUtil.registerFunction(p5, "getMaxComponentMassReached", Vehicle.getMaxComponentMassReached)
	SpecializationUtil.registerFunction(p5, "getAdditionalComponentMass", Vehicle.getAdditionalComponentMass)
	SpecializationUtil.registerFunction(p5, "getTotalMass", Vehicle.getTotalMass)
	SpecializationUtil.registerFunction(p5, "getComponentMass", Vehicle.getComponentMass)
	SpecializationUtil.registerFunction(p5, "getDefaultMass", Vehicle.getDefaultMass)
	SpecializationUtil.registerFunction(p5, "getOverallCenterOfMass", Vehicle.getOverallCenterOfMass)
	SpecializationUtil.registerFunction(p5, "getVehicleWorldXRot", Vehicle.getVehicleWorldXRot)
	SpecializationUtil.registerFunction(p5, "getVehicleWorldDirection", Vehicle.getVehicleWorldDirection)
	SpecializationUtil.registerFunction(p5, "getFillLevelInformation", Vehicle.getFillLevelInformation)
	SpecializationUtil.registerFunction(p5, "activate", Vehicle.activate)
	SpecializationUtil.registerFunction(p5, "deactivate", Vehicle.deactivate)
	SpecializationUtil.registerFunction(p5, "setComponentJointFrame", Vehicle.setComponentJointFrame)
	SpecializationUtil.registerFunction(p5, "setComponentJointRotLimit", Vehicle.setComponentJointRotLimit)
	SpecializationUtil.registerFunction(p5, "setComponentJointTransLimit", Vehicle.setComponentJointTransLimit)
	SpecializationUtil.registerFunction(p5, "loadComponentFromXML", Vehicle.loadComponentFromXML)
	SpecializationUtil.registerFunction(p5, "loadComponentJointFromXML", Vehicle.loadComponentJointFromXML)
	SpecializationUtil.registerFunction(p5, "createComponentJoint", Vehicle.createComponentJoint)
	SpecializationUtil.registerFunction(p5, "loadSchemaOverlay", Vehicle.loadSchemaOverlay)
	SpecializationUtil.registerFunction(p5, "getAdditionalSchemaText", Vehicle.getAdditionalSchemaText)
	SpecializationUtil.registerFunction(p5, "getUseTurnedOnSchema", Vehicle.getUseTurnedOnSchema)
	SpecializationUtil.registerFunction(p5, "dayChanged", Vehicle.dayChanged)
	SpecializationUtil.registerFunction(p5, "periodChanged", Vehicle.periodChanged)
	SpecializationUtil.registerFunction(p5, "raiseStateChange", Vehicle.raiseStateChange)
	SpecializationUtil.registerFunction(p5, "doCheckSpeedLimit", Vehicle.doCheckSpeedLimit)
	SpecializationUtil.registerFunction(p5, "interact", Vehicle.interact)
	SpecializationUtil.registerFunction(p5, "getInteractionHelp", Vehicle.getInteractionHelp)
	SpecializationUtil.registerFunction(p5, "getIsInteractive", Vehicle.getIsInteractive)
	SpecializationUtil.registerFunction(p5, "getDistanceToNode", Vehicle.getDistanceToNode)
	SpecializationUtil.registerFunction(p5, "getIsAIActive", Vehicle.getIsAIActive)
	SpecializationUtil.registerFunction(p5, "getIsPowered", Vehicle.getIsPowered)
	SpecializationUtil.registerFunction(p5, "getRequiresPower", Vehicle.getRequiresPower)
	SpecializationUtil.registerFunction(p5, "getIsInShowroom", Vehicle.getIsInShowroom)
	SpecializationUtil.registerFunction(p5, "addVehicleToAIImplementList", Vehicle.addVehicleToAIImplementList)
	SpecializationUtil.registerFunction(p5, "setOperatingTime", Vehicle.setOperatingTime)
	SpecializationUtil.registerFunction(p5, "requestActionEventUpdate", Vehicle.requestActionEventUpdate)
	SpecializationUtil.registerFunction(p5, "removeActionEvents", Vehicle.removeActionEvents)
	SpecializationUtil.registerFunction(p5, "updateActionEvents", Vehicle.updateActionEvents)
	SpecializationUtil.registerFunction(p5, "registerActionEvents", Vehicle.registerActionEvents)
	SpecializationUtil.registerFunction(p5, "addActionEvent", Vehicle.addActionEvent)
	SpecializationUtil.registerFunction(p5, "updateSelectableObjects", Vehicle.updateSelectableObjects)
	SpecializationUtil.registerFunction(p5, "registerSelectableObjects", Vehicle.registerSelectableObjects)
	SpecializationUtil.registerFunction(p5, "addSubselection", Vehicle.addSubselection)
	SpecializationUtil.registerFunction(p5, "getRootVehicle", Vehicle.getRootVehicle)
	SpecializationUtil.registerFunction(p5, "findRootVehicle", Vehicle.findRootVehicle)
	SpecializationUtil.registerFunction(p5, "getChildVehicles", Vehicle.getChildVehicles)
	SpecializationUtil.registerFunction(p5, "addChildVehicles", Vehicle.addChildVehicles)
	SpecializationUtil.registerFunction(p5, "updateVehicleChain", Vehicle.updateVehicleChain)
	SpecializationUtil.registerFunction(p5, "getCanBeSelected", Vehicle.getCanBeSelected)
	SpecializationUtil.registerFunction(p5, "getBlockSelection", Vehicle.getBlockSelection)
	SpecializationUtil.registerFunction(p5, "getCanToggleSelectable", Vehicle.getCanToggleSelectable)
	SpecializationUtil.registerFunction(p5, "unselectVehicle", Vehicle.unselectVehicle)
	SpecializationUtil.registerFunction(p5, "selectVehicle", Vehicle.selectVehicle)
	SpecializationUtil.registerFunction(p5, "getIsSelected", Vehicle.getIsSelected)
	SpecializationUtil.registerFunction(p5, "getSelectedObject", Vehicle.getSelectedObject)
	SpecializationUtil.registerFunction(p5, "getSelectedVehicle", Vehicle.getSelectedVehicle)
	SpecializationUtil.registerFunction(p5, "setSelectedVehicle", Vehicle.setSelectedVehicle)
	SpecializationUtil.registerFunction(p5, "setSelectedObject", Vehicle.setSelectedObject)
	SpecializationUtil.registerFunction(p5, "getIsReadyForAutomatedTrainTravel", Vehicle.getIsReadyForAutomatedTrainTravel)
	SpecializationUtil.registerFunction(p5, "getIsAutomaticShiftingAllowed", Vehicle.getIsAutomaticShiftingAllowed)
	SpecializationUtil.registerFunction(p5, "getSpeedLimit", Vehicle.getSpeedLimit)
	SpecializationUtil.registerFunction(p5, "getRawSpeedLimit", Vehicle.getRawSpeedLimit)
	SpecializationUtil.registerFunction(p5, "getActiveFarm", Vehicle.getActiveFarm)
	SpecializationUtil.registerFunction(p5, "onVehicleWakeUpCallback", Vehicle.onVehicleWakeUpCallback)
	SpecializationUtil.registerFunction(p5, "getCanBeMounted", Vehicle.getCanBeMounted)
	SpecializationUtil.registerFunction(p5, "getName", Vehicle.getName)
	SpecializationUtil.registerFunction(p5, "getFullName", Vehicle.getFullName)
	SpecializationUtil.registerFunction(p5, "getBrand", Vehicle.getBrand)
	SpecializationUtil.registerFunction(p5, "getImageFilename", Vehicle.getImageFilename)
	SpecializationUtil.registerFunction(p5, "getCanBePickedUp", Vehicle.getCanBePickedUp)
	SpecializationUtil.registerFunction(p5, "getCanBeReset", Vehicle.getCanBeReset)
	SpecializationUtil.registerFunction(p5, "getCanBeSold", Vehicle.getCanBeSold)
	SpecializationUtil.registerFunction(p5, "getReloadXML", Vehicle.getReloadXML)
	SpecializationUtil.registerFunction(p5, "getIsInUse", Vehicle.getIsInUse)
	SpecializationUtil.registerFunction(p5, "getPropertyState", Vehicle.getPropertyState)
	SpecializationUtil.registerFunction(p5, "getAreControlledActionsAllowed", Vehicle.getAreControlledActionsAllowed)
	SpecializationUtil.registerFunction(p5, "getAreControlledActionsAvailable", Vehicle.getAreControlledActionsAvailable)
	SpecializationUtil.registerFunction(p5, "getAreControlledActionsAccessible", Vehicle.getAreControlledActionsAccessible)
	SpecializationUtil.registerFunction(p5, "getControlledActionIcons", Vehicle.getControlledActionIcons)
	SpecializationUtil.registerFunction(p5, "playControlledActions", Vehicle.playControlledActions)
	SpecializationUtil.registerFunction(p5, "getActionControllerDirection", Vehicle.getActionControllerDirection)
	SpecializationUtil.registerFunction(p5, "createMapHotspot", Vehicle.createMapHotspot)
	SpecializationUtil.registerFunction(p5, "getMapHotspot", Vehicle.getMapHotspot)
	SpecializationUtil.registerFunction(p5, "updateMapHotspot", Vehicle.updateMapHotspot)
	SpecializationUtil.registerFunction(p5, "getIsMapHotspotVisible", Vehicle.getIsMapHotspotVisible)
	SpecializationUtil.registerFunction(p5, "getMapHotspotRotation", Vehicle.getMapHotspotRotation)
	SpecializationUtil.registerFunction(p5, "getShowInVehiclesOverview", Vehicle.getShowInVehiclesOverview)
	SpecializationUtil.registerFunction(p5, "showInfo", Vehicle.showInfo)
	SpecializationUtil.registerFunction(p5, "loadObjectChangeValuesFromXML", Vehicle.loadObjectChangeValuesFromXML)
	SpecializationUtil.registerFunction(p5, "setObjectChangeValues", Vehicle.setObjectChangeValues)
	SpecializationUtil.registerFunction(p5, "getIsSynchronized", Vehicle.getIsSynchronized)
end
function Vehicle.init()
	g_vehicleConfigurationManager:addConfigurationType("baseColor", g_i18n:getText("configuration_baseColor"), nil, VehicleConfigurationItemColor)
	g_vehicleConfigurationManager:addConfigurationType("vehicleType", g_i18n:getText("configuration_design"), nil, VehicleConfigurationItemVehicleType)
	g_vehicleConfigurationManager:addConfigurationType("component", g_i18n:getText("configuration_design"), "base", VehicleConfigurationItem)
	g_vehicleConfigurationManager:addConfigurationType("design", g_i18n:getText("configuration_design"), nil, VehicleConfigurationItem)
	g_vehicleConfigurationManager:addConfigurationType("designColor", g_i18n:getText("configuration_designColor"), nil, VehicleConfigurationItemColor)
	for v6 = 2, 16 do
		g_vehicleConfigurationManager:addConfigurationType(string.format("design%d", v6), g_i18n:getText("configuration_design"), nil, VehicleConfigurationItem)
		g_vehicleConfigurationManager:addConfigurationType(string.format("designColor%d", v6), g_i18n:getText("configuration_designColor"), nil, VehicleConfigurationItemColor)
	end
	g_storeManager:addSpecType("age", "shopListAttributeIconLifeTime", nil, Vehicle.getSpecValueAge, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("operatingTime", "shopListAttributeIconOperatingHours", nil, Vehicle.getSpecValueOperatingTime, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("dailyUpkeep", "shopListAttributeIconMaintenanceCosts", nil, Vehicle.getSpecValueDailyUpkeep, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("workingWidth", "shopListAttributeIconWorkingWidth", Vehicle.loadSpecValueWorkingWidth, Vehicle.getSpecValueWorkingWidth, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("workingWidthConfig", "shopListAttributeIconWorkingWidth", Vehicle.loadSpecValueWorkingWidthConfig, Vehicle.getSpecValueWorkingWidthConfig, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("speedLimit", "shopListAttributeIconWorkSpeed", Vehicle.loadSpecValueSpeedLimit, Vehicle.getSpecValueSpeedLimit, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("weight", "shopListAttributeIconWeight", Vehicle.loadSpecValueWeight, Vehicle.getSpecValueWeight, StoreSpecies.VEHICLE, nil, Vehicle.getSpecConfigValuesWeight)
	g_storeManager:addSpecType("additionalWeight", "shopListAttributeIconAdditionalWeight", Vehicle.loadSpecValueAdditionalWeight, Vehicle.getSpecValueAdditionalWeight, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("combinations", nil, Vehicle.loadSpecValueCombinations, Vehicle.getSpecValueCombinations, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("slots", "shopListAttributeIconSlots", nil, Vehicle.getSpecValueSlots, StoreSpecies.VEHICLE)
	Vehicle.xmlSchema = XMLSchema.new("vehicle")
	g_storeManager:addSpeciesXMLSchema(StoreSpecies.VEHICLE, Vehicle.xmlSchema)
	g_vehicleTypeManager:setXMLSchema(Vehicle.xmlSchema)
	Vehicle.xmlSchemaSounds = XMLSchema.new("vehicle_sounds")
	Vehicle.xmlSchemaSounds:setRootNodeName("sounds")
	Vehicle.xmlSchema:addSubSchema(Vehicle.xmlSchemaSounds, "sounds")
	Vehicle.xmlSchemaSavegame = XMLSchema.new("savegame_vehicles")
	Vehicle.registers()
end
function Vehicle.postInit()
	local v_u_7 = Vehicle.xmlSchema
	local v8 = g_vehicleConfigurationManager:getConfigurations()
	for _, v_u_9 in pairs(v8) do
		g_asyncTaskManager:addSubtask(function()
			-- upvalues: (copy) v_u_9, (copy) v_u_7
			if v_u_9.itemClass.registerXMLPaths ~= nil then
				v_u_9.itemClass.registerXMLPaths(v_u_7, v_u_9.configurationsKey, v_u_9.configurationKey .. "(?)")
			end
			v_u_7:register(XMLValueType.FLOAT, v_u_9.configurationKey .. "(?)#workingWidth", "Work width to display in shop while config is active")
			v_u_7:register(XMLValueType.L10N_STRING, v_u_9.configurationKey .. "(?)#typeDesc", "Type description text to display in shop while config is active")
		end)
	end
end
function Vehicle.registers()
	local v10 = Vehicle.xmlSchema
	local v11 = Vehicle.xmlSchemaSavegame
	v10:register(XMLValueType.STRING, "vehicle#type", "Vehicle type")
	v10:registerAutoCompletionDataSource("vehicle#type", "$dataS/vehicleTypes.xml", "vehicleTypes.type#name")
	v10:register(XMLValueType.STRING, "vehicle.annotation", "Annotation", nil, true)
	StoreManager.registerStoreDataXMLPaths(v10, "vehicle")
	v10:register(XMLValueType.STRING, "vehicle.storeData.specs.workingWidth", "Working width to display in shop")
	v10:register(XMLValueType.STRING, "vehicle.storeData.specs.combination(?)#xmlFilename", "Combination to display in shop")
	v10:registerAutoCompletionDataSource("vehicle.storeData.specs.combination(?)#xmlFilename", "dataS/storeItems.xml", "storeItems.storeItem#xmlFilename")
	v10:register(XMLValueType.STRING, "vehicle.storeData.specs.combination(?)#filterCategory", "Filter in this category")
	v10:registerAutoCompletionDataSource("vehicle.storeData.specs.combination(?)#filterCategory", "$dataS/storeCategories.xml", "categories.category#name")
	v10:register(XMLValueType.STRING, "vehicle.storeData.specs.combination(?)#filterSpec", "Filter for this spec type")
	v10:register(XMLValueType.FLOAT, "vehicle.storeData.specs.combination(?)#filterSpecMin", "Filter spec type in this range (min.)")
	v10:register(XMLValueType.FLOAT, "vehicle.storeData.specs.combination(?)#filterSpecMax", "Filter spec type in this range (max.)")
	v10:register(XMLValueType.BOOL, "vehicle.storeData.specs.weight#ignore", "Hide vehicle weight in shop", false)
	v10:register(XMLValueType.FLOAT, "vehicle.storeData.specs.weight#minValue", "Min. weight to display in shop")
	v10:register(XMLValueType.FLOAT, "vehicle.storeData.specs.weight#maxValue", "Max. weight to display in shop")
	v10:register(XMLValueType.STRING, "vehicle.storeData.specs.weight.config(?)#name", "Name of configuration")
	v10:register(XMLValueType.INT, "vehicle.storeData.specs.weight.config(?)#index", "Index of selected configuration")
	v10:register(XMLValueType.FLOAT, "vehicle.storeData.specs.weight.config(?)#value", "Weight value which can be reached with this configuration")
	v10:register(XMLValueType.STRING, "vehicle.base.filename", "Path to i3d filename", nil)
	v10:register(XMLValueType.L10N_STRING, "vehicle.base.typeDesc", "Type description", nil)
	v10:register(XMLValueType.BOOL, "vehicle.base.synchronizePosition", "Vehicle position synchronized", true)
	v10:register(XMLValueType.BOOL, "vehicle.base.supportsPickUp", "Vehicle can be picked up by hand", false)
	v10:register(XMLValueType.BOOL, "vehicle.base.canBeReset", "Vehicle can be reset to shop", true)
	v10:register(XMLValueType.BOOL, "vehicle.base.showInVehicleMenu", "Vehicle shows in vehicle menu", true)
	v10:register(XMLValueType.BOOL, "vehicle.base.supportsRadio", "Vehicle supported radio", true)
	v10:register(XMLValueType.BOOL, "vehicle.base.input#allowed", "Vehicle allows key input", true)
	v10:register(XMLValueType.BOOL, "vehicle.base.selection#allowed", "Vehicle selection is allowed", true)
	v10:register(XMLValueType.FLOAT, "vehicle.base.tailwaterDepth#warning", "Tailwater depth warning is shown from this water depth", "25% of vehicle height")
	v10:register(XMLValueType.FLOAT, "vehicle.base.tailwaterDepth#threshold", "Vehicle is broken after this water depth", "75% of vehicle height")
	v10:register(XMLValueType.STRING, "vehicle.base.mapHotspot#type", "Map hotspot type", nil, nil, table.toList(VehicleHotspot.TYPE))
	v10:register(XMLValueType.BOOL, "vehicle.base.mapHotspot#available", "Map hotspot is available", true)
	v10:register(XMLValueType.FLOAT, "vehicle.base.speedLimit#value", "Speed limit")
	v10:register(XMLValueType.FLOAT, "vehicle.base.size#width", "Occupied width of the vehicle when loaded", nil, true)
	v10:register(XMLValueType.FLOAT, "vehicle.base.size#length", "Occupied length of the vehicle when loaded", nil, true)
	v10:register(XMLValueType.FLOAT, "vehicle.base.size#height", "Occupied height of the vehicle when loaded")
	v10:register(XMLValueType.FLOAT, "vehicle.base.size#widthOffset", "Width offset")
	v10:register(XMLValueType.FLOAT, "vehicle.base.size#lengthOffset", "Width offset")
	v10:register(XMLValueType.FLOAT, "vehicle.base.size#heightOffset", "Height offset")
	v10:register(XMLValueType.ANGLE, "vehicle.base.size#yRotation", "Y Rotation offset in i3d (Needs to be set to the vehicle\'s rotation in the i3d file and is e.g. used to check ai working direction)", 0)
	v10:register(XMLValueType.NODE_INDEX, "vehicle.base.steeringAxle#node", "Steering axle node used to calculate the steering angle of attachments")
	v10:register(XMLValueType.STRING, "vehicle.base.sounds#filename", "Path to external sound files")
	v10:register(XMLValueType.FLOAT, "vehicle.base.sounds#volumeFactor", "This factor will be applied to all sounds of this vehicle")
	I3DUtil.registerI3dMappingXMLPaths(v10, "vehicle")
	Vehicle.registerComponentXMLPaths(v10, "vehicle.base.components")
	Vehicle.registerComponentXMLPaths(v10, "vehicle.base.componentConfigurations.componentConfiguration(?)")
	ObjectChangeUtil.registerObjectChangesXMLPaths(v10, "vehicle.base")
	v10:register(XMLValueType.VECTOR_2, "vehicle.base.schemaOverlay#attacherJointPosition", "Position of attacher joint")
	v10:register(XMLValueType.VECTOR_2, "vehicle.base.schemaOverlay#basePosition", "Position of vehicle")
	v10:register(XMLValueType.STRING, "vehicle.base.schemaOverlay#name", "Name of schema overlay")
	v10:registerAutoCompletionDataSource("vehicle.base.schemaOverlay#name", "$dataS/vehicleSchemaOverlays.xml", "vehicleSchemaOverlays.overlay#name")
	v10:register(XMLValueType.FLOAT, "vehicle.base.schemaOverlay#invisibleBorderRight", "Size of invisible border on the right")
	v10:register(XMLValueType.FLOAT, "vehicle.base.schemaOverlay#invisibleBorderLeft", "Size of invisible border on the left")
	v10:register(XMLValueType.STRING, "vehicle.vehicleTypeConfigurations.vehicleTypeConfiguration(?)#vehicleType", "Vehicle type for configuration")
	v10:register(XMLValueType.BOOL, "vehicle.designConfigurations#preLoad", "Defines if the design configurations are applied before the execution of load or after. Can help if the configurations manipulate the wheel positions for example.", false)
	StoreItemUtil.registerConfigurationSetXMLPaths(v10, "vehicle")
	v11:register(XMLValueType.BOOL, "vehicles#loadAnyFarmInSingleplayer", "Load any farm in singleplayer", false)
	v11:register(XMLValueType.STRING, "vehicles.vehicle(?)#filename", "XML filename")
	v11:register(XMLValueType.STRING, "vehicles.vehicle(?)#modName", "Vehicle mod name")
	v11:register(XMLValueType.BOOL, "vehicles.vehicle(?)#isBroken", "If the vehicle is broken", false)
	v11:register(XMLValueType.BOOL, "vehicles.vehicle(?)#defaultFarmProperty", "Property of default farm", false)
	v11:register(XMLValueType.INT, "vehicles.vehicle(?)#id", "Vehicle id")
	v11:register(XMLValueType.STRING, "vehicles.vehicle(?)#tourId", "Tour id")
	v11:register(XMLValueType.INT, "vehicles.vehicle(?)#farmId", "Farm id")
	v11:register(XMLValueType.STRING, "vehicles.vehicle(?)#uniqueId", "Vehicle\'s unique id")
	v11:register(XMLValueType.FLOAT, "vehicles.vehicle(?)#age", "Age in number of months")
	v11:register(XMLValueType.FLOAT, "vehicles.vehicle(?)#price", "Price")
	VehiclePropertyState.registerXMLPath(v11, "vehicles.vehicle(?)#propertyState", "Property state")
	v11:register(XMLValueType.FLOAT, "vehicles.vehicle(?)#operatingTime", "Operating time")
	v11:register(XMLValueType.FLOAT, "vehicles.vehicle(?)#yOffset", "Y Offset")
	v11:register(XMLValueType.FLOAT, "vehicles.vehicle(?)#xPosition", "X Position")
	v11:register(XMLValueType.FLOAT, "vehicles.vehicle(?)#zPosition", "Z Position")
	v11:register(XMLValueType.FLOAT, "vehicles.vehicle(?)#yRotation", "Y Rotation")
	v11:register(XMLValueType.INT, "vehicles.vehicle(?)#selectedObjectIndex", "Selected object index")
	v11:register(XMLValueType.INT, "vehicles.vehicle(?)#subSelectedObjectIndex", "Sub selected object index")
	v11:register(XMLValueType.INT, "vehicles.vehicle(?).component(?)#index", "Component index")
	v11:register(XMLValueType.VECTOR_TRANS, "vehicles.vehicle(?).component(?)#position", "Component position")
	v11:register(XMLValueType.VECTOR_ROT, "vehicles.vehicle(?).component(?)#rotation", "Component rotation")
	v11:register(XMLValueType.STRING, "vehicles.vehicle(?).boughtConfiguration(?)#name", "Configuration name")
	v11:register(XMLValueType.STRING, "vehicles.vehicle(?).boughtConfiguration(?)#id", "Configuration save id")
	v11:register(XMLValueType.STRING, "vehicles.vehicle(?).configuration(?)#name", "Configuration name")
	v11:register(XMLValueType.STRING, "vehicles.vehicle(?).configuration(?)#id", "Configuration save id")
	VehicleActionController.registerXMLPaths(v11, "vehicles.vehicle(?).actionController")
	v11:register(XMLValueType.INT, "vehicles.attachments(?)#rootVehicleId", "Id of root vehicle")
end
function Vehicle.registerComponentXMLPaths(p12, p13)
	p12:register(XMLValueType.INT, p13 .. "#numComponents", "Number of components loaded from i3d", "number of components the i3d contains")
	p12:register(XMLValueType.FLOAT, p13 .. "#maxMass", "Max. overall mass the vehicle can have", "unlimited")
	p12:register(XMLValueType.INT, p13 .. ".component(?)#index", "Index of the component node in the i3d hierarchy")
	p12:register(XMLValueType.FLOAT, p13 .. ".component(?)#mass", "Mass of component [kg]", "Mass of component in i3d")
	p12:register(XMLValueType.VECTOR_TRANS, p13 .. ".component(?)#centerOfMass", "Center of mass in local space (x y z)", "Center of mass in i3d")
	p12:register(XMLValueType.VECTOR_TRANS, p13 .. ".component(?)#inertiaScale", "Scales the inertia, defining how the mass is distributed around the object (x y z, x = inertia around the local x axis). Inertia quadratically depends on the object radius. E.g. using an inertiaScale of 4 is equal to having a 2 times larger object along the given axis", "1 1 1")
	p12:register(XMLValueType.INT, p13 .. ".component(?)#solverIterationCount", "Solver iterations count")
	p12:register(XMLValueType.BOOL, p13 .. ".component(?)#motorized", "Is motorized component", "set by motorized specialization")
	p12:register(XMLValueType.BOOL, p13 .. ".component(?)#collideWithAttachables", "Collides with attachables", false)
	p12:register(XMLValueType.INT, p13 .. ".joint(?)#component1", "First component of the joint")
	p12:register(XMLValueType.INT, p13 .. ".joint(?)#component2", "Second component of the joint")
	p12:register(XMLValueType.NODE_INDEX, p13 .. ".joint(?)#node", "Joint node")
	p12:register(XMLValueType.NODE_INDEX, p13 .. ".joint(?)#nodeActor1", "Actor node of second component", "Joint node")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotLimit", "Rotation limit", "0 0 0")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transLimit", "Translation limit", "0 0 0")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotMinLimit", "Min rotation limit", "inversed rotation limit")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transMinLimit", "Min translation limit", "inversed translation limit")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotLimitSpring", "Rotation spring limit", "0 0 0")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotLimitDamping", "Rotation damping limit", "1 1 1")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotLimitForceLimit", "Rotation limit force limit (-1 = infinite)", "-1 -1 -1")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transLimitForceLimit", "Translation limit force limit (-1 = infinite)", "-1 -1 -1")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transLimitSpring", "Translation spring limit", "0 0 0")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transLimitDamping", "Translation damping limit", "1 1 1")
	p12:register(XMLValueType.NODE_INDEX, p13 .. ".joint(?)#zRotationNode", "Position of joints z rotation")
	p12:register(XMLValueType.BOOL, p13 .. ".joint(?)#breakable", "Joint is breakable", false)
	p12:register(XMLValueType.FLOAT, p13 .. ".joint(?)#breakForce", "Joint force until it breaks", 10)
	p12:register(XMLValueType.FLOAT, p13 .. ".joint(?)#breakTorque", "Joint torque until it breaks", 10)
	p12:register(XMLValueType.BOOL, p13 .. ".joint(?)#enableCollision", "Enable collision between both components", false)
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#maxRotDriveForce", "Max rotational drive force", "0 0 0")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotDriveVelocity", "Rotational drive velocity")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotDriveRotation", "Rotational drive rotation")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotDriveSpring", "Rotational drive spring", "0 0 0")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#rotDriveDamping", "Rotational drive damping", "0 0 0")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transDriveVelocity", "Translational drive velocity")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transDrivePosition", "Translational drive position")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transDriveSpring", "Translational drive spring", "0 0 0")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#transDriveDamping", "Translational drive damping", "1 1 1")
	p12:register(XMLValueType.VECTOR_3, p13 .. ".joint(?)#maxTransDriveForce", "Max translational drive force", "0 0 0")
	p12:register(XMLValueType.BOOL, p13 .. ".joint(?)#initComponentPosition", "Defines if the component is translated and rotated during loading based on joint movement", true)
	p12:register(XMLValueType.BOOL, p13 .. ".collisionPair(?)#enabled", "Collision between components enabled")
	p12:register(XMLValueType.INT, p13 .. ".collisionPair(?)#component1", "Index of first component")
	p12:register(XMLValueType.INT, p13 .. ".collisionPair(?)#component2", "Index of second component")
end
function Vehicle.new(p14, p15, p16)
	-- upvalues: (copy) v_u_1
	local v17 = Object.new(p14, p15, p16 or v_u_1)
	v17.finishedLoading = false
	v17.isDeleted = false
	v17.updateLoopIndex = -1
	v17.sharedLoadRequestId = nil
	v17.loadingState = VehicleLoadingState.OK
	v17.loadingStep = SpecializationLoadStep.CREATED
	v17.loadingTasks = {}
	v17.readyForFinishLoading = false
	v17.uniqueId = nil
	v17.actionController = VehicleActionController.new(v17)
	return v17
end
function Vehicle.setFilename(p18, p19)
	p18.configFileName = p19
	p18.configFileNameClean = Utils.getFilenameInfo(p19, true)
	local v20, v21 = Utils.getModNameAndBaseDirectory(p19)
	p18.customEnvironment = v20
	p18.baseDirectory = v21
end
function Vehicle.setConfigurations(p22, p23, p24)
	p22.configurations = p23
	p22.boughtConfigurations = p24
end
function Vehicle.setType(p25, p26)
	assertWithCallstack(p25.configFileName ~= nil, "Setting vehicle type without setting a filename previously. Call \'setFilename\' first!")
	if p25.configurations ~= nil then
		local v27 = ConfigurationUtil.getConfigItemByConfigId(p25.configFileName, "vehicleType", p25.configurations.vehicleType)
		if v27 ~= nil and v27.vehicleType ~= nil then
			local v28 = g_vehicleTypeManager:getTypeByName(v27.vehicleType)
			if v28 == nil then
				Logging.warning("Unknown vehicle type \'%s\' in configuration for \'%s\'", v27.vehicleType, p25.configFileName)
			else
				p26 = v28
			end
		end
	end
	SpecializationUtil.initSpecializationsIntoTypeClass(g_vehicleTypeManager, p26, p25)
end
function Vehicle.setLoadCallback(p29, p30, p31, p32)
	p29.loadCallbackFunction = p30
	p29.loadCallbackFunctionTarget = p31
	p29.loadCallbackFunctionArguments = p32
end
function Vehicle.loadCallback(p33)
	if p33.loadCallbackFunction ~= nil then
		p33.loadCallbackFunction(p33.loadCallbackFunctionTarget, p33, p33.loadingState, p33.loadCallbackFunctionArguments)
	end
end
function Vehicle.load(p_u_34, p35)
	p_u_34.vehicleLoadingData = p35
	p_u_34:setLoadingStep(SpecializationLoadStep.PRE_LOAD)
	p_u_34.isVehicleSaved = p35.isSaved
	if p_u_34.type == nil then
		Logging.xmlWarning(p_u_34.xmlFile, "Unable to find vehicleType")
		p_u_34:setLoadingState(VehicleLoadingState.ERROR)
		return p_u_34.loadingState
	end
	p_u_34.actionEvents = {}
	p_u_34.xmlFile = XMLFile.load("vehicleXML", p_u_34.configFileName, Vehicle.xmlSchema)
	p_u_34.savegame = p35.savegameData
	p_u_34.isAddedToPhysics = false
	local v36 = g_storeManager:getItemByXMLFilename(p_u_34.configFileName)
	if v36 ~= nil then
		p_u_34.brand = g_brandManager:getBrandByIndex(v36.brandIndex)
		p_u_34.lifetime = v36.lifetime
	end
	p_u_34.externalSoundsFilename = p_u_34.xmlFile:getValue("vehicle.base.sounds#filename")
	if p_u_34.externalSoundsFilename ~= nil then
		p_u_34.externalSoundsFilename = Utils.getFilename(p_u_34.externalSoundsFilename, p_u_34.baseDirectory)
		p_u_34.externalSoundsFile = XMLFile.load("TempExternalSounds", p_u_34.externalSoundsFilename, Vehicle.xmlSchemaSounds)
	end
	p_u_34.soundVolumeFactor = p_u_34.xmlFile:getValue("vehicle.base.sounds#volumeFactor")
	SpecializationUtil.copyTypeFunctionsInto(p_u_34.type, p_u_34)
	local v37 = g_storeManager:getItemByXMLFilename(p_u_34.configFileName)
	if v37 ~= nil and v37.configurations ~= nil then
		if v37.configurationSets ~= nil and (#v37.configurationSets > 0 and not ConfigurationUtil.getConfigurationsMatchConfigSets(p_u_34.configurations, v37.configurationSets)) then
			local v38, v39 = ConfigurationUtil.getClosestConfigurationSet(p_u_34.configurations, v37.configurationSets)
			if v38 ~= nil then
				for v40, v41 in pairs(v38.configurations) do
					p_u_34.configurations[v40] = v41
				end
				Logging.xmlInfo(p_u_34.xmlFile, "Savegame configurations do not match the configuration sets! Apply closest configuration set \'%s\' with %d matching configurations.", v38.name, v39)
			end
		end
		for v42, _ in pairs(v37.configurations) do
			local v43 = StoreItemUtil.getDefaultConfigId(v37, v42)
			if p_u_34.configurations[v42] == nil then
				ConfigurationUtil.setConfiguration(p_u_34, v42, v43)
			end
			ConfigurationUtil.addBoughtConfiguration(g_vehicleConfigurationManager, p_u_34, v42, v43)
		end
		for v44, v45 in pairs(p_u_34.configurations) do
			if v37.configurations[v44] == nil then
				Logging.xmlWarning(p_u_34.xmlFile, "Configurations are not present anymore. Ignoring this configuration (%s)!", v44)
				p_u_34.configurations[v44] = nil
				p_u_34.boughtConfigurations[v44] = nil
			else
				local v46 = StoreItemUtil.getDefaultConfigId(v37, v44)
				if #v37.configurations[v44] < v45 then
					Logging.xmlWarning(p_u_34.xmlFile, "Configuration with index \'%d\' is not present anymore. Using default configuration instead! (%s)", v45, v44)
					if p_u_34.boughtConfigurations[v44] ~= nil then
						p_u_34.boughtConfigurations[v44][v45] = nil
						if next(p_u_34.boughtConfigurations[v44]) == nil then
							p_u_34.boughtConfigurations[v44] = nil
						end
					end
					ConfigurationUtil.setConfiguration(p_u_34, v44, v46)
				else
					ConfigurationUtil.addBoughtConfiguration(g_vehicleConfigurationManager, p_u_34, v44, v45)
				end
			end
		end
	end
	SpecializationUtil.createSpecializationEnvironments(p_u_34, function(p47, p48)
		-- upvalues: (copy) p_u_34
		Logging.xmlError(p_u_34.xmlFile, "The vehicle specialization \'%s\' could not be added because variable \'%s\' already exists!", p47, p48)
		p_u_34:setLoadingState(VehicleLoadingState.ERROR)
	end)
	SpecializationUtil.raiseEvent(p_u_34, "onPreLoad", p_u_34.savegame)
	if p_u_34.loadingState ~= VehicleLoadingState.OK then
		Logging.xmlError(p_u_34.xmlFile, "Vehicle pre-loading failed!")
		p_u_34.xmlFile:delete()
		return false
	end
	ConfigurationUtil.raiseConfigurationItemEvent(p_u_34, "onPreLoad")
	XMLUtil.checkDeprecatedXMLElements(p_u_34.xmlFile, "vehicle.filename", "vehicle.base.filename")
	p_u_34.i3dFilename = Utils.getFilename(p_u_34.xmlFile:getValue("vehicle.base.filename"), p_u_34.baseDirectory)
	if string.contains(p_u_34.i3dFilename, "\\") then
		Logging.xmlWarning(p_u_34.xmlFile, "Filename contains backslashes, which are not allowed! (%s)", "vehicle.base.filename")
	end
	p_u_34:setLoadingStep(SpecializationLoadStep.AWAIT_I3D)
	p_u_34.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(p_u_34.i3dFilename, true, false, p_u_34.i3dFileLoaded, p_u_34)
	return nil
end
function Vehicle.i3dFileLoaded(p_u_49, p50, _, _, _)
	if p50 == 0 then
		p_u_49:setLoadingState(VehicleLoadingState.ERROR)
		Logging.xmlError(p_u_49.xmlFile, "Vehicle i3d loading failed!")
		p_u_49:loadCallback()
	else
		p_u_49.i3dNode = p50
		setVisibility(p50, false)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_49
			p_u_49:loadFinished()
		end)
	end
end
function Vehicle.loadFinished(p_u_51)
	local v_u_52 = nil
	local v_u_53 = nil
	local v_u_54 = nil
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		p_u_51:setLoadingState(VehicleLoadingState.OK)
		p_u_51:setLoadingStep(SpecializationLoadStep.LOAD)
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.forcedMapHotspotType", "vehicle.base.mapHotspot#type")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.base.forcedMapHotspotType", "vehicle.base.mapHotspot#type")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.speedLimit#value", "vehicle.base.speedLimit#value")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.steeringAxleNode#index", "vehicle.base.steeringAxle#node")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.size#width", "vehicle.base.size#width")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.size#length", "vehicle.base.size#length")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.size#widthOffset", "vehicle.base.size#widthOffset")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.size#lengthOffset", "vehicle.base.size#lengthOffset")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.typeDesc", "vehicle.base.typeDesc")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.components", "vehicle.base.components")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.components.component", "vehicle.base.components.component")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.base.components.component1", "vehicle.base.components.component")
		XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, "vehicle.base.mapHotspot#hasDirection")
	end, "Vehicle - Deprecated Check")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51, (ref) v_u_52, (ref) v_u_53, (ref) v_u_54
		local v55 = p_u_51.savegame
		if v55 ~= nil then
			for _, v56 in v55.xmlFile:iterator(v55.key .. ".boughtConfiguration") do
				local v57 = v55.xmlFile:getValue(v56 .. "#name")
				local v58 = v55.xmlFile:getValue(v56 .. "#id")
				ConfigurationUtil.addBoughtConfiguration(g_vehicleConfigurationManager, p_u_51, v57, ConfigurationUtil.getConfigIdBySaveId(p_u_51.configFileName, v57, v58))
			end
			p_u_51.tourId = nil
			local v59 = v55.xmlFile:getValue(v55.key .. "#tourId")
			if v59 ~= nil then
				p_u_51.tourId = v59
				g_guidedTourManager:addVehicle(p_u_51, p_u_51.tourId)
			end
		end
		p_u_51.age = 0
		p_u_51.propertyState = p_u_51.vehicleLoadingData.propertyState
		p_u_51:setOwnerFarmId(p_u_51.vehicleLoadingData.ownerFarmId, true)
		if v55 ~= nil then
			local v60 = v55.xmlFile:getValue(v55.key .. "#uniqueId", nil)
			if v60 ~= nil then
				p_u_51:setUniqueId(v60)
			end
			if not v55.ignoreFarmId then
				local v61 = v55.xmlFile:getValue(v55.key .. "#farmId", AccessHandler.EVERYONE)
				if g_farmManager.mergedFarms ~= nil and g_farmManager.mergedFarms[v61] ~= nil then
					v61 = g_farmManager.mergedFarms[v61]
				end
				p_u_51:setOwnerFarmId(v61, true)
			end
		end
		p_u_51.price = p_u_51.vehicleLoadingData.price
		if p_u_51.price == 0 or p_u_51.price == nil then
			local v62 = g_storeManager:getItemByXMLFilename(p_u_51.configFileName)
			p_u_51.price = StoreItemUtil.getDefaultPrice(v62, p_u_51.configurations)
		end
		p_u_51.typeDesc = p_u_51.xmlFile:getValue("vehicle.base.typeDesc", "TypeDescription", p_u_51.customEnvironment, true)
		for v63, v64 in pairs(g_vehicleConfigurationManager:getConfigurations()) do
			local v65 = string.format("%s(%d)", v64.configurationKey, (p_u_51.configurations[v63] or 1) - 1)
			local v66 = p_u_51.xmlFile:getValue(v65 .. "#typeDesc", nil, p_u_51.customEnvironment, false)
			if v66 ~= nil then
				p_u_51.typeDesc = v66
			end
		end
		p_u_51.synchronizePosition = p_u_51.xmlFile:getValue("vehicle.base.synchronizePosition", true)
		p_u_51.highPrecisionPositionSynchronization = false
		p_u_51.supportsPickUp = p_u_51.xmlFile:getValue("vehicle.base.supportsPickUp", false)
		p_u_51.canBeReset = p_u_51.xmlFile:getValue("vehicle.base.canBeReset", true)
		p_u_51.showInVehicleOverview = p_u_51.xmlFile:getValue("vehicle.base.showInVehicleMenu", true)
		p_u_51.rootNode = getChildAt(p_u_51.i3dNode, 0)
		p_u_51.serverMass = 0
		p_u_51.precalculatedMass = 0
		p_u_51.isMassDirty = false
		p_u_51.currentUpdateDistance = 0
		p_u_51.lastDistanceToCamera = 0
		p_u_51.lodDistanceCoeff = getLODDistanceCoeff()
		p_u_51.components = {}
		p_u_51.vehicleNodes = {}
		v_u_52 = getNumOfChildren(p_u_51.i3dNode)
		local v67 = { 0, 0, 0 }
		local v68 = p_u_51.configurations.component or 1
		v_u_53 = string.format("vehicle.base.componentConfigurations.componentConfiguration(%d)", v68 - 1)
		if not p_u_51.xmlFile:hasProperty(v_u_53) then
			v_u_53 = "vehicle.base.components"
		end
		v_u_54 = p_u_51.xmlFile:getValue(v_u_53 .. "#numComponents", v_u_52)
		p_u_51.maxComponentMass = p_u_51.xmlFile:getValue(v_u_53 .. "#maxMass", (1 / 0)) / 1000
		p_u_51.rootLevelNodes = {}
		for v69 = 1, v_u_52 do
			local v70 = {
				["node"] = getChildAt(p_u_51.i3dNode, v69 - 1),
				["isInactive"] = true
			}
			if not getVisibility(v70.node) then
				Logging.xmlDevWarning(p_u_51.xmlFile, "Found hidden component \'%s\' in i3d file. Components are not allowed to be hidden!", getName(v70.node))
			end
			setVisibility(v70.node, false)
			local v71 = p_u_51.rootLevelNodes
			table.insert(v71, v70)
		end
		for v72, v73 in p_u_51.xmlFile:iterator(v_u_53 .. ".component") do
			if v_u_54 < v72 then
				Logging.xmlWarning(p_u_51.xmlFile, "Invalid components count. I3D file has \'%d\' components, but tried to load component no. \'%d\'!", v_u_54, v72 + 1)
				break
			end
			local v74 = p_u_51.xmlFile:getValue(v73 .. "#index", v72) - 1
			local v75 = {
				["node"] = getChildAt(p_u_51.i3dNode, v74)
			}
			if p_u_51:loadComponentFromXML(v75, p_u_51.xmlFile, v73, v67, v72) then
				local v76, v77, v78 = getWorldTranslation(v75.node)
				local v79, v80, v81, v82 = getWorldQuaternion(v75.node)
				v75.networkInterpolators = {}
				v75.networkInterpolators.position = InterpolatorPosition.new(v76, v77, v78)
				v75.networkInterpolators.quaternion = InterpolatorQuaternion.new(v79, v80, v81, v82)
				local v83 = p_u_51.components
				table.insert(v83, v75)
			end
		end
		for _, v84 in ipairs(p_u_51.components) do
			link(getRootNode(), v84.node)
		end
	end, "Vehicle - Components Loading")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51, (ref) v_u_54
		for _, v85 in ipairs(p_u_51.rootLevelNodes) do
			for _, v86 in ipairs(p_u_51.components) do
				if v86.node == v85.node then
					v85.isInactive = false
				end
			end
			if v85.isInactive then
				local v87, v88, v89 = getWorldTranslation(v85.node)
				local v90, v91, v92 = getWorldRotation(v85.node)
				link(p_u_51.components[1].node, v85.node)
				setWorldTranslation(v85.node, v87, v88, v89)
				setWorldRotation(v85.node, v90, v91, v92)
				setRigidBodyType(v85.node, RigidBodyType.NONE)
				I3DUtil.iterateRecursively(v85.node, function(p93)
					if getIsCompoundChild(p93) then
						setIsCompoundChild(p93, false)
					end
				end)
			end
		end
		delete(p_u_51.i3dNode)
		p_u_51.i3dNode = nil
		p_u_51.numComponents = #p_u_51.components
		if v_u_54 ~= p_u_51.numComponents then
			Logging.xmlWarning(p_u_51.xmlFile, "I3D file offers \'%d\' objects, but \'%d\' components have been loaded!", v_u_54, p_u_51.numComponents)
		end
		if p_u_51.numComponents == 0 then
			Logging.xmlWarning(p_u_51.xmlFile, "No components defined for vehicle!")
			p_u_51:setLoadingState(VehicleLoadingState.ERROR)
			p_u_51:loadCallback()
		end
	end, "Vehicle - I3D Delete")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51, (ref) v_u_52
		p_u_51.defaultMass = 0
		for v94 = 1, #p_u_51.components do
			p_u_51.defaultMass = p_u_51.defaultMass + p_u_51.components[v94].defaultMass
		end
		p_u_51.i3dMappings = {}
		I3DUtil.loadI3DMapping(p_u_51.xmlFile, "vehicle", p_u_51.rootLevelNodes, p_u_51.i3dMappings, v_u_52)
	end, "Vehicle - I3D mapping")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		p_u_51.steeringAxleNode = p_u_51.xmlFile:getValue("vehicle.base.steeringAxle#node", nil, p_u_51.components, p_u_51.i3dMappings)
		if p_u_51.steeringAxleNode == nil then
			p_u_51.steeringAxleNode = p_u_51.components[1].node
		end
		p_u_51:loadSchemaOverlay(p_u_51.xmlFile)
	end, "Vehicle - Schema Overlays")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51, (ref) v_u_53
		p_u_51.componentJoints = {}
		for v95, v96 in p_u_51.xmlFile:iterator(v_u_53 .. ".joint") do
			local v97 = p_u_51.xmlFile:getValue(v96 .. "#component1")
			local v98 = p_u_51.xmlFile:getValue(v96 .. "#component2")
			XMLUtil.checkDeprecatedXMLElements(p_u_51.xmlFile, v96 .. "#index", v96 .. "#node")
			if v97 == nil or v98 == nil then
				Logging.xmlWarning(p_u_51.xmlFile, "Missing component index in component joint \'%s\'", v96)
				return
			end
			local v99 = p_u_51.xmlFile:getValue(v96 .. "#node", nil, p_u_51.components, p_u_51.i3dMappings)
			if v99 ~= nil and v99 ~= 0 then
				local v100 = {}
				if p_u_51:loadComponentJointFromXML(v100, p_u_51.xmlFile, v96, v95 - 1, v99, v97, v98) then
					local v101 = p_u_51.componentJoints
					table.insert(v101, v100)
					v100.index = #p_u_51.componentJoints
				end
			end
		end
	end, "Vehicle - Component Joints")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51, (ref) v_u_53
		p_u_51.collisionPairs = {}
		for _, v102 in p_u_51.xmlFile:iterator(v_u_53 .. ".collisionPair") do
			local v103 = p_u_51.xmlFile:getValue(v102 .. "#enabled")
			local v104 = p_u_51.xmlFile:getValue(v102 .. "#component1")
			local v105 = p_u_51.xmlFile:getValue(v102 .. "#component2")
			if v104 ~= nil and (v105 ~= nil and v103 ~= nil) then
				local v106 = p_u_51.components[v104]
				local v107 = p_u_51.components[v105]
				if v106 == nil or v107 == nil then
					Logging.xmlWarning(p_u_51.xmlFile, "Failed to load collision pair \'%s\'. Unknown component indices. Indices start with 1.", v102)
				elseif not v103 then
					local v108 = p_u_51.collisionPairs
					table.insert(v108, {
						["component1"] = v106,
						["component2"] = v107,
						["enabled"] = v103
					})
				end
			end
		end
	end, "Vehicle - Collision Pairs")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		p_u_51.supportsRadio = p_u_51.xmlFile:getValue("vehicle.base.supportsRadio", true)
		p_u_51.allowsInput = p_u_51.xmlFile:getValue("vehicle.base.input#allowed", true)
		p_u_51.size = StoreItemUtil.getSizeValuesFromXML(p_u_51.configFileName, p_u_51.xmlFile, "vehicle", 0, p_u_51.configurations)
	end, "Vehicle - Size")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		p_u_51.yRotationOffset = p_u_51.xmlFile:getValue("vehicle.base.size#yRotation", 0)
		p_u_51.showTailwaterDepthWarning = false
		p_u_51.thresholdTailwaterDepthWarning = p_u_51.xmlFile:getValue("vehicle.base.tailwaterDepth#warning", p_u_51.size.height * 0.25)
		p_u_51.thresholdTailwaterDepth = p_u_51.xmlFile:getValue("vehicle.base.tailwaterDepth#threshold", p_u_51.size.height * 0.75)
		p_u_51.networkTimeInterpolator = InterpolationTime.new(1.2)
		p_u_51.movingDirection = 0
		p_u_51.rotatedTime = 0
		p_u_51.isBroken = false
		p_u_51.forceIsActive = false
		p_u_51.finishedFirstUpdate = false
		p_u_51.lastPosition = nil
		p_u_51.lastSpeed = 0
		p_u_51.lastSpeedReal = 0
		p_u_51.lastSpeedSmoothed = 0
		p_u_51.lastSignedSpeed = 0
		p_u_51.lastSignedSpeedReal = 0
		p_u_51.lastMovedDistance = 0
		p_u_51.lastSpeedAcceleration = 0
		p_u_51.lastMoveTime = -10000
		p_u_51.operatingTime = 0
		p_u_51.allowSelection = p_u_51.xmlFile:getValue("vehicle.base.selection#allowed", true)
		p_u_51.isInWater = false
		p_u_51.isInShallowWater = false
		p_u_51.isInMediumWater = false
		p_u_51.waterY = -200
		p_u_51.tailwaterDepth = -200
		p_u_51.waterCheckPosition = { 0, 0, 0 }
		p_u_51.currentSelection = {
			["object"] = nil,
			["index"] = 0,
			["subIndex"] = 1
		}
		p_u_51.selectionObject = {
			["index"] = 0,
			["isSelected"] = false,
			["vehicle"] = p_u_51,
			["subSelections"] = {}
		}
		p_u_51.childVehicles = { p_u_51 }
		p_u_51.childVehicleHash = ""
		p_u_51.rootVehicle = p_u_51
		p_u_51.registeredActionEvents = {}
		p_u_51.actionEventUpdateRequested = false
		p_u_51.vehicleDirtyFlag = p_u_51:getNextDirtyFlag()
		if g_currentMission ~= nil and g_currentMission.environment ~= nil then
			g_messageCenter:subscribe(MessageType.DAY_CHANGED, p_u_51.dayChanged, p_u_51)
			g_messageCenter:subscribe(MessageType.PERIOD_CHANGED, p_u_51.periodChanged, p_u_51)
		end
		p_u_51.mapHotspotAvailable = p_u_51.xmlFile:getValue("vehicle.base.mapHotspot#available", true)
		if p_u_51.mapHotspotAvailable then
			local v109 = p_u_51.xmlFile:getValue("vehicle.base.mapHotspot#type", "OTHER")
			p_u_51.mapHotspotType = VehicleHotspot.getTypeByName(v109) or VehicleHotspot.TYPE.OTHER
		end
		local v110 = (1 / 0)
		for _, v111 in ipairs(p_u_51.specializations) do
			if v111.getDefaultSpeedLimit ~= nil then
				local v112 = v111.getDefaultSpeedLimit(p_u_51)
				v110 = math.min(v112, v110)
			end
		end
		p_u_51.checkSpeedLimit = v110 == (1 / 0)
		p_u_51.speedLimit = p_u_51.xmlFile:getValue("vehicle.base.speedLimit#value", v110)
	end, "Vehicle - Various Data")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		local v113 = {}
		ObjectChangeUtil.loadObjectChangeFromXML(p_u_51.xmlFile, "vehicle.base.objectChanges", v113, p_u_51.components, p_u_51)
		ObjectChangeUtil.setObjectChanges(v113, true)
	end, "Vehicle - Object Change Loading")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		ConfigurationUtil.raiseConfigurationItemEvent(p_u_51, "onLoad")
	end, "Vehicle - Configurations OnLoad")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		SpecializationUtil.raiseAsyncEvent(p_u_51, "onLoad", p_u_51.savegame)
	end)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		if p_u_51.loadingState ~= VehicleLoadingState.OK then
			Logging.xmlError(p_u_51.xmlFile, "Vehicle loading failed!")
			p_u_51:loadCallback()
		end
	end, nil, true)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		if Platform.gameplay.automaticVehicleControl and p_u_51.actionController ~= nil then
			p_u_51.actionController:load(p_u_51.savegame)
		end
		SpecializationUtil.raiseEvent(p_u_51, "onRootVehicleChanged", p_u_51)
		if p_u_51.isServer then
			for _, v114 in pairs(p_u_51.componentJoints) do
				if v114.initComponentPosition then
					local v115 = p_u_51.components[v114.componentIndices[2]].node
					local v116 = v114.jointNode
					if p_u_51:getParentComponent(v116) == v115 then
						v116 = v114.jointNodeActor1
					end
					if p_u_51:getParentComponent(v116) ~= v115 then
						setTranslation(v115, localToLocal(v115, v116, 0, 0, 0))
						setRotation(v115, localRotationToLocal(v115, v116, 0, 0, 0))
						link(v116, v115)
					end
				end
			end
		end
	end)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		ConfigurationUtil.raiseConfigurationItemEvent(p_u_51, "onPrePostLoad")
		p_u_51:setLoadingStep(SpecializationLoadStep.POST_LOAD)
	end)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		SpecializationUtil.raiseAsyncEvent(p_u_51, "onPostLoad", p_u_51.savegame)
	end)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		ConfigurationUtil.raiseConfigurationItemEvent(p_u_51, "onPostLoad")
	end)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		if p_u_51.loadingState ~= VehicleLoadingState.OK then
			Logging.xmlError(p_u_51.xmlFile, "Vehicle post-loading failed!")
			p_u_51:loadCallback()
		end
	end, nil, true)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		SpecializationUtil.raiseAsyncEvent(p_u_51, "onPreInitComponentPlacement", p_u_51.savegame)
	end)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		if p_u_51.loadingState ~= VehicleLoadingState.OK then
			Logging.xmlError(p_u_51.xmlFile, "Vehicle pre init component placement failed!")
			p_u_51:loadCallback()
		end
	end, nil, true)
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		if p_u_51.isServer then
			for _, v117 in pairs(p_u_51.componentJoints) do
				if v117.initComponentPosition then
					local v118 = p_u_51.components[v117.componentIndices[2]]
					local v119 = v117.jointNode
					if p_u_51:getParentComponent(v119) == v118.node then
						v119 = v117.jointNodeActor1
					end
					if p_u_51:getParentComponent(v119) ~= v118.node and getParent(v118.node) == v119 then
						local v120, v121, v122
						if v117.jointNodeActor1 == v117.jointNode then
							v120 = 0
							v121 = 0
							v122 = 0
						else
							local v123, v124, v125 = localToLocal(v117.jointNode, v118.node, 0, 0, 0)
							local v126, v127, v128 = localToLocal(v117.jointNodeActor1, v118.node, 0, 0, 0)
							v120 = v123 - v126
							v121 = v124 - v127
							v122 = v125 - v128
						end
						local v129, v130, v131 = localToWorld(v118.node, v120, v121, v122)
						local v132, v133, v134 = localRotationToWorld(v118.node, 0, 0, 0)
						link(getRootNode(), v118.node)
						setWorldTranslation(v118.node, v129, v130, v131)
						setWorldRotation(v118.node, v132, v133, v134)
						v118.originalTranslation = { v129, v130, v131 }
						v118.originalRotation = { v132, v133, v134 }
						v118.sentTranslation = { v129, v130, v131 }
						v118.sentRotation = { v132, v133, v134 }
					end
				end
			end
			for _, v135 in pairs(p_u_51.componentJoints) do
				p_u_51:setComponentJointFrame(v135, 0)
				p_u_51:setComponentJointFrame(v135, 1)
			end
		end
		local v136 = p_u_51.savegame
		if v136 ~= nil then
			p_u_51.age = v136.xmlFile:getValue(v136.key .. "#age", 0)
			p_u_51.price = v136.xmlFile:getValue(v136.key .. "#price", p_u_51.price)
			p_u_51.propertyState = VehiclePropertyState.loadFromXMLFile(v136.xmlFile, v136.key .. "#propertyState") or p_u_51.propertyState
			p_u_51:setOperatingTime(v136.xmlFile:getValue(v136.key .. "#operatingTime", p_u_51.operatingTime) * 1000, true)
			local v137 = v136.xmlFile:getValue(v136.key .. "#isBroken", p_u_51.isBroken)
			if not v136.resetVehicles and v137 then
				p_u_51:setBroken()
			end
		end
		if not p_u_51.vehicleLoadingData:applyPositionData(p_u_51) then
			p_u_51:setLoadingState(VehicleLoadingState.NO_SPACE)
			p_u_51:loadCallback()
		end
	end, "Vehicle - Components Linking")
	p_u_51:addAsyncTask(function()
		-- upvalues: (copy) p_u_51
		p_u_51:updateSelectableObjects()
		p_u_51:setSelectedVehicle(p_u_51, nil, true)
		if p_u_51.rootVehicle == p_u_51 then
			local v138 = p_u_51.savegame
			if v138 ~= nil then
				p_u_51.loadedSelectedObjectIndex = v138.xmlFile:getValue(v138.key .. "#selectedObjectIndex")
				p_u_51.loadedSubSelectedObjectIndex = v138.xmlFile:getValue(v138.key .. "#subSelectedObjectIndex")
			end
		end
		SpecializationUtil.raiseEvent(p_u_51, "onPreLoadFinished", p_u_51.savegame)
		p_u_51:setVisibility(false)
		if #p_u_51.loadingTasks == 0 then
			p_u_51:onFinishedLoading()
		else
			p_u_51.readyForFinishLoading = true
			p_u_51:setLoadingStep(SpecializationLoadStep.AWAIT_SUB_I3D)
		end
	end, "Vehicle - Finalize Loading")
end
function Vehicle.addAsyncTask(p_u_139, p_u_140, p141, p_u_142)
	g_asyncTaskManager:addSubtask(function()
		-- upvalues: (copy) p_u_142, (copy) p_u_139, (copy) p_u_140
		if p_u_142 == true or p_u_139.loadingState == VehicleLoadingState.OK and not p_u_139.markedForDeletion then
			p_u_140()
		end
	end, p141)
end
function Vehicle.loadSubSharedI3DFile(p_u_143, p144, p145, p146, p_u_147, p148, p149)
	local v_u_150 = p_u_143:createLoadingTask(p_u_143)
	local v155 = p_u_147 ~= nil and function(p151, p152, p153, p154)
		-- upvalues: (copy) p_u_143, (copy) p_u_147, (copy) v_u_150
		if p_u_143.isDeleted or p_u_143.isDeleting then
			if p152 ~= 0 then
				delete(p152)
			end
			p_u_147(p151, 0, p153, p154)
			p_u_143:finishLoadingTask(v_u_150)
		else
			p_u_147(p151, p152, p153, p154)
			p_u_143:finishLoadingTask(v_u_150)
		end
	end or p_u_147
	return g_i3DManager:loadSharedI3DFileAsync(p144, p145, p146, v155, p148, p149)
end
function Vehicle.onFinishedLoading(p156)
	if p156.isServer then
		p156:setVisibility(true)
		p156:addToPhysics()
	end
	p156:setLoadingStep(SpecializationLoadStep.FINISHED)
	SpecializationUtil.raiseEvent(p156, "onLoadFinished", p156.savegame)
	ConfigurationUtil.raiseConfigurationItemEvent(p156, "onLoadFinished")
	if p156.isServer then
		p156:setLoadingStep(SpecializationLoadStep.SYNCHRONIZED)
	end
	if g_currentMission ~= nil and (p156.propertyState ~= VehiclePropertyState.SHOP_CONFIG and p156.mapHotspotAvailable) then
		p156:createMapHotspot()
	end
	p156.finishedLoading = true
	if g_currentMission.vehicleSystem:addVehicle(p156) then
		if p156.propertyState == VehiclePropertyState.OWNED then
			g_currentMission:addOwnedItem(p156)
		elseif p156.propertyState == VehiclePropertyState.LEASED then
			g_currentMission:addLeasedItem(p156)
		end
		if p156.vehicleLoadingData.isRegistered then
			p156:register()
		end
		SpecializationUtil.raiseEvent(p156, "onLoadEnd", p156.savegame)
		p156:loadCallback()
		p156.savegame = nil
		p156.vehicleLoadingData = nil
	else
		Logging.xmlError(p156.xmlFile, "Failed to register vehicle!")
		p156:setLoadingState(VehicleLoadingState.ERROR)
		p156:loadCallback()
	end
end
function Vehicle.createLoadingTask(p157, p158)
	return SpecializationUtil.createLoadingTask(p157, p158)
end
function Vehicle.finishLoadingTask(p159, p160)
	SpecializationUtil.finishLoadingTask(p159, p160)
end
function Vehicle.getIsBeingDeleted(p161)
	return p161.markedForDeletion or (p161.isDeleting or p161.isDeleted)
end
function Vehicle.delete(p162, p163)
	if not p162.markedForDeletion then
		p162:deleteMapHotspot()
		if p162.tourId ~= nil then
			g_guidedTourManager:removeVehicle(p162.tourId)
		end
		g_messageCenter:unsubscribeAll(p162)
		local v164 = p162.rootVehicle
		if v164 ~= nil and v164:getIsAIActive() then
			v164:stopCurrentAIJob(AIMessageErrorVehicleDeleted.new())
		end
		if p162.propertyState == VehiclePropertyState.OWNED then
			g_currentMission:removeOwnedItem(p162)
		elseif p162.propertyState == VehiclePropertyState.LEASED then
			g_currentMission:removeLeasedItem(p162)
		end
	end
	p162.markedForDeletion = true
	if g_currentMission.isExitingGame or p163 then
		if p162.isDeleted then
			Logging.devError("Trying to delete an already deleted vehicle")
			printCallstack()
		else
			VehicleDebug.delete(p162)
			p162.isDeleting = true
			g_inputBinding:beginActionEventsModification(Vehicle.INPUT_CONTEXT_NAME)
			p162:removeActionEvents()
			g_inputBinding:endActionEventsModification()
			SpecializationUtil.raiseEvent(p162, "onPreDelete")
			SpecializationUtil.raiseEvent(p162, "onDelete")
			if p162.isServer and p162.componentJoints ~= nil then
				for _, v165 in pairs(p162.componentJoints) do
					if v165.jointIndex ~= 0 then
						removeJoint(v165.jointIndex)
					end
				end
				removeWakeUpReport(p162.rootNode)
			end
			if p162.components ~= nil then
				for _, v166 in pairs(p162.components) do
					unlink(v166.node)
				end
				for _, v167 in pairs(p162.components) do
					delete(v167.node)
					g_currentMission:removeNodeObject(v167.node)
				end
			end
			if p162.i3dNode ~= nil then
				delete(p162.i3dNode)
				p162.i3dNode = nil
			end
			if p162.sharedLoadRequestId ~= nil then
				g_i3DManager:releaseSharedI3DFile(p162.sharedLoadRequestId)
				p162.sharedLoadRequestId = nil
			end
			p162.xmlFile:delete()
			if p162.externalSoundsFile ~= nil then
				p162.externalSoundsFile:delete()
			end
			p162.isDeleting = false
			p162.isDeleted = true
			g_currentMission.vehicleSystem:removeVehicle(p162)
			Vehicle:superClass().delete(p162)
		end
	else
		g_currentMission.vehicleSystem:markVehicleForDeletion(p162)
		return
	end
end
function Vehicle.getNeedsSaving(p168)
	return p168.isVehicleSaved
end
function Vehicle.saveToXMLFile(p169, p170, p171, p172)
	p170:setValue(p171 .. "#uniqueId", p169.uniqueId)
	p170:setValue(p171 .. "#age", p169.age)
	p170:setValue(p171 .. "#price", p169.price)
	p170:setValue(p171 .. "#farmId", p169:getOwnerFarmId())
	VehiclePropertyState.saveToXMLFile(p170, p171 .. "#propertyState", p169.propertyState)
	p170:setValue(p171 .. "#operatingTime", p169.operatingTime / 1000)
	if p169.tourId ~= nil then
		p170:setValue(p171 .. "#tourId", p169.tourId)
	end
	if p169.rootVehicle == p169 then
		p170:setValue(p171 .. "#selectedObjectIndex", p169.currentSelection.index)
		if p169.currentSelection.subIndex ~= nil then
			p170:setValue(p171 .. "#subSelectedObjectIndex", p169.currentSelection.subIndex)
		end
	end
	if p169.isBroken then
		p170:setValue(p171 .. "#isBroken", p169.isBroken)
	end
	for v173, v174 in ipairs(p169.components) do
		local v175 = string.format("%s.component(%d)", p171, v173 - 1)
		local v176 = v174.node
		local v177, v178, v179 = getWorldTranslation(v176)
		local v180, v181, v182 = getWorldRotation(v176)
		p170:setValue(v175 .. "#index", v173)
		p170:setValue(v175 .. "#position", v177, v178, v179)
		p170:setValue(v175 .. "#rotation", v180, v181, v182)
	end
	local v183 = 0
	for v184, v185 in pairs(p169.configurations) do
		local v186 = ConfigurationUtil.getSaveIdByConfigId(p169.configFileName, v184, v185)
		if v186 ~= nil then
			local v187 = string.format("%s.configuration(%d)", p171, v183)
			p170:setValue(v187 .. "#name", v184)
			p170:setValue(v187 .. "#id", v186)
			v183 = v183 + 1
		end
	end
	local v188 = 0
	for v189, v190 in pairs(p169.boughtConfigurations) do
		for v191, _ in pairs(v190) do
			local v192 = ConfigurationUtil.getSaveIdByConfigId(p169.configFileName, v189, v191)
			if v192 ~= nil then
				local v193 = string.format("%s.boughtConfiguration(%d)", p171, v188)
				p170:setValue(v193 .. "#name", v189)
				p170:setValue(v193 .. "#id", v192)
				v188 = v188 + 1
			end
		end
	end
	for v194, v195 in pairs(p169.specializations) do
		local v196 = p169.specializationNames[v194]
		if v195.saveToXMLFile ~= nil then
			v195.saveToXMLFile(p169, p170, p171 .. "." .. v196, p172)
		end
	end
	if Platform.gameplay.automaticVehicleControl and p169.actionController ~= nil then
		p169.actionController:saveToXMLFile(p170, p171 .. ".actionController", p172)
	end
end
function Vehicle.saveStatsToXMLFile(p197, p198, p199)
	local v200 = p197.getIsTabbable == nil and true or p197:getIsTabbable()
	if p197.isDeleted or not (p197.isVehicleSaved and v200) then
		return false
	end
	local v201 = "Unknown"
	local v202 = g_storeManager:getItemByXMLFilename(p197.configFileName)
	local v203
	if v202 == nil then
		v203 = "unknown"
	else
		if v202.name ~= nil then
			local v204 = v202.name
			v201 = tostring(v204)
		end
		v203 = v202.categoryName
	end
	setXMLString(p198, p199 .. "#name", HTMLUtil.encodeToHTML(v201))
	setXMLString(p198, p199 .. "#category", HTMLUtil.encodeToHTML(v203))
	local v205 = setXMLString
	local v206 = p199 .. "#type"
	local v207 = HTMLUtil.encodeToHTML
	local v208 = p197.typeName
	v205(p198, v206, v207((tostring(v208))))
	if p197.components[1] ~= nil and p197.components[1].node ~= 0 then
		local v209, v210, v211 = getWorldTranslation(p197.components[1].node)
		setXMLFloat(p198, p199 .. "#x", v209)
		setXMLFloat(p198, p199 .. "#y", v210)
		setXMLFloat(p198, p199 .. "#z", v211)
	end
	for _, v212 in pairs(p197.specializations) do
		if v212.saveStatsToXMLFile ~= nil then
			v212.saveStatsToXMLFile(p197, p198, p199)
		end
	end
	return true
end
function Vehicle.readStream(p213, p214, p215, p216)
	Vehicle:superClass().readStream(p213, p214, p215, p216)
	local v217 = NetworkUtil.convertFromNetworkFilename(streamReadString(p214))
	local v218 = {}
	for _ = 1, streamReadUIntN(p214, ConfigurationUtil.SEND_NUM_BITS) do
		local v219 = streamReadUIntN(p214, ConfigurationUtil.SEND_NUM_BITS)
		local v220 = streamReadUInt16(p214)
		local v221 = g_vehicleConfigurationManager:getConfigurationNameByIndex(v219 + 1)
		if v221 ~= nil then
			v218[v221] = v220 + 1
		end
	end
	local v222 = {}
	for _ = 1, streamReadUIntN(p214, ConfigurationUtil.SEND_NUM_BITS) do
		local v223 = streamReadUIntN(p214, ConfigurationUtil.SEND_NUM_BITS)
		local v224 = g_vehicleConfigurationManager:getConfigurationNameByIndex(v223 + 1)
		v222[v224] = {}
		for _ = 1, streamReadUInt16(p214) do
			local v225 = streamReadUInt16(p214)
			v222[v224][v225 + 1] = true
		end
	end
	p213.propertyState = VehiclePropertyState.readStream(p214)
	local v226 = VehicleLoadingData.new()
	v226:setFilename(v217)
	v226:setPropertyState(p213.propertyState)
	v226:setOwnerFarmId(p213.ownerFarmId)
	v226:setConfigurations(v218)
	v226:setBoughtConfigurations(v222)
	v226:loadVehicleOnClient(p213, function(_, p227, p228)
		if p228 == VehicleLoadingState.OK then
			g_client:onObjectFinishedAsyncLoading(p227)
		else
			Logging.error("Failed to load vehicle on client")
			printCallstack()
		end
	end, nil)
end
function Vehicle.postReadStream(p229, p230, p231)
	p229:removeFromPhysics()
	local v232 = p229.highPrecisionPositionSynchronization and g_currentMission.vehicleXZPosHighPrecisionCompressionParams or g_currentMission.vehicleXZPosCompressionParams
	local v233 = p229.highPrecisionPositionSynchronization and g_currentMission.vehicleYPosHighPrecisionCompressionParams or g_currentMission.vehicleYPosCompressionParams
	for v234 = 1, #p229.components do
		local v235 = p229.components[v234]
		local v236 = NetworkUtil.readCompressedWorldPosition(p230, v232)
		local v237 = NetworkUtil.readCompressedWorldPosition(p230, v233)
		local v238 = NetworkUtil.readCompressedWorldPosition(p230, v232)
		local v239 = NetworkUtil.readCompressedAngle(p230)
		local v240 = NetworkUtil.readCompressedAngle(p230)
		local v241 = NetworkUtil.readCompressedAngle(p230)
		local v242, v243, v244, v245 = mathEulerToQuaternion(v239, v240, v241)
		p229:setWorldPositionQuaternion(v236, v237, v238, v242, v243, v244, v245, v234, true)
		v235.networkInterpolators.position:setPosition(v236, v237, v238)
		v235.networkInterpolators.quaternion:setQuaternion(v242, v243, v244, v245)
	end
	p229.networkTimeInterpolator:reset()
	p229:setVisibility(true)
	p229:addToPhysics()
	p229.serverMass = streamReadFloat32(p230)
	p229.age = streamReadUInt16(p230)
	p229:setOperatingTime(streamReadFloat32(p230), true)
	p229.price = streamReadInt32(p230)
	p229.isBroken = streamReadBool(p230)
	if Vehicle.DEBUG_NETWORK_READ_WRITE then
		print("-------------------------------------------------------------")
		print(p229.configFileName)
		for _, v246 in ipairs(p229.eventListeners.onReadStream) do
			local v247 = ClassUtil.getClassName(v246)
			local v248 = streamGetReadOffset(p230)
			v246.onReadStream(p229, p230, p231)
			print("  " .. tostring(v247) .. " read " .. streamGetReadOffset(p230) - v248 .. " bits")
		end
	else
		SpecializationUtil.raiseEvent(p229, "onReadStream", p230, p231)
	end
	p229:setLoadingStep(SpecializationLoadStep.SYNCHRONIZED)
end
function Vehicle.writeStream(p249, p250, p251)
	Vehicle:superClass().writeStream(p249, p250, p251)
	streamWriteString(p250, NetworkUtil.convertToNetworkFilename(p249.configFileName))
	local v252 = 0
	for _, _ in pairs(p249.configurations) do
		v252 = v252 + 1
	end
	streamWriteUIntN(p250, v252, ConfigurationUtil.SEND_NUM_BITS)
	for v253, v254 in pairs(p249.configurations) do
		local v255 = g_vehicleConfigurationManager:getConfigurationIndexByName(v253)
		streamWriteUIntN(p250, v255 - 1, ConfigurationUtil.SEND_NUM_BITS)
		streamWriteUInt16(p250, v254 - 1)
	end
	local v256 = 0
	for _, _ in pairs(p249.boughtConfigurations) do
		v256 = v256 + 1
	end
	streamWriteUIntN(p250, v256, ConfigurationUtil.SEND_NUM_BITS)
	for v257, v258 in pairs(p249.boughtConfigurations) do
		local v259 = 0
		for _, _ in pairs(v258) do
			v259 = v259 + 1
		end
		local v260 = g_vehicleConfigurationManager:getConfigurationIndexByName(v257)
		streamWriteUIntN(p250, v260 - 1, ConfigurationUtil.SEND_NUM_BITS)
		streamWriteUInt16(p250, v259)
		for v261, _ in pairs(v258) do
			streamWriteUInt16(p250, v261 - 1)
		end
	end
	VehiclePropertyState.writeStream(p250, p249.propertyState)
end
function Vehicle.postWriteStream(p262, p263, p264)
	local v265 = p262.highPrecisionPositionSynchronization and g_currentMission.vehicleXZPosHighPrecisionCompressionParams or g_currentMission.vehicleXZPosCompressionParams
	local v266 = p262.highPrecisionPositionSynchronization and g_currentMission.vehicleYPosHighPrecisionCompressionParams or g_currentMission.vehicleYPosCompressionParams
	for v267 = 1, #p262.components do
		local v268 = p262.components[v267]
		local v269, v270, v271 = getWorldTranslation(v268.node)
		local v272, v273, v274 = getWorldRotation(v268.node)
		NetworkUtil.writeCompressedWorldPosition(p263, v269, v265)
		NetworkUtil.writeCompressedWorldPosition(p263, v270, v266)
		NetworkUtil.writeCompressedWorldPosition(p263, v271, v265)
		NetworkUtil.writeCompressedAngle(p263, v272)
		NetworkUtil.writeCompressedAngle(p263, v273)
		NetworkUtil.writeCompressedAngle(p263, v274)
	end
	streamWriteFloat32(p263, p262.serverMass)
	streamWriteUInt16(p263, p262.age)
	streamWriteFloat32(p263, p262.operatingTime)
	streamWriteInt32(p263, p262.price)
	streamWriteBool(p263, p262.isBroken)
	if Vehicle.DEBUG_NETWORK_READ_WRITE then
		print("-------------------------------------------------------------")
		print(p262.configFileName)
		for _, v275 in ipairs(p262.eventListeners.onWriteStream) do
			local v276 = ClassUtil.getClassName(v275)
			local v277 = streamGetWriteOffset(p263)
			v275.onWriteStream(p262, p263, p264)
			print("  " .. tostring(v276) .. " Wrote " .. streamGetWriteOffset(p263) - v277 .. " bits")
		end
	else
		SpecializationUtil.raiseEvent(p262, "onWriteStream", p263, p264)
	end
end
function Vehicle.readUpdateStream(p278, p279, p280, p281)
	if p281.isServer and streamReadBool(p279) then
		p278.networkTimeInterpolator:startNewPhaseNetwork()
		local v282 = p278.highPrecisionPositionSynchronization and g_currentMission.vehicleXZPosHighPrecisionCompressionParams or g_currentMission.vehicleXZPosCompressionParams
		local v283 = p278.highPrecisionPositionSynchronization and g_currentMission.vehicleYPosHighPrecisionCompressionParams or g_currentMission.vehicleYPosCompressionParams
		for v284 = 1, #p278.components do
			local v285 = p278.components[v284]
			if not v285.isStatic then
				local v286 = NetworkUtil.readCompressedWorldPosition(p279, v282)
				local v287 = NetworkUtil.readCompressedWorldPosition(p279, v283)
				local v288 = NetworkUtil.readCompressedWorldPosition(p279, v282)
				local v289 = NetworkUtil.readCompressedAngle(p279)
				local v290 = NetworkUtil.readCompressedAngle(p279)
				local v291 = NetworkUtil.readCompressedAngle(p279)
				local v292, v293, v294, v295 = mathEulerToQuaternion(v289, v290, v291)
				v285.networkInterpolators.position:setTargetPosition(v286, v287, v288)
				v285.networkInterpolators.quaternion:setTargetQuaternion(v292, v293, v294, v295)
			end
		end
		SpecializationUtil.raiseEvent(p278, "onReadPositionUpdateStream", p279, p281)
	end
	if Vehicle.DEBUG_NETWORK_READ_WRITE_UPDATE then
		print("-------------------------------------------------------------")
		print(p278.configFileName)
		for _, v296 in ipairs(p278.eventListeners.onReadUpdateStream) do
			local v297 = ClassUtil.getClassName(v296)
			local v298 = streamGetReadOffset(p279)
			v296.onReadUpdateStream(p278, p279, p280, p281)
			print("  " .. tostring(v297) .. " read " .. streamGetReadOffset(p279) - v298 .. " bits")
		end
	else
		SpecializationUtil.raiseEvent(p278, "onReadUpdateStream", p279, p280, p281)
	end
end
function Vehicle.writeUpdateStream(p299, p300, p301, p302)
	if not p301.isServer and streamWriteBool(p300, bitAND(p302, p299.vehicleDirtyFlag) ~= 0) then
		local v303 = p299.highPrecisionPositionSynchronization and g_currentMission.vehicleXZPosHighPrecisionCompressionParams or g_currentMission.vehicleXZPosCompressionParams
		local v304 = p299.highPrecisionPositionSynchronization and g_currentMission.vehicleYPosHighPrecisionCompressionParams or g_currentMission.vehicleYPosCompressionParams
		for v305 = 1, #p299.components do
			local v306 = p299.components[v305]
			if not v306.isStatic then
				local v307, v308, v309 = getWorldTranslation(v306.node)
				local v310, v311, v312 = getWorldRotation(v306.node)
				NetworkUtil.writeCompressedWorldPosition(p300, v307, v303)
				NetworkUtil.writeCompressedWorldPosition(p300, v308, v304)
				NetworkUtil.writeCompressedWorldPosition(p300, v309, v303)
				NetworkUtil.writeCompressedAngle(p300, v310)
				NetworkUtil.writeCompressedAngle(p300, v311)
				NetworkUtil.writeCompressedAngle(p300, v312)
			end
		end
		SpecializationUtil.raiseEvent(p299, "onWritePositionUpdateStream", p300, p301, p302)
	end
	if Vehicle.DEBUG_NETWORK_READ_WRITE_UPDATE then
		print("-------------------------------------------------------------")
		print(p299.configFileName)
		for _, v313 in ipairs(p299.eventListeners.onWriteUpdateStream) do
			local v314 = ClassUtil.getClassName(v313)
			local v315 = streamGetWriteOffset(p300)
			v313.onWriteUpdateStream(p299, p300, p301, p302)
			print("  " .. tostring(v314) .. " Wrote " .. streamGetWriteOffset(p300) - v315 .. " bits")
		end
	else
		SpecializationUtil.raiseEvent(p299, "onWriteUpdateStream", p300, p301, p302)
	end
end
function Vehicle.updateVehicleSpeed(p316, p317)
	if p316.finishedFirstUpdate and not p316.components[1].isStatic then
		local v318 = 0
		local v319 = 0
		local v320 = 0
		local v321 = 0
		if p316.isServer and not p316.components[1].isKinematic then
			if p316.components[1].isDynamic then
				local v322, v323, v324 = getLocalLinearVelocity(p316.components[1].node)
				v318 = MathUtil.vector3Length(v322, v323, v324) * 0.001
				v319 = v318 * g_physicsDt
				v321 = v318 * (v324 >= 0 and 1 or -1)
				if v324 > 0.001 then
					v320 = 1
				elseif v324 < -0.001 then
					v320 = -1
				end
			end
		elseif p316.isServer or not p316.synchronizePosition then
			local v325, v326, v327 = getWorldTranslation(p316.components[1].node)
			if p316.lastPosition == nil then
				p316.lastPosition = { v325, v326, v327 }
			end
			local v328, v329, v330 = worldDirectionToLocal(p316.components[1].node, v325 - p316.lastPosition[1], v326 - p316.lastPosition[2], v327 - p316.lastPosition[3])
			local v331 = p316.lastPosition
			local v332 = p316.lastPosition
			local v333 = p316.lastPosition
			v331[1] = v325
			v332[2] = v326
			v333[3] = v327
			v320 = v330 > 0.001 and 1 or (v330 < -0.001 and -1 or v320)
			v319 = MathUtil.vector3Length(v328, v329, v330)
			v318 = v319 / p317
			v321 = v318 * (v330 >= 0 and 1 or -1)
		else
			local v334 = p316.components[1].networkInterpolators.position
			local v335, v336, v337
			if p316.networkTimeInterpolator:isInterpolating() then
				v335, v336, v337 = worldDirectionToLocal(p316.components[1].node, v334.targetPositionX - v334.lastPositionX, v334.targetPositionY - v334.lastPositionY, v334.targetPositionZ - v334.lastPositionZ)
			else
				v337 = 0
				v335 = 0
				v336 = 0
			end
			v320 = v337 > 0.001 and 1 or (v337 < -0.001 and -1 or v320)
			v318 = MathUtil.vector3Length(v335, v336, v337) / p316.networkTimeInterpolator.interpolationDuration
			v321 = v318 * (v337 >= 0 and 1 or -1)
			v319 = v318 * p317
		end
		if p316.isServer then
			if g_physicsDtNonInterpolated > 0 then
				p316.lastSpeedAcceleration = (v318 * v320 - p316.lastSpeedReal * p316.movingDirection) / g_physicsDtNonInterpolated
			end
		else
			p316.lastSpeedAcceleration = (v318 * v320 - p316.lastSpeedReal * p316.movingDirection) / p317
		end
		if p316.isServer then
			p316.lastSpeed = p316.lastSpeed * 0.5 + v318 * 0.5
			p316.lastSignedSpeed = p316.lastSignedSpeed * 0.5 + v321 * 0.5
		else
			p316.lastSpeed = p316.lastSpeed * 0.9 + v318 * 0.1
			p316.lastSignedSpeed = p316.lastSignedSpeed * 0.9 + v321 * 0.1
		end
		p316.lastSpeedSmoothed = p316.lastSpeedSmoothed * 0.9 + v318 * 0.1
		p316.lastSpeedReal = v318
		p316.lastSignedSpeedReal = v321
		p316.movingDirection = v320
		p316.lastMovedDistance = v319
	end
end
function Vehicle.update(p338, p339)
	p338.isActive = p338:getIsActive()
	local v340 = p338:getIsActiveForInput()
	local v341 = p338:getIsActiveForInput(true)
	local v342 = p338:getIsSelected()
	p338.lastDistanceToCamera = calcDistanceFrom(p338.rootNode, g_cameraManager:getActiveCamera())
	p338.currentUpdateDistance = p338.lastDistanceToCamera / p338.lodDistanceCoeff
	p338.isActiveForInputIgnoreSelectionIgnoreAI = p338:getIsActiveForInput(true, true)
	p338.isActiveForLocalSound = p338.isActiveForInputIgnoreSelectionIgnoreAI
	p338.updateLoopIndex = g_updateLoopIndex
	SpecializationUtil.raiseEvent(p338, "onPreUpdate", p339, v340, v341, v342)
	if not p338.isServer and p338.synchronizePosition then
		p338.networkTimeInterpolator:update(p339)
		local v343 = p338.networkTimeInterpolator:getAlpha()
		for v344, v345 in pairs(p338.components) do
			if not v345.isStatic then
				local v346, v347, v348 = v345.networkInterpolators.position:getInterpolatedValues(v343)
				local v349, v350, v351, v352 = v345.networkInterpolators.quaternion:getInterpolatedValues(v343)
				p338:setWorldPositionQuaternion(v346, v347, v348, v349, v350, v351, v352, v344, false)
			end
		end
		if p338.networkTimeInterpolator:isInterpolating() then
			p338:raiseActive()
		end
	end
	SpecializationUtil.raiseEvent(p338, "onUpdateInterpolation", p339, v340, v341, v342)
	p338:updateVehicleSpeed(p339)
	if p338.actionEventUpdateRequested then
		p338:updateActionEvents()
	end
	if Platform.gameplay.automaticVehicleControl then
		if p338.actionController ~= nil then
			p338.actionController:update(p339)
			p338.actionController:updateForAI(p339)
		end
	elseif p338.actionController ~= nil then
		p338.actionController:updateForAI(p339)
	end
	SpecializationUtil.raiseEvent(p338, "onUpdate", p339, v340, v341, v342)
	if Vehicle.debuggingActive then
		SpecializationUtil.raiseEvent(p338, "onUpdateDebug", p339, v340, v341, v342)
	end
	SpecializationUtil.raiseEvent(p338, "onPostUpdate", p339, v340, v341, v342)
	if p338.finishedFirstUpdate and p338.isMassDirty then
		p338.isMassDirty = false
		p338:updateMass()
	end
	p338.finishedFirstUpdate = true
	if p338.isServer and not getIsSleeping(p338.rootNode) then
		p338:raiseActive()
	end
	VehicleDebug.updateDebug(p338, p339)
	p338:updateMapHotspot()
end
function Vehicle.updateTick(p353, p354)
	local v355 = p353:getIsActiveForInput()
	local v356 = p353:getIsActiveForInput(true)
	local v357 = p353:getIsSelected()
	if p353.isActive and p353.needWaterInfo then
		p353:updateWaterInfo()
	end
	if p353.isServer and p353.synchronizePosition then
		local v358 = p353:getOwnerConnection() ~= nil
		for v359 = 1, #p353.components do
			local v360 = p353.components[v359]
			if not v360.isStatic then
				local v361, v362, v363 = getWorldTranslation(v360.node)
				local v364, v365, v366 = getWorldRotation(v360.node)
				local v367 = v360.sentTranslation
				local v368 = v360.sentRotation
				if v358 then
					::l14::
					p353:raiseDirtyFlags(p353.vehicleDirtyFlag)
					v367[1] = v361
					v367[2] = v362
					v367[3] = v363
					v368[1] = v364
					v368[2] = v365
					v368[3] = v366
					p353.lastMoveTime = g_currentMission.time
				else
					local v369 = v361 - v367[1]
					if math.abs(v369) > 0.005 then
						goto l14
					end
					local v370 = v362 - v367[2]
					if math.abs(v370) > 0.005 then
						goto l14
					end
					local v371 = v363 - v367[3]
					if math.abs(v371) > 0.005 then
						goto l14
					end
					local v372 = v364 - v368[1]
					if math.abs(v372) > 0.1 then
						goto l14
					end
					local v373 = v365 - v368[2]
					if math.abs(v373) > 0.1 then
						goto l14
					end
					local v374 = v366 - v368[3]
					if math.abs(v374) > 0.1 then
						goto l14
					end
				end
			end
		end
	end
	p353.showTailwaterDepthWarning = false
	if not p353.isBroken and (not g_gui:getIsGuiVisible() and p353.tailwaterDepth > p353.thresholdTailwaterDepthWarning) then
		p353.showTailwaterDepthWarning = true
		if p353.tailwaterDepth > p353.thresholdTailwaterDepth then
			p353:setBroken()
		end
	end
	local v375 = p353.rootVehicle
	if v375 ~= nil and v375 ~= p353 then
		v375.showTailwaterDepthWarning = v375.showTailwaterDepthWarning or p353.showTailwaterDepthWarning
	end
	if p353:getIsOperating() then
		p353:setOperatingTime(p353.operatingTime + p354)
	end
	SpecializationUtil.raiseEvent(p353, "onUpdateTick", p354, v355, v356, v357)
	SpecializationUtil.raiseEvent(p353, "onPostUpdateTick", p354, v355, v356, v357)
end
function Vehicle.updateEnd(p376, p377)
	local v378 = p376:getIsActiveForInput()
	local v379 = p376:getIsActiveForInput(true)
	local v380 = p376:getIsSelected()
	p376.currentUpdateDistance = 0
	SpecializationUtil.raiseEvent(p376, "onUpdateEnd", p377, v378, v379, v380)
end
function Vehicle.draw(p381, p382)
	if p381:getIsSynchronized() then
		local v383 = p381.rootVehicle
		local v384 = p381:getSelectedVehicle()
		if not p382 then
			if p381 ~= v383 and v384 ~= v383 then
				v383:draw(true)
			end
			if v384 ~= nil and (p381 ~= v384 and v384 ~= v383) then
				v384:draw(true)
			end
		end
		if v384 == p381 or v383 == p381 then
			local v385 = p381:getIsActiveForInput()
			local v386 = p381:getIsActiveForInput(true)
			SpecializationUtil.raiseEvent(p381, "onDraw", v385, v386, true)
		end
		VehicleDebug.drawDebug(p381)
		if p381.showTailwaterDepthWarning then
			g_currentMission:showBlinkingWarning(g_i18n:getText("warning_dontDriveIntoWater"), 2000)
		end
	end
end
function Vehicle.drawUIInfo(p387)
	if p387:getIsSynchronized() then
		SpecializationUtil.raiseEvent(p387, "onDrawUIInfo")
		if g_showVehicleDistance then
			local v388 = calcDistanceFrom(p387.rootNode, g_cameraManager:getActiveCamera())
			if v388 <= 350 then
				local v389, v390, v391 = getWorldTranslation(p387.rootNode)
				Utils.renderTextAtWorldPosition(v389, v390 + 1, v391, string.format("%.0f", v388), getCorrectTextSize(0.02), 0)
			end
		end
	end
end
function Vehicle.setLoadingState(p392, p393)
	if VehicleLoadingState.getName(p393) == nil then
		printCallstack()
		Logging.error("Invalid loading state \'%s\'!", p393)
	else
		p392.loadingState = p393
	end
end
function Vehicle.setLoadingStep(p394, p395)
	SpecializationUtil.setLoadingStep(p394, p395)
end
function Vehicle.addToPhysics(p396)
	if p396.isAddedToPhysics then
		return false
	end
	local v397 = nil
	for _, v398 in pairs(p396.components) do
		addToPhysics(v398.node)
		if v398.motorized then
			if v397 ~= nil and p396.isServer then
				addVehicleLink(v397, v398.node)
			end
			v397 = v398.node
		end
	end
	p396.isAddedToPhysics = true
	if p396.isServer then
		for _, v399 in pairs(p396.componentJoints) do
			p396:createComponentJoint(p396.components[v399.componentIndices[1]], p396.components[v399.componentIndices[2]], v399)
		end
		addWakeUpReport(p396.rootNode, "onVehicleWakeUpCallback", p396)
	end
	for _, v400 in pairs(p396.collisionPairs) do
		setPairCollision(v400.component1.node, v400.component2.node, v400.enabled)
	end
	p396:setMassDirty()
	return true
end
function Vehicle.removeFromPhysics(p401)
	for _, v402 in pairs(p401.components) do
		removeFromPhysics(v402.node)
	end
	if p401.isServer then
		for _, v403 in pairs(p401.componentJoints) do
			v403.jointIndex = 0
		end
		removeWakeUpReport(p401.rootNode)
	end
	p401.isAddedToPhysics = false
	return true
end
function Vehicle.setVisibility(p404, p405)
	for _, v406 in pairs(p404.components) do
		setVisibility(v406.node, p405)
	end
end
function Vehicle.setRelativePosition(p407, p408, p409, p410, p411)
	p407:setAbsolutePosition(p408, getTerrainHeightAtWorldPos(g_terrainNode, p408, 300, p410) + p409, p410, 0, p411, 0)
end
function Vehicle.setAbsolutePosition(p412, p413, p414, p415, p416, p417, p418, p419)
	local v420 = createTransformGroup("tempRootNode")
	setTranslation(v420, p413, p414, p415)
	setRotation(v420, p416, p417, p418)
	for v421, v422 in pairs(p412.components) do
		local v423 = localToWorld
		local v424 = v422.originalTranslation
		local v425, v426, v427 = v423(v420, unpack(v424))
		local v428 = localRotationToWorld
		local v429 = v422.originalRotation
		local v430, v431, v432 = v428(v420, unpack(v429))
		if p419 ~= nil and #p419 == #p412.components then
			local v433 = p419[v421][1]
			v425, v426, v427 = unpack(v433)
			local v434 = p419[v421][2]
			v430, v431, v432 = unpack(v434)
		end
		p412:setWorldPosition(v425, v426, v427, v430, v431, v432, v421, true)
	end
	delete(v420)
	p412.networkTimeInterpolator:reset()
end
function Vehicle.getLimitedVehicleYPosition(_, p435)
	if p435.posY == nil then
		return getTerrainHeightAtWorldPos(g_terrainNode, p435.posX, 300, p435.posZ) + Utils.getNoNil(p435.yOffset, 0)
	else
		return p435.posY
	end
end
function Vehicle.setWorldPosition(p436, p437, p438, p439, p440, p441, p442, p443, p444)
	local v445 = p436.components[p443]
	if v445 ~= nil then
		setWorldTranslation(v445.node, p437, p438, p439)
		setWorldRotation(v445.node, p440, p441, p442)
		if p444 then
			local v446, v447, v448, v449 = mathEulerToQuaternion(p440, p441, p442)
			v445.networkInterpolators.quaternion:setQuaternion(v446, v447, v448, v449)
			v445.networkInterpolators.position:setPosition(p437, p438, p439)
		end
	end
end
function Vehicle.setWorldPositionQuaternion(p450, p451, p452, p453, p454, p455, p456, p457, p458, p459)
	local v460 = p450.components[p458]
	if v460 ~= nil then
		setWorldTranslation(v460.node, p451, p452, p453)
		setWorldQuaternion(v460.node, p454, p455, p456, p457)
		if p459 then
			v460.networkInterpolators.quaternion:setQuaternion(p454, p455, p456, p457)
			v460.networkInterpolators.position:setPosition(p451, p452, p453)
		end
	end
end
function Vehicle.setDefaultComponentPosition(p461, p462)
	if p462 ~= 1 then
		local v463 = p461.components[p462]
		if v463 ~= nil then
			local v464 = localToWorld
			local v465 = p461.rootNode
			local v466 = v463.originalTranslation
			local v467, v468, v469 = v464(v465, unpack(v466))
			local v470 = localRotationToWorld
			local v471 = p461.rootNode
			local v472 = v463.originalRotation
			local v473, v474, v475 = v470(v471, unpack(v472))
			p461:setWorldPosition(v467, v468, v469, v473, v474, v475, p462, true)
		end
	end
end
function Vehicle.getIsNodeActive(p476, p477)
	while p477 ~= 0 do
		for _, v478 in ipairs(p476.rootLevelNodes) do
			if p477 == v478.node then
				return not v478.isInactive
			end
		end
		p477 = getParent(p477)
	end
	return false
end
function Vehicle.getUpdatePriority(p479, p480, p481, p482, p483, p484, p485, _)
	if p479:getOwnerConnection() == p485 then
		return 50
	end
	local v486, v487, v488 = getWorldTranslation(p479.components[1].node)
	return (1 - MathUtil.vector3Length(v486 - p481, v487 - p482, v488 - p483) / (getClipDistance(p479.components[1].node) * p484)) * 0.8 + 0.5 * p480 * 0.2
end
function Vehicle.getPrice(p489)
	return p489.price
end
function Vehicle.getSellPrice(p490)
	local v491 = g_storeManager:getItemByXMLFilename(p490.configFileName)
	return Vehicle.calculateSellPrice(v491, p490.age, p490.operatingTime, p490:getPrice(), p490:getRepairPrice(), p490:getRepaintPrice())
end
function Vehicle.calculateSellPrice(p492, p493, p494, p495, p496, p497)
	local v498 = p494 / 3600000
	local v499 = p492.lifetime
	local v500 = p493 / Environment.PERIODS_IN_YEAR
	StoreItemUtil.loadSpecsFromXML(p492)
	local v501 = 1 - v498 ^ (p492.specs.power == nil and 1.3 or 1) / v499
	local v502 = -0.1 * math.log(v500) + 0.75
	local v503 = math.min(v502, 0.85)
	local v504 = p495 * v501 * v503 - p496 - p497
	local v505 = p495 * 0.03
	return math.max(v504, v505)
end
function Vehicle.getIsOnField(p506)
	for _, v507 in pairs(p506.components) do
		local v508, v509, v510 = localToWorld(v507.node, getCenterOfMass(v507.node))
		if v509 < getTerrainHeightAtWorldPos(g_terrainNode, v508, v509, v510) - 1 then
			break
		end
		local v511, _ = FSDensityMapUtil.getFieldDataAtWorldPosition(v508, v509, v510)
		if v511 then
			return true
		end
	end
	return false
end
function Vehicle.getParentComponent(p512, p513)
	while p513 ~= 0 do
		if p512:getIsVehicleNode(p513) then
			return p513
		end
		p513 = getParent(p513)
	end
	return 0
end
function Vehicle.getLastSpeed(p514, p515)
	if p515 and p514.attacherVehicle ~= nil then
		return p514.attacherVehicle:getLastSpeed(true)
	else
		return p514.lastSpeed * 3600
	end
end
g_soundManager:registerModifierType("SPEED", Vehicle.getLastSpeed)
function Vehicle.getDeactivateOnLeave(_)
	return true
end
function Vehicle.getIsSynchronized(p516)
	return p516.loadingStep == SpecializationLoadStep.SYNCHRONIZED
end
function Vehicle.getActiveFarm(p517)
	return p517:getOwnerFarmId()
end
function Vehicle.getIsVehicleNode(p518, p519)
	return p518.vehicleNodes[p519] ~= nil
end
function Vehicle.getIsOperating(_)
	return false
end
function Vehicle.getIsActive(p520)
	if p520.isBroken then
		return false
	else
		return p520.forceIsActive and true or false
	end
end
function Vehicle.getIsActiveForInput(p521, p522, p523)
	if not p521.allowsInput then
		return false
	end
	if not g_currentMission.isRunning then
		return false
	end
	if (p523 == nil or not p523) and p521:getIsAIActive() then
		return false
	end
	if not p522 then
		local v524 = p521.rootVehicle
		if v524 == nil then
			return false
		end
		if p521 ~= v524:getSelectedVehicle() then
			return false
		end
	end
	local v525 = p521.rootVehicle
	if v525 == p521 then
		if p521.getIsEntered == nil and (p521.getAttacherVehicle ~= nil and p521:getAttacherVehicle() == nil) then
			return false
		end
	elseif not v525:getIsActiveForInput(true, p523) then
		return false
	end
	return true
end
function Vehicle.getIsActiveForSound(_)
	printWarning("Warning: Vehicle:getIsActiveForSound() is deprecated")
	return false
end
function Vehicle.getIsLowered(_, _)
	return false
end
function Vehicle.updateWaterInfo(p526)
	if not p526.waterCheckIsPending then
		local v527, v528, v529 = localToWorld(p526.rootNode, 0, p526.size.height * 0.5, 0)
		p526.waterCheckPosition[1] = v527
		p526.waterCheckPosition[2] = v528
		p526.waterCheckPosition[3] = v529
		p526.waterCheckIsPending = true
		raycastClosestAsync(v527, v528 + 25, v529, 0, -1, 0, 50, "onWaterRaycastCallback", p526, CollisionFlag.WATER)
	end
end
function Vehicle.onWaterRaycastCallback(p530, p531, _, p532, _, _, _, _, _, _, _, _)
	p530.waterCheckIsPending = false
	local v533 = p530.waterCheckPosition[2] - p530.size.height * 0.5
	local v534 = p531 == 0 and -2000 or p532
	p530.waterY = v534
	p530.isInWater = v533 < v534
	p530.isInShallowWater = false
	p530.isInMediumWater = false
	if p530.isInWater then
		local v535 = p530.waterCheckPosition[1]
		local v536 = p530.waterCheckPosition[3]
		local v537 = v534 - getTerrainHeightAtWorldPos(g_terrainNode, v535, 0, v536)
		p530.isInShallowWater = math.max(0, v537) <= 0.5
		p530.isInMediumWater = not p530.isInShallowWater
	end
	local v538 = v534 - v533
	p530.tailwaterDepth = math.max(0, v538)
	return false
end
function Vehicle.setBroken(p539)
	if p539.isServer and not p539.isBroken then
		g_server:broadcastEvent(VehicleBrokenEvent.new(p539), nil, nil, p539)
	end
	p539.isBroken = true
	SpecializationUtil.raiseEvent(p539, "onSetBroken")
	if p539.tourId ~= nil and g_guidedTourManager:getIsTourRunning() then
		g_guidedTourManager:abortTour()
	end
end
function Vehicle.getVehicleDamage(_)
	return 0
end
function Vehicle.getRepairPrice(_)
	return 0
end
function Vehicle.getRepaintPrice(_)
	return 0
end
function Vehicle.requestActionEventUpdate(p540)
	local v541 = p540.rootVehicle
	if v541 == p540 then
		p540.actionEventUpdateRequested = true
	else
		v541:requestActionEventUpdate()
	end
	v541:removeActionEvents()
end
function Vehicle.removeActionEvents(p542)
	g_inputBinding:removeActionEventsByTarget(p542)
end
function Vehicle.updateActionEvents(p543)
	p543.rootVehicle:registerActionEvents()
end
function Vehicle.registerActionEvents(p544, p545)
	if not g_gui:getIsGuiVisible() and (not g_currentMission.isPlayerFrozen and p545 ~= p544) then
		p544.actionEventUpdateRequested = false
		local v546 = p544:getIsActiveForInput()
		local v547 = p544:getIsActiveForInput(true)
		if v546 then
			g_inputBinding:resetActiveActionBindings()
		end
		g_inputBinding:beginActionEventsModification(Vehicle.INPUT_CONTEXT_NAME)
		SpecializationUtil.raiseEvent(p544, "onPreRegisterActionEvents", v546, v547)
		SpecializationUtil.raiseEvent(p544, "onRegisterActionEvents", v546, v547)
		p544:clearActionEventsTable(p544.actionEvents)
		if p544:getCanToggleSelectable() then
			local v548 = 0
			for _, v549 in ipairs(p544.selectableObjects) do
				v548 = v548 + 1 + #v549.subSelections
			end
			if v548 > 1 then
				local _, v550 = p544:addActionEvent(p544.actionEvents, InputAction.SWITCH_IMPLEMENT, p544, Vehicle.actionEventToggleSelection, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v550, GS_PRIO_LOW)
				local _, v551 = p544:addActionEvent(p544.actionEvents, InputAction.SWITCH_IMPLEMENT_BACK, p544, Vehicle.actionEventToggleSelectionReverse, false, true, false, true, nil)
				g_inputBinding:setActionEventTextVisibility(v551, false)
			end
		end
		VehicleDebug.registerActionEvents(p544)
		if Platform.gameplay.automaticVehicleControl and (p544.actionController ~= nil and (p544:getIsActiveForInput(true) and p544 == p544.rootVehicle)) then
			p544.actionController:registerActionEvents(v546, v547)
		end
		g_inputBinding:endActionEventsModification()
	end
end
function Vehicle.clearActionEventsTable(_, p552)
	if p552 ~= nil then
		for v553, v554 in pairs(p552) do
			g_inputBinding:removeActionEvent(v554.actionEventId)
			p552[v553] = nil
		end
	end
end
function Vehicle.addPoweredActionEvent(p555, p556, p557, p558, p_u_559, p560, p561, p562, p563, p564, p565, p566, p567)
	return p555:addActionEvent(p556, p557, p558, function(p568, p569, p570, p571, p572, p573, p574, p575)
		-- upvalues: (copy) p_u_559
		local v576, v577 = p568:getIsPowered()
		if v576 then
			p_u_559(p568, p569, p570, p571, p572, p573, p574, p575)
		elseif p570 ~= 0 and v577 ~= nil then
			g_currentMission:showBlinkingWarning(v577, 2000)
		end
	end, p560, p561, p562, p563, p564, p565, p566, p567)
end
function Vehicle.addActionEvent(p578, p579, p580, p581, p582, p583, p584, p585, p586, p587, p588, p589, p590)
	local v591, v592, v593 = g_inputBinding:registerActionEvent(p580, p581, p582, p583, p584, p585, p586, p587, true, p590)
	if v591 then
		p579[p580] = {
			["actionEventId"] = v592
		}
		local v594 = g_inputBinding.events[v592]
		if v594 ~= nil then
			v594.parentEventsTable = p579
		end
		if p588 and p588 ~= "" then
			g_inputBinding:setActionEventIcon(v592, p588)
		end
	end
	if v593 ~= nil and (p589 == nil or not p589) then
		if p578:getIsSelected() then
			local v595 = false
			for _, v596 in ipairs(v593) do
				if v596.parentEventsTable ~= nil then
					g_inputBinding:removeActionEvent(v596.id)
					v596.parentEventsTable[v596.id] = nil
					v595 = true
				end
			end
			if v595 then
				return p578:addActionEvent(p579, p580, p581, p582, p583, p584, p585, p586, p587, p588)
			end
		else
			g_inputBinding:removeActionEvent(v592)
			for _, v597 in ipairs(v593) do
				if v597.targetObject.getIsSelected ~= nil and (not v597.targetObject:getIsSelected() and v597.parentEventsTable ~= nil) then
					g_inputBinding:removeActionEvent(v597.id)
					v597.parentEventsTable[v597.id] = nil
				end
			end
		end
	end
	return v591, v592
end
function Vehicle.removeActionEvent(_, p598, p599)
	if p598[p599] ~= nil then
		g_inputBinding:removeActionEvent(p598[p599].actionEventId)
		p598[p599] = nil
	end
end
function Vehicle.updateSelectableObjects(p600)
	p600.selectableObjects = {}
	if p600 == p600.rootVehicle then
		p600:registerSelectableObjects(p600.selectableObjects)
	end
end
function Vehicle.registerSelectableObjects(p601, p602)
	if p601:getCanBeSelected() and not p601:getBlockSelection() then
		local v603 = p601.selectionObject
		table.insert(p602, v603)
		p601.selectionObject.index = #p602
	end
end
function Vehicle.addSubselection(p604, p605)
	local v606 = p604.selectionObject.subSelections
	table.insert(v606, p605)
	return #p604.selectionObject.subSelections
end
function Vehicle.clearSubselections(p607)
	p607.selectionObject.subSelections = {}
end
function Vehicle.getCanBeSelected(_)
	return VehicleDebug.state ~= 0
end
function Vehicle.getBlockSelection(p608)
	return not p608.allowSelection
end
function Vehicle.getCanToggleSelectable(_)
	return false
end
function Vehicle.getRootVehicle(p609)
	return p609.rootVehicle
end
function Vehicle.findRootVehicle(p610)
	return p610
end
function Vehicle.getChildVehicles(p611)
	return p611.childVehicles
end
function Vehicle.getChildVehicleHash(p612)
	return p612.childVehicleHash
end
function Vehicle.addChildVehicles(p613, p614, p615)
	table.insert(p614, p613)
	local v616 = p615.childVehicleHash
	local v617 = p613.id
	p615.childVehicleHash = v616 .. ":" .. tostring(v617)
end
function Vehicle.updateVehicleChain(p618, p619)
	local v620 = p618:findRootVehicle()
	if v620 ~= p618.rootVehicle then
		p618.rootVehicle = v620
		SpecializationUtil.raiseEvent(p618, "onRootVehicleChanged", v620)
	end
	if v620 == p618 or p619 then
		for v621 = #p618.childVehicles, 1, -1 do
			p618.childVehicles[v621] = nil
		end
		p618.childVehicleHash = ""
		p618:addChildVehicles(p618.childVehicles, p618)
		if v620 == p618 then
			for v622 = 1, #p618.childVehicles do
				if p618.childVehicles[v622] ~= v620 then
					p618.childVehicles[v622]:updateVehicleChain(true)
				end
			end
		end
	else
		v620:updateVehicleChain()
	end
end
function Vehicle.unselectVehicle(p623)
	p623.selectionObject.isSelected = false
	SpecializationUtil.raiseEvent(p623, "onUnselect")
	p623:requestActionEventUpdate()
end
function Vehicle.selectVehicle(p624, p625, p626)
	p624.selectionObject.isSelected = true
	SpecializationUtil.raiseEvent(p624, "onSelect", p625)
	if p626 == nil or not p626 then
		p624:requestActionEventUpdate()
	end
end
function Vehicle.setSelectedVehicle(p627, p628, p629, p630)
	local v631 = nil
	if p628 == nil or (not p628:getCanBeSelected() or p627:getBlockSelection()) then
		p628 = nil
		for _, v632 in ipairs(p627.selectableObjects) do
			if v632.vehicle:getCanBeSelected() and not v632.vehicle:getBlockSelection() then
				p628 = v632.vehicle
				break
			end
		end
	end
	if p628 ~= nil then
		v631 = p628.selectionObject
	end
	return p627:setSelectedObject(v631, p629, p630)
end
function Vehicle.setSelectedObject(p633, p634, p635, p636)
	local v637 = p633.currentSelection
	if p634 == nil then
		p634 = p633:getSelectedObject()
	end
	local v638 = false
	for _, v639 in ipairs(p633.selectableObjects) do
		if v639 == p634 then
			v638 = true
		end
	end
	if v638 then
		for _, v640 in ipairs(p633.selectableObjects) do
			if v640 ~= p634 and v640.vehicle:getIsSelected() then
				v640.vehicle:unselectVehicle()
			end
		end
		if p634 ~= v637.object or p635 ~= v637.subIndex then
			v637.object = p634
			v637.index = p634.index
			if p635 ~= nil then
				v637.subIndex = p635
			end
			if v637.subIndex > #p634.subSelections then
				v637.subIndex = 1
			end
			v637.object.vehicle:selectVehicle(v637.subIndex, p636)
			return true
		end
	else
		local v641 = p633:getSelectedObject()
		local v642 = false
		for _, v643 in ipairs(p633.selectableObjects) do
			if v643 == v641 then
				v642 = true
			end
		end
		if not v642 then
			v637.object = nil
			v637.index = 1
			v637.subIndex = 1
		end
	end
	return false
end
function Vehicle.getIsSelected(p644)
	return p644.selectionObject.isSelected
end
function Vehicle.getSelectedObject(p645)
	local v646 = p645.rootVehicle
	if v646 == p645 then
		return p645.currentSelection.object
	else
		return v646:getSelectedObject()
	end
end
function Vehicle.getSelectedVehicle(p647)
	local v648 = p647:getSelectedObject()
	if v648 == nil then
		return nil
	else
		return v648.vehicle
	end
end
function Vehicle.hasInputConflictWithSelection(p649, _)
	printCallstack()
	Logging.xmlWarning(p649.xmlFile, "Vehicle:hasInputConflictWithSelection() is deprecated!")
	return false
end
function Vehicle.setMassDirty(p650)
	p650.isMassDirty = true
end
function Vehicle.updateMass(p651)
	p651.serverMass = 0
	for _, v652 in ipairs(p651.components) do
		if v652.defaultMass == nil then
			if v652.isDynamic then
				v652.defaultMass = getMass(v652.node)
			else
				v652.defaultMass = 1
			end
			v652.mass = v652.defaultMass
		end
		local v653 = p651:getAdditionalComponentMass(v652)
		v652.mass = v652.defaultMass + v653
		p651.serverMass = p651.serverMass + v652.mass
	end
	local v654 = 0
	for _, v655 in ipairs(p651.components) do
		v654 = v654 + p651:getComponentMass(v655)
	end
	p651.precalculatedMass = v654 - p651.serverMass
	for _, v656 in ipairs(p651.components) do
		local v657 = p651.serverMass / (p651.maxComponentMass - p651.precalculatedMass)
		if v657 > 1 then
			v656.mass = v656.mass / v657
		end
		if p651.isServer and v656.isDynamic then
			local v658 = v656.lastMass - v656.mass
			if math.abs(v658) > 0.02 then
				setMass(v656.node, v656.mass)
				v656.lastMass = v656.mass
			end
		end
	end
	local v659 = p651.serverMass
	local v660 = p651.maxComponentMass - p651.precalculatedMass
	p651.serverMass = math.min(v659, v660)
end
function Vehicle.getMaxComponentMassReached(p661)
	return p661.serverMass + 0.00001 >= p661.maxComponentMass - p661.precalculatedMass
end
function Vehicle.getAvailableComponentMass(p662)
	local v663 = p662.maxComponentMass - p662.precalculatedMass - p662.serverMass
	return math.max(v663, 0)
end
function Vehicle.getAdditionalComponentMass(_, _)
	return 0
end
function Vehicle.getTotalMass(p664, _)
	local v665 = 0
	for _, v666 in ipairs(p664.components) do
		v665 = v665 + p664:getComponentMass(v666)
	end
	return v665
end
function Vehicle.getComponentMass(_, p667)
	return p667 == nil and 0 or p667.mass
end
function Vehicle.getDefaultMass(p668)
	local v669 = 0
	for _, v670 in ipairs(p668.components) do
		v669 = v669 + (v670.defaultMass or 0)
	end
	return v669
end
function Vehicle.getOverallCenterOfMass(p671)
	local v672 = p671:getTotalMass(true)
	local v673 = 0
	local v674 = 0
	local v675 = 0
	for v676 = 1, #p671.components do
		local v677 = p671.components[v676]
		local v678, v679, v680 = localToWorld(v677.node, getCenterOfMass(v677.node))
		local v681 = p671:getComponentMass(v677) / v672
		v673 = v673 + v678 * v681
		v674 = v674 + v679 * v681
		v675 = v675 + v680 * v681
	end
	return v673, v674, v675
end
function Vehicle.getVehicleWorldXRot(p682)
	local _, v683, _ = localDirectionToWorld(p682.components[1].node, 0, 0, 1)
	local v684 = 1 / v683
	local v685 = 1.5707963267948966 - math.atan(v684)
	if v685 > 1.5707963267948966 then
		v685 = v685 - 3.141592653589793
	end
	return v685
end
function Vehicle.getVehicleWorldDirection(p686)
	return localDirectionToWorld(p686.components[1].node, 0, 0, 1)
end
function Vehicle.getFillLevelInformation(_, _) end
function Vehicle.activate(p687)
	if p687.actionController ~= nil then
		p687.actionController:activate()
	end
	SpecializationUtil.raiseEvent(p687, "onActivate")
end
function Vehicle.deactivate(p688)
	if p688.actionController ~= nil then
		p688.actionController:deactivate()
	end
	SpecializationUtil.raiseEvent(p688, "onDeactivate")
end
function Vehicle.setComponentJointFrame(p689, p690, p691)
	if p691 == 0 then
		local v692 = p690.jointLocalPoses[1]
		local v693 = v692.trans
		local v694 = v692.trans
		local v695 = v692.trans
		local v696, v697, v698 = localToLocal(p690.jointNode, p689.components[p690.componentIndices[1]].node, 0, 0, 0)
		v693[1] = v696
		v694[2] = v697
		v695[3] = v698
		local v699 = v692.rot
		local v700 = v692.rot
		local v701 = v692.rot
		local v702, v703, v704 = localRotationToLocal(p690.jointNode, p689.components[p690.componentIndices[1]].node, 0, 0, 0)
		v699[1] = v702
		v700[2] = v703
		v701[3] = v704
	else
		local v705 = p690.jointLocalPoses[2]
		local v706 = v705.trans
		local v707 = v705.trans
		local v708 = v705.trans
		local v709, v710, v711 = localToLocal(p690.jointNodeActor1, p689.components[p690.componentIndices[2]].node, 0, 0, 0)
		v706[1] = v709
		v707[2] = v710
		v708[3] = v711
		local v712 = v705.rot
		local v713 = v705.rot
		local v714 = v705.rot
		local v715, v716, v717 = localRotationToLocal(p690.jointNodeActor1, p689.components[p690.componentIndices[2]].node, 0, 0, 0)
		v712[1] = v715
		v713[2] = v716
		v714[3] = v717
	end
	local v718 = p690.jointNode
	if p691 == 1 then
		v718 = p690.jointNodeActor1
	end
	if p690.jointIndex ~= 0 then
		setJointFrame(p690.jointIndex, p691, v718)
	end
end
function Vehicle.setComponentJointRotLimit(p719, p720, p721, p722, p723)
	if p719.isServer then
		p720.rotLimit[p721] = p723
		p720.rotMinLimit[p721] = p722
		if p720.jointIndex ~= 0 then
			if p722 <= p723 then
				setJointRotationLimit(p720.jointIndex, p721 - 1, true, p722, p723)
				return
			end
			setJointRotationLimit(p720.jointIndex, p721 - 1, false, 0, 0)
		end
	end
end
function Vehicle.setComponentJointTransLimit(p724, p725, p726, p727, p728)
	if p724.isServer then
		p725.transLimit[p726] = p728
		p725.transMinLimit[p726] = p727
		if p725.jointIndex ~= 0 then
			if p727 <= p728 then
				setJointTranslationLimit(p725.jointIndex, p726 - 1, true, p727, p728)
				return
			end
			setJointTranslationLimit(p725.jointIndex, p726 - 1, false, 0, 0)
		end
	end
end
function Vehicle.loadComponentFromXML(p729, p730, p731, p732, p733, p734)
	if not p729.isServer and getRigidBodyType(p730.node) == RigidBodyType.DYNAMIC then
		setRigidBodyType(p730.node, RigidBodyType.KINEMATIC)
	end
	if p734 == 1 then
		local v735, v736, v737 = getTranslation(p730.node)
		p733[1] = v735
		p733[2] = v736
		p733[3] = v737
		if p733[2] ~= 0 then
			Logging.xmlWarning(p729.xmlFile, "Y-Translation of component 1 (node 0>) has to be 0. Current value is: %.5f", p733[2])
		end
	end
	if getRigidBodyType(p730.node) == RigidBodyType.STATIC then
		p730.isStatic = true
	elseif getRigidBodyType(p730.node) == RigidBodyType.KINEMATIC then
		p730.isKinematic = true
	elseif getRigidBodyType(p730.node) == RigidBodyType.DYNAMIC then
		p730.isDynamic = true
	end
	if not CollisionFlag.getHasGroupFlagSet(p730.node, CollisionFlag.VEHICLE) then
		Logging.xmlWarning(p729.xmlFile, "Missing collision group mask %s. Please add this bit to component node \'%s\'", CollisionFlag.getBitAndName(CollisionFlag.VEHICLE), getName(p730.node))
	end
	if not CollisionFlag.getHasMaskFlagSet(p730.node, CollisionFlag.VEHICLE) then
		Logging.xmlWarning(p729.xmlFile, "Missing collision filter mask %s. Please add this bit to component node \'%s\'", CollisionFlag.getBitAndName(CollisionFlag.VEHICLE), getName(p730.node))
	end
	translate(p730.node, -p733[1], -p733[2], -p733[3])
	local v738, v739, v740 = getTranslation(p730.node)
	local v741, v742, v743 = getRotation(p730.node)
	p730.originalTranslation = { v738, v739, v740 }
	p730.originalRotation = { v741, v742, v743 }
	p730.sentTranslation = { v738, v739, v740 }
	p730.sentRotation = { v741, v742, v743 }
	p730.defaultMass = nil
	p730.mass = nil
	local v744 = p731:getValue(p732 .. "#mass")
	if v744 == nil then
		Logging.xmlWarning(p729.xmlFile, "Missing \'mass\' for \'%s\'. Using default mass 500kg instead!", p732)
		p730.defaultMass = 0.5
		p730.mass = 0.5
		p730.lastMass = p730.mass
	else
		if v744 < 10 then
			Logging.xmlDevWarning(p729.xmlFile, "Mass is lower than 10kg for \'%s\'. Mass unit is kilograms. Is this correct?", p732)
		end
		if p730.isDynamic then
			setMass(p730.node, v744 / 1000)
		end
		p730.defaultMass = v744 / 1000
		p730.mass = p730.defaultMass
		p730.lastMass = p730.mass
	end
	local v745, v746, v747 = p731:getValue(p732 .. "#centerOfMass")
	if v745 ~= nil then
		setCenterOfMass(p730.node, v745, v746, v747)
	end
	local v748, v749, v750 = p731:getValue(p732 .. "#inertiaScale")
	if v748 ~= nil then
		setInertiaScale(p730.node, v748, v749, v750)
	end
	local v751 = p731:getValue(p732 .. "#solverIterationCount")
	if v751 ~= nil then
		setSolverIterationCount(p730.node, v751)
		p730.solverIterationCount = v751
	end
	p730.motorized = p731:getValue(p732 .. "#motorized")
	p729.vehicleNodes[p730.node] = {
		["component"] = p730
	}
	if getClipDistance(p730.node) >= 1000000 and getVisibility(p730.node) then
		Logging.xmlWarning(p729.xmlFile, "No clipdistance is set to component node \'%s\' (%s>). Set default clipdistance \'%d\'", getName(p730.node), p734 - 1, 300)
		setClipDistance(p730.node, 300)
	end
	p730.collideWithAttachables = p731:getValue(p732 .. "#collideWithAttachables", false)
	if getRigidBodyType(p730.node) ~= RigidBodyType.NONE then
		if getLinearDamping(p730.node) > 0.01 then
			Logging.xmlDevWarning(p729.xmlFile, "Non-zero linear damping (%.4f) for component node \'%s\' (%s>). Is this correct?", getLinearDamping(p730.node), getName(p730.node), p734 - 1)
		elseif getAngularDamping(p730.node) > 0.05 then
			Logging.xmlDevWarning(p729.xmlFile, "Large angular damping (%.4f) for component node \'%s\' (%s>). Is this correct?", getAngularDamping(p730.node), getName(p730.node), p734 - 1)
		elseif getAngularDamping(p730.node) < 0.0001 then
			Logging.xmlDevWarning(p729.xmlFile, "Zero damping for component node \'%s\' (%s>). Is this correct?", getName(p730.node), p734 - 1)
		end
	end
	local v752 = getName(p730.node)
	if not v752:contains("_component") then
		Logging.xmlDevWarning(p729.xmlFile, "Name of component \'%d\' (\'%s\') does not correspond with the component naming convention! (vehicleName_componentName_component%d)", p734, v752, p734)
	end
	g_currentMission:addNodeObject(p730.node, p729)
	return true
end
function Vehicle.loadComponentJointFromXML(p753, p754, p755, p756, p757, p758, p759, p760)
	XMLUtil.checkDeprecatedXMLElements(p753.xmlFile, p756 .. "#indexActor1", p756 .. "#nodeActor1")
	p754.componentIndices = { p759, p760 }
	p754.jointNode = p758
	p754.jointNodeActor1 = p755:getValue(p756 .. "#nodeActor1", p758, p753.components, p753.i3dMappings)
	if p753.isServer then
		if p753.components[p759] == nil or p753.components[p760] == nil then
			Logging.xmlWarning(p753.xmlFile, "Invalid component indices (component1: %d, component2: %d) for component joint %d. Indices start with 1!", p759, p760, p757)
			return false
		end
		local v761, v762, v763 = p755:getValue(p756 .. "#rotLimit")
		local v764 = {}
		local v765 = Utils.getNoNil(v761, 0)
		local v766 = math.rad(v765)
		local v767 = Utils.getNoNil(v762, 0)
		local v768 = math.rad(v767)
		local v769 = Utils.getNoNil(v763, 0)
		__set_list(v764, 1, {v766, v768, (math.rad(v769))})
		local v770, v771, v772 = p755:getValue(p756 .. "#transLimit")
		local v773 = { Utils.getNoNil(v770, 0), Utils.getNoNil(v771, 0), Utils.getNoNil(v772, 0) }
		p754.rotLimit = v764
		p754.transLimit = v773
		local v774, v775, v776 = p755:getValue(p756 .. "#rotMinLimit")
		local v777 = { Utils.getNoNilRad(v774, nil), Utils.getNoNilRad(v775, nil), Utils.getNoNilRad(v776, nil) }
		local v778, v779, v780 = p755:getValue(p756 .. "#transMinLimit")
		local v781 = { v778, v779, v780 }
		for v782 = 1, 3 do
			if v777[v782] == nil then
				if v764[v782] >= 0 then
					v777[v782] = -v764[v782]
				else
					v777[v782] = v764[v782] + 1
				end
			end
			if v781[v782] == nil then
				if v773[v782] >= 0 then
					v781[v782] = -v773[v782]
				else
					v781[v782] = v773[v782] + 1
				end
			end
		end
		p754.jointLocalPoses = {}
		local v783 = {
			["trans"] = { localToLocal(p754.jointNode, p753.components[p759].node, 0, 0, 0) },
			["rot"] = { localRotationToLocal(p754.jointNode, p753.components[p759].node, 0, 0, 0) }
		}
		p754.jointLocalPoses[1] = v783
		local v784 = {
			["trans"] = { localToLocal(p754.jointNodeActor1, p753.components[p760].node, 0, 0, 0) },
			["rot"] = { localRotationToLocal(p754.jointNodeActor1, p753.components[p760].node, 0, 0, 0) }
		}
		p754.jointLocalPoses[2] = v784
		p754.rotMinLimit = v777
		p754.transMinLimit = v781
		local v785, v786, v787 = p755:getValue(p756 .. "#rotLimitSpring")
		local v788 = { Utils.getNoNil(v785, 0), Utils.getNoNil(v786, 0), Utils.getNoNil(v787, 0) }
		local v789, v790, v791 = p755:getValue(p756 .. "#rotLimitDamping")
		local v792 = { Utils.getNoNil(v789, 1), Utils.getNoNil(v790, 1), Utils.getNoNil(v791, 1) }
		p754.rotLimitSpring = v788
		p754.rotLimitDamping = v792
		local v793, v794, v795 = p755:getValue(p756 .. "#rotLimitForceLimit")
		local v796 = { Utils.getNoNil(v793, -1), Utils.getNoNil(v794, -1), Utils.getNoNil(v795, -1) }
		local v797, v798, v799 = p755:getValue(p756 .. "#transLimitForceLimit")
		local v800 = { Utils.getNoNil(v797, -1), Utils.getNoNil(v798, -1), Utils.getNoNil(v799, -1) }
		p754.rotLimitForceLimit = v796
		p754.transLimitForceLimit = v800
		local v801, v802, v803 = p755:getValue(p756 .. "#transLimitSpring")
		local v804 = { Utils.getNoNil(v801, 0), Utils.getNoNil(v802, 0), Utils.getNoNil(v803, 0) }
		local v805, v806, v807 = p755:getValue(p756 .. "#transLimitDamping")
		local v808 = { Utils.getNoNil(v805, 1), Utils.getNoNil(v806, 1), Utils.getNoNil(v807, 1) }
		p754.transLimitSpring = v804
		p754.transLimitDamping = v808
		p754.zRotationXOffset = 0
		local v809 = p755:getValue(p756 .. "#zRotationNode", nil, p753.components, p753.i3dMappings)
		if v809 ~= nil then
			local v810, v811, v812 = localToLocal(v809, p758, 0, 0, 0)
			p754.zRotationXOffset = v810
			if math.abs(v811) > 0.01 or math.abs(v812) > 0.01 then
				Logging.xmlWarning(p753.xmlFile, "ComponentJoint zRotationNode \'%s\' is not correctly aligned with joint node \'%s\'. Offset is: y %.3f, z %.3f. Make sure the zRotationNode has only a translation offset on the X axis.", getName(v809), getName(p758), v811, v812)
			end
		end
		p754.isBreakable = p755:getValue(p756 .. "#breakable", false)
		if p754.isBreakable then
			p754.breakForce = p755:getValue(p756 .. "#breakForce", 10)
			p754.breakTorque = p755:getValue(p756 .. "#breakTorque", 10)
		end
		p754.enableCollision = p755:getValue(p756 .. "#enableCollision", false)
		local v813, v814, v815 = p755:getValue(p756 .. "#maxRotDriveForce")
		local v816 = { Utils.getNoNil(v813, 0), Utils.getNoNil(v814, 0), Utils.getNoNil(v815, 0) }
		local v817, v818, v819 = p755:getValue(p756 .. "#rotDriveVelocity")
		local v820 = { Utils.getNoNilRad(v817, nil), Utils.getNoNilRad(v818, nil), Utils.getNoNilRad(v819, nil) }
		local v821, v822, v823 = p755:getValue(p756 .. "#rotDriveRotation")
		local v824 = { Utils.getNoNilRad(v821, nil), Utils.getNoNilRad(v822, nil), Utils.getNoNilRad(v823, nil) }
		local v825, v826, v827 = p755:getValue(p756 .. "#rotDriveSpring")
		local v828 = { Utils.getNoNil(v825, 0), Utils.getNoNil(v826, 0), Utils.getNoNil(v827, 0) }
		local v829, v830, v831 = p755:getValue(p756 .. "#rotDriveDamping")
		local v832 = { Utils.getNoNil(v829, 0), Utils.getNoNil(v830, 0), Utils.getNoNil(v831, 0) }
		p754.rotDriveVelocity = v820
		p754.rotDriveRotation = v824
		p754.rotDriveSpring = v828
		p754.rotDriveDamping = v832
		p754.maxRotDriveForce = v816
		local v833, v834, v835 = p755:getValue(p756 .. "#maxTransDriveForce")
		local v836 = { Utils.getNoNil(v833, 0), Utils.getNoNil(v834, 0), Utils.getNoNil(v835, 0) }
		local v837, v838, v839 = p755:getValue(p756 .. "#transDriveVelocity")
		local v840 = { v837, v838, v839 }
		local v841, v842, v843 = p755:getValue(p756 .. "#transDrivePosition")
		local v844 = { v841, v842, v843 }
		local v845, v846, v847 = p755:getValue(p756 .. "#transDriveSpring")
		local v848 = { Utils.getNoNil(v845, 0), Utils.getNoNil(v846, 0), Utils.getNoNil(v847, 0) }
		local v849, v850, v851 = p755:getValue(p756 .. "#transDriveDamping")
		local v852 = { Utils.getNoNil(v849, 1), Utils.getNoNil(v850, 1), Utils.getNoNil(v851, 1) }
		p754.transDriveVelocity = v840
		p754.transDrivePosition = v844
		p754.transDriveSpring = v848
		p754.transDriveDamping = v852
		p754.maxTransDriveForce = v836
		p754.initComponentPosition = p755:getValue(p756 .. "#initComponentPosition", true)
		p754.jointIndex = 0
	end
	return true
end
function Vehicle.createComponentJoint(p853, p854, p855, p856)
	if p854 == nil or (p855 == nil or p856 == nil) then
		Logging.xmlWarning(p853.xmlFile, "Could not create component joint. No component1, component2 or jointDesc given!")
		return false
	end
	local v857 = JointConstructor.new()
	v857:setActors(p854.node, p855.node)
	local v858 = p856.jointLocalPoses[1]
	local v859 = p856.jointLocalPoses[2]
	v857:setJointLocalPositions(v858.trans[1], v858.trans[2], v858.trans[3], v859.trans[1], v859.trans[2], v859.trans[3])
	v857:setJointLocalRotations(v858.rot[1], v858.rot[2], v858.rot[3], v859.rot[1], v859.rot[2], v859.rot[3])
	v857:setRotationLimitSpring(p856.rotLimitSpring[1], p856.rotLimitDamping[1], p856.rotLimitSpring[2], p856.rotLimitDamping[2], p856.rotLimitSpring[3], p856.rotLimitDamping[3])
	v857:setTranslationLimitSpring(p856.transLimitSpring[1], p856.transLimitDamping[1], p856.transLimitSpring[2], p856.transLimitDamping[2], p856.transLimitSpring[3], p856.transLimitDamping[3])
	v857:setZRotationXOffset(p856.zRotationXOffset)
	for v860 = 1, 3 do
		if p856.rotLimit[v860] >= p856.rotMinLimit[v860] then
			v857:setRotationLimit(v860 - 1, p856.rotMinLimit[v860], p856.rotLimit[v860])
		end
		if p856.transLimit[v860] >= p856.transMinLimit[v860] then
			v857:setTranslationLimit(v860 - 1, true, p856.transMinLimit[v860], p856.transLimit[v860])
		else
			v857:setTranslationLimit(v860 - 1, false, 0, 0)
		end
	end
	v857:setRotationLimitForceLimit(p856.rotLimitForceLimit[1], p856.rotLimitForceLimit[2], p856.rotLimitForceLimit[3])
	v857:setTranslationLimitForceLimit(p856.transLimitForceLimit[1], p856.transLimitForceLimit[2], p856.transLimitForceLimit[3])
	if p856.isBreakable then
		v857:setBreakable(p856.breakForce, p856.breakTorque)
	end
	v857:setEnableCollision(p856.enableCollision)
	for v861 = 1, 3 do
		if p856.maxRotDriveForce[v861] > 0.0001 and (p856.rotDriveVelocity[v861] ~= nil or p856.rotDriveRotation[v861] ~= nil) then
			local v862 = Utils.getNoNil(p856.rotDriveRotation[v861], 0)
			local v863 = Utils.getNoNil(p856.rotDriveVelocity[v861], 0)
			v857:setAngularDrive(v861 - 1, p856.rotDriveRotation[v861] ~= nil, p856.rotDriveVelocity[v861] ~= nil, p856.rotDriveSpring[v861], p856.rotDriveDamping[v861], p856.maxRotDriveForce[v861], v862, v863)
		end
		if p856.maxTransDriveForce[v861] > 0.0001 and (p856.transDriveVelocity[v861] ~= nil or p856.transDrivePosition[v861] ~= nil) then
			local v864 = Utils.getNoNil(p856.transDrivePosition[v861], 0)
			local v865 = Utils.getNoNil(p856.transDriveVelocity[v861], 0)
			v857:setLinearDrive(v861 - 1, p856.transDrivePosition[v861] ~= nil, p856.transDriveVelocity[v861] ~= nil, p856.transDriveSpring[v861], p856.transDriveDamping[v861], p856.maxTransDriveForce[v861], v864, v865)
		end
	end
	p856.jointIndex = v857:finalize()
	return true
end
function Vehicle.prefixSchemaOverlayName(p866, p867)
	if p866 ~= "" and not VehicleSchemaOverlayData.SCHEMA_OVERLAY[p866] then
		p866 = p867 .. p866
	end
	return p866
end
function Vehicle.loadSchemaOverlay(p868, p869)
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#file")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#width")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#height")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#invisibleBorderRight", "vehicle.base.schemaOverlay#invisibleBorderRight")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#invisibleBorderLeft", "vehicle.base.schemaOverlay#invisibleBorderLeft")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#attacherJointPosition", "vehicle.base.schemaOverlay#attacherJointPosition")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#basePosition", "vehicle.base.schemaOverlay#basePosition")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#fileSelected")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#fileTurnedOn")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.schemaOverlay#fileSelectedTurnedOn")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.base.schemaOverlay.default#name", "vehicle.base.schemaOverlay#name")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.base.schemaOverlay.turnedOn#name")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.base.schemaOverlay.selected#name")
	XMLUtil.checkDeprecatedXMLElements(p868.xmlFile, "vehicle.base.schemaOverlay.turnedOnSelected#name")
	if p869:hasProperty("vehicle.base.schemaOverlay") then
		XMLUtil.checkDeprecatedXMLElements(p869, "vehicle.schemaOverlay.attacherJoint", "vehicle.attacherJoints.attacherJoint.schema")
		local v870, v871 = p869:getValue("vehicle.base.schemaOverlay#attacherJointPosition")
		local v872, v873 = p869:getValue("vehicle.base.schemaOverlay#basePosition")
		if v872 ~= nil then
			v870 = v872
		end
		if v873 ~= nil then
			v871 = v873
		end
		local v874 = p869:getValue("vehicle.base.schemaOverlay#name", "")
		local v875 = p868.customEnvironment or ""
		local v876 = Vehicle.prefixSchemaOverlayName(v874, v875)
		p868.schemaOverlay = VehicleSchemaOverlayData.new(v870, v871, v876, p869:getValue("vehicle.base.schemaOverlay#invisibleBorderRight"), p869:getValue("vehicle.base.schemaOverlay#invisibleBorderLeft"))
	end
end
function Vehicle.getAdditionalSchemaText(_)
	return nil
end
function Vehicle.getUseTurnedOnSchema(_)
	return false
end
function Vehicle.dayChanged(_) end
function Vehicle.periodChanged(p877)
	p877.age = p877.age + 1
end
function Vehicle.raiseStateChange(p878, p879, ...)
	SpecializationUtil.raiseEvent(p878, "onStateChange", p879, ...)
end
function Vehicle.doCheckSpeedLimit(_)
	return false
end
function Vehicle.getWorkLoad(_)
	return 0, 0
end
function Vehicle.interact(_, _) end
function Vehicle.getInteractionHelp(_)
	return ""
end
function Vehicle.getIsInteractive(p880)
	return not p880.isBroken
end
function Vehicle.getDistanceToNode(p881, _)
	p881.interactionFlag = Vehicle.INTERACTION_FLAG_NONE
	return (1 / 0)
end
function Vehicle.getIsAIActive(p882)
	if p882.getAttacherVehicle ~= nil then
		local v883 = p882:getAttacherVehicle()
		if v883 ~= nil then
			return v883:getIsAIActive()
		end
	end
	return false
end
function Vehicle.getIsPowered(_)
	return true
end
function Vehicle.getRequiresPower(_)
	return false
end
function Vehicle.getIsInShowroom(p884)
	return p884.propertyState == VehiclePropertyState.SHOP_CONFIG
end
function Vehicle.addVehicleToAIImplementList(_, _) end
function Vehicle.setOperatingTime(p885, p886, p887)
	if not p887 and (p885.propertyState == VehiclePropertyState.LEASED and (g_currentMission ~= nil and g_currentMission.economyManager ~= nil)) then
		local v888 = p886 / 3600000
		local v889 = math.floor(v888)
		local v890 = p885.operatingTime / 3600000
		if math.floor(v890) < v889 then
			g_currentMission.economyManager:vehicleOperatingHourChanged(p885)
		end
	end
	p885.operatingTime = math.max(p886 or 0, 0)
end
function Vehicle.getOperatingTime(p891)
	return p891.operatingTime
end
function Vehicle.doCollisionMaskCheck(p892, p893, p894, p895, p896)
	local v897
	if p894 == nil then
		v897 = false
	else
		v897 = p892.xmlFile:getValue(p894, false)
	end
	if not v897 then
		local v898 = false
		if p895 == nil then
			for _, v899 in ipairs(p892.components) do
				v898 = v898 or bitAND(getCollisionFilterMask(v899.node), p893) == p893
			end
		else
			v898 = v898 or bitAND(getCollisionFilterMask(p895), p893) == p893
		end
		if not v898 then
			printCallstack()
			Logging.xmlWarning(p892.xmlFile, "%s has wrong collision mask! Following bit(s) need to be set \'%s\' or use \'%s\'", p896 or p892.typeName, MathUtil.numberToSetBitsStr(p893), p894)
			return false
		end
	end
	return true
end
function Vehicle.getIsReadyForAutomatedTrainTravel(_)
	return true
end
function Vehicle.getIsAutomaticShiftingAllowed(_)
	return true
end
function Vehicle.getSpeedLimit(p900, p901)
	local v902 = p900:doCheckSpeedLimit()
	local v903
	if p901 == nil or p901 and v902 then
		v903 = p900:getRawSpeedLimit()
		local v904 = p900:getVehicleDamage()
		if v904 > 0 then
			v903 = v903 * (1 - v904 * Vehicle.DAMAGED_SPEEDLIMIT_REDUCTION)
		end
	else
		v903 = (1 / 0)
	end
	local v905
	if p900.getAttachedImplements == nil then
		v905 = nil
	else
		v905 = p900:getAttachedImplements()
	end
	if v905 ~= nil then
		for _, v906 in pairs(v905) do
			if v906.object ~= nil then
				local v907, v908 = v906.object:getSpeedLimit(p901)
				if p901 == nil or p901 and v908 then
					v903 = math.min(v903, v907)
				end
				v902 = v902 or v908
			end
		end
	end
	return v903, v902
end
function Vehicle.getRawSpeedLimit(p909)
	return p909.speedLimit
end
function Vehicle.onVehicleWakeUpCallback(p910, _)
	p910:raiseActive()
end
function Vehicle.getCanBeMounted(p911)
	return entityExists(p911.components[1].node)
end
function Vehicle.getDailyUpkeep(p912)
	local v913 = g_storeManager:getItemByXMLFilename(p912.configFileName)
	return Vehicle.calculateDailyUpkeep(v913, p912.age, p912.operatingTime, p912.configurations)
end
function Vehicle.calculateDailyUpkeep(p914, p915, p916, p917)
	local v918
	if p914.lifetime == nil or p914.lifetime == 0 then
		v918 = 1
	else
		local v919 = p915 / p914.lifetime
		local v920 = 0.3 * math.min(v919, 1)
		local v921 = p916 / 3600000 / (p914.lifetime * EconomyManager.LIFETIME_OPERATINGTIME_RATIO)
		local v922 = 0.7 * math.min(v921, 1)
		v918 = 1 + EconomyManager.MAX_DAILYUPKEEP_MULTIPLIER * (v920 + v922)
	end
	return StoreItemUtil.getDailyUpkeep(p914, p917) * v918
end
function Vehicle.getUppercaseName(p923)
	local v924 = p923:getFullName()
	return utf8ToUpper(v924)
end
function Vehicle.getName(p925)
	local v926 = g_storeManager:getItemByXMLFilename(p925.configFileName)
	if v926 ~= nil and v926.configurations ~= nil then
		for v927, _ in pairs(v926.configurations) do
			local v928 = p925.configurations[v927]
			local v929 = v926.configurations[v927][v928]
			if v929.vehicleName ~= nil and v929.vehicleName ~= "" then
				return v929.vehicleName
			end
		end
	end
	return v926.name
end
function Vehicle.getFullName(p930)
	local v931 = p930:getName()
	if g_storeManager:getItemByXMLFilename(p930.configFileName) ~= nil then
		local v932 = g_brandManager:getBrandByIndex(p930:getBrand())
		if v932 ~= nil and v932.name ~= "NONE" then
			v931 = v932.title .. " " .. v931
		end
	end
	return v931
end
function Vehicle.getBrand(p933)
	local v934 = g_storeManager:getItemByXMLFilename(p933.configFileName)
	if v934 ~= nil and v934.configurations ~= nil then
		for v935, _ in pairs(v934.configurations) do
			local v936 = p933.configurations[v935]
			local v937 = v934.configurations[v935][v936]
			if v937.vehicleBrand ~= nil then
				return v937.vehicleBrand
			end
		end
	end
	return v934.brandIndex
end
function Vehicle.getImageFilename(p938)
	local v939 = g_storeManager:getItemByXMLFilename(p938.configFileName)
	if v939 ~= nil and v939.configurations ~= nil then
		for v940, _ in pairs(v939.configurations) do
			local v941 = p938.configurations[v940]
			local v942 = v939.configurations[v940][v941]
			if v942 == nil then
				Logging.xmlWarning(p938.xmlFile, "Vehicle has an invalid configuration value %s for %s", v941, v940)
			elseif v942.vehicleIcon ~= nil and v942.vehicleIcon ~= "" then
				return v942.vehicleIcon
			end
		end
	end
	return v939.imageFilename
end
function Vehicle.getCanBePickedUp(p943, p944)
	local v945 = p943.supportsPickUp
	if v945 then
		v945 = g_currentMission.accessHandler:canPlayerAccess(p943, p944)
	end
	return v945
end
function Vehicle.getCanBeReset(p946)
	local v947 = p946.canBeReset
	if v947 then
		v947 = not g_guidedTourManager:getIsTourRunning()
	end
	return v947
end
function Vehicle.getCanBeSold(p948)
	local v949 = g_storeManager:getItemByXMLFilename(p948.configFileName)
	return v949 == nil and true or v949.canBeSold
end
function Vehicle.getReloadXML(p950)
	local v951 = XMLFile.create("vehicleXMLFile", "", "vehicles", Vehicle.xmlSchemaSavegame)
	if v951 == nil then
		return nil
	end
	local v952 = string.format("vehicles.vehicle(%d)", 0)
	v951:setValue(v952 .. "#filename", HTMLUtil.encodeToHTML(NetworkUtil.convertToNetworkFilename(p950.configFileName)))
	p950:saveToXMLFile(v951, v952, {})
	return v951
end
function Vehicle.getIsInUse(_, _)
	return false
end
function Vehicle.getPropertyState(p953)
	return p953.propertyState
end
function Vehicle.getAreControlledActionsAvailable(p954)
	if p954:getIsAIActive() then
		return false
	elseif p954.actionController == nil then
		return false
	else
		return p954.actionController:getAreControlledActionsAvailable()
	end
end
function Vehicle.getAreControlledActionsAccessible(p955)
	if p955:getIsAIActive() then
		return false
	elseif p955.actionController == nil then
		return false
	else
		return p955.actionController:getAreControlledActionsAccessible()
	end
end
function Vehicle.getControlledActionIcons(p956)
	if p956.actionController ~= nil then
		local v957, v958, v959 = p956.actionController:getControlledActionIcons()
		if v957 ~= nil then
			return v957, v958, v959
		end
	end
	return "TURN_ON", "TURN_ON", true
end
function Vehicle.getAreControlledActionsAllowed(p960)
	return not p960:getIsAIActive(), ""
end
function Vehicle.playControlledActions(p961)
	if p961.actionController ~= nil then
		p961.actionController:playControlledActions()
	end
end
function Vehicle.getActionControllerDirection(p962)
	return p962.actionController == nil and 1 or p962.actionController:getActionControllerDirection()
end
function Vehicle.createMapHotspot(p963)
	local v964 = VehicleHotspot.new()
	v964:setVehicle(p963)
	v964:setVehicleType(p963.mapHotspotType)
	v964:setOwnerFarmId(p963:getOwnerFarmId())
	p963.mapHotspot = v964
	g_currentMission:addMapHotspot(v964)
end
function Vehicle.deleteMapHotspot(p965)
	if p965.mapHotspot ~= nil then
		g_currentMission:removeMapHotspot(p965.mapHotspot)
		p965.mapHotspot:delete()
		p965.mapHotspot = nil
	end
end
function Vehicle.getMapHotspot(p966)
	return p966.mapHotspot
end
function Vehicle.updateMapHotspot(p967)
	if p967.mapHotspot ~= nil then
		p967.mapHotspot:setVisible(p967:getIsMapHotspotVisible())
	end
end
function Vehicle.getIsMapHotspotVisible(_)
	return true
end
function Vehicle.getMapHotspotRotation(p968, _)
	local v969, _, v970 = localDirectionToWorld(p968.rootNode, 0, 0, 1)
	return MathUtil.getYRotationFromDirection(v969, v970) + 3.141592653589793
end
function Vehicle.getShowInVehiclesOverview(p971)
	local v972 = p971.showInVehicleOverview
	if v972 then
		v972 = p971.propertyState == VehiclePropertyState.OWNED and true or p971.propertyState == VehiclePropertyState.LEASED
	end
	return v972
end
function Vehicle.showInfo(p973, p974)
	if p973.isBroken then
		p974:addLine(g_i18n:getText("infohud_vehicleBrokenNeedToReset"), nil, true)
	end
end
function Vehicle.loadObjectChangeValuesFromXML(_, _, _, _, _) end
function Vehicle.setObjectChangeValues(_, _, _) end
function Vehicle.wakeUp(p975)
	I3DUtil.wakeUpObject(p975.components[1].node)
end
function Vehicle.register(p976, p977)
	Vehicle:superClass().register(p976, p977)
	SpecializationUtil.raiseEvent(p976, "onRegistered", p977)
end
function Vehicle.setOwnerFarmId(p978, p979, p980)
	Vehicle:superClass().setOwnerFarmId(p978, p979, p980)
	if p978.mapHotspot ~= nil then
		p978.mapHotspot:setOwnerFarmId(p979)
	end
end
function Vehicle.getUniqueId(p981)
	return p981.uniqueId
end
function Vehicle.setUniqueId(p982, p983)
	p982.uniqueId = p983
end
function Vehicle.actionEventToggleSelection(p984, _, _, _, _)
	local v985 = p984.currentSelection
	local v986 = v985.object
	local v987 = v985.index
	local v988 = v985.subIndex
	local v989 = v986 == nil and 0 or #v986.subSelections
	local v990 = v988 + 1
	local v991, v992
	if v989 < v990 then
		local v993 = v987 + 1
		v991 = #p984.selectableObjects < v993 and 1 or v993
		v992 = p984.selectableObjects[v991]
		v990 = 1
	else
		v991 = v987
		v992 = v986
	end
	if v986 ~= v992 or (v987 ~= v991 or v988 ~= v990) then
		p984:setSelectedObject(v992, v990)
	end
end
function Vehicle.actionEventToggleSelectionReverse(p994, _, _, _, _)
	local v995 = p994.currentSelection
	local v996 = v995.object
	local v997 = v995.index
	local v998 = v995.subIndex
	local v999 = v998 - 1
	local v1000, v1001
	if v999 < 1 then
		local v1002 = v997 - 1
		v1000 = v1002 < 1 and #p994.selectableObjects or v1002
		v1001 = p994.selectableObjects[v1000]
		if v1001 == nil then
			v999 = 1
		else
			v999 = #v1001.subSelections
		end
	else
		v1000 = v997
		v1001 = v996
	end
	if v996 ~= v1001 or (v997 ~= v1000 or v998 ~= v999) then
		p994:setSelectedObject(v1001, v999)
	end
end
function Vehicle.getSpecValueAge(_, p1003, _, p1004)
	if p1003 == nil or p1003.age == nil then
		if p1004 == nil or p1004.age == nil then
			return nil
		else
			return g_i18n:formatNumMonth(p1004.age)
		end
	else
		return g_i18n:formatNumMonth(p1003.age)
	end
end
function Vehicle.getSpecValueDailyUpkeep(p1005, p1006, _, p1007)
	local v1008 = p1005.dailyUpkeep
	local v1009
	if p1006 == nil or p1006.getDailyUpkeep == nil then
		v1009 = p1007 ~= nil and 0 or v1008
	else
		v1009 = p1006:getDailyUpkeep()
	end
	if v1009 == 0 then
		return nil
	else
		return string.format(g_i18n:getText("shop_maintenanceValue"), g_i18n:formatMoney(v1009, 2))
	end
end
function Vehicle.getSpecValueOperatingTime(_, p1010, _, p1011)
	local v1012
	if p1010 == nil or p1010.operatingTime == nil then
		if p1011 == nil then
			return nil
		end
		v1012 = p1011.operatingTime
	else
		v1012 = p1010.operatingTime
	end
	local v1013 = v1012 / 60000
	local v1014 = v1013 / 60
	local v1015 = math.floor(v1014)
	local v1016 = (v1013 - v1015 * 60) / 6
	local v1017 = math.floor(v1016)
	return string.format(g_i18n:getText("shop_operatingTime"), v1015, v1017)
end
function Vehicle.loadSpecValueWorkingWidth(p1018, _, _)
	return p1018:getValue("vehicle.storeData.specs.workingWidth")
end
function Vehicle.getSpecValueWorkingWidth(p1019, _)
	if p1019.specs.workingWidth == nil then
		return nil
	else
		return string.format(g_i18n:getText("shop_workingWidthValue"), g_i18n:formatNumber(p1019.specs.workingWidth, 1, true))
	end
end
function Vehicle.loadSpecValueWorkingWidthConfig(p1020, _, _)
	local v1021 = nil
	for v1022, v1023 in pairs(g_vehicleConfigurationManager:getConfigurations()) do
		for v1024, v1025 in p1020:iterator(v1023.configurationKey) do
			local v1026 = p1020:getValue(v1025 .. "#workingWidth")
			if v1026 ~= nil then
				v1021 = v1021 or {}
				v1021[v1022] = v1021[v1022] or {}
				v1021[v1022][v1024] = v1026
			end
		end
	end
	return v1021
end
function Vehicle.getSpecValueWorkingWidthConfig(p1027, p1028, p1029, p1030, p1031, _)
	if p1027.specs.workingWidthConfig == nil then
		return nil
	else
		local v1032 = 0
		local v1033 = 0
		if p1029 == nil or p1028 == nil and p1030 == nil then
			v1032 = (1 / 0)
			v1033 = 0
			for _, v1034 in pairs(p1027.specs.workingWidthConfig) do
				for _, v1035 in pairs(v1034) do
					v1032 = math.min(v1032, v1035)
					v1033 = math.max(v1033, v1035)
				end
			end
		else
			for v1036, v1037 in pairs(p1029) do
				if p1027.specs.workingWidthConfig[v1036] ~= nil then
					local v1038 = p1027.specs.workingWidthConfig[v1036][v1037]
					if v1038 ~= nil then
						v1033 = v1038
					end
				end
			end
		end
		if p1031 then
			return v1033
		elseif v1032 == 0 or (v1032 == (1 / 0) or v1032 == v1033) then
			return string.format(g_i18n:getText("shop_workingWidthValue"), g_i18n:formatNumber(v1033, 1, true))
		else
			return string.format(g_i18n:getText("shop_workingWidthValue"), string.format("%s-%s", g_i18n:formatNumber(v1032, 1, true), g_i18n:formatNumber(v1033, 1, true)))
		end
	end
end
function Vehicle.loadSpecValueSpeedLimit(p1039, _, _)
	return p1039:getValue("vehicle.base.speedLimit#value")
end
function Vehicle.getSpecValueSpeedLimit(p1040, _)
	if p1040.specs.speedLimit == nil then
		return nil
	else
		return string.format(g_i18n:getText("shop_maxSpeed"), string.format("%1d", g_i18n:getSpeed(p1040.specs.speedLimit)), g_i18n:getSpeedMeasuringUnit())
	end
end
function Vehicle.loadSpecValueWeight(p1041, p1042, p1043)
	local v1044 = {
		["componentMass"] = 0
	}
	for _, v1045 in p1041:iterator("vehicle.base.components.component") do
		local v1046 = p1041:getValue(v1045 .. "#mass", 0) / 1000
		v1044.componentMass = v1044.componentMass + v1046
	end
	v1044.configurations = {}
	local v1047 = false
	for v1048, v1049 in p1041:iterator("vehicle.base.componentConfigurations.componentConfiguration") do
		local v1050 = 0
		for _, v1051 in p1041:iterator(v1049 .. ".component") do
			v1050 = v1050 + p1041:getValue(v1051 .. "#mass", 0) / 1000
			v1047 = true
		end
		v1044.configurations[v1048] = v1050
	end
	v1044.fillUnitMassData = FillUnit.loadSpecValueFillUnitMassData(p1041, p1042, p1043)
	v1044.wheelMassDefaultConfig = Wheels.loadSpecValueWheelWeight(p1041, p1042, p1043)
	v1044.storeDataConfigs = {}
	local v1052 = nil
	local v1053 = nil
	for _, v1054 in p1041:iterator("vehicle.storeData.specs.weight.config") do
		local v1055 = {
			["name"] = p1041:getValue(v1054 .. "#name")
		}
		if v1055.name ~= nil then
			v1055.index = p1041:getValue(v1054 .. "#index", 1)
			v1055.value = p1041:getValue(v1054 .. "#value", 0) / 1000
			local v1056 = v1055.value * 1000
			v1052 = math.min(v1052 or (1 / 0), v1056)
			local v1057 = v1055.value * 1000
			v1053 = math.max(v1053 or (-1 / 0), v1057)
			local v1058 = v1044.storeDataConfigs
			table.insert(v1058, v1055)
		end
	end
	if #v1044.storeDataConfigs == 0 then
		v1044.storeDataConfigs = nil
	end
	if not p1041:getValue("vehicle.storeData.specs.weight#ignore", false) then
		v1044.storeDataMin = p1041:getValue("vehicle.storeData.specs.weight#minValue", v1052)
		v1044.storeDataMax = p1041:getValue("vehicle.storeData.specs.weight#maxValue", v1053)
		if v1044.componentMass > 0 or (v1047 or v1044.storeDataMin ~= nil) then
			return v1044
		end
	end
	return nil
end
function Vehicle.getSpecConfigValuesWeight(p1059, _, _, _, _, _)
	if p1059.specs.weight == nil or p1059.specs.weight.storeDataConfigs == nil then
		return nil
	else
		return p1059.specs.weight.storeDataConfigs
	end
end
function Vehicle.getSpecValueWeight(p1060, p1061, p1062, _, p1063, p1064)
	if p1060.specs.weight ~= nil then
		local v1065 = nil
		local v1066 = nil
		if p1061 == nil then
			if p1060.specs.weight.storeDataMin == nil then
				if p1060.specs.weight.componentMass ~= nil then
					if p1062 ~= nil and p1062.component ~= nil then
						v1065 = p1060.specs.weight.configurations[p1062.component]
					end
					if v1065 == nil then
						v1065 = p1060.specs.weight.componentMass
					end
					v1065 = v1065 + (p1060.specs.weight.wheelMassDefaultConfig or 0) + FillUnit.getSpecValueStartFillUnitMassByMassData(p1060.specs.weight.fillUnitMassData)
				end
			else
				v1065 = (p1060.specs.weight.storeDataMin or 0) / 1000
				v1066 = (p1060.specs.weight.storeDataMax or 0) / 1000
			end
		else
			p1061:updateMass()
			v1065 = p1061:getTotalMass(true)
		end
		if v1065 ~= nil and v1065 ~= 0 then
			if p1063 then
				if p1064 then
					return v1065, v1066
				else
					return v1065
				end
			elseif v1066 == nil or v1066 == 0 then
				return g_i18n:formatMass(v1065)
			else
				return g_i18n:formatMass(v1065, v1066)
			end
		end
	end
	return nil
end
function Vehicle.loadSpecValueAdditionalWeight(p1067, _, _)
	local v1068 = p1067:getValue("vehicle.base.components#maxMass")
	if v1068 == nil then
		return nil
	else
		return v1068 / 1000
	end
end
function Vehicle.getSpecValueAdditionalWeight(p1069, p1070, p1071, p1072, p1073, _)
	if not g_currentMission.missionInfo.trailerFillLimit then
		return nil
	end
	if p1069.specs.additionalWeight ~= nil then
		local v1074 = Vehicle.getSpecValueWeight(p1069, p1070, p1071, p1072, true)
		if v1074 ~= nil then
			local v1075 = p1069.specs.additionalWeight - v1074
			if p1073 then
				return v1075
			else
				return g_i18n:formatMass(v1075)
			end
		end
	end
	return nil
end
function Vehicle.loadSpecValueCombinations(p_u_1076, _, p_u_1077)
	local v_u_1078 = {}
	p_u_1076:iterate("vehicle.storeData.specs.combination", function(_, p1079)
		-- upvalues: (copy) p_u_1076, (copy) p_u_1077, (copy) v_u_1078
		local v1080 = {}
		local v1081 = p_u_1076:getValue(p1079 .. "#xmlFilename")
		if v1081 ~= nil then
			v1080.xmlFilename = Utils.getFilename(v1081)
			v1080.customXMLFilename = Utils.getFilename(v1081, p_u_1077)
			local v1082 = g_storeManager:getItemByXMLFilename(v1080.customXMLFilename)
			if v1082 == nil then
				v1082 = g_storeManager:getItemByXMLFilename(v1080.xmlFilename)
			end
			if v1082 == nil then
				Logging.xmlWarning(p_u_1076, "Could not find combination vehicle \'%s\'", v1080.xmlFilename)
			end
		end
		local v1083 = p_u_1076:getValue(p1079 .. "#filterCategory")
		if v1083 ~= nil then
			v1080.filterCategories = v1083:split(" ")
		end
		v1080.filterSpec = p_u_1076:getValue(p1079 .. "#filterSpec")
		v1080.filterSpecMin = p_u_1076:getValue(p1079 .. "#filterSpecMin", 0)
		v1080.filterSpecMax = p_u_1076:getValue(p1079 .. "#filterSpecMax", 1)
		if v1080.xmlFilename ~= nil or (v1080.filterCategories ~= nil or v1080.filterSpec) then
			local v1084 = v_u_1078
			table.insert(v1084, v1080)
		end
	end)
	return v_u_1078
end
function Vehicle.getSpecValueCombinations(p1085, _)
	return p1085.specs.combinations
end
function Vehicle.getSpecValueSlots(p1086, p1087, _, _, _, _)
	local v1088 = g_currentMission:getNumOfItems(p1086)
	local v1089 = ""
	if p1087 == nil then
		local v1090 = g_currentMission.slotSystem:getStoreItemSlotUsage(p1086, v1088 == 0)
		if p1086.bundleInfo ~= nil then
			v1090 = 0
			for v1091 = 1, #p1086.bundleInfo.bundleItems do
				local v1092 = p1086.bundleInfo.bundleItems[v1091]
				local v1093 = g_currentMission:getNumOfItems(v1092.item)
				v1090 = v1090 + g_currentMission.slotSystem:getStoreItemSlotUsage(v1092.item, v1093 == 0)
			end
		end
		if v1090 ~= 0 then
			v1089 = "-" .. v1090
		end
	else
		local v1094 = g_currentMission.slotSystem:getStoreItemSlotUsage(p1086, v1088 == 1)
		if v1094 ~= 0 then
			v1089 = "+" .. v1094
		end
	end
	if v1089 == "" then
		return nil
	else
		return v1089
	end
end

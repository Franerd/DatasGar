VehicleSystem = {}
VehicleSystem.UNIQUE_ID_PREFIX = "vehicle"
local v_u_1 = Class(VehicleSystem)
function VehicleSystem.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.mission = p2
	v5.vehicles = {}
	v5.pendingVehicleLoadingData = {}
	v5.vehicleByUniqueId = {}
	v5.wetVehicles = {}
	v5.enterables = {}
	v5.lastEnteredVehicleIndex = 1
	v5.inputAttacherJoints = {}
	v5.interactiveVehicles = {}
	v5.vehiclesToDelete = {}
	v5.isReloadRunning = false
	if g_addCheatCommands then
		addConsoleCommand("gsVehicleShowDistance", "Shows the distance between vehicle and cam", "consoleCommandShowVehicleDistance", v5)
	end
	if v5.mission:getIsServer() then
		addConsoleCommand("gsVehicleReload", "Reloads currently entered vehicle or vehicles within a range when second radius parameter is given", "consoleCommandReloadVehicle", v5, "[resetVehicle]; [radiusAroundPlayer]")
		if g_addCheatCommands then
			addConsoleCommand("gsPalletAdd", "Adds a pallet", "consoleCommandAddPallet", v5, "fillTypeName; [fillAmount]; [worldX]; [worldZ]")
			addConsoleCommand("gsVehicleFuelSet", "Sets the vehicle fuel level", "consoleCommandSetFuel", v5)
			addConsoleCommand("gsVehicleTemperatureSet", "Sets the vehicle motor temperature", "consoleCommandSetMotorTemperature", v5)
			addConsoleCommand("gsFillUnitAdd", "Changes a fillUnit with given filllevel and filltype", "consoleCommandFillUnitAdd", v5, "fillUnitIndex; fillTypeName; [amount]")
			addConsoleCommand("gsVehicleOperatingTimeSet", "Sets the vehicle operating time", "consoleCommandSetOperatingTime", v5)
			addConsoleCommand("gsVehicleAddDirt", "Adds a given amount to current dirt amount", "consoleCommandAddDirtAmount", v5)
			addConsoleCommand("gsVehicleAddWear", "Adds a given amount to current wear amount", "consoleCommandAddWearAmount", v5)
			addConsoleCommand("gsVehicleAddWetness", "Adds a given amount to current wetness amount", "consoleCommandAddWetnessAmount", v5)
			addConsoleCommand("gsVehicleAddDamage", "Adds a given amount to current damage amount", "consoleCommandAddDamageAmount", v5)
			addConsoleCommand("gsVehicleLoadAll", "Load all vehicles", "consoleCommandLoadAllVehicles", v5, "[loadConfigs]; [modsOnly]; [palletsOnly]; [verbose]", true)
		end
		if g_addTestCommands then
			addConsoleCommand("gsVehicleRemoveAll", "Removes all vehicles from current mission", "consoleCommandVehicleRemoveAll", v5, nil, true)
			addConsoleCommand("gsExportVehicleSets", "Exports vehicle sets", "consoleCommandExportVehicleSets", v5)
		end
	end
	g_messageCenter:subscribe(BuyVehicleEvent, v5.onVehicleBuyEvent, v5)
	return v5
end
function VehicleSystem.delete(p6)
	for v7 = #p6.pendingVehicleLoadingData, 1, -1 do
		p6.pendingVehicleLoadingData[v7]:cancelLoading()
	end
	for v8, v9 in pairs(p6.vehiclesToDelete) do
		v9:delete(true)
		p6.vehiclesToDelete[v8] = nil
	end
	for v10 = #p6.vehicles, 1, -1 do
		p6.vehicles[v10]:delete(true)
	end
	if p6.savegameXMLFile ~= nil then
		p6.savegameXMLFile:delete()
		p6.savegameXMLFile = nil
	end
	p6.mission = nil
	p6.vehicles = {}
	p6.vehicleByUniqueId = {}
	p6.wetVehicles = {}
	p6.enterables = {}
	p6.interactiveVehicles = {}
	g_messageCenter:unsubscribeAll(p6)
	removeConsoleCommand("gsVehicleShowDistance")
	removeConsoleCommand("gsVehicleReload")
	removeConsoleCommand("gsPalletAdd")
	removeConsoleCommand("gsVehicleFuelSet")
	removeConsoleCommand("gsVehicleTemperatureSet")
	removeConsoleCommand("gsFillUnitAdd")
	removeConsoleCommand("gsVehicleOperatingTimeSet")
	removeConsoleCommand("gsVehicleAddDirt")
	removeConsoleCommand("gsVehicleAddWear")
	removeConsoleCommand("gsVehicleAddWetness")
	removeConsoleCommand("gsVehicleAddDamage")
	removeConsoleCommand("gsVehicleLoadAll")
	removeConsoleCommand("gsVehicleRemoveAll")
	removeConsoleCommand("gsExportVehicleSets")
end
function VehicleSystem.deleteAll(p11)
	local v12 = #p11.vehicles
	for v13 = #p11.vehicles, 1, -1 do
		p11.vehicles[v13]:delete()
	end
	return v12
end
function VehicleSystem.deleteAllPallets(p14)
	local v15 = 0
	for v16 = #p14.vehicles, 1, -1 do
		local v17 = p14.vehicles[v16]
		if v17.isPallet then
			v17:delete()
			v15 = v15 + 1
		end
	end
	return v15
end
function VehicleSystem.update(p18, p19)
	if p18.debugVehiclesToBeLoaded ~= nil then
		p18:consoleCommandLoadAllVehiclesNext()
	end
	if g_server ~= nil then
		local v20 = g_currentMission.environment.weather
		local v21 = g_currentMission.indoorMask
		if v20:getRainFallScale() > 0.1 then
			local v22 = v20:getTimeSinceLastRain()
			local v23 = v20:getCurrentTemperature()
			if v22 < 30 and v23 > 0 then
				for _, v24 in pairs(p18.vehicles) do
					if v24.updateWetness ~= nil then
						local v25, _, v26 = getWorldTranslation(v24.rootNode)
						if v21:getIsIndoorAtWorldPosition(v25, v26) then
							v24:updateWetness(false, p19)
							if not v24:getIsWet() then
								p18.wetVehicles[v24] = nil
							end
						else
							v24:updateWetness(true, p19)
							if v24:getIsWet() then
								p18.wetVehicles[v24] = v24
							end
						end
					end
				end
				return
			end
		elseif next(p18.wetVehicles) ~= nil then
			for v27, _ in pairs(p18.wetVehicles) do
				v27:updateWetness(false, p19)
				if not v27:getIsWet() then
					p18.wetVehicles[v27] = nil
				end
			end
		end
	end
end
function VehicleSystem.draw(p28)
	for _, v29 in pairs(p28.enterables) do
		v29:drawUIInfo()
	end
end
function VehicleSystem.deleteMarkedVehicles(p30)
	for v31, v32 in pairs(p30.vehiclesToDelete) do
		v32:delete(true)
		p30.vehiclesToDelete[v31] = nil
	end
end
function VehicleSystem.markVehicleForDeletion(p33, p34)
	p33.vehiclesToDelete[p34] = p34
end
function VehicleSystem.addVehicle(p35, p36)
	if p36 == nil or p36:isa(Vehicle) == nil then
		Logging.error("Given object is not a vehicle")
		return false
	elseif p36:getUniqueId() == nil or p35.vehicleByUniqueId[p36:getUniqueId()] == nil then
		if p36:getUniqueId() == nil then
			p36:setUniqueId(Utils.getUniqueId(p36, p35.vehicleByUniqueId, VehicleSystem.UNIQUE_ID_PREFIX))
		end
		table.addElement(p35.vehicles, p36)
		p35.vehicleByUniqueId[p36:getUniqueId()] = p36
		if p36.getIsWet ~= nil and p36:getIsWet() then
			p35.wetVehicles[p36] = p36
		end
		return true
	else
		local v37 = Logging.warning
		local v38 = p36:getUniqueId()
		local v39 = p35.vehicleByUniqueId[p36:getUniqueId()]
		v37("Tried to add existing vehicle with unique id of %s! Existing: %s, new: %s", v38, tostring(v39), (tostring(p36)))
		return false
	end
end
function VehicleSystem.removeVehicle(p40, p41)
	table.removeElement(p40.vehicles, p41)
	local v42 = p41:getUniqueId()
	if v42 ~= nil and p40.vehicleByUniqueId[v42] == p41 then
		p40.vehicleByUniqueId[v42] = nil
	end
	p40.wetVehicles[p41] = nil
end
function VehicleSystem.getVehicleByUniqueId(p43, p44)
	return p43.vehicleByUniqueId[p44]
end
function VehicleSystem.addPendingVehicleLoad(p45, p46)
	table.addElement(p45.pendingVehicleLoadingData, p46)
end
function VehicleSystem.removePendingVehicleLoad(p47, p48)
	table.removeElement(p47.pendingVehicleLoadingData, p48)
end
function VehicleSystem.canStartMission(p49)
	for v50 = 1, #p49.vehicles do
		if not p49.vehicles[v50]:getIsSynchronized() then
			return false
		end
	end
	return #p49.pendingVehicleLoadingData <= 0
end
function VehicleSystem.addEnterableVehicle(p51, p52)
	table.addElement(p51.enterables, p52)
end
function VehicleSystem.removeEnterableVehicle(p53, p54)
	table.removeElement(p53.enterables, p54)
end
function VehicleSystem.setEnteredVehicle(p55, p56)
	for v57 = 1, #p55.enterables do
		if p55.enterables[v57] == p56 then
			p55.lastEnteredVehicleIndex = v57
			return
		end
	end
end
function VehicleSystem.getNextEnterableVehicle(p58, p59, p60)
	local v61 = #p58.enterables
	if v61 == 0 then
		return nil
	end
	local v62 = 1
	if g_localPlayer:getIsInVehicle() and p59 ~= nil then
		for v63, _ in ipairs(p58.enterables) do
			if p59 == p58.enterables[v63] then
				v62 = v63 + p60
				break
			end
		end
	elseif p60 > 0 then
		v62 = p58.lastEnteredVehicleIndex
	else
		v62 = v61
	end
	local v64 = false
	for _ = 1, v61 do
		local v65 = p58.enterables[v62]
		if v65 ~= nil and (v65:getIsTabbable() and v65:getIsEnterable()) then
			v64 = true
			break
		end
		v62 = v62 + p60
		if v61 < v62 then
			v62 = 1
		elseif v62 < 1 then
			v62 = v61
		end
	end
	if v64 then
		return p58.enterables[v62]
	else
		return nil
	end
end
function VehicleSystem.registerInputAttacherJoint(p66, p67, p68, p69)
	local v70 = {
		["vehicle"] = p67,
		["jointIndex"] = p68,
		["inputAttacherJoint"] = p69,
		["node"] = p69.node,
		["jointType"] = p69.jointType,
		["translation"] = { getWorldTranslation(p69.node) }
	}
	table.addElement(p66.inputAttacherJoints, v70)
	return v70
end
function VehicleSystem.updateInputAttacherJoint(_, p71)
	local v72, v73, v74 = getWorldTranslation(p71.node)
	local v75 = p71.translation
	local v76 = p71.translation
	local v77 = p71.translation
	v75[1] = v72
	v76[2] = v73
	v77[3] = v74
end
function VehicleSystem.removeInputAttacherJoint(p78, p79)
	table.removeElement(p78.inputAttacherJoints, p79)
end
function VehicleSystem.addInteractiveVehicle(p80, p81)
	p80.interactiveVehicles[p81] = p81
end
function VehicleSystem.removeInteractiveVehicle(p82, p83)
	p82.interactiveVehicles[p83] = nil
end
function VehicleSystem.save(p84, p85, p86)
	local v87 = XMLFile.create("vehiclesXML", p85, "vehicles", Vehicle.xmlSchemaSavegame)
	if v87 ~= nil then
		p84:saveToXML(p84.vehicles, v87, p86)
		v87:delete()
	end
end
function VehicleSystem.saveToXML(p88, p89, p90, p91)
	if p90 ~= nil then
		local v92 = 0
		for v93, v94 in ipairs(p89) do
			if v94:getNeedsSaving() then
				p88:saveVehicleToXML(v94, p90, v92, v93, p91)
				v92 = v92 + 1
			end
		end
		p90:save(false, true)
	end
end
function VehicleSystem.saveVehicleToXML(_, p95, p96, p97, _, p98)
	local v99 = string.format("vehicles.vehicle(%d)", p97)
	local v100 = p95.customEnvironment
	if v100 ~= nil then
		if p98 ~= nil then
			p98[v100] = v100
		end
		p96:setValue(v99 .. "#modName", v100)
	end
	p96:setValue(v99 .. "#filename", HTMLUtil.encodeToHTML(NetworkUtil.convertToNetworkFilename(p95.configFileName)))
	p95:saveToXMLFile(p96, v99, p98)
end
function VehicleSystem.load(p101, p102, p103, p104, p105, _)
	p101.savegameXMLFile = XMLFile.load("vehiclesXML", p102, Vehicle.xmlSchemaSavegame)
	p101:loadFromXMLFile(p101.savegameXMLFile, p103, p104, p105)
end
function VehicleSystem.loadFromXMLFile(p_u_106, p_u_107, p108, p109, p110, p_u_111, p_u_112)
	local v_u_113 = p_u_107:getValue("vehicles#loadAnyFarmInSingleplayer", false)
	p_u_106.loadedVehicles = {}
	p_u_106.vehiclesToLoad = 0
	p_u_106.vehicleLoadingState = nil
	p_u_106.asyncCallbackFunction = p108
	p_u_106.asyncCallbackObject = p109
	p_u_106.asyncCallbackArguments = p110
	p_u_107:iterate("vehicles.vehicle", function(_, p_u_114)
		-- upvalues: (copy) p_u_106, (copy) p_u_107, (copy) v_u_113, (copy) p_u_111, (copy) p_u_112
		g_asyncTaskManager:addTask(function()
			-- upvalues: (ref) p_u_106, (ref) p_u_107, (copy) p_u_114, (ref) v_u_113, (ref) p_u_111, (ref) p_u_112
			p_u_106:loadVehicleFromXML(p_u_107, p_u_114, v_u_113, p_u_111, p_u_112)
		end)
	end)
	if p_u_106.asyncCallbackFunction ~= nil then
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_106
			if p_u_106.vehiclesToLoad <= 0 then
				p_u_106.asyncCallbackFunction(p_u_106.asyncCallbackObject, p_u_106.loadedVehicles, VehicleLoadingState.OK, p_u_106.asyncCallbackArguments)
				p_u_106.asyncCallbackFunction = nil
				p_u_106.asyncCallbackObject = nil
				p_u_106.asyncCallbackArguments = nil
			end
		end)
	end
end
function VehicleSystem.loadVehicleFromXML(p115, p116, p117, p118, p119, p120)
	local v121 = g_currentMission.missionInfo
	local v122 = g_currentMission.missionDynamicInfo
	local v123 = p116:getValue(p117 .. "#filename")
	local v124 = p116:getValue(p117 .. "#defaultFarmProperty", false)
	local v125 = p116:getValue(p117 .. "#farmId")
	local v126 = v124 and v121.isCompetitiveMultiplayer
	if v126 then
		v126 = g_farmManager:getFarmById(v125) ~= nil
	end
	local v127 = v124 and (v121.loadDefaultFarm and not v122.isMultiplayer)
	if v127 then
		v127 = v125 == FarmManager.SINGLEPLAYER_FARM_ID and true or p118
	end
	if v121.isValid or (not v124 or (v127 or v126)) then
		local v128 = NetworkUtil.convertFromNetworkFilename(v123)
		local v129 = {
			["xmlFile"] = p116,
			["key"] = p117,
			["ignoreFarmId"] = false,
			["resetVehicles"] = p119,
			["keepPosition"] = p120
		}
		if v127 and (p118 and v125 ~= FarmManager.SINGLEPLAYER_FARM_ID) then
			v125 = FarmManager.SINGLEPLAYER_FARM_ID
			v129.ignoreFarmId = true
		end
		local v130 = g_storeManager:getItemByXMLFilename(v128)
		if v130 ~= nil then
			if g_currentMission.slotSystem:hasEnoughSlots(v130) then
				p115.vehiclesToLoad = p115.vehiclesToLoad + 1
				local v131 = VehicleLoadingData.new()
				v131:setStoreItem(v130)
				v131:setSavegameData(v129)
				v131:setAddToPhysics(false)
				v131:load(p115.loadVehicleFinished, p115)
				return true
			end
			g_currentMission:addMoney(v130.price, v125, MoneyType.SHOP_VEHICLE_SELL, true)
			Logging.warning("Too many slots in use. Selling vehicle \'%s\' for \'%d\'", v128, v130.price)
		end
	else
		Logging.xmlInfo(p116, "Vehicle \'%s\' is not allowed to be loaded", v123)
	end
	return false
end
function VehicleSystem.loadVehicleFinished(p132, p133, p134)
	if p134 == VehicleLoadingState.OK then
		for _, v135 in ipairs(p133) do
			local v136 = p132.loadedVehicles
			table.insert(v136, v135)
		end
	else
		p132.vehicleLoadingState = p132.vehicleLoadingState or p134
	end
	p132.vehiclesToLoad = p132.vehiclesToLoad - 1
	if p132.vehiclesToLoad <= 0 then
		for _, v137 in ipairs(p132.loadedVehicles) do
			v137:addToPhysics()
		end
		if p132.asyncCallbackFunction ~= nil then
			p132.asyncCallbackFunction(p132.asyncCallbackObject, p132.loadedVehicles, p132.vehicleLoadingState or VehicleLoadingState.OK, p132.asyncCallbackArguments)
			p132.asyncCallbackFunction = nil
			p132.asyncCallbackObject = nil
			p132.asyncCallbackArguments = nil
			p132.loadedVehicles = nil
			p132.vehicleLoadingState = nil
		end
	end
end
function VehicleSystem.onVehicleBuyEvent(p138, _, _, _)
	local v139 = g_currentMission:getFarmId()
	local v140 = 0
	local v141 = 0
	for _, v142 in ipairs(p138.vehicles) do
		if v142:getOwnerFarmId() == v139 then
			if v142.spec_drivable == nil then
				if v142.spec_attachable ~= nil and v142.spec_bigBag == nil then
					v140 = v140 + 1
				end
			else
				v141 = v141 + 1
				v140 = v140 + 1
			end
		end
	end
	g_achievementManager:tryUnlock("NumDrivables", v141)
	g_achievementManager:tryUnlock("NumVehiclesSmall", v140)
	g_achievementManager:tryUnlock("NumVehiclesLarge", v140)
end
function VehicleSystem.consoleCommandShowVehicleDistance(_, p143)
	g_showVehicleDistance = Utils.getNoNil(p143, not g_showVehicleDistance)
end
function VehicleSystem.consoleCommandReloadVehicle(p_u_144, p145, p146)
	if g_gui.currentGuiName == "ShopMenu" or g_gui.currentGuiName == "ShopConfigScreen" then
		return "Error: Reload not supported while in shop!"
	end
	if p_u_144.isReloadRunning then
		return "Error: Reloading of vehicles already in progress!"
	end
	if not p_u_144.mission:getIsServer() or p_u_144.mission.missionDynamicInfo.isMultiplayer then
		return "Error: Reloading only available in SP"
	end
	local v147 = Utils.stringToBoolean(p145)
	local v148 = tonumber(p146) or 0
	local v149, v150, v151 = g_localPlayer:getPosition()
	g_soundManager:reloadSoundTemplates()
	g_vehicleMaterialManager:loadMaterialTemplates(VehicleMaterialManager.DEFAULT_TEMPLATES_FILENAME)
	g_vehicleMaterialManager:loadMaterialTemplates(VehicleMaterialManager.DEFAULT_BRAND_TEMPLATES_FILENAME)
	local v_u_152 = {}
	local v_u_153 = {}
	local v154 = {}
	local function v_u_159(p155, p156)
		-- upvalues: (copy) v_u_153, (copy) v_u_159
		if p155.isVehicleSaved then
			p155.isReconfigurating = true
			table.insert(p156, p155)
			v_u_153[p155] = true
			if p155 ~= nil and p155.getAttachedImplements ~= nil then
				local v157 = p155:getAttachedImplements()
				for _, v158 in pairs(v157) do
					v_u_159(v158.object, p156)
				end
				return
			end
		else
			p155:delete()
		end
	end
	if g_localPlayer:getCurrentVehicle() ~= nil then
		v_u_159(g_localPlayer:getCurrentVehicle(), v_u_152)
	end
	if v148 ~= 0 then
		for _, v160 in pairs(p_u_144.vehicles) do
			if v160 ~= g_localPlayer:getCurrentVehicle() then
				local v161, v162, v163 = getWorldTranslation(v160.rootNode)
				if MathUtil.vector3Length(v161 - v149, v162 - v150, v163 - v151) < v148 and v_u_153[v160.rootVehicle] == nil then
					v_u_159(v160.rootVehicle, v_u_152)
				end
			end
		end
	end
	if #v_u_152 == 0 then
		return "Warning: No vehicle reloaded. Enter a vehicle first or use the command with the radius parameter given, e.g. \'gsVehicleReload false 25\'\nUsage: gsVehicleReload [resetVehicle] [radius]"
	end
	local v_u_164 = XMLFile.create("reloadVehiclesXMLFile", "", "vehicles", Vehicle.xmlSchemaSavegame)
	if v_u_164 == nil then
		return "Error: Unable to create XML for saving vehicles"
	end
	simulatePhysics(false)
	p_u_144.isReloadRunning = true
	for _, v165 in ipairs(v_u_152) do
		p_u_144.vehicleByUniqueId[v165:getUniqueId()] = nil
	end
	p_u_144:saveToXML(v_u_152, v_u_164, v154)
	for _, v166 in ipairs(v_u_152) do
		v166:removeFromPhysics()
	end
	local v_u_167
	if g_localPlayer:getCurrentVehicle() == nil then
		v_u_167 = nil
	else
		v_u_167 = g_localPlayer:getCurrentVehicle():getUniqueId()
	end
	g_i3DManager:clearEntireSharedI3DFileCache(false)
	p_u_144:loadFromXMLFile(v_u_164, function(_, p168, p169, _)
		-- upvalues: (copy) v_u_152, (ref) v_u_167, (copy) p_u_144, (copy) v_u_164
		local v170 = true
		if p169 == VehicleLoadingState.OK then
			if #p168 == #v_u_152 then
				for _, v171 in pairs(v_u_152) do
					v171:delete()
				end
				if v_u_167 ~= nil then
					for _, v172 in pairs(p168) do
						if v172:getUniqueId() == v_u_167 then
							g_localPlayer:requestToEnterVehicle(v172)
						end
					end
				end
			else
				Logging.error("Not all vehicles could be reloaded")
				v170 = false
			end
		else
			Logging.error("Failed to load vehicles")
			v170 = false
		end
		if not v170 then
			for _, v173 in pairs(p168) do
				v173:delete()
			end
			for _, v174 in ipairs(v_u_152) do
				v174:addToPhysics()
				p_u_144.vehicleByUniqueId[v174:getUniqueId()] = v174
			end
		end
		v_u_164:delete()
		p_u_144.isReloadRunning = false
		simulatePhysics(true)
		if v170 then
			Logging.info("%d vehicle(s) reloaded", #v_u_152)
		end
	end, nil, nil, v147, true)
end
function VehicleSystem.consoleCommandAddPallet(p175, p176, p_u_177, p178, p179)
	local v180 = {}
	for _, v181 in pairs(g_fillTypeManager:getFillTypes()) do
		if v181.palletFilename ~= nil then
			v180[v181.name] = v181.palletFilename
		end
	end
	if p176 == nil then
		return "Error: no fillType given"
	else
		local v182 = g_localPlayer
		if p176:lower() == "all" then
			local v183, _, v184 = v182:getPosition()
			local v185, v186 = v182:getCurrentFacingDirection()
			for _, v187 in pairs(g_fillTypeManager:getFillTypes()) do
				if v187.palletFilename ~= nil then
					v183 = v183 + v185 * 3
					v184 = v184 + v186 * 3
					p175:consoleCommandAddPallet(v187.name, p_u_177, v183, v184)
				end
			end
		else
			local v_u_188 = string.upper(p176)
			local v_u_189 = g_fillTypeManager:getFillTypeIndexByName(v_u_188)
			if v_u_189 == nil then
				return string.format("Error: Invalid pallet fillType \'%s\'. Valid types are %s", v_u_188, table.concatKeys(v180, ", "))
			end
			local v190 = v180[v_u_188]
			if v190 == nil then
				return string.format("Error: no pallet for given fillType \'%s\'", v_u_188)
			end
			local v191, v192, v193 = v182:getPosition()
			local v194, v195 = v182:getCurrentFacingDirection()
			local v196 = v191 + v194 * 4
			local v197 = v193 + v195 * 4
			if p178 ~= nil then
				v196 = tonumber(p178)
			end
			if p179 ~= nil then
				v197 = tonumber(p179)
			end
			local v198 = Platform.gameplay.hasDynamicPallets and 0.2 or 0
			local v199 = CollisionFlag.STATIC_OBJECT + CollisionFlag.TERRAIN + CollisionFlag.TERRAIN_DELTA + CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.VEHICLE
			local v200, _, v201, _, _ = RaycastUtil.raycastClosest(v196, v192 + 25, v197, 0, -1, 0, 40, v199)
			if v200 == nil then
				v201 = getTerrainHeightAtWorldPos(g_terrainNode, v196, v192, v197)
			end
			local v202 = p175.mission:getFarmId()
			local v203 = (v202 == FarmManager.SPECTATOR_FARM_ID or not v202) and 1 or v202
			local v204 = VehicleLoadingData.new()
			v204:setFilename(v190)
			v204:setPosition(v196, v201 + v198, v197)
			v204:setPropertyState(VehiclePropertyState.OWNED)
			v204:setOwnerFarmId(v203)
			v204:load(function(_, p205, p206, _)
				-- upvalues: (copy) p_u_177, (copy) v_u_189, (ref) v_u_188
				if p206 ~= VehicleLoadingState.OK then
					printError("Error: Failed to load pallet")
					return
				end
				local v207 = p205[1]
				local v208 = v207:getFillUnits()
				local v209 = p_u_177
				local v210 = tonumber(v209) or (1 / 0)
				local v211 = 0
				for _, v212 in ipairs(v208) do
					if v207:getFillUnitSupportsFillType(v212.fillUnitIndex, v_u_189) then
						v211 = v211 + v207:addFillUnitFillLevel(1, v212.fillUnitIndex, v210, v_u_189, ToolType.UNDEFINED, nil)
						v210 = v210 - v211
						if v210 <= 0 then
							break
						end
					end
				end
				print(string.format("Loaded pallet with %dl of %s", v211, v_u_188))
			end)
		end
	end
end
function VehicleSystem.consoleCommandSetFuel(p213, p214)
	if not p213.mission:getIsServer() then
		return "Not available on clients"
	end
	if p214 == nil then
		return "No fuellevel given! Usage: gsVehicleFuelSet <fuelLevel>"
	end
	local v215 = Utils.getNoNil(tonumber(p214), 10000000000)
	local v216 = g_localPlayer:getCurrentVehicle()
	if v216 == nil then
		return "Enter a vehicle first!"
	end
	if v216.getConsumerFillUnitIndex == nil then
		return "Vehicle has no consumer"
	end
	local v217 = v216:getConsumerFillUnitIndex(FillType.DIESEL) or (v216:getConsumerFillUnitIndex(FillType.ELECTRICCHARGE) or v216:getConsumerFillUnitIndex(FillType.METHANE))
	if v217 == nil then
		return "No Fuel filltype supported!"
	end
	local v218 = v215 - v216:getFillUnitFillLevel(v217)
	v216:addFillUnitFillLevel(p213.mission:getFarmId(), v217, v218, v216:getFillUnitFirstSupportedFillType(v217), ToolType.UNDEFINED, nil)
	return "Added fuel"
end
function VehicleSystem.consoleCommandSetMotorTemperature(p219, p220)
	if not p219.mission:getIsServer() then
		return "Not available on clients"
	end
	if p220 == nil then
		return "No temperature given! Usage: gsVehicleTemperatureSet <temperature>"
	end
	local v221 = Utils.getNoNil(tonumber(p220), 0)
	local v222 = g_localPlayer:getCurrentVehicle()
	if v222 == nil then
		return "Enter a vehicle first!"
	end
	local v223 = v222.spec_motorized
	if v223 == nil then
		return "Vehicle has no motor"
	end
	local v224 = v223.motorTemperature
	local v225 = v223.motorTemperature.valueMin
	local v226 = v223.motorTemperature.valueMax
	v224.value = math.clamp(v221, v225, v226)
	return "Set motor temperature to " .. v223.motorTemperature.value
end
function VehicleSystem.consoleCommandFillUnitAdd(p227, p228, p229, p230)
	local v231 = p227.mission
	local v232 = g_localPlayer
	local v233 = v232:getCurrentVehicle()
	local v234 = nil
	if v233 ~= nil and v233.getSelectedObject ~= nil then
		local v235 = v233:getSelectedObject()
		if v235 ~= nil and v235.vehicle.addFillUnitFillLevel ~= nil then
			v234 = v235.vehicle
		end
	end
	if v234 ~= nil or (v233 == nil or v233.addFillUnitFillLevel == nil) then
		v233 = v234
	end
	local v_u_236
	if v233 == nil and (v232.isControlled and v232.lastFoundAnyObject ~= nil) then
		v_u_236 = g_currentMission.nodeToObject[v231.player.lastFoundAnyObject]
		if v_u_236 == nil or (not v_u_236:isa(Vehicle) or v_u_236.addFillUnitFillLevel == nil) then
			v_u_236 = v233
		end
	else
		v_u_236 = v233
	end
	local v237 = v231:getFarmId()
	if v_u_236 == nil or v_u_236.getFillUnitSupportedToolTypes == nil then
		return "Error: could not find a fillable vehicle!"
	end
	local function v244()
		-- upvalues: (ref) v_u_236
		local v238 = {}
		for v239, v240 in pairs(v_u_236:debugGetSupportedFillTypesPerFillUnit()) do
			local v241 = string.format
			local v242 = table.concat
			local v243 = g_fillTypeManager:getFillTypeNamesByIndices(v240)
			table.insert(v238, v241("FillUnit %d - FillTypes: %s", v239, v242(v243, " ")))
		end
		return "Available FillUnits and supported FillTypes:\n" .. table.concat(v238, "\n")
	end
	if p228 == nil or p229 == nil then
		return "Error: Missing parameters.\nUsage: \'gsFillUnitAdd <fillUnitIndex> <fillTypeName> [amount]\'"
	end
	if not v231:getIsServer() then
		return "Error: \'gsFillUnitAdd\' can only be called on server side!"
	end
	local v245 = tonumber(p228)
	local v246 = g_fillTypeManager:getFillTypeIndexByName(p229)
	local v247 = tonumber(p230)
	if v245 == nil then
		return "Error: Missing fillUnitIndex!\nUsage: \'gsFillUnitAdd <fillUnitIndex> <fillTypeName> [amount]\'"
	end
	if not v_u_236:getFillUnitExists(v245) then
		return string.format("Error: FillUnit \'%d\' in \'%s\' does not exist!\n%s", v245, v_u_236:getName(), (v244()))
	end
	if v246 == nil then
		return string.format("Error: Unknown fillType \'%s\'!\n%s", p229, (v244()))
	end
	local v248 = v_u_236:getFillUnitCapacity(v245)
	if v248 == 0 then
		return string.format("Error: Selected Vehicle \'%s\' cannot be filled. Capacity is 0!", v_u_236:getName())
	end
	if not v_u_236:getFillUnitSupportsFillType(v245, v246) then
		return string.format("Error: fillUnit \'%d\' in \'%s\' does not support fillType \'%s\'\n%s", v245, v_u_236:getName(), p229, (v244()))
	end
	local v249 = v247 or v248
	if v249 == 0 then
		v249 = -v248
	end
	v_u_236:addFillUnitFillLevel(v237, v245, v249, v246, ToolType.UNDEFINED)
	local v250 = v_u_236:getFillUnitFillLevel(v245)
	local v251 = v_u_236:getFillUnitFillType(v245)
	local v252 = Utils.getNoNil(g_fillTypeManager:getFillTypeNameByIndex(v251), "unknown")
	return string.format("new fillLevel: %.1f, fillType: %d (%s)", v250, v251, v252)
end
function VehicleSystem.consoleCommandSetOperatingTime(p253, p254)
	if not p253.mission:getIsServer() then
		return "Not available on clients"
	end
	if p254 == nil then
		return "No operatingTime given! Usage: gsVehicleOperatingTimeSet <operatingTime (h)>"
	end
	local v255 = (tonumber(p254) or 0) * 1000 * 60 * 60
	local v256 = g_localPlayer:getCurrentVehicle()
	if v256 == nil then
		return "Enter a vehicle first!"
	end
	if v256.setOperatingTime == nil then
		return "Vehicle has no operating time"
	end
	v256:setOperatingTime(v255)
	return string.format("Set operating time to %.1f", v255)
end
function VehicleSystem.consoleCommandAddDirtAmount(p257, p258)
	if not p257.mission:getIsServer() then
		return "Error: Not available on clients"
	end
	local v259 = tonumber(p258) or 0
	if g_localPlayer:getCurrentVehicle() == nil then
		return "Error: Enter a vehicle first!"
	end
	for _, v260 in pairs(p257.vehicles) do
		if v260:getIsActive() and v260.addDirtAmount ~= nil then
			v260:addDirtAmount(v259)
		end
	end
	return string.format("Added dirt to vehicles (Amount: %.2f)", v259)
end
function VehicleSystem.consoleCommandAddWearAmount(p261, p262)
	if not p261.mission:getIsServer() then
		return "Error: Not available on clients"
	end
	local v263 = tonumber(p262) or 0
	if g_localPlayer:getCurrentVehicle() == nil then
		return "Error: Enter a vehicle first!"
	end
	for _, v264 in pairs(p261.vehicles) do
		if v264:getIsActive() and v264.addWearAmount ~= nil then
			v264:addWearAmount(v263)
		end
	end
	return string.format("Added wear to vehicles (Amount: %.2f)", v263)
end
function VehicleSystem.consoleCommandAddWetnessAmount(p265, p266)
	if not p265.mission:getIsServer() then
		return "Error: Not available on clients"
	end
	local v267 = tonumber(p266) or 0
	if g_localPlayer:getCurrentVehicle() == nil then
		return "Error: Enter a vehicle first!"
	end
	for _, v268 in pairs(p265.vehicles) do
		if v268:getIsActive() and v268.addWetnessAmount ~= nil then
			v268:addWetnessAmount(v267)
		end
	end
	return string.format("Added wetness to vehicles (Amount: %.2f)", v267)
end
function VehicleSystem.consoleCommandAddDamageAmount(p269, p270)
	if not p269.mission:getIsServer() then
		return "Error: Not available on clients"
	end
	local v271 = tonumber(p270) or 0
	if g_localPlayer:getCurrentVehicle() == nil then
		return "Error: Enter a vehicle first!"
	end
	for _, v272 in pairs(p269.vehicles) do
		if v272:getIsActive() and v272.addDamageAmount ~= nil then
			v272:addDamageAmount(v271)
		end
	end
	return string.format("Added damage to vehicles (Amount: %.2f)", v271)
end
function VehicleSystem.consoleCommandLoadAllVehicles(p273, p274, p275, p276, p277)
	if not p273.mission:getIsServer() and p273.mission.missionDynamicInfo.isMultiplayer then
		return "Error: Command not allowed in multiplayer"
	end
	if p273.debugVehiclesToBeLoaded ~= nil then
		return "Error: Loading task is currently running!"
	end
	local v278 = string.lower(p274 or "false") == "true"
	local v279 = string.lower(p275 or "false") == "true"
	local v280 = string.lower(p276 or "false") == "true"
	local v281 = string.lower(p277 or "false") == "true"
	p273.debugVehiclesToBeLoaded = {}
	p273.debugVehiclesLoaded = {}
	local v282 = 0
	p273.debugVehiclesToBeLoadedStartTime = g_time
	I3DManager.VERBOSE_LOADING = v281
	if v280 then
		for _, v283 in pairs(g_fillTypeManager:getFillTypes()) do
			if v283.palletFilename ~= nil then
				local v284 = g_storeManager:getItemByXMLFilename(v283.palletFilename)
				local v285 = p273.debugVehiclesToBeLoaded
				table.insert(v285, {
					["storeItem"] = v284,
					["configurations"] = {}
				})
			end
		end
	else
		for _, v286 in pairs(g_storeManager:getItems()) do
			if StoreItemUtil.getIsVehicle(v286) and (not v279 or v286.isMod) then
				local v287 = p273.debugVehiclesToBeLoaded
				table.insert(v287, {
					["storeItem"] = v286,
					["configurations"] = {}
				})
				v282 = v282 + 1
				if v278 then
					if v286.configurations ~= nil then
						for v288, v289 in pairs(v286.configurations) do
							if #v289 > 1 then
								local v290 = false
								for v291 = 1, #v286.configurationSets do
									if v286.configurationSets[v291].configurations[v288] ~= nil then
										v290 = true
										break
									end
								end
								if not v290 then
									for _, v292 in ipairs(v289) do
										if v292.isSelectable then
											local v293 = {
												[v288] = v292.index
											}
											local v294 = p273.debugVehiclesToBeLoaded
											table.insert(v294, {
												["storeItem"] = v286,
												["configurations"] = v293
											})
										end
									end
								end
							end
						end
					end
					for v295 = 1, #v286.configurationSets do
						local v296 = v286.configurationSets[v295]
						local v297 = {}
						for v298, v299 in pairs(v296.configurations) do
							v297[v298] = v299
						end
						local v300 = p273.debugVehiclesToBeLoaded
						table.insert(v300, {
							["storeItem"] = v286,
							["configurations"] = v297
						})
					end
				end
			end
		end
	end
	local v301 = v279 and "mod " or ""
	if v278 then
		return print(string.format("Loading %i %svehicles with all configs...", v282, v301))
	else
		return print(string.format("Loading %i %svehicles (add first param \'true\' to include configs, add second param \'true\' to only load mods, add third param \'true\' to only load pallets, add fourth param \'verbose\' to print i3d loading messages)...", v282, v301))
	end
end
function VehicleSystem.consoleCommandLoadAllVehiclesNext(p_u_302)
	if p_u_302.debugVehiclesLoaded ~= nil then
		for v303 = #p_u_302.debugVehiclesLoaded, 1, -1 do
			local v304 = p_u_302.debugVehiclesLoaded[v303]
			v304.deleteFrameCounter = v304.deleteFrameCounter - 1
			if v304.deleteFrameCounter <= 0 then
				v304:delete()
				table.remove(p_u_302.debugVehiclesLoaded, v303)
			end
		end
	end
	if p_u_302.debugVehiclesToBeLoaded == nil then
		return
	elseif p_u_302.debugVehiclesLoadingCount == nil or p_u_302.debugVehiclesLoadingCount <= 0 then
		if not p_u_302.debugVehiclesLoading then
			local v305 = table.remove(p_u_302.debugVehiclesToBeLoaded, 1)
			if v305 == nil then
				local v306 = g_time - p_u_302.debugVehiclesToBeLoadedStartTime
				print(string.format("Successfully loaded and removed all vehicles in %.1f seconds!", v306 / 1000))
				p_u_302.debugVehiclesToBeLoaded = nil
				p_u_302.debugVehiclesLoadingCount = nil
				for _, v307 in pairs(p_u_302.debugVehiclesLoaded) do
					v307:delete()
				end
				p_u_302.debugVehiclesLoaded = {}
				I3DManager.VERBOSE_LOADING = true
				return
			end
			log(#p_u_302.debugVehiclesToBeLoaded, v305.storeItem.xmlFilename)
			local v308 = VehicleLoadingData.new()
			local v309 = g_localPlayer
			local v310, v311, v312 = v309:getPosition()
			local v313, v314 = v309:getCurrentFacingDirection()
			v308:setPosition(v310 + v313 * 10, v311, v312 + v314 * 10)
			v308:setStoreItem(v305.storeItem)
			v308:setConfigurations(v305.configurations)
			v308:setIsRegistered(false)
			v308:setIsSaved(false)
			p_u_302.debugVehiclesLoading = true
			v308:load(function(_, p315, _, _)
				-- upvalues: (copy) p_u_302
				p_u_302.debugVehiclesLoading = false
				for _, v316 in pairs(p315) do
					v316:removeFromPhysics()
					local v317 = p_u_302.debugVehiclesLoaded
					table.insert(v317, v316)
					v316.deleteFrameCounter = 2
				end
			end, nil, nil)
		end
	end
end
function VehicleSystem.consoleCommandVehicleRemoveAll(p318)
	local v319 = 0
	for v320 = #p318.vehicles, 1, -1 do
		local v321 = p318.vehicles[v320]
		if v321.trainSystem == nil and not v321.isPallet then
			v321:delete()
			v319 = v319 + 1
		end
	end
	return string.format("Deleted %i vehicle(s)! Excluded train and pallets", v319)
end
function VehicleSystem.consoleCommandExportVehicleSets(p322)
	local v323 = {}
	for _, v324 in ipairs(p322.vehicles) do
		local v325 = v324:getRootVehicle()
		if v325 ~= nil then
			v323[v325] = v325
		end
	end
	setFileLogPrefixTimestamp(false)
	local function v338(p326, p327, p328, p329)
		setXMLString(p326, p327 .. ".xmlFilename", p328.configFileName)
		setXMLFloat(p326, p327 .. ".rotY", 0)
		setXMLFloat(p326, p327 .. ".captainFoldingState", 0)
		local v330, v331, v332 = localToLocal(p328.rootNode, p329.rootNode, 0, 0, 0)
		setXMLString(p326, p327 .. ".offset", string.format("%.2f %.2f %.2f", v330, v331, v332))
		local v333 = 0
		for v334, v335 in pairs(p328.configurations) do
			local v336 = ConfigurationUtil.getSaveIdByConfigId(p328.configFileName, v334, v335)
			if v336 ~= nil then
				local v337 = string.format("%s.configurations.configuration(%d)", p327, v333)
				setXMLString(p326, v337 .. "#name", v334)
				setXMLString(p326, v337 .. "#id", v336)
				v333 = v333 + 1
			end
		end
	end
	for _, v339 in pairs(v323) do
		local v340 = loadXMLFileFromMemory("vehicleSets", "<vehicleSets></vehicleSets>")
		local v341 = string.format("vehicleSets.vehicleSet(%d)", 0)
		local v342 = v339:getChildVehicles()
		local v343 = 0
		local v344 = {}
		for v345 = #v342, 1, -1 do
			local v346 = v342[v345]
			v338(v340, string.format("%s.vehicle(%d)", v341, v343), v346, v339)
			v343 = v343 + 1
			v344[v346] = v343
		end
		local v347 = 0
		for v348 = #v342, 1, -1 do
			local v349 = v342[v348]
			local v350
			if v349.getAttacherVehicle == nil then
				v350 = nil
			else
				v350 = v349:getAttacherVehicle()
			end
			if v350 ~= nil then
				local v351 = string.format("%s.attach(%d)", v341, v347)
				local v352 = v344[v350]
				local v353 = v344[v349]
				local v354 = v350:getImplementByObject(v349)
				local v355 = v349:getActiveInputAttacherJointDescIndex()
				setXMLInt(v340, v351 .. "#element0", v352)
				setXMLInt(v340, v351 .. "#element1", v353)
				setXMLInt(v340, v351 .. "#attacherJointIndex", v354.jointDescIndex)
				setXMLInt(v340, v351 .. "#inputAttacherJointIndex", v355)
				v347 = v347 + 1
			end
		end
		local v356 = saveXMLFileToMemory(v340)
		print(v356)
		delete(v340)
	end
	setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
end

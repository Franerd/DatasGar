VehicleAttachEvent = {}
local v_u_1 = Class(VehicleAttachEvent, Event)
InitStaticEventClass(VehicleAttachEvent, "VehicleAttachEvent")
function VehicleAttachEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleAttachEvent.new(p2, p3, p4, p5, p6)
	local v7 = VehicleAttachEvent.emptyNew()
	v7.jointIndex = p5
	v7.inputJointIndex = p4
	v7.vehicle = p2
	v7.implement = p3
	v7.startLowered = p6
	local v8
	if v7.jointIndex >= 0 then
		v8 = v7.jointIndex < 127
	else
		v8 = false
	end
	assert(v8)
	return v7
end
function VehicleAttachEvent.readStream(p9, p10, p11)
	p9.vehicle = NetworkUtil.readNodeObject(p10)
	p9.implement = NetworkUtil.readNodeObject(p10)
	p9.jointIndex = streamReadUIntN(p10, 7)
	p9.inputJointIndex = streamReadUIntN(p10, 7)
	p9.startLowered = streamReadBool(p10)
	p9:run(p11)
end
function VehicleAttachEvent.writeStream(p12, p13, _)
	NetworkUtil.writeNodeObject(p13, p12.vehicle)
	NetworkUtil.writeNodeObject(p13, p12.implement)
	streamWriteUIntN(p13, p12.jointIndex, 7)
	streamWriteUIntN(p13, p12.inputJointIndex, 7)
	streamWriteBool(p13, p12.startLowered)
end
function VehicleAttachEvent.run(p14, p15)
	if p14.vehicle ~= nil and p14.vehicle:getIsSynchronized() then
		if p14.implement == nil then
			Logging.error("Failed to attach unknown implement to vehicle \'%s\' between joints \'%d\' and \'%d\'", p14.vehicle.configFileName, p14.jointIndex, p14.inputJointIndex)
			return
		end
		p14.vehicle:attachImplement(p14.implement, p14.inputJointIndex, p14.jointIndex, true, nil, p14.startLowered)
	end
	if not p15:getIsServer() then
		g_server:broadcastEvent(p14, nil, p15, p14.object)
	end
end

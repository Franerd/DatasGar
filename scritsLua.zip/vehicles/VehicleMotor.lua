VehicleMotor = {}
local v_u_1 = Class(VehicleMotor)
VehicleMotor.DAMAGE_TORQUE_REDUCTION = 0.3
VehicleMotor.DEFAULT_DAMPING_RATE_FULL_THROTTLE = 0.00025
VehicleMotor.DEFAULT_DAMPING_RATE_ZERO_THROTTLE_CLUTCH_EN = 0.0015
VehicleMotor.DEFAULT_DAMPING_RATE_ZERO_THROTTLE_CLUTCH_DIS = 0.0015
VehicleMotor.GEAR_START_THRESHOLD = 1.5
VehicleMotor.REASON_CLUTCH_NOT_ENGAGED = 0
VehicleMotor.SHIFT_MODE_AUTOMATIC = 1
VehicleMotor.SHIFT_MODE_MANUAL = 2
VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH = 3
VehicleMotor.DIRECTION_CHANGE_MODE_AUTOMATIC = 1
VehicleMotor.DIRECTION_CHANGE_MODE_MANUAL = 2
VehicleMotor.TRANSMISSION_TYPE = {}
VehicleMotor.TRANSMISSION_TYPE.DEFAULT = 1
VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT = 2
local v_u_2 = 0.0009
local v_u_3 = 150
local v_u_4 = 0.1
local v_u_5 = 1
local v_u_6 = 0.01
local v_u_7 = 0.05
local v_u_8 = 0
local v_u_9 = 0.5
local v_u_10 = 0
local v_u_11 = 0.8
function VehicleMotor.new(p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26)
	-- upvalues: (copy) v_u_1
	local v27 = v_u_1
	local v28 = setmetatable({}, v27)
	v28.vehicle = p12
	v28.minRpm = p13
	v28.maxRpm = p14
	v28.minSpeed = p26
	v28.maxForwardSpeed = p15
	v28.maxBackwardSpeed = p16
	v28.maxClutchTorque = 5
	v28.torqueCurve = p17
	v28.brakeForce = p18
	v28.lastAcceleratorPedal = 0
	v28.idleGearChangeTimer = 0
	v28.doSecondBestGearSelection = 0
	v28.gear = 0
	v28.bestGearSelected = 0
	v28.minGearRatio = 0
	v28.maxGearRatio = 0
	v28.allowGearChangeTimer = 0
	v28.allowGearChangeDirection = 0
	v28.forwardGears = p19
	v28.backwardGears = p20
	v28.currentGears = v28.forwardGears
	v28.minForwardGearRatio = p21
	v28.maxForwardGearRatio = p22
	v28.minBackwardGearRatio = p23
	v28.maxBackwardGearRatio = p24
	v28.transmissionDirection = 1
	v28.maxClutchSpeedDifference = 0
	v28.defaultForwardGear = 1
	if v28.forwardGears ~= nil then
		for v29 = 1, #v28.forwardGears do
			local v30 = v28.maxClutchSpeedDifference
			local v31 = v28.minRpm / v28.forwardGears[v29].ratio * 3.141592653589793 / 30
			v28.maxClutchSpeedDifference = math.max(v30, v31)
			if v28.forwardGears[v29].default then
				v28.defaultForwardGear = v29
			end
		end
	end
	v28.defaultBackwardGear = 1
	if v28.backwardGears ~= nil then
		for v32 = 1, #v28.backwardGears do
			local v33 = v28.maxClutchSpeedDifference
			local v34 = v28.minRpm / v28.backwardGears[v32].ratio * 3.141592653589793 / 30
			v28.maxClutchSpeedDifference = math.max(v33, v34)
			if v28.backwardGears[v32].default then
				v28.defaultBackwardGear = v32
			end
		end
	end
	v28.gearType = VehicleMotor.TRANSMISSION_TYPE.DEFAULT
	v28.groupType = VehicleMotor.TRANSMISSION_TYPE.DEFAULT
	v28.manualTargetGear = nil
	v28.targetGear = 0
	v28.previousGear = 0
	v28.gearChangeTimer = -1
	v28.gearChangeTime = 250
	v28.gearChangeTimeOrig = v28.gearChangeTime
	v28.autoGearChangeTimer = -1
	v28.autoGearChangeTime = 1000
	v28.manualClutchValue = 0
	v28.stallTimer = 0
	v28.lastGearChangeTime = 0
	v28.gearChangeTimeAutoReductionTime = 500
	v28.gearChangeTimeAutoReductionTimer = 0
	v28.lastManualShifterActive = false
	v28.clutchSlippingTime = 1000
	v28.clutchSlippingTimer = 0
	v28.clutchSlippingGearRatio = 0
	v28.groupChangeTime = 500
	v28.groupChangeTimer = 0
	v28.gearGroupUpShiftTime = 3000
	v28.gearGroupUpShiftTimer = 0
	v28.currentDirection = 1
	v28.directionChangeTimer = 0
	v28.directionChangeTime = 500
	v28.directionChangeUseGear = false
	v28.directionChangeGearIndex = 1
	v28.directionLastGear = -1
	v28.directionChangeUseGroup = false
	v28.directionChangeGroupIndex = 1
	v28.directionLastGroup = -1
	v28.directionChangeUseInverse = true
	v28.gearChangedIsLocked = false
	v28.gearGroupChangedIsLocked = false
	v28.startGearValues = {
		["slope"] = 0,
		["mass"] = 0,
		["lastMass"] = 0,
		["maxForce"] = 0,
		["massDirectionDifferenceXZ"] = 0,
		["massDirectionDifferenceY"] = 0,
		["massDirectionFactor"] = 0,
		["availablePower"] = 0,
		["massFactor"] = 0
	}
	v28.startGearThreshold = VehicleMotor.GEAR_START_THRESHOLD
	v28.lastSmoothedClutchPedal = 0
	v28.lastRealMotorRpm = 0
	v28.lastMotorRpm = 0
	v28.lastModulationPercentage = 0
	v28.lastModulationTimer = 0
	v28.rawLoadPercentage = 0
	v28.rawLoadPercentageBuffer = 0
	v28.rawLoadPercentageBufferIndex = 0
	v28.smoothedLoadPercentage = 0
	v28.loadPercentageChangeCharge = 0
	v28.accelerationLimitLoadScale = 1
	v28.accelerationLimitLoadScaleTimer = 0
	v28.accelerationLimitLoadScaleDelay = 2000
	v28.constantRpmCharge = 0
	v28.constantAccelerationCharge = 0
	v28.lastTurboScale = 0
	v28.blowOffValveState = 0
	v28.overSpeedTimer = 0
	v28.rpmLimit = (1 / 0)
	v28.speedLimit = (1 / 0)
	v28.speedLimitAcc = (1 / 0)
	v28.accelerationLimit = 2
	v28.motorRotationAccelerationLimit = (p14 - p13) * 3.141592653589793 / 30 / 2
	v28.equalizedMotorRpm = 0
	v28.requiredMotorPower = 0
	if v28.maxForwardSpeed == nil then
		v28.maxForwardSpeed = v28:calculatePhysicalMaximumForwardSpeed()
	end
	if v28.maxBackwardSpeed == nil then
		v28.maxBackwardSpeed = v28:calculatePhysicalMaximumBackwardSpeed()
	end
	v28.maxForwardSpeedOrigin = v28.maxForwardSpeed
	v28.maxBackwardSpeedOrigin = v28.maxBackwardSpeed
	v28.minForwardGearRatioOrigin = v28.minForwardGearRatio
	v28.maxForwardGearRatioOrigin = v28.maxForwardGearRatio
	v28.minBackwardGearRatioOrigin = v28.minBackwardGearRatio
	v28.maxBackwardGearRatioOrigin = v28.maxBackwardGearRatio
	v28.peakMotorTorque = v28.torqueCurve:getMaximum()
	v28.peakMotorPower = 0
	v28.peakMotorPowerRotSpeed = 0
	local v35 = #v28.torqueCurve.keyframes
	if v35 >= 2 then
		for v36 = 2, v35 do
			local v37 = v28.torqueCurve.keyframes[v36 - 1]
			local v38 = v28.torqueCurve.keyframes[v36]
			local v39 = v28.torqueCurve:getFromKeyframes(v37, v37, v36 - 1, v36 - 1, 0)
			local v40 = v28.torqueCurve:getFromKeyframes(v38, v38, v36, v36, 0)
			local v41 = v39 - v40
			local v42
			if math.abs(v41) > 0.0001 then
				local v43 = (v38.time * v39 - v37.time * v40) / (2 * (v39 - v40))
				local v44 = v37.time
				local v45 = math.max(v43, v44)
				local v46 = v38.time
				v42 = math.min(v45, v46)
				v39 = v28.torqueCurve:getFromKeyframes(v37, v38, v36 - 1, v36, (v38.time - v42) / (v38.time - v37.time))
			else
				v42 = v37.time
			end
			local v47 = v39 * v42
			if v28.peakMotorPower < v47 then
				v28.peakMotorPower = v47
				v28.peakMotorPowerRotSpeed = v42
			end
		end
		v28.peakMotorPower = v28.peakMotorPower * 3.141592653589793 / 30
		v28.peakMotorPowerRotSpeed = v28.peakMotorPowerRotSpeed * 3.141592653589793 / 30
	else
		local v48 = v28.torqueCurve.keyframes[1]
		local v49 = v48.time * 3.141592653589793 / 30
		v28.peakMotorPower = v49 * v28.torqueCurve:getFromKeyframes(v48, v48, 1, 1, 0)
		v28.peakMotorPowerRotSpeed = v49
	end
	v28.ptoMotorRpmRatio = p25
	v28.rotInertia = v28.peakMotorTorque / 600
	v28.dampingRateFullThrottle = VehicleMotor.DEFAULT_DAMPING_RATE_FULL_THROTTLE
	v28.dampingRateZeroThrottleClutchEngaged = VehicleMotor.DEFAULT_DAMPING_RATE_ZERO_THROTTLE_CLUTCH_EN
	v28.dampingRateZeroThrottleClutchDisengaged = VehicleMotor.DEFAULT_DAMPING_RATE_ZERO_THROTTLE_CLUTCH_DIS
	v28.gearRatio = 0
	v28.motorRotSpeed = 0
	v28.motorRotSpeedClutchEngaged = 0
	v28.motorRotAcceleration = 0
	v28.motorRotAccelerationSmoothed = 0
	v28.motorAvailableTorque = 0
	v28.lastMotorAvailableTorque = 0
	v28.motorAppliedTorque = 0
	v28.lastMotorAppliedTorque = 0
	v28.motorExternalTorque = 0
	v28.lastMotorExternalTorque = 0
	v28.externalTorqueVirtualMultiplicator = 1
	v28.differentialRotSpeed = 0
	v28.differentialRotAcceleration = 0
	v28.differentialRotAccelerationSmoothed = 0
	v28.differentialRotAccelerationIndex = 1
	v28.differentialRotAccelerationSamples = {}
	local v50 = v28.differentialRotAccelerationSamples
	table.insert(v50, 0)
	local v51 = v28.differentialRotAccelerationSamples
	table.insert(v51, 0)
	local v52 = v28.differentialRotAccelerationSamples
	table.insert(v52, 0)
	local v53 = v28.differentialRotAccelerationSamples
	table.insert(v53, 0)
	local v54 = v28.differentialRotAccelerationSamples
	table.insert(v54, 0)
	local v55 = v28.differentialRotAccelerationSamples
	table.insert(v55, 0)
	local v56 = v28.differentialRotAccelerationSamples
	table.insert(v56, 0)
	local v57 = v28.differentialRotAccelerationSamples
	table.insert(v57, 0)
	local v58 = v28.differentialRotAccelerationSamples
	table.insert(v58, 0)
	local v59 = v28.differentialRotAccelerationSamples
	table.insert(v59, 0)
	v28.lastDifference = 0
	v28.directionChangeMode = g_gameSettings:getValue(GameSettings.SETTING.DIRECTION_CHANGE_MODE)
	v28.gearShiftMode = g_gameSettings:getValue(GameSettings.SETTING.GEAR_SHIFT_MODE)
	return v28
end
function VehicleMotor.postLoad(p60, _)
	if p60.gearGroups ~= nil then
		SpecializationUtil.raiseEvent(p60.vehicle, "onGearGroupChanged", p60.activeGearGroupIndex, 0)
	end
end
function VehicleMotor.delete(p61)
	g_messageCenter:unsubscribeAll(p61)
end
function VehicleMotor.setGearGroups(p62, p63, p64, p65)
	p62.gearGroups = p63
	p62.groupType = VehicleMotor.TRANSMISSION_TYPE[p64:upper()] or VehicleMotor.TRANSMISSION_TYPE.DEFAULT
	p62.groupChangeTime = p65
	if p63 ~= nil then
		p62.numGearGroups = #p63
		p62.defaultGearGroup = 1
		for v66 = 1, p62.numGearGroups do
			if p62.gearGroups[v66].ratio > 0 then
				p62.defaultGearGroup = v66
				break
			end
		end
		for v67 = 1, p62.numGearGroups do
			if p62.gearGroups[v67].isDefault then
				p62.defaultGearGroup = v67
				break
			end
		end
		p62.activeGearGroupIndex = p62.defaultGearGroup
	end
end
function VehicleMotor.setDirectionChange(p68, p69, p70, p71, p72, p73)
	p68.directionChangeUseGear = p69
	p68.directionChangeGearIndex = p70
	p68.directionChangeUseGroup = p71
	p68.directionChangeGroupIndex = p72
	p68.directionChangeTime = p73
	local v74 = not p69
	if v74 then
		v74 = not p71
	end
	p68.directionChangeUseInverse = v74
end
function VehicleMotor.setManualShift(p75, p76, p77)
	p75.manualShiftGears = p76
	p75.manualShiftGroups = p77
end
function VehicleMotor.setStartGearThreshold(p78, p79)
	p78.startGearThreshold = p79
end
function VehicleMotor.setLowBrakeForce(p80, p81, p82)
	p80.lowBrakeForceScale = p81
	p80.lowBrakeForceSpeedLimit = p82
end
function VehicleMotor.getMaxClutchTorque(p83)
	return p83.maxClutchTorque
end
function VehicleMotor.getRotInertia(p84)
	return p84.rotInertia
end
function VehicleMotor.setRotInertia(p85, p86)
	p85.rotInertia = p86
end
function VehicleMotor.getDampingRateFullThrottle(p87)
	return p87.dampingRateFullThrottle
end
function VehicleMotor.getDampingRateZeroThrottleClutchEngaged(p88)
	return p88.dampingRateZeroThrottleClutchEngaged
end
function VehicleMotor.getDampingRateZeroThrottleClutchDisengaged(p89)
	return p89.dampingRateZeroThrottleClutchDisengaged
end
function VehicleMotor.setDampingRateScale(p90, p91)
	p90.dampingRateFullThrottle = VehicleMotor.DEFAULT_DAMPING_RATE_FULL_THROTTLE * p91
	p90.dampingRateZeroThrottleClutchEngaged = VehicleMotor.DEFAULT_DAMPING_RATE_ZERO_THROTTLE_CLUTCH_EN * p91
	p90.dampingRateZeroThrottleClutchDisengaged = VehicleMotor.DEFAULT_DAMPING_RATE_ZERO_THROTTLE_CLUTCH_DIS * p91
end
function VehicleMotor.setGearChangeTime(p92, p93)
	p92.gearChangeTime = p93
	p92.gearChangeTimeOrig = p93
	local v94 = p92.gearChangeTimer
	p92.gearChangeTimer = math.min(v94, p93)
	p92.gearType = p93 == 0 and VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT or VehicleMotor.TRANSMISSION_TYPE.DEFAULT
end
function VehicleMotor.setAutoGearChangeTime(p95, p96)
	p95.autoGearChangeTime = p96
	local v97 = p95.autoGearChangeTimer
	p95.autoGearChangeTimer = math.min(v97, p96)
end
function VehicleMotor.getPeakTorque(p98)
	return p98.peakMotorTorque
end
function VehicleMotor.getBrakeForce(p99)
	return p99.brakeForce
end
function VehicleMotor.getMinRpm(p100)
	return p100.minRpm
end
function VehicleMotor.getMaxRpm(p101)
	return p101.maxRpm
end
function VehicleMotor.getRequiredMotorRpmRange(p102)
	local v103 = PowerConsumer.getMaxPtoRpm(p102.vehicle) * p102.ptoMotorRpmRatio
	local v104 = p102.maxRpm
	local v105 = math.min(v103, v104)
	if v105 == 0 then
		return p102.minRpm, p102.maxRpm
	else
		return v105, p102.maxRpm
	end
end
function VehicleMotor.getLastMotorRpm(p106)
	return p106.lastMotorRpm
end
function VehicleMotor.getLastModulatedMotorRpm(p107)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_3
	local v108 = (p107.smoothedLoadPercentage - 0.1) / 0.9
	local v109 = math.clamp(v108, 0.01, 1)
	local v110 = p107.lastModulationPercentage * (150 * v109) * p107.constantRpmCharge
	local v111 = 0
	if p107:getClutchPedal() < 0.1 and p107.minGearRatio > 0 then
		local v112 = p107.maxRpm - p107.minRpm
		local v113 = (p107.lastMotorRpm - p107.minRpm) / v112 * 0.5
		v111 = p107.loadPercentageChangeCharge * v112 * v113
	else
		p107.loadPercentageChangeCharge = 0
	end
	return p107.lastMotorRpm + v110 - v111
end
function VehicleMotor.getLastRealMotorRpm(p114)
	return p114.lastRealMotorRpm
end
function VehicleMotor.getSmoothLoadPercentage(p115)
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_7
	local v116 = (p115.smoothedLoadPercentage - 0) / 0.5
	local v117 = math.clamp(v116, 0, 1)
	return p115.smoothedLoadPercentage - p115.lastModulationPercentage * (0.05 * v117)
end
function VehicleMotor.getClutchPedal(p118)
	if not p118.vehicle.isServer or p118.gearShiftMode == VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH then
		return p118.manualClutchValue
	end
	local v119 = p118:getNonClampedMotorRpm()
	if v119 == 0 then
		return 0
	end
	local v120 = (p118:getClutchRotSpeed() * 30 / 3.141592653589793 + 50) / v119
	local v121 = math.min(v120, 1)
	return 1 - math.max(v121, 0)
end
function VehicleMotor.getSmoothedClutchPedal(p122)
	return p122.lastSmoothedClutchPedal
end
function VehicleMotor.getManualClutchPedal(p123)
	return p123.gearShiftMode ~= VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH and 0 or p123.manualClutchValue
end
function VehicleMotor.getGearToDisplay(p124, p125)
	local v126 = "N"
	if p124.backwardGears or p124.forwardGears then
		if p124.targetGear > 0 then
			local v127 = p124.currentGears[p124.targetGear]
			if v127 ~= nil then
				local v128 = p124.currentGears == p124.forwardGears and p124.currentDirection or 1
				if p125 then
					return v128 == 1 and (v127.dashboardName or v127.name) or (v127.dashboardReverseName or v127.reverseName)
				else
					return v128 == 1 and v127.name or v127.reverseName
				end
			end
		end
	else
		local v129 = p124:getDrivingDirection()
		if v129 > 0 then
			return "D"
		end
		v126 = v129 < 0 and "R" or v126
	end
	return v126
end
function VehicleMotor.getGearInfoToDisplay(p130)
	local v131 = "N"
	local v132 = false
	local v133 = nil
	local v134 = nil
	local v135 = nil
	local v136 = nil
	local v137 = false
	local v138 = false
	if p130.backwardGears or p130.forwardGears then
		if p130.targetGear > 0 then
			local v139 = p130.currentGears[p130.targetGear]
			if v139 ~= nil then
				local v140 = p130.currentDirection
				local v141 = p130.currentGears == p130.forwardGears and (p130.currentDirection or 1) or 1
				v131 = v141 == 1 and v139.name or v139.reverseName
				local v142 = p130.currentGears[p130.targetGear + 1 * -v140]
				if v142 ~= nil then
					v133 = v141 == 1 and v142.name or v142.reverseName
					local v143 = p130.currentGears[p130.targetGear + 2 * -v140]
					if v143 ~= nil then
						v135 = v141 == 1 and v143.name or v143.reverseName
					end
				end
				local v144 = p130.currentGears[p130.targetGear + 1 * v140]
				if v144 ~= nil then
					v134 = v141 == 1 and v144.name or v144.reverseName
					local v145 = p130.currentGears[p130.targetGear + 2 * v140]
					if v145 ~= nil then
						v136 = v141 == 1 and v145.name or v145.reverseName
					end
				end
				if p130.gear ~= p130.targetGear then
					v138 = true
				end
			end
		end
		v132 = true
	else
		local v146 = p130:getDrivingDirection()
		if v146 > 0 then
			v131 = "D"
			v133 = "N"
		elseif v146 < 0 then
			v131 = "R"
			v134 = "N"
		else
			v133 = "R"
			v134 = "D"
		end
		v137 = true
	end
	return v131, v132, v137, v133, v134, v135, v136, v138
end
function VehicleMotor.getDrivingDirection(p147)
	if p147.directionChangeMode == VehicleMotor.DIRECTION_CHANGE_MODE_MANUAL or p147.gearShiftMode ~= VehicleMotor.SHIFT_MODE_AUTOMATIC then
		return p147.currentDirection * p147.transmissionDirection
	else
		return p147.vehicle:getLastSpeed() <= 0.95 and 0 or p147.vehicle.movingDirection * p147.transmissionDirection
	end
end
function VehicleMotor.getGearGroupToDisplay(p148, p149)
	local v150 = "N"
	local v151
	if (p148.backwardGears or p148.forwardGears) and p148.gearGroups ~= nil then
		if p148.activeGearGroupIndex > 0 then
			local v152 = p148.gearGroups[p148.activeGearGroupIndex]
			if v152 ~= nil then
				if p149 then
					v150 = v152.dashboardName or v152.name
				else
					v150 = v152.name
				end
			end
		end
		v151 = true
	else
		v151 = false
	end
	return v150, v151
end
function VehicleMotor.readGearDataFromStream(p153, p154)
	p153.currentDirection = streamReadUIntN(p154, 2) - 1
	if streamReadBool(p154) then
		local v155 = streamReadUIntN(p154, 6)
		local v156 = streamReadBool(p154)
		if streamReadBool(p154) then
			p153.currentGears = p153.forwardGears
		else
			p153.currentGears = p153.backwardGears
		end
		local v157
		if p153.gearGroups == nil then
			v157 = nil
		else
			v157 = streamReadUIntN(p154, 5)
		end
		if v155 ~= p153.gear then
			if v156 and p153.gear ~= 0 then
				p153.lastGearChangeTime = g_time
			end
			p153.gear = v156 and 0 or v155
			p153.targetGear = v155
			local v158 = p153.directionChangeUseGear and (p153.currentDirection or 1) or 1
			SpecializationUtil.raiseEvent(p153.vehicle, "onGearChanged", p153.gear * v158, p153.targetGear * v158, 0)
		end
		if v157 ~= p153.activeGearGroupIndex then
			p153.activeGearGroupIndex = v157
			SpecializationUtil.raiseEvent(p153.vehicle, "onGearGroupChanged", p153.activeGearGroupIndex, p153.groupType == VehicleMotor.TRANSMISSION_TYPE.DEFAULT and p153.groupChangeTime or 0)
		end
	end
end
function VehicleMotor.writeGearDataToStream(p159, p160)
	local v161 = streamWriteUIntN
	local v162 = p159.currentDirection
	v161(p160, math.sign(v162) + 1, 2)
	if streamWriteBool(p160, p159.backwardGears ~= nil and true or p159.forwardGears ~= nil) then
		streamWriteUIntN(p160, p159.targetGear, 6)
		streamWriteBool(p160, p159.targetGear ~= p159.gear)
		streamWriteBool(p160, p159.currentGears == p159.forwardGears)
		if p159.gearGroups ~= nil then
			streamWriteUIntN(p160, p159.activeGearGroupIndex, 5)
		end
	end
end
function VehicleMotor.setLastRpm(p163, p164)
	local v165 = p163.lastMotorRpm
	p163.lastRealMotorRpm = p164
	local v166 = p163.gearType == VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT and g_time - p163.lastGearChangeTime < 200 and 0.2 or 0.05
	p163.lastMotorRpm = p163.lastMotorRpm * (1 - v166) + p163.lastRealMotorRpm * v166
	local v167 = p163.lastMotorRpm
	local v168 = p163.lastPtoRpm or p163.minRpm
	local v169 = p163.minRpm
	local v170 = (v167 - math.max(v168, v169)) / (p163.maxRpm - p163.minRpm) * p163:getSmoothLoadPercentage()
	p163.lastTurboScale = p163.lastTurboScale * 0.95 + v170 * 0.05
	if p163.lastAcceleratorPedal == 0 or p163.minGearRatio == 0 and p163.autoGearChangeTime > 0 then
		p163.blowOffValveState = p163.lastTurboScale
	else
		p163.blowOffValveState = 0
	end
	local v171 = p163.lastMotorRpm - v165
	local v172 = math.abs(v171) * 0.15
	p163.constantRpmCharge = 1 - math.min(v172, 1)
end
function VehicleMotor.getMotorAppliedTorque(p173)
	return p173.motorAppliedTorque
end
function VehicleMotor.getMotorExternalTorque(p174)
	return p174.motorExternalTorque
end
function VehicleMotor.getMotorAvailableTorque(p175)
	return p175.motorAvailableTorque
end
function VehicleMotor.getEqualizedMotorRpm(p176)
	return p176.equalizedMotorRpm
end
function VehicleMotor.setEqualizedMotorRpm(p177, p178)
	p177.equalizedMotorRpm = p178
	p177:setLastRpm(p178)
end
function VehicleMotor.getPtoMotorRpmRatio(p179)
	return p179.ptoMotorRpmRatio
end
function VehicleMotor.setExternalTorqueVirtualMultiplicator(p180, p181)
	p180.externalTorqueVirtualMultiplicator = p181 or 1
end
function VehicleMotor.getNonClampedMotorRpm(p182)
	return p182.motorRotSpeed * 30 / 3.141592653589793
end
function VehicleMotor.getMotorRotSpeed(p183)
	return p183.motorRotSpeed
end
function VehicleMotor.getClutchRotSpeed(p184)
	return p184.differentialRotSpeed * p184.gearRatio
end
function VehicleMotor.getTorqueCurve(p185)
	return p185.torqueCurve
end
function VehicleMotor.getTorque(p186, p187)
	local v188 = p186.motorRotSpeed * 30 / 3.141592653589793
	local v189 = p186.minRpm
	local v190 = p186.maxRpm
	return p186:getTorqueCurveValue((math.clamp(v188, v189, v190))) * math.abs(p187)
end
function VehicleMotor.getTorqueCurveValue(p191, p192)
	local v193 = 1 - p191.vehicle:getVehicleDamage() * VehicleMotor.DAMAGE_TORQUE_REDUCTION
	return p191:getTorqueCurve():get(p192) * v193
end
function VehicleMotor.getTorqueAndSpeedValues(p194)
	local v195 = {}
	local v196 = {}
	for _, v197 in ipairs(p194:getTorqueCurve().keyframes) do
		local v198 = v197.time * 3.141592653589793 / 30
		table.insert(v195, v198)
		local v199 = v197.time
		table.insert(v196, p194:getTorqueCurveValue(v199))
	end
	return v196, v195
end
function VehicleMotor.getMaximumForwardSpeed(p200)
	return p200.maxForwardSpeed
end
function VehicleMotor.getMaximumBackwardSpeed(p201)
	return p201.maxBackwardSpeed
end
function VehicleMotor.calculatePhysicalMaximumForwardSpeed(p202)
	return VehicleMotor.calculatePhysicalMaximumSpeed(p202.minForwardGearRatio, p202.forwardGears, p202.maxRpm)
end
function VehicleMotor.calculatePhysicalMaximumBackwardSpeed(p203)
	return VehicleMotor.calculatePhysicalMaximumSpeed(p203.minBackwardGearRatio, p203.backwardGears or p203.forwardGears, p203.maxRpm)
end
function VehicleMotor.calculatePhysicalMaximumSpeed(p204, p205, p206)
	if p204 == nil then
		if p205 == nil then
			printCallstack()
			return 0
		end
		p204 = (1 / 0)
		for _, v207 in pairs(p205) do
			local v208 = v207.ratio
			p204 = math.min(p204, v208)
		end
	end
	return p206 * 3.141592653589793 / (30 * p204)
end
function VehicleMotor.update(p209, p210)
	-- upvalues: (copy) v_u_11, (copy) v_u_2
	local v211 = p209.vehicle
	if next(v211.spec_motorized.differentials) == nil or v211.spec_motorized.motorizedNode == nil then
		local _, v212 = p209:getMinMaxGearRatio()
		p209.differentialRotSpeed = WheelsUtil.computeDifferentialRotSpeedNonMotor(v211)
		local v213 = p209.differentialRotSpeed * v212
		local v214 = math.abs(v213)
		p209.motorRotSpeed = math.max(v214, 0)
		p209.gearRatio = v212
	else
		local v215 = p209.motorRotSpeed
		local v216 = p209.differentialRotSpeed
		local v217, v218, v219 = getMotorRotationSpeed(v211.spec_motorized.motorizedNode)
		p209.motorRotSpeed = v217
		p209.differentialRotSpeed = v218
		p209.gearRatio = v219
		if p209.gearShiftMode ~= VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH and (p209.backwardGears or p209.forwardGears) and (p209.gearRatio ~= 0 and (p209.maxGearRatio ~= 0 and p209.lastAcceleratorPedal ~= 0)) then
			local v220 = p209.minRpm
			local v221 = p209.maxGearRatio
			local v222 = v220 / math.abs(v221) * 3.141592653589793 / 30
			local v223 = p209.differentialRotSpeed
			if math.abs(v223) < v222 * 0.75 then
				p209.clutchSlippingTimer = p209.clutchSlippingTime
				p209.clutchSlippingGearRatio = p209.gearRatio
			else
				local v224 = p209.clutchSlippingTimer - p210
				p209.clutchSlippingTimer = math.max(v224, 0)
			end
		end
		if not p209:getUseAutomaticGearShifting() then
			local v225 = p209.lastAcceleratorPedal * p209.currentDirection
			local v226 = ((p209.minGearRatio == 0 and p209.maxGearRatio == 0 or p209.manualClutchValue > 0.1) and 1 or 0) * v225
			local v227 = v226 == 0 and -1 or v226
			local v228 = v227 > 0 and p209.motorRotationAccelerationLimit * 0.02 or p209.dampingRateZeroThrottleClutchEngaged * 30 * 3.141592653589793
			local v229 = p209.minRpm * 3.141592653589793 / 30
			local v230 = p209.maxRpm * 3.141592653589793 / 30
			local v231 = p209.motorRotSpeedClutchEngaged + v227 * v228 * p210
			local v232 = math.max(v231, v229)
			local v233 = v229 + (v230 - v229) * v225
			p209.motorRotSpeedClutchEngaged = math.min(v232, v233)
			local v234 = p209.motorRotSpeed
			local v235 = p209.motorRotSpeedClutchEngaged
			p209.motorRotSpeed = math.max(v234, v235)
		end
		if g_physicsDtNonInterpolated > 0 and not getIsSleeping(v211.rootNode) then
			local v236, v237, v238 = getMotorTorque(v211.spec_motorized.motorizedNode)
			p209.lastMotorAvailableTorque = v236
			p209.lastMotorAppliedTorque = v237
			p209.lastMotorExternalTorque = v238
		end
		local v239 = p209.lastMotorAvailableTorque
		local v240 = p209.lastMotorAppliedTorque
		local v241 = p209.lastMotorExternalTorque
		p209.motorAvailableTorque = v239
		p209.motorAppliedTorque = v240
		p209.motorExternalTorque = v241
		p209.motorAppliedTorque = p209.motorAppliedTorque - p209.motorExternalTorque
		local v242 = p209.motorExternalTorque * p209.externalTorqueVirtualMultiplicator
		local v243 = p209.motorAvailableTorque - p209.motorAppliedTorque
		p209.motorExternalTorque = math.min(v242, v243)
		p209.motorAppliedTorque = p209.motorAppliedTorque + p209.motorExternalTorque
		local v244, v245
		if g_physicsDtNonInterpolated > 0 then
			v244 = (p209.motorRotSpeed - v215) / (g_physicsDtNonInterpolated * 0.001)
			v245 = (p209.differentialRotSpeed - v216) / (g_physicsDtNonInterpolated * 0.001)
		else
			v244 = 0
			v245 = 0
		end
		p209.motorRotAcceleration = v244
		p209.motorRotAccelerationSmoothed = 0.8 * p209.motorRotAccelerationSmoothed + 0.2 * v244
		p209.differentialRotAcceleration = v245
		p209.differentialRotAccelerationSmoothed = 0.95 * p209.differentialRotAccelerationSmoothed + 0.05 * v245
		p209.requiredMotorPower = (1 / 0)
	end
	if p209.lastPtoRpm == nil then
		p209.lastPtoRpm = p209.minRpm
	end
	local v246 = PowerConsumer.getMaxPtoRpm(p209.vehicle) * p209.ptoMotorRpmRatio
	if p209.lastPtoRpm < v246 then
		local v247 = p209.lastPtoRpm + p209.maxRpm * p210 / 2000
		p209.lastPtoRpm = math.min(v246, v247)
	elseif v246 < p209.lastPtoRpm then
		local v248 = p209.minRpm
		local v249 = p209.lastPtoRpm - p209.maxRpm * p210 / 1000
		p209.lastPtoRpm = math.max(v248, v249)
	end
	if p209.vehicle.isServer then
		local v250 = p209.motorRotSpeed * 30 / 3.141592653589793
		local v251 = p209.lastPtoRpm
		local v252 = p209.maxRpm
		local v253 = math.min(v251, v252)
		local v254 = p209.minRpm
		local v255 = math.max(v250, v253, v254)
		p209:setLastRpm(v255)
		p209.equalizedMotorRpm = v255
		local v256 = p209:getMotorAppliedTorque()
		local v257 = p209:getMotorAvailableTorque()
		local v258 = v256 / math.max(v257, 0.0001)
		p209.rawLoadPercentageBuffer = p209.rawLoadPercentageBuffer + v258
		p209.rawLoadPercentageBufferIndex = p209.rawLoadPercentageBufferIndex + 1
		if p209.rawLoadPercentageBufferIndex >= 2 then
			p209.rawLoadPercentage = p209.rawLoadPercentageBuffer / 2
			p209.rawLoadPercentageBuffer = 0
			p209.rawLoadPercentageBufferIndex = 0
		end
		if p209.rawLoadPercentage < 0.01 and p209.lastAcceleratorPedal < 0.2 and (not (p209.backwardGears or p209.forwardGears) or (p209.gear ~= 0 or p209.targetGear == 0)) then
			p209.rawLoadPercentage = -1
		else
			p209.rawLoadPercentage = (p209.rawLoadPercentage - 0.05) / 0.95
		end
		local v259 = p209.vehicle.lastSpeedAcceleration * 1000 * 1000 * p209.vehicle.movingDirection / p209.accelerationLimit
		local v260 = math.min(v259, 1)
		if v260 < 0.95 and p209.lastAcceleratorPedal > 0.2 then
			p209.accelerationLimitLoadScale = 1
			p209.accelerationLimitLoadScaleTimer = p209.accelerationLimitLoadScaleDelay
		elseif p209.accelerationLimitLoadScaleTimer > 0 then
			p209.accelerationLimitLoadScaleTimer = p209.accelerationLimitLoadScaleTimer - p210
			local v261 = p209.accelerationLimitLoadScaleTimer / p209.accelerationLimitLoadScaleDelay
			local v262 = (1 - math.max(v261, 0)) * 3.14
			p209.accelerationLimitLoadScale = math.sin(v262) * 0.85
		end
		if v260 > 0 then
			local v263 = p209.rawLoadPercentage
			local v264 = v260 * p209.accelerationLimitLoadScale
			p209.rawLoadPercentage = math.max(v263, v264)
		end
		local v265 = p209.vehicle.lastSpeedAcceleration
		local v266 = math.abs(v265) * 1000 * 1000 / p209.accelerationLimit
		p209.constantAccelerationCharge = 1 - math.min(v266, 1)
		if p209.rawLoadPercentage > 0 then
			p209.rawLoadPercentage = p209.rawLoadPercentage * 0.8 + p209.rawLoadPercentage * 0.19999999999999996 * p209.constantAccelerationCharge
		end
		if (p209.backwardGears or p209.forwardGears) and p209:getUseAutomaticGearShifting() then
			if p209.constantRpmCharge > 0.99 then
				if p209.maxRpm - v255 < 50 then
					local v267 = p209.gearChangeTimeAutoReductionTimer + p210
					local v268 = p209.gearChangeTimeAutoReductionTime
					p209.gearChangeTimeAutoReductionTimer = math.min(v267, v268)
					p209.gearChangeTime = p209.gearChangeTimeOrig * (1 - p209.gearChangeTimeAutoReductionTimer / p209.gearChangeTimeAutoReductionTime)
				else
					p209.gearChangeTimeAutoReductionTimer = 0
					p209.gearChangeTime = p209.gearChangeTimeOrig
				end
			else
				p209.gearChangeTimeAutoReductionTimer = 0
				p209.gearChangeTime = p209.gearChangeTimeOrig
			end
		end
	end
	p209:updateSmoothLoadPercentage(p210, p209.rawLoadPercentage)
	local v269 = p209.idleGearChangeTimer - p210
	p209.idleGearChangeTimer = math.max(v269, 0)
	if p209.forwardGears or p209.backwardGears then
		p209:updateStartGearValues(p210)
		local v270 = p209:getClutchPedal()
		p209.lastSmoothedClutchPedal = p209.lastSmoothedClutchPedal * 0.9 + v270 * 0.1
	end
	p209.lastModulationTimer = p209.lastModulationTimer + p210 * 0.0009
	local v271 = p209.lastModulationTimer
	local v272 = math.sin(v271)
	local v273 = (p209.lastModulationTimer + 2) * 0.3
	local v274 = v272 * math.sin(v273) * 0.8
	local v275 = p209.lastModulationTimer * 5
	p209.lastModulationPercentage = v274 + math.cos(v275) * 0.2
end
function VehicleMotor.updateSmoothLoadPercentage(p276, p277, p278)
	local v279 = p276.smoothedLoadPercentage
	local v280 = p276:getMaximumForwardSpeed() * 3.6
	if p276.vehicle.movingDirection < 0 then
		v280 = p276:getMaximumBackwardSpeed() * 3.6
	end
	local v281 = p276.vehicle:getLastSpeed() / v280
	local v282 = math.min(v281, 1)
	local v283 = 0.05 + (1 - math.max(v282, 0)) * 0.3
	if p278 < p276.smoothedLoadPercentage then
		if p276.gearType == VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT and g_time - p276.lastGearChangeTime <= 200 then
			v283 = v283 * 0.05
		else
			v283 = v283 * 0.2
			if p276:getClutchPedal() > 0.75 then
				v283 = v283 * 5
			end
			if p278 < 0 then
				v283 = v283 * 2.5
			end
		end
	end
	p276.smoothedLoadPercentage = (1 - v283) * p276.smoothedLoadPercentage + v283 * p278
	local v284 = p276.smoothedLoadPercentage - v279
	local v285 = math.max(v284, 0)
	p276.loadPercentageChangeCharge = p276.loadPercentageChangeCharge + v285
	local v286 = p276.loadPercentageChangeCharge - p277 * 0.0005
	local v287 = math.max(v286, 0)
	p276.loadPercentageChangeCharge = math.min(v287, 1)
end
function VehicleMotor.updateStartGearValues(p288, p289)
	local v290 = p288.vehicle:getTotalMass()
	local v291 = 0
	local v292 = p288.vehicle:getTotalMass(true)
	local v293 = v290 - p288.startGearValues.lastMass
	if math.abs(v293) > 0.00001 * p289 then
		p288.startGearValues.lastMass = v290
		p288.idleGearChangeTimer = 500
	end
	local v294 = p288.vehicle:getChildVehicles()
	local v295 = 0
	for _, v296 in ipairs(v294) do
		if v296 ~= p288.vehicle then
			if v296.spec_powerConsumer ~= nil and (v296.spec_powerConsumer.maxForce ~= nil and v296:getPowerMultiplier() ~= 0) then
				v295 = v295 + v296.spec_powerConsumer.maxForce
			end
			if v296.spec_leveler ~= nil then
				local v297 = v296.spec_leveler.lastForce
				v295 = v295 + math.abs(v297)
			end
			if v296.spec_wheels ~= nil and #v296.spec_wheels.wheels > 0 then
				v291 = v291 + v296:getTotalMass(true)
			end
		end
	end
	local v298 = 0
	local v299 = 0
	local v300 = 0
	local v301 = 0
	local v302 = 0
	local v303 = 0
	for _, v304 in ipairs(v294) do
		if v304 ~= p288.vehicle and (v304.spec_wheels ~= nil and #v304.spec_wheels.wheels > 0) then
			local v305 = v304:getTotalMass(true) / v291
			local v306, v307, v308 = v304:getOverallCenterOfMass()
			v298 = v298 + v306 * v305
			v299 = v299 + v307 * v305
			v300 = v300 + v308 * v305
			local v309, v310, v311 = v304:getVehicleWorldDirection()
			v301 = v301 + v309 * v305
			v302 = v302 + v310 * v305
			v303 = v303 + v311 * v305
		end
	end
	local v312, v313, v314 = p288.vehicle:getVehicleWorldDirection()
	if VehicleDebug.state == VehicleDebug.DEBUG_TRANSMISSION then
		local v315, v316, v317 = getWorldTranslation(p288.vehicle.components[1].node)
		DebugGizmo.renderAtPosition(v298, v299, v300, v301, v302, v303, 0, 1, 0, "TOOLS DIR")
		DebugGizmo.renderAtPosition(v315, v316, v317, v312, v313, v314, 0, 1, 0, "VEHICLE DIR")
	end
	local v318, v319
	if v301 == 0 and (v302 == 0 and v303 == 0) then
		v318 = 0
		v319 = 0
	else
		local v320 = v301 - v312
		local v321 = math.abs(v320)
		local v322 = v303 - v314
		local v323 = math.abs(v322)
		v318 = math.max(v321, v323)
		local v324 = v302 - v313
		v319 = math.max(v324, 0)
	end
	local v325 = (v290 - v292) / 5
	local v326 = math.min(v325, 1)
	p288.startGearValues.massDirectionDifferenceXZ = v318
	p288.startGearValues.massDirectionDifferenceY = v319
	p288.startGearValues.massDirectionFactor = (1 + v318 * v326) * (1 + v319 / 0.15 * v326)
	local v327 = PowerConsumer.getTotalConsumedPtoTorque(p288.vehicle, nil, nil, true) / p288:getPtoMotorRpmRatio()
	local v328 = p288.peakMotorPowerRotSpeed * v327
	p288.startGearValues.availablePower = p288.peakMotorPower - v328
	local v329 = (((v290 + v295 * (1 + v328 / p288.peakMotorPower * 0.75)) / v292 - 1) * 0.5 + 1) * v292
	p288.startGearValues.maxForce = v295
	p288.startGearValues.mass = v329
	p288.startGearValues.slope = p288.vehicle:getVehicleWorldXRot()
	p288.startGearValues.massFactor = p288.startGearValues.mass * p288.startGearValues.massDirectionFactor / (((p288.startGearValues.availablePower / 100 - 1) * 50 + 100) * 0.4)
end
function VehicleMotor.getBestStartGear(p330, p331)
	local v332 = p330.directionChangeUseGroup and 1 or p330.currentDirection
	local v333 = (1 / 0)
	local v334 = 1
	local v335 = 1
	local v336 = 0
	local v337 = 1
	local v338 = 1
	if p330.gearGroups == nil then
		local v339 = p330:getGearRatioMultiplier()
		for v340 = 1, #p331 do
			local v341 = p330:getStartInGearFactor(p331[v340].ratio * v339)
			if v341 < p330.startGearThreshold then
				if v336 < v341 then
					v337 = v340
					v336 = v341
				end
			end
			if v341 < v333 then
				v334 = v340
				v333 = v341
			end
		end
	elseif p330:getUseAutomaticGroupShifting() then
		for v342 = 1, #p330.gearGroups do
			local v343 = p330.gearGroups[v342].ratio * v332
			if math.sign(v343) == p330.currentDirection or not p330.directionChangeUseGroup then
				for v344 = 1, #p331 do
					local v345 = p330:getStartInGearFactor(p331[v344].ratio * v343)
					if v345 < p330.startGearThreshold then
						if v336 < v345 then
							v338 = v342
							v337 = v344
							v336 = v345
						end
					end
					if v345 < v333 then
						v335 = v342
						v334 = v344
						v333 = v345
					end
				end
			end
		end
	end
	if v336 == 0 then
		return v334, v335
	else
		return v337, v338
	end
end
function VehicleMotor.getRequiredRpmAtSpeedLimit(p346, p347)
	local v348 = p346.vehicle:getSpeedLimit(true)
	local v349 = p346.speedLimitAcc
	local v350 = p346.vehicle.lastSpeedReal * 3600
	local v351 = math.max(v349, v350)
	local v352 = math.min(v348, v351)
	if p346.vehicle:getCruiseControlState() == Drivable.CRUISECONTROL_STATE_ACTIVE then
		local v353 = p346.vehicle
		v352 = math.min(v352, v353:getCruiseControlSpeed())
	end
	if p347 > 0 then
		local v354 = p346.maxForwardSpeed * 3.6
		v356 = math.min(v352, v354)
		if v356 then
			::l5::
			return v356 / 3.6 * 30 / 3.141592653589793 * math.abs(p347)
		end
	end
	local v355 = p346.maxBackwardSpeed * 3.6
	local v356 = math.min(v352, v355)
	goto l5
end
function VehicleMotor.getStartInGearFactor(p357, p358)
	if p357:getRequiredRpmAtSpeedLimit(p358) < p357.minRpm + (p357.maxRpm - p357.minRpm) * 0.25 then
		return (1 / 0)
	end
	local v359 = p357.startGearValues.slope
	if p358 < 0 then
		v359 = -v359
	end
	local v360 = ((p357.startGearValues.availablePower / 100 - 1) / 2) ^ 2 * 2 + 1
	local v361 = 1 + math.max(v359, 0) / (v360 * 0.06981)
	return p357.startGearValues.massFactor * v361 / (math.abs(p358) / 300)
end
function VehicleMotor.getBestGearRatio(p362, p363, p364, p365, p366, p367, p368)
	if p368 ~= 0 then
		local v369 = p368 - p366
		local v370 = p368 * 0.8
		local v371 = math.max(v369, v370) / math.max(p363, 0.001)
		return math.clamp(v371, p364, p365)
	end
	local v372 = math.max(p363, 0.0001)
	local v373 = 0
	for v374 = p364, p365, 0.5 do
		local v375 = v372 * v374
		if p362.maxRpm - p366 < v375 then
			break
		end
		local v376 = p362.minRpm
		local v377 = p362:getTorqueCurveValue((math.max(v375, v376))) * v375 * 3.141592653589793 / 30
		if v373 < v377 then
			p364 = v374
			v373 = v377
		end
		if p367 <= v377 then
			break
		end
	end
	return p364
end
function VehicleMotor.getBestGear(p378, p379, p380, p381, p382, p383)
	if (math.abs(p379) < 0.001 and (p380 < 0 and -1 or 1) or p379) > 0 then
		if p378.minForwardGearRatio == nil then
			return 1, p378.forwardGears[1].ratio
		else
			return 1, p378:getBestGearRatio(math.max(p380, 0), p378.minForwardGearRatio, p378.maxForwardGearRatio, p381, p382, p383)
		end
	elseif p378.minBackwardGearRatio == nil then
		if p378.backwardGears == nil then
			return 1, p378.forwardGears[1].ratio
		else
			return -1, -p378.backwardGears[1].ratio
		end
	else
		local v384 = -p380
		return -1, -p378:getBestGearRatio(math.max(v384, 0), p378.minBackwardGearRatio, p378.maxBackwardGearRatio, p381, p382, p383)
	end
end
function VehicleMotor.findGearChangeTargetGearPrediction(p385, p386, p387, p388, p389, p390, _)
	local v391 = p385:getGearRatioMultiplier()
	local v392 = p385.minRpm
	local v393 = p385.maxRpm
	local v394 = p387[p386].ratio * v391
	local v395 = math.abs(v394)
	local v396 = p385.differentialRotSpeed * p388
	local v397 = math.max(v396, 0.0001)
	local v398 = v397 * 30 / 3.141592653589793
	local v399 = v398 * v395
	local v400
	if math.abs(p390) < 0.0001 then
		local v401 = p385.differentialRotAccelerationSmoothed * p388 * 0.8
		local v402 = v397 + math.min(v401, 0) * p385.gearChangeTime * 0.001
		v400 = math.max(v402, 0)
	else
		local v403 = (p385.motorRotSpeed - p385.motorRotAcceleration * (g_physicsDtLastValidNonInterpolated * 0.001)) / (1 + p385.dampingRateFullThrottle / p385.rotInertia * g_physicsDtLastValidNonInterpolated * 0.001)
		local v404 = (p385.motorRotSpeed - v403) / (g_physicsDtLastValidNonInterpolated * 0.001) * p385.rotInertia
		local v405 = p385.motorAppliedTorque - p385.motorExternalTorque - v404
		local v406 = p385.vehicle:getTotalMass()
		local v407 = v405 * v395 / v406 * 0.9
		local v408 = p385.differentialRotAccelerationSmoothed * p388
		local v409 = v407 - math.max(v408, 0)
		local v410 = v397 - math.max(v409, 0) * p385.gearChangeTime * 0.001
		v400 = math.max(v410, 0)
	end
	local v411 = p386
	local v412 = 0
	local v413 = 0
	for v414 = 1, #p387 do
		local v415
		if v414 == p386 then
			v415 = v399
		else
			local v416 = p387[v414].ratio * v391
			v415 = v400 * math.abs(v416) * 30 / 3.141592653589793
		end
		local v417 = p385:getStartInGearFactor(p387[v414].ratio * v391) < p385.startGearThreshold and 0 or 1
		if v415 <= v393 and v392 * v417 <= v415 or v414 == p386 then
			local v418 = p385:getTorqueCurveValue(v415) * v415
			if v412 <= v418 then
				v413 = v414
				v412 = v418
			end
		end
	end
	if v413 ~= 0 then
		local v419 = 0
		for v420 = #p387, 1, -1 do
			local v421 = false
			local v422
			if v420 == p386 then
				v422 = v399
			else
				local v423 = p387[v420].ratio * v391
				v422 = v400 * math.abs(v423) * 30 / 3.141592653589793
			end
			local v424 = p385:getStartInGearFactor(p387[v420].ratio * v391)
			local v425, v426
			if v424 < p385.startGearThreshold then
				v425 = 0
				v426 = 0
			else
				v425 = 1
				v426 = 0.8
			end
			if v422 <= v393 and v392 * v425 <= v422 or v420 == p386 then
				local v427 = p385:getTorqueCurveValue(v422) * v422
				if v412 * v426 <= v427 or v420 == p386 then
					local v428 = (v427 - v412 * v426) / (v412 * (1 - v426))
					local v429 = p387[v420].ratio * v391
					local v430 = v393 - v398 * math.abs(v429)
					local v431 = v393 - v392
					local v432 = v430 / math.max(v431, 0.001)
					local v433 = math.clamp(v432, 0, 2)
					if v433 > 1 then
						v433 = 1 - (v433 - 1) * 4
					end
					local v434
					if v420 == p386 then
						v434 = 1
					else
						local v435 = -p389 / 2000
						v434 = math.min(v435, 0.9)
					end
					local v436
					if v420 < p386 then
						local v437 = (v422 - v399) / 250
						v436 = math.clamp(v437, -1, 0)
					else
						v436 = 0
					end
					if v420 < p385.bestGearSelected and p385:getStartInGearFactor(v395) < p385.startGearThreshold then
						v434 = v434 - 3
					end
					local v438 = v433 * 3.141592653589793
					local v439 = math.sin(v438) * 5
					local v440 = v436 - (1 - math.min(v439, 2)) * 0.7
					if v420 == p386 and v440 > 0 then
						v440 = v440 * 1.5
					end
					local v441
					if math.abs(p390) < 0.0001 then
						v441 = 1 - v433
					else
						v441 = v433 * 2
					end
					if math.abs(p390) < 0.0001 and (v399 - v425) / (v393 - v425) > 0.25 then
						if v420 < p386 then
							v428 = 0
							v441 = 0
						elseif v420 == p386 then
							v428 = 1
							v441 = 1
						end
					end
					if p386 < v420 and v424 < p385.startGearThreshold then
						v428 = 1
						v440 = 1
					end
					local v442 = v428 + v441 + v434 + v440
					if v419 <= v442 then
						v411 = v420
						v419 = v442
					end
					if VehicleDebug.state == VehicleDebug.DEBUG_TRANSMISSION then
						p387[v420].lastTradeoff = v442
						p387[v420].lastDiffSpeedAfterChange = v420 == p386 and v400 and v400 or nil
						p387[v420].lastPowerFactor = v428
						p387[v420].lastRpmFactor = v441
						p387[v420].lastGearChangeFactor = v434
						p387[v420].lastRpmPreferenceFactor = v440
						p387[v420].lastNextPower = v427
						p387[v420].nextPowerValid = true
						p387[v420].lastNextRpm = v422
						p387[v420].nextRpmValid = true
						p387[v420].lastMaxPower = v412
						p387[v420].lastHasPower = true
						v421 = true
					else
						v421 = true
					end
				elseif VehicleDebug.state == VehicleDebug.DEBUG_TRANSMISSION then
					p387[v420].lastNextPower = v427
				end
			end
			if not v421 and VehicleDebug.state == VehicleDebug.DEBUG_TRANSMISSION then
				p387[v420].lastTradeoff = 0
				p387[v420].lastPowerFactor = 0
				p387[v420].lastRpmFactor = 0
				p387[v420].lastGearChangeFactor = 0
				p387[v420].lastRpmPreferenceFactor = 0
				p387[v420].lastDiffSpeedAfterChange = v420 == p386 and v400 and v400 or nil
				p387[v420].lastNextRpm = v422
				local v443 = p387[v420]
				local v444
				if v422 <= v393 then
					v444 = v392 * v425 <= v422
				else
					v444 = false
				end
				v443.nextRpmValid = v444
				p387[v420].nextPowerValid = false
				p387[v420].lastMaxPower = v412
				p387[v420].lastHasPower = false
			end
		end
		return v411
	end
	local v445 = (1 / 0)
	local v446 = 0
	for v447 = 1, #p387 do
		local v448 = p387[v447].ratio * v391
		local v449 = v400 * math.abs(v448) * 30 / 3.141592653589793
		local v450 = v449 - v393
		local v451 = v392 - v449
		local v452 = math.max(v450, v451)
		if v452 < v445 then
			v446 = v447
			v445 = v452
		end
	end
	return v446
end
function VehicleMotor.applyTargetGear(p453)
	local v454 = p453:getGearRatioMultiplier()
	p453.gear = p453.targetGear
	if p453.gearShiftMode ~= VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH then
		if p453.currentGears[p453.gear] == nil then
			p453.minGearRatio = 0
			p453.maxGearRatio = 0
		else
			p453.minGearRatio = p453.currentGears[p453.gear].ratio * v454
			p453.maxGearRatio = p453.minGearRatio
		end
		p453.startDebug = 0
	end
	p453.gearChangeTime = p453.gearChangeTimeOrig
	local v455 = p453.directionChangeUseGear and (p453.currentDirection or 1) or 1
	SpecializationUtil.raiseEvent(p453.vehicle, "onGearChanged", p453.gear * v455, p453.targetGear * v455, 0)
end
function VehicleMotor.updateGear(p456, p457, p458, p459)
	p456.lastAcceleratorPedal = p457
	if p456.gearChangeTimer >= 0 then
		p456.gearChangeTimer = p456.gearChangeTimer - p459
		if p456.gearChangeTimer < 0 and p456.targetGear ~= 0 then
			p456.allowGearChangeTimer = 3000
			local v460 = p456.targetGear - p456.previousGear
			p456.allowGearChangeDirection = math.sign(v460)
			p456:applyTargetGear()
			p457 = 0
		else
			p457 = 0
		end
	elseif p456.groupChangeTimer > 0 or p456.directionChangeTimer > 0 then
		p456.groupChangeTimer = p456.groupChangeTimer - p459
		p456.directionChangeTimer = p456.directionChangeTimer - p459
		if p456.groupChangeTimer < 0 and p456.directionChangeTimer < 0 then
			p456:applyTargetGear()
		end
	else
		local v461 = 0
		if p457 > 0 then
			if p456.minForwardGearRatio == nil then
				v461 = 1
			else
				p456.minGearRatio = p456.minForwardGearRatio
				p456.maxGearRatio = p456.maxForwardGearRatio
			end
		elseif p457 < 0 then
			if p456.minBackwardGearRatio == nil then
				v461 = -1
			else
				p456.minGearRatio = -p456.minBackwardGearRatio
				p456.maxGearRatio = -p456.maxBackwardGearRatio
			end
		elseif p456.maxGearRatio > 0 then
			v461 = p456.minForwardGearRatio == nil and 1 or v461
		else
			v461 = p456.maxGearRatio < 0 and p456.minBackwardGearRatio == nil and -1 or v461
		end
		local v462 = p456.gear
		local v463, v464
		if (p456.backwardGears or p456.forwardGears) and p456:getUseAutomaticGearShifting() then
			p456.autoGearChangeTimer = p456.autoGearChangeTimer - p459
			if p456.vehicle:getIsAutomaticShiftingAllowed() or p457 ~= 0 then
				local v465 = p456.vehicle.lastSpeed
				if math.abs(v465) < 0.0003 then
					local v466 = false
					local v467 = false
					local v468 = false
					if v461 < 0 and (p456.currentDirection == 1 or p456.gear == 0) then
						p456:changeDirection(-1, true)
						v466 = true
					elseif v461 > 0 and (p456.currentDirection == -1 or p456.gear == 0) then
						p456:changeDirection(1, true)
						v466 = true
					elseif p456.lastAcceleratorPedal == 0 and p456.idleGearChangeTimer <= 0 then
						p456.doSecondBestGearSelection = 3
						v467 = true
					elseif p456.doSecondBestGearSelection > 0 and p456.lastAcceleratorPedal ~= 0 then
						p456.doSecondBestGearSelection = p456.doSecondBestGearSelection - 1
						if p456.doSecondBestGearSelection == 0 then
							v467 = true
							v468 = true
						end
					end
					if v466 then
						if p456.targetGear ~= p456.gear then
							v462 = p456.targetGear
						end
						v467 = true
					end
					if v467 then
						local v469
						v463, v469 = p456:getBestStartGear(p456.currentGears)
						if v463 == p456.gear and v463 == p456.bestGearSelected then
							v463 = v462
						elseif v463 > 1 or v468 then
							p456.bestGearSelected = v463
							p456.allowGearChangeTimer = 0
						end
						if p456:getUseAutomaticGroupShifting() and (v469 ~= nil and v469 ~= p456.activeGearGroupIndex) then
							p456:setGearGroup(v469)
							v464 = p457
						else
							v464 = p457
						end
					else
						v464 = p457
						v463 = v462
					end
				elseif p456.gear == 0 then
					v464 = p457
					v463 = v462
				else
					local v470
					if p456.autoGearChangeTimer <= 0 then
						local v471 = math.sign(p457)
						local v472 = p456.currentDirection
						v470 = v471 ~= math.sign(v472) and 0 or p457
						v462 = p456:findGearChangeTargetGearPrediction(p456.gear, p456.currentGears, p456.currentDirection, p456.autoGearChangeTimer, v470, p459)
						if p456:getUseAutomaticGroupShifting() and p456.gearGroups ~= nil then
							if p456.activeGearGroupIndex < #p456.gearGroups then
								local v473 = p456:getLastRealMotorRpm()
								local v474 = p456.maxRpm
								local v475 = math.min(v473, v474) - p456.maxRpm
								if math.abs(v475) < 50 then
									if p456.gear == #p456.currentGears then
										local v476 = p456.gearGroups[p456.activeGearGroupIndex + 1].ratio
										local v477 = p456.gearGroups[p456.activeGearGroupIndex].ratio
										if math.sign(v477) == math.sign(v476) then
											for v478 = p456.gear, 1, -1 do
												v476 = v476 * p456.currentGears[v478].ratio
												if p456:getRequiredRpmAtSpeedLimit(v476) > p456.minRpm + (p456.maxRpm - p456.minRpm) * 0.25 then
													p456:shiftGroup(true)
													v462 = v478
													break
												end
											end
										end
									elseif p456.groupType == VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT then
										local v479 = p456.gearGroups[p456.activeGearGroupIndex].ratio
										local v480 = math.sign(v479)
										local v481 = p456.gearGroups[p456.activeGearGroupIndex + 1].ratio
										if v480 == math.sign(v481) then
											p456.gearGroupUpShiftTimer = p456.gearGroupUpShiftTimer + p459
											if p456.gearGroupUpShiftTimer > p456.gearGroupUpShiftTime then
												p456.gearGroupUpShiftTimer = 0
												p456:shiftGroup(true)
											end
										else
											p456.gearGroupUpShiftTimer = 0
										end
									end
								else
									p456.gearGroupUpShiftTimer = 0
								end
							else
								p456.gearGroupUpShiftTimer = 0
							end
							if p456.gear == 1 and p456.lastRealMotorRpm < p456.minRpm + (p456.maxRpm - p456.minRpm) * 0.25 then
								local _, v482 = p456:getBestStartGear(p456.currentGears)
								if v482 < p456.activeGearGroupIndex then
									local v483 = p456.gearGroups[v482].ratio
									local v484 = math.sign(v483)
									local v485 = p456.gearGroups[p456.activeGearGroupIndex].ratio
									if v484 == math.sign(v485) then
										p456:setGearGroup(v482)
									end
								end
							end
						end
					else
						v470 = p457
					end
					local v486 = math.max(v462, 1)
					local v487 = #p456.currentGears
					v463 = math.min(v486, v487)
					v464 = p457
					p457 = v470
				end
				p456.allowGearChangeTimer = p456.allowGearChangeTimer - p459
				if p456.allowGearChangeTimer > 0 and (p457 * p456.currentDirection > 0 and v463 < p456.gear) then
					local v488 = p456.allowGearChangeDirection
					local v489 = v463 - p456.gear
					if v488 ~= math.sign(v489) then
						v463 = p456.gear
					end
				end
			else
				v464 = p457
				v463 = v462
			end
		else
			v464 = p457
			v463 = v462
		end
		if v463 == p456.gear then
			p457 = v464
		else
			if v463 ~= p456.bestGearSelected then
				p456.bestGearSelected = -1
			end
			p456.targetGear = v463
			p456.previousGear = p456.gear
			p456.gear = 0
			p456.minGearRatio = 0
			p456.maxGearRatio = 0
			p456.autoGearChangeTimer = p456.autoGearChangeTime
			p456.gearChangeTimer = p456.gearChangeTime
			p456.lastGearChangeTime = g_time
			p457 = 0
			local v490 = p456.directionChangeUseGear and (p456.currentDirection or 1) or 1
			SpecializationUtil.raiseEvent(p456.vehicle, "onGearChanged", p456.gear * v490, p456.targetGear * v490, p456.gearChangeTimer)
			if p456.gearChangeTimer == 0 then
				p456.gearChangeTimer = -1
				p456.allowGearChangeTimer = 3000
				local v491 = p456.targetGear - p456.previousGear
				p456.allowGearChangeDirection = math.sign(v491)
				p456:applyTargetGear()
			end
		end
	end
	if p456.gearShiftMode == VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH and (p456.backwardGears or p456.forwardGears) then
		local v492, v493
		if p456.currentGears[p456.gear] == nil then
			v492 = nil
			v493 = nil
		else
			v492 = p456.currentGears[p456.gear].ratio * p456:getGearRatioMultiplier()
			local v494 = p456.motorRotSpeed
			local v495 = p456.differentialRotSpeed
			local v496 = v494 / math.max(v495, 0.00001)
			v493 = math.min(v496, 5000)
		end
		local v497
		if v492 == nil then
			v497 = 0
		else
			local v498 = MathUtil.lerp
			local v499 = math.abs(v492)
			local v500 = math.abs(v493)
			local v501 = p456.manualClutchValue
			v497 = v498(v499, v500, math.min(v501, 0.9) / 0.9 * 0.5) * math.sign(v492)
		end
		p456.minGearRatio = v497
		p456.maxGearRatio = v497
		if p456.manualClutchValue == 0 and p456.maxGearRatio ~= 0 then
			if (p456:getClutchRotSpeed() * 30 / 3.141592653589793 + 50) / p456:getNonClampedMotorRpm() < 0.2 then
				p456.stallTimer = p456.stallTimer + p459
				if p456.stallTimer > 500 then
					p456.vehicle:stopMotor()
					p456.stallTimer = 0
				end
			else
				p456.stallTimer = 0
			end
		else
			p456.stallTimer = 0
		end
	end
	if p456:getUseAutomaticGearShifting() then
		local v502 = p456.vehicle.lastSpeed
		if math.abs(v502) > 0.0003 and (p456.backwardGears or p456.forwardGears) then
			if p456.currentDirection > 0 and p457 < 0 then
				p457 = 0
				p458 = 1
			elseif p456.currentDirection < 0 and p457 > 0 then
				p457 = 0
				p458 = 1
			end
		end
	end
	return p457, p458
end
function VehicleMotor.shiftGear(p503, p504)
	if not p503.gearChangedIsLocked then
		if p503:getIsGearChangeAllowed() then
			local v505
			if p504 then
				v505 = p503.targetGear + 1 * p503.currentDirection
			else
				v505 = p503.targetGear - 1 * p503.currentDirection
			end
			local v506
			if p503.currentDirection > 0 or p503.backwardGears == nil then
				v506 = #p503.forwardGears < v505 and #p503.forwardGears or v505
			else
				v506 = (p503.currentDirection < 0 or p503.backwardGears ~= nil) and #p503.backwardGears < v505 and #p503.backwardGears or v505
			end
			if v506 ~= p503.targetGear then
				if p503.currentDirection > 0 then
					if v506 < 0 then
						p503:changeDirection(-1)
						v506 = 1
					end
				elseif v506 < 0 then
					p503:changeDirection(1)
					v506 = 1
				end
				p503:setGear(v506)
				p503.lastManualShifterActive = false
				return
			end
		else
			SpecializationUtil.raiseEvent(p503.vehicle, "onClutchCreaking", true, false)
		end
	end
end
function VehicleMotor.selectGear(p507, p508, p509)
	if p509 then
		if p507.gear ~= p508 then
			if not p507:getIsGearChangeAllowed() then
				SpecializationUtil.raiseEvent(p507.vehicle, "onClutchCreaking", false, false, p508)
				return
			end
			if p507.currentGears[p508] ~= nil then
				p507:setGear(p508, true)
				p507.lastManualShifterActive = true
				return
			end
		end
	else
		p507:setGear(0, false)
		p507.lastManualShifterActive = true
	end
end
function VehicleMotor.setGear(p510, p511, _)
	if p511 ~= p510.targetGear then
		if p510.gearChangeTime == 0 and p511 < p510.targetGear then
			p510.loadPercentageChangeCharge = 1
		end
		if p510.gearShiftMode == VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH then
			p510.targetGear = p511
			p510.previousGear = p510.gear
			p510.gear = p511
		else
			p510.targetGear = p511
			p510.previousGear = p510.gear
			p510.gear = 0
			p510.minGearRatio = 0
			p510.maxGearRatio = 0
			p510.autoGearChangeTimer = p510.autoGearChangeTime
			p510.gearChangeTimer = p510.gearChangeTime
		end
		p510.lastGearChangeTime = g_time
		local v512 = p510.directionChangeUseGear and (p510.currentDirection or 1) or 1
		SpecializationUtil.raiseEvent(p510.vehicle, "onGearChanged", p510.gear * v512, p510.targetGear * v512, p510.gearChangeTime)
	end
end
function VehicleMotor.shiftGroup(p513, p514)
	if not p513.gearGroupChangedIsLocked then
		if p513:getIsGearGroupChangeAllowed() then
			if p513.gearGroups ~= nil then
				local v515
				if p514 then
					v515 = p513.activeGearGroupIndex + 1
				else
					v515 = p513.activeGearGroupIndex - 1
				end
				local v516 = p513.numGearGroups
				p513:setGearGroup((math.clamp(v515, 1, v516)))
				return
			end
		else
			SpecializationUtil.raiseEvent(p513.vehicle, "onClutchCreaking", true, true)
		end
	end
end
function VehicleMotor.selectGroup(p517, p518, p519)
	if p519 then
		if p517:getIsGearGroupChangeAllowed() then
			if p517.gearGroups ~= nil and p517.gearGroups[p518] ~= nil then
				p517:setGearGroup(p518, true)
				return
			end
		elseif p517.activeGearGroupIndex ~= p518 then
			SpecializationUtil.raiseEvent(p517.vehicle, "onClutchCreaking", false, true, nil, p518)
			return
		end
	else
		p517:setGearGroup(0, false)
	end
end
function VehicleMotor.setGearGroup(p520, p521, p522)
	local v523 = p520.activeGearGroupIndex
	p520.activeGearGroupIndex = p521
	p520.gearGroupChangedIsLocked = p522
	if p520.activeGearGroupIndex ~= v523 then
		if p520.groupType == VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT and v523 < p520.activeGearGroupIndex then
			p520.loadPercentageChangeCharge = 1
		end
		if p520.directionChangeUseGroup then
			p520.currentDirection = p520.activeGearGroupIndex == p520.directionChangeGroupIndex and -1 or 1
		end
		if p520.gearShiftMode ~= VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH then
			if p520.groupType == VehicleMotor.TRANSMISSION_TYPE.DEFAULT then
				p520.groupChangeTimer = p520.groupChangeTime
				p520.gear = 0
				p520.minGearRatio = 0
				p520.maxGearRatio = 0
			elseif p520.groupType == VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT then
				p520:applyTargetGear()
			end
		end
		SpecializationUtil.raiseEvent(p520.vehicle, "onGearGroupChanged", p520.activeGearGroupIndex, p520.groupType == VehicleMotor.TRANSMISSION_TYPE.DEFAULT and p520.groupChangeTime or 0)
	end
end
function VehicleMotor.changeDirection(p524, p525, p526)
	if p525 == nil then
		p525 = -p524.currentDirection
	end
	if p524.backwardGears == nil and p524.forwardGears == nil then
		p524.currentDirection = p525
		SpecializationUtil.raiseEvent(p524.vehicle, "onGearDirectionChanged", p524.currentDirection)
	else
		local v527 = ((not p524.directionChangeUseGroup or p524.gearGroupChangedIsLocked) and true or false) and ((not p524.directionChangeUseGear or p524.gearChangedIsLocked) and not p524.directionChangeUseGear and true or false)
		if v527 then
			v527 = not p524.directionChangeUseGroup
		end
		if v527 and (p525 ~= p524.currentDirection or p526) then
			p524.currentDirection = p525
			if p524.directionChangeTime > 0 then
				p524.directionChangeTimer = p524.directionChangeTime
				p524.gear = 0
				p524.minGearRatio = 0
				p524.maxGearRatio = 0
			end
			local v528 = p524.activeGearGroupIndex
			if p524.currentDirection < 0 then
				if p524.directionChangeUseGear then
					p524.directionLastGear = p524.targetGear
					if not (p524:getUseAutomaticGearShifting() and p524.lastManualShifterActive) then
						p524.targetGear = p524.directionChangeGearIndex
					end
					p524.currentGears = p524.backwardGears or p524.forwardGears
				elseif p524.directionChangeUseGroup then
					p524.directionLastGroup = p524.activeGearGroupIndex
					p524.activeGearGroupIndex = p524.directionChangeGroupIndex
				end
			elseif p524.directionChangeUseGear then
				if not (p524:getUseAutomaticGearShifting() and p524.lastManualShifterActive) then
					if p524.directionLastGear > 0 then
						p524.targetGear = not p524:getUseAutomaticGearShifting() and p524.directionLastGear or p524.defaultForwardGear
					else
						p524.targetGear = p524.defaultForwardGear
					end
				end
				p524.currentGears = p524.forwardGears
			elseif p524.directionChangeUseGroup then
				if p524.directionLastGroup > 0 then
					p524.activeGearGroupIndex = p524.directionLastGroup
				else
					p524.activeGearGroupIndex = p524.defaultGearGroup
				end
			end
			SpecializationUtil.raiseEvent(p524.vehicle, "onGearDirectionChanged", p524.currentDirection)
			local v529 = p524.directionChangeUseGear and (p524.currentDirection or 1) or 1
			SpecializationUtil.raiseEvent(p524.vehicle, "onGearChanged", p524.gear * v529, p524.targetGear * v529, p524.directionChangeTime)
			if p524.activeGearGroupIndex ~= v528 then
				SpecializationUtil.raiseEvent(p524.vehicle, "onGearGroupChanged", p524.activeGearGroupIndex, p524.directionChangeTime)
			end
			if p524.directionChangeTime == 0 then
				p524:applyTargetGear()
			end
		end
	end
end
function VehicleMotor.onManualClutchChanged(p530, p531)
	p530.manualClutchValue = p531
end
function VehicleMotor.getIsGearChangeAllowed(p532)
	return (p532.gearShiftMode ~= VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH or p532.gearType == VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT) and true or p532.manualClutchValue > 0.5
end
function VehicleMotor.getIsGearGroupChangeAllowed(p533)
	if p533.gearGroups == nil then
		return false
	else
		return (p533.gearShiftMode ~= VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH or p533.groupType == VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT) and true or p533.manualClutchValue > 0.5
	end
end
function VehicleMotor.setTransmissionDirection(p534, p535)
	if p535 > 0 then
		p534.maxForwardSpeed = p534.maxForwardSpeedOrigin
		p534.maxBackwardSpeed = p534.maxBackwardSpeedOrigin
		p534.minForwardGearRatio = p534.minForwardGearRatioOrigin
		p534.maxForwardGearRatio = p534.maxForwardGearRatioOrigin
		p534.minBackwardGearRatio = p534.minBackwardGearRatioOrigin
		p534.maxBackwardGearRatio = p534.maxBackwardGearRatioOrigin
	else
		p534.maxForwardSpeed = p534.maxBackwardSpeedOrigin
		p534.maxBackwardSpeed = p534.maxForwardSpeedOrigin
		p534.minForwardGearRatio = p534.minBackwardGearRatioOrigin
		p534.maxForwardGearRatio = p534.maxBackwardGearRatioOrigin
		p534.minBackwardGearRatio = p534.minForwardGearRatioOrigin
		p534.maxBackwardGearRatio = p534.maxForwardGearRatioOrigin
	end
	p534.transmissionDirection = p535
end
function VehicleMotor.getMinMaxGearRatio(p536)
	local v537 = p536.minGearRatio
	local v538 = p536.maxGearRatio
	if p536.minGearRatio ~= 0 or p536.maxGearRatio ~= 0 then
		if p536.clutchSlippingTimer == p536.clutchSlippingTime then
			local v539 = p536.maxGearRatio
			local v540 = math.max(350, v539)
			local v541 = p536.maxGearRatio
			return v537, v540 * math.sign(v541)
		end
		if p536.clutchSlippingTimer > 0 then
			v537 = MathUtil.lerp(v537, p536.clutchSlippingGearRatio, p536.clutchSlippingTimer / p536.clutchSlippingTime)
			v538 = MathUtil.lerp(v538, p536.clutchSlippingGearRatio, p536.clutchSlippingTimer / p536.clutchSlippingTime)
		end
	end
	return v537, v538
end
function VehicleMotor.getGearRatio(p542)
	return p542.gearRatio
end
function VehicleMotor.getGearRatioMultiplier(p543)
	local v544 = p543.directionChangeUseGroup and 1 or p543.currentDirection
	if p543.gearGroups ~= nil then
		if p543.activeGearGroupIndex == 0 then
			return 0
		end
		local v545 = p543.gearGroups[p543.activeGearGroupIndex]
		if v545 ~= nil then
			return v545.ratio * v544
		end
	end
	return v544
end
function VehicleMotor.getIsInNeutral(p546)
	return (p546.backwardGears or p546.forwardGears) and (p546.gear == 0 and p546.targetGear == 0) and true or false
end
function VehicleMotor.getCanMotorRun(p547)
	if p547.gearShiftMode == VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH and (not p547.vehicle:getIsMotorStarted() and (p547.backwardGears or p547.forwardGears)) and (p547.manualClutchValue == 0 and (p547.maxGearRatio ~= 0 and (p547:getClutchRotSpeed() * 30 / 3.141592653589793 + 50) / p547:getNonClampedMotorRpm() < 0.2)) then
		return false, VehicleMotor.REASON_CLUTCH_NOT_ENGAGED
	else
		return true
	end
end
function VehicleMotor.getCurMaxRpm(p548)
	local v549 = p548.maxRpm
	local v550 = p548:getGearRatio()
	if v550 ~= 0 then
		local v551 = p548.speedLimit
		local v552 = p548.speedLimitAcc
		local v553 = p548.vehicle.lastSpeedReal * 3600
		local v554 = math.max(v552, v553)
		local v555 = math.min(v551, v554) * 0.277778
		local v556
		if v550 > 0 then
			local v557 = p548.maxForwardSpeed
			v556 = math.min(v555, v557)
		else
			local v558 = p548.maxBackwardSpeed
			v556 = math.min(v555, v558)
		end
		local v559 = v556 * 30 / 3.141592653589793 * math.abs(v550)
		v549 = math.min(v549, v559)
	end
	local v560 = p548.rpmLimit
	return math.min(v549, v560)
end
function VehicleMotor.setSpeedLimit(p561, p562)
	local v563 = p561.minSpeed
	p561.speedLimit = math.max(p562, v563)
end
function VehicleMotor.getSpeedLimit(p564)
	return p564.speedLimit
end
function VehicleMotor.setAccelerationLimit(p565, p566)
	p565.accelerationLimit = p566
end
function VehicleMotor.getAccelerationLimit(p567)
	return p567.accelerationLimit
end
function VehicleMotor.setRpmLimit(p568, p569)
	p568.rpmLimit = p569
end
function VehicleMotor.setMotorRotationAccelerationLimit(p570, p571)
	p570.motorRotationAccelerationLimit = p571
end
function VehicleMotor.getMotorRotationAccelerationLimit(p572)
	return p572.motorRotationAccelerationLimit
end
function VehicleMotor.setDirectionChangeMode(p573, p574)
	p573.directionChangeMode = p574
end
function VehicleMotor.setGearShiftMode(p575, p576)
	p575.gearShiftMode = p576
	if p575.gearShiftMode == VehicleMotor.SHIFT_MODE_MANUAL_CLUTCH and p575.gearType == VehicleMotor.TRANSMISSION_TYPE.POWERSHIFT then
		p575.gearShiftMode = VehicleMotor.SHIFT_MODE_MANUAL
	end
end
function VehicleMotor.getUseAutomaticGearShifting(p577)
	return p577.gearShiftMode == VehicleMotor.SHIFT_MODE_AUTOMATIC and true or not p577.manualShiftGears
end
function VehicleMotor.getUseAutomaticGroupShifting(p578)
	return p578.gearShiftMode == VehicleMotor.SHIFT_MODE_AUTOMATIC and true or not p578.manualShiftGroups
end

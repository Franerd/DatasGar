Crawlers = {}
Crawlers.VRAM_PER_CRAWLER = 1572864
Crawlers.MAX_UPDATE_DISTANCE_ALIGNMENT = 50
Crawlers.xmlSchema = nil
function Crawlers.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Wheels, p1)
end
function Crawlers.initSpecialization()
	g_storeManager:addVRamUsageFunction(Crawlers.getVRamUsageFromXML)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Crawlers")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#linkNode", "Link node")
	v2:register(XMLValueType.NODE_INDICES, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#linkWheelNodes", "Back and front wheels which are used to link the crawler. Wheels are also used for speed reference.")
	v2:register(XMLValueType.BOOL, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#isLeft", "Is left crawler", false)
	v2:register(XMLValueType.FLOAT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#trackWidth", "Track width", 1)
	v2:register(XMLValueType.BOOL, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#hasShallowWaterObstacle", "Crawler has a shallow water obstacle between the defined wheels")
	v2:register(XMLValueType.STRING, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#filename", "Crawler filename")
	v2:register(XMLValueType.VECTOR_TRANS, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#offset", "Crawler position offset")
	v2:register(XMLValueType.INT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#wheelIndex", "Speed reference wheel index")
	v2:register(XMLValueType.VECTOR_N, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#wheelIndices", "Multiple speed reference wheels. The average speed of the wheels WITH ground contact is used")
	v2:register(XMLValueType.NODE_INDICES, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#wheelNodes", "Multiple speed reference wheels (defined by any node of the wheel). The average speed of the wheels WITH ground contact is used")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#speedReferenceNode", "Speed reference node")
	v2:register(XMLValueType.FLOAT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#fieldDirtMultiplier", "Field dirt multiplier", 75)
	v2:register(XMLValueType.FLOAT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#streetDirtMultiplier", "Street dirt multiplier", -150)
	v2:register(XMLValueType.FLOAT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#waterWetnessFactor", "Factor for crawler wetness while driving in water", 20)
	v2:register(XMLValueType.FLOAT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#minDirtPercentage", "Min. dirt while getting clean on non field ground", 0.35)
	v2:register(XMLValueType.FLOAT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#maxDirtOffset", "Max. dirt amount offset to global dirt node", 0.5)
	v2:register(XMLValueType.FLOAT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?)#dirtColorChangeSpeed", "Defines speed to change the dirt color (sec)", 20)
	VehicleMaterial.registerXMLPaths(v2, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).crawlers.crawler(?).rimMaterial")
	v2:setXMLSpecializationType()
	local v3 = XMLSchema.new("crawler")
	v3:shareDelayedRegistrationFuncs(v2)
	v3:register(XMLValueType.STRING, "crawler.file#name", "Crawler i3d filename")
	v3:register(XMLValueType.NODE_INDEX, "crawler.file#leftNode", "Crawler left node in i3d")
	v3:register(XMLValueType.NODE_INDEX, "crawler.file#rightNode", "Crawler right node in i3d")
	v3:register(XMLValueType.NODE_INDEX, "crawler.scrollerNodes.scrollerNode(?)#node", "Scroller node")
	v3:register(XMLValueType.FLOAT, "crawler.scrollerNodes.scrollerNode(?)#scrollSpeed", "Scroll speed", 1)
	v3:register(XMLValueType.FLOAT, "crawler.scrollerNodes.scrollerNode(?)#scrollLength", "Scroll length", 1)
	v3:register(XMLValueType.STRING, "crawler.scrollerNodes.scrollerNode(?)#shaderParameterName", "Shader parameter name", "offsetUV")
	v3:register(XMLValueType.STRING, "crawler.scrollerNodes.scrollerNode(?)#shaderParameterNamePrev", "Shader parameter name (Prev)", "#shaderParameterName prefixed with \'prev\'")
	v3:register(XMLValueType.INT, "crawler.scrollerNodes.scrollerNode(?)#shaderParameterComponent", "Shader paramater component", 1)
	v3:register(XMLValueType.FLOAT, "crawler.scrollerNodes.scrollerNode(?)#maxSpeed", "Max. speed in m/s", "unlimited")
	v3:register(XMLValueType.FLOAT, "crawler.scrollerNodes.scrollerNode(?)#isTrackPart", "Is part of track (Track width is set as scale X)")
	v3:register(XMLValueType.NODE_INDEX, "crawler.rotatingParts.rotatingPart(?)#node", "Rotating node")
	v3:register(XMLValueType.FLOAT, "crawler.rotatingParts.rotatingPart(?)#radius", "Radius")
	v3:register(XMLValueType.FLOAT, "crawler.rotatingParts.rotatingPart(?)#speedScale", "Speed scale")
	v3:register(XMLValueType.NODE_INDEX, "crawler.dirtNodes.dirtNode(?)#node", "Nodes that act the same way as wheels and get dirty faster when on field. If not defined everything gets dirty faster.")
	v3:register(XMLValueType.BOOL, "crawler.animations.animation(?)#isLeft", "Load for left crawler", false)
	AnimatedVehicle.registerAnimationXMLPaths(v3, "crawler.animations.animation(?)")
	ObjectChangeUtil.registerObjectChangeSingleXMLPaths(v3, "crawler")
	Crawlers.xmlSchema = v3
end
function Crawlers.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "updateCrawler", Crawlers.updateCrawler)
	SpecializationUtil.registerFunction(p4, "loadCrawlerFromXML", Crawlers.loadCrawlerFromXML)
	SpecializationUtil.registerFunction(p4, "loadCrawlerFromConfigFile", Crawlers.loadCrawlerFromConfigFile)
	SpecializationUtil.registerFunction(p4, "onCrawlerI3DLoaded", Crawlers.onCrawlerI3DLoaded)
	SpecializationUtil.registerFunction(p4, "getCrawlerWheelMovedDistance", Crawlers.getCrawlerWheelMovedDistance)
end
function Crawlers.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "validateWashableNode", Crawlers.validateWashableNode)
end
function Crawlers.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", Crawlers)
	SpecializationUtil.registerEventListener(p6, "onLoadFinished", Crawlers)
	SpecializationUtil.registerEventListener(p6, "onDelete", Crawlers)
	SpecializationUtil.registerEventListener(p6, "onUpdate", Crawlers)
	SpecializationUtil.registerEventListener(p6, "onWheelConfigurationChanged", Crawlers)
end
function Crawlers.onLoad(p_u_7, _)
	local v8 = p_u_7.spec_crawlers
	local v9 = Utils.getNoNil(p_u_7.configurations.wheel, 1)
	local v10 = string.format("vehicle.wheels.wheelConfigurations.wheelConfiguration(%d)", v9 - 1)
	v8.crawlers = {}
	v8.sharedLoadRequestIds = {}
	v8.xmlLoadingHandles = {}
	p_u_7.xmlFile:iterate(v10 .. ".crawlers.crawler", function(_, p11)
		-- upvalues: (copy) p_u_7
		p_u_7:loadCrawlerFromXML(p_u_7.xmlFile, p11)
	end)
end
function Crawlers.onLoadFinished(p12, _)
	local v13 = p12.spec_crawlers
	if #v13.crawlers == 0 then
		SpecializationUtil.removeEventListener(p12, "onUpdate", Crawlers)
	else
		for _, v14 in ipairs(v13.crawlers) do
			if v14.rimMaterial ~= nil then
				v14.rimMaterial:apply(v14.loadedCrawler, "rim_inner_mat")
				v14.rimMaterial:apply(v14.loadedCrawler, "rim_outer_mat")
			end
			p12:updateCrawler(v14, 999)
		end
	end
end
function Crawlers.onDelete(p15)
	local v16 = p15.spec_crawlers
	if v16.xmlLoadingHandles ~= nil then
		for v17, _ in pairs(v16.xmlLoadingHandles) do
			v17:delete()
			v16.xmlLoadingHandles[v17] = nil
		end
	end
	if v16.crawlers ~= nil then
		for _, v18 in pairs(v16.crawlers) do
			if v18.shallowWaterObstacle ~= nil then
				g_currentMission.shallowWaterSimulation:removeObstacle(v18.shallowWaterObstacle)
				v18.shallowWaterObstacle = nil
			end
		end
	end
	if v16.sharedLoadRequestIds ~= nil then
		for _, v19 in ipairs(v16.sharedLoadRequestIds) do
			g_i3DManager:releaseSharedI3DFile(v19)
		end
		v16.sharedLoadRequestIds = nil
	end
end
function Crawlers.onUpdate(p20, p21, _, _, _)
	local v22 = p20.spec_crawlers
	for _, v23 in pairs(v22.crawlers) do
		p20:updateCrawler(v23, p21)
	end
end
function Crawlers.onWheelConfigurationChanged(p24)
	local v25 = p24.spec_crawlers
	for _, v26 in pairs(v25.crawlers) do
		local v27 = p24:getWashableNodeByCustomIndex(v26)
		if v27 ~= nil then
			p24:setNodeDirtAmount(v27, 0, true)
		end
	end
end
function Crawlers.updateCrawler(p28, p29, _)
	p29.movedDistance = 0
	if p29.speedReferenceNode == nil then
		p29.movedDistance = p28:getCrawlerWheelMovedDistance(p29, "lastRotationScroll", false)
	else
		local v30, v31, v32 = getWorldTranslation(p29.speedReferenceNode)
		if p29.lastPosition == nil then
			p29.lastPosition = { v30, v31, v32 }
		end
		local v33, v34, v35 = worldDirectionToLocal(p29.speedReferenceNode, v30 - p29.lastPosition[1], v31 - p29.lastPosition[2], v32 - p29.lastPosition[3])
		local v36 = v35 > 0.0001 and 1 or (v35 < -0.0001 and -1 or 0)
		p29.movedDistance = MathUtil.vector3Length(v33, v34, v35) * v36
		p29.lastPosition[1] = v30
		p29.lastPosition[2] = v31
		p29.lastPosition[3] = v32
	end
	for _, v37 in pairs(p29.scrollerNodes) do
		local v38 = p29.movedDistance * v37.scrollSpeed
		local v39 = math.sign(v38)
		local v40 = math.abs(v38)
		local v41 = v37.maxSpeed
		local v42 = math.min(v40, v41) * v39
		v37.scrollPosition = (v37.scrollPosition + v42) % v37.scrollLength
		for _, v43 in pairs(v37.nodes) do
			local v44, v45, v46, v47 = getShaderParameter(v43, v37.shaderParameterName)
			if v37.shaderParameterComponent == 1 then
				v44 = v37.scrollPosition
			else
				v45 = v37.scrollPosition
			end
			if v37.shaderParameterNamePrev == nil then
				setShaderParameter(v43, v37.shaderParameterName, v44, v45, v46, v47, false)
			else
				g_animationManager:setPrevShaderParameter(v43, v37.shaderParameterName, v44, v45, v46, v47, false, v37.shaderParameterNamePrev)
			end
		end
	end
	local v48 = p28:getCrawlerWheelMovedDistance(p29, "lastRotationRot", true)
	for _, v49 in pairs(p29.rotatingParts) do
		if p29.wheel == nil or v49.speedScale ~= nil then
			if v49.speedScale ~= nil then
				rotate(v49.node, v49.speedScale * p29.movedDistance, 0, 0)
			end
		else
			rotate(v49.node, v48, 0, 0)
		end
	end
	if p29.referenceNode ~= nil and p28.currentUpdateDistance < Crawlers.MAX_UPDATE_DISTANCE_ALIGNMENT then
		setWorldTranslation(p29.linkNode, getWorldTranslation(p29.positionReferenceNode))
		local v50, v51, v52 = getWorldTranslation(p29.loadedCrawler)
		local v53, v54, v55 = getWorldTranslation(p29.referenceNode)
		local v56, v57, v58 = MathUtil.vector3Normalize(v53 - v50, v54 - v51, v55 - v52)
		local v59, v60, v61 = localDirectionToWorld(p29.linkNode, 0, 1, 0)
		setWorldDirection(p29.loadedCrawler, v56, v57, v58, v59, v60, v61)
	end
end
function Crawlers.loadCrawlerFromXML(p62, p63, p64)
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#crawlerIndex", "Moved to external crawler config file")
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#length", "Moved to external crawler config file")
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#shaderParameterComponent", "Moved to external crawler config file")
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#shaderParameterName", "Moved to external crawler config file")
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#scrollLength", "Moved to external crawler config file")
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#scrollSpeed", "Moved to external crawler config file")
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#index", "Moved to external crawler config file")
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. ".rotatingPart", "Moved to external crawler config file")
	local v65 = {
		["vehicle"] = p62,
		["wheels"] = {}
	}
	XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#linkIndex", p64 .. "#linkNode")
	local v66 = p63:getValue(p64 .. "#linkNode", nil, p62.components, p62.i3dMappings)
	local v67 = p63:getValue(p64 .. "#linkWheelNodes", nil, p62.components, p62.i3dMappings, true)
	if v67 ~= nil then
		local v68 = #v67
		if v68 == 2 then
			local v69 = p62:getWheelByWheelNode(v67[1])
			local v70 = p62:getWheelByWheelNode(v67[2])
			if v69 == nil or v70 == nil then
				Logging.xmlWarning(p62.xmlFile, "Unknown link wheel nodes found in \'%s\'", p64)
			else
				if v66 == nil then
					v66 = createTransformGroup("crawlerLinkNode")
				end
				link(v69.repr, v66)
				setWorldTranslation(v66, getWorldTranslation(v69.driveNode))
				setWorldRotation(v66, getWorldRotation(v69.driveNode))
				v65.positionReferenceNode = v69.driveNode
				v65.referenceNode = v70.driveNode
				local v71 = v65.wheels
				table.insert(v71, {
					["wheel"] = v69
				})
				local v72 = v65.wheels
				table.insert(v72, {
					["wheel"] = v70
				})
			end
		elseif v68 ~= 0 then
			Logging.xmlWarning(p62.xmlFile, "The \'linkWheelNodes\' attribute in crawlers requires exactly two nodes! \'%s\'", p64)
		end
	end
	if v66 == nil then
		Logging.xmlWarning(p62.xmlFile, "Missing link node for crawler \'%s\'", p64)
	else
		v65.linkNode = v66
		v65.isLeft = p63:getValue(p64 .. "#isLeft", false)
		v65.trackWidth = p63:getValue(p64 .. "#trackWidth", 1)
		v65.translationOffset = p63:getValue(p64 .. "#offset", "0 0 0", true)
		XMLUtil.checkDeprecatedXMLElements(p63, p64 .. "#speedRefWheel", p64 .. "#wheelIndex")
		local v73 = p63:getValue(p64 .. "#wheelIndex")
		local v74 = p63:getValue(p64 .. "#wheelIndices", nil, true)
		local v75 = p63:getValue(p64 .. "#wheelNodes", nil, p62.components, p62.i3dMappings, true)
		if v73 ~= nil or (v74 ~= nil or #v75 > 0) then
			if v73 ~= nil then
				v74 = v74 or {}
				table.insert(v74, v73)
			end
			if v74 ~= nil then
				for _, v76 in ipairs(v74) do
					local v77 = p62:getWheelFromWheelIndex(v76)
					if v77 ~= nil then
						local v78 = v65.wheels
						table.insert(v78, {
							["wheel"] = v77
						})
					end
				end
			end
			if v75 ~= nil then
				for _, v79 in ipairs(v75) do
					local v80 = p62:getWheelByWheelNode(v79)
					if v80 ~= nil then
						local v81 = v65.wheels
						table.insert(v81, {
							["wheel"] = v80
						})
					end
				end
			end
		end
		local v82 = #v65.wheels
		if v82 > 0 then
			local v83 = 0
			for _, v84 in ipairs(v65.wheels) do
				for _, v85 in ipairs(v65.wheels) do
					if v84 ~= v85 then
						local v86 = calcDistanceFrom(v84.wheel.driveNode, v85.wheel.driveNode)
						v83 = math.max(v83, v86)
					end
				end
			end
			for v87, v88 in ipairs(v65.wheels) do
				v88.wheel.syncContactState = true
				v88.wheel.transRatio = 1
				if v88.wheel.physics.showSteeringAngle == nil then
					v88.wheel.physics.showSteeringAngle = false
				end
				local v89 = false
				if v82 > 1 then
					if v87 == 1 then
						v88.wheel.effects.waterParticleDirection = -1
						v89 = true
					elseif v87 == 2 then
						v88.wheel.effects.waterParticleDirection = 1
						v89 = true
					end
					local v90 = v88.wheel.effects
					local v91 = v83 * 0.5
					v90.waterEffectReferenceRadius = math.min(v91, 1)
				else
					v89 = true
				end
				if v89 then
					if v88.wheel.effects.hasWaterParticles == nil then
						v88.wheel.effects:addWaterEffectsToPhysicsData()
					end
				else
					v88.wheel.effects:removeWaterEffects()
				end
				if not v88.wheel.physics.isSynchronized then
					Logging.xmlWarning(p62.xmlFile, "Wheel \'%s\' for crawler \'%s\' in not synchronized! It won\'t rotate on the client side.", getName(v88.wheel.repr), p64)
				end
			end
			v65.wheel = v65.wheels[1].wheel
			v65.hasShallowWaterObstacle = p63:getValue(p64 .. "#hasShallowWaterObstacle", true)
			if v65.hasShallowWaterObstacle and p62.propertyState ~= VehiclePropertyState.SHOP_CONFIG then
				local v92 = (1 / 0)
				local v93 = (1 / 0)
				local v94 = (1 / 0)
				local v95 = (-1 / 0)
				local v96 = (-1 / 0)
				local v97 = (-1 / 0)
				for _, v98 in ipairs(v65.wheels) do
					local v99 = v98.wheel
					local v100, v101, v102 = localToLocal(v99.driveNode, v66, v99.physics.wheelShapeWidth * 0.5 + v99.physics.wheelShapeWidthOffset, v99.physics.radius, v99.physics.radius)
					local v103, v104, v105 = localToLocal(v99.driveNode, v66, -(v99.physics.wheelShapeWidth * 0.5 - v99.physics.wheelShapeWidthOffset), -v99.physics.radius, -v99.physics.radius)
					v92 = math.min(v92, v100, v103)
					v93 = math.min(v93, v101, v104)
					v94 = math.min(v94, v102, v105)
					v95 = math.max(v95, v100, v103)
					v96 = math.max(v96, v101, v104)
					v97 = math.max(v97, v102, v105)
				end
				local v106 = v95 - v92
				local v107 = v96 - v93
				local v108 = v97 - v94
				local v109 = { (v92 + v95) * 0.5, (v93 + v96) * 0.5, (v94 + v97) * 0.5 }
				v65.shallowWaterObstacle = g_currentMission.shallowWaterSimulation:addObstacle(v66, v106, v107, v108, Crawlers.getShallowWaterParameters, v65, v109)
			end
		end
		XMLUtil.checkDeprecatedXMLElements(p62.xmlFile, p62.configFileName, p64 .. "#speedRefNode", p64 .. "#speedReferenceNode")
		v65.speedReferenceNode = p63:getValue(p64 .. "#speedReferenceNode", nil, p62.components, p62.i3dMappings)
		v65.movedDistance = 0
		v65.fieldDirtMultiplier = p63:getValue(p64 .. "#fieldDirtMultiplier", 75)
		v65.streetDirtMultiplier = p63:getValue(p64 .. "#streetDirtMultiplier", -150)
		v65.waterWetnessFactor = p63:getValue(p64 .. "#waterWetnessFactor", 20)
		v65.minDirtPercentage = p63:getValue(p64 .. "#minDirtPercentage", 0.35)
		v65.maxDirtOffset = p63:getValue(p64 .. "#maxDirtOffset", 0.5)
		v65.dirtColorChangeSpeed = 1 / (p63:getValue(p64 .. "#dirtColorChangeSpeed", 20) * 1000)
		local v110 = VehicleMaterial.new(p62.baseDirectory)
		if v110:loadFromXML(p63, p64 .. ".rimMaterial", p62.customEnvironment) then
			v65.rimMaterial = v110
		end
		p62:loadCrawlerFromConfigFile(v65, p63:getValue(p64 .. "#filename"), v66)
	end
end
function Crawlers.loadCrawlerFromConfigFile(p111, p112, p113, _)
	local v114 = Utils.getFilename(p113, p111.baseDirectory)
	local v115 = XMLFile.load("crawlerXml", v114, Crawlers.xmlSchema)
	if v115 == nil then
		Logging.xmlWarning(p111.xmlFile, "Failed to open crawler config file \'%s\'", v114)
		return
	else
		local v116 = v115:getValue("crawler.file#name")
		if v116 == nil then
			Logging.xmlWarning(v115, "Failed to open crawler i3d file \'%s\' in \'%s\'", v116, v114)
			v115:delete()
		else
			local v117 = p111.spec_crawlers
			v117.xmlLoadingHandles[v115] = true
			p112.filename = Utils.getFilename(v116, p111.baseDirectory)
			local v118 = p111:loadSubSharedI3DFile(p112.filename, false, false, p111.onCrawlerI3DLoaded, p111, {
				["xmlFile"] = v115,
				["crawler"] = p112
			})
			local v119 = v117.sharedLoadRequestIds
			table.insert(v119, v118)
		end
	end
end
function Crawlers.onCrawlerI3DLoaded(p120, p121, _, p122)
	local v123 = p122.xmlFile
	local v124 = p122.crawler
	local v125 = p120.spec_crawlers
	if p121 == 0 then
		if not (p120.isDeleted or p120.isDeleting) then
			Logging.xmlWarning(v123, "Failed to find crawler in i3d file \'%s\'", v124.filename)
		end
	else
		v124.loadedCrawler = v123:getValue("crawler.file#" .. (v124.isLeft and "leftNode" or "rightNode"), nil, p121)
		if v124.loadedCrawler ~= nil then
			link(v124.linkNode, v124.loadedCrawler)
			if v124.translationOffset ~= nil then
				local v126 = setTranslation
				local v127 = v124.loadedCrawler
				local v128 = v124.translationOffset
				v126(v127, unpack(v128))
			end
			v124.scrollerNodes = {}
			local v129 = 0
			while true do
				local v130 = string.format("crawler.scrollerNodes.scrollerNode(%d)", v129)
				if not v123:hasProperty(v130) then
					break
				end
				local v131 = {
					["node"] = v123:getValue(v130 .. "#node", nil, v124.loadedCrawler)
				}
				if v131.node ~= nil then
					v131.scrollSpeed = v123:getValue(v130 .. "#scrollSpeed", 1)
					v131.scrollLength = v123:getValue(v130 .. "#scrollLength", 1)
					v131.shaderParameterName = v123:getValue(v130 .. "#shaderParameterName", "offsetUV")
					v131.shaderParameterNamePrev = v123:getValue(v130 .. "#shaderParameterNamePrev")
					if v131.shaderParameterNamePrev == nil then
						local v132 = "prev" .. v131.shaderParameterName:sub(1, 1):upper() .. v131.shaderParameterName:sub(2)
						if getHasShaderParameter(v131.node, v132) then
							v131.shaderParameterNamePrev = v132
						end
					elseif not getHasShaderParameter(v131.node, v131.shaderParameterNamePrev) then
						Logging.xmlWarning(v123, "Node \'%s\' has no shader parameter \'%s\' (prev) for crawler node \'%s\'!", getName(v131.node), v131.shaderParameterNamePrev, v130)
						return
					end
					v131.nodes = {}
					I3DUtil.getNodesByShaderParam(v124.loadedCrawler, v131.shaderParameterName, v131.nodes)
					v131.shaderParameterComponent = v123:getValue(v130 .. "#shaderParameterComponent", 1)
					v131.maxSpeed = v123:getValue(v130 .. "#maxSpeed", (1 / 0)) / 1000
					v131.scrollPosition = 0
					if v124.trackWidth ~= 1 and v123:getValue(v130 .. "#isTrackPart", true) then
						setScale(v131.node, v124.trackWidth, 1, 1)
					end
					local v133 = v124.scrollerNodes
					table.insert(v133, v131)
				end
				v129 = v129 + 1
			end
			v124.rotatingParts = {}
			local v134 = 0
			while true do
				local v135 = string.format("crawler.rotatingParts.rotatingPart(%d)", v134)
				if not v123:hasProperty(v135) then
					break
				end
				local v136 = {
					["node"] = v123:getValue(v135 .. "#node", nil, v124.loadedCrawler)
				}
				if v136.node ~= nil then
					v136.radius = v123:getValue(v135 .. "#radius")
					v136.speedScale = v123:getValue(v135 .. "#speedScale")
					if v136.speedScale == nil and v136.radius ~= nil then
						v136.speedScale = 1 / v136.radius
					end
					local v137 = v124.rotatingParts
					table.insert(v137, v136)
				end
				v134 = v134 + 1
			end
			v124.hasDirtNodes = false
			v124.dirtNodes = {}
			local v138 = 0
			while true do
				local v139 = string.format("crawler.dirtNodes.dirtNode(%d)", v138)
				if not v123:hasProperty(v139) then
					break
				end
				local v140 = v123:getValue(v139 .. "#node", nil, v124.loadedCrawler)
				if v140 ~= nil then
					v124.dirtNodes[v140] = v140
					v124.hasDirtNodes = true
				end
				v138 = v138 + 1
			end
			v124.objectChanges = {}
			ObjectChangeUtil.loadObjectChangeFromXML(v123, "crawler", v124.objectChanges, v124.loadedCrawler, p120)
			ObjectChangeUtil.setObjectChanges(v124.objectChanges, true)
			local v141 = 0
			while true do
				local v142 = string.format("crawler.animations.animation(%d)", v141)
				if not v123:hasProperty(v142) then
					break
				end
				if v124.isLeft == v123:getValue(v142 .. "#isLeft", false) then
					local v143 = {}
					if p120:loadAnimation(v123, v142, v143, v124.loadedCrawler) then
						p120.spec_animatedVehicle.animations[v143.name] = v143
					end
				end
				v141 = v141 + 1
			end
			local v144 = p120.spec_crawlers.crawlers
			table.insert(v144, v124)
		end
		delete(p121)
	end
	v123:delete()
	v125.xmlLoadingHandles[v123] = nil
end
function Crawlers.getCrawlerWheelMovedDistance(_, p145, p146, p147)
	local v148 = (1 / 0)
	local v149 = 1
	for v150 = 1, #p145.wheels do
		local v151 = p145.wheels[v150]
		if v151.wheel.physics.contact ~= WheelContactType.NONE or #p145.wheels == 1 then
			local v152, _, _ = getRotation(v151.wheel.driveNode)
			if v151[p146] == nil then
				v151[p146] = v152
			end
			local v153 = v151[p146]
			if v152 - v153 < -3.141592653589793 then
				v153 = v153 - 6.283185307179586
			elseif v152 - v153 > 3.141592653589793 then
				v153 = v153 + 6.283185307179586
			end
			local v154 = v151.wheel.physics.radius * (v152 - v153)
			local v155 = v151.wheel.physics.steeringAngle
			if math.abs(v155) > 1.5707963267948966 then
				v154 = -v154
			end
			if p147 then
				v154 = v152 - v153
			end
			if v154 < 0 then
				if -v148 < v154 then
					v148 = -v154
					v149 = -1
				end
			elseif v154 < v148 then
				v148 = v154
				v149 = 1
			end
			v151[p146] = v152
		end
	end
	return v148 == (1 / 0) and 0 or v148 * v149
end
function Crawlers.validateWashableNode(p_u_156, p157, p158)
	local v159 = p_u_156.spec_crawlers
	for _, v_u_160 in pairs(v159.crawlers) do
		if v_u_160.wheel ~= nil then
			local v161 = v_u_160.dirtNodes
			if not v_u_160.hasDirtNodes then
				I3DUtil.getNodesByShaderParam(v_u_160.loadedCrawler, "scratches_dirt_snow_wetness", v161)
			end
			if v_u_160.crawlerMudMeshes == nil then
				v_u_160.crawlerMudMeshes = {}
				I3DUtil.getNodesByShaderParam(v_u_160.loadedCrawler, "mudAmount", v_u_160.crawlerMudMeshes)
			end
			if v161[p158] ~= nil then
				local v_u_171 = {
					["wheel"] = v_u_160.wheel,
					["fieldDirtMultiplier"] = v_u_160.fieldDirtMultiplier,
					["streetDirtMultiplier"] = v_u_160.streetDirtMultiplier,
					["minDirtPercentage"] = v_u_160.minDirtPercentage,
					["maxDirtOffset"] = v_u_160.maxDirtOffset,
					["dirtColorChangeSpeed"] = v_u_160.dirtColorChangeSpeed,
					["waterWetnessFactor"] = v_u_160.waterWetnessFactor,
					["isSnowNode"] = true,
					["loadFromSavegameFunc"] = function(p162, p163)
						-- upvalues: (copy) v_u_171, (copy) p_u_156, (copy) v_u_160
						v_u_171.wheel.physics.snowScale = p162:getValue(p163 .. "#snowScale", 0)
						local v164, v165 = g_currentMission.environment:getDirtColors()
						local v166, v167, v168 = MathUtil.vector3ArrayLerp(v164, v165, v_u_171.wheel.physics.snowScale)
						p_u_156:setNodeDirtColor(p_u_156:getWashableNodeByCustomIndex(v_u_160), v166, v167, v168, true)
					end,
					["saveToSavegameFunc"] = function(p169, p170)
						-- upvalues: (copy) v_u_171
						p169:setValue(p170 .. "#snowScale", v_u_171.wheel.physics.snowScale)
					end
				}
				return false, p_u_156.updateWheelDirtAmount, v_u_160, v_u_171
			end
			if v_u_160.crawlerMudMeshes[p158] ~= nil then
				local v172 = {
					["wheel"] = v_u_160.wheel,
					["fieldDirtMultiplier"] = v_u_160.fieldDirtMultiplier,
					["streetDirtMultiplier"] = v_u_160.streetDirtMultiplier,
					["minDirtPercentage"] = v_u_160.minDirtPercentage,
					["maxDirtOffset"] = v_u_160.maxDirtOffset,
					["dirtColorChangeSpeed"] = v_u_160.dirtColorChangeSpeed,
					["waterWetnessFactor"] = v_u_160.waterWetnessFactor,
					["isSnowNode"] = true,
					["cleaningMultiplier"] = 4
				}
				return false, p_u_156.updateWheelMudAmount, v_u_160.crawlerMudMeshes, v172
			end
		end
	end
	return p157(p_u_156, p158)
end
function Crawlers.getVRamUsageFromXML(p_u_173)
	if not p_u_173:hasProperty("vehicle.wheels") then
		return 0, 0
	end
	local v_u_174 = nil
	p_u_173:iterate("vehicle.wheels.wheelConfigurations.wheelConfiguration", function(_, p175)
		-- upvalues: (copy) p_u_173, (ref) v_u_174
		local v176 = p175 .. ".crawlers"
		if p_u_173:hasProperty(v176) then
			v_u_174 = v176
			return false
		end
	end)
	if v_u_174 == nil then
		return 0, 0
	end
	local v_u_177 = 0
	local v_u_178 = {}
	p_u_173:iterate(v_u_174 .. ".crawler", function(_, p179)
		-- upvalues: (copy) p_u_173, (copy) v_u_178, (ref) v_u_177
		local v180 = p_u_173:getString(p179 .. "#filename")
		if v180 ~= nil and v_u_178[v180] == nil then
			v_u_177 = v_u_177 + 1
			v_u_178[v180] = true
		end
	end)
	return v_u_177 * Crawlers.VRAM_PER_CRAWLER, 0
end
function Crawlers.getShallowWaterParameters(p181)
	local v182 = p181.vehicle.lastSignedSpeed * 1000
	local v183 = 0
	local v184 = 0
	if p181.wheel.physics ~= nil then
		local v185 = p181.wheel.physics.netInfo.slip
		if v185 > 0.1 then
			v183 = math.random() * 2 - 1 * v185
			v184 = math.random() * 2 - 1 * v185
		end
	end
	if v183 == 0 and math.abs(v182) > 0.27 then
		v183 = math.random() * 2 - 1
		v184 = math.random() * 2 - 1
	end
	local v186, _, v187 = localDirectionToWorld(p181.linkNode, 0, 0, 1)
	local v188 = MathUtil.getYRotationFromDirection(v186, v187)
	local v189 = v186 * v182
	local v190 = v187 * v182
	return v189 + v183, v190 + v184, v188
end

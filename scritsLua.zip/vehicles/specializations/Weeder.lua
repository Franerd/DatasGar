Weeder = {}
function Weeder.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("weeder", true, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Weeder")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.weeder.sounds", "work(?)")
	v1:register(XMLValueType.BOOL, "vehicle.weeder#isHoe", "Is hoe weeder", false)
	v1:register(XMLValueType.BOOL, "vehicle.weeder#isGrasslandWeeder", "Is a grassland weeder (grass fertilizer state + grass growth reset)", false)
	v1:register(XMLValueType.BOOL, WorkParticles.PARTICLE_MAPPING_XML_PATH .. "#adjustColor", "Adjust color", false)
	v1:setXMLSpecializationType()
end
function Weeder.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(WorkArea, p2)
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(AttacherJoints, p2)
	end
	return v3
end
function Weeder.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "processWeederArea", Weeder.processWeederArea)
	SpecializationUtil.registerFunction(p4, "updateWeederAIRequirements", Weeder.updateWeederAIRequirements)
end
function Weeder.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", Weeder.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDirtMultiplier", Weeder.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", Weeder.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadWorkAreaFromXML", Weeder.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsWorkAreaActive", Weeder.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadGroundParticleMapping", Weeder.loadGroundParticleMapping)
end
function Weeder.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", Weeder)
	SpecializationUtil.registerEventListener(p6, "onDelete", Weeder)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", Weeder)
	SpecializationUtil.registerEventListener(p6, "onDeactivate", Weeder)
	SpecializationUtil.registerEventListener(p6, "onPostAttach", Weeder)
	SpecializationUtil.registerEventListener(p6, "onStartWorkAreaProcessing", Weeder)
	SpecializationUtil.registerEventListener(p6, "onEndWorkAreaProcessing", Weeder)
	SpecializationUtil.registerEventListener(p6, "onStateChange", Weeder)
end
function Weeder.onLoad(p7, _)
	local v8 = p7.spec_weeder
	if p7.isClient then
		v8.samples = {}
		v8.samples.work = g_soundManager:loadSamplesFromXML(p7.xmlFile, "vehicle.weeder.sounds", "work", p7.baseDirectory, p7.components, 0, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.isWorkSamplePlaying = false
	end
	v8.startActivationTimeout = 2000
	v8.startActivationTime = 0
	v8.isHoeWeeder = p7.xmlFile:getValue("vehicle.weeder#isHoe", false)
	v8.isGrasslandWeeder = p7.xmlFile:getValue("vehicle.weeder#isGrasslandWeeder", false)
	v8.workAreaParameters = {}
	v8.workAreaParameters.lastArea = 0
	v8.workAreaParameters.lastStatsArea = 0
	v8.isWorking = false
	v8.stoneLastState = 0
	v8.stoneWearMultiplierData = g_currentMission.stoneSystem:getWearMultiplierByType("WEEDER")
	p7:updateWeederAIRequirements()
end
function Weeder.onDelete(p9)
	local v10 = p9.spec_weeder
	if v10.samples ~= nil then
		g_soundManager:deleteSamples(v10.samples.work)
	end
end
function Weeder.onUpdateTick(p11, p12, _, _, _)
	local v13 = p11.spec_weeder
	if v13.isWorking and v13.colorParticleSystems ~= nil then
		for _, v14 in ipairs(v13.colorParticleSystems) do
			local v15, v16, v17 = getWorldTranslation(v14.node)
			local v18, v19 = FSDensityMapUtil.getFieldDataAtWorldPosition(v15, v16, v17)
			if v18 then
				local v20 = v14.lastColor
				local v21 = v14.lastColor
				local v22 = v14.lastColor
				local v23, v24, v25, _ = g_currentMission.fieldGroundSystem:getFieldGroundTyreTrackColor(v19)
				v20[1] = v23
				v21[2] = v24
				v22[3] = v25
			else
				local v26 = v14.lastColor
				local v27 = v14.lastColor
				local v28 = v14.lastColor
				local v29, v30, v31, _, _ = getTerrainAttributesAtWorldPos(g_terrainNode, v15, v16, v17, true, true, true, true, false)
				v26[1] = v29
				v27[2] = v30
				v28[3] = v31
			end
			if v14.targetColor == nil then
				v14.targetColor = { v14.lastColor[1], v14.lastColor[2], v14.lastColor[3] }
				v14.currentColor = { v14.lastColor[1], v14.lastColor[2], v14.lastColor[3] }
				v14.alpha = 1
			end
			if v14.alpha ~= 1 then
				local v32 = v14.alpha + p12 / 1000
				v14.alpha = math.min(v32, 1)
				v14.currentColor = { MathUtil.vector3ArrayLerp(v14.lastColor, v14.targetColor, v14.alpha) }
				if v14.alpha == 1 then
					v14.lastColor = { v14.currentColor[1], v14.currentColor[2], v14.currentColor[3] }
				end
			end
			if v14.alpha == 1 and (v14.lastColor[1] ~= v14.targetColor[1] and (v14.lastColor[2] ~= v14.targetColor[2] and v14.lastColor[3] ~= v14.targetColor[3])) then
				v14.alpha = 0
				v14.targetColor = { v14.lastColor[1], v14.lastColor[2], v14.lastColor[3] }
			end
			setShaderParameter(v14.particleSystem.shape, "psColor", v14.currentColor[1], v14.currentColor[2], v14.currentColor[3], 1, false)
		end
	end
end
function Weeder.processWeederArea(p33, p34, _)
	local v35 = p33.spec_weeder
	local v36, _, v37 = getWorldTranslation(p34.start)
	local v38, _, v39 = getWorldTranslation(p34.width)
	local v40, _, v41 = getWorldTranslation(p34.height)
	local v42 = FSDensityMapUtil.updateWeederArea(v36, v37, v38, v39, v40, v41, v35.isHoeWeeder)
	if v35.isGrasslandWeeder then
		local v43 = FSDensityMapUtil.updateGrassRollerArea(v36, v37, v38, v39, v40, v41, false)
		v42 = math.max(v42, v43)
	end
	v35.workAreaParameters.lastArea = v35.workAreaParameters.lastArea + v42
	v35.workAreaParameters.lastStatsArea = v35.workAreaParameters.lastStatsArea + v42
	v35.isWorking = p33:getLastSpeed() > 0.5
	if v35.isWorking then
		v35.stoneLastState = FSDensityMapUtil.getStoneArea(v36, v37, v38, v39, v40, v41)
	else
		v35.stoneLastState = 0
	end
	return v42, v42
end
function Weeder.updateWeederAIRequirements(p44)
	local v45 = p44.spec_weeder
	if p44.addAITerrainDetailRequiredRange ~= nil then
		local v46 = p44.rootVehicle:getChildVehicles()
		local v47 = false
		for v48 = 1, #v46 do
			if SpecializationUtil.hasSpecialization(SowingMachine, v46[v48].specializations) and v46[v48]:getUseSowingMachineAIRequirements() then
				v47 = true
			end
		end
		p44:clearAIFruitRequirements()
		if not v47 then
			local v49 = g_currentMission.weedSystem
			if v49 ~= nil then
				local v50, v51, v52 = v49:getDensityMapData()
				local v53 = v49:getWeederReplacements(v45.isHoeWeeder)
				if v53.weed ~= nil then
					local v54 = -1
					local v55 = -1
					for v56, _ in pairs(v53.weed.replacements) do
						if v54 == -1 then
							v54 = v56
						elseif v56 ~= v55 + 1 then
							p44:addAIFruitRequirement(nil, v54, v55, v50, v51, v52)
							v54 = v56
						end
						v55 = v56
					end
					if v54 ~= -1 then
						p44:addAIFruitRequirement(nil, v54, v55, v50, v51, v52)
					end
				end
			end
			if v45.isGrasslandWeeder then
				local v57 = g_fruitTypeManager:getFruitTypeByIndex(FruitType.GRASS)
				if v57.terrainDataPlaneId ~= nil then
					p44:addAIFruitRequirement(v57.index, 2, v57.cutState + 1)
				end
			end
		end
	end
end
function Weeder.loadWorkAreaFromXML(p58, p59, p60, p61, p62)
	if p60.type == WorkAreaType.DEFAULT then
		p60.type = WorkAreaType.WEEDER
	end
	return p59(p58, p60, p61, p62)
end
function Weeder.getIsWorkAreaActive(p63, p64, p65)
	if p65.type ~= WorkAreaType.WEEDER then
		return p64(p63, p65)
	end
	local v66 = true
	if p65.requiresGroundContact and p65.groundReferenceNode ~= nil then
		if v66 then
			v66 = p63:getIsGroundReferenceNodeActive(p65.groundReferenceNode)
		end
	end
	if v66 and p65.disableBackwards then
		if v66 then
			v66 = p63.movingDirection > 0
		end
	end
	return v66
end
function Weeder.doCheckSpeedLimit(p67, p68)
	return p68(p67) or p67:getIsImplementChainLowered()
end
function Weeder.getDirtMultiplier(p69, p70)
	local v71 = p69.spec_weeder
	local v72 = p70(p69)
	if v71.isWorking then
		v72 = v72 + p69:getWorkDirtMultiplier() * p69:getLastSpeed() / p69.speedLimit
	end
	return v72
end
function Weeder.getWearMultiplier(p73, p74)
	local v75 = p73.spec_weeder
	local v76 = p74(p73)
	if v75.isWorking then
		local v77 = (v75.stoneLastState == 0 or v75.stoneWearMultiplierData == nil) and 1 or (v75.stoneWearMultiplierData[v75.stoneLastState] or 1)
		v76 = v76 + p73:getWorkWearMultiplier() * p73:getLastSpeed() / p73.speedLimit * v77
	end
	return v76
end
function Weeder.loadGroundParticleMapping(p78, p79, p80, p81, p82, p83, p84)
	if not p79(p78, p80, p81, p82, p83, p84) then
		return false
	end
	p82.adjustColor = p80:getValue(p81 .. "#adjustColor", false)
	if p82.adjustColor then
		local v85 = p78.spec_weeder
		if v85.colorParticleSystems == nil then
			v85.colorParticleSystems = {}
		end
		p82.lastColor = {}
		local v86 = v85.colorParticleSystems
		table.insert(v86, p82)
	end
	return true
end
function Weeder.onStartWorkAreaProcessing(p87, _)
	local v88 = p87.spec_weeder
	v88.isWorking = false
	v88.workAreaParameters.lastArea = 0
	v88.workAreaParameters.lastStatsArea = 0
end
function Weeder.onEndWorkAreaProcessing(p89, _, _)
	local v90 = p89.spec_weeder
	if p89.isServer and v90.workAreaParameters.lastStatsArea > 0 then
		p89:updateLastWorkedArea(v90.workAreaParameters.lastStatsArea)
	end
	if p89.isClient then
		if v90.isWorking then
			if not v90.isWorkSamplePlaying then
				g_soundManager:playSamples(v90.samples.work)
				v90.isWorkSamplePlaying = true
				return
			end
		elseif v90.isWorkSamplePlaying then
			g_soundManager:stopSamples(v90.samples.work)
			v90.isWorkSamplePlaying = false
		end
	end
end
function Weeder.onStateChange(p91, p92, _)
	if p92 == VehicleStateChange.ATTACH or p92 == VehicleStateChange.DETACH then
		p91:updateWeederAIRequirements()
	end
end
function Weeder.onDeactivate(p93)
	if p93.isClient then
		local v94 = p93.spec_weeder
		g_soundManager:stopSamples(v94.samples.work)
		v94.isWorkSamplePlaying = false
	end
end
function Weeder.onPostAttach(p95, _, _, _)
	local v96 = p95.spec_weeder
	v96.startActivationTime = g_currentMission.time + v96.startActivationTimeout
end
function Weeder.getDefaultSpeedLimit()
	return 15
end

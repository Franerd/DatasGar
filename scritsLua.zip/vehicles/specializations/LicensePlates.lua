LicensePlates = {}
function LicensePlates.prerequisitesPresent(_)
	return true
end
function LicensePlates.initSpecialization()
	g_storeManager:addSpecType("licensePlate", "shopListAttributeIconLicensePlate", LicensePlates.loadSpecValuePlateText, LicensePlates.getSpecValuePlateText, StoreSpecies.VEHICLE)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("LicensePlates")
	v1:register(XMLValueType.STRING, "vehicle.licensePlates#defaultPlacement", "Defines the default placement index independent of map setting (NONE|BOTH|BACK_ONLY)", false)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.licensePlates.licensePlate(?)#node", "License plate node")
	v1:register(XMLValueType.STRING, "vehicle.licensePlates.licensePlate(?)#preferedType", "Prefered license plate type to be placed if available")
	v1:register(XMLValueType.STRING, "vehicle.licensePlates.licensePlate(?)#placementArea", "Defines the available area around the node (top, right, bottom, left) (\'-\' means unlimited)")
	v1:register(XMLValueType.STRING, "vehicle.licensePlates.licensePlate(?)#position", "Position of license plate (\'FRONT\' or \'BACK\')", "ANY")
	v1:register(XMLValueType.BOOL, "vehicle.licensePlates.licensePlate(?)#frame", "License plate with frame of without frame", true)
	ObjectChangeUtil.registerObjectChangeXMLPaths(v1, "vehicle.licensePlates.licensePlate(?)")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).licensePlates#variation", "License plate variation", 1)
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).licensePlates#characters", "Characters string")
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).licensePlates#colorIndex", "Selected color index", 1)
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).licensePlates#placementIndex", "Selected placement index", 1)
end
function LicensePlates.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "setLicensePlatesData", LicensePlates.setLicensePlatesData)
	SpecializationUtil.registerFunction(p3, "getLicensePlatesData", LicensePlates.getLicensePlatesData)
	SpecializationUtil.registerFunction(p3, "getLicensePlatesDataIsEqual", LicensePlates.getLicensePlatesDataIsEqual)
	SpecializationUtil.registerFunction(p3, "getHasLicensePlates", LicensePlates.getHasLicensePlates)
	SpecializationUtil.registerFunction(p3, "getLicensePlateDialogSettings", LicensePlates.getLicensePlateDialogSettings)
end
function LicensePlates.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", LicensePlates)
	SpecializationUtil.registerEventListener(p4, "onDelete", LicensePlates)
	SpecializationUtil.registerEventListener(p4, "onPostLoad", LicensePlates)
	SpecializationUtil.registerEventListener(p4, "onReadStream", LicensePlates)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", LicensePlates)
end
function LicensePlates.onLoad(p5, _)
	local v6 = p5.spec_licensePlates
	v6.licensePlates = {}
	local v7 = p5.xmlFile:getValue("vehicle.licensePlates#defaultPlacement")
	if v7 ~= nil then
		v6.defaultPlacementIndex = LicensePlateManager.PLACEMENT_OPTION[v7:upper()]
		if v6.defaultPlacementIndex == nil then
			Logging.xmlWarning(p5.xmlFile, "Unknown defaultPlacement \'%s\' in \'vehicle.licensePlates#defaultPlacement", v7)
		end
	end
	if g_licensePlateManager:getAreLicensePlatesAvailable() then
		local v8 = 0
		while true do
			local v9 = string.format("vehicle.licensePlates.licensePlate(%d)", v8)
			if not p5.xmlFile:hasProperty(v9) then
				break
			end
			local v10 = {
				["node"] = p5.xmlFile:getValue(v9 .. "#node", nil, p5.components, p5.i3dMappings)
			}
			if v10.node ~= nil then
				local v11 = p5.xmlFile:getValue(v9 .. "#preferedType", "ELONGATED")
				v10.preferedType = LicensePlateManager.PLATE_TYPE[v11]
				if v10.preferedType == nil then
					Logging.xmlError(p5.xmlFile, "Unknown preferedType \'%s\' for license plate \'%s\'", v11, v9)
				else
					v10.placementArea = {
						1,
						1,
						1,
						1
					}
					local v12 = p5.xmlFile:getString(v9 .. "#placementArea")
					if v12 ~= nil then
						local v13 = string.split(v12, " ")
						if #v13 == 4 then
							for v14 = 1, 4 do
								if v13[v14] ~= "-" then
									local v15 = v13[v14]
									local v16 = tonumber(v15)
									if v16 == nil then
										Logging.xmlWarning(p5.xmlFile, "Invalid 4-vector \'%s\' for \'%s\'. \'%s\' is not a number!", v12, v9 .. "#placementArea", v13[v14])
									else
										v10.placementArea[v14] = v16
									end
								end
							end
						else
							Logging.xmlWarning(p5.xmlFile, "Invalid 4-vector \'%s\' for \'%s\' ", v12, v9 .. "#placementArea")
						end
					end
					local v17 = p5.xmlFile:getValue(v9 .. "#position", "ANY")
					v10.position = LicensePlateManager.PLATE_POSITION[v17] or LicensePlateManager.PLATE_POSITION.ANY
					local v18 = p5.xmlFile:getValue(v9 .. "#frame", true)
					v10.data = g_licensePlateManager:getLicensePlate(v10.preferedType, v18)
					if v10.data ~= nil then
						link(v10.node, v10.data.node)
						setTranslation(v10.data.node, 0, 0, 0)
						setRotation(v10.data.node, 0, 0, 0)
						setVisibility(v10.data.node, false)
						local v19 = v10.data.rawWidth * 0.5 + v10.data.widthOffsetLeft
						local v20 = v10.data.rawWidth * 0.5 + v10.data.widthOffsetRight
						local v21 = v10.data.rawHeight * 0.5 + v10.data.heightOffsetTop
						local v22 = v10.data.rawHeight * 0.5 + v10.data.heightOffsetBot
						local v23 = (v10.placementArea[2] + v10.placementArea[4]) / (v19 + v20)
						local v24 = (v10.placementArea[1] + v10.placementArea[3]) / (v21 + v22)
						local v25 = math.min(v23, v24)
						local v26 = math.clamp(v25, 0, 1)
						if v26 < 1 then
							setScale(v10.data.node, v26, v26, v26)
							v19 = v19 * v26
							v20 = v20 * v26
							v21 = v21 * v26
							v22 = v22 * v26
						end
						local v27 = v19 - v10.placementArea[2]
						local v28 = 0 - math.max(v27, 0)
						local v29 = v20 - v10.placementArea[4]
						local v30 = v28 + math.max(v29, 0)
						local v31 = v21 - v10.placementArea[1]
						local v32 = 0 - math.max(v31, 0)
						local v33 = v22 - v10.placementArea[3]
						local v34 = v32 + math.max(v33, 0)
						setTranslation(v10.data.node, v30, v34, 0)
						v10.changeObjects = {}
						ObjectChangeUtil.loadObjectChangeFromXML(p5.xmlFile, v9, v10.changeObjects, p5.components, p5)
						local v35 = v6.licensePlates
						table.insert(v35, v10)
					end
				end
			end
			v8 = v8 + 1
		end
		if p5:getHasLicensePlates() then
			v6.licensePlateData = {
				["variation"] = 1,
				["characters"] = nil,
				["colorIndex"] = nil
			}
			return
		end
	else
		ObjectChangeUtil.updateObjectChanges(p5.xmlFile, "vehicle.licensePlates.licensePlate", -1, p5.components, p5)
	end
end
function LicensePlates.onPostLoad(p36, p37)
	local v38 = p36.spec_licensePlates
	for v39 = 1, #v38.licensePlates do
		ObjectChangeUtil.setObjectChanges(v38.licensePlates[v39].changeObjects, false, p36, p36.setMovingToolDirty)
	end
	if p37 ~= nil and p36:getHasLicensePlates() then
		local v40 = p37.xmlFile:getValue(p37.key .. ".licensePlates#variation", 1)
		local v41 = p37.xmlFile:getValue(p37.key .. ".licensePlates#characters")
		local v42 = p37.xmlFile:getValue(p37.key .. ".licensePlates#colorIndex", 1)
		local v43 = p37.xmlFile:getValue(p37.key .. ".licensePlates#placementIndex", 1)
		if v40 ~= nil and (v41 ~= nil and (v42 ~= nil and v43 ~= nil)) then
			local v44 = {}
			for v45 = 1, v41:len() do
				table.insert(v44, v41:sub(v45, v45))
			end
			v38.licensePlateData = {
				["variation"] = v40,
				["characters"] = v44,
				["colorIndex"] = v42,
				["placementIndex"] = v43
			}
			p36:setLicensePlatesData(v38.licensePlateData)
		end
	end
end
function LicensePlates.onDelete(p46, _)
	p46.spec_licensePlates.licensePlates = {}
end
function LicensePlates.saveToXMLFile(p47, p48, p49, _)
	local v50 = p47.spec_licensePlates
	if p47:getHasLicensePlates() and (v50.licensePlateData and (v50.licensePlateData.placementIndex ~= LicensePlateManager.PLACEMENT_OPTION.NONE and (v50.licensePlateData.variation ~= nil and (v50.licensePlateData.characters ~= nil and v50.licensePlateData.colorIndex ~= nil)))) then
		p48:setValue(p49 .. "#variation", v50.licensePlateData.variation)
		p48:setValue(p49 .. "#characters", table.concat(v50.licensePlateData.characters, ""))
		p48:setValue(p49 .. "#colorIndex", v50.licensePlateData.colorIndex)
		p48:setValue(p49 .. "#placementIndex", v50.licensePlateData.placementIndex)
	end
end
function LicensePlates.onReadStream(p51, p52, p53)
	local v54 = p51.spec_licensePlates
	v54.licensePlateData = LicensePlateManager.readLicensePlateData(p52, p53)
	p51:setLicensePlatesData(v54.licensePlateData)
end
function LicensePlates.onWriteStream(p55, p56, p57)
	local v58 = p55.spec_licensePlates
	LicensePlateManager.writeLicensePlateData(p56, p57, v58.licensePlateData)
end
function LicensePlates.setLicensePlatesData(p59, p60)
	local v61 = p59.spec_licensePlates
	if p60 == nil or (p60.variation == nil or (p60.characters == nil or (p60.colorIndex == nil or p60.placementIndex == nil))) then
		for v62 = 1, #v61.licensePlates do
			setVisibility(v61.licensePlates[v62].data.node, false)
		end
	else
		for v63 = 1, #v61.licensePlates do
			local v64 = v61.licensePlates[v63]
			local v65 = true
			if p60.placementIndex == LicensePlateManager.PLACEMENT_OPTION.NONE then
				v65 = false
			elseif p60.placementIndex == LicensePlateManager.PLACEMENT_OPTION.BACK_ONLY and v64.position == LicensePlateManager.PLATE_POSITION.FRONT then
				v65 = false
			end
			if v65 then
				v64.data:updateData(p60.variation, v64.position, table.concat(p60.characters, ""), true)
				v64.data:setColorIndex(p60.colorIndex)
				setVisibility(v64.data.node, true)
			else
				setVisibility(v64.data.node, false)
			end
			ObjectChangeUtil.setObjectChanges(v64.changeObjects, v65, p59, p59.setMovingToolDirty)
		end
		v61.licensePlateData = p60
	end
end
function LicensePlates.getLicensePlatesData(p66)
	return p66.spec_licensePlates.licensePlateData
end
function LicensePlates.getLicensePlatesDataIsEqual(p67, p68)
	if p68 == nil or p67.spec_licensePlates.licensePlateData == nil then
		return true
	end
	local v69 = p67.spec_licensePlates.licensePlateData
	if p68.variation ~= v69.variation or (p68.colorIndex ~= v69.colorIndex or p68.placementIndex ~= v69.placementIndex) then
		return false
	end
	if p68.characters ~= nil and v69.characters ~= nil then
		if #p68.characters ~= #v69.characters then
			return false
		end
		for v70 = 1, #p68.characters do
			if p68.characters[v70] ~= v69.characters[v70] then
				return false
			end
		end
	end
	return true
end
function LicensePlates.getHasLicensePlates(p71)
	return #p71.spec_licensePlates.licensePlates > 0
end
function LicensePlates.getLicensePlateDialogSettings(p72)
	local v73 = p72.spec_licensePlates
	local v74 = false
	for v75 = 1, #v73.licensePlates do
		if v73.licensePlates[v75].position == LicensePlateManager.PLATE_POSITION.FRONT then
			v74 = true
			break
		end
	end
	return v73.defaultPlacementIndex, v74
end
function LicensePlates.loadSpecValuePlateText(_, _, _)
	return nil
end
function LicensePlates.getSpecValuePlateText(_, p76)
	if p76 == nil then
		return nil
	end
	if p76.getHasLicensePlates == nil or not p76:getHasLicensePlates() then
		return nil
	end
	local v77 = p76.spec_licensePlates
	for v78 = 1, #v77.licensePlates do
		local v79 = v77.licensePlates[v78]
		if v79.position == LicensePlateManager.PLATE_POSITION.BACK or v78 == #v77.licensePlates then
			return v79.data:getFormattedString()
		end
	end
	return nil
end

TipOccluder = {}
function TipOccluder.prerequisitesPresent(_)
	return true
end
function TipOccluder.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("TipOccluder")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tipOccluder.occlusionArea(?)#start", "Start node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tipOccluder.occlusionArea(?)#width", "Width node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tipOccluder.occlusionArea(?)#height", "Height node")
	v1:setXMLSpecializationType()
end
function TipOccluder.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "getTipOcclusionAreas", TipOccluder.getTipOcclusionAreas)
	SpecializationUtil.registerFunction(p2, "getWheelsWithTipOcclisionAreaGroupId", TipOccluder.getWheelsWithTipOcclisionAreaGroupId)
	SpecializationUtil.registerFunction(p2, "getRequiresTipOcclusionArea", TipOccluder.getRequiresTipOcclusionArea)
end
function TipOccluder.registerOverwrittenFunctions(_) end
function TipOccluder.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", TipOccluder)
	SpecializationUtil.registerEventListener(p3, "onLoadFinished", TipOccluder)
end
function TipOccluder.onLoad(p4, _)
	local v5 = p4.spec_tipOccluder
	XMLUtil.checkDeprecatedXMLElements(p4.xmlFile, "vehicle.tipOcclusionAreas.tipOcclusionArea", "vehicle.tipOccluder.occlusionArea")
	v5.tipOcclusionAreas = {}
	local v6 = 0
	while true do
		local v7 = string.format("vehicle.tipOccluder.occlusionArea(%d)", v6)
		if not p4.xmlFile:hasProperty(v7) then
			break
		end
		local v8 = {
			["start"] = p4.xmlFile:getValue(v7 .. "#start", nil, p4.components, p4.i3dMappings),
			["width"] = p4.xmlFile:getValue(v7 .. "#width", nil, p4.components, p4.i3dMappings),
			["height"] = p4.xmlFile:getValue(v7 .. "#height", nil, p4.components, p4.i3dMappings)
		}
		if v8.start ~= nil and (v8.width ~= nil and v8.height ~= nil) then
			local v9 = v5.tipOcclusionAreas
			table.insert(v9, v8)
		end
		v6 = v6 + 1
	end
	v5.createdTipOcclusionAreaGroupIds = {}
end
function TipOccluder.onLoadFinished(p10, _)
	if p10.getWheels ~= nil then
		for _, v11 in ipairs(p10:getWheels()) do
			local v12 = p10.spec_tipOccluder
			local v13 = v11.physics.tipOcclusionAreaGroupId
			if v13 ~= nil then
				local v14 = p10.components[1].node
				local v15 = true
				local v16 = nil
				for v17, v18 in pairs(v12.createdTipOcclusionAreaGroupIds) do
					if v17 == v13 then
						v16 = v18
						v15 = false
						break
					end
				end
				if v15 then
					local v19 = createTransformGroup(string.format("tipOcclusionAreaGroupId%d", v13))
					local v20 = createTransformGroup(string.format("tipOcclusionAreaGroupId%d", v13))
					local v21 = createTransformGroup(string.format("tipOcclusionAreaGroupId%d", v13))
					link(v14, v19)
					link(v14, v20)
					link(v14, v21)
					v16 = {
						["start"] = v19,
						["width"] = v20,
						["height"] = v21
					}
					local v22 = v12.tipOcclusionAreas
					table.insert(v22, v16)
					v12.createdTipOcclusionAreaGroupIds[v13] = v16
				end
				if v16 ~= nil then
					local v23 = p10:getWheelsWithTipOcclisionAreaGroupId(p10:getWheels(), v13)
					table.insert(v23, v11)
					local v24 = v23[#v23].node
					link(v24, v16.start)
					link(v24, v16.width)
					link(v24, v16.height)
					local v25 = (-1 / 0)
					local v26 = (1 / 0)
					local v27 = (1 / 0)
					local v28 = (-1 / 0)
					for _, v29 in pairs(v23) do
						local v30, _, v31 = localToLocal(v29.driveNode, v24, v29.physics.wheelShapeWidth - 0.5 * v29.physics.width, 0, -v29.physics.radius)
						v25 = math.max(v30, v25)
						v26 = math.min(v31, v26)
						local v32, _, v33 = localToLocal(v29.driveNode, v24, -v29.physics.wheelShapeWidth + 0.5 * v29.physics.width, 0, v29.physics.radius)
						v27 = math.min(v32, v27)
						v28 = math.max(v33, v28)
					end
					setTranslation(v16.start, v25, 0, v26)
					setTranslation(v16.width, v27, 0, v26)
					setTranslation(v16.height, v25, 0, v28)
				end
			end
		end
	end
	if p10:getRequiresTipOcclusionArea() and #p10.spec_tipOccluder.tipOcclusionAreas == 0 then
		Logging.xmlDevWarning(p10.xmlFile, "No TipOcclusionArea defined")
	end
end
function TipOccluder.getTipOcclusionAreas(p34)
	return p34.spec_tipOccluder.tipOcclusionAreas
end
function TipOccluder.getWheelsWithTipOcclisionAreaGroupId(_, p35, p36)
	local v37 = {}
	for _, v38 in pairs(p35) do
		if v38.physics.tipOcclusionAreaGroupId == p36 then
			table.insert(v37, v38)
		end
	end
	return v37
end
function TipOccluder.getRequiresTipOcclusionArea(_)
	return false
end

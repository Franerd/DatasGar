AIDischargeable = {}
function AIDischargeable.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Dischargeable, p1)
end
function AIDischargeable.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Dischargeable")
	v2:register(XMLValueType.BOOL, "vehicle.dischargeable.dischargeNode(?)#allowAIDischarge", "Allows ai discharge", false)
	v2:register(XMLValueType.BOOL, "vehicle.dischargeable.dischargeableConfigurations.dischargeableConfiguration(?).dischargeNode(?)#allowAIDischarge", "Allows ai discharge", false)
	v2:setXMLSpecializationType()
end
function AIDischargeable.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getAIDischargeNodes", AIDischargeable.getAIDischargeNodes)
	SpecializationUtil.registerFunction(p3, "getAIDischargeNodeZAlignedOffset", AIDischargeable.getAIDischargeNodeZAlignedOffset)
	SpecializationUtil.registerFunction(p3, "getAICanStartDischarge", AIDischargeable.getAICanStartDischarge)
	SpecializationUtil.registerFunction(p3, "startAIDischarge", AIDischargeable.startAIDischarge)
	SpecializationUtil.registerFunction(p3, "stoppedAIDischarge", AIDischargeable.stoppedAIDischarge)
	SpecializationUtil.registerFunction(p3, "finishedAIDischarge", AIDischargeable.finishedAIDischarge)
	SpecializationUtil.registerFunction(p3, "getAIHasFinishedDischarge", AIDischargeable.getAIHasFinishedDischarge)
end
function AIDischargeable.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadDischargeNode", AIDischargeable.loadDischargeNode)
	SpecializationUtil.registerOverwrittenFunction(p4, "getDischargeNodeAutomaticDischarge", AIDischargeable.getDischargeNodeAutomaticDischarge)
end
function AIDischargeable.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onPreLoad", AIDischargeable)
	SpecializationUtil.registerEventListener(p5, "onLoad", AIDischargeable)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", AIDischargeable)
	SpecializationUtil.registerEventListener(p5, "onUpdate", AIDischargeable)
	SpecializationUtil.registerEventListener(p5, "onDischargeStateChanged", AIDischargeable)
end
function AIDischargeable.onPreLoad(p6)
	p6.spec_aiDischargeable.aiDischargeNodes = {}
end
function AIDischargeable.onLoad(p7)
	p7.spec_aiDischargeable.currentDischargeNode = nil
end
function AIDischargeable.onPostLoad(p8)
	local v9 = p8.spec_aiDischargeable
	if v9.aiDischargeNodes ~= nil then
		for _, v10 in ipairs(v9.aiDischargeNodes) do
			v10.inputAttacherJointOffsets = {}
			if p8.getInputAttacherJoints ~= nil then
				for _, v11 in ipairs(p8:getInputAttacherJoints()) do
					local v12, v13, v14 = localToLocal(v10.node, v11.node, 0, 0, 0)
					local v15 = v10.inputAttacherJointOffsets
					table.insert(v15, { v12, v13, v14 })
				end
			end
			if p8.getAIRootNode ~= nil then
				local v16 = p8:getAIRootNode()
				v10.aiRootNodeOffsets = { localToLocal(v10.node, v16, 0, 0, 0) }
			end
		end
	end
end
function AIDischargeable.onUpdate(p17, _, _, _, _)
	local v18 = p17.spec_aiDischargeable
	if v18.currentDischargeNode ~= nil and (not v18.isAIDischargeRunning and p17:getAIHasFinishedDischarge(v18.currentDischargeNode)) then
		p17:finishedAIDischarge()
	end
end
function AIDischargeable.loadDischargeNode(p19, p20, p21, p22, p23)
	if not p20(p19, p21, p22, p23) then
		return false
	end
	p23.allowAIDischarge = p21:getValue(p22 .. "#allowAIDischarge", false)
	if p23.allowAIDischarge then
		local v24 = p19.spec_aiDischargeable
		local v25 = false
		for _, v26 in ipairs(v24.aiDischargeNodes) do
			if v26.fillUnitIndex == p23.fillUnitIndex then
				v25 = true
				break
			end
		end
		if v25 then
			Logging.xmlWarning(p21, "Discharge node fill unit index already used for AI. Discharge node will be ignored for \'%s\'", p22)
		else
			local v27 = v24.aiDischargeNodes
			table.insert(v27, p23)
		end
	end
	return true
end
function AIDischargeable.getDischargeNodeAutomaticDischarge(p28, p29, p30)
	if Platform.gameplay.automaticDischarge and p28:getIsAIActive() then
		return false
	else
		return p29(p28, p30)
	end
end
function AIDischargeable.onDischargeStateChanged(p31, p32)
	local v33 = p31.spec_aiDischargeable
	if v33.currentDischargeNode ~= nil and (v33.isAIDischargeRunning and p32 == Dischargeable.DISCHARGE_STATE_OFF) then
		p31:stoppedAIDischarge()
	end
end
function AIDischargeable.getAIDischargeNodes(p34)
	return p34.spec_aiDischargeable.aiDischargeNodes
end
function AIDischargeable.getAIDischargeNodeZAlignedOffset(p35, p36, p37)
	if p37 == p35 then
		return p36.aiRootNodeOffsets[1], p36.aiRootNodeOffsets[2], p36.aiRootNodeOffsets[3]
	end
	local v38 = p35:getActiveInputAttacherJointDescIndex()
	local v39 = p36.inputAttacherJointOffsets[v38]
	local v40 = v39[1]
	local v41 = v39[2]
	local v42 = v39[3]
	local v43 = p35:getAttacherVehicle()
	while p37 ~= v43 do
		local v44 = v43:getAttacherJointDescFromObject(p35)
		local v45 = v43:getActiveInputAttacherJointDescIndex()
		local v46 = v44.inputAttacherJointOffsets[v45]
		local v47, v48, v49, v50, v51, v52, v53, v54, v55, v56, v57, v58 = unpack(v46)
		local v59 = v47 + v56 * v40 + v53 * v41 + v50 * v42
		local v60 = v48 + v57 * v40 + v54 * v41 + v51 * v42
		v42 = v49 + v58 * v40 + v55 * v41 + v52 * v42
		local v61 = v43:getAttacherVehicle()
		v41 = v60
		v40 = v59
		p35 = v43
		v43 = v61
	end
	local v62 = p37:getAttacherJointDescFromObject(p35).aiRootNodeOffset
	local v63, v64, v65, v66, v67, v68, v69, v70, v71, v72, v73, v74 = unpack(v62)
	return v63 + v72 * v40 + v69 * v41 + v66 * v42, v64 + v73 * v40 + v70 * v41 + v67 * v42, v65 + v74 * v40 + v71 * v41 + v68 * v42
end
function AIDischargeable.getAICanStartDischarge(p75, p76)
	return p75:getCanDischargeToObject(p76)
end
function AIDischargeable.startAIDischarge(p77, p78, p79)
	local v80 = p77.spec_aiDischargeable
	v80.currentDischargeNode = p78
	v80.task = p79
	v80.isAIDischargeRunning = true
	p77:setDischargeState(Dischargeable.DISCHARGE_STATE_OBJECT)
end
function AIDischargeable.stoppedAIDischarge(p81)
	p81.spec_aiDischargeable.isAIDischargeRunning = false
end
function AIDischargeable.finishedAIDischarge(p82)
	local v83 = p82.spec_aiDischargeable
	if v83.task ~= nil then
		v83.task:finishedDischarge()
	end
	v83.currentDischargeNode = nil
	v83.task = nil
end
function AIDischargeable.getAIHasFinishedDischarge(_, _)
	return true
end

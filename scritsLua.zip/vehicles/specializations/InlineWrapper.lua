InlineWrapper = {}
InlineWrapper.INTERACTION_RADIUS = 5
InlineWrapper.CONSUMABLE_TYPE_NAME = "BALE_WRAP"
source("dataS/scripts/vehicles/specializations/events/InlineWrapperPushOffEvent.lua")
function InlineWrapper.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Foldable, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Consumable, p1)
	end
	return v2
end
function InlineWrapper.initSpecialization()
	g_storeManager:addSpecType("inlineWrapperBaleSizeRound", "shopListAttributeIconBaleWrapperBaleSizeRound", InlineWrapper.loadSpecValueBaleSizeRound, InlineWrapper.getSpecValueBaleSizeRound, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("inlineWrapperBaleSizeSquare", "shopListAttributeIconBaleWrapperBaleSizeSquare", InlineWrapper.loadSpecValueBaleSizeSquare, InlineWrapper.getSpecValueBaleSizeSquare, StoreSpecies.VEHICLE)
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("InlineWrapper")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.inlineWrapper.baleTrigger#node", "Bale pickup trigger")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.baleTrigger#minFoldTime", "Min. folding time for bale pickup", 0)
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.baleTrigger#maxFoldTime", "Max. folding time for bale pickup", 1)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.inlineWrapper.wrapTrigger#node", "Wrap trigger")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.inlineWrapper.baleTypes.baleType(?)#startNode", "Start placement node for bale")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.baleTypes.baleType(?)#wrapUsage", "Usage of wrap rolls per minute", 0.1)
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.baleTypes.baleType(?).railing#width", "Railing width to set")
	v3:register(XMLValueType.STRING, "vehicle.inlineWrapper.baleTypes.baleType(?).inlineBale#filename", "Path to inline bale xml file")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.baleTypes.baleType(?).size#diameter", "Bale diameter")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.baleTypes.baleType(?).size#width", "Bale width")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.baleTypes.baleType(?).size#height", "Bale height")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.baleTypes.baleType(?).size#length", "Bale length")
	v3:register(XMLValueType.STRING, "vehicle.inlineWrapper.railings#animation", "Railing animation")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.railings#animStartX", "Railing width at start of animation")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.railings#animEndX", "Railing width at end of animation")
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.railings#defaultX", "Default railing width", 1)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.inlineWrapper.wrapping#startNode", "Reference node for wrapping state of bale")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.inlineWrapper.steeringNodes.steeringNode(?)#node", "Steering node that is aligned to the start wrapping direction")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.inlineWrapper.wrappingNodes.wrappingNode(?)#node", "Wrapping node")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.inlineWrapper.wrappingNodes.wrappingNode(?)#target", "Target node that is aligned to the bale")
	v3:register(XMLValueType.VECTOR_TRANS, "vehicle.inlineWrapper.wrappingNodes.wrappingNode(?)#startTrans", "Start translation")
	v3:register(XMLValueType.STRING, "vehicle.inlineWrapper.animations#pusher", "Pusher animation", "pusherAnimation")
	v3:register(XMLValueType.STRING, "vehicle.inlineWrapper.animations#wrapping", "Wrapping animation", "wrappingAnimation")
	v3:register(XMLValueType.STRING, "vehicle.inlineWrapper.animations#pushOff", "Push bale off animation", "pushOffAnimation")
	v3:register(XMLValueType.STRING, "vehicle.inlineWrapper.pushing#brakeForce", "Brake force while pushing", 0)
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.pushing#openBrakeTime", "Pusher animation time to open brake", 0.1)
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper.pushing#closeBrakeTime", "Pusher animation time to close brake", 0.5)
	v3:register(XMLValueType.INT, "vehicle.inlineWrapper.pushing#minBaleAmount", "Min. bales wrapped to open brake", 4)
	v3:register(XMLValueType.FLOAT, "vehicle.inlineWrapper#baleMovedThreshold", "Bale moved threshold for starting wrapping animation", 0.05)
	v3:register(XMLValueType.INT, "vehicle.inlineWrapper#numObjectBits", "Num bits for sending bales", 4)
	SoundManager.registerSampleXMLPaths(v3, "vehicle.inlineWrapper.sounds", "wrap")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.inlineWrapper.sounds", "start")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.inlineWrapper.sounds", "stop")
	v3:setXMLSpecializationType()
end
function InlineWrapper.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "readInlineBales", InlineWrapper.readInlineBales)
	SpecializationUtil.registerFunction(p4, "writeInlineBales", InlineWrapper.writeInlineBales)
	SpecializationUtil.registerFunction(p4, "getIsInlineBalingAllowed", InlineWrapper.getIsInlineBalingAllowed)
	SpecializationUtil.registerFunction(p4, "inlineBaleTriggerCallback", InlineWrapper.inlineBaleTriggerCallback)
	SpecializationUtil.registerFunction(p4, "inlineWrapTriggerCallback", InlineWrapper.inlineWrapTriggerCallback)
	SpecializationUtil.registerFunction(p4, "updateWrappingNodes", InlineWrapper.updateWrappingNodes)
	SpecializationUtil.registerFunction(p4, "updateRoundBaleWrappingNode", InlineWrapper.updateRoundBaleWrappingNode)
	SpecializationUtil.registerFunction(p4, "updateSquareBaleWrappingNode", InlineWrapper.updateSquareBaleWrappingNode)
	SpecializationUtil.registerFunction(p4, "getWrapperBaleType", InlineWrapper.getWrapperBaleType)
	SpecializationUtil.registerFunction(p4, "getAllowBalePushing", InlineWrapper.getAllowBalePushing)
	SpecializationUtil.registerFunction(p4, "updateWrapperRailings", InlineWrapper.updateWrapperRailings)
	SpecializationUtil.registerFunction(p4, "updateInlineSteeringWheels", InlineWrapper.updateInlineSteeringWheels)
	SpecializationUtil.registerFunction(p4, "getCanInteract", InlineWrapper.getCanInteract)
	SpecializationUtil.registerFunction(p4, "getCanPushOff", InlineWrapper.getCanPushOff)
	SpecializationUtil.registerFunction(p4, "setCurrentInlineBale", InlineWrapper.setCurrentInlineBale)
	SpecializationUtil.registerFunction(p4, "getCurrentInlineBale", InlineWrapper.getCurrentInlineBale)
	SpecializationUtil.registerFunction(p4, "pushOffInlineBale", InlineWrapper.pushOffInlineBale)
end
function InlineWrapper.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsFoldAllowed", InlineWrapper.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsActive", InlineWrapper.getIsActive)
	SpecializationUtil.registerOverwrittenFunction(p5, "getBrakeForce", InlineWrapper.getBrakeForce)
	SpecializationUtil.registerOverwrittenFunction(p5, "getShowConsumableEmptyWarning", InlineWrapper.getShowConsumableEmptyWarning)
end
function InlineWrapper.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onDelete", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onReadStream", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onUpdate", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onDraw", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onLeaveVehicle", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onEnterVehicle", InlineWrapper)
	SpecializationUtil.registerEventListener(p6, "onConsumableVariationChanged", InlineWrapper)
end
function InlineWrapper.onLoad(p_u_7, _)
	local v_u_8 = p_u_7.spec_inlineWrapper
	v_u_8.triggerNode = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.baleTrigger#node", nil, p_u_7.components, p_u_7.i3dMappings)
	if v_u_8.triggerNode ~= nil then
		addTrigger(v_u_8.triggerNode, "inlineBaleTriggerCallback", p_u_7)
	end
	v_u_8.wrapTriggerNode = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.wrapTrigger#node", nil, p_u_7.components, p_u_7.i3dMappings)
	if v_u_8.wrapTriggerNode ~= nil then
		addTrigger(v_u_8.wrapTriggerNode, "inlineWrapTriggerCallback", p_u_7)
	end
	v_u_8.minFoldTime = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.baleTrigger#minFoldTime", 0)
	v_u_8.maxFoldTime = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.baleTrigger#maxFoldTime", 1)
	v_u_8.wrapColor = { 1, 1, 1 }
	v_u_8.baleTypes = {}
	p_u_7.xmlFile:iterate("vehicle.inlineWrapper.baleTypes.baleType", function(_, p9)
		-- upvalues: (copy) p_u_7, (copy) v_u_8
		local v10 = {
			["startNode"] = p_u_7.xmlFile:getValue(p9 .. "#startNode", nil, p_u_7.components, p_u_7.i3dMappings)
		}
		if v10.startNode == nil then
			Logging.xmlError(p_u_7.xmlFile, "Failed to load bale type. Missing start node! \'%s\'", p9)
			return
		else
			v10.railingWidth = p_u_7.xmlFile:getValue(p9 .. ".railing#width")
			v10.wrapUsage = p_u_7.xmlFile:getValue(p9 .. "#wrapUsage", 0.1) / 60 / 1000
			v10.inlineBaleFilename = Utils.getFilename(p_u_7.xmlFile:getValue(p9 .. ".inlineBale#filename"), p_u_7.baseDirectory)
			if v10.inlineBaleFilename == nil then
				Logging.xmlError(p_u_7.xmlFile, "Failed to load bale type. Missing inline bale filename! \'%s\'", p9)
			else
				v10.diameter = MathUtil.round(p_u_7.xmlFile:getValue(p9 .. ".size#diameter", 0), 2)
				v10.width = MathUtil.round(p_u_7.xmlFile:getValue(p9 .. ".size#width", 0), 2)
				v10.isRoundBale = v10.diameter ~= 0
				if not v10.isRoundBale then
					v10.height = MathUtil.round(p_u_7.xmlFile:getValue(p9 .. ".size#height", 0), 2)
					v10.length = MathUtil.round(p_u_7.xmlFile:getValue(p9 .. ".size#length", 0), 2)
				end
				v10.index = #v_u_8.baleTypes + 1
				local v11 = v_u_8.baleTypes
				table.insert(v11, v10)
			end
		end
	end)
	v_u_8.railingsAnimation = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.railings#animation")
	v_u_8.railingsAnimationStartX = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.railings#animStartX")
	v_u_8.railingsAnimationEndX = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.railings#animEndX")
	v_u_8.railingStartX = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.railings#defaultX", 1)
	v_u_8.currentPosition = v_u_8.railingStartX + 0.01
	v_u_8.targetPosition = v_u_8.railingStartX + 0.01
	v_u_8.wrappingStartNode = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.wrapping#startNode", nil, p_u_7.components, p_u_7.i3dMappings)
	v_u_8.steeringNodes = {}
	p_u_7.xmlFile:iterate("vehicle.inlineWrapper.steeringNodes.steeringNode", function(_, p12)
		-- upvalues: (copy) p_u_7, (copy) v_u_8
		local v13 = {
			["node"] = p_u_7.xmlFile:getValue(p12 .. "#node", nil, p_u_7.components, p_u_7.i3dMappings)
		}
		if v13.node ~= nil then
			v13.startRot = { getRotation(v13.node) }
			local v14 = v_u_8.steeringNodes
			table.insert(v14, v13)
		end
	end)
	v_u_8.wrappingNodes = {}
	p_u_7.xmlFile:iterate("vehicle.inlineWrapper.wrappingNodes.wrappingNode", function(_, p15)
		-- upvalues: (copy) p_u_7, (copy) v_u_8
		local v16 = {
			["node"] = p_u_7.xmlFile:getValue(p15 .. "#node", nil, p_u_7.components, p_u_7.i3dMappings),
			["target"] = p_u_7.xmlFile:getValue(p15 .. "#target", nil, p_u_7.components, p_u_7.i3dMappings)
		}
		if v16.node ~= nil and v16.target ~= nil then
			v16.startTrans = p_u_7.xmlFile:getValue(p15 .. "#startTrans", nil, true) or { getTranslation(v16.target) }
			setTranslation(v16.target, v16.startTrans[1], v16.startTrans[2], v16.startTrans[3])
			local v17 = v_u_8.wrappingNodes
			table.insert(v17, v16)
		end
	end)
	v_u_8.animations = {}
	v_u_8.animations.pusher = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.animations#pusher", "pusherAnimation")
	v_u_8.animations.wrapping = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.animations#wrapping", "wrappingAnimation")
	v_u_8.animations.pushOff = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.animations#pushOff", "pushOffAnimation")
	v_u_8.pushingBrakeForce = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.pushing#brakeForce", 0)
	v_u_8.pushingOpenBrakeTime = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.pushing#openBrakeTime", 0.1)
	v_u_8.pushingCloseBrakeTime = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.pushing#closeBrakeTime", 0.5)
	v_u_8.pushingMinBaleAmount = p_u_7.xmlFile:getValue("vehicle.inlineWrapper.pushing#minBaleAmount", 4)
	v_u_8.baleMovedThreshold = p_u_7.xmlFile:getValue("vehicle.inlineWrapper#baleMovedThreshold", 0.05)
	v_u_8.pusherAnimationDirty = false
	v_u_8.showIncompatibleBalesWarning = false
	v_u_8.pendingSingleBales = {}
	v_u_8.pendingIncompatibleBales = {}
	v_u_8.enteredInlineBales = {}
	v_u_8.enteredBalesToWrap = {}
	v_u_8.numObjectBits = p_u_7.xmlFile:getValue("vehicle.inlineWrapper#numObjectBits", 4)
	v_u_8.inlineBalesDirtyFlag = p_u_7:getNextDirtyFlag()
	v_u_8.warningDirtyFlag = p_u_7:getNextDirtyFlag()
	v_u_8.currentLineDirection = nil
	v_u_8.lineDirection = nil
	v_u_8.activatable = InlineWrapperActivatable.new(p_u_7)
	if p_u_7.isClient then
		v_u_8.samples = {}
		v_u_8.samples.wrap = g_soundManager:loadSampleFromXML(p_u_7.xmlFile, "vehicle.inlineWrapper.sounds", "wrap", p_u_7.baseDirectory, p_u_7.components, 0, AudioGroup.VEHICLE, p_u_7.i3dMappings, p_u_7)
		v_u_8.samples.start = g_soundManager:loadSampleFromXML(p_u_7.xmlFile, "vehicle.inlineWrapper.sounds", "start", p_u_7.baseDirectory, p_u_7.components, 1, AudioGroup.VEHICLE, p_u_7.i3dMappings, p_u_7)
		v_u_8.samples.stop = g_soundManager:loadSampleFromXML(p_u_7.xmlFile, "vehicle.inlineWrapper.sounds", "stop", p_u_7.baseDirectory, p_u_7.components, 1, AudioGroup.VEHICLE, p_u_7.i3dMappings, p_u_7)
	end
end
function InlineWrapper.onPostLoad(p18, _)
	local v19 = p18.spec_inlineWrapper
	if v19.railingsAnimation ~= nil then
		p18:setAnimationTime(v19.railingsAnimation, 1, true)
	end
end
function InlineWrapper.onDelete(p20)
	local v21 = p20.spec_inlineWrapper
	if v21.triggerNode ~= nil then
		removeTrigger(v21.triggerNode)
	end
	if v21.wrapTriggerNode ~= nil then
		removeTrigger(v21.wrapTriggerNode)
	end
	g_soundManager:deleteSamples(v21.samples)
	g_currentMission.activatableObjectsSystem:removeActivatable(v21.activatable)
	local v22 = p20:getCurrentInlineBale()
	if v22 ~= nil then
		v22:wakeUp(50)
		v22:setWrappingState(1)
		v22:setCurrentWrapperInfo(nil, nil)
		p20:setCurrentInlineBale(nil)
	end
end
function InlineWrapper.onReadStream(p23, p24, p25)
	p23:readInlineBales("pendingSingleBales", p24, p25)
	p23:readInlineBales("enteredInlineBales", p24, p25)
	p23:readInlineBales("enteredBalesToWrap", p24, p25)
	if streamReadBool(p24) then
		p23:setCurrentInlineBale(NetworkUtil.readNodeObjectId(p24), true)
	else
		p23:setCurrentInlineBale(nil, true)
	end
	local v26 = p23.spec_inlineWrapper
	v26.showIncompatibleBalesWarning = streamReadBool(p24)
	g_currentMission.activatableObjectsSystem:addActivatable(v26.activatable)
end
function InlineWrapper.onWriteStream(p27, p28, p29)
	p27:writeInlineBales("pendingSingleBales", p28, p29)
	p27:writeInlineBales("enteredInlineBales", p28, p29)
	p27:writeInlineBales("enteredBalesToWrap", p28, p29)
	local v30 = p27:getCurrentInlineBale()
	if streamWriteBool(p28, v30 ~= nil) then
		NetworkUtil.writeNodeObject(p28, v30)
	end
	streamWriteBool(p28, p27.spec_inlineWrapper.showIncompatibleBalesWarning)
end
function InlineWrapper.onReadUpdateStream(p31, p32, _, p33)
	if p33:getIsServer() then
		local v34 = p31.spec_inlineWrapper
		if streamReadBool(p32) then
			p31:readInlineBales("pendingSingleBales", p32, p33)
			p31:readInlineBales("enteredInlineBales", p32, p33)
			p31:readInlineBales("enteredBalesToWrap", p32, p33)
			if streamReadBool(p32) then
				p31:setCurrentInlineBale(NetworkUtil.readNodeObjectId(p32), true)
			else
				p31:setCurrentInlineBale(nil, true)
			end
			g_currentMission.activatableObjectsSystem:addActivatable(v34.activatable)
		end
		v34.showIncompatibleBalesWarning = streamReadBool(p32)
	end
end
function InlineWrapper.onWriteUpdateStream(p35, p36, p37, p38)
	if not p37:getIsServer() then
		local v39 = p35.spec_inlineWrapper
		if streamWriteBool(p36, bitAND(p38, v39.inlineBalesDirtyFlag) ~= 0) then
			p35:writeInlineBales("pendingSingleBales", p36, p37)
			p35:writeInlineBales("enteredInlineBales", p36, p37)
			p35:writeInlineBales("enteredBalesToWrap", p36, p37)
			local v40 = p35:getCurrentInlineBale()
			if streamWriteBool(p36, v40 ~= nil) then
				NetworkUtil.writeNodeObject(p36, v40)
			end
		end
		streamWriteBool(p36, v39.showIncompatibleBalesWarning)
	end
end
function InlineWrapper.readInlineBales(p41, p42, p43, _)
	local v44 = p41.spec_inlineWrapper
	local v45 = streamReadUIntN(p43, v44.numObjectBits)
	v44[p42] = {}
	for _ = 1, v45 do
		local v46 = NetworkUtil.readNodeObjectId(p43)
		v44[p42][v46] = v46
	end
end
function InlineWrapper.writeInlineBales(p47, p48, p49, _)
	local v50 = p47.spec_inlineWrapper
	local v51 = table.size(v50[p48])
	streamWriteUIntN(p49, v51, v50.numObjectBits)
	local v52 = 0
	for v53, _ in pairs(v50[p48]) do
		v52 = v52 + 1
		if v52 <= v51 then
			NetworkUtil.writeNodeObjectId(p49, v53)
		else
			Logging.xmlWarning(p47.xmlFile, "Not enough bits to send all inline objects. Please increase \'%s\'", "vehicle.inlineWrapper#numObjectBits")
		end
	end
end
function InlineWrapper.onUpdate(p54, _, _, _, _)
	if p54:getIsAnimationPlaying(p54.spec_inlineWrapper.animations.wrapping) then
		p54:updateWrappingNodes()
	end
end
function InlineWrapper.onUpdateTick(p55, p56, _, _, _)
	local v57 = p55.spec_inlineWrapper
	if p55.isServer then
		local v58 = next(v57.pendingSingleBales)
		local v59 = NetworkUtil.getObject(v58)
		if v59 ~= nil and p55:getIsInlineBalingAllowed() then
			local v60 = p55:getWrapperBaleType(v59)
			local v61 = next(v57.enteredInlineBales)
			local v62 = NetworkUtil.getObject(v61)
			local v63 = nil
			local v64 = false
			if v62 == nil then
				v63 = InlineBale.new(p55.isServer, p55.isClient)
				if v63:loadFromConfigXML(v60.inlineBaleFilename) then
					v63:setOwnerFarmId(p55:getActiveFarm(), true)
					v63:setCurrentWrapperInfo(p55, v57.wrappingStartNode)
					v63:register()
					v64 = v63:addBale(v59, v60)
				else
					v63:delete()
				end
			elseif v62:isa(InlineBaleSingle) then
				v63 = v62:getConnectedInlineBale()
				if v63 ~= nil then
					v64 = v63:addBale(v59, v60)
					if v64 then
						p55:getCurrentInlineBale():setCurrentWrapperInfo(p55, v57.wrappingStartNode)
					end
				end
			end
			if v64 then
				v57.pendingSingleBales[v58] = nil
				v57.enteredInlineBales[v58] = v58
				v57.pusherAnimationDirty = true
				p55:setCurrentInlineBale(v63)
				g_currentMission.activatableObjectsSystem:addActivatable(v57.activatable)
				local v65, _ = g_farmManager:updateFarmStats(p55:getOwnerFarmId(), "wrappedBales", 1)
				if v65 ~= nil then
					g_achievementManager:tryUnlock("WrappedBales", v65)
				end
				p55:raiseDirtyFlags(v57.inlineBalesDirtyFlag)
			end
		end
		local v66 = next(v57.pendingIncompatibleBales) ~= nil
		if v66 ~= v57.showIncompatibleBalesWarning then
			v57.showIncompatibleBalesWarning = v66
			p55:raiseDirtyFlags(v57.warningDirtyFlag)
		end
	end
	local v67 = next(v57.enteredInlineBales)
	local v68 = NetworkUtil.getObject(v67)
	if v68 == nil then
		p55:setCurrentInlineBale(nil)
	elseif p55:getCurrentInlineBale() == nil and v68:isa(InlineBaleSingle) then
		local v69 = v68:getConnectedInlineBale()
		if v69 ~= nil then
			p55:setCurrentInlineBale(v69)
			g_currentMission.activatableObjectsSystem:addActivatable(v57.activatable)
			p55:updateWrappingNodes()
			p55:getCurrentInlineBale():setCurrentWrapperInfo(p55, v57.wrappingStartNode)
		end
	end
	local v70 = next(v57.enteredInlineBales) ~= nil or v57.pushOffStarted
	if v70 then
		v70 = p55:getAttacherVehicle() == nil
	end
	local v71
	if v70 then
		v71 = not p55:getIsControlled()
	else
		v71 = v70
	end
	if v57.lineDirection == nil and v70 then
		local v72, _, v73 = localDirectionToWorld(p55.components[1].node, 0, 0, -1)
		v57.lineDirection = { v72, v73 }
	elseif v57.lineDirection ~= nil and not v70 then
		v57.lineDirection = nil
	end
	if v71 then
		v57.currentLineDirection = v57.lineDirection
	elseif v57.currentLineDirection ~= nil then
		v57.currentLineDirection = nil
		p55:updateInlineSteeringWheels()
	end
	if v57.currentLineDirection ~= nil then
		p55:updateInlineSteeringWheels(v57.currentLineDirection[1], v57.currentLineDirection[2])
	end
	if p55.isServer then
		v57.releaseBrake = false
		local v74 = p55:getCurrentInlineBale()
		if v57.pusherAnimationDirty then
			local v75 = true
			for _, v76 in pairs(v57.pendingSingleBales) do
				if not p55:getAllowBalePushing(NetworkUtil.getObject(v76)) then
					v75 = false
					break
				end
			end
			if v75 then
				for _, v77 in pairs(v57.enteredInlineBales) do
					if not p55:getAllowBalePushing(NetworkUtil.getObject(v77)) then
						v75 = false
						break
					end
				end
			end
			if v75 and v74 ~= nil then
				local v78 = v74:getPendingBale()
				local v79 = NetworkUtil.getObjectId(v78)
				local v80, v81 = v74:replacePendingBale(p55:getWrapperBaleType(v78).startNode, v57.wrapColor)
				if v80 then
					v57.enteredInlineBales[v79] = nil
					v57.enteredInlineBales[v81] = v81
				end
				p55:playAnimation(v57.animations.pusher, 1, 0)
				v57.pusherAnimationDirty = false
				v74:connectPendingBale()
				p55:raiseDirtyFlags(v57.inlineBalesDirtyFlag)
			end
			p55:raiseActive()
		end
		if p55:getAttacherVehicle() == nil then
			local v82 = v74 == nil or v74:getNumberOfBales() >= v57.pushingMinBaleAmount
			local v83 = p55:getAnimationTime(v57.animations.pusher)
			local v84 = p55:getIsAnimationPlaying(v57.animations.pusher)
			if v84 then
				if v57.pushingOpenBrakeTime < v83 then
					v84 = v83 < v57.pushingCloseBrakeTime
				else
					v84 = false
				end
			end
			local v85 = p55:getAnimationSpeed(v57.animations.pushOff)
			local v86 = p55:getIsAnimationPlaying(v57.animations.pushOff)
			if v86 then
				v86 = v85 > 0
			end
			local v87 = v84 or v86
			if v82 then
				v57.releaseBrake = v87
			end
		end
	end
	local v88 = false
	local v89 = nil
	for _, v90 in pairs(v57.enteredBalesToWrap) do
		local v91 = NetworkUtil.getObject(v90)
		if v91 ~= nil and entityExists(v91.nodeId) then
			local v92, v93, v94 = localToLocal(v91.nodeId, p55.components[1].node, 0, 0, 0)
			if v91.lastWrapTranslation == nil or v91.lastWrapMoveTime == nil then
				v91.lastWrapMoveTime = (-1 / 0)
				v91.lastWrapTranslation = { v92, v93, v94 }
			else
				local v95 = v91.lastWrapTranslation[1] - v92
				local v96 = math.abs(v95)
				local v97 = v91.lastWrapTranslation[2] - v93
				local v98 = v96 + math.abs(v97)
				local v99 = v91.lastWrapTranslation[3] - v94
				if v98 + math.abs(v99) > v57.baleMovedThreshold then
					v91.lastWrapMoveTime = g_currentMission.time
					v91.lastWrapTranslation = { v92, v93, v94 }
				end
			end
			if v91.lastWrapMoveTime + 1500 > g_currentMission.time then
				v89 = p55:getWrapperBaleType(v91)
				v88 = true
				break
			end
			p55:raiseActive()
		end
	end
	if v88 then
		if p55.isServer and v89 ~= nil then
			p55:updateConsumable(InlineWrapper.CONSUMABLE_TYPE_NAME, -v89.wrapUsage * p56, true)
		end
		if not p55:getIsAnimationPlaying(v57.animations.wrapping) then
			p55:playAnimation(v57.animations.wrapping, 1, p55:getAnimationTime(v57.animations.wrapping), true)
		end
		if p55.isClient and not (g_soundManager:getIsSamplePlaying(v57.samples.start) or g_soundManager:getIsSamplePlaying(v57.samples.wrap)) then
			g_soundManager:playSample(v57.samples.start)
			g_soundManager:playSample(v57.samples.wrap, 0, v57.samples.start)
		end
	else
		p55:stopAnimation(v57.animations.wrapping, true)
		if p55.isClient and (g_soundManager:getIsSamplePlaying(v57.samples.start) or g_soundManager:getIsSamplePlaying(v57.samples.wrap)) then
			g_soundManager:stopSample(v57.samples.start)
			g_soundManager:stopSample(v57.samples.wrap)
			g_soundManager:playSample(v57.samples.stop)
		end
	end
	local v100 = next(v57.pendingSingleBales) or next(v57.enteredInlineBales)
	local v101 = NetworkUtil.getObject(v100)
	if v101 == nil then
		p55:updateWrapperRailings(v57.railingStartX, p56)
	elseif p55:getIsInlineBalingAllowed() then
		local v102 = p55:getWrapperBaleType(v101)
		local v103 = p55:getCurrentInlineBale()
		if v103 ~= nil and not v103:getIsBaleAllowed(v101, v102) then
			v102 = nil
		end
		if v102 ~= nil then
			v57.targetPosition = v102.railingWidth
			p55:updateWrapperRailings(v57.targetPosition, p56)
		end
	end
	if p55.isServer and (v57.pushOffStarted ~= nil and (v57.pushOffStarted and not p55:getIsAnimationPlaying(v57.animations.pushOff))) then
		p55:playAnimation(v57.animations.pushOff, -1, 1)
		v57.pushOffStarted = nil
	end
	if p55.isClient then
		local v104 = v57.actionEvents[InputAction.ACTIVATE_OBJECT]
		if v104 ~= nil then
			g_inputBinding:setActionEventActive(v104.actionEventId, p55:getCanPushOff())
		end
	end
end
function InlineWrapper.onDraw(p105, _, _, _)
	if p105.isClient then
		local v106 = p105.spec_inlineWrapper
		if next(v106.pendingSingleBales) ~= nil then
			local v107 = p105:getFoldAnimTime()
			if v107 < v106.minFoldTime or v106.maxFoldTime < v107 then
				g_currentMission:showBlinkingWarning(p105.spec_foldable.unfoldWarning, 500)
			end
		end
		if v106.showIncompatibleBalesWarning then
			g_currentMission:showBlinkingWarning(g_i18n:getText("warning_baleNotSupported"), 500)
		end
	end
end
function InlineWrapper.updateWrappingNodes(p108)
	local v109 = p108.spec_inlineWrapper
	local v110 = p108:getCurrentInlineBale()
	if v110 == nil then
		if v109.resetWrappingNodes then
			for _, v111 in ipairs(v109.wrappingNodes) do
				setTranslation(v111.target, v111.startTrans[1], v111.startTrans[2], v111.startTrans[3])
			end
			v109.resetWrappingNodes = nil
		end
	else
		local v112 = v109.enteredBalesToWrap
		for _, v113 in ipairs(v109.wrappingNodes) do
			local v114, v115, v116 = getWorldTranslation(v113.node)
			local v117 = (1 / 0)
			local v118 = nil
			for _, v119 in pairs(v112) do
				local v120 = NetworkUtil.getObject(v119)
				if v120 ~= nil and v120 ~= v110:getPendingBale() then
					local v121, _, v122 = worldToLocal(v120.nodeId, v114, v115, v116)
					local v123 = nil
					local v124 = nil
					local v125 = nil
					local v126 = nil
					local v127 = nil
					local v128 = nil
					if v120.isRoundbale then
						if -v120.width / 2 <= v122 then
							v123, v124, v125 = localToWorld(v120.nodeId, 0, 0, v120.width / 2)
							v126, v127, v128 = localToWorld(v120.nodeId, 0, 0, -v120.width / 2)
						end
					elseif -v120.width / 2 <= v121 then
						v123, v124, v125 = localToWorld(v120.nodeId, v120.width / 2, 0, 0)
						v126, v127, v128 = localToWorld(v120.nodeId, -v120.width / 2, 0, 0)
					end
					if v123 ~= nil then
						local v129 = MathUtil.vector3Length(v114 - v123, v115 - v124, v116 - v125)
						local v130 = MathUtil.vector3Length
						local v131 = v114 - v126
						local v132 = v115 - v127
						local v133 = v116 - v128
						local v134 = math.min(v129, v130(v131, v132, v133))
						if v134 < v117 then
							v118 = v120
							v117 = v134
						end
					end
				end
			end
			if v118 == nil then
				setTranslation(v113.target, v113.startTrans[1], v113.startTrans[2], v113.startTrans[3])
			else
				local v135, v136, v137
				if v118.isRoundbale then
					v135, v136, v137 = p108:updateRoundBaleWrappingNode(v118, v113.node, v114, v115, v116)
				else
					v135, v136, v137 = p108:updateSquareBaleWrappingNode(v118, v113.node, v114, v115, v116)
				end
				if v135 == nil then
					setTranslation(v113.target, v113.startTrans[1], v113.startTrans[2], v113.startTrans[3])
				else
					local v138, v139, v140 = worldToLocal(getParent(v113.target), v135, v136, v137)
					setTranslation(v113.target, v138, v139, v140)
				end
			end
		end
		v109.resetWrappingNodes = true
	end
end
function InlineWrapper.updateRoundBaleWrappingNode(_, p141, p142, p143, p144, p145)
	local v146 = p141.nodeId
	local v147 = p141.diameter / 2
	local v148, v149, v150 = worldToLocal(v146, p143, p144, p145)
	local v151 = MathUtil.vector3Length(v148, v149, 0)
	local v152 = (-1 / 0)
	local v153 = nil
	local v154 = nil
	local v155 = nil
	for v156 = 1, 32 do
		local v157 = v156 / 32 * 2 * 3.141592653589793
		local v158 = math.cos(v157) * (v147 + 0.01)
		local v159 = math.sin(v157) * (v147 + 0.01)
		if MathUtil.vector2Length(v158 - v148, v159 - v149) < v151 then
			local v160, _, _, _, _ = MathUtil.getCircleLineIntersection(0, 0, v147, v148, v149, v158, v159)
			if not v160 then
				local v161, v162, v163 = localToWorld(v146, v158, v159, 0)
				local _, v164, _ = worldToLocal(p142, v161, v162, v163)
				if v152 < v164 then
					v153, v154, v155 = localToWorld(v146, math.cos(v157) * (v147 + -0.03), math.sin(v157) * (v147 + -0.03), v150)
					v152 = v164
				end
			end
		end
	end
	return v153, v154, v155
end
function InlineWrapper.updateSquareBaleWrappingNode(_, p165, p166, p167, p168, p169)
	local v170 = p165.nodeId
	local v171 = (1 / 0)
	local v172 = nil
	local v173 = nil
	local v174 = nil
	local v175 = p165.height / 2
	local v176 = p165.length / 2
	local v177, v178, v179 = worldToLocal(v170, p167, p168, p169)
	if p165.wrappingEdges == nil then
		p165.wrappingEdges = {}
		p165.wrappingEdges[1] = { 0, v175, -v176 }
		p165.wrappingEdges[2] = { 0, -v175, -v176 }
		p165.wrappingEdges[3] = { 0, -v175, v176 }
		p165.wrappingEdges[4] = { 0, v175, v176 }
	end
	for _, v180 in ipairs(p165.wrappingEdges) do
		local v181 = v180[2]
		local v182 = v180[2]
		local v183 = v181 + math.sign(v182) * 0.01
		local v184 = v180[3]
		local v185 = v180[3]
		local v186 = v184 + math.sign(v185) * 0.01
		local v187 = false
		for v188 = 1, 4 do
			local v189 = v188 <= 3 and (v188 + 1 or 1) or 1
			v187 = v187 or MathUtil.getLineBoundingVolumeIntersect(v183, v186, v178, v179, p165.wrappingEdges[v188][2], p165.wrappingEdges[v188][3], p165.wrappingEdges[v189][2], p165.wrappingEdges[v189][3])
		end
		if not v187 then
			local v190, v191, v192 = localToWorld(v170, v177, v183, v186)
			local _, v193, v194 = worldToLocal(p166, v190, v191, v192)
			local v195 = MathUtil.getYRotationFromDirection(v193, v194)
			if v195 < 0 then
				v195 = 3.141592653589793 + (3.141592653589793 + v195)
			end
			if v195 < v171 then
				local v196 = localToWorld
				local v197 = v180[2]
				local v198 = v180[2]
				local v199 = v197 + math.sign(v198) * -0.05
				local v200 = v180[3]
				local v201 = v180[3]
				v172, v173, v174 = v196(v170, v177, v199, v200 + math.sign(v201) * -0.05)
				v171 = v195
			end
		end
	end
	return v172, v173, v174
end
function InlineWrapper.onRegisterActionEvents(p202, p203, _)
	if p202.isClient then
		local v204 = p202.spec_inlineWrapper
		p202:clearActionEventsTable(v204.actionEvents)
		if p203 then
			local _, v205 = p202:addActionEvent(v204.actionEvents, InputAction.ACTIVATE_OBJECT, p202, InlineWrapper.pushOffInlineBaleEvent, false, false, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v205, GS_PRIO_HIGH)
			g_inputBinding:setActionEventActive(v205, p202:getCanPushOff())
			g_inputBinding:setActionEventTextVisibility(v205, true)
			g_inputBinding:setActionEventText(v205, g_i18n:getText("action_baleloaderUnload"))
		end
	end
end
function InlineWrapper.getIsFoldAllowed(p206, p207, p208, p209)
	local v210 = p206.spec_inlineWrapper
	if next(v210.enteredInlineBales) == nil then
		return p207(p206, p208, p209)
	else
		return false
	end
end
function InlineWrapper.getIsActive(p211, p212)
	local v213 = p211.spec_inlineWrapper
	return (v213.releaseBrake or v213.releaseBrake ~= v213.releaseBrakeSet) and true or p212(p211)
end
function InlineWrapper.getBrakeForce(p214, p215)
	local v216 = p214.spec_inlineWrapper
	if not v216.releaseBrake then
		return p215(p214)
	end
	v216.releaseBrakeSet = v216.releaseBrake
	return 0
end
function InlineWrapper.getShowConsumableEmptyWarning(p217, p218, p219)
	if p219 ~= InlineWrapper.CONSUMABLE_TYPE_NAME or not p218(p217, p219) then
		return p218(p217, p219)
	end
	local v220 = p217.spec_inlineWrapper
	if next(v220.pendingSingleBales) ~= nil then
		local v221 = p217:getFoldAnimTime()
		if v220.minFoldTime <= v221 or v221 <= v220.maxFoldTime then
			return true
		end
	end
	return false
end
function InlineWrapper.getIsInlineBalingAllowed(p222)
	local v223 = p222.spec_inlineWrapper
	local v224 = p222:getFoldAnimTime()
	if v224 < v223.minFoldTime or v223.maxFoldTime < v224 then
		return false
	elseif p222:getIsAnimationPlaying(v223.animations.pusher) then
		return false
	elseif p222:getIsAnimationPlaying(v223.animations.pushOff) or p222:getAnimationTime(v223.animations.pushOff) > 0 then
		return false
	else
		return p222:getConsumableIsAvailable(InlineWrapper.CONSUMABLE_TYPE_NAME)
	end
end
function InlineWrapper.inlineBaleTriggerCallback(p225, _, p226, p227, p228, _, _)
	if p225.isServer then
		local v229 = g_currentMission:getNodeObject(p226)
		if v229 ~= nil and v229:isa(Bale) then
			local v230 = NetworkUtil.getObjectId(v229)
			local v231 = p225.spec_inlineWrapper
			if p227 then
				if v229:isa(InlineBaleSingle) then
					v231.enteredInlineBales[v230] = v230
					local v232 = v229:getConnectedInlineBale()
					if v232 == nil then
						v229.inlineWrapperToAdd = {
							["wrapper"] = p225,
							["wrappingNode"] = v231.wrappingStartNode
						}
					else
						v232:setCurrentWrapperInfo(p225, v231.wrappingStartNode)
					end
				elseif p225:getWrapperBaleType(v229) == nil then
					v231.pendingIncompatibleBales[v230] = v230
				else
					v231.pendingSingleBales[v230] = v230
				end
			elseif p228 then
				v231.pendingSingleBales[v230] = nil
				v231.pendingIncompatibleBales[v230] = nil
				v231.enteredInlineBales[v230] = nil
				if v229:isa(InlineBaleSingle) then
					local v233 = v229:getConnectedInlineBale()
					if v233 ~= nil then
						local v234 = v233:getBales()
						local v235 = true
						for _, v236 in ipairs(v234) do
							local v237 = NetworkUtil.getObjectId(v236)
							if v231.pendingSingleBales[v237] ~= nil or v231.enteredInlineBales[v237] ~= nil then
								v235 = false
								break
							end
						end
						if v235 then
							v233:setCurrentWrapperInfo(nil, nil)
							p225:setCurrentInlineBale(nil)
						end
					end
				end
			end
			p225:raiseDirtyFlags(v231.inlineBalesDirtyFlag)
		end
	end
end
function InlineWrapper.inlineWrapTriggerCallback(p238, _, p239, p240, p241, _, _)
	if p238.isServer then
		local v242 = g_currentMission:getNodeObject(p239)
		if v242 ~= nil and v242:isa(Bale) then
			local v243 = p238.spec_inlineWrapper
			local v244 = NetworkUtil.getObjectId(v242)
			if p240 then
				v243.enteredBalesToWrap[v244] = v244
			elseif p241 then
				v243.enteredBalesToWrap[v244] = nil
			end
			p238:raiseActive()
			p238:raiseDirtyFlags(v243.inlineBalesDirtyFlag)
		end
	end
end
function InlineWrapper.getWrapperBaleType(p245, p246)
	local v247 = p245.spec_inlineWrapper
	for _, v248 in pairs(v247.baleTypes) do
		if p246:getSupportsWrapping() then
			if p246.isRoundbale then
				if v248.isRoundBale and (p246.diameter == v248.diameter and p246.width == v248.width) then
					return v248
				end
			elseif not v248.isRoundBale and (p246.width == v248.width and (p246.height == v248.height and p246.length == v248.length)) then
				return v248
			end
		end
	end
	return nil
end
function InlineWrapper.getAllowBalePushing(_, p249)
	return p249.dynamicMountJointIndex == nil
end
function InlineWrapper.updateWrapperRailings(p250, p251, p252)
	local v253 = p250.spec_inlineWrapper
	if p251 ~= v253.currentPosition then
		local v254 = p251 - v253.currentPosition
		local v255 = math.sign(v254)
		v253.currentPosition = v253.currentPosition + 0.0001 * p252 * v255
		if v255 > 0 then
			local v256 = v253.currentPosition
			v253.currentPosition = math.min(v256, p251)
		else
			local v257 = v253.currentPosition
			v253.currentPosition = math.max(v257, p251)
		end
		local v258 = (v253.currentPosition - v253.railingsAnimationStartX) / (v253.railingsAnimationEndX - v253.railingsAnimationStartX)
		p250:setAnimationTime(v253.railingsAnimation, v258, true)
	end
end
function InlineWrapper.updateInlineSteeringWheels(p259, p260, p261)
	local v262 = p259.spec_inlineWrapper
	for _, v263 in ipairs(v262.steeringNodes) do
		if p260 == nil or p261 == nil then
			local v264 = setRotation
			local v265 = v263.node
			local v266 = v263.startRot
			v264(v265, unpack(v266))
		else
			local v267, v268, v269 = getWorldTranslation(v263.node)
			local v270, _, v271 = worldToLocal(getParent(v263.node), v267 + p260 * 10, v268, v269 + p261 * 10)
			local v272, _, v273 = MathUtil.vector3Normalize(v270, 0, v271)
			local v274, v275, v276 = localDirectionToWorld(getParent(v263.node), 0, 1, 0)
			setDirection(v263.node, v272, 0, v273, v274, v275, v276)
		end
		if p259.setMovingToolDirty ~= nil then
			p259:setMovingToolDirty(v263.node)
		end
	end
end
function InlineWrapper.onLeaveVehicle(p277)
	p277.rotatedTime = 0
end
function InlineWrapper.onEnterVehicle(p278)
	local v279 = p278.spec_inlineWrapper
	for _, v280 in ipairs(v279.steeringNodes) do
		local v281 = setRotation
		local v282 = v280.node
		local v283 = v280.startRot
		v281(v282, unpack(v283))
		if p278.setMovingToolDirty ~= nil then
			p278:setMovingToolDirty(v280.node)
		end
	end
end
function InlineWrapper.onConsumableVariationChanged(p284, _, p285)
	if p285.color ~= nil then
		local v286 = p284.spec_inlineWrapper
		v286.wrapColor[1] = p285.color[1]
		v286.wrapColor[2] = p285.color[2]
		v286.wrapColor[3] = p285.color[3]
	end
end
function InlineWrapper.getCanInteract(p287)
	local v288 = g_localPlayer
	if v288:getIsInVehicle() then
		return false
	end
	if not g_currentMission.accessHandler:canPlayerAccess(p287) then
		return false
	end
	local v289, v290, v291 = v288:getPosition()
	local v292, v293, v294 = getWorldTranslation(p287.components[1].node)
	return MathUtil.vector3Length(v289 - v292, v290 - v293, v291 - v294) < InlineWrapper.INTERACTION_RADIUS
end
function InlineWrapper.getCanPushOff(p295)
	local v296 = p295.spec_inlineWrapper
	local v297 = p295:getCurrentInlineBale()
	if v297 == nil then
		return false
	elseif v297:getPendingBale() == nil then
		if p295:getIsAnimationPlaying(v296.animations.pusher) then
			return false
		else
			return not p295:getIsAnimationPlaying(v296.animations.pushOff)
		end
	else
		return false
	end
end
function InlineWrapper.setCurrentInlineBale(p298, p299, p300)
	local v301 = p298.spec_inlineWrapper
	if p298.isServer then
		local v302 = NetworkUtil.getObjectId(p299)
		if v302 ~= v301.currentInlineBale then
			v301.currentInlineBale = v302
			p298:raiseDirtyFlags(v301.inlineBalesDirtyFlag)
		end
	end
	if p300 then
		v301.currentInlineBale = p299
	end
end
function InlineWrapper.getCurrentInlineBale(p303)
	return NetworkUtil.getObject(p303.spec_inlineWrapper.currentInlineBale)
end
function InlineWrapper.pushOffInlineBaleEvent(p304, _, p305, _, _)
	if p305 == 1 then
		if g_server ~= nil then
			p304:pushOffInlineBale()
			return
		end
		g_client:getServerConnection():sendEvent(InlineWrapperPushOffEvent.new(p304))
	end
end
function InlineWrapper.pushOffInlineBale(p306)
	local v307 = p306.spec_inlineWrapper
	if not p306:getIsAnimationPlaying(v307.animations.pushOff) then
		p306:playAnimation(v307.animations.pushOff, 1)
		v307.pushOffStarted = true
	end
end
function InlineWrapper.loadSpecValueBaleSize(p_u_308, _, _, p_u_309)
	local v_u_310 = {
		["minDiameter"] = (1 / 0),
		["maxDiameter"] = (-1 / 0),
		["minLength"] = (1 / 0),
		["maxLength"] = (-1 / 0)
	}
	p_u_308:iterate(p_u_308:getRootName() .. ".inlineWrapper.baleTypes.baleType", function(_, p311)
		-- upvalues: (copy) p_u_308, (copy) p_u_309, (copy) v_u_310
		local v312 = MathUtil.round(p_u_308:getValue(p311 .. ".size#diameter", 0), 2)
		if p_u_309 and v312 ~= 0 then
			local v313 = v_u_310
			local v314 = v_u_310.minDiameter
			v313.minDiameter = math.min(v314, v312)
			local v315 = v_u_310
			local v316 = v_u_310.maxDiameter
			v315.maxDiameter = math.max(v316, v312)
		end
		local v317 = MathUtil.round(p_u_308:getValue(p311 .. ".size#length", 0), 2)
		if not p_u_309 and v317 ~= 0 then
			local v318 = v_u_310
			local v319 = v_u_310.minLength
			v318.minLength = math.min(v319, v317)
			local v320 = v_u_310
			local v321 = v_u_310.maxLength
			v320.maxLength = math.max(v321, v317)
		end
	end)
	if v_u_310.minDiameter == (1 / 0) and v_u_310.minLength == (1 / 0) then
		return nil
	else
		return v_u_310
	end
end
function InlineWrapper.getSpecValueBaleSize(p322, _, _, _, p323, p324, p325)
	local v326 = p325 and p322.specs.inlineWrapperBaleSizeRound or p322.specs.inlineWrapperBaleSizeSquare
	if v326 == nil then
		if p323 and p324 then
			return 0, 0, ""
		elseif p323 then
			return 0, ""
		else
			return ""
		end
	else
		local v327 = p325 and v326.minDiameter or v326.minLength
		local v328 = p325 and v326.maxDiameter or v326.maxLength
		if p323 == nil or not p323 then
			local v329 = g_i18n:getText("unit_cmShort")
			if v328 == v327 then
				return string.format("%d%s", v327 * 100, v329)
			else
				return string.format("%d%s-%d%s", v327 * 100, v329, v328 * 100, v329)
			end
		elseif p324 == true and v328 ~= v327 then
			return v327 * 100, v328 * 100, g_i18n:getText("unit_cmShort")
		else
			return v327 * 100, g_i18n:getText("unit_cmShort")
		end
	end
end
function InlineWrapper.loadSpecValueBaleSizeRound(p330, p331, p332)
	return InlineWrapper.loadSpecValueBaleSize(p330, p331, p332, true)
end
function InlineWrapper.loadSpecValueBaleSizeSquare(p333, p334, p335)
	return InlineWrapper.loadSpecValueBaleSize(p333, p334, p335, false)
end
function InlineWrapper.getSpecValueBaleSizeRound(p336, p337, p338, p339, p340, p341)
	if p336.specs.inlineWrapperBaleSizeRound == nil then
		return nil
	else
		return InlineWrapper.getSpecValueBaleSize(p336, p337, p338, p339, p340, p341, true)
	end
end
function InlineWrapper.getSpecValueBaleSizeSquare(p342, p343, p344, p345, p346, p347)
	if p342.specs.inlineWrapperBaleSizeSquare == nil then
		return nil
	else
		return InlineWrapper.getSpecValueBaleSize(p342, p343, p344, p345, p346, p347, false)
	end
end
InlineWrapperActivatable = {}
local v_u_348 = Class(InlineWrapperActivatable)
function InlineWrapperActivatable.new(p349)
	-- upvalues: (copy) v_u_348
	local v350 = v_u_348
	local v351 = setmetatable({}, v350)
	v351.inlineWrapper = p349
	v351.activateText = g_i18n:getText("action_baleloaderUnload")
	return v351
end
function InlineWrapperActivatable.getIsActivatable(p352)
	return p352.inlineWrapper:getCanInteract() and p352.inlineWrapper:getCanPushOff() and true or false
end
function InlineWrapperActivatable.run(p353)
	if g_server == nil then
		g_client:getServerConnection():sendEvent(InlineWrapperPushOffEvent.new(p353.inlineWrapper))
	else
		p353.inlineWrapper:pushOffInlineBale()
	end
end

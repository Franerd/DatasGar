ConnectionHoses = {}
ConnectionHoses.DEFAULT_MAX_UPDATE_DISTANCE = 50
function ConnectionHoses.prerequisitesPresent(_)
	return true
end
function ConnectionHoses.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("ConnectionHoses")
	v1:register(XMLValueType.FLOAT, "vehicle.connectionHoses#maxUpdateDistance", "Max. distance to vehicle root to update connection hoses", ConnectionHoses.DEFAULT_MAX_UPDATE_DISTANCE)
	ConnectionHoses.registerConnectionHoseXMLPaths(v1, "vehicle.connectionHoses")
	ConnectionHoses.registerConnectionHoseXMLPaths(v1, "vehicle.connectionHoses.connectionHoseConfigurations.connectionHoseConfiguration(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.connectionHoses.sounds", "connect(?)")
	v1:register(XMLValueType.STRING, "vehicle.connectionHoses.sounds.connect(?)#type", "Connection hose type")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.connectionHoses.sounds", "disconnect(?)")
	v1:register(XMLValueType.STRING, "vehicle.connectionHoses.sounds.disconnect(?)#type", "Connection hose type")
	v1:addDelayedRegistrationFunc("Cylindered:movingTool", function(p2, p3)
		p2:register(XMLValueType.VECTOR_N, p3 .. ".connectionHoses#customHoseIndices", "Custom hoses to update")
		p2:register(XMLValueType.VECTOR_N, p3 .. ".connectionHoses#customTargetIndices", "Custom hose targets to update")
		p2:register(XMLValueType.VECTOR_N, p3 .. ".connectionHoses#localHoseIndices", "Local hoses to update")
	end)
	v1:addDelayedRegistrationFunc("Cylindered:movingPart", function(p4, p5)
		p4:register(XMLValueType.VECTOR_N, p5 .. ".connectionHoses#customHoseIndices", "Custom hoses to update")
		p4:register(XMLValueType.VECTOR_N, p5 .. ".connectionHoses#customTargetIndices", "Custom hose targets to update")
		p4:register(XMLValueType.VECTOR_N, p5 .. ".connectionHoses#localHoseIndices", "Local hoses to update")
	end)
	v1:setXMLSpecializationType()
end
function ConnectionHoses.registerConnectionHoseXMLPaths(p6, p7)
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".skipNode(?)#node", "Skip node")
	p6:register(XMLValueType.INT, p7 .. ".skipNode(?)#inputAttacherJointIndex", "Input attacher joint index", 1)
	p6:register(XMLValueType.INT, p7 .. ".skipNode(?)#attacherJointIndex", "Attacher joint index", 1)
	p6:register(XMLValueType.STRING, p7 .. ".skipNode(?)#type", "Connection hose type")
	p6:register(XMLValueType.STRING, p7 .. ".skipNode(?)#specType", "Connection hose specialization type (if defined it needs to match the type of the other tool)")
	p6:register(XMLValueType.FLOAT, p7 .. ".skipNode(?)#length", "Hose length")
	p6:register(XMLValueType.BOOL, p7 .. ".skipNode(?)#isTwoPointHose", "Is two point hose without sagging", false)
	ConnectionHoses.registerHoseTargetNodesXMLPaths(p6, p7 .. ".target(?)")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".toolConnectorHose(?)#mountingNode", "Mounting node to toggle visibility")
	p6:register(XMLValueType.BOOL, p7 .. ".toolConnectorHose(?)#moveNodes", "Defines if the start and end nodes are moved up depending on hose diameter", true)
	p6:register(XMLValueType.BOOL, p7 .. ".toolConnectorHose(?)#additionalHose", "Defines if between start and end node a additional hose is created", true)
	ConnectionHoses.registerHoseTargetNodesXMLPaths(p6, p7 .. ".toolConnectorHose(?).startTarget(?)")
	ConnectionHoses.registerHoseTargetNodesXMLPaths(p6, p7 .. ".toolConnectorHose(?).endTarget(?)")
	ConnectionHoses.registerHoseNodesXMLPaths(p6, p7 .. ".hose(?)")
	ConnectionHoses.registerHoseNodesXMLPaths(p6, p7 .. ".localHose(?).hose")
	ConnectionHoses.registerHoseTargetNodesXMLPaths(p6, p7 .. ".localHose(?).target")
	ConnectionHoses.registerCustomHoseNodesXMLPaths(p6, p7 .. ".customHose(?)")
	ConnectionHoses.registerCustomHoseTargetNodesXMLPaths(p6, p7 .. ".customTarget(?)")
end
function ConnectionHoses.registerHoseTargetNodesXMLPaths(p8, p9)
	p8:register(XMLValueType.NODE_INDEX, p9 .. "#node", "Target node")
	p8:register(XMLValueType.VECTOR_N, p9 .. "#attacherJointIndices", "List of corresponding attacher joint indices")
	p8:register(XMLValueType.NODE_INDICES, p9 .. "#attacherJointNodes", "List of corresponding attacher joint nodes (i3dIdentifiers or paths separated by space)")
	p8:register(XMLValueType.STRING, p9 .. "#type", "Hose type")
	p8:registerAutoCompletionDataSource(p9 .. "#type", "data/shared/connectionHoses/connectionHoses.xml", "connectionHoses.connectionHoseTypes.connectionHoseType#name")
	p8:register(XMLValueType.STRING, p9 .. "#specType", "Connection hose specialization type (if defined it needs to match the type of the other tool)")
	p8:register(XMLValueType.FLOAT, p9 .. "#straighteningFactor", "Straightening Factor", 1)
	p8:register(XMLValueType.VECTOR_3, p9 .. "#straighteningDirection", "Straightening direction", "0 0 1")
	p8:register(XMLValueType.STRING, p9 .. "#socket", "Socket name to load")
	p8:register(XMLValueType.VEHICLE_MATERIAL, p9 .. "#socketMaterialTemplateName", "Socket custom material")
	p8:registerAutoCompletionDataSource(p9 .. "#socketMaterialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p8:register(XMLValueType.STRING, p9 .. "#adapterType", "Adapter type to use", "DEFAULT")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p8, p9)
end
function ConnectionHoses.registerHoseNodesXMLPaths(p10, p11)
	p10:register(XMLValueType.VECTOR_N, p11 .. "#inputAttacherJointIndices", "List of corresponding input attacher joint indices")
	p10:register(XMLValueType.NODE_INDICES, p11 .. "#inputAttacherJointNodes", "List of corresponding input attacher joint nodes (i3dIdentifiers or paths separated by space)")
	p10:register(XMLValueType.STRING, p11 .. "#type", "Hose type")
	p10:register(XMLValueType.STRING, p11 .. "#specType", "Connection hose specialization type (if defined it needs to match the type of the other tool)")
	p10:register(XMLValueType.STRING, p11 .. "#hoseType", "Hose material type", "DEFAULT")
	p10:register(XMLValueType.NODE_INDEX, p11 .. "#node", "Hose output node")
	p10:register(XMLValueType.BOOL, p11 .. "#isTwoPointHose", "Is two point hose without sagging", false)
	p10:register(XMLValueType.BOOL, p11 .. "#isWorldSpaceHose", "Sagging is calculated in world space or local space of hose node", true)
	p10:register(XMLValueType.STRING, p11 .. "#dampingRange", "Damping range in meters", 0.05)
	p10:register(XMLValueType.FLOAT, p11 .. "#dampingFactor", "Damping factor", 50)
	p10:register(XMLValueType.FLOAT, p11 .. "#length", "Hose length", 3)
	p10:register(XMLValueType.FLOAT, p11 .. "#diameter", "Hose diameter", 0.02)
	p10:register(XMLValueType.FLOAT, p11 .. "#straighteningFactor", "Straightening Factor", 1)
	p10:register(XMLValueType.FLOAT, p11 .. "#centerPointDropFactor", "Can be used to manipulate how much the hose will drop while it\'s getting shorter then set", 1)
	p10:register(XMLValueType.FLOAT, p11 .. "#centerPointTension", "Defines the tension on the center control point (0: default behavior)", 0)
	p10:register(XMLValueType.ANGLE, p11 .. "#minCenterPointAngle", "Min. angle of sagged curve", "Defined on connectionHose xml, default 90 degree")
	p10:register(XMLValueType.VECTOR_TRANS, p11 .. "#minCenterPointOffset", "Min. center point offset from hose node", "unlimited")
	p10:register(XMLValueType.VECTOR_TRANS, p11 .. "#maxCenterPointOffset", "Max. center point offset from hose node", "unlimited")
	p10:register(XMLValueType.FLOAT, p11 .. "#minDeltaY", "Min. delta Y from center point")
	p10:register(XMLValueType.NODE_INDEX, p11 .. "#minDeltaYComponent", "Min. delta Y reference node")
	p10:register(XMLValueType.VEHICLE_MATERIAL, p11 .. "#materialTemplateName", "Hose material")
	p10:registerAutoCompletionDataSource(p11 .. "#materialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p10:register(XMLValueType.VEHICLE_MATERIAL, p11 .. "#adapterMaterialTemplateName", "Material of colorable part of adapter")
	p10:registerAutoCompletionDataSource(p11 .. "#adapterMaterialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p10:register(XMLValueType.STRING, p11 .. "#adapterType", "Adapter type name")
	p10:register(XMLValueType.NODE_INDEX, p11 .. "#adapterNode", "Link node for detached adapter")
	p10:register(XMLValueType.STRING, p11 .. "#outgoingAdapter", "Adapter type that is used for outgoing connection hose")
	p10:register(XMLValueType.STRING, p11 .. "#socket", "Outgoing socket name to load")
	p10:register(XMLValueType.VEHICLE_MATERIAL, p11 .. "#socketMaterialTemplateName", "Socket custom material")
	p10:registerAutoCompletionDataSource(p11 .. "#socketMaterialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p10, p11)
end
function ConnectionHoses.registerCustomHoseNodesXMLPaths(p12, p13)
	p12:register(XMLValueType.NODE_INDEX, p13 .. "#node", "Target or source node")
	p12:register(XMLValueType.STRING, p13 .. "#type", "Hose type which can be any string that needs to match between hose and target node")
	p12:register(XMLValueType.VECTOR_N, p13 .. "#inputAttacherJointIndices", "Input attacher joint indices")
	p12:register(XMLValueType.VECTOR_N, p13 .. "#attacherJointIndices", "Attacher joint indices")
	p12:register(XMLValueType.BOOL, p13 .. "#isActiveDirty", "Custom hose is permanently updated", false)
	ObjectChangeUtil.registerObjectChangeXMLPaths(p12, p13)
end
function ConnectionHoses.registerCustomHoseTargetNodesXMLPaths(p14, p15)
	p14:register(XMLValueType.NODE_INDEX, p15 .. "#node", "Target or source node")
	p14:register(XMLValueType.STRING, p15 .. "#type", "Hose type which can be any string that needs to match between hose and target node")
	p14:register(XMLValueType.VECTOR_N, p15 .. "#inputAttacherJointIndices", "Input attacher joint indices")
	p14:register(XMLValueType.VECTOR_N, p15 .. "#attacherJointIndices", "Attacher joint indices")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p14, p15)
end
function ConnectionHoses.registerFunctions(p16)
	SpecializationUtil.registerFunction(p16, "getConnectionHoseConfigIndex", ConnectionHoses.getConnectionHoseConfigIndex)
	SpecializationUtil.registerFunction(p16, "updateAttachedConnectionHoses", ConnectionHoses.updateAttachedConnectionHoses)
	SpecializationUtil.registerFunction(p16, "updateConnectionHose", ConnectionHoses.updateConnectionHose)
	SpecializationUtil.registerFunction(p16, "getCenterPointAngle", ConnectionHoses.getCenterPointAngle)
	SpecializationUtil.registerFunction(p16, "getCenterPointAngleRegulation", ConnectionHoses.getCenterPointAngleRegulation)
	SpecializationUtil.registerFunction(p16, "loadConnectionHosesFromXML", ConnectionHoses.loadConnectionHosesFromXML)
	SpecializationUtil.registerFunction(p16, "loadHoseSkipNode", ConnectionHoses.loadHoseSkipNode)
	SpecializationUtil.registerFunction(p16, "loadToolConnectorHoseNode", ConnectionHoses.loadToolConnectorHoseNode)
	SpecializationUtil.registerFunction(p16, "addHoseTargetNodes", ConnectionHoses.addHoseTargetNodes)
	SpecializationUtil.registerFunction(p16, "loadCustomHosesFromXML", ConnectionHoses.loadCustomHosesFromXML)
	SpecializationUtil.registerFunction(p16, "loadHoseTargetNode", ConnectionHoses.loadHoseTargetNode)
	SpecializationUtil.registerFunction(p16, "loadHoseNode", ConnectionHoses.loadHoseNode)
	SpecializationUtil.registerFunction(p16, "getClonedSkipHoseNode", ConnectionHoses.getClonedSkipHoseNode)
	SpecializationUtil.registerFunction(p16, "getConnectionTarget", ConnectionHoses.getConnectionTarget)
	SpecializationUtil.registerFunction(p16, "iterateConnectionTargets", ConnectionHoses.iterateConnectionTargets)
	SpecializationUtil.registerFunction(p16, "getIsConnectionTargetUsed", ConnectionHoses.getIsConnectionTargetUsed)
	SpecializationUtil.registerFunction(p16, "getIsConnectionHoseUsed", ConnectionHoses.getIsConnectionHoseUsed)
	SpecializationUtil.registerFunction(p16, "getIsSkipNodeAvailable", ConnectionHoses.getIsSkipNodeAvailable)
	SpecializationUtil.registerFunction(p16, "getConnectionHosesByInputAttacherJoint", ConnectionHoses.getConnectionHosesByInputAttacherJoint)
	SpecializationUtil.registerFunction(p16, "connectHose", ConnectionHoses.connectHose)
	SpecializationUtil.registerFunction(p16, "disconnectHose", ConnectionHoses.disconnectHose)
	SpecializationUtil.registerFunction(p16, "updateToolConnectionHose", ConnectionHoses.updateToolConnectionHose)
	SpecializationUtil.registerFunction(p16, "addHoseToDelayedMountings", ConnectionHoses.addHoseToDelayedMountings)
	SpecializationUtil.registerFunction(p16, "connectHoseToSkipNode", ConnectionHoses.connectHoseToSkipNode)
	SpecializationUtil.registerFunction(p16, "connectHosesToAttacherVehicle", ConnectionHoses.connectHosesToAttacherVehicle)
	SpecializationUtil.registerFunction(p16, "retryHoseSkipNodeConnections", ConnectionHoses.retryHoseSkipNodeConnections)
	SpecializationUtil.registerFunction(p16, "connectCustomHosesToAttacherVehicle", ConnectionHoses.connectCustomHosesToAttacherVehicle)
	SpecializationUtil.registerFunction(p16, "connectCustomHoseNode", ConnectionHoses.connectCustomHoseNode)
	SpecializationUtil.registerFunction(p16, "updateCustomHoseNode", ConnectionHoses.updateCustomHoseNode)
	SpecializationUtil.registerFunction(p16, "disconnectCustomHoseNode", ConnectionHoses.disconnectCustomHoseNode)
end
function ConnectionHoses.registerOverwrittenFunctions(p17)
	SpecializationUtil.registerOverwrittenFunction(p17, "loadExtraDependentParts", ConnectionHoses.loadExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p17, "updateExtraDependentParts", ConnectionHoses.updateExtraDependentParts)
end
function ConnectionHoses.registerEventListeners(p18)
	SpecializationUtil.registerEventListener(p18, "onPreLoad", ConnectionHoses)
	SpecializationUtil.registerEventListener(p18, "onPostLoad", ConnectionHoses)
	SpecializationUtil.registerEventListener(p18, "onLoadFinished", ConnectionHoses)
	SpecializationUtil.registerEventListener(p18, "onDelete", ConnectionHoses)
	SpecializationUtil.registerEventListener(p18, "onPostUpdate", ConnectionHoses)
	SpecializationUtil.registerEventListener(p18, "onUpdateEnd", ConnectionHoses)
	SpecializationUtil.registerEventListener(p18, "onPostAttach", ConnectionHoses)
	SpecializationUtil.registerEventListener(p18, "onPreDetach", ConnectionHoses)
end
function ConnectionHoses.onPreLoad(p19, _)
	local v20 = p19.spec_connectionHoses
	v20.configIndex = p19:getConnectionHoseConfigIndex()
	v20.numHosesByType = {}
	v20.numToolConnectionsByType = {}
	v20.hoseSkipNodes = {}
	v20.hoseSkipNodeByType = {}
	v20.targetNodes = {}
	v20.targetNodesByType = {}
	v20.toolConnectorHoses = {}
	v20.targetNodeToToolConnection = {}
	v20.hoseNodes = {}
	v20.hoseNodesByInputAttacher = {}
	v20.localHoseNodes = {}
	v20.customHoses = {}
	v20.customHosesByAttacher = {}
	v20.customHosesByInputAttacher = {}
	v20.customHosesActiveDirty = {}
	v20.customHoseTargets = {}
	v20.customHoseTargetsByAttacher = {}
	v20.customHoseTargetsByInputAttacher = {}
	v20.additionalSharedLoadRequestIds = {}
	v20.maxUpdateDistance = p19.xmlFile:getValue("vehicle.connectionHoses#maxUpdateDistance", ConnectionHoses.DEFAULT_MAX_UPDATE_DISTANCE)
end
function ConnectionHoses.onPostLoad(p_u_21, _)
	local v_u_22 = p_u_21.spec_connectionHoses
	local v23 = string.format("vehicle.connectionHoses.connectionHoseConfigurations.connectionHoseConfiguration(%d)", v_u_22.configIndex - 1)
	p_u_21:loadConnectionHosesFromXML(p_u_21.xmlFile, "vehicle.connectionHoses")
	if p_u_21.xmlFile:hasProperty(v23) then
		p_u_21:loadConnectionHosesFromXML(p_u_21.xmlFile, v23)
	end
	ConnectionHoses.registerAdditionalToolConnectionHoses(p_u_21)
	v_u_22.targetNodesAvailable = #v_u_22.targetNodes > 0
	v_u_22.hoseNodesAvailable = #v_u_22.hoseNodes > 0
	v_u_22.localHosesAvailable = #v_u_22.localHoseNodes > 0
	v_u_22.skipNodesAvailable = #v_u_22.hoseSkipNodes > 0
	v_u_22.activeDirtyCustomHosesAvailable = #v_u_22.customHosesActiveDirty > 0
	v_u_22.updateableHoses = {}
	if p_u_21.isClient then
		local function v33(p24)
			-- upvalues: (copy) p_u_21, (copy) v_u_22
			local v25 = 0
			local v26 = {}
			while true do
				local v27 = string.format("%s(%d)", p24, v25)
				local v28 = "vehicle.connectionHoses.sounds." .. v27
				if not p_u_21.xmlFile:hasProperty(v28) then
					return v26
				end
				local v29 = g_soundManager:loadSampleFromXML(p_u_21.xmlFile, "vehicle.connectionHoses.sounds", v27, p_u_21.baseDirectory, p_u_21.components, 1, AudioGroup.VEHICLE, p_u_21.i3dMappings, p_u_21)
				if v29 ~= nil then
					local v30 = p_u_21.xmlFile:getValue(v28 .. "#type")
					local v31 = false
					for _, v32 in ipairs(v_u_22.hoseNodes) do
						if v32.type == v30 then
							v31 = true
							break
						end
					end
					if v31 then
						v26[v30] = v29
					else
						Logging.xmlWarning(p_u_21.xmlFile, "Failed load %s-sound with type %s. No hose with that type available.", p24, v30)
					end
				end
				v25 = v25 + 1
			end
		end
		v_u_22.samples = {}
		v_u_22.samples.connect = v33("connect")
		v_u_22.samples.disconnect = v33("disconnect")
	end
	if not (p_u_21.isClient and (v_u_22.targetNodesAvailable or (v_u_22.hoseNodesAvailable or (v_u_22.localHosesAvailable or (v_u_22.skipNodesAvailable or v_u_22.activeDirtyCustomHosesAvailable))))) then
		SpecializationUtil.removeEventListener(p_u_21, "onPostUpdate", ConnectionHoses)
	end
end
function ConnectionHoses.onLoadFinished(p34, _)
	local v35 = p34.spec_connectionHoses
	for _, v36 in ipairs(v35.localHoseNodes) do
		p34:connectHose(v36.hose, p34, v36.target, false)
	end
end
function ConnectionHoses.onDelete(p37)
	local v38 = p37.spec_connectionHoses
	if v38.additionalSharedLoadRequestIds ~= nil then
		for v39 = 1, #v38.additionalSharedLoadRequestIds do
			g_i3DManager:releaseSharedI3DFile(v38.additionalSharedLoadRequestIds[v39])
		end
		v38.additionalSharedLoadRequestIds = nil
	end
	if v38.samples ~= nil then
		g_soundManager:deleteSamples(v38.samples.connect)
		g_soundManager:deleteSamples(v38.samples.disconnect)
	end
end
function ConnectionHoses.onPostUpdate(p40, _, _, _, _)
	local v41 = p40.spec_connectionHoses
	if p40.currentUpdateDistance < v41.maxUpdateDistance then
		for v42 = 1, #v41.updateableHoses do
			local v43 = v41.updateableHoses[v42]
			if p40.updateLoopIndex == v43.connectedObject.updateLoopIndex then
				p40:updateConnectionHose(v43, v42)
			end
		end
		if p40.getAttachedImplements ~= nil then
			local v44 = p40:getAttachedImplements()
			for v45 = 1, #v44 do
				local v46 = v44[v45].object
				if v46.updateAttachedConnectionHoses ~= nil then
					v46:updateAttachedConnectionHoses(p40)
				end
			end
		end
		for _, v47 in ipairs(v41.customHosesActiveDirty) do
			if v47.isActive and v47.connectedTarget ~= nil then
				p40:updateCustomHoseNode(v47, v47.connectedTarget)
			end
		end
	end
end
function ConnectionHoses.onUpdateEnd(p48, p49, p50, p51, p52)
	ConnectionHoses.onPostUpdate(p48, p49, p50, p51, p52)
end
function ConnectionHoses.getConnectionHoseConfigIndex(_)
	return 1
end
function ConnectionHoses.updateAttachedConnectionHoses(p53, p54)
	local v55 = p53.spec_connectionHoses
	for v56 = 1, #v55.updateableHoses do
		local v57 = v55.updateableHoses[v56]
		if v57.connectedObject == p54 and p53.updateLoopIndex == v57.connectedObject.updateLoopIndex then
			p53:updateConnectionHose(v57, v56)
		end
	end
end
function ConnectionHoses.updateConnectionHose(p58, p59, p60)
	local v61 = -p59.startStraightening
	local v62, v63, v64 = localToLocal(p59.targetNode, p59.hoseNode, 0, 0, 0)
	local v65, v66, v67 = localToLocal(p59.targetNode, p59.hoseNode, p59.endStraighteningDirection[1] * p59.endStraightening, p59.endStraighteningDirection[2] * p59.endStraightening, p59.endStraighteningDirection[3] * p59.endStraightening)
	local v68, v69, v70
	if p59.isWorldSpaceHose then
		local v71, v72, v73 = getWorldTranslation(p59.hoseNode)
		local v74, v75, v76 = getWorldTranslation(p59.targetNode)
		v68 = (v71 + v74) / 2
		v69 = (v72 + v75) / 2
		v70 = (v73 + v76) / 2
	else
		v68 = v62 / 2
		v69 = v63 / 2
		v70 = v64 / 2
	end
	local v77 = MathUtil.vector3Length(v62, v63, v64)
	local v78 = p59.length - v77
	local v79 = math.max(v78, 0) * (p59.centerPointDropFactor or 1)
	local v80
	if p59.isWorldSpaceHose then
		v80 = v69
	else
		local v81, v82
		v81, v80, v82 = localToWorld(p59.hoseNode, v68, v69, v70)
	end
	local v83 = 0.04 * v77
	local v84 = v69 - math.max(v79, v83)
	if p59.isWorldSpaceHose then
		if p59.minDeltaY ~= (1 / 0) then
			local v85, v86, v87 = worldToLocal(p59.minDeltaYComponent, v68, v84, v70)
			local _, v88, _ = localToLocal(p59.hoseNode, p59.minDeltaYComponent, 0, 0, 0)
			local v89 = localToWorld
			local v90 = p59.minDeltaYComponent
			local v91 = v88 + p59.minDeltaY
			v68, v84, v70 = v89(v90, v85, math.max(v86, v91), v87)
		end
		v68, v84, v70 = worldToLocal(p59.hoseNode, v68, v84, v70)
	end
	local v92, v93 = p58:getCenterPointAngle(p59.hoseNode, v68, v84, v70, v62, v63, v64, p59.isWorldSpaceHose)
	local v94 = v92 + v93
	if v94 < p59.minCenterPointAngle then
		v68, v84, v70 = p58:getCenterPointAngleRegulation(p59.hoseNode, v68, v84, v70, v62, v63, v64, v92, v93, p59.minCenterPointAngle, p59.isWorldSpaceHose)
	end
	if p59.minCenterPointOffset ~= nil and p59.maxCenterPointOffset ~= nil then
		local v95 = p59.minCenterPointOffset[1]
		local v96 = p59.maxCenterPointOffset[1]
		v68 = math.clamp(v68, v95, v96)
		local v97 = p59.minCenterPointOffset[2]
		local v98 = p59.maxCenterPointOffset[2]
		v84 = math.clamp(v84, v97, v98)
		local v99 = p59.minCenterPointOffset[3]
		local v100 = p59.maxCenterPointOffset[3]
		v70 = math.clamp(v70, v99, v100)
	end
	local v101, v102, v103 = getWorldTranslation(p59.component)
	if p59.lastComponentPosition == nil or p59.lastComponentVelocity == nil then
		p59.lastComponentPosition = { v101, v102, v103 }
		p59.lastComponentVelocity = { v101, v102, v103 }
	end
	local v104 = v101 - p59.lastComponentPosition[1]
	local v105 = v102 - p59.lastComponentPosition[2]
	local v106 = v103 - p59.lastComponentPosition[3]
	local v107 = p59.lastComponentPosition
	local v108 = p59.lastComponentPosition
	local v109 = p59.lastComponentPosition
	v107[1] = v101
	v108[2] = v102
	v109[3] = v103
	local v110 = v104 - p59.lastComponentVelocity[1]
	local v111 = v105 - p59.lastComponentVelocity[2]
	local v112 = v106 - p59.lastComponentVelocity[3]
	local v113 = p59.lastComponentVelocity
	local v114 = p59.lastComponentVelocity
	local v115 = p59.lastComponentVelocity
	v113[1] = v104
	v114[2] = v105
	v115[3] = v106
	local v116, v117, v118 = getWorldTranslation(p59.hoseNode)
	local _, v119, v120 = worldToLocal(p59.hoseNode, v116 + v110, v117 + v111, v118 + v112)
	local _, v121, _ = localToWorld(p59.hoseNode, v68, v84, v70)
	local v122 = v80 - v121
	local v123 = v119 * -p59.dampingFactor
	local v124 = -p59.dampingRange
	local v125 = p59.dampingRange
	local v126 = math.clamp(v123, v124, v125) * v122
	local v127 = v120 * -p59.dampingFactor
	local v128 = -p59.dampingRange
	local v129 = p59.dampingRange
	local v130 = math.clamp(v127, v128, v129) * v122
	local v131 = v126 * 0.1 + p59.lastVelY * 0.9
	local v132 = v130 * 0.1 + p59.lastVelZ * 0.9
	p59.lastVelY = v131
	p59.lastVelZ = v132
	local v133 = v84 + v131
	local v134 = v70 + v132
	if p59.isTwoPointHose then
		v68 = 0
		v133 = 0
		v134 = 0
	end
	setShaderParameter(p59.hoseNode, "cv2", v68, v133, v134, p59.centerPointTension or 0, false)
	setShaderParameter(p59.hoseNode, "cv3", v62, v63, v64, 0, false)
	setShaderParameter(p59.hoseNode, "cv4", v65, v66, v67, 1, false)
	if VehicleDebug.state == VehicleDebug.DEBUG_ATTACHER_JOINTS and p58:getIsActiveForInput() then
		local v135 = MathUtil.vector3Length(v68, v133, v134) + MathUtil.vector3Length(v68 - v62, v133 - v63, v134 - v64)
		renderText(0.5, 0.9 - p60 * 0.02, 0.0175, string.format("hose %s:", getName(p59.node)))
		local v136 = renderText
		local v137 = 0.9 - p60 * 0.02
		local v138 = string.format
		local v139 = p59.length
		local v140 = math.deg(v94)
		local v141 = p59.minCenterPointAngle
		v136(0.62, v137, 0.0175, v138("directLength: %.2f configLength: %.2f realLength: %.2f angle: %.2f minAngle: %.2f", v77, v139, v135, v140, (math.deg(v141))))
		local v142, v143, v144 = localToWorld(p59.hoseNode, 0, 0, v61)
		local v145, v146, v147 = localToWorld(p59.hoseNode, 0, 0, 0)
		drawDebugLine(v142, v143, v144, 1, 0, 0, v145, v146, v147, 0, 1, 0)
		local v148, v149, v150 = localToWorld(p59.hoseNode, 0, 0, 0)
		local v151, v152, v153 = localToWorld(p59.hoseNode, v68, v133, v134)
		drawDebugLine(v148, v149, v150, 1, 0, 0, v151, v152, v153, 0, 1, 0)
		local v154, v155, v156 = localToWorld(p59.hoseNode, v68, v133, v134)
		local v157, v158, v159 = localToWorld(p59.hoseNode, v62, v63, v64)
		drawDebugLine(v154, v155, v156, 1, 0, 0, v157, v158, v159, 0, 1, 0)
		local v160, v161, v162 = localToWorld(p59.hoseNode, v62, v63, v64)
		local v163, v164, v165 = localToWorld(p59.hoseNode, v65, v66, v67)
		drawDebugLine(v160, v161, v162, 1, 0, 0, v163, v164, v165, 0, 1, 0)
		local v166, v167, v168 = localToWorld(p59.hoseNode, 0, 0, v61)
		local v169, v170, v171 = localToWorld(p59.hoseNode, 0, 0, 0)
		local v172, v173, v174 = localToWorld(p59.hoseNode, v68, v133, v134)
		local v175, v176, v177 = localToWorld(p59.hoseNode, v62, v63, v64)
		local v178, v179, v180 = localToWorld(p59.hoseNode, v65, v66, v67)
		drawDebugPoint(v166, v167, v168, 1, 0, 0, 1)
		drawDebugPoint(v169, v170, v171, 1, 0, 0, 1)
		drawDebugPoint(v172, v173, v174, 1, 0, 0, 1)
		drawDebugPoint(v175, v176, v177, 1, 0, 0, 1)
		drawDebugPoint(v178, v179, v180, 1, 0, 0, 1)
		DebugGizmo.renderAtNode(p59.hoseNode, "hn")
		DebugGizmo.renderAtNode(p59.targetNode, "tn")
		if p59.minCenterPointOffset ~= nil and p59.maxCenterPointOffset ~= nil then
			local v181, v182, v183 = localToWorld(p59.hoseNode, 0, 0, 0)
			local v184, v185, v186 = localDirectionToWorld(p59.hoseNode, 0, 1, 0)
			local v187, v188, v189 = localDirectionToWorld(p59.hoseNode, 0, 0, 1)
			local v190, v191, v192 = localDirectionToWorld(p59.hoseNode, 1, 0, 0)
			local v193 = p59.minCenterPointOffset[1]
			local v194 = math.clamp(v193, -1, 1)
			local v195 = p59.maxCenterPointOffset[1]
			local v196 = math.clamp(v195, -1, 1)
			local v197 = p59.minCenterPointOffset[2]
			local v198 = math.clamp(v197, -1, 1)
			local v199 = p59.maxCenterPointOffset[2]
			local v200 = math.clamp(v199, -1, 1)
			local v201 = p59.minCenterPointOffset[3]
			local v202 = math.clamp(v201, -1, 1)
			local v203 = p59.maxCenterPointOffset[3]
			local v204 = math.clamp(v203, -1, 1)
			if p59.minCenterPointOffset[3] ~= (-1 / 0) or p59.maxCenterPointOffset[3] ~= (1 / 0) then
				local v205 = v181 + v184 * (v198 + v200) * 0.5
				local v206 = v182 + v185 * (v198 + v200) * 0.5
				local v207 = v183 + v186 * (v198 + v200) * 0.5
				local v208 = v205 + v190 * (v194 + v196) * 0.5
				local v209 = v206 + v191 * (v194 + v196) * 0.5
				local v210 = v207 + v192 * (v194 + v196) * 0.5
				local v211 = Color.new(0, 0, 1, 0.1)
				DebugPlane.newSimple(true, true, v211, false):createFromPosAndDir(v208 + v187 * v202, v209 + v188 * v202, v210 + v189 * v202, v184, v185, v186, v187, v188, v189, v196 - v194, v200 - v198):draw()
				DebugPlane.newSimple(true, true, v211, false):createFromPosAndDir(v208 + v187 * v204, v209 + v188 * v204, v210 + v189 * v204, v184, v185, v186, v187, v188, v189, v196 - v194, v200 - v198):draw()
			end
			if p59.minCenterPointOffset[2] ~= (-1 / 0) or p59.maxCenterPointOffset[2] ~= (1 / 0) then
				local v212 = v181 + v187 * (v202 + v204) * 0.5
				local v213 = v182 + v188 * (v202 + v204) * 0.5
				local v214 = v183 + v189 * (v202 + v204) * 0.5
				local v215 = v212 + v190 * (v194 + v196) * 0.5
				local v216 = v213 + v191 * (v194 + v196) * 0.5
				local v217 = v214 + v192 * (v194 + v196) * 0.5
				local v218 = Color.new(0, 1, 0, 0.1)
				DebugPlane.newSimple(true, true, v218, false):createFromPosAndDir(v215 + v184 * v198, v216 + v185 * v198, v217 + v186 * v198, v187, v188, v189, v184, v185, v186, v196 - v194, v204 - v202):draw()
				DebugPlane.newSimple(true, true, v218, false):createFromPosAndDir(v215 + v184 * v200, v216 + v185 * v200, v217 + v186 * v200, v187, v188, v189, v184, v185, v186, v196 - v194, v204 - v202):draw()
			end
			if p59.minCenterPointOffset[1] ~= (-1 / 0) or p59.maxCenterPointOffset[1] ~= (1 / 0) then
				local v219 = v181 + v187 * (v202 + v204) * 0.5
				local v220 = v182 + v188 * (v202 + v204) * 0.5
				local v221 = v183 + v189 * (v202 + v204) * 0.5
				local v222 = Color.new(1, 0, 0, 0.1)
				DebugPlane.newSimple(true, true, v222, false):createFromPosAndDir(v219 + v190 * v194, v220 + v191 * v194, v221 + v192 * v194, v187, v188, v189, v190, v191, v192, v200 - v198, v204 - v202):draw()
				DebugPlane.newSimple(true, true, v222, false):createFromPosAndDir(v219 + v190 * v196, v220 + v191 * v196, v221 + v192 * v196, v187, v188, v189, v190, v191, v192, v200 - v198, v204 - v202):draw()
			end
		end
		if p59.minDeltaY ~= (1 / 0) and p59.minDeltaYComponent ~= nil then
			local v223, _, v224 = localToLocal(p59.hoseNode, p59.minDeltaYComponent, v68, v133, v134)
			local _, v225, _ = localToLocal(p59.hoseNode, p59.minDeltaYComponent, 0, 0, 0)
			local v226, v227, v228 = localToWorld(p59.minDeltaYComponent, v223, v225 + p59.minDeltaY, v224)
			local v229, v230, v231 = localDirectionToWorld(p59.minDeltaYComponent, 0, 1, 0)
			local v232, v233, v234 = localDirectionToWorld(p59.minDeltaYComponent, 0, 0, 1)
			DebugPlane.newSimple(true, true, Color.new(0, 1, 0, 0.1), false):createFromPosAndDir(v226, v227, v228, v232, v233, v234, v229, v230, v231, 1, 1):draw()
		end
	end
end
function ConnectionHoses.getCenterPointAngle(_, p235, p236, p237, p238, p239, p240, p241, p242)
	local v243 = MathUtil.vector3Length(p236, p237, p238)
	local v244 = MathUtil.vector3Length(p236 - p239, p237 - p240, p238 - p241)
	local v245 = math.abs(v244)
	local _, v246, _ = getWorldTranslation(p235)
	if p242 then
		local v247, v248
		v247, p237, v248 = localToWorld(p235, p236, p237, p238)
		local v249, v250
		v249, p240, v250 = localToWorld(p235, p239, p240, p241)
	else
		v246 = 0
	end
	local v251 = v246 - p237
	local v252 = p240 - p237
	local v253 = v251 / v243
	local v254 = math.acos(v253)
	local v255 = v252 / v245
	return v254, math.acos(v255)
end
function ConnectionHoses.getCenterPointAngleRegulation(_, p256, p257, p258, p259, p260, p261, p262, p263, p264, p265, p266)
	local v267, v268, v269 = getWorldTranslation(p256)
	if p266 then
		local v270
		p257, v270, p259 = localToWorld(p256, p257, p258, p259)
		local v271
		p260, v271, p262 = localToWorld(p256, p260, p261, p262)
	else
		v268 = 0
		v267 = 0
		v269 = 0
	end
	local v272 = MathUtil.vector2Length(v267 - p257, v269 - p259)
	local v273 = MathUtil.vector2Length(p260 - p257, p262 - p259)
	local v274 = 1.5707963267948966 - p263 / (p263 + p264) * p265
	local v275 = (math.tan(v274) * v272 + math.tan(v274) * v273) / 2
	if p266 then
		return worldToLocal(p256, p257, v268 - v275, p259)
	else
		return p257, v268 - v275, p259
	end
end
function ConnectionHoses.loadConnectionHosesFromXML(p_u_276, p_u_277, p278)
	local v_u_279 = p_u_276.spec_connectionHoses
	p_u_277:iterate(p278 .. ".skipNode", function(_, p280)
		-- upvalues: (copy) p_u_276, (copy) p_u_277, (copy) v_u_279
		local v281 = {}
		if p_u_276:loadHoseSkipNode(p_u_277, p280, v281) then
			local v282 = v_u_279.hoseSkipNodes
			table.insert(v282, v281)
			if v_u_279.hoseSkipNodeByType[v281.type] == nil then
				v_u_279.hoseSkipNodeByType[v281.type] = {}
			end
			local v283 = v_u_279.hoseSkipNodeByType[v281.type]
			table.insert(v283, v281)
		end
	end)
	p_u_276:addHoseTargetNodes(p_u_277, p278 .. ".target")
	p_u_277:iterate(p278 .. ".toolConnectorHose", function(_, p284)
		-- upvalues: (copy) p_u_276, (copy) p_u_277, (copy) v_u_279
		local v285 = {}
		if p_u_276:loadToolConnectorHoseNode(p_u_277, p284, v285) then
			local v286 = v_u_279.toolConnectorHoses
			table.insert(v286, v285)
			v_u_279.targetNodeToToolConnection[v285.startTargetNodeIndex] = v285
			v_u_279.targetNodeToToolConnection[v285.endTargetNodeIndex] = v285
		end
	end)
	p_u_277:iterate(p278 .. ".hose", function(_, p287)
		-- upvalues: (copy) p_u_276, (copy) p_u_277, (copy) v_u_279
		local v288 = {}
		if p_u_276:loadHoseNode(p_u_277, p287, v288, true) then
			local v289 = v_u_279.hoseNodes
			table.insert(v289, v288)
			v288.index = #v_u_279.hoseNodes
			for _, v290 in pairs(v288.inputAttacherJointIndices) do
				if v_u_279.hoseNodesByInputAttacher[v290] == nil then
					v_u_279.hoseNodesByInputAttacher[v290] = {}
				end
				local v291 = v_u_279.hoseNodesByInputAttacher[v290]
				table.insert(v291, v288)
			end
		end
	end)
	p_u_277:iterate(p278 .. ".localHose", function(_, p292)
		-- upvalues: (copy) p_u_276, (copy) p_u_277, (copy) v_u_279
		local v293 = {}
		if p_u_276:loadHoseNode(p_u_277, p292 .. ".hose", v293, false) then
			local v294 = {}
			if p_u_276:loadHoseTargetNode(p_u_277, p292 .. ".target", v294) then
				local v295 = v_u_279.localHoseNodes
				table.insert(v295, {
					["hose"] = v293,
					["target"] = v294
				})
			end
		end
	end)
	p_u_276:loadCustomHosesFromXML(true, v_u_279.customHoses, v_u_279.customHosesByAttacher, v_u_279.customHosesByInputAttacher, p_u_277, p278 .. ".customHose")
	p_u_276:loadCustomHosesFromXML(false, v_u_279.customHoseTargets, v_u_279.customHoseTargetsByAttacher, v_u_279.customHoseTargetsByInputAttacher, p_u_277, p278 .. ".customTarget")
end
function ConnectionHoses.loadHoseSkipNode(p296, p297, p298, p299)
	p299.node = p297:getValue(p298 .. "#node", nil, p296.components, p296.i3dMappings)
	if p299.node == nil then
		Logging.xmlWarning(p297, "Missing node for hose skip node \'%s\'", p298)
		return false
	end
	p299.inputAttacherJointIndex = p297:getValue(p298 .. "#inputAttacherJointIndex", 1)
	p299.attacherJointIndex = p297:getValue(p298 .. "#attacherJointIndex", 1)
	p299.type = p297:getValue(p298 .. "#type")
	p299.specType = p297:getValue(p298 .. "#specType")
	if p299.type == nil then
		Logging.xmlWarning(p297, "Missing type for hose skip node \'%s\'", p298)
		return false
	end
	p299.length = p297:getValue(p298 .. "#length")
	p299.isTwoPointHose = p297:getValue(p298 .. "#isTwoPointHose", false)
	p299.isSkipNode = true
	return true
end
function ConnectionHoses.loadToolConnectorHoseNode(p300, p301, p302, p303)
	local v304 = p300.spec_connectionHoses
	p303.startTargetNodeIndex = p300:addHoseTargetNodes(p301, (string.format("%s.startTarget", p302)))
	if p303.startTargetNodeIndex == nil then
		Logging.xmlWarning(p301, "startTarget is missing for tool connection hose \'%s\'", p302)
		return false
	end
	p303.endTargetNodeIndex = p300:addHoseTargetNodes(p301, (string.format("%s.endTarget", p302)))
	if p303.endTargetNodeIndex == nil then
		Logging.xmlWarning(p301, "endTarget is missing for tool connection hose \'%s\'", p302)
		return false
	end
	local v305 = v304.targetNodes[p303.startTargetNodeIndex]
	local v306 = v304.targetNodes[p303.endTargetNodeIndex]
	for v307, _ in pairs(v305.attacherJointIndices) do
		if v306.attacherJointIndices[v307] ~= nil then
			Logging.xmlWarning(p301, "Double usage of attacher joint index \'%d\' in \'%s\'", v307, p302)
		end
	end
	p303.moveNodes = p301:getValue(p302 .. "#moveNodes", true)
	p303.additionalHose = p301:getValue(p302 .. "#additionalHose", true)
	if p303.moveNodes then
		local v308, v309, v310 = getTranslation(v305.node)
		local v311, v312, v313 = getTranslation(v306.node)
		local v314, v315, v316 = MathUtil.vector3Normalize(v308 - v311, v309 - v312, v310 - v313)
		local v317, v318, v319 = localDirectionToLocal(v306.node, getParent(v306.node), 0, 1, 0)
		if (v314 ~= 0 or (v315 ~= 0 or v316 ~= 0)) and not (MathUtil.isNan(v314) or (MathUtil.isNan(v315) or MathUtil.isNan(v316))) then
			setDirection(v305.node, -v314, -v315, -v316, v317, v318, v319)
			setDirection(v306.node, v314, v315, v316, v317, v318, v319)
		end
	end
	p303.mountingNode = p301:getValue(p302 .. "#mountingNode", nil, p300.components, p300.i3dMappings)
	if p303.mountingNode ~= nil then
		setVisibility(p303.mountingNode, false)
	end
	local v320 = v304.targetNodes[p303.startTargetNodeIndex].type .. (v304.targetNodes[p303.startTargetNodeIndex].specType or "")
	if v304.numToolConnectionsByType[v320] == nil then
		v304.numToolConnectionsByType[v320] = 0
	end
	v304.numToolConnectionsByType[v320] = v304.numToolConnectionsByType[v320] + 1
	p303.typedIndex = v304.numToolConnectionsByType[v320]
	p303.connected = false
	return true
end
function ConnectionHoses.addHoseTargetNodes(p_u_321, p_u_322, p323)
	local v_u_324 = p_u_321.spec_connectionHoses
	local v_u_325 = false
	p_u_322:iterate(p323, function(_, p326)
		-- upvalues: (copy) p_u_321, (copy) p_u_322, (copy) v_u_324, (ref) v_u_325
		local v327 = {}
		if p_u_321:loadHoseTargetNode(p_u_322, p326, v327) then
			local v328 = v_u_324.targetNodes
			table.insert(v328, v327)
			v327.index = #v_u_324.targetNodes
			if v_u_324.targetNodesByType[v327.type] == nil then
				v_u_324.targetNodesByType[v327.type] = {}
			end
			local v329 = v_u_324.targetNodesByType[v327.type]
			table.insert(v329, v327)
			v_u_325 = true
		end
	end)
	return v_u_325 and #v_u_324.targetNodes or nil
end
function ConnectionHoses.loadCustomHosesFromXML(p_u_330, p_u_331, p_u_332, p_u_333, p_u_334, p_u_335, p336)
	p_u_335:iterate(p336, function(_, p337)
		-- upvalues: (copy) p_u_335, (copy) p_u_330, (copy) p_u_334, (copy) p_u_333, (copy) p_u_331, (copy) p_u_332
		local v338 = {
			["node"] = p_u_335:getValue(p337 .. "#node", nil, p_u_330.components, p_u_330.i3dMappings)
		}
		if v338.node == nil then
			Logging.xmlWarning(p_u_335, "Missing node for custom hose \'%s\'", p337)
			return
		else
			v338.type = p_u_335:getValue(p337 .. "#type")
			if v338.type == nil then
				Logging.xmlWarning(p_u_335, "Missing type for custom hose \'%s\'", p337)
			else
				v338.type = v338.type:upper()
				v338.inputAttacherJointIndices = {}
				local v339 = p_u_335:getValue(p337 .. "#inputAttacherJointIndices", nil, true)
				if v339 ~= nil then
					for _, v340 in ipairs(v339) do
						v338.inputAttacherJointIndices[v340] = v340
						if p_u_334[v340] == nil then
							p_u_334[v340] = {}
						end
						local v341 = p_u_334[v340]
						table.insert(v341, v338)
					end
				end
				v338.attacherJointIndices = {}
				local v342 = p_u_335:getValue(p337 .. "#attacherJointIndices", nil, true)
				if v342 ~= nil then
					for _, v343 in ipairs(v342) do
						v338.attacherJointIndices[v343] = v343
						if p_u_333[v343] == nil then
							p_u_333[v343] = {}
						end
						local v344 = p_u_333[v343]
						table.insert(v344, v338)
					end
				end
				if p_u_331 then
					v338.isActiveDirty = p_u_335:getValue(p337 .. "#isActiveDirty", false)
					if v338.isActiveDirty then
						local v345 = p_u_330.spec_connectionHoses.customHosesActiveDirty
						table.insert(v345, v338)
					end
					v338.startTranslation = { getTranslation(v338.node) }
					v338.startRotation = { getRotation(v338.node) }
				end
				if next(v338.inputAttacherJointIndices) == nil and next(v338.attacherJointIndices) == nil then
					Logging.xmlWarning(p_u_335, "Missing inputAttacherJointIndices for custom hose \'%s\'", p337)
					return false
				end
				v338.objectChanges = {}
				ObjectChangeUtil.loadObjectChangeFromXML(p_u_335, p337, v338.objectChanges, p_u_330.components, p_u_330)
				ObjectChangeUtil.setObjectChanges(v338.objectChanges, false, p_u_330, p_u_330.setMovingToolDirty)
				v338.objectChangesTarget = p_u_330
				v338.isActive = false
				local v346 = p_u_332
				table.insert(v346, v338)
			end
		end
	end)
end
function ConnectionHoses.loadHoseTargetNode(p347, p348, p349, p350)
	XMLUtil.checkDeprecatedXMLElements(p348, p349 .. "#socketColor", p349 .. "#socketMaterialTemplateName")
	p350.node = p348:getValue(p349 .. "#node", nil, p347.components, p347.i3dMappings)
	if p350.node == nil then
		Logging.xmlWarning(p348, "Missing node for connection hose target \'%s\'", p349)
		return false
	end
	p350.attacherJointIndices = {}
	local v351 = p348:getValue(p349 .. "#attacherJointIndices", nil, true)
	if v351 ~= nil then
		for _, v352 in ipairs(v351) do
			p350.attacherJointIndices[v352] = v352
		end
	end
	local v353 = p348:getValue(p349 .. "#attacherJointNodes", nil, p347.components, p347.i3dMappings, true)
	if v353 ~= nil then
		for _, v354 in ipairs(v353) do
			local v355 = p347:getAttacherJointIndexByNode(v354)
			if v355 ~= nil then
				p350.attacherJointIndices[v355] = v355
			end
		end
	end
	p350.type = p348:getValue(p349 .. "#type")
	p350.specType = p348:getValue(p349 .. "#specType")
	p350.straighteningFactor = p348:getValue(p349 .. "#straighteningFactor", 1)
	p350.straighteningDirection = p348:getValue(p349 .. "#straighteningDirection", nil, true)
	local v356 = p348:getValue(p349 .. "#socket")
	if v356 ~= nil then
		local v357 = p348:getValue(p349 .. "#socketMaterialTemplateName")
		p350.socket = g_connectionHoseManager:linkSocketToNode(v356, p350.node, p347.customEnvironment, v357)
	end
	if p350.type == nil then
		Logging.xmlWarning(p348, "Missing type for \'%s\'", p349)
		return false
	end
	p350.adapterName = p348:getValue(p349 .. "#adapterType", "DEFAULT")
	if p350.adapter == nil then
		p350.adapter = {}
		p350.adapter.node = p350.node
		p350.adapter.refNode = p350.node
	end
	p350.objectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p348, p349, p350.objectChanges, p347.components, p347)
	ObjectChangeUtil.setObjectChanges(p350.objectChanges, false, p347, p347.setMovingToolDirty)
	return true
end
function ConnectionHoses.loadHoseNode(p358, p359, p360, p361, p362)
	XMLUtil.checkDeprecatedXMLElements(p359, p360 .. "#color", p360 .. "#materialTemplateName")
	XMLUtil.checkDeprecatedXMLElements(p359, p360 .. "#socketColor", p360 .. "#socketMaterialTemplateName")
	p361.inputAttacherJointIndices = {}
	local v363 = p359:getValue(p360 .. "#inputAttacherJointIndices", nil, true)
	if v363 ~= nil then
		for _, v364 in ipairs(v363) do
			p361.inputAttacherJointIndices[v364] = v364
		end
	end
	local v365 = p359:getValue(p360 .. "#inputAttacherJointNodes", nil, p358.components, p358.i3dMappings, true)
	if v365 ~= nil then
		for _, v366 in ipairs(v365) do
			local v367 = p358:getInputAttacherJointIndexByNode(v366)
			if v367 ~= nil then
				p361.inputAttacherJointIndices[v367] = v367
			end
		end
	end
	p361.type = p359:getValue(p360 .. "#type")
	p361.specType = p359:getValue(p360 .. "#specType")
	if p361.type == nil then
		Logging.xmlWarning(p359, "Missing type attribute in \'%s\'", p360)
		return false
	end
	p361.hoseType = p359:getValue(p360 .. "#hoseType", "DEFAULT")
	p361.node = p359:getValue(p360 .. "#node", nil, p358.components, p358.i3dMappings)
	if p361.node == nil then
		Logging.xmlWarning(p359, "Missing node for connection hose \'%s\'", p360)
		return false
	end
	if p362 then
		local v368 = p358.spec_connectionHoses
		local v369 = p361.type .. (p361.specType or "")
		if v368.numHosesByType[v369] == nil then
			v368.numHosesByType[v369] = 0
		end
		v368.numHosesByType[v369] = v368.numHosesByType[v369] + 1
		p361.typedIndex = v368.numHosesByType[v369]
	end
	p361.isTwoPointHose = p359:getValue(p360 .. "#isTwoPointHose", false)
	p361.isWorldSpaceHose = p359:getValue(p360 .. "#isWorldSpaceHose", true)
	p361.component = p358:getParentComponent(p361.node)
	p361.lastVelY = 0
	p361.lastVelZ = 0
	p361.dampingRange = p359:getValue(p360 .. "#dampingRange", 0.05)
	p361.dampingFactor = p359:getValue(p360 .. "#dampingFactor", 50)
	p361.length = p359:getValue(p360 .. "#length", 3)
	p361.diameter = p359:getValue(p360 .. "#diameter", 0.02)
	p361.straighteningFactor = p359:getValue(p360 .. "#straighteningFactor", 1)
	p361.centerPointDropFactor = p359:getValue(p360 .. "#centerPointDropFactor", 1)
	p361.centerPointTension = p359:getValue(p360 .. "#centerPointTension", 0)
	p361.minCenterPointAngle = p359:getValue(p360 .. "#minCenterPointAngle")
	p361.minCenterPointOffset = p359:getValue(p360 .. "#minCenterPointOffset", nil, true)
	p361.maxCenterPointOffset = p359:getValue(p360 .. "#maxCenterPointOffset", nil, true)
	if p361.minCenterPointOffset ~= nil and p361.maxCenterPointOffset ~= nil then
		for v370 = 1, 3 do
			if p361.minCenterPointOffset[v370] == 0 then
				p361.minCenterPointOffset[v370] = (-1 / 0)
			end
			if p361.maxCenterPointOffset[v370] == 0 then
				p361.maxCenterPointOffset[v370] = (1 / 0)
			end
		end
		for v371 = 1, 3 do
			if p361.maxCenterPointOffset[v371] < p361.minCenterPointOffset[v371] or p361.minCenterPointOffset[v371] > p361.maxCenterPointOffset[v371] then
				p361.minCenterPointOffset = nil
				p361.maxCenterPointOffset = nil
				Logging.xmlWarning(p359, "Invalid centerPointOffset in \'%s\'. Max is smaller than min or min is greater than max.", p360)
				break
			end
		end
	end
	p361.minDeltaY = p359:getValue(p360 .. "#minDeltaY", (1 / 0))
	p361.minDeltaYComponent = p359:getValue(p360 .. "#minDeltaYComponent", p361.component, p358.components, p358.i3dMappings)
	p361.material = p359:getValue(p360 .. "#materialTemplateName")
	p361.adapterMaterial = p359:getValue(p360 .. "#adapterMaterialTemplateName")
	p361.adapterName = p359:getValue(p360 .. "#adapterType")
	p361.outgoingAdapter = p359:getValue(p360 .. "#outgoingAdapter")
	p361.adapterNode = p359:getValue(p360 .. "#adapterNode", nil, p358.components, p358.i3dMappings)
	if p361.adapterNode ~= nil then
		local v372 = g_connectionHoseManager:getClonedAdapterNode(p361.type, p361.adapterName or "DEFAULT", p358.customEnvironment, true)
		if v372 == nil then
			Logging.xmlWarning(p359, "Unable to find detached adapter for type \'%s\' in \'%s\'", p361.adapterName or "DEFAULT", p360)
		else
			if p361.adapterMaterial ~= nil then
				p361.adapterMaterial:apply(v372, "connector_color_mat")
			end
			link(p361.adapterNode, v372)
		end
	end
	local v373 = p359:getValue(p360 .. "#socket")
	if v373 ~= nil then
		local v374 = p359:getValue(p360 .. "#socketMaterialTemplateName")
		p361.socket = g_connectionHoseManager:linkSocketToNode(v373, p361.node, p358.customEnvironment, v374)
		if p361.socket ~= nil then
			setRotation(p361.socket.node, 0, 3.141592653589793, 0)
		end
	end
	local v375, v376, v377, v378 = g_connectionHoseManager:getClonedHoseNode(p361.type, p361.hoseType, p361.length, p361.diameter, p361.material, p358.customEnvironment)
	if v375 == nil then
		Logging.xmlWarning(p359, "Unable to find connection hose with length \'%.2f\' and diameter \'%.2f\' in \'%s\'", p361.length, p361.diameter, p360)
		return false
	end
	local v379 = g_connectionHoseManager:getSocketTarget(p361.socket, p361.node)
	local v380 = 0
	local v381
	if p361.outgoingAdapter == nil then
		v381 = v375
	else
		local v382
		v381, v382 = g_connectionHoseManager:getClonedAdapterNode(p361.type, p361.outgoingAdapter, p358.customEnvironment)
		if v381 == nil then
			Logging.xmlWarning(p359, "Unable to find adapter type \'%s\' in \'%s\'", p361.outgoingAdapter, p360)
			v381 = v375
		else
			if p361.adapterMaterial ~= nil then
				p361.adapterMaterial:apply(v381, "connector_color_mat")
			end
			link(v379, v381)
			v380 = 3.141592653589793
			if p361.socket == nil then
				setRotation(v381, 0, v380, 0)
				v379 = v382
			else
				v379 = v382
			end
		end
	end
	link(v379, v375)
	setTranslation(v375, 0, 0, 0)
	setRotation(v375, 0, v380, 0)
	p361.hoseNode = v375
	p361.visibilityNode = v381
	p361.startStraightening = v376 * p361.straighteningFactor
	p361.endStraightening = v377
	p361.endStraighteningBase = v377
	p361.endStraighteningDirectionBase = { 0, 0, 1 }
	p361.endStraighteningDirection = p361.endStraighteningDirectionBase
	p361.minCenterPointAngle = p361.minCenterPointAngle or v378
	setVisibility(p361.visibilityNode, false)
	p361.objectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p359, p360, p361.objectChanges, p358.components, p358)
	ObjectChangeUtil.setObjectChanges(p361.objectChanges, false, p358, p358.setMovingToolDirty)
	return true
end
function ConnectionHoses.getClonedSkipHoseNode(p383, p384, p385)
	local v386 = {
		["isClonedSkipNodeHose"] = true,
		["type"] = p384.type,
		["specType"] = p384.specType,
		["hoseType"] = p384.hoseType,
		["node"] = p385.node,
		["component"] = p383:getParentComponent(p385.node),
		["lastVelY"] = 0,
		["lastVelZ"] = 0,
		["dampingRange"] = 0.05,
		["dampingFactor"] = 50,
		["minDeltaYComponent"] = p383:getParentComponent(p385.node),
		["minDeltaY"] = (1 / 0),
		["length"] = p385.length or p384.length,
		["diameter"] = p384.diameter,
		["isTwoPointHose"] = p385.isTwoPointHose,
		["material"] = p384.material
	}
	local v387, v388, v389, v390 = g_connectionHoseManager:getClonedHoseNode(v386.type, v386.hoseType, v386.length, v386.diameter, v386.material, p383.customEnvironment)
	if v387 == nil then
		Logging.xmlWarning(p383.xmlFile, "Unable to find connection hose with length \'%.2f\' and diameter \'%.2f\' in \'%s\'", v386.length, v386.diameter, "skipHoseClone")
		return false
	end
	link(v386.node, v387)
	setTranslation(v387, 0, 0, 0)
	setRotation(v387, 0, 0, 0)
	v386.hoseNode = v387
	v386.visibilityNode = v387
	v386.startStraightening = v388
	v386.endStraightening = v389
	v386.endStraighteningBase = v389
	v386.endStraighteningDirectionBase = { 0, 0, 1 }
	v386.endStraighteningDirection = v386.endStraighteningDirectionBase
	v386.minCenterPointAngle = v390
	setVisibility(v386.visibilityNode, false)
	v386.objectChanges = {}
	return v386
end
function ConnectionHoses.getConnectionTarget(p391, p392, p393, p394, p395)
	local v396 = p391.spec_connectionHoses
	if #v396.targetNodes == 0 and #v396.hoseSkipNodes == 0 then
		return nil
	end
	local v397 = v396.targetNodesByType[p393]
	if v397 ~= nil then
		for _, v398 in ipairs(v397) do
			if v398.attacherJointIndices[p392] ~= nil and (v398.specType == p394 and not p391:getIsConnectionTargetUsed(v398)) then
				local v399 = v396.targetNodeToToolConnection[v398.index]
				if v399 == nil or (p395 == nil or (not p395 or v399.delayedMounting ~= nil)) then
					return v398, false
				else
					return nil
				end
			end
		end
	end
	local v400 = v396.hoseSkipNodeByType[p393]
	if v400 ~= nil then
		for _, v401 in ipairs(v400) do
			if v401.specType == p394 and p391:getIsSkipNodeAvailable(v401) then
				return v401, true
			end
		end
	end
	return nil
end
function ConnectionHoses.iterateConnectionTargets(p402, p403, p404, p405, p406, p407)
	local v408 = p402.spec_connectionHoses
	if #v408.targetNodes == 0 and #v408.hoseSkipNodes == 0 then
		return nil
	end
	local v409 = v408.targetNodesByType[p405]
	if v409 ~= nil then
		for _, v410 in ipairs(v409) do
			if v410.attacherJointIndices[p404] ~= nil and (v410.specType == p406 and not p402:getIsConnectionTargetUsed(v410)) then
				local v411 = v408.targetNodeToToolConnection[v410.index]
				if v411 ~= nil and (p407 ~= nil and (p407 and v411.delayedMounting == nil)) then
					return nil
				end
				if not p403(v410, false) then
					break
				end
			end
		end
	end
	local v412 = v408.hoseSkipNodeByType[p405]
	if v412 ~= nil then
		for _, v413 in ipairs(v412) do
			if v413.specType == p406 and (p402:getIsSkipNodeAvailable(v413) and not p403(v413, true)) then
				break
			end
		end
	end
	return nil
end
function ConnectionHoses.getIsConnectionTargetUsed(_, p414)
	return p414.connectedObject ~= nil
end
function ConnectionHoses.getIsConnectionHoseUsed(_, p415)
	return p415.connectedObject ~= nil
end
function ConnectionHoses.getIsSkipNodeAvailable(p416, p417)
	if p416.getAttacherVehicle == nil then
		return false
	end
	local v418 = p416:getAttacherVehicle()
	if v418 ~= nil then
		local v419 = v418:getAttacherJointIndexFromObject(p416)
		if v418:getImplementFromAttacherJointIndex(v419).inputJointDescIndex == p417.inputAttacherJointIndex then
			local v420
			if v418:getConnectionTarget(v419, p417.type, p417.specType, true) == nil then
				v420 = false
			else
				v420 = p417.parentHose == nil
			end
			return v420
		end
	end
	return false
end
function ConnectionHoses.getConnectionHosesByInputAttacherJoint(p421, p422)
	local v423 = p421.spec_connectionHoses
	return v423.hoseNodesByInputAttacher[p422] == nil and {} or v423.hoseNodesByInputAttacher[p422]
end
function ConnectionHoses.connectHose(p424, p425, p426, p427, p428)
	local v429 = p424.spec_connectionHoses
	local v430 = false
	if (p428 == nil or p428) and not p426:updateToolConnectionHose(p424, p425, p426, p427, true) then
		p426:addHoseToDelayedMountings(p424, p425, p426, p427)
	else
		v430 = true
	end
	if not v430 then
		return false
	end
	p427.connectedObject = p424
	p425.connectedObject = p426
	p425.targetHose = p427
	local v431 = nil
	local v432 = nil
	if p425.adapterName == nil then
		if p427.adapterName ~= "NONE" then
			v431, v432 = g_connectionHoseManager:getClonedAdapterNode(p427.type, p427.adapterName, p424.customEnvironment)
		end
	elseif p425.adapterName ~= "NONE" then
		v431, v432 = g_connectionHoseManager:getClonedAdapterNode(p427.type, p425.adapterName, p424.customEnvironment)
	end
	if v431 ~= nil then
		if p425.adapterMaterial ~= nil then
			p425.adapterMaterial:apply(v431, "connector_color_mat")
		end
		link(g_connectionHoseManager:getSocketTarget(p427.socket, p427.node), v431)
		setTranslation(v431, 0, 0, 0)
		setRotation(v431, 0, 0, 0)
		p426:addAllSubWashableNodes(v431)
		p427.adapter.node = v431
		p427.adapter.refNode = v432
		p427.adapter.isLinked = true
	end
	p425.targetNode = p427.adapter.refNode
	setVisibility(p425.visibilityNode, true)
	setShaderParameter(p425.hoseNode, "cv0", 0, 0, -p425.startStraightening, 1, false)
	p425.endStraightening = p425.endStraighteningBase * p427.straighteningFactor
	p425.endStraighteningDirection = p427.straighteningDirection or p425.endStraighteningDirectionBase
	ObjectChangeUtil.setObjectChanges(p427.objectChanges, true, p425.connectedObject, p425.connectedObject.setMovingToolDirty)
	ObjectChangeUtil.setObjectChanges(p425.objectChanges, true, p427.connectedObject, p427.connectedObject.setMovingToolDirty)
	g_connectionHoseManager:openSocket(p425.socket)
	g_connectionHoseManager:openSocket(p427.socket)
	p424:updateConnectionHose(p425, 0)
	if p424.isClient then
		local v433 = v429.samples.connect[p425.type]
		if v433 ~= nil and not g_soundManager:getIsSamplePlaying(v433) then
			g_soundManager:playSample(v433)
		end
	end
	local v434 = v429.updateableHoses
	table.insert(v434, p425)
	return true
end
function ConnectionHoses.disconnectHose(p435, p436)
	local v437 = p435.spec_connectionHoses
	local v438 = p436.targetHose
	if v438 ~= nil then
		p436.connectedObject:updateToolConnectionHose(p435, p436, p436.connectedObject, v438, false)
		local v439
		if v438.isSkipNode == nil then
			v439 = false
		else
			v439 = v438.isSkipNode
		end
		local v440
		if p436.isClonedSkipNodeHose == nil then
			v440 = false
		else
			v440 = p436.isClonedSkipNodeHose
		end
		if v439 or v440 then
			if p436.parentVehicle ~= nil and p436.parentHose ~= nil then
				p436.parentHose.childVehicle = nil
				p436.parentHose.childHose = nil
				p436.parentVehicle:disconnectHose(p436.parentHose)
			end
			if p436.childVehicle ~= nil and p436.childHose ~= nil then
				p436.childHose.parentVehicle = nil
				p436.childHose.parentHose = nil
				p436.childVehicle:disconnectHose(p436.childHose)
			end
			v438.parentHose = nil
		end
		if v438.adapter ~= nil and (v438.adapter.isLinked ~= nil and v438.adapter.isLinked) then
			p436.connectedObject:removeAllSubWashableNodes(v438.adapter.node)
			delete(v438.adapter.node)
			v438.adapter.node = v438.node
			v438.adapter.refNode = v438.node
			v438.adapter.isLinked = false
		end
		setVisibility(p436.visibilityNode, false)
		ObjectChangeUtil.setObjectChanges(v438.objectChanges, false, p436.connectedObject, p436.connectedObject.setMovingToolDirty)
		ObjectChangeUtil.setObjectChanges(p436.objectChanges, false, v438.connectedObject, v438.connectedObject.setMovingToolDirty)
		g_connectionHoseManager:closeSocket(p436.socket)
		g_connectionHoseManager:closeSocket(v438.socket)
		v438.connectedObject = nil
		p436.connectedObject = nil
		p436.targetHose = nil
		table.removeElement(v437.updateableHoses, p436)
		if p435.isClient then
			local v441 = v437.samples.disconnect[p436.type]
			if v441 ~= nil and not g_soundManager:getIsSamplePlaying(v441) then
				g_soundManager:playSample(v441)
			end
		end
	end
end
function ConnectionHoses.updateToolConnectionHose(p442, p443, p_u_444, p445, p446, p447)
	local v448 = p442.spec_connectionHoses
	local function v459(p449)
		-- upvalues: (copy) p_u_444
		if p449.originalNodeTranslation == nil then
			p449.originalNodeTranslation = { getTranslation(p449.node) }
		else
			local v450 = setTranslation
			local v451 = p449.node
			local v452 = p449.originalNodeTranslation
			v450(v451, unpack(v452))
		end
		local v453, v454, v455 = localToWorld(p449.node, 0, p_u_444.diameter * 0.5, 0)
		local v456, v457, v458 = worldToLocal(getParent(p449.node), v453, v454, v455)
		setTranslation(p449.node, v456, v457, v458)
	end
	local v460 = v448.targetNodeToToolConnection[p446.index]
	if v460 == nil then
		return true
	end
	local v461 = v460.startTargetNodeIndex
	if v461 == p446.index then
		v461 = v460.endTargetNodeIndex
	end
	local v462 = v448.targetNodes[v461]
	if v462 ~= nil then
		if p447 and (v460.delayedMounting ~= nil and v460.delayedMounting.sourceHose.connectedObject == nil) then
			local v463 = v460.delayedMounting.sourceObject ~= p443
			local v464
			if v460.delayedMounting.sourceHose.type == p_u_444.type then
				v464 = v460.delayedMounting.sourceHose.specType == p_u_444.specType
			else
				v464 = false
			end
			if v463 and v464 then
				local v465, v466, v467 = localToLocal(p446.node, v462.node, 0, 0, 0)
				local v468 = MathUtil.vector3Length(v465, v466, v467)
				if v460.additionalHose then
					local v469, _, _, _ = g_connectionHoseManager:getClonedHoseNode(p_u_444.type, p_u_444.hoseType, v468, p_u_444.diameter, p_u_444.material, p442.customEnvironment)
					if v469 == nil then
						return false
					end
					link(p446.node, v469)
					setTranslation(v469, 0, 0, 0)
					local v470, v471, v472 = localToLocal(v469, v462.node, 0, 0, 0)
					if v470 ~= 0 or (v471 ~= nil or v472 ~= nil) then
						setDirection(v469, v470, v471, v472, 0, 0, 1)
						setShaderParameter(v469, "cv0", 0, 0, -v472 * 0.5, 0, false)
						setShaderParameter(v469, "cv2", v470 * 0.5 + 0.003, v471 * 0.5, v472 * 0.5, 0, false)
						setShaderParameter(v469, "cv3", v470 - 0.003, v471, v472, 0, false)
						setShaderParameter(v469, "cv4", v470 - 0.003, v471, v472 + v472 * 0.5, 0, false)
					end
					if v460.moveNodes then
						v459(p446)
						v459(v462)
					end
					p443:addAllSubWashableNodes(v469)
					v460.hoseNode = v469
					v460.hoseNodeObject = p443
				end
				v460.connected = true
				if v460.mountingNode ~= nil then
					setVisibility(v460.mountingNode, true)
				end
				if v460.delayedMounting ~= nil then
					v460.delayedUnmounting = {}
					local v473 = v460.delayedUnmounting
					local v474 = v460.delayedMounting
					table.insert(v473, v474)
					local v475 = v460.delayedUnmounting
					table.insert(v475, {
						["sourceObject"] = p443,
						["sourceHose"] = p_u_444,
						["targetObject"] = p445,
						["targetHose"] = p446
					})
					local v476 = v460.delayedMounting
					v460.delayedMounting = nil
					v476.sourceObject:connectHose(v476.sourceHose, v476.targetObject, v476.targetHose, false)
					v476.sourceObject:retryHoseSkipNodeConnections(false)
				end
				return true
			end
		elseif v460.connected then
			v460.connected = false
			if v460.hoseNode ~= nil then
				v460.hoseNodeObject:removeAllSubWashableNodes(v460.hoseNode)
				delete(v460.hoseNode)
				v460.hoseNode = nil
				v460.hoseNodeObject = nil
			end
			if v460.mountingNode ~= nil then
				setVisibility(v460.mountingNode, false)
			end
			if v460.delayedUnmounting ~= nil then
				for _, v477 in ipairs(v460.delayedUnmounting) do
					if p_u_444 ~= v477.sourceHose then
						v477.sourceObject:disconnectHose(v477.sourceHose)
						if v477.sourceHose.isClonedSkipNodeHose == nil or not v477.sourceHose.isClonedSkipNodeHose then
							v460.delayedMounting = v477
						end
					end
				end
				v460.delayedUnmounting = nil
			end
		end
	end
	return false
end
function ConnectionHoses.addHoseToDelayedMountings(p478, p479, p480, p481, p482)
	local v483 = p478.spec_connectionHoses.targetNodeToToolConnection[p482.index]
	if v483 ~= nil and (v483.delayedMounting == nil or p480.typedIndex == v483.typedIndex) then
		local v484 = v483.delayedMounting == nil
		v483.delayedMounting = {
			["sourceObject"] = p479,
			["sourceHose"] = p480,
			["targetObject"] = p481,
			["targetHose"] = p482
		}
		if v484 then
			p478.rootVehicle:retryHoseSkipNodeConnections(true, p479)
		end
	end
end
function ConnectionHoses.connectHoseToSkipNode(p485, p486, p487, p488, p489, p490)
	local v491 = p485.spec_connectionHoses
	p488.connectedObject = p485
	p486.connectedObject = p487
	p486.targetHose = p488
	p486.targetNode = p488.node
	setVisibility(p486.visibilityNode, true)
	setShaderParameter(p486.hoseNode, "cv0", 0, 0, -p486.startStraightening, 1, false)
	ObjectChangeUtil.setObjectChanges(p486.objectChanges, true, p485, p485.setMovingToolDirty)
	p485:addAllSubWashableNodes(p486.hoseNode)
	p486.childVehicle = p490
	p486.childHose = p489
	if p485.getAttacherVehicle ~= nil then
		local v492 = p485:getAttacherVehicle()
		if v492.getAttacherVehicle ~= nil then
			local v493 = v492:getAttacherVehicle()
			if v493 ~= nil then
				local v494 = v493:getAttacherJointIndexFromObject(v492)
				if v493:getImplementFromAttacherJointIndex(v494).inputJointDescIndex == p488.inputAttacherJointIndex then
					local v495, v496 = v493:getConnectionTarget(v494, p488.type, p488.specType)
					if v495 == nil then
						if p488.parentHose ~= nil then
							p486.parentVehicle = p488.parentVehicle
							p486.parentHose = p488.parentHose
							p486.parentHose.childVehicle = p485
							p486.parentHose.childHose = p486
						end
					else
						local v497 = v492:getClonedSkipHoseNode(p486, p488)
						if v496 then
							v492:connectHoseToSkipNode(v497, v493, v495, p486, v492)
						else
							v492:connectHose(v497, v493, v495)
						end
						if p488.parentHose ~= nil then
							p488.parentVehicle:removeWashableNode(p488.parentHose.hoseNode)
							delete(p488.parentHose.hoseNode)
							table.removeElement(v491.updateableHoses, p488.parentHose.childHose)
						end
						p488.parentVehicle = v492
						p488.parentHose = v497
						p486.parentVehicle = v492
						p486.parentHose = v497
						v497.childVehicle = p485
						v497.childHose = p486
						v492:addAllSubWashableNodes(v497.hoseNode)
					end
				end
			end
		end
	end
	local v498 = v491.updateableHoses
	table.insert(v498, p486)
	return true
end
function ConnectionHoses.connectHosesToAttacherVehicle(p_u_499, p_u_500, p501, p502, p_u_503, p504)
	if p_u_500.getConnectionTarget ~= nil then
		local v505 = p_u_499:getConnectionHosesByInputAttacherJoint(p501)
		for _, v_u_506 in ipairs(v505) do
			p_u_500:iterateConnectionTargets(function(p507, p508)
				-- upvalues: (copy) p_u_499, (copy) v_u_506, (copy) p_u_500, (copy) p_u_503
				if p_u_499:getIsConnectionHoseUsed(v_u_506) then
					return false
				end
				if p508 then
					if p_u_499:connectHoseToSkipNode(v_u_506, p_u_500, p507) then
						return false
					end
				elseif p_u_499:connectHose(v_u_506, p_u_500, p507, p_u_503) then
					return false
				end
				return true
			end, p502, v_u_506.type, v_u_506.specType)
		end
		p_u_499:retryHoseSkipNodeConnections(p_u_503, p504)
	end
end
function ConnectionHoses.retryHoseSkipNodeConnections(p509, p510, p511)
	if p509.getAttachedImplements ~= nil then
		local v512 = p509:getAttachedImplements()
		for _, v513 in ipairs(v512) do
			local v514 = v513.object
			if v514 ~= p511 and v514.connectHosesToAttacherVehicle ~= nil then
				v514:connectHosesToAttacherVehicle(p509, v513.inputJointDescIndex, v513.jointDescIndex, p510, p511)
			end
		end
	end
end
function ConnectionHoses.connectCustomHosesToAttacherVehicle(p515, p516, p517, p518)
	local v519 = p515.spec_connectionHoses
	local v520 = v519.customHosesByInputAttacher[p517]
	if v520 ~= nil then
		for v521 = 1, #v520 do
			local v522 = v520[v521]
			if not v522.isActive and p516.spec_connectionHoses ~= nil then
				local v523 = p516.spec_connectionHoses.customHoseTargetsByAttacher[p518]
				if v523 ~= nil then
					for v524 = 1, #v523 do
						local v525 = v523[v524]
						if not v525.isActive and (v522.type == v525.type and v522.specType == v525.specType) then
							p515:connectCustomHoseNode(v522, v525)
						end
					end
				end
			end
		end
	end
	local v526 = v519.customHoseTargetsByInputAttacher[p517]
	if v526 ~= nil then
		for v527 = 1, #v526 do
			local v528 = v526[v527]
			if not v528.isActive and p516.spec_connectionHoses ~= nil then
				local v529 = p516.spec_connectionHoses.customHosesByAttacher[p518]
				if v529 ~= nil then
					for v530 = 1, #v529 do
						local v531 = v529[v530]
						if not v531.isActive and (v531.type == v528.type and v531.specType == v528.specType) then
							p515:connectCustomHoseNode(v531, v528)
						end
					end
				end
			end
		end
	end
end
function ConnectionHoses.connectCustomHoseNode(p532, p533, p534)
	p532:updateCustomHoseNode(p533, p534)
	p533.isActive = true
	p534.isActive = true
	p533.connectedTarget = p534
	p534.connectedHose = p533
	ObjectChangeUtil.setObjectChanges(p533.objectChanges, true, p533.objectChangesTarget, p533.objectChangesTarget.setMovingToolDirty)
	ObjectChangeUtil.setObjectChanges(p534.objectChanges, true, p534.objectChangesTarget, p534.objectChangesTarget.setMovingToolDirty)
	if p532.setMovingToolDirty ~= nil then
		p532:setMovingToolDirty(p533.node, true)
	end
end
function ConnectionHoses.updateCustomHoseNode(p535, p536, p537)
	setTranslation(p536.node, localToLocal(p537.node, getParent(p536.node), 0, 0, 0))
	setRotation(p536.node, localRotationToLocal(p537.node, getParent(p536.node), 0, 0, 0))
	if p535.setMovingToolDirty ~= nil then
		p535:setMovingToolDirty(p536.node)
	end
end
function ConnectionHoses.disconnectCustomHoseNode(p538, p539, p540)
	local v541 = setTranslation
	local v542 = p539.node
	local v543 = p539.startTranslation
	v541(v542, unpack(v543))
	local v544 = setRotation
	local v545 = p539.node
	local v546 = p539.startRotation
	v544(v545, unpack(v546))
	if p538.setMovingToolDirty ~= nil then
		p538:setMovingToolDirty(p539.node, true)
	end
	p539.isActive = false
	p540.isActive = false
	p539.connectedTarget = nil
	p540.connectedHose = nil
	ObjectChangeUtil.setObjectChanges(p539.objectChanges, false, p539.objectChangesTarget, p539.objectChangesTarget.setMovingToolDirty)
	ObjectChangeUtil.setObjectChanges(p540.objectChanges, false, p540.objectChangesTarget, p540.objectChangesTarget.setMovingToolDirty)
end
function ConnectionHoses.loadExtraDependentParts(p547, p548, p549, p550, p551)
	if not p548(p547, p549, p550, p551) then
		return false
	end
	local v552 = p549:getValue(p550 .. ".connectionHoses#customHoseIndices", nil, true)
	if v552 ~= nil and #v552 > 0 then
		p551.customHoseIndices = v552
	end
	local v553 = p549:getValue(p550 .. ".connectionHoses#customTargetIndices", nil, true)
	if v553 ~= nil and #v553 > 0 then
		p551.customTargetIndices = v553
	end
	local v554 = p549:getValue(p550 .. ".connectionHoses#localHoseIndices", nil, true)
	if v554 ~= nil and #v554 > 0 then
		p551.localHoseIndices = v554
	end
	return true
end
function ConnectionHoses.updateExtraDependentParts(p555, p556, p557, p558)
	p556(p555, p557, p558)
	if p557.customHoseIndices ~= nil then
		local v559 = p555.spec_connectionHoses
		for v560 = 1, #p557.customHoseIndices do
			local v561 = p557.customHoseIndices[v560]
			local v562 = v559.customHoses[v561]
			if v562 ~= nil and v562.isActive then
				p555:updateCustomHoseNode(v562, v562.connectedTarget)
			end
		end
	end
	if p557.customTargetIndices ~= nil then
		local v563 = p555.spec_connectionHoses
		for v564 = 1, #p557.customTargetIndices do
			local v565 = p557.customTargetIndices[v564]
			local v566 = v563.customHoseTargets[v565]
			if v566 ~= nil and v566.isActive then
				p555:updateCustomHoseNode(v566.connectedHose, v566)
			end
		end
	end
	if p557.localHoseIndices ~= nil then
		local v567 = p555.spec_connectionHoses
		for v568 = 1, #p557.localHoseIndices do
			local v569 = p557.localHoseIndices[v568]
			local v570 = v567.localHoseNodes[v569]
			if v570 ~= nil and v570.hose.connectedObject ~= nil then
				p555:updateConnectionHose(v570.hose, v569)
			end
		end
	end
end
function ConnectionHoses.onPostAttach(p571, p572, p573, p574)
	p571:connectHosesToAttacherVehicle(p572, p573, p574)
	p571:connectCustomHosesToAttacherVehicle(p572, p573, p574)
end
function ConnectionHoses.onPreDetach(p575, p576, _)
	local v577 = p575.spec_connectionHoses
	local v578 = p575:getActiveInputAttacherJointDescIndex()
	local v579 = p575:getConnectionHosesByInputAttacherJoint(v578)
	for _, v580 in ipairs(v579) do
		p575:disconnectHose(v580)
	end
	for v581 = #v577.updateableHoses, 1, -1 do
		local v582 = v577.updateableHoses[v581]
		if v582.connectedObject == p576 then
			p575:disconnectHose(v582)
		end
	end
	local v583 = p576.spec_connectionHoses
	if v583 ~= nil then
		for _, v584 in pairs(v583.toolConnectorHoses) do
			if v584.delayedMounting ~= nil and v584.delayedMounting.sourceObject == p575 then
				v584.delayedMounting = nil
			end
		end
	end
	local v585 = v577.customHosesByInputAttacher[v578]
	if v585 ~= nil then
		for v586 = 1, #v585 do
			local v587 = v585[v586]
			if v587.isActive then
				p575:disconnectCustomHoseNode(v587, v587.connectedTarget)
			end
		end
	end
	local v588 = v577.customHoseTargetsByInputAttacher[v578]
	if v588 ~= nil then
		for v589 = 1, #v588 do
			local v590 = v588[v589]
			if v590.isActive then
				p575:disconnectCustomHoseNode(v590.connectedHose, v590)
			end
		end
	end
end
local v_u_591 = {
	["TOOL_CONNECTOR_TOP_RIGHT"] = {
		["name"] = "TOOL_CONNECTOR_TOP_RIGHT_02",
		["filename"] = "data/shared/connectionHoses/AdditionalTopRightHose.i3d",
		["sourceLength"] = 3.045
	}
}
function ConnectionHoses.registerAdditionalToolConnectionHoses(p592)
	-- upvalues: (copy) v_u_591
	local v593 = p592.spec_connectionHoses
	for v594 = 1, #v593.toolConnectorHoses do
		local v595 = v593.toolConnectorHoses[v594]
		local v596 = v593.targetNodes[v595.startTargetNodeIndex]
		local v597 = v593.targetNodes[v595.endTargetNodeIndex]
		for v598, v599 in pairs(v_u_591) do
			if v596 ~= nil and (v596.type == v598 and (v597 ~= nil and (v597.type == v598 and calcDistanceFrom(v596.node, v597.node) > 0))) then
				local v600 = p592:loadSubSharedI3DFile(v599.filename, false, false, ConnectionHoses.onAdditionalI3DFileLoaded, p592, {
					["spec"] = v593,
					["startTarget"] = v596,
					["endTarget"] = v597,
					["data"] = v599
				})
				local v601 = v593.additionalSharedLoadRequestIds
				table.insert(v601, v600)
			end
		end
	end
end
local function v_u_609(p602, p603, p604, p605)
	local v606 = {
		["node"] = p603,
		["attacherJointIndices"] = p604.attacherJointIndices,
		["type"] = p605,
		["straighteningFactor"] = p604.straighteningFactor,
		["adapterName"] = p604.adapterName,
		["adapter"] = {}
	}
	v606.adapter.node = p603
	v606.adapter.refNode = p603
	v606.objectChanges = {}
	local v607 = p602.targetNodes
	table.insert(v607, v606)
	v606.index = #p602.targetNodes
	if p602.targetNodesByType[v606.type] == nil then
		p602.targetNodesByType[v606.type] = {}
	end
	local v608 = p602.targetNodesByType[v606.type]
	table.insert(v608, v606)
	return v606.index
end
function ConnectionHoses.onAdditionalI3DFileLoaded(_, p610, _, p611)
	-- upvalues: (copy) v_u_609
	if p610 ~= 0 then
		local v612 = p611.spec
		local v613 = getChildAt(p610, 0)
		local v614 = getChildAt(v613, 1)
		local v615 = getChildAt(v613, 0)
		link(getParent(p611.endTarget.node), v613)
		setTranslation(v613, getTranslation(p611.endTarget.node))
		setRotation(v613, getRotation(p611.endTarget.node))
		local v616 = calcDistanceFrom(p611.startTarget.node, p611.endTarget.node)
		setScale(v613, 1, 1, v616 / p611.data.sourceLength)
		setScale(v614, 1, 1, 1 / (v616 / p611.data.sourceLength))
		setScale(v615, 1, 1, 1 / (v616 / p611.data.sourceLength))
		delete(p610)
		local v617 = {
			["startTargetNodeIndex"] = v_u_609(v612, v614, p611.startTarget, p611.data.name),
			["endTargetNodeIndex"] = v_u_609(v612, v615, p611.endTarget, p611.data.name),
			["mountingNode"] = v613,
			["moveNodes"] = true,
			["additionalHose"] = true
		}
		setVisibility(v613, false)
		if getHasShaderParameter(v617.mountingNode, "colorMat0") then
			v617.mountingNodeDefaultColor = { getShaderParameter(v617.mountingNode, "colorMat0") }
		end
		local v618 = p611.spec.toolConnectorHoses
		table.insert(v618, v617)
		p611.spec.targetNodeToToolConnection[v617.startTargetNodeIndex] = v617
		p611.spec.targetNodeToToolConnection[v617.endTargetNodeIndex] = v617
	end
end
function ConnectionHoses.consoleCommandTestSockets(p619, p620)
	local v621 = p619.spec_connectionHoses
	if v621 ~= nil then
		local v622 = {
			["hydraulicIn"] = Color.new(0, 1, 0),
			["hydraulicOut"] = Color.new(0, 0, 1),
			["electric"] = Color.new(1, 0, 1),
			["airDoubleRed"] = Color.new(1, 0, 0),
			["airDoubleYellow"] = Color.new(1, 1, 0),
			["isobus"] = Color.new(1, 1, 1)
		}
		local v623 = {}
		local v624 = {
			["hydraulicIn"] = "in",
			["hydraulicOut"] = "out",
			["electric"] = "e",
			["airDoubleRed"] = "red",
			["airDoubleYellow"] = "yel",
			["isobus"] = "iso"
		}
		for _, v625 in ipairs(v621.targetNodes) do
			if v625.socket ~= nil then
				g_connectionHoseManager:closeSocket(v625.socket)
			end
			if v625.debugNode ~= nil then
				delete(v625.debugNode)
				v625.debugNode = nil
			end
			if v625.debugLine ~= nil then
				g_debugManager:removeElement(v625.debugLine)
				v625.debugLine = nil
			end
			if v625.debugText ~= nil then
				g_debugManager:removeElement(v625.debugText)
				v625.debugText = nil
			end
			if v625.objectChanges ~= nil then
				ObjectChangeUtil.setObjectChanges(v625.objectChanges, false, p619, p619.setMovingToolDirty)
			end
			if v625.attacherJointIndices[p620] ~= nil then
				if v623[v625.type] == nil then
					v623[v625.type] = 0
				end
				v623[v625.type] = v623[v625.type] + 1
				if v625.socket ~= nil then
					g_connectionHoseManager:openSocket(v625.socket)
				end
				local v626, v627 = g_connectionHoseManager:getClonedAdapterNode(v625.type, "DEFAULT", p619.customEnvironment)
				if v626 ~= nil then
					local v628 = VehicleMaterial.new()
					v628:setTemplateName("plasticPainted")
					v628:setColor(1, 1, 1)
					v628:apply(v626)
					link(g_connectionHoseManager:getSocketTarget(v625.socket, v625.node), v626)
					setTranslation(v626, 0, 0, 0)
					setRotation(v626, 0, 0, 0)
					v625.debugNode = v626
					local v629 = p619:getAttacherJointByJointDescIndex(p620)
					if v629 ~= nil then
						v625.debugLine = DebugLine.new():createWithStartAndEndNode(v629.jointTransform, v627 or v626, false, true, 100, true)
						v625.debugLine:setColors(v622[v625.type], v622[v625.type])
						g_debugManager:addElement(v625.debugLine, nil, nil, (1 / 0))
						local v630 = DebugText.new()
						local v631 = v624[v625.type]
						local v632 = v623[v625.type]
						v625.debugText = v630:createWithNode(v627, v631 .. tostring(v632), 0.015, true)
						v625.debugText.color = v622[v625.type]
						g_debugManager:addElement(v625.debugText, nil, nil, (1 / 0))
					end
				end
				if v625.objectChanges ~= nil then
					ObjectChangeUtil.setObjectChanges(v625.objectChanges, true, p619, p619.setMovingToolDirty)
				end
			end
		end
	end
end

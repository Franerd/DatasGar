StumpCutter = {}
function StumpCutter.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(TurnOnVehicle, p1)
end
function StumpCutter.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("stumpCutter", true, false, false)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("StumpCutter")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.stumpCutter.cutNode(?)#node", "Cut node")
	v2:register(XMLValueType.FLOAT, "vehicle.stumpCutter.cutNode(?)#cutSizeY", "Cut size Y", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.stumpCutter.cutNode(?)#cutSizeZ", "Cut size X", 1)
	v2:register(XMLValueType.TIME, "vehicle.stumpCutter.cutNode(?)#maxCutTime", "Time until cut", 4)
	v2:register(XMLValueType.TIME, "vehicle.stumpCutter.cutNode(?)#maxResetCutTime", "Time between cuts", 4)
	v2:register(XMLValueType.FLOAT, "vehicle.stumpCutter.cutNode(?)#cutFullTreeThreshold", "If the tree length below the cut node is smaller than this value it gets removed", 0.4)
	v2:register(XMLValueType.FLOAT, "vehicle.stumpCutter.cutNode(?)#cutPartThreshold", "Cut part threshold", 0.2)
	v2:register(XMLValueType.INT, "vehicle.stumpCutter.cutNode(?)#workAreaIndex", "Work area index")
	v2:register(XMLValueType.TIME, "vehicle.stumpCutter.cutNode(?)#cutDuration", "Cut duration", 1)
	EffectManager.registerEffectXMLPaths(v2, "vehicle.stumpCutter.cutNode(?).effects")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.stumpCutter.sounds", "start")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.stumpCutter.sounds", "stop")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.stumpCutter.sounds", "idle")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.stumpCutter.sounds", "work")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.stumpCutter.effects")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.stumpCutter.animationNodes")
	v2:setXMLSpecializationType()
end
function StumpCutter.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "crushSplitShape", StumpCutter.crushSplitShape)
	SpecializationUtil.registerFunction(p3, "stumpCutterSplitShapeCallback", StumpCutter.stumpCutterSplitShapeCallback)
	SpecializationUtil.registerFunction(p3, "processStumpCutterArea", StumpCutter.processStumpCutterArea)
end
function StumpCutter.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getDirtMultiplier", StumpCutter.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p4, "getWearMultiplier", StumpCutter.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCultivatorLimitToField", StumpCutter.getCultivatorLimitToField)
	SpecializationUtil.registerOverwrittenFunction(p4, "getPlowLimitToField", StumpCutter.getPlowLimitToField)
	SpecializationUtil.registerOverwrittenFunction(p4, "getPlowForceLimitToField", StumpCutter.getPlowForceLimitToField)
	SpecializationUtil.registerOverwrittenFunction(p4, "getConsumingLoad", StumpCutter.getConsumingLoad)
end
function StumpCutter.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", StumpCutter)
	SpecializationUtil.registerEventListener(p5, "onDelete", StumpCutter)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", StumpCutter)
	SpecializationUtil.registerEventListener(p5, "onDeactivate", StumpCutter)
	SpecializationUtil.registerEventListener(p5, "onTurnedOn", StumpCutter)
	SpecializationUtil.registerEventListener(p5, "onTurnedOff", StumpCutter)
end
function StumpCutter.onLoad(p6, _)
	local v7 = p6.spec_stumpCutter
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode", "vehicle.stumpCutter.animationNodes.animationNode", "stumbCutter")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutterStartSound", "vehicle.stumpCutter.sounds.start")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutterIdleSound", "vehicle.stumpCutter.sounds.idle")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutterWorkSound", "vehicle.stumpCutter.sounds.work")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutterStopSound", "vehicle.stumpCutter.sounds.stop")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutter.emitterShape(0)", "vehicle.stumpCutter.effects.effectNode")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutter.particleSystem(0)", "vehicle.stumpCutter.effects.effectNode")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutter#cutNode", "vehicle.stumpCutter.cutNode#node")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutter#cutSizeY", "vehicle.stumpCutter.cutNode#cutSizeY")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutter#cutSizeZ", "vehicle.stumpCutter.cutNode#cutSizeZ")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutter#cutFullTreeThreshold", "vehicle.stumpCutter.cutNode#cutFullTreeThreshold")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.stumpCutter#cutPartThreshold", "vehicle.stumpCutter.cutNode#cutPartThreshold")
	v7.cutNodes = {}
	v7.currentCutNodeIndex = 1
	local v8 = 0
	while true do
		local v9 = string.format("%s.cutNode(%d)", "vehicle.stumpCutter", v8)
		if not p6.xmlFile:hasProperty(v9) then
			break
		end
		local v10 = p6.xmlFile:getValue(v9 .. "#node", nil, p6.components, p6.i3dMappings)
		if v10 == nil then
			Logging.xmlWarning(p6.xmlFile, "Missing \'node\' for \'%s\'!", v9)
			break
		end
		local v11 = {
			["node"] = v10,
			["cutSizeY"] = p6.xmlFile:getValue(v9 .. "#cutSizeY", 1),
			["cutSizeZ"] = p6.xmlFile:getValue(v9 .. "#cutSizeZ", 1),
			["maxCutTime"] = p6.xmlFile:getValue(v9 .. "#maxCutTime", 4)
		}
		v11.nextCutTime = v11.maxCutTime
		v11.maxResetCutTime = p6.xmlFile:getValue(v9 .. "#maxResetCutTime", 1)
		v11.resetCutTime = v11.maxResetCutTime
		v11.cutFullTreeThreshold = p6.xmlFile:getValue(v9 .. "#cutFullTreeThreshold", 0.4)
		v11.cutPartThreshold = p6.xmlFile:getValue(v9 .. "#cutPartThreshold", 0.2)
		v11.workAreaIndex = p6.xmlFile:getValue(v9 .. "#workAreaIndex")
		v11.workTimer = 0
		v11.workDuration = p6.xmlFile:getValue(v9 .. "#cutDuration", 1)
		v11.lastWorkTime = -1000
		v11.workFadeTime = 0
		v11.maxWorkFadeTime = 1000
		if p6.isClient then
			v11.effects = g_effectManager:loadEffect(p6.xmlFile, v9 .. ".effects", p6.components, p6, p6.i3dMappings)
		end
		local v12 = v7.cutNodes
		table.insert(v12, v11)
		v8 = v8 + 1
	end
	if p6.isClient then
		v7.samples = {}
		v7.samples.start = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.stumpCutter.sounds", "start", p6.baseDirectory, p6.components, 1, AudioGroup.VEHICLE, p6.i3dMappings, p6)
		v7.samples.stop = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.stumpCutter.sounds", "stop", p6.baseDirectory, p6.components, 1, AudioGroup.VEHICLE, p6.i3dMappings, p6)
		v7.samples.idle = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.stumpCutter.sounds", "idle", p6.baseDirectory, p6.components, 0, AudioGroup.VEHICLE, p6.i3dMappings, p6)
		v7.samples.work = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.stumpCutter.sounds", "work", p6.baseDirectory, p6.components, 0, AudioGroup.VEHICLE, p6.i3dMappings, p6)
		v7.maxWorkFadeTime = 1000
		v7.workFadeTime = 0
		v7.effects = g_effectManager:loadEffect(p6.xmlFile, "vehicle.stumpCutter.effects", p6.components, p6, p6.i3dMappings)
		v7.animationNodes = g_animationManager:loadAnimations(p6.xmlFile, "vehicle.stumpCutter.animationNodes", p6.components, p6, p6.i3dMappings)
	end
end
function StumpCutter.onDelete(p13)
	local v14 = p13.spec_stumpCutter
	g_soundManager:deleteSamples(v14.samples)
	g_animationManager:deleteAnimations(v14.animationNodes)
	g_effectManager:deleteEffects(v14.effects)
	if v14.cutNodes ~= nil then
		for v15 = 1, #v14.cutNodes do
			g_effectManager:deleteEffects(v14.cutNodes[v15].effects)
		end
	end
end
function StumpCutter.onUpdateTick(p16, p17, _, _, _)
	if p16:getIsTurnedOn() then
		local v18 = p16.spec_stumpCutter
		local v19 = #v18.cutNodes
		if v19 > 0 then
			local v20 = v18.currentCutNodeIndex + 1
			local v21 = v19 < v20 and 1 or v20
			v18.currentCutNodeIndex = v21
			local v22 = v18.cutNodes[v21]
			v22.curLenAbove = 0
			v22.curLenBelow = 0
			local v23, v24, v25 = getWorldTranslation(v22.node)
			local v26, v27, v28 = localDirectionToWorld(v22.node, 1, 0, 0)
			local v29, v30, v31 = localDirectionToWorld(v22.node, 0, 1, 0)
			if v22.curSplitShape ~= nil and (not entityExists(v22.curSplitShape) or testSplitShape(v22.curSplitShape, v23, v24, v25, v26, v27, v28, v29, v30, v31, v22.cutSizeY, v22.cutSizeZ) == nil) then
				v22.curSplitShape = nil
			end
			if v22.curSplitShape == nil then
				local v32, _, _, _, _ = findSplitShape(v23, v24, v25, v26, v27, v28, v29, v30, v31, v22.cutSizeY, v22.cutSizeZ)
				if v32 ~= 0 then
					v22.curSplitShape = v32
				end
			end
			if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
				local v33, v34, v35 = localToWorld(v22.node, 0, 0, v22.cutSizeZ)
				local v36, v37, v38 = localToWorld(v22.node, 0, v22.cutSizeY, 0)
				DebugPlane.renderWithPositions(v23, v24, v25, v33, v34, v35, v36, v37, v38, Color.PRESETS.PINK)
			end
			if v22.curSplitShape == nil then
				local v39 = v22.workFadeTime - p17
				v22.workFadeTime = math.max(0, v39)
				if p16.isServer and v22.resetCutTime > 0 then
					v22.resetCutTime = v22.resetCutTime - p17
					if v22.resetCutTime <= 0 then
						v22.nextCutTime = v22.maxCutTime
					end
				end
			else
				local v40, v41 = getSplitShapePlaneExtents(v22.curSplitShape, v23, v24, v25, v26, v27, v28)
				if v22.cutPartThreshold <= v41 then
					v22.lastWorkTime = g_time
				end
				local v42 = v22.maxWorkFadeTime
				local v43 = v22.workFadeTime + p17 * v19
				v22.workFadeTime = math.min(v42, v43)
				if p16.isServer then
					v22.resetCutTime = v22.maxResetCutTime
					if v22.nextCutTime > 0 then
						v22.nextCutTime = v22.nextCutTime - p17
						if v22.nextCutTime <= 0 then
							local _, v44, _ = worldToLocal(v22.curSplitShape, v23, v24, v25)
							if (v40 <= v22.cutFullTreeThreshold or v44 < v22.cutPartThreshold + 0.01) and v41 < 1 then
								p16:crushSplitShape(v22.curSplitShape)
								v22.curSplitShape = nil
							elseif v22.cutPartThreshold <= v41 and v22.cutPartThreshold <= v40 then
								v22.nextCutTime = v22.maxCutTime
								local v45 = v22.curSplitShape
								v22.curSplitShape = nil
								v22.curLenAbove = v41
								v22.curLenBelow = v40
								p16.shapeBeingCut = v45
								splitShape(v45, v23, v24, v25, v26, v27, v28, v29, v30, v31, v22.cutSizeY, v22.cutSizeZ, "stumpCutterSplitShapeCallback", p16)
								g_treePlantManager:removingSplitShape(v45)
							else
								v22.curSplitShape = nil
								v22.nextCutTime = v22.maxCutTime
							end
						end
					end
				end
			end
			if p16.isClient then
				if v22.lastWorkTime + 500 > g_time then
					g_effectManager:setEffectTypeInfo(v22.effects, FillType.WOODCHIPS)
					g_effectManager:startEffects(v22.effects)
				else
					g_effectManager:stopEffects(v22.effects)
				end
				local v46 = false
				for v47 = 1, #v18.cutNodes do
					if v18.cutNodes[v47].lastWorkTime + 500 > g_time then
						v46 = true
						break
					end
				end
				if v46 then
					g_effectManager:setEffectTypeInfo(v18.effects, FillType.WOODCHIPS)
					g_effectManager:startEffects(v18.effects)
					if not g_soundManager:getIsSamplePlaying(v18.samples.work) then
						g_soundManager:playSample(v18.samples.work)
						return
					end
				else
					g_effectManager:stopEffects(v18.effects)
					if g_soundManager:getIsSamplePlaying(v18.samples.work) then
						g_soundManager:stopSample(v18.samples.work)
					end
				end
			end
		end
	end
end
function StumpCutter.onDeactivate(p48)
	if p48.isClient then
		local v49 = p48.spec_stumpCutter
		g_effectManager:stopEffects(v49.effects)
		for v50 = 1, #v49.cutNodes do
			g_effectManager:stopEffects(v49.cutNodes[v50].effects)
		end
	end
end
function StumpCutter.onTurnedOn(p51)
	if p51.isClient then
		local v52 = p51.spec_stumpCutter
		g_soundManager:stopSamples(v52.samples)
		g_soundManager:playSample(v52.samples.start)
		g_soundManager:playSample(v52.samples.idle, 0, v52.samples.start)
		g_animationManager:startAnimations(v52.animationNodes)
	end
end
function StumpCutter.onTurnedOff(p53)
	if p53.isClient then
		local v54 = p53.spec_stumpCutter
		v54.workFadeTime = 0
		g_effectManager:stopEffects(v54.effects)
		for v55 = 1, #v54.cutNodes do
			g_effectManager:stopEffects(v54.cutNodes[v55].effects)
		end
		g_soundManager:stopSamples(v54.samples)
		g_soundManager:playSample(v54.samples.stop)
		g_animationManager:stopAnimations(v54.animationNodes)
	end
end
function StumpCutter.crushSplitShape(p56, p57)
	if p56.isServer then
		local v58, _, v59 = getWorldTranslation(p57)
		delete(p57)
		g_densityMapHeightManager:setCollisionMapAreaDirty(v58 - 10, v59 - 10, v58 + 10, v59 + 10, true)
		g_currentMission.aiSystem:setAreaDirty(v58 - 10, v58 + 10, v59 - 10, v59 + 10)
	end
end
function StumpCutter.stumpCutterSplitShapeCallback(p60, p61, p62, _, p63, p64, p65, p66)
	local v67 = p60.spec_stumpCutter
	local v68 = v67.cutNodes[v67.currentCutNodeIndex]
	if p62 then
		local v69 = p63 + (p64 - p63) / 2
		local v70 = p65 + (p66 - p65) / 2
		local _, v71, _ = localToWorld(v68.node, -0.05, v69, v70)
		if v71 < getTerrainHeightAtWorldPos(g_terrainNode, getWorldTranslation(v68.node)) then
			p60:crushSplitShape(p61)
		else
			v67.curSplitShape = p61
			g_treePlantManager:addingSplitShape(p61, p60.shapeBeingCut)
		end
	elseif v68.curLenAbove < 1 then
		p60:crushSplitShape(p61)
	else
		g_treePlantManager:addingSplitShape(p61, p60.shapeBeingCut)
	end
end
function StumpCutter.processStumpCutterArea(p72, p73, _)
	local v74 = p72.spec_stumpCutter
	local v75 = 0
	local v76 = 0
	for _, v77 in ipairs(v74.cutNodes) do
		if v77.workAreaIndex == p73.index then
			local v78, _, v79 = getWorldTranslation(p73.start)
			local v80, _, v81 = getWorldTranslation(p73.width)
			local v82, _, v83 = getWorldTranslation(p73.height)
			local v84, v85, v86 = FSDensityMapUtil.clearDecoArea(v78, v79, v80, v81, v82, v83)
			if v84 > 0 and v86 then
				v77.lastWorkTime = g_time
			end
			v75 = v75 + v84
			v76 = v76 + v85
		end
	end
	return v75, v76
end
function StumpCutter.getDirtMultiplier(p87, p88)
	local v89 = p88(p87)
	if p87.spec_stumpCutter.curSplitShape ~= nil then
		v89 = v89 + p87:getWorkDirtMultiplier()
	end
	return v89
end
function StumpCutter.getWearMultiplier(p90, p91)
	local v92 = p91(p90)
	if p90.spec_stumpCutter.curSplitShape ~= nil then
		v92 = v92 + p90:getWorkWearMultiplier()
	end
	return v92
end
function StumpCutter.getCultivatorLimitToField(_, _)
	return false
end
function StumpCutter.getPlowLimitToField(_)
	return false
end
function StumpCutter.getPlowForceLimitToField(_)
	return true
end
function StumpCutter.getConsumingLoad(p93, p94)
	local v95, v96 = p94(p93)
	local v97 = p93.spec_stumpCutter
	local v98 = 0
	for v99 = 1, #v97.cutNodes do
		if v97.cutNodes[v99].lastWorkTime + 500 > g_time then
			v98 = 1
			break
		end
	end
	return v95 + v98, v96 + 1
end

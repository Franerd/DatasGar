source("dataS/scripts/vehicles/specializations/events/EnterablePassengerEnterRequestEvent.lua")
source("dataS/scripts/vehicles/specializations/events/EnterablePassengerEnterResponseEvent.lua")
source("dataS/scripts/vehicles/specializations/events/EnterablePassengerLeaveEvent.lua")
EnterablePassenger = {}
EnterablePassenger.DEBUG_ACTIVE = false
EnterablePassenger.SEAT_INDEX_SEND_NUM_BITS = 4
function EnterablePassenger.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Enterable, p1)
end
function EnterablePassenger.initSpecialization()
	Vehicle.INTERACTION_FLAG_ENTERABLE_PASSENGER = Vehicle.registerInteractionFlag("ENTERABLE_PASSENGER")
	g_vehicleConfigurationManager:addConfigurationType("enterablePassenger", g_i18n:getText("shop_configuration"), "enterable", VehicleConfigurationItem)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("EnterablePassenger")
	EnterablePassenger.registerXMLPaths("vehicle.enterable.passengerSeats", v2)
	EnterablePassenger.registerXMLPaths("vehicle.enterable.enterablePassengerConfigurations.enterablePassengerConfiguration(?)", v2)
	v2:setXMLSpecializationType()
end
function EnterablePassenger.registerXMLPaths(p3, p4)
	p4:register(XMLValueType.NODE_INDEX, p3 .. ".passengerSeat(?)#node", "Seat reference node to calculate entering distance to")
	p4:register(XMLValueType.NODE_INDEX, p3 .. ".passengerSeat(?)#exitPoint", "Player spawn point when leaving the vehicle")
	p4:register(XMLValueType.INT, p3 .. ".passengerSeat(?)#outdoorCameraIndex", "Index of regular outdoor camera if it should be available as well")
	p4:register(XMLValueType.FLOAT, p3 .. ".passengerSeat(?)#nicknameOffset", "Nickname rendering offset", 1.5)
	VehicleCamera.registerCameraXMLPaths(p4, p3 .. ".passengerSeat(?).camera(?)")
	VehicleCharacter.registerCharacterXMLPaths(p4, p3 .. ".passengerSeat(?).characterNode")
end
function EnterablePassenger.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "getClosestSeatIndex", EnterablePassenger.getClosestSeatIndex)
	SpecializationUtil.registerFunction(p5, "getIsPassengerSeatAvailable", EnterablePassenger.getIsPassengerSeatAvailable)
	SpecializationUtil.registerFunction(p5, "getIsPassengerSeatIndexAvailable", EnterablePassenger.getIsPassengerSeatIndexAvailable)
	SpecializationUtil.registerFunction(p5, "getFirstAvailablePassengerSeat", EnterablePassenger.getFirstAvailablePassengerSeat)
	SpecializationUtil.registerFunction(p5, "getPlayerNameBySeatIndex", EnterablePassenger.getPlayerNameBySeatIndex)
	SpecializationUtil.registerFunction(p5, "getCanUsePassengerSeats", EnterablePassenger.getCanUsePassengerSeats)
	SpecializationUtil.registerFunction(p5, "enterVehiclePassengerSeat", EnterablePassenger.enterVehiclePassengerSeat)
	SpecializationUtil.registerFunction(p5, "leaveLocalPassengerSeat", EnterablePassenger.leaveLocalPassengerSeat)
	SpecializationUtil.registerFunction(p5, "leavePassengerSeat", EnterablePassenger.leavePassengerSeat)
	SpecializationUtil.registerFunction(p5, "getPassengerSeatIndexByPlayer", EnterablePassenger.getPassengerSeatIndexByPlayer)
	SpecializationUtil.registerFunction(p5, "copyEnterableActiveCameraIndex", EnterablePassenger.copyEnterableActiveCameraIndex)
	SpecializationUtil.registerFunction(p5, "setPassengerActiveCameraIndex", EnterablePassenger.setPassengerActiveCameraIndex)
	SpecializationUtil.registerFunction(p5, "enablePassengerActiveCamera", EnterablePassenger.enablePassengerActiveCamera)
	SpecializationUtil.registerFunction(p5, "setPassengerSeatCharacter", EnterablePassenger.setPassengerSeatCharacter)
	SpecializationUtil.registerFunction(p5, "updatePassengerSeatCharacter", EnterablePassenger.updatePassengerSeatCharacter)
	SpecializationUtil.registerFunction(p5, "onPassengerPlayerStyleChanged", EnterablePassenger.onPassengerPlayerStyleChanged)
end
function EnterablePassenger.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "getInteractionHelp", EnterablePassenger.getInteractionHelp)
	SpecializationUtil.registerOverwrittenFunction(p6, "interact", EnterablePassenger.interact)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDistanceToNode", EnterablePassenger.getDistanceToNode)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsEnterable", EnterablePassenger.getIsEnterable)
	SpecializationUtil.registerOverwrittenFunction(p6, "getExitNode", EnterablePassenger.getExitNode)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsInUse", EnterablePassenger.getIsInUse)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDeactivateOnLeave", EnterablePassenger.getDeactivateOnLeave)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsInteractive", EnterablePassenger.getIsInteractive)
end
function EnterablePassenger.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onDelete", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onReadStream", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onWriteStream", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onPostUpdate", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onDrawUIInfo", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onSetBroken", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onEnterVehicle", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onLeaveVehicle", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onPreRegisterActionEvents", EnterablePassenger)
	SpecializationUtil.registerEventListener(p7, "onRegisterActionEvents", EnterablePassenger)
end
function EnterablePassenger.onLoad(p_u_8, _)
	local v9 = p_u_8.spec_enterablePassenger
	v9.currentSeatIndex = 1
	v9.passengerEntered = false
	local v10 = "vehicle.enterable.passengerSeats"
	local v11 = p_u_8.configurations.enterablePassenger
	local v12
	if v11 == nil then
		v12 = v10
	else
		v12 = string.format("vehicle.enterable.enterablePassengerConfigurations.enterablePassengerConfiguration(%d)", v11 - 1)
		if not p_u_8.xmlFile:hasProperty(v12) then
			v12 = v10
		end
	end
	v9.passengerSeats = {}
	for _, v13 in p_u_8.xmlFile:iterator(v12 .. ".passengerSeat") do
		local v_u_14 = {
			["node"] = p_u_8.xmlFile:getValue(v13 .. "#node", nil, p_u_8.components, p_u_8.i3dMappings),
			["exitPoint"] = p_u_8.xmlFile:getValue(v13 .. "#exitPoint", nil, p_u_8.components, p_u_8.i3dMappings)
		}
		if v_u_14.node == nil then
			Logging.xmlWarning(p_u_8.xmlFile, "Missing node for \'%s\'", v13)
		else
			v_u_14.cameras = {}
			v_u_14.camIndex = 1
			local v15 = p_u_8.xmlFile:getValue(v13 .. "#outdoorCameraIndex")
			if v15 ~= nil then
				local v16 = p_u_8.spec_enterable
				if v16.cameras ~= nil and v16.cameras[v15] ~= nil then
					local v17 = v_u_14.cameras
					local v18 = v16.cameras[v15]
					table.insert(v17, v18)
				end
			end
			p_u_8.xmlFile:iterate(v13 .. ".camera", function(p19, p20)
				-- upvalues: (copy) p_u_8, (copy) v_u_14
				local v21 = VehicleCamera.new(p_u_8)
				if v21:loadFromXML(p_u_8.xmlFile, p20, nil, p19) then
					v21.isPassengerCamera = true
					local v22 = v_u_14.cameras
					table.insert(v22, v21)
				end
			end)
			v_u_14.nicknameOffset = p_u_8.xmlFile:getValue(v13 .. "#nicknameOffset", 1.5)
			v_u_14.vehicleCharacter = VehicleCharacter.new(p_u_8)
			if v_u_14.vehicleCharacter ~= nil and not v_u_14.vehicleCharacter:load(p_u_8.xmlFile, v13 .. ".characterNode") then
				v_u_14.vehicleCharacter = nil
			end
			v_u_14.isUsed = false
			v_u_14.playerStyle = nil
			v_u_14.userId = nil
			local v23 = v9.passengerSeats
			table.insert(v23, v_u_14)
		end
	end
	local v24
	if #v9.passengerSeats > 0 then
		v24 = g_currentMission.missionDynamicInfo.isMultiplayer
	else
		v24 = false
	end
	v9.available = v24
	v9.texts = {}
	v9.texts.enterVehicleDriver = string.format("%s (%s)", g_i18n:getText("button_enterVehicle"), g_i18n:getText("passengerSeat_driver"))
	v9.texts.enterVehiclePassenger = string.format("%s (%s)", g_i18n:getText("button_enterVehicle"), g_i18n:getText("passengerSeat_passenger"))
	v9.texts.switchSeatDriver = g_i18n:getText("passengerSeat_switchSeatDriver")
	v9.texts.switchSeatPassenger = g_i18n:getText("passengerSeat_switchSeatPassenger")
	v9.texts.switchNextSeat = g_i18n:getText("passengerSeat_switchNextSeat")
	v9.minEnterDistance = 3
	if v9.available then
		g_messageCenter:subscribe(MessageType.PLAYER_STYLE_CHANGED, p_u_8.onPassengerPlayerStyleChanged, p_u_8)
	end
end
function EnterablePassenger.onDelete(p25)
	p25:leaveLocalPassengerSeat(true)
	local v26 = p25.spec_enterablePassenger
	if v26.passengerSeats ~= nil then
		for v27 = 1, #v26.passengerSeats do
			local v28 = v26.passengerSeats[v27]
			if v28.isUsed then
				p25:leavePassengerSeat(false, v27)
			end
			for _, v29 in ipairs(v28.cameras) do
				if v29.isPassengerCamera then
					v29:delete()
				end
			end
			if v28.vehicleCharacter ~= nil then
				v28.vehicleCharacter:delete()
			end
		end
	end
end
function EnterablePassenger.onReadStream(p30, p31, _)
	for v32 = 1, #p30.spec_enterablePassenger.passengerSeats do
		if streamReadBool(p31) then
			local v33 = User.streamReadUserId(p31)
			local v34 = g_playerSystem:getPlayerByUserId(v33)
			if v34 ~= nil then
				v34:onEnterVehicleAsPassenger(p30, v32)
			end
		end
	end
end
function EnterablePassenger.onWriteStream(p35, p36, _)
	local v37 = p35.spec_enterablePassenger
	for v38 = 1, #v37.passengerSeats do
		local v39 = v37.passengerSeats[v38]
		if streamWriteBool(p36, v39.isUsed) then
			User.streamWriteUserId(p36, v39.userId)
		end
	end
end
function EnterablePassenger.onPostUpdate(p40, p41, _, _, _)
	local v42 = p40.spec_enterablePassenger
	if v42.available and p40.isClient then
		local v43 = p40.spec_enterable
		if v43.activeCamera ~= nil then
			v43.activeCamera:update(p41)
		end
		EnterablePassenger.updateActionEvents(p40)
		if v42.passengerEntered then
			p40:raiseActive()
		end
		p40:updatePassengerSeatCharacter(p41)
	end
end
function EnterablePassenger.onDrawUIInfo(p44)
	local v45 = p44.spec_enterablePassenger
	if v45.available then
		local v46 = not (g_gui:getIsGuiVisible() or g_noHudModeEnabled)
		if v46 then
			v46 = g_gameSettings:getValue(GameSettings.SETTING.SHOW_MULTIPLAYER_NAMES)
		end
		if p44.isClient and v46 then
			for v47 = 1, #v45.passengerSeats do
				local v48 = v45.passengerSeats[v47]
				if v48.isUsed and (not v45.passengerEntered or v47 ~= v45.currentSeatIndex) and calcDistanceFrom(v48.node, getCamera()) < 100 then
					local v49, v50, v51 = getWorldTranslation(v48.node)
					local v52 = v50 + v48.nicknameOffset
					Utils.renderTextAtWorldPosition(v49, v52, v51, p44:getPlayerNameBySeatIndex(v47), getCorrectTextSize(0.02), 0)
				end
			end
		end
	end
end
function EnterablePassenger.onSetBroken(p53)
	if p53.spec_enterablePassenger.passengerEntered then
		g_localPlayer:leaveVehicle()
	end
end
function EnterablePassenger.onEnterVehicle(p54)
	if EnterablePassenger.DEBUG_ACTIVE then
		for v55 = 1, #p54.spec_enterablePassenger.passengerSeats do
			p54:setPassengerSeatCharacter(v55, p54:getUserPlayerStyle())
		end
	end
end
function EnterablePassenger.onLeaveVehicle(p56)
	if EnterablePassenger.DEBUG_ACTIVE then
		for v57 = 1, #p56.spec_enterablePassenger.passengerSeats do
			p56:setPassengerSeatCharacter(v57, nil)
		end
	end
end
function EnterablePassenger.getInteractionHelp(p58, p59)
	if p58.spec_enterablePassenger.available and p58.interactionFlag == Vehicle.INTERACTION_FLAG_ENTERABLE_PASSENGER then
		return p58.spec_enterablePassenger.texts.enterVehiclePassenger
	else
		return p59(p58)
	end
end
function EnterablePassenger.interact(p60, p61, p62)
	if p60.interactionFlag == Vehicle.INTERACTION_FLAG_ENTERABLE_PASSENGER then
		p62:requestToEnterVehicleAsPassenger(p60, (p60:getClosestSeatIndex(p62.rootNode)))
	else
		p61(p60, p62)
	end
end
function EnterablePassenger.getIsInteractive(p63, p64)
	if p63.isBroken then
		return false
	elseif p63:getIsControlled() then
		return p63:getCanUsePassengerSeats()
	else
		return p64(p63)
	end
end
function EnterablePassenger.getDistanceToNode(p65, p66, p67)
	local v68 = p66(p65, p67)
	if p65:getIsControlled() then
		local v69, v70 = p65:getClosestSeatIndex(p67)
		if v69 ~= nil and v70 < v68 then
			p65.interactionFlag = Vehicle.INTERACTION_FLAG_ENTERABLE_PASSENGER
			return v70
		end
	end
	return v68
end
function EnterablePassenger.getIsEnterable(p71, p72)
	if not p71.spec_enterablePassenger.available then
		return p72(p71)
	end
	local v73 = not p71:getCanUsePassengerSeats()
	if v73 then
		v73 = p72(p71)
	end
	return v73
end
function EnterablePassenger.getExitNode(p74, p75, p76)
	local v77 = p74.spec_enterablePassenger
	if v77.available then
		for v78 = 1, #v77.passengerSeats do
			local v79 = v77.passengerSeats[v78]
			if v79.userId == p76.userId then
				return v79.exitPoint
			end
		end
	end
	return p75(p74, p76)
end
function EnterablePassenger.getIsInUse(p80, p81, p82)
	local v83 = p80.spec_enterablePassenger
	if v83.available then
		for v84 = 1, #v83.passengerSeats do
			if v83.passengerSeats[v84].isUsed then
				return true
			end
		end
	end
	return p81(p80, p82)
end
function EnterablePassenger.getDeactivateOnLeave(p85, p86, p87)
	local v88 = p85.spec_enterablePassenger
	if v88.available then
		for v89 = 1, #v88.passengerSeats do
			if v88.passengerSeats[v89].isUsed then
				return false
			end
		end
	end
	return p86(p85, p87)
end
function EnterablePassenger.onPreRegisterActionEvents(p90, _, _)
	local v91 = p90.spec_enterablePassenger
	if v91.available then
		p90:clearActionEventsTable(v91.actionEvents)
	end
end
function EnterablePassenger.onRegisterActionEvents(p92, _, _)
	local v93 = p92.spec_enterablePassenger
	if v93.available then
		if v93.passengerEntered then
			g_localPlayer.inputComponent:registerGlobalPlayerActionEvents(Vehicle.INPUT_CONTEXT_NAME)
			local _, v94 = p92:addActionEvent(v93.actionEvents, InputAction.ENTER, p92, EnterablePassenger.actionEventLeave, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v94, GS_PRIO_VERY_HIGH)
			g_inputBinding:setActionEventTextVisibility(v94, false)
			local v95 = v93.passengerSeats[v93.currentSeatIndex]
			if v95 ~= nil and #v95.cameras > 0 then
				local _, v96 = p92:addActionEvent(v93.actionEvents, InputAction.CAMERA_SWITCH, p92, EnterablePassenger.actionEventCameraSwitch, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v96, GS_PRIO_LOW)
				g_inputBinding:setActionEventTextVisibility(v96, true)
			end
			local _, v97 = p92:addActionEvent(v93.actionEvents, InputAction.CAMERA_ZOOM_IN_OUT, p92, Enterable.actionEventCameraZoomInOut, false, true, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v97, GS_PRIO_LOW)
			g_inputBinding:setActionEventTextVisibility(v97, false)
			local _, v98 = p92:addActionEvent(v93.actionEvents, InputAction.SWITCH_SEAT, p92, EnterablePassenger.actionEventSwitchSeat, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v98, GS_PRIO_HIGH)
		elseif p92:getIsEntered() and p92:getIsActiveForInput(true, true) then
			local _, v99 = p92:addActionEvent(v93.actionEvents, InputAction.SWITCH_SEAT, p92, EnterablePassenger.actionEventSwitchSeat, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v99, GS_PRIO_HIGH)
		end
		EnterablePassenger.updateActionEvents(p92)
	end
end
function EnterablePassenger.actionEventLeave(p100, _, _, _, _, _)
	if p100.spec_enterablePassenger.passengerEntered then
		g_localPlayer:leaveVehicle()
	end
end
function EnterablePassenger.actionEventCameraSwitch(p101, _, _, _, _, _)
	if p101.spec_enterablePassenger.passengerEntered then
		p101:setPassengerActiveCameraIndex()
	end
end
function EnterablePassenger.actionEventSwitchSeat(p102, _, _, _, _, _)
	local v103 = p102.spec_enterablePassenger
	if v103.passengerEntered then
		local v104 = p102:getFirstAvailablePassengerSeat(v103.currentSeatIndex)
		if v104 ~= nil then
			p102:copyEnterableActiveCameraIndex(v104)
			g_localPlayer:requestToEnterVehicleAsPassenger(p102, v104)
			return
		end
		if not p102:getIsControlled() and g_currentMission.accessHandler:canPlayerAccess(p102) then
			p102:copyEnterableActiveCameraIndex()
			g_localPlayer:requestToEnterVehicle(p102)
			return
		end
	end
	local v105 = p102:getFirstAvailablePassengerSeat()
	if v105 ~= nil then
		p102:copyEnterableActiveCameraIndex(v105)
		g_localPlayer:requestToEnterVehicleAsPassenger(p102, v105)
	end
end
function EnterablePassenger.updateActionEvents(p106)
	local v107 = p106.spec_enterablePassenger
	local v108 = v107.actionEvents[InputAction.SWITCH_SEAT]
	if v108 ~= nil then
		local v109 = false
		if v107.passengerEntered then
			if p106:getFirstAvailablePassengerSeat(v107.currentSeatIndex) == nil then
				if not p106:getIsControlled() and g_currentMission.accessHandler:canPlayerAccess(p106) then
					g_inputBinding:setActionEventText(v108.actionEventId, v107.texts.switchSeatDriver)
					v109 = true
				end
			else
				g_inputBinding:setActionEventText(v108.actionEventId, v107.texts.switchNextSeat)
				v109 = true
			end
		end
		if not v109 and p106:getFirstAvailablePassengerSeat() ~= nil then
			g_inputBinding:setActionEventText(v108.actionEventId, v107.texts.switchSeatPassenger)
			v109 = true
		end
		g_inputBinding:setActionEventActive(v108.actionEventId, v109)
	end
end
function EnterablePassenger.getClosestSeatIndex(p110, p111)
	local v112 = p110.spec_enterablePassenger
	local v113 = (1 / 0)
	local v114 = nil
	for v115 = 1, #v112.passengerSeats do
		local v116 = v112.passengerSeats[v115]
		if p110:getIsPassengerSeatAvailable(v116) then
			local v117 = calcDistanceFrom(p111, v116.node)
			if v117 < v112.minEnterDistance and v117 < v113 then
				v114 = v115
				v113 = v117
			end
		end
	end
	return v114, v113
end
function EnterablePassenger.getIsPassengerSeatAvailable(_, p118)
	return not p118.isUsed
end
function EnterablePassenger.getIsPassengerSeatIndexAvailable(p119, p120)
	local v121 = p119.spec_enterablePassenger.passengerSeats[p120]
	if v121 == nil then
		return false
	else
		return p119:getIsPassengerSeatAvailable(v121)
	end
end
function EnterablePassenger.getFirstAvailablePassengerSeat(p122, p123)
	local v124 = p122.spec_enterablePassenger
	for v125 = p123 or 1, #v124.passengerSeats do
		if p122:getIsPassengerSeatAvailable(v124.passengerSeats[v125]) then
			return v125
		end
	end
	return nil
end
function EnterablePassenger.getPlayerNameBySeatIndex(p126, p127)
	local v128 = p126.spec_enterablePassenger.passengerSeats[p127]
	if v128 ~= nil then
		local v129 = g_currentMission.userManager:getUserByUserId(v128.userId)
		if v129 ~= nil then
			return v129:getNickname()
		end
	end
	return ""
end
function EnterablePassenger.getCanUsePassengerSeats(p130)
	if p130.isBroken then
		return false
	else
		return p130:getIsControlled() and true or not g_currentMission.accessHandler:canPlayerAccess(p130)
	end
end
function EnterablePassenger.enterVehiclePassengerSeat(p131, p132, p133, p134, p135)
	local v136 = p131.spec_enterablePassenger
	if p132 then
		if v136.passengerEntered then
			p131:leaveLocalPassengerSeat(true)
		end
		v136.currentSeatIndex = p133
		v136.passengerEntered = true
		p131:enablePassengerActiveCamera()
		p131:setPassengerSeatCharacter(p133, p134)
		if p131.spec_enterable.playerHotspot ~= nil then
			p131.spec_enterable.playerHotspot:setOwnerFarmId(g_currentMission:getFarmId())
			g_currentMission:addMapHotspot(p131.spec_enterable.playerHotspot)
		end
		if p131.isClient then
			g_messageCenter:subscribe(MessageType.INPUT_BINDINGS_CHANGED, p131.requestActionEventUpdate, p131)
			p131:requestActionEventUpdate()
		end
	else
		for v137, v138 in ipairs(v136.passengerSeats) do
			if v138.isUsed and v138.userId == p135 then
				p131:leavePassengerSeat(false, v137)
				break
			end
		end
		p131:setPassengerSeatCharacter(p133, p134)
	end
	local v139 = true
	for v140 = 1, #v136.passengerSeats do
		if v136.passengerSeats[v140].isUsed then
			v139 = false
			break
		end
	end
	if v139 and not p131:getIsControlled() then
		p131:activate()
	end
	local v141 = v136.passengerSeats[p133]
	if v141 ~= nil then
		v141.isUsed = true
		v141.playerStyle = p134
		v141.userId = p135
	end
end
function EnterablePassenger.leaveLocalPassengerSeat(p142, p143)
	local v144 = p142.spec_enterablePassenger
	if v144.passengerEntered then
		if p143 ~= true then
			g_client:getServerConnection():sendEvent(EnterablePassengerLeaveEvent.new(p142, g_localPlayer.userId))
		end
		p142:leavePassengerSeat(true, v144.currentSeatIndex)
	end
end
function EnterablePassenger.leavePassengerSeat(p145, p146, p147)
	local v148 = p145.spec_enterablePassenger
	if p146 then
		local v149 = p145.spec_enterable
		if v149.activeCamera ~= nil and v148.passengerEntered then
			v149.activeCamera:onDeactivate()
			g_soundManager:setIsIndoor(false)
			g_currentMission.ambientSoundSystem:setIsIndoor(false)
			g_currentMission.environment.environmentMaskSystem:setIsIndoor(false)
			g_currentMission.activatableObjectsSystem:deactivate(Vehicle.INPUT_CONTEXT_NAME)
			v149.activeCamera = nil
		end
		p145:setMirrorVisible(false)
		p145:setPassengerSeatCharacter(p147, nil)
		v148.currentSeatIndex = 1
		v148.passengerEntered = false
		if p145.spec_enterable.playerHotspot ~= nil then
			g_currentMission:removeMapHotspot(p145.spec_enterable.playerHotspot)
		end
		if p145.isClient then
			g_messageCenter:unsubscribe(MessageType.INPUT_BINDINGS_CHANGED, p145)
			p145:requestActionEventUpdate()
			if g_touchHandler ~= nil then
				g_touchHandler:removeGestureListener(p145.touchListenerDoubleTab)
			end
		end
	else
		p145:setPassengerSeatCharacter(p147, nil)
	end
	local v150 = v148.passengerSeats[p147]
	if v150 ~= nil then
		v150.isUsed = false
		v150.playerStyle = nil
		v150.userId = nil
	end
	if not p145:getIsControlled() then
		local v151 = true
		for v152 = 1, #v148.passengerSeats do
			if v148.passengerSeats[v152].isUsed then
				v151 = false
				break
			end
		end
		if v151 then
			p145:deactivate()
		end
	end
end
function EnterablePassenger.getPassengerSeatIndexByPlayer(p153, p154)
	local v155 = p153.spec_enterablePassenger
	for v156 = 1, #v155.passengerSeats do
		if v155.passengerSeats[v156].userId == p154 then
			return v156
		end
	end
	return nil
end
function EnterablePassenger.copyEnterableActiveCameraIndex(p157, p158)
	local v159 = p157.spec_enterablePassenger
	local v160 = p157.spec_enterable
	if v160.activeCamera ~= nil then
		if p158 == nil then
			if v159.passengerSeats[v159.currentSeatIndex] ~= nil then
				local v161 = false
				for v162 = 1, #v160.cameras do
					if v160.cameras[v162] == v160.activeCamera then
						v160.camIndex = v162
						v161 = true
					end
				end
				if not v161 then
					for v163 = 1, #v160.cameras do
						if v160.cameras[v163].isInside == v160.activeCamera.isInside then
							v160.camIndex = v163
							return
						end
					end
				end
			end
		else
			local v164 = v159.passengerSeats[p158]
			if v164 ~= nil then
				local v165 = false
				for v166 = 1, #v164.cameras do
					if v164.cameras[v166] == v160.activeCamera then
						v164.camIndex = v166
						v165 = true
					end
				end
				if not v165 then
					for v167 = 1, #v164.cameras do
						if v164.cameras[v167].isInside == v160.activeCamera.isInside then
							v164.camIndex = v167
							return
						end
					end
					return
				end
			end
		end
	end
end
function EnterablePassenger.setPassengerActiveCameraIndex(p168, p169, p170)
	local v171 = p168.spec_enterablePassenger
	local v172 = v171.passengerSeats[p170 or v171.currentSeatIndex]
	if v172 ~= nil then
		v172.camIndex = p169 or v172.camIndex + 1
		if v172.camIndex > #v172.cameras then
			v172.camIndex = 1
		end
	end
	p168:enablePassengerActiveCamera()
end
function EnterablePassenger.enablePassengerActiveCamera(p173)
	local v174 = p173.spec_enterablePassenger
	local v175 = p173.spec_enterable
	if v175.activeCamera ~= nil then
		v175.activeCamera:onDeactivate()
	end
	local v176 = v174.passengerSeats[v174.currentSeatIndex]
	if v176 ~= nil then
		local v177 = v176.cameras[v176.camIndex]
		v175.activeCamera = v177
		v175.activeCamera:onActivate()
		p173:setMirrorVisible(v177.useMirror)
		g_currentMission.environmentAreaSystem:setReferenceNode(v177.cameraNode)
	end
	p173:updatePassengerSeatCharacter(99999)
	p173:raiseActive()
end
function EnterablePassenger.setPassengerSeatCharacter(p178, p179, p180)
	local v181 = p178.spec_enterablePassenger.passengerSeats[p179]
	if v181 ~= nil and v181.vehicleCharacter ~= nil then
		v181.vehicleCharacter:unloadCharacter()
		if p180 ~= nil then
			v181.vehicleCharacter:loadCharacter(p180, p178, EnterablePassenger.vehiclePassengerCharacterLoaded, { v181 })
		end
	end
end
function EnterablePassenger.updatePassengerSeatCharacter(p182, p183)
	local v184 = p182.spec_enterablePassenger
	for _, v185 in ipairs(v184.passengerSeats) do
		if v185.isUsed and v185.vehicleCharacter ~= nil then
			v185.vehicleCharacter:updateVisibility()
			v185.vehicleCharacter:update(p183)
		end
	end
end
function EnterablePassenger.onPassengerPlayerStyleChanged(p186, p187, p188)
	local v189 = p186.spec_enterablePassenger
	for v190 = 1, #v189.passengerSeats do
		if v189.passengerSeats[v190].userId == p188 then
			p186:setPassengerSeatCharacter(v190, p187)
		end
	end
end
function EnterablePassenger.vehiclePassengerCharacterLoaded(_, p191, p192)
	if p191 == HumanModelLoadingState.OK then
		local v193 = p192[1]
		if v193 ~= nil then
			v193.vehicleCharacter:updateVisibility()
			v193.vehicleCharacter:updateIKChains()
			if EnterablePassenger.DEBUG_ACTIVE then
				v193.vehicleCharacter:setCharacterVisibility(true)
			end
		end
	end
end
function EnterablePassenger.consoleCommandDebugPassengerSeat()
	EnterablePassenger.DEBUG_ACTIVE = not EnterablePassenger.DEBUG_ACTIVE
	local v194 = g_localPlayer:getCurrentVehicle()
	if v194 ~= nil and v194.spec_enterablePassenger ~= nil then
		if EnterablePassenger.DEBUG_ACTIVE then
			for v195 = 1, #v194.spec_enterablePassenger.passengerSeats do
				v194:setPassengerSeatCharacter(v195, v194:getUserPlayerStyle())
			end
		else
			for v196 = 1, #v194.spec_enterablePassenger.passengerSeats do
				v194:setPassengerSeatCharacter(v196, nil)
			end
		end
	end
	local v197 = Logging.info
	local v198 = EnterablePassenger.DEBUG_ACTIVE
	v197("Passenger Seat Debug: %s", (tostring(v198)))
end
addConsoleCommand("gsVehicleDebugPassengerSeats", "Enables debugging for passenger seat character targets", "consoleCommandDebugPassengerSeat", EnterablePassenger)

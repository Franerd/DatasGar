Roller = {}
Roller.AI_REQUIRED_GROUND_TYPES = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.CULTIVATED,
	FieldGroundType.SEEDBED,
	FieldGroundType.PLOWED,
	FieldGroundType.RIDGE,
	FieldGroundType.SOWN,
	FieldGroundType.DIRECT_SOWN,
	FieldGroundType.PLANTED,
	FieldGroundType.RIDGE_SOWN,
	FieldGroundType.CULTIVATED
}
Roller.AI_REQUIRED_GROUND_TYPES_GRASS = { FieldGroundType.GRASS, FieldGroundType.GRASS_CUT }
function Roller.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("roller", g_i18n:getText("configuration_design"), "roller", VehicleConfigurationItem)
	g_workAreaTypeManager:addWorkAreaType("roller", false, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Roller")
	Roller.registerRollerXMLPaths(v1, "vehicle.roller")
	Roller.registerRollerXMLPaths(v1, "vehicle.roller.rollerConfigurations.rollerConfiguration(?).roller")
	v1:setXMLSpecializationType()
end
function Roller.registerRollerXMLPaths(p2, p3)
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".directionNode#node", "Roller direction node")
	p2:register(XMLValueType.BOOL, p3 .. "#onlyActiveWhenLowered", "Only active when lowered", true)
	p2:register(XMLValueType.BOOL, p3 .. "#isSoilRoller", "If roller is for soil", true)
	p2:register(XMLValueType.BOOL, p3 .. "#isGrassRoller", "If roller is for grassland", false)
	p2:register(XMLValueType.BOOL, p3 .. "#usingAIRequirements", "Tool using roller ai requirements", true)
	SoundManager.registerSampleXMLPaths(p2, p3 .. ".sounds", "work")
end
function Roller.prerequisitesPresent(p4)
	return SpecializationUtil.hasSpecialization(WorkArea, p4)
end
function Roller.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "processRollerArea", Roller.processRollerArea)
	SpecializationUtil.registerFunction(p5, "updateRollerAIRequirements", Roller.updateRollerAIRequirements)
end
function Roller.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "doCheckSpeedLimit", Roller.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDoGroundManipulation", Roller.getDoGroundManipulation)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDirtMultiplier", Roller.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getWearMultiplier", Roller.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsWorkAreaActive", Roller.getIsWorkAreaActive)
end
function Roller.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", Roller)
	SpecializationUtil.registerEventListener(p7, "onDelete", Roller)
	SpecializationUtil.registerEventListener(p7, "onPostAttach", Roller)
	SpecializationUtil.registerEventListener(p7, "onDeactivate", Roller)
	SpecializationUtil.registerEventListener(p7, "onStartWorkAreaProcessing", Roller)
	SpecializationUtil.registerEventListener(p7, "onEndWorkAreaProcessing", Roller)
end
function Roller.onLoad(p8, _)
	local v9 = p8.spec_roller
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.rollerSound", "vehicle.roller.sounds.work")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.onlyActiveWhenLowered#value", "vehicle.roller#onlyActiveWhenLowered")
	local v10 = Utils.getNoNil(p8.configurations.roller, 1)
	local v11 = string.format("vehicle.roller.rollerConfigurations.rollerConfiguration(%d).roller", v10 - 1)
	local v12 = not p8.xmlFile:hasProperty(v11) and "vehicle.roller" or v11
	v9.directionNode = p8.xmlFile:getValue(v12 .. ".directionNode#node", p8.components[1].node, p8.components, p8.i3dMappings)
	if p8.isClient then
		v9.samples = {}
		v9.isWorkSamplePlaying = false
		v9.samples.work = g_soundManager:loadSampleFromXML(p8.xmlFile, v12 .. ".sounds", "work", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
	end
	v9.isSoilRoller = p8.xmlFile:getValue(v12 .. "#isSoilRoller")
	v9.isGrassRoller = p8.xmlFile:getValue(v12 .. "#isGrassRoller")
	if v9.isSoilRoller == nil and v9.isGrassRoller == nil then
		v9.isSoilRoller = true
		v9.isGrassRoller = false
	else
		if v9.isGrassRoller == nil then
			v9.isGrassRoller = false
		end
		if v9.isSoilRoller == nil then
			v9.isSoilRoller = false
		end
	end
	v9.grassFruitTypes = { FruitType.GRASS, FruitType.MEADOW }
	v9.usingAIRequirements = p8.xmlFile:getValue(v12 .. "#usingAIRequirements", true)
	v9.onlyActiveWhenLowered = p8.xmlFile:getValue(v12 .. "#onlyActiveWhenLowered", true)
	v9.startActivationTimeout = 2000
	v9.startActivationTime = 0
	v9.isWorking = false
	v9.angle = 0
	p8:updateRollerAIRequirements()
	v9.dirtyFlag = p8:getNextDirtyFlag()
end
function Roller.onDelete(p13)
	local v14 = p13.spec_roller
	g_soundManager:deleteSamples(v14.samples)
end
function Roller.processRollerArea(p15, p16, _)
	local v17 = p15.spec_roller
	local v18, _, v19 = getWorldTranslation(p16.start)
	local v20, _, v21 = getWorldTranslation(p16.width)
	local v22, _, v23 = getWorldTranslation(p16.height)
	local v24
	if v17.isGrassRoller then
		local v25
		v24, v25 = FSDensityMapUtil.updateGrassRollerArea(v18, v19, v20, v21, v22, v23, not v17.isSoilRoller)
	else
		v24 = nil
	end
	if v17.isSoilRoller then
		local v26
		v24, v26 = FSDensityMapUtil.updateRollerArea(v18, v19, v20, v21, v22, v23, v17.angle)
	end
	FSDensityMapUtil.eraseTireTrack(v18, v19, v20, v21, v22, v23)
	v17.isWorking = p15:getLastSpeed() > 0.5
	return v24
end
function Roller.updateRollerAIRequirements(p27)
	if p27.clearAITerrainDetailRequiredRange ~= nil then
		local v28 = p27.spec_roller
		if not v28.usingAIRequirements then
			return
		end
		local v29 = SpecializationUtil.hasSpecialization(SowingMachine, p27.specializations) and p27:getUseSowingMachineAIRequirements() and true or false
		p27:clearAIFruitRequirements()
		p27:clearAIFruitProhibitions()
		p27:clearAITerrainDetailRequiredRange()
		if not v29 then
			if v28.isGrassRoller and not v28.isSoilRoller then
				p27:addAIGroundTypeRequirements(Roller.AI_REQUIRED_GROUND_TYPES_GRASS)
				for v30 = 1, #v28.grassFruitTypes do
					local v31 = g_fruitTypeManager:getFruitTypeByIndex(v28.grassFruitTypes[v30])
					if v31.terrainDataPlaneId ~= nil then
						p27:addAIFruitRequirement(v31.index, 2, v31.cutState + 1)
					end
				end
			end
			if v28.isSoilRoller then
				p27:addAIGroundTypeRequirements(Roller.AI_REQUIRED_GROUND_TYPES)
				for v32, v33 in pairs(g_fruitTypeManager:getFruitTypes()) do
					if v33.terrainDataPlaneId ~= nil and (not v28.isGrassRoller or v32 ~= FruitType.GRASS) then
						p27:addAIFruitProhibitions(v33.index, 2, 15)
					end
				end
				if v28.isGrassRoller then
					p27:addAIGroundTypeRequirements(Roller.AI_REQUIRED_GROUND_TYPES_GRASS)
					for v34 = 1, #v28.grassFruitTypes do
						local v35 = g_fruitTypeManager:getFruitTypeByIndex(v28.grassFruitTypes[v34])
						if v35.terrainDataPlaneId ~= nil then
							p27:addAIFruitProhibitions(v35.index, 1, 1)
						end
					end
				end
			end
		end
	end
end
function Roller.doCheckSpeedLimit(p36, p37)
	local v38 = p36.spec_roller
	return p37(p36) or v38.isWorking
end
function Roller.getDoGroundManipulation(p39, p40)
	local v41 = p39.spec_roller
	local v42 = p40(p39)
	if v42 then
		v42 = v41.isWorking
	end
	return v42
end
function Roller.getDirtMultiplier(p43, p44)
	local v45 = p43.spec_roller
	local v46 = p44(p43)
	if v45.isWorking then
		v46 = v46 + p43:getWorkDirtMultiplier()
	end
	return v46
end
function Roller.getWearMultiplier(p47, p48)
	local v49 = p47.spec_roller
	local v50 = p48(p47)
	if v49.isWorking then
		v50 = v50 + p47:getWorkWearMultiplier()
	end
	return v50
end
function Roller.getIsWorkAreaActive(p51, p52, p53)
	if p53.type == WorkAreaType.ROLLER then
		local v54 = p51.spec_roller
		if v54.startActivationTime > g_currentMission.time then
			return false
		end
		if v54.onlyActiveWhenLowered and not p51:getIsLowered() then
			return false
		end
	end
	return p52(p51, p53)
end
function Roller.onStartWorkAreaProcessing(p55, _)
	local v56 = p55.spec_roller
	local v57, _, v58 = localDirectionToWorld(v56.directionNode, 0, 0, 1)
	v56.angle = FSDensityMapUtil.convertToDensityMapAngle(MathUtil.getYRotationFromDirection(v57, v58), g_currentMission.fieldGroundSystem:getGroundAngleMaxValue())
	v56.isWorking = false
end
function Roller.onEndWorkAreaProcessing(p59, _, _)
	local v60 = p59.spec_roller
	if p59.isClient then
		if v60.isWorking then
			if not v60.isWorkSamplePlaying then
				g_soundManager:playSample(v60.samples.work)
				v60.isWorkSamplePlaying = true
				return
			end
		elseif v60.isWorkSamplePlaying then
			g_soundManager:stopSample(v60.samples.work)
			v60.isWorkSamplePlaying = false
		end
	end
end
function Roller.onPostAttach(p61, _, _, _)
	local v62 = p61.spec_roller
	v62.startActivationTime = g_currentMission.time + v62.startActivationTimeout
end
function Roller.onDeactivate(p63)
	local v64 = p63.spec_roller
	g_soundManager:stopSample(v64.samples.work)
	v64.isWorkSamplePlaying = false
end
function Roller.getDefaultSpeedLimit()
	return 15
end

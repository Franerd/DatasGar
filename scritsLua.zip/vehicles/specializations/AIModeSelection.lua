AIModeSelection = {}
AIModeSelection.MODE = {}
AIModeSelection.MODE.WORKER = 1
AIModeSelection.MODE.STEERING_ASSIST = 2
Enum(AIModeSelection.MODE)
AIModeSelection.NUM_MODES = 2
AIModeSelection.NUM_BITS = 1
AIModeSelection.MODE_CHANGE_DURATION = 1000
AIModeSelection.MODE_TEXTS = {}
AIModeSelection.MODE_TEXTS[AIModeSelection.MODE.WORKER] = "ai_modeWorker"
AIModeSelection.MODE_TEXTS[AIModeSelection.MODE.STEERING_ASSIST] = "ai_modeSteeringAssist"
source("dataS/scripts/vehicles/specializations/events/AISetModeEvent.lua")
source("dataS/scripts/vehicles/specializations/events/AIModeSelectionSettingsEvent.lua")
source("dataS/scripts/vehicles/ai/settings/AIUserSettings.lua")
source("dataS/scripts/gui/hud/extensions/AIModeHUDExtension.lua")
function AIModeSelection.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AIDrivable, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AIAutomaticSteering, p1)
	end
	return v2
end
function AIModeSelection.initSpecialization()
	local v3 = Vehicle.xmlSchemaSavegame
	v3:register(XMLValueType.STRING, "vehicles.vehicle(?).aiModeSelection#currentMode", "Currently selected AI mode")
	AIUserSettings.registerXMLPaths(v3, "vehicles.vehicle(?).aiModeSelection.settings")
end
function AIModeSelection.registerEvents(p4)
	SpecializationUtil.registerEvent(p4, "onAIModeChanged")
	SpecializationUtil.registerEvent(p4, "onAIModeSettingsChanged")
end
function AIModeSelection.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "setAIModeSelection", AIModeSelection.setAIModeSelection)
	SpecializationUtil.registerFunction(p5, "getAIModeSelection", AIModeSelection.getAIModeSelection)
	SpecializationUtil.registerFunction(p5, "aiModeSettingsChanged", AIModeSelection.aiModeSettingsChanged)
	SpecializationUtil.registerFunction(p5, "initializeLoadedAIModeUserSettings", AIModeSelection.initializeLoadedAIModeUserSettings)
	SpecializationUtil.registerFunction(p5, "getAIModeFieldCourseSettings", AIModeSelection.getAIModeFieldCourseSettings)
	SpecializationUtil.registerFunction(p5, "setAIModeFieldCourseSettings", AIModeSelection.setAIModeFieldCourseSettings)
	SpecializationUtil.registerFunction(p5, "applyReadAIModeSettingsFromStream", AIModeSelection.applyReadAIModeSettingsFromStream)
	SpecializationUtil.registerFunction(p5, "writeAIModeSettingsToStream", AIModeSelection.writeAIModeSettingsToStream)
end
function AIModeSelection.registerOverwrittenFunctions(_) end
function AIModeSelection.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", AIModeSelection)
	SpecializationUtil.registerEventListener(p6, "onDelete", AIModeSelection)
	SpecializationUtil.registerEventListener(p6, "onReadStream", AIModeSelection)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", AIModeSelection)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", AIModeSelection)
	SpecializationUtil.registerEventListener(p6, "onDraw", AIModeSelection)
	SpecializationUtil.registerEventListener(p6, "onStateChange", AIModeSelection)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", AIModeSelection)
end
function AIModeSelection.onLoad(p7, p8)
	local v9 = p7.spec_aiModeSelection
	v9.currentMode = AIModeSelection.MODE.WORKER
	v9.modeChangeStartTime = 0
	v9.lastModeChangeTime = (-1 / 0)
	v9.hudExtension = AIModeHUDExtension.new(p7)
	v9.texts = {}
	v9.texts.modeSelect = g_i18n:getText("ai_modeSelect")
	if p8 ~= nil and not p8.resetVehicles then
		local v10 = p8.xmlFile:getValue(p8.key .. ".aiModeSelection#currentMode")
		if v10 ~= nil then
			v9.currentMode = AIModeSelection.MODE[string.upper(v10)] or v9.currentMode
		end
		if p8.xmlFile:hasProperty(p8.key .. ".aiModeSelection.settings") then
			v9.loadedUserSettings = AIUserSettings.new()
			v9.loadedUserSettings:loadFromXML(p8.xmlFile, p8.key .. ".aiModeSelection.settings")
		end
	end
end
function AIModeSelection.onDelete(p11)
	local v12 = p11.spec_aiModeSelection
	if v12.hudExtension ~= nil then
		v12.hudExtension:delete()
	end
end
function AIModeSelection.saveToXMLFile(p13, p14, p15, _)
	local v16 = p13.spec_aiModeSelection
	p14:setValue(p15 .. "#currentMode", AIModeSelection.MODE.getName(v16.currentMode))
	if v16.userSettings ~= nil then
		v16.userSettings:saveToXML(p14, p15 .. ".settings")
	end
end
function AIModeSelection.onReadStream(p17, p18, p19)
	local v20 = p17.spec_aiModeSelection
	v20.currentMode = streamReadUIntN(p18, AIModeSelection.NUM_BITS) + 1
	if streamReadBool(p18) then
		v20.receivedFieldCourseAttributes = FieldCourseSettings.readStream(p18, p19)
	end
end
function AIModeSelection.onWriteStream(p21, p22, p23)
	local v24 = p21.spec_aiModeSelection
	streamWriteUIntN(p22, v24.currentMode - 1, AIModeSelection.NUM_BITS)
	if streamWriteBool(p22, v24.fieldCourseSettings ~= nil) then
		v24.fieldCourseSettings:writeStream(p22, p23)
	end
end
function AIModeSelection.onUpdateTick(p25, _, _, _, _)
	if p25.isClient then
		AIModeSelection.updateActionEvents(p25)
	end
	if not g_currentMission.vehicleSystem.isReloadRunning then
		local v26 = p25.spec_aiModeSelection
		if v26.loadedUserSettings ~= nil then
			p25:initializeLoadedAIModeUserSettings()
		end
		if v26.receivedFieldCourseAttributes ~= nil then
			v26.fieldCourseSettings = FieldCourseSettings.generate(p25)
			v26.userSettings = AIUserSettings.new(v26.fieldCourseSettings)
			v26.fieldCourseSettings:applyAttributes(v26.receivedFieldCourseAttributes)
			v26.receivedFieldCourseAttributes = nil
			v26.userSettings:reinitialize(v26.fieldCourseSettings, false)
			v26.userSettings:apply(v26.fieldCourseSettings, v26.currentMode)
		end
	end
end
function AIModeSelection.onDraw(p27, _, p28, _)
	if p28 then
		local v29 = p27.spec_aiModeSelection
		if v29.hudExtension ~= nil then
			g_currentMission.hud:addHelpExtension(v29.hudExtension)
		end
	end
end
function AIModeSelection.onStateChange(p30, p31, _)
	if (p31 == VehicleStateChange.ATTACH or p31 == VehicleStateChange.DETACH) and not g_currentMission.vehicleSystem.isReloadRunning then
		local v32 = p30.spec_aiModeSelection
		v32.fieldCourseSettings = nil
		v32.userSettings = nil
	end
end
function AIModeSelection.onRegisterActionEvents(p33, _, _)
	if p33.isClient then
		local v34 = p33.spec_aiModeSelection
		p33:clearActionEventsTable(v34.actionEvents)
		if p33:getIsActiveForInput(true, true) then
			local _, v35 = p33:addActionEvent(v34.actionEvents, InputAction.TOGGLE_AI, p33, AIModeSelection.actionEventToggleAIState, true, true, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v35, GS_PRIO_HIGH)
			AIModeSelection.updateActionEvents(p33)
		end
	end
end
function AIModeSelection.actionEventToggleAIState(p36, _, p37, _, _, _, _, _, p38)
	local v39 = p36.spec_aiModeSelection
	if p37 == 1 then
		if v39.modeChangeStartTime == 0 then
			v39.modeChangeStartTime = g_time
		end
		if v39.modeChangeStartTime + AIModeSelection.MODE_CHANGE_DURATION < g_time then
			local v40, v41, _ = FieldCourse.findClosestField(nil, nil, nil, nil, p36.rootVehicle:getActiveFarm(), p36.rootVehicle, nil)
			if v39.fieldCourseSettings == nil then
				local v42, _ = FieldCourseSettings.generate(p36.rootVehicle)
				v39.fieldCourseSettings = v42
				if v39.userSettings ~= nil then
					v39.userSettings:reinitialize(v39.fieldCourseSettings, true)
				end
			end
			if v39.userSettings == nil then
				v39.userSettings = AIUserSettings.new(v39.fieldCourseSettings)
			end
			AISettingsDialog.show(v39.userSettings, v39.fieldCourseSettings, p36, v39.currentMode, v40, v41, p36.aiModeSettingsChanged, p36)
			v39.modeChangeStartTime = 0
			return
		end
	elseif v39.modeChangeStartTime ~= 0 then
		v39.modeChangeStartTime = 0
		if not p38 then
			if v39.currentMode == AIModeSelection.MODE.WORKER then
				if g_currentMission:getHasPlayerPermission("hireAssistant") then
					p36:toggleAIVehicle()
				else
					g_currentMission:showBlinkingWarning(g_i18n:getText("ai_startStateNoPermission"), 2000)
				end
			end
			if v39.currentMode == AIModeSelection.MODE.STEERING_ASSIST then
				local v43, v44 = p36:getIsAIAutomaticSteeringAllowed()
				if v43 then
					p36:setAIAutomaticSteeringEnabled()
					return
				end
				g_currentMission:showBlinkingWarning(v44, 2000)
			end
		end
	end
end
function AIModeSelection.updateActionEvents(p45)
	local v46 = p45.spec_aiModeSelection
	local v47 = v46.actionEvents[InputAction.TOGGLE_AI]
	if v47 ~= nil and p45.isActiveForInputIgnoreSelectionIgnoreAI then
		g_inputBinding:setActionEventText(v47.actionEventId, string.format(v46.texts.modeSelect, g_i18n:getText(AIModeSelection.MODE_TEXTS[v46.currentMode])))
		g_inputBinding:setActionEventTextPriority(v47.actionEventId, GS_PRIO_HIGH)
		g_inputBinding:setActionEventActive(v47.actionEventId, p45:getCanToggleAIVehicle())
	end
end
function AIModeSelection.setAIModeSelection(p48, p49, p50)
	local v51 = p48.spec_aiModeSelection
	if p49 == nil then
		local v52 = v51.currentMode + 1
		p49 = AIModeSelection.NUM_MODES < v52 and 1 or v52
	end
	v51.lastModeChangeTime = g_time
	if p49 ~= v51.currentMode then
		v51.currentMode = p49
		SpecializationUtil.raiseEvent(p48, "onAIModeChanged", p49)
		AIModeSelection.updateActionEvents(p48)
		AISetModeEvent.sendEvent(p48, p49, p50)
	end
end
function AIModeSelection.getAIModeSelection(p53)
	return p53.spec_aiModeSelection.currentMode
end
function AIModeSelection.aiModeSettingsChanged(p54, p55)
	local v56 = p54.spec_aiModeSelection
	AIModeSelectionSettingsEvent.sendEvent(p54, v56.fieldCourseSettings, false)
	p54:setAIModeSelection(p55)
	SpecializationUtil.raiseEvent(p54, "onAIModeSettingsChanged", p55)
end
function AIModeSelection.initializeLoadedAIModeUserSettings(p57)
	local v58 = p57.spec_aiModeSelection
	if v58.loadedUserSettings ~= nil then
		if v58.fieldCourseSettings == nil then
			local v59, _ = FieldCourseSettings.generate(p57.rootVehicle)
			v58.fieldCourseSettings = v59
		end
		v58.userSettings = v58.loadedUserSettings
		v58.loadedUserSettings = nil
		v58.userSettings:reinitialize(v58.fieldCourseSettings, true)
		v58.userSettings:apply(v58.fieldCourseSettings, v58.currentMode)
	end
end
function AIModeSelection.getAIModeFieldCourseSettings(p60)
	return p60.spec_aiModeSelection.fieldCourseSettings
end
function AIModeSelection.setAIModeFieldCourseSettings(p61, p62)
	local v63 = p61.spec_aiModeSelection
	v63.fieldCourseSettings = p62
	if v63.userSettings == nil then
		local v64, _ = FieldCourseSettings.generate(p61.rootVehicle)
		v63.userSettings = AIUserSettings.new(v64)
	end
	v63.userSettings:reinitialize(v63.fieldCourseSettings, false)
	v63.userSettings:apply(v63.fieldCourseSettings, v63.currentMode)
	SpecializationUtil.raiseEvent(p61, "onAIModeSettingsChanged", v63.currentMode)
end
function AIModeSelection.readAIModeSettingsFromStream(p65, p66)
	if streamReadBool(p65) then
		return {
			["attributes"] = FieldCourseSettings.readStream(p65, p66)
		}
	end
end
function AIModeSelection.applyReadAIModeSettingsFromStream(p67, p68)
	local v69 = p67.spec_aiModeSelection
	if p68 ~= nil then
		v69.fieldCourseSettings = FieldCourseSettings.generate(p67)
		v69.fieldCourseSettings:applyAttributes(p68.attributes)
		v69.loadedUserSettings = nil
	end
end
function AIModeSelection.writeAIModeSettingsToStream(p70, p71, p72)
	p70:initializeLoadedAIModeUserSettings()
	local v73 = p70.spec_aiModeSelection
	if streamWriteBool(p71, v73.fieldCourseSettings ~= nil) then
		v73.fieldCourseSettings:writeStream(p71, p72)
	end
end

AutomaticArmControlHarvester = {}
AutomaticArmControlHarvester.STATE_NONE = 0
AutomaticArmControlHarvester.STATE_MOVE_BACK = 1
AutomaticArmControlHarvester.STATE_ALIGN_X = 2
AutomaticArmControlHarvester.STATE_ALIGN_Z = 3
AutomaticArmControlHarvester.STATE_FINISHED = 4
local v1 = AutomaticArmControlHarvester
local v2 = {
	[1] = {
		[AutomaticArmControlHarvester.STATE_NONE] = AutomaticArmControlHarvester.STATE_MOVE_BACK,
		[AutomaticArmControlHarvester.STATE_MOVE_BACK] = AutomaticArmControlHarvester.STATE_ALIGN_X,
		[AutomaticArmControlHarvester.STATE_ALIGN_X] = AutomaticArmControlHarvester.STATE_ALIGN_Z,
		[AutomaticArmControlHarvester.STATE_ALIGN_Z] = AutomaticArmControlHarvester.STATE_FINISHED
	},
	[-1] = {
		[AutomaticArmControlHarvester.STATE_NONE] = AutomaticArmControlHarvester.STATE_ALIGN_Z,
		[AutomaticArmControlHarvester.STATE_ALIGN_Z] = AutomaticArmControlHarvester.STATE_ALIGN_X,
		[AutomaticArmControlHarvester.STATE_ALIGN_X] = AutomaticArmControlHarvester.STATE_FINISHED
	}
}
v1.NEXT_STATE = v2
AutomaticArmControlHarvester.INVALID_REASON_NONE = 0
AutomaticArmControlHarvester.INVALID_REASON_NO_ACCESS = 1
AutomaticArmControlHarvester.INVALID_REASON_TOO_THICK = 2
AutomaticArmControlHarvester.INVALID_REASON_WRONG_TYPE = 3
function AutomaticArmControlHarvester.prerequisitesPresent(p3)
	return SpecializationUtil.hasSpecialization(Cylindered, p3)
end
function AutomaticArmControlHarvester.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("automaticArmControlHarvester", g_i18n:getText("shop_configuration"), "automaticArmControlHarvester", VehicleConfigurationItem)
	local v4 = Vehicle.xmlSchema
	v4:setXMLSpecializationType("AutomaticArmControlHarvester")
	AutomaticArmControlHarvester.registerXMLPaths(v4, "vehicle.automaticArmControlHarvester")
	AutomaticArmControlHarvester.registerXMLPaths(v4, "vehicle.automaticArmControlHarvester.automaticArmControlHarvesterConfigurations.automaticArmControlHarvesterConfiguration(?)")
	v4:setXMLSpecializationType()
end
function AutomaticArmControlHarvester.registerXMLPaths(p5, p6)
	p5:register(XMLValueType.BOOL, p6 .. "#requiresEasyArmControl", "If \'true\' then it is only available if easy arm control is enabled", true)
	p5:register(XMLValueType.FLOAT, p6 .. "#foldMinLimit", "Min. folding time to activate the automatic control", 0)
	p5:register(XMLValueType.FLOAT, p6 .. "#foldMaxLimit", "Max. folding time to activate the automatic control", 1)
	p5:register(XMLValueType.NODE_INDEX, p6 .. "#returnPositionNode", "This node is used as target if no tree to align has been found (only for platforms with automatic vehicle control)")
	p5:register(XMLValueType.NODE_INDEX, p6 .. ".treeDetectionNode#node", "Tree detection node")
	p5:register(XMLValueType.FLOAT, p6 .. ".treeDetectionNode#minRadius", "Min. distance to tree", 5)
	p5:register(XMLValueType.FLOAT, p6 .. ".treeDetectionNode#maxRadius", "Max. distance to tree", 10)
	p5:register(XMLValueType.ANGLE, p6 .. ".treeDetectionNode#maxAngle", "Max. angle to the target tree", 45)
	p5:register(XMLValueType.FLOAT, p6 .. ".treeDetectionNode#cutHeight", "Tree cur height measured from terrain height", 0.4)
	p5:register(XMLValueType.NODE_INDEX, p6 .. ".xAlignment#movingToolNode", "Moving tool to do alignment on X axis (most likely Y-Rot tool)")
	p5:register(XMLValueType.FLOAT, p6 .. ".xAlignment#speedScale", "Speed scale used to control the moving tool", 1)
	p5:register(XMLValueType.FLOAT, p6 .. ".xAlignment#offset", "X alignment offset from tree detection node", "Automatically calculated with the difference on X between xAlignment and zAlignment node")
	p5:register(XMLValueType.ANGLE, p6 .. ".xAlignment#threshold", "X alignment angle threshold (if angle to target is below this value the Y and Z alignment will start)", 1)
	p5:register(XMLValueType.NODE_INDEX, p6 .. ".zAlignment#movingToolNode", "Moving tool to do alignment on Z axis (EasyArmControl Z Target)")
	p5:register(XMLValueType.FLOAT, p6 .. ".zAlignment#speedScale", "Speed scale used to control the moving tool", 1)
	p5:register(XMLValueType.FLOAT, p6 .. ".zAlignment#moveBackDistance", "Distance the arm is moved back behind the tree first to start the x alignment", 2)
	p5:register(XMLValueType.NODE_INDEX, p6 .. ".zAlignment#referenceNode", "Reference node which is tried to be moved right in front of the tree")
	p5:register(XMLValueType.NODE_INDEX, p6 .. ".yAlignment#movingToolNode", "Moving tool to do alignment on Y axis (EasyArmControl Y Target)")
	p5:register(XMLValueType.FLOAT, p6 .. ".yAlignment#speedScale", "Speed scale used to control the moving tool", 1)
	p5:register(XMLValueType.NODE_INDEX, p6 .. ".yAlignment#referenceNode", "Reference node which is tried to be moved right in front of the tree")
	p5:register(XMLValueType.NODE_INDEX, p6 .. ".alignmentNode(?)#movingToolNode", "MovingTool node which is aligned according to attributes")
	p5:register(XMLValueType.ANGLE, p6 .. ".alignmentNode(?)#rotation", "Target rotation")
	p5:register(XMLValueType.FLOAT, p6 .. ".alignmentNode(?)#translation", "Target translation")
	p5:register(XMLValueType.FLOAT, p6 .. ".alignmentNode(?)#speedScale", "Speed scale used to reach the target rotation/translation", 1)
	p5:register(XMLValueType.BOOL, p6 .. ".alignmentNode(?)#isPrerequisite", "Defines if this moving tool is first brought into the target position before the real alignment starts", false)
	TargetTreeMarker.registerXMLPaths(p5, p6 .. ".treeMarker")
	p5:register(XMLValueType.COLOR, p6 .. ".treeMarker#targetColor", "Color if tree is available to alignment, but not ready for cut yet", "2 2 0")
	p5:register(XMLValueType.COLOR, p6 .. ".treeMarker#tooThickColor", "Color if tree is too thick to be cut", "2 0 0")
	p5:register(XMLValueType.FLOAT, p6 .. ".treeMarker#treeOffset", "Offset from tree to marker", 0.025)
end
function AutomaticArmControlHarvester.registerFunctions(p7)
	SpecializationUtil.registerFunction(p7, "getSupportsAutoTreeAlignment", AutomaticArmControlHarvester.getSupportsAutoTreeAlignment)
	SpecializationUtil.registerFunction(p7, "getIsAutoTreeAlignmentAllowed", AutomaticArmControlHarvester.getIsAutoTreeAlignmentAllowed)
	SpecializationUtil.registerFunction(p7, "getAutoAlignHasValidTree", AutomaticArmControlHarvester.getAutoAlignHasValidTree)
	SpecializationUtil.registerFunction(p7, "getAutoAlignTreeMarkerState", AutomaticArmControlHarvester.getAutoAlignTreeMarkerState)
	SpecializationUtil.registerFunction(p7, "setTreeArmAlignmentInput", AutomaticArmControlHarvester.setTreeArmAlignmentInput)
	SpecializationUtil.registerFunction(p7, "doTreeArmAlignment", AutomaticArmControlHarvester.doTreeArmAlignment)
	SpecializationUtil.registerFunction(p7, "getIsAutomaticAlignmentActive", AutomaticArmControlHarvester.getIsAutomaticAlignmentActive)
	SpecializationUtil.registerFunction(p7, "getAutomaticAlignmentCurrentTarget", AutomaticArmControlHarvester.getAutomaticAlignmentCurrentTarget)
	SpecializationUtil.registerFunction(p7, "getAutomaticAlignmentInvalidTreeReason", AutomaticArmControlHarvester.getAutomaticAlignmentInvalidTreeReason)
	SpecializationUtil.registerFunction(p7, "getBestTreeToAutoAlign", AutomaticArmControlHarvester.getBestTreeToAutoAlign)
	SpecializationUtil.registerFunction(p7, "onTreeAutoOverlapCallback", AutomaticArmControlHarvester.onTreeAutoOverlapCallback)
	SpecializationUtil.registerFunction(p7, "getTreeAutomaticOverwrites", AutomaticArmControlHarvester.getTreeAutomaticOverwrites)
end
function AutomaticArmControlHarvester.registerOverwrittenFunctions(_) end
function AutomaticArmControlHarvester.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", AutomaticArmControlHarvester)
	SpecializationUtil.registerEventListener(p8, "onPostLoad", AutomaticArmControlHarvester)
	SpecializationUtil.registerEventListener(p8, "onDelete", AutomaticArmControlHarvester)
	SpecializationUtil.registerEventListener(p8, "onReadUpdateStream", AutomaticArmControlHarvester)
	SpecializationUtil.registerEventListener(p8, "onWriteUpdateStream", AutomaticArmControlHarvester)
	SpecializationUtil.registerEventListener(p8, "onUpdate", AutomaticArmControlHarvester)
	SpecializationUtil.registerEventListener(p8, "onRegisterActionEvents", AutomaticArmControlHarvester)
	SpecializationUtil.registerEventListener(p8, "onRootVehicleChanged", AutomaticArmControlHarvester)
end
function AutomaticArmControlHarvester.onLoad(p_u_9, _)
	local v_u_10 = p_u_9.spec_automaticArmControlHarvester
	local v11 = Utils.getNoNil(p_u_9.configurations.automaticArmControlHarvester, 1)
	local v12 = string.format("vehicle.automaticArmControlHarvester.automaticArmControlHarvesterConfigurations.automaticArmControlHarvesterConfiguration(%d)", v11 - 1)
	local v13 = not p_u_9.xmlFile:hasProperty(v12) and "vehicle.automaticArmControlHarvester" or v12
	v_u_10.alignmentNodes = {}
	p_u_9.xmlFile:iterate(v13 .. ".alignmentNode", function(_, p14)
		-- upvalues: (copy) p_u_9, (copy) v_u_10
		local v15 = {
			["movingToolNode"] = p_u_9.xmlFile:getValue(p14 .. "#movingToolNode", nil, p_u_9.components, p_u_9.i3dMappings),
			["rotation"] = p_u_9.xmlFile:getValue(p14 .. "#rotation"),
			["translation"] = p_u_9.xmlFile:getValue(p14 .. "#translation")
		}
		if v15.movingToolNode ~= nil and (v15.rotation ~= nil or v15.translation ~= nil) then
			v15.speedScale = p_u_9.xmlFile:getValue(p14 .. "#speedScale", 1)
			v15.isPrerequisite = p_u_9.xmlFile:getValue(p14 .. "#isPrerequisite", false)
			local v16 = v_u_10.alignmentNodes
			table.insert(v16, v15)
		end
	end)
	v_u_10.xAlignment = {}
	v_u_10.zAlignment = {}
	v_u_10.yAlignment = {}
	v_u_10.treeDetectionNode = p_u_9.xmlFile:getValue(v13 .. ".treeDetectionNode#node", nil, p_u_9.components, p_u_9.i3dMappings)
	if v_u_10.treeDetectionNode == nil then
		v_u_10.xAlignment.offset = p_u_9.xmlFile:getValue(v13 .. ".xAlignment#offset")
		v_u_10.zAlignment.referenceNode = p_u_9.xmlFile:getValue(v13 .. ".zAlignment#referenceNode", nil, p_u_9.components, p_u_9.i3dMappings)
		v_u_10.yAlignment.referenceNode = p_u_9.xmlFile:getValue(v13 .. ".yAlignment#referenceNode", nil, p_u_9.components, p_u_9.i3dMappings)
		SpecializationUtil.removeEventListener(p_u_9, "onDelete", AutomaticArmControlHarvester)
		SpecializationUtil.removeEventListener(p_u_9, "onUpdate", AutomaticArmControlHarvester)
		SpecializationUtil.removeEventListener(p_u_9, "onRegisterActionEvents", AutomaticArmControlHarvester)
	else
		v_u_10.treeDetectionNodeMinRadius = p_u_9.xmlFile:getValue(v13 .. ".treeDetectionNode#minRadius", 5)
		v_u_10.treeDetectionNodeMaxRadius = p_u_9.xmlFile:getValue(v13 .. ".treeDetectionNode#maxRadius", 10)
		v_u_10.treeDetectionNodeMaxAngle = p_u_9.xmlFile:getValue(v13 .. ".treeDetectionNode#maxAngle", 45)
		v_u_10.treeDetectionNodeCutHeight = p_u_9.xmlFile:getValue(v13 .. ".treeDetectionNode#cutHeight", 0.4)
		v_u_10.treeDetectionNodeCutHeightSafetyOffset = 0.075
		v_u_10.foundTrees = {}
		v_u_10.foundValidTargetServer = false
		v_u_10.lastFoundValidTarget = false
		v_u_10.lastTargetTrans = { 0, 0, 0 }
		v_u_10.lastRadius = 1
		v_u_10.state = AutomaticArmControlHarvester.STATE_NONE
		v_u_10.xAlignment = {}
		v_u_10.xAlignment.movingToolNode = p_u_9.xmlFile:getValue(v13 .. ".xAlignment#movingToolNode", nil, p_u_9.components, p_u_9.i3dMappings)
		v_u_10.xAlignment.speedScale = p_u_9.xmlFile:getValue(v13 .. ".xAlignment#speedScale", 1)
		v_u_10.xAlignment.offset = p_u_9.xmlFile:getValue(v13 .. ".xAlignment#offset")
		v_u_10.xAlignment.threshold = p_u_9.xmlFile:getValue(v13 .. ".xAlignment#threshold", 1)
		v_u_10.zAlignment = {}
		v_u_10.zAlignment.movingToolNode = p_u_9.xmlFile:getValue(v13 .. ".zAlignment#movingToolNode", nil, p_u_9.components, p_u_9.i3dMappings)
		v_u_10.zAlignment.speedScale = p_u_9.xmlFile:getValue(v13 .. ".zAlignment#speedScale", 1)
		v_u_10.zAlignment.moveBackDistance = p_u_9.xmlFile:getValue(v13 .. ".zAlignment#moveBackDistance", 2)
		v_u_10.zAlignment.referenceNode = p_u_9.xmlFile:getValue(v13 .. ".zAlignment#referenceNode", nil, p_u_9.components, p_u_9.i3dMappings)
		v_u_10.yAlignment = {}
		v_u_10.yAlignment.movingToolNode = p_u_9.xmlFile:getValue(v13 .. ".yAlignment#movingToolNode", nil, p_u_9.components, p_u_9.i3dMappings)
		v_u_10.yAlignment.speedScale = p_u_9.xmlFile:getValue(v13 .. ".yAlignment#speedScale", 1)
		v_u_10.yAlignment.referenceNode = p_u_9.xmlFile:getValue(v13 .. ".yAlignment#referenceNode", nil, p_u_9.components, p_u_9.i3dMappings)
		v_u_10.treeMarker = TargetTreeMarker.new(p_u_9, p_u_9.rootNode)
		v_u_10.treeMarker:loadFromXML(p_u_9.xmlFile, v13 .. ".treeMarker", p_u_9.baseDirectory)
		v_u_10.treeMarker.cutColor = { v_u_10.treeMarker.color[1], v_u_10.treeMarker.color[2], v_u_10.treeMarker.color[3] }
		v_u_10.treeMarker.targetColor = p_u_9.xmlFile:getValue(v13 .. ".treeMarker#targetColor", "2 2 0", true)
		v_u_10.treeMarker.tooThickColor = p_u_9.xmlFile:getValue(v13 .. ".treeMarker#tooThickColor", "2 0 0", true)
		v_u_10.treeMarker.treeOffset = p_u_9.xmlFile:getValue(v13 .. ".treeMarker#treeOffset", 0.025)
		v_u_10.requiresEasyArmControl = p_u_9.xmlFile:getValue(v13 .. "#requiresEasyArmControl", true)
		v_u_10.foldMinLimit = p_u_9.xmlFile:getValue(v13 .. "#foldMinLimit", 0)
		v_u_10.foldMaxLimit = p_u_9.xmlFile:getValue(v13 .. "#foldMaxLimit", 1)
		v_u_10.returnPositionNode = p_u_9.xmlFile:getValue(v13 .. "#returnPositionNode", nil, p_u_9.components, p_u_9.i3dMappings)
		v_u_10.pendingArmReturn = false
		if v_u_10.xAlignment.offset == nil and (v_u_10.yAlignment.referenceNode ~= nil and v_u_10.xAlignment.movingToolNode ~= nil) then
			local v17, _, _ = localToLocal(v_u_10.yAlignment.referenceNode, v_u_10.xAlignment.movingToolNode, 0, 0, 0)
			v_u_10.xAlignment.offset = -v17
		end
		v_u_10.controlInputLastValue = 0
		v_u_10.controlInputTimer = 0
		v_u_10.invalidTreeReason = AutomaticArmControlHarvester.INVALID_REASON_NONE
		v_u_10.dirtyFlag = p_u_9:getNextDirtyFlag()
		if Platform.gameplay.automaticVehicleControl then
			SpecializationUtil.removeEventListener(p_u_9, "onRegisterActionEvents", AutomaticArmControlHarvester)
			return
		end
	end
end
function AutomaticArmControlHarvester.onPostLoad(p18, _)
	local v19 = p18.spec_automaticArmControlHarvester
	if v19.xAlignment.movingToolNode ~= nil then
		v19.xAlignment.movingTool = p18:getMovingToolByNode(v19.xAlignment.movingToolNode)
	end
	if v19.zAlignment.movingToolNode ~= nil then
		v19.zAlignment.movingTool = p18:getMovingToolByNode(v19.zAlignment.movingToolNode)
	end
	if v19.yAlignment.movingToolNode ~= nil then
		v19.yAlignment.movingTool = p18:getMovingToolByNode(v19.yAlignment.movingToolNode)
	end
	for v20 = #v19.alignmentNodes, 1, -1 do
		local v21 = v19.alignmentNodes[v20]
		v21.movingTool = p18:getMovingToolByNode(v21.movingToolNode)
		if v21.movingTool == nil then
			table.remove(v19.alignmentNodes, v20)
		end
	end
end
function AutomaticArmControlHarvester.onDelete(p22)
	local v23 = p22.spec_automaticArmControlHarvester
	if v23.treeMarker ~= nil then
		v23.treeMarker:delete()
	end
end
function AutomaticArmControlHarvester.onReadUpdateStream(p24, p25, _, p26)
	local v27 = p24.spec_automaticArmControlHarvester
	if v27.treeDetectionNode ~= nil then
		if p26:getIsServer() then
			if streamReadBool(p25) then
				v27.foundValidTargetServer = streamReadBool(p25)
			end
		elseif streamReadBool(p25) then
			v27.controlInputLastValue = streamReadBool(p25) and 1 or 0
			v27.controlInputTimer = 250
			return
		end
	end
end
function AutomaticArmControlHarvester.onWriteUpdateStream(p28, p29, p30, p31)
	local v32 = p28.spec_automaticArmControlHarvester
	if v32.treeDetectionNode ~= nil then
		if p30:getIsServer() then
			if streamWriteBool(p29, bitAND(p31, v32.dirtyFlag) ~= 0) then
				streamWriteBool(p29, v32.controlInputLastValue ~= 0)
				return
			end
		elseif streamWriteBool(p29, bitAND(p31, v32.dirtyFlag) ~= 0) then
			streamWriteBool(p29, v32.foundValidTargetServer)
		end
	end
end
function AutomaticArmControlHarvester.onUpdate(p33, p34, _, p35, _)
	local v36 = p33.spec_automaticArmControlHarvester
	v36.invalidTreeReason = AutomaticArmControlHarvester.INVALID_REASON_NONE
	local v37 = false
	local v38 = false
	if p33:getIsAutoTreeAlignmentAllowed() then
		local v39, v40, v41 = p33:getBestTreeToAutoAlign(v36.treeDetectionNode, v36.foundTrees)
		if v39 == nil then
			if v40 ~= nil then
				local v42, v43, v44 = getWorldTranslation(v40)
				local v45 = getTerrainHeightAtWorldPos(g_terrainNode, v42, v43, v44) + v36.treeDetectionNodeCutHeight + v36.treeDetectionNodeCutHeightSafetyOffset
				local v46 = math.max(v43, v45)
				local v47, v48, v49, v50, v51, v52, v53 = SplitShapeUtil.getTreeOffsetPosition(v40, v42, v46, v44, 3)
				if v47 ~= nil then
					v36.treeMarker:setPosition(v47, v48, v49, v50, v51, v52, v53 + v36.treeMarker.treeOffset, 0)
					v36.treeMarker:setColor(v36.treeMarker.tooThickColor[1], v36.treeMarker.tooThickColor[2], v36.treeMarker.tooThickColor[3], false)
					v36.invalidTreeReason = v41
					v38 = true
				end
			end
		else
			local v54, v55, v56 = getWorldTranslation(v39)
			local v57 = getTerrainHeightAtWorldPos(g_terrainNode, v54, v55, v56) + v36.treeDetectionNodeCutHeight + v36.treeDetectionNodeCutHeightSafetyOffset
			local v58 = math.max(v55, v57)
			local v59, v60, v61, v62, v63, v64, v65 = SplitShapeUtil.getTreeOffsetPosition(v39, v54, v58, v56, 3)
			if v59 ~= nil then
				v36.treeMarker:setPosition(v59, v60, v61, v62, v63, v64, v65 + v36.treeMarker.treeOffset, 0)
				local v66, v67 = p33:getAutoAlignTreeMarkerState(v65)
				if v66 then
					v36.treeMarker:setColor(v36.treeMarker.cutColor[1], v36.treeMarker.cutColor[2], v36.treeMarker.cutColor[3], false)
				else
					local v68 = v67 and v36.treeMarker.targetColor or v36.treeMarker.tooThickColor
					if v36.state == AutomaticArmControlHarvester.STATE_NONE then
						v36.treeMarker:setColor(v68[1], v68[2], v68[3], false)
					else
						v36.treeMarker:setColor(v68[1], v68[2], v68[3], true)
					end
				end
				v36.lastRadius = v65
				local v69 = v36.lastTargetTrans
				local v70 = v36.lastTargetTrans
				local v71 = v36.lastTargetTrans
				v69[1] = v59
				v70[2] = v60
				v71[3] = v61
				v37 = true
				v38 = true
			end
		end
		for v72 = #v36.foundTrees, 1, -1 do
			v36.foundTrees[v72] = nil
		end
		if not Platform.gameplay.automaticVehicleControl and v36.state ~= AutomaticArmControlHarvester.STATE_NONE then
			local v73 = v36.foundTrees
			table.insert(v73, v39)
		end
		local v74, v75, v76 = getWorldTranslation(v36.treeDetectionNode)
		overlapSphereAsync(v74, v75, v76, v36.treeDetectionNodeMaxRadius, "onTreeAutoOverlapCallback", p33, CollisionFlag.TREE, false, false, true, false)
	end
	if p33.isClient then
		local v77 = v36.foundValidTargetServer
		if v77 then
			if not v37 then
				p35 = v37
			end
		else
			p35 = v77
		end
		local v78 = v36.treeMarker
		if p35 or v38 then
			v38 = g_woodCuttingMarkerEnabled
		end
		v78:setIsActive(v38)
		AutomaticArmControlHarvester.updateActionEvents(p33, p35)
	end
	if p33.isServer then
		if v37 ~= v36.lastFoundValidTarget then
			v36.foundValidTargetServer = v37
			v36.lastFoundValidTarget = v37
			p33:raiseDirtyFlags(v36.dirtyFlag)
			v36.state = AutomaticArmControlHarvester.STATE_NONE
		end
		if Platform.gameplay.automaticVehicleControl then
			if p33:getIsTurnedOn() then
				if v37 and v36.state ~= AutomaticArmControlHarvester.STATE_FINISHED then
					p33:doTreeArmAlignment(v36.lastTargetTrans[1], v36.lastTargetTrans[2], v36.lastTargetTrans[3], 1)
				end
			elseif v36.pendingArmReturn then
				if v36.returnPositionNode == nil then
					v36.pendingArmReturn = false
				else
					local v79, v80, v81 = getWorldTranslation(v36.returnPositionNode)
					p33:doTreeArmAlignment(v79, v80, v81, -1)
					if v36.state == AutomaticArmControlHarvester.STATE_FINISHED then
						v36.pendingArmReturn = false
					end
				end
			end
		end
		if v36.controlInputTimer > 0 then
			v36.controlInputTimer = v36.controlInputTimer - p34
			if v36.controlInputTimer <= 0 then
				v36.controlInputLastValue = 0
				v36.controlInputTimer = 0
			end
			p33:setTreeArmAlignmentInput(v36.controlInputLastValue)
		end
	end
end
function AutomaticArmControlHarvester.onRegisterActionEvents(p82, _, p83)
	if p82.isClient then
		local v84 = p82.spec_automaticArmControlHarvester
		p82:clearActionEventsTable(v84.actionEvents)
		if p83 then
			local _, v85 = p82:addPoweredActionEvent(v84.actionEvents, InputAction.TREE_AUTOMATIC_ALIGN, p82, AutomaticArmControlHarvester.actionEvent, true, false, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v85, GS_PRIO_VERY_HIGH)
			AutomaticArmControlHarvester.updateActionEvents(p82, false)
		end
	end
end
function AutomaticArmControlHarvester.actionEvent(p86, _, p87, _, _)
	p86:setTreeArmAlignmentInput(p87)
end
function AutomaticArmControlHarvester.updateActionEvents(p88, p89)
	local v90 = p88.spec_automaticArmControlHarvester.actionEvents[InputAction.TREE_AUTOMATIC_ALIGN]
	if v90 ~= nil then
		g_inputBinding:setActionEventActive(v90.actionEventId, p89)
	end
end
function AutomaticArmControlHarvester.onRootVehicleChanged(p91, p92)
	local v_u_93 = p91.spec_automaticArmControlHarvester
	local v94 = p92.actionController
	if v94 == nil then
		if v_u_93.controlledAction ~= nil then
			v_u_93.controlledAction:remove()
			v_u_93.controlledAction = nil
		end
		return
	elseif v_u_93.controlledAction == nil then
		v_u_93.controlledAction = v94:registerAction("automaticArmControlHarvester", nil, 4)
		v_u_93.controlledAction:setCallback(p91, AutomaticArmControlHarvester.actionControllerEvent)
		v_u_93.controlledAction:setFinishedFunctions(p91, function(_)
			-- upvalues: (copy) v_u_93
			return not v_u_93.pendingArmReturn
		end, true, true)
		v_u_93.controlledAction:setActionIcons("WOOD_SAW", "WOOD_SAW", true)
	else
		v_u_93.controlledAction:updateParent(v94)
	end
end
function AutomaticArmControlHarvester.actionControllerEvent(p95, p96)
	local v97 = p95.spec_automaticArmControlHarvester
	if p96 < 0 then
		v97.pendingArmReturn = true
	end
	v97.state = AutomaticArmControlHarvester.STATE_NONE
	return true
end
function AutomaticArmControlHarvester.getSupportsAutoTreeAlignment(_)
	return false
end
function AutomaticArmControlHarvester.getIsAutoTreeAlignmentAllowed(p98)
	local v99 = p98.spec_automaticArmControlHarvester
	if p98.getIsControlled ~= nil and not p98:getIsControlled() then
		return false
	end
	if v99.requiresEasyArmControl and (p98.spec_cylindered.easyArmControl == nil or not p98.spec_cylindered.easyArmControl.state) then
		return false
	end
	if not p98:getSupportsAutoTreeAlignment() then
		local v100 = false
		for v101 = 1, #p98.childVehicles do
			local v102 = p98.childVehicles[v101]
			if v102 ~= p98 and (v102.getSupportsAutoTreeAlignment ~= nil and v102:getSupportsAutoTreeAlignment()) then
				v100 = true
				break
			end
		end
		if not v100 then
			return false
		end
	end
	if p98.getFoldAnimTime ~= nil then
		local v103 = p98:getFoldAnimTime()
		if v103 < v99.foldMinLimit or v99.foldMaxLimit < v103 then
			return false
		end
	end
	return true
end
function AutomaticArmControlHarvester.getAutoAlignHasValidTree(_, _)
	return false, false
end
function AutomaticArmControlHarvester.getAutoAlignTreeMarkerState(p104, p105, p106)
	local v107, v108 = p104:getAutoAlignHasValidTree(p105)
	if v107 then
		return v107, v108
	end
	if p106 ~= false then
		for v109 = 1, #p104.childVehicles do
			local v110 = p104.childVehicles[v109]
			if v110 ~= p104 and v110.getAutoAlignTreeMarkerState ~= nil then
				local v111, v112 = v110:getAutoAlignTreeMarkerState(p105, false)
				if v111 then
					return v111, v112
				end
				v108 = v108 or v112
			end
		end
	end
	return false, v108
end
function AutomaticArmControlHarvester.setTreeArmAlignmentInput(p113, p114)
	local v115 = p113.spec_automaticArmControlHarvester
	if p113.isServer then
		if p114 > 0 and (v115.state ~= AutomaticArmControlHarvester.STATE_FINISHED and v115.foundValidTargetServer) then
			p113:doTreeArmAlignment(v115.lastTargetTrans[1], v115.lastTargetTrans[2], v115.lastTargetTrans[3], 1)
			return
		end
		if p114 == 0 then
			v115.state = AutomaticArmControlHarvester.STATE_NONE
			return
		end
	else
		v115.controlInputLastValue = p114
		if p114 > 0 then
			p113:raiseDirtyFlags(v115.dirtyFlag)
		end
	end
end
function AutomaticArmControlHarvester.doTreeArmAlignment(p116, p117, p118, p119, p120)
	local v121 = p116.spec_automaticArmControlHarvester
	if AutomaticArmControlHarvester.prepareAlignment(p116, p120) then
		if v121.state == AutomaticArmControlHarvester.STATE_NONE then
			v121.state = AutomaticArmControlHarvester.NEXT_STATE[p120][v121.state]
		end
		local v122 = v121.zAlignment.referenceNode
		local v123 = v121.yAlignment.referenceNode
		local v124 = v121.xAlignment.offset or 0
		for v125 = 1, #p116.childVehicles do
			local v126 = p116.childVehicles[v125]
			if v126 ~= p116 and v126.getTreeAutomaticOverwrites ~= nil then
				if not AutomaticArmControlHarvester.prepareAlignment(v126, p120) then
					return
				end
				local v127, v128, v129 = v126:getTreeAutomaticOverwrites()
				v122 = v122 or v127
				v123 = v123 or v128
				if v129 ~= nil then
					v124 = v124 + v129
				end
			end
		end
		if v121.xAlignment.movingTool ~= nil and (v121.state ~= AutomaticArmControlHarvester.STATE_FINISHED and v121.state ~= AutomaticArmControlHarvester.STATE_MOVE_BACK) then
			local v130, _, v131 = worldToLocal(v121.xAlignment.movingTool.node, p117, p118, p119)
			local v132 = MathUtil.vector2Length(v130, v131)
			local v133 = (v130 + (v124 or 0)) / v132
			local v134 = math.atan(v133) * v121.xAlignment.speedScale
			local v135 = v121.xAlignment.movingTool.curRot[v121.xAlignment.movingTool.rotationAxis]
			local v136 = AutomaticArmControlHarvester.calculateMovingToolTargetMove(p116, v121.xAlignment.movingTool, v135 + v134)
			if v136 == 0 then
				if math.abs(v134) < v121.xAlignment.threshold and v121.state == AutomaticArmControlHarvester.STATE_ALIGN_X then
					v121.state = AutomaticArmControlHarvester.NEXT_STATE[p120][v121.state]
				end
			else
				v121.xAlignment.movingTool.externalMove = v136
			end
		end
		if v121.zAlignment.movingTool ~= nil and v122 ~= nil then
			local _, _, v137 = worldToLocal(v121.treeDetectionNode, p117, p118, p119)
			local _, _, v138 = localToLocal(v122, v121.treeDetectionNode, 0, 0, 0)
			local v139 = 0
			if v121.state == AutomaticArmControlHarvester.STATE_MOVE_BACK then
				v139 = v138 - (v137 - v121.lastRadius - v121.zAlignment.moveBackDistance)
				if v139 < v121.zAlignment.moveBackDistance * 0.5 then
					v121.state = AutomaticArmControlHarvester.NEXT_STATE[p120][v121.state]
				end
			elseif v121.state == AutomaticArmControlHarvester.STATE_ALIGN_Z then
				v139 = v138 - (v137 - v121.lastRadius)
				if math.abs(v139) < 0.03 then
					v121.state = AutomaticArmControlHarvester.NEXT_STATE[p120][v121.state]
				end
			end
			if math.abs(v139) > 0.03 then
				v121.zAlignment.movingTool.externalMove = -(v139 + 0.5 * math.sign(v139)) * v121.zAlignment.speedScale
			else
				v121.zAlignment.movingTool.externalMove = 0
			end
		end
		if v121.yAlignment.movingTool ~= nil and (v123 ~= nil and v121.state == AutomaticArmControlHarvester.STATE_ALIGN_Z) then
			local _, v140, _ = getWorldTranslation(v123)
			local v141 = p118 - v121.treeDetectionNodeCutHeightSafetyOffset - v140
			if math.abs(v141) > 0.03 then
				v121.yAlignment.movingTool.externalMove = (v141 + 0.5 * math.sign(v141)) * v121.yAlignment.speedScale
				return
			end
			v121.yAlignment.movingTool.externalMove = 0
		end
	end
end
function AutomaticArmControlHarvester.calculateMovingToolTargetMove(p142, p143, p144)
	local v145 = p143.lastRotSpeed / p143.rotAcceleration
	local v146 = p143.lastRotSpeed
	local v147 = p143.curRot[p143.rotationAxis]
	local v148 = -p143.rotAcceleration * math.sign(v145)
	for _ = 1, math.abs(v145) do
		v146 = v146 + v148
		v147 = v147 + v146
	end
	local v149 = 0.001
	local v150, v151
	if p143.rotMin == nil or p143.rotMax == nil then
		local v152 = p143.curRot[p143.rotationAxis]
		v150 = MathUtil.normalizeRotationForShortestPath(v152, p144)
		v151 = MathUtil.normalizeRotationForShortestPath(v147, p144)
		v149 = 0.0001
	else
		v150 = Cylindered.getMovingToolState(p142, p143)
		v151 = MathUtil.inverseLerp(p143.rotMin, p143.rotMax, v147)
		p144 = MathUtil.inverseLerp(p143.rotMin, p143.rotMax, p144)
	end
	local v153
	if p144 < v150 then
		local v154 = p143.rotSpeed
		v153 = -math.sign(v154)
		if v151 < p144 then
			return 0
		end
	else
		local v155 = p143.rotSpeed
		v153 = math.sign(v155)
		if p144 < v151 then
			return 0
		end
	end
	local v156 = p144 - v150
	return math.abs(v156) < v149 and 0 or v153
end
function AutomaticArmControlHarvester.prepareAlignment(p157, p158)
	local v159 = p157.spec_automaticArmControlHarvester
	if p158 == 1 then
		if p157.getIsTurnedOn ~= nil and (not p157:getIsTurnedOn() and p157:getCanBeTurnedOn()) then
			p157:setIsTurnedOn(true)
		end
		local v160 = p157.spec_woodHarvester
		if v160 ~= nil and (v160.headerJointTilt ~= nil and v160.headerJointTilt.state) then
			p157:setWoodHarvesterTiltState(false)
		end
	end
	for v161 = 1, #v159.alignmentNodes do
		local v162 = v159.alignmentNodes[v161]
		local v163 = v162.rotation == nil and 0 or AutomaticArmControlHarvester.calculateMovingToolTargetMove(p157, v162.movingTool, v162.rotation)
		if v163 ~= 0 then
			v162.movingTool.externalMove = v163
			if v162.isPrerequisite then
				return false
			end
		end
	end
	return true
end
function AutomaticArmControlHarvester.getIsAutomaticAlignmentActive(p164)
	local v165 = p164.spec_automaticArmControlHarvester
	local v166
	if v165.state == AutomaticArmControlHarvester.STATE_NONE then
		v166 = false
	else
		v166 = v165.state ~= AutomaticArmControlHarvester.STATE_FINISHED
	end
	return v166
end
function AutomaticArmControlHarvester.getAutomaticAlignmentCurrentTarget(p167)
	local v168 = p167.spec_automaticArmControlHarvester
	if v168.lastFoundValidTarget then
		return v168.lastTargetTrans[1], v168.lastTargetTrans[2], v168.lastTargetTrans[3], v168.lastRadius
	else
		return nil, nil, nil, nil
	end
end
function AutomaticArmControlHarvester.getAutomaticAlignmentInvalidTreeReason(p169)
	return p169.spec_automaticArmControlHarvester.invalidTreeReason
end
function AutomaticArmControlHarvester.getBestTreeToAutoAlign(p170, p171, p172)
	local v173 = (1 / 0)
	local v174 = nil
	local v175 = nil
	local v176 = nil
	for v177 = 1, #p172 do
		local v178 = p172[v177]
		if entityExists(v178) and (getRigidBodyType(v178) == RigidBodyType.STATIC and (getHasClassId(v178, ClassIds.MESH_SPLIT_SHAPE) and not getIsSplitShapeSplit(v178))) then
			local v179 = calcDistanceFrom(p171, v178)
			local v180, _, v181 = localToLocal(v178, p171, 0, 0, 0)
			local v182, v183 = MathUtil.vector2Normalize(v180, v181)
			local v184 = MathUtil.getYRotationFromDirection(v182, v183)
			if math.abs(v184) < p170.spec_automaticArmControlHarvester.treeDetectionNodeMaxAngle then
				if g_splitShapeManager:getSplitShapeAllowsHarvester(v178) then
					local v185, _, v186 = getWorldTranslation(v178)
					if WoodHarvester.getCanSplitShapeBeAccessed(p170, v185, v186, v178) then
						local v187 = math.deg(v184)
						local v188 = math.abs(v187) + v179 * 2
						if v188 < v173 then
							v174 = v178
							v173 = v188
						end
					else
						v176 = AutomaticArmControlHarvester.INVALID_REASON_NO_ACCESS
						v175 = v178
					end
				else
					v176 = AutomaticArmControlHarvester.INVALID_REASON_WRONG_TYPE
					v175 = v178
				end
			end
		end
	end
	return v174, v175, v176
end
function AutomaticArmControlHarvester.onTreeAutoOverlapCallback(p189, p190, ...)
	if not p189.isDeleted and (p190 ~= 0 and (getHasClassId(p190, ClassIds.SHAPE) and (getUserAttribute(p190, "isTreeStump") ~= true and g_splitShapeManager:getSplitTypeByIndex(getSplitType(p190)) ~= nil))) then
		local v191 = p189.spec_automaticArmControlHarvester
		local v192, _, v193 = getWorldTranslation(v191.treeDetectionNode)
		local v194, _, v195 = getWorldTranslation(p190)
		local v196 = MathUtil.vector2Length(v192 - v194, v193 - v195)
		if v191.treeDetectionNodeMinRadius < v196 and v196 < v191.treeDetectionNodeMaxRadius then
			local v197 = v191.foundTrees
			table.insert(v197, p190)
		end
	end
end
function AutomaticArmControlHarvester.getTreeAutomaticOverwrites(p198)
	local v199 = p198.spec_automaticArmControlHarvester
	return v199.zAlignment.referenceNode, v199.yAlignment.referenceNode, v199.xAlignment.offset
end
function AutomaticArmControlHarvester.drawDebugCircleRange(p200, p201, p202, p203, p204)
	local v205 = p204 - p203
	local v206 = 0
	local v207 = 0
	for v208 = 1, p202 do
		local v209 = 1.5707963267948966 + p203 + (v208 - 1) / p202 * v205
		local v210 = 1.5707963267948966 + p203 + v208 / p202 * v205
		local v211 = math.cos(v209) * p201
		local v212 = math.sin(v209) * p201
		local v213, v214, v215 = localToWorld(p200, v206 + v211, 0, v207 + v212)
		local v216 = math.cos(v210) * p201
		local v217 = math.sin(v210) * p201
		local v218, v219, v220 = localToWorld(p200, v206 + v216, 0, v207 + v217)
		drawDebugLine(v213, v214, v215, 1, 0, 0, v218, v219, v220, 1, 0, 0)
	end
end

CropRowAdjustedNodes = {}
function CropRowAdjustedNodes.prerequisitesPresent(_)
	return true
end
function CropRowAdjustedNodes.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("CropRowAdjustedNodes")
	v1:register(XMLValueType.FLOAT, "vehicle.cropRowAdjustedNodes#maxUpdateDistance", "If the player is more than this distance away the nodes will no longer be updated", 100)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.cropRowAdjustedNodes.adjustedNode(?)#node", "Row adjusted node")
	v1:register(XMLValueType.INT, "vehicle.cropRowAdjustedNodes.adjustedNode(?)#transAxis", "Translation Axis", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.cropRowAdjustedNodes.adjustedNode(?)#minTrans", "Min. translation value", -0.25)
	v1:register(XMLValueType.FLOAT, "vehicle.cropRowAdjustedNodes.adjustedNode(?)#maxTrans", "Max. translation value", 0.25)
	v1:register(XMLValueType.FLOAT, "vehicle.cropRowAdjustedNodes.adjustedNode(?)#moveSpeed", "Move speed (m/sec)", 0.25)
	v1:register(XMLValueType.BOOL, "vehicle.cropRowAdjustedNodes.adjustedNode(?)#betweenRows", "Defines if the node is aligned on the rows or the middle between the rows", true)
	v1:register(XMLValueType.STRING, "vehicle.cropRowAdjustedNodes.adjustedNode(?)#fruitTypes", "List of supported fruit types separated by a whitespace", "maize potato sunflower")
	v1:register(XMLValueType.FLOAT, "vehicle.cropRowAdjustedNodes.adjustedNode(?).foldable#minLimit", "Fold min. time", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.cropRowAdjustedNodes.adjustedNode(?).foldable#maxLimit", "Fold max. time", 1)
	v1:setXMLSpecializationType()
end
function CropRowAdjustedNodes.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "loadCropRowAdjustedNodeFromXML", CropRowAdjustedNodes.loadCropRowAdjustedNodeFromXML)
	SpecializationUtil.registerFunction(p2, "updateCropRowAdjustedNode", CropRowAdjustedNodes.updateCropRowAdjustedNode)
	SpecializationUtil.registerFunction(p2, "getIsCropRowAdjustedNodeActive", CropRowAdjustedNodes.getIsCropRowAdjustedNodeActive)
end
function CropRowAdjustedNodes.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", CropRowAdjustedNodes)
	SpecializationUtil.registerEventListener(p3, "onUpdate", CropRowAdjustedNodes)
end
function CropRowAdjustedNodes.onLoad(p_u_4, _)
	local v_u_5 = p_u_4.spec_cropRowAdjustedNodes
	v_u_5.adjustedNodes = {}
	p_u_4.xmlFile:iterate("vehicle.cropRowAdjustedNodes.adjustedNode", function(_, p6)
		-- upvalues: (copy) p_u_4, (copy) v_u_5
		local v7 = {}
		if p_u_4:loadCropRowAdjustedNodeFromXML(p_u_4.xmlFile, p6, v7) then
			local v8 = v_u_5.adjustedNodes
			table.insert(v8, v7)
		end
	end)
	if #v_u_5.adjustedNodes == 0 then
		SpecializationUtil.removeEventListener(p_u_4, "onUpdate", CropRowAdjustedNodes)
	else
		v_u_5.maxUpdateDistance = p_u_4.xmlFile:getValue("vehicle.cropRowAdjustedNodes#maxUpdateDistance", 100)
	end
end
function CropRowAdjustedNodes.onUpdate(p9, p10, _, _, _)
	local v11 = p9.spec_cropRowAdjustedNodes
	if p9.currentUpdateDistance < v11.maxUpdateDistance then
		for _, v12 in pairs(v11.adjustedNodes) do
			p9:updateCropRowAdjustedNode(v12, p10)
		end
	end
end
function CropRowAdjustedNodes.loadCropRowAdjustedNodeFromXML(p13, p14, p15, p16)
	p16.node = p14:getValue(p15 .. "#node", nil, p13.components, p13.i3dMappings)
	if p16.node == nil then
		Logging.xmlWarning(p14, "Missing node in \'%s\'", p15)
	else
		p16.referenceFrame = createTransformGroup("cropRowAdjustedNodeRefFrame")
		link(getParent(p16.node), p16.referenceFrame)
		setTranslation(p16.referenceFrame, getTranslation(p16.node))
		setRotation(p16.referenceFrame, getRotation(p16.node))
		p16.startTrans = { getTranslation(p16.node) }
		p16.curTrans = { getTranslation(p16.node) }
		p16.transAxis = p14:getValue(p15 .. "#transAxis", 1)
		p16.minTrans = p14:getValue(p15 .. "#minTrans", -0.25)
		p16.maxTrans = p14:getValue(p15 .. "#maxTrans", 0.25)
		p16.moveSpeed = p14:getValue(p15 .. "#moveSpeed", 0.25) / 1000
		p16.betweenRows = p14:getValue(p15 .. "#betweenRows", true)
		p16.fruitTypes = {}
		local v17 = p14:getValue(p15 .. "#fruitTypes", "maize potato sunflower")
		if v17 ~= nil then
			local v18 = v17:split(" ")
			for _, v19 in pairs(v18) do
				local v20 = g_fruitTypeManager:getFruitTypeByName(v19)
				if v20 ~= nil then
					p16.fruitTypes[v20.index] = true
				end
			end
		end
		if next(p16.fruitTypes) ~= nil then
			p16.foldMinLimit = p14:getValue(p15 .. ".foldable#minLimit", 0)
			p16.foldMaxLimit = p14:getValue(p15 .. ".foldable#maxLimit", 1)
			return true
		end
		Logging.xmlWarning(p14, "Missing fruit types in \'%s\'", p15)
	end
	return false
end
CropRowAdjustedNodes.MAX_ACTIVE_ANGLE = 0.17453292519943295
function CropRowAdjustedNodes.updateCropRowAdjustedNode(p21, p22, p23)
	local v24 = p22.isActive
	p22.isActive = p21:getIsCropRowAdjustedNodeActive(p22)
	if p22.isActive then
		local v25, _, v26 = getWorldTranslation(p22.referenceFrame)
		local v27, _ = FSDensityMapUtil.getFruitTypeIndexAtWorldPos(v25, v26)
		if p22.fruitTypes[v27] == nil then
			p22.isActive = false
			return
		end
		local v28 = g_fruitTypeManager:getFruitTypeByIndex(v27).plantSpacing
		local v29 = g_currentMission.terrainSize
		local v30 = p22.betweenRows
		local v31 = v29 * 0.5
		if v30 then
			v31 = v31 - v28 * 0.5
		end
		local v32 = v25 + v31
		local v33 = v26 + v31
		local v34 = MathUtil.round(v32 / v28) * v28
		local v35 = MathUtil.round(v33 / v28) * v28
		local v36 = -v31 + v34
		local v37 = -v31 + v35
		local v38, _, v39 = localToWorld(p22.referenceFrame, 0, 0, 10)
		local v40 = g_currentMission.terrainSize
		local v41 = p22.betweenRows
		local v42 = v40 * 0.5
		if v41 then
			v42 = v42 - v28 * 0.5
		end
		local v43 = v38 + v42
		local v44 = v39 + v42
		local v45 = MathUtil.round(v43 / v28) * v28
		local v46 = MathUtil.round(v44 / v28) * v28
		local v47 = -v42 + v45
		local v48 = -v42 + v46
		local v49, v50 = MathUtil.vector2Normalize(v47 - v36, v48 - v37)
		local v51 = MathUtil.getYRotationFromDirection(v49, v50)
		local v52 = MathUtil.round(v51 / 1.5707963267948966) * 1.5707963267948966
		local v53, v54 = MathUtil.getDirectionFromYRotation(v52)
		local v55 = v36 - v53
		local v56 = v37 - v54
		local v57 = -MathUtil.getSignedDistanceToLineSegment2D(v25, v26, v55, v56, v53, v54, v28 + 1)
		local v58 = p22.startTrans[p22.transAxis] + p22.minTrans
		local v59 = p22.startTrans[p22.transAxis] + p22.maxTrans
		p22.targetTrans = math.clamp(v57, v58, v59)
		local v60 = p22.targetTrans - p22.curTrans[p22.transAxis]
		if math.abs(v60) > 0.001 then
			p22.isDirty = true
		end
	elseif v24 then
		p22.targetTrans = p22.startTrans[p22.transAxis]
		p22.isDirty = true
	end
	if p22.isDirty then
		local v61 = p22.curTrans
		local v62 = p22.curTrans
		local v63 = p22.curTrans
		local v64, v65, v66 = getTranslation(p22.node)
		v61[1] = v64
		v62[2] = v65
		v63[3] = v66
		local v67 = p22.targetTrans - p22.curTrans[p22.transAxis]
		if math.abs(v67) > 0.001 then
			local v68 = math.sign(v67)
			local v69 = v68 > 0 and math.min or math.max
			p22.curTrans[p22.transAxis] = v69(p22.curTrans[p22.transAxis] + v68 * p22.moveSpeed * p23, p22.targetTrans)
			setTranslation(p22.node, p22.curTrans[1], p22.curTrans[2], p22.curTrans[3])
			if p21.setMovingToolDirty ~= nil then
				p21:setMovingToolDirty(p22.node)
				return
			end
		else
			p22.isDirty = false
		end
	end
end
function CropRowAdjustedNodes.getIsCropRowAdjustedNodeActive(p70, p71)
	local v72 = p70.spec_foldable
	if v72 ~= nil then
		local v73 = v72.foldAnimTime
		if v73 ~= nil and (p71.foldMaxLimit < v73 or v73 < p71.foldMinLimit) then
			return false
		end
	end
	if p70.getIsLowered == nil or not p70:getIsLowered() then
		return false
	end
	local v74, _, v75 = localDirectionToWorld(p71.referenceFrame, 0, 0, 1)
	local v76 = MathUtil.getYRotationFromDirection(MathUtil.vector2Normalize(v74, v75)) % 1.5707963267948966
	return math.abs(v76) < CropRowAdjustedNodes.MAX_ACTIVE_ANGLE or math.abs(v76) > 1.5708 - CropRowAdjustedNodes.MAX_ACTIVE_ANGLE
end

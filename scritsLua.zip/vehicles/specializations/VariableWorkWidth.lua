source("dataS/scripts/vehicles/specializations/events/VariableWorkWidthStateEvent.lua")
VariableWorkWidth = {}
VariableWorkWidth.SEND_NUM_BITS = 6
source("dataS/scripts/gui/hud/extensions/VariableWorkWidthHUDExtension.lua")
function VariableWorkWidth.prerequisitesPresent(_)
	return true
end
function VariableWorkWidth.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("variableWorkWidth", g_i18n:getText("configuration_workingWidth"), "variableWorkWidth", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("VariableWorkWidth")
	VariableWorkWidth.registerSectionPaths(v1, "vehicle.variableWorkWidth")
	VariableWorkWidth.registerSectionPaths(v1, "vehicle.variableWorkWidth.variableWorkWidthConfigurations.variableWorkWidthConfiguration(?)")
	v1:register(XMLValueType.INT, "vehicle.variableWorkWidth#widthReferenceWorkAreaIndex", "Width of this work area is used as reference for the HUD display", 1)
	v1:register(XMLValueType.INT, "vehicle.variableWorkWidth#defaultStateLeft", "Default state on left side", "Max. possible state")
	v1:register(XMLValueType.INT, "vehicle.variableWorkWidth#defaultStateRight", "Default state on right side", "Max. possible state")
	v1:register(XMLValueType.BOOL, "vehicle.variableWorkWidth#aiKeepCurrentWidth", "Defines if the ai should keep the current width or change it", false)
	v1:register(XMLValueType.INT, "vehicle.variableWorkWidth#aiStateLeft", "AI state on left side", "Max. possible state")
	v1:register(XMLValueType.INT, "vehicle.variableWorkWidth#aiStateRight", "AI state on right side", "Max. possible state")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. ".section#index", "Section index (Section needs to be active to activate workArea)")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".section#index", "Section index (Section needs to be active to activate workArea)")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).variableWorkWidth#leftSide", "Left side section states", "Max. state")
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).variableWorkWidth#rightSide", "Right side section states", "Max. state")
end
function VariableWorkWidth.registerSectionPaths(p3, p4)
	p3:register(XMLValueType.BOOL, p4 .. ".sections.section(?)#isLeft", "Section side", false)
	p3:register(XMLValueType.BOOL, p4 .. ".sections.section(?)#isCenter", "Is center section", false)
	p3:register(XMLValueType.FLOAT, p4 .. ".sections.section(?)#width", "Section max. width as percentage [0..1]", "Automatically calculated")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".sections.section(?)#maxWidthNode", "Position of this node defines max. width of this section")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".sections.section(?).effect(?)#node", "Effect to deactivate/activate")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".sectionNodes.sectionNode(?)#node", "Section node")
	p3:register(XMLValueType.BOOL, p4 .. ".sectionNodes.sectionNode(?)#isLeft", "Section node")
	p3:register(XMLValueType.VECTOR_TRANS, p4 .. ".sectionNodes.sectionNode(?)#minTrans", "Min. translation")
	p3:register(XMLValueType.FLOAT, p4 .. ".sectionNodes.sectionNode(?)#minTransX", "Min. X translation")
	p3:register(XMLValueType.VECTOR_TRANS, p4 .. ".sectionNodes.sectionNode(?)#maxTrans", "Max. translation")
	p3:register(XMLValueType.FLOAT, p4 .. ".sectionNodes.sectionNode(?)#maxTransX", "Max. X translation")
	p3:register(XMLValueType.VECTOR_ROT, p4 .. ".sectionNodes.sectionNode(?)#minRot", "Min. rotation")
	p3:register(XMLValueType.VECTOR_ROT, p4 .. ".sectionNodes.sectionNode(?)#endRot", "Max. rotation")
	p3:register(XMLValueType.INT, p4 .. ".sectionNodes.sectionNode(?)#workAreaIndex", "Work area index", 1)
end
function VariableWorkWidth.registerEvents(p5)
	SpecializationUtil.registerEvent(p5, "onVariableWorkWidthSectionChanged")
end
function VariableWorkWidth.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "setSectionsActive", VariableWorkWidth.setSectionsActive)
	SpecializationUtil.registerFunction(p6, "setSectionNodePercentage", VariableWorkWidth.setSectionNodePercentage)
	SpecializationUtil.registerFunction(p6, "updateSections", VariableWorkWidth.updateSections)
	SpecializationUtil.registerFunction(p6, "updateSectionStates", VariableWorkWidth.updateSectionStates)
	SpecializationUtil.registerFunction(p6, "getEffectByNode", VariableWorkWidth.getEffectByNode)
	SpecializationUtil.registerFunction(p6, "getVariableWorkWidth", VariableWorkWidth.getVariableWorkWidth)
	SpecializationUtil.registerFunction(p6, "getVariableWorkWidthUsage", VariableWorkWidth.getVariableWorkWidthUsage)
end
function VariableWorkWidth.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadWorkAreaFromXML", VariableWorkWidth.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsWorkAreaActive", VariableWorkWidth.getIsWorkAreaActive)
end
function VariableWorkWidth.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onPostLoad", VariableWorkWidth)
	SpecializationUtil.registerEventListener(p8, "onRegisterActionEvents", VariableWorkWidth)
	SpecializationUtil.registerEventListener(p8, "onAIFieldWorkerStart", VariableWorkWidth)
	SpecializationUtil.registerEventListener(p8, "onAIImplementStart", VariableWorkWidth)
	SpecializationUtil.registerEventListener(p8, "onDraw", VariableWorkWidth)
	SpecializationUtil.registerEventListener(p8, "onDelete", VariableWorkWidth)
end
function VariableWorkWidth.onPostLoad(p_u_9, p10)
	local v_u_11 = p_u_9.spec_variableWorkWidth
	local v12 = Utils.getNoNil(p_u_9.configurations.variableWorkWidth, 1)
	local v13 = string.format("vehicle.variableWorkWidth.variableWorkWidthConfigurations.variableWorkWidthConfiguration(%d)", v12 - 1)
	local v14 = not p_u_9.xmlFile:hasProperty(v13) and "vehicle.variableWorkWidth" or v13
	local function v_u_18(p15, p16)
		for v17 = #p15.effects, 1, -1 do
			if p15.effects[v17] == p16 then
				p15.effects[v17] = nil
				return
			end
		end
	end
	local function v_u_20(p19)
		return p19.isActive
	end
	v_u_11.hasCenter = false
	v_u_11.sections = {}
	v_u_11.sectionsLeft = {}
	v_u_11.sectionsRight = {}
	p_u_9.xmlFile:iterate(v14 .. ".sections.section", function(_, p21)
		-- upvalues: (copy) p_u_9, (copy) v_u_18, (copy) v_u_20, (copy) v_u_11
		local v_u_22 = {
			["isLeft"] = p_u_9.xmlFile:getValue(p21 .. "#isLeft", false),
			["isCenter"] = p_u_9.xmlFile:getValue(p21 .. "#isCenter", false),
			["maxWidthNode"] = p_u_9.xmlFile:getValue(p21 .. "#maxWidthNode", nil, p_u_9.components, p_u_9.i3dMappings),
			["width"] = p_u_9.xmlFile:getValue(p21 .. "#width"),
			["effects"] = {}
		}
		p_u_9.xmlFile:iterate(p21 .. ".effect", function(_, p23)
			-- upvalues: (ref) p_u_9, (ref) v_u_18, (copy) v_u_22, (ref) v_u_20
			local v24 = p_u_9.xmlFile:getValue(p23 .. "#node", nil, p_u_9.components, p_u_9.i3dMappings)
			if v24 ~= nil then
				local v25 = p_u_9:getEffectByNode(v24)
				if v25 ~= nil then
					v25:addDeleteListener(v_u_18, v_u_22, v25)
					v25:addStartRestriction(v_u_20, v_u_22)
					local v26 = v_u_22.effects
					table.insert(v26, v25)
				end
			end
		end)
		v_u_22.isActive = true
		if v_u_22.isLeft then
			local v27 = v_u_11.sectionsLeft
			table.insert(v27, v_u_22)
		elseif v_u_22.isCenter then
			v_u_11.hasCenter = true
		else
			local v28 = v_u_11.sectionsRight
			table.insert(v28, v_u_22)
		end
		local v29 = v_u_11.sections
		table.insert(v29, v_u_22)
	end)
	v_u_11.sectionNodes = {}
	v_u_11.sectionNodesLeft = {}
	v_u_11.sectionNodesRight = {}
	p_u_9.xmlFile:iterate(v14 .. ".sectionNodes.sectionNode", function(_, p30)
		-- upvalues: (copy) p_u_9, (copy) v_u_11
		local v31 = {
			["node"] = p_u_9.xmlFile:getValue(p30 .. "#node", nil, p_u_9.components, p_u_9.i3dMappings)
		}
		if v31.node ~= nil then
			v31.isLeft = p_u_9.xmlFile:getValue(p30 .. "#isLeft", false)
			v31.startTrans = p_u_9.xmlFile:getValue(p30 .. "#minTrans", nil, true)
			v31.startTransX = p_u_9.xmlFile:getValue(p30 .. "#minTransX")
			v31.endTrans = p_u_9.xmlFile:getValue(p30 .. "#maxTrans", nil, true)
			v31.endTransX = p_u_9.xmlFile:getValue(p30 .. "#maxTransX")
			v31.startRot = p_u_9.xmlFile:getValue(p30 .. "#minRot", nil, true)
			v31.endRot = p_u_9.xmlFile:getValue(p30 .. "#endRot", nil, true)
			if v31.startTrans == nil and v31.startTransX == nil then
				Logging.xmlWarning(p_u_9.xmlFile, "sectionNode \'%s\' needs either \'minTrans\' or \'minTransX\' set", p30)
				return
			end
			if v31.endTrans == nil and v31.endTransX == nil then
				Logging.xmlWarning(p_u_9.xmlFile, "sectionNode \'%s\' needs either \'maxTrans\' or \'maxTransX\' set", p30)
				return
			end
			v31.workAreaIndex = p_u_9.xmlFile:getValue(p30 .. "#workAreaIndex", 1)
			if v31.isLeft then
				local v32 = v_u_11.sectionNodesLeft
				table.insert(v32, v31)
			else
				local v33 = v_u_11.sectionNodesRight
				table.insert(v33, v31)
			end
			local v34 = v_u_11.sectionNodes
			table.insert(v34, v31)
		end
	end)
	for v35 = 1, #v_u_11.sections do
		local v36 = v_u_11.sections[v35]
		if v36.maxWidthNode == nil then
			v36.width = 0
		elseif not v36.isCenter then
			for v37 = 1, #v_u_11.sectionNodes do
				local v38 = v_u_11.sectionNodes[v37]
				if v38.isLeft == v36.isLeft then
					local v39, _, _ = localToLocal(v36.maxWidthNode, getParent(v38.node), 0, 0, 0)
					local v40 = v38.startTransX or v38.startTrans[1]
					local v41 = v38.endTransX or v38.endTrans[1]
					local v42 = (v39 - v40) / (v41 - v40)
					local v43 = math.abs(v42)
					v36.width = math.clamp(v43, 0, 1)
					v36.widthAbs = v39
					break
				end
			end
		end
		if v36.width == nil then
			Logging.xmlWarning(p_u_9.xmlFile, "Unable to get width for section \'vehicle.variableWorkWidth.sections.section(%d)\'", v35)
			v36.width = 0
		end
	end
	local function v46(p44, p45)
		return p44.width < p45.width
	end
	table.sort(v_u_11.sectionsLeft, v46)
	table.sort(v_u_11.sectionsRight, v46)
	v_u_11.widthReferenceWorkArea = p_u_9.xmlFile:getValue("vehicle.variableWorkWidth#widthReferenceWorkAreaIndex", 1)
	v_u_11.leftSideMax = #v_u_11.sectionsLeft
	v_u_11.leftSide = p_u_9.xmlFile:getValue("vehicle.variableWorkWidth#defaultStateLeft", v_u_11.leftSideMax)
	v_u_11.rightSideMax = #v_u_11.sectionsRight
	v_u_11.rightSide = p_u_9.xmlFile:getValue("vehicle.variableWorkWidth#defaultStateRight", v_u_11.rightSideMax)
	v_u_11.aiKeepCurrentWidth = p_u_9.xmlFile:getValue("vehicle.variableWorkWidth#aiKeepCurrentWidth", false)
	v_u_11.aiStateLeft = p_u_9.xmlFile:getValue("vehicle.variableWorkWidth#aiStateLeft", v_u_11.leftSideMax)
	v_u_11.aiStateRight = p_u_9.xmlFile:getValue("vehicle.variableWorkWidth#aiStateRight", v_u_11.rightSideMax)
	v_u_11.minSideState = v_u_11.hasCenter and 0 or 1
	if p10 ~= nil and not p10.resetVehicles then
		local v47 = p10.xmlFile:getValue(p10.key .. ".variableWorkWidth#leftSide", v_u_11.leftSide)
		local v48 = v_u_11.leftSideMax
		v_u_11.leftSide = math.min(v47, v48)
		local v49 = p10.xmlFile:getValue(p10.key .. ".variableWorkWidth#rightSide", v_u_11.rightSide)
		local v50 = v_u_11.rightSideMax
		v_u_11.rightSide = math.min(v49, v50)
	end
	p_u_9:updateSections()
	v_u_11.drawInputHelp = false
	v_u_11.hasSections = #v_u_11.sections > 0
	if v_u_11.hasSections then
		v_u_11.hudExtension = VariableWorkWidthHUDExtension.new(p_u_9)
	end
	if not (p_u_9.isClient and v_u_11.hasSections) then
		SpecializationUtil.removeEventListener(p_u_9, "onRegisterActionEvents", VariableWorkWidth)
	end
end
function VariableWorkWidth.onDelete(p51)
	local v52 = p51.spec_variableWorkWidth
	if v52.hudExtension ~= nil then
		g_currentMission.hud:removeInfoExtension(v52.hudExtension)
		v52.hudExtension:delete()
	end
end
function VariableWorkWidth.saveToXMLFile(p53, p54, p55, _)
	local v56 = p53.spec_variableWorkWidth
	if v56.hasSections then
		p54:setValue(p55 .. "#leftSide", v56.leftSide)
		p54:setValue(p55 .. "#rightSide", v56.rightSide)
	end
end
function VariableWorkWidth.onDraw(p57)
	local v58 = p57.spec_variableWorkWidth
	if v58.hudExtension ~= nil then
		g_currentMission.hud:addInfoExtension(v58.hudExtension)
	end
end
function VariableWorkWidth.onRegisterActionEvents(p59, _, p60)
	local v61 = p59.spec_variableWorkWidth
	p59:clearActionEventsTable(v61.actionEvents)
	if p60 then
		local _, v62 = p59:addActionEvent(v61.actionEvents, InputAction.VARIABLE_WORK_WIDTH_LEFT, p59, VariableWorkWidth.actionEventWorkWidthLeft, false, true, false, true, nil)
		g_inputBinding:setActionEventTextPriority(v62, GS_PRIO_HIGH)
		local _, v63 = p59:addActionEvent(v61.actionEvents, InputAction.VARIABLE_WORK_WIDTH_RIGHT, p59, VariableWorkWidth.actionEventWorkWidthRight, false, true, false, true, nil)
		g_inputBinding:setActionEventTextPriority(v63, GS_PRIO_HIGH)
		local _, v64 = p59:addActionEvent(v61.actionEvents, InputAction.VARIABLE_WORK_WIDTH_TOGGLE, p59, VariableWorkWidth.actionEventWorkWidthToggle, false, true, false, true, nil)
		g_inputBinding:setActionEventTextPriority(v64, GS_PRIO_HIGH)
		v61.drawInputHelp = g_inputBinding:getActionEventsHasBinding(v62) or (g_inputBinding:getActionEventsHasBinding(v63) or g_inputBinding:getActionEventsHasBinding(v64))
	end
end
function VariableWorkWidth.actionEventWorkWidthLeft(p65, _, p66, _, _)
	local v67 = p65.spec_variableWorkWidth
	p65:setSectionsActive(v67.leftSide - p66, v67.rightSide)
end
function VariableWorkWidth.actionEventWorkWidthRight(p68, _, p69, _, _)
	local v70 = p68.spec_variableWorkWidth
	p68:setSectionsActive(v70.leftSide, v70.rightSide - p69)
end
function VariableWorkWidth.actionEventWorkWidthToggle(p71, _, _, _, _)
	local v72 = p71.spec_variableWorkWidth
	local v73 = v72.leftSide
	local v74 = v72.rightSide
	local v75 = math.min(v73, v74) - 1
	if v75 < v72.minSideState then
		local v76 = v72.leftSideMax
		local v77 = v72.rightSideMax
		v75 = math.min(v76, v77)
	end
	p71:setSectionsActive(v75, v75)
end
function VariableWorkWidth.onAIFieldWorkerStart(p78)
	if p78.isServer then
		local v79 = p78.spec_variableWorkWidth
		if not v79.aiKeepCurrentWidth then
			p78:setSectionsActive(v79.aiStateLeft, v79.aiStateRight)
		end
	end
end
function VariableWorkWidth.onAIImplementStart(p80)
	if p80.isServer then
		local v81 = p80.spec_variableWorkWidth
		if not v81.aiKeepCurrentWidth then
			p80:setSectionsActive(v81.aiStateLeft, v81.aiStateRight)
		end
	end
end
function VariableWorkWidth.setSectionsActive(p82, p83, p84, p85)
	local v86 = p82.spec_variableWorkWidth
	local v87 = v86.leftSideMax
	local v88 = math.clamp(p83, 0, v87)
	local v89 = v86.rightSideMax
	local v90 = math.clamp(p84, 0, v89)
	if v86.leftSide ~= v88 or v86.rightSide ~= v90 then
		v86.leftSide = v88
		v86.rightSide = v90
		p82:updateSections()
		VariableWorkWidthStateEvent.sendEvent(p82, v86.leftSide, v86.rightSide, p85)
	end
end
function VariableWorkWidth.setSectionNodePercentage(p91, p92, p93)
	local v94 = math.min(p93, 1)
	local v95 = math.max(v94, 0)
	for v96 = 1, #p92 do
		local v97 = p92[v96]
		if v97.startTrans ~= nil and v97.endTrans ~= nil then
			setTranslation(v97.node, MathUtil.vector3ArrayLerp(v97.startTrans, v97.endTrans, v95))
		end
		if v97.startTransX ~= nil and v97.endTransX ~= nil then
			local _, v98, v99 = getTranslation(v97.node)
			local v100 = MathUtil.lerp(v97.startTransX, v97.endTransX, v95)
			setTranslation(v97.node, v100, v98, v99)
		end
		if v97.startRot ~= nil and v97.endRot ~= nil then
			setRotation(v97.node, MathUtil.vector3ArrayLerp(v97.startRot, v97.endRot, v95))
		end
		if v97.workAreaIndex ~= nil then
			p91:updateWorkAreaWidth(v97.workAreaIndex)
		end
	end
end
function VariableWorkWidth.updateSections(p101)
	local v102 = p101.spec_variableWorkWidth
	p101:updateSectionStates(v102.sectionsLeft, v102.leftSide)
	p101:updateSectionStates(v102.sectionsRight, v102.rightSide)
	local v103 = v102.leftSide == 0 and 0 or v102.sectionsLeft[v102.leftSide].width
	p101:setSectionNodePercentage(v102.sectionNodesLeft, v103)
	local v104 = v102.rightSide == 0 and 0 or v102.sectionsRight[v102.rightSide].width
	p101:setSectionNodePercentage(v102.sectionNodesRight, v104)
	SpecializationUtil.raiseEvent(p101, "onVariableWorkWidthSectionChanged")
end
function VariableWorkWidth.updateSectionStates(_, p105, p106)
	for v107 = 1, #p105 do
		local v108 = p105[v107]
		v108.isActive = v107 <= p106
		for v109 = 1, #v108.effects do
			local v110 = v108.effects[v109]
			if not v108.isActive and v110:isRunning() then
				v110:stop()
			end
		end
	end
end
function VariableWorkWidth.getEffectByNode(_, _) end
function VariableWorkWidth.getVariableWorkWidth(p111, p112)
	local v113 = p111.spec_variableWorkWidth
	local v114 = p112 and v113.sectionsLeft or v113.sectionsRight
	if #v114 == 0 then
		return 1, 1, false
	end
	local v115 = nil
	for v116 = #v114, 1, -1 do
		local v117 = v114[v116]
		v115 = v115 or v117.widthAbs
		if v117.isActive then
			return v117.widthAbs, v115, true
		end
	end
	return 0, v115 or 1, true
end
function VariableWorkWidth.getVariableWorkWidthUsage(_)
	return nil
end
function VariableWorkWidth.loadWorkAreaFromXML(p118, p119, p120, p121, p122)
	p120.sectionIndex = p121:getValue(p122 .. ".section#index")
	return p119(p118, p120, p121, p122)
end
function VariableWorkWidth.getIsWorkAreaActive(p123, p124, p125)
	if p125.sectionIndex ~= nil then
		local v126 = p123.spec_variableWorkWidth.sections[p125.sectionIndex]
		if v126 ~= nil and not v126.isActive then
			return false
		end
	end
	return p124(p123, p125)
end

AttacherJoints = {}
AttacherJoints.DEFAULT_MAX_UPDATE_DISTANCE = 50
AttacherJoints.MAX_ATTACH_DISTANCE_SQ = 0.48999999999999994
AttacherJoints.MAX_ATTACH_ANGLE = 0.34202
AttacherJoints.SMOOTH_ATTACH_TIME = 500
AttacherJoints.NUM_JOINTTYPES = 0
AttacherJoints.jointTypeNameToInt = {}
AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY = {}
AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[0] = 0.51
AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[1] = 0.718
AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[2] = 0.87
AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[3] = 1.01
AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[4] = 1.222
AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY = {}
AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY[0] = 0.035
AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY[1] = 0.044
AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY[2] = 0.056
AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY[3] = 0.064
AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY[4] = 0.085
source("dataS/scripts/vehicles/specializations/components/AttacherJointTopArm.lua")
function AttacherJoints.getClosestLowerLinkCategoryIndex(p1)
	local v2 = (1 / 0)
	local v3 = 1
	for v4, v5 in pairs(AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY) do
		local v6 = p1 - v5
		local v7 = math.abs(v6)
		if v7 < v2 then
			v3 = v4
			v2 = v7
		end
	end
	return v3
end
function AttacherJoints.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("attacherJoint", g_i18n:getText("configuration_attacherJoint"), "attacherJoints", VehicleConfigurationItem)
	local v8 = Vehicle.xmlSchema
	v8:setXMLSpecializationType("AttacherJoints")
	AttacherJoints.registerAttacherJointXMLPaths(v8, "vehicle.attacherJoints")
	SoundManager.registerSampleXMLPaths(v8, "vehicle.attacherJoints.sounds", "hydraulic")
	SoundManager.registerSampleXMLPaths(v8, "vehicle.attacherJoints.sounds", "attach")
	SoundManager.registerSampleXMLPaths(v8, "vehicle.attacherJoints.sounds", "detach")
	v8:register(XMLValueType.FLOAT, "vehicle.attacherJoints#comboDuration", "Combo duration", 2)
	v8:register(XMLValueType.INT, "vehicle.attacherJoints#connectionHoseConfigId", "Connection hose configuration index to use")
	v8:register(XMLValueType.INT, "vehicle.attacherJoints#powerTakeOffConfigId", "Power take off configuration index to use")
	v8:register(XMLValueType.INT, "vehicle.attacherJoints.attacherJointConfigurations.attacherJointConfiguration(?)#connectionHoseConfigId", "Connection hose configuration index to use")
	v8:register(XMLValueType.INT, "vehicle.attacherJoints.attacherJointConfigurations.attacherJointConfiguration(?)#powerTakeOffConfigId", "Power take off configuration index to use")
	v8:register(XMLValueType.FLOAT, "vehicle.attacherJoints#maxUpdateDistance", "Max. distance to vehicle root to update attacher joint graphics", AttacherJoints.DEFAULT_MAX_UPDATE_DISTANCE)
	v8:register(XMLValueType.VECTOR_N, Dashboard.GROUP_XML_KEY .. "#attacherJointIndices", "Group is only active if something is attached to those joints (List if indices of the attacher joint in xml)")
	v8:register(XMLValueType.NODE_INDICES, Dashboard.GROUP_XML_KEY .. "#attacherJointNodes", "Group is only active if something is attached to those joints (List of attacherJoint nodes)")
	v8:register(XMLValueType.VECTOR_N, Attachable.INPUT_ATTACHERJOINT_XML_KEY .. ".heightNode(?)#disablingAttacherJointIndices", "Attacher joint indices that disable height node if something is attached")
	v8:register(XMLValueType.VECTOR_N, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY .. ".heightNode(?)#disablingAttacherJointIndices", "Attacher joint indices that disable height node if something is attached")
	v8:setXMLSpecializationType()
	local v9 = Vehicle.xmlSchemaSavegame
	v9:register(XMLValueType.INT, "vehicles.vehicle(?).attacherJoints#comboDirection", "Current combo direction")
	v9:register(XMLValueType.INT, "vehicles.vehicle(?).attacherJoints.attachedImplement(?)#jointIndex", "Index of attacherJoint")
	v9:register(XMLValueType.BOOL, "vehicles.vehicle(?).attacherJoints.attachedImplement(?)#moveDown", "Attacher joint is lowered or not")
	v9:register(XMLValueType.STRING, "vehicles.vehicle(?).attacherJoints.attachedImplement(?)#attachedVehicleUniqueId", "Unique id of attached vehicle")
	v9:register(XMLValueType.INT, "vehicles.vehicle(?).attacherJoints.attachedImplement(?)#inputJointIndex", "Index of input attacher joint on the attached vehicle")
	v9:register(XMLValueType.INT, "vehicles.vehicle(?).attacherJoints.attacherJoint(?)#jointIndex", "Index of attacherJoint")
	v9:register(XMLValueType.BOOL, "vehicles.vehicle(?).attacherJoints.attacherJoint(?)#isBlocked", "Attacher joint is blocked or not")
	v9:register(XMLValueType.INT, "vehicles.attachments(?)#rootVehicleId", "Root vehicle id")
	v9:register(XMLValueType.INT, "vehicles.attachments(?).attachment(?)#attachmentId", "Attachment vehicle id")
	v9:register(XMLValueType.INT, "vehicles.attachments(?).attachment(?)#inputJointDescIndex", "Index of input attacher joint", 1)
	v9:register(XMLValueType.INT, "vehicles.attachments(?).attachment(?)#jointIndex", "Index of attacher joint")
	v9:register(XMLValueType.BOOL, "vehicles.attachments(?).attachment(?)#moveDown", "Attachment lowered or lifted")
end
function AttacherJoints.registerAttacherJointXMLPaths(p10, p11)
	p10:setXMLSharedRegistration("AttacherJoint", p11)
	local v12 = p11 .. ".attacherJoint(?)"
	p10:register(XMLValueType.NODE_INDEX, v12 .. "#node", "Node")
	p10:register(XMLValueType.NODE_INDEX, v12 .. "#nodeVisual", "Visual node")
	p10:register(XMLValueType.BOOL, v12 .. "#supportsHardAttach", "Supports hard attach")
	p10:register(XMLValueType.STRING, v12 .. "#jointType", "Joint type", "implement")
	p10:register(XMLValueType.STRING, v12 .. ".subType#name", "If defined this type needs to match with the sub type in the tool")
	p10:register(XMLValueType.STRING, v12 .. ".subType#brandRestriction", "If defined it\'s only possible to attach tools from these brands (can be multiple separated by \' \')")
	p10:register(XMLValueType.STRING, v12 .. ".subType#vehicleRestriction", "If defined it\'s only possible to attach tools containing these strings in there xml path (can be multiple separated by \' \')")
	p10:register(XMLValueType.BOOL, v12 .. ".subType#subTypeShowWarning", "Show warning if sub type does not match", true)
	p10:register(XMLValueType.BOOL, v12 .. "#allowsJointLimitMovement", "Allows joint limit movement", true)
	p10:register(XMLValueType.BOOL, v12 .. "#allowsLowering", "Allows lowering", true)
	p10:register(XMLValueType.BOOL, v12 .. "#isDefaultLowered", "Default lowered state", false)
	p10:register(XMLValueType.BOOL, v12 .. "#allowDetachingWhileLifted", "Allow detach while lifted", true)
	p10:register(XMLValueType.BOOL, v12 .. "#allowFoldingWhileAttached", "Allow folding while attached", true)
	p10:register(XMLValueType.BOOL, v12 .. "#canTurnOnImplement", "Can turn on implement", true)
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".rotationNode#node", "Rotation node")
	p10:register(XMLValueType.VECTOR_ROT, v12 .. ".rotationNode#lowerRotation", "Lower rotation", "0 0 0")
	p10:register(XMLValueType.VECTOR_ROT, v12 .. ".rotationNode#upperRotation", "Upper rotation", "rotation in i3d")
	p10:register(XMLValueType.VECTOR_ROT, v12 .. ".rotationNode#startRotation", "Start rotation", "rotation in i3d")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".rotationNode2#node", "Rotation node")
	p10:register(XMLValueType.VECTOR_ROT, v12 .. ".rotationNode2#lowerRotation", "Lower rotation", "0 0 0")
	p10:register(XMLValueType.VECTOR_ROT, v12 .. ".rotationNode2#upperRotation", "Upper rotation", "rotation in i3d")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".transNode#node", "Translation node")
	p10:register(XMLValueType.FLOAT, v12 .. ".transNode#height", "Height of visual translation node", 0.12)
	p10:register(XMLValueType.FLOAT, v12 .. ".transNode#minY", "Min Y translation")
	p10:register(XMLValueType.FLOAT, v12 .. ".transNode#maxY", "Max Y translation")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".transNode.dependentBottomArm#node", "Dependent bottom arm node")
	p10:register(XMLValueType.FLOAT, v12 .. ".transNode.dependentBottomArm#threshold", "If the trans node Y translation is below this threshold the rotation will be set", "unlimited, so rotation is always set")
	p10:register(XMLValueType.VECTOR_ROT, v12 .. ".transNode.dependentBottomArm#rotation", "Rotation to be set when the translation node is below the threshold", "0 0 0")
	p10:register(XMLValueType.FLOAT, v12 .. ".distanceToGround#lower", "Lower distance to ground", 0.7)
	p10:register(XMLValueType.FLOAT, v12 .. ".distanceToGround#upper", "Upper distance to ground", 1)
	p10:register(XMLValueType.ANGLE, v12 .. "#lowerRotationOffset", "Upper rotation offset", 0)
	p10:register(XMLValueType.ANGLE, v12 .. "#upperRotationOffset", "Lower rotation offset", 0)
	p10:register(XMLValueType.BOOL, v12 .. "#dynamicLowerRotLimit", "Set the lower rot limit dynamically based on the lowered state (so the attacher can freely rotate between it\'s upper and lower rotation value. E.g. for combines)", false)
	p10:register(XMLValueType.BOOL, v12 .. "#lockDownRotLimit", "Lock down rotation limit", false)
	p10:register(XMLValueType.BOOL, v12 .. "#lockUpRotLimit", "Lock up rotation limit", false)
	p10:register(XMLValueType.BOOL, v12 .. "#lockDownTransLimit", "Lock down translation limit", true)
	p10:register(XMLValueType.BOOL, v12 .. "#lockUpTransLimit", "Lock up translation limit", false)
	p10:register(XMLValueType.VECTOR_ROT, v12 .. "#lowerRotLimit", "Lower rotation limit", "(20 20 20) for implement type, otherwise (0 0 0)")
	p10:register(XMLValueType.VECTOR_ROT, v12 .. "#upperRotLimit", "Upper rotation limit", "Lower rot limit")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#lowerTransLimit", "Lower translation limit", "(0.5 0.5 0.5) for implement type, otherwise (0 0 0)")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#upperTransLimit", "Upper translation limit", "Lower trans limit")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#jointPositionOffset", "Joint position offset", "0 0 0")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#rotLimitSpring", "Rotation limit spring", "0 0 0")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#rotLimitDamping", "Rotation limit damping", "1 1 1")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#rotLimitForceLimit", "Rotation limit force limit", "-1 -1 -1")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#transLimitSpring", "Translation limit spring", "0 0 0")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#transLimitDamping", "Translation limit damping", "1 1 1")
	p10:register(XMLValueType.VECTOR_3, v12 .. "#transLimitForceLimit", "Translation limit force limit", "-1 -1 -1")
	p10:register(XMLValueType.FLOAT, v12 .. "#moveTime", "Move time", 0.5)
	p10:register(XMLValueType.VECTOR_N, v12 .. "#disabledByAttacherJoints", "This attacher becomes unavailable after attaching something to these attacher joint indices")
	p10:register(XMLValueType.BOOL, v12 .. "#enableCollision", "Collision between vehicle is enabled", false)
	AttacherJointTopArm.registerVehicleXMLPaths(p10, v12 .. ".topArm")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm#rotationNode", "Rotation node of bottom arm")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm#translationNode", "Translation node of bottom arm")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm#referenceNode", "Reference node of bottom arm")
	p10:register(XMLValueType.VECTOR_ROT, v12 .. ".bottomArm#startRotation", "Start rotation", "values set in i3d")
	p10:register(XMLValueType.INT, v12 .. ".bottomArm#zScale", "Inverts bottom arm direction", 1)
	p10:register(XMLValueType.BOOL, v12 .. ".bottomArm#lockDirection", "Lock direction", true)
	p10:register(XMLValueType.ANGLE, v12 .. ".bottomArm#resetSpeed", "Speed of bottom arm to return to idle position (deg/sec)", 45)
	p10:register(XMLValueType.BOOL, v12 .. ".bottomArm#updateReferenceDistance", "If \'true\', the reference distance will be updated dynamically. So it\'s possible to adjust the bottom arm length.", false)
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm#jointPositionNode", "Node that will be equalized with the current attacher joint position of the attached implement")
	p10:register(XMLValueType.BOOL, v12 .. ".bottomArm#toggleVisibility", "Bottom arm will be hidden on detach", false)
	p10:register(XMLValueType.VECTOR_N, v12 .. ".bottomArm#categoryRange", "Defines the min. and max. category that can be used separated by a whitespace. (if only one value is given it will be used as min. and max. value.)", "1 4")
	p10:register(XMLValueType.VECTOR_N, v12 .. ".bottomArm#widthRange", "Defines the min. and max. bottom arm width that can be used separated by a whitespace. Overwrites the categoryRange attribute. (if only one value is given it will be used as min. and max. value.)")
	p10:register(XMLValueType.FLOAT, v12 .. ".bottomArm#defaultWidth", "Defines the default bottom arm width while nothing is attached", "Width inside i3d file")
	p10:register(XMLValueType.INT, v12 .. ".bottomArm#defaultCategory", "Defines the default width category which is used when nothing is attached", "Width inside i3d file")
	p10:register(XMLValueType.BOOL, v12 .. ".bottomArm#ballVisibility", "Defines if the balls of the tool are visible while the tool is attached to us", true)
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm.armLeft#node", "Left bottom arm")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm.armLeft#referenceNode", "Left bottom arm reference node (placed at the attaching point at the end of the bottom arm. If not defined the arm will be translated on the X axis to the target width.)")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm.armRight#node", "Right bottom arm")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm.armRight#referenceNode", "Right bottom arm reference node (placed at the attaching point at the end of the bottom arm. If not defined the arm will be translated on the X axis to the target width.)")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm#leftNode", "Node of moving tool that will be aligned to \'bottomArmLeftNode\', if defined in the tool")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".bottomArm#rightNode", "Node of moving tool that will be aligned to \'bottomArmRightNode\', if defined in the tool")
	p10:register(XMLValueType.STRING, v12 .. ".toolbar#filename", "Filename to toolbars i3d containing 5 meshes for category 0-4", "$data/shared/assets/toolbars/toolbars.i3d")
	SoundManager.registerSampleXMLPaths(p10, v12, "attachSound")
	SoundManager.registerSampleXMLPaths(p10, v12, "detachSound")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".steeringBars#leftNode", "Steering bar left node")
	p10:register(XMLValueType.NODE_INDEX, v12 .. ".steeringBars#rightNode", "Steering bar right node")
	p10:register(XMLValueType.BOOL, v12 .. ".steeringBars#forceUsage", "Forces usage of tools steering axle even if no steering bars are defined", true)
	p10:register(XMLValueType.NODE_INDICES, v12 .. ".visuals#nodes", "Visual nodes of attacher joint that will be visible when the joint is active")
	p10:register(XMLValueType.NODE_INDICES, v12 .. ".visuals#hide", "Visual nodes that will be hidden while attacher joint is active if there attacher is inactive")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p10, v12)
	p10:register(XMLValueType.BOOL, v12 .. "#delayedObjectChanges", "Defines if object change is deactivated after the bottomArm has moved (if available)", true)
	p10:register(XMLValueType.BOOL, v12 .. "#delayedObjectChangesOnAttach", "Defines if object change is activated on attach or post attach", false)
	p10:register(XMLValueType.INT, v12 .. "#direction", "Direction of attacher joint (1 = front, -1 = back). Used for additional attachments on mobile and top light control in basegame.")
	p10:register(XMLValueType.BOOL, v12 .. "#useTopLights", "Defines if the attacher joint enables the top lights if something is attached. Flag needs to be set on the implement as well.", "\'true\' if the attacher joint is on the front")
	p10:register(XMLValueType.NODE_INDEX, v12 .. "#rootNode", "Root node", "Parent component of attacher joint node")
	p10:register(XMLValueType.FLOAT, v12 .. "#comboTime", "Combo time")
	p10:register(XMLValueType.VECTOR_2, v12 .. ".schema#position", "Schema position")
	p10:register(XMLValueType.VECTOR_2, v12 .. ".schema#liftedOffset", "Offset if lifted", "0 5")
	p10:register(XMLValueType.ANGLE, v12 .. ".schema#rotation", "Schema rotation", 0)
	p10:register(XMLValueType.BOOL, v12 .. ".schema#invertX", "Invert X", false)
	p10:addDelayedRegistrationPath(v12, "AttacherJoint")
	p10:resetXMLSharedRegistration("AttacherJoint", v12)
end
function AttacherJoints.registerJointType(p13)
	local v14 = "JOINTTYPE_" .. string.upper(p13)
	if AttacherJoints[v14] == nil then
		AttacherJoints.NUM_JOINTTYPES = AttacherJoints.NUM_JOINTTYPES + 1
		AttacherJoints[v14] = AttacherJoints.NUM_JOINTTYPES
		AttacherJoints.jointTypeNameToInt[p13] = AttacherJoints.NUM_JOINTTYPES
	end
	return AttacherJoints[v14]
end
AttacherJoints.JOINTTYPE_IMPLEMENT = AttacherJoints.registerJointType("implement")
AttacherJoints.JOINTTYPE_TRAILER = AttacherJoints.registerJointType("trailer")
AttacherJoints.JOINTTYPE_TRAILERLOW = AttacherJoints.registerJointType("trailerLow")
AttacherJoints.JOINTTYPE_TRAILERSADDLED = AttacherJoints.registerJointType("trailerSaddled")
AttacherJoints.JOINTTYPE_TRAILERCAR = AttacherJoints.registerJointType("trailerCar")
AttacherJoints.JOINTTYPE_TELEHANDLER = AttacherJoints.registerJointType("telehandler")
AttacherJoints.JOINTTYPE_FRONTLOADER = AttacherJoints.registerJointType("frontloader")
AttacherJoints.JOINTTYPE_LOADERFORK = AttacherJoints.registerJointType("loaderFork")
AttacherJoints.JOINTTYPE_SEMITRAILER = AttacherJoints.registerJointType("semitrailer")
AttacherJoints.JOINTTYPE_SEMITRAILERHOOK = AttacherJoints.registerJointType("semitrailerHook")
AttacherJoints.JOINTTYPE_SEMITRAILERCAR = AttacherJoints.registerJointType("semitrailerCar")
AttacherJoints.JOINTTYPE_ATTACHABLEFRONTLOADER = AttacherJoints.registerJointType("attachableFrontloader")
AttacherJoints.JOINTTYPE_WHEELLOADER = AttacherJoints.registerJointType("wheelLoader")
AttacherJoints.JOINTTYPE_MANUREBARREL = AttacherJoints.registerJointType("manureBarrel")
AttacherJoints.JOINTTYPE_CUTTER = AttacherJoints.registerJointType("cutter")
AttacherJoints.JOINTTYPE_CUTTERHARVESTER = AttacherJoints.registerJointType("cutterHarvester")
AttacherJoints.JOINTTYPE_CUTTERTRAILER = AttacherJoints.registerJointType("cutterTrailer")
AttacherJoints.JOINTTYPE_SKIDSTEER = AttacherJoints.registerJointType("skidSteer")
AttacherJoints.JOINTTYPE_CONVEYOR = AttacherJoints.registerJointType("conveyor")
AttacherJoints.JOINTTYPE_HOOKLIFT = AttacherJoints.registerJointType("hookLift")
AttacherJoints.JOINTTYPE_BIGBAG = AttacherJoints.registerJointType("bigBag")
AttacherJoints.JOINTTYPE_TRAIN = AttacherJoints.registerJointType("train")
function AttacherJoints.prerequisitesPresent(_)
	return true
end
function AttacherJoints.registerEvents(p15)
	SpecializationUtil.registerEvent(p15, "onPreAttachImplement")
	SpecializationUtil.registerEvent(p15, "onPostAttachImplement")
	SpecializationUtil.registerEvent(p15, "onPreDetachImplement")
	SpecializationUtil.registerEvent(p15, "onPostDetachImplement")
	SpecializationUtil.registerEvent(p15, "onRequiresTopLightsChanged")
end
function AttacherJoints.registerFunctions(p16)
	SpecializationUtil.registerFunction(p16, "loadAttachmentsFinished", AttacherJoints.loadAttachmentsFinished)
	SpecializationUtil.registerFunction(p16, "handleLowerImplementEvent", AttacherJoints.handleLowerImplementEvent)
	SpecializationUtil.registerFunction(p16, "handleLowerImplementByAttacherJointIndex", AttacherJoints.handleLowerImplementByAttacherJointIndex)
	SpecializationUtil.registerFunction(p16, "getAttachedImplements", AttacherJoints.getAttachedImplements)
	SpecializationUtil.registerFunction(p16, "getAttacherJoints", AttacherJoints.getAttacherJoints)
	SpecializationUtil.registerFunction(p16, "getAttacherJointByJointDescIndex", AttacherJoints.getAttacherJointByJointDescIndex)
	SpecializationUtil.registerFunction(p16, "getAttacherJointIndexByNode", AttacherJoints.getAttacherJointIndexByNode)
	SpecializationUtil.registerFunction(p16, "getImplementFromAttacherJointIndex", AttacherJoints.getImplementFromAttacherJointIndex)
	SpecializationUtil.registerFunction(p16, "getAttacherJointIndexFromObject", AttacherJoints.getAttacherJointIndexFromObject)
	SpecializationUtil.registerFunction(p16, "getAttacherJointDescFromObject", AttacherJoints.getAttacherJointDescFromObject)
	SpecializationUtil.registerFunction(p16, "getAttacherJointIndexFromImplementIndex", AttacherJoints.getAttacherJointIndexFromImplementIndex)
	SpecializationUtil.registerFunction(p16, "getObjectFromImplementIndex", AttacherJoints.getObjectFromImplementIndex)
	SpecializationUtil.registerFunction(p16, "updateAttacherJointGraphics", AttacherJoints.updateAttacherJointGraphics)
	SpecializationUtil.registerFunction(p16, "calculateAttacherJointMoveUpperLowerAlpha", AttacherJoints.calculateAttacherJointMoveUpperLowerAlpha)
	SpecializationUtil.registerFunction(p16, "doGroundHeightNodeCheck", AttacherJoints.doGroundHeightNodeCheck)
	SpecializationUtil.registerFunction(p16, "finishGroundHeightNodeCheck", AttacherJoints.finishGroundHeightNodeCheck)
	SpecializationUtil.registerFunction(p16, "groundHeightNodeCheckCallback", AttacherJoints.groundHeightNodeCheckCallback)
	SpecializationUtil.registerFunction(p16, "updateAttacherJointRotation", AttacherJoints.updateAttacherJointRotation)
	SpecializationUtil.registerFunction(p16, "updateAttacherJointRotationNodes", AttacherJoints.updateAttacherJointRotationNodes)
	SpecializationUtil.registerFunction(p16, "updateAttacherJointSettingsByObject", AttacherJoints.updateAttacherJointSettingsByObject)
	SpecializationUtil.registerFunction(p16, "setAttacherJointBottomArmWidth", AttacherJoints.setAttacherJointBottomArmWidth)
	SpecializationUtil.registerFunction(p16, "attachImplementFromInfo", AttacherJoints.attachImplementFromInfo)
	SpecializationUtil.registerFunction(p16, "attachImplement", AttacherJoints.attachImplement)
	SpecializationUtil.registerFunction(p16, "postAttachImplement", AttacherJoints.postAttachImplement)
	SpecializationUtil.registerFunction(p16, "createAttachmentJoint", AttacherJoints.createAttachmentJoint)
	SpecializationUtil.registerFunction(p16, "hardAttachImplement", AttacherJoints.hardAttachImplement)
	SpecializationUtil.registerFunction(p16, "hardDetachImplement", AttacherJoints.hardDetachImplement)
	SpecializationUtil.registerFunction(p16, "detachImplement", AttacherJoints.detachImplement)
	SpecializationUtil.registerFunction(p16, "detachImplementByObject", AttacherJoints.detachImplementByObject)
	SpecializationUtil.registerFunction(p16, "playAttachSound", AttacherJoints.playAttachSound)
	SpecializationUtil.registerFunction(p16, "playDetachSound", AttacherJoints.playDetachSound)
	SpecializationUtil.registerFunction(p16, "detachingIsPossible", AttacherJoints.detachingIsPossible)
	SpecializationUtil.registerFunction(p16, "attachAdditionalAttachment", AttacherJoints.attachAdditionalAttachment)
	SpecializationUtil.registerFunction(p16, "detachAdditionalAttachment", AttacherJoints.detachAdditionalAttachment)
	SpecializationUtil.registerFunction(p16, "getImplementIndexByJointDescIndex", AttacherJoints.getImplementIndexByJointDescIndex)
	SpecializationUtil.registerFunction(p16, "getImplementByJointDescIndex", AttacherJoints.getImplementByJointDescIndex)
	SpecializationUtil.registerFunction(p16, "getImplementIndexByObject", AttacherJoints.getImplementIndexByObject)
	SpecializationUtil.registerFunction(p16, "getImplementByObject", AttacherJoints.getImplementByObject)
	SpecializationUtil.registerFunction(p16, "callFunctionOnAllImplements", AttacherJoints.callFunctionOnAllImplements)
	SpecializationUtil.registerFunction(p16, "activateAttachments", AttacherJoints.activateAttachments)
	SpecializationUtil.registerFunction(p16, "deactivateAttachments", AttacherJoints.deactivateAttachments)
	SpecializationUtil.registerFunction(p16, "deactivateAttachmentsLights", AttacherJoints.deactivateAttachmentsLights)
	SpecializationUtil.registerFunction(p16, "setJointMoveDown", AttacherJoints.setJointMoveDown)
	SpecializationUtil.registerFunction(p16, "getJointMoveDown", AttacherJoints.getJointMoveDown)
	SpecializationUtil.registerFunction(p16, "getIsHardAttachAllowed", AttacherJoints.getIsHardAttachAllowed)
	SpecializationUtil.registerFunction(p16, "loadAttacherJointFromXML", AttacherJoints.loadAttacherJointFromXML)
	SpecializationUtil.registerFunction(p16, "onBottomArmToolbarI3DLoaded", AttacherJoints.onBottomArmToolbarI3DLoaded)
	SpecializationUtil.registerFunction(p16, "setSelectedImplementByObject", AttacherJoints.setSelectedImplementByObject)
	SpecializationUtil.registerFunction(p16, "getSelectedImplement", AttacherJoints.getSelectedImplement)
	SpecializationUtil.registerFunction(p16, "getCanToggleAttach", AttacherJoints.getCanToggleAttach)
	SpecializationUtil.registerFunction(p16, "getShowAttachControlBarAction", AttacherJoints.getShowAttachControlBarAction)
	SpecializationUtil.registerFunction(p16, "getAttachControlBarActionAccessible", AttacherJoints.getAttachControlBarActionAccessible)
	SpecializationUtil.registerFunction(p16, "detachAttachedImplement", AttacherJoints.detachAttachedImplement)
	SpecializationUtil.registerFunction(p16, "startAttacherJointCombo", AttacherJoints.startAttacherJointCombo)
	SpecializationUtil.registerFunction(p16, "registerSelfLoweringActionEvent", AttacherJoints.registerSelfLoweringActionEvent)
	SpecializationUtil.registerFunction(p16, "getIsAttachingAllowed", AttacherJoints.getIsAttachingAllowed)
	SpecializationUtil.registerFunction(p16, "getCanSteerAttachable", AttacherJoints.getCanSteerAttachable)
	SpecializationUtil.registerFunction(p16, "onAttacherJointsVehicleLoaded", AttacherJoints.onAttacherJointsVehicleLoaded)
	SpecializationUtil.registerFunction(p16, "getAttachableInfo", AttacherJoints.getAttachableInfo)
	SpecializationUtil.registerFunction(p16, "setAttacherJointBlocked", AttacherJoints.setAttacherJointBlocked)
end
function AttacherJoints.registerOverwrittenFunctions(p17)
	SpecializationUtil.registerOverwrittenFunction(p17, "raiseActive", AttacherJoints.raiseActive)
	SpecializationUtil.registerOverwrittenFunction(p17, "registerActionEvents", AttacherJoints.registerActionEvents)
	SpecializationUtil.registerOverwrittenFunction(p17, "removeActionEvents", AttacherJoints.removeActionEvents)
	SpecializationUtil.registerOverwrittenFunction(p17, "addToPhysics", AttacherJoints.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p17, "removeFromPhysics", AttacherJoints.removeFromPhysics)
	SpecializationUtil.registerOverwrittenFunction(p17, "getTotalMass", AttacherJoints.getTotalMass)
	SpecializationUtil.registerOverwrittenFunction(p17, "addChildVehicles", AttacherJoints.addChildVehicles)
	SpecializationUtil.registerOverwrittenFunction(p17, "getAirConsumerUsage", AttacherJoints.getAirConsumerUsage)
	SpecializationUtil.registerOverwrittenFunction(p17, "getRequiresPower", AttacherJoints.getRequiresPower)
	SpecializationUtil.registerOverwrittenFunction(p17, "addVehicleToAIImplementList", AttacherJoints.addVehicleToAIImplementList)
	SpecializationUtil.registerOverwrittenFunction(p17, "collectAIAgentAttachments", AttacherJoints.collectAIAgentAttachments)
	SpecializationUtil.registerOverwrittenFunction(p17, "setAIVehicleObstacleStateDirty", AttacherJoints.setAIVehicleObstacleStateDirty)
	SpecializationUtil.registerOverwrittenFunction(p17, "getDirectionSnapAngle", AttacherJoints.getDirectionSnapAngle)
	SpecializationUtil.registerOverwrittenFunction(p17, "getFillLevelInformation", AttacherJoints.getFillLevelInformation)
	SpecializationUtil.registerOverwrittenFunction(p17, "attachableAddToolCameras", AttacherJoints.attachableAddToolCameras)
	SpecializationUtil.registerOverwrittenFunction(p17, "attachableRemoveToolCameras", AttacherJoints.attachableRemoveToolCameras)
	SpecializationUtil.registerOverwrittenFunction(p17, "registerSelectableObjects", AttacherJoints.registerSelectableObjects)
	SpecializationUtil.registerOverwrittenFunction(p17, "getIsReadyForAutomatedTrainTravel", AttacherJoints.getIsReadyForAutomatedTrainTravel)
	SpecializationUtil.registerOverwrittenFunction(p17, "getIsAutomaticShiftingAllowed", AttacherJoints.getIsAutomaticShiftingAllowed)
	SpecializationUtil.registerOverwrittenFunction(p17, "loadDashboardGroupFromXML", AttacherJoints.loadDashboardGroupFromXML)
	SpecializationUtil.registerOverwrittenFunction(p17, "getIsDashboardGroupActive", AttacherJoints.getIsDashboardGroupActive)
	SpecializationUtil.registerOverwrittenFunction(p17, "loadAttacherJointHeightNode", AttacherJoints.loadAttacherJointHeightNode)
	SpecializationUtil.registerOverwrittenFunction(p17, "getIsAttacherJointHeightNodeActive", AttacherJoints.getIsAttacherJointHeightNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p17, "isDetachAllowed", AttacherJoints.isDetachAllowed)
	SpecializationUtil.registerOverwrittenFunction(p17, "getIsFoldAllowed", AttacherJoints.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p17, "getIsWheelFoliageDestructionAllowed", AttacherJoints.getIsWheelFoliageDestructionAllowed)
	SpecializationUtil.registerOverwrittenFunction(p17, "getAreControlledActionsAllowed", AttacherJoints.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p17, "getConnectionHoseConfigIndex", AttacherJoints.getConnectionHoseConfigIndex)
	SpecializationUtil.registerOverwrittenFunction(p17, "getPowerTakeOffConfigIndex", AttacherJoints.getPowerTakeOffConfigIndex)
end
function AttacherJoints.registerEventListeners(p18)
	SpecializationUtil.registerEventListener(p18, "onPreLoad", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onLoad", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onPostLoad", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onLoadFinished", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onPreDelete", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onDelete", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onReadStream", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onWriteStream", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onUpdate", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onUpdateEnd", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onUpdateTick", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onRegisterActionEvents", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onStateChange", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onLightsTypesMaskChanged", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onTurnLightStateChanged", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onBrakeLightsVisibilityChanged", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onReverseLightsVisibilityChanged", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onBeaconLightsVisibilityChanged", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onBrake", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onTurnedOn", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onTurnedOff", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onLeaveVehicle", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onActivate", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onDeactivate", AttacherJoints)
	SpecializationUtil.registerEventListener(p18, "onReverseDirectionChanged", AttacherJoints)
end
function AttacherJoints.onPreLoad(p19, _)
	local v20 = p19.spec_attacherJoints
	v20.attachedImplements = {}
	v20.selectedImplement = nil
	v20.lastInputAttacherCheckIndex = 0
end
function AttacherJoints.onLoad(p21, _)
	local v22 = p21.spec_attacherJoints
	v22.attacherJointCombos = {}
	v22.attacherJointCombos.duration = p21.xmlFile:getValue("vehicle.attacherJoints#comboDuration", 2) * 1000
	v22.attacherJointCombos.currentTime = 0
	v22.attacherJointCombos.direction = -1
	v22.attacherJointCombos.isRunning = false
	v22.attacherJointCombos.joints = {}
	v22.maxUpdateDistance = p21.xmlFile:getValue("vehicle.attacherJoints#maxUpdateDistance", AttacherJoints.DEFAULT_MAX_UPDATE_DISTANCE)
	v22.visualNodeToAttacherJoints = {}
	v22.hideVisualNodeToAttacherJoints = {}
	v22.attacherJoints = {}
	local v23 = 0
	while true do
		local v24 = string.format("vehicle.attacherJoints.attacherJoint(%d)", v23)
		if not p21.xmlFile:hasProperty(v24) then
			break
		end
		local v25 = {}
		if p21:loadAttacherJointFromXML(v25, p21.xmlFile, v24, v23) then
			local v26 = v22.attacherJoints
			table.insert(v26, v25)
			v25.index = #v22.attacherJoints
		end
		v23 = v23 + 1
	end
	v22.attachableInfo = {}
	v22.attachableInfo.attacherVehicle = nil
	v22.attachableInfo.attacherVehicleJointDescIndex = nil
	v22.attachableInfo.attachable = nil
	v22.attachableInfo.attachableJointDescIndex = nil
	v22.pendingAttachableInfo = {}
	v22.pendingAttachableInfo.minDistance = (1 / 0)
	v22.pendingAttachableInfo.minDistanceY = (1 / 0)
	v22.pendingAttachableInfo.attacherVehicle = nil
	v22.pendingAttachableInfo.attacherVehicleJointDescIndex = nil
	v22.pendingAttachableInfo.attachable = nil
	v22.pendingAttachableInfo.attachableJointDescIndex = nil
	v22.pendingAttachableInfo.warning = nil
	if p21.isClient then
		v22.samples = {}
		v22.isHydraulicSamplePlaying = false
		v22.samples.hydraulic = g_soundManager:loadSampleFromXML(p21.xmlFile, "vehicle.attacherJoints.sounds", "hydraulic", p21.baseDirectory, p21.components, 0, AudioGroup.VEHICLE, p21.i3dMappings, p21)
		v22.samples.attach = g_soundManager:loadSampleFromXML(p21.xmlFile, "vehicle.attacherJoints.sounds", "attach", p21.baseDirectory, p21.components, 1, AudioGroup.VEHICLE, p21.i3dMappings, p21)
		v22.samples.detach = g_soundManager:loadSampleFromXML(p21.xmlFile, "vehicle.attacherJoints.sounds", "detach", p21.baseDirectory, p21.components, 1, AudioGroup.VEHICLE, p21.i3dMappings, p21)
	end
	if p21.isClient and g_isDevelopmentVersion then
		for v27, v28 in ipairs(v22.attacherJoints) do
			if v22.samples.attach == nil and v28.sampleAttach == nil then
				Logging.xmlDevWarning(p21.xmlFile, "Missing attach sound for attacherjoint \'%d\'", v27)
			end
			if v28.rotationNode ~= nil and v22.samples.hydraulic == nil then
				Logging.xmlDevWarning(p21.xmlFile, "Missing hydraulic sound for attacherjoint \'%d\'", v27)
			end
		end
	end
	v22.showAttachNotAllowedText = 0
	v22.wasInAttachRange = false
	v22.texts = {}
	v22.texts.warningToolNotCompatible = g_i18n:getText("warning_toolNotCompatible")
	v22.texts.warningToolBrandNotCompatible = g_i18n:getText("warning_toolBrandNotCompatible")
	v22.texts.infoAttachNotAllowed = g_i18n:getText("info_attach_not_allowed")
	v22.texts.lowerImplementFirst = g_i18n:getText("warning_lowerImplementFirst")
	v22.texts.detachNotAllowed = g_i18n:getText("warning_detachNotAllowed")
	v22.texts.actionAttach = g_i18n:getText("action_attach")
	v22.texts.actionDetach = g_i18n:getText("action_detach")
	v22.texts.warningFoldingAttacherJoint = g_i18n:getText("warning_foldingNotWhileAttachedToAttacherJoint")
	v22.groundHeightNodeCheckData = {
		["isDirty"] = false,
		["minDistance"] = (1 / 0),
		["hit"] = false,
		["raycastDistance"] = 1,
		["currentRaycastDistance"] = 1,
		["heightNodes"] = {},
		["jointDesc"] = {},
		["index"] = -1,
		["lowerDistanceToGround"] = 0,
		["upperDistanceToGround"] = 0,
		["currentRaycastWorldPos"] = { 0, 0, 0 },
		["currentRaycastWorldDir"] = { 0, 0, 0 },
		["currentJointTransformPos"] = { 0, 0, 0 },
		["raycastWorldPos"] = { 0, 0, 0 },
		["raycastWorldDir"] = { 0, 0, 0 },
		["jointTransformPos"] = { 0, 0, 0 },
		["upperAlpha"] = 0,
		["lowerAlpha"] = 0
	}
	v22.dirtyFlag = p21:getNextDirtyFlag()
end
function AttacherJoints.onPostLoad(p29, p30)
	local v31 = p29.spec_attacherJoints
	for v32, v33 in pairs(v31.attacherJoints) do
		v33.jointOrigRot = { getRotation(v33.jointTransform) }
		v33.jointOrigTrans = { getTranslation(v33.jointTransform) }
		if v33.transNode ~= nil then
			v33.transNodeMinY = Utils.getNoNil(v33.transNodeMinY, v33.jointOrigTrans[2])
			v33.transNodeMaxY = Utils.getNoNil(v33.transNodeMaxY, v33.jointOrigTrans[2])
			local _, v34, _ = localToLocal(v33.jointTransform, v33.transNode, 0, 0, 0)
			v33.transNodeOffsetY = v34
			local _, v35, _ = localToLocal(getParent(v33.transNode), p29.rootNode, 0, v33.transNodeMinY, 0)
			v33.transNodeMinY = v35
			local _, v36, _ = localToLocal(getParent(v33.transNode), p29.rootNode, 0, v33.transNodeMaxY, 0)
			v33.transNodeMaxY = v36
		end
		if v33.transNodeDependentBottomArm ~= nil then
			for _, v37 in pairs(v31.attacherJoints) do
				if v37.bottomArm ~= nil and v37.bottomArm.rotationNode == v33.transNodeDependentBottomArm then
					v33.transNodeDependentBottomArmAttacherJoint = v37
				end
			end
			if v33.transNodeDependentBottomArmAttacherJoint == nil then
				Logging.xmlWarning(p29.xmlFile, "Unable to find dependent bottom arm \'%s\' in any attacher joint.", getName(v33.transNodeDependentBottomArm))
				v33.transNodeDependentBottomArm = nil
			end
		end
		if v33.bottomArm ~= nil then
			setRotation(v33.bottomArm.rotationNode, v33.bottomArm.rotX, v33.bottomArm.rotY, v33.bottomArm.rotZ)
			if p29.setMovingToolDirty ~= nil then
				p29:setMovingToolDirty(v33.bottomArm.rotationNode)
			end
		end
		if v33.rotationNode ~= nil then
			setRotation(v33.rotationNode, v33.rotX, v33.rotY, v33.rotZ)
		end
		if p29.getInputAttacherJoints ~= nil then
			v33.inputAttacherJointOffsets = {}
			for _, v38 in ipairs(p29:getInputAttacherJoints()) do
				local v39, v40, v41 = localDirectionToLocal(v33.jointTransform, v38.node, 0, 0, 1)
				local v42, v43, v44 = localDirectionToLocal(v33.jointTransform, v38.node, 0, 1, 0)
				local v45, v46, v47 = localDirectionToLocal(v33.jointTransform, v38.node, 1, 0, 0)
				local v48, v49, v50 = localToLocal(v33.jointTransform, v38.node, 0, 0, 0)
				local v51 = v33.inputAttacherJointOffsets
				table.insert(v51, {
					v48,
					v49,
					v50,
					v39,
					v40,
					v41,
					v42,
					v43,
					v44,
					v45,
					v46,
					v47
				})
			end
		end
		if p29.getAIRootNode ~= nil then
			local v52 = p29:getAIRootNode()
			local v53, v54, v55 = localDirectionToLocal(v33.jointTransform, v52, 0, 0, 1)
			local v56, v57, v58 = localDirectionToLocal(v33.jointTransform, v52, 0, 1, 0)
			local v59, v60, v61 = localDirectionToLocal(v33.jointTransform, v52, 1, 0, 0)
			local v62, v63, v64 = localToLocal(v33.jointTransform, v52, 0, 0, 0)
			v33.aiRootNodeOffset = {
				v62,
				v63,
				v64,
				v53,
				v54,
				v55,
				v56,
				v57,
				v58,
				v59,
				v60,
				v61
			}
		end
		if v33.comboTime ~= nil then
			local v65 = v31.attacherJointCombos.joints
			local v66 = {
				["jointIndex"] = v32
			}
			local v67 = v33.comboTime
			v66.time = math.clamp(v67, 0, 1) * v31.attacherJointCombos.duration
			table.insert(v65, v66)
		end
		p29:setAttacherJointBottomArmWidth(v32, nil)
	end
	if p30 ~= nil and (not p30.resetVehicles and v31.attacherJointCombos ~= nil) then
		local v68 = p30.xmlFile:getValue(p30.key .. ".attacherJoints#comboDirection")
		if v68 ~= nil then
			v31.attacherJointCombos.direction = v68
			if v68 == 1 then
				v31.attacherJointCombos.currentTime = v31.attacherJointCombos.duration
			end
		end
	end
	if #v31.attacherJoints == 0 then
		SpecializationUtil.removeEventListener(p29, "onReadStream", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onWriteStream", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onUpdate", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onUpdateEnd", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onStateChange", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onLightsTypesMaskChanged", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onTurnLightStateChanged", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onBrakeLightsVisibilityChanged", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onReverseLightsVisibilityChanged", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onBeaconLightsVisibilityChanged", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onBrake", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onTurnedOn", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onTurnedOff", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onLeaveVehicle", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onActivate", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onDeactivate", AttacherJoints)
		SpecializationUtil.removeEventListener(p29, "onReverseDirectionChanged", AttacherJoints)
	end
end
function AttacherJoints.onLoadFinished(p69, p70)
	local v71 = p69.spec_attacherJoints
	if p70 ~= nil and (not p70.resetVehicles or p70.keepPosition) then
		v71.attachmentDataToLoad = {}
		local v72 = p70.xmlFile
		for _, v73 in v72:iterator(p70.key .. ".attacherJoints.attachedImplement") do
			local v74 = {
				["jointIndex"] = v72:getValue(v73 .. "#jointIndex"),
				["attachedVehicleUniqueId"] = v72:getValue(v73 .. "#attachedVehicleUniqueId"),
				["inputIndex"] = v72:getValue(v73 .. "#inputJointIndex"),
				["moveDown"] = v72:getValue(v73 .. "#moveDown", false)
			}
			if v74.jointIndex ~= nil and (v74.attachedVehicleUniqueId ~= nil and v74.inputIndex ~= nil) then
				local v75 = g_currentMission.vehicleSystem:getVehicleByUniqueId(v74.attachedVehicleUniqueId)
				if v75 == nil then
					local v76 = v71.attachmentDataToLoad
					table.insert(v76, v74)
				else
					p69:attachImplement(v75, v74.inputIndex, v74.jointIndex, true, nil, v74.moveDown, true, true)
					p69:setJointMoveDown(v74.jointIndex, v74.moveDown, true)
				end
			end
		end
		for _, v77 in v72:iterator(p70.key .. ".attacherJoints.attacherJoint") do
			local v78 = v72:getValue(v77 .. "#jointIndex")
			local v79 = v72:getValue(v77 .. "#isBlocked")
			if v79 then
				v71.attacherJoints[v78].isBlocked = v79
			end
		end
		if #v71.attachmentDataToLoad > 0 then
			g_messageCenter:subscribe(MessageType.VEHICLE_LOADED, p69.onAttacherJointsVehicleLoaded, p69)
		end
	end
end
function AttacherJoints.onPreDelete(p80)
	local v81 = p80.spec_attacherJoints
	if v81.attachedImplements ~= nil then
		for v82 = #v81.attachedImplements, 1, -1 do
			local v83 = v81.attachedImplements[v82]
			if not v83.object:getIsAdditionalAttachment() then
				p80:detachImplementByObject(v83.object, true)
			end
		end
	end
end
function AttacherJoints.onDelete(p84)
	local v85 = p84.spec_attacherJoints
	if v85.attacherJoints ~= nil then
		for _, v86 in pairs(v85.attacherJoints) do
			g_soundManager:deleteSample(v86.sampleAttach)
			g_soundManager:deleteSample(v86.sampleDetach)
			if v86.topArm ~= nil then
				v86.topArm:delete()
				v86.topArm = nil
			end
			local v87 = v86.bottomArm
			if v87 ~= nil and v87.sharedLoadRequestIdToolbar ~= nil then
				g_i3DManager:releaseSharedI3DFile(v87.sharedLoadRequestIdToolbar)
				v87.sharedLoadRequestIdToolbar = nil
			end
		end
		g_soundManager:deleteSamples(v85.samples)
	end
end
function AttacherJoints.saveToXMLFile(p88, p89, p90, _)
	local v91 = p88.spec_attacherJoints
	if v91.attacherJointCombos ~= nil then
		p89:setValue(p90 .. "#comboDirection", v91.attacherJointCombos.direction)
	end
	if v91.attacherJoints ~= nil then
		for v92, v93 in ipairs(v91.attachedImplements) do
			if v93.object ~= nil then
				local v94 = string.format("%s.attachedImplement(%d)", p90, v92 - 1)
				local v95 = p88:getAttacherJointByJointDescIndex(v93.jointDescIndex)
				p89:setValue(v94 .. "#jointIndex", v93.jointDescIndex)
				p89:setValue(v94 .. "#moveDown", v95.moveDown)
				p89:setValue(v94 .. "#attachedVehicleUniqueId", v93.object:getUniqueId())
				p89:setValue(v94 .. "#inputJointIndex", v93.inputJointDescIndex)
			end
		end
		local v96 = 0
		for v97, v98 in pairs(v91.attacherJoints) do
			if v98.isBlocked then
				local v99 = string.format("%s.attacherJoint(%d)", p90, v96)
				p89:setValue(v99 .. "#jointIndex", v97)
				p89:setValue(v99 .. "#isBlocked", v98.isBlocked)
				v96 = v96 + 1
			end
		end
	end
end
function AttacherJoints.onReadStream(p100, p101, _)
	for v102 = 1, streamReadInt8(p101) do
		local v103 = NetworkUtil.readNodeObject(p101)
		local v104 = streamReadInt8(p101)
		local v105 = streamReadInt8(p101)
		local v106 = streamReadBool(p101)
		if v103 ~= nil and v103:getIsSynchronized() then
			p100:attachImplement(v103, v104, v105, true, v102, v106, true, true)
			p100:setJointMoveDown(v105, v106, true)
		end
	end
end
function AttacherJoints.onWriteStream(p107, p108, _)
	local v109 = p107.spec_attacherJoints
	streamWriteInt8(p108, #v109.attachedImplements)
	for v110 = 1, #v109.attachedImplements do
		local v111 = v109.attachedImplements[v110]
		local v112 = v111.object.spec_attachable.inputAttacherJointDescIndex
		local v113 = v111.jointDescIndex
		local v114 = v109.attacherJoints[v113].moveDown
		NetworkUtil.writeNodeObject(p108, v111.object)
		streamWriteInt8(p108, v112)
		streamWriteInt8(p108, v113)
		streamWriteBool(p108, v114)
	end
end
function AttacherJoints.onUpdate(p115, p116, _, _, _)
	local v117 = p115.spec_attacherJoints
	if p115.currentUpdateDistance < v117.maxUpdateDistance then
		for _, v118 in pairs(v117.attachedImplements) do
			if v118.object ~= nil and p115.updateLoopIndex == v118.object.updateLoopIndex then
				p115:updateAttacherJointGraphics(v118, p116)
				v118.object:updateInputAttacherJointGraphics(v118, p116)
			end
		end
	end
	if p115.isClient then
		local v119 = v117.showAttachNotAllowedText - p116
		v117.showAttachNotAllowedText = math.max(v119, 0)
		if v117.showAttachNotAllowedText > 0 then
			g_currentMission:addExtraPrintText(v117.texts.infoAttachNotAllowed)
		end
	end
	local v120 = v117.attachableInfo
	if Platform.gameplay.automaticAttach and p115.isServer or p115.isClient and (v117.actionEvents ~= nil and v117.actionEvents[InputAction.ATTACH] ~= nil) then
		if p115:getCanToggleAttach() then
			AttacherJoints.updateVehiclesInAttachRange(p115, AttacherJoints.MAX_ATTACH_DISTANCE_SQ, AttacherJoints.MAX_ATTACH_ANGLE, true)
			return
		end
		v120.attacherVehicle = nil
		v120.attacherVehicleJointDescIndex = nil
		v120.attachable = nil
		v120.attachableJointDescIndex = nil
	end
end
function AttacherJoints.onUpdateEnd(p121, p122, _, _, _)
	local v123 = p121.spec_attacherJoints
	for _, v124 in pairs(v123.attachedImplements) do
		if v124.object ~= nil and p121.updateLoopIndex == v124.object.updateLoopIndex then
			p121:updateAttacherJointGraphics(v124, p122)
		end
	end
end
function AttacherJoints.onUpdateTick(p125, p126, _, _, _)
	local v127 = p125.spec_attacherJoints
	local v128 = false
	for _, v129 in pairs(v127.attachedImplements) do
		if v129.object ~= nil then
			local v130 = v127.attacherJoints[v129.jointDescIndex]
			if not v129.object.spec_attachable.isHardAttached then
				if p125.isServer and v129.attachingIsInProgress then
					local v131 = true
					for v132 = 1, 3 do
						local v133 = v129.attachingRotLimit[v132]
						local v134 = v129.attachingTransLimit[v132]
						local v135 = v129.attachingRotLimit
						local v136 = v129.attachingRotLimit[v132] - v129.attachingRotLimitSpeed[v132] * p126
						v135[v132] = math.max(0, v136)
						local v137 = v129.attachingTransLimit
						local v138 = v129.attachingTransLimit[v132] - v129.attachingTransLimitSpeed[v132] * p126
						v137[v132] = math.max(0, v138)
						if v129.attachingRotLimit[v132] > 0 or (v129.attachingTransLimit[v132] > 0 or (v133 > 0 or v134 > 0)) then
							v131 = false
						end
					end
					v129.attachingIsInProgress = not v131
					if v131 then
						if v129.object.spec_attachable.attacherJoint.hardAttach and p125:getIsHardAttachAllowed(v129.jointDescIndex) then
							p125:hardAttachImplement(v129)
						end
						p125:postAttachImplement(v129)
					end
				end
				if not v129.attachingIsInProgress then
					local v139 = false
					if v130.allowsLowering and p125:getIsActive() then
						local v140 = v130.upperAlpha
						local v141 = v130.lowerAlpha
						if v130.moveDown then
							v140, v141 = p125:calculateAttacherJointMoveUpperLowerAlpha(v130, v129.object)
							local v142 = v130.moveDefaultTime
							local v143 = v140 - v141
							v130.moveTime = v142 * math.abs(v143)
						end
						local v144 = Utils.getMovedLimitedValue(v130.moveAlpha, v141, v140, v130.moveTime, p126, not v130.moveDown)
						if v144 ~= v130.moveAlpha or (v140 ~= v130.upperAlpha or v141 ~= v130.lowerAlpha) then
							v130.upperAlpha = v140
							v130.lowerAlpha = v141
							if v130.moveDown then
								local v145 = v130.moveAlpha - v130.lowerAlpha
								if math.abs(v145) < 0.05 then
									v130.isMoving = false
								end
							else
								local v146 = v130.moveAlpha - v130.upperAlpha
								if math.abs(v146) < 0.05 then
									v130.isMoving = false
								end
							end
							v128 = v130.isMoving
							v130.moveAlpha = v144
							if v130.upperAlpha - v130.lowerAlpha == 0 then
								v130.moveLimitAlpha = 1
							else
								v130.moveLimitAlpha = 1 - (v144 - v130.lowerAlpha) / (v130.upperAlpha - v130.lowerAlpha)
							end
							p125:updateAttacherJointRotationNodes(v130, v130.moveAlpha)
							p125:updateAttacherJointRotation(v130, v129.object)
							v139 = true
						end
					end
					if v139 or v130.jointFrameInvalid then
						v130.jointFrameInvalid = false
						if p125.isServer then
							setJointFrame(v130.jointIndex, 0, v130.jointTransform)
						end
					end
				end
				if p125.isServer then
					local v147 = v129.attachingIsInProgress
					if (v147 or v130.allowsLowering and v130.allowsJointLimitMovement) and (v130.jointIndex ~= nil and v130.jointIndex ~= 0) then
						if v147 or v129.object.spec_attachable.attacherJoint.allowsJointRotLimitMovement then
							local v148 = v130.moveLimitAlpha - v129.rotLimitThreshold
							local v149 = math.max(v148, 0) / (1 - v129.rotLimitThreshold)
							for v150 = 1, 3 do
								AttacherJoints.updateAttacherJointRotationLimit(v129, v130, v150, v147, v149)
							end
						end
						if v147 or v129.object.spec_attachable.attacherJoint.allowsJointTransLimitMovement then
							local v151 = v130.moveLimitAlpha - v129.transLimitThreshold
							local v152 = math.max(v151, 0) / (1 - v129.transLimitThreshold)
							for v153 = 1, 3 do
								AttacherJoints.updateAttacherJointTranslationLimit(v129, v130, v153, v147, v152)
							end
						end
					end
				end
			end
		end
	end
	if p125.isClient and v127.samples.hydraulic ~= nil then
		for v154 = 1, #v127.attacherJoints do
			local v155 = v127.attacherJoints[v154]
			if v155.bottomArm ~= nil and v155.bottomArm.bottomArmInterpolating then
				v128 = true
			end
		end
		if v128 then
			if not v127.isHydraulicSamplePlaying then
				g_soundManager:playSample(v127.samples.hydraulic)
				v127.isHydraulicSamplePlaying = true
			end
		elseif v127.isHydraulicSamplePlaying then
			g_soundManager:stopSample(v127.samples.hydraulic)
			v127.isHydraulicSamplePlaying = false
		end
	end
	local v156 = v127.attacherJointCombos
	if v156 ~= nil and v156.isRunning then
		for _, v157 in pairs(v156.joints) do
			local v158 = nil
			if v156.direction == 1 and v156.currentTime >= v157.time then
				v158 = true
			elseif v156.direction == -1 and v156.currentTime <= v156.duration - v157.time then
				v158 = false
			end
			if v158 ~= nil then
				local v159 = p125:getImplementFromAttacherJointIndex(v157.jointIndex)
				if v159 ~= nil and v159.object.setLoweredAll ~= nil then
					v159.object:setLoweredAll(v158, v157.jointIndex)
				end
			end
		end
		if v156.direction == -1 and v156.currentTime == 0 or v156.direction == 1 and v156.currentTime == v156.duration then
			v156.isRunning = false
		end
		local v160 = v156.currentTime + p126 * v156.direction
		local v161 = v156.duration
		v156.currentTime = math.clamp(v160, 0, v161)
	end
	AttacherJoints.updateActionEvents(p125)
	if Platform.gameplay.automaticAttach and (p125.isServer and p125:getCanToggleAttach()) then
		local v162 = v127.attachableInfo
		if v162.attachable == nil or (v127.wasInAttachRange or v162.attacherVehicle ~= p125) then
			if v162.attachable == nil and v127.wasInAttachRange then
				v127.wasInAttachRange = false
			end
		elseif not (p125.isReconfigurating or v162.attachable.isReconfigurating) then
			local v163, v164 = v162.attachable:isAttachAllowed(p125:getActiveFarm(), v162.attacherVehicle)
			if v163 then
				if v127.wasInAttachRange == nil then
					v127.wasInAttachRange = true
				else
					p125:attachImplementFromInfo(v162)
				end
			end
			if v164 ~= nil then
				g_currentMission:showBlinkingWarning(v164, 2000)
				return
			end
		end
	end
end
function AttacherJoints.loadAttachmentsFinished(p165)
	if p165.rootVehicle == p165 and p165.loadedSelectedObjectIndex ~= nil then
		local v166 = p165.selectableObjects[p165.loadedSelectedObjectIndex]
		if v166 ~= nil then
			p165:setSelectedObject(v166, p165.loadedSubSelectedObjectIndex or 1)
		end
		p165.loadedSelectedObjectIndex = nil
		p165.loadedSubSelectedObjectIndex = nil
	end
end
function AttacherJoints.handleLowerImplementEvent(p167, p168, p169)
	local v170 = p167:getSelectedVehicle()
	if p168 == nil and v170 == p167 then
		local v171 = p167.spec_attacherJoints
		if #v171.attachedImplements == 1 then
			p168 = v171.attachedImplements[1].object
		end
	end
	local v172 = p167:getImplementByObject(p168 or v170)
	if v172 ~= nil then
		local v173 = v172.object
		if v173 ~= nil and v173.getAttacherVehicle ~= nil then
			local v174 = v173:getAttacherVehicle()
			if v174 ~= nil then
				v174:handleLowerImplementByAttacherJointIndex(v174:getAttacherJointIndexFromObject(v173), p169)
			end
		end
	end
end
function AttacherJoints.handleLowerImplementByAttacherJointIndex(p175, p176, p177)
	if p176 ~= nil then
		local v178 = p175:getImplementByJointDescIndex(p176)
		if v178 ~= nil then
			local v179 = v178.object
			local v180 = p175:getAttacherJoints()[p176]
			local v181, v182 = v179:getAllowsLowering()
			if v181 and v180.allowsLowering then
				if p177 == nil then
					p177 = not v180.moveDown
				end
				p175:setJointMoveDown(v178.jointDescIndex, p177, false)
				return
			end
			if not v181 and v182 ~= nil then
				g_currentMission:showBlinkingWarning(v182, 2000)
			end
		end
	end
end
function AttacherJoints.getAttachedImplements(p183)
	return p183.spec_attacherJoints.attachedImplements
end
function AttacherJoints.getAttacherJoints(p184)
	return p184.spec_attacherJoints.attacherJoints
end
function AttacherJoints.getAttacherJointByJointDescIndex(p185, p186)
	return p185.spec_attacherJoints.attacherJoints[p186]
end
function AttacherJoints.getAttacherJointIndexByNode(p187, p188)
	local v189 = p187.spec_attacherJoints
	for v190 = 1, #v189.attacherJoints do
		if v189.attacherJoints[v190].jointTransform == p188 then
			return v190
		end
	end
	return nil
end
function AttacherJoints.getImplementFromAttacherJointIndex(p191, p192)
	local v193 = p191.spec_attacherJoints
	for _, v194 in pairs(v193.attachedImplements) do
		if v194.jointDescIndex == p192 then
			return v194
		end
	end
	return nil
end
function AttacherJoints.getAttacherJointIndexFromObject(p195, p196)
	local v197 = p195.spec_attacherJoints
	for _, v198 in pairs(v197.attachedImplements) do
		if v198.object == p196 then
			return v198.jointDescIndex
		end
	end
	return nil
end
function AttacherJoints.getAttacherJointDescFromObject(p199, p200)
	local v201 = p199.spec_attacherJoints
	for _, v202 in pairs(v201.attachedImplements) do
		if v202.object == p200 then
			return v201.attacherJoints[v202.jointDescIndex]
		end
	end
	return nil
end
function AttacherJoints.getAttacherJointIndexFromImplementIndex(p203, p204)
	local v205 = p203.spec_attacherJoints.attachedImplements[p204]
	if v205 == nil then
		return nil
	else
		return v205.jointDescIndex
	end
end
function AttacherJoints.getObjectFromImplementIndex(p206, p207)
	local v208 = p206.spec_attacherJoints.attachedImplements[p207]
	if v208 == nil then
		return nil
	else
		return v208.object
	end
end
function AttacherJoints.updateAttacherJointGraphics(p209, p210, p211, p212)
	local v213 = p209.spec_attacherJoints
	if p210.object ~= nil then
		local v214 = v213.attacherJoints[p210.jointDescIndex]
		local v215 = p210.object:getActiveInputAttacherJoint()
		if v214.topArm ~= nil and (not p210.attachingIsInProgress and v215.topReferenceNode ~= nil) then
			v214.topArm:update(p211, v215.topReferenceNode)
		end
		if v214.bottomArm ~= nil then
			local v216, v217, v218 = getWorldTranslation(v214.bottomArm.rotationNode)
			local v219, v220, v221 = getWorldTranslation(v215.node)
			local v222, v223, v224 = worldDirectionToLocal(getParent(v214.bottomArm.rotationNode), v219 - v216, v220 - v217, v221 - v218)
			local v225 = MathUtil.vector3Length(v222, v223, v224)
			local v226, v227
			if math.abs(v223) > 0.99 * v225 then
				v226 = 0
				if v223 > 0 then
					v227 = 1
				else
					v227 = -1
				end
			else
				v226 = 1
				v227 = 0
			end
			local v228 = v223 * v214.bottomArm.zScale
			local v229 = v224 * v214.bottomArm.zScale
			local v230 = v214.bottomArm.lockDirection and 0 or v222 * v214.bottomArm.zScale
			local v231 = false
			local v232 = v214.bottomArm.lastDirection[1] - v230
			if math.abs(v232) <= 0.001 then
				local v233 = v214.bottomArm.lastDirection[2] - v228
				if math.abs(v233) <= 0.001 then
					local v234 = v214.bottomArm.lastDirection[3] - v229
					if math.abs(v234) <= 0.001 then
						::l17::
						if p210.attachingIsInProgress then
							if v231 then
								if p210.bottomArmInterpolating then
									local v235, v236, v237 = getRotation(v214.bottomArm.rotationNodeDir)
									local v238 = p210.bottomArmInterpolator:getTarget()
									v238[1] = v235
									v238[2] = v236
									v238[3] = v237
									p210.bottomArmInterpolator:updateSpeed()
								else
									local v239 = ValueInterpolator.new(v214.bottomArm.interpolatorKey, v214.bottomArm.interpolatorGet, v214.bottomArm.interpolatorSet, { getRotation(v214.bottomArm.rotationNodeDir) }, AttacherJoints.SMOOTH_ATTACH_TIME)
									if v239 ~= nil then
										v239:setDeleteListenerObject(p209)
										v239:setFinishedFunc(v214.bottomArm.interpolatorFinished, v214.bottomArm)
										v214.bottomArm.bottomArmInterpolating = true
										p210.bottomArmInterpolating = true
										p210.bottomArmInterpolator = v239
									end
								end
							end
						elseif p210.bottomArmInterpolator ~= nil then
							ValueInterpolator.removeInterpolator(v214.bottomArm.interpolatorKey)
							v214.bottomArm.bottomArmInterpolating = false
							p210.bottomArmInterpolating = false
							p210.bottomArmInterpolator = nil
						end
						if v214.bottomArm.translationNode ~= nil and not p210.attachingIsInProgress then
							if v214.bottomArm.updateReferenceDistance then
								v214.bottomArm.referenceDistance = calcDistanceFrom(v214.bottomArm.referenceNode, v214.bottomArm.translationNode)
							end
							setTranslation(v214.bottomArm.translationNode, 0, 0, (v225 - v214.bottomArm.referenceDistance) * v214.bottomArm.zScale)
						end
						if v214.bottomArm.jointPositionNode ~= nil and not p210.attachingIsInProgress then
							setWorldTranslation(v214.bottomArm.jointPositionNode, v219, v220, v221)
							if p209.setMovingToolDirty ~= nil then
								p209:setMovingToolDirty(v214.bottomArm.jointPositionNode, p212, p211)
							end
						end
						if p209.setMovingToolDirty ~= nil then
							p209:setMovingToolDirty(v214.bottomArm.rotationNode, p212, p211)
						end
						if v215.needsToolbar and v214.bottomArm.toolbarNode ~= nil then
							local v240 = getParent(v214.bottomArm.toolbarNode)
							local _, v241, v242 = localDirectionToLocal(v215.node, v214.rootNode, 1, 0, 0)
							local v243, v244, v245 = localDirectionToLocal(v214.rootNode, v240, 0, v241, v242)
							local _, v246, v247 = localDirectionToLocal(v215.node, v214.rootNode, 0, 1, 0)
							local v248, v249, v250 = localDirectionToLocal(v214.rootNode, v240, 0, v246, v247)
							setDirection(v214.bottomArm.toolbarNode, v243, v244, v245, v248, v249, v250)
						end
						goto l2
					end
				end
			end
			if p210.attachingIsInProgress then
				setDirection(v214.bottomArm.rotationNodeDir, v230, v228, v229, 0, v226, v227)
			else
				setDirection(v214.bottomArm.rotationNode, v230, v228, v229, 0, v226, v227)
			end
			v214.bottomArm.lastDirection[1] = v230
			v214.bottomArm.lastDirection[2] = v228
			v214.bottomArm.lastDirection[3] = v229
			v231 = true
			goto l17
		end
	end
	::l2::
end
function AttacherJoints.calculateAttacherJointMoveUpperLowerAlpha(p251, p252, p253, p254)
	local v255 = p253.spec_attachable.attacherJoint
	if p252.allowsLowering then
		local v256 = p252.lowerDistanceToGround
		local v257 = p252.upperDistanceToGround
		local v258 = nil
		local v259 = nil
		if #v255.heightNodes > 0 and p252.rotationNode ~= nil then
			local v260 = p251.spec_attacherJoints.groundHeightNodeCheckData
			if p254 then
				v260.heightNodes = v255.heightNodes
				v260.jointDesc = p252
				v260.objectAttacherJoint = v255
				v260.object = p253
				v260.index = -1
				v256 = p252.lowerDistanceToGround
				v257 = p252.upperDistanceToGround
				for v261 = 1, #v255.heightNodes do
					local v262 = v255.heightNodes[v261]
					local v263, v264, v265 = localToLocal(v262.node, v262.attacherJointNode, 0, 0, 0)
					p251:updateAttacherJointRotationNodes(p252, 1)
					local v266 = setRotation
					local v267 = p252.jointTransform
					local v268 = p252.jointOrigRot
					v266(v267, unpack(v268))
					local _, v269, _ = localToLocal(p252.jointTransform, p252.rootNode, 0, 0, 0)
					local v270 = p252.lowerDistanceToGround - v269
					local _, v271, _ = localToLocal(p252.jointTransform, p252.rootNode, v263, v264, v265)
					v256 = v271 + v270
					p251:updateAttacherJointRotationNodes(p252, 0)
					local _, v272, _ = localToLocal(p252.jointTransform, p252.rootNode, 0, 0, 0)
					local v273 = p252.upperDistanceToGround - v272
					local _, v274, _ = localToLocal(p252.jointTransform, p252.rootNode, v263, v264, v265)
					v257 = v274 + v273
				end
			elseif (p252.moveAlpha or 0) > 0 then
				if v260.index == -1 then
					v260.index = 1
					v260.minDistance = (1 / 0)
					v260.hit = false
					p251:doGroundHeightNodeCheck()
				end
				if v260.isDirty then
					v260.isDirty = false
					p251:doGroundHeightNodeCheck()
				end
				if p252.upperAlpha == nil or v260.upperAlpha == nil then
					v258 = v260.upperAlpha
					v259 = v260.lowerAlpha
				else
					v258 = p252.upperAlpha * 0.9 + v260.upperAlpha * 0.1
					v259 = p252.lowerAlpha * 0.9 + v260.lowerAlpha * 0.1
				end
			else
				v258 = p252.upperAlpha
				v259 = p252.lowerAlpha
			end
		end
		if v257 == v256 then
			v258 = v258 or 1
			v259 = v259 or 1
		else
			if not v258 then
				local v275 = (v255.upperDistanceToGround - v257) / (v256 - v257)
				v258 = math.clamp(v275, 0, 1)
			end
			if not v259 then
				local v276 = (v255.lowerDistanceToGround - v257) / (v256 - v257)
				v259 = math.clamp(v276, 0, 1)
			end
		end
		if p254 then
			local v277 = p251.spec_attacherJoints.groundHeightNodeCheckData
			v277.upperAlpha = v258
			v277.lowerAlpha = v259
		end
		if v255.allowsLowering and p252.allowsLowering then
			return v258, v259
		elseif v255.isDefaultLowered then
			return v259, v259
		else
			return v258, v258
		end
	elseif v255.isDefaultLowered then
		return 1, 1
	else
		return 0, 0
	end
end
function AttacherJoints.doGroundHeightNodeCheck(p278)
	local v279 = p278.spec_attacherJoints.groundHeightNodeCheckData
	local v280 = v279.heightNodes[v279.index]
	if v280 == nil or not v279.object:getIsAttacherJointHeightNodeActive(v280) then
		v279.index = v279.index + 1
		if v279.index > #v279.heightNodes then
			p278:finishGroundHeightNodeCheck()
		else
			v279.isDirty = true
		end
	else
		local v281, v282, v283 = localToLocal(v280.node, v280.attacherJointNode, 0, 0, 0)
		p278:updateAttacherJointRotationNodes(v279.jointDesc, 1)
		local v284, v285, v286 = localToWorld(v279.jointDesc.jointTransformOrig, v281, v282, v283)
		p278:updateAttacherJointRotationNodes(v279.jointDesc, 0)
		local v287, v288, v289 = localToWorld(v279.jointDesc.jointTransformOrig, v281, v282, v283)
		local v290 = v284 - v287
		local v291 = v285 - v288
		local v292 = v286 - v289
		local v293 = MathUtil.vector3Length(v290, v291, v292)
		local v294, v295, v296 = MathUtil.vector3Normalize(v290, v291, v292)
		v279.currentRaycastDistance = v293
		v279.currentRaycastWorldPos[1] = v287
		v279.currentRaycastWorldPos[2] = v288
		v279.currentRaycastWorldPos[3] = v289
		v279.currentRaycastWorldDir[1] = v294
		v279.currentRaycastWorldDir[2] = v295
		v279.currentRaycastWorldDir[3] = v296
		local v297 = v279.currentJointTransformPos
		local v298 = v279.currentJointTransformPos
		local v299 = v279.currentJointTransformPos
		local v300, v301, v302 = getWorldTranslation(v279.jointDesc.jointTransform)
		v297[1] = v300
		v298[2] = v301
		v299[3] = v302
		local v303 = v293 + v279.objectAttacherJoint.lowerDistanceToGround
		local v304 = v279.minDistance
		v279.minDistance = math.min(v304, v303)
		raycastAllAsync(v287, v288, v289, v294, v295, v296, v303, "groundHeightNodeCheckCallback", p278, CollisionFlag.TERRAIN)
		p278:updateAttacherJointRotationNodes(v279.jointDesc, v279.jointDesc.moveAlpha or 0)
		return
	end
end
function AttacherJoints.finishGroundHeightNodeCheck(p305)
	local v306 = p305.spec_attacherJoints.groundHeightNodeCheckData
	if v306.minDistance ~= (1 / 0) then
		if not v306.hit then
			v306.raycastDistance = v306.currentRaycastDistance
			v306.raycastWorldPos[1] = v306.currentRaycastWorldPos[1]
			v306.raycastWorldPos[2] = v306.currentRaycastWorldPos[2]
			v306.raycastWorldPos[3] = v306.currentRaycastWorldPos[3]
			v306.raycastWorldDir[1] = v306.currentRaycastWorldDir[1]
			v306.raycastWorldDir[2] = v306.currentRaycastWorldDir[2]
			v306.raycastWorldDir[3] = v306.currentRaycastWorldDir[3]
			v306.jointTransformPos[1] = v306.currentJointTransformPos[1]
			v306.jointTransformPos[2] = v306.currentJointTransformPos[2]
			v306.jointTransformPos[3] = v306.currentJointTransformPos[3]
		end
		local v307 = (v306.minDistance - v306.objectAttacherJoint.upperDistanceToGround) / v306.raycastDistance
		local v308 = (v306.minDistance - v306.objectAttacherJoint.lowerDistanceToGround) / v306.raycastDistance
		local v309 = v306.raycastWorldPos[1]
		local v310 = v306.raycastWorldPos[2]
		local v311 = v306.raycastWorldPos[3]
		local v312 = v306.raycastWorldDir[1]
		local v313 = v306.raycastWorldDir[2]
		local v314 = v306.raycastWorldDir[3]
		local v315 = v309 + v312 * v306.raycastDistance * v308
		local v316 = v310 + v313 * v306.raycastDistance * v308
		local v317 = v311 + v314 * v306.raycastDistance * v308
		local v318 = v306.jointTransformPos[1]
		local v319 = v306.jointTransformPos[2]
		local v320 = v306.jointTransformPos[3]
		local v321 = MathUtil.vector3Length(v315 - v318, v316 - v319, v317 - v320)
		local v322 = MathUtil.vector3Length(v309 - v318, v310 - v319, v311 - v320) - v321
		local _, v323, _ = worldToLocal(p305.rootNode, v315, v316, v317)
		local _, v324, _ = worldToLocal(p305.rootNode, v309, v310, v311)
		local v325 = v322 / (v324 - v323)
		local v326 = math.atan(v325)
		local v327 = v322 * math.sin(v326)
		local v328 = (v306.minDistance - v306.objectAttacherJoint.lowerDistanceToGround - v327) / v306.raycastDistance
		v306.lowerAlpha = math.clamp(v328, 0, 1)
		v306.upperAlpha = math.clamp(v307, 0, 1)
	end
	v306.index = -1
end
function AttacherJoints.groundHeightNodeCheckCallback(p329, p330, _, _, _, p331, _, _, _, _, _, p332)
	if not p329.isDeleted then
		local v333 = p329.spec_attacherJoints.groundHeightNodeCheckData
		if p330 ~= 0 then
			if getRigidBodyType(p330) == RigidBodyType.STATIC then
				if p331 < v333.minDistance then
					v333.raycastDistance = v333.currentRaycastDistance
					v333.minDistance = p331
					v333.hit = true
					v333.raycastWorldPos[1] = v333.currentRaycastWorldPos[1]
					v333.raycastWorldPos[2] = v333.currentRaycastWorldPos[2]
					v333.raycastWorldPos[3] = v333.currentRaycastWorldPos[3]
					v333.raycastWorldDir[1] = v333.currentRaycastWorldDir[1]
					v333.raycastWorldDir[2] = v333.currentRaycastWorldDir[2]
					v333.raycastWorldDir[3] = v333.currentRaycastWorldDir[3]
					v333.jointTransformPos[1] = v333.currentJointTransformPos[1]
					v333.jointTransformPos[2] = v333.currentJointTransformPos[2]
					v333.jointTransformPos[3] = v333.currentJointTransformPos[3]
				end
			elseif not p332 then
				return true
			end
		end
		v333.index = v333.index + 1
		if v333.index > #v333.heightNodes then
			p329:finishGroundHeightNodeCheck()
		else
			v333.isDirty = true
		end
		return false
	end
end
function AttacherJoints.updateAttacherJointRotation(_, p334, p335)
	local v336 = p335.spec_attachable.attacherJoint
	local v337 = MathUtil.lerp(v336.upperRotationOffset, v336.lowerRotationOffset, p334.moveAlpha) - MathUtil.lerp(p334.upperRotationOffset, p334.lowerRotationOffset, p334.moveAlpha)
	local v338 = setRotation
	local v339 = p334.jointTransform
	local v340 = p334.jointOrigRot
	v338(v339, unpack(v340))
	rotateAboutLocalAxis(p334.jointTransform, v337, 0, 0, 1)
end
function AttacherJoints.updateAttacherJointRotationNodes(_, p341, p342)
	if p341.rotationNode ~= nil then
		setRotation(p341.rotationNode, MathUtil.vector3ArrayLerp(p341.upperRotation, p341.lowerRotation, p342))
	end
	if p341.rotationNode2 ~= nil then
		setRotation(p341.rotationNode2, MathUtil.vector3ArrayLerp(p341.upperRotation2, p341.lowerRotation2, p342))
	end
end
function AttacherJoints.updateAttacherJointSettingsByObject(p343, p344, p345, p346, p347)
	local v348 = p343:getAttacherJointDescFromObject(p344)
	local v349 = p343:getImplementByObject(p344)
	local v350 = p344:getActiveInputAttacherJoint()
	if v348 ~= nil and v349 ~= nil then
		if p345 then
			for v351 = 1, 3 do
				AttacherJoints.updateAttacherJointLimits(v349, v348, v350, v351)
				AttacherJoints.updateAttacherJointRotationLimit(v349, v348, v351, false, v348.moveLimitAlpha)
				AttacherJoints.updateAttacherJointTranslationLimit(v349, v348, v351, false, v348.moveLimitAlpha)
			end
		end
		if p346 then
			p343:updateAttacherJointRotation(v348, p344)
			if p343.isServer then
				setJointFrame(v348.jointIndex, 0, v348.jointTransform)
			end
		end
		if p347 then
			local v352, v353 = p343:calculateAttacherJointMoveUpperLowerAlpha(v348, p344)
			local v354 = v348.moveDefaultTime
			local v355 = v352 - v353
			v348.moveTime = v354 * math.abs(v355)
			v348.upperAlpha = v352
			v348.lowerAlpha = v353
		end
	end
end
function AttacherJoints.setAttacherJointBottomArmWidth(p356, p357, p358)
	local v359 = p356.spec_attacherJoints.attacherJoints[p357]
	local v360 = v359.bottomArm
	if v360 ~= nil and v360.variableWidthAvailable ~= nil then
		p358 = p358 or v360.defaultWidth
		if v360.armLeftReferenceNode == nil or v360.armRightReferenceNode == nil then
			local _, v361, v362 = getTranslation(v360.armLeft)
			setTranslation(v360.armLeft, p358 * 0.5, v361, v362)
			local _, v363, v364 = getTranslation(v360.armRight)
			setTranslation(v360.armRight, -p358 * 0.5, v363, v364)
		else
			local v365, v366, v367 = localDirectionToWorld(v360.rotationNode, 0, 1, 0)
			local v368, v369, v370 = localToWorld(v360.referenceNode, p358 * 0.5, 0, 0)
			local v371, v372, v373 = getWorldTranslation(v360.armLeft)
			local v374, v375, v376 = MathUtil.vector3Normalize(v368 - v371, v369 - v372, v370 - v373)
			I3DUtil.setWorldDirection(v360.armLeft, v374, v375, v376, v365, v366, v367, nil, nil, nil)
			local v377, v378, v379 = localToWorld(v360.referenceNode, -p358 * 0.5, 0, 0)
			local v380, v381, v382 = getWorldTranslation(v360.armRight)
			local v383, v384, v385 = MathUtil.vector3Normalize(v377 - v380, v378 - v381, v379 - v382)
			I3DUtil.setWorldDirection(v360.armRight, v383, v384, v385, v365, v366, v367, nil, nil, nil)
			local _, _, v386 = localToLocal(v360.armLeftReferenceNode, v360.rotationNode, 0, 0, 0)
			local _, _, v387 = localToLocal(v360.armRightReferenceNode, v360.rotationNode, 0, 0, 0)
			v360.referenceDistance = (math.abs(v386) + math.abs(v387)) * 0.5
			setTranslation(v360.referenceNode, 0, 0, -v360.referenceDistance)
		end
		if p356.setMovingToolDirty ~= nil then
			p356:setMovingToolDirty(v360.rotationNode)
		end
	end
	if v360 ~= nil and v360.toolbars ~= nil then
		local v388 = AttacherJoints.getClosestLowerLinkCategoryIndex(p358 or v360.defaultWidth)
		for v389, v390 in ipairs(v359.bottomArm.toolbars) do
			setVisibility(v390, v388 == v389 - 1)
		end
	end
end
function AttacherJoints.attachImplementFromInfo(_, p391)
	if p391.attachable ~= nil then
		local v392 = p391.attacherVehicle.spec_attacherJoints.attacherJoints
		if v392[p391.attacherVehicleJointDescIndex].jointIndex == 0 then
			if p391.attachable:getActiveInputAttacherJointDescIndex() ~= nil then
				if not p391.attachable:getAllowMultipleAttachments() then
					return false
				end
				p391.attachable:resolveMultipleAttachments()
			end
			if GS_IS_MOBILE_VERSION then
				local v393 = v392[p391.attacherVehicleJointDescIndex].attacherJointDirection
				if v393 ~= nil then
					local v394 = p391.attacherVehicle:getAttachedImplements()
					for v395 = 1, #v394 do
						if v393 == v392[v394[v395].jointDescIndex].attacherJointDirection then
							return false
						end
					end
				end
			end
			p391.attacherVehicle:attachImplement(p391.attachable, p391.attachableJointDescIndex, p391.attacherVehicleJointDescIndex)
			return true
		end
	end
	return false
end
function AttacherJoints.attachImplement(p396, p397, p398, p399, p400, p401, p402, p403, p404)
	local v405 = p396.spec_attacherJoints
	local v406 = p397.spec_attachable.inputAttacherJoints[p398]
	local v407 = v405.attacherJoints[p399]
	if p396:getAttacherJointIndexFromObject(p397) ~= nil then
		Logging.warning("Cannot attach object \'%s\' to vehicle \'%s\' between joints \'%d\' and \'%d\'. Joint already in use!", p397.configFileName, p396.configFileName, p399, p398)
		return
	end
	SpecializationUtil.raiseEvent(p396, "onPreAttachImplement", p397, p398, p399)
	p397:preAttach(p396, p398, p399, p404)
	if not v407.delayedObjectChangesOnAttach then
		ObjectChangeUtil.setObjectChanges(v407.changeObjects, true, p396, p396.setMovingToolDirty)
	end
	for v408 = 1, #v407.visualNodes do
		local v409 = v407.visualNodes[v408]
		setVisibility(v409, true)
	end
	for v410 = 1, #v407.hideVisuals do
		local v411 = v407.hideVisuals[v410]
		local v412 = true
		local v413 = v405.visualNodeToAttacherJoints[v411]
		if v413 ~= nil then
			for v414 = 1, #v413 do
				if v413[v414].jointIndex ~= 0 then
					v412 = false
				end
			end
		end
		if v412 then
			setVisibility(v411, false)
		end
	end
	if v406.bottomArm ~= nil and (v407.bottomArm ~= nil and v407.bottomArm.variableWidthAvailable) then
		local v415 = nil
		local v416 = nil
		for v417 = #v406.bottomArm.widths, 1, -1 do
			local v418 = v406.bottomArm.widths[v417]
			if v407.bottomArm.minWidth <= v418 and v418 <= v407.bottomArm.maxWidth then
				v416 = v417
				v415 = v418
				break
			end
		end
		if v415 == nil then
			for v419 = 1, #v406.bottomArm.widths do
				local v420 = v406.bottomArm.widths[v419]
				if v420 < v407.bottomArm.minWidth then
					v415 = v407.bottomArm.minWidth
				elseif v407.bottomArm.maxWidth < v420 then
					v415 = v407.bottomArm.maxWidth
				end
			end
			v415 = v415 or v407.bottomArm.maxWidth
		end
		if v416 ~= nil then
			p397:setToolBottomArmWidthByIndex(p398, v416)
		end
		p396:setAttacherJointBottomArmWidth(p399, v415)
	end
	local v421, v422 = p396:calculateAttacherJointMoveUpperLowerAlpha(v407, p397, true)
	local v423 = v407.moveDefaultTime
	local v424 = v421 - v422
	v407.moveTime = v423 * math.abs(v424)
	if p402 == nil then
		p402 = true
		if v406.allowsLowering and v407.allowsLowering then
			p396:updateAttacherJointRotationNodes(v407, v421)
			local v425 = calcDistanceSquaredFrom(v407.jointTransform, v406.node)
			p396:updateAttacherJointRotationNodes(v407, v422)
			if v425 < calcDistanceSquaredFrom(v407.jointTransform, v406.node) * 1.1 then
				p402 = false
			end
			if v406.useFoldingLoweredState then
				p402 = p397:getIsLowered()
			end
		elseif not v406.isDefaultLowered then
			p402 = false
		end
	end
	if p400 == nil or p400 == false then
		if g_server == nil then
			g_client:getServerConnection():sendEvent(VehicleAttachEvent.new(p396, p397, p398, p399, p402))
		else
			g_server:broadcastEvent(VehicleAttachEvent.new(p396, p397, p398, p399, p402), nil, nil, p396)
		end
	end
	if v407.transNode == nil or v406.attacherHeight == nil then
		if v407.transNode == nil then
			local v426 = (v407.jointType == AttacherJoints.JOINTTYPE_TRAILER or v407.jointType == AttacherJoints.JOINTTYPE_TRAILERLOW) and true or v407.jointType == AttacherJoints.JOINTTYPE_TRAILERCAR
			if p396.checkPowerTakeOffCollision ~= nil then
				p396:checkPowerTakeOffCollision(v407.jointTransform, p399, v426)
			end
		end
	else
		local v427 = v407.transNodeMinY
		local v428 = v407.transNodeMaxY
		local v429 = v407.lowerDistanceToGround
		local v430 = v407.upperDistanceToGround
		local v431 = v406.attacherHeight
		if p396.getOutputPowerTakeOffsByJointDescIndex ~= nil and v427 ~= v428 then
			local v432 = p396:getOutputPowerTakeOffsByJointDescIndex(p399)
			if v432 ~= nil and #v432 > 0 then
				local v433 = v432[1]
				local v434 = v433.connectedInput
				if v434 ~= nil then
					local _, v435, _ = localToLocal(v433.outputNode, getParent(v407.transNode), 0, 0, 0)
					local v436 = (v435 - v427) / (v428 - v427)
					local v437 = MathUtil.lerp(v429, v430, v436)
					local v438 = (v434.size + v407.transNodeHeight) * 0.5
					if v434.aboveAttacher then
						local v439 = v437 - v438
						local v440 = math.min(v429, v439)
						v431 = math.clamp(v431, v440, v439)
					else
						local v441 = v437 + v438
						local v442 = math.max(v430, v441)
						v431 = math.clamp(v431, v441, v442)
					end
				end
			end
		end
		local v443 = v431 - v407.transNodeOffsetY
		local v444 = math.clamp(v443, v429, v430)
		local v445 = v430 - v429
		local v446
		if v445 > 0 then
			local v447 = (v444 - v429) / v445
			v446 = math.clamp(v447, 0, 1)
		else
			v446 = 0
		end
		local v448 = MathUtil.lerp(v427, v428, v446)
		local v449, _, v450 = getTranslation(v407.transNode)
		local _, v451, _ = localToLocal(p396.rootNode, getParent(v407.transNode), 0, v448, 0)
		setTranslation(v407.transNode, v449, v451, v450)
		if v407.transNodeDependentBottomArm ~= nil and v451 <= v407.transNodeDependentBottomArmThreshold then
			local v452 = v407.transNodeDependentBottomArmAttacherJoint
			local v453 = v407.transNodeDependentBottomArmRotation[1]
			local v454 = v407.transNodeDependentBottomArmRotation[2]
			local v455 = v407.transNodeDependentBottomArmRotation[3]
			if p404 then
				setRotation(v452.bottomArm.rotationNode, v453, v454, v455)
				if p396.setMovingToolDirty ~= nil then
					p396:setMovingToolDirty(v452.bottomArm.rotationNode)
				end
			else
				local v456 = ValueInterpolator.new(v452.bottomArm.interpolatorKey, v452.bottomArm.interpolatorGet, v452.bottomArm.interpolatorSet, { v453, v454, v455 }, AttacherJoints.SMOOTH_ATTACH_TIME * 2)
				if v456 ~= nil then
					v456:setDeleteListenerObject(p396)
					v456:setFinishedFunc(v452.bottomArm.interpolatorFinished, v452.bottomArm)
					v452.bottomArm.bottomArmInterpolating = true
				end
			end
		end
	end
	local v457 = {
		["object"] = p397,
		["jointDescIndex"] = p399,
		["inputJointDescIndex"] = p398,
		["loadFromSavegame"] = p404
	}
	v407.upperAlpha = v421
	v407.lowerAlpha = v422
	v407.moveAlpha = v421
	v407.moveLimitAlpha = 0
	if p402 then
		v407.moveAlpha = v422
		v407.moveLimitAlpha = 1
	end
	p396:updateAttacherJointRotationNodes(v407, v407.moveAlpha)
	p396:updateAttacherJointRotation(v407, p397)
	p396:createAttachmentJoint(v457, p403)
	local v458 = v406.isDefaultLowered or v407.isDefaultLowered
	if v406.useFoldingLoweredState or p404 then
		v458 = p402
	end
	v407.moveDown = v458
	v407.isMoving = true
	p397:setLowered(v407.moveDown)
	if p401 == nil then
		local v459 = v405.attachedImplements
		table.insert(v459, v457)
	else
		v405.attachedImplements[p401] = v457
	end
	p396:updateAttacherJointGraphics(v457, 0)
	p396:attachAdditionalAttachment(v407, v406, p397)
	p396.rootVehicle:updateSelectableObjects()
	p396:updateVehicleChain()
	local v460
	if v457.object:getActiveInputAttacherJoint().forceSelection then
		v460 = v457.object
	else
		v460 = nil
	end
	p396.rootVehicle:setSelectedVehicle(v460)
	if not v457.attachingIsInProgress then
		if v457.object.spec_attachable.attacherJoint.hardAttach and p396:getIsHardAttachAllowed(v457.jointDescIndex) then
			p396:hardAttachImplement(v457)
		end
		p396:postAttachImplement(v457)
	end
	AttacherJoints.updateRequiredTopLightsState(p396)
	return true
end
function AttacherJoints.postAttachImplement(p461, p462)
	local v463 = p461.spec_attacherJoints
	local v464 = p462.object
	local v465 = p462.inputJointDescIndex
	local v466 = p462.jointDescIndex
	local v467 = v464.spec_attachable.inputAttacherJoints[v465]
	local v468 = v463.attacherJoints[v466]
	if v467.topReferenceNode ~= nil and v468.topArm ~= nil then
		v468.topArm:setIsActive(true)
	end
	if v468.bottomArm ~= nil then
		if v468.bottomArm.toggleVisibility then
			setVisibility(v468.bottomArm.rotationNode, true)
		end
		if v467.needsToolbar and v468.bottomArm.toolbarNode ~= nil then
			setVisibility(v468.bottomArm.toolbarNode, true)
		end
		if v468.bottomArm.leftNode ~= nil and v467.bottomArmLeftNode ~= nil then
			p461:setMovingPartReferenceNode(v468.bottomArm.leftNode, v467.bottomArmLeftNode, true)
		end
		if v468.bottomArm.rightNode ~= nil and v467.bottomArmRightNode ~= nil then
			p461:setMovingPartReferenceNode(v468.bottomArm.rightNode, v467.bottomArmRightNode, true)
		end
	end
	if v468.delayedObjectChangesOnAttach then
		ObjectChangeUtil.setObjectChanges(v468.changeObjects, true, p461, p461.setMovingToolDirty)
	end
	if not p462.loadFromSavegame then
		p461:playAttachSound(v468)
	end
	p461:updateAttacherJointGraphics(p462, 0)
	SpecializationUtil.raiseEvent(p461, "onPostAttachImplement", v464, v465, v466)
	v464:postAttach(p461, v465, v466, p462.loadFromSavegame)
	local v469 = {
		["attacherVehicle"] = p461,
		["attachedVehicle"] = p462.object
	}
	p461.rootVehicle:raiseStateChange(VehicleStateChange.ATTACH, v469)
end
function AttacherJoints.createAttachmentJoint(p470, p471, p472)
	local v473 = p470.spec_attacherJoints.attacherJoints[p471.jointDescIndex]
	local v474 = p471.object.spec_attachable.attacherJoint
	if p470.isServer and v474 ~= nil then
		if (getRigidBodyType(v473.rootNode) == RigidBodyType.DYNAMIC or getRigidBodyType(v473.rootNode) == RigidBodyType.KINEMATIC) and (getRigidBodyType(v474.rootNode) == RigidBodyType.DYNAMIC or getRigidBodyType(v474.rootNode) == RigidBodyType.KINEMATIC) then
			if (g_currentMission:getNodeObject(v473.rootNode) or p470).isAddedToPhysics and p471.object.isAddedToPhysics then
				local v475 = v473.jointOrigTrans[1] + v473.jointPositionOffset[1]
				local v476 = v473.jointOrigTrans[2] + v473.jointPositionOffset[2]
				local v477 = v473.jointOrigTrans[3] + v473.jointPositionOffset[3]
				local v478, v479, v480 = getRotation(v473.jointTransform)
				setTranslation(v473.jointTransform, v473.jointOrigTrans[1], v473.jointOrigTrans[2], v473.jointOrigTrans[3])
				setRotation(v473.jointTransform, v473.jointOrigRot[1], v473.jointOrigRot[2], v473.jointOrigRot[3])
				local v481, v482, v483 = localToWorld(getParent(v473.jointTransform), v475, v476, v477)
				local v484, v485, v486 = worldToLocal(v473.jointTransform, v481, v482, v483)
				setTranslation(v473.jointTransform, v475, v476, v477)
				setRotation(v473.jointTransform, v478, v479, v480)
				local v487, v488, v489 = localToWorld(v474.node, v484, v485, v486)
				local v490, v491, v492 = worldToLocal(getParent(v474.node), v487, v488, v489)
				setTranslation(v474.node, v490, v491, v492)
				local v493 = JointConstructor.new()
				v493:setActors(v473.rootNode, v474.rootNode)
				v493:setJointTransforms(v473.jointTransform, v474.node)
				p471.jointRotLimit = {}
				p471.jointTransLimit = {}
				p471.lowerRotLimit = {}
				p471.lowerTransLimit = {}
				p471.upperRotLimit = {}
				p471.upperTransLimit = {}
				if p472 == nil or not p472 then
					local v494, v495, v496 = localToLocal(v474.node, v473.jointTransform, 0, 0, 0)
					local _, v497, v498 = localDirectionToLocal(v474.node, v473.jointTransform, 0, 1, 0)
					local v499 = math.atan2(v498, v497)
					local v500, _, v501 = localDirectionToLocal(v474.node, v473.jointTransform, 0, 0, 1)
					local v502 = math.atan2(v500, v501)
					local v503, v504, _ = localDirectionToLocal(v474.node, v473.jointTransform, 1, 0, 0)
					local v505 = math.atan2(v504, v503)
					p471.attachingTransLimit = { math.abs(v494), math.abs(v495), (math.abs(v496)) }
					p471.attachingRotLimit = { math.abs(v499), math.abs(v502), (math.abs(v505)) }
					p471.attachingTransLimitSpeed = {}
					p471.attachingRotLimitSpeed = {}
					for v506 = 1, 3 do
						p471.attachingTransLimitSpeed[v506] = p471.attachingTransLimit[v506] / AttacherJoints.SMOOTH_ATTACH_TIME
						p471.attachingRotLimitSpeed[v506] = p471.attachingRotLimit[v506] / AttacherJoints.SMOOTH_ATTACH_TIME
					end
					p471.attachingIsInProgress = true
				else
					p471.attachingTransLimit = { 0, 0, 0 }
					p471.attachingRotLimit = { 0, 0, 0 }
				end
				p471.rotLimitThreshold = v474.rotLimitThreshold or 0
				p471.transLimitThreshold = v474.transLimitThreshold or 0
				for v507 = 1, 3 do
					local v508, v509 = AttacherJoints.updateAttacherJointLimits(p471, v473, v474, v507)
					if p472 == nil or not p472 then
						local v510 = p471.attachingRotLimit[v507]
						v508 = math.max(v508, v510)
						local v511 = p471.attachingTransLimit[v507]
						v509 = math.max(v509, v511)
					end
					local v512 = -v508
					local v513
					if v507 == 3 then
						if v473.lockDownRotLimit then
							local v514 = -p471.attachingRotLimit[v507]
							v512 = math.min(v514, 0)
						end
						if v473.lockUpRotLimit then
							local v515 = p471.attachingRotLimit[v507]
							v513 = math.max(v515, 0)
						else
							v513 = v508
						end
					else
						v513 = v508
					end
					v493:setRotationLimit(v507 - 1, v512, v513)
					p471.jointRotLimit[v507] = v508
					local v516 = -v509
					local v517
					if v507 == 2 then
						if v473.lockDownTransLimit then
							local v518 = -p471.attachingTransLimit[v507]
							v516 = math.min(v518, 0)
						end
						if v473.lockUpTransLimit then
							local v519 = p471.attachingTransLimit[v507]
							v517 = math.max(v519, 0)
						else
							v517 = v509
						end
					else
						v517 = v509
					end
					v493:setTranslationLimit(v507 - 1, true, v516, v517)
					p471.jointTransLimit[v507] = v509
				end
				if v473.enableCollision then
					v493:setEnableCollision(true)
				else
					for _, v520 in pairs(p470.components) do
						if v520.node ~= v473.rootNodeBackup and not v520.collideWithAttachables then
							setPairCollision(v520.node, v474.rootNode, false)
						end
					end
				end
				local v521 = v473.rotLimitSpring[1]
				local v522 = v474.rotLimitSpring[1]
				local v523 = math.max(v521, v522)
				local v524 = v473.rotLimitSpring[2]
				local v525 = v474.rotLimitSpring[2]
				local v526 = math.max(v524, v525)
				local v527 = v473.rotLimitSpring[3]
				local v528 = v474.rotLimitSpring[3]
				local v529 = math.max(v527, v528)
				local v530 = v473.rotLimitDamping[1]
				local v531 = v474.rotLimitDamping[1]
				local v532 = math.max(v530, v531)
				local v533 = v473.rotLimitDamping[2]
				local v534 = v474.rotLimitDamping[2]
				local v535 = math.max(v533, v534)
				local v536 = v473.rotLimitDamping[3]
				local v537 = v474.rotLimitDamping[3]
				local v538 = math.max(v536, v537)
				local v539 = Utils.getMaxJointForceLimit(v473.rotLimitForceLimit[1], v474.rotLimitForceLimit[1])
				local v540 = Utils.getMaxJointForceLimit(v473.rotLimitForceLimit[2], v474.rotLimitForceLimit[2])
				local v541 = Utils.getMaxJointForceLimit(v473.rotLimitForceLimit[3], v474.rotLimitForceLimit[3])
				v493:setRotationLimitSpring(v523, v532, v526, v535, v529, v538)
				v493:setRotationLimitForceLimit(v539, v540, v541)
				local v542 = v473.transLimitSpring[1]
				local v543 = v474.transLimitSpring[1]
				local v544 = math.max(v542, v543)
				local v545 = v473.transLimitSpring[2]
				local v546 = v474.transLimitSpring[2]
				local v547 = math.max(v545, v546)
				local v548 = v473.transLimitSpring[3]
				local v549 = v474.transLimitSpring[3]
				local v550 = math.max(v548, v549)
				local v551 = v473.transLimitDamping[1]
				local v552 = v474.transLimitDamping[1]
				local v553 = math.max(v551, v552)
				local v554 = v473.transLimitDamping[2]
				local v555 = v474.transLimitDamping[2]
				local v556 = math.max(v554, v555)
				local v557 = v473.transLimitDamping[3]
				local v558 = v474.transLimitDamping[3]
				local v559 = math.max(v557, v558)
				local v560 = Utils.getMaxJointForceLimit(v473.transLimitForceLimit[1], v474.transLimitForceLimit[1])
				local v561 = Utils.getMaxJointForceLimit(v473.transLimitForceLimit[2], v474.transLimitForceLimit[2])
				local v562 = Utils.getMaxJointForceLimit(v473.transLimitForceLimit[3], v474.transLimitForceLimit[3])
				v493:setTranslationLimitSpring(v544, v553, v547, v556, v550, v559)
				v493:setTranslationLimitForceLimit(v560, v561, v562)
				v473.jointIndex = v493:finalize()
				local v563 = setTranslation
				local v564 = v474.node
				local v565 = v474.jointOrigTrans
				v563(v564, unpack(v565))
			end
		else
			return
		end
	else
		v473.jointIndex = 1
		return
	end
end
function AttacherJoints.hardAttachImplement(p566, p567)
	local v568 = p566.spec_attacherJoints
	local v569 = {}
	local v570
	if p567.object.getAttachedImplements == nil then
		v570 = nil
	else
		v570 = p567.object:getAttachedImplements()
	end
	if v570 ~= nil then
		for v571 = #v570, 1, -1 do
			local v572 = v570[v571]
			local v573 = v572.object
			local v574 = v572.jointDescIndex
			local v575 = p567.object.spec_attacherJoints.attacherJoints[v574]
			local v576 = {
				["object"] = v573,
				["implementIndex"] = v571,
				["jointDescIndex"] = v574,
				["inputJointDescIndex"] = v573.spec_attachable.inputAttacherJointDescIndex,
				["moveDown"] = v575.moveDown
			}
			table.insert(v569, 1, v576)
			p567.object:detachImplement(1, true)
		end
	end
	local v577 = v568.attacherJoints[p567.jointDescIndex]
	local v578 = p567.object.spec_attachable.attacherJoint
	local v579 = p566:getParentComponent(v577.jointTransform)
	local v580 = p567.object:getParentComponent(p567.object.spec_attachable.attacherJoint.node)
	local v581 = p566.isAddedToPhysics
	if v581 then
		local v582 = p566
		while p566 ~= nil do
			p566:removeFromPhysics()
			p566 = p566.attacherVehicle
		end
		p567.object:removeFromPhysics()
		p566 = v582
	end
	if v568.attacherVehicle == nil then
		setIsCompound(v579, true)
	end
	setIsCompoundChild(v580, true)
	local v583, v584, v585 = localDirectionToLocal(v580, v578.node, 0, 0, 1)
	local v586, v587, v588 = localDirectionToLocal(v580, v578.node, 0, 1, 0)
	setDirection(v580, v583, v584, v585, v586, v587, v588)
	local v589, v590, v591 = localToLocal(v580, v578.node, 0, 0, 0)
	setTranslation(v580, v589, v590, v591)
	link(v577.jointTransform, v580)
	if v578.visualNode ~= nil and v577.jointTransformVisual ~= nil then
		local v592, v593, v594 = localDirectionToLocal(v578.visualNode, v578.node, 0, 0, 1)
		local v595, v596, v597 = localDirectionToLocal(v578.visualNode, v578.node, 0, 1, 0)
		setDirection(v578.visualNode, v592, v593, v594, v595, v596, v597)
		local v598, v599, v600 = localToLocal(v578.visualNode, v578.node, 0, 0, 0)
		setTranslation(v578.visualNode, v598, v599, v600)
		link(v577.jointTransformVisual, v578.visualNode)
	end
	p567.object.spec_attachable.isHardAttached = true
	if v581 then
		local v601 = p566
		while p566 ~= nil do
			p566:addToPhysics()
			p566 = p566.attacherVehicle
		end
		p566 = v601
	end
	for _, v602 in pairs(p567.object.spec_attacherJoints.attacherJoints) do
		v602.rootNode = p566.rootNode
	end
	for _, v603 in pairs(v569) do
		p567.object:attachImplement(v603.object, v603.inputJointDescIndex, v603.jointDescIndex, true, v603.implementIndex, v603.moveDown, true)
	end
	if p566.isServer then
		p566:raiseDirtyFlags(p566.vehicleDirtyFlag)
	end
	return true
end
function AttacherJoints.hardDetachImplement(p604, p605)
	for _, v606 in pairs(p605.object.spec_attacherJoints.attacherJoints) do
		v606.rootNode = v606.rootNodeBackup
	end
	local v607 = p605.object.spec_attachable.attacherJoint
	local v608 = p605.object:getParentComponent(v607.node)
	local v609 = p604.isAddedToPhysics
	if v609 then
		local v610 = p604
		while p604 ~= nil do
			p604:removeFromPhysics()
			p604 = p604.attacherVehicle
		end
		p604 = v610
	end
	setIsCompound(v608, true)
	local v611, v612, v613 = getWorldTranslation(v608)
	setTranslation(v608, v611, v612, v613)
	local v614, v615, v616 = localDirectionToWorld(p605.object.rootNode, 0, 0, 1)
	local v617, v618, v619 = localDirectionToWorld(p605.object.rootNode, 0, 1, 0)
	setDirection(v608, v614, v615, v616, v617, v618, v619)
	link(getRootNode(), v608)
	if v607.visualNode ~= nil and getParent(v607.visualNode) ~= v607.visualNodeData.parent then
		link(v607.visualNodeData.parent, v607.visualNode, v607.visualNodeData.index)
		setRotation(v607.visualNode, v607.visualNodeData.rotation[1], v607.visualNodeData.rotation[2], v607.visualNodeData.rotation[3])
		setTranslation(v607.visualNode, v607.visualNodeData.translation[1], v607.visualNodeData.translation[2], v607.visualNodeData.translation[3])
	end
	if v609 then
		local v620 = p604
		while p604 ~= nil do
			p604:addToPhysics()
			p604 = p604.attacherVehicle
		end
		p605.object:addToPhysics()
		p604 = v620
	end
	p605.object.spec_attachable.isHardAttached = false
	if p604.isServer then
		p604:raiseDirtyFlags(p604.vehicleDirtyFlag)
	end
	return true
end
function AttacherJoints.detachImplement(p_u_621, p622, p623)
	local v624 = p_u_621.spec_attacherJoints
	if p623 == nil or p623 == false then
		if g_server == nil then
			local v625 = v624.attachedImplements[p622]
			if v625.object ~= nil then
				g_client:getServerConnection():sendEvent(VehicleDetachEvent.new(p_u_621, v625.object))
			end
			return
		end
		g_server:broadcastEvent(VehicleDetachEvent.new(p_u_621, v624.attachedImplements[p622].object), nil, nil, p_u_621)
	end
	local v626 = v624.attachedImplements[p622]
	SpecializationUtil.raiseEvent(p_u_621, "onPreDetachImplement", v626)
	v626.object:preDetach(p_u_621, v626)
	local v_u_627
	if v626.object == nil then
		v_u_627 = nil
	else
		v_u_627 = v624.attacherJoints[v626.jointDescIndex]
		if v_u_627.transNode ~= nil then
			local v628 = setTranslation
			local v629 = v_u_627.transNode
			local v630 = v_u_627.transNodeOrgTrans
			v628(v629, unpack(v630))
			if v_u_627.transNodeDependentBottomArm ~= nil then
				local v631 = v_u_627.transNodeDependentBottomArmAttacherJoint
				local v632 = ValueInterpolator.new(v631.bottomArm.interpolatorKey, v631.bottomArm.interpolatorGet, v631.bottomArm.interpolatorSet, { v631.bottomArm.rotX, v631.bottomArm.rotY, v631.bottomArm.rotZ }, AttacherJoints.SMOOTH_ATTACH_TIME * 2)
				if v632 ~= nil then
					v632:setDeleteListenerObject(p_u_621)
					v632:setFinishedFunc(v631.bottomArm.interpolatorFinished, v631.bottomArm)
					v631.bottomArm.bottomArmInterpolating = true
				end
			end
		end
		if not v626.object.spec_attachable.isHardAttached and p_u_621.isServer then
			if v_u_627.jointIndex ~= 0 then
				removeJoint(v_u_627.jointIndex)
			end
			if not v_u_627.enableCollision then
				for _, v633 in pairs(p_u_621.components) do
					if v633.node ~= v_u_627.rootNodeBackup and not v633.collideWithAttachables then
						local v634 = v626.object:getActiveInputAttacherJoint()
						setPairCollision(v633.node, v634.rootNode, true)
					end
				end
			end
		end
		v_u_627.jointIndex = 0
		p_u_621:setAttacherJointBottomArmWidth(v626.jointDescIndex, nil)
	end
	if not v_u_627.delayedObjectChanges or v_u_627.bottomArm == nil then
		ObjectChangeUtil.setObjectChanges(v_u_627.changeObjects, false, p_u_621, p_u_621.setMovingToolDirty)
	end
	for v635 = 1, #v_u_627.hideVisuals do
		local v636 = v_u_627.hideVisuals[v635]
		local v637 = true
		local v638 = v624.hideVisualNodeToAttacherJoints[v636]
		if v638 ~= nil then
			for v639 = 1, #v638 do
				if v638[v639].jointIndex ~= 0 then
					v637 = false
				end
			end
		end
		if v637 then
			setVisibility(v636, true)
		end
	end
	for v640 = 1, #v_u_627.visualNodes do
		local v641 = v_u_627.visualNodes[v640]
		local v642 = false
		local v643 = v624.hideVisualNodeToAttacherJoints[v641]
		if v643 ~= nil then
			for v644 = 1, #v643 do
				if v643[v644].jointIndex ~= 0 then
					v642 = true
				end
			end
		end
		if v642 then
			setVisibility(v641, false)
		end
	end
	if v626.object ~= nil then
		local v645 = v626.object
		if v645.spec_attachable.isHardAttached then
			p_u_621:hardDetachImplement(v626)
		end
		if p_u_621.isClient then
			if v_u_627.topArm ~= nil then
				v_u_627.topArm:setIsActive(false)
			end
			if v_u_627.bottomArm ~= nil then
				local v646 = ValueInterpolator.new(v_u_627.bottomArm.interpolatorKey, v_u_627.bottomArm.interpolatorGet, v_u_627.bottomArm.interpolatorSet, { v_u_627.bottomArm.rotX, v_u_627.bottomArm.rotY, v_u_627.bottomArm.rotZ }, nil, v_u_627.bottomArm.resetSpeed)
				if v646 ~= nil then
					v646:setDeleteListenerObject(p_u_621)
					v646:setFinishedFunc(v_u_627.bottomArm.interpolatorFinished, v_u_627.bottomArm)
					v_u_627.bottomArm.bottomArmInterpolating = true
					if v_u_627.delayedObjectChanges then
						v646:setFinishedFunc(function()
							-- upvalues: (ref) v_u_627, (copy) p_u_621
							v_u_627.bottomArm.interpolatorFinished(v_u_627.bottomArm)
							if v_u_627.jointIndex == 0 then
								ObjectChangeUtil.setObjectChanges(v_u_627.changeObjects, false, p_u_621, p_u_621.setMovingToolDirty)
							end
						end)
					end
				end
				local v647 = v_u_627.bottomArm.lastDirection
				local v648 = v_u_627.bottomArm.lastDirection
				local v649 = v_u_627.bottomArm.lastDirection
				v647[1] = 0
				v648[2] = 0
				v649[3] = 0
				if v_u_627.bottomArm.translationNode ~= nil then
					setTranslation(v_u_627.bottomArm.translationNode, 0, 0, 0)
				end
				if v_u_627.bottomArm.toolbarNode ~= nil then
					setVisibility(v_u_627.bottomArm.toolbarNode, false)
				end
				if v_u_627.bottomArm.toggleVisibility then
					setVisibility(v_u_627.bottomArm.rotationNode, false)
				end
				if v_u_627.bottomArm.leftNode ~= nil then
					p_u_621:setMovingPartReferenceNode(v_u_627.bottomArm.leftNode, nil, false)
				end
				if v_u_627.bottomArm.rightNode ~= nil then
					p_u_621:setMovingPartReferenceNode(v_u_627.bottomArm.rightNode, nil, false)
				end
			end
		end
		local v650 = setTranslation
		local v651 = v_u_627.jointTransform
		local v652 = v_u_627.jointOrigTrans
		v650(v651, unpack(v652))
		local v653 = v645:getActiveInputAttacherJoint()
		local v654 = setTranslation
		local v655 = v653.node
		local v656 = v653.jointOrigTrans
		v654(v655, unpack(v656))
		if v_u_627.rotationNode ~= nil then
			setRotation(v_u_627.rotationNode, v_u_627.rotX, v_u_627.rotY, v_u_627.rotZ)
		end
		SpecializationUtil.raiseEvent(p_u_621, "onPostDetachImplement", p622)
		v645:postDetach(p622)
		p_u_621:detachAdditionalAttachment(v_u_627, v653)
	end
	table.remove(v624.attachedImplements, p622)
	p_u_621:playDetachSound(v_u_627)
	v624.wasInAttachRange = nil
	p_u_621:updateVehicleChain()
	v626.object:updateVehicleChain()
	local v657 = {
		["attacherVehicle"] = p_u_621,
		["attachedVehicle"] = v626.object
	}
	v626.object:raiseStateChange(VehicleStateChange.DETACH, v657)
	p_u_621.rootVehicle:raiseStateChange(VehicleStateChange.DETACH, v657)
	p_u_621.rootVehicle:updateSelectableObjects()
	if GS_IS_MOBILE_VERSION then
		local v658 = next(v624.attachedImplements)
		if v624.attachedImplements[v658] == nil then
			p_u_621.rootVehicle:setSelectedVehicle(p_u_621, nil, true)
		else
			p_u_621.rootVehicle:setSelectedVehicle(v624.attachedImplements[v658].object, nil, true)
		end
	else
		p_u_621.rootVehicle:setSelectedVehicle(p_u_621, nil, true)
	end
	p_u_621.rootVehicle:requestActionEventUpdate()
	v626.object:updateSelectableObjects()
	v626.object:setSelectedVehicle(v626.object, nil, true)
	v626.object:requestActionEventUpdate()
	AttacherJoints.updateRequiredTopLightsState(p_u_621)
	return true
end
function AttacherJoints.detachImplementByObject(p659, p660, p661)
	local v662 = p659.spec_attacherJoints
	for v663, v664 in ipairs(v662.attachedImplements) do
		if v664.object == p660 then
			p659:detachImplement(v663, p661)
			break
		end
	end
	return true
end
function AttacherJoints.setSelectedImplementByObject(p665, p666)
	p665.spec_attacherJoints.selectedImplement = p665:getImplementByObject(p666)
end
function AttacherJoints.getSelectedImplement(p667)
	local v668 = p667.spec_attacherJoints
	if v668.selectedImplement == nil or v668.selectedImplement.object:getAttacherVehicle() == p667 then
		return v668.selectedImplement
	else
		return nil
	end
end
function AttacherJoints.getCanToggleAttach(_)
	return true
end
function AttacherJoints.getAttachControlBarActionAccessible(_)
	return true
end
function AttacherJoints.getShowAttachControlBarAction(p669)
	if p669:getIsAIActive() then
		return false
	end
	local v670 = p669.spec_attacherJoints.attachableInfo
	local v671 = p669:getSelectedVehicle()
	if v670.attacherVehicle == nil then
		if v671 ~= nil and (not v671.isDeleted and (v671.getAttacherVehicle ~= nil and v671:getAttacherVehicle() ~= nil)) then
			return true
		end
	elseif v671 == nil then
		return true
	end
	return v670.attachable ~= nil and v670.attacherVehicle == p669
end
function AttacherJoints.detachAttachedImplement(p672)
	if p672:getCanToggleAttach() then
		AttacherJoints.actionEventAttach(p672)
	end
end
function AttacherJoints.startAttacherJointCombo(p673, p674)
	local v675 = p673.spec_attacherJoints
	if not v675.attacherJointCombos.isRunning or p674 then
		v675.attacherJointCombos.direction = -v675.attacherJointCombos.direction
		v675.attacherJointCombos.isRunning = true
	end
end
function AttacherJoints.setAttacherJointBlocked(p676, p677, p678)
	local v679 = p676.spec_attacherJoints.attacherJoints[p677]
	if v679 ~= nil then
		v679.isBlocked = p678
	end
end
function AttacherJoints.getIsAttachingAllowed(p680, p681)
	if p681.jointIndex ~= 0 then
		return false
	end
	if p681.isBlocked then
		return false
	end
	if p681.disabledByAttacherJoints ~= nil and #p681.disabledByAttacherJoints > 0 then
		for v682 = 1, #p681.disabledByAttacherJoints do
			if p680:getImplementByJointDescIndex(p681.disabledByAttacherJoints[v682]) ~= nil then
				return false
			end
		end
	end
	return true
end
function AttacherJoints.getCanSteerAttachable(p683, p684)
	local v685 = p683:getAttacherJointDescFromObject(p684)
	return v685 ~= nil and (v685.steeringBarLeftNode ~= nil or (v685.steeringBarRightNode ~= nil or v685.steeringBarForceUsage)) and true or false
end
function AttacherJoints.onAttacherJointsVehicleLoaded(p686, p687)
	local v688 = p686.spec_attacherJoints
	if v688.attachmentDataToLoad == nil then
		g_messageCenter:unsubscribe(MessageType.VEHICLE_LOADED, p686)
	else
		for v689 = #v688.attachmentDataToLoad, 1, -1 do
			local v690 = v688.attachmentDataToLoad[v689]
			if v690.attachedVehicleUniqueId == p687:getUniqueId() then
				p686:attachImplement(p687, v690.inputIndex, v690.jointIndex, true, nil, v690.moveDown, true, true)
				p686:setJointMoveDown(v690.jointIndex, v690.moveDown, true)
				table.remove(v688.attachmentDataToLoad, v689)
			end
		end
		if #v688.attachmentDataToLoad == 0 then
			p686:loadAttachmentsFinished()
			v688.attachmentDataToLoad = nil
			g_messageCenter:unsubscribe(MessageType.VEHICLE_LOADED, p686)
			return
		end
	end
end
function AttacherJoints.registerSelfLoweringActionEvent(_, _, _, _, _, _, _, _, _, _, _, _) end
function AttacherJoints.playAttachSound(p691, p692)
	local v693 = p691.spec_attacherJoints
	if p691.isClient then
		if p692 == nil or p692.sampleAttach == nil then
			g_soundManager:playSample(v693.samples.attach)
		else
			g_soundManager:playSample(p692.sampleAttach)
		end
	end
	return true
end
function AttacherJoints.playDetachSound(p694, p695)
	local v696 = p694.spec_attacherJoints
	if p694.isClient then
		if p695 == nil or p695.sampleDetach == nil then
			if v696.samples.detach == nil then
				if p695 == nil or p695.sampleAttach == nil then
					g_soundManager:playSample(v696.samples.attach)
				else
					g_soundManager:playSample(p695.sampleAttach)
				end
			else
				g_soundManager:playSample(v696.samples.detach)
			end
		else
			g_soundManager:playSample(p695.sampleDetach)
		end
	end
	return true
end
function AttacherJoints.detachingIsPossible(p697)
	local v698 = p697:getImplementByObject(p697:getSelectedVehicle())
	if v698 ~= nil then
		local v699 = v698.object
		if v699 ~= nil and (v699.attacherVehicle ~= nil and (v699:isDetachAllowed() and v699.attacherVehicle:getImplementIndexByObject(v699) ~= nil)) then
			return true
		end
	end
	return false
end
function AttacherJoints.attachAdditionalAttachment(p700, p701, p702, p703)
	if p701.attacherJointDirection ~= nil and p702.additionalAttachment.filename ~= nil then
		local v704 = g_storeManager:getItemByXMLFilename(p702.additionalAttachment.filename)
		if v704 ~= nil then
			local v705 = -p701.attacherJointDirection
			local v706 = nil
			local v707 = nil
			for v708, v709 in ipairs(p700:getAttacherJoints()) do
				if v709.attacherJointDirection == v705 then
					if v709.jointIndex ~= 0 then
						v707 = nil
						break
					end
					if v709.jointType == p702.additionalAttachment.jointType then
						v707 = v709
						v706 = v708
					end
				end
			end
			if v707 ~= nil then
				local v710, v711, v712 = localToWorld(v707.jointTransform, 0, 0, 0)
				local v713, _, v714 = localDirectionToWorld(v707.jointTransform, 1, 0, 0)
				local v715 = MathUtil.getYRotationFromDirection(v713, v714)
				p701.additionalAttachment.currentAttacherJointIndex = v706
				local v716 = {
					v706,
					p702.additionalAttachment.inputAttacherJointIndex,
					v707.jointTransform,
					p702.additionalAttachment.needsLowering,
					p703,
					v704.xmlFilename
				}
				local v717 = VehicleLoadingData.new()
				v717:setStoreItem(v704)
				v717:setPosition(v710, v711, v712)
				v717:setRotation(0, v715, 0)
				v717:setPropertyState(VehiclePropertyState.NONE)
				v717:setOwnerFarmId(p700:getActiveFarm())
				v717:load(AttacherJoints.additionalAttachmentLoaded, p700, v716)
			end
		end
	end
end
function AttacherJoints.detachAdditionalAttachment(p718, p719, p720)
	if p719.additionalAttachment.currentAttacherJointIndex ~= nil and p720.additionalAttachment.filename ~= nil then
		local v721 = p718:getImplementByJointDescIndex(p719.additionalAttachment.currentAttacherJointIndex)
		if v721 ~= nil and v721.object:getIsAdditionalAttachment() then
			p718:detachImplementByObject(v721.object)
			if not g_currentMission.isExitingGame then
				v721.object:delete()
			end
		end
	end
end
function AttacherJoints.additionalAttachmentLoaded(p722, p723, p724, p725)
	if p724 == VehicleLoadingState.OK then
		local v726 = p723[1]
		if v726 == nil or v726.setIsAdditionalAttachment == nil then
			Logging.warning("Invalid additional attachment \'%s\'.", p725[6].xmlFilename)
		else
			local v727 = { 0, 0, 0 }
			if v726.getInputAttacherJoints ~= nil then
				local v728 = v726:getInputAttacherJoints()
				if v728[p725[2]] ~= nil then
					v727 = v728[p725[2]].jointOrigOffsetComponent
				end
			end
			local v729, v730, v731 = localToWorld(p725[3], unpack(v727))
			local v732, _, v733 = localDirectionToWorld(p725[3], 1, 0, 0)
			local v734 = MathUtil.getYRotationFromDirection(v732, v733)
			local v735 = getTerrainHeightAtWorldPos(g_terrainNode, v729, 0, v731) + 0.05
			v726:setAbsolutePosition(v729, math.max(v730, v735), v731, 0, v734, 0)
			p722:attachImplement(v726, p725[2], p725[1], true, nil, nil, true, true)
			v726:setIsAdditionalAttachment(p725[4], true)
			if v726.addDirtAmount ~= nil and (p725[5] ~= nil and p725[5].getDirtAmount ~= nil) then
				v726:addDirtAmount(p725[5]:getDirtAmount())
			end
			p722.rootVehicle:updateSelectableObjects()
			p722.rootVehicle:setSelectedVehicle(p725[5] or p722)
		end
	else
		Logging.warning("Failed to load additional attachment \'%s\'.", p725[6].xmlFilename)
		return
	end
end
function AttacherJoints.getImplementIndexByJointDescIndex(p736, p737)
	local v738 = p736.spec_attacherJoints
	for v739, v740 in pairs(v738.attachedImplements) do
		if v740.jointDescIndex == p737 then
			return v739
		end
	end
	return nil
end
function AttacherJoints.getImplementByJointDescIndex(p741, p742)
	local v743 = p741.spec_attacherJoints
	for _, v744 in pairs(v743.attachedImplements) do
		if v744.jointDescIndex == p742 then
			return v744
		end
	end
	return nil
end
function AttacherJoints.getImplementIndexByObject(p745, p746)
	local v747 = p745.spec_attacherJoints
	for v748, v749 in pairs(v747.attachedImplements) do
		if v749.object == p746 then
			return v748
		end
	end
	return nil
end
function AttacherJoints.getImplementByObject(p750, p751)
	local v752 = p750.spec_attacherJoints
	for _, v753 in pairs(v752.attachedImplements) do
		if v753.object == p751 then
			return v753
		end
	end
	return nil
end
function AttacherJoints.callFunctionOnAllImplements(p754, p755, ...)
	for _, v756 in pairs(p754:getAttachedImplements()) do
		local v757 = v756.object
		if v757 ~= nil and v757[p755] ~= nil then
			v757[p755](v757, ...)
		end
	end
end
function AttacherJoints.activateAttachments(p758)
	local v759 = p758.spec_attacherJoints
	for _, v760 in pairs(v759.attachedImplements) do
		if v760.object ~= nil then
			v760.object:activate()
		end
	end
end
function AttacherJoints.deactivateAttachments(p761)
	local v762 = p761.spec_attacherJoints
	for _, v763 in pairs(v762.attachedImplements) do
		if v763.object ~= nil then
			v763.object:deactivate()
		end
	end
end
function AttacherJoints.deactivateAttachmentsLights(p764)
	local v765 = p764.spec_attacherJoints
	for _, v766 in pairs(v765.attachedImplements) do
		if v766.object ~= nil and v766.object.deactivateLights ~= nil then
			v766.object:deactivateLights()
		end
	end
end
function AttacherJoints.setJointMoveDown(p767, p768, p769, p770)
	local v771 = p767.spec_attacherJoints
	local v772 = v771.attacherJoints[p768]
	if p769 ~= v772.moveDown then
		if v772.allowsLowering then
			v772.moveDown = p769
			v772.isMoving = true
			local v773 = p767:getImplementIndexByJointDescIndex(p768)
			if v773 ~= nil then
				local v774 = v771.attachedImplements[v773]
				if v774.object ~= nil then
					v774.object:setLowered(p769)
				end
			end
		end
		VehicleLowerImplementEvent.sendEvent(p767, p768, p769, p770)
	end
	return true
end
function AttacherJoints.getJointMoveDown(p775, p776)
	local v777 = p775.spec_attacherJoints.attacherJoints[p776]
	if v777.allowsLowering then
		return v777.moveDown
	else
		return false
	end
end
function AttacherJoints.getIsHardAttachAllowed(p778, p779)
	return p778.spec_attacherJoints.attacherJoints[p779].supportsHardAttach
end
function AttacherJoints.loadAttacherJointFromXML(p_u_780, p781, p782, p783, _)
	local v784 = p_u_780.spec_attacherJoints
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#index", p783 .. "#node")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#indexVisual", p783 .. "#nodeVisual")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#ptoOutputNode", "vehicle.powerTakeOffs.output")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#lowerDistanceToGround", p783 .. ".distanceToGround#lower")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#upperDistanceToGround", p783 .. ".distanceToGround#upper")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#rotationNode", p783 .. ".rotationNode#node")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#upperRotation", p783 .. ".rotationNode#upperRotation")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#lowerRotation", p783 .. ".rotationNode#lowerRotation")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#startRotation", p783 .. ".rotationNode#startRotation")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#rotationNode2", p783 .. ".rotationNode2#node")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#upperRotation2", p783 .. ".rotationNode2#upperRotation")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#lowerRotation2", p783 .. ".rotationNode2#lowerRotation")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#transNode", p783 .. ".transNode#node")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#transNodeMinY", p783 .. ".transNode#minY")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#transNodeMaxY", p783 .. ".transNode#maxY")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. "#transNodeHeight", p783 .. ".transNode#height")
	XMLUtil.checkDeprecatedXMLElements(p782, p783 .. ".additionalAttachment#attacherJointDirection", p783 .. "#direction")
	local v785 = p782:getValue(p783 .. "#node", nil, p_u_780.components, p_u_780.i3dMappings)
	if v785 == nil then
		Logging.xmlWarning(p_u_780.xmlFile, "Missing node for attacherJoint \'%s\'", p783)
		return false
	end
	p781.jointTransform = v785
	p781.jointComponent = p_u_780:getParentComponent(p781.jointTransform)
	p781.jointTransformVisual = p782:getValue(p783 .. "#nodeVisual", nil, p_u_780.components, p_u_780.i3dMappings)
	p781.supportsHardAttach = p782:getValue(p783 .. "#supportsHardAttach", true)
	p781.jointOrigOffsetComponent = { localToLocal(p781.jointComponent, p781.jointTransform, 0, 0, 0) }
	p781.jointOrigRotOffsetComponent = { localRotationToLocal(p781.jointComponent, p781.jointTransform, 0, 0, 0) }
	p781.jointTransformOrig = createTransformGroup("jointTransformOrig")
	link(getParent(v785), p781.jointTransformOrig)
	setTranslation(p781.jointTransformOrig, getTranslation(v785))
	setRotation(p781.jointTransformOrig, getRotation(v785))
	local v786 = p782:getValue(p783 .. "#jointType")
	local v787
	if v786 == nil then
		v787 = nil
	else
		v787 = AttacherJoints.jointTypeNameToInt[v786]
		if v787 == nil then
			Logging.xmlWarning(p_u_780.xmlFile, "Invalid jointType \'%s\' for attacherJoint \'%s\'!", tostring(v786), p783)
		end
	end
	if v787 == nil then
		v787 = AttacherJoints.JOINTTYPE_IMPLEMENT
	end
	p781.jointType = v787
	local v788 = p782:getValue(p783 .. ".subType#name")
	if not string.isNilOrWhitespace(v788) then
		p781.subTypes = string.split(v788, " ")
	end
	local v789 = p782:getValue(p783 .. ".subType#brandRestriction")
	if v789 ~= nil and string.trim(v789) ~= "" then
		p781.brandRestrictions = string.split(v789, " ")
		for v790 = 1, #p781.brandRestrictions do
			local v791 = g_brandManager:getBrandByName(p781.brandRestrictions[v790])
			if v791 == nil then
				Logging.xmlError(p782, "Unknown brand \'%s\' in \'%s\'", p781.brandRestrictions[v790], p783 .. ".subType#brandRestriction")
				p781.brandRestrictions = nil
				break
			end
			p781.brandRestrictions[v790] = v791
		end
	end
	local v792 = p782:getValue(p783 .. ".subType#vehicleRestriction")
	if v792 ~= nil and string.trim(v792) ~= "" then
		p781.vehicleRestrictions = string.split(v792, " ")
	end
	p781.subTypeShowWarning = p782:getValue(p783 .. ".subType#subTypeShowWarning", true)
	p781.allowsJointLimitMovement = p782:getValue(p783 .. "#allowsJointLimitMovement", true)
	p781.allowsLowering = p782:getValue(p783 .. "#allowsLowering", true)
	p781.isDefaultLowered = p782:getValue(p783 .. "#isDefaultLowered", false)
	p781.allowDetachingWhileLifted = p782:getValue(p783 .. "#allowDetachingWhileLifted", true)
	p781.allowFoldingWhileAttached = p782:getValue(p783 .. "#allowFoldingWhileAttached", true)
	if v787 == AttacherJoints.JOINTTYPE_TRAILER or (v787 == AttacherJoints.JOINTTYPE_TRAILERLOW or v787 == AttacherJoints.JOINTTYPE_TRAILERCAR) then
		p781.allowsLowering = false
	end
	p781.canTurnOnImplement = p782:getValue(p783 .. "#canTurnOnImplement", true)
	local v793 = p782:getValue(p783 .. ".rotationNode#node", nil, p_u_780.components, p_u_780.i3dMappings)
	if v793 ~= nil then
		p781.rotationNode = v793
		p781.lowerRotation = p782:getValue(p783 .. ".rotationNode#lowerRotation", "0 0 0", true)
		p781.upperRotation = p782:getValue(p783 .. ".rotationNode#upperRotation", nil, true) or { getRotation(v793) }
		local v794, v795, v796 = p782:getValue(p783 .. ".rotationNode#startRotation", nil)
		p781.rotX = v794
		p781.rotY = v795
		p781.rotZ = v796
		if p781.rotX == nil then
			local v797, v798, v799 = getRotation(v793)
			p781.rotX = v797
			p781.rotY = v798
			p781.rotZ = v799
		end
		local v800 = { p781.lowerRotation[1], p781.lowerRotation[2], p781.lowerRotation[3] }
		local v801 = { p781.upperRotation[1], p781.upperRotation[2], p781.upperRotation[3] }
		local v802 = v800[1]
		local v803 = v801[1]
		if v803 < v802 then
			v801[1] = v802
			v800[1] = v803
		end
		local v804 = v800[2]
		local v805 = v801[2]
		if v805 < v804 then
			v801[2] = v804
			v800[2] = v805
		end
		local v806 = v800[3]
		local v807 = v801[3]
		if v807 < v806 then
			v801[3] = v806
			v800[3] = v807
		end
		local v808 = p781.rotX
		local v809 = v800[1]
		local v810 = v801[1]
		p781.rotX = math.clamp(v808, v809, v810)
		local v811 = p781.rotY
		local v812 = v800[2]
		local v813 = v801[2]
		p781.rotY = math.clamp(v811, v812, v813)
		local v814 = p781.rotZ
		local v815 = v800[3]
		local v816 = v801[3]
		p781.rotZ = math.clamp(v814, v815, v816)
	end
	local v817 = p782:getValue(p783 .. ".rotationNode2#node", nil, p_u_780.components, p_u_780.i3dMappings)
	if v817 ~= nil then
		p781.rotationNode2 = v817
		p781.lowerRotation2 = p782:getValue(p783 .. ".rotationNode2#lowerRotation", nil, true) or { -p781.lowerRotation[1], -p781.lowerRotation[2], -p781.lowerRotation[3] }
		p781.upperRotation2 = p782:getValue(p783 .. ".rotationNode2#upperRotation", nil, true) or { -p781.upperRotation[1], -p781.upperRotation[2], -p781.upperRotation[3] }
	end
	p781.transNode = p782:getValue(p783 .. ".transNode#node", nil, p_u_780.components, p_u_780.i3dMappings)
	if p781.transNode ~= nil then
		p781.transNodeOrgTrans = { getTranslation(p781.transNode) }
		p781.transNodeHeight = p782:getValue(p783 .. ".transNode#height", 0.12)
		p781.transNodeMinY = p782:getValue(p783 .. ".transNode#minY")
		p781.transNodeMaxY = p782:getValue(p783 .. ".transNode#maxY")
		p781.transNodeDependentBottomArm = p782:getValue(p783 .. ".transNode.dependentBottomArm#node", nil, p_u_780.components, p_u_780.i3dMappings)
		p781.transNodeDependentBottomArmThreshold = p782:getValue(p783 .. ".transNode.dependentBottomArm#threshold", (1 / 0))
		p781.transNodeDependentBottomArmRotation = p782:getValue(p783 .. ".transNode.dependentBottomArm#rotation", "0 0 0", true)
	end
	if (p781.rotationNode ~= nil or p781.transNode ~= nil) and p782:getValue(p783 .. ".distanceToGround#lower") == nil then
		Logging.xmlWarning(p_u_780.xmlFile, "Missing \'.distanceToGround#lower\' for attacherJoint \'%s\'. Use console command \'gsVehicleAnalyze\' to get correct values!", p783)
	end
	p781.lowerDistanceToGround = p782:getValue(p783 .. ".distanceToGround#lower", 0.7)
	if (p781.rotationNode ~= nil or p781.transNode ~= nil) and p782:getValue(p783 .. ".distanceToGround#upper") == nil then
		Logging.xmlWarning(p_u_780.xmlFile, "Missing \'.distanceToGround#upper\' for attacherJoint \'%s\'. Use console command \'gsVehicleAnalyze\' to get correct values!", p783)
	end
	p781.upperDistanceToGround = p782:getValue(p783 .. ".distanceToGround#upper", 1)
	if p781.lowerDistanceToGround > p781.upperDistanceToGround then
		Logging.xmlWarning(p_u_780.xmlFile, "distanceToGround#lower may not be larger than distanceToGround#upper for attacherJoint \'%s\'. Switching values!", p783)
		local v818 = p781.lowerDistanceToGround
		p781.lowerDistanceToGround = p781.upperDistanceToGround
		p781.upperDistanceToGround = v818
	end
	p781.lowerRotationOffset = p782:getValue(p783 .. "#lowerRotationOffset", 0)
	p781.upperRotationOffset = p782:getValue(p783 .. "#upperRotationOffset", 0)
	p781.dynamicLowerRotLimit = p782:getValue(p783 .. "#dynamicLowerRotLimit", false)
	p781.lockDownRotLimit = p782:getValue(p783 .. "#lockDownRotLimit", false)
	p781.lockUpRotLimit = p782:getValue(p783 .. "#lockUpRotLimit", false)
	p781.lockDownTransLimit = p782:getValue(p783 .. "#lockDownTransLimit", true)
	p781.lockUpTransLimit = p782:getValue(p783 .. "#lockUpTransLimit", false)
	local v819 = v787 == AttacherJoints.JOINTTYPE_IMPLEMENT and "20 20 20" or "0 0 0"
	local v820, v821, v822 = p782:getValue(p783 .. "#lowerRotLimit", v819)
	p781.lowerRotLimit = { math.abs(v820 or 20), math.abs(v821 or 20), (math.abs(v822 or 20)) }
	local v823, v824, v825 = p782:getValue(p783 .. "#upperRotLimit")
	p781.upperRotLimit = { math.abs(v823 or (v820 or 20)), math.abs(v824 or (v821 or 20)), (math.abs(v825 or (v822 or 20))) }
	local v826 = v787 == AttacherJoints.JOINTTYPE_IMPLEMENT and "0.5 0.5 0.5" or "0 0 0"
	local v827, v828, v829 = p782:getValue(p783 .. "#lowerTransLimit", v826)
	p781.lowerTransLimit = { math.abs(v827 or 0), math.abs(v828 or 0), (math.abs(v829 or 0)) }
	local v830, v831, v832 = p782:getValue(p783 .. "#upperTransLimit")
	p781.upperTransLimit = { math.abs(v830 or (v827 or 0)), math.abs(v831 or (v828 or 0)), (math.abs(v832 or (v829 or 0))) }
	p781.jointPositionOffset = p782:getValue(p783 .. "#jointPositionOffset", "0 0 0", true)
	p781.rotLimitSpring = p782:getValue(p783 .. "#rotLimitSpring", "0 0 0", true)
	p781.rotLimitDamping = p782:getValue(p783 .. "#rotLimitDamping", "1 1 1", true)
	p781.rotLimitForceLimit = p782:getValue(p783 .. "#rotLimitForceLimit", "-1 -1 -1", true)
	p781.transLimitSpring = p782:getValue(p783 .. "#transLimitSpring", "0 0 0", true)
	p781.transLimitDamping = p782:getValue(p783 .. "#transLimitDamping", "1 1 1", true)
	p781.transLimitForceLimit = p782:getValue(p783 .. "#transLimitForceLimit", "-1 -1 -1", true)
	p781.moveDefaultTime = p782:getValue(p783 .. "#moveTime", 0.5) * 1000
	p781.moveTime = p781.moveDefaultTime
	p781.disabledByAttacherJoints = p782:getValue(p783 .. "#disabledByAttacherJoints", nil, true)
	p781.enableCollision = p782:getValue(p783 .. "#enableCollision", false)
	p781.topArm = AttacherJointTopArm.loadFromVehicleXML(p_u_780, p783 .. ".topArm")
	local v833 = p782:getValue(p783 .. ".bottomArm#rotationNode", nil, p_u_780.components, p_u_780.i3dMappings)
	local v834 = p782:getValue(p783 .. ".bottomArm#translationNode", nil, p_u_780.components, p_u_780.i3dMappings)
	local v835 = p782:getValue(p783 .. ".bottomArm#referenceNode", nil, p_u_780.components, p_u_780.i3dMappings)
	if v833 ~= nil then
		local v_u_836 = {
			["rotationNode"] = v833,
			["rotationNodeDir"] = createTransformGroup("rotationNodeDirTemp")
		}
		link(getParent(v833), v_u_836.rotationNodeDir)
		setTranslation(v_u_836.rotationNodeDir, getTranslation(v833))
		setRotation(v_u_836.rotationNodeDir, getRotation(v833))
		v_u_836.lastDirection = { 0, 0, 0 }
		local v837, v838, v839 = p782:getValue(p783 .. ".bottomArm#startRotation", nil)
		v_u_836.rotX = v837
		v_u_836.rotY = v838
		v_u_836.rotZ = v839
		if v_u_836.rotX == nil then
			local v840, v841, v842 = getRotation(v833)
			v_u_836.rotX = v840
			v_u_836.rotY = v841
			v_u_836.rotZ = v842
		end
		function v_u_836.interpolatorGet()
			-- upvalues: (copy) v_u_836
			return getRotation(v_u_836.rotationNode)
		end
		function v_u_836.interpolatorSet(p843, p844, p845)
			-- upvalues: (copy) v_u_836, (copy) p_u_780
			setRotation(v_u_836.rotationNode, p843, p844, p845)
			if p_u_780.setMovingToolDirty ~= nil then
				p_u_780:setMovingToolDirty(v_u_836.rotationNode)
			end
		end
		function v_u_836.interpolatorFinished(_)
			-- upvalues: (copy) v_u_836
			v_u_836.bottomArmInterpolating = false
		end
		v_u_836.interpolatorKey = v833 .. "rotation"
		v_u_836.bottomArmInterpolating = false
		if v834 ~= nil and v835 ~= nil then
			v_u_836.translationNode = v834
			v_u_836.referenceNode = v835
			local v846, v847, v848 = getTranslation(v834)
			if math.abs(v846) >= 0.0001 or (math.abs(v847) >= 0.0001 or math.abs(v848) >= 0.0001) then
				Logging.xmlWarning(p_u_780.xmlFile, "BottomArm translation of attacherJoint \'%s\' is not 0/0/0!", p783)
			end
			v_u_836.referenceDistance = calcDistanceFrom(v835, v834)
		end
		local v849 = p782:getValue(p783 .. ".bottomArm#zScale", 1)
		v_u_836.zScale = math.sign(v849)
		v_u_836.lockDirection = p782:getValue(p783 .. ".bottomArm#lockDirection", true)
		v_u_836.resetSpeed = p782:getValue(p783 .. ".bottomArm#resetSpeed", 45)
		v_u_836.updateReferenceDistance = p782:getValue(p783 .. ".bottomArm#updateReferenceDistance", false)
		v_u_836.jointPositionNode = p782:getValue(p783 .. ".bottomArm#jointPositionNode", nil, p_u_780.components, p_u_780.i3dMappings)
		v_u_836.toggleVisibility = p782:getValue(p783 .. ".bottomArm#toggleVisibility", false)
		if v_u_836.toggleVisibility then
			setVisibility(v_u_836.rotationNode, false)
		end
		if v787 == AttacherJoints.JOINTTYPE_IMPLEMENT then
			v_u_836.sharedLoadRequestIdToolbar = p_u_780:loadSubSharedI3DFile(Utils.getFilename(p782:getValue(p783 .. ".toolbar#filename", "$data/shared/assets/toolbars/toolbars.i3d"), p_u_780.baseDirectory), false, false, p_u_780.onBottomArmToolbarI3DLoaded, p_u_780, {
				["bottomArm"] = v_u_836,
				["referenceNode"] = v835
			})
		end
		local v850 = AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[2]
		local v851 = AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[2]
		v_u_836.minWidth = v850
		v_u_836.maxWidth = v851
		local v852 = p782:getValue(p783 .. ".bottomArm#categoryRange", "1 4", true)
		if v852 ~= nil and #v852 >= 1 then
			v_u_836.minWidth = AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[v852[1]] or v_u_836.minWidth
			v_u_836.maxWidth = AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[v852[2] or v852[1]] or v_u_836.maxWidth
		end
		local v853 = p782:getValue(p783 .. ".bottomArm#widthRange", nil, true)
		if v853 ~= nil and #v853 >= 1 then
			v_u_836.minWidth = v853[1] or v_u_836.minWidth
			v_u_836.maxWidth = v853[2] or (v853[1] or v_u_836.maxWidth)
		end
		if v787 == AttacherJoints.JOINTTYPE_IMPLEMENT and not (p782:hasProperty(p783 .. ".bottomArm#categoryRange") or p782:hasProperty(p783 .. ".bottomArm#widthRange")) then
			Logging.xmlWarning(p782, "Missing categoryRange or widthRange attribute for bottom arm in \'%s\'", p783)
		end
		v_u_836.armLeft = p782:getValue(p783 .. ".bottomArm.armLeft#node", nil, p_u_780.components, p_u_780.i3dMappings)
		v_u_836.armLeftReferenceNode = p782:getValue(p783 .. ".bottomArm.armLeft#referenceNode", nil, p_u_780.components, p_u_780.i3dMappings)
		if v_u_836.armLeft ~= nil and v_u_836.armLeftReferenceNode ~= nil then
			v_u_836.armLeftLength = calcDistanceFrom(v_u_836.armLeft, v_u_836.armLeftReferenceNode)
		end
		v_u_836.armRight = p782:getValue(p783 .. ".bottomArm.armRight#node", nil, p_u_780.components, p_u_780.i3dMappings)
		v_u_836.armRightReferenceNode = p782:getValue(p783 .. ".bottomArm.armRight#referenceNode", nil, p_u_780.components, p_u_780.i3dMappings)
		if v_u_836.armRight ~= nil and v_u_836.armRightReferenceNode ~= nil then
			v_u_836.armRightLength = calcDistanceFrom(v_u_836.armRight, v_u_836.armRightReferenceNode)
		end
		v_u_836.ballVisibility = p782:getValue(p783 .. ".bottomArm#ballVisibility", true)
		if v_u_836.armLeft == nil or (v_u_836.armRight == nil or v_u_836.referenceNode == nil) then
			v_u_836.defaultWidth = (v_u_836.minWidth + v_u_836.maxWidth) * 0.5
		else
			v_u_836.variableWidthAvailable = true
			local v854 = p782:getValue(p783 .. ".bottomArm#defaultCategory")
			local v855
			if v854 == nil or (v854 < 0 or v854 > 4) then
				v855 = nil
			else
				v855 = AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[v854]
			end
			if v855 == nil then
				v855 = p782:getValue(p783 .. ".bottomArm#defaultWidth")
			end
			if v855 == nil then
				local v856, _, _ = localToLocal(v_u_836.armLeftReferenceNode or v_u_836.armLeft, v_u_836.referenceNode, 0, 0, 0)
				v855 = math.abs(v856) * 2
			end
			v_u_836.defaultWidth = v855
		end
		if p_u_780.setMovingPartReferenceNode ~= nil then
			v_u_836.leftNode = p782:getValue(p783 .. ".bottomArm#leftNode", nil, p_u_780.components, p_u_780.i3dMappings)
			v_u_836.rightNode = p782:getValue(p783 .. ".bottomArm#rightNode", nil, p_u_780.components, p_u_780.i3dMappings)
		end
		p781.bottomArm = v_u_836
	end
	if p_u_780.isClient then
		p781.sampleAttach = g_soundManager:loadSampleFromXML(p782, p783, "attachSound", p_u_780.baseDirectory, p_u_780.components, 1, AudioGroup.VEHICLE, p_u_780.i3dMappings, p_u_780)
		p781.sampleDetach = g_soundManager:loadSampleFromXML(p782, p783, "detachSound", p_u_780.baseDirectory, p_u_780.components, 1, AudioGroup.VEHICLE, p_u_780.i3dMappings, p_u_780)
	end
	p781.steeringBarLeftNode = p782:getValue(p783 .. ".steeringBars#leftNode", nil, p_u_780.components, p_u_780.i3dMappings)
	p781.steeringBarRightNode = p782:getValue(p783 .. ".steeringBars#rightNode", nil, p_u_780.components, p_u_780.i3dMappings)
	p781.steeringBarForceUsage = p782:getValue(p783 .. ".steeringBars#forceUsage", true)
	p781.visualNodes = p782:getValue(p783 .. ".visuals#nodes", nil, p_u_780.components, p_u_780.i3dMappings, true)
	for v857 = 1, #p781.visualNodes do
		local v858 = p781.visualNodes[v857]
		if v784.visualNodeToAttacherJoints[v858] == nil then
			v784.visualNodeToAttacherJoints[v858] = {}
		end
		local v859 = v784.visualNodeToAttacherJoints[v858]
		table.insert(v859, p781)
	end
	p781.hideVisuals = p782:getValue(p783 .. ".visuals#hide", nil, p_u_780.components, p_u_780.i3dMappings, true)
	for v860 = 1, #p781.hideVisuals do
		local v861 = p781.hideVisuals[v860]
		if v784.hideVisualNodeToAttacherJoints[v861] == nil then
			v784.hideVisualNodeToAttacherJoints[v861] = {}
		end
		local v862 = v784.hideVisualNodeToAttacherJoints[v861]
		table.insert(v862, p781)
	end
	p781.changeObjects = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p782, p783, p781.changeObjects, p_u_780.components, p_u_780)
	ObjectChangeUtil.setObjectChanges(p781.changeObjects, false, p_u_780, p_u_780.setMovingToolDirty, true)
	p781.delayedObjectChanges = p782:getValue(p783 .. "#delayedObjectChanges", true)
	p781.delayedObjectChangesOnAttach = p782:getValue(p783 .. "#delayedObjectChangesOnAttach", false)
	p781.additionalAttachment = {}
	local _, _, v863 = localToLocal(p781.jointTransform, p_u_780.rootNode, 0, 0, 0)
	p781.attacherJointDirection = p782:getValue(p783 .. "#direction", (math.sign(v863)))
	p781.useTopLights = p782:getValue(p783 .. "#useTopLights", p781.attacherJointDirection == 1)
	p781.rootNode = p782:getValue(p783 .. "#rootNode", p_u_780:getParentComponent(p781.jointTransform), p_u_780.components, p_u_780.i3dMappings)
	p781.rootNodeBackup = p781.rootNode
	p781.jointIndex = 0
	p781.isBlocked = false
	p781.comboTime = p782:getValue(p783 .. "#comboTime")
	local v864 = p783 .. ".schema"
	if p782:hasProperty(v864) then
		local v865, v866 = p782:getValue(v864 .. "#position")
		if v865 == nil then
			Logging.xmlWarning(p_u_780.xmlFile, "Missing values for \'%s\'", v864 .. "#position")
		else
			local v867, v868 = p782:getValue(v864 .. "#liftedOffset", "0 5")
			p_u_780.schemaOverlay:addAttacherJoint(v865, v866, p782:getValue(v864 .. "#rotation", 0), p782:getValue(v864 .. "#invertX", false), v867, v868)
		end
	else
		Logging.xmlWarning(p_u_780.xmlFile, "Missing schema overlay attacherJoint \'%s\'!", p783)
	end
	return true
end
function AttacherJoints.onBottomArmToolbarI3DLoaded(_, p869, _, p870)
	local v871 = p870.bottomArm
	local v872 = p870.referenceNode
	if p869 ~= 0 then
		local v873 = getChildAt(p869, 0)
		link(v872, v873)
		setTranslation(v873, 0, 0, 0)
		setVisibility(v873, false)
		local v874 = AttacherJoints.getClosestLowerLinkCategoryIndex(v871.defaultWidth or AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[2])
		v871.toolbarNode = v873
		v871.toolbars = {}
		for v875 = 1, getNumOfChildren(v873) do
			local v876 = getChildAt(v873, v875 - 1)
			setTranslation(v876, 0, 0, 0)
			setVisibility(v876, v874 == v875 - 1)
			local v877 = v871.toolbars
			table.insert(v877, v876)
		end
		delete(p869)
	end
end
function AttacherJoints.raiseActive(p878, p879)
	local v880 = p878.spec_attacherJoints
	p879(p878)
	for _, v881 in pairs(v880.attachedImplements) do
		if v881.object ~= nil then
			v881.object:raiseActive()
		end
	end
end
function AttacherJoints.registerActionEvents(p882, p883, p884)
	local v885 = p882.spec_attacherJoints
	p883(p882, p884)
	if p882 ~= p884 then
		local v886 = p882:getSelectedObject()
		if v886 ~= nil and (p882 ~= v886.vehicle and p884 ~= v886.vehicle) then
			v886.vehicle:registerActionEvents()
		end
		for _, v887 in pairs(v885.attachedImplements) do
			if v887.object ~= nil then
				if v886 == nil then
					printCallstack()
				end
				v887.object:registerActionEvents(v886.vehicle)
			end
		end
	end
end
function AttacherJoints.removeActionEvents(p888, p889)
	local v890 = p888.spec_attacherJoints
	p889(p888)
	for _, v891 in pairs(v890.attachedImplements) do
		if v891.object ~= nil then
			v891.object:removeActionEvents()
		end
	end
end
function AttacherJoints.addToPhysics(p892, p893)
	if not p893(p892) then
		return false
	end
	local v894 = p892.spec_attacherJoints
	for _, v895 in pairs(v894.attachedImplements) do
		if v895.object.spec_attachable.isHardAttached then
			v895.object:addToPhysics()
		else
			p892:createAttachmentJoint(v895, true)
		end
	end
	return true
end
function AttacherJoints.removeFromPhysics(p896, p897)
	local v898 = p896.spec_attacherJoints
	for _, v899 in pairs(v898.attachedImplements) do
		if v899.object.spec_attachable.isHardAttached then
			v899.object:removeFromPhysics()
		else
			local v900 = v898.attacherJoints[v899.jointDescIndex]
			if v900.jointIndex ~= 0 then
				v900.jointIndex = 0
			end
		end
	end
	return p897(p896) and true or false
end
function AttacherJoints.getTotalMass(p901, p902, p903)
	local v904 = p901.spec_attacherJoints
	local v905 = p902(p901)
	if p903 == nil or not p903 then
		for _, v906 in pairs(v904.attachedImplements) do
			local v907 = v906.object
			if v907 ~= nil then
				v905 = v905 + v907:getTotalMass(p903)
			end
		end
	end
	return v905
end
function AttacherJoints.addChildVehicles(p908, p909, p910, p911)
	local v912 = p908.spec_attacherJoints
	for _, v913 in pairs(v912.attachedImplements) do
		local v914 = v913.object
		if v914 ~= nil and v914.addChildVehicles ~= nil then
			v914:addChildVehicles(p910, p911)
		end
	end
	return p909(p908, p910, p911)
end
function AttacherJoints.getAirConsumerUsage(p915, p916)
	local v917 = p915.spec_attacherJoints
	local v918 = p916(p915)
	for _, v919 in pairs(v917.attachedImplements) do
		local v920 = v919.object
		if v920 ~= nil and v920.getAttachbleAirConsumerUsage ~= nil then
			v918 = v918 + v920:getAttachbleAirConsumerUsage()
		end
	end
	return v918
end
function AttacherJoints.getRequiresPower(p921, p922)
	local v923 = p921.spec_attacherJoints
	for _, v924 in pairs(v923.attachedImplements) do
		if v924.object ~= nil and v924.object:getRequiresPower() then
			return true
		end
	end
	return p922(p921)
end
function AttacherJoints.addVehicleToAIImplementList(p925, p926, p927)
	p926(p925, p927)
	for _, v928 in pairs(p925:getAttachedImplements()) do
		local v929 = v928.object
		if v929 ~= nil and v929.addVehicleToAIImplementList ~= nil then
			v929:addVehicleToAIImplementList(p927)
		end
	end
end
function AttacherJoints.collectAIAgentAttachments(p930, p931, p932)
	p931(p930, p932)
	for _, v933 in pairs(p930:getAttachedImplements()) do
		local v934 = v933.object
		if v934 ~= nil and v934.collectAIAgentAttachments ~= nil then
			v934:collectAIAgentAttachments(p932)
			p932:startNewAIAgentAttachmentChain()
		end
	end
end
function AttacherJoints.setAIVehicleObstacleStateDirty(p935, p936)
	p936(p935)
	for _, v937 in pairs(p935:getAttachedImplements()) do
		local v938 = v937.object
		if v938 ~= nil and v938.setAIVehicleObstacleStateDirty ~= nil then
			v938:setAIVehicleObstacleStateDirty()
		end
	end
end
function AttacherJoints.getDirectionSnapAngle(p939, p940)
	local v941 = p939.spec_attacherJoints
	local v942 = p940(p939)
	for _, v943 in pairs(v941.attachedImplements) do
		local v944 = v943.object
		if v944 ~= nil and v944.getDirectionSnapAngle ~= nil then
			local v945 = v942 + v944:getDirectionSnapAngle()
			v942 = math.max(v945)
		end
	end
	return v942
end
function AttacherJoints.getFillLevelInformation(p946, p947, p948)
	local v949 = p946.spec_attacherJoints
	p947(p946, p948)
	for _, v950 in pairs(v949.attachedImplements) do
		local v951 = v950.object
		if v951 ~= nil and v951.getFillLevelInformation ~= nil then
			v951:getFillLevelInformation(p948)
		end
	end
end
function AttacherJoints.attachableAddToolCameras(p952, p953)
	local v954 = p952.spec_attacherJoints
	p953(p952)
	for _, v955 in pairs(v954.attachedImplements) do
		local v956 = v955.object
		if v956 ~= nil and v956.attachableAddToolCameras ~= nil then
			v956:attachableAddToolCameras()
		end
	end
end
function AttacherJoints.attachableRemoveToolCameras(p957, p958)
	local v959 = p957.spec_attacherJoints
	p958(p957)
	for _, v960 in pairs(v959.attachedImplements) do
		local v961 = v960.object
		if v961 ~= nil and v961.attachableRemoveToolCameras ~= nil then
			v961:attachableRemoveToolCameras()
		end
	end
end
function AttacherJoints.registerSelectableObjects(p962, p963, p964)
	p963(p962, p964)
	local v965 = p962.spec_attacherJoints
	for _, v966 in pairs(v965.attachedImplements) do
		local v967 = v966.object
		if v967 ~= nil and v967.registerSelectableObjects ~= nil then
			v967:registerSelectableObjects(p964)
		end
	end
end
function AttacherJoints.getIsReadyForAutomatedTrainTravel(p968, p969)
	local v970 = p968.spec_attacherJoints
	for _, v971 in pairs(v970.attachedImplements) do
		local v972 = v971.object
		if v972 ~= nil and (v972.getIsReadyForAutomatedTrainTravel ~= nil and not v972:getIsReadyForAutomatedTrainTravel()) then
			return false
		end
	end
	return p969(p968)
end
function AttacherJoints.getIsAutomaticShiftingAllowed(p973, p974)
	local v975 = p973.spec_attacherJoints
	local v976 = p973:getLastSpeed()
	for _, v977 in pairs(v975.attachedImplements) do
		if v976 < 2 then
			if v977.attachingIsInProgress then
				return false
			end
			local v978 = v977.jointDescIndex
			if v975.attacherJoints[v978].isMoving then
				return false
			end
		end
		local v979 = v977.object
		if v979 ~= nil and (v979.getIsAutomaticShiftingAllowed ~= nil and not v979:getIsAutomaticShiftingAllowed()) then
			return false
		end
	end
	return p974(p973)
end
function AttacherJoints.loadDashboardGroupFromXML(p980, p981, p982, p983, p984)
	if not p981(p980, p982, p983, p984) then
		return false
	end
	p984.attacherJointIndices = {}
	local v985 = p982:getValue(p983 .. "#attacherJointIndices", nil, true)
	if v985 ~= nil then
		for _, v986 in ipairs(v985) do
			local v987 = p984.attacherJointIndices
			table.insert(v987, v986)
		end
	end
	if #p984.attacherJointIndices == 0 then
		p984.attacherJointIndices = nil
	end
	p984.attacherJointNodes = p982:getValue(p983 .. "#attacherJointNodes", nil, p980.components, p980.i3dMappings, true)
	if #p984.attacherJointNodes == 0 then
		p984.attacherJointNodes = nil
	end
	return true
end
function AttacherJoints.getIsDashboardGroupActive(p988, p989, p990)
	if p990.attacherJointNodes ~= nil and p988.finishedLoading then
		if p990.attacherJointIndices == nil then
			p990.attacherJointIndices = {}
		end
		for _, v991 in ipairs(p990.attacherJointNodes) do
			local v992 = p988:getAttacherJointIndexByNode(v991)
			if v992 ~= nil then
				local v993 = p990.attacherJointIndices
				table.insert(v993, v992)
			end
		end
		if #p990.attacherJointIndices == 0 then
			p990.attacherJointIndices = nil
		end
		p990.attacherJointNodes = nil
	end
	if p990.attacherJointIndices ~= nil then
		local v994 = false
		for _, v995 in ipairs(p990.attacherJointIndices) do
			if p988:getImplementFromAttacherJointIndex(v995) ~= nil then
				v994 = true
			end
		end
		if not v994 then
			return false
		end
	end
	return p989(p988, p990)
end
function AttacherJoints.loadAttacherJointHeightNode(p996, p997, p998, p999, p1000, p1001)
	p1000.disablingAttacherJointIndices = p998:getValue(p999 .. "#disablingAttacherJointIndices", "", true)
	return p997(p996, p998, p999, p1000, p1001)
end
function AttacherJoints.getIsAttacherJointHeightNodeActive(p1002, p1003, p1004)
	for _, v1005 in ipairs(p1004.disablingAttacherJointIndices) do
		if p1002:getImplementFromAttacherJointIndex(v1005) ~= nil then
			return false
		end
	end
	return p1003(p1002, p1004)
end
function AttacherJoints.isDetachAllowed(p1006, p1007)
	local v1008, v1009, v1010 = p1007(p1006)
	if not v1008 then
		return v1008, v1009, v1010
	end
	local v1011 = p1006.spec_attacherJoints
	for v1012, v1013 in ipairs(v1011.attacherJoints) do
		if not (v1013.allowDetachingWhileLifted or v1013.moveDown) then
			local v1014 = p1006:getImplementByJointDescIndex(v1012)
			if v1014 ~= nil then
				local v1015 = v1014.object:getInputAttacherJointByJointDescIndex(v1014.inputJointDescIndex)
				if v1015 ~= nil and not v1015.forceAllowDetachWhileLifted then
					return false, string.format(v1011.texts.lowerImplementFirst, v1014.object.typeDesc)
				end
			end
		end
	end
	return true
end
function AttacherJoints.getIsFoldAllowed(p1016, p1017, p1018, p1019)
	local v1020 = p1016.spec_attacherJoints
	for _, v1021 in ipairs(v1020.attacherJoints) do
		if not v1021.allowFoldingWhileAttached and v1021.jointIndex ~= 0 then
			return false, v1020.texts.warningFoldingAttacherJoint
		end
	end
	return p1017(p1016, p1018, p1019)
end
function AttacherJoints.getIsWheelFoliageDestructionAllowed(p1022, p1023, p1024)
	if not p1023(p1022, p1024) then
		return false
	end
	local v1025 = p1022.spec_attacherJoints
	for _, v1026 in pairs(v1025.attachedImplements) do
		local v1027 = v1026.object
		if v1027 ~= nil and (v1027.getBlockFoliageDestruction ~= nil and v1027:getBlockFoliageDestruction()) then
			return false
		end
	end
	return true
end
function AttacherJoints.getAreControlledActionsAllowed(p1028, p1029)
	local v1030, v1031 = p1029(p1028)
	if not v1030 then
		return false, v1031
	end
	local v1032 = p1028.spec_attacherJoints
	for _, v1033 in pairs(v1032.attachedImplements) do
		local v1034 = v1033.object
		if v1034 ~= nil and v1034.getAreControlledActionsAllowed ~= nil then
			local v1035
			v1035, v1031 = v1034:getAreControlledActionsAllowed()
			if not v1035 then
				return false, v1031
			end
		end
		if v1033.attachingIsInProgress then
			return false
		end
	end
	return true, v1031
end
function AttacherJoints.getConnectionHoseConfigIndex(p1036, p1037)
	local v1038 = p1037(p1036)
	local v1039 = p1036.xmlFile:getValue("vehicle.attacherJoints#connectionHoseConfigId", v1038)
	if p1036.configurations.attacherJoint ~= nil then
		local v1040 = string.format("vehicle.attacherJoints.attacherJointConfigurations.attacherJointConfiguration(%d)", p1036.configurations.attacherJoint - 1)
		v1039 = p1036.xmlFile:getValue(v1040 .. "#connectionHoseConfigId", v1039)
	end
	return v1039
end
function AttacherJoints.getPowerTakeOffConfigIndex(p1041, p1042)
	local v1043 = p1042(p1041)
	local v1044 = p1041.xmlFile:getValue("vehicle.attacherJoints#powerTakeOffConfigId", v1043)
	if p1041.configurations.attacherJoint ~= nil then
		local v1045 = string.format("vehicle.attacherJoints.attacherJointConfigurations.attacherJointConfiguration(%d)", p1041.configurations.attacherJoint - 1)
		v1044 = p1041.xmlFile:getValue(v1045 .. "#powerTakeOffConfigId", v1044)
	end
	return v1044
end
function AttacherJoints.onRegisterActionEvents(p1046, _, p1047)
	if p1046.isClient then
		local v1048 = p1046.spec_attacherJoints
		p1046:clearActionEventsTable(v1048.actionEvents)
		if p1047 then
			if #v1048.attacherJoints > 0 then
				local v1049 = p1046:getSelectedImplement()
				if v1049 ~= nil and v1049.object ~= p1046 then
					for _, v1050 in pairs(v1048.attachedImplements) do
						if v1050 == v1049 then
							v1049.object:registerLoweringActionEvent(v1048.actionEvents, InputAction.LOWER_IMPLEMENT, v1049.object, AttacherJoints.actionEventLowerImplement, false, true, false, true, nil, nil, true)
						end
					end
				end
				local _, v1051 = p1046:addPoweredActionEvent(v1048.actionEvents, InputAction.LOWER_ALL_IMPLEMENTS, p1046, AttacherJoints.actionEventLowerAllImplements, false, true, false, true, nil, nil, true)
				g_inputBinding:setActionEventTextVisibility(v1051, false)
			end
			if p1046:getSelectedVehicle() == p1046 then
				local v1052, _ = p1046:registerSelfLoweringActionEvent(v1048.actionEvents, InputAction.LOWER_IMPLEMENT, p1046, AttacherJoints.actionEventLowerImplement, false, true, false, true, nil, nil, true)
				if (v1052 == nil or not v1052) and #v1048.attachedImplements == 1 then
					local v1053 = v1048.attachedImplements[1]
					if v1053 ~= nil then
						v1053.object:registerLoweringActionEvent(v1048.actionEvents, InputAction.LOWER_IMPLEMENT, v1053.object, AttacherJoints.actionEventLowerImplement, false, true, false, true, nil, nil, true)
					end
				end
			end
			local _, v1054 = p1046:addActionEvent(v1048.actionEvents, InputAction.ATTACH, p1046, AttacherJoints.actionEventAttach, false, true, false, true, nil, nil, true)
			g_inputBinding:setActionEventTextPriority(v1054, GS_PRIO_VERY_HIGH)
			local _, v1055 = p1046:addActionEvent(v1048.actionEvents, InputAction.DETACH, p1046, AttacherJoints.actionEventDetach, false, true, false, true, nil, nil, true)
			g_inputBinding:setActionEventTextVisibility(v1055, false)
			AttacherJoints.updateActionEvents(p1046)
		end
	end
end
function AttacherJoints.onActivate(p1056)
	p1056:activateAttachments()
end
function AttacherJoints.onDeactivate(p1057)
	p1057:deactivateAttachments()
	if p1057.isClient then
		local v1058 = p1057.spec_attacherJoints
		g_soundManager:stopSample(v1058.samples.hydraulic)
		v1058.isHydraulicSamplePlaying = false
	end
end
function AttacherJoints.onReverseDirectionChanged(p1059, _)
	local v1060 = p1059.spec_attacherJoints
	if v1060.attacherJointCombos ~= nil then
		for _, v1061 in pairs(v1060.attacherJointCombos.joints) do
			local v1062 = v1061.time - v1060.attacherJointCombos.duration
			v1061.time = math.abs(v1062)
		end
	end
end
function AttacherJoints.onStateChange(p1063, p1064, p1065)
	local v1066 = p1063.spec_attacherJoints
	for _, v1067 in pairs(v1066.attachedImplements) do
		if v1067.object ~= nil then
			v1067.object:raiseStateChange(p1064, p1065)
		end
	end
	if p1064 == VehicleStateChange.LOWER_ALL_IMPLEMENTS and #v1066.attacherJoints > 0 then
		p1063:startAttacherJointCombo()
	end
end
function AttacherJoints.onLightsTypesMaskChanged(p1068, p1069)
	local v1070 = p1068.spec_attacherJoints
	for _, v1071 in pairs(v1070.attachedImplements) do
		local v1072 = v1071.object
		if v1072 ~= nil and v1072.setLightsTypesMask ~= nil then
			v1072:setLightsTypesMask(p1069, true, true)
		end
	end
end
function AttacherJoints.onTurnLightStateChanged(p1073, p1074)
	local v1075 = p1073.spec_attacherJoints
	for _, v1076 in pairs(v1075.attachedImplements) do
		local v1077 = v1076.object
		if v1077 ~= nil and v1077.setTurnLightState ~= nil then
			v1077:setTurnLightState(p1074, true, true)
		end
	end
end
function AttacherJoints.onBrakeLightsVisibilityChanged(p1078, p1079)
	local v1080 = p1078.spec_attacherJoints
	for _, v1081 in pairs(v1080.attachedImplements) do
		local v1082 = v1081.object
		if v1082 ~= nil and v1082.setBrakeLightsVisibility ~= nil then
			v1082:setBrakeLightsVisibility(p1079)
		end
	end
end
function AttacherJoints.onReverseLightsVisibilityChanged(p1083, p1084)
	local v1085 = p1083.spec_attacherJoints
	for _, v1086 in pairs(v1085.attachedImplements) do
		local v1087 = v1086.object
		if v1087 ~= nil and v1087.setReverseLightsVisibility ~= nil then
			v1087:setReverseLightsVisibility(p1084)
		end
	end
end
function AttacherJoints.onBeaconLightsVisibilityChanged(p1088, p1089)
	local v1090 = p1088.spec_attacherJoints
	for _, v1091 in pairs(v1090.attachedImplements) do
		local v1092 = v1091.object
		if v1092 ~= nil and v1092.setBeaconLightsVisibility ~= nil then
			v1092:setBeaconLightsVisibility(p1089, true, true)
		end
	end
end
function AttacherJoints.onBrake(p1093, p1094)
	local v1095 = p1093.spec_attacherJoints
	for _, v1096 in pairs(v1095.attachedImplements) do
		local v1097 = v1096.object
		if v1097 ~= nil and v1097.brake ~= nil then
			v1097:brake(p1094)
		end
	end
end
function AttacherJoints.onTurnedOn(p1098)
	local v1099 = p1098.spec_attacherJoints
	for _, v1100 in pairs(v1099.attachedImplements) do
		local v1101 = v1100.object
		if v1101 ~= nil then
			local v1102 = v1101.spec_turnOnVehicle
			if v1102 and v1102.turnedOnByAttacherVehicle then
				v1101:setIsTurnedOn(true, true)
			end
		end
	end
end
function AttacherJoints.onTurnedOff(p1103)
	local v1104 = p1103.spec_attacherJoints
	for _, v1105 in pairs(v1104.attachedImplements) do
		local v1106 = v1105.object
		if v1106 ~= nil then
			local v1107 = v1106.spec_turnOnVehicle
			if v1107 and v1107.turnedOnByAttacherVehicle then
				v1106:setIsTurnedOn(false, true)
			end
		end
	end
end
function AttacherJoints.onLeaveVehicle(p1108)
	local v1109 = p1108.spec_attacherJoints
	for _, v1110 in pairs(v1109.attachedImplements) do
		local v1111 = v1110.object
		if v1111 ~= nil then
			SpecializationUtil.raiseEvent(v1111, "onLeaveRootVehicle")
		end
	end
end
function AttacherJoints.getAttachableInfo(p1112)
	local v1113 = p1112.spec_attacherJoints.attachableInfo
	return v1113.attacherVehicle, v1113.attacherVehicleJointDescIndex, v1113.attachable, v1113.attachableJointDescIndex
end
function AttacherJoints.getAttacherJointCompatibility(p1114, p1115, p1116, p1117)
	if p1117.forcedAttachingDirection ~= 0 and (p1115.attacherJointDirection ~= nil and p1117.forcedAttachingDirection ~= p1115.attacherJointDirection) then
		return false
	end
	if p1115.isBlocked then
		return false
	end
	if p1115.subTypes == nil then
		if p1117.subTypes ~= nil then
			if p1117.subTypeShowWarning and p1115.subTypeShowWarning then
				return false, p1114.spec_attacherJoints.texts.warningToolNotCompatible
			else
				return false
			end
		end
	else
		if p1117.subTypes == nil then
			return false, p1114.spec_attacherJoints.texts.warningToolNotCompatible
		end
		local v1118 = false
		for v1119 = 1, #p1115.subTypes do
			for v1120 = 1, #p1117.subTypes do
				if p1115.subTypes[v1119] == p1117.subTypes[v1120] then
					v1118 = true
					break
				end
			end
		end
		if not v1118 then
			if p1115.subTypeShowWarning and p1117.subTypeShowWarning then
				return false, p1114.spec_attacherJoints.texts.warningToolNotCompatible
			else
				return false
			end
		end
	end
	if p1115.brandRestrictions ~= nil then
		local v1121 = false
		for v1122 = 1, #p1115.brandRestrictions do
			if p1116.brand ~= nil and p1116.brand == p1115.brandRestrictions[v1122] then
				v1121 = true
				break
			end
		end
		if not v1121 then
			local v1123 = ""
			for v1124 = 1, #p1115.brandRestrictions do
				if v1124 > 1 then
					v1123 = v1123 .. ", "
				end
				v1123 = v1123 .. p1115.brandRestrictions[v1124].title
			end
			return false, string.format(p1114.spec_attacherJoints.texts.warningToolBrandNotCompatible, v1123)
		end
	end
	if p1115.vehicleRestrictions ~= nil then
		local v1125 = false
		for v1126 = 1, #p1115.vehicleRestrictions do
			if p1116.configFileName:find(p1115.vehicleRestrictions[v1126]) ~= nil then
				v1125 = true
				break
			end
		end
		if not v1125 then
			return false, p1114.spec_attacherJoints.texts.warningToolNotCompatible
		end
	end
	return true
end
local v_u_1127 = AttacherJoints.getAttacherJointCompatibility
function AttacherJoints.findVehicleInAttachRange()
	log("function \'AttacherJoints.findVehicleInAttachRange\' is deprecated. Use \'AttacherJoints.updateVehiclesInAttachRange\' instead. Valid output of this function is now up to 5 frames delayed, if parameter 4 is not \'true\'.")
end
function AttacherJoints.updateVehiclesInAttachRange(p1128, p1129, p1130, p1131)
	-- upvalues: (copy) v_u_1127
	local v1132 = p1128.spec_attacherJoints
	if v1132 == nil then
		return nil, nil, nil, nil
	end
	local v1133 = v1132.attachableInfo
	local v1134 = v1132.pendingAttachableInfo
	if p1128.getAttachedImplements ~= nil then
		local v1135 = p1128:getAttachedImplements()
		for _, v1136 in pairs(v1135) do
			if v1136.object ~= nil then
				local v1137, v1138, v1139, v1140, v1141 = AttacherJoints.updateVehiclesInAttachRange(v1136.object, p1129, p1130, p1131)
				if v1137 ~= nil then
					v1133.attacherVehicle = v1137
					v1133.attacherVehicleJointDescIndex = v1138
					v1133.attachable = v1139
					v1133.attachableJointDescIndex = v1140
					v1133.warning = v1141
					return v1137, v1138, v1139, v1140, v1141
				end
			end
		end
	end
	local v1142 = #g_currentMission.vehicleSystem.inputAttacherJoints
	local v1143 = v1142 / 5
	local v1144 = math.floor(v1143)
	local v1145 = math.max(v1144, 1)
	local v1146 = v1132.lastInputAttacherCheckIndex % v1142 + 1
	local v1147 = v1146 + v1145
	local v1148 = math.min(v1147, v1142)
	if p1131 then
		v1148 = v1142
		v1146 = 1
	end
	v1132.lastInputAttacherCheckIndex = v1148 % v1142
	for v1149 = 1, #v1132.attacherJoints do
		local v1150 = v1132.attacherJoints[v1149]
		if v1150.jointIndex == 0 and p1128:getIsAttachingAllowed(v1150) then
			local v1151, v1152, v1153 = getWorldTranslation(v1150.jointTransform)
			for v1154 = v1146, v1148 do
				local v1155 = g_currentMission.vehicleSystem.inputAttacherJoints[v1154]
				if v1155.jointType == v1150.jointType and v1155.vehicle:getIsInputAttacherActive(v1155.inputAttacherJoint) then
					local v1156 = MathUtil.vector2LengthSq(v1151 - v1155.translation[1], v1153 - v1155.translation[3])
					if v1156 < p1129 and v1156 < v1134.minDistance then
						local v1157 = v1152 - v1155.translation[2]
						local v1158 = v1157 * v1157
						if v1158 < p1129 * 4 and (v1158 < v1134.minDistanceY and (v1155.vehicle:getActiveInputAttacherJointDescIndex() == nil or v1155.vehicle:getAllowMultipleAttachments())) then
							local v1159, v1160 = v_u_1127(p1128, v1150, v1155.vehicle, v1155.inputAttacherJoint)
							if v1159 then
								local v1161 = v1155.inputAttacherJoint.attachAngleLimitAxis
								local v1162
								if v1161 == 1 then
									local v1163, _, _ = localDirectionToLocal(v1155.node, v1150.jointTransform, 1, 0, 0)
									v1162 = p1130 < v1163
								elseif v1161 == 2 then
									local _, v1164, _ = localDirectionToLocal(v1155.node, v1150.jointTransform, 0, 1, 0)
									v1162 = p1130 < v1164
								else
									local _, _, v1165 = localDirectionToLocal(v1155.node, v1150.jointTransform, 0, 0, 1)
									v1162 = p1130 < v1165
								end
								if v1162 then
									v1134.minDistance = v1156
									v1134.minDistanceY = v1158
									v1134.attacherVehicle = p1128
									v1134.attacherVehicleJointDescIndex = v1149
									v1134.attachable = v1155.vehicle
									v1134.attachableJointDescIndex = v1155.jointIndex
								end
							else
								v1134.warning = v1134.warning or v1160
							end
						end
					end
				end
			end
		end
	end
	if v1132.lastInputAttacherCheckIndex == 0 then
		v1133.attacherVehicle = v1134.attacherVehicle
		v1133.attacherVehicleJointDescIndex = v1134.attacherVehicleJointDescIndex
		v1133.attachable = v1134.attachable
		v1133.attachableJointDescIndex = v1134.attachableJointDescIndex
		v1133.warning = v1134.warning
		v1134.minDistance = (1 / 0)
		v1134.minDistanceY = (1 / 0)
		v1134.attacherVehicle = nil
		v1134.attacherVehicleJointDescIndex = nil
		v1134.attachable = nil
		v1134.attachableJointDescIndex = nil
		v1134.warning = nil
	end
	return v1133.attacherVehicle, v1133.attacherVehicleJointDescIndex, v1133.attachable, v1133.attachableJointDescIndex, v1133.warning
end
function AttacherJoints.actionEventAttach(p1166, _, _, _, _)
	local v1167 = p1166.spec_attacherJoints.attachableInfo
	if v1167.attachable == nil then
		local v1168 = p1166:getSelectedVehicle()
		if v1168 ~= nil and (v1168 ~= p1166 and v1168.isDetachAllowed ~= nil) then
			local v1169, v1170, v1171 = v1168:isDetachAllowed()
			if v1169 then
				v1168:startDetachProcess()
				return
			end
			if v1171 == nil or v1171 then
				g_currentMission:showBlinkingWarning(v1170 or p1166.spec_attacherJoints.texts.detachNotAllowed, 2000)
			end
		end
	else
		local v1172, v1173 = v1167.attachable:isAttachAllowed(p1166:getActiveFarm(), v1167.attacherVehicle)
		if v1172 then
			if p1166.isServer then
				p1166:attachImplementFromInfo(v1167)
			else
				g_client:getServerConnection():sendEvent(VehicleAttachRequestEvent.new(v1167))
			end
		end
		if v1173 ~= nil then
			g_currentMission:showBlinkingWarning(v1173, 2000)
			return
		end
	end
end
function AttacherJoints.actionEventDetach(p1174, _, _, _, _)
	local v1175 = p1174:getSelectedVehicle()
	if v1175 ~= nil and (v1175 ~= p1174 and v1175.isDetachAllowed ~= nil) then
		local v1176, v1177, v1178 = v1175:isDetachAllowed()
		if v1176 then
			v1175:startDetachProcess()
			return
		end
		if v1178 == nil or v1178 then
			g_currentMission:showBlinkingWarning(v1177 or p1174.spec_attacherJoints.texts.detachNotAllowed, 2000)
		end
	end
end
function AttacherJoints.actionEventLowerImplement(p1179, _, _, _, _)
	if p1179.getAttacherVehicle ~= nil then
		p1179:getAttacherVehicle():handleLowerImplementEvent()
	end
end
function AttacherJoints.actionEventLowerAllImplements(p1180, _, _, _, _)
	p1180:startAttacherJointCombo(true)
	p1180.rootVehicle:raiseStateChange(VehicleStateChange.LOWER_ALL_IMPLEMENTS)
end
function AttacherJoints.updateActionEvents(p1181)
	local v1182 = p1181.spec_attacherJoints
	local v1183 = v1182.attachableInfo
	if p1181.isClient and v1182.actionEvents ~= nil then
		local v1184 = v1182.actionEvents[InputAction.ATTACH]
		if v1184 ~= nil then
			local v1185 = false
			if p1181:getCanToggleAttach() then
				if v1183.warning ~= nil then
					g_currentMission:showBlinkingWarning(v1183.warning, 500)
				end
				local v1186 = GS_PRIO_VERY_LOW
				local v1187 = p1181:getSelectedVehicle()
				local v1188
				if v1187 == nil or (v1187.isDeleted or (v1187.isDetachAllowed == nil or (not v1187:isDetachAllowed() or v1187:getAttacherVehicle() == nil))) then
					v1188 = ""
				else
					v1188 = v1182.texts.actionDetach
					v1185 = true
				end
				if v1183.attacherVehicle ~= nil then
					if g_currentMission.accessHandler:canFarmAccess(p1181:getActiveFarm(), v1183.attachable) then
						v1188 = v1182.texts.actionAttach
						g_currentMission:showAttachContext(v1183.attachable)
						v1186 = GS_PRIO_VERY_HIGH
						v1185 = true
					else
						v1182.showAttachNotAllowedText = 100
					end
				end
				g_inputBinding:setActionEventText(v1184.actionEventId, v1188)
				g_inputBinding:setActionEventTextPriority(v1184.actionEventId, v1186)
			end
			g_inputBinding:setActionEventTextVisibility(v1184.actionEventId, v1185)
		end
		local v1189 = v1182.actionEvents[InputAction.LOWER_IMPLEMENT]
		if v1189 ~= nil then
			local v1190 = false
			local v1191 = ""
			local v1192 = p1181:getSelectedImplement()
			if v1192 == nil then
				if #v1182.attachedImplements == 1 then
					v1190, v1191 = v1182.attachedImplements[1].object:getLoweringActionEventState()
				end
			else
				for _, v1193 in pairs(v1182.attachedImplements) do
					if v1193 == v1192 then
						v1190, v1191 = v1193.object:getLoweringActionEventState()
						break
					end
				end
			end
			g_inputBinding:setActionEventActive(v1189.actionEventId, v1190)
			g_inputBinding:setActionEventText(v1189.actionEventId, v1191)
			g_inputBinding:setActionEventTextPriority(v1189.actionEventId, GS_PRIO_NORMAL)
		end
	end
end
function AttacherJoints.updateAttacherJointLimits(p1194, p1195, p1196, p1197)
	local v1198 = p1195.lowerRotLimit[p1197] * p1196.lowerRotLimitScale[p1197]
	local v1199 = p1195.upperRotLimit[p1197] * p1196.upperRotLimitScale[p1197]
	if p1196.fixedRotation then
		v1198 = 0
		v1199 = 0
	end
	local v1200 = p1195.lowerTransLimit[p1197] * p1196.lowerTransLimitScale[p1197]
	local v1201 = p1195.upperTransLimit[p1197] * p1196.upperTransLimitScale[p1197]
	p1194.lowerRotLimit[p1197] = v1198
	p1194.upperRotLimit[p1197] = v1199
	p1194.lowerTransLimit[p1197] = v1200
	p1194.upperTransLimit[p1197] = v1201
	if not p1195.allowsLowering then
		p1194.upperRotLimit[p1197] = v1198
		p1194.upperTransLimit[p1197] = v1200
	end
	if p1195.allowsLowering and p1195.allowsJointLimitMovement then
		if p1196.allowsJointRotLimitMovement then
			v1198 = MathUtil.lerp(v1199, v1198, p1195.moveAlpha)
		end
		if p1196.allowsJointTransLimitMovement then
			v1200 = MathUtil.lerp(v1201, v1200, p1195.moveAlpha)
		end
	end
	return v1198, v1200
end
function AttacherJoints.updateAttacherJointRotationLimit(p1202, p1203, p1204, p1205, p1206)
	local v1207 = MathUtil.lerp
	local v1208 = p1202.attachingRotLimit[p1204]
	local v1209 = p1202.upperRotLimit[p1204]
	local v1210 = math.max(v1208, v1209)
	local v1211 = p1202.attachingRotLimit[p1204]
	local v1212 = p1202.lowerRotLimit[p1204]
	local v1213 = v1207(v1210, math.max(v1211, v1212), p1206)
	if not p1205 then
		local v1214 = v1213 - p1202.jointRotLimit[p1204]
		if math.abs(v1214) <= 0.0005 then
			::l3::
			return
		end
	end
	local v1215 = -v1213
	local v1216
	if p1204 == 3 then
		if p1203.lockDownRotLimit then
			local v1217 = -p1202.attachingRotLimit[p1204]
			v1215 = math.min(v1217, 0)
		end
		if p1203.lockUpRotLimit then
			local v1218 = p1202.attachingRotLimit[p1204]
			v1216 = math.max(v1218, 0)
		else
			v1216 = v1213
		end
		if p1203.dynamicLowerRotLimit and p1203.rotationNode ~= nil then
			local v1219 = p1203.upperRotation[1] - p1203.lowerRotation[1]
			v1216 = math.abs(v1219) * p1206
			v1215 = 0
		end
	else
		v1216 = v1213
	end
	setJointRotationLimit(p1203.jointIndex, p1204 - 1, true, v1215, v1216)
	p1202.jointRotLimit[p1204] = v1213
	goto l3
end
function AttacherJoints.updateAttacherJointTranslationLimit(p1220, p1221, p1222, p1223, p1224)
	local v1225 = MathUtil.lerp
	local v1226 = p1220.attachingTransLimit[p1222]
	local v1227 = p1220.upperTransLimit[p1222]
	local v1228 = math.max(v1226, v1227)
	local v1229 = p1220.attachingTransLimit[p1222]
	local v1230 = p1220.lowerTransLimit[p1222]
	local v1231 = v1225(v1228, math.max(v1229, v1230), p1224)
	if p1223 then
		::l2::
		local v1232 = -v1231
		local v1233
		if p1222 == 2 then
			if p1221.lockDownTransLimit then
				local v1234 = -p1220.attachingTransLimit[p1222]
				v1232 = math.min(v1234, 0)
			end
			if p1221.lockUpTransLimit then
				local v1235 = p1220.attachingTransLimit[p1222]
				v1233 = math.max(v1235, 0)
			else
				v1233 = v1231
			end
		else
			v1233 = v1231
		end
		setJointTranslationLimit(p1221.jointIndex, p1222 - 1, true, v1232, v1233)
		p1220.jointTransLimit[p1222] = v1231
	else
		local v1236 = v1231 - p1220.jointTransLimit[p1222]
		if math.abs(v1236) > 0.0005 then
			goto l2
		end
	end
end
function AttacherJoints.updateRequiredTopLightsState(p1237)
	local v1238 = p1237.spec_attacherJoints
	local v1239 = false
	for _, v1240 in ipairs(v1238.attachedImplements) do
		local v1241 = v1238.attacherJoints[v1240.jointDescIndex]
		local v1242 = v1240.object:getActiveInputAttacherJoint()
		if v1241.useTopLights and v1242.useTopLights then
			v1239 = true
			break
		end
	end
	SpecializationUtil.raiseEvent(p1237, "onRequiresTopLightsChanged", v1239)
end
function AttacherJoints.consoleCommandBottomArmWidth(_, p1243, p1244)
	local v1245
	if p1244 == nil then
		v1245 = AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[tonumber(p1243) or 2]
	else
		v1245 = tonumber(p1244) or AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[2]
	end
	Logging.info("Set bottom arm width to %.3f m. (Category %d)", v1245, AttacherJoints.getClosestLowerLinkCategoryIndex(v1245))
	if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
		for _, v1246 in ipairs(g_localPlayer:getCurrentVehicle().childVehicles) do
			local v1247 = v1246.spec_attacherJoints
			if v1247 ~= nil then
				for v1248, _ in ipairs(v1247.attacherJoints) do
					v1246:setAttacherJointBottomArmWidth(v1248, v1245)
				end
			end
		end
	end
end
addConsoleCommand("gsVehicleBottomArmSetWidth", "Sets the width of the bottom arm to a certain category width", "consoleCommandBottomArmWidth", AttacherJoints)

Consumable = {}
Consumable.CONSUME_LEVEL_NUM_BITS = 7
Consumable.CONSUME_LEVEL_RESOLUTION = 2 ^ Consumable.CONSUME_LEVEL_NUM_BITS - 1
source("dataS/scripts/vehicles/specializations/events/ConsumableRefillEvent.lua")
source("dataS/scripts/vehicles/specializations/activatables/ConsumableActivatable.lua")
Consumable.CONFIG_NAMES = { "consumable", "consumable2" }
function Consumable.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(FillUnit, p1)
end
function Consumable.initSpecialization()
	for _, v2 in ipairs(Consumable.CONFIG_NAMES) do
		g_vehicleConfigurationManager:addConfigurationType(v2, g_i18n:getText("shop_configuration"), "consumable", VehicleConfigurationItem)
	end
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Consumable")
	for _, v4 in ipairs(Consumable.CONFIG_NAMES) do
		v3:register(XMLValueType.STRING, "vehicle.consumable." .. v4 .. "Configurations#typeName", "Name of the consumable type that can be filled")
		v3:register(XMLValueType.STRING, "vehicle.consumable." .. v4 .. "Configurations." .. v4 .. "Configuration(?)#consumableName", "Consumable Name")
	end
	v3:register(XMLValueType.STRING, "vehicle.consumable.type(?)#typeName", "Name of the consumable type that can be filled")
	v3:register(XMLValueType.STRING, "vehicle.consumable.type(?)#defaultConsumableName", "Name of the consumable that is loaded by default, if not given the tool spawns empty")
	v3:register(XMLValueType.INT, "vehicle.consumable.type(?)#fillUnitIndex", "Fill unit index of the consumable fill unit", 1)
	v3:register(XMLValueType.BOOL, "vehicle.consumable.type(?)#allowRefillDialog", "Defines if the type can be refilled via the UI dialog", true)
	v3:register(XMLValueType.BOOL, "vehicle.consumable.type(?)#showWarning", "Show warning if the consumable is empty", true)
	v3:register(XMLValueType.BOOL, "vehicle.consumable.type(?).consuming#useScale", "Scale the consuming meshes based on the fill level", false)
	v3:register(XMLValueType.BOOL, "vehicle.consumable.type(?).consuming#useAmount", "Apply the fill level to the \'amount\' shader parameter", false)
	v3:register(XMLValueType.BOOL, "vehicle.consumable.type(?).consuming#useHideByIndex", "Apply hideByIndex shader parameter to the consuming mesh", false)
	v3:register(XMLValueType.FLOAT, "vehicle.consumable.type(?).consuming#hideByIndexOffset", "Offset for the hide by index fill level", 0)
	v3:register(XMLValueType.STRING, "vehicle.consumable.type(?).consuming.animation(?)#name", "Name of the animation that is set based on the consuming fill level")
	v3:register(XMLValueType.FLOAT, "vehicle.consumable.type(?).consuming.animation(?)#numLoops", "Number of times the animation is looping for the capacity of the consuming slots", 1)
	v3:register(XMLValueType.INT, "vehicle.consumable.type(?).consuming.animation(?)#numSteps", "If defined, the animation will move in steps")
	v3:register(XMLValueType.FLOAT, "vehicle.consumable.type(?).consuming.animation(?)#speedScale", "Speed of the animation", 1)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.consumable.type(?).slot(?)#node", "Link node of visual slot")
	v3:register(XMLValueType.BOOL, "vehicle.consumable.type(?).slot(?)#isConsumingSlot", "Slot is a consuming slot (different 3d model without packing if available)", false)
	v3:register(XMLValueType.BOOL, "vehicle.consumable.type(?).slot(?)#useTensionBeltMesh", "A tension belt mesh will be loaded for this slot if available", "\'true\' for pallets")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.consumable.type(?).shaderParameterNode(?)#node", "Shader parameter defined in the consumable variation will be applied here as well")
	ObjectChangeUtil.registerObjectChangeXMLPaths(v3, "vehicle.consumable.type(?)")
	v3:setXMLSpecializationType()
	local v5 = Vehicle.xmlSchemaSavegame
	v5:register(XMLValueType.STRING, "vehicles.vehicle(?).consumable.type(?)#typeName", "Consumer type name")
	v5:register(XMLValueType.FLOAT, "vehicles.vehicle(?).consumable.type(?)#consumingFillLevel", "Fill Level of consuming slots")
	v5:register(XMLValueType.STRING, "vehicles.vehicle(?).consumable.type(?)#consumingVariationName", "Name of the variation that is currently loaded on the consuming slots")
	v5:register(XMLValueType.STRING, "vehicles.vehicle(?).consumable.type(?).storageSlot(?)#consumableVariation", "Currently loaded consumer variation for slot")
end
function Consumable.registerEvents(p6)
	SpecializationUtil.registerEvent(p6, "onConsumableVariationChanged")
end
function Consumable.registerFunctions(p7)
	SpecializationUtil.registerFunction(p7, "getConsumableVariationIndexByFillUnitIndex", Consumable.getConsumableVariationIndexByFillUnitIndex)
	SpecializationUtil.registerFunction(p7, "setConsumableSlotVariationIndex", Consumable.setConsumableSlotVariationIndex)
	SpecializationUtil.registerFunction(p7, "updateConsumable", Consumable.updateConsumable)
	SpecializationUtil.registerFunction(p7, "getConsumableIsAvailable", Consumable.getConsumableIsAvailable)
	SpecializationUtil.registerFunction(p7, "getShowConsumableEmptyWarning", Consumable.getShowConsumableEmptyWarning)
	SpecializationUtil.registerFunction(p7, "getCustomFillTriggerSpeedFactor", Consumable.getCustomFillTriggerSpeedFactor)
end
function Consumable.registerOverwrittenFunctions(p8)
	SpecializationUtil.registerOverwrittenFunction(p8, "addFillUnitFillLevel", Consumable.addFillUnitFillLevel)
	SpecializationUtil.registerOverwrittenFunction(p8, "getFillUnitFreeCapacity", Consumable.getFillUnitFreeCapacity)
	SpecializationUtil.registerOverwrittenFunction(p8, "collectPalletTensionBeltNodes", Consumable.collectPalletTensionBeltNodes)
end
function Consumable.registerEventListeners(p9)
	SpecializationUtil.registerEventListener(p9, "onLoad", Consumable)
	SpecializationUtil.registerEventListener(p9, "onPostLoad", Consumable)
	SpecializationUtil.registerEventListener(p9, "onReadStream", Consumable)
	SpecializationUtil.registerEventListener(p9, "onWriteStream", Consumable)
	SpecializationUtil.registerEventListener(p9, "onReadUpdateStream", Consumable)
	SpecializationUtil.registerEventListener(p9, "onWriteUpdateStream", Consumable)
	SpecializationUtil.registerEventListener(p9, "onUpdate", Consumable)
	SpecializationUtil.registerEventListener(p9, "onDraw", Consumable)
	SpecializationUtil.registerEventListener(p9, "onFillUnitFillLevelChanged", Consumable)
	SpecializationUtil.registerEventListener(p9, "onFillUnitIsFillingStateChanged", Consumable)
	SpecializationUtil.registerEventListener(p9, "onAddedFillUnitTrigger", Consumable)
	SpecializationUtil.registerEventListener(p9, "onRemovedFillUnitTrigger", Consumable)
end
function Consumable.onLoad(p10, _)
	local v11 = p10.spec_consumable
	v11.animationsDirty = false
	v11.types = {}
	v11.typesByName = {}
	for _, v12 in p10.xmlFile:iterator("vehicle.consumable.type") do
		local v13 = {
			["typeName"] = p10.xmlFile:getValue(v12 .. "#typeName")
		}
		if v13.typeName == nil then
			Logging.xmlWarning(p10.xmlFile, "Missing type name in \'%s\'", v12)
		else
			v13.fillUnitIndex = p10.xmlFile:getValue(v12 .. "#fillUnitIndex")
			if v13.fillUnitIndex == nil then
				Logging.xmlWarning(p10.xmlFile, "Missing fillUnitIndex in \'%s\'", v12)
			elseif p10:getFillUnitByIndex(v13.fillUnitIndex) == nil then
				Logging.xmlWarning(p10.xmlFile, "Invalid fillUnitIndex in \'%s\'", v12)
			else
				v13.defaultConsumableName = p10.xmlFile:getValue(v12 .. "#defaultConsumableName")
				v13.allowRefillDialog = p10.xmlFile:getValue(v12 .. "#allowRefillDialog", true)
				v13.showWarning = p10.xmlFile:getValue(v12 .. "#showWarning", true)
				v13.slots = {}
				v13.storageSlots = {}
				v13.consumingSlots = {}
				for _, v14 in p10.xmlFile:iterator(v12 .. ".slot") do
					local v15 = {
						["node"] = p10.xmlFile:getValue(v14 .. "#node", nil, p10.components, p10.i3dMappings),
						["isConsumingSlot"] = p10.xmlFile:getValue(v14 .. "#isConsumingSlot", false),
						["useTensionBeltMesh"] = p10.xmlFile:getValue(v14 .. "#useTensionBeltMesh", p10.setPalletTensionBeltNodesDirty ~= nil),
						["mesh"] = nil,
						["consumingMesh"] = nil,
						["consumableVariationIndex"] = 0
					}
					if v15.isConsumingSlot then
						local v16 = v13.consumingSlots
						table.insert(v16, v15)
					else
						local v17 = v13.storageSlots
						table.insert(v17, v15)
					end
					local v18 = v13.slots
					table.insert(v18, v15)
				end
				v13.useScale = p10.xmlFile:getValue(v12 .. ".consuming#useScale", false)
				v13.useAmount = p10.xmlFile:getValue(v12 .. ".consuming#useAmount", false)
				v13.useHideByIndex = p10.xmlFile:getValue(v12 .. ".consuming#useHideByIndex", false)
				v13.hideByIndexOffset = p10.xmlFile:getValue(v12 .. ".consuming#hideByIndexOffset", 0)
				v13.animations = {}
				for _, v19 in p10.xmlFile:iterator(v12 .. ".consuming.animation") do
					local v20 = {
						["name"] = p10.xmlFile:getValue(v19 .. "#name")
					}
					if v20.name ~= nil then
						local v21 = p10.xmlFile:getValue(v19 .. "#numLoops", 1)
						v20.numLoops = math.max(v21, 1)
						v20.numSteps = p10.xmlFile:getValue(v19 .. "#numSteps")
						v20.speedScale = p10.xmlFile:getValue(v19 .. "#speedScale", 1) * 0.001
						v20.currentTime = 0
						local v22 = v13.animations
						table.insert(v22, v20)
					end
				end
				v13.numSlots = #v13.slots
				v13.numStorageSlots = #v13.storageSlots
				v13.numConsumingSlots = #v13.consumingSlots
				v13.objectChanges = {}
				ObjectChangeUtil.loadObjectChangeFromXML(p10.xmlFile, v12, v13.objectChanges, p10.components, p10)
				ObjectChangeUtil.setObjectChanges(v13.objectChanges, false, p10, p10.setMovingToolDirty)
				v13.shaderParameterNodes = {}
				for _, v23 in p10.xmlFile:iterator(v12 .. ".shaderParameterNode") do
					local v24 = p10.xmlFile:getValue(v23 .. "#node", nil, p10.components, p10.i3dMappings)
					if v24 ~= nil then
						local v25 = v13.shaderParameterNodes
						table.insert(v25, v24)
					end
				end
				v13.consumingFillLevel = 0
				v13.consumingFillLevelSent = 0
				v13.consumingVariationIndex = 0
				v13.lastConsumedVariationIndex = 0
				v13.isDirty = false
				p10:setFillUnitCapacity(v13.fillUnitIndex, v13.numStorageSlots + v13.numConsumingSlots)
				p10:setFillUnitCapacityToDisplay(v13.fillUnitIndex, v13.numStorageSlots + v13.numConsumingSlots)
				local v26 = v11.types
				table.insert(v26, v13)
				v13.index = #v11.types
				v11.typesByName[v13.typeName] = v13
			end
		end
	end
	for _, v27 in ipairs(Consumable.CONFIG_NAMES) do
		local v28 = string.format("vehicle.consumable.%sConfigurations", v27)
		if p10.xmlFile:hasProperty(v28) then
			local v29 = p10.configurations[v27] or 1
			local v30 = p10.xmlFile:getValue(v28 .. "#typeName")
			if v30 ~= nil then
				local v31 = v11.typesByName[v30]
				if v31 == nil then
					Logging.xmlWarning(p10.xmlFile, "Consumable type name \'%s\' not found for configuration \'%s\'", v30, v27)
				else
					local v32 = string.format("%s.%sConfiguration(%d)", v28, v27, v29 - 1)
					v31.defaultConsumableName = p10.xmlFile:getValue(v32 .. "#consumableName")
				end
			end
		end
	end
	v11.activatable = ConsumableActivatable.new(p10)
	v11.dirtyFlag = p10:getNextDirtyFlag()
end
function Consumable.onPostLoad(p33, p34)
	local v35 = p33.spec_consumable
	if p34 == nil then
		if not p33.vehicleLoadingData:getCustomParameter("spawnEmpty") then
			for _, v36 in ipairs(v35.types) do
				if v36.defaultConsumableName ~= nil then
					p33:addFillUnitFillLevel(p33:getOwnerFarmId(), v36.fillUnitIndex, v36.numStorageSlots, p33:getFillUnitFirstSupportedFillType(v36.fillUnitIndex), ToolType.UNDEFINED, nil)
					v36.consumingFillLevel = 1
					v36.consumingVariationIndex = g_consumableManager:getConsumableVariationIndexByName(v36.defaultConsumableName, p33.customEnvironment)
					p33:updateConsumable(v36.typeName, 0)
				end
			end
		end
	elseif not p34.resetVehicles then
		local v37 = p34.key .. ".consumable"
		for _, v38 in p34.xmlFile:iterator(v37 .. ".type") do
			local v39 = p34.xmlFile:getValue(v38 .. "#typeName")
			local v40 = v35.typesByName[v39]
			if v40 ~= nil then
				v40.consumingFillLevel = p34.xmlFile:getValue(v38 .. "#consumingFillLevel", 0)
				local v41 = p34.xmlFile:getValue(v38 .. "#consumingVariationName")
				v40.consumingVariationIndex = g_consumableManager:getConsumableVariationIndexByName(v41, p33.customEnvironment)
				for v42, v43 in p34.xmlFile:iterator(v38 .. ".storageSlot") do
					local v44 = p34.xmlFile:getValue(v43 .. "#consumableVariation")
					if v44 ~= nil then
						local v45 = g_consumableManager:getConsumableVariationIndexByName(v44, p33.customEnvironment)
						p33:setConsumableSlotVariationIndex(v40.index, v42, v45)
					end
				end
				p33:updateConsumable(v40.typeName, 0)
				if p33.updatePalletStraps ~= nil then
					p33:updatePalletStraps()
				end
			end
		end
	end
	Consumable.updateActivatable(p33)
end
function Consumable.saveToXMLFile(p46, p47, p48, _)
	local v49 = p46.spec_consumable
	for v50, v51 in ipairs(v49.types) do
		local v52 = string.format("%s.type(%d)", p48, v50 - 1)
		p47:setValue(v52 .. "#typeName", v51.typeName)
		p47:setValue(v52 .. "#consumingFillLevel", v51.consumingFillLevel)
		p47:setValue(v52 .. "#consumingVariationName", g_consumableManager:getConsumableVariationNameByIndex(v51.consumingVariationIndex))
		for v53, v54 in ipairs(v51.storageSlots) do
			p47:setValue(string.format("%s.storageSlot(%d)", v52, v53 - 1) .. "#consumableVariation", g_consumableManager:getConsumableVariationNameByIndex(v54.consumableVariationIndex))
		end
	end
end
function Consumable.onReadStream(p55, p56, p57)
	if p57:getIsServer() then
		local v58 = p55.spec_consumable
		for _, v59 in ipairs(v58.types) do
			if v59.numConsumingSlots > 0 then
				v59.consumingFillLevel = streamReadUIntN(p56, Consumable.CONSUME_LEVEL_NUM_BITS) / Consumable.CONSUME_LEVEL_RESOLUTION
				v59.consumingVariationIndex = streamReadUIntN(p56, ConsumableManager.NUM_VARIATION_BITS)
				p55:updateConsumable(v59.typeName, 0)
			end
			for v60, _ in ipairs(v59.storageSlots) do
				local v61 = streamReadUIntN(p56, ConsumableManager.NUM_VARIATION_BITS)
				p55:setConsumableSlotVariationIndex(v59.index, v60, v61)
			end
		end
		if p55.updatePalletStraps ~= nil then
			p55:updatePalletStraps()
		end
	end
end
function Consumable.onWriteStream(p62, p63, p64)
	if not p64:getIsServer() then
		local v65 = p62.spec_consumable
		for _, v66 in ipairs(v65.types) do
			if v66.numConsumingSlots > 0 then
				streamWriteUIntN(p63, v66.consumingFillLevel * Consumable.CONSUME_LEVEL_RESOLUTION, Consumable.CONSUME_LEVEL_NUM_BITS)
				streamWriteUIntN(p63, v66.consumingVariationIndex, ConsumableManager.NUM_VARIATION_BITS)
			end
			for _, v67 in ipairs(v66.storageSlots) do
				streamWriteUIntN(p63, v67.consumableVariationIndex, ConsumableManager.NUM_VARIATION_BITS)
			end
		end
	end
end
function Consumable.onReadUpdateStream(p68, p69, _, p70)
	if p70:getIsServer() then
		local v71 = p68.spec_consumable
		if streamReadBool(p69) then
			for _, v72 in ipairs(v71.types) do
				if streamReadBool(p69) then
					v72.consumingFillLevel = streamReadUIntN(p69, Consumable.CONSUME_LEVEL_NUM_BITS) / Consumable.CONSUME_LEVEL_RESOLUTION
					v72.consumingVariationIndex = streamReadUIntN(p69, ConsumableManager.NUM_VARIATION_BITS)
					p68:updateConsumable(v72.typeName, 0)
				end
				if streamReadBool(p69) then
					for v73, _ in ipairs(v72.storageSlots) do
						local v74 = streamReadUIntN(p69, ConsumableManager.NUM_VARIATION_BITS)
						p68:setConsumableSlotVariationIndex(v72.index, v73, v74)
					end
					if p68.updatePalletStraps ~= nil then
						p68:updatePalletStraps()
					end
				end
			end
		end
	end
end
function Consumable.onWriteUpdateStream(p75, p76, p77, p78)
	if not p77:getIsServer() then
		local v79 = p75.spec_consumable
		if streamWriteBool(p76, bitAND(p78, v79.dirtyFlag) ~= 0) then
			for _, v80 in ipairs(v79.types) do
				if streamWriteBool(p76, v80.isDirty) then
					streamWriteUIntN(p76, v80.consumingFillLevel * Consumable.CONSUME_LEVEL_RESOLUTION, Consumable.CONSUME_LEVEL_NUM_BITS)
					streamWriteUIntN(p76, v80.consumingVariationIndex, ConsumableManager.NUM_VARIATION_BITS)
					v80.isDirty = false
				end
				local v81 = false
				for _, v82 in ipairs(v80.storageSlots) do
					if v82.isDirty then
						v81 = true
						break
					end
				end
				if streamWriteBool(p76, v81) then
					for _, v83 in ipairs(v80.storageSlots) do
						streamWriteUIntN(p76, v83.consumableVariationIndex, ConsumableManager.NUM_VARIATION_BITS)
						v83.isDirty = false
					end
				end
			end
		end
	end
end
function Consumable.onUpdate(p84, p85, _, _, _)
	local v86 = p84.spec_consumable
	if v86.types ~= nil and v86.animationsDirty then
		v86.animationsDirty = false
		for _, v87 in ipairs(v86.types) do
			for _, v88 in ipairs(v87.animations) do
				if v88.isDirty then
					local v89 = v88.targetTime - v88.currentTime
					local v90 = math.sign(v89)
					v88.currentTime = (v90 > 0 and math.min or math.max)(v88.currentTime + v90 * p85 * v88.speedScale, v88.targetTime)
					if v88.currentTime > 1 and v88.targetTime > 1 then
						v88.currentTime = v88.currentTime - 1
						v88.targetTime = v88.targetTime - 1
					elseif v88.currentTime < 0 and v88.targetTime < 0 then
						v88.currentTime = v88.currentTime + 1
						v88.targetTime = v88.targetTime + 1
					end
					p84:setAnimationTime(v88.name, v88.currentTime, true)
					v88.isDirty = v88.targetTime ~= v88.currentTime
					if v88.isDirty then
						v86.animationsDirty = true
						p84:raiseActive()
					end
				end
			end
		end
	end
end
function Consumable.onDraw(p91, _, _, _)
	local v92 = p91.spec_consumable
	if v92.types ~= nil then
		for _, v93 in ipairs(v92.types) do
			if v93.showWarning and (v93.numConsumingSlots > 0 and (v93.consumingFillLevel == 0 and (p91:getFillUnitFillLevel(v93.fillUnitIndex) == 0 and p91:getShowConsumableEmptyWarning(v93.typeName)))) then
				local v94 = string.format(g_i18n:getText("warning_consumableEmpty"), g_consumableManager:getTypeTitle(v93.typeName))
				g_currentMission:showBlinkingWarning(v94, 500)
				return
			end
		end
	end
end
function Consumable.onFillUnitFillLevelChanged(p95, p96, _, _, _, _, _)
	if p95.isServer then
		local v97 = p95.spec_consumable
		if v97.types ~= nil then
			local v98 = p95:getFillUnitFillLevel(p96)
			for _, v99 in ipairs(v97.types) do
				if p96 == v99.fillUnitIndex then
					local v100 = 0
					for _, v101 in ipairs(v99.storageSlots) do
						if v101.consumableVariationIndex ~= 0 then
							v100 = v100 + 1
						end
					end
					local v102 = v98 - v100
					local v103 = math.abs(v102)
					if v99.numStorageSlots > 0 then
						v103 = math.floor(v103)
					end
					if v103 > 0 then
						if v100 < v98 then
							local v104 = nil
							local v105 = p95.spec_fillUnit
							if v105.fillTrigger.isFilling then
								local v106 = v105.fillTrigger.currentTrigger
								if v106 ~= nil and v106.sourceObject.getConsumableVariationIndexByFillUnitIndex ~= nil then
									v104 = v106.sourceObject:getConsumableVariationIndexByFillUnitIndex(v106.fillUnitIndex)
								end
							end
							if v104 == nil and v99.consumingVariationIndex ~= 0 then
								v104 = v99.consumingVariationIndex
							end
							if v104 == nil then
								v104 = g_consumableManager:getConsumableVariationIndexByName(v99.defaultConsumableName, p95.customEnvironment)
							end
							if v99.numStorageSlots > 0 then
								for _ = 1, v103 do
									for v107, v108 in ipairs(v99.storageSlots) do
										if v108.consumableVariationIndex == 0 then
											p95:setConsumableSlotVariationIndex(v99.index, v107, v104)
											break
										end
									end
								end
							end
							v99.lastConsumedVariationIndex = v104
							local v109 = v99.numStorageSlots == 0
							p95:updateConsumable(v99.typeName, 0, nil, v109)
						else
							for _ = 1, v103 do
								for v110, v111 in ipairs(v99.storageSlots) do
									if v111.consumableVariationIndex ~= 0 then
										v99.lastConsumedVariationIndex = v111.consumableVariationIndex
										p95:setConsumableSlotVariationIndex(v99.index, v110, 0)
										break
									end
								end
							end
						end
						if p95.updatePalletStraps ~= nil then
							p95:updatePalletStraps()
						end
					end
				end
			end
		end
	end
end
function Consumable.onFillUnitIsFillingStateChanged(p112, p113)
	if not p113 then
		local v114 = p112.spec_consumable
		if v114.types ~= nil then
			for _, v115 in ipairs(v114.types) do
				if v115.consumingFillLevel == 0 then
					p112:updateConsumable(v115.typeName, 0, nil, true)
				end
			end
		end
	end
end
function Consumable.onAddedFillUnitTrigger(p116, _, _, _)
	Consumable.updateActivatable(p116)
end
function Consumable.onRemovedFillUnitTrigger(p117, _)
	Consumable.updateActivatable(p117)
end
function Consumable.getConsumableVariationIndexByFillUnitIndex(p118, p119)
	local v120 = p118.spec_consumable
	if v120.types ~= nil then
		for _, v121 in ipairs(v120.types) do
			if v121.fillUnitIndex == p119 then
				for _, v122 in ipairs(v121.storageSlots) do
					if v122.consumableVariationIndex ~= 0 then
						return v122.consumableVariationIndex
					end
				end
				return v121.lastConsumedVariationIndex
			end
		end
	end
	return nil
end
function Consumable.setConsumableSlotVariationIndex(p123, p124, p125, p126)
	local v127 = p126 or 0
	local v128 = p123.spec_consumable
	local v129 = v128.types[p124]
	if v129 ~= nil then
		local v130 = v129.storageSlots[p125]
		if v130 ~= nil and v127 ~= v130.consumableVariationIndex then
			v130.consumableVariationIndex = v127
			v130.isDirty = true
			if v130.node ~= nil then
				if v130.mesh ~= nil then
					if p123.removeAllSubWashableNodes ~= nil then
						p123:removeAllSubWashableNodes(v130.mesh)
					end
					if p123.removeAllSubWearableNodes ~= nil then
						p123:removeAllSubWearableNodes(v130.mesh)
					end
					delete(v130.mesh)
					v130.mesh = nil
					if v130.tensionBeltMesh ~= nil then
						v130.tensionBeltMesh = nil
						if p123.setPalletTensionBeltNodesDirty ~= nil then
							p123:setPalletTensionBeltNodesDirty()
						end
					end
				end
				local v131, v132 = g_consumableManager:getConsumableMeshByIndex(v130.consumableVariationIndex, v130.useTensionBeltMesh)
				if v131 ~= nil then
					link(v130.node, v131)
					setTranslation(v131, 0, 0, 0)
					setRotation(v131, 0, 0, 0)
					v130.mesh = v131
					if p123.addAllSubWashableNodes ~= nil then
						p123:addAllSubWashableNodes(v131)
					end
					if p123.addAllSubWearableNodes ~= nil then
						p123:addAllSubWearableNodes(v131)
					end
					if v132 ~= nil then
						v130.tensionBeltMesh = v132
						if p123.setPalletTensionBeltNodesDirty ~= nil then
							p123:setPalletTensionBeltNodesDirty()
						end
					end
				end
			end
			p123:raiseDirtyFlags(v128.dirtyFlag)
		end
	end
end
function Consumable.updateConsumable(p133, p134, p135, p136, p137)
	local v138 = p133.spec_consumable
	local v139 = v138.typesByName[p134]
	if v139 ~= nil and v139.numConsumingSlots ~= 0 then
		local v140 = v139.consumingFillLevel + p135 / v139.numConsumingSlots
		v139.consumingFillLevel = math.clamp(v140, 0, 1)
		if (p137 or p137 == nil and v139.consumingFillLevel == 0) and p133:getFillUnitFillLevel(v139.fillUnitIndex) > 0 then
			local v141 = p133:addFillUnitFillLevel(p133:getOwnerFarmId(), v139.fillUnitIndex, -v139.numConsumingSlots, p133:getFillUnitFillType(v139.fillUnitIndex), ToolType.UNDEFINED, nil)
			local v142 = v139.consumingFillLevel + -v141 / v139.numConsumingSlots
			local v143 = v139.numConsumingSlots
			v139.consumingFillLevel = math.min(v142, v143)
			v139.consumingVariationIndex = v139.lastConsumedVariationIndex
		end
		for v144, v145 in ipairs(v139.consumingSlots) do
			if v145.consumingMesh == nil or v139.consumingVariationIndex ~= v145.consumableVariationIndex then
				v145.consumableVariationIndex = v139.consumingVariationIndex
				if v144 == 1 then
					local v146 = g_consumableManager:getConsumableVariationShaderParameterByIndex(v145.consumableVariationIndex)
					if v146 ~= nil then
						for _, v147 in ipairs(v146) do
							for _, v148 in ipairs(v139.shaderParameterNodes) do
								I3DUtil.setShaderParameterRec(v148, v147.name, v147.value[1], v147.value[2], v147.value[3], v147.value[4])
							end
						end
					end
					local v149 = g_consumableManager:getConsumableVariationMetaDataByIndex(v145.consumableVariationIndex)
					if v149 ~= nil then
						SpecializationUtil.raiseEvent(p133, "onConsumableVariationChanged", v145.consumableVariationIndex, v149)
					end
				end
				if v145.node ~= nil then
					if v145.consumingMesh ~= nil then
						if p133.removeAllSubWashableNodes ~= nil then
							p133:removeAllSubWashableNodes(v145.consumingMesh)
						end
						if p133.removeAllSubWearableNodes ~= nil then
							p133:removeAllSubWearableNodes(v145.consumingMesh)
						end
						delete(v145.consumingMesh)
						v145.consumingMesh = nil
					end
					local v150 = g_consumableManager:getConsumableConsumingMeshByIndex(v145.consumableVariationIndex)
					if v150 ~= nil then
						link(v145.node, v150)
						setTranslation(v150, 0, 0, 0)
						setRotation(v150, 0, 0, 0)
						v145.consumingMesh = v150
						if p133.addAllSubWashableNodes ~= nil then
							p133:addAllSubWashableNodes(v150)
						end
						if p133.addAllSubWearableNodes ~= nil then
							p133:addAllSubWearableNodes(v150)
						end
					end
				end
			end
			if v145.consumingMesh ~= nil then
				if v139.useScale then
					local v151 = setScale
					local v152 = v145.consumingMesh
					local v153 = v139.consumingFillLevel
					local v154 = math.max(v153, 0.1)
					local v155 = v139.consumingFillLevel
					v151(v152, v154, 1, (math.max(v155, 0.1)))
				end
				if v139.useAmount then
					if getHasClassId(v145.consumingMesh, ClassIds.SHAPE) and getHasShaderParameter(v145.consumingMesh, "amount") then
						g_animationManager:setPrevShaderParameter(v145.consumingMesh, "amount", v139.consumingFillLevel, 0, 0, 0, false, "prevAmount")
					end
					for v156 = 1, getNumOfChildren(v145.consumingMesh) do
						local v157 = getChildAt(v145.consumingMesh, v156 - 1)
						if getHasClassId(v157, ClassIds.SHAPE) and getHasShaderParameter(v157, "amount") then
							g_animationManager:setPrevShaderParameter(v157, "amount", v139.consumingFillLevel, 0, 0, 0, false, "prevAmount")
						end
					end
				end
				if v139.useHideByIndex then
					local v158 = I3DUtil.setHideByIndexRec
					local v159 = v145.consumingMesh
					local v160 = v139.consumingFillLevel + v139.hideByIndexOffset
					v158(v159, (math.clamp(v160, 0, 1)))
				end
				if p136 ~= true then
					setVisibility(v145.consumingMesh, v139.consumingFillLevel > 0)
				end
			end
		end
		for _, v161 in ipairs(v139.animations) do
			local v162
			if v161.numSteps == nil then
				local v163 = 1 / v161.numLoops
				local v164 = (1 - v139.consumingFillLevel) % v163 / v163
				v162 = math.clamp(v164, 0, 1)
			else
				local v165 = v139.consumingFillLevel * v161.numSteps
				v162 = 1 - math.ceil(v165) / v161.numSteps
			end
			local v166 = v162 - v161.currentTime
			local v167 = math.abs(v166)
			if v161.currentTime < v162 then
				local v168 = v162 - 1 - v161.currentTime
				if math.abs(v168) < v167 then
					v162 = v162 - 1
				end
			else
				local v169 = v162 + 1 - v161.currentTime
				if math.abs(v169) < v167 then
					v161.currentTime = v161.currentTime - 1
					p133:setAnimationTime(v161.name, v161.currentTime, true)
				end
			end
			v161.targetTime = v162
			v161.isDirty = v161.targetTime ~= v161.currentTime
			if v161.isDirty then
				v138.animationsDirty = true
				p133:raiseActive()
			end
		end
		if p136 ~= true then
			ObjectChangeUtil.setObjectChanges(v139.objectChanges, v139.consumingFillLevel > 0, p133, p133.setMovingToolDirty)
		end
		local v170 = p133:getFillUnitFillLevel(v139.fillUnitIndex) + v139.consumingFillLevel * v139.numConsumingSlots
		local v171 = v139.fillUnitIndex
		local v172 = math.min(v170, p133:getFillUnitCapacity(v171))
		p133:setFillUnitFillLevelToDisplay(v139.fillUnitIndex, v172, true)
		if MathUtil.round(v139.consumingFillLevel * Consumable.CONSUME_LEVEL_RESOLUTION) ~= MathUtil.round(v139.consumingFillLevelSent * Consumable.CONSUME_LEVEL_RESOLUTION) then
			p133:raiseDirtyFlags(v138.dirtyFlag)
			v139.consumingFillLevelSent = v139.consumingFillLevel
			v139.isDirty = true
		end
	end
	if p136 ~= true then
		Consumable.updateActivatable(p133)
	end
end
function Consumable.getConsumableIsAvailable(p173, p174)
	local v175 = p173.spec_consumable.typesByName[p174]
	return v175 == nil and true or v175.consumingFillLevel > 0
end
function Consumable.getShowConsumableEmptyWarning(p176, p177)
	local v178 = p176.spec_consumable.typesByName[p177]
	if v178 == nil then
		return false
	else
		return v178.consumingFillLevel == 0
	end
end
function Consumable.getCustomFillTriggerSpeedFactor(p179, _, p180, _)
	local v181 = p179.spec_consumable
	if v181.types ~= nil then
		for _, v182 in ipairs(v181.types) do
			if v182.fillUnitIndex == p180 and v182.numConsumingSlots > 0 then
				for _, v183 in ipairs(v182.storageSlots) do
					if v183.consumableVariationIndex == 0 then
						return 1
					end
				end
				return (1 / 0)
			end
		end
	end
	return 1
end
function Consumable.addFillUnitFillLevel(p184, p185, p186, p187, p188, p189, ...)
	if p188 > 0 then
		local v190 = p184.spec_consumable
		if v190.types ~= nil then
			for _, v191 in ipairs(v190.types) do
				if v191.fillUnitIndex == p187 then
					local v192 = v191.numConsumingSlots * (1 - v191.consumingFillLevel) + v191.numStorageSlots + 1e-6 - p184:getFillUnitFillLevel(p187)
					p188 = math.min(p188, v192)
				end
			end
		end
	end
	return p185(p184, p186, p187, p188, p189, ...)
end
function Consumable.getFillUnitFreeCapacity(p193, p194, p195, ...)
	local v196 = p193.spec_consumable
	if v196.types ~= nil then
		for _, v197 in ipairs(v196.types) do
			if v197.fillUnitIndex == p195 then
				local v198 = p193:getFillUnitFillLevel(p195)
				local v199 = v197.numStorageSlots + v197.numConsumingSlots
				if v197.consumingFillLevel ~= 0 and v197.numStorageSlots ~= 0 then
					v199 = v197.numStorageSlots
				end
				return v199 + 1e-6 - v198
			end
		end
	end
	return p194(p193, p195, ...)
end
function Consumable.collectPalletTensionBeltNodes(p200, p201, p202)
	p201(p200, p202)
	local v203 = p200.spec_consumable
	if v203.types ~= nil then
		for _, v204 in ipairs(v203.types) do
			for _, v205 in ipairs(v204.storageSlots) do
				if v205.tensionBeltMesh ~= nil then
					local v206 = v205.tensionBeltMesh
					table.insert(p202, v206)
				end
			end
		end
	end
end
function Consumable.updateActivatable(p207)
	local v208 = p207.spec_consumable
	local v209 = false
	for _, v210 in ipairs(v208.types) do
		if v210.consumingFillLevel == 0 and v210.allowRefillDialog then
			v209 = true
		end
	end
	if #p207.spec_fillUnit.fillTrigger.triggers ~= 0 then
		v209 = false
	end
	if v209 then
		v208.activatable:updateActivateText()
		g_currentMission.activatableObjectsSystem:addActivatable(v208.activatable)
	else
		g_currentMission.activatableObjectsSystem:removeActivatable(v208.activatable)
	end
end

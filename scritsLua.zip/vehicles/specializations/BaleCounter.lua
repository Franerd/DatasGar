BaleCounter = {}
BaleCounter.SEND_NUM_BITS = 16
source("dataS/scripts/vehicles/specializations/events/BaleCounterResetEvent.lua")
source("dataS/scripts/gui/hud/extensions/BaleCounterHUDExtension.lua")
function BaleCounter.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Baler, p1)
end
function BaleCounter.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("BaleCounter")
	Dashboard.registerDashboardXMLPaths(v2, "vehicle.baleCounter.dashboards", { "sessionCounter", "lifetimeCounter" })
	v2:setXMLSpecializationType()
	local v3 = Vehicle.xmlSchemaSavegame
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).baleCounter#sessionCounter", "Session counter")
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).baleCounter#lifetimeCounter", "Lifetime counter")
end
function BaleCounter.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "doBaleCounterReset", BaleCounter.doBaleCounterReset)
end
function BaleCounter.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "dropBale", BaleCounter.dropBale)
end
function BaleCounter.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", BaleCounter)
	SpecializationUtil.registerEventListener(p6, "onDelete", BaleCounter)
	SpecializationUtil.registerEventListener(p6, "onDraw", BaleCounter)
	SpecializationUtil.registerEventListener(p6, "onRegisterDashboardValueTypes", BaleCounter)
	SpecializationUtil.registerEventListener(p6, "onReadStream", BaleCounter)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", BaleCounter)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", BaleCounter)
	SpecializationUtil.registerEventListener(p6, "onRegisterExternalActionEvents", BaleCounter)
end
function BaleCounter.onLoad(p7, p8)
	local v9 = p7.spec_baleCounter
	v9.sessionCounter = 0
	v9.lifetimeCounter = 0
	if p8 ~= nil and not p8.resetVehicles then
		v9.sessionCounter = p8.xmlFile:getValue(p8.key .. ".baleCounter#sessionCounter", v9.sessionCounter)
		v9.lifetimeCounter = p8.xmlFile:getValue(p8.key .. ".baleCounter#lifetimeCounter", v9.lifetimeCounter)
	end
	v9.hudExtension = BaleCounterHUDExtension.new(p7)
end
function BaleCounter.onDelete(p10)
	local v11 = p10.spec_baleCounter
	if v11.hudExtension ~= nil then
		g_currentMission.hud:removeInfoExtension(v11.hudExtension)
		v11.hudExtension:delete()
	end
end
function BaleCounter.onDraw(p12)
	local v13 = p12.spec_baleCounter
	if v13.hudExtension ~= nil then
		g_currentMission.hud:addInfoExtension(v13.hudExtension)
	end
end
function BaleCounter.onRegisterDashboardValueTypes(p14)
	local v15 = p14.spec_baleCounter
	local v16 = DashboardValueType.new("baleCounter", "sessionCounter")
	v16:setValue(v15, "sessionCounter")
	p14:registerDashboardValueType(v16)
	local v17 = DashboardValueType.new("baleCounter", "lifetimeCounter")
	v17:setValue(v15, "lifetimeCounter")
	p14:registerDashboardValueType(v17)
end
function BaleCounter.saveToXMLFile(p18, p19, p20, _)
	local v21 = p18.spec_baleCounter
	p19:setValue(p20 .. "#sessionCounter", v21.sessionCounter)
	p19:setValue(p20 .. "#lifetimeCounter", v21.lifetimeCounter)
end
function BaleCounter.onReadStream(p22, p23, _)
	local v24 = p22.spec_baleCounter
	v24.sessionCounter = streamReadUIntN(p23, BaleCounter.SEND_NUM_BITS)
	v24.lifetimeCounter = streamReadUIntN(p23, BaleCounter.SEND_NUM_BITS)
end
function BaleCounter.onWriteStream(p25, p26, _)
	local v27 = p25.spec_baleCounter
	streamWriteUIntN(p26, v27.sessionCounter, BaleCounter.SEND_NUM_BITS)
	streamWriteUIntN(p26, v27.lifetimeCounter, BaleCounter.SEND_NUM_BITS)
end
function BaleCounter.onRegisterActionEvents(p28, _, p29)
	if p28.isClient then
		local v30 = p28.spec_baleCounter
		p28:clearActionEventsTable(v30.actionEvents)
		if p29 then
			local _, v31 = p28:addPoweredActionEvent(v30.actionEvents, InputAction.BALE_COUNTER_RESET, p28, BaleCounter.actionEventResetCounter, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v31, GS_PRIO_HIGH)
		end
	end
end
function BaleCounter.onRegisterExternalActionEvents(p32, p33, p34, _, _)
	if p34 == "baleCounterReset" then
		p32:registerExternalActionEvent(p33, p34, BaleCounter.externalActionEventRegister, BaleCounter.externalActionEventUpdate)
	end
end
function BaleCounter.actionEventResetCounter(p35, _, _, _, _)
	p35:doBaleCounterReset()
end
function BaleCounter.externalActionEventRegister(p36, p_u_37)
	local _, v38 = g_inputBinding:registerActionEvent(InputAction.BALE_COUNTER_RESET, p36, function(_, _, _, _, _)
		-- upvalues: (copy) p_u_37
		p_u_37:doBaleCounterReset()
	end, false, true, false, true)
	p36.actionEventId = v38
	g_inputBinding:setActionEventTextPriority(p36.actionEventId, GS_PRIO_HIGH)
end
function BaleCounter.externalActionEventUpdate(_, _) end
function BaleCounter.doBaleCounterReset(p39, p40)
	p39.spec_baleCounter.sessionCounter = 0
	BaleCounterResetEvent.sendEvent(p39, p40)
end
function BaleCounter.dropBale(p41, p42, p43)
	p42(p41, p43)
	local v44 = p41.spec_baleCounter
	v44.sessionCounter = v44.sessionCounter + 1
	v44.lifetimeCounter = v44.lifetimeCounter + 1
end

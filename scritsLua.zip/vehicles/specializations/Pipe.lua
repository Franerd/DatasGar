source("dataS/scripts/vehicles/specializations/events/SetPipeStateEvent.lua")
source("dataS/scripts/vehicles/specializations/events/SetPipeDischargeToGroundEvent.lua")
Pipe = {}
function Pipe.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(FillUnit, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Dischargeable, p1)
	end
	return v2
end
function Pipe.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("pipe", g_i18n:getText("configuration_pipe"), "pipe", VehicleConfigurationItem)
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Pipe")
	AnimationManager.registerAnimationNodesXMLPaths(v3, "vehicle.pipe.animationNodes")
	v3:addDelayedRegistrationFunc("Cylindered:movingTool", function(p4, p5)
		p4:register(XMLValueType.VECTOR_N, p5 .. "#freezingPipeStates", "Freezing pipe states")
	end)
	v3:register(XMLValueType.INT, Cover.COVER_XML_KEY .. "#minPipeState", "Min. pipe state", 0)
	v3:register(XMLValueType.INT, Cover.COVER_XML_KEY .. "#maxPipeState", "Max. pipe state", "inf.")
	Pipe.registers(v3, "vehicle.pipe")
	Pipe.registers(v3, "vehicle.pipe.pipeConfigurations.pipeConfiguration(?)")
	v3:setXMLSpecializationType()
	local v6 = Vehicle.xmlSchemaSavegame
	v6:register(XMLValueType.INT, "vehicles.vehicle(?).pipe#state", "Current pipe state")
	v6:register(XMLValueType.BOOL, "vehicles.vehicle(?).pipe#isStateChangeAllowed", "If pipe state change is allowed")
end
function Pipe.registers(p7, p8)
	p7:register(XMLValueType.L10N_STRING, p8 .. "#pipeInText", "Text to show for pipe extending action", "action_pipeIn")
	p7:register(XMLValueType.L10N_STRING, p8 .. "#pipeOutText", "Text to show for pipe retracting action", "action_pipeOut")
	p7:register(XMLValueType.L10N_STRING, p8 .. "#turnOnStateWarning", "Turn on warning", "warning_firstSetPipeState")
	p7:register(XMLValueType.INT, p8 .. "#dischargeNodeIndex", "Discharge node index", 1)
	p7:register(XMLValueType.BOOL, p8 .. "#forceDischargeNodeIndex", "Force discharge node selection while changing pipe state. Can be deactivated e.g. if the selection is done by trailer spec etc.", true)
	p7:register(XMLValueType.BOOL, p8 .. "#automaticDischarge", "Pipe is automatically starting to discharge as soon as it hits the trailer", true)
	p7:register(XMLValueType.BOOL, p8 .. "#toggleableDischargeToGround", "Defines if the discharge to ground can be enabled separately", false)
	p7:register(XMLValueType.BOOL, p8 .. "#defaultDischargeToGroundState", "Discharge to ground is enabled by default if #toggleableDischargeToGround is set", false)
	p7:register(XMLValueType.NODE_INDEX, p8 .. ".unloadingTriggers.unloadingTrigger(?)#node", "Unload trigger node")
	p7:register(XMLValueType.STRING, p8 .. ".animation#name", "Pipe animation name")
	p7:register(XMLValueType.FLOAT, p8 .. ".animation#speedScale", "Pipe animation speed scale", 1)
	p7:register(XMLValueType.INT, p8 .. ".states#num", "Number of pipe states", 0)
	p7:register(XMLValueType.NODE_INDEX, p8 .. ".pipeNodes.pipeNode(?)#node", "Pipe node")
	p7:register(XMLValueType.NODE_INDEX, p8 .. ".pipeNodes.pipeNode(?)#subPipeNode", "Sub pipe node (Target rotation is divided between these two nodes depending on the X rotation ratio between #node and #node parent and #subPipeNode and #node parent)")
	p7:register(XMLValueType.FLOAT, p8 .. ".pipeNodes.pipeNode(?)#subPipeNodeRatio", "Ratio between usage of this pipe node and sub node [0-1]", "Calculated based on rotation in i3d file")
	p7:register(XMLValueType.BOOL, p8 .. ".pipeNodes.pipeNode(?)#autoAimXRotation", "Auto aim X rotation", false)
	p7:register(XMLValueType.BOOL, p8 .. ".pipeNodes.pipeNode(?)#autoAimYRotation", "Auto aim Y rotation", false)
	p7:register(XMLValueType.BOOL, p8 .. ".pipeNodes.pipeNode(?)#autoAimInvertZ", "Auto aim invert Z axis", false)
	p7:register(XMLValueType.VECTOR_TRANS, p8 .. ".pipeNodes.pipeNode(?).state(?)#translation", "State translation")
	p7:register(XMLValueType.VECTOR_ROT, p8 .. ".pipeNodes.pipeNode(?).state(?)#rotation", "State translation")
	p7:register(XMLValueType.VECTOR_TRANS, p8 .. ".pipeNodes.pipeNode(?)#translationSpeeds", "Translation speeds")
	p7:register(XMLValueType.VECTOR_ROT, p8 .. ".pipeNodes.pipeNode(?)#rotationSpeeds", "Rotation speeds")
	p7:register(XMLValueType.VECTOR_ROT, p8 .. ".pipeNodes.pipeNode(?)#minRotationLimits", "Min. rotation limit")
	p7:register(XMLValueType.VECTOR_ROT, p8 .. ".pipeNodes.pipeNode(?)#maxRotationLimits", "Max. rotation limit")
	p7:register(XMLValueType.INT, p8 .. ".pipeNodes.pipeNode(?)#foldPriority", "Fold priority", 0)
	p7:register(XMLValueType.FLOAT, p8 .. ".pipeNodes.pipeNode(?)#bendingRegulation", "Bending angle regulation", 0)
	p7:register(XMLValueType.NODE_INDEX, p8 .. ".pipeNodes.pipeNode(?).bendingRegulationNode(?)#node", "Bending regulation node", 0)
	p7:register(XMLValueType.INT, p8 .. ".pipeNodes.pipeNode(?).bendingRegulationNode(?)#axis", "Bending regulation axis", 0)
	p7:register(XMLValueType.INT, p8 .. ".pipeNodes.pipeNode(?).bendingRegulationNode(?)#direction", "Bending regulation direction", 0)
	SoundManager.registerSampleXMLPaths(p7, p8 .. ".pipeNodes.pipeNode(?)", "moveSound(?)")
	p7:register(XMLValueType.VECTOR_N, p8 .. ".states#unloading", "Unloading states")
	p7:register(XMLValueType.VECTOR_N, p8 .. ".states#autoAiming", "Auto aim states")
	p7:register(XMLValueType.VECTOR_N, p8 .. ".states#turnOnAllowed", "Turn on allowed states")
	p7:register(XMLValueType.INT, p8 .. ".states.state(?)#stateIndex", "State index")
	p7:register(XMLValueType.INT, p8 .. ".states.state(?)#dischargeNodeIndex", "Discharge node index")
	p7:register(XMLValueType.FLOAT, p8 .. "#foldMinLimit", "Fold min. limit", 0)
	p7:register(XMLValueType.FLOAT, p8 .. "#foldMaxLimit", "Fold max. limit", 1)
	p7:register(XMLValueType.INT, p8 .. "#foldMinState", "Fold min. state", 1)
	p7:register(XMLValueType.INT, p8 .. "#foldMaxState", "Fold max. state", "Num. of states")
	p7:register(XMLValueType.BOOL, p8 .. "#aiFoldedPipeUsesTrailerSpace", "Defines if the folded pipe uses the space of the trailer to discharge", false)
end
function Pipe.registerFunctions(p9)
	SpecializationUtil.registerFunction(p9, "loadUnloadingTriggers", Pipe.loadUnloadingTriggers)
	SpecializationUtil.registerFunction(p9, "loadPipeNodes", Pipe.loadPipeNodes)
	SpecializationUtil.registerFunction(p9, "getIsPipeStateChangeAllowed", Pipe.getIsPipeStateChangeAllowed)
	SpecializationUtil.registerFunction(p9, "setPipeState", Pipe.setPipeState)
	SpecializationUtil.registerFunction(p9, "getCurrentPipeState", Pipe.getCurrentPipeState)
	SpecializationUtil.registerFunction(p9, "updatePipeNodes", Pipe.updatePipeNodes)
	SpecializationUtil.registerFunction(p9, "updateBendingRegulationNodes", Pipe.updateBendingRegulationNodes)
	SpecializationUtil.registerFunction(p9, "unloadingTriggerCallback", Pipe.unloadingTriggerCallback)
	SpecializationUtil.registerFunction(p9, "updateNearestObjectInTriggers", Pipe.updateNearestObjectInTriggers)
	SpecializationUtil.registerFunction(p9, "updateActionEventText", Pipe.updateActionEventText)
	SpecializationUtil.registerFunction(p9, "onDeletePipeObject", Pipe.onDeletePipeObject)
	SpecializationUtil.registerFunction(p9, "getPipeDischargeNodeIndex", Pipe.getPipeDischargeNodeIndex)
	SpecializationUtil.registerFunction(p9, "setPipeDischargeToGround", Pipe.setPipeDischargeToGround)
	SpecializationUtil.registerFunction(p9, "setIsPipeStateChangeAllowed", Pipe.setIsPipeStateChangeAllowed)
end
function Pipe.registerOverwrittenFunctions(p10)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsDischargeNodeActive", Pipe.getIsDischargeNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "getCanBeTurnedOn", Pipe.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p10, "getTurnedOnNotAllowedWarning", Pipe.getTurnedOnNotAllowedWarning)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsFoldAllowed", Pipe.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p10, "handleDischarge", Pipe.handleDischarge)
	SpecializationUtil.registerOverwrittenFunction(p10, "handleDischargeRaycast", Pipe.handleDischargeRaycast)
	SpecializationUtil.registerOverwrittenFunction(p10, "dischargeToGround", Pipe.dischargeToGround)
	SpecializationUtil.registerOverwrittenFunction(p10, "getCanToggleDischargeToObject", Pipe.getCanToggleDischargeToObject)
	SpecializationUtil.registerOverwrittenFunction(p10, "getCanToggleDischargeToGround", Pipe.getCanToggleDischargeToGround)
	SpecializationUtil.registerOverwrittenFunction(p10, "getRequiresPower", Pipe.getRequiresPower)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadMovingToolFromXML", Pipe.loadMovingToolFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsMovingToolActive", Pipe.getIsMovingToolActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadCoverFromXML", Pipe.loadCoverFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsNextCoverStateAllowed", Pipe.getIsNextCoverStateAllowed)
	SpecializationUtil.registerOverwrittenFunction(p10, "getCanBeSelected", Pipe.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsAIReadyToDrive", Pipe.getIsAIReadyToDrive)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsAIPreparingToDrive", Pipe.getIsAIPreparingToDrive)
end
function Pipe.registerEventListeners(p11)
	SpecializationUtil.registerEventListener(p11, "onLoad", Pipe)
	SpecializationUtil.registerEventListener(p11, "onPostLoad", Pipe)
	SpecializationUtil.registerEventListener(p11, "onDelete", Pipe)
	SpecializationUtil.registerEventListener(p11, "onReadStream", Pipe)
	SpecializationUtil.registerEventListener(p11, "onWriteStream", Pipe)
	SpecializationUtil.registerEventListener(p11, "onReadUpdateStream", Pipe)
	SpecializationUtil.registerEventListener(p11, "onWriteUpdateStream", Pipe)
	SpecializationUtil.registerEventListener(p11, "onUpdate", Pipe)
	SpecializationUtil.registerEventListener(p11, "onUpdateTick", Pipe)
	SpecializationUtil.registerEventListener(p11, "onMovingToolChanged", Pipe)
	SpecializationUtil.registerEventListener(p11, "onRegisterActionEvents", Pipe)
	SpecializationUtil.registerEventListener(p11, "onDischargeStateChanged", Pipe)
	SpecializationUtil.registerEventListener(p11, "onAIImplementPrepareForTransport", Pipe)
	SpecializationUtil.registerEventListener(p11, "onRootVehicleChanged", Pipe)
end
function Pipe.onLoad(p12, _)
	local v13 = p12.spec_pipe
	local v14 = Utils.getNoNil(p12.configurations.pipe, 1)
	local v15 = string.format("vehicle.pipe.pipeConfigurations.pipeConfiguration(%d)", v14 - 1)
	local v16 = not p12.xmlFile:hasProperty(v15) and "vehicle.pipe" or v15
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipeEffect.effectNode", v16 .. ".pipeEffect.effectNode")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.overloading.trailerTriggers.trailerTrigger(0)#index", v16 .. ".unloadingTriggers.unloadingTrigger(0)#node")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#raycastNodeIndex", v16 .. ".raycast#node")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#raycastDistance", v16 .. ".raycast#maxDistance")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#effectExtraDistanceOnTrailer", v16 .. ".raycast#extraDistance")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#animName", v16 .. ".animation#name")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#animSpeedScale", v16 .. ".animation#speedScale")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#animSpeedScale", v16 .. ".animation#speedScale")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe.node#node", v16 .. ".node#node")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#numStates", v16 .. ".states#num")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#unloadingStates", v16 .. ".states#unloading")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#autoAimingStates", v16 .. ".states#autoAiming")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.pipe#turnOnAllowed", v16 .. ".states#turnOnAllowed")
	v13.dischargeNodeIndex = p12.xmlFile:getValue(v16 .. "#dischargeNodeIndex", 1)
	v13.forceDischargeNodeIndex = p12.xmlFile:getValue(v16 .. "#forceDischargeNodeIndex", true)
	if v13.forceDischargeNodeIndex then
		p12:setCurrentDischargeNodeIndex(v13.dischargeNodeIndex)
	end
	v13.isStateChangeAllowed = true
	v13.automaticDischarge = p12.xmlFile:getValue(v16 .. "#automaticDischarge", true)
	v13.toggleableDischargeToGround = p12.xmlFile:getValue(v16 .. "#toggleableDischargeToGround", false)
	v13.dischargeToGroundState = p12.xmlFile:getValue(v16 .. "#defaultDischargeToGroundState", false)
	v13.unloadingTriggers = {}
	v13.objectsInTriggers = {}
	v13.unloadTriggersInTriggers = {}
	v13.numObjectsInTriggers = 0
	v13.numUnloadTriggersInTriggers = 0
	v13.nearestObjectInTriggers = {
		["objectId"] = nil,
		["fillUnitIndex"] = 0,
		["isDischargeObject"] = false
	}
	v13.nearestObjectInTriggersSent = {
		["objectId"] = nil,
		["fillUnitIndex"] = 0,
		["isDischargeObject"] = false
	}
	p12:loadUnloadingTriggers(v13.unloadingTriggers, p12.xmlFile, v16 .. ".unloadingTriggers.unloadingTrigger")
	if #v13.unloadingTriggers == 0 then
		Logging.xmlWarning(p12.xmlFile, "No \'unloadingTriggers\' defined for pipe \'vehicle.pipe\'!")
	else
		for _, v17 in pairs(v13.unloadingTriggers) do
			addTrigger(v17.node, "unloadingTriggerCallback", p12)
			setTriggerReportStatics(v17.node, true)
		end
	end
	v13.animation = {}
	v13.animation.name = p12.xmlFile:getValue(v16 .. ".animation#name")
	v13.animation.speedScale = p12.xmlFile:getValue(v16 .. ".animation#speedScale", 1)
	v13.currentState = 1
	v13.targetState = 1
	v13.numStates = p12.xmlFile:getValue(v16 .. ".states#num", 0)
	v13.nodes = {}
	p12:loadPipeNodes(v13.nodes, p12.xmlFile, v16 .. ".pipeNodes.pipeNode")
	v13.hasMovablePipe = #v13.nodes > 0 and true or v13.animation.name ~= nil
	v13.unloadingStates = {}
	v13.autoAimingStates = {}
	v13.turnOnAllowedStates = {}
	local v18 = v13.unloadingStates
	local v19 = 0
	local v20 = p12.xmlFile:getValue(v16 .. ".states#unloading", nil, true)
	if v20 ~= nil then
		for _, v21 in ipairs(v20) do
			v18[v21] = true
			v19 = v19 + 1
		end
	end
	v13.numUnloadingStates = v19
	local v22 = v13.autoAimingStates
	local v23 = 0
	local v24 = p12.xmlFile:getValue(v16 .. ".states#autoAiming", nil, true)
	if v24 ~= nil then
		for _, v25 in ipairs(v24) do
			v22[v25] = true
			v23 = v23 + 1
		end
	end
	v13.numAutoAimingStates = v23
	local v26 = v13.turnOnAllowedStates
	local v27 = 0
	local v28 = p12.xmlFile:getValue(v16 .. ".states#turnOnAllowed", nil, true)
	if v28 ~= nil then
		for _, v29 in ipairs(v28) do
			v26[v29] = true
			v27 = v27 + 1
		end
	end
	v13.numTurnOnAllowedStates = v27
	v13.dischargeNodeMapping = {}
	local v30 = 0
	while true do
		local v31 = string.format("%s.states.state(%d)", v16, v30)
		if not p12.xmlFile:hasProperty(v31) then
			break
		end
		local v32 = p12.xmlFile:getValue(v31 .. "#stateIndex")
		local v33 = p12.xmlFile:getValue(v31 .. "#dischargeNodeIndex")
		if v32 ~= nil and v33 ~= nil then
			v13.dischargeNodeMapping[v32] = v33
		end
		v30 = v30 + 1
	end
	if p12.isClient then
		v13.animationNodes = g_animationManager:loadAnimations(p12.xmlFile, "vehicle.pipe.animationNodes", p12.components, p12, p12.i3dMappings)
	end
	v13.foldMinTime = p12.xmlFile:getValue(v16 .. "#foldMinLimit", 0)
	v13.foldMaxTime = p12.xmlFile:getValue(v16 .. "#foldMaxLimit", 1)
	v13.foldMinState = p12.xmlFile:getValue(v16 .. "#foldMinState", 1)
	v13.foldMaxState = p12.xmlFile:getValue(v16 .. "#foldMaxState", v13.numStates)
	v13.aiFoldedPipeUsesTrailerSpace = p12.xmlFile:getValue(v16 .. "#aiFoldedPipeUsesTrailerSpace", false)
	v13.texts = {}
	v13.texts.warningFoldingPipe = g_i18n:getText("warning_foldingNotWhilePipeExtended")
	v13.texts.turnOnStateWarning = string.format(p12.xmlFile:getValue(v16 .. "#turnOnStateWarning", "warning_firstSetPipeState", p12.customEnvironment), p12.typeDesc)
	v13.texts.pipeIn = p12.xmlFile:getValue(v16 .. "#pipeInText", "action_pipeIn", p12.customEnvironment)
	v13.texts.pipeOut = p12.xmlFile:getValue(v16 .. "#pipeOutText", "action_pipeOut", p12.customEnvironment)
	v13.texts.startTipToGround = g_i18n:getText("action_startTipToGround")
	v13.texts.stopTipToGround = g_i18n:getText("action_stopTipToGround")
	v13.sideNotificationData = {}
	v13.sideNotificationData.objectId = nil
	v13.sideNotificationData.fillUnitIndex = nil
	v13.sideNotificationData.progressBar = g_currentMission.hud:addSideNotificationProgressBar("", "", "")
	v13.sideNotificationTime = 0
	v13.dirtyFlag = p12:getNextDirtyFlag()
	v13.lastFillTime = -1000
	v13.lastEmptyTime = -1000
	if not p12.isServer then
		SpecializationUtil.removeEventListener(p12, "onUpdateTick", Pipe)
	end
end
function Pipe.onPostLoad(p34, p35)
	local v36 = p34.spec_pipe
	if p35 ~= nil and not p35.resetVehicles then
		v36.isStateChangeAllowed = p35.xmlFile:getValue(p35.key .. ".pipe#isStateChangeAllowed", v36.isStateChangeAllowed)
		local v37 = p35.xmlFile:getValue(p35.key .. ".pipe#state", v36.currentState)
		p34:setPipeState(v37, true)
		p34:updatePipeNodes(999999)
		v36.currentState = v36.targetState
		if v36.animation.name ~= nil then
			local v38 = v37 == 1 and 0 or 1
			p34:setAnimationTime(v36.animation.name, v38, true)
		end
	end
end
function Pipe.onDelete(p39)
	local v40 = p39.spec_pipe
	if v40.unloadingTriggers ~= nil then
		for _, v41 in pairs(v40.unloadingTriggers) do
			removeTrigger(v41.node)
		end
	end
	if v40.nodes ~= nil then
		for _, v42 in ipairs(v40.nodes) do
			g_soundManager:deleteSamples(v42.moveSamples)
		end
	end
	if v40.sideNotificationData ~= nil then
		g_currentMission.hud:removeSideNotificationProgressBar(v40.sideNotificationData.progressBar)
	end
	g_animationManager:deleteAnimations(v40.animationNodes)
end
function Pipe.saveToXMLFile(p43, p44, p45, _)
	local v46 = p43.spec_pipe
	local v47 = p45 .. "#state"
	local v48 = v46.currentState
	local v49 = v46.numStates
	p44:setValue(v47, (math.clamp(v48, 1, v49)))
	p44:setValue(p45 .. "#isStateChangeAllowed", v46.isStateChangeAllowed)
end
function Pipe.onReadStream(p50, p51, _)
	local v52 = p50.spec_pipe
	p50:setPipeState(streamReadUIntN(p51, 2), true)
	if streamReadBool(p51) then
		v52.nearestObjectInTriggers.objectId = NetworkUtil.readNodeObjectId(p51)
		v52.nearestObjectInTriggers.fillUnitIndex = streamReadUIntN(p51, 4)
		v52.nearestObjectInTriggers.isDischargeObject = streamReadBool(p51)
	end
end
function Pipe.onWriteStream(p53, p54, _)
	local v55 = p53.spec_pipe
	streamWriteUIntN(p54, v55.targetState, 2)
	if streamWriteBool(p54, v55.nearestObjectInTriggersSent.objectId ~= nil) then
		NetworkUtil.writeNodeObjectId(p54, v55.nearestObjectInTriggersSent.objectId)
		streamWriteUIntN(p54, v55.nearestObjectInTriggersSent.fillUnitIndex, 4)
		streamWriteBool(p54, v55.nearestObjectInTriggersSent.isDischargeObject)
	end
end
function Pipe.onReadUpdateStream(p56, p57, _, p58)
	if p58:getIsServer() and streamReadBool(p57) then
		local v59 = p56.spec_pipe
		if streamReadBool(p57) then
			v59.nearestObjectInTriggers.objectId = NetworkUtil.readNodeObjectId(p57)
			v59.nearestObjectInTriggers.fillUnitIndex = streamReadUIntN(p57, 4)
			v59.nearestObjectInTriggers.isDischargeObject = streamReadBool(p57)
			return
		end
		v59.nearestObjectInTriggers.objectId = nil
		v59.nearestObjectInTriggers.fillUnitIndex = 0
		v59.nearestObjectInTriggers.isDischargeObject = false
	end
end
function Pipe.onWriteUpdateStream(p60, p61, p62, p63)
	if not p62:getIsServer() then
		local v64 = p60.spec_pipe
		if streamWriteBool(p61, bitAND(p63, v64.dirtyFlag) ~= 0) and streamWriteBool(p61, v64.nearestObjectInTriggersSent.objectId ~= nil) then
			NetworkUtil.writeNodeObjectId(p61, v64.nearestObjectInTriggersSent.objectId)
			streamWriteUIntN(p61, v64.nearestObjectInTriggersSent.fillUnitIndex, 4)
			streamWriteBool(p61, v64.nearestObjectInTriggersSent.isDischargeObject)
		end
	end
end
function Pipe.onUpdate(p65, p66, _, p67, _)
	local v68 = p65.spec_pipe
	p65:updateActionEventText()
	if v68.hasMovablePipe then
		p65:updatePipeNodes(p66)
	end
	if p65.isClient then
		if v68.sideNotificationTime > 0 then
			local v69 = v68.sideNotificationTime - p66
			v68.sideNotificationTime = math.max(v69, 0)
		end
		if p67 then
			local v70 = p65.spec_pipe
			local v71 = NetworkUtil.getObject(v70.nearestObjectInTriggers.objectId)
			local v72 = v70.nearestObjectInTriggers.fillUnitIndex
			if not v70.nearestObjectInTriggers.isDischargeObject then
				v71 = nil
			end
			if v71 == nil and (v70.sideNotificationTime > 0 and v70.sideNotificationData.objectId ~= nil) then
				v71 = NetworkUtil.getObject(v70.sideNotificationData.objectId)
				v72 = v70.sideNotificationData.fillUnitIndex
				if v71 == nil then
					v70.sideNotificationData.objectId = nil
				end
			end
			if v71 ~= nil then
				local v73 = v71:getFillUnitFillType(v72)
				if v73 ~= FillType.UNKNOWN then
					local v74 = v71:getFillUnitFillLevel(v72)
					local v75 = v74 / v71:getFillUnitCapacity(v72)
					local v76 = g_fillTypeManager:getFillTypeByIndex(v73)
					local v77 = string.format("%d%s %s", v74, v76.unitShort or "", v76.title)
					if v70.nearestObjectInTriggers.objectId ~= nil then
						v70.sideNotificationData.objectId = v70.nearestObjectInTriggers.objectId
						v70.sideNotificationData.fillUnitIndex = v72
						v70.sideNotificationTime = 5000
					end
					local v78 = v70.sideNotificationData.progressBar
					v78.title = v71:getFullName()
					v78.text = v77
					v78.progress = v75
					g_currentMission.hud:markSideNotificationProgressBarForDrawing(v78)
				end
			end
		end
	end
end
function Pipe.onUpdateTick(p79, _, _, _, _)
	if p79.isServer then
		p79:updateNearestObjectInTriggers()
		local v80 = p79.spec_pipe
		if v80.nearestObjectInTriggers.objectId ~= v80.nearestObjectInTriggersSent.objectId or (v80.nearestObjectInTriggers.fillUnitIndex ~= v80.nearestObjectInTriggersSent.fillUnitIndex or v80.nearestObjectInTriggers.isDischargeObject ~= v80.nearestObjectInTriggersSent.isDischargeObject) then
			v80.nearestObjectInTriggersSent.objectId = v80.nearestObjectInTriggers.objectId
			v80.nearestObjectInTriggersSent.fillUnitIndex = v80.nearestObjectInTriggers.fillUnitIndex
			v80.nearestObjectInTriggersSent.isDischargeObject = v80.nearestObjectInTriggers.isDischargeObject
			p79:raiseDirtyFlags(v80.dirtyFlag)
		end
		if v80.numAutoAimingStates == 0 and (Platform.gameplay.automaticPipeUnfolding and not p79:getIsAIActive()) then
			local v81 = v80.nearestObjectInTriggers.objectId ~= nil and true or v80.numUnloadTriggersInTriggers > 0
			local v82 = p79:getDischargeNodeByIndex(p79:getPipeDischargeNodeIndex())
			if v82 ~= nil then
				local v83 = p79:getFillUnitCapacity(v82.fillUnitIndex)
				local v84 = p79:getFillUnitFillLevel(v82.fillUnitIndex)
				v81 = not v81 or v83 == (1 / 0) and (p79.getIsTurnedOn == nil or p79:getIsTurnedOn()) or v84 > 0
			end
			if v81 then
				if v80.targetState == 1 then
					local v85, _ = next(v80.unloadingStates)
					if p79:getIsPipeStateChangeAllowed(v85) then
						p79:setPipeState(v85)
					end
				end
			elseif v80.targetState > 1 and p79:getIsPipeStateChangeAllowed(1) then
				p79:setPipeState(1)
			end
			if v81 then
				p79:raiseActive()
			end
		end
	end
end
function Pipe.loadUnloadingTriggers(p86, p87, p88, p89)
	local v90 = 0
	while true do
		local v91 = string.format("%s(%d)", p89, v90)
		if not p88:hasProperty(v91) then
			break
		end
		XMLUtil.checkDeprecatedXMLElements(p86.xmlFile, v91 .. "#index", v91 .. "#node")
		local v92 = p88:getValue(v91 .. "#node", nil, p86.components, p86.i3dMappings)
		if v92 ~= nil then
			if CollisionFlag.getHasMaskFlagSet(v92, CollisionFlag.FILLABLE) then
				table.insert(p87, {
					["node"] = v92
				})
			else
				Logging.xmlWarning(p86.xmlFile, "Missing collision filter mask %s. Please add this bit to unload trigger node \'%s\' in \'%s\'", CollisionFlag.getBitAndName(CollisionFlag.FILLABLE), getName(v92), v91)
			end
		end
		v90 = v90 + 1
	end
end
function Pipe.loadPipeNodes(p93, p94, p95, p96)
	local v97 = p93.spec_pipe
	local v98 = 0
	local v99 = 0
	while true do
		local v100 = string.format("%s(%d)", p96, v98)
		if not p95:hasProperty(v100) then
			break
		end
		local v101 = p95:getValue(v100 .. "#node", nil, p93.components, p93.i3dMappings)
		if v101 ~= nil then
			local v102 = {
				["node"] = v101,
				["autoAimXRotation"] = p95:getValue(v100 .. "#autoAimXRotation", false),
				["autoAimYRotation"] = p95:getValue(v100 .. "#autoAimYRotation", false),
				["autoAimInvertZ"] = p95:getValue(v100 .. "#autoAimInvertZ", false),
				["states"] = {},
				["subPipeNode"] = p95:getValue(v100 .. "#subPipeNode", nil, p93.components, p93.i3dMappings)
			}
			if v102.subPipeNode ~= nil then
				local v103, _, _ = getRotation(v102.node)
				local v104, _, _ = localRotationToLocal(v102.subPipeNode, getParent(v102.node), 0, 0, 0)
				local v105 = v100 .. "#subPipeNodeRatio"
				local v106 = v103 / v104
				v102.subPipeNodeRatio = p95:getValue(v105, (math.abs(v106)))
			end
			XMLUtil.checkDeprecatedXMLElements(p93.xmlFile, v100 .. ".state1", v100 .. ".state")
			for v107 = 1, v97.numStates do
				local v108 = v100 .. string.format(".state(%d)", v107 - 1)
				v102.states[v107] = {}
				local v109, v110, v111 = p95:getValue(v108 .. "#translation", { getTranslation(v101) })
				if v107 == 1 then
					setTranslation(v101, v109, v110, v111)
				end
				v102.states[v107].translation = { v109, v110, v111 }
				local v112, v113, v114 = p95:getValue(v108 .. "#rotation", { getRotation(v101) })
				if v107 == 1 then
					setRotation(v101, v112, v113, v114)
				end
				v102.states[v107].rotation = { v112, v113, v114 }
			end
			local v115, v116, v117 = p95:getValue(v100 .. "#translationSpeeds")
			if v115 ~= nil and (v116 ~= nil and v117 ~= nil) then
				local v118 = v115 * 0.001
				local v119 = v116 * 0.001
				local v120 = v117 * 0.001
				if v118 ~= 0 or (v119 ~= 0 or v120 ~= 0) then
					v102.translationSpeeds = { v118, v119, v120 }
				end
			end
			local v121, v122, v123 = p95:getValue(v100 .. "#rotationSpeeds")
			if v121 ~= nil and (v122 ~= nil and v123 ~= nil) then
				local v124 = v121 * 0.001
				local v125 = v122 * 0.001
				local v126 = v123 * 0.001
				if v124 ~= 0 or (v125 ~= 0 or v126 ~= 0) then
					v102.rotationSpeeds = { v124, v125, v126 }
				end
			end
			v102.minRotationLimits = p95:getValue(v100 .. "#minRotationLimits", nil, true)
			v102.maxRotationLimits = p95:getValue(v100 .. "#maxRotationLimits", nil, true)
			v102.foldPriority = p95:getValue(v100 .. "#foldPriority", 0)
			local v127 = v102.foldPriority
			v99 = math.max(v127, v99)
			local v128, v129, v130 = getTranslation(v101)
			v102.curTranslation = { v128, v129, v130 }
			local v131, v132, v133 = getRotation(v101)
			v102.curRotation = { v131, v132, v133 }
			v102.lastTargetRotation = { v131, v132, v133 }
			v102.bendingRegulation = p95:getValue(v100 .. "#bendingRegulation", 0)
			v102.regulationNodes = {}
			local v134 = 0
			while true do
				local v135 = string.format("%s.bendingRegulationNode(%d)", v100, v134)
				if not p95:hasProperty(v135) then
					break
				end
				local v136 = {
					["node"] = p95:getValue(v135 .. "#node", nil, p93.components, p93.i3dMappings)
				}
				if v136.node == nil then
					Logging.xmlWarning(p93.xmlFile, "Failed to load bendingRegulationNode \'%s\'", v135)
				else
					v136.startRotation = { getRotation(v136.node) }
					local v137 = p95:getValue(v135 .. "#axis", 1)
					local v138 = p95:getValue(v135 .. "#direction", 1)
					v136.weights = { 0, 0, 0 }
					v136.weights[math.clamp(v137, 1, 3)] = v138
					local v139 = v102.regulationNodes
					table.insert(v139, v136)
				end
				v134 = v134 + 1
			end
			v102.moveSamples = g_soundManager:loadSamplesFromXML(p93.xmlFile, v100, "moveSound", p93.baseDirectory, p93.components, 0, AudioGroup.VEHICLE, p93.i3dMappings, p93)
			v102.moveSamplesPlayTimer = 0
			table.insert(p94, v102)
		end
		v98 = v98 + 1
	end
	for _, v140 in ipairs(p94) do
		v140.inverseFoldPriority = v99 - v140.foldPriority
	end
end
function Pipe.getIsPipeStateChangeAllowed(p141, _)
	local v142 = p141.spec_pipe
	if not v142.isStateChangeAllowed then
		return false
	end
	local v143
	if p141.getFoldAnimTime == nil then
		v143 = nil
	else
		v143 = p141:getFoldAnimTime()
	end
	return v143 == nil or v143 >= v142.foldMinTime and v142.foldMaxTime >= v143
end
function Pipe.setIsPipeStateChangeAllowed(p144, p145)
	p144.spec_pipe.isStateChangeAllowed = p145
end
function Pipe.setPipeState(p146, p147, p148)
	local v149 = p146.spec_pipe
	local v150 = v149.numStates
	local v151 = math.min(p147, v150)
	if v149.targetState ~= v151 then
		if p148 == nil or p148 == false then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(SetPipeStateEvent.new(p146, v151), nil, nil, p146)
			else
				g_server:broadcastEvent(SetPipeStateEvent.new(p146, v151))
			end
		end
		v149.targetState = v151
		v149.currentState = 0
		if v149.animation ~= nil then
			if v151 == 1 then
				p146:playAnimation(v149.animation.name, -v149.animation.speedScale, p146:getAnimationTime(v149.animation.name), true)
			else
				p146:playAnimation(v149.animation.name, v149.animation.speedScale, p146:getAnimationTime(v149.animation.name), true)
			end
		end
		if v149.forceDischargeNodeIndex then
			p146:setCurrentDischargeNodeIndex(p146:getPipeDischargeNodeIndex(v151))
		end
	end
end
function Pipe.getCurrentPipeState(p152)
	return p152.spec_pipe.currentState
end
function Pipe.updatePipeNodes(p153, p154)
	local v155 = p153.spec_pipe
	local v156
	if v155.nearestObjectInTriggers.objectId == nil then
		v156 = nil
	else
		v156 = NetworkUtil.getObject(v155.nearestObjectInTriggers.objectId)
		if v156 ~= nil and not v156:getIsSynchronized() then
			v156 = nil
		end
		if v156 ~= nil and (v156.rootNode == nil or not entityExists(v156.rootNode)) then
			v156 = nil
		end
	end
	local v157
	if v156 == nil then
		v157 = false
	else
		v157 = v155.autoAimingStates[v155.currentState]
	end
	if v155.currentState == v155.targetState and not v157 then
		if p153:getDischargeState() == Dischargeable.DISCHARGE_STATE_GROUND then
			local v158 = p153:getDischargeNodeByIndex(p153:getPipeDischargeNodeIndex())
			if v158 ~= nil then
				for _, v159 in ipairs(v155.nodes) do
					if v159.bendingRegulation > 0 then
						p153:updateBendingRegulationNodes(v159, v158.dischargeDistance)
					end
				end
			end
		end
	else
		local v160 = v155.targetState == v155.numStates and "inverseFoldPriority" or "foldPriority"
		local v161, v162, v163, v164
		if v157 then
			v161 = v156:getFillUnitAutoAimTargetNode(v155.nearestObjectInTriggers.fillUnitIndex)
			if v161 == nil then
				v161 = v156:getFillUnitExactFillRootNode(v155.nearestObjectInTriggers.fillUnitIndex)
			end
			v162, v163, v164 = getWorldTranslation(v161)
			if VehicleDebug.state == VehicleDebug.DEBUG then
				DebugGizmo.renderAtPositionSimple(v162, v163, v164, getName(v161))
			end
			if v156.isActive and p153.updateLoopIndex ~= v156.updateLoopIndex then
				v156:addExactFillRootAimToUpdate(p153, p153.updatePipeNodes)
				return
			end
		else
			v163 = nil
			v161 = nil
			v162 = nil
			v164 = nil
		end
		local v165 = false
		for v166 = 1, #v155.nodes do
			local v167 = false
			local v168 = v155.nodes[v166]
			local v169
			if v168.bendingRegulation > 0 and v161 ~= nil then
				v169 = v163 - p153:updateBendingRegulationNodes(v168, (calcDistanceFrom(v168.node, v161)))
			else
				v169 = v163
			end
			local v170 = v168.states[v155.targetState]
			if v168.translationSpeeds ~= nil then
				for v171 = 1, 3 do
					local v172 = v168.curTranslation[v171] - v170.translation[v171]
					if math.abs(v172) > 1e-6 then
						v167 = true
						if v168.curTranslation[v171] < v170.translation[v171] then
							local v173 = v168.curTranslation
							local v174 = v168.curTranslation[v171] + p154 * v168.translationSpeeds[v171]
							local v175 = v170.translation[v171]
							v173[v171] = math.min(v174, v175)
						else
							local v176 = v168.curTranslation
							local v177 = v168.curTranslation[v171] - p154 * v168.translationSpeeds[v171]
							local v178 = v170.translation[v171]
							v176[v171] = math.max(v177, v178)
						end
					end
				end
				setTranslation(v168.node, v168.curTranslation[1], v168.curTranslation[2], v168.curTranslation[3])
			end
			if v168.rotationSpeeds ~= nil then
				local v179 = false
				for v180 = 1, 3 do
					local v181 = v170.rotation[v180]
					if v157 then
						if v168.autoAimXRotation and v180 == 1 then
							local v182, v183, v184 = getWorldTranslation(v168.node)
							if VehicleDebug.state == VehicleDebug.DEBUG then
								if v168.subPipeNode == nil then
									drawDebugLine(v182, v183, v184, 1, 0, 0, v162, v169, v164, 1, 0, 0)
								else
									local v185, v186, v187 = getWorldTranslation(v168.node)
									local v188, v189, v190 = localToWorld(v168.node, 0, 0, 3)
									drawDebugLine(v185, v186, v187, 1, 1, 0, v188, v189, v190, 1, 1, 0)
									DebugGizmo.renderAtPositionSimple(v188, v189, v190, string.format("ratio: %.2f", v168.subPipeNodeRatio))
								end
							end
							local _, v191, v192 = worldDirectionToLocal(getParent(v168.node), v162 - v182, v169 - v183, v164 - v184)
							local v193 = -math.atan2(v191, v192)
							if v168.subPipeNode ~= nil then
								v193 = v193 * v168.subPipeNodeRatio
							end
							if v168.autoAimInvertZ then
								v193 = v193 + 3.141592653589793
							end
							v181 = MathUtil.normalizeRotationForShortestPath(v193, v168.curRotation[v180])
						elseif v168.autoAimYRotation and v180 == 2 then
							local v194, v195, v196 = getWorldTranslation(v168.node)
							local v197, _, v198 = worldDirectionToLocal(getParent(v168.node), v162 - v194, v169 - v195, v164 - v196)
							local v199 = math.atan2(v197, v198)
							if v168.autoAimInvertZ then
								v199 = v199 + 3.141592653589793
							end
							v181 = MathUtil.normalizeRotationForShortestPath(v199, v168.curRotation[v180])
						end
					end
					if v168.minRotationLimits ~= nil and v168.maxRotationLimits ~= nil then
						if math.abs(v181) > 6.283185307179586 then
							v181 = v181 % 6.283185307179586
						end
						if v168.minRotationLimits[v180] ~= nil then
							local v200 = v168.minRotationLimits[v180]
							v181 = math.max(v181, v200)
						end
						if v168.maxRotationLimits[v180] ~= nil then
							local v201 = v168.maxRotationLimits[v180]
							v181 = math.min(v181, v201)
						end
					end
					local v202 = v168.curRotation[v180] - v181
					if math.abs(v202) > 0.00001 then
						v179 = true
						local v203 = true
						if not v157 then
							for v204 = 1, #v155.nodes do
								local v205 = v155.nodes[v204]
								if v205[v160] > v168[v160] then
									if v205.curRotation[1] == v205.lastTargetRotation[1] then
										if v205.curRotation[2] == v205.lastTargetRotation[2] then
											if v205.curRotation[3] ~= v205.lastTargetRotation[3] then
												v203 = false
											end
										else
											v203 = false
										end
									else
										v203 = false
									end
								end
							end
						end
						if v203 then
							local v206 = v168.curRotation[v180] - v181
							if math.abs(v206) > p154 * v168.rotationSpeeds[v180] * 0.95 then
								if v168.moveSamplesPlayTimer <= 0 then
									g_soundManager:playSamples(v168.moveSamples)
								end
								v168.moveSamplesPlayTimer = 250
							end
							v167 = true
							if v168.curRotation[v180] < v181 then
								local v207 = v168.curRotation
								local v208 = v168.curRotation[v180] + p154 * v168.rotationSpeeds[v180]
								v207[v180] = math.min(v208, v181)
							else
								local v209 = v168.curRotation
								local v210 = v168.curRotation[v180] - p154 * v168.rotationSpeeds[v180]
								v209[v180] = math.max(v210, v181)
							end
							if v168.curRotation[v180] > 6.283185307179586 then
								v168.curRotation[v180] = v168.curRotation[v180] - 6.283185307179586
							elseif v168.curRotation[v180] < -6.283185307179586 then
								v168.curRotation[v180] = v168.curRotation[v180] + 6.283185307179586
							end
							v168.lastTargetRotation[v180] = v181
						end
					end
				end
				if v179 then
					setRotation(v168.node, v168.curRotation[1], v168.curRotation[2], v168.curRotation[3])
				end
			end
			v165 = v165 or v167
			if v167 and p153.setMovingToolDirty ~= nil then
				p153:setMovingToolDirty(v168.node)
			end
		end
		if (#v155.nodes ~= 0 or (v155.animation.name == nil or not p153:getIsAnimationPlaying(v155.animation.name))) and not v165 then
			v155.currentState = v155.targetState
		end
	end
	for _, v211 in ipairs(v155.nodes) do
		v211.moveSamplesPlayTimer = v211.moveSamplesPlayTimer - p154
		if v211.moveSamplesPlayTimer < 0 then
			g_soundManager:stopSamples(v211.moveSamples)
			v211.moveSamplesPlayTimer = 0
		end
	end
end
function Pipe.updateBendingRegulationNodes(_, p212, p213)
	local _, v214, _ = localDirectionToWorld(p212.node, 0, 1, 0)
	for _, v215 in ipairs(p212.regulationNodes) do
		local v216 = v214 * p212.bendingRegulation
		local v217 = v215.weights
		local v218 = v215.startRotation
		setRotation(v215.node, v218[1] + v217[1] * v216, v218[2] + v217[2] * v216, v218[3] + v217[3] * v216)
		if VehicleDebug.state == VehicleDebug.DEBUG then
			local v219, v220, v221 = getWorldTranslation(v215.node)
			local v222, v223, v224 = localToWorld(v215.node, 0, -10, 0)
			drawDebugLine(v219, v220, v221, 0, 0, 1, v222, v223, v224, 0, 0, 1)
		end
	end
	local v225 = v214 * p212.bendingRegulation
	return math.sin(v225) * p213
end
function Pipe.unloadingTriggerCallback(p226, _, p227, p228, p229, _, _)
	if p228 or p229 then
		local v230 = g_currentMission:getNodeObject(p227)
		if v230 == nil or (v230 == p226 or not v230:isa(Vehicle)) then
			if v230 ~= nil and (v230 ~= p226 and v230:isa(UnloadTrigger)) then
				local v231 = p226.spec_pipe
				if p228 then
					if v231.unloadTriggersInTriggers[v230] == nil then
						v231.unloadTriggersInTriggers[v230] = 0
						v231.numUnloadTriggersInTriggers = v231.numUnloadTriggersInTriggers + 1
						if v230.addDeleteListener ~= nil then
							v230:addDeleteListener(p226, "onDeletePipeObject")
						end
					end
					v231.unloadTriggersInTriggers[v230] = v231.unloadTriggersInTriggers[v230] + 1
					p226:raiseActive()
					return
				end
				v231.unloadTriggersInTriggers[v230] = v231.unloadTriggersInTriggers[v230] - 1
				if v231.unloadTriggersInTriggers[v230] == 0 then
					v231.unloadTriggersInTriggers[v230] = nil
					v231.numUnloadTriggersInTriggers = v231.numUnloadTriggersInTriggers - 1
					if v230.removeDeleteListener ~= nil then
						v230:removeDeleteListener(p226)
					end
				end
			end
		elseif v230.getFillUnitIndexFromNode ~= nil then
			local v232 = v230:getFillUnitIndexFromNode(p227)
			if v232 ~= nil then
				local v233 = p226.spec_pipe
				local v234 = p226:getDischargeNodeByIndex(p226:getPipeDischargeNodeIndex())
				if v234 ~= nil then
					local v235 = p226:getFillUnitSupportedFillTypes(v234.fillUnitIndex)
					local v236 = false
					for v237, _ in pairs(v235) do
						if v230:getFillUnitSupportsFillType(v232, v237) then
							v236 = true
							break
						end
					end
					if v236 then
						if p228 then
							if v233.objectsInTriggers[v230] == nil then
								v233.objectsInTriggers[v230] = 0
								v233.numObjectsInTriggers = v233.numObjectsInTriggers + 1
								if v230.addDeleteListener ~= nil then
									v230:addDeleteListener(p226, "onDeletePipeObject")
								end
							end
							v233.objectsInTriggers[v230] = v233.objectsInTriggers[v230] + 1
							p226:raiseActive()
							return
						end
						v233.objectsInTriggers[v230] = v233.objectsInTriggers[v230] - 1
						if v233.objectsInTriggers[v230] == 0 then
							v233.objectsInTriggers[v230] = nil
							v233.numObjectsInTriggers = v233.numObjectsInTriggers - 1
							if v230.removeDeleteListener ~= nil then
								v230:removeDeleteListener(p226)
								return
							end
						end
					end
				end
			end
		end
	end
end
function Pipe.updateNearestObjectInTriggers(p238)
	local v239 = p238.spec_pipe
	v239.nearestObjectInTriggers.objectId = nil
	v239.nearestObjectInTriggers.fillUnitIndex = 0
	v239.nearestObjectInTriggers.isDischargeObject = false
	local v240 = (1 / 0)
	local v241 = p238:getDischargeNodeByIndex(p238:getPipeDischargeNodeIndex())
	if v241 == nil then
		Logging.xmlWarning(p238.xmlFile, "Unable to find discharge node index \'%d\' for pipe", p238:getPipeDischargeNodeIndex())
	else
		local v242 = Utils.getNoNil(v241.node, p238.components[1].node)
		for v243, _ in pairs(v239.objectsInTriggers) do
			local v244 = p238:getFillUnitLastValidFillType(v241.fillUnitIndex)
			for v245, _ in ipairs(v243.spec_fillUnit.fillUnits) do
				if v243:getFillUnitSupportsToolType(v245, ToolType.DISCHARGEABLE) and ((v243:getFillUnitSupportsFillType(v245, v244) or v244 == FillType.UNKNOWN) and v243:getFillUnitFreeCapacity(v245, v244, p238:getOwnerFarmId()) > 0) then
					local v246 = v243:getFillUnitAutoAimTargetNode(v245)
					local v247 = v243:getFillUnitExactFillRootNode(v245)
					if v246 ~= nil then
						v247 = v246
					end
					if v247 ~= nil then
						local v248 = calcDistanceFrom(v242, v247)
						if v248 < v240 then
							v239.nearestObjectInTriggers.objectId = NetworkUtil.getObjectId(v243)
							v239.nearestObjectInTriggers.fillUnitIndex = v245
							if v243 == v241.dischargeObject and v245 == v241.dischargeFillUnitIndex then
								v239.nearestObjectInTriggers.isDischargeObject = true
								v240 = v248
							else
								v240 = v248
							end
						end
					end
				end
			end
		end
	end
end
function Pipe.updateActionEventText(p249)
	local v250 = p249.spec_pipe
	local v251 = v250.actionEvents[InputAction.TOGGLE_PIPE]
	if v251 ~= nil then
		local v252 = false
		if v250.targetState == v250.numStates then
			if p249:getIsPipeStateChangeAllowed(1) then
				g_inputBinding:setActionEventText(v251.actionEventId, v250.texts.pipeIn)
				v252 = true
			end
		else
			local v253 = v250.targetState + 1
			if p249:getIsPipeStateChangeAllowed(v253) then
				local v254
				if v250.numUnloadingStates > 1 and v250.numUnloadingStates ~= v250.numStates then
					v254 = string.format(" [%d]", v253 - 1)
					local v255 = p249:getFillUnitFillType(p249:getDischargeNodeByIndex((p249:getPipeDischargeNodeIndex(v253))).fillUnitIndex)
					if v255 ~= FillType.UNKNOWN then
						local v256 = g_fillTypeManager:getFillTypeByIndex(v255)
						if v256 ~= nil then
							v254 = string.format(" [%d, %s]", v253 - 1, v256.title)
						end
					end
				else
					v254 = ""
				end
				g_inputBinding:setActionEventText(v251.actionEventId, string.format(v250.texts.pipeOut, v254))
				v252 = true
			end
		end
		g_inputBinding:setActionEventActive(v251.actionEventId, v252)
	end
end
function Pipe.getIsDischargeNodeActive(p257, p258, p259)
	local v260 = p257.spec_pipe
	if p259.index == p257:getPipeDischargeNodeIndex() then
		return v260.unloadingStates[v260.currentState] == true
	else
		return p258(p257, p259)
	end
end
function Pipe.getCanBeTurnedOn(p261, p262)
	local v263 = p261.spec_pipe
	if v263.hasMovablePipe and next(v263.turnOnAllowedStates) ~= nil then
		local v264 = false
		for v265, _ in pairs(v263.turnOnAllowedStates) do
			if v265 == v263.currentState then
				v264 = true
				break
			end
		end
		if not v264 then
			return false
		end
	end
	return p262(p261)
end
function Pipe.getTurnedOnNotAllowedWarning(p266, p267)
	local v268 = p266.spec_pipe
	if v268.hasMovablePipe and next(v268.turnOnAllowedStates) ~= nil then
		local v269 = false
		for v270, _ in pairs(v268.turnOnAllowedStates) do
			if v270 == v268.currentState then
				v269 = true
				break
			end
		end
		if not v269 then
			return v268.texts.turnOnStateWarning
		end
	end
	return p267(p266)
end
function Pipe.getIsFoldAllowed(p271, p272, p273, p274)
	local v275 = p271.spec_pipe
	if v275.hasMovablePipe and (v275.currentState > v275.foldMaxState or v275.currentState < v275.foldMinState) then
		return false, v275.texts.warningFoldingPipe
	else
		return p272(p271, p273, p274)
	end
end
function Pipe.handleDischarge(p276, p277, p278, p279, p280, p281)
	if p276.spec_pipe.automaticDischarge then
		if p278.index ~= p276:getPipeDischargeNodeIndex() then
			p277(p276, p278, p279, p280, p281)
			return
		end
	else
		p277(p276, p278, p279, p280, p281)
	end
end
function Pipe.handleDischargeRaycast(p282, p283, p284, p285, p286, p287, p288, p289)
	local v290 = p282.spec_pipe
	if v290.automaticDischarge then
		local v291 = false
		if p282:getIsPowered() and p285 ~= nil then
			local v292 = p282:getDischargeFillType(p284)
			if p285:getFillUnitAllowsFillType(p288, v292) and p285:getFillUnitFreeCapacity(p288, v292, p282:getOwnerFarmId()) > 0 then
				p282:setDischargeState(Dischargeable.DISCHARGE_STATE_OBJECT, true)
			else
				v291 = true
			end
		elseif p282:getIsPowered() and v290.toggleableDischargeToGround then
			p282:setDischargeState(Dischargeable.DISCHARGE_STATE_GROUND, true)
		else
			v291 = true
		end
		if v291 and p282:getDischargeState() == Dischargeable.DISCHARGE_STATE_OBJECT then
			p282:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF, true)
		end
	else
		p283(p282, p284, p285, p286, p287, p288, p289)
	end
end
function Pipe.dischargeToGround(p293, p294, p295, p296)
	local v297 = p293.spec_pipe
	if not v297.toggleableDischargeToGround or v297.dischargeToGroundState then
		return p294(p293, p295, p296)
	end
	local v298 = p293:getFillVolumeUnloadInfo(p295.unloadInfoIndex)
	p293:addFillUnitFillLevel(p293:getOwnerFarmId(), p295.fillUnitIndex, -p296, p293:getFillUnitFillType(p295.fillUnitIndex), ToolType.UNDEFINED, v298)
	return -p296, p296 > 0, p296 > 0
end
function Pipe.getCanToggleDischargeToObject(p299, p300)
	if p299.spec_pipe.automaticDischarge then
		return false
	else
		return p300(p299)
	end
end
function Pipe.getCanToggleDischargeToGround(p301, p302)
	local v303 = p301.spec_pipe
	if v303.automaticDischarge and v303.toggleableDischargeToGround then
		return false
	else
		return p302(p301)
	end
end
function Pipe.getRequiresPower(p304, p305)
	local v306 = p304.spec_pipe
	if v306.automaticDischarge then
		local v307 = p304:getDischargeNodeByIndex(p304:getPipeDischargeNodeIndex())
		if v307 ~= nil then
			if v306.isAsyncRaycastActive and v307.lastDischargeObject ~= nil then
				return true
			end
			if not v306.isAsyncRaycastActive and v307.dischargeObject ~= nil then
				return true
			end
		end
	end
	return v306.currentState ~= v306.targetState and true or p305(p304)
end
function Pipe.loadMovingToolFromXML(p308, p309, p310, p311, p312)
	if not p309(p308, p310, p311, p312) then
		return false
	end
	p312.freezingPipeStates = p310:getValue(p311 .. "#freezingPipeStates", nil, true)
	return true
end
function Pipe.getIsMovingToolActive(p313, p314, p315)
	local v316 = p313.spec_pipe
	if p315.freezingPipeStates ~= nil then
		for _, v317 in pairs(p315.freezingPipeStates) do
			if v316.currentState == v317 or (v316.targetState == v317 or v316.currentState == 0) then
				return false
			end
		end
	end
	return p314(p313, p315)
end
function Pipe.loadCoverFromXML(p318, p319, p320, p321, p322)
	p322.minPipeState = p320:getValue(p321 .. "#minPipeState", 0)
	p322.maxPipeState = p320:getValue(p321 .. "#maxPipeState", (1 / 0))
	return p319(p318, p320, p321, p322)
end
function Pipe.getIsNextCoverStateAllowed(p323, p324, p325)
	if not p324(p323, p325) then
		return false
	end
	local v326 = p323.spec_pipe
	local v327 = p323.spec_cover.covers[p325]
	return p325 == 0 or v326.currentState >= v327.minPipeState and v326.currentState <= v327.maxPipeState
end
function Pipe.onDeletePipeObject(p328, p329)
	local v330 = p328.spec_pipe
	if v330.objectsInTriggers[p329] ~= nil then
		v330.objectsInTriggers[p329] = nil
		v330.numObjectsInTriggers = v330.numObjectsInTriggers - 1
	end
	if v330.unloadTriggersInTriggers[p329] ~= nil then
		v330.unloadTriggersInTriggers[p329] = nil
		v330.numUnloadTriggersInTriggers = v330.numUnloadTriggersInTriggers - 1
	end
end
function Pipe.getPipeDischargeNodeIndex(p331, p332)
	local v333 = p331.spec_pipe
	if p332 == nil then
		p332 = v333.currentState
	end
	if v333.dischargeNodeMapping[p332] == nil then
		return v333.dischargeNodeIndex
	else
		return v333.dischargeNodeMapping[p332]
	end
end
function Pipe.setPipeDischargeToGround(p334, p335, p336)
	local v337 = p334.spec_pipe
	if p335 == nil then
		p335 = not v337.dischargeToGroundState
	end
	if p335 ~= v337.dischargeToGroundState then
		v337.dischargeToGroundState = p335
		local v338 = v337.actionEvents[InputAction.TOGGLE_TIPSTATE_GROUND]
		if v338 ~= nil then
			g_inputBinding:setActionEventText(v338.actionEventId, p335 and v337.texts.stopTipToGround or v337.texts.startTipToGround)
		end
		SetPipeDischargeToGroundEvent.sendEvent(p334, p335, p336)
	end
end
function Pipe.getCanBeSelected(_, _)
	return true
end
function Pipe.getIsAIReadyToDrive(p339, p340)
	local v341 = p339.spec_pipe
	if v341.hasMovablePipe and v341.currentState ~= 1 then
		return false
	else
		return p340(p339)
	end
end
function Pipe.getIsAIPreparingToDrive(p342, p343)
	local v344 = p342.spec_pipe
	return v344.hasMovablePipe and v344.currentState ~= v344.targetState and true or p343(p342)
end
function Pipe.onMovingToolChanged(p345, p346, _, _)
	local v347 = p345.spec_pipe
	for _, v348 in ipairs(v347.nodes) do
		if v348.node == p346.node then
			v348.curTranslation = { p346.curTrans[1], p346.curTrans[2], p346.curTrans[3] }
			v348.curRotation = { p346.curRot[1], p346.curRot[2], p346.curRot[3] }
		end
	end
end
function Pipe.onRegisterActionEvents(p349, _, p350)
	if p349.isClient then
		local v351 = p349.spec_pipe
		p349:clearActionEventsTable(v351.actionEvents)
		if p350 and v351.hasMovablePipe then
			local _, v352 = p349:addPoweredActionEvent(v351.actionEvents, InputAction.TOGGLE_PIPE, p349, Pipe.actionEventTogglePipe, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v352, GS_PRIO_HIGH)
			p349:updateActionEventText()
			if v351.toggleableDischargeToGround then
				local _, v353 = p349:addActionEvent(v351.actionEvents, InputAction.TOGGLE_TIPSTATE_GROUND, p349, Pipe.actionEventToggleDischargeToGround, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v353, GS_PRIO_NORMAL)
				g_inputBinding:setActionEventText(v353, v351.dischargeToGroundState and v351.texts.stopTipToGround or v351.texts.startTipToGround)
			end
		end
	end
end
function Pipe.onDischargeStateChanged(p354, p355)
	if p354.isClient then
		local v356 = p354.spec_pipe
		local v357 = p354:getCurrentDischargeNode()
		local v358
		if v357 == nil then
			v358 = nil
		else
			v358 = v357.index
		end
		if v358 == p354:getPipeDischargeNodeIndex() then
			if p355 == Dischargeable.DISCHARGE_STATE_OFF then
				g_animationManager:stopAnimations(v356.animationNodes)
				return
			end
			g_animationManager:startAnimations(v356.animationNodes)
			g_animationManager:setFillType(v356.animationNodes, p354:getFillUnitLastValidFillType(v357.fillUnitIndex))
		end
	end
end
function Pipe.onAIImplementPrepareForTransport(p359)
	if p359.spec_pipe.hasMovablePipe and p359:getIsPipeStateChangeAllowed(1) then
		p359:setPipeState(1)
	end
end
function Pipe.onRootVehicleChanged(p360, p361)
	local v362 = p360.spec_pipe
	if v362.hasMovablePipe and v362.numAutoAimingStates > 0 then
		local v363 = p361.actionController
		if v363 ~= nil then
			if v362.controlledAction == nil then
				local v364, _ = next(v362.autoAimingStates)
				v362.controlledAction = v363:registerAction("pipe", nil, 2)
				v362.controlledAction:setCallback(p360, Pipe.actionControllerPipeEvent)
				v362.controlledAction:addAIEventListener(p360, "onAIFieldWorkerEnd", -1)
				v362.controlledAction:setFinishedFunctions(p360, Pipe.getCurrentPipeState, v364, 1)
			else
				v362.controlledAction:updateParent(v363)
			end
		end
		if v362.controlledAction ~= nil then
			v362.controlledAction:remove()
			v362.controlledAction = nil
		end
	end
end
function Pipe.actionControllerPipeEvent(p365, p366)
	local v367 = p365.spec_pipe
	if p366 > 0 then
		local v368, _ = next(v367.autoAimingStates)
		p365:setPipeState(v368)
	else
		p365:setPipeState(1)
	end
	return true
end
function Pipe.actionEventTogglePipe(p369, _, _, _, _)
	local v370 = p369.spec_pipe
	local v371 = v370.targetState + 1
	local v372 = v370.numStates < v371 and 1 or v371
	if p369:getIsPipeStateChangeAllowed(v372) then
		p369:setPipeState(v372)
	elseif v372 ~= 1 and p369:getIsPipeStateChangeAllowed(1) then
		p369:setPipeState(1)
	end
end
function Pipe.actionEventToggleDischargeToGround(p373, _, _, _, _)
	p373:setPipeDischargeToGround()
end

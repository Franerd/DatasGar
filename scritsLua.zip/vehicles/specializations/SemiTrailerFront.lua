SemiTrailerFront = {}
function SemiTrailerFront.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AttacherJoints, p1)
end
function SemiTrailerFront.registerOverwrittenFunctions(p2)
	SpecializationUtil.registerOverwrittenFunction(p2, "isDetachAllowed", SemiTrailerFront.isDetachAllowed)
end
function SemiTrailerFront.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", SemiTrailerFront)
	SpecializationUtil.registerEventListener(p3, "onUpdate", SemiTrailerFront)
	SpecializationUtil.registerEventListener(p3, "onPostAttachImplement", SemiTrailerFront)
	SpecializationUtil.registerEventListener(p3, "onPreDetachImplement", SemiTrailerFront)
	SpecializationUtil.registerEventListener(p3, "onPreDetach", SemiTrailerFront)
	SpecializationUtil.registerEventListener(p3, "onPostAttach", SemiTrailerFront)
end
function SemiTrailerFront.onLoad(p4, _)
	local v5 = p4.spec_semiTrailerFront
	v5.inputAttacherCurFade = 1
	v5.inputAttacherFadeDir = 1
	v5.inputAttacherFadeDuration = 1000
	v5.joint = p4.spec_attachable.inputAttacherJoints[1]
	v5.joint.lowerRotLimitScaleBackup = { v5.joint.lowerRotLimitScale[1], v5.joint.lowerRotLimitScale[2], v5.joint.lowerRotLimitScale[3] }
	v5.attachedSemiTrailerBack = nil
	v5.inputAttacherImplement = nil
	v5.doSemiTrailerLockCheck = true
end
function SemiTrailerFront.onUpdate(p6, p7, _, _, _)
	local v8 = p6.spec_semiTrailerFront
	if v8.doSemiTrailerLockCheck then
		v8.doSemiTrailerLockCheck = false
		if v8.attachedSemiTrailerBack == nil then
			v8.inputAttacherFadeDir = -1
		end
	end
	if p6.isServer and v8.inputAttacherImplement ~= nil and (v8.inputAttacherCurFade > 0 and v8.inputAttacherFadeDir < 0 or v8.inputAttacherCurFade < 1 and v8.inputAttacherFadeDir > 0) then
		local v9 = v8.inputAttacherCurFade + v8.inputAttacherFadeDir * p7 / v8.inputAttacherFadeDuration
		v8.inputAttacherCurFade = math.clamp(v9, 0, 1)
		local v10 = v8.joint.lowerRotLimitScale
		local v11 = v8.joint.lowerRotLimitScaleBackup
		v10[1] = v11[1] * v8.inputAttacherCurFade
		v10[2] = v11[2] * v8.inputAttacherCurFade
		v10[3] = v11[3] * v8.inputAttacherCurFade
		local v12 = p6:getAttacherVehicle()
		if v12 ~= nil then
			local v13 = v12:getAttacherJoints()[v8.inputAttacherImplement.jointDescIndex]
			local v14 = v8.inputAttacherImplement.lowerRotLimit
			if v14 ~= nil then
				local v15 = v14[1] * v10[1]
				local v16 = v14[2] * v10[2]
				local v17 = v14[3] * v10[3]
				setJointRotationLimit(v13.jointIndex, 0, true, -v15, v15)
				setJointRotationLimit(v13.jointIndex, 1, true, -v16, v16)
				setJointRotationLimit(v13.jointIndex, 2, true, -v17, v17)
			end
		end
	end
end
function SemiTrailerFront.isDetachAllowed(p18, p19)
	local v20, v21 = p19(p18)
	if v20 then
		return p18.spec_semiTrailerFront.attachedSemiTrailerBack ~= nil, nil
	else
		return false, v21
	end
end
function SemiTrailerFront.onPostAttachImplement(p22, p23, _, _)
	local v24 = p22.spec_semiTrailerFront
	v24.attachedSemiTrailerBack = p23
	v24.inputAttacherFadeDir = 1000
end
function SemiTrailerFront.onPreDetachImplement(p25, _)
	local v26 = p25.spec_semiTrailerFront
	v26.attachedSemiTrailerBack = nil
	v26.inputAttacherFadeDir = -1
end
function SemiTrailerFront.onPreDetach(p27, _, _)
	p27.spec_semiTrailerFront.inputAttacherImplement = nil
end
function SemiTrailerFront.onPostAttach(p28, p29, _, _)
	p28.spec_semiTrailerFront.inputAttacherImplement = p29:getImplementByObject(p28)
end

source("dataS/scripts/vehicles/specializations/events/WoodHarvesterCutLengthEvent.lua")
source("dataS/scripts/vehicles/specializations/events/WoodHarvesterCutTreeEvent.lua")
source("dataS/scripts/vehicles/specializations/events/WoodHarvesterDropTreeEvent.lua")
source("dataS/scripts/vehicles/specializations/events/WoodHarvesterHeaderTiltEvent.lua")
source("dataS/scripts/vehicles/specializations/events/WoodHarvesterOnCutTreeEvent.lua")
source("dataS/scripts/vehicles/specializations/events/WoodHarvesterOnDelimbTreeEvent.lua")
WoodHarvester = {}
WoodHarvester.NUM_BITS_CUT_LENGTH = 5
WoodHarvester.HEADER_JOINT_TILT_XML_KEY = "vehicle.woodHarvester.headerJointTilt"
function WoodHarvester.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(TurnOnVehicle, p1)
end
function WoodHarvester.initSpecialization()
	g_storeManager:addSpecType("woodHarvesterMaxTreeSize", "shopListAttributeIconMaxTreeSize", WoodHarvester.loadSpecValueMaxTreeSize, WoodHarvester.getSpecValueMaxTreeSize, StoreSpecies.VEHICLE)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("WoodHarvester")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.woodHarvester.cutNode#node", "Cut node")
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutNode#maxRadius", "Max. radius", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutNode#sizeY", "Size Y", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutNode#sizeZ", "Size Z", 1)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.woodHarvester.cutNode#attachNode", "Attach node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.woodHarvester.cutNode#attachReferenceNode", "Attach reference node")
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutNode#attachMoveSpeed", "Attach move speed", 3)
	v2:register(XMLValueType.INT, "vehicle.woodHarvester.cutNode#releasedComponentJointIndex", "Released component joint")
	v2:register(XMLValueType.ANGLE, "vehicle.woodHarvester.cutNode#releasedComponentJointRotLimitXSpeed", "Released component joint rot limit X speed", 100)
	v2:register(XMLValueType.INT, "vehicle.woodHarvester.cutNode#releasedComponentJoint2Index", "Released component joint 2")
	v2:register(XMLValueType.STRING, WoodHarvester.HEADER_JOINT_TILT_XML_KEY .. "#animationName", "Header tilt animation")
	v2:register(XMLValueType.FLOAT, WoodHarvester.HEADER_JOINT_TILT_XML_KEY .. "#speedFactor", "Speed of header tilt animation", 1)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.woodHarvester.delimbNode#node", "Delimb node")
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.delimbNode#sizeX", "Delimb size X", 0.1)
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.delimbNode#sizeY", "Delimb size Y", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.delimbNode#sizeZ", "Delimb size Z", 1)
	v2:register(XMLValueType.BOOL, "vehicle.woodHarvester.delimbNode#delimbOnCut", "Delimb on cut", false)
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutLengths#min", "Min. cut length", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutLengths#max", "Max. cut length", 5)
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutLengths#step", "Cut length steps", 0.5)
	v2:register(XMLValueType.VECTOR_N, "vehicle.woodHarvester.cutLengths#values", "Multiple lengths that are available separated by blank space")
	v2:register(XMLValueType.INT, "vehicle.woodHarvester.cutLengths#startIndex", "Default selected cut length index", 1)
	EffectManager.registerEffectXMLPaths(v2, "vehicle.woodHarvester.cutEffects")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.woodHarvester.delimbEffects")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.woodHarvester.forwardingNodes")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.woodHarvester.sounds", "cut")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.woodHarvester.sounds", "delimb")
	v2:register(XMLValueType.STRING, "vehicle.woodHarvester.cutAnimation#name", "Cut animation name")
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutAnimation#speedScale", "Cut animation speed scale")
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.cutAnimation#cutTime", "Cut animation cut time")
	v2:register(XMLValueType.STRING, "vehicle.woodHarvester.grabAnimation#name", "Grab animation name")
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.grabAnimation#speedScale", "Grab animation speed scale")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.woodHarvester.treeSizeMeasure#node", "Tree size measure node")
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.treeSizeMeasure#rotMaxRadius", "Max. tree size as reference for grab animation", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.woodHarvester.treeSizeMeasure#rotMaxAnimTime", "Grab animation time which reflects the rotMaxRadius (0-1)", 1)
	Dashboard.registerDashboardXMLPaths(v2, "vehicle.woodHarvester.dashboards", { "cutLength", "curCutLength", "diameter" })
	v2:setXMLSpecializationType()
	local v3 = Vehicle.xmlSchemaSavegame
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).woodHarvester#currentCutLengthIndex", "Current cut length selection index", 1)
	v3:register(XMLValueType.BOOL, "vehicles.vehicle(?).woodHarvester#isTurnedOn", "Harvester is turned on", false)
	v3:register(XMLValueType.VECTOR_4, "vehicles.vehicle(?).woodHarvester#lastTreeSize", "Last dimensions of tree to cutNode")
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).woodHarvester#lastCutAttachDirection", "Last tree attach direction")
	v3:register(XMLValueType.VECTOR_3, "vehicles.vehicle(?).woodHarvester#lastTreeJointPos", "Last tree joint position in local space of splitShape")
	v3:register(XMLValueType.BOOL, "vehicles.vehicle(?).woodHarvester#hasAttachedSplitShape", "Has split shape attached", false)
end
function WoodHarvester.registerEvents(p4)
	SpecializationUtil.registerEvent(p4, "onCutTree")
end
function WoodHarvester.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "woodHarvesterSplitShapeCallback", WoodHarvester.woodHarvesterSplitShapeCallback)
	SpecializationUtil.registerFunction(p5, "setLastTreeDiameter", WoodHarvester.setLastTreeDiameter)
	SpecializationUtil.registerFunction(p5, "findSplitShapesInRange", WoodHarvester.findSplitShapesInRange)
	SpecializationUtil.registerFunction(p5, "cutTree", WoodHarvester.cutTree)
	SpecializationUtil.registerFunction(p5, "onDelimbTree", WoodHarvester.onDelimbTree)
	SpecializationUtil.registerFunction(p5, "getCanSplitShapeBeAccessed", WoodHarvester.getCanSplitShapeBeAccessed)
	SpecializationUtil.registerFunction(p5, "loadWoodHarvesterHeaderTiltFromXML", WoodHarvester.loadWoodHarvesterHeaderTiltFromXML)
	SpecializationUtil.registerFunction(p5, "getIsWoodHarvesterTiltStateAllowed", WoodHarvester.getIsWoodHarvesterTiltStateAllowed)
	SpecializationUtil.registerFunction(p5, "setWoodHarvesterTiltState", WoodHarvester.setWoodHarvesterTiltState)
	SpecializationUtil.registerFunction(p5, "setWoodHarvesterCutLengthIndex", WoodHarvester.setWoodHarvesterCutLengthIndex)
	SpecializationUtil.registerFunction(p5, "dropWoodHarvesterTree", WoodHarvester.dropWoodHarvesterTree)
end
function WoodHarvester.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanBeSelected", WoodHarvester.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDoConsumePtoPower", WoodHarvester.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsFoldAllowed", WoodHarvester.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p6, "getSupportsAutoTreeAlignment", WoodHarvester.getSupportsAutoTreeAlignment)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsAutoTreeAlignmentAllowed", WoodHarvester.getIsAutoTreeAlignmentAllowed)
	SpecializationUtil.registerOverwrittenFunction(p6, "getAutoAlignHasValidTree", WoodHarvester.getAutoAlignHasValidTree)
end
function WoodHarvester.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onPostLoad", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onLoadFinished", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onRegisterDashboardValueTypes", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onDelete", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onReadStream", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onWriteStream", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onReadUpdateStream", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onWriteUpdateStream", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onUpdate", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onUpdateTick", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onDraw", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onRegisterActionEvents", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onDeactivate", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onTurnedOn", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onTurnedOff", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onStateChange", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onCutTree", WoodHarvester)
	SpecializationUtil.registerEventListener(p7, "onVehicleSettingChanged", WoodHarvester)
end
function WoodHarvester.onLoad(p8, _)
	local v9 = p8.spec_woodHarvester
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.woodHarvester.delimbSound", "vehicle.woodHarvester.sounds.delimb")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.woodHarvester.cutSound", "vehicle.woodHarvester.sounds.cut")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.woodHarvester.treeSizeMeasure#index", "vehicle.woodHarvester.treeSizeMeasure#node")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.woodHarvester.forwardingWheels.wheel(0)", "vehicle.woodHarvester.forwardingNodes.animationNode")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.woodHarvester.cutParticleSystems", "vehicle.woodHarvester.cutEffects")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.woodHarvester.delimbParticleSystems", "vehicle.woodHarvester.delimbEffects")
	v9.curSplitShape = nil
	v9.attachedSplitShape = nil
	v9.hasAttachedSplitShape = false
	v9.isAttachedSplitShapeMoving = false
	v9.attachedSplitShapeLastDelimbTime = 0
	v9.attachedSplitShapeX = 0
	v9.attachedSplitShapeY = 0
	v9.attachedSplitShapeZ = 0
	v9.attachedSplitShapeTargetY = 0
	v9.attachedSplitShapeLastCutY = 0
	v9.attachedSplitShapeStartY = 0
	v9.attachedSplitShapeOnlyMove = false
	v9.attachedSplitShapeOnlyMoveDelay = 0
	v9.attachedSplitShapeMoveEffectActive = false
	v9.attachedSplitShapeDelimbEffectActive = false
	v9.cutTimer = -1
	v9.lastCutEventTime = 0
	v9.cutEventCoolDownTime = 1000
	v9.automaticCuttingEnabled = true
	v9.automaticCuttingIsDirty = false
	v9.lastTreeSize = nil
	v9.lastTreeJointPos = nil
	v9.loadedSplitShapeFromSavegame = false
	v9.cutNode = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#node", nil, p8.components, p8.i3dMappings)
	v9.cutMaxRadius = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#maxRadius", 1)
	v9.cutSizeY = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#sizeY", 1)
	v9.cutSizeZ = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#sizeZ", 1)
	v9.cutAttachNode = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#attachNode", nil, p8.components, p8.i3dMappings)
	v9.cutAttachReferenceNode = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#attachReferenceNode", nil, p8.components, p8.i3dMappings)
	v9.cutAttachMoveSpeed = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#attachMoveSpeed", 3) * 0.001
	local v10 = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#releasedComponentJointIndex")
	if v10 ~= nil then
		v9.cutReleasedComponentJoint = p8.componentJoints[v10]
		v9.cutReleasedComponentJointRotLimitX = 0
		v9.cutReleasedComponentJointRotLimitXSpeed = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#releasedComponentJointRotLimitXSpeed", 100) * 0.001
	end
	local v11 = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#releasedComponentJoint2Index")
	if v11 ~= nil then
		v9.cutReleasedComponentJoint2 = p8.componentJoints[v11]
		v9.cutReleasedComponentJoint2RotLimitX = 0
		v9.cutReleasedComponentJoint2RotLimitXSpeed = p8.xmlFile:getValue("vehicle.woodHarvester.cutNode#releasedComponentJointRotLimitXSpeed", 100) * 0.001
	end
	v9.headerJointTilt = {}
	if not p8:loadWoodHarvesterHeaderTiltFromXML(v9.headerJointTilt, p8.xmlFile, "vehicle.woodHarvester.headerJointTilt") then
		v9.headerJointTilt = nil
	end
	if v9.cutAttachReferenceNode ~= nil and v9.cutAttachNode ~= nil then
		v9.cutAttachHelperNode = createTransformGroup("helper")
		link(v9.cutAttachReferenceNode, v9.cutAttachHelperNode)
		setTranslation(v9.cutAttachHelperNode, 0, 0, 0)
		setRotation(v9.cutAttachHelperNode, 0, 0, 0)
	end
	v9.cutAttachDirection = 1
	v9.lastCutAttachDirection = 1
	v9.delimbNode = p8.xmlFile:getValue("vehicle.woodHarvester.delimbNode#node", nil, p8.components, p8.i3dMappings)
	v9.delimbSizeX = p8.xmlFile:getValue("vehicle.woodHarvester.delimbNode#sizeX", 0.1)
	v9.delimbSizeY = p8.xmlFile:getValue("vehicle.woodHarvester.delimbNode#sizeY", 1)
	v9.delimbSizeZ = p8.xmlFile:getValue("vehicle.woodHarvester.delimbNode#sizeZ", 1)
	v9.delimbOnCut = p8.xmlFile:getValue("vehicle.woodHarvester.delimbNode#delimbOnCut", false)
	v9.cutLengthMin = p8.xmlFile:getValue("vehicle.woodHarvester.cutLengths#min", 1)
	v9.cutLengthMax = p8.xmlFile:getValue("vehicle.woodHarvester.cutLengths#max", 5)
	v9.cutLengthStep = p8.xmlFile:getValue("vehicle.woodHarvester.cutLengths#step", 0.5)
	v9.cutLengths = p8.xmlFile:getValue("vehicle.woodHarvester.cutLengths#values", nil, true)
	if v9.cutLengths == nil or #v9.cutLengths == 0 then
		v9.cutLengths = {}
		for v12 = v9.cutLengthMin, v9.cutLengthMax, v9.cutLengthStep do
			local v13 = v9.cutLengths
			table.insert(v13, v12)
		end
	else
		for v14 = 1, #v9.cutLengths do
			if v9.cutLengths[v14] == 0 then
				v9.cutLengths[v14] = (1 / 0)
			end
		end
	end
	local v15 = p8.xmlFile:getValue("vehicle.woodHarvester.cutLengths#startIndex", 1)
	local v16 = #v9.cutLengths
	v9.currentCutLengthIndex = math.clamp(v15, 1, v16)
	v9.currentCutLength = v9.cutLengths[v9.currentCutLengthIndex] or 1
	if p8.isClient then
		v9.cutEffects = g_effectManager:loadEffect(p8.xmlFile, "vehicle.woodHarvester.cutEffects", p8.components, p8, p8.i3dMappings)
		v9.delimbEffects = g_effectManager:loadEffect(p8.xmlFile, "vehicle.woodHarvester.delimbEffects", p8.components, p8, p8.i3dMappings)
		v9.forwardingNodes = g_animationManager:loadAnimations(p8.xmlFile, "vehicle.woodHarvester.forwardingNodes", p8.components, p8, p8.i3dMappings)
		v9.samples = {}
		v9.samples.cut = g_soundManager:loadSampleFromXML(p8.xmlFile, "vehicle.woodHarvester.sounds", "cut", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v9.samples.delimb = g_soundManager:loadSampleFromXML(p8.xmlFile, "vehicle.woodHarvester.sounds", "delimb", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v9.isCutSamplePlaying = false
		v9.isDelimbSamplePlaying = false
	end
	v9.cutAnimation = {}
	v9.cutAnimation.name = p8.xmlFile:getValue("vehicle.woodHarvester.cutAnimation#name")
	v9.cutAnimation.speedScale = p8.xmlFile:getValue("vehicle.woodHarvester.cutAnimation#speedScale", 1)
	v9.cutAnimation.cutTime = p8.xmlFile:getValue("vehicle.woodHarvester.cutAnimation#cutTime", 1)
	v9.grabAnimation = {}
	v9.grabAnimation.name = p8.xmlFile:getValue("vehicle.woodHarvester.grabAnimation#name")
	v9.grabAnimation.speedScale = p8.xmlFile:getValue("vehicle.woodHarvester.grabAnimation#speedScale", 1)
	v9.treeSizeMeasure = {}
	v9.treeSizeMeasure.node = p8.xmlFile:getValue("vehicle.woodHarvester.treeSizeMeasure#node", nil, p8.components, p8.i3dMappings)
	v9.treeSizeMeasure.rotMaxRadius = p8.xmlFile:getValue("vehicle.woodHarvester.treeSizeMeasure#rotMaxRadius", 1)
	v9.treeSizeMeasure.rotMaxAnimTime = p8.xmlFile:getValue("vehicle.woodHarvester.treeSizeMeasure#rotMaxAnimTime", 1)
	v9.warnInvalidTree = false
	v9.warnInvalidTreeRadius = false
	v9.warnInvalidTreePosition = false
	v9.warnTreeNotOwned = false
	v9.lastDiameter = 0
	v9.texts = {}
	v9.texts.actionChangeCutLength = g_i18n:getText("action_woodHarvesterChangeCutLength")
	v9.texts.woodHarvesterTiltHeader = g_i18n:getText("action_woodHarvesterTiltHeader")
	v9.texts.uiMax = g_i18n:getText("ui_max")
	v9.texts.unitMeterShort = g_i18n:getText("unit_mShort")
	v9.texts.actionCut = g_i18n:getText("action_woodHarvesterCut")
	v9.texts.warningFoldingTreeMounted = g_i18n:getText("warning_foldingTreeMounted")
	v9.texts.warningTreeTooThick = g_i18n:getText("warning_treeTooThick")
	v9.texts.warningTreeTooThickAtPosition = g_i18n:getText("warning_treeTooThickAtPosition")
	v9.texts.warningTreeTypeNotSupported = g_i18n:getText("warning_treeTypeNotSupported")
	v9.texts.warningYouDontHaveAccessToThisLand = g_i18n:getText("warning_youAreNotAllowedToCutThisTree")
	v9.texts.warningFirstTurnOnTheTool = string.format(g_i18n:getText("warning_firstTurnOnTheTool"), p8.typeDesc)
	p8:registerVehicleSetting(GameSettings.SETTING.WOOD_HARVESTER_AUTO_CUT, true)
end
function WoodHarvester.onPostLoad(p17, _)
	local v18 = p17.spec_woodHarvester
	if v18.grabAnimation.name ~= nil then
		local v19 = -v18.grabAnimation.speedScale
		local v20 = v18.grabAnimation.speedScale < 0 and 1 or 0
		p17:playAnimation(v18.grabAnimation.name, v19, nil, true)
		p17:setAnimationStopTime(v18.grabAnimation.name, v20)
		AnimatedVehicle.updateAnimationByName(p17, v18.grabAnimation.name, 99999999, true)
	end
end
function WoodHarvester.onLoadFinished(p21, p22)
	local v23 = p21.spec_woodHarvester
	if p22 ~= nil and not p22.resetVehicles then
		p21:setWoodHarvesterCutLengthIndex(p22.xmlFile:getValue(p22.key .. ".woodHarvester#currentCutLengthIndex", v23.currentCutLengthIndex), true)
		if p22.xmlFile:getValue(p22.key .. ".woodHarvester#isTurnedOn", false) then
			p21:setIsTurnedOn(true)
		end
		if v23.grabAnimation.name ~= nil then
			AnimatedVehicle.updateAnimationByName(p21, v23.grabAnimation.name, 99999999, true)
		end
		local v24 = p22.xmlFile:getValue(p22.key .. ".woodHarvester#lastTreeSize", nil, true)
		if v24 ~= nil then
			v23.lastTreeSize = v24
		end
		local v25 = p22.xmlFile:getValue(p22.key .. ".woodHarvester#lastTreeJointPos", nil, true)
		if v25 ~= nil then
			v23.lastTreeJointPos = v25
		end
		v23.lastCutAttachDirection = p22.xmlFile:getValue(p22.key .. ".woodHarvester#lastCutAttachDirection", v23.lastCutAttachDirection)
		if p22.xmlFile:getValue(p22.key .. ".woodHarvester#hasAttachedSplitShape", false) and p21:getIsTurnedOn() then
			p21:findSplitShapesInRange(0.5, true)
			if v23.curSplitShape ~= nil and v23.curSplitShape ~= 0 then
				v23.loadedSplitShapeFromSavegame = true
			end
		end
	end
end
function WoodHarvester.onRegisterDashboardValueTypes(p26)
	local v_u_27 = p26.spec_woodHarvester
	local v28 = DashboardValueType.new("woodHarvester", "cutLength")
	v28:setValue(v_u_27, function()
		-- upvalues: (copy) v_u_27
		return v_u_27.currentCutLength == (1 / 0) and 9999999 or v_u_27.currentCutLength * 100
	end)
	p26:registerDashboardValueType(v28)
	local v29 = DashboardValueType.new("woodHarvester", "curCutLength")
	v29:setValue(v_u_27, function()
		-- upvalues: (copy) v_u_27
		local v30 = v_u_27.attachedSplitShapeStartY - v_u_27.attachedSplitShapeY
		return math.abs(v30) * 100
	end)
	p26:registerDashboardValueType(v29)
	local v31 = DashboardValueType.new("woodHarvester", "diameter")
	v31:setValue(v_u_27, function()
		-- upvalues: (copy) v_u_27
		return v_u_27.lastDiameter * 1000
	end)
	p26:registerDashboardValueType(v31)
end
function WoodHarvester.onDelete(p32)
	local v33 = p32.spec_woodHarvester
	if v33.attachedSplitShapeJointIndex ~= nil then
		removeJoint(v33.attachedSplitShapeJointIndex)
		v33.attachedSplitShapeJointIndex = nil
	end
	if v33.cutAttachHelperNode ~= nil then
		delete(v33.cutAttachHelperNode)
	end
	g_effectManager:deleteEffects(v33.cutEffects)
	g_effectManager:deleteEffects(v33.delimbEffects)
	g_soundManager:deleteSamples(v33.samples)
	g_animationManager:deleteAnimations(v33.forwardingNodes)
end
function WoodHarvester.saveToXMLFile(p34, p35, p36, _)
	local v37 = p34.spec_woodHarvester
	p35:setValue(p36 .. "#currentCutLengthIndex", v37.currentCutLengthIndex)
	p35:setValue(p36 .. "#isTurnedOn", p34:getIsTurnedOn() or v37.hasAttachedSplitShape)
	p35:setValue(p36 .. "#hasAttachedSplitShape", v37.hasAttachedSplitShape)
	p35:setValue(p36 .. "#lastCutAttachDirection", v37.lastCutAttachDirection)
	if v37.hasAttachedSplitShape then
		if v37.lastTreeSize ~= nil then
			local v38 = p36 .. "#lastTreeSize"
			local v39 = v37.lastTreeSize
			p35:setValue(v38, unpack(v39))
		end
		if v37.lastTreeJointPos ~= nil then
			local v40 = p36 .. "#lastTreeJointPos"
			local v41 = v37.lastTreeJointPos
			p35:setValue(v40, unpack(v41))
		end
	end
end
function WoodHarvester.onReadStream(p42, p43, _)
	local v44 = p42.spec_woodHarvester
	v44.hasAttachedSplitShape = streamReadBool(p43)
	if v44.hasAttachedSplitShape then
		local v45 = streamReadUIntN(p43, 7) / 127
		p42:setAnimationTime(v44.grabAnimation.name, v45, true)
		p42:setAnimationTime(v44.cutAnimation.name, 1, true)
	end
	v44.isAttachedSplitShapeMoving = streamReadBool(p43)
	p42:setWoodHarvesterCutLengthIndex(streamReadUIntN(p43, WoodHarvester.NUM_BITS_CUT_LENGTH), true)
end
function WoodHarvester.onWriteStream(p46, p47, _)
	local v48 = p46.spec_woodHarvester
	if streamWriteBool(p47, v48.hasAttachedSplitShape) then
		local v49 = p46:getAnimationTime(v48.grabAnimation.name)
		streamWriteUIntN(p47, v49 * 127, 7)
	end
	streamWriteBool(p47, v48.isAttachedSplitShapeMoving)
	streamWriteUIntN(p47, v48.currentCutLengthIndex, WoodHarvester.NUM_BITS_CUT_LENGTH)
end
function WoodHarvester.onReadUpdateStream(p50, p51, _, p52)
	if p52:getIsServer() then
		local v53 = p50.spec_woodHarvester
		v53.attachedSplitShapeMoveEffectActive = streamReadBool(p51)
		if v53.attachedSplitShapeMoveEffectActive then
			v53.attachedSplitShapeDelimbEffectActive = streamReadBool(p51)
			return
		end
		v53.attachedSplitShapeDelimbEffectActive = false
	end
end
function WoodHarvester.onWriteUpdateStream(p54, p55, p56, _)
	if not p56:getIsServer() then
		local v57 = p54.spec_woodHarvester
		if streamWriteBool(p55, v57.attachedSplitShapeMoveEffectActive) then
			streamWriteBool(p55, v57.attachedSplitShapeDelimbEffectActive)
		end
	end
end
function WoodHarvester.onUpdate(p58, p59, _, _, _)
	local v60 = p58.spec_woodHarvester
	if p58.isServer then
		local v61 = false
		if v60.attachedSplitShape == nil then
			if v60.curSplitShape ~= nil and not entityExists(v60.curSplitShape) then
				v60.curSplitShape = nil
				v61 = true
			end
		elseif not entityExists(v60.attachedSplitShape) then
			v60.attachedSplitShape = nil
			v60.attachedSplitShapeJointIndex = nil
			v60.isAttachedSplitShapeMoving = false
			v60.attachedSplitShapeMoveEffectActive = false
			v60.attachedSplitShapeDelimbEffectActive = false
			v60.cutTimer = -1
			v61 = true
		end
		if v61 then
			SpecializationUtil.raiseEvent(p58, "onCutTree", 0, false, false)
			if g_server ~= nil then
				g_server:broadcastEvent(WoodHarvesterOnCutTreeEvent.new(p58, 0), nil, nil, p58)
			end
		end
	end
	if p58.isServer and (v60.attachedSplitShape ~= nil or v60.curSplitShape ~= nil) then
		if v60.cutTimer > 0 then
			if v60.cutAnimation.name == nil then
				local v62 = v60.cutTimer - p59
				v60.cutTimer = math.max(v62, 0)
			elseif p58:getAnimationTime(v60.cutAnimation.name) > v60.cutAnimation.cutTime then
				v60.cutTimer = 0
			end
		end
		if v60.cutTimer == 0 then
			v60.cutTimer = -1
			local v63, v64, v65 = getWorldTranslation(v60.cutNode)
			local v66, v67, v68 = localDirectionToWorld(v60.cutNode, 1, 0, 0)
			local v69, v70, v71 = localDirectionToWorld(v60.cutNode, 0, 1, 0)
			local v72 = false
			local v73
			if v60.attachedSplitShapeJointIndex == nil then
				v73 = v60.curSplitShape
				v60.curSplitShape = nil
				v72 = true
			else
				removeJoint(v60.attachedSplitShapeJointIndex)
				v60.attachedSplitShapeJointIndex = nil
				v73 = v60.attachedSplitShape
				v60.attachedSplitShape = nil
			end
			local v74 = g_splitShapeManager:getSplitTypeByIndex(getSplitType(v73))
			local v75 = v74 == nil and "" or v74.name
			if v60.delimbOnCut then
				local v76, v77, v78 = getWorldTranslation(v60.delimbNode)
				local v79, v80, v81 = localDirectionToWorld(v60.delimbNode, 1, 0, 0)
				local v82, v83, v84 = localDirectionToWorld(v60.delimbNode, 0, 1, 0)
				local v85 = v63 - v76
				local v86 = v64 - v77
				local v87 = v65 - v78
				local v88 = MathUtil.vector3Length(v85, v86, v87)
				removeSplitShapeAttachments(v73, v76 + v85 * 0.5, v77 + v86 * 0.5, v78 + v87 * 0.5, v79, v80, v81, v82, v83, v84, v88 * 0.7 + v60.delimbSizeX, v60.delimbSizeY, v60.delimbSizeZ)
			end
			v60.attachedSplitShape = nil
			v60.curSplitShape = nil
			v60.prevSplitShape = v73
			local v89 = not v60.loadedSplitShapeFromSavegame
			if getRigidBodyType(v73) ~= RigidBodyType.STATIC and v72 then
				v89 = false
			end
			if v89 then
				g_currentMission:removeKnownSplitShape(v73)
				p58.shapeBeingCut = v73
				p58.shapeBeingCutIsTree = getRigidBodyType(v73) == RigidBodyType.STATIC
				p58.shapeBeingCutIsNew = v72
				splitShape(v73, v63, v64, v65, v66, v67, v68, v69, v70, v71, v60.cutSizeY, v60.cutSizeZ, "woodHarvesterSplitShapeCallback", p58)
				g_treePlantManager:removingSplitShape(v73)
			else
				local v90 = 0
				local v91, v92, v93, v94
				if v60.lastTreeSize == nil or not v60.loadedSplitShapeFromSavegame then
					v91, v92, v93, v94 = testSplitShape(v73, v63, v64, v65, v66, v67, v68, v69, v70, v71, v60.cutSizeY, v60.cutSizeZ)
					if v91 ~= nil then
						local v95, _ = getSplitShapePlaneExtents(v73, v63, v64, v65, v66, v67, v68)
						if v95 ~= nil and v95 > 0.01 then
							v90 = -v95
						end
					end
				else
					v91 = v60.lastTreeSize[1]
					v92 = v60.lastTreeSize[2]
					v93 = v60.lastTreeSize[3]
					v94 = v60.lastTreeSize[4]
				end
				if v91 ~= nil then
					p58:woodHarvesterSplitShapeCallback(v73, false, true, v91, v92, v93, v94)
					g_messageCenter:publish(MessageType.TREE_SHAPE_MOUNTED, v73, p58)
					if v90 ~= 0 then
						v60.attachedSplitShapeTargetY = v60.attachedSplitShapeLastCutY + v90 * v60.cutAttachDirection
						v60.attachedSplitShapeOnlyMove = true
						v60.attachedSplitShapeOnlyMoveDelay = 750
						p58:onDelimbTree(true)
					end
				end
			end
			if v60.attachedSplitShape == nil then
				SpecializationUtil.raiseEvent(p58, "onCutTree", 0, false, false)
				if g_server ~= nil then
					g_server:broadcastEvent(WoodHarvesterOnCutTreeEvent.new(p58, 0), nil, nil, p58)
				end
			elseif v60.delimbOnCut then
				local v96, v97, v98 = getWorldTranslation(v60.delimbNode)
				local v99, v100, v101 = localDirectionToWorld(v60.delimbNode, 1, 0, 0)
				local v102, v103, v104 = localDirectionToWorld(v60.delimbNode, 0, 1, 0)
				local v105 = v63 - v96
				local v106 = v64 - v97
				local v107 = v65 - v98
				local v108 = MathUtil.vector3Length(v105, v106, v107)
				removeSplitShapeAttachments(v60.attachedSplitShape, v96 + v105 * 3, v97 + v106 * 3, v98 + v107 * 3, v99, v100, v101, v102, v103, v104, v108 * 3 + v60.delimbSizeX, v60.delimbSizeY, v60.delimbSizeZ)
			end
			if v89 and v72 then
				local v109, _ = g_farmManager:updateFarmStats(p58:getActiveFarm(), "cutTreeCount", 1)
				if v109 ~= nil then
					g_achievementManager:tryUnlock("CutTreeFirst", v109)
					g_achievementManager:tryUnlock("CutTree", v109)
				end
				if v75 ~= "" then
					local v110 = g_farmManager:getFarmById(p58:getActiveFarm())
					if v110 ~= nil then
						v110.stats:updateTreeTypesCut(v75)
					end
				end
			end
		end
		v60.attachedSplitShapeMoveEffectActive = false
		v60.attachedSplitShapeDelimbEffectActive = false
		if v60.attachedSplitShape ~= nil and v60.isAttachedSplitShapeMoving then
			if v60.delimbNode ~= nil then
				local v111, v112, v113 = getWorldTranslation(v60.delimbNode)
				local v114, v115, v116 = localDirectionToWorld(v60.delimbNode, 1, 0, 0)
				local v117, v118, v119 = localDirectionToWorld(v60.delimbNode, 0, 1, 0)
				if removeSplitShapeAttachments(v60.attachedSplitShape, v111, v112, v113, v114, v115, v116, v117, v118, v119, v60.delimbSizeX, v60.delimbSizeY, v60.delimbSizeZ) then
					v60.attachedSplitShapeLastDelimbTime = g_time
				end
				if g_time - v60.attachedSplitShapeLastDelimbTime < 500 then
					v60.attachedSplitShapeDelimbEffectActive = true
				end
			end
			local v120 = false
			local v121 = false
			if v60.attachedSplitShapeOnlyMove then
				if v60.attachedSplitShapeOnlyMoveDelay <= 0 then
					local v122 = v60.attachedSplitShapeTargetY > v60.attachedSplitShapeY and 1 or -1
					v60.attachedSplitShapeY = (v60.attachedSplitShapeTargetY > v60.attachedSplitShapeY and math.min or math.max)(v60.attachedSplitShapeY + v60.cutAttachMoveSpeed * p59 * v122, v60.attachedSplitShapeTargetY)
					if v60.attachedSplitShapeY == v60.attachedSplitShapeTargetY then
						v60.isAttachedSplitShapeMoving = false
						v60.attachedSplitShapeOnlyMove = false
						v60.attachedSplitShapeLastCutY = v60.attachedSplitShapeY
						v120 = true
						v121 = true
					else
						v120 = true
						v121 = true
					end
				else
					v60.attachedSplitShapeOnlyMoveDelay = v60.attachedSplitShapeOnlyMoveDelay - p59
				end
			elseif v60.cutNode ~= nil and v60.attachedSplitShapeJointIndex ~= nil then
				local v123, v124, v125 = getWorldTranslation(v60.cutAttachReferenceNode)
				local v126, v127, v128 = localDirectionToWorld(v60.cutAttachReferenceNode, 0, 1, 0)
				local _, v129 = getSplitShapePlaneExtents(v60.attachedSplitShape, v123, v124, v125, v126, v127, v128)
				if v129 == nil or v129 <= 0.1 then
					removeJoint(v60.attachedSplitShapeJointIndex)
					v60.attachedSplitShapeJointIndex = nil
					v60.attachedSplitShape = nil
					p58:onDelimbTree(false)
					if g_server ~= nil then
						g_server:broadcastEvent(WoodHarvesterOnDelimbTreeEvent.new(p58, false), nil, nil, p58)
					end
					SpecializationUtil.raiseEvent(p58, "onCutTree", 0, false, false)
					if g_server ~= nil then
						g_server:broadcastEvent(WoodHarvesterOnCutTreeEvent.new(p58, 0), nil, nil, p58)
					end
				else
					local v130 = v60.attachedSplitShapeTargetY > v60.attachedSplitShapeY and 1 or -1
					v60.attachedSplitShapeY = (v60.attachedSplitShapeTargetY > v60.attachedSplitShapeY and math.min or math.max)(v60.attachedSplitShapeY + v60.cutAttachMoveSpeed * p59 * v130, v60.attachedSplitShapeTargetY)
					if v60.attachedSplitShapeY == v60.attachedSplitShapeTargetY then
						p58:onDelimbTree(false)
						if g_server == nil then
							v120 = true
						else
							g_server:broadcastEvent(WoodHarvesterOnDelimbTreeEvent.new(p58, false), nil, nil, p58)
							v120 = true
						end
					else
						v120 = true
					end
				end
			end
			if v120 and v60.attachedSplitShapeJointIndex ~= nil then
				local v131, v132, v133 = localToWorld(v60.cutNode, 0.3, 0, 0)
				local v134, v135, v136 = localDirectionToWorld(v60.cutNode, 1, 0, 0)
				local v137, v138, v139 = localDirectionToWorld(v60.cutNode, 0, 1, 0)
				local v140, v141, v142, v143, v144 = findSplitShape(v131, v132, v133, v134, v135, v136, v137, v138, v139, v60.cutSizeY, v60.cutSizeZ)
				if v140 == v60.attachedSplitShape then
					local v145, v146, v147 = localToWorld(v60.cutNode, 0, (v141 + v142) * 0.5, (v143 + v144) * 0.5)
					local v148, _, v149 = worldToLocal(v60.attachedSplitShape, v145, v146, v147)
					v60.attachedSplitShapeX = v148
					v60.attachedSplitShapeZ = v149
					p58:setLastTreeDiameter((v142 - v141 + v144 - v143) * 0.5)
				end
				local v150, v151, v152 = localToWorld(v60.attachedSplitShape, v60.attachedSplitShapeX, v60.attachedSplitShapeY, v60.attachedSplitShapeZ)
				setJointPosition(v60.attachedSplitShapeJointIndex, 1, v150, v151, v152)
				if v121 then
					v60.lastTreeJointPos[1] = v60.attachedSplitShapeX
					v60.lastTreeJointPos[2] = v60.attachedSplitShapeY
					v60.lastTreeJointPos[3] = v60.attachedSplitShapeZ
				end
			end
			v60.attachedSplitShapeMoveEffectActive = v120
		end
	end
	if p58.isClient then
		if v60.cutAnimation.name ~= nil then
			if p58:getIsAnimationPlaying(v60.cutAnimation.name) and p58:getAnimationTime(v60.cutAnimation.name) < v60.cutAnimation.cutTime then
				if not v60.isCutSamplePlaying then
					g_soundManager:playSample(v60.samples.cut)
					v60.isCutSamplePlaying = true
				end
				g_effectManager:setEffectTypeInfo(v60.cutEffects, FillType.WOODCHIPS)
				g_effectManager:startEffects(v60.cutEffects)
			else
				if v60.isCutSamplePlaying then
					g_soundManager:stopSample(v60.samples.cut)
					v60.isCutSamplePlaying = false
				end
				g_effectManager:stopEffects(v60.cutEffects)
			end
		end
		if v60.attachedSplitShapeMoveEffectActive then
			if not v60.isDelimbSamplePlaying then
				g_soundManager:playSample(v60.samples.delimb)
				v60.isDelimbSamplePlaying = true
			end
			g_effectManager:setEffectTypeInfo(v60.delimbEffects, FillType.WOODCHIPS)
			g_effectManager:startEffects(v60.delimbEffects)
			g_effectManager:setDensity(v60.delimbEffects, v60.attachedSplitShapeDelimbEffectActive and 1 or 0.1)
			g_animationManager:startAnimations(v60.forwardingNodes)
			return
		end
		if v60.isDelimbSamplePlaying then
			g_soundManager:stopSample(v60.samples.delimb)
			v60.isDelimbSamplePlaying = false
		end
		g_effectManager:stopEffects(v60.delimbEffects)
		g_animationManager:stopAnimations(v60.forwardingNodes)
	end
end
function WoodHarvester.onUpdateTick(p153, p154, _, _, _)
	local v155 = p153.spec_woodHarvester
	v155.warnInvalidTree = false
	v155.warnInvalidTreeRadius = false
	v155.warnInvalidTreePosition = false
	v155.warnTreeNotOwned = false
	if p153:getIsTurnedOn() and (v155.attachedSplitShape == nil and v155.cutNode ~= nil) then
		local v156, v157, v158 = getWorldTranslation(v155.cutNode)
		local v159, v160, v161 = localDirectionToWorld(v155.cutNode, 1, 0, 0)
		local v162, v163, v164 = localDirectionToWorld(v155.cutNode, 0, 1, 0)
		p153:findSplitShapesInRange()
		if v155.curSplitShape ~= nil then
			if entityExists(v155.curSplitShape) then
				local v165, v166, v167, v168 = testSplitShape(v155.curSplitShape, v156, v157, v158, v159, v160, v161, v162, v163, v164, v155.cutSizeY, v155.cutSizeZ)
				if v165 == nil then
					v155.curSplitShape = nil
				else
					local _, v169, _ = localToLocal(v155.cutNode, v155.curSplitShape, 0, v165, v167)
					local v170 = v169 < 0.01
					local _, v171, _ = localToLocal(v155.cutNode, v155.curSplitShape, 0, v165, v168)
					local v172 = v170 or v171 < 0.01
					local _, v173, _ = localToLocal(v155.cutNode, v155.curSplitShape, 0, v166, v167)
					local v174 = v172 or v173 < 0.01
					local _, v175, _ = localToLocal(v155.cutNode, v155.curSplitShape, 0, v166, v168)
					if v174 or v175 < 0.01 then
						v155.curSplitShape = nil
					end
				end
			else
				v155.curSplitShape = nil
			end
		end
		if v155.curSplitShape == nil and v155.cutTimer > -1 then
			SpecializationUtil.raiseEvent(p153, "onCutTree", 0, false, false)
			if g_server ~= nil then
				g_server:broadcastEvent(WoodHarvesterOnCutTreeEvent.new(p153, 0), nil, nil, p153)
			end
		end
	end
	if p153.isServer and v155.attachedSplitShape == nil then
		if v155.cutReleasedComponentJoint ~= nil and v155.cutReleasedComponentJointRotLimitX ~= 0 then
			local v176 = v155.cutReleasedComponentJointRotLimitX - v155.cutReleasedComponentJointRotLimitXSpeed * p154
			v155.cutReleasedComponentJointRotLimitX = math.max(0, v176)
			setJointRotationLimit(v155.cutReleasedComponentJoint.jointIndex, 0, true, 0, v155.cutReleasedComponentJointRotLimitX)
		end
		if v155.cutReleasedComponentJoint2 ~= nil and v155.cutReleasedComponentJoint2RotLimitX ~= 0 then
			local v177 = v155.cutReleasedComponentJoint2RotLimitX - v155.cutReleasedComponentJoint2RotLimitXSpeed * p154
			v155.cutReleasedComponentJoint2RotLimitX = math.max(v177, 0)
			setJointRotationLimit(v155.cutReleasedComponentJoint2.jointIndex, 0, true, -v155.cutReleasedComponentJoint2RotLimitX, v155.cutReleasedComponentJoint2RotLimitX)
		end
	end
	if p153.isServer and (p153.playDelayedGrabAnimationTime ~= nil and p153.playDelayedGrabAnimationTime < g_currentMission.time) then
		p153.playDelayedGrabAnimationTime = nil
		if p153:getAnimationTime(v155.grabAnimation.name) > 0 and (v155.grabAnimation.name ~= nil and v155.attachedSplitShape == nil) then
			if v155.grabAnimation.speedScale > 0 then
				p153:setAnimationStopTime(v155.grabAnimation.name, 0)
			else
				p153:setAnimationStopTime(v155.grabAnimation.name, 1)
			end
			p153:playAnimation(v155.grabAnimation.name, -v155.grabAnimation.speedScale, p153:getAnimationTime(v155.grabAnimation.name), false)
		end
	end
	if p153.isClient then
		local v178 = v155.actionEvents[InputAction.IMPLEMENT_EXTRA2]
		if v178 ~= nil then
			local v179 = false
			local v180
			if v155.hasAttachedSplitShape then
				v180 = not v155.isAttachedSplitShapeMoving and p153:getAnimationTime(v155.cutAnimation.name) == 1 and true or v179
			else
				v180 = v155.curSplitShape ~= nil and true or v179
			end
			g_inputBinding:setActionEventActive(v178.actionEventId, v180)
			local v181 = v155.actionEvents[InputAction.WOOD_HARVESTER_DROP]
			if v181 ~= nil then
				g_inputBinding:setActionEventActive(v181.actionEventId, v180)
			end
		end
		local v182 = v155.actionEvents[InputAction.IMPLEMENT_EXTRA3]
		if v182 ~= nil then
			g_inputBinding:setActionEventActive(v182.actionEventId, not v155.isAttachedSplitShapeMoving)
			if not v155.isAttachedSplitShapeMoving then
				local v183 = string.format("%.1f%s", v155.currentCutLength, v155.texts.unitMeterShort)
				if v155.currentCutLength == (1 / 0) then
					v183 = v155.texts.uiMax
				end
				g_inputBinding:setActionEventText(v182.actionEventId, string.format(v155.texts.actionChangeCutLength, v183))
			end
		end
	end
end
function WoodHarvester.onDraw(p184, _, p185, p186)
	local v187 = p184.spec_woodHarvester
	if p185 and (p186 and (p184:getIsTurnedOn() and v187.cutNode ~= nil)) then
		if v187.warnInvalidTreeRadius then
			g_currentMission:showBlinkingWarning(v187.texts.warningTreeTooThick, 100)
			return
		end
		if v187.warnInvalidTreePosition then
			g_currentMission:showBlinkingWarning(v187.texts.warningTreeTooThickAtPosition, 100)
			return
		end
		if v187.warnInvalidTree then
			g_currentMission:showBlinkingWarning(v187.texts.warningTreeTypeNotSupported, 100)
			return
		end
		if v187.warnTreeNotOwned then
			g_currentMission:showBlinkingWarning(v187.texts.warningYouDontHaveAccessToThisLand, 100)
		end
	end
end
function WoodHarvester.onRegisterActionEvents(p188, _, p189)
	if p188.isClient then
		local v190 = p188.spec_woodHarvester
		p188:clearActionEventsTable(v190.actionEvents)
		if p189 then
			local _, v191 = p188:addPoweredActionEvent(v190.actionEvents, InputAction.IMPLEMENT_EXTRA2, p188, WoodHarvester.actionEventCutTree, false, true, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v191, GS_PRIO_HIGH)
			g_inputBinding:setActionEventText(v191, v190.texts.actionCut)
			local _, v192 = p188:addActionEvent(v190.actionEvents, InputAction.IMPLEMENT_EXTRA3, p188, WoodHarvester.actionEventSetCutlength, false, true, false, true, 1)
			g_inputBinding:setActionEventTextPriority(v192, GS_PRIO_HIGH)
			local _, v193 = p188:addActionEvent(v190.actionEvents, InputAction.TOGGLE_CUT_LENGTH_BACK, p188, WoodHarvester.actionEventSetCutlength, false, true, false, true, -1)
			g_inputBinding:setActionEventTextVisibility(v193, false)
			local _, v194 = p188:addActionEvent(v190.actionEvents, InputAction.WOOD_HARVESTER_DROP, p188, WoodHarvester.actionEventDropTree, false, true, false, true, nil)
			g_inputBinding:setActionEventTextVisibility(v194, true)
			g_inputBinding:setActionEventTextPriority(v194, GS_PRIO_NORMAL)
			if v190.headerJointTilt ~= nil then
				local _, v195 = p188:addActionEvent(v190.actionEvents, InputAction.TOGGLE_WOOD_HARVESTER_TILT, p188, WoodHarvester.actionEventTiltHeader, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v195, GS_PRIO_HIGH)
				g_inputBinding:setActionEventText(v195, v190.texts.woodHarvesterTiltHeader)
			end
		end
	end
end
function WoodHarvester.onDeactivate(p196)
	p196.spec_woodHarvester.curSplitShape = nil
	p196:setLastTreeDiameter(0)
end
function WoodHarvester.onTurnedOn(p197)
	local v198 = p197.spec_woodHarvester
	p197.playDelayedGrabAnimationTime = nil
	if v198.grabAnimation.name ~= nil and v198.attachedSplitShape == nil then
		if v198.grabAnimation.speedScale > 0 then
			p197:setAnimationStopTime(v198.grabAnimation.name, 1)
		else
			p197:setAnimationStopTime(v198.grabAnimation.name, 0)
		end
		p197:playAnimation(v198.grabAnimation.name, v198.grabAnimation.speedScale, p197:getAnimationTime(v198.grabAnimation.name), true)
	end
	p197:setLastTreeDiameter(0)
end
function WoodHarvester.onTurnedOff(p199)
	local v200 = p199.spec_woodHarvester
	if v200.grabAnimation.name ~= nil and v200.attachedSplitShape == nil then
		p199.playDelayedGrabAnimationTime = g_currentMission.time + 500
		if v200.grabAnimation.speedScale > 0 then
			p199:setAnimationStopTime(v200.grabAnimation.name, 1)
		else
			p199:setAnimationStopTime(v200.grabAnimation.name, 0)
		end
		p199:playAnimation(v200.grabAnimation.name, v200.grabAnimation.speedScale, p199:getAnimationTime(v200.grabAnimation.name), true)
	end
	if p199.isClient then
		g_effectManager:stopEffects(v200.delimbEffects)
		g_effectManager:stopEffects(v200.cutEffects)
		g_soundManager:stopSamples(v200.samples)
		v200.isCutSamplePlaying = false
		v200.isDelimbSamplePlaying = false
	end
end
function WoodHarvester.onStateChange(p201, p202, _)
	if p201.isServer and (p202 == VehicleStateChange.MOTOR_TURN_ON and (p201.spec_woodHarvester.attachedSplitShape ~= nil and p201:getCanBeTurnedOn())) then
		p201:setIsTurnedOn(true)
	end
end
function WoodHarvester.getCanSplitShapeBeAccessed(p203, p204, p205, p206)
	return g_splitShapeManager:getIsShapeCutAllowed(p204, p205, p206, p203:getActiveFarm(), p203:getOwnerConnection())
end
function WoodHarvester.loadWoodHarvesterHeaderTiltFromXML(_, p207, p208, p209)
	p207.animationName = p208:getValue(p209 .. "#animationName")
	if p207.animationName == nil then
		return false
	end
	p207.speedFactor = p208:getValue(p209 .. "#speedFactor", 1)
	p207.state = false
	p207.lastState = nil
	return true
end
function WoodHarvester.getIsWoodHarvesterTiltStateAllowed(_, _)
	return true
end
function WoodHarvester.setWoodHarvesterTiltState(p210, p211, p212)
	local v213 = p210.spec_woodHarvester
	if p211 == nil then
		p211 = not v213.headerJointTilt.state
	end
	if p211 ~= v213.headerJointTilt.state then
		v213.headerJointTilt.state = p211
		p210:playAnimation(v213.headerJointTilt.animationName, p211 and 1 or -1, p210:getAnimationTime(v213.headerJointTilt.animationName), true)
	end
	WoodHarvesterHeaderTiltEvent.sendEvent(p210, p211, p212)
end
function WoodHarvester.setWoodHarvesterCutLengthIndex(p214, p215, p216)
	local v217 = p214.spec_woodHarvester
	if p215 ~= v217.currentCutLengthIndex then
		v217.currentCutLengthIndex = p215
		v217.currentCutLength = v217.cutLengths[v217.currentCutLengthIndex] or 1
	end
	WoodHarvesterCutLengthEvent.sendEvent(p214, p215, p216)
end
function WoodHarvester.dropWoodHarvesterTree(p218, p219)
	if p218.isServer then
		local v220 = p218.spec_woodHarvester
		if v220.attachedSplitShapeJointIndex ~= nil then
			removeJoint(v220.attachedSplitShapeJointIndex)
			v220.attachedSplitShapeJointIndex = nil
		end
		v220.attachedSplitShape = nil
		p218:onDelimbTree(false)
		g_server:broadcastEvent(WoodHarvesterOnDelimbTreeEvent.new(p218, false), nil, nil, p218)
		SpecializationUtil.raiseEvent(p218, "onCutTree", 0, false, false)
		g_server:broadcastEvent(WoodHarvesterOnCutTreeEvent.new(p218, 0), nil, nil, p218)
	end
	WoodHarvesterDropTreeEvent.sendEvent(p218, p219)
end
function WoodHarvester.findSplitShapesInRange(p221, p222, p223)
	local v224 = p221.spec_woodHarvester
	if v224.attachedSplitShape == nil and v224.cutNode ~= nil then
		local v225, v226, v227 = localToWorld(v224.cutNode, p222 or 0, 0, 0)
		local v228, v229, v230 = localDirectionToWorld(v224.cutNode, 1, 0, 0)
		local v231, v232, v233 = localDirectionToWorld(v224.cutNode, 0, 1, 0)
		if v224.curSplitShape == nil and (v224.cutReleasedComponentJoint == nil or v224.cutReleasedComponentJointRotLimitX == 0) then
			local v234, v235, v236, v237, v238 = findSplitShape(v225, v226, v227, v228, v229, v230, v231, v232, v233, v224.cutSizeY, v224.cutSizeZ)
			if v234 ~= 0 then
				if not g_splitShapeManager:getSplitShapeAllowsHarvester(v234) then
					v224.warnInvalidTree = true
					return
				end
				if p221:getCanSplitShapeBeAccessed(v225, v227, v234) then
					local v239, v240, v241 = localDirectionToWorld(v234, 0, 1, 0)
					local v242 = MathUtil.dotProduct(v228, v229, v230, v239, v240, v241)
					local v243 = getRigidBodyType(v234) == RigidBodyType.STATIC and 0.2617 or 0.6981
					local v244 = math.acos(v242) - 1.57079
					local v245 = 1.57079 - math.abs(v244)
					if v245 <= v243 then
						local v246 = v236 - v235
						local v247 = v238 - v237
						if math.max(v246, v247) * 0.5 * v242 > v224.cutMaxRadius then
							v224.warnInvalidTreeRadius = true
							local v248, v249, v250 = localToWorld(v224.cutNode, p222 or 1, 0, 0)
							local v251, v252, v253, v254, v255 = findSplitShape(v248, v249, v250, v228, v229, v230, v231, v232, v233, v224.cutSizeY, v224.cutSizeZ)
							if v251 ~= 0 then
								local v256 = v253 - v252
								local v257 = v255 - v254
								if math.max(v256, v257) * 0.5 * math.cos(v245) <= v224.cutMaxRadius then
									v224.warnInvalidTreeRadius = false
									v224.warnInvalidTreePosition = true
									return
								end
							end
						else
							local v258 = v236 - v235
							local v259 = v238 - v237
							p221:setLastTreeDiameter((math.max(v258, v259)))
							v224.curSplitShape = v234
							if p223 then
								p221:setAnimationTime(v224.cutAnimation.name, 1, true)
								v224.cutTimer = 0
								return
							end
						end
					end
				else
					v224.warnTreeNotOwned = true
				end
			end
		end
	end
end
function WoodHarvester.cutTree(p260, p261, p262)
	local v263 = p260.spec_woodHarvester
	WoodHarvesterCutTreeEvent.sendEvent(p260, p261, p262)
	if p260.isServer then
		if p261 == 0 then
			if v263.attachedSplitShape ~= nil or v263.curSplitShape ~= nil then
				if v263.attachedSplitShape == nil and (v263.curSplitShape ~= nil and getRigidBodyType(v263.curSplitShape) ~= RigidBodyType.STATIC) then
					v263.cutTimer = 0
					if v263.cutAnimation.name ~= nil then
						p260:setAnimationTime(v263.cutAnimation.name, 0, true)
						p260:playAnimation(v263.cutAnimation.name, 999999, p260:getAnimationTime(v263.cutAnimation.name))
					end
				else
					v263.cutTimer = 100
					if v263.cutAnimation.name ~= nil then
						p260:setAnimationTime(v263.cutAnimation.name, 0, true)
						p260:playAnimation(v263.cutAnimation.name, v263.cutAnimation.speedScale, p260:getAnimationTime(v263.cutAnimation.name))
					end
				end
			end
		elseif p261 > 0 and v263.attachedSplitShape ~= nil then
			v263.attachedSplitShapeTargetY = v263.attachedSplitShapeLastCutY + p261 * v263.cutAttachDirection
			p260:onDelimbTree(true)
			if g_server ~= nil then
				g_server:broadcastEvent(WoodHarvesterOnDelimbTreeEvent.new(p260, true), nil, nil, p260)
			end
		end
	end
	v263.automaticCuttingIsDirty = false
end
function WoodHarvester.onCutTree(p264, p265, _, p266)
	local v267 = p264.spec_woodHarvester
	if p265 > 0 then
		if p264.isClient then
			if v267.grabAnimation.name ~= nil then
				local v268 = p265 / v267.treeSizeMeasure.rotMaxRadius
				local v269 = math.min(v268, 1) * v267.treeSizeMeasure.rotMaxAnimTime
				if v267.grabAnimation.speedScale < 0 then
					v269 = 1 - v269
				end
				p264:setAnimationStopTime(v267.grabAnimation.name, v269)
				if p264:getAnimationTime(v267.grabAnimation.name) < v269 then
					p264:playAnimation(v267.grabAnimation.name, v267.grabAnimation.speedScale, p264:getAnimationTime(v267.grabAnimation.name), true)
				else
					p264:playAnimation(v267.grabAnimation.name, -v267.grabAnimation.speedScale, p264:getAnimationTime(v267.grabAnimation.name), true)
				end
			end
			p264:setLastTreeDiameter(2 * p265)
		end
		v267.hasAttachedSplitShape = true
	else
		if v267.grabAnimation.name ~= nil then
			if v267.grabAnimation.speedScale > 0 then
				p264:setAnimationStopTime(v267.grabAnimation.name, 1)
			else
				p264:setAnimationStopTime(v267.grabAnimation.name, 0)
			end
			p264:playAnimation(v267.grabAnimation.name, v267.grabAnimation.speedScale, p264:getAnimationTime(v267.grabAnimation.name), true)
		end
		v267.hasAttachedSplitShape = false
		v267.cutTimer = -1
		if p264.isServer and (v267.headerJointTilt ~= nil and v267.headerJointTilt.lastState ~= nil) then
			p264:setWoodHarvesterTiltState(v267.headerJointTilt.lastState)
			v267.headerJointTilt.lastState = nil
		end
	end
	if p266 and v267.grabAnimation.name ~= nil then
		AnimatedVehicle.updateAnimationByName(p264, v267.grabAnimation.name, 99999999, true)
	end
end
function WoodHarvester.onVehicleSettingChanged(p270, p271, p272)
	if p271 == GameSettings.SETTING.WOOD_HARVESTER_AUTO_CUT then
		p270.spec_woodHarvester.automaticCuttingEnabled = p272
	end
end
function WoodHarvester.onDelimbTree(p273, p274)
	local v275 = p273.spec_woodHarvester
	if p274 then
		v275.isAttachedSplitShapeMoving = true
		return
	else
		v275.isAttachedSplitShapeMoving = false
		if p273.isServer then
			if v275.automaticCuttingEnabled then
				p273:cutTree(0)
			else
				v275.automaticCuttingIsDirty = true
			end
		else
			v275.automaticCuttingIsDirty = not v275.automaticCuttingEnabled
			return
		end
	end
end
function WoodHarvester.woodHarvesterSplitShapeCallback(p276, p277, p278, p279, p280, p281, p282, p283)
	local v284 = p276.spec_woodHarvester
	g_currentMission:addKnownSplitShape(p277)
	g_treePlantManager:addingSplitShape(p277, p276.shapeBeingCut, p276.shapeBeingCutIsTree)
	if v284.attachedSplitShape == nil and (p279 and (not p278 and (v284.cutAttachNode ~= nil and v284.cutAttachReferenceNode ~= nil))) then
		v284.attachedSplitShape = p277
		v284.lastTreeSize = {
			p280,
			p281,
			p282,
			p283
		}
		local v285, v286, v287 = localToWorld(v284.cutNode, 0, (p280 + p281) * 0.5, (p282 + p283) * 0.5)
		local v288 = nil
		local v289 = v284.loadedSplitShapeFromSavegame
		if v289 then
			if v284.lastTreeJointPos ~= nil then
				local v290 = localToWorld
				local v291 = v284.lastTreeJointPos
				v285, v286, v287 = v290(p277, unpack(v291))
				v288 = v284.lastCutAttachDirection
			end
			v284.loadedSplitShapeFromSavegame = false
		end
		v284.lastTreeJointPos = { worldToLocal(p277, v285, v286, v287) }
		local v292, v293, v294 = localToWorld(v284.cutAttachReferenceNode, 0, 0, (p283 - p282) * 0.5)
		local v295, v296, v297 = localDirectionToWorld(p277, 0, 0, 1)
		local _, v298, _ = localDirectionToLocal(p277, v284.cutAttachReferenceNode, 0, 1, 0)
		v284.cutAttachDirection = v288 or (v298 > 0 and 1 or -1)
		v284.lastCutAttachDirection = v284.cutAttachDirection
		local v299, v300, v301 = localDirectionToWorld(v284.cutAttachReferenceNode, 0, v284.cutAttachDirection, 0)
		local v302, v303, v304 = MathUtil.crossProduct(v299, v300, v301, v295, v296, v297)
		local v305, v306, v307 = MathUtil.crossProduct(v302, v303, v304, v299, v300, v301)
		I3DUtil.setWorldDirection(v284.cutAttachHelperNode, v305, v306, v307, v299, v300, v301, 2)
		local v308 = JointConstructor.new()
		v308:setActors(v284.cutAttachNode, p277)
		v308:setJointTransforms(v284.cutAttachHelperNode, p277)
		v308:setJointWorldPositions(v292, v293, v294, v285, v286, v287)
		v308:setRotationLimit(0, 0, 0)
		v308:setRotationLimit(1, 0, 0)
		v308:setRotationLimit(2, 0, 0)
		v308:setEnableCollision(false)
		v284.attachedSplitShapeJointIndex = v308:finalize()
		if v284.cutReleasedComponentJoint ~= nil then
			v284.cutReleasedComponentJointRotLimitX = 2.827433388230814
			if v284.cutReleasedComponentJoint.jointIndex ~= 0 then
				setJointRotationLimit(v284.cutReleasedComponentJoint.jointIndex, 0, true, 0, v284.cutReleasedComponentJointRotLimitX)
			end
		end
		if v284.cutReleasedComponentJoint2 ~= nil then
			v284.cutReleasedComponentJoint2RotLimitX = 2.827433388230814
			if v284.cutReleasedComponentJoint2.jointIndex ~= 0 then
				setJointRotationLimit(v284.cutReleasedComponentJoint2.jointIndex, 0, true, -v284.cutReleasedComponentJoint2RotLimitX, v284.cutReleasedComponentJoint2RotLimitX)
			end
		end
		if v284.headerJointTilt ~= nil and (v284.headerJointTilt.state and v284.headerJointTilt.lastState == nil) then
			v284.headerJointTilt.lastState = v284.headerJointTilt.state
			p276:setWoodHarvesterTiltState(false)
		end
		local v309, v310, v311 = worldToLocal(p277, v285, v286, v287)
		v284.attachedSplitShapeX = v309
		v284.attachedSplitShapeY = v310
		v284.attachedSplitShapeZ = v311
		v284.attachedSplitShapeLastCutY = v284.attachedSplitShapeY
		v284.attachedSplitShapeStartY = v284.attachedSplitShapeY
		v284.attachedSplitShapeTargetY = v284.attachedSplitShapeY
		local v312 = (p281 - p280 + (p283 - p282)) / 4
		SpecializationUtil.raiseEvent(p276, "onCutTree", v312, p276.shapeBeingCutIsNew, v289)
		if g_server ~= nil then
			g_server:broadcastEvent(WoodHarvesterOnCutTreeEvent.new(p276, v312), nil, nil, p276)
		end
	end
end
function WoodHarvester.setLastTreeDiameter(p313, p314)
	p313.spec_woodHarvester.lastDiameter = p314
end
function WoodHarvester.getCanBeSelected(_, _)
	return true
end
function WoodHarvester.getDoConsumePtoPower(p315, p316)
	local v317 = p315.spec_woodHarvester
	return p316(p315) or (v317.isAttachedSplitShapeMoving or p315:getIsAnimationPlaying(v317.cutAnimation.name))
end
function WoodHarvester.getIsFoldAllowed(p318, p319, p320, p321)
	local v322 = p318.spec_woodHarvester
	if v322.hasAttachedSplitShape then
		return false, v322.texts.warningFoldingTreeMounted
	else
		return p319(p318, p320, p321)
	end
end
function WoodHarvester.getSupportsAutoTreeAlignment(_, _)
	return true
end
function WoodHarvester.getIsAutoTreeAlignmentAllowed(p323, p324)
	if p323.spec_woodHarvester.hasAttachedSplitShape then
		return false
	else
		return p324(p323)
	end
end
function WoodHarvester.getAutoAlignHasValidTree(p325, _, p326)
	local v327 = p325.spec_woodHarvester
	return v327.curSplitShape ~= nil, p326 <= v327.cutMaxRadius
end
function WoodHarvester.actionEventCutTree(p328, _, _, _, _)
	local v329 = p328.spec_woodHarvester
	if p328:getIsTurnedOn() then
		if g_time - v329.lastCutEventTime > v329.cutEventCoolDownTime then
			if v329.hasAttachedSplitShape then
				if not v329.isAttachedSplitShapeMoving and p328:getAnimationTime(v329.cutAnimation.name) == 1 then
					if v329.automaticCuttingIsDirty then
						p328:cutTree(0)
						v329.lastCutEventTime = g_time
					else
						p328:cutTree(v329.currentCutLength)
						v329.lastCutEventTime = g_time
					end
				end
			elseif v329.curSplitShape ~= nil and v329.cutTimer == -1 then
				p328:cutTree(0)
				v329.lastCutEventTime = g_time
				return
			end
		end
	else
		g_currentMission:showBlinkingWarning(v329.texts.warningFirstTurnOnTheTool, 2000)
	end
end
function WoodHarvester.actionEventSetCutlength(p330, _, _, p331, _)
	local v332 = p330.spec_woodHarvester
	if not v332.isAttachedSplitShapeMoving then
		local v333 = v332.currentCutLengthIndex + p331
		p330:setWoodHarvesterCutLengthIndex(#v332.cutLengths < v333 and 1 or (v333 < 1 and #v332.cutLengths or v333))
	end
end
function WoodHarvester.actionEventDropTree(p334, _, _, _, _)
	p334:dropWoodHarvesterTree()
end
function WoodHarvester.actionEventTiltHeader(p335, _, _, _, _)
	local v336 = p335.spec_woodHarvester
	if p335:getIsWoodHarvesterTiltStateAllowed(v336.headerJointTilt) and not v336.hasAttachedSplitShape then
		p335:setWoodHarvesterTiltState()
	end
end
function WoodHarvester.loadSpecValueMaxTreeSize(p337, _, _)
	return p337:getValue("vehicle.woodHarvester.cutNode#maxRadius")
end
function WoodHarvester.getSpecValueMaxTreeSize(p338, _, _, _, p339, p340)
	if p338.specs.woodHarvesterMaxTreeSize == nil then
		return nil
	else
		local v341 = p338.specs.woodHarvesterMaxTreeSize * 2 * 100
		local v342 = string.format("%d%s", MathUtil.round(v341), g_i18n:getText("unit_cmShort"))
		if p339 and p340 then
			return v341, v341, v342
		elseif p339 then
			return v341, v342
		else
			return v342
		end
	end
end

RandomlyMovingParts = {}
RandomlyMovingParts.DEFAULT_MAX_UPDATE_DISTANCE = 50
RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY = "vehicle.randomlyMovingParts.randomlyMovingPart(?)"
RandomlyMovingParts.PRESETS = {}
RandomlyMovingParts.PRESETS.SOWINGMACHINE = {}
RandomlyMovingParts.PRESETS.SOWINGMACHINE.noiseFrequency = { 5, 23, 65 }
RandomlyMovingParts.PRESETS.SOWINGMACHINE.noiseAmount = { 0.4, 0.4, 0.2 }
RandomlyMovingParts.PRESETS.SOWINGMACHINE.hasBumps = false
RandomlyMovingParts.PRESETS.CULTIVATOR = {}
RandomlyMovingParts.PRESETS.CULTIVATOR.noiseFrequency = { 5, 23, 65 }
RandomlyMovingParts.PRESETS.CULTIVATOR.noiseAmount = { 0, 0.05, 0.05 }
RandomlyMovingParts.PRESETS.CULTIVATOR.hasBumps = true
RandomlyMovingParts.PRESETS.CULTIVATOR.bumpFrequency = 20
RandomlyMovingParts.PRESETS.CULTIVATOR.bumpDuration = 0.25
function RandomlyMovingParts.prerequisitesPresent(_)
	return true
end
function RandomlyMovingParts.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("RandomlyMovingParts")
	v1:register(XMLValueType.FLOAT, "vehicle.randomlyMovingParts#maxUpdateDistance", RandomlyMovingParts.DEFAULT_MAX_UPDATE_DISTANCE)
	v1:register(XMLValueType.NODE_INDEX, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#node", "Node")
	v1:register(XMLValueType.INT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#refNodeIndex", "Ground reference node index")
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#speedScale", "Speed scale", 1)
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#speedVariance", "Random variance in the speed scale", 0.1)
	v1:register(XMLValueType.TIME, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#fadeTime", "Fade in and fade out time", 1)
	local v2 = {}
	for v3, _ in pairs(RandomlyMovingParts.PRESETS) do
		table.insert(v2, v3)
	end
	v1:register(XMLValueType.STRING, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#preset", "Name of the preset to use for random value behaviour (%s)", "SOWINGMACHINE", nil, v2)
	v1:register(XMLValueType.VECTOR_3, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#noiseFrequency", "The frequency of the different offsets that is applied", "used from preset")
	v1:register(XMLValueType.VECTOR_3, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#noiseAmount", "The max. offset for each frequency", "used from preset")
	v1:register(XMLValueType.BOOL, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#hasBumps", "The max. offset for each frequency", "used from preset")
	v1:register(XMLValueType.TIME, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#bumpFrequency", "Max. time between bumps", "used from preset")
	v1:register(XMLValueType.TIME, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#bumpDuration", "Duration of the bump", "used from preset")
	v1:register(XMLValueType.INT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#rotAxis", "Rotation axis")
	v1:register(XMLValueType.ANGLE, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#rotMax", "Max. delta rotation value in position direction")
	v1:register(XMLValueType.ANGLE, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#rotMin", "Max. delta rotation value in negative direction", "Inverted rotMax value")
	v1:register(XMLValueType.ANGLE, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#rotStart", "Initial rotation value on the defined axis", "Current value from i3d")
	v1:register(XMLValueType.INT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#transAxis", "Translation axis")
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#transMax", "Max. delta translation value in position direction")
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#transMin", "Max. delta translation value in negative direction", "Inverted rotMax value")
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#transStart", "Initial translation value on the defined axis", "Current value from i3d")
	v1:register(XMLValueType.BOOL, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#isSpeedDependent", "Speed will adjust based on vehicle moving speed", true)
	v1:register(XMLValueType.NODE_INDEX, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#node", "Node that receives the same value")
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#scale", "Scale that is applied to the random value (use -1 to invert the value)", 1)
	v1:register(XMLValueType.INT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#rotAxis", "Rotation axis")
	v1:register(XMLValueType.ANGLE, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#rotMax", "Max. delta rotation value in position direction")
	v1:register(XMLValueType.ANGLE, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#rotMin", "Max. delta rotation value in negative direction", "Inverted rotMax value")
	v1:register(XMLValueType.ANGLE, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#rotStart", "Initial rotation value on the defined axis", "Current value from i3d")
	v1:register(XMLValueType.INT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#transAxis", "Translation axis")
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#transMax", "Max. delta translation value in position direction")
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#transMin", "Max. delta translation value in negative direction", "Inverted rotMax value")
	v1:register(XMLValueType.FLOAT, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. ".node(?)#transStart", "Initial translation value on the defined axis", "Current value from i3d")
	v1:setXMLSpecializationType()
end
function RandomlyMovingParts.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "loadRandomlyMovingPartFromXML", RandomlyMovingParts.loadRandomlyMovingPartFromXML)
	SpecializationUtil.registerFunction(p4, "updateRandomlyMovingPart", RandomlyMovingParts.updateRandomlyMovingPart)
	SpecializationUtil.registerFunction(p4, "getIsRandomlyMovingPartActive", RandomlyMovingParts.getIsRandomlyMovingPartActive)
end
function RandomlyMovingParts.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", RandomlyMovingParts)
	SpecializationUtil.registerEventListener(p5, "onUpdate", RandomlyMovingParts)
end
function RandomlyMovingParts.onLoad(p6, _)
	local v7 = p6.spec_randomlyMovingParts
	v7.maxUpdateDistance = p6.xmlFile:getValue("vehicle.randomlyMovingParts#maxUpdateDistance", RandomlyMovingParts.DEFAULT_MAX_UPDATE_DISTANCE)
	v7.nodes = {}
	for _, v8 in p6.xmlFile:iterator("vehicle.randomlyMovingParts.randomlyMovingPart") do
		local v9 = {}
		if p6:loadRandomlyMovingPartFromXML(v9, p6.xmlFile, v8) then
			local v10 = v7.nodes
			table.insert(v10, v9)
		end
	end
	if not p6.isClient or #v7.nodes == 0 then
		SpecializationUtil.removeEventListener(p6, "onUpdate", RandomlyMovingParts)
	end
end
function RandomlyMovingParts.onUpdate(p11, p12, _, _, _)
	local v13 = p11.spec_randomlyMovingParts
	if p11.currentUpdateDistance < v13.maxUpdateDistance and p11:getLastSpeed() > 0.1 then
		for _, v14 in pairs(v13.nodes) do
			p11:updateRandomlyMovingPart(v14, p12)
		end
	end
end
function RandomlyMovingParts.loadRandomlyMovingPartFromXML(p15, p16, p17, p18)
	XMLUtil.checkDeprecatedXMLElements(p17, p18 .. "#index", p18 .. "#node")
	XMLUtil.checkDeprecatedXMLElements(p17, p18 .. "#rotMean")
	XMLUtil.checkDeprecatedXMLElements(p17, p18 .. "#rotVariance")
	XMLUtil.checkDeprecatedXMLElements(p17, p18 .. "#rotTimeMean")
	XMLUtil.checkDeprecatedXMLElements(p17, p18 .. "#rotTimeVariance")
	XMLUtil.checkDeprecatedXMLElements(p17, p18 .. "#pauseMean")
	XMLUtil.checkDeprecatedXMLElements(p17, p18 .. "#pauseVariance")
	local v19 = p17:getValue(p18 .. "#node", nil, p15.components, p15.i3dMappings)
	if v19 == nil then
		Logging.xmlWarning(p17, "Unknown node for randomlyMovingPart in \'%s\'", p18)
		return false
	end
	p16.node = v19
	if p15.getGroundReferenceNodeFromIndex ~= nil then
		local v20 = p17:getValue(p18 .. "#refNodeIndex")
		if v20 ~= nil then
			if v20 == 0 then
				Logging.xmlWarning(p17, "Unknown ground reference node in \'%s\'! Indices start with \'0\'", p18 .. "#refNodeIndex")
			else
				local v21 = p15:getGroundReferenceNodeFromIndex(v20)
				if v21 ~= nil then
					p16.groundReferenceNode = v21
				end
			end
		end
	end
	p16.isSpeedDependent = p17:getValue(p18 .. "#isSpeedDependent", true)
	p16.speedScale = p17:getValue(p18 .. "#speedScale", 1)
	p16.speedVariance = p17:getValue(p18 .. "#speedVariance", 0.1)
	p16.speedScale = p16.speedScale + (math.random() * p16.speedVariance - p16.speedVariance * 0.5)
	p16.fadeTime = 1 / p17:getValue(p18 .. "#fadeTime", 1)
	local v22 = p17:getValue(p18 .. "#preset", "SOWINGMACHINE")
	local v23 = RandomlyMovingParts.PRESETS[v22:upper()] or RandomlyMovingParts.PRESETS.SOWINGMACHINE
	p16.noiseFrequency = p17:getValue(p18 .. "#noiseFrequency", v23.noiseFrequency, true)
	p16.noiseAmount = p17:getValue(p18 .. "#noiseAmount", v23.noiseAmount, true)
	p16.hasBumps = p17:getValue(p18 .. "#hasBumps", v23.hasBumps)
	if p16.hasBumps then
		p16.bumpFrequency = p17:getValue(p18 .. "#bumpFrequency", v23.bumpFrequency or 10)
		p16.bumpNextTime = p16.bumpFrequency * math.random()
		p16.bumpTimer = 0
		p16.bumpDuration = p17:getValue(p18 .. "#bumpDuration", v23.bumpDuration or 0.25)
	end
	p16.rotAxis = p17:getValue(p18 .. "#rotAxis", nil)
	if p16.rotAxis ~= nil then
		p16.rotMax = p17:getValue(p18 .. "#rotMax", 0)
		p16.rotMin = p17:getValue(p18 .. "#rotMin") or -p16.rotMax
		p16.rotation = { getRotation(p16.node) }
		p16.initialRotation = { getRotation(p16.node) }
		p16.rotStart = p17:getValue(p18 .. "#rotStart")
		if p16.rotStart ~= nil then
			p16.rotation[p16.rotAxis] = p16.rotStart
			p16.initialRotation[p16.rotAxis] = p16.rotStart
			setRotation(p16.node, p16.initialRotation[1], p16.initialRotation[2], p16.initialRotation[3])
		end
	end
	p16.transAxis = p17:getValue(p18 .. "#transAxis", nil)
	if p16.transAxis ~= nil then
		p16.transMax = p17:getValue(p18 .. "#transMax", 0)
		p16.transMin = p17:getValue(p18 .. "#transMin") or -p16.transMax
		p16.translation = { getTranslation(p16.node) }
		p16.initialTranslation = { getTranslation(p16.node) }
		p16.transStart = p17:getValue(p18 .. "#transStart")
		if p16.transStart ~= nil then
			p16.translation[p16.transAxis] = p16.transStart
			p16.initialTranslation[p16.transAxis] = p16.transStart
			setTranslation(p16.node, p16.initialTranslation[1], p16.initialTranslation[2], p16.initialTranslation[3])
		end
	end
	if p16.rotAxis == nil and p16.transAxis == nil then
		Logging.xmlWarning(p17, "No rotation or translation axis for randomlyMovingPart in \'%s\'", p18)
		return false
	end
	p16.nodes = {}
	for _, v24 in p17:iterator(p18 .. ".node") do
		local v25 = p17:getValue(v24 .. "#node", nil, p15.components, p15.i3dMappings)
		if v25 ~= nil then
			local v26 = {
				["node"] = v25,
				["deltaScale"] = p17:getValue(v24 .. "#scale", 1),
				["rotAxis"] = p17:getValue(p18 .. "#rotAxis", p16.rotAxis)
			}
			if v26.rotAxis ~= nil then
				v26.rotMax = p17:getValue(p18 .. "#rotMax", p16.rotMax or 0)
				v26.rotMin = p17:getValue(p18 .. "#rotMin") or -v26.rotMax
				v26.rotation = { getRotation(v26.node) }
				v26.initialRotation = { getRotation(v26.node) }
				v26.rotStart = p17:getValue(p18 .. "#rotStart")
				if v26.rotStart ~= nil then
					v26.rotation[v26.rotAxis] = v26.rotStart
					v26.initialRotation[v26.rotAxis] = v26.rotStart
					setRotation(v26.node, v26.initialRotation[1], v26.initialRotation[2], v26.initialRotation[3])
				end
			end
			v26.transAxis = p17:getValue(p18 .. "#transAxis", p16.transAxis)
			if v26.transAxis ~= nil then
				v26.transMax = p17:getValue(p18 .. "#transMax", p16.transMax or 0)
				v26.transMin = p17:getValue(p18 .. "#transMin") or -v26.transMax
				v26.translation = { getTranslation(v26.node) }
				v26.initialTranslation = { getTranslation(v26.node) }
				v26.transStart = p17:getValue(p18 .. "#transStart")
				if v26.transStart ~= nil then
					v26.translation[v26.transAxis] = v26.transStart
					v26.initialTranslation[v26.transAxis] = v26.transStart
					setTranslation(v26.node, v26.initialTranslation[1], v26.initialTranslation[2], v26.initialTranslation[3])
				end
			end
			if p16.rotAxis ~= nil or p16.transAxis ~= nil then
				local v27 = p16.nodes
				table.insert(v27, v26)
			end
		end
	end
	p16.isActive = true
	p16.time = math.random()
	p16.alpha = 0
	return true
end
local function v_u_39(p28, p29, p30, p31)
	if p29.deltaScale ~= nil then
		p30 = p30 * p29.deltaScale
	end
	if p29.rotAxis ~= nil then
		local v32 = p29.rotMin
		local v33 = math.min(p30, 0)
		local v34 = v32 * math.abs(v33)
		local v35 = p29.rotMax
		local v36 = math.max(p30, 0)
		local v37 = v34 + v35 * math.abs(v36)
		p29.rotation[p29.rotAxis] = p29.initialRotation[p29.rotAxis] + v37 * p31
		setRotation(p29.node, p29.rotation[1], p29.rotation[2], p29.rotation[3])
		if p28.setMovingToolDirty ~= nil then
			p28:setMovingToolDirty(p29.node)
		end
	end
	if p29.transAxis ~= nil then
		local v38 = p29.transMin + p30 * (p29.transMax - p29.transMin)
		p29.translation[p29.transAxis] = p29.initialTranslation[p29.transAxis] + v38 * p31
		setTranslation(p29.node, p29.translation[1], p29.translation[2], p29.translation[3])
		if p28.setMovingToolDirty ~= nil then
			p28:setMovingToolDirty(p29.node)
		end
	end
end
function RandomlyMovingParts.updateRandomlyMovingPart(p40, p41, p42)
	-- upvalues: (copy) v_u_39
	local v43
	if p41.isSpeedDependent then
		v43 = p40.lastMovedDistance * p40.movingDirection * 0.2
	else
		v43 = p42 * 0.00033
	end
	p41.isActive = p40:getIsRandomlyMovingPartActive(p41)
	if p41.isActive then
		if p41.alpha < 1 then
			local v44 = p41.alpha + p42 * p41.fadeTime
			p41.alpha = math.min(v44, 1)
		end
		if p41.hasBumps then
			if not p41.isSpeedDependent or p40:getLastSpeed() > 1 then
				p41.bumpNextTime = p41.bumpNextTime - p42
				if p41.bumpNextTime <= 0 then
					p41.bumpTimer = p41.bumpDuration
					p41.bumpNextTime = p41.bumpFrequency * math.random()
				end
			end
			if p41.bumpTimer > 0 then
				p41.bumpTimer = p41.bumpTimer - p42
			end
		end
	elseif p41.alpha > 0 then
		local v45 = p41.alpha - p42 * p41.fadeTime
		p41.alpha = math.max(v45, 0)
	end
	if p41.alpha > 0 then
		p41.time = p41.time + v43 * p41.speedScale
		local v46 = p41.time * p41.noiseFrequency[1]
		local v47 = math.sin(v46) * p41.noiseAmount[1]
		local v48 = p41.time * p41.noiseFrequency[2]
		local v49 = v47 + math.sin(v48) * p41.noiseAmount[2]
		local v50 = p41.time * p41.noiseFrequency[3]
		local v51 = v49 + math.sin(v50) * p41.noiseAmount[3]
		if p41.hasBumps and p41.bumpTimer > 0 then
			local v52 = (1 - p41.bumpTimer / p41.bumpDuration) * 3.141592653589793
			local v53 = v51 + math.sin(v52)
			v51 = math.min(v53, 1)
		end
		v_u_39(p40, p41, v51, p41.alpha)
		for _, v54 in ipairs(p41.nodes) do
			v_u_39(p40, v54, v51, p41.alpha)
		end
	end
end
function RandomlyMovingParts.getIsRandomlyMovingPartActive(p55, p56)
	return p56.groundReferenceNode == nil and true or p55:getIsGroundReferenceNodeActive(p56.groundReferenceNode)
end

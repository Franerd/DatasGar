FruitPreparer = {}
function FruitPreparer.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("fruitPreparer", false, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("FruitPreparer")
	v1:register(XMLValueType.STRING, "vehicle.fruitPreparer#fruitType", "Fruit type")
	v1:register(XMLValueType.BOOL, "vehicle.fruitPreparer#aiUsePreparedState", "AI uses prepared state instead of unprepared state", "true if vehicle has also the Cutter specialization")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. ".fruitPreparer#dropWorkAreaIndex", "Drop area index")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".fruitPreparer#dropWorkAreaIndex", "Drop area index")
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.fruitPreparer.animationNodes")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.fruitPreparer.sounds", "work")
	v1:register(XMLValueType.BOOL, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#moveOnlyIfPreparerCut", "Move only if fruit preparer cuts something", false)
	v1:setXMLSpecializationType()
end
function FruitPreparer.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(WorkArea, p2)
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p2)
	end
	return v3
end
function FruitPreparer.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "processFruitPreparerArea", FruitPreparer.processFruitPreparerArea)
end
function FruitPreparer.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadWorkAreaFromXML", FruitPreparer.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDoGroundManipulation", FruitPreparer.getDoGroundManipulation)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", FruitPreparer.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAllowCutterAIFruitRequirements", FruitPreparer.getAllowCutterAIFruitRequirements)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDirtMultiplier", FruitPreparer.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", FruitPreparer.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadRandomlyMovingPartFromXML", FruitPreparer.loadRandomlyMovingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsRandomlyMovingPartActive", FruitPreparer.getIsRandomlyMovingPartActive)
end
function FruitPreparer.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", FruitPreparer)
	SpecializationUtil.registerEventListener(p6, "onDelete", FruitPreparer)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", FruitPreparer)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", FruitPreparer)
	SpecializationUtil.registerEventListener(p6, "onTurnedOn", FruitPreparer)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", FruitPreparer)
	SpecializationUtil.registerEventListener(p6, "onEndWorkAreaProcessing", FruitPreparer)
	SpecializationUtil.registerEventListener(p6, "onAIFieldCourseSettingsInitialized", FruitPreparer)
end
function FruitPreparer.onLoad(p7, _)
	local v8 = p7.spec_fruitPreparer
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.turnOnAnimation#name", "vehicle.turnOnVehicle.turnedAnimation#name")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.turnOnAnimation#speed", "vehicle.turnOnVehicle.turnedAnimation#turnOnSpeedScale")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.fruitPreparer#useReelStateToTurnOn")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.fruitPreparer#onlyActiveWhenLowered")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.vehicle.fruitPreparerSound", "vehicle.fruitPreparer.sounds.work")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode", "vehicle.fruitPreparer.animationNodes.animationNode", "fruitPreparer")
	if p7.isClient then
		v8.samples = {}
		v8.samples.work = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.fruitPreparer.sounds", "work", p7.baseDirectory, p7.components, 0, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.animationNodes = g_animationManager:loadAnimations(p7.xmlFile, "vehicle.fruitPreparer.animationNodes", p7.components, p7, p7.i3dMappings)
	end
	v8.fruitType = FruitType.UNKNOWN
	local v9 = p7.xmlFile:getValue("vehicle.fruitPreparer#fruitType")
	if v9 == nil then
		Logging.xmlWarning(p7.xmlFile, "Missing fruitType in fruitPreparer")
	else
		local v10 = g_fruitTypeManager:getFruitTypeByName(v9)
		if v10 == nil then
			Logging.xmlWarning(p7.xmlFile, "Unable to find fruitType \'%s\' in fruitPreparer", v9)
		else
			v8.fruitType = v10.index
			if p7.setAIFruitRequirements ~= nil then
				p7:setAIFruitRequirements(v10.index, v10.minPreparingGrowthState, v10.maxPreparingGrowthState)
				if p7.xmlFile:getValue("vehicle.fruitPreparer#aiUsePreparedState", p7.spec_cutter ~= nil) then
					p7:addAIFruitRequirement(v10.index, v10.preparedGrowthState, v10.preparedGrowthState)
				end
			end
		end
	end
	v8.isWorking = false
	v8.lastWorkTime = (-1 / 0)
	v8.dirtyFlag = p7:getNextDirtyFlag()
end
function FruitPreparer.onDelete(p11)
	local v12 = p11.spec_fruitPreparer
	g_soundManager:deleteSamples(v12.samples)
	g_animationManager:deleteAnimations(v12.animationNodes)
end
function FruitPreparer.onReadUpdateStream(p13, p14, _, p15)
	if p15:getIsServer() then
		p13.spec_fruitPreparer.isWorking = streamReadBool(p14)
	end
end
function FruitPreparer.onWriteUpdateStream(p16, p17, p18, _)
	if not p18:getIsServer() then
		local v19 = p16.spec_fruitPreparer
		streamWriteBool(p17, v19.isWorking)
	end
end
function FruitPreparer.onTurnedOn(p20)
	if p20.isClient then
		local v21 = p20.spec_fruitPreparer
		g_soundManager:playSample(v21.samples.work)
		g_animationManager:startAnimations(v21.animationNodes)
	end
end
function FruitPreparer.onTurnedOff(p22)
	if p22.isClient then
		local v23 = p22.spec_fruitPreparer
		g_soundManager:stopSamples(v23.samples)
		g_animationManager:stopAnimations(v23.animationNodes)
	end
end
function FruitPreparer.loadWorkAreaFromXML(p24, p25, p26, p27, p28)
	local v29 = p25(p24, p26, p27, p28)
	if p26.type == WorkAreaType.FRUITPREPARER then
		XMLUtil.checkDeprecatedXMLElements(p24.xmlFile, p28 .. "#dropStartIndex", p28 .. ".fruitPreparer#dropWorkAreaIndex")
		XMLUtil.checkDeprecatedXMLElements(p24.xmlFile, p28 .. "#dropWidthIndex", p28 .. ".fruitPreparer#dropWorkAreaIndex")
		XMLUtil.checkDeprecatedXMLElements(p24.xmlFile, p28 .. "#dropHeightIndex", p28 .. ".fruitPreparer#dropWorkAreaIndex")
		p26.dropWorkAreaIndex = p27:getValue(p28 .. ".fruitPreparer#dropWorkAreaIndex")
	end
	return v29
end
function FruitPreparer.getDoGroundManipulation(p30, p31)
	local v32 = p30.spec_fruitPreparer
	local v33 = p31(p30)
	if v33 then
		v33 = v32.isWorking
	end
	return v33
end
function FruitPreparer.doCheckSpeedLimit(p34, p35)
	local v36 = not p35(p34) and p34:getIsTurnedOn()
	if v36 then
		v36 = p34.getIsImplementChainLowered == nil and true or p34:getIsImplementChainLowered()
	end
	return v36
end
function FruitPreparer.getAllowCutterAIFruitRequirements(_, _)
	return false
end
function FruitPreparer.getDirtMultiplier(p37, p38)
	if p37.spec_fruitPreparer.isWorking then
		return p38(p37) + p37:getWorkDirtMultiplier() * p37:getLastSpeed() / p37.speedLimit
	else
		return p38(p37)
	end
end
function FruitPreparer.getWearMultiplier(p39, p40)
	if p39.spec_fruitPreparer.isWorking then
		return p40(p39) + p39:getWorkWearMultiplier() * p39:getLastSpeed() / p39.speedLimit
	else
		return p40(p39)
	end
end
function FruitPreparer.loadRandomlyMovingPartFromXML(p41, p42, p43, p44, p45)
	local v46 = p42(p41, p43, p44, p45)
	p43.moveOnlyIfPreparerCut = p44:getValue(p45 .. "#moveOnlyIfPreparerCut", false)
	return v46
end
function FruitPreparer.getIsRandomlyMovingPartActive(p47, p48, p49)
	local v50 = p48(p47, p49)
	if p49.moveOnlyIfPreparerCut then
		if v50 then
			v50 = p47.spec_fruitPreparer.isWorking
		end
	end
	return v50
end
function FruitPreparer.getDefaultSpeedLimit()
	return 15
end
function FruitPreparer.onEndWorkAreaProcessing(p51, _)
	if p51.isServer then
		local v52 = p51.spec_fruitPreparer
		local v53 = g_time - v52.lastWorkTime < 500
		if v53 ~= v52.isWorking then
			p51:raiseDirtyFlags(v52.dirtyFlag)
			v52.isWorking = v53
		end
	end
end
function FruitPreparer.onAIFieldCourseSettingsInitialized(_, p54)
	p54.headlandsFirst = true
	p54.workInitialSegment = true
end
function FruitPreparer.processFruitPreparerArea(p55, p56)
	local v57 = p55.spec_fruitPreparer
	local v58 = p55.spec_workArea
	local v59, _, v60 = getWorldTranslation(p56.start)
	local v61, _, v62 = getWorldTranslation(p56.width)
	local v63, _, v64 = getWorldTranslation(p56.height)
	local v65 = true
	local v66, v67, v68, v69, v70, v71
	if p56.dropWorkAreaIndex == nil then
		v66 = v59
		v67 = v64
		v68 = v63
		v69 = v62
		v70 = v61
		v71 = v60
	else
		local v72 = v58.workAreas[p56.dropWorkAreaIndex]
		if v72 == nil then
			v66 = v59
			v67 = v64
			v68 = v63
			v69 = v62
			v70 = v61
			v71 = v60
		else
			local v73
			v66, v73, v71 = getWorldTranslation(v72.start)
			local v74
			v70, v74, v69 = getWorldTranslation(v72.width)
			local v75
			v68, v75, v67 = getWorldTranslation(v72.height)
			v65 = false
		end
	end
	local v76 = FSDensityMapUtil.updateFruitPreparerArea(v57.fruitType, v59, v60, v61, v62, v63, v64, v66, v71, v70, v69, v68, v67, v65)
	if v76 > 0 then
		v57.lastWorkTime = g_time
	end
	return 0, v76
end

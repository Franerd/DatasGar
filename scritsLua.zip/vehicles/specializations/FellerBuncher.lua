FellerBuncher = {}
source("dataS/scripts/vehicles/specializations/events/FellerBuncherCutEvent.lua")
source("dataS/scripts/vehicles/specializations/events/FellerBuncherReleaseEvent.lua")
function FellerBuncher.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(FillUnit, p1)
end
function FellerBuncher.initSpecialization()
	g_storeManager:addSpecType("fellerBuncherMaxTreeSize", "shopListAttributeIconMaxTreeSize", FellerBuncher.loadSpecValueMaxTreeSize, FellerBuncher.getSpecValueMaxTreeSize, StoreSpecies.VEHICLE)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("FellerBuncher")
	v2:register(XMLValueType.INT, "vehicle.fellerBuncher#fillUnitIndex", "Fill unit index")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher#maxRadius", "Max. tree radius that can be cut", 1)
	v2:register(XMLValueType.STRING, "vehicle.fellerBuncher#releaseInputAction", "Name of input action to release the tree(s)", "IMPLEMENT_EXTRA2")
	v2:register(XMLValueType.STRING, "vehicle.fellerBuncher#cutInputAction", "Name of input action to cut the tree (if not defined the trees are automatically cut after cutNode#duration)")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.fellerBuncher.cutNode#node", "Cut node - Used for tree detection and actual cutting")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.cutNode#sizeY", "Cut node size y", 2)
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.cutNode#sizeZ", "Cut node size z", 2)
	v2:register(XMLValueType.TIME, "vehicle.fellerBuncher.cutNode#duration", "Cut duration", 1)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.fellerBuncher.cutNode.cutCollision#node", "Cut collision node - Node is moved during cutting process")
	v2:register(XMLValueType.VECTOR_TRANS, "vehicle.fellerBuncher.cutNode.cutCollision#startTrans", "Start translation")
	v2:register(XMLValueType.VECTOR_TRANS, "vehicle.fellerBuncher.cutNode.cutCollision#endTrans", "end translation")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.fellerBuncher.mountNode#node", "Mount node - Detects trees and mounts them to the parent component")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.mountNode#sizeY", "Mount node size y", 2)
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.mountNode#sizeZ", "Mount node size z", 2)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.fellerBuncher.treeMoveDirectionNode#node", "Provides direction in which the tree is moved while mounting")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.treeMoveDirectionNode#distance", "How far the tree is moved")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.treeMoveDirectionNode#liftDistance", "How far the tree is lifted")
	v2:register(XMLValueType.STRING, "vehicle.fellerBuncher.mainGrab#animationName", "Main grab animation name")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.mainGrab#speedScale", "Main grab animation speed", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.mainGrab#releaseSpeedScale", "Main grab animation release speed", 1)
	v2:register(XMLValueType.VECTOR_N, "vehicle.fellerBuncher.mainGrab#componentJointIndices", "Component joint indices to change the damping rate while main grab is closed")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.mainGrab#dampingFactor", "Damping factor for component joint index", 20)
	v2:register(XMLValueType.STRING, "vehicle.fellerBuncher.cutAnimation#animationName", "Cut animation name")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.cutAnimation#speedScale", "Cut animation speed scale", 1)
	v2:register(XMLValueType.TIME, "vehicle.fellerBuncher.unmount#delay", "Delay between unmounting each tree", 0.4)
	v2:register(XMLValueType.STRING, "vehicle.fellerBuncher.unmount#animationName", "Animation played after the joint releases")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.unmount#speedScale", "Animation speed", 1)
	v2:register(XMLValueType.STRING, "vehicle.fellerBuncher.treeSlot(?).grab#animationName", "Grab animation name")
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.treeSlot(?).grab#speedScale", "Grab animation speed", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.fellerBuncher.treeSlot(?).grab#releaseSpeedScale", "Grab animation release speed", 1)
	SoundManager.registerSampleXMLPaths(v2, "vehicle.fellerBuncher.sounds", "cut")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.fellerBuncher.sounds", "saw")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.fellerBuncher.animationNodes")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.fellerBuncher.effects")
	v2:setXMLSpecializationType()
end
function FellerBuncher.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "setFellerBuncherGrabState", FellerBuncher.setFellerBuncherGrabState)
	SpecializationUtil.registerFunction(p3, "getIsFellerBuncherReadyForCut", FellerBuncher.getIsFellerBuncherReadyForCut)
	SpecializationUtil.registerFunction(p3, "getFellerBuncherCanCutSplitShape", FellerBuncher.getFellerBuncherCanCutSplitShape)
	SpecializationUtil.registerFunction(p3, "cutTree", FellerBuncher.cutTree)
	SpecializationUtil.registerFunction(p3, "fellerBuncherSplitShapeCallback", FellerBuncher.fellerBuncherSplitShapeCallback)
	SpecializationUtil.registerFunction(p3, "doMountProcess", FellerBuncher.doMountProcess)
	SpecializationUtil.registerFunction(p3, "mountTreeInRange", FellerBuncher.mountTreeInRange)
	SpecializationUtil.registerFunction(p3, "releaseMountedTrees", FellerBuncher.releaseMountedTrees)
	SpecializationUtil.registerFunction(p3, "releaseMainArmTree", FellerBuncher.releaseMainArmTree)
	SpecializationUtil.registerFunction(p3, "releaseNextTreeSlot", FellerBuncher.releaseNextTreeSlot)
	SpecializationUtil.registerFunction(p3, "onFellerBuncherTreesChanged", FellerBuncher.onFellerBuncherTreesChanged)
	SpecializationUtil.registerFunction(p3, "getNumLoadedTrees", FellerBuncher.getNumLoadedTrees)
	SpecializationUtil.registerFunction(p3, "onFellerBuncherTreeShapeCut", FellerBuncher.onFellerBuncherTreeShapeCut)
	SpecializationUtil.registerFunction(p3, "onFellerBuncherTreeShapeMounted", FellerBuncher.onFellerBuncherTreeShapeMounted)
end
function FellerBuncher.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanToggleTurnedOn", FellerBuncher.getCanToggleTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p4, "registerLoweringActionEvent", FellerBuncher.registerLoweringActionEvent)
	SpecializationUtil.registerOverwrittenFunction(p4, "getSupportsAutoTreeAlignment", FellerBuncher.getSupportsAutoTreeAlignment)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAutoAlignHasValidTree", FellerBuncher.getAutoAlignHasValidTree)
end
function FellerBuncher.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onDelete", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onReadStream", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onTurnedOn", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onTurnedOff", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onFinishAnimation", FellerBuncher)
	SpecializationUtil.registerEventListener(p5, "onRegisterActionEvents", FellerBuncher)
end
function FellerBuncher.onLoad(p_u_6, _)
	local v_u_7 = p_u_6.spec_fellerBuncher
	v_u_7.fillUnitIndex = p_u_6.xmlFile:getValue("vehicle.fellerBuncher#fillUnitIndex")
	v_u_7.maxRadius = p_u_6.xmlFile:getValue("vehicle.fellerBuncher#maxRadius", 1)
	v_u_7.releaseInputAction = InputAction[p_u_6.xmlFile:getValue("vehicle.fellerBuncher#releaseInputAction", "IMPLEMENT_EXTRA2")] or InputAction.IMPLEMENT_EXTRA2
	local v8 = p_u_6.xmlFile:getValue("vehicle.fellerBuncher#cutInputAction")
	if v8 ~= nil then
		v_u_7.cutInputAction = InputAction[v8]
	end
	v_u_7.cutNode = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutNode#node", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.cutNodeSizeY = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutNode#sizeY", 2)
	v_u_7.cutNodeSizeZ = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutNode#sizeZ", 2)
	v_u_7.cutDuration = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutNode#duration", 1)
	v_u_7.cutTimer = 0
	v_u_7.effectState = false
	v_u_7.lastEffectState = false
	v_u_7.cutCollisionNode = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutNode.cutCollision#node", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.cutCollisionNodeStartTrans = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutNode.cutCollision#startTrans", nil, true)
	v_u_7.cutCollisionNodeEndTrans = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutNode.cutCollision#endTrans", nil, true)
	v_u_7.mountNode = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.mountNode#node", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.mountComponent = p_u_6:getParentComponent(v_u_7.mountNode or p_u_6.rootNode)
	v_u_7.mountNodeSizeY = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.mountNode#sizeY", 2)
	v_u_7.mountNodeSizeZ = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.mountNode#sizeZ", 2)
	v_u_7.treeMoveDirectionNode = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.treeMoveDirectionNode#node", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.treeMoveDirectionDistance = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.treeMoveDirectionNode#distance", 0.05)
	v_u_7.treeMoveDirectionLiftDistance = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.treeMoveDirectionNode#liftDistance", 0.05)
	v_u_7.mainGrab = {}
	v_u_7.mainGrab.animationName = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.mainGrab#animationName")
	v_u_7.mainGrab.speedScale = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.mainGrab#speedScale", 1)
	v_u_7.mainGrab.releaseSpeedScale = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.mainGrab#releaseSpeedScale", 1)
	v_u_7.mainGrab.componentJointIndices = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.mainGrab#componentJointIndices", nil, true)
	v_u_7.mainGrab.dampingFactor = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.mainGrab#dampingFactor", 20)
	v_u_7.mainGrab.jointIndex = 0
	v_u_7.mainGrab.jointNode = nil
	v_u_7.mainGrab.shapeId = nil
	v_u_7.mainGrab.isUsed = false
	v_u_7.cutAnimation = {}
	v_u_7.cutAnimation.animationName = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutAnimation#animationName")
	v_u_7.cutAnimation.speedScale = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.cutAnimation#speedScale", 1)
	v_u_7.foundSplitShape = nil
	v_u_7.foundSplitShapeIsTree = false
	v_u_7.mountProcessInProgress = false
	v_u_7.mountProcessSplitShape = nil
	v_u_7.mountProcessTreeSlot = nil
	v_u_7.unmountProcessInProgress = false
	v_u_7.unmountProcessAnimationPlayed = false
	v_u_7.unmountProcessTimer = 0
	v_u_7.unmountProcessDelay = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.unmount#delay", 0.4)
	v_u_7.unmountProcessAnimation = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.unmount#animationName")
	v_u_7.unmountProcessAnimationSpeedScale = p_u_6.xmlFile:getValue("vehicle.fellerBuncher.unmount#speedScale", 1)
	v_u_7.treeSlots = {}
	p_u_6.xmlFile:iterate("vehicle.fellerBuncher.treeSlot", function(_, p9)
		-- upvalues: (copy) p_u_6, (copy) v_u_7
		local v10 = {
			["animationName"] = p_u_6.xmlFile:getValue(p9 .. ".grab#animationName"),
			["speedScale"] = p_u_6.xmlFile:getValue(p9 .. ".grab#speedScale", 1),
			["releaseSpeedScale"] = p_u_6.xmlFile:getValue(p9 .. ".grab#releaseSpeedScale", 1)
		}
		if v10.animationName ~= nil then
			v10.isUsed = false
			v10.jointIndex = 0
			v10.jointNode = nil
			v10.shapeId = nil
			local v11 = v_u_7.treeSlots
			table.insert(v11, v10)
		end
	end)
	if p_u_6.isClient then
		v_u_7.animationNodes = g_animationManager:loadAnimations(p_u_6.xmlFile, "vehicle.fellerBuncher.animationNodes", p_u_6.components, p_u_6, p_u_6.i3dMappings)
		v_u_7.effects = g_effectManager:loadEffect(p_u_6.xmlFile, "vehicle.fellerBuncher.effects", p_u_6.components, p_u_6, p_u_6.i3dMappings)
		v_u_7.samples = {}
		v_u_7.samples.cut = g_soundManager:loadSampleFromXML(p_u_6.xmlFile, "vehicle.fellerBuncher.sounds", "cut", p_u_6.baseDirectory, p_u_6.components, 0, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
		v_u_7.samples.saw = g_soundManager:loadSampleFromXML(p_u_6.xmlFile, "vehicle.fellerBuncher.sounds", "saw", p_u_6.baseDirectory, p_u_6.components, 0, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
	end
	v_u_7.texts = {}
	v_u_7.texts.actionRelease = g_i18n:getText("action_releaseTrees", p_u_6.customEnvironment)
	v_u_7.texts.actionCutTree = g_i18n:getText("action_woodHarvesterCut", p_u_6.customEnvironment)
	v_u_7.texts.warningNoAccess = g_i18n:getText("warning_youAreNotAllowedToCutThisTree", p_u_6.customEnvironment)
	v_u_7.texts.warningNoPermission = g_i18n:getText("shop_messageNoPermissionGeneral", p_u_6.customEnvironment)
	v_u_7.texts.treeTooThick = g_i18n:getText("warning_treeTooThick", p_u_6.customEnvironment)
	g_messageCenter:subscribe(MessageType.TREE_SHAPE_CUT, p_u_6.onFellerBuncherTreeShapeCut, p_u_6)
	g_messageCenter:subscribe(MessageType.TREE_SHAPE_MOUNTED, p_u_6.onFellerBuncherTreeShapeMounted, p_u_6)
	v_u_7.dirtyFlag = p_u_6:getNextDirtyFlag()
end
function FellerBuncher.onDelete(p12)
	local v13 = p12.spec_fellerBuncher
	if v13.treeSlots ~= nil then
		p12:releaseMainArmTree()
		while p12:releaseNextTreeSlot() do

		end
	end
	g_effectManager:deleteEffects(v13.effects)
	g_soundManager:deleteSamples(v13.samples)
	g_animationManager:deleteAnimations(v13.animationNodes)
end
function FellerBuncher.onReadStream(p14, p15, _)
	local v16 = p14.spec_fellerBuncher
	v16.effectState = streamReadBool(p15)
	v16.mainGrab.isUsed = streamReadBool(p15)
	for v17 = 1, #v16.treeSlots do
		v16.treeSlots[v17].isUsed = streamReadBool(p15)
	end
end
function FellerBuncher.onWriteStream(p18, p19, _)
	local v20 = p18.spec_fellerBuncher
	streamWriteBool(p19, v20.effectState)
	streamWriteBool(p19, v20.mainGrab.isUsed)
	for v21 = 1, #v20.treeSlots do
		streamWriteBool(p19, v20.treeSlots[v21].isUsed)
	end
end
function FellerBuncher.onReadUpdateStream(p22, p23, _, p24)
	if p24:getIsServer() and streamReadBool(p23) then
		local v25 = p22.spec_fellerBuncher
		v25.effectState = streamReadBool(p23)
		v25.mainGrab.isUsed = streamReadBool(p23)
		for v26 = 1, #v25.treeSlots do
			v25.treeSlots[v26].isUsed = streamReadBool(p23)
		end
		FellerBuncher.updateActionEvents(p22)
	end
end
function FellerBuncher.onWriteUpdateStream(p27, p28, p29, p30)
	if not p29:getIsServer() then
		local v31 = p27.spec_fellerBuncher
		if streamWriteBool(p28, bitAND(p30, v31.dirtyFlag) ~= 0) then
			streamWriteBool(p28, v31.effectState)
			streamWriteBool(p28, v31.mainGrab.isUsed)
			for v32 = 1, #v31.treeSlots do
				streamWriteBool(p28, v31.treeSlots[v32].isUsed)
			end
		end
	end
end
function FellerBuncher.onUpdateTick(p33, p34, _, p35, _)
	local v36 = p33.spec_fellerBuncher
	local v37 = v36.foundSplitShape
	v36.foundSplitShape = nil
	if p33.isServer then
		local v38 = false
		if p33:getIsFellerBuncherReadyForCut() then
			if v36.cutNode ~= nil then
				local v39, v40, v41 = getWorldTranslation(v36.cutNode)
				local v42, v43, v44 = localDirectionToWorld(v36.cutNode, 1, 0, 0)
				local v45, v46, v47 = localDirectionToWorld(v36.cutNode, 0, 1, 0)
				local v48, v49, v50, v51, v52 = findSplitShape(v39, v40, v41, v42, v43, v44, v45, v46, v47, v36.cutNodeSizeY, v36.cutNodeSizeZ)
				if v48 ~= 0 then
					local v53, v54 = p33:getFellerBuncherCanCutSplitShape(v48, v39, v40, v41, v42, v43, v44, v45, v46, v47, v49, v50, v51, v52)
					if v53 then
						v36.foundSplitShape = v48
						v36.foundSplitShapeIsTree = getRigidBodyType(v48) == RigidBodyType.STATIC
						if v36.cutInputAction == nil then
							v38 = true
							v36.cutTimer = v36.cutTimer + p34
							if v36.cutTimer > v36.cutDuration then
								p33:cutTree()
								v36.cutTimer = 0
							end
							if v36.cutCollisionNode ~= nil then
								setTranslation(v36.cutCollisionNode, MathUtil.vector3ArrayLerp(v36.cutCollisionNodeStartTrans, v36.cutCollisionNodeEndTrans, v36.cutTimer / v36.cutDuration))
							end
						end
					elseif p35 and v54 ~= nil then
						g_currentMission:showBlinkingWarning(v54, 100)
					end
				end
			end
			if not v38 then
				v36.cutTimer = 0
			end
		elseif v36.mountProcessInProgress then
			if v36.mountProcessSplitShape ~= nil then
				local v55, v56, v57 = localDirectionToWorld(v36.treeMoveDirectionNode, 0, 0, getMass(v36.mountProcessSplitShape) * 10)
				local v58, v59, v60 = worldToLocal(v36.mountProcessSplitShape, localToWorld(v36.treeMoveDirectionNode, 0, 1, 0))
				addForce(v36.mountProcessSplitShape, v55, v56, v57, v58, v59, v60, true)
			end
		elseif v36.unmountProcessInProgress then
			local v61 = v36.unmountProcessTimer - p34
			v36.unmountProcessTimer = math.max(v61, 0)
			if v36.unmountProcessTimer <= 0 then
				if p33:getNumLoadedTrees() > 0 then
					if not p33:releaseNextTreeSlot() then
						v36.unmountProcessInProgress = false
						if not p33:getIsTurnedOn() then
							p33:setFellerBuncherGrabState(false)
						end
					end
					v36.unmountProcessTimer = v36.unmountProcessDelay
				else
					local v62 = p33:getIsAnimationPlaying(v36.mainGrab.animationName)
					for v63 = 1, #v36.treeSlots do
						v62 = v62 or p33:getIsAnimationPlaying(v36.treeSlots[v63].animationName)
					end
					if not (v62 or v36.unmountProcessAnimationPlayed) then
						if v36.unmountProcessAnimation ~= nil and not p33:getIsAnimationPlaying(v36.unmountProcessAnimation) then
							p33:playAnimation(v36.unmountProcessAnimation, v36.unmountProcessAnimationSpeedScale, 0, true)
						end
						v36.unmountProcessAnimationPlayed = true
					end
					local v64 = false
					if not v62 and v36.unmountProcessAnimationPlayed then
						if v36.unmountProcessAnimation == nil then
							v64 = true
						elseif not p33:getIsAnimationPlaying(v36.unmountProcessAnimation) then
							if p33:getAnimationTime(v36.unmountProcessAnimation) > 0.99 then
								p33:playAnimation(v36.unmountProcessAnimation, -v36.unmountProcessAnimationSpeedScale, 1, true)
							else
								v64 = true
							end
						end
					end
					if v64 then
						v36.unmountProcessInProgress = false
						if not p33:getIsTurnedOn() then
							p33:setFellerBuncherGrabState(false)
						end
					end
				end
			end
		else
			v36.cutTimer = 0
		end
		if v36.mainGrab.shapeId == nil or entityExists(v36.mainGrab.shapeId) then
			for v65 = 1, #v36.treeSlots do
				if v36.treeSlots[v65].shapeId ~= nil and not entityExists(v36.treeSlots[v65].shapeId) then
					p33:releaseMountedTrees()
					break
				end
			end
		else
			p33:releaseMountedTrees()
		end
	elseif p35 and v36.cutNode ~= nil then
		local v66, v67, v68 = getWorldTranslation(v36.cutNode)
		local v69, v70, v71 = localDirectionToWorld(v36.cutNode, 1, 0, 0)
		local v72, v73, v74 = localDirectionToWorld(v36.cutNode, 0, 1, 0)
		local v75, v76, v77, v78, v79 = findSplitShape(v66, v67, v68, v69, v70, v71, v72, v73, v74, v36.cutNodeSizeY, v36.cutNodeSizeZ)
		if v75 ~= 0 then
			local v80, v81 = p33:getFellerBuncherCanCutSplitShape(v75, v66, v67, v68, v69, v70, v71, v72, v73, v74, v76, v77, v78, v79)
			if v80 then
				v36.foundSplitShape = v75
			elseif v81 ~= nil then
				g_currentMission:showBlinkingWarning(v81, 100)
			end
		end
	end
	if v37 ~= v36.foundSplitShape then
		FellerBuncher.updateActionEvents(p33)
	end
	if p33.isServer then
		v36.effectState = v36.cutTimer > 0
	end
	if v36.effectState ~= v36.lastEffectState then
		v36.lastEffectState = v36.effectState
		p33:raiseDirtyFlags(v36.dirtyFlag)
		if p33.isClient then
			if v36.effectState then
				g_effectManager:setEffectTypeInfo(v36.effects, FillType.WOODCHIPS)
				g_effectManager:startEffects(v36.effects)
				if not g_soundManager:getIsSamplePlaying(v36.samples.cut) then
					g_soundManager:playSample(v36.samples.cut)
					return
				end
			else
				g_effectManager:stopEffects(v36.effects)
				if g_soundManager:getIsSamplePlaying(v36.samples.cut) then
					g_soundManager:stopSample(v36.samples.cut)
				end
			end
		end
	end
end
function FellerBuncher.onTurnedOn(p82)
	local v83 = p82.spec_fellerBuncher
	if p82:getNumLoadedTrees() == 0 then
		p82:setFellerBuncherGrabState(true)
	end
	if p82.isClient then
		g_animationManager:startAnimations(v83.animationNodes)
		g_soundManager:playSample(v83.samples.saw)
	end
end
function FellerBuncher.onTurnedOff(p84)
	local v85 = p84.spec_fellerBuncher
	if p84:getNumLoadedTrees() == 0 then
		p84:setFellerBuncherGrabState(false)
	end
	if p84.isClient then
		g_animationManager:stopAnimations(v85.animationNodes)
		g_effectManager:stopEffects(v85.effects)
		g_soundManager:stopSamples(v85.samples)
	end
end
function FellerBuncher.onFinishAnimation(p86, p87)
	local v88 = p86.spec_fellerBuncher
	if v88.mountProcessInProgress then
		if p87 == v88.mainGrab.animationName then
			for v89 = 1, #v88.treeSlots do
				local v90 = v88.treeSlots[v89]
				if not v90.isUsed then
					p86:playAnimation(v90.animationName, -v90.speedScale, p86:getAnimationTime(v90.animationName), true)
					v88.mountProcessTreeSlot = v90
					break
				end
			end
			if v88.mountProcessTreeSlot == nil and v88.mainGrab.jointIndex == 0 then
				local v91 = v88.mainGrab
				local v92 = v88.mainGrab
				local v93 = v88.mainGrab
				local v94, v95, v96 = p86:mountTreeInRange()
				v91.jointIndex = v94
				v92.jointNode = v95
				v93.shapeId = v96
				if v88.mainGrab.jointIndex == 0 then
					p86:playAnimation(v88.mainGrab.animationName, v88.mainGrab.speedScale, p86:getAnimationTime(v88.mainGrab.animationName), true)
					p86:playAnimation(v88.cutAnimation.animationName, v88.cutAnimation.speedScale, p86:getAnimationTime(v88.cutAnimation.animationName), true)
				else
					v88.mainGrab.isUsed = true
					p86:onFellerBuncherTreesChanged()
					if p86.isServer and v88.mainGrab.componentJointIndices ~= nil then
						for v97 = 1, #v88.mainGrab.componentJointIndices do
							local v98 = p86.componentJoints[v88.mainGrab.componentJointIndices[v97]]
							if v98 ~= nil then
								for v99 = 1, 3 do
									setJointRotationLimitSpring(v98.jointIndex, v99 - 1, v98.rotLimitSpring[v99], v98.rotLimitDamping[v99] * v88.mainGrab.dampingFactor)
								end
							end
						end
					end
				end
				v88.mountProcessInProgress = false
				v88.mountProcessSplitShape = nil
				return
			end
		elseif v88.mountProcessTreeSlot ~= nil and p87 == v88.mountProcessTreeSlot.animationName then
			p86:playAnimation(v88.mainGrab.animationName, v88.mainGrab.speedScale, p86:getAnimationTime(v88.mainGrab.animationName), true)
			p86:playAnimation(v88.cutAnimation.animationName, v88.cutAnimation.speedScale, p86:getAnimationTime(v88.cutAnimation.animationName), true)
			local v100 = v88.mountProcessTreeSlot
			local v101, v102, v103 = p86:mountTreeInRange()
			v100.jointIndex = v101
			v100.jointNode = v102
			v100.shapeId = v103
			if v100.jointIndex == 0 then
				p86:playAnimation(v100.animationName, v100.speedScale, p86:getAnimationTime(v100.animationName), true)
			else
				v100.isUsed = true
				p86:onFellerBuncherTreesChanged()
			end
			v88.mountProcessInProgress = false
			v88.mountProcessSplitShape = nil
			v88.mountProcessTreeSlot = nil
		end
	end
end
function FellerBuncher.setFellerBuncherGrabState(p104, p105)
	local v106 = p104.spec_fellerBuncher
	if p105 then
		p104:playAnimation(v106.mainGrab.animationName, v106.mainGrab.speedScale, p104:getAnimationTime(v106.mainGrab.animationName), true)
		for v107 = 1, #v106.treeSlots do
			local v108 = v106.treeSlots[v107]
			p104:playAnimation(v108.animationName, v108.speedScale, p104:getAnimationTime(v108.animationName), true)
		end
		p104:playAnimation(v106.cutAnimation.animationName, v106.cutAnimation.speedScale, p104:getAnimationTime(v106.cutAnimation.animationName), true)
	else
		p104:playAnimation(v106.mainGrab.animationName, -v106.mainGrab.speedScale, p104:getAnimationTime(v106.mainGrab.animationName), true)
		for v109 = 1, #v106.treeSlots do
			local v110 = v106.treeSlots[v109]
			p104:playAnimation(v110.animationName, -v110.speedScale, p104:getAnimationTime(v110.animationName), true)
		end
		p104:playAnimation(v106.cutAnimation.animationName, -v106.cutAnimation.speedScale, p104:getAnimationTime(v106.cutAnimation.animationName), true)
	end
end
function FellerBuncher.getIsFellerBuncherReadyForCut(p111)
	local v112 = p111.spec_fellerBuncher
	if v112.mountProcessInProgress then
		return false
	elseif v112.unmountProcessInProgress then
		return false
	elseif p111:getIsAnimationPlaying(v112.mainGrab.animationName) then
		return false
	elseif p111:getIsTurnedOn() then
		return p111:getNumLoadedTrees() < #v112.treeSlots + 1
	else
		return false
	end
end
function FellerBuncher.getFellerBuncherCanCutSplitShape(p113, p114, p115, p116, p117, p118, p119, p120, _, _, _, p121, p122, p123, p124)
	local v125 = p113.spec_fellerBuncher
	if WoodHarvester.getCanSplitShapeBeAccessed(p113, p115, p117, p114) then
		local v126 = p122 - p121
		local v127 = p124 - p123
		if math.max(v126, v127) * 0.5 > v125.maxRadius then
			return false, v125.texts.treeTooThick
		end
		if p114 == v125.mainGrab.shapeId then
			return false
		end
		for v128 = 1, #v125.treeSlots do
			if p114 == v125.treeSlots[v128].shapeId then
				return false
			end
		end
		local v129, v130 = getSplitShapePlaneExtents(p114, p115, p116, p117, p118, p119, p120)
		return v129 ~= nil and (v129 > 0.15 and v130 > 0.15)
	elseif g_currentMission:getHasPlayerPermission("cutTrees", p113:getOwnerConnection()) then
		return false, v125.texts.warningNoAccess
	else
		return false, v125.texts.warningNoPermission
	end
end
function FellerBuncher.cutTree(p131, p132)
	local v133 = p131.spec_fellerBuncher
	if v133.foundSplitShape ~= nil then
		if p131.isServer then
			local v134 = g_currentMission:farmStats(p131:getActiveFarm())
			local v135 = v134:updateStats("cutTreeCount", 1)
			g_achievementManager:tryUnlock("CutTreeFirst", v135)
			g_achievementManager:tryUnlock("CutTree", v135)
			local v136 = g_splitShapeManager:getSplitTypeByIndex(getSplitType(v133.foundSplitShape))
			if v136 ~= nil then
				v134:updateTreeTypesCut(v136.name)
			end
			local v137, v138, v139 = getWorldTranslation(v133.cutNode)
			local v140, v141, v142 = localDirectionToWorld(v133.cutNode, 1, 0, 0)
			local v143, v144, v145 = localDirectionToWorld(v133.cutNode, 0, 1, 0)
			splitShape(v133.foundSplitShape, v137, v138, v139, v140, v141, v142, v143, v144, v145, v133.cutNodeSizeY, v133.cutNodeSizeZ, "fellerBuncherSplitShapeCallback", p131)
		end
		v133.foundSplitShape = nil
	end
	p131:playAnimation(v133.cutAnimation.animationName, -v133.cutAnimation.speedScale, p131:getAnimationTime(v133.cutAnimation.animationName), true)
	if v133.cutInputAction ~= nil and p131.isClient then
		g_soundManager:playSample(v133.samples.cut)
	end
	FellerBuncherCutEvent.sendEvent(p131, p132)
end
function FellerBuncher.fellerBuncherSplitShapeCallback(p146, p147, _, p148, _, _, _, _)
	local v149 = p146.spec_fellerBuncher
	g_currentMission:addKnownSplitShape(p147)
	g_treePlantManager:addingSplitShape(p147, v149.foundSplitShape, v149.foundSplitShapeIsTree)
	if p148 then
		p146:doMountProcess(p147)
	end
end
function FellerBuncher.doMountProcess(p150, p151, _)
	local v152 = p150.spec_fellerBuncher
	p150:playAnimation(v152.mainGrab.animationName, -v152.mainGrab.speedScale, p150:getAnimationTime(v152.mainGrab.animationName), true)
	v152.mountProcessInProgress = true
	v152.mountProcessSplitShape = p151
	local v153, v154, v155 = getTranslation(p151)
	local v156, v157, v158 = localDirectionToWorld(v152.treeMoveDirectionNode, 0, 0, 1)
	setTranslation(p151, v153 + v156 * v152.treeMoveDirectionDistance, v154 + v157 * v152.treeMoveDirectionDistance + v152.treeMoveDirectionLiftDistance, v155 + v158 * v152.treeMoveDirectionDistance)
end
function FellerBuncher.mountTreeInRange(p159)
	local v160 = p159.spec_fellerBuncher
	if v160.mountNode ~= nil then
		local v161, v162, v163 = getWorldTranslation(v160.mountNode)
		local v164, v165, v166 = localDirectionToWorld(v160.mountNode, 1, 0, 0)
		local v167, v168, v169 = localDirectionToWorld(v160.mountNode, 0, 1, 0)
		local v170, v171, v172, v173 = testSplitShape(v160.mountProcessSplitShape, v161, v162, v163, v164, v165, v166, v167, v168, v169, v160.mountNodeSizeY, v160.mountNodeSizeZ)
		if v170 ~= nil then
			local v174 = createTransformGroup("jointNode")
			link(v160.mountNode, v174)
			setTranslation(v174, 0, (v170 + v171) * 0.5, (v172 + v173) * 0.5)
			local v175 = JointConstructor.new()
			v175:setActors(v160.mountComponent, v160.mountProcessSplitShape)
			v175:setJointTransforms(v174, v174)
			v175:setRotationLimit(0, 0, 0)
			v175:setRotationLimit(1, 0, 0)
			v175:setRotationLimit(2, 0, 0)
			v175:setEnableCollision(true)
			v175:setRotationLimitSpring(7500, 1500, 7500, 1500, 7500, 1500)
			v175:setTranslationLimitSpring(7500, 1500, 7500, 1500, 7500, 1500)
			g_messageCenter:publish(MessageType.TREE_SHAPE_MOUNTED, v160.mountProcessSplitShape, p159)
			return v175:finalize(), v174, v160.mountProcessSplitShape
		end
	end
	return 0, nil
end
function FellerBuncher.releaseMountedTrees(p176, p177)
	local v178 = p176.spec_fellerBuncher
	if p176.isServer then
		v178.unmountProcessInProgress = true
		v178.unmountProcessAnimationPlayed = false
		v178.unmountProcessTimer = v178.unmountProcessDelay
		if not p176:releaseMainArmTree() then
			p176:releaseNextTreeSlot()
		end
	end
	FellerBuncherReleaseEvent.sendEvent(p176, p177)
end
function FellerBuncher.releaseMainArmTree(p179)
	local v180 = p179.spec_fellerBuncher
	local v181 = v180.mainGrab.isUsed
	p179:playAnimation(v180.mainGrab.animationName, v180.mainGrab.releaseSpeedScale, p179:getAnimationTime(v180.mainGrab.animationName), true)
	p179:playAnimation(v180.cutAnimation.animationName, v180.cutAnimation.speedScale, p179:getAnimationTime(v180.cutAnimation.animationName), true)
	if v180.mainGrab.jointIndex ~= 0 then
		removeJoint(v180.mainGrab.jointIndex)
		v180.mainGrab.jointIndex = 0
	end
	if v180.mainGrab.jointNode ~= nil then
		delete(v180.mainGrab.jointNode)
		v180.mainGrab.jointNode = nil
	end
	v180.mainGrab.shapeId = nil
	v180.mainGrab.isUsed = false
	if p179.isServer and (p179.isServer and v180.mainGrab.componentJointIndices ~= nil) then
		for v182 = 1, #v180.mainGrab.componentJointIndices do
			local v183 = p179.componentJoints[v180.mainGrab.componentJointIndices[v182]]
			if v183 ~= nil then
				setJointRotationLimitSpring(v183.jointIndex, 0, v183.rotLimitSpring[1], v183.rotLimitDamping[1])
				setJointRotationLimitSpring(v183.jointIndex, 1, v183.rotLimitSpring[2], v183.rotLimitDamping[2])
				setJointRotationLimitSpring(v183.jointIndex, 2, v183.rotLimitSpring[3], v183.rotLimitDamping[3])
			end
		end
	end
	p179:onFellerBuncherTreesChanged()
	return v181
end
function FellerBuncher.releaseNextTreeSlot(p184)
	local v185 = p184.spec_fellerBuncher
	for v186 = 1, #v185.treeSlots do
		local v187 = v185.treeSlots[v186]
		if v187.isUsed then
			p184:playAnimation(v187.animationName, v187.releaseSpeedScale, p184:getAnimationTime(v187.animationName), true)
			if v187.jointIndex ~= 0 then
				removeJoint(v187.jointIndex)
				v187.jointIndex = 0
			end
			if v187.jointNode ~= nil then
				delete(v187.jointNode)
				v187.jointNode = nil
			end
			v187.shapeId = nil
			v187.isUsed = false
			p184:onFellerBuncherTreesChanged()
			return true
		end
	end
	return false
end
function FellerBuncher.onFellerBuncherTreesChanged(p188)
	local v189 = p188.spec_fellerBuncher
	if v189.fillUnitIndex ~= nil then
		p188:addFillUnitFillLevel(p188:getOwnerFarmId(), v189.fillUnitIndex, (-1 / 0), p188:getFillUnitFirstSupportedFillType(v189.fillUnitIndex), ToolType.UNDEFINED, nil)
		p188:addFillUnitFillLevel(p188:getOwnerFarmId(), v189.fillUnitIndex, p188:getNumLoadedTrees(), p188:getFillUnitFirstSupportedFillType(v189.fillUnitIndex), ToolType.UNDEFINED, nil)
	end
	FellerBuncher.updateActionEvents(p188)
	p188:raiseDirtyFlags(v189.dirtyFlag)
end
function FellerBuncher.getNumLoadedTrees(p190)
	local v191 = p190.spec_fellerBuncher
	local v192 = 0
	if v191.mainGrab.isUsed then
		v192 = v192 + 1
	end
	for v193 = 1, #v191.treeSlots do
		if v191.treeSlots[v193].isUsed then
			v192 = v192 + 1
		end
	end
	return v192
end
function FellerBuncher.onFellerBuncherTreeShapeCut(p194, p195, _)
	if p194.isServer then
		local v196 = p194.spec_fellerBuncher
		if p195 == v196.mainGrab.shapeId then
			p194:releaseMountedTrees()
			return
		end
		for v197 = 1, #v196.treeSlots do
			if p195 == v196.treeSlots[v197].shapeId then
				p194:releaseMountedTrees()
				return
			end
		end
	end
end
function FellerBuncher.onFellerBuncherTreeShapeMounted(p198, p199, p200)
	if p200 ~= p198 and p198.isServer then
		local v201 = p198.spec_fellerBuncher
		if p199 == v201.mainGrab.shapeId then
			p198:releaseMountedTrees()
			return
		end
		for v202 = 1, #v201.treeSlots do
			if p199 == v201.treeSlots[v202].shapeId then
				p198:releaseMountedTrees()
				return
			end
		end
	end
end
function FellerBuncher.getCanToggleTurnedOn(p203, p204)
	local v205 = p203.spec_fellerBuncher
	if v205.mountProcessInProgress then
		return false
	elseif p203:getIsAnimationPlaying(v205.mainGrab.animationName) then
		return false
	elseif v205.unmountProcessInProgress then
		return false
	else
		return p204(p203)
	end
end
function FellerBuncher.registerLoweringActionEvent(_, _, _, _, _, _, _, _, _, _, _, _, _) end
function FellerBuncher.getSupportsAutoTreeAlignment(_, _)
	return true
end
function FellerBuncher.getAutoAlignHasValidTree(p206, _, p207)
	local v208 = p206.spec_fellerBuncher
	return v208.foundSplitShape ~= nil, p207 <= v208.maxRadius
end
function FellerBuncher.onRegisterActionEvents(p209, _, p210)
	if p209.isClient then
		local v211 = p209.spec_fellerBuncher
		p209:clearActionEventsTable(v211.actionEvents)
		if p210 then
			local _, v212 = p209:addPoweredActionEvent(v211.actionEvents, v211.releaseInputAction, p209, FellerBuncher.actionEventReleaseTrees, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v212, GS_PRIO_HIGH)
			g_inputBinding:setActionEventText(v212, v211.texts.actionRelease)
			if v211.cutInputAction ~= nil then
				local _, v213 = p209:addPoweredActionEvent(v211.actionEvents, v211.cutInputAction, p209, FellerBuncher.actionEventCutTree, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v213, GS_PRIO_HIGH)
				g_inputBinding:setActionEventText(v213, v211.texts.actionCutTree)
			end
			FellerBuncher.updateActionEvents(p209)
		end
	end
end
function FellerBuncher.actionEventReleaseTrees(p214, _, _, _, _)
	p214:releaseMountedTrees()
end
function FellerBuncher.actionEventCutTree(p215, _, _, _, _)
	p215:cutTree()
end
function FellerBuncher.updateActionEvents(p216)
	if p216.isClient then
		local v217 = p216.spec_fellerBuncher
		local v218 = v217.actionEvents[v217.releaseInputAction]
		if v218 ~= nil then
			local v219 = v217.mainGrab.isUsed
			if not v219 then
				for v220 = 1, #v217.treeSlots do
					if v217.treeSlots[v220].isUsed then
						v219 = true
						break
					end
				end
			end
			g_inputBinding:setActionEventActive(v218.actionEventId, v219)
		end
		local v221 = v217.actionEvents[v217.cutInputAction]
		if v221 ~= nil then
			g_inputBinding:setActionEventActive(v221.actionEventId, v217.foundSplitShape ~= nil)
		end
	end
end
function FellerBuncher.loadSpecValueMaxTreeSize(p222, _, _)
	return p222:getValue("vehicle.fellerBuncher#maxRadius")
end
function FellerBuncher.getSpecValueMaxTreeSize(p223, _, _, _, p224, p225)
	if p223.specs.fellerBuncherMaxTreeSize == nil then
		return
	else
		local v226 = p223.specs.fellerBuncherMaxTreeSize * 2 * 100
		local v227 = string.format("%d%s", MathUtil.round(v226), g_i18n:getText("unit_cmShort"))
		if p224 and p225 then
			return v226, v226, v227
		elseif p224 then
			return v226, v227
		else
			return v227
		end
	end
end

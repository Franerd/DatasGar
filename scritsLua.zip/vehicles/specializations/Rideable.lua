Rideable = {}
source("dataS/scripts/vehicles/specializations/events/JumpEvent.lua")
source("dataS/scripts/vehicles/specializations/events/RideableStableNotificationEvent.lua")
Rideable.GAITTYPES = {
	["MIN"] = 1,
	["BACKWARDS"] = 1,
	["STILL"] = 2,
	["WALK"] = 3,
	["TROT"] = 4,
	["CANTER"] = 5,
	["GALLOP"] = 6,
	["MAX"] = 6
}
Rideable.HOOVES = {
	["FRONT_LEFT"] = 1,
	["FRONT_RIGHT"] = 2,
	["BACK_LEFT"] = 3,
	["BACK_RIGHT"] = 4
}
Rideable.GROUND_RAYCAST_OFFSET = 1.2
Rideable.GROUND_RAYCAST_MAXDISTANCE = 5
Rideable.GROUND_RAYCAST_COLLISIONMASK = CollisionFlag.TERRAIN + CollisionFlag.TERRAIN_DELTA + CollisionFlag.ROAD + CollisionFlag.STATIC_OBJECT
function Rideable.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(CCTDrivable, p1)
end
function Rideable.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Rideable")
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#speedBackwards", "Backward speed", -1)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#speedWalk", "Walk speed", 2.5)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#speedCanter", "Canter speed", 3.5)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#speedTrot", "Trot speed", 5)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#speedGallop", "Gallop speed", 10)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#minTurnRadiusBackwards", "Min turning radius backward", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#minTurnRadiusWalk", "Min turning radius walk", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#minTurnRadiusCanter", "Min turning radius canter", 2.5)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#minTurnRadiusTrot", "Min turning radius trot", 5)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#minTurnRadiusGallop", "Min turning radius gallop", 10)
	v2:register(XMLValueType.ANGLE, "vehicle.rideable#turnSpeed", "Turn speed (deg/s)", 45)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable#jumpHeight", "Jump height", 2)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable#proxy", "Proxy node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofFrontLeft#node", "Hoof node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofFrontLeft.particleSystemSlow#node", "Slow step particle emitterShape")
	v2:register(XMLValueType.STRING, "vehicle.rideable.modelInfo.hoofFrontLeft.particleSystemSlow#particleType", "Slow step particle type")
	ParticleUtil.registerParticleCopyXMLPaths(v2, "vehicle.rideable.modelInfo.hoofFrontLeft.particleSystemSlow")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofFrontLeft.particleSystemFast#node", "Fast step particle emitterShape")
	v2:register(XMLValueType.STRING, "vehicle.rideable.modelInfo.hoofFrontLeft.particleSystemFast#particleType", "Fast step particle type")
	ParticleUtil.registerParticleCopyXMLPaths(v2, "vehicle.rideable.modelInfo.hoofFrontLeft.particleSystemFast")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofFrontRight#node", "Hoof node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofFrontRight.particleSystemSlow#node", "Slow step particle emitterShape")
	v2:register(XMLValueType.STRING, "vehicle.rideable.modelInfo.hoofFrontRight.particleSystemSlow#particleType", "Slow step particle type")
	ParticleUtil.registerParticleCopyXMLPaths(v2, "vehicle.rideable.modelInfo.hoofFrontRight.particleSystemSlow")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofFrontRight.particleSystemFast#node", "Fast step particle emitterShape")
	v2:register(XMLValueType.STRING, "vehicle.rideable.modelInfo.hoofFrontRight.particleSystemFast#particleType", "Fast step particle type")
	ParticleUtil.registerParticleCopyXMLPaths(v2, "vehicle.rideable.modelInfo.hoofFrontRight.particleSystemFast")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofBackLeft#node", "Hoof node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofBackLeft.particleSystemSlow#node", "Slow step particle emitterShape")
	v2:register(XMLValueType.STRING, "vehicle.rideable.modelInfo.hoofBackLeft.particleSystemSlow#particleType", "Slow step particle type")
	ParticleUtil.registerParticleCopyXMLPaths(v2, "vehicle.rideable.modelInfo.hoofBackLeft.particleSystemSlow")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofBackLeft.particleSystemFast#node", "Fast step particle emitterShape")
	v2:register(XMLValueType.STRING, "vehicle.rideable.modelInfo.hoofBackLeft.particleSystemFast#particleType", "Fast step particle type")
	ParticleUtil.registerParticleCopyXMLPaths(v2, "vehicle.rideable.modelInfo.hoofBackLeft.particleSystemFast")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofBackRight#node", "Hoof node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofBackRight.particleSystemSlow#node", "Slow step particle emitterShape")
	v2:register(XMLValueType.STRING, "vehicle.rideable.modelInfo.hoofBackRight.particleSystemSlow#particleType", "Slow step particle type")
	ParticleUtil.registerParticleCopyXMLPaths(v2, "vehicle.rideable.modelInfo.hoofBackRight.particleSystemSlow")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo.hoofBackRight.particleSystemFast#node", "Fast step particle emitterShape")
	v2:register(XMLValueType.STRING, "vehicle.rideable.modelInfo.hoofBackRight.particleSystemFast#particleType", "Fast step particle type")
	ParticleUtil.registerParticleCopyXMLPaths(v2, "vehicle.rideable.modelInfo.hoofBackRight.particleSystemFast")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo#animationNode", "Animation node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo#meshNode", "Mesh node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo#equipmentNode", "Equipment node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo#reinsNode", "Reins node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo#reinLeftNode", "Rein left node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.rideable.modelInfo#reinRightNode", "Rein right node")
	v2:register(XMLValueType.FLOAT, "vehicle.rideable.sounds#breathIntervalNoEffort", "Breath interval no effort", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable.sounds#breathIntervalEffort", "Breath interval effort", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable.sounds#minBreathIntervalIdle", "Min. breath interval idle", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.rideable.sounds#maxBreathIntervalIdle", "Max. breath interval idle", 1)
	SoundManager.registerSampleXMLPaths(v2, "vehicle.rideable.sounds", "halt")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.rideable.sounds", "breathingNoEffort")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.rideable.sounds", "breathingEffort")
	ConditionalAnimation.registerXMLPaths(v2, "vehicle.conditionalAnimation")
	ConditionalAnimation.registerXMLPaths(v2, "vehicle.riderConditionalAnimation")
	v2:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.STRING, "vehicles.vehicle(?).rideable#animalType", "Animal type name")
end
function Rideable.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getIsRideableJumpAllowed", Rideable.getIsRideableJumpAllowed)
	SpecializationUtil.registerFunction(p3, "jump", Rideable.jump)
	SpecializationUtil.registerFunction(p3, "setCurrentGait", Rideable.setCurrentGait)
	SpecializationUtil.registerFunction(p3, "getCurrentGait", Rideable.getCurrentGait)
	SpecializationUtil.registerFunction(p3, "setRideableSteer", Rideable.setRideableSteer)
	SpecializationUtil.registerFunction(p3, "resetInputs", Rideable.resetInputs)
	SpecializationUtil.registerFunction(p3, "updateKinematic", Rideable.updateKinematic)
	SpecializationUtil.registerFunction(p3, "testCCTMove", Rideable.testCCTMove)
	SpecializationUtil.registerFunction(p3, "updateAnimation", Rideable.updateAnimation)
	SpecializationUtil.registerFunction(p3, "updateSound", Rideable.updateSound)
	SpecializationUtil.registerFunction(p3, "updateRiding", Rideable.updateRiding)
	SpecializationUtil.registerFunction(p3, "updateDirt", Rideable.updateDirt)
	SpecializationUtil.registerFunction(p3, "calculateLegsDistance", Rideable.calculateLegsDistance)
	SpecializationUtil.registerFunction(p3, "setWorldPositionQuat", Rideable.setWorldPositionQuat)
	SpecializationUtil.registerFunction(p3, "updateFootsteps", Rideable.updateFootsteps)
	SpecializationUtil.registerFunction(p3, "getPosition", Rideable.getPosition)
	SpecializationUtil.registerFunction(p3, "getRotation", Rideable.getRotation)
	SpecializationUtil.registerFunction(p3, "setEquipmentVisibility", Rideable.setEquipmentVisibility)
	SpecializationUtil.registerFunction(p3, "getHoofSurfaceSound", Rideable.getHoofSurfaceSound)
	SpecializationUtil.registerFunction(p3, "groundRaycastCallback", Rideable.groundRaycastCallback)
	SpecializationUtil.registerFunction(p3, "unlinkReins", Rideable.unlinkReins)
	SpecializationUtil.registerFunction(p3, "updateInputText", Rideable.updateInputText)
	SpecializationUtil.registerFunction(p3, "setPlayerToEnter", Rideable.setPlayerToEnter)
	SpecializationUtil.registerFunction(p3, "endFade", Rideable.endFade)
	SpecializationUtil.registerFunction(p3, "setCluster", Rideable.setCluster)
	SpecializationUtil.registerFunction(p3, "getCluster", Rideable.getCluster)
end
function Rideable.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", Rideable)
	SpecializationUtil.registerEventListener(p4, "onLoadFinished", Rideable)
	SpecializationUtil.registerEventListener(p4, "onDelete", Rideable)
	SpecializationUtil.registerEventListener(p4, "onReadStream", Rideable)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", Rideable)
	SpecializationUtil.registerEventListener(p4, "onReadUpdateStream", Rideable)
	SpecializationUtil.registerEventListener(p4, "onWriteUpdateStream", Rideable)
	SpecializationUtil.registerEventListener(p4, "onReadPositionUpdateStream", Rideable)
	SpecializationUtil.registerEventListener(p4, "onWritePositionUpdateStream", Rideable)
	SpecializationUtil.registerEventListener(p4, "onUpdate", Rideable)
	SpecializationUtil.registerEventListener(p4, "onUpdateInterpolation", Rideable)
	SpecializationUtil.registerEventListener(p4, "onDraw", Rideable)
	SpecializationUtil.registerEventListener(p4, "onRegisterActionEvents", Rideable)
	SpecializationUtil.registerEventListener(p4, "onEnterVehicle", Rideable)
	SpecializationUtil.registerEventListener(p4, "onLeaveVehicle", Rideable)
	SpecializationUtil.registerEventListener(p4, "onSetBroken", Rideable)
	SpecializationUtil.registerEventListener(p4, "onVehicleCharacterChanged", Rideable)
end
function Rideable.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "setWorldPosition", Rideable.setWorldPosition)
	SpecializationUtil.registerOverwrittenFunction(p5, "setWorldPositionQuaternion", Rideable.setWorldPositionQuaternion)
	SpecializationUtil.registerOverwrittenFunction(p5, "updateVehicleSpeed", Rideable.updateVehicleSpeed)
	SpecializationUtil.registerOverwrittenFunction(p5, "getName", Rideable.getName)
	SpecializationUtil.registerOverwrittenFunction(p5, "getFullName", Rideable.getFullName)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanBeReset", Rideable.getCanBeReset)
	SpecializationUtil.registerOverwrittenFunction(p5, "getMapHotspotRotation", Rideable.getMapHotspotRotation)
	SpecializationUtil.registerOverwrittenFunction(p5, "getShowInVehiclesOverview", Rideable.getShowInVehiclesOverview)
	SpecializationUtil.registerOverwrittenFunction(p5, "periodChanged", Rideable.periodChanged)
	SpecializationUtil.registerOverwrittenFunction(p5, "dayChanged", Rideable.dayChanged)
	SpecializationUtil.registerOverwrittenFunction(p5, "getImageFilename", Rideable.getImageFilename)
	SpecializationUtil.registerOverwrittenFunction(p5, "showInfo", Rideable.showInfo)
	SpecializationUtil.registerOverwrittenFunction(p5, "deleteVehicleCharacter", Rideable.deleteVehicleCharacter)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanBeSold", Rideable.getCanBeSold)
end
function Rideable.onLoad(p_u_6, p7)
	local v8 = p_u_6.spec_rideable
	p_u_6.highPrecisionPositionSynchronization = true
	v8.leaveTimer = 15000
	v8.currentDirtScale = 0
	v8.abandonTimerDuration = g_gameSettings:getValue(GameSettings.SETTING.HORSE_ABANDON_TIMER_DURATION)
	v8.abandonTimer = v8.abandonTimerDuration
	v8.fadeDuration = 400
	v8.isRideableRemoved = false
	v8.justSpawned = true
	v8.meshNode = nil
	v8.animationNode = nil
	v8.charsetId = nil
	v8.animationPlayer = nil
	v8.animationParameters = {}
	v8.animationParameters.forwardVelocity = {
		["id"] = 1,
		["value"] = 0,
		["type"] = 1
	}
	v8.animationParameters.verticalVelocity = {
		["id"] = 2,
		["value"] = 0,
		["type"] = 1
	}
	v8.animationParameters.yawVelocity = {
		["id"] = 3,
		["value"] = 0,
		["type"] = 1
	}
	v8.animationParameters.absForwardVelocity = {
		["id"] = 4,
		["value"] = 0,
		["type"] = 1
	}
	v8.animationParameters.onGround = {
		["id"] = 5,
		["value"] = false,
		["type"] = 0
	}
	v8.animationParameters.inWater = {
		["id"] = 6,
		["value"] = false,
		["type"] = 0
	}
	v8.animationParameters.closeToGround = {
		["id"] = 7,
		["value"] = false,
		["type"] = 0
	}
	v8.animationParameters.leftRightWeight = {
		["id"] = 8,
		["value"] = 0,
		["type"] = 1
	}
	v8.animationParameters.absYawVelocity = {
		["id"] = 9,
		["value"] = 0,
		["type"] = 1
	}
	v8.animationParameters.halted = {
		["id"] = 10,
		["value"] = false,
		["type"] = 0
	}
	v8.animationParameters.smoothedForwardVelocity = {
		["id"] = 11,
		["value"] = 0,
		["type"] = 1
	}
	v8.animationParameters.absSmoothedForwardVelocity = {
		["id"] = 12,
		["value"] = 0,
		["type"] = 1
	}
	v8.acceletateEventId = ""
	v8.brakeEventId = ""
	v8.steerEventId = ""
	v8.jumpEventId = ""
	v8.currentTurnAngle = 0
	v8.currentTurnSpeed = 0
	v8.currentSpeed = 0
	v8.currentSpeedY = 0
	v8.cctMoveQueue = {}
	v8.currentCCTPosX = 0
	v8.currentCCTPosY = 0
	v8.currentCCTPosZ = 0
	v8.lastCCTPosX = 0
	v8.lastCCTPosY = 0
	v8.lastCCTPosZ = 0
	v8.topSpeeds = {}
	v8.topSpeeds[Rideable.GAITTYPES.BACKWARDS] = p_u_6.xmlFile:getValue("vehicle.rideable#speedBackwards", -1)
	v8.topSpeeds[Rideable.GAITTYPES.STILL] = 0
	v8.topSpeeds[Rideable.GAITTYPES.WALK] = p_u_6.xmlFile:getValue("vehicle.rideable#speedWalk", 2.5)
	v8.topSpeeds[Rideable.GAITTYPES.CANTER] = p_u_6.xmlFile:getValue("vehicle.rideable#speedCanter", 3.5)
	v8.topSpeeds[Rideable.GAITTYPES.TROT] = p_u_6.xmlFile:getValue("vehicle.rideable#speedTrot", 5)
	v8.topSpeeds[Rideable.GAITTYPES.GALLOP] = p_u_6.xmlFile:getValue("vehicle.rideable#speedGallop", 10)
	v8.minTurnRadius = {}
	v8.minTurnRadius[Rideable.GAITTYPES.BACKWARDS] = p_u_6.xmlFile:getValue("vehicle.rideable#minTurnRadiusBackwards", 1)
	v8.minTurnRadius[Rideable.GAITTYPES.STILL] = 1
	v8.minTurnRadius[Rideable.GAITTYPES.WALK] = p_u_6.xmlFile:getValue("vehicle.rideable#minTurnRadiusWalk", 1)
	v8.minTurnRadius[Rideable.GAITTYPES.CANTER] = p_u_6.xmlFile:getValue("vehicle.rideable#minTurnRadiusCanter", 2.5)
	v8.minTurnRadius[Rideable.GAITTYPES.TROT] = p_u_6.xmlFile:getValue("vehicle.rideable#minTurnRadiusTrot", 5)
	v8.minTurnRadius[Rideable.GAITTYPES.GALLOP] = p_u_6.xmlFile:getValue("vehicle.rideable#minTurnRadiusGallop", 10)
	v8.groundRaycastResult = {}
	v8.groundRaycastResult.y = 0
	v8.groundRaycastResult.object = nil
	v8.groundRaycastResult.distance = 0
	v8.haltTimer = 0
	v8.smoothedLeftRightWeight = 0
	v8.interpolationDt = 16
	v8.ridingTimer = 0
	v8.doHusbandryCheck = 0
	v8.proxy = p_u_6.xmlFile:getValue("vehicle.rideable#proxy", nil, p_u_6.components, p_u_6.i3dMappings)
	if v8.proxy ~= nil then
		setRigidBodyType(v8.proxy, RigidBodyType.NONE)
	end
	v8.collisionMask = getCollisionFilterMask(p_u_6.components[1].node)
	v8.maxAcceleration = 5
	v8.maxDeceleration = 10
	v8.gravity = -9.81
	v8.frontCheckDistance = 0
	v8.backCheckDistance = 0
	v8.isOnGround = true
	v8.isCloseToGround = true
	local v9 = v8.topSpeeds[Rideable.GAITTYPES.MIN] < v8.topSpeeds[Rideable.GAITTYPES.MAX]
	assert(v9)
	v8.maxTurnSpeed = p_u_6.xmlFile:getValue("vehicle.rideable#turnSpeed", 45)
	v8.jumpHeight = p_u_6.xmlFile:getValue("vehicle.rideable#jumpHeight", 2)
	local function v20(p10, p11, p12)
		-- upvalues: (copy) p_u_6
		local v13 = {
			["node"] = p_u_6.xmlFile:getValue(p12 .. "#node", nil, p_u_6.components, p_u_6.i3dMappings),
			["onGround"] = false
		}
		local v14 = p_u_6.xmlFile:getValue(p12 .. ".particleSystemSlow#node", nil, p_u_6.components, p_u_6.i3dMappings)
		local v15 = p_u_6.xmlFile:getValue(p12 .. ".particleSystemSlow#particleType")
		if v15 == nil then
			Logging.xmlWarning(p_u_6.xmlFile, "Missing horse step slow particleType in \'%s\'", p12 .. ".particleSystemSlow")
			return
		else
			local v16 = g_particleSystemManager:getParticleSystem(v15)
			if v16 ~= nil then
				v13.psSlow = ParticleUtil.copyParticleSystem(p_u_6.xmlFile, p12 .. ".particleSystemSlow", v16, v14)
				link(getRootNode(), v13.psSlow.emitterShape)
			end
			local v17 = p_u_6.xmlFile:getValue(p12 .. ".particleSystemFast#node", nil, p_u_6.components, p_u_6.i3dMappings)
			local v18 = p_u_6.xmlFile:getValue(p12 .. ".particleSystemFast#particleType")
			if v18 == nil then
				Logging.xmlWarning(p_u_6.xmlFile, "Missing horse step fast particleType in \'%s\'", p12 .. ".particleSystemFast")
			else
				local v19 = g_particleSystemManager:getParticleSystem(v18)
				if v19 ~= nil then
					v13.psFast = ParticleUtil.copyParticleSystem(p_u_6.xmlFile, p12 .. ".particleSystemFast", v19, v17)
					link(getRootNode(), v13.psFast.emitterShape)
				end
				p10[p11] = v13
			end
		end
	end
	v8.hooves = {}
	v20(v8.hooves, Rideable.HOOVES.FRONT_LEFT, "vehicle.rideable.modelInfo.hoofFrontLeft")
	v20(v8.hooves, Rideable.HOOVES.FRONT_RIGHT, "vehicle.rideable.modelInfo.hoofFrontRight")
	v20(v8.hooves, Rideable.HOOVES.BACK_LEFT, "vehicle.rideable.modelInfo.hoofBackLeft")
	v20(v8.hooves, Rideable.HOOVES.BACK_RIGHT, "vehicle.rideable.modelInfo.hoofBackRight")
	v8.frontCheckDistance = p_u_6:calculateLegsDistance(v8.hooves[Rideable.HOOVES.FRONT_LEFT].node, v8.hooves[Rideable.HOOVES.FRONT_RIGHT].node)
	v8.backCheckDistance = p_u_6:calculateLegsDistance(v8.hooves[Rideable.HOOVES.BACK_LEFT].node, v8.hooves[Rideable.HOOVES.BACK_RIGHT].node)
	v8.animationNode = p_u_6.xmlFile:getValue("vehicle.rideable.modelInfo#animationNode", nil, p_u_6.components, p_u_6.i3dMappings)
	v8.meshNode = p_u_6.xmlFile:getValue("vehicle.rideable.modelInfo#meshNode", nil, p_u_6.components, p_u_6.i3dMappings)
	v8.equipmentNode = p_u_6.xmlFile:getValue("vehicle.rideable.modelInfo#equipmentNode", nil, p_u_6.components, p_u_6.i3dMappings)
	v8.reinsNode = p_u_6.xmlFile:getValue("vehicle.rideable.modelInfo#reinsNode", nil, p_u_6.components, p_u_6.i3dMappings)
	v8.leftReinNode = p_u_6.xmlFile:getValue("vehicle.rideable.modelInfo#reinLeftNode", nil, p_u_6.components, p_u_6.i3dMappings)
	v8.rightReinNode = p_u_6.xmlFile:getValue("vehicle.rideable.modelInfo#reinRightNode", nil, p_u_6.components, p_u_6.i3dMappings)
	v8.leftReinParentNode = getParent(v8.leftReinNode)
	v8.rightReinParentNode = getParent(v8.rightReinNode)
	if v8.animationNode ~= nil then
		v8.charsetId = getAnimCharacterSet(v8.animationNode)
		local v21 = createConditionalAnimation()
		if v21 ~= 0 then
			v8.animationPlayer = v21
			for v22, v23 in pairs(v8.animationParameters) do
				conditionalAnimationRegisterParameter(v8.animationPlayer, v23.id, v23.type, v22)
			end
			initConditionalAnimation(v8.animationPlayer, v8.charsetId, p_u_6.configFileName, "vehicle.conditionalAnimation")
			setConditionalAnimationSpecificParameterIds(v8.animationPlayer, v8.animationParameters.absForwardVelocity.id, v8.animationParameters.absYawVelocity.id)
		end
	end
	v8.surfaceSounds = {}
	v8.surfaceIdToSound = {}
	v8.surfaceNameToSound = {}
	v8.currentSurfaceSound = nil
	local v24 = g_currentMission
	for _, v25 in pairs(v24.surfaceSounds) do
		if v25.type == "hoofstep" and v25.sample ~= nil then
			local v26 = g_soundManager:cloneSample(v25.sample, p_u_6.components[1].node, p_u_6)
			v26.sampleName = v25.name
			local v27 = v8.surfaceSounds
			table.insert(v27, v26)
			v8.surfaceIdToSound[v25.materialId] = v26
			v8.surfaceNameToSound[v25.name] = v26
		end
	end
	v8.horseStopSound = g_soundManager:loadSampleFromXML(p_u_6.xmlFile, "vehicle.rideable.sounds", "halt", p_u_6.baseDirectory, p_u_6.components, 1, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
	v8.horseBreathSoundsNoEffort = g_soundManager:loadSampleFromXML(p_u_6.xmlFile, "vehicle.rideable.sounds", "breathingNoEffort", p_u_6.baseDirectory, p_u_6.components, 1, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
	v8.horseBreathSoundsEffort = g_soundManager:loadSampleFromXML(p_u_6.xmlFile, "vehicle.rideable.sounds", "breathingEffort", p_u_6.baseDirectory, p_u_6.components, 1, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
	v8.horseBreathIntervalNoEffort = p_u_6.xmlFile:getValue("vehicle.rideable.sounds#breathIntervalNoEffort", 1) * 1000
	v8.horseBreathIntervalEffort = p_u_6.xmlFile:getValue("vehicle.rideable.sounds#breathIntervalEffort", 1) * 1000
	v8.horseBreathMinIntervalIdle = p_u_6.xmlFile:getValue("vehicle.rideable.sounds#minBreathIntervalIdle", 1) * 1000
	v8.horseBreathMaxIntervalIdle = p_u_6.xmlFile:getValue("vehicle.rideable.sounds#maxBreathIntervalIdle", 1) * 1000
	v8.currentBreathTimer = 0
	v8.inputValues = {}
	v8.inputValues.axisSteer = 0
	v8.inputValues.axisSteerSend = 0
	v8.inputValues.currentGait = Rideable.GAITTYPES.STILL
	p_u_6:resetInputs()
	v8.interpolatorIsOnGround = InterpolatorValue.new(0)
	if p_u_6.isServer then
		v8.interpolatorTurnAngle = InterpolatorAngle.new(0)
		p_u_6.networkTimeInterpolator.maxInterpolationAlpha = 1.2
	end
	v8.dirtyFlag = p_u_6:getNextDirtyFlag()
	if p7 ~= nil then
		local v28 = p7.xmlFile
		local v29 = p7.key .. ".rideable"
		local v30 = v28:getString(v29 .. "#subType", "HORSE_GRAY")
		local v31 = v24.animalSystem:getSubTypeByName(v30)
		if v31 == nil then
			Logging.xmlError(p_u_6.xmlFile, "Animal sub type \'%s\' not found for \'%s\'!", v30, v29)
			p_u_6:setLoadingState(VehicleLoadingState.ERROR)
			return
		end
		local v32 = v24.animalSystem:createClusterFromSubTypeIndex(v31.subTypeIndex)
		v32:loadFromXMLFile(v28, v29 .. ".animal")
		p_u_6:setCluster(v32)
	end
	v24.husbandrySystem:addRideable(p_u_6)
	p_u_6.needWaterInfo = true
end
function Rideable.onLoadFinished(p33)
	p33:raiseActive()
end
function Rideable.setWorldPosition(p34, p35, p36, p37, p38, p39, p40, p41, p42, p43)
	p35(p34, p36, p37, p38, p39, p40, p41, p42, p43)
	if p34.isServer and p42 == 1 then
		local v44 = p34.spec_rideable
		local v45, _, v46 = localDirectionToWorld(p34.rootNode, 0, 0, 1)
		v44.currentTurnAngle = MathUtil.getYRotationFromDirection(v45, v46)
		if p43 then
			v44.interpolatorTurnAngle:setAngle(v44.currentTurnAngle)
		end
	end
end
function Rideable.setWorldPositionQuaternion(p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57)
	p48(p47, p49, p50, p51, p52, p53, p54, p55, p56, p57)
	if p47.isServer and p56 == 1 then
		local v58 = p47.spec_rideable
		local v59, _, v60 = localDirectionToWorld(p47.rootNode, 0, 0, 1)
		v58.currentTurnAngle = MathUtil.getYRotationFromDirection(v59, v60)
		if p57 then
			v58.interpolatorTurnAngle:setAngle(v58.currentTurnAngle)
		end
	end
end
function Rideable.updateVehicleSpeed(p61, p62, p63)
	if p61.isServer then
		p62(p61, p61.spec_rideable.interpolationDt)
	else
		p62(p61, p63)
	end
end
function Rideable.calculateLegsDistance(p64, p65, p66)
	local v67
	if p65 == nil or p66 == nil then
		v67 = 0
	else
		local _, _, v68 = localToLocal(p65, p64.rootNode, 0, 0, 0)
		local _, _, v69 = localToLocal(p66, p64.rootNode, 0, 0, 0)
		v67 = (v68 + v69) * 0.5
	end
	return v67
end
function Rideable.onDelete(p70)
	local v71 = p70.spec_rideable
	g_currentMission.husbandrySystem:removeRideable(p70)
	g_soundManager:deleteSamples(v71.surfaceSounds)
	g_soundManager:deleteSample(v71.horseStopSound)
	g_soundManager:deleteSample(v71.horseBreathSoundsNoEffort)
	g_soundManager:deleteSample(v71.horseBreathSoundsEffort)
	if v71.hooves ~= nil then
		for _, v72 in pairs(v71.hooves) do
			if v72.psSlow ~= nil then
				ParticleUtil.deleteParticleSystem(v72.psSlow)
				delete(v72.psSlow.emitterShape)
			end
			if v72.psFast ~= nil then
				ParticleUtil.deleteParticleSystem(v72.psFast)
				delete(v72.psFast.emitterShape)
			end
		end
	end
	if v71.animationPlayer ~= nil then
		delete(v71.animationPlayer)
		v71.animationPlayer = nil
	end
end
function Rideable.onReadStream(p73, p74, p75)
	local v76 = p73.spec_rideable
	if p75:getIsServer() then
		if streamReadBool(p74) then
			v76.interpolatorIsOnGround:setValue(1)
		else
			v76.interpolatorIsOnGround:setValue(0)
		end
	end
	if streamReadBool(p74) then
		local v77 = streamReadUIntN(p74, AnimalCluster.NUM_BITS_SUB_TYPE)
		local v78 = g_currentMission.animalSystem:createClusterFromSubTypeIndex(v77)
		v78:readStream(p74, p75)
		p73:setCluster(v78)
	end
	if streamReadBool(p74) then
		p73:setPlayerToEnter((NetworkUtil.readNodeObject(p74)))
	end
end
function Rideable.onWriteStream(p79, p80, p81)
	local v82 = p79.spec_rideable
	if not p81:getIsServer() then
		streamWriteBool(p80, v82.isOnGround)
	end
	if streamWriteBool(p80, v82.cluster ~= nil) then
		streamWriteUIntN(p80, v82.cluster:getSubTypeIndex(), AnimalCluster.NUM_BITS_SUB_TYPE)
		v82.cluster:writeStream(p80, p81)
	end
	if streamWriteBool(p80, v82.playerToEnter ~= nil) then
		NetworkUtil.writeNodeObject(p80, v82.playerToEnter)
	end
end
function Rideable.onReadUpdateStream(p83, p84, _, p85)
	local v86 = p83.spec_rideable
	if p85:getIsServer() then
		v86.haltTimer = streamReadFloat32(p84)
		if v86.haltTimer > 0 then
			v86.inputValues.currentGait = Rideable.GAITTYPES.STILL
			v86.inputValues.axisSteerSend = 0
		end
		if streamReadBool(p84) then
			v86.cluster:readUpdateStream(p84, p85)
			p83:updateDirt()
		end
	else
		v86.inputValues.axisSteer = streamReadFloat32(p84)
		v86.inputValues.currentGait = streamReadUInt8(p84)
	end
end
function Rideable.onWriteUpdateStream(p87, p88, p89, _)
	local v90 = p87.spec_rideable
	if p89:getIsServer() then
		streamWriteFloat32(p88, v90.inputValues.axisSteerSend)
		streamWriteUInt8(p88, v90.inputValues.currentGait)
	else
		streamWriteFloat32(p88, v90.haltTimer)
		if streamWriteBool(p88, v90.cluster ~= nil) then
			v90.cluster:writeUpdateStream(p88, p89)
		end
	end
end
function Rideable.onReadPositionUpdateStream(p91, p92, _)
	local v93 = p91.spec_rideable
	if streamReadBool(p92) then
		v93.interpolatorIsOnGround:setValue(1)
	else
		v93.interpolatorIsOnGround:setValue(0)
	end
end
function Rideable.onWritePositionUpdateStream(p94, p95, _, _)
	local v96 = p94.spec_rideable
	streamWriteBool(p95, v96.isOnGround)
end
function Rideable.endFade(_) end
function Rideable.saveToXMLFile(p97, p98, p99, p100)
	local v101 = p97.spec_rideable
	if v101.cluster ~= nil then
		local v102 = g_currentMission.animalSystem:getSubTypeByIndex((v101.cluster:getSubTypeIndex()))
		p98:setString(p99 .. "#subType", v102.name)
		v101.cluster:saveToXMLFile(p98, p99 .. ".animal", p100)
	end
end
function Rideable.setCluster(p103, p104)
	local v105 = p103.spec_rideable
	v105.cluster = p104
	if p104 ~= nil then
		local v106 = g_currentMission.animalSystem:getVisualByAge(p104:getSubTypeIndex(), p104:getAge()).visualAnimal.variations[1]
		local v107 = v106.tileUIndex / v106.numTilesU
		local v108 = v106.tileVIndex / v106.numTilesV
		I3DUtil.setShaderParameterRec(v105.meshNode, "atlasInvSizeAndOffsetUV", nil, nil, v107, v108)
		p103:updateDirt()
	end
end
function Rideable.updateDirt(p109)
	local v110 = p109.spec_rideable
	local v111 = v110.cluster
	local v112 = (not Platform.gameplay.needHorseCleaning or (v111 == nil or v111.getDirtFactor == nil)) and 0 or v111:getDirtFactor()
	I3DUtil.setShaderParameterRec(v110.meshNode, "dirt", v112, nil, nil, nil)
end
function Rideable.getCluster(p113)
	return p113.spec_rideable.cluster
end
function Rideable.onUpdate(p114, p115, _, p116, _)
	local v117 = p114.spec_rideable
	if p114:getIsSynchronized() and (v117.playerToEnter ~= nil and (v117.checkPlayerToEnter and v117.playerToEnter == g_localPlayer)) then
		g_localPlayer:requestToEnterVehicle(p114, true)
		v117.checkPlayerToEnter = false
	end
	if p114:getIsEntered() then
		if p116 then
			p114:updateInputText()
		end
		if not p114.isServer then
			v117.inputValues.axisSteerSend = v117.inputValues.axisSteer
			p114:raiseDirtyFlags(v117.dirtyFlag)
			p114:resetInputs()
		end
	end
	p114:updateAnimation(p115)
	if p114.isClient then
		p114:updateSound(p115)
	end
	if p114.isServer then
		p114:updateRiding(p115)
	end
	if v117.haltTimer > 0 then
		p114:setCurrentGait(Rideable.GAITTYPES.STILL)
		v117.haltTimer = v117.haltTimer - p115
	end
	if p114:getIsActiveForInput(true) and (g_inputBinding:getInputHelpMode() ~= GS_INPUT_HELP_MODE_GAMEPAD or GS_PLATFORM_SWITCH) and g_gameSettings:getValue(GameSettings.SETTING.GYROSCOPE_STEERING) then
		local v118, v119, v120 = getGravityDirection()
		p114:setRideableSteer((MathUtil.getSteeringAngleFromDeviceGravity(v118, v119, v120)))
	end
	if p114.isServer and v117.doHusbandryCheck > 0 then
		v117.doHusbandryCheck = v117.doHusbandryCheck - p115
		local v121, v122 = g_currentMission.husbandrySystem:getHusbandryInRideableRange(p114)
		if v121 then
			local v123
			if v122 == nil then
				v123 = false
			else
				v122:addCluster((p114:getCluster()))
				p114:delete()
				v123 = true
			end
			if v117.lastOwner ~= nil then
				v117.lastOwner:sendEvent(RideableStableNotificationEvent.new(v123, v117.cluster:getName()), nil, true)
			end
		end
		v117.lastOwner = nil
	end
end
function Rideable.onUpdateInterpolation(p124, p125, _, _, _)
	local v126 = p124.spec_rideable
	if p124.isServer then
		if not p124:getIsControlled() then
			p124:setCurrentGait(Rideable.GAITTYPES.STILL)
		end
		local v127 = v126.cctMoveQueue[1]
		local v128
		if v127 == nil or not getIsPhysicsUpdateIndexSimulated(v127.physicsIndex) then
			v128 = p125
		else
			v128 = v127.dt
		end
		v126.interpolationDt = v128
		p124:testCCTMove(v128)
		p124:updateKinematic(p125)
		if p124:getIsEntered() then
			p124:resetInputs()
		end
		local v129 = p124.components[1]
		local v130, v131, v132 = p124:getCCTWorldTranslation()
		v129.networkInterpolators.position:setTargetPosition(v130, v131, v132)
		v126.interpolatorTurnAngle:setTargetAngle(v126.currentTurnAngle)
		v126.interpolatorIsOnGround:setTargetValue(p124:getIsCCTOnGround() and 1 or 0)
		local v133 = v128 + 30
		p124.networkTimeInterpolator:startNewPhase(v133)
		p124.networkTimeInterpolator:update(v128)
		local v134, v135, v136 = v129.networkInterpolators.position:getInterpolatedValues(p124.networkTimeInterpolator.interpolationAlpha)
		setTranslation(p124.rootNode, v134, v135, v136)
		local v137 = v126.interpolatorTurnAngle:getInterpolatedValue(p124.networkTimeInterpolator.interpolationAlpha)
		local _, v138, _ = localDirectionToWorld(p124.rootNode, 0, 0, 1)
		local v139 = math.sin(v137)
		local v140 = math.cos(v137)
		local v141 = v138 * v138
		local v142 = 1 - math.min(v141, 0.9)
		local v143 = math.sqrt(v142)
		local v144 = v139 * v143
		local v145 = v140 * v143
		setDirection(p124.rootNode, v144, v138, v145, 0, 1, 0)
	end
	if not p124:getIsEntered() and v126.leaveTimer > 0 then
		v126.leaveTimer = v126.leaveTimer - p125
		p124:raiseActive()
	end
	v126.isOnGround = v126.interpolatorIsOnGround:getInterpolatedValue(p124.networkTimeInterpolator:getAlpha()) > 0.9
	v126.isCloseToGround = false
	if v126.isOnGround then
		local v146 = v126.currentSpeed
		if math.abs(v146) > 0.001 then
			::l22::
			local v147, v148, v149 = getWorldTranslation(p124.rootNode)
			local v150, v151, v152 = localDirectionToWorld(p124.rootNode, 0, 0, 1)
			local v153 = v147 + v150 * v126.frontCheckDistance
			local v154 = v148 + v151 * v126.frontCheckDistance
			local v155 = v149 + v152 * v126.frontCheckDistance
			v126.groundRaycastResult.y = v154 + Rideable.GROUND_RAYCAST_OFFSET - Rideable.GROUND_RAYCAST_MAXDISTANCE
			raycastClosest(v153, v154 + Rideable.GROUND_RAYCAST_OFFSET, v155, 0, -1, 0, Rideable.GROUND_RAYCAST_MAXDISTANCE, "groundRaycastCallback", p124, Rideable.GROUND_RAYCAST_COLLISIONMASK)
			local v156 = v126.groundRaycastResult.y
			local v157 = v147 + v150 * v126.backCheckDistance
			local v158 = v148 + v151 * v126.backCheckDistance
			local v159 = v149 + v152 * v126.backCheckDistance
			v126.groundRaycastResult.y = v158 + Rideable.GROUND_RAYCAST_OFFSET - Rideable.GROUND_RAYCAST_MAXDISTANCE
			raycastClosest(v157, v158 + Rideable.GROUND_RAYCAST_OFFSET, v159, 0, -1, 0, Rideable.GROUND_RAYCAST_MAXDISTANCE, "groundRaycastCallback", p124, Rideable.GROUND_RAYCAST_COLLISIONMASK)
			local v160 = v126.groundRaycastResult.y
			local v161 = v153 - v157
			local v162 = v156 - v160
			local v163 = v155 - v159
			setDirection(p124.rootNode, v161, v162, v163, 0, 1, 0)
			return
		end
		local v164 = v126.currentTurnSpeed
		if math.abs(v164) > 0.001 then
			goto l22
		end
	end
	local v165, v166, v167 = getWorldTranslation(p124.rootNode)
	v126.groundRaycastResult.distance = Rideable.GROUND_RAYCAST_MAXDISTANCE
	raycastClosest(v165, v166, v167, 0, -1, 0, Rideable.GROUND_RAYCAST_MAXDISTANCE, "groundRaycastCallback", p124, Rideable.GROUND_RAYCAST_COLLISIONMASK)
	v126.isCloseToGround = v126.groundRaycastResult.distance < 1.25
end
function Rideable.onDraw(p168, _, p169, _)
	local v170 = p168.spec_rideable
	if p169 and v170.cluster ~= nil then
		g_currentMission:addExtraPrintText(string.format("%s: %d %%", g_i18n:getText("infohud_riding"), v170.cluster:getRidingFactor() * 100))
	end
end
function Rideable.onSetBroken(p171)
	p171:unlinkReins()
	if p171.isServer then
		local v172 = g_currentMission.husbandrySystem:getFirstAvailableHusbandry(p171)
		local v173 = p171.spec_rideable
		local v174
		if v172 == nil then
			v174 = false
		else
			v172:addCluster((p171:getCluster()))
			p171:delete()
			v174 = true
		end
		if v173.lastOwner ~= nil then
			v173.lastOwner:sendEvent(RideableStableNotificationEvent.new(v174, v173.cluster:getName()), nil, true)
		end
	end
end
function Rideable.testCCTMove(p175, p176)
	local v177 = p175.spec_rideable
	local v178 = v177.currentCCTPosX
	local v179 = v177.currentCCTPosY
	local v180 = v177.currentCCTPosZ
	v177.lastCCTPosX = v178
	v177.lastCCTPosY = v179
	v177.lastCCTPosZ = v180
	local v181, v182, v183 = getWorldTranslation(p175.spec_cctdrivable.cctNode)
	v177.currentCCTPosX = v181
	v177.currentCCTPosY = v182
	v177.currentCCTPosZ = v183
	local v184 = 0
	local v185 = 0
	while v177.cctMoveQueue[1] ~= nil and getIsPhysicsUpdateIndexSimulated(v177.cctMoveQueue[1].physicsIndex) do
		v184 = v184 + v177.cctMoveQueue[1].moveX
		v185 = v185 + v177.cctMoveQueue[1].moveZ
		table.remove(v177.cctMoveQueue, 1)
	end
	local v186 = v184 * v184 + v185 * v185
	local v187 = math.sqrt(v186)
	if 0.001 * p176 < v187 then
		local v188 = v177.currentCCTPosX - v177.lastCCTPosX
		local v189 = v177.currentCCTPosZ - v177.lastCCTPosZ
		local v190 = v188 * v188 + v189 * v189
		if math.sqrt(v190) <= v187 * 0.7 and v177.haltTimer <= 0 then
			p175:setCurrentGait(Rideable.GAITTYPES.STILL)
			v177.haltTimer = 900
			if v177.horseStopSound ~= nil then
				g_soundManager:playSample(v177.horseStopSound)
			end
		end
	end
end
function Rideable.getIsRideableJumpAllowed(p191, p192)
	local v193 = p191.spec_rideable
	if v193.isOnGround or p192 then
		if v193.inputValues.currentGait < Rideable.GAITTYPES.CANTER then
			return false
		else
			return not p191.isBroken
		end
	else
		return false
	end
end
function Rideable.jump(p194)
	local v195 = p194.spec_rideable
	if p194.isServer then
		local v196, _ = g_farmManager:updateFarmStats(p194:getOwnerFarmId(), "horseJumpCount", 1)
		if v196 ~= nil then
			g_achievementManager:tryUnlock("HorseJumpsFirst", v196)
			g_achievementManager:tryUnlock("HorseJumps", v196)
		end
	else
		g_client:getServerConnection():sendEvent(JumpEvent.new(p194))
	end
	local v197 = v195.jumpHeight
	if v195.inputValues.currentGait == Rideable.GAITTYPES.CANTER then
		v197 = v197 * 0.5
	end
	local v198 = v195.gravity
	local v199 = 2 * math.abs(v198) * v197
	v195.currentSpeedY = math.sqrt(v199)
end
function Rideable.setCurrentGait(p200, p201)
	p200.spec_rideable.inputValues.currentGait = p201
end
function Rideable.getCurrentGait(p202)
	return p202.spec_rideable.inputValues.currentGait
end
function Rideable.setRideableSteer(p203, p204)
	local v205 = p203.spec_rideable
	if p204 ~= 0 then
		v205.inputValues.axisSteer = -p204
	end
end
function Rideable.resetInputs(p206)
	p206.spec_rideable.inputValues.axisSteer = 0
end
function Rideable.updateKinematic(p207, p208)
	local v209 = p207.spec_rideable
	local v210 = p208 * 0.001
	local v211 = v209.topSpeeds[v209.inputValues.currentGait]
	local v212 = v209.maxAcceleration
	if v211 == 0 then
		v212 = v209.maxDeceleration
	end
	local v213 = v212 * v210
	if not v209.isOnGround then
		v213 = v213 * 0.2
	end
	local v214 = v211 - v209.currentSpeed
	local v215 = -v213
	local v216 = math.clamp(v214, v215, v213)
	if v209.haltTimer <= 0 then
		v209.currentSpeed = v209.currentSpeed + v216
	else
		v209.currentSpeed = 0
	end
	local v217 = v209.currentSpeed * v210
	if v209.isOnGround and v209.currentSpeedY < 0 then
		v209.currentSpeedY = 0
	end
	local v218 = v209.gravity * v210
	v209.currentSpeedY = v209.currentSpeedY + v218
	local v219 = v209.currentSpeedY * v210
	local v220 = v209.topSpeeds[Rideable.GAITTYPES.WALK]
	local v221 = v209.topSpeeds[Rideable.GAITTYPES.MAX]
	local v222 = (v221 - v209.currentSpeed) / (v221 - v220)
	local v223 = (math.clamp(v222, 0, 1) * 0.4 + 0.8) * v210
	if not v209.isOnGround then
		v223 = v223 * 0.25
	end
	if p207.isServer and (not p207:getIsEntered() and (not p207:getIsControlled() and v209.inputValues.axisSteer ~= 0)) then
		v209.inputValues.axisSteer = 0
	end
	local v224 = v209.maxTurnSpeed * v209.inputValues.axisSteer - v209.currentTurnSpeed
	local v225 = -v223
	local v226 = math.clamp(v224, v225, v223)
	v209.currentTurnSpeed = v209.currentTurnSpeed + v226
	v209.currentTurnAngle = v209.currentTurnAngle + v209.currentTurnSpeed * v210 * (v217 >= 0 and 1 or -1)
	local v227 = v209.currentTurnAngle
	local v228 = math.sin(v227) * v217
	local v229 = v209.currentTurnAngle
	local v230 = math.cos(v229) * v217
	p207:moveCCT(v228, v219, v230, true)
	local v231 = v209.cctMoveQueue
	local v232 = {
		["physicsIndex"] = getPhysicsUpdateIndex(),
		["moveX"] = v228,
		["moveY"] = v219,
		["moveZ"] = v230,
		["dt"] = p208
	}
	table.insert(v231, v232)
end
function Rideable.groundRaycastCallback(p233, p234, _, p235, _, p236)
	local v237 = p233.spec_rideable
	if p234 == p233.spec_cctdrivable.cctNode then
		return true
	end
	v237.groundRaycastResult.y = p235
	v237.groundRaycastResult.object = p234
	v237.groundRaycastResult.distance = p236
	return false
end
function Rideable.updateAnimation(p238, p239)
	local v240 = p238.spec_rideable
	local v241 = v240.animationParameters
	local v242 = p238.lastSignedSpeedReal * 1000
	local v243 = p238.lastSignedSpeed * 1000
	local v244 = v240.topSpeeds[Rideable.GAITTYPES.BACKWARDS]
	local v245 = v240.topSpeeds[Rideable.GAITTYPES.MAX]
	local v246 = math.clamp(v242, v244, v245)
	local v247 = v240.topSpeeds[Rideable.GAITTYPES.BACKWARDS]
	local v248 = v240.topSpeeds[Rideable.GAITTYPES.MAX]
	local v249 = math.clamp(v243, v247, v248)
	local v250
	if p238.isServer then
		v250 = (v240.interpolatorTurnAngle.targetValue - v240.interpolatorTurnAngle.lastValue) / (p238.networkTimeInterpolator.interpolationDuration * 0.001)
	else
		local v251 = p238.components[1].networkInterpolators.quaternion
		local v252, _, v253 = mathQuaternionRotateVector(v251.lastQuaternionX, v251.lastQuaternionY, v251.lastQuaternionZ, v251.lastQuaternionW, 0, 0, 1)
		local v254, _, v255 = mathQuaternionRotateVector(v251.targetQuaternionX, v251.targetQuaternionY, v251.targetQuaternionZ, v251.targetQuaternionW, 0, 0, 1)
		local v256 = MathUtil.getYRotationFromDirection(v252, v253)
		local v257 = MathUtil.getYRotationFromDirection(v254, v255) - v256
		if v257 > 3.141592653589793 then
			v257 = v257 - 6.283185307179586
		elseif v257 < -3.141592653589793 then
			v257 = v257 + 6.283185307179586
		end
		v250 = v257 / (p238.networkTimeInterpolator.interpolationDuration * 0.001)
	end
	local v258 = p238.components[1].networkInterpolators.position
	local v259 = (v258.targetPositionY - v258.lastPositionY) / (p238.networkTimeInterpolator.interpolationDuration * 0.001)
	local v260
	if math.abs(v246) > 0.01 then
		local v261 = Rideable.GAITTYPES.STILL
		local v262 = (1 / 0)
		for v263 = 1, Rideable.GAITTYPES.MAX do
			local v264 = v246 - v240.topSpeeds[v263]
			local v265 = math.abs(v264)
			if v265 < v262 then
				v261 = v263
				v262 = v265
			end
		end
		v260 = v240.minTurnRadius[v261] * v250 / v246
	else
		v260 = v250 / v240.maxTurnSpeed
	end
	if v260 < v240.smoothedLeftRightWeight then
		local v266 = v240.smoothedLeftRightWeight - 0.002 * p239
		v240.smoothedLeftRightWeight = math.max(v260, v266, -1)
	else
		local v267 = v240.smoothedLeftRightWeight + 0.002 * p239
		v240.smoothedLeftRightWeight = math.min(v260, v267, 1)
	end
	v241.forwardVelocity.value = v246
	v241.absForwardVelocity.value = math.abs(v246)
	v241.verticalVelocity.value = v259
	v241.yawVelocity.value = v250
	v241.absYawVelocity.value = math.abs(v250)
	v241.leftRightWeight.value = v240.smoothedLeftRightWeight
	v241.onGround.value = v240.isOnGround
	v241.closeToGround.value = v240.isCloseToGround
	v241.inWater.value = p238.isInWater
	v241.halted.value = v240.haltTimer > 0
	v241.smoothedForwardVelocity.value = v249
	v241.absSmoothedForwardVelocity.value = math.abs(v249)
	if v240.animationPlayer ~= nil then
		for _, v268 in pairs(v241) do
			if v268.type == 0 then
				setConditionalAnimationBoolValue(v240.animationPlayer, v268.id, v268.value)
			elseif v268.type == 1 then
				setConditionalAnimationFloatValue(v240.animationPlayer, v268.id, v268.value)
			end
		end
		updateConditionalAnimation(v240.animationPlayer, p239)
	end
	local v269
	if p238.getIsEntered == nil then
		v269 = false
	else
		v269 = p238:getIsEntered()
	end
	local v270
	if p238.getIsControlled == nil then
		v270 = false
	else
		v270 = p238:getIsControlled()
	end
	if v269 or v270 then
		local v271 = p238:getVehicleCharacter()
		if v271 ~= nil and (v271.animationCharsetId ~= nil and v271.animationPlayer ~= nil) then
			for _, v272 in pairs(v241) do
				if v272.type == 0 then
					setConditionalAnimationBoolValue(v271.animationPlayer, v272.id, v272.value)
				elseif v272.type == 1 then
					setConditionalAnimationFloatValue(v271.animationPlayer, v272.id, v272.value)
				end
			end
			updateConditionalAnimation(v271.animationPlayer, p239)
		end
	end
	p238:updateFootsteps(p239, (math.abs(v246)))
end
function Rideable.updateSound(p273, p274)
	local v275 = p273.spec_rideable
	if v275.horseBreathSoundsEffort ~= nil and (v275.horseBreathSoundsNoEffort ~= nil and v275.isOnGround) then
		v275.currentBreathTimer = v275.currentBreathTimer - p274
		local v276 = v275.currentBreathTimer
		v275.currentBreathTimer = math.max(v276, 0)
		if v275.currentBreathTimer == 0 then
			if v275.inputValues.currentGait == Rideable.GAITTYPES.GALLOP then
				g_soundManager:playSample(v275.horseBreathSoundsEffort)
				v275.currentBreathTimer = v275.horseBreathIntervalEffort
				return
			end
			g_soundManager:playSample(v275.horseBreathSoundsNoEffort)
			if v275.inputValues.currentGait == Rideable.GAITTYPES.STILL then
				v275.currentBreathTimer = v275.horseBreathMinIntervalIdle + math.random() * (v275.horseBreathMaxIntervalIdle - v275.horseBreathMinIntervalIdle)
				return
			end
			v275.currentBreathTimer = v275.horseBreathIntervalNoEffort
		end
	end
end
function Rideable.setWorldPositionQuat(p277, p278, p279, p280, p281, p282, p283, p284, p285)
	setWorldTranslation(p277.rootNode, p278, p279, p280)
	setWorldQuaternion(p277.rootNode, p281, p282, p283, p284)
	if p285 then
		local v286 = p277.spec_rideable
		v286.networkInterpolators.position:setPosition(p278, p279, p280)
		v286.networkInterpolators.quaternion:setQuaternion(p281, p282, p283, p284)
	end
end
function Rideable.onRegisterActionEvents(p287, _, p288)
	if p287.isClient then
		local v289 = p287.spec_rideable
		p287:clearActionEventsTable(v289.actionEvents)
		if p288 then
			local _, v290 = p287:addActionEvent(v289.actionEvents, InputAction.AXIS_ACCELERATE_VEHICLE, p287, Rideable.actionEventAccelerate, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v290, GS_PRIO_VERY_HIGH)
			g_inputBinding:setActionEventTextVisibility(v290, false)
			v289.acceletateEventId = v290
			local _, v291 = p287:addActionEvent(v289.actionEvents, InputAction.AXIS_BRAKE_VEHICLE, p287, Rideable.actionEventBrake, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v291, GS_PRIO_HIGH)
			g_inputBinding:setActionEventTextVisibility(v291, false)
			v289.brakeEventId = v291
			local _, v292 = p287:addActionEvent(v289.actionEvents, InputAction.AXIS_MOVE_SIDE_VEHICLE, p287, Rideable.actionEventSteer, false, false, true, true, nil)
			g_inputBinding:setActionEventTextVisibility(v292, false)
			v289.steerEventId = v292
			local _, v293 = p287:addActionEvent(v289.actionEvents, InputAction.JUMP, p287, Rideable.actionEventJump, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v293, GS_PRIO_VERY_LOW)
			g_inputBinding:setActionEventTextVisibility(v293, false)
			v289.jumpEventId = v293
		end
	end
end
function Rideable.onEnterVehicle(p294, _)
	local v295 = p294.spec_rideable
	if p294.isClient then
		v295.playerToEnter = nil
		v295.checkPlayerToEnter = false
		v295.currentSpeed = 0
		v295.currentTurnSpeed = 0
		p294:setCurrentGait(Rideable.GAITTYPES.STILL)
		v295.isOnGround = false
	end
	if p294.isServer then
		v295.lastOwner = p294:getOwnerConnection()
		v295.doHusbandryCheck = 0
	end
end
function Rideable.onVehicleCharacterChanged(p296, p297)
	if p297 ~= nil and p296.isClient then
		local v298 = p296.spec_rideable
		link(p297.playerModel.thirdPersonLeftHandNode, v298.leftReinNode)
		link(p297.playerModel.thirdPersonRightHandNode, v298.rightReinNode)
		setVisibility(v298.reinsNode, true)
		if p297 ~= nil and (p297.animationCharsetId ~= nil and p297.animationPlayer ~= nil) then
			for v299, v300 in pairs(v298.animationParameters) do
				conditionalAnimationRegisterParameter(p297.animationPlayer, v300.id, v300.type, v299)
			end
			initConditionalAnimation(p297.animationPlayer, p297.animationCharsetId, p296.configFileName, "vehicle.riderConditionalAnimation")
			setConditionalAnimationSpecificParameterIds(p297.animationPlayer, v298.animationParameters.absForwardVelocity.id, v298.animationParameters.absYawVelocity.id)
			p296:setEquipmentVisibility(true)
			conditionalAnimationZeroiseTrackTimes(p297.animationPlayer)
			conditionalAnimationZeroiseTrackTimes(v298.animationPlayer)
		end
		if p296:getIsControlled() then
			local v301 = g_currentMission
			if v301.hud.fadeScreenElement:getAlpha() > 0 then
				v301:fadeScreen(-1, v298.fadeDuration, p296.endFade, p296)
			end
		end
	end
end
function Rideable.onLeaveVehicle(p302)
	local v303 = p302.spec_rideable
	if p302.isClient then
		v303.inputValues.currentGait = Rideable.GAITTYPES.STILL
		p302:resetInputs()
		local v304 = g_currentMission
		if v304.hud.fadeScreenElement:getAlpha() > 0 then
			v304:fadeScreen(-1, v303.fadeDuration, p302.endFade, p302)
		end
	end
	if p302.isServer then
		v303.doHusbandryCheck = 5000
	end
	v303.leaveTimer = 15000
end
function Rideable.unlinkReins(p305)
	if p305.isClient then
		local v306 = p305.spec_rideable
		link(v306.leftReinParentNode, v306.leftReinNode)
		link(v306.rightReinParentNode, v306.rightReinNode)
		setVisibility(v306.reinsNode, false)
	end
end
function Rideable.setEquipmentVisibility(p307, p308)
	if p307.isClient then
		local v309 = p307.spec_rideable
		if v309.equipmentNode ~= nil then
			setVisibility(v309.equipmentNode, p308)
			setVisibility(v309.reinsNode, p308)
		end
	end
end
function Rideable.actionEventAccelerate(p310, _, _, _, _)
	local v311 = p310.spec_rideable
	local v312 = p310.spec_enterable
	if v312.isEntered and (v312.isControlled and (v311.haltTimer <= 0 and v311.isOnGround)) then
		local v313 = p310:getCurrentGait() + 1
		local v314 = Rideable.GAITTYPES.MAX
		p310:setCurrentGait((math.min(v313, v314)))
	end
end
function Rideable.actionEventBrake(p315, _, _, _, _)
	local v316 = p315.spec_rideable
	if p315:getIsEntered() and (v316.haltTimer <= 0 and v316.isOnGround) then
		local v317 = p315:getCurrentGait() - 1
		p315:setCurrentGait((math.max(v317, 1)))
	end
end
function Rideable.actionEventSteer(p318, _, p319, _, _)
	local v320 = p318.spec_rideable
	if p318:getIsEntered() and v320.haltTimer <= 0 then
		p318:setRideableSteer(p319)
	end
end
function Rideable.actionEventJump(p321, _, _, _, _)
	if p321:getIsRideableJumpAllowed() then
		p321:jump()
	end
end
function Rideable.updateFootsteps(p322, _, p323)
	local v324 = p322.spec_rideable
	if p323 > 0.001 then
		local v325, _, v326 = localDirectionToWorld(p322.rootNode, 0, 0, 1)
		local v327 = MathUtil.getYRotationFromDirection(v325, v326)
		for _, v328 in pairs(v324.hooves) do
			local v329, v330, v331 = getWorldTranslation(v328.node)
			v324.groundRaycastResult.object = 0
			v324.groundRaycastResult.y = v330 - 1
			raycastClosest(v329, v330 + Rideable.GROUND_RAYCAST_OFFSET, v331, 0, -1, 0, Rideable.GROUND_RAYCAST_MAXDISTANCE, "groundRaycastCallback", p322, Rideable.GROUND_RAYCAST_COLLISIONMASK)
			local v332 = v324.groundRaycastResult.object == g_terrainNode
			local v333 = v324.groundRaycastResult.y
			local v334 = v330 - v333 < 0.05
			if v334 and not v328.onGround then
				local v335, v336, v337, _, _ = getTerrainAttributesAtWorldPos(g_terrainNode, v329, v330, v331, true, true, true, true, false)
				v328.onGround = true
				if v324.inputValues.currentGait < Rideable.GAITTYPES.CANTER then
					if v328.psSlow ~= nil and v328.psSlow.emitterShape ~= nil then
						ParticleUtil.resetNumOfEmittedParticles(v328.psSlow)
						ParticleUtil.setEmittingState(v328.psSlow, true)
						setShaderParameter(v328.psSlow.shape, "psColor", v335, v336, v337, 1, false)
						setWorldTranslation(v328.psSlow.emitterShape, v329, v333, v331)
						setWorldRotation(v328.psSlow.emitterShape, 0, v327, 0)
					end
				elseif v328.psFast ~= nil and v328.psFast.emitterShape ~= nil then
					ParticleUtil.resetNumOfEmittedParticles(v328.psFast)
					ParticleUtil.setEmittingState(v328.psFast, true)
					setShaderParameter(v328.psFast.shape, "psColor", v335, v336, v337, 1, false)
					setWorldTranslation(v328.psFast.emitterShape, v329, v333, v331)
					setWorldRotation(v328.psSlow.emitterShape, 0, v327, 0)
				end
				local v338 = p322:getHoofSurfaceSound(v329, v330, v331, v332)
				if v338 ~= nil then
					v328.sampleDebug = string.format("%s - %s", v338.sampleName, v338.filename)
					g_soundManager:playSample(v338)
				end
			elseif not v334 and v328.onGround then
				v328.onGround = false
				if v328.psSlow ~= nil and v328.psSlow.emitterShape ~= nil then
					ParticleUtil.setEmittingState(v328.psSlow, false)
				end
				if v328.psFast ~= nil and v328.psFast.emitterShape ~= nil then
					ParticleUtil.setEmittingState(v328.psFast, false)
				end
			end
		end
	end
end
function Rideable.updateRiding(p339, p340)
	local v341 = p339.spec_rideable
	if v341.cluster ~= nil and v341.currentSpeed ~= 0 then
		local v342 = v341.cluster:getDailyRidingTime() / 100
		local v343 = v341.inputValues.currentGait
		local v344 = v343 == Rideable.GAITTYPES.CANTER and 2 or (v343 == Rideable.GAITTYPES.GALLOP and 3 or 1)
		v341.ridingTimer = v341.ridingTimer + p340 * v344
		if v342 < v341.ridingTimer then
			v341.ridingTimer = 0
			v341.cluster:changeRiding(1)
			v341.cluster:changeDirt(1)
		end
		if p339.lastMovedDistance > 0.001 then
			local v345 = p339.lastMovedDistance * 0.001
			g_farmManager:updateFarmStats(p339:getOwnerFarmId(), "horseDistance", v345)
		end
		p339:updateDirt()
	end
end
function Rideable.getHoofSurfaceSound(p346, p347, p348, p349, p350)
	local v351 = p346.spec_rideable
	if not p350 then
		return v351.surfaceNameToSound.asphalt
	end
	if g_currentMission.snowSystem:getSnowHeightAtArea(p347, p349, p347 + 0.1, p349 + 0.1, p347 + 0.1, p349) > 0 then
		return v351.surfaceNameToSound.snow
	end
	local v352, _ = FSDensityMapUtil.getFieldDataAtWorldPosition(p347, p348, p349)
	if v352 then
		return v351.surfaceNameToSound.field
	end
	if p346.isInShallowWater then
		return v351.surfaceNameToSound.shallowWater
	end
	if p346.isInMediumWater then
		return v351.surfaceNameToSound.mediumWater
	end
	local _, _, _, _, v353 = getTerrainAttributesAtWorldPos(g_terrainNode, p347, p348, p349, true, true, true, true, false)
	return v351.surfaceIdToSound[v353]
end
function Rideable.getPosition(p354)
	return getWorldTranslation(p354.rootNode)
end
function Rideable.getRotation(p355)
	return getWorldRotation(p355.rootNode)
end
function Rideable.setPlayerToEnter(p356, p357)
	local v358 = p356.spec_rideable
	v358.playerToEnter = p357
	v358.checkPlayerToEnter = true
	p356:raiseActive()
end
function Rideable.getName(p359, _)
	return p359.spec_rideable.cluster:getName()
end
function Rideable.getFullName(p360, _)
	return p360:getName()
end
function Rideable.getCanBeReset(_, _)
	return false
end
function Rideable.getCanBeSold(_, _)
	return false
end
function Rideable.getMapHotspotRotation(p361, p362, p363)
	return not p363 and 0 or p362(p361, p363)
end
function Rideable.getShowInVehiclesOverview(_, _)
	return false
end
function Rideable.periodChanged(p364, p365)
	p365(p364)
	local v366 = p364.spec_rideable
	if v366.cluster ~= nil then
		v366.cluster:onPeriodChanged()
	end
end
function Rideable.dayChanged(p367, p368)
	p368(p367)
	local v369 = p367.spec_rideable
	if v369.cluster ~= nil then
		v369.cluster:onDayChanged()
	end
end
function Rideable.getImageFilename(p370, p371)
	local v372 = p371(p370)
	local v373 = p370:getCluster()
	if v373 ~= nil then
		v372 = g_currentMission.animalSystem:getVisualByAge(v373.subTypeIndex, v373:getAge()).store.imageFilename
	end
	return v372
end
function Rideable.deleteVehicleCharacter(p374, p375)
	p374:setEquipmentVisibility(false)
	p374:unlinkReins()
	p375(p374)
end
function Rideable.showInfo(p376, p377, p378)
	local v379 = p376.spec_rideable
	if v379.cluster ~= nil then
		v379.cluster:showInfo(p378)
	end
	p377(p376, p378)
end
function Rideable.updateDebugValues(p380, p381)
	local v382 = p380.spec_rideable
	for v383, v384 in pairs(v382.hooves) do
		local v385 = {
			["name"] = "hoof sample " .. v383,
			["value"] = v384.sampleDebug
		}
		table.insert(p381, v385)
	end
end
function Rideable.updateInputText(p386)
	local v387 = p386.spec_rideable
	if v387.inputValues.currentGait == Rideable.GAITTYPES.BACKWARDS then
		g_inputBinding:setActionEventText(v387.acceletateEventId, g_i18n:getText("action_stop"))
		g_inputBinding:setActionEventActive(v387.acceletateEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.acceletateEventId, true)
		g_inputBinding:setActionEventActive(v387.brakeEventId, false)
		g_inputBinding:setActionEventTextVisibility(v387.brakeEventId, false)
		g_inputBinding:setActionEventActive(v387.jumpEventId, false)
		g_inputBinding:setActionEventTextVisibility(v387.jumpEventId, false)
		return
	elseif v387.inputValues.currentGait == Rideable.GAITTYPES.STILL then
		g_inputBinding:setActionEventText(v387.acceletateEventId, g_i18n:getText("action_walk"))
		g_inputBinding:setActionEventActive(v387.acceletateEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.acceletateEventId, true)
		g_inputBinding:setActionEventText(v387.brakeEventId, g_i18n:getText("action_walkBackwards"))
		g_inputBinding:setActionEventActive(v387.brakeEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.brakeEventId, true)
		g_inputBinding:setActionEventActive(v387.jumpEventId, false)
		g_inputBinding:setActionEventTextVisibility(v387.jumpEventId, false)
		return
	elseif v387.inputValues.currentGait == Rideable.GAITTYPES.WALK then
		g_inputBinding:setActionEventText(v387.acceletateEventId, g_i18n:getText("action_trot"))
		g_inputBinding:setActionEventActive(v387.acceletateEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.acceletateEventId, true)
		g_inputBinding:setActionEventText(v387.brakeEventId, g_i18n:getText("action_stop"))
		g_inputBinding:setActionEventActive(v387.brakeEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.brakeEventId, true)
		g_inputBinding:setActionEventActive(v387.jumpEventId, false)
		g_inputBinding:setActionEventTextVisibility(v387.jumpEventId, false)
		return
	elseif v387.inputValues.currentGait == Rideable.GAITTYPES.TROT then
		g_inputBinding:setActionEventText(v387.acceletateEventId, g_i18n:getText("action_canter"))
		g_inputBinding:setActionEventActive(v387.acceletateEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.acceletateEventId, true)
		g_inputBinding:setActionEventText(v387.brakeEventId, g_i18n:getText("action_walk"))
		g_inputBinding:setActionEventActive(v387.brakeEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.brakeEventId, true)
		g_inputBinding:setActionEventActive(v387.jumpEventId, false)
		g_inputBinding:setActionEventTextVisibility(v387.jumpEventId, false)
		return
	elseif v387.inputValues.currentGait == Rideable.GAITTYPES.CANTER then
		g_inputBinding:setActionEventText(v387.acceletateEventId, g_i18n:getText("action_gallop"))
		g_inputBinding:setActionEventActive(v387.acceletateEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.acceletateEventId, true)
		g_inputBinding:setActionEventText(v387.brakeEventId, g_i18n:getText("action_trot"))
		g_inputBinding:setActionEventActive(v387.brakeEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.brakeEventId, true)
		g_inputBinding:setActionEventText(v387.jumpEventId, g_i18n:getText("input_JUMP"))
		g_inputBinding:setActionEventActive(v387.jumpEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.jumpEventId, true)
	elseif v387.inputValues.currentGait == Rideable.GAITTYPES.GALLOP then
		g_inputBinding:setActionEventActive(v387.acceletateEventId, false)
		g_inputBinding:setActionEventTextVisibility(v387.acceletateEventId, false)
		g_inputBinding:setActionEventText(v387.brakeEventId, g_i18n:getText("action_canter"))
		g_inputBinding:setActionEventActive(v387.brakeEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.brakeEventId, true)
		g_inputBinding:setActionEventText(v387.jumpEventId, g_i18n:getText("input_JUMP"))
		g_inputBinding:setActionEventActive(v387.jumpEventId, true)
		g_inputBinding:setActionEventTextVisibility(v387.jumpEventId, true)
	end
end

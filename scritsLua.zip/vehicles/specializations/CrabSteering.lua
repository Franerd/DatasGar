source("dataS/scripts/vehicles/specializations/events/SetCrabSteeringEvent.lua")
CrabSteering = {}
source("dataS/scripts/gui/hud/extensions/CrabSteeringHUDExtension.lua")
CrabSteering.STEERING_SEND_NUM_BITS = 3
function CrabSteering.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Drivable, p1) and SpecializationUtil.hasSpecialization(Wheels, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	end
	return v2
end
function CrabSteering.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("CrabSteering")
	v3:register(XMLValueType.FLOAT, "vehicle.crabSteering#distFromCompJointToCenterOfBackWheels", "Distance from component joint to center of back wheels")
	v3:register(XMLValueType.FLOAT, "vehicle.crabSteering#aiSteeringModeIndex", "AI steering mode index", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.crabSteering#toggleSpeedFactor", "Toggle speed factor", 1)
	CrabSteering.registerSteeringModeXMLPaths(v3, "vehicle.crabSteering.steeringMode(?)")
	CrabSteering.registerSteeringModeXMLPaths(v3, "vehicle.crabSteering.crabSteeringConfiguration(?).steeringMode(?)")
	Dashboard.registerDashboardXMLPaths(v3, "vehicle.crabSteering.dashboards", { "state" })
	v3:register(XMLValueType.VECTOR_N, "vehicle.crabSteering.dashboards.dashboard(?)#states", "Crab steering states which activate the dashboard")
	v3:register(XMLValueType.INT, "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).wheels#crabSteeringIndex", "Crab steering configuration index")
	v3:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.INT, "vehicles.vehicle(?).crabSteering#state", "Current steering mode", 1)
end
function CrabSteering.registerSteeringModeXMLPaths(p4, p5)
	p4:register(XMLValueType.L10N_STRING, p5 .. "#name", "Steering mode name")
	p4:register(XMLValueType.STRING, p5 .. "#inputBindingName", "Input action name")
	p4:register(XMLValueType.INT, p5 .. ".wheel(?)#index", "Wheel Index")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".wheel(?)#node", "Wheel Node")
	p4:register(XMLValueType.ANGLE, p5 .. ".wheel(?)#offset", "Rotation offset", 0)
	p4:register(XMLValueType.BOOL, p5 .. ".wheel(?)#locked", "Steering is locked", false)
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".steeringNode(?)#node", "Steering node")
	p4:register(XMLValueType.ANGLE, p5 .. ".steeringNode(?)#offset", "Rotation offset", 0)
	p4:register(XMLValueType.BOOL, p5 .. ".steeringNode(?)#locked", "Steering is locked", false)
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".node(?)#node", "Node to adjust when the steering mode is active")
	p4:register(XMLValueType.VECTOR_ROT, p5 .. ".node(?)#rotation", "Rotation when steering mode is active")
	p4:register(XMLValueType.VECTOR_TRANS, p5 .. ".node(?)#translation", "Translation when steering mode is active")
	p4:register(XMLValueType.ANGLE, p5 .. ".articulatedAxis#offset", "Articulated axis offset angle", 0)
	p4:register(XMLValueType.BOOL, p5 .. ".articulatedAxis#locked", "Articulated axis is locked", false)
	p4:register(XMLValueType.VECTOR_N, p5 .. ".articulatedAxis#wheelIndices", "Wheel indices")
	p4:register(XMLValueType.STRING, p5 .. ".animation(?)#name", "Change animation name")
	p4:register(XMLValueType.FLOAT, p5 .. ".animation(?)#speed", "Animation speed", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".animation(?)#stopTime", "Animation stop time")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".steeringWheel#node", "Steering wheel node")
	p4:register(XMLValueType.ANGLE, p5 .. ".steeringWheel#indoorRotation", "Steering wheel indoor rotation", 0)
	p4:register(XMLValueType.ANGLE, p5 .. ".steeringWheel#outdoorRotation", "Steering wheel outdoor rotation", 0)
end
function CrabSteering.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "getCanToggleCrabSteering", CrabSteering.getCanToggleCrabSteering)
	SpecializationUtil.registerFunction(p6, "setCrabSteering", CrabSteering.setCrabSteering)
	SpecializationUtil.registerFunction(p6, "getCrabSteeringMode", CrabSteering.getCrabSteeringMode)
	SpecializationUtil.registerFunction(p6, "updateArticulatedAxisRotation", CrabSteering.updateArticulatedAxisRotation)
end
function CrabSteering.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadWheelFromXML", CrabSteering.loadWheelFromXML)
	SpecializationUtil.registerOverwrittenFunction(p7, "updateSteeringAngle", CrabSteering.updateSteeringAngle)
	SpecializationUtil.registerOverwrittenFunction(p7, "getCanBeSelected", CrabSteering.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadWheelsFromXML", CrabSteering.loadWheelsFromXML)
	SpecializationUtil.registerOverwrittenFunction(p7, "updateSteeringWheel", CrabSteering.updateSteeringWheel)
end
function CrabSteering.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onPostLoad", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onDelete", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onRegisterDashboardValueTypes", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onReadStream", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onWriteStream", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onReadUpdateStream", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onWriteUpdateStream", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onDraw", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onAIImplementStart", CrabSteering)
	SpecializationUtil.registerEventListener(p8, "onRegisterActionEvents", CrabSteering)
end
function CrabSteering.onLoad(p9, _)
	local v10 = p9.spec_crabSteering
	v10.state = 1
	v10.stateMax = -1
	v10.configurationIndex = v10.configurationIndex or 1
	v10.distFromCompJointToCenterOfBackWheels = p9.xmlFile:getValue("vehicle.crabSteering#distFromCompJointToCenterOfBackWheels")
	v10.aiSteeringModeIndex = p9.xmlFile:getValue("vehicle.crabSteering#aiSteeringModeIndex", 1)
	v10.toggleSpeedFactor = p9.xmlFile:getValue("vehicle.crabSteering#toggleSpeedFactor", 1)
	v10.currentArticulatedAxisOffset = 0
	v10.articulatedAxisOffsetChanged = false
	v10.articulatedAxisLastAngle = 0
	v10.articulatedAxisChangingTime = 0
	local v11 = string.format("vehicle.crabSteering.crabSteeringConfiguration(%d)", v10.configurationIndex - 1)
	local v12 = not p9.xmlFile:hasProperty(v11) and "vehicle.crabSteering" or v11
	v10.steeringModes = {}
	local v13 = 0
	while true do
		local v14 = string.format("%s.steeringMode(%d)", v12, v13)
		if not p9.xmlFile:hasProperty(v14) then
			v10.stateMax = #v10.steeringModes
			if v10.stateMax > 2 ^ CrabSteering.STEERING_SEND_NUM_BITS - 1 then
				Logging.xmlError(p9.xmlFile, "CrabSteering only supports %d steering modes!", 2 ^ CrabSteering.STEERING_SEND_NUM_BITS - 1)
			end
			v10.hasSteeringModes = v10.stateMax > 0
			if v10.hasSteeringModes then
				p9.customSteeringAngleFunction = true
				v10.hudExtension = CrabSteeringHUDExtension.new(p9)
				p9:setCrabSteering(1, true)
			else
				SpecializationUtil.removeEventListener(p9, "onReadStream", CrabSteering)
				SpecializationUtil.removeEventListener(p9, "onWriteStream", CrabSteering)
				SpecializationUtil.removeEventListener(p9, "onReadUpdateStream", CrabSteering)
				SpecializationUtil.removeEventListener(p9, "onWriteUpdateStream", CrabSteering)
				SpecializationUtil.removeEventListener(p9, "onDraw", CrabSteering)
				SpecializationUtil.removeEventListener(p9, "onAIImplementStart", CrabSteering)
				SpecializationUtil.removeEventListener(p9, "onRegisterActionEvents", CrabSteering)
			end
		end
		local v15 = {
			["name"] = p9.xmlFile:getValue(v14 .. "#name", "", p9.customEnvironment, false)
		}
		local v16 = p9.xmlFile:getValue(v14 .. "#inputBindingName")
		if v16 ~= nil then
			if InputAction[v16] == nil then
				Logging.xmlWarning(p9.xmlFile, "Invalid inputBindingname \'%s\' for \'%s\'", tostring(v16), v14)
			else
				v15.inputAction = InputAction[v16]
			end
		end
		v15.wheels = {}
		for _, v17 in p9.xmlFile:iterator(v14 .. ".wheel") do
			local v18 = {
				["wheelIndex"] = p9.xmlFile:getValue(v17 .. "#index"),
				["wheelNode"] = p9.xmlFile:getValue(v17 .. "#node", nil, p9.components, p9.i3dMappings)
			}
			if v18.wheelNode == nil then
				::l12::
				v18.offset = p9.xmlFile:getValue(v17 .. "#offset", 0)
				v18.locked = p9.xmlFile:getValue(v17 .. "#locked", false)
				if v18.wheelIndex == nil then
					::l19::
					local v19 = v15.wheels
					table.insert(v19, v18)
				else
					v18.wheel = p9:getWheelFromWheelIndex(v18.wheelIndex)
					if v18.wheel ~= nil then
						goto l19
					end
					local v20 = Logging.xmlError
					local v21 = p9.xmlFile
					local v22 = v18.wheelIndex
					v20(v21, "Invalid wheel \'%s\' for \'%s\'", tostring(v22), v17)
				end
			else
				local v23 = p9:getWheelByWheelNode(v18.wheelNode)
				if v23 == nil then
					Logging.xmlError(p9.xmlFile, "Invalid wheel node \'%s\' for \'%s\'", p9.xmlFile:getString(v17 .. "#node"), v17)
				else
					if v23.physics.rotSpeed ~= 0 then
						v18.wheelIndex = v23.wheelIndex
						v18.wheel = v23
						goto l12
					end
					Logging.xmlError(p9.xmlFile, "Invalid wheel node \'%s\' for \'%s\'. Wheel needs to have a rotSpeed defined!", p9.xmlFile:getString(v17 .. "#node"), v17)
				end
			end
		end
		v15.steeringNodes = {}
		for _, v24 in p9.xmlFile:iterator(v14 .. ".steeringNode") do
			local v25 = {
				["node"] = p9.xmlFile:getValue(v24 .. "#node", nil, p9.components, p9.i3dMappings)
			}
			if v25.node ~= nil then
				local v26 = p9:getSteeringNodeByNode(v25.node)
				if v26 == nil then
					Logging.xmlError(p9.xmlFile, "Invalid steering node \'%s\' for \'%s\'", getName(v25.node), v24)
				else
					v25.steeringNode = v26
					v25.offset = p9.xmlFile:getValue(v24 .. "#offset", 0)
					v25.locked = p9.xmlFile:getValue(v24 .. "#locked", false)
					local v27 = v15.steeringNodes
					table.insert(v27, v25)
				end
			end
		end
		v15.nodes = {}
		for _, v28 in p9.xmlFile:iterator(v14 .. ".node") do
			local v29 = {
				["node"] = p9.xmlFile:getValue(v28 .. "#node", nil, p9.components, p9.i3dMappings)
			}
			if v29.node ~= nil then
				v29.rotation = p9.xmlFile:getValue(v28 .. "#rotation", nil, true)
				v29.translation = p9.xmlFile:getValue(v28 .. "#translation", nil, true)
				local v30 = v15.nodes
				table.insert(v30, v29)
			end
		end
		local v31 = p9.spec_articulatedAxis
		if v31 ~= nil and v31.componentJoint ~= nil then
			v15.articulatedAxis = {}
			v15.articulatedAxis.rotSpeedBackUp = v31.rotSpeed
			v15.articulatedAxis.offset = p9.xmlFile:getValue(v14 .. ".articulatedAxis#offset", 0)
			v15.articulatedAxis.locked = p9.xmlFile:getValue(v14 .. ".articulatedAxis#locked", false)
			v15.articulatedAxis.wheelIndices = p9.xmlFile:getValue(v14 .. ".articulatedAxis#wheelIndices", nil, true)
		end
		v15.animations = {}
		for _, v32 in p9.xmlFile:iterator(v14 .. ".animation") do
			local v33 = {
				["animName"] = p9.xmlFile:getValue(v32 .. "#name"),
				["animSpeed"] = p9.xmlFile:getValue(v32 .. "#speed", 1),
				["stopTime"] = p9.xmlFile:getValue(v32 .. "#stopTime")
			}
			if v33.animName == nil or not p9:getAnimationExists(v33.animName) then
				local v34 = Logging.xmlWarning
				local v35 = p9.xmlFile
				local v36 = v33.animName
				v34(v35, "Invalid animation \'%s\' for \'%s\'", tostring(v36), v32)
			else
				local v37 = v15.animations
				table.insert(v37, v33)
			end
		end
		local v38 = p9.xmlFile:getValue(v14 .. ".steeringWheel#node", nil, p9.components, p9.i3dMappings)
		if v38 ~= nil then
			v15.steeringWheel = {}
			v15.steeringWheel.node = v38
			local _, v39, _ = getRotation(v15.steeringWheel.node)
			v15.steeringWheel.lastRotation = v39
			v15.steeringWheel.indoorRotation = p9.xmlFile:getValue(v14 .. ".steeringWheel#indoorRotation", 0)
			v15.steeringWheel.outdoorRotation = p9.xmlFile:getValue(v14 .. ".steeringWheel#outdoorRotation", 0)
		end
		local v40 = v10.steeringModes
		table.insert(v40, v15)
		v13 = v13 + 1
	end
end
function CrabSteering.onPostLoad(p41, p42)
	if p42 ~= nil and not p42.resetVehicles then
		local v43 = p41.spec_crabSteering
		if v43.hasSteeringModes and p42.xmlFile:hasProperty(p42.key .. ".crabSteering") then
			local v44 = p42.xmlFile:getValue(p42.key .. ".crabSteering#state", 1)
			local v45 = v43.stateMax
			p41:setCrabSteering(math.clamp(v44, 1, v45), true)
			AnimatedVehicle.updateAnimations(p41, 99999999, true)
			p41:forceUpdateWheelPhysics(99999999)
		end
	end
end
function CrabSteering.onDelete(p46)
	local v47 = p46.spec_crabSteering
	if v47.hudExtension ~= nil then
		v47.hudExtension:delete()
	end
end
function CrabSteering.onRegisterDashboardValueTypes(p48)
	local v_u_49 = p48.spec_crabSteering
	local v50 = DashboardValueType.new("crabSteering", "state")
	v50:setValue(v_u_49, function(_, p51)
		-- upvalues: (copy) v_u_49
		local v52 = false
		if p51.crabSteeringStates ~= nil then
			for _, v53 in pairs(p51.crabSteeringStates) do
				if v_u_49.state == v53 then
					v52 = true
				end
			end
		end
		return v52
	end)
	v50:setAdditionalFunctions(function(_, p54, p55, p56, _)
		p56.crabSteeringStates = p54:getValue(p55 .. "#states", nil, true)
		return true
	end)
	p48:registerDashboardValueType(v50)
end
function CrabSteering.saveToXMLFile(p57, p58, p59, _)
	local v60 = p57.spec_crabSteering
	if v60.hasSteeringModes then
		p58:setValue(p59 .. "#state", v60.state)
	end
end
function CrabSteering.onReadStream(p61, p62, _)
	p61:setCrabSteering(streamReadUIntN(p62, CrabSteering.STEERING_SEND_NUM_BITS), true)
	AnimatedVehicle.updateAnimations(p61, 99999999, true)
	p61:forceUpdateWheelPhysics(99999999)
end
function CrabSteering.onWriteStream(p63, p64, _)
	local v65 = p63.spec_crabSteering
	streamWriteUIntN(p64, v65.state, CrabSteering.STEERING_SEND_NUM_BITS)
end
function CrabSteering.onReadUpdateStream(p66, p67, _, _)
	local v68 = p66.spec_articulatedAxis
	if v68 ~= nil and v68.componentJoint ~= nil then
		v68.curRot = streamReadFloat32(p67)
	end
end
function CrabSteering.onWriteUpdateStream(p69, p70, _, _)
	local v71 = p69.spec_articulatedAxis
	if v71 ~= nil and v71.componentJoint ~= nil then
		streamWriteFloat32(p70, v71.curRot)
	end
end
function CrabSteering.onDraw(p72)
	local v73 = p72.spec_crabSteering
	if v73.hudExtension ~= nil then
		g_currentMission.hud:addHelpExtension(v73.hudExtension)
	end
end
function CrabSteering.getCanToggleCrabSteering(_)
	return true, nil
end
function CrabSteering.setCrabSteering(p74, p75, p76)
	local v77 = p74.spec_crabSteering
	if p76 == nil or p76 == false then
		if g_server == nil then
			g_client:getServerConnection():sendEvent(SetCrabSteeringEvent.new(p74, p75))
		else
			g_server:broadcastEvent(SetCrabSteeringEvent.new(p74, p75), nil, nil, p74)
		end
	end
	if p75 ~= v77.state then
		local v78 = v77.steeringModes[v77.state]
		if v78.animations ~= nil then
			for _, v79 in pairs(v78.animations) do
				local v80 = p74:getAnimationTime(v79.animName)
				if v79.stopTime == nil then
					p74:playAnimation(v79.animName, -v79.animSpeed, v80, p76)
				end
			end
		end
		local v81 = v77.steeringModes[p75]
		if v81.animations ~= nil then
			for _, v82 in pairs(v81.animations) do
				local v83 = p74:getAnimationTime(v82.animName)
				if v82.stopTime == nil then
					p74:playAnimation(v82.animName, v82.animSpeed, v83, p76)
				else
					p74:setAnimationStopTime(v82.animName, v82.stopTime)
					local v84 = v82.stopTime < v83 and -1 or 1
					p74:playAnimation(v82.animName, v84, v83, p76)
				end
			end
		end
		for _, v85 in pairs(v81.steeringNodes) do
			v85.steeringNode.offsetTarget = v85.offset
			local v86 = v85.steeringNode
			local v87 = v85.steeringNode.offsetTarget - v85.steeringNode.offset
			v86.offsetTargetSpeed = math.abs(v87) / (1 / v77.toggleSpeedFactor * 1000)
			if v85.steeringNode.locked then
				v85.steeringNode.rotScaleTarget = 0
			else
				v85.steeringNode.rotScaleTarget = v85.steeringNode.rotScaleOrig
			end
			local v88 = v85.steeringNode
			local v89 = v85.steeringNode.rotScaleTarget - v85.steeringNode.rotScale
			v88.rotScaleTargetSpeed = math.abs(v89) / (1 / v77.toggleSpeedFactor * 1000)
		end
		for _, v90 in pairs(v81.wheels) do
			v90.wheel.steeringOffset = v90.wheel.steeringOffset or 0
			local v91 = v90.wheel
			local v92 = v90.offset - v90.wheel.steeringOffset
			v91.steeringOffsetSpeed = math.abs(v92) / (1 / v77.toggleSpeedFactor * 1000)
		end
		for _, v93 in ipairs(v81.nodes) do
			if v93.rotation ~= nil then
				setRotation(v93.node, v93.rotation[1], v93.rotation[2], v93.rotation[3])
			end
			if v93.translation ~= nil then
				setTranslation(v93.node, v93.translation[1], v93.translation[2], v93.translation[3])
			end
			if p74.setMovingToolDirty ~= nil then
				p74:setMovingToolDirty(v93.node)
			end
		end
	end
	v77.state = p75
end
function CrabSteering.getCrabSteeringMode(p94)
	local v95 = p94.spec_crabSteering
	if v95.steeringModes == nil then
		return nil
	else
		return v95.steeringModes[v95.state]
	end
end
function CrabSteering.loadWheelFromXML(p96, p97, p98)
	if not p97(p96, p98) then
		return false
	end
	p98.steeringOffset = 0
	p98.forceSteeringAngleUpdate = true
	return true
end
function CrabSteering.updateSteeringAngle(p99, p100, p101, p102, p103)
	local v104 = p99.spec_crabSteering
	local v105 = p99.spec_drivable
	if v104.stateMax == 0 then
		return p100(p99, p101, p102, p103)
	end
	local v106 = v104.steeringModes[v104.state]
	for v107 = 1, #v106.wheels do
		local v108 = v106.wheels[v107]
		if v108.wheelIndex == p101.wheelIndex then
			if p101.rotSpeedBackUp == nil then
				p101.rotSpeedBackUp = p101.physics.rotSpeed
			end
			if p101.rotSpeedBackUp ~= 0 then
				local v109
				if p99.lastSpeed == 0 then
					v109 = 0
				else
					local v110 = 1 / (p99.lastSpeed * v105.speedRotScale + v105.speedRotScaleOffset)
					v109 = math.min(v110, 1)
				end
				local v111 = p102 * 0.001 * p99.autoRotateBackSpeed * v109 * v104.toggleSpeedFactor
				if p101.steeringOffset ~= v108.offset then
					local v112 = v108.offset - p101.steeringOffset
					local v113 = math.sign(v112)
					local v114 = p102 * v108.wheel.steeringOffsetSpeed * v113
					p101.steeringOffset = (v113 > 0 and math.min or math.max)(p101.steeringOffset + v114, v108.offset)
				end
				if v108.locked then
					if p101.physics.steeringAngle > p101.steeringOffset or p101.steeringOffset < p103 then
						local v115 = p101.steeringOffset
						local v116 = p101.physics.steeringAngle
						local v117 = math.min(v116, p103) - v111
						p103 = math.max(v115, v117)
					elseif p101.physics.steeringAngle < p101.steeringOffset or p103 < p101.steeringOffset then
						local v118 = p101.steeringOffset
						local v119 = p101.physics.steeringAngle
						local v120 = math.max(v119, p103) + v111
						p103 = math.min(v118, v120)
					end
					if p103 == p101.steeringOffset then
						p101.physics.rotSpeed = 0
					elseif p101.physics.rotSpeed < 0 then
						local v121 = p101.physics
						local v122 = p101.physics.rotSpeed + v111
						v121.rotSpeed = math.min(0, v122)
					elseif p101.physics.rotSpeed > 0 then
						local v123 = p101.physics
						local v124 = p101.physics.rotSpeed - v111
						v123.rotSpeed = math.max(0, v124)
					end
				else
					local v125
					if p99.rotatedTime > 0 then
						v125 = (p101.physics.rotMax - p101.steeringOffset) / p99.wheelSteeringDuration
						if p101.rotSpeedBackUp < 0 then
							v125 = (p101.physics.rotMin - p101.steeringOffset) / p99.wheelSteeringDuration
						end
					else
						v125 = -(p101.physics.rotMin - p101.steeringOffset) / p99.wheelSteeringDuration
						if p101.rotSpeedBackUp < 0 then
							v125 = -(p101.physics.rotMax - p101.steeringOffset) / p99.wheelSteeringDuration
						end
					end
					if p101.physics.rotSpeed < p101.rotSpeedBackUp then
						local v126 = p101.physics
						local v127 = p101.rotSpeedBackUp
						local v128 = p101.physics.rotSpeed + v111
						v126.rotSpeed = math.min(v127, v128)
					elseif p101.physics.rotSpeed > p101.rotSpeedBackUp then
						local v129 = p101.physics
						local v130 = p101.rotSpeedBackUp
						local v131 = p101.physics.rotSpeed - v111
						v129.rotSpeed = math.max(v130, v131)
					end
					local v132 = p101.physics.rotSpeed / p101.rotSpeedBackUp
					p103 = p101.steeringOffset + p99.rotatedTime * v132 * v125
				end
				local v133 = p101.physics.rotMin
				local v134 = p101.physics.rotMax
				return math.clamp(p103, v133, v134)
			end
			break
		end
	end
	return p103
end
function CrabSteering.updateArticulatedAxisRotation(p135, p136, p137)
	local v138 = p135.spec_crabSteering
	local v139 = p135.spec_articulatedAxis
	local v140 = p135.spec_drivable
	if v138.stateMax == 0 then
		return p136
	end
	if not p135.isServer then
		return v139.curRot
	end
	local v141 = v138.steeringModes[v138.state]
	if v141.articulatedAxis == nil then
		return p136
	end
	local v142 = 1 / (p135.lastSpeed * v140.speedRotScale + v140.speedRotScaleOffset)
	local v143 = math.min(v142, 1)
	local v144 = p137 * 0.001 * p135.autoRotateBackSpeed * v143 * v138.toggleSpeedFactor
	if v138.currentArticulatedAxisOffset < v141.articulatedAxis.offset then
		local v145 = v141.articulatedAxis.offset
		local v146 = v138.currentArticulatedAxisOffset + v144
		v138.currentArticulatedAxisOffset = math.min(v145, v146)
	elseif v138.currentArticulatedAxisOffset > v141.articulatedAxis.offset then
		local v147 = v141.articulatedAxis.offset
		local v148 = v138.currentArticulatedAxisOffset - v144
		v138.currentArticulatedAxisOffset = math.max(v147, v148)
	end
	if v141.articulatedAxis.locked then
		if v139.rotSpeed > 0 then
			local v149 = v139.rotSpeed - v144
			v139.rotSpeed = math.max(0, v149)
		elseif v139.rotSpeed < 0 then
			local v150 = v139.rotSpeed + v144
			v139.rotSpeed = math.min(0, v150)
		end
	elseif v139.rotSpeed > v141.articulatedAxis.rotSpeedBackUp then
		local v151 = v141.articulatedAxis.rotSpeedBackUp
		local v152 = v139.rotSpeed - v144
		v139.rotSpeed = math.max(v151, v152)
	elseif v139.rotSpeed < v141.articulatedAxis.rotSpeedBackUp then
		local v153 = v141.articulatedAxis.rotSpeedBackUp
		local v154 = v139.rotSpeed + v144
		v139.rotSpeed = math.min(v153, v154)
	end
	local v155
	if p135.rotatedTime * v141.articulatedAxis.rotSpeedBackUp > 0 then
		v155 = (v139.rotMax - v138.currentArticulatedAxisOffset) / p135.wheelSteeringDuration
	else
		v155 = (v139.rotMin - v138.currentArticulatedAxisOffset) / p135.wheelSteeringDuration
	end
	local v156 = v139.rotSpeed
	local v157 = math.abs(v156)
	local v158 = v141.articulatedAxis.rotSpeedBackUp
	local v159 = v155 * (v157 / math.abs(v158))
	local v160 = v138.currentArticulatedAxisOffset
	local v161 = p135.rotatedTime
	local v162 = v160 + math.abs(v161) * v159
	if v141.articulatedAxis.wheelIndices == nil or (v138.distFromCompJointToCenterOfBackWheels == nil or p135.movingDirection < 0) then
		local v163 = v138.articulatedAxisChangingTime
		if v138.articulatedAxisOffsetChanged then
			v138.articulatedAxisOffsetChanged = false
			v163 = 2500
		end
		if v163 > 0 then
			local v164 = v163 / 2500
			v162 = v162 * (1 - v164) + v138.articulatedAxisLastAngle * v164
			v138.articulatedAxisChangingTime = v163 - p137
		end
	else
		local v165 = p135:getWheels()
		local v166 = v141.articulatedAxis.rotSpeedBackUp
		local v167 = math.sign(v166) * v139.curRot
		local v168 = 0
		local v169 = 0
		for _, v170 in pairs(v141.articulatedAxis.wheelIndices) do
			v168 = v168 + v165[v170].physics.steeringAngle
			v169 = v169 + 1
		end
		if v169 > 0 then
			v168 = v168 / v169
		end
		local v171 = v168 - v167
		local v172 = 0
		local v173 = 0
		for _, v174 in pairs(v141.articulatedAxis.wheelIndices) do
			local v175 = v165[v174]
			local v176 = getWheelShapeAxleSpeed(v175.node, v175.physics.wheelShape)
			if v175.physics.hasGroundContact then
				local v177, _ = getWheelShapeSlip(v175.node, v175.physics.wheelShape)
				v172 = v172 + (1 - math.min(1, v177)) * v176 * v175.physics.radius
				v173 = v173 + 1
			end
		end
		if v173 > 0 then
			v172 = v172 / v173
		end
		local v178 = v172 * 0.001 * p137
		local v179 = math.sin(v171) * v178
		local v180 = math.cos(v171) * v178
		local v181 = v138.distFromCompJointToCenterOfBackWheels - v180
		local v182 = math.atan2(v179, v181)
		local v183 = v141.articulatedAxis.rotSpeedBackUp
		v162 = math.sign(v183) * (v167 + v182)
		v138.articulatedAxisOffsetChanged = true
		v138.articulatedAxisLastAngle = v162
	end
	local v184 = v139.rotMin
	local v185 = v139.rotMax
	local v186 = math.min(v185, v162)
	return math.max(v184, v186)
end
function CrabSteering.getCanBeSelected(p187, p188)
	return p187.spec_crabSteering.hasSteeringModes or p188(p187)
end
function CrabSteering.loadWheelsFromXML(p189, p190, p191, p192, p193)
	p190(p189, p191, p192, p193)
	p189.spec_crabSteering.configurationIndex = WheelXMLObject.getValueStatic(p189.spec_wheels.wheelConfigurationId, p189.spec_wheels.configurationIndexToParentConfigIndex, p189.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#crabSteeringIndex")
end
function CrabSteering.updateSteeringWheel(p194, p195, p196, p197, p198)
	if p194.spec_crabSteering.hasSteeringModes then
		local v199 = p194.spec_crabSteering
		local v200 = v199.steeringModes[v199.state]
		if v200.steeringWheel ~= nil then
			p196 = v200.steeringWheel
		end
	end
	p195(p194, p196, p197, p198)
end
function CrabSteering.onAIImplementStart(p201)
	p201:setCrabSteering(p201.spec_crabSteering.aiSteeringModeIndex)
end
function CrabSteering.onRegisterActionEvents(p202, _, p203)
	if p202.isClient then
		local v204 = p202.spec_crabSteering
		if v204.hasSteeringModes then
			p202:clearActionEventsTable(v204.actionEvents)
			if p203 then
				local _, v205 = p202:addPoweredActionEvent(v204.actionEvents, InputAction.TOGGLE_CRABSTEERING, p202, CrabSteering.actionEventToggleCrabSteeringModes, false, true, false, true, 1)
				g_inputBinding:setActionEventTextPriority(v205, GS_PRIO_NORMAL)
				for _, v206 in pairs(v204.steeringModes) do
					if v206.inputAction ~= nil then
						local _, v207 = p202:addPoweredActionEvent(v204.actionEvents, v206.inputAction, p202, CrabSteering.actionEventSetCrabSteeringMode, false, true, false, true, nil)
						g_inputBinding:setActionEventTextVisibility(v207, false)
						g_inputBinding:setActionEventTextPriority(v207, GS_PRIO_NORMAL)
					end
				end
				local _, v208 = p202:addPoweredActionEvent(v204.actionEvents, InputAction.TOGGLE_CRABSTEERING_BACK, p202, CrabSteering.actionEventToggleCrabSteeringModes, false, true, false, true, -1)
				g_inputBinding:setActionEventTextVisibility(v208, false)
			end
		end
	end
end
function CrabSteering.actionEventToggleCrabSteeringModes(p209, _, _, p210, _)
	local v211, v212 = p209:getCanToggleCrabSteering()
	if v211 then
		local v213 = p209.spec_crabSteering
		local v214 = v213.state + p210
		if v213.stateMax < v214 then
			v214 = 1
		elseif v214 < 1 then
			v214 = v213.stateMax
		end
		if v214 ~= v213.state then
			p209:setCrabSteering(v214)
			return
		end
	elseif v212 ~= nil then
		g_currentMission:showBlinkingWarning(v212, 2000)
	end
end
function CrabSteering.actionEventSetCrabSteeringMode(p215, p216, _, _, _)
	local v217, v218 = p215:getCanToggleCrabSteering()
	if v217 then
		local v219 = p215.spec_crabSteering
		local v220 = v219.state
		for v221, v222 in pairs(v219.steeringModes) do
			if v222.inputAction == InputAction[p216] then
				v220 = v221
				break
			end
		end
		if v220 ~= v219.state then
			p215:setCrabSteering(v220)
			return
		end
	elseif v218 ~= nil then
		g_currentMission:showBlinkingWarning(v218, 2000)
	end
end

TireTracks = {}
TireTracks.MAX_CREATION_DISTANCE = 75
function TireTracks.prerequisitesPresent(_)
	return true
end
function TireTracks.initSpecialization() end
function TireTracks.registerFunctions(p1)
	SpecializationUtil.registerFunction(p1, "getAllowTireTracks", TireTracks.getAllowTireTracks)
	SpecializationUtil.registerFunction(p1, "addTireTrackNode", TireTracks.addTireTrackNode)
	SpecializationUtil.registerFunction(p1, "removeTireTrackNode", TireTracks.removeTireTrackNode)
	SpecializationUtil.registerFunction(p1, "updateTireTrackNode", TireTracks.updateTireTrackNode)
end
function TireTracks.registerOverwrittenFunctions(_) end
function TireTracks.registerEventListeners(p2)
	SpecializationUtil.registerEventListener(p2, "onPreLoad", TireTracks)
	SpecializationUtil.registerEventListener(p2, "onDelete", TireTracks)
	SpecializationUtil.registerEventListener(p2, "onUpdate", TireTracks)
end
function TireTracks.onPreLoad(p3, _)
	local v4 = p3.spec_tireTracks
	v4.tireTrackNodes = {}
	v4.hasTireTrackNodes = false
	v4.segmentsCoeff = getTyreTracksSegmentsCoeff()
	v4.tireTrackSystem = g_currentMission.tireTrackSystem
end
function TireTracks.onDelete(p5)
	local v6 = p5.spec_tireTracks
	if v6.tireTrackNodes ~= nil then
		for _, v7 in pairs(v6.tireTrackNodes) do
			v6.tireTrackSystem:destroyTrack(v7.tireTrackIndex)
		end
	end
end
function TireTracks.onUpdate(p8, _, _, _, _)
	if p8.isActive then
		local v9 = p8.spec_tireTracks
		if v9.hasTireTrackNodes then
			local v10 = p8:getAllowTireTracks()
			for _, v11 in pairs(v9.tireTrackNodes) do
				p8:updateTireTrackNode(v11, v10)
			end
		end
	end
end
function TireTracks.getAllowTireTracks(p12)
	local v13
	if p12.currentUpdateDistance < TireTracks.MAX_CREATION_DISTANCE then
		v13 = p12.spec_tireTracks.segmentsCoeff > 0
	else
		v13 = false
	end
	return v13
end
function TireTracks.addTireTrackNode(p14, p15, p16, p17, p18, p19, p20, p21, p22)
	local v23 = p14.spec_tireTracks
	local v24 = {
		["wheel"] = p15,
		["parent"] = p16,
		["linkNode"] = p17,
		["tireTrackAtlasIndex"] = p18,
		["width"] = p19,
		["radius"] = p20,
		["inverted"] = p21,
		["activeFunc"] = p22
	}
	if v23.tireTrackSystem ~= nil then
		v24.tireTrackIndex = v23.tireTrackSystem:createTrack(p19, p18)
		if v24.tireTrackIndex ~= nil then
			local v25 = v23.tireTrackNodes
			table.insert(v25, v24)
			v23.hasTireTrackNodes = next(v23.tireTrackNodes) ~= nil
			return #v23.tireTrackNodes
		end
	end
	return nil
end
function TireTracks.removeTireTrackNode(p26, p27)
	local v28 = p26.spec_tireTracks
	v28.tireTrackNodes[p27] = nil
	v28.hasTireTrackNodes = next(v28.tireTrackNodes) ~= nil
end
function TireTracks.updateTireTrackNode(p29, p30, p31)
	local v32 = p29.spec_tireTracks
	local v33 = p30.wheel
	if p31 then
		if p30.activeFunc == nil or p30.activeFunc() then
			local v34, v35, v36 = worldToLocal(p30.parent, getWorldTranslation(p30.linkNode))
			local v37 = v35 - p30.radius
			local v38, v39, v40 = localToWorld(p30.parent, v34, v37, v36)
			local v41 = getTerrainHeightAtWorldPos
			local v42 = g_terrainNode
			local v43 = math.max(v39, v41(v42, v38, v39, v40))
			if v33.physics.contact == WheelContactType.NONE or not v33.physics.lastContactObjectAllowsTireTracks then
				v32.tireTrackSystem:cutTrack(p30.tireTrackIndex)
				return
			else
				local v44, v45, v46, v47, _, v48, v49 = v33.physics:getGroundAttributes()
				if v48 > 0 then
					local v50, v51, v52 = localDirectionToWorld(v33.node, -v33.physics.directionX, -v33.physics.directionY, -v33.physics.directionZ)
					local v53 = p29.movingDirection
					if p30.inverted then
						v53 = v53 * -1
					end
					v32.tireTrackSystem:addTrackPoint(p30.tireTrackIndex, v38, v43, v40, v50, v51, v52, v44, v45, v46, v48, v47, v53, v33.physics.contact ~= WheelContactType.OBJECT, v49)
				else
					v32.tireTrackSystem:cutTrack(p30.tireTrackIndex)
				end
			end
		else
			v32.tireTrackSystem:cutTrack(p30.tireTrackIndex)
			return
		end
	else
		v32.tireTrackSystem:cutTrack(p30.tireTrackIndex)
		return
	end
end

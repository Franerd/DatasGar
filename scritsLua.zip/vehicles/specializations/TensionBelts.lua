source("dataS/scripts/vehicles/specializations/events/TensionBeltsEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TensionBeltsRefreshEvent.lua")
TensionBelts = {}
TensionBelts.debugRendering = false
TensionBelts.NUM_SEND_BITS = 5
function TensionBelts.prerequisitesPresent(_)
	return true
end
function TensionBelts.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("tensionBelts", g_i18n:getText("configuration_tensionBelts"), "tensionBelts", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("TensionBelts")
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#totalInteractionRadius", "Total interaction radius", 6)
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#interactionRadius", "Interaction radius", 1)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#interactionBaseNode", "Interaction base node", "Vehicle root node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#activationTrigger", "Activation trigger")
	v1:register(XMLValueType.STRING, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#tensionBeltType", "Supports tension belts", "basic")
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#width", "Belt width", "Used from belt definitions")
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#ratchetPosition", "Ratchet position")
	v1:register(XMLValueType.BOOL, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#useHooks", "Use hooks", true)
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#maxEdgeLength", "Max. edge length", 0.1)
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#geometryBias", "Geometry bias", 0.01)
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#defaultOffsetSide", "Default offset side", 0.1)
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#defaultOffset", "Default offset", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#defaultHeight", "Default height", 5)
	v1:register(XMLValueType.BOOL, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#allowFoldingWhileFasten", "Folding is allowed while tension belts are fasten", true)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#linkNode", "Link node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#rootNode", "Root node", "Root component")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts#jointNode", "Joint node", "rootNode")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)#startNode", "Start node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)#endNode", "End node")
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)#offsetLeft", "Offset left")
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)#offsetRight", "Offset right")
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)#offset", "Offset")
	v1:register(XMLValueType.FLOAT, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)#height", "Height")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)#linkNode", "Custom link node for visual tension belts")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)#jointNode", "Custom joint node for to mount the objects to")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?).intersectionNode(?)#node", "Intersection node")
	ObjectChangeUtil.registerObjectChangeXMLPaths(v1, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.tensionBelt(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.sounds", "toggleBelt")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.sounds", "addBelt")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(?).tensionBelts.sounds", "removeBelt")
	v1:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.BOOL, "vehicles.vehicle(?).tensionBelts.belt(?)#isActive", "Belt is active", false)
end
function TensionBelts.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "createTensionBelt", TensionBelts.createTensionBelt)
	SpecializationUtil.registerFunction(p2, "removeTensionBelt", TensionBelts.removeTensionBelt)
	SpecializationUtil.registerFunction(p2, "setTensionBeltsActive", TensionBelts.setTensionBeltsActive)
	SpecializationUtil.registerFunction(p2, "setAllTensionBeltsActive", TensionBelts.setAllTensionBeltsActive)
	SpecializationUtil.registerFunction(p2, "objectOverlapCallback", TensionBelts.objectOverlapCallback)
	SpecializationUtil.registerFunction(p2, "getObjectToMount", TensionBelts.getObjectToMount)
	SpecializationUtil.registerFunction(p2, "getObjectsToUnmount", TensionBelts.getObjectsToUnmount)
	SpecializationUtil.registerFunction(p2, "updateFastenState", TensionBelts.updateFastenState)
	SpecializationUtil.registerFunction(p2, "refreshTensionBelts", TensionBelts.refreshTensionBelts)
	SpecializationUtil.registerFunction(p2, "freeTensionBeltObject", TensionBelts.freeTensionBeltObject)
	SpecializationUtil.registerFunction(p2, "lockTensionBeltObject", TensionBelts.lockTensionBeltObject)
	SpecializationUtil.registerFunction(p2, "getIsPlayerInTensionBeltsRange", TensionBelts.getIsPlayerInTensionBeltsRange)
	SpecializationUtil.registerFunction(p2, "getIsDynamicallyMountedNode", TensionBelts.getIsDynamicallyMountedNode)
	SpecializationUtil.registerFunction(p2, "tensionBeltActivationTriggerCallback", TensionBelts.tensionBeltActivationTriggerCallback)
	SpecializationUtil.registerFunction(p2, "onTensionBeltTreeShapeCut", TensionBelts.onTensionBeltTreeShapeCut)
end
function TensionBelts.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsReadyForAutomatedTrainTravel", TensionBelts.getIsReadyForAutomatedTrainTravel)
	SpecializationUtil.registerOverwrittenFunction(p3, "getCanBeSelected", TensionBelts.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsFoldAllowed", TensionBelts.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p3, "getFillLevelInformation", TensionBelts.getFillLevelInformation)
	SpecializationUtil.registerOverwrittenFunction(p3, "getAdditionalComponentMass", TensionBelts.getAdditionalComponentMass)
end
function TensionBelts.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onPostLoad", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onDelete", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onPreDelete", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onReadStream", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onUpdate", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onUpdateTick", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onDraw", TensionBelts)
	SpecializationUtil.registerEventListener(p4, "onRegisterActionEvents", TensionBelts)
end
function TensionBelts.onLoad(p5, _)
	local v6 = p5.spec_tensionBelts
	local v7 = Utils.getNoNil(p5.configurations.tensionBelts, 1)
	local v8 = string.format("vehicle.tensionBelts.tensionBeltsConfigurations.tensionBeltsConfiguration(%d).tensionBelts", v7 - 1)
	v6.hasTensionBelts = true
	if not p5.xmlFile:hasProperty(v8) then
		v6.hasTensionBelts = false
		SpecializationUtil.removeEventListener(p5, "onPostLoad", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onDelete", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onPreDelete", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onReadStream", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onWriteStream", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onUpdate", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onUpdateTick", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onDraw", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onRegisterActionEvents", TensionBelts)
		return
	end
	v6.belts = {}
	v6.tensionBelts = {}
	v6.singleBelts = {}
	v6.sortedBelts = {}
	v6.activatable = TensionBeltsActivatable.new(p5)
	v6.totalInteractionRadius = p5.xmlFile:getValue(v8 .. "#totalInteractionRadius", 6)
	v6.interactionRadius = p5.xmlFile:getValue(v8 .. "#interactionRadius", 1)
	v6.interactionBaseNode = p5.xmlFile:getValue(v8 .. "#interactionBaseNode", p5.rootNode, p5.components, p5.i3dMappings)
	local v9 = p5.xmlFile:getValue(v8 .. "#activationTrigger", nil, p5.components, p5.i3dMappings)
	if v9 ~= nil then
		if getCollisionFilterGroup(v9) == CollisionFlag.TRIGGER then
			if getCollisionFilterMask(v9) == CollisionFlag.PLAYER then
				addTrigger(v9, "tensionBeltActivationTriggerCallback", p5)
				v6.activationTrigger = v9
			else
				Logging.xmlError(p5.xmlFile, "Wrong collision filter mask for tension belt activation trigger \'%s\'. Should only have %s", getName(v9), CollisionFlag.getBitAndName(CollisionFlag.PLAYER))
			end
		else
			Logging.xmlError(p5.xmlFile, "Wrong collision filter group set for tension belt activation trigger \'%s\'. Should only have %s", getName(v9), CollisionFlag.getBitAndName(CollisionFlag.TRIGGER))
		end
	end
	v6.allowFoldingWhileFasten = p5.xmlFile:getValue(v8 .. "#allowFoldingWhileFasten", true)
	v6.isPlayerInTrigger = false
	v6.checkSizeOffsets = { 0, 2.5, 1.5 }
	v6.objectsInTensionBeltRange = {}
	v6.numObjectsIntensionBeltRange = 0
	local v10 = p5.xmlFile:getValue(v8 .. "#tensionBeltType", "basic")
	local v11 = g_tensionBeltManager:getBeltData(v10)
	if v11 == nil then
		Logging.xmlWarning(p5.xmlFile, "No belt data found for tension belt type %s", v10)
	else
		v6.width = p5.xmlFile:getValue(v8 .. "#width")
		v6.ratchetPosition = p5.xmlFile:getValue(v8 .. "#ratchetPosition")
		v6.useHooks = p5.xmlFile:getValue(v8 .. "#useHooks", true)
		v6.maxEdgeLength = p5.xmlFile:getValue(v8 .. "#maxEdgeLength", 0.1)
		v6.geometryBias = p5.xmlFile:getValue(v8 .. "#geometryBias", 0.01)
		v6.defaultOffsetSide = p5.xmlFile:getValue(v8 .. "#defaultOffsetSide", 0.1)
		v6.defaultOffset = p5.xmlFile:getValue(v8 .. "#defaultOffset", 0)
		v6.defaultHeight = p5.xmlFile:getValue(v8 .. "#defaultHeight", 5)
		v6.beltData = v11
		v6.linkNode = p5.xmlFile:getValue(v8 .. "#linkNode", nil, p5.components, p5.i3dMappings)
		v6.rootNode = p5.xmlFile:getValue(v8 .. "#rootNode", p5.components[1].node, p5.components, p5.i3dMappings)
		v6.jointNode = p5.xmlFile:getValue(v8 .. "#jointNode", v6.rootNode, p5.components, p5.i3dMappings)
		v6.checkTimerDuration = 500
		v6.checkTimer = v6.checkTimerDuration
		if v6.linkNode == nil then
			Logging.xmlError(p5.xmlFile, "No tension belts link node given at %s%s", v8, "#linkNode")
			p5:setLoadingState(VehicleLoadingState.ERROR)
			return
		end
		if getRigidBodyType(v6.jointNode) ~= RigidBodyType.DYNAMIC and getRigidBodyType(v6.jointNode) ~= RigidBodyType.KINEMATIC then
			Logging.xmlError(p5.xmlFile, "Given jointNode \'" .. getName(v6.jointNode) .. "\' has invalid rigidBodyType. Have to be \'Dynamic\' or \'Kinematic\'! Using \'" .. getName(p5.components[1].node) .. "\' instead!")
			v6.jointNode = p5.components[1].node
		end
		v6.isDynamic = getRigidBodyType(v6.jointNode) == RigidBodyType.DYNAMIC
		local v12, v13, v14 = localToLocal(v6.linkNode, v6.jointNode, 0, 0, 0)
		local v15, v16, v17 = localRotationToLocal(v6.linkNode, v6.jointNode, 0, 0, 0)
		v6.linkNodePosition = { v12, v13, v14 }
		v6.linkNodeRotation = { v15, v16, v17 }
		v6.jointComponent = p5:getParentComponent(v6.jointNode)
		local v18 = 0
		while true do
			local v19 = string.format(v8 .. ".tensionBelt(%d)", v18)
			if not p5.xmlFile:hasProperty(v19) then
				break
			end
			if #v6.sortedBelts == 2 ^ TensionBelts.NUM_SEND_BITS then
				Logging.xmlWarning(p5.xmlFile, "Max number of tension belts is " .. 2 ^ TensionBelts.NUM_SEND_BITS .. "!")
				break
			end
			local v20 = p5.xmlFile:getValue(v19 .. "#startNode", nil, p5.components, p5.i3dMappings)
			local v21 = p5.xmlFile:getValue(v19 .. "#endNode", nil, p5.components, p5.i3dMappings)
			if v20 ~= nil and v21 ~= nil then
				local v22, v23, _ = getTranslation(v21)
				if math.abs(v22) < 0.0001 and math.abs(v23) < 0.0001 then
					if v6.linkNode == nil then
						v6.linkNode = getParent(v20)
					end
					if v6.startNode == nil then
						v6.startNode = v20
					end
					v6.endNode = v21
					local v24 = p5.xmlFile:getValue(v19 .. "#offsetLeft")
					local v25 = p5.xmlFile:getValue(v19 .. "#offsetRight")
					local v26 = p5.xmlFile:getValue(v19 .. "#offset")
					local v27 = p5.xmlFile:getValue(v19 .. "#height")
					local v28 = 0
					local v29 = {}
					while true do
						local v30 = string.format(v19 .. ".intersectionNode(%d)", v28)
						if not p5.xmlFile:hasProperty(v30) then
							break
						end
						local v31 = p5.xmlFile:getValue(v30 .. "#node", nil, p5.components, p5.i3dMappings)
						if v31 ~= nil then
							table.insert(v29, v31)
						end
						v28 = v28 + 1
					end
					local v32 = p5.xmlFile:getValue(v19 .. "#linkNode", nil, p5.components, p5.i3dMappings)
					local v33 = p5.xmlFile:getValue(v19 .. "#jointNode", nil, p5.components, p5.i3dMappings)
					local v34 = {}
					ObjectChangeUtil.loadObjectChangeFromXML(p5.xmlFile, v19, v34, p5.components, p5)
					ObjectChangeUtil.setObjectChanges(v34, false, p5, p5.setMovingToolDirty)
					local v35 = {
						["id"] = v18 + 1,
						["startNode"] = v20,
						["endNode"] = v21,
						["offsetLeft"] = v24,
						["offsetRight"] = v25,
						["offset"] = v26,
						["height"] = v27,
						["mesh"] = nil,
						["intersectionNodes"] = v29,
						["changeObjects"] = v34,
						["linkNode"] = v32,
						["jointNode"] = v33,
						["dummy"] = nil,
						["objectsToMount"] = nil
					}
					v6.singleBelts[v35] = v35
					local v36 = v6.sortedBelts
					table.insert(v36, v35)
				else
					Logging.xmlWarning(p5.xmlFile, "x and y position of endNode need to be 0 for tension belt \'" .. v19 .. "\'")
				end
			end
			v18 = v18 + 1
		end
		local v37 = (1 / 0)
		local v38 = (1 / 0)
		local v39 = (-1 / 0)
		local v40 = (-1 / 0)
		for _, v41 in pairs(v6.singleBelts) do
			local v42, _, v43 = localToLocal(v41.startNode, v6.interactionBaseNode, 0, 0, 0)
			local v44, _, v45 = localToLocal(v41.endNode, v6.interactionBaseNode, 0, 0, 0)
			v37 = math.min(v37, v42, v44)
			v38 = math.min(v38, v43, v45)
			v39 = math.max(v39, v42, v44)
			v40 = math.max(v40, v43, v45)
		end
		v6.interactionBasePointX = (v39 + v37) / 2
		v6.interactionBasePointZ = (v40 + v38) / 2
		for _, v46 in pairs(v6.singleBelts) do
			local v47, _, v48 = localToLocal(v46.startNode, v6.interactionBaseNode, 0, 0, 0)
			local v49 = MathUtil.vector2Length(v6.interactionBasePointX - v47, v6.interactionBasePointZ - v48) + 1
			local v50 = MathUtil.vector2Length(v6.interactionBasePointX - v47, v6.interactionBasePointZ - v48) + 1
			local v51 = v6.totalInteractionRadius
			v6.totalInteractionRadius = math.max(v51, v49, v50)
		end
	end
	v6.hasTensionBelts = #v6.sortedBelts > 0
	v6.checkBoxes = {}
	v6.objectsToJoint = {}
	v6.isPlayerInRange = false
	v6.currentBelt = nil
	v6.areAllBeltsFastened = false
	v6.fastenedAllBeltsIndex = -1
	v6.fastenedAllBeltsState = true
	if p5.isClient then
		v6.samples = {}
		v6.samples.toggleBelt = g_soundManager:loadSampleFromXML(p5.xmlFile, v8 .. ".sounds", "toggleBelt", p5.baseDirectory, p5.components, 1, AudioGroup.VEHICLE, p5.i3dMappings, p5)
		v6.samples.addBelt = g_soundManager:loadSampleFromXML(p5.xmlFile, v8 .. ".sounds", "addBelt", p5.baseDirectory, p5.components, 1, AudioGroup.VEHICLE, p5.i3dMappings, p5)
		v6.samples.removeBelt = g_soundManager:loadSampleFromXML(p5.xmlFile, v8 .. ".sounds", "removeBelt", p5.baseDirectory, p5.components, 1, AudioGroup.VEHICLE, p5.i3dMappings, p5)
	end
	v6.texts = {}
	v6.texts.warningFoldingTensionBelts = g_i18n:getText("warning_foldingNotWhileTensionBeltsFasten")
	if v6.hasTensionBelts then
		g_messageCenter:subscribe(MessageType.TREE_SHAPE_CUT, p5.onTensionBeltTreeShapeCut, p5)
	else
		SpecializationUtil.removeEventListener(p5, "onPostLoad", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onDelete", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onPreDelete", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onReadStream", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onWriteStream", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onUpdate", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onUpdateTick", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onDraw", TensionBelts)
		SpecializationUtil.removeEventListener(p5, "onRegisterActionEvents", TensionBelts)
		if v6.activationTrigger ~= nil then
			removeTrigger(v6.activationTrigger)
			v6.activationTrigger = nil
			return
		end
	end
end
function TensionBelts.onPostLoad(p52, p53)
	if p53 ~= nil then
		local v54 = p52.spec_tensionBelts
		v54.beltsToLoad = {}
		local v55 = 0
		while true do
			local v56 = string.format("%s.tensionBelts.belt(%d)", p53.key, v55)
			if not p53.xmlFile:hasProperty(v56) then
				break
			end
			if p53.xmlFile:getValue(v56 .. "#isActive") then
				local v57 = v54.beltsToLoad
				local v58 = v55 + 1
				table.insert(v57, v58)
			end
			v55 = v55 + 1
		end
	end
end
function TensionBelts.saveToXMLFile(p59, p60, p61, _)
	local v62 = p59.spec_tensionBelts
	if v62.hasTensionBelts then
		for v63, v64 in ipairs(v62.sortedBelts) do
			p60:setValue(string.format("%s.belt(%d)", p61, v63 - 1) .. "#isActive", v64.mesh ~= nil)
		end
	end
end
function TensionBelts.onPreDelete(p65)
	if p65.spec_tensionBelts.sortedBelts ~= nil then
		for _, v66 in pairs(p65.spec_tensionBelts.sortedBelts) do
			local v67, _ = p65:getObjectToMount(v66)
			for v68, _ in pairs(v67) do
				I3DUtil.wakeUpObject(v68)
			end
		end
	end
end
function TensionBelts.onDelete(p69)
	local v70 = p69.spec_tensionBelts
	v70.isPlayerInRange = false
	g_currentMission.activatableObjectsSystem:removeActivatable(v70.activatable)
	p69:setTensionBeltsActive(false, nil, true, false)
	if v70.activationTrigger ~= nil then
		removeTrigger(v70.activationTrigger)
		v70.activationTrigger = nil
	end
	g_soundManager:deleteSamples(v70.samples)
end
function TensionBelts.onReadStream(p71, p72, _)
	local v73 = p71.spec_tensionBelts
	if v73.tensionBelts ~= nil then
		v73.beltsToLoad = {}
		for v74, _ in ipairs(v73.sortedBelts) do
			if streamReadBool(p72) then
				local v75 = v73.beltsToLoad
				table.insert(v75, v74)
			end
		end
	end
end
function TensionBelts.onWriteStream(p76, p77, _)
	local v78 = p76.spec_tensionBelts
	if v78.tensionBelts ~= nil then
		for _, v79 in ipairs(v78.sortedBelts) do
			streamWriteBool(p77, v79.mesh ~= nil)
		end
	end
end
function TensionBelts.onUpdate(p80, _, _, _, _)
	local v81 = p80.spec_tensionBelts
	if v81.beltsToLoad ~= nil then
		if #v81.beltsToLoad > 0 then
			local v82 = v81.beltsToLoad[#v81.beltsToLoad]
			local v83 = not p80.isServer
			p80:setTensionBeltsActive(true, v81.sortedBelts[v82].id, v83, false)
			table.remove(v81.beltsToLoad, #v81.beltsToLoad)
		else
			v81.beltsToLoad = nil
		end
	end
	if p80.isServer and v81.isDynamic then
		local v84, v85, v86 = localToLocal(v81.linkNode, v81.jointNode, 0, 0, 0)
		local v87, v88, v89 = localRotationToLocal(v81.linkNode, v81.jointNode, 0, 0, 0)
		local v90 = false
		local v91 = v84 - v81.linkNodePosition[1]
		local v92
		if math.abs(v91) > 0.001 then
			v92 = true
		else
			local v93 = v85 - v81.linkNodePosition[2]
			if math.abs(v93) > 0.001 then
				v92 = true
			else
				local v94 = v86 - v81.linkNodePosition[3]
				if math.abs(v94) > 0.001 then
					v92 = true
				else
					local v95 = v87 - v81.linkNodeRotation[1]
					if math.abs(v95) > 0.001 then
						v92 = true
					else
						local v96 = v88 - v81.linkNodeRotation[2]
						if math.abs(v96) > 0.001 then
							v92 = true
						else
							local v97 = v89 - v81.linkNodeRotation[3]
							v92 = math.abs(v97) > 0.001 and true or v90
						end
					end
				end
			end
		end
		if v92 then
			local v98 = v81.linkNodePosition
			local v99 = v81.linkNodePosition
			local v100 = v81.linkNodePosition
			v98[1] = v84
			v99[2] = v85
			v100[3] = v86
			local v101 = v81.linkNodeRotation
			local v102 = v81.linkNodeRotation
			local v103 = v81.linkNodeRotation
			v101[1] = v87
			v102[2] = v88
			v103[3] = v89
			for _, v104 in pairs(v81.objectsToJoint) do
				setJointFrame(v104.jointIndex, 0, v104.jointTransform)
			end
		end
	end
	if p80.isClient and v81.fastenedAllBeltsIndex > 0 then
		local v105 = v81.sortedBelts[v81.fastenedAllBeltsIndex]
		if v105 ~= nil then
			p80:setTensionBeltsActive(v81.fastenedAllBeltsState, v105.id, false)
		end
		v81.fastenedAllBeltsIndex = v81.fastenedAllBeltsIndex + 1
		if v81.fastenedAllBeltsIndex > #v81.sortedBelts then
			v81.fastenedAllBeltsIndex = -1
		end
	end
	if TensionBelts.debugRendering then
		for v106, _ in pairs(v81.belts) do
			DebugGizmo.renderAtNode(v106, v106.id, false, 0.5)
			for v107 = 0, getNumOfChildren(v106) - 1 do
				DebugGizmo.renderAtNode(getChildAt(v106, v107), string.format("%s-%d", v106.id, v107), false, 0.2)
			end
		end
		if v81.checkBoxes ~= nil then
			for _, v108 in pairs(v81.checkBoxes) do
				local v109 = v108.points
				local v110 = v108.color
				drawDebugLine(v109[1][1], v109[1][2], v109[1][3], v110[1], v110[2], v110[3], v109[2][1], v109[2][2], v109[2][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[2][1], v109[2][2], v109[2][3], v110[1], v110[2], v110[3], v109[3][1], v109[3][2], v109[3][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[3][1], v109[3][2], v109[3][3], v110[1], v110[2], v110[3], v109[4][1], v109[4][2], v109[4][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[4][1], v109[4][2], v109[4][3], v110[1], v110[2], v110[3], v109[1][1], v109[1][2], v109[1][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[5][1], v109[5][2], v109[5][3], v110[1], v110[2], v110[3], v109[6][1], v109[6][2], v109[6][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[6][1], v109[6][2], v109[6][3], v110[1], v110[2], v110[3], v109[7][1], v109[7][2], v109[7][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[7][1], v109[7][2], v109[7][3], v110[1], v110[2], v110[3], v109[8][1], v109[8][2], v109[8][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[8][1], v109[8][2], v109[8][3], v110[1], v110[2], v110[3], v109[5][1], v109[5][2], v109[5][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[1][1], v109[1][2], v109[1][3], v110[1], v110[2], v110[3], v109[5][1], v109[5][2], v109[5][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[4][1], v109[4][2], v109[4][3], v110[1], v110[2], v110[3], v109[8][1], v109[8][2], v109[8][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[2][1], v109[2][2], v109[2][3], v110[1], v110[2], v110[3], v109[6][1], v109[6][2], v109[6][3], v110[1], v110[2], v110[3])
				drawDebugLine(v109[3][1], v109[3][2], v109[3][3], v110[1], v110[2], v110[3], v109[7][1], v109[7][2], v109[7][3], v110[1], v110[2], v110[3])
				drawDebugPoint(v109[9][1], v109[9][2], v109[9][3], 1, 1, 1, 1)
			end
		end
		local v111, v112, v113 = localToWorld(v81.interactionBaseNode, v81.interactionBasePointX, 0, v81.interactionBasePointZ)
		drawDebugPoint(v111, v112, v113, 0, 0, 1, 1, false)
		for v114 = 0, 350, 10 do
			local v115 = localToWorld
			local v116 = v81.interactionBaseNode
			local v117 = v81.interactionBasePointX
			local v118 = math.rad(v114)
			local v119 = v117 + math.cos(v118) * v81.totalInteractionRadius
			local v120 = v81.interactionBasePointZ
			local v121 = math.rad(v114)
			local v122, v123, v124 = v115(v116, v119, 0, v120 + math.sin(v121) * v81.totalInteractionRadius)
			drawDebugPoint(v122, v123, v124, 1, 1, 1, 1)
			for _, v125 in pairs(v81.singleBelts) do
				local v126 = localToWorld
				local v127 = v125.startNode
				local v128 = math.rad(v114)
				local v129 = math.cos(v128) * v81.interactionRadius
				local v130 = math.rad(v114)
				local v131, v132, v133 = v126(v127, v129, 0, math.sin(v130) * v81.interactionRadius)
				drawDebugPoint(v131, v132, v133, 0, 1, 0, 1)
				local v134 = localToWorld
				local v135 = v125.endNode
				local v136 = math.rad(v114)
				local v137 = math.cos(v136) * v81.interactionRadius
				local v138 = math.rad(v114)
				local v139, v140, v141 = v134(v135, v137, 0, math.sin(v138) * v81.interactionRadius)
				drawDebugPoint(v139, v140, v141, 1, 0, 0, 1)
			end
		end
	end
	if v81.isPlayerInTrigger or v81.isPlayerInRange then
		p80:raiseActive()
	end
	local v142 = v81.isPlayerInRange
	local v143, v144 = p80:getIsPlayerInTensionBeltsRange()
	v81.isPlayerInRange = v143
	if v81.isPlayerInRange then
		if v144 ~= v81.currentBelt then
			if v81.currentBelt ~= nil and v81.currentBelt.dummy ~= nil then
				delete(v81.currentBelt.dummy)
				v81.currentBelt.dummy = nil
			end
			v81.currentBelt = v144
			if v81.currentBelt ~= nil and v81.currentBelt.mesh == nil then
				local v145, _ = p80:getObjectToMount(v81.currentBelt)
				p80:createTensionBelt(v81.currentBelt, true, v145)
			end
		end
		g_currentMission.activatableObjectsSystem:addActivatable(v81.activatable)
		v81.activatable:updateActivateText()
	elseif v142 then
		g_currentMission.activatableObjectsSystem:removeActivatable(v81.activatable)
		if v81.currentBelt ~= nil and v81.currentBelt.dummy ~= nil then
			delete(v81.currentBelt.dummy)
			v81.currentBelt.dummy = nil
			v81.currentBelt = nil
		end
	end
end
function TensionBelts.onUpdateTick(p146, p147, _, _, _)
	local v148 = p146.spec_tensionBelts
	if not v148.hasTensionBelts then
		return
	end
	if p146.isServer and v148.tensionBelts ~= nil then
		v148.checkTimer = v148.checkTimer - p147
		if v148.checkTimer < 0 then
			local v149 = false
			for v150, _ in pairs(v148.objectsToJoint) do
				if not entityExists(v150) then
					v148.objectsToJoint[v150] = nil
					v149 = true
					break
				end
			end
			if v149 then
				p146:refreshTensionBelts()
			end
			v148.checkTimer = v148.checkTimerDuration
		end
	end
end
function TensionBelts.onDraw(p151, _, p152, p153)
	local v154 = p151.spec_tensionBelts
	if v154.hasTensionBelts then
		if p152 and p153 then
			if v154.areAllBeltsFastened then
				g_inputBinding:setActionEventText(p151.toggleTensionBeltActionEvent, g_i18n:getText("action_unfastenTensionBelts"))
				return
			end
			g_inputBinding:setActionEventText(p151.toggleTensionBeltActionEvent, g_i18n:getText("action_fastenTensionBelts"))
		end
	end
end
function TensionBelts.refreshTensionBelts(p155)
	if p155.isServer and g_server ~= nil then
		g_server:broadcastEvent(TensionBeltsRefreshEvent.new(p155), nil, nil, p155)
	end
	for _, v156 in pairs(p155.spec_tensionBelts.sortedBelts) do
		if v156.mesh ~= nil then
			p155:removeTensionBelt(v156)
			local v157, _ = p155:getObjectToMount(v156)
			p155:createTensionBelt(v156, false, v157)
		end
	end
end
function TensionBelts.freeTensionBeltObject(p158, p159, p160, _, p161)
	if entityExists(p159) then
		local v162 = p160[p159]
		if v162.jointIndex == nil then
			local v163
			if v162 == nil then
				v163 = nil
			else
				v163 = v162.parent
			end
			if v163 == nil or entityExists(v163) then
				if v163 == nil then
					v163 = getRootNode()
				end
				local v164, v165, v166 = getWorldTranslation(p159)
				local v167, v168, v169 = getWorldRotation(p159)
				if p161 == nil or p161.unmountKinematic == nil then
					if p158.isServer then
						link(v163, p159)
						setWorldTranslation(p159, v164, v165, v166)
						setWorldRotation(p159, v167, v168, v169)
						setRigidBodyType(p159, RigidBodyType.DYNAMIC)
					end
				else
					p161:unmountKinematic()
				end
			else
				delete(p159)
			end
		elseif p158.isServer and v162 ~= nil then
			removeJoint(v162.jointIndex)
			delete(v162.jointTransform)
			if getSplitType(p159) ~= 0 then
				setInertiaScale(p159, 1, 1, 1)
			end
			if v162.objectMass ~= nil then
				setMass(p159, v162.objectMass)
				p158:setMassDirty()
			end
			if p161 ~= nil then
				if p161.setReducedComponentMass ~= nil then
					p161:setReducedComponentMass(false)
					p158:setMassDirty()
				end
				if p161.setCanBeSold ~= nil then
					p161:setCanBeSold(true)
				end
				if p161.setDynamicMountType ~= nil then
					p161:setDynamicMountType(MountableObject.MOUNT_TYPE_NONE)
				end
			end
		end
		if getSplitType(p159) ~= 0 then
			setUserAttribute(p159, "isTensionBeltMounted", UserAttributeType.BOOLEAN, false)
		end
	end
	p160[p159] = nil
end
function TensionBelts.lockTensionBeltObject(p170, p171, p172, p173, p174, p175)
	if p172[p171] == nil then
		local v176 = false
		local v177 = false
		local v178 = false
		if p173 then
			if p170.isServer then
				v176 = true
			end
		elseif p175 == nil or p175.mountKinematic == nil then
			if p170.isServer then
				v178 = true
			end
		else
			local v179 = (p175.getSupportsMountKinematic == nil or p175:getSupportsMountKinematic()) and true or false
			if p175.rootVehicle ~= nil and #p175.rootVehicle.childVehicles > 1 then
				v179 = false
			end
			if v179 then
				v177 = true
			else
				v176 = true
			end
		end
		if v176 then
			local v180 = JointConstructor.new()
			v180:setActors(p174, p171)
			local v181 = createTransformGroup("tensionBeltJoint")
			link(p174, v181)
			local v182, v183, v184 = localToWorld(p171, getCenterOfMass(p171))
			setWorldTranslation(v181, v182, v183, v184)
			v180:setJointTransforms(v181, v181)
			v180:setEnableCollision(true)
			v180:setRotationLimit(0, 0, 0)
			v180:setRotationLimit(1, 0, 0)
			v180:setRotationLimit(2, 0, 0)
			v180:setRotationLimitSpring(1000, 10, 1000, 10, 1000, 10)
			v180:setTranslationLimitSpring(1000, 10, 1000, 10, 1000, 10)
			local v185 = v180:finalize()
			local v186 = nil
			if p175 == nil then
				v186 = getMass(p171)
				if v186 > 0.01 then
					setMass(p171, 0.01)
					p170:setMassDirty()
				else
					v186 = nil
				end
			else
				if p175.setReducedComponentMass ~= nil and p175:getAllowComponentMassReduction() then
					p175:setReducedComponentMass(true)
					p170:setMassDirty()
				end
				if p175.setCanBeSold ~= nil then
					p175:setCanBeSold(false)
				end
				if p175.setDynamicMountType ~= nil then
					p175:setDynamicMountType(MountableObject.MOUNT_TYPE_DYNAMIC, true)
				end
			end
			if getSplitType(p171) ~= 0 then
				setInertiaScale(p171, 20, 20, 20)
			end
			p172[p171] = {
				["jointIndex"] = v185,
				["jointTransform"] = v181,
				["object"] = p175,
				["objectMass"] = v186
			}
		elseif v177 then
			local v187 = getParent(p171)
			local v188, v189, v190 = localToLocal(p171, p174, 0, 0, 0)
			local v191, v192, v193 = localRotationToLocal(p171, p174, 0, 0, 0)
			p175:mountKinematic(p170, p174, v188, v189, v190, v191, v192, v193)
			p172[p171] = {
				["parent"] = v187,
				["object"] = p175
			}
		elseif v178 then
			local v194 = getParent(p171)
			local v195, v196, v197 = localToLocal(p171, p174, 0, 0, 0)
			local v198, v199, v200 = localRotationToLocal(p171, p174, 0, 0, 0)
			setRigidBodyType(p171, RigidBodyType.KINEMATIC)
			link(p174, p171)
			setTranslation(p171, v195, v196, v197)
			setRotation(p171, v198, v199, v200)
			p172[p171] = {
				["parent"] = v194,
				["object"] = p175
			}
		end
		if getSplitType(p171) ~= 0 then
			setUserAttribute(p171, "isTensionBeltMounted", UserAttributeType.BOOLEAN, true)
			g_messageCenter:publish(MessageType.TREE_SHAPE_MOUNTED, p171, p170)
		end
	end
end
function TensionBelts.setTensionBeltsActive(p201, p202, p203, p204, p205)
	local v206 = p201.spec_tensionBelts
	if v206.tensionBelts ~= nil then
		TensionBeltsEvent.sendEvent(p201, p202, p203, p204)
		local v207
		if p203 == nil then
			v207 = nil
		else
			v207 = v206.sortedBelts[p203]
		end
		if p202 then
			local v208, _ = p201:getObjectToMount(v207)
			if v207 == nil then
				for _, v209 in pairs(v206.singleBelts) do
					if v209.mesh == nil then
						p201:createTensionBelt(v209, false, v208, p205)
					end
				end
			elseif v207.mesh == nil then
				p201:createTensionBelt(v207, false, v208, p205)
			end
			for _, v210 in pairs(v208) do
				p201:lockTensionBeltObject(v210.physics, v206.objectsToJoint, v206.isDynamic, v207.jointNode or v206.jointNode, v210.object)
				if v210.object ~= nil then
					v210.object.tensionMountObject = p201
				end
			end
		else
			if v207 == nil then
				for _, v211 in pairs(v206.singleBelts) do
					p201:removeTensionBelt(v211, p205)
				end
			else
				p201:removeTensionBelt(v207, p205)
			end
			local v212, _ = p201:getObjectsToUnmount(v207)
			for v213, v214 in pairs(v212) do
				p201:freeTensionBeltObject(v213, v206.objectsToJoint, v206.isDynamic, v214.object)
				if v214.object ~= nil then
					v214.object.tensionMountObject = nil
				end
			end
		end
		if v207 ~= nil then
			ObjectChangeUtil.setObjectChanges(v207.changeObjects, p202, p201, p201.setMovingToolDirty)
		end
		p201:updateFastenState()
	end
end
function TensionBelts.setAllTensionBeltsActive(p215, p216, p217)
	local v218 = p215.spec_tensionBelts
	if v218.hasTensionBelts then
		local v219 = Utils.getNoNil(p216, not v218.areAllBeltsFastened)
		for _, v220 in pairs(v218.sortedBelts) do
			p215:setTensionBeltsActive(v219, v220.id, p217)
		end
	end
end
function TensionBelts.updateFastenState(p221)
	local v222 = p221.spec_tensionBelts
	local v223 = false
	for _, v224 in pairs(v222.singleBelts) do
		if v224.mesh == nil then
			v223 = true
			break
		end
	end
	v222.areAllBeltsFastened = not v223
end
function TensionBelts.createTensionBelt(p225, p226, p227, p228, p229)
	local v230 = p225.spec_tensionBelts
	local v231 = TensionBeltGeometryConstructor.new()
	local v232 = v230.beltData
	local v233 = v230.width or v232.width
	v231:setWidth(v233)
	v231:setMaxEdgeLength(v230.maxEdgeLength)
	if p227 then
		v231:setMaterial(v232.dummyMaterial.materialId)
		v231:setUVscale(v232.dummyMaterial.uvScale)
	else
		v231:setMaterial(v232.material.materialId)
		v231:setUVscale(v232.material.uvScale)
	end
	local v234, v235
	if v230.ratchetPosition == nil or v232.ratchet == nil then
		v234 = 0
		v235 = 0
	else
		v234 = v230.ratchetPosition
		v235 = v230.ratchetPosition + v232.ratchet.sizeRatio * v233
		v231:addAttachment(0, v230.ratchetPosition, v232.ratchet.sizeRatio * v233)
	end
	local v236, v237
	if v230.useHooks and v232.hook ~= nil then
		v236 = v232.hook.sizeRatio * v233
		v231:addAttachment(0, v236, 0)
		v237 = (v232.hook2 or v232.hook).sizeRatio * v233
		v231:addAttachment(1, -v237, 0)
	else
		v237 = 0
		v236 = 0
	end
	v231:setFixedPoints(p226.startNode, p226.endNode)
	v231:setGeometryBias(v230.geometryBias)
	v231:setLinkNode(p226.linkNode or v230.linkNode)
	for _, v238 in pairs(p226.intersectionNodes) do
		local v239, v240, v241 = getWorldTranslation(v238)
		local v242, v243, v244 = localDirectionToWorld(v238, 1, 0, 0)
		v231:addIntersectionPoint(v239, v240, v241, v242, v243, v244)
	end
	for _, v245 in pairs(p228) do
		for _, v246 in pairs(v245.visuals) do
			if getSplitType(v246) == 0 then
				v231:addShape(v246, 0, 10, 0, 10)
			else
				v231:addShape(v246, -100, 100, -100, 100)
			end
		end
	end
	local v247, _, v248 = v231:finalize()
	if v247 == 0 then
		return nil
	end
	if p227 then
		p226.dummy = v247
		return v247
	end
	local v249 = 0
	if v230.ratchetPosition ~= nil and (v232.ratchet ~= nil and v249 < getNumOfChildren(v247)) then
		local v250 = clone(v232.ratchet.node, false, false, false)
		link(getChildAt(v247, 0), v250)
		setTranslation(v250, 0, v230.geometryBias, 0)
		setScale(v250, v233, v233, v233)
		v249 = v249 + 1
	end
	if v230.useHooks and (v232.hook ~= nil and getNumOfChildren(v247) > v249 + 1) then
		local v251 = clone(v232.hook.node, false, false, false)
		link(getChildAt(v247, v249), v251)
		local v252 = v230.geometryBias
		local v253 = v236 / v230.maxEdgeLength
		local v254 = v252 * math.min(v253, 1)
		setTranslation(v251, 0, v254, 0)
		local v255, v256, v257 = getWorldTranslation(p226.startNode)
		local v258, v259, v260 = getWorldTranslation(v251)
		local v261, v262, v263 = worldDirectionToLocal(getParent(v251), v255 - v258, v256 - v259, v257 - v260)
		local v264, v265, v266 = localDirectionToLocal(v251, getParent(v251), 0, 1, 0)
		setDirection(v251, v261, v262, v263, v264, v265, v266)
		setScale(v251, v233, v233, v233)
		local v267 = v232.hook2 or v232.hook
		local v268 = clone(v267.node, false, false, false)
		link(getChildAt(v247, v249 + 1), v268)
		local v269 = v230.geometryBias
		local v270 = v237 / v230.maxEdgeLength
		local v271 = v269 * math.min(v270, 1)
		setTranslation(v268, 0, v271, 0)
		local v272, v273, v274 = getWorldTranslation(p226.endNode)
		local v275, v276, v277 = getWorldTranslation(v268)
		local v278, v279, v280 = worldDirectionToLocal(getParent(v268), v272 - v275, v273 - v276, v274 - v277)
		local v281, v282, v283 = localDirectionToLocal(v268, getParent(v268), 0, 1, 0)
		setDirection(v268, v278, v279, v280, v281, v282, v283)
		setScale(v268, v233, v233, v233)
	end
	setShaderParameter(v247, "beltClipOffsets", v236, v234, v235, v248 - v237, false)
	p226.mesh = v247
	v230.belts[v247] = v247
	if p226.dummy ~= nil then
		delete(p226.dummy)
		p226.dummy = nil
	end
	if p229 ~= false and p225.isClient then
		g_soundManager:playSample(v230.samples.toggleBelt)
		g_soundManager:playSample(v230.samples.addBelt)
	end
	return v247
end
function TensionBelts.removeTensionBelt(p284, p285, p286)
	if p285.mesh ~= nil then
		local v287 = p284.spec_tensionBelts
		v287.belts[p285.mesh] = nil
		delete(p285.mesh)
		p285.mesh = nil
		if v287.currentBelt == p285 then
			v287.currentBelt = nil
		end
		if p285.dummy == nil and (p286 ~= false and p284.isClient) then
			g_soundManager:playSample(v287.samples.toggleBelt)
			g_soundManager:playSample(v287.samples.removeBelt)
		end
	end
end
function TensionBelts.getObjectToMount(p288, p289)
	local v290 = p288.spec_tensionBelts
	local v291 = v290.startNode
	local v292 = v290.endNode
	local v293, v294, v295, v296
	if p289 == nil then
		v293 = nil
		v294 = nil
		v295 = nil
		v296 = nil
	else
		v291 = p289.startNode
		v292 = p289.endNode
		v293 = p289.offsetLeft
		v294 = p289.offsetRight
		v295 = p289.offset
		v296 = p289.height
		if v293 == nil and (v290.sortedBelts[p289.id - 1] ~= nil and v290.sortedBelts[p289.id - 1].mesh ~= nil) then
			local v297, _, _ = localToLocal(v291, v290.sortedBelts[p289.id - 1].startNode, 0, 0, 0)
			v293 = math.abs(v297)
		end
		if v294 == nil and (v290.sortedBelts[p289.id + 1] ~= nil and v290.sortedBelts[p289.id + 1].mesh ~= nil) then
			local v298, _, _ = localToLocal(v291, v290.sortedBelts[p289.id + 1].startNode, 0, 0, 0)
			v294 = math.abs(v298)
		end
	end
	if v293 == nil then
		v293 = v290.defaultOffsetSide
	end
	if v294 == nil then
		v294 = v290.defaultOffsetSide
	end
	if v295 == nil then
		v295 = v290.defaultOffset
	end
	if v296 == nil then
		v296 = v290.defaultHeight
	end
	local v299 = (v293 + v294) * 0.5
	local v300 = v296 * 0.5
	local _, _, v301 = localToLocal(v292, v291, 0, 0, 0)
	local v302 = v301 * 0.5 - 2 * v295
	local v303 = (v293 - v294) * 0.5
	local v304 = v296 * 0.5
	local v305 = v301 * 0.5
	local v306, v307, v308 = localToWorld(v291, v303, v304, v305)
	if TensionBelts.debugRendering then
		local v309 = {
			["points"] = {},
			["color"] = { math.random(0, 1), math.random(0, 1), (math.random(0, 1)) }
		}
		local v310, v311, v312 = localToWorld(v291, v303 - v299, v304 - v300, v305 - v302)
		local v313, v314, v315 = localToWorld(v291, v303 + v299, v304 - v300, v305 - v302)
		local v316, v317, v318 = localToWorld(v291, v303 - v299, v304 - v300, v305 + v302)
		local v319, v320, v321 = localToWorld(v291, v303 + v299, v304 - v300, v305 + v302)
		local v322, v323, v324 = localToWorld(v291, v303 - v299, v304 + v300, v305 - v302)
		local v325, v326, v327 = localToWorld(v291, v303 + v299, v304 + v300, v305 - v302)
		local v328, v329, v330 = localToWorld(v291, v303 - v299, v304 + v300, v305 + v302)
		local v331, v332, v333 = localToWorld(v291, v303 + v299, v304 + v300, v305 + v302)
		local v334 = v309.points
		table.insert(v334, { v310, v311, v312 })
		local v335 = v309.points
		table.insert(v335, { v313, v314, v315 })
		local v336 = v309.points
		table.insert(v336, { v319, v320, v321 })
		local v337 = v309.points
		table.insert(v337, { v316, v317, v318 })
		local v338 = v309.points
		table.insert(v338, { v322, v323, v324 })
		local v339 = v309.points
		table.insert(v339, { v325, v326, v327 })
		local v340 = v309.points
		table.insert(v340, { v331, v332, v333 })
		local v341 = v309.points
		table.insert(v341, { v328, v329, v330 })
		local v342 = v309.points
		table.insert(v342, { v306, v307, v308 })
		v290.checkBoxes[v291] = v309
	end
	local v343, v344, v345 = getWorldRotation(v291)
	table.clear(v290.objectsInTensionBeltRange)
	v290.numObjectsIntensionBeltRange = 0
	overlapBox(v306, v307, v308, v343, v344, v345, v299, v300, v302, "objectOverlapCallback", p288, CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.VEHICLE + CollisionFlag.TREE, true, true, false, true)
	return v290.objectsInTensionBeltRange, v290.numObjectsIntensionBeltRange
end
function TensionBelts.getObjectsToUnmount(p346, p347)
	local v348 = p346.spec_tensionBelts
	local v349 = {}
	local v350 = 0
	for v351, v352 in pairs(v348.objectsToJoint) do
		v349[v351] = {
			["objectId"] = v351,
			["object"] = v352.object
		}
		v350 = v350 + 1
	end
	for _, v353 in pairs(v348.singleBelts) do
		if v353.mesh ~= nil and v353 ~= p347 then
			local v354, _ = p346:getObjectToMount(v353)
			for _, v355 in pairs(v354) do
				if v349[v355.physics] ~= nil then
					v349[v355.physics] = nil
					v350 = v350 - 1
				end
			end
		end
	end
	return v349, v350
end
function TensionBelts.objectOverlapCallback(p356, p357)
	if p357 ~= 0 and getHasClassId(p357, ClassIds.SHAPE) then
		local v358 = p356.spec_tensionBelts
		local v359 = g_currentMission:getNodeObject(p357)
		if v359 == nil or (v359 == p356 or v359.rootVehicle == p356.rootVehicle) then
			if getSplitType(p357) ~= 0 then
				local v360 = getRigidBodyType(p357)
				if (v360 == RigidBodyType.DYNAMIC or v360 == RigidBodyType.KINEMATIC) and v358.objectsInTensionBeltRange[p357] == nil then
					v358.objectsInTensionBeltRange[p357] = {
						["physics"] = p357,
						["visuals"] = { p357 }
					}
					v358.numObjectsIntensionBeltRange = v358.numObjectsIntensionBeltRange + 1
				end
			end
		elseif v359.getSupportsTensionBelts ~= nil and (v359:getSupportsTensionBelts() and (v359.getMeshNodes ~= nil and v359.dynamicMountObject == nil)) then
			local v361 = v359:getTensionBeltNodeId()
			if v358.objectsInTensionBeltRange[v361] == nil then
				local v362 = v359:getMeshNodes()
				if v362 ~= nil then
					v358.objectsInTensionBeltRange[v361] = {
						["physics"] = v361,
						["visuals"] = v362,
						["object"] = v359
					}
					v358.numObjectsIntensionBeltRange = v358.numObjectsIntensionBeltRange + 1
				end
			end
		end
	end
	return true
end
function TensionBelts.getIsPlayerInTensionBeltsRange(p363)
	if g_localPlayer == nil then
		return false, nil
	end
	if not g_currentMission.accessHandler:canPlayerAccess(p363) then
		return false, nil
	end
	local v364 = p363.spec_tensionBelts
	if v364.beltData ~= nil then
		local v365, v366, v367 = getWorldTranslation(g_localPlayer.rootNode)
		local v368, v369, v370 = localToWorld(v364.interactionBaseNode, v364.interactionBasePointX, 0, v364.interactionBasePointZ)
		local v371 = nil
		local v372 = (1 / 0)
		if MathUtil.vector3Length(v365 - v368, v366 - v369, v367 - v370) < v364.totalInteractionRadius then
			if v364.tensionBelts ~= nil then
				for _, v373 in pairs(v364.singleBelts) do
					local v374, _, v375 = getWorldTranslation(v373.startNode)
					local v376, _, v377 = getWorldTranslation(v373.endNode)
					local v378 = MathUtil.vector2Length(v365 - v374, v367 - v375)
					local v379 = MathUtil.vector2Length(v365 - v376, v367 - v377)
					if v378 < v372 and v378 < v364.interactionRadius or v379 < v372 and v379 < v364.interactionRadius then
						v372 = math.min(v378, v379)
						v371 = v373
					end
				end
			end
			if v372 < v364.interactionRadius then
				return true, v371
			end
		end
	end
	return false, nil
end
function TensionBelts.getIsDynamicallyMountedNode(p380, p381)
	local v382 = p380.spec_tensionBelts
	if v382.objectsToJoint ~= nil then
		for v383, _ in pairs(v382.objectsToJoint) do
			if v383 == p381 then
				return true
			end
		end
	end
	return false
end
function TensionBelts.getIsReadyForAutomatedTrainTravel(p384, p385)
	local v386 = p384.spec_tensionBelts
	if v386.hasTensionBelts and v386.numObjectsIntensionBeltRange > 0 then
		return false
	else
		return p385(p384)
	end
end
function TensionBelts.getCanBeSelected(_, _)
	return true
end
function TensionBelts.getIsFoldAllowed(p387, p388, p389, p390)
	local v391 = p387.spec_tensionBelts
	if v391.hasTensionBelts and (not v391.allowFoldingWhileFasten and ((p389 or 1) >= 0 and v391.areAllBeltsFastened)) then
		return false, v391.texts.warningFoldingTensionBelts
	else
		return p388(p387, p389, p390)
	end
end
function TensionBelts.getFillLevelInformation(p392, p393, p394)
	p393(p392, p394)
	local v395 = p392.spec_tensionBelts
	if v395.hasTensionBelts then
		for _, v396 in pairs(v395.objectsToJoint) do
			local v397 = v396.object
			if v397 ~= nil then
				if v397.getFillLevelInformation == nil then
					if v397.getFillLevel ~= nil and v397.getFillType ~= nil then
						local v398 = v397:getFillType()
						local v399 = v397:getFillLevel()
						local v400
						if v397.getCapacity == nil then
							v400 = v399
						else
							v400 = v397:getCapacity()
						end
						p394:addFillLevel(v398, v399, v400)
					end
				else
					v397:getFillLevelInformation(p394)
				end
			end
		end
	end
end
function TensionBelts.getAdditionalComponentMass(p401, p402, p403)
	local v404 = p402(p401, p403)
	local v405 = p401.spec_tensionBelts
	if v405.hasTensionBelts and v405.jointComponent == p403.node then
		for _, v406 in pairs(v405.objectsToJoint) do
			local v407 = v406.object
			if v407 ~= nil and (v407.getAllowComponentMassReduction ~= nil and v407:getAllowComponentMassReduction()) then
				local v408 = v407:getDefaultMass() - 0.1
				v404 = v404 + math.max(v408, 0)
			end
			if v406.objectMass ~= nil then
				v404 = v404 + (v406.objectMass - 0.01)
			end
		end
	end
	return v404
end
function TensionBelts.onRegisterActionEvents(p409, _, p410)
	local v411 = p409.spec_tensionBelts
	if p409.isClient and v411.hasTensionBelts then
		p409:clearActionEventsTable(v411.actionEvents)
		if p410 then
			local _, v412 = p409:addActionEvent(v411.actionEvents, InputAction.TOGGLE_TENSION_BELTS, p409, TensionBelts.actionEventToggleTensionBelts, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v412, GS_PRIO_NORMAL)
			p409.toggleTensionBeltActionEvent = v412
		end
	end
end
function TensionBelts.tensionBeltActivationTriggerCallback(p413, _, p414, p415, p416, _, _)
	local v417 = p413.spec_tensionBelts
	if p413.isClient and (v417.hasTensionBelts and (p415 or p416)) and (g_localPlayer ~= nil and p414 == g_localPlayer.rootNode) then
		if p415 then
			p413:raiseActive()
			v417.isPlayerInTrigger = true
			return
		end
		v417.isPlayerInTrigger = false
	end
end
function TensionBelts.onTensionBeltTreeShapeCut(p418, p419, _)
	if p418.isServer then
		local v420 = p418.spec_tensionBelts
		for v421, _ in pairs(v420.objectsToJoint) do
			if v421 == p419 then
				p418:setAllTensionBeltsActive(false)
			end
		end
	end
end
TensionBeltsActivatable = {}
local v_u_422 = Class(TensionBeltsActivatable)
function TensionBeltsActivatable.new(p423)
	-- upvalues: (copy) v_u_422
	local v424 = v_u_422
	local v425 = setmetatable({}, v424)
	v425.object = p423
	v425.spec = p423.spec_tensionBelts
	v425.activateText = g_i18n:getText("action_fastenTensionBelt")
	return v425
end
function TensionBeltsActivatable.getIsActivatable(p426)
	return p426.spec.isPlayerInRange
end
function TensionBeltsActivatable.getDistance(p427, _, _, _)
	return p427.spec.currentBelt == nil and (1 / 0) or 0
end
function TensionBeltsActivatable.run(p428)
	if p428.spec.currentBelt ~= nil then
		if p428.spec.currentBelt.mesh == nil then
			p428.object:setTensionBeltsActive(true, p428.spec.currentBelt.id, false)
		else
			p428.object:setTensionBeltsActive(false, p428.spec.currentBelt.id, false)
		end
	end
	p428:updateActivateText()
end
function TensionBeltsActivatable.updateActivateText(p429)
	if p429.spec.currentBelt == nil or p429.spec.currentBelt.mesh == nil then
		p429.activateText = g_i18n:getText("action_fastenTensionBelt")
	else
		p429.activateText = g_i18n:getText("action_unfastenTensionBelt")
	end
end
function TensionBelts.actionEventToggleTensionBelts(p430, _, _, _, _)
	local v431 = p430.spec_tensionBelts
	v431.fastenedAllBeltsIndex = 1
	v431.fastenedAllBeltsState = not v431.areAllBeltsFastened
end
function TensionBelts.consoleCommandToggleTensionBeltDebugRendering(_)
	TensionBelts.debugRendering = not TensionBelts.debugRendering
	local v432 = TensionBelts.debugRendering
	return "TensionBeltsDebugRendering = " .. tostring(v432)
end
addConsoleCommand("gsTensionBeltDebug", "Toggles the debug tension belt rendering of the vehicle", "TensionBelts.consoleCommandToggleTensionBeltDebugRendering", nil)

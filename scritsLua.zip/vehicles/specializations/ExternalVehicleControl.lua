ExternalVehicleControl = {}
ExternalVehicleControl.FUNCTION_XML_PATH = "vehicle.externalVehicleControl.trigger(?).function(?)"
function ExternalVehicleControl.prerequisitesPresent(_)
	return true
end
function ExternalVehicleControl.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("ExternalVehicleControl")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.externalVehicleControl.trigger(?)#node", "Player trigger node")
	v1:register(XMLValueType.STRING, ExternalVehicleControl.FUNCTION_XML_PATH .. "#name", "Name of the function to be available")
	v1:setXMLSpecializationType()
end
function ExternalVehicleControl.registerEvents(p2)
	SpecializationUtil.registerEvent(p2, "onRegisterExternalActionEvents")
end
function ExternalVehicleControl.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "registerExternalActionEvent", ExternalVehicleControl.registerExternalActionEvent)
end
function ExternalVehicleControl.registerOverwrittenFunctions(_) end
function ExternalVehicleControl.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoadFinished", ExternalVehicleControl)
	SpecializationUtil.registerEventListener(p4, "onDelete", ExternalVehicleControl)
	SpecializationUtil.registerEventListener(p4, "onUpdateTick", ExternalVehicleControl)
end
function ExternalVehicleControl.onLoadFinished(p5, _)
	local v6 = p5.spec_externalVehicleControl
	v6.triggers = {}
	for _, v7 in p5.xmlFile:iterator("vehicle.externalVehicleControl.trigger") do
		local v8 = {
			["node"] = p5.xmlFile:getValue(v7 .. "#node", nil, p5.components, p5.i3dMappings)
		}
		if v8.node ~= nil then
			if not CollisionFlag.getHasMaskFlagSet(v8.node, CollisionFlag.PLAYER) then
				Logging.xmlWarning(p5.xmlFile, "Invalid collision mask flags set in \'%s\'. Player bit missing!", v7)
			end
			v8.vehicle = p5
			v8.isPlayerInRange = false
			v8.controlFunctions = {}
			v8.callbackId = addTrigger(v8.node, "onExternalVehicleControlTriggerCallback", v8, false, ExternalVehicleControl.onExternalVehicleControlTriggerCallback)
			for _, v9 in p5.xmlFile:iterator(v7 .. ".function") do
				local v10 = p5.xmlFile:getValue(v9 .. "#name")
				if v10 ~= nil then
					SpecializationUtil.raiseEvent(p5, "onRegisterExternalActionEvents", v8, v10, p5.xmlFile, v9)
				end
			end
			v8.activatable = ExternalVehicleControlActivatable.new(p5, v8)
			local v11 = v6.triggers
			table.insert(v11, v8)
		end
	end
	if #v6.triggers == 0 then
		SpecializationUtil.removeEventListener(p5, "onDelete", ExternalVehicleControl)
		SpecializationUtil.removeEventListener(p5, "onUpdateTick", ExternalVehicleControl)
	end
end
function ExternalVehicleControl.onDelete(p12)
	local v13 = p12.spec_externalVehicleControl
	if v13.triggers ~= nil then
		for _, v14 in ipairs(v13.triggers) do
			if v14.node ~= nil then
				removeTrigger(v14.node, v14.callbackId)
			end
			g_currentMission.activatableObjectsSystem:removeActivatable(v14.activatable)
		end
	end
end
function ExternalVehicleControl.onUpdateTick(p15, _, _, _, _)
	local v16 = p15.spec_externalVehicleControl
	for _, v17 in ipairs(v16.triggers) do
		if v17.isPlayerInRange then
			v17.activatable:updateText()
			p15:raiseActive()
		end
	end
end
function ExternalVehicleControl.registerExternalActionEvent(_, p18, _, p19, p20)
	local v21 = p18.controlFunctions
	table.insert(v21, {
		["registerFunc"] = p19,
		["updateFunc"] = p20
	})
end
function ExternalVehicleControl.onExternalVehicleControlTriggerCallback(p22, _, p23, p24, _, _)
	if g_localPlayer ~= nil and p23 == g_localPlayer.rootNode then
		if p24 then
			p22.isPlayerInRange = true
			p22.vehicle:raiseActive()
			p22.activatable:updateText()
			g_currentMission.activatableObjectsSystem:addActivatable(p22.activatable)
			return
		end
		p22.isPlayerInRange = false
		g_currentMission.activatableObjectsSystem:removeActivatable(p22.activatable)
	end
end
ExternalVehicleControlActivatable = {}
local v_u_25 = Class(ExternalVehicleControlActivatable)
function ExternalVehicleControlActivatable.new(p26, p27)
	-- upvalues: (copy) v_u_25
	local v28 = v_u_25
	local v29 = setmetatable({}, v28)
	v29.vehicle = p26
	v29.trigger = p27
	v29.activateText = ""
	v29:updateText()
	return v29
end
function ExternalVehicleControlActivatable.registerCustomInput(p30, p31)
	if p31 == PlayerInputComponent.INPUT_CONTEXT_NAME then
		for _, v32 in ipairs(p30.trigger.controlFunctions) do
			if v32.registerFunc ~= nil then
				v32:registerFunc(p30.vehicle)
			end
		end
	end
end
function ExternalVehicleControlActivatable.removeCustomInput(p33, _)
	for _, v34 in ipairs(p33.trigger.controlFunctions) do
		g_inputBinding:removeActionEventsByTarget(v34)
	end
end
function ExternalVehicleControlActivatable.getIsActivatable(p35)
	if g_currentMission.accessHandler:canPlayerAccess(p35.vehicle) then
		return p35.trigger.isPlayerInRange
	else
		return false
	end
end
function ExternalVehicleControlActivatable.run(_) end
function ExternalVehicleControlActivatable.getDistance(p36, p37, p38, p39)
	local v40, v41, v42 = getWorldTranslation(p36.trigger.node)
	return MathUtil.vector3Length(p37 - v40, p38 - v41, p39 - v42)
end
function ExternalVehicleControlActivatable.updateText(p43)
	for _, v44 in ipairs(p43.trigger.controlFunctions) do
		if v44.updateFunc ~= nil then
			v44:updateFunc(p43.vehicle)
		end
	end
end

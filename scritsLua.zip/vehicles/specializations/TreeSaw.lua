TreeSaw = {}
function TreeSaw.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(TurnOnVehicle, p1)
end
function TreeSaw.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("TreeSaw")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.treeSaw.sounds", "cut")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.treeSaw.sounds", "saw")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.treeSaw.animationNodes")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.treeSaw.effects")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.treeSaw.cutNode#node", "Cut node")
	v2:register(XMLValueType.FLOAT, "vehicle.treeSaw.cutNode#sizeY", "Size Y", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.treeSaw.cutNode#sizeZ", "Size Z", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.treeSaw.cutNode#lengthAboveThreshold", "Min. tree length above cut node", 0.3)
	v2:register(XMLValueType.FLOAT, "vehicle.treeSaw.cutNode#lengthBelowThreshold", "Min. tree length below cut node", 0.3)
	v2:register(XMLValueType.FLOAT, "vehicle.treeSaw.cutNode#timer", "Cut delay (sec.)", 1)
	v2:setXMLSpecializationType()
end
function TreeSaw.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onDelete", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onReadUpdateStream", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onWriteUpdateStream", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onUpdate", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onUpdateTick", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onDraw", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onDeactivate", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onTurnedOn", TreeSaw)
	SpecializationUtil.registerEventListener(p3, "onTurnedOff", TreeSaw)
end
function TreeSaw.onLoad(p4, _)
	local v5 = p4.spec_treeSaw
	XMLUtil.checkDeprecatedXMLElements(p4.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode", "vehicle.treeSaw.animationNodes.animationNode", "stumbCutter")
	XMLUtil.checkDeprecatedXMLElements(p4.xmlFile, "vehicle.treeSaw.cutParticleSystems.emitterShape(0)", "vehicle.treeSaw.effects.effectNode")
	XMLUtil.checkDeprecatedXMLElements(p4.xmlFile, "vehicle.treeSaw.sawSound", "vehicle.treeSaw.sounds.saw")
	XMLUtil.checkDeprecatedXMLElements(p4.xmlFile, "vehicle.treeSaw.cutSound", "vehicle.treeSaw.sounds.cut")
	if p4.isClient then
		v5.animationNodes = g_animationManager:loadAnimations(p4.xmlFile, "vehicle.treeSaw.animationNodes", p4.components, p4, p4.i3dMappings)
		v5.effects = g_effectManager:loadEffect(p4.xmlFile, "vehicle.treeSaw.effects", p4.components, p4, p4.i3dMappings)
		v5.samples = {}
		v5.samples.cut = g_soundManager:loadSampleFromXML(p4.xmlFile, "vehicle.treeSaw.sounds", "cut", p4.baseDirectory, p4.components, 0, AudioGroup.VEHICLE, p4.i3dMappings, p4)
		v5.samples.saw = g_soundManager:loadSampleFromXML(p4.xmlFile, "vehicle.treeSaw.sounds", "saw", p4.baseDirectory, p4.components, 0, AudioGroup.VEHICLE, p4.i3dMappings, p4)
	end
	v5.cutNode = p4.xmlFile:getValue("vehicle.treeSaw.cutNode#node", nil, p4.components, p4.i3dMappings)
	v5.cutSizeY = p4.xmlFile:getValue("vehicle.treeSaw.cutNode#sizeY", 1)
	v5.cutSizeZ = p4.xmlFile:getValue("vehicle.treeSaw.cutNode#sizeZ", 1)
	v5.lengthAboveThreshold = p4.xmlFile:getValue("vehicle.treeSaw.cutNode#lengthAboveThreshold", 0.3)
	v5.lengthBelowThreshold = p4.xmlFile:getValue("vehicle.treeSaw.cutNode#lengthBelowThreshold", 0.3)
	v5.cutTimerDuration = p4.xmlFile:getValue("vehicle.treeSaw.cutNode#timer", 1) * 1000
	v5.curSplitShape = nil
	v5.cutTimer = -1
	v5.isCutting = false
	v5.warnTreeNotOwned = false
end
function TreeSaw.onDelete(p6)
	local v7 = p6.spec_treeSaw
	g_effectManager:deleteEffects(v7.effects)
	g_soundManager:deleteSamples(v7.samples)
	g_animationManager:deleteAnimations(v7.animationNodes)
end
function TreeSaw.onReadUpdateStream(p8, p9, _, p10)
	if p10:getIsServer() then
		p8.spec_treeSaw.isCutting = streamReadBool(p9)
	end
end
function TreeSaw.onWriteUpdateStream(p11, p12, p13, _)
	if not p13:getIsServer() then
		local v14 = p11.spec_treeSaw
		streamWriteBool(p12, v14.isCutting)
	end
end
function TreeSaw.onUpdate(p15, p16, _, _, _)
	local v17 = p15.spec_treeSaw
	if p15.isServer then
		if v17.curSplitShape ~= nil and not entityExists(v17.curSplitShape) then
			v17.curSplitShape = nil
			if g_server ~= nil then
				v17.cutTimer = -1
			end
		end
		v17.isCutting = v17.curSplitShape ~= nil
		if v17.curSplitShape ~= nil then
			if v17.cutTimer > 0 then
				local v18 = v17.cutTimer - p16
				v17.cutTimer = math.max(v18, 0)
			end
			if v17.cutTimer == 0 then
				v17.cutTimer = -1
				local v19, v20, v21 = getWorldTranslation(v17.cutNode)
				local v22, v23, v24 = localDirectionToWorld(v17.cutNode, 1, 0, 0)
				local v25, v26, v27 = localDirectionToWorld(v17.cutNode, 0, 1, 0)
				ChainsawUtil.cutSplitShape(v17.curSplitShape, v19, v20, v21, v22, v23, v24, v25, v26, v27, v17.cutSizeY, v17.cutSizeZ, p15:getActiveFarm())
				v17.curSplitShape = nil
			end
		end
	end
	if p15.isClient then
		if v17.cutTimer > 0 then
			g_effectManager:setEffectTypeInfo(v17.effects, FillType.WOODCHIPS)
			g_effectManager:startEffects(v17.effects)
			if not g_soundManager:getIsSamplePlaying(v17.samples.cut) then
				g_soundManager:playSample(v17.samples.cut)
				return
			end
		else
			g_effectManager:stopEffects(v17.effects)
			if g_soundManager:getIsSamplePlaying(v17.samples.cut) then
				g_soundManager:stopSample(v17.samples.cut)
			end
		end
	end
end
function TreeSaw.onUpdateTick(p28, _, _, _, _)
	local v29 = p28.spec_treeSaw
	v29.warnTreeNotOwned = false
	if p28:getIsTurnedOn() and v29.cutNode ~= nil then
		local v30, v31, v32 = getWorldTranslation(v29.cutNode)
		local v33, v34, v35 = localDirectionToWorld(v29.cutNode, 1, 0, 0)
		local v36, v37, v38 = localDirectionToWorld(v29.cutNode, 0, 1, 0)
		if v29.curSplitShape == nil then
			local v39, _, _, _, _ = findSplitShape(v30, v31, v32, v33, v34, v35, v36, v37, v38, v29.cutSizeY, v29.cutSizeZ)
			if v39 ~= 0 then
				if g_currentMission.accessHandler:canFarmAccessLand(p28:getActiveFarm(), v30, v32) then
					v29.curSplitShape = v39
					v29.cutTimer = v29.cutTimerDuration
				else
					v29.warnTreeNotOwned = true
				end
			end
		end
		if v29.curSplitShape ~= nil then
			local v40, v41, v42, v43 = testSplitShape(v29.curSplitShape, v30, v31, v32, v33, v34, v35, v36, v37, v38, v29.cutSizeY, v29.cutSizeZ)
			if v40 == nil then
				v29.curSplitShape = nil
			else
				local _, v44, _ = localToLocal(v29.cutNode, v29.curSplitShape, 0, v40, v42)
				local v45 = v44 < 0.01
				local _, v46, _ = localToLocal(v29.cutNode, v29.curSplitShape, 0, v40, v43)
				local v47 = v45 or v46 < 0.01
				local _, v48, _ = localToLocal(v29.cutNode, v29.curSplitShape, 0, v41, v42)
				local v49 = v47 or v48 < 0.01
				local _, v50, _ = localToLocal(v29.cutNode, v29.curSplitShape, 0, v41, v43)
				if v49 or v50 < 0.01 then
					v29.curSplitShape = nil
				end
			end
		end
		if v29.curSplitShape ~= nil then
			local v51, v52 = getSplitShapePlaneExtents(v29.curSplitShape, v30, v31, v32, v33, v34, v35)
			if v52 < v29.lengthAboveThreshold or v51 < v29.lengthBelowThreshold then
				v29.curSplitShape = nil
			end
		end
		if v29.curSplitShape == nil and v29.cutTimer > -1 then
			v29.cutTimer = -1
		end
	end
end
function TreeSaw.onDraw(p53, _, _, _)
	local v54 = p53.spec_treeSaw
	if v54.isCutting then
		g_currentMission:addExtraPrintText(g_i18n:getText("info_cutting"))
	end
	if v54.warnTreeNotOwned then
		g_currentMission:showBlinkingWarning(g_i18n:getText("warning_youDontHaveAccessToThisLand"), 1000)
	end
end
function TreeSaw.onDeactivate(p55)
	local v56 = p55.spec_treeSaw
	v56.curSplitShape = nil
	v56.cutTimer = -1
end
function TreeSaw.onTurnedOn(p57)
	if p57.isClient then
		local v58 = p57.spec_treeSaw
		g_animationManager:startAnimations(v58.animationNodes)
		g_soundManager:playSample(v58.samples.saw)
	end
end
function TreeSaw.onTurnedOff(p59)
	local v60 = p59.spec_treeSaw
	v60.curSplitShape = nil
	v60.cutTimer = -1
	if p59.isClient then
		g_animationManager:stopAnimations(v60.animationNodes)
		g_effectManager:stopEffects(v60.effects)
		g_soundManager:stopSamples(v60.samples)
	end
end

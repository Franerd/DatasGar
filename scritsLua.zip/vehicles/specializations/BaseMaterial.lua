BaseMaterial = {}
function BaseMaterial.prerequisitesPresent(_)
	return true
end
function BaseMaterial.initSpecialization() end
function BaseMaterial.registerFunctions(_) end
function BaseMaterial.registerEventListeners(p1)
	SpecializationUtil.registerEventListener(p1, "onLoad", BaseMaterial)
end
function BaseMaterial.onLoad(p2, _)
	XMLUtil.checkDeprecatedXMLElements(p2.xmlFile, "vehicle.baseMaterial")
	XMLUtil.checkDeprecatedXMLElements(p2.xmlFile, "vehicle.baseMaterialConfigurations", "vehicle.designColorConfigurations")
	XMLUtil.checkDeprecatedXMLElements(p2.xmlFile, "vehicle.designMaterialConfigurations", "vehicle.designColorConfigurations")
	XMLUtil.checkDeprecatedXMLElements(p2.xmlFile, "vehicle.designMaterial2Configurations", "vehicle.designColorConfigurations")
	XMLUtil.checkDeprecatedXMLElements(p2.xmlFile, "vehicle.designMaterial3Configurations", "vehicle.designColorConfigurations")
end

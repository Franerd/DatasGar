Tedder = {}
function Tedder.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("tedder", false, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Tedder")
	v1:register(XMLValueType.STRING, "vehicle.tedder#fillTypeConverter", "Fill type converter name")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.tedder.effects.effect(?)")
	v1:register(XMLValueType.INT, "vehicle.tedder.effects.effect(?)#workAreaIndex", "Work area index", 1)
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.tedder.animationNodes")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. ".tedder#dropWindrowWorkAreaIndex", "Drop work area index", 1)
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".tedder#dropWindrowWorkAreaIndex", "Drop work area index", 1)
	v1:setXMLSpecializationType()
end
function Tedder.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(WorkArea, p2)
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p2)
	end
	return v3
end
function Tedder.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "preprocessTedderArea", Tedder.preprocessTedderArea)
	SpecializationUtil.registerFunction(p4, "processTedderArea", Tedder.processTedderArea)
	SpecializationUtil.registerFunction(p4, "processDropArea", Tedder.processDropArea)
end
function Tedder.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDirtMultiplier", Tedder.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", Tedder.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadWorkAreaFromXML", Tedder.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", Tedder.doCheckSpeedLimit)
end
function Tedder.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", Tedder)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", Tedder)
	SpecializationUtil.registerEventListener(p6, "onDelete", Tedder)
	SpecializationUtil.registerEventListener(p6, "onReadStream", Tedder)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", Tedder)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", Tedder)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", Tedder)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", Tedder)
	SpecializationUtil.registerEventListener(p6, "onStartWorkAreaProcessing", Tedder)
	SpecializationUtil.registerEventListener(p6, "onEndWorkAreaProcessing", Tedder)
	SpecializationUtil.registerEventListener(p6, "onDeactivate", Tedder)
	SpecializationUtil.registerEventListener(p6, "onTurnedOn", Tedder)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", Tedder)
	SpecializationUtil.registerEventListener(p6, "onAIFieldCourseSettingsInitialized", Tedder)
end
function Tedder.onLoad(p7, _)
	local v8 = p7.spec_tedder
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.tedder.animationNodes.animationNode", "tedder")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.tedder.sounds", "vehicle.turnOnVehicle.sounds.work")
	v8.fillTypeConverters = {}
	v8.fillTypeConvertersReverse = {}
	local v9 = p7.xmlFile:getValue("vehicle.tedder#fillTypeConverter")
	if v9 == nil then
		printWarning(string.format("Warning: Missing fill type converter in \'%s\'", p7.configFileName))
	else
		local v10 = g_fillTypeManager:getConverterDataByName(v9)
		if v10 ~= nil then
			for v11, v12 in pairs(v10) do
				v8.fillTypeConverters[v11] = v12
				if v8.fillTypeConvertersReverse[v12.targetFillTypeIndex] == nil then
					v8.fillTypeConvertersReverse[v12.targetFillTypeIndex] = {}
				end
				local v13 = v8.fillTypeConvertersReverse[v12.targetFillTypeIndex]
				table.insert(v13, v11)
			end
		end
	end
	if p7.isClient then
		v8.animationNodes = g_animationManager:loadAnimations(p7.xmlFile, "vehicle.tedder.animationNodes", p7.components, p7, p7.i3dMappings)
		v8.effects = {}
		v8.workAreaToEffects = {}
		local v14 = 0
		while true do
			local v15 = string.format("vehicle.tedder.effects.effect(%d)", v14)
			if not p7.xmlFile:hasProperty(v15) then
				break
			end
			local v16 = g_effectManager:loadEffect(p7.xmlFile, v15, p7.components, p7, p7.i3dMappings)
			if v16 ~= nil then
				local v17 = {
					["effects"] = v16,
					["workAreaIndex"] = p7.xmlFile:getValue(v15 .. "#workAreaIndex", 1),
					["activeTime"] = -1,
					["activeTimeDuration"] = 250,
					["isActive"] = false,
					["isActiveSent"] = false
				}
				local v18 = v8.effects
				table.insert(v18, v17)
			end
			v14 = v14 + 1
		end
	end
	v8.lastDroppedLiters = 0
	v8.stoneLastState = 0
	v8.stoneWearMultiplierData = g_currentMission.stoneSystem:getWearMultiplierByType("TEDDER")
	v8.fillTypesDirtyFlag = p7:getNextDirtyFlag()
	v8.effectDirtyFlag = p7:getNextDirtyFlag()
	if p7.addAIDensityHeightTypeRequirement ~= nil then
		p7:addAIDensityHeightTypeRequirement(FillType.GRASS_WINDROW)
	end
end
function Tedder.onPostLoad(p19, _)
	local v20 = p19.spec_tedder
	for v21 = #v20.effects, 1, -1 do
		local v22 = v20.effects[v21]
		local v23 = p19:getWorkAreaByIndex(v22.workAreaIndex)
		if v23 == nil then
			Logging.xmlWarning(p19.xmlFile, "Invalid workAreaIndex \'%d\' for effect \'vehicle.tedder.effects.effect(%d)\'!", v22.workAreaIndex, v21)
			local v24 = v20.effects
			table.insert(v24, v21)
		else
			v22.tedderWorkAreaFillTypeIndex = v23.tedderWorkAreaIndex
			if v20.workAreaToEffects[v23.index] == nil then
				v20.workAreaToEffects[v23.index] = {}
			end
			local v25 = v20.workAreaToEffects[v23.index]
			table.insert(v25, v22)
		end
	end
	if not p19.isServer then
		SpecializationUtil.removeEventListener(p19, "onUpdateTick", Tedder)
	end
end
function Tedder.onDelete(p26)
	local v27 = p26.spec_tedder
	if v27.effects ~= nil then
		for _, v28 in ipairs(v27.effects) do
			g_effectManager:deleteEffects(v28.effects)
		end
	end
	g_animationManager:deleteAnimations(v27.animationNodes)
end
function Tedder.onReadStream(p29, p30, _)
	local v31 = p29.spec_tedder
	for v32, _ in ipairs(v31.tedderWorkAreaFillTypes) do
		local v33 = streamReadUIntN(p30, FillTypeManager.SEND_NUM_BITS)
		v31.tedderWorkAreaFillTypes[v32] = v33
	end
	for _, v34 in ipairs(v31.effects) do
		if streamReadBool(p30) then
			local v35 = v31.tedderWorkAreaFillTypes[v34.tedderWorkAreaFillTypeIndex]
			g_effectManager:setEffectTypeInfo(v34.effects, v35)
			g_effectManager:startEffects(v34.effects)
		else
			g_effectManager:stopEffects(v34.effects)
		end
	end
end
function Tedder.onWriteStream(p36, p37, _)
	local v38 = p36.spec_tedder
	for _, v39 in ipairs(v38.tedderWorkAreaFillTypes) do
		streamWriteUIntN(p37, v39, FillTypeManager.SEND_NUM_BITS)
	end
	for _, v40 in ipairs(v38.effects) do
		streamWriteBool(p37, v40.isActiveSent)
	end
end
function Tedder.onReadUpdateStream(p41, p42, _, p43)
	if p43:getIsServer() then
		local v44 = p41.spec_tedder
		if streamReadBool(p42) then
			for v45, _ in ipairs(v44.tedderWorkAreaFillTypes) do
				local v46 = streamReadUIntN(p42, FillTypeManager.SEND_NUM_BITS)
				v44.tedderWorkAreaFillTypes[v45] = v46
			end
		end
		if streamReadBool(p42) then
			for _, v47 in ipairs(v44.effects) do
				if streamReadBool(p42) then
					local v48 = v44.tedderWorkAreaFillTypes[v47.tedderWorkAreaFillTypeIndex]
					g_effectManager:setEffectTypeInfo(v47.effects, v48)
					g_effectManager:startEffects(v47.effects)
				else
					g_effectManager:stopEffects(v47.effects)
				end
			end
		end
	end
end
function Tedder.onWriteUpdateStream(p49, p50, p51, p52)
	if not p51:getIsServer() then
		local v53 = p49.spec_tedder
		if streamWriteBool(p50, bitAND(p52, v53.fillTypesDirtyFlag) ~= 0) then
			for _, v54 in ipairs(v53.tedderWorkAreaFillTypes) do
				streamWriteUIntN(p50, v54, FillTypeManager.SEND_NUM_BITS)
			end
		end
		if streamWriteBool(p50, bitAND(p52, v53.effectDirtyFlag) ~= 0) then
			for _, v55 in ipairs(v53.effects) do
				streamWriteBool(p50, v55.isActiveSent)
			end
		end
	end
end
function Tedder.onUpdateTick(p56, _, _, _, _)
	local v57 = p56.spec_tedder
	if p56.isServer then
		for _, v58 in ipairs(v57.effects) do
			if v58.isActive and g_currentMission.time > v58.activeTime then
				v58.isActive = false
				if v58.isActiveSent then
					v58.isActiveSent = false
					p56:raiseDirtyFlags(v57.effectDirtyFlag)
				end
				g_effectManager:stopEffects(v58.effects)
			end
		end
	end
end
function Tedder.loadWorkAreaFromXML(p59, p60, p61, p62, p63)
	local v64 = p60(p59, p61, p62, p63)
	if p61.type == WorkAreaType.DEFAULT then
		p61.type = WorkAreaType.TEDDER
	end
	if p61.type == WorkAreaType.TEDDER then
		p61.dropWindrowWorkAreaIndex = p62:getValue(p63 .. ".tedder#dropWindrowWorkAreaIndex", 1)
		p61.litersToDrop = 0
		p61.lastPickupLiters = 0
		p61.lastDropFillType = FillType.UNKNOWN
		p61.lastDroppedLiters = 0
		p61.tedderParticlesActive = false
		p61.tedderParticlesActiveSent = false
		local v65 = p59.spec_tedder
		if v65.tedderWorkAreaFillTypes == nil then
			v65.tedderWorkAreaFillTypes = {}
		end
		local v66 = v65.tedderWorkAreaFillTypes
		local v67 = FruitType.UNKNOWN
		table.insert(v66, v67)
		p61.tedderWorkAreaIndex = #v65.tedderWorkAreaFillTypes
	end
	return v64
end
function Tedder.getDirtMultiplier(p68, p69)
	local v70 = p68.spec_tedder
	local v71 = p69(p68)
	if v70.isWorking then
		v71 = v71 + p68:getWorkDirtMultiplier() * p68:getLastSpeed() / p68.speedLimit
	end
	return v71
end
function Tedder.getWearMultiplier(p72, p73)
	local v74 = p72.spec_tedder
	local v75 = p73(p72)
	if v74.isWorking then
		local v76 = (v74.stoneLastState == 0 or v74.stoneWearMultiplierData == nil) and 1 or (v74.stoneWearMultiplierData[v74.stoneLastState] or 1)
		v75 = v75 + p72:getWorkWearMultiplier() * p72:getLastSpeed() / p72.speedLimit * v76
	end
	return v75
end
function Tedder.doCheckSpeedLimit(p77, p78)
	local v79 = not p78(p77) and p77:getIsTurnedOn()
	if v79 then
		v79 = p77:getIsImplementChainLowered()
	end
	return v79
end
function Tedder.preprocessTedderArea(_, p80)
	p80.lastPickupLiters = 0
	p80.lastDroppedLiters = 0
end
function Tedder.processTedderArea(p81, p82, _)
	local v83 = p81.spec_tedder
	local v84 = p81.spec_workArea
	local v85, v86, v87 = getWorldTranslation(p82.start)
	local v88, v89, v90 = getWorldTranslation(p82.width)
	local v91, v92, v93 = getWorldTranslation(p82.height)
	local v94, v95, v96, v97, v98, v99, v100 = DensityMapHeightUtil.getLineByAreaDimensions(v85, v86, v87, v88, v89, v90, v91, v92, v93, true)
	for v105, v102 in pairs(v83.fillTypeConvertersReverse) do
		local v103 = 0
		for _, v104 in ipairs(v102) do
			v103 = v103 + DensityMapHeightUtil.tipToGroundAroundLine(p81, (-1 / 0), v104, v94, v95, v96, v97, v98, v99, v100, nil, nil, false, nil)
		end
		if v103 == 0 and p82.lastDropFillType ~= FillType.UNKNOWN then
			local v105 = p82.lastDropFillType
		end
		p82.lastPickupLiters = -v103
		p82.litersToDrop = p82.litersToDrop + p82.lastPickupLiters
		local v106 = v84.workAreas[p82.dropWindrowWorkAreaIndex]
		if v106 ~= nil and p82.litersToDrop > 0 then
			local v107 = p81:processDropArea(v106, v105, p82.litersToDrop)
			p82.lastDropFillType = v105
			p82.lastDroppedLiters = v107
			v83.lastDroppedLiters = v83.lastDroppedLiters + v107
			p82.litersToDrop = p82.litersToDrop - v107
			if p81.isServer then
				local v108 = p81:getLastSpeed(true)
				if v107 > 0 and v108 > 0.5 then
					local v109
					if v83.tedderWorkAreaFillTypes[p82.tedderWorkAreaIndex] == v105 then
						v109 = false
					else
						v83.tedderWorkAreaFillTypes[p82.tedderWorkAreaIndex] = v105
						p81:raiseDirtyFlags(v83.fillTypesDirtyFlag)
						v109 = true
					end
					local v110 = v83.workAreaToEffects[p82.index]
					if v110 ~= nil then
						for _, v111 in ipairs(v110) do
							v111.activeTime = g_currentMission.time + v111.activeTimeDuration
							if not v111.isActiveSent then
								v111.isActiveSent = true
								p81:raiseDirtyFlags(v83.effectDirtyFlag)
							end
							if v109 then
								g_effectManager:setEffectTypeInfo(v111.effects, v105)
							end
							if not v111.isActive then
								g_effectManager:setEffectTypeInfo(v111.effects, v105)
								g_effectManager:startEffects(v111.effects)
							end
							local v112 = g_effectManager
							local v113 = v111.effects
							local v114 = v108 / p81:getSpeedLimit()
							v112:setDensity(v113, (math.max(v114, 0.6)))
							v111.isActive = true
						end
					end
				end
			end
		end
	end
	if p81:getLastSpeed() > 0.5 then
		v83.stoneLastState = FSDensityMapUtil.getStoneArea(v85, v87, v88, v90, v91, v93)
	else
		v83.stoneLastState = 0
	end
	local v115 = MathUtil.vector3Length(v94 - v97, v95 - v98, v96 - v99) * p81.lastMovedDistance
	return v115, v115
end
function Tedder.processDropArea(p116, p117, p118, p119)
	local v120, v121, v122, v123, v124, v125, v126 = DensityMapHeightUtil.getLineByArea(p117.start, p117.width, p117.height, true)
	local v127, v128 = DensityMapHeightUtil.tipToGroundAroundLine(p116, p119, p118, v120, v121, v122, v123, v124, v125, v126, nil, p117.lineOffset, false, nil, false)
	p117.lineOffset = v128
	return v127
end
function Tedder.onStartWorkAreaProcessing(p129, _)
	p129.spec_tedder.lastDroppedLiters = 0
end
function Tedder.onEndWorkAreaProcessing(p130, _, _)
	local v131 = p130.spec_tedder
	v131.isWorking = v131.lastDroppedLiters > 0
end
function Tedder.onTurnedOn(p132)
	if p132.isClient then
		local v133 = p132.spec_tedder
		g_animationManager:startAnimations(v133.animationNodes)
	end
end
function Tedder.onTurnedOff(p134)
	if p134.isClient then
		local v135 = p134.spec_tedder
		g_animationManager:stopAnimations(v135.animationNodes)
		for _, v136 in ipairs(v135.effects) do
			g_effectManager:stopEffects(v136.effects)
		end
	end
end
function Tedder.onAIFieldCourseSettingsInitialized(_, p137)
	p137.headlandsFirst = true
	p137.workInitialSegment = true
end
function Tedder.onDeactivate(p138)
	if p138.isClient then
		local v139 = p138.spec_tedder
		for _, v140 in ipairs(v139.effects) do
			g_effectManager:stopEffects(v140.effects)
		end
	end
end
function Tedder.getDefaultSpeedLimit()
	return 15
end

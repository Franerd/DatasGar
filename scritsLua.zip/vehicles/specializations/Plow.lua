source("dataS/scripts/vehicles/specializations/events/PlowRotationEvent.lua")
source("dataS/scripts/vehicles/specializations/events/PlowLimitToFieldEvent.lua")
Plow = {}
Plow.AI_REQUIRED_GROUND_TYPES = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.CULTIVATED,
	FieldGroundType.SEEDBED,
	FieldGroundType.ROLLED_SEEDBED,
	FieldGroundType.RIDGE,
	FieldGroundType.SOWN,
	FieldGroundType.DIRECT_SOWN,
	FieldGroundType.PLANTED,
	FieldGroundType.RIDGE_SOWN,
	FieldGroundType.ROLLER_LINES,
	FieldGroundType.HARVEST_READY,
	FieldGroundType.HARVEST_READY_OTHER,
	FieldGroundType.GRASS,
	FieldGroundType.GRASS_CUT
}
Plow.AI_OUTPUT_GROUND_TYPES = { FieldGroundType.PLOWED }
function Plow.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("plow", g_i18n:getText("configuration_design"), "plow", VehicleConfigurationItem)
	g_workAreaTypeManager:addWorkAreaType("plow", true, true, true)
	g_workAreaTypeManager:addWorkAreaType("plowShare", true, false, false)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Plow")
	Plow.registerXMLPaths(v1, "vehicle.plow")
	Plow.registerXMLPaths(v1, "vehicle.plow.plowConfigurations.plowConfiguration(?)")
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#disableOnTurn", "Disable while turning", true)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#turnAnimLimit", "Turn animation limit", 0)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#turnAnimLimitSide", "Turn animation limit side", 0)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#invertDirectionOnRotation", "Invert direction on rotation", true)
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.BOOL, "vehicles.vehicle(?).plow#rotationMax", "Rotation max.")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).plow#turnAnimTime", "Turn animation time")
end
function Plow.registerXMLPaths(p3, p4)
	p3:register(XMLValueType.STRING, p4 .. ".rotationPart#turnAnimationName", "Turn animation name")
	p3:register(XMLValueType.FLOAT, p4 .. ".rotationPart#foldMinLimit", "Fold min. limit", 0)
	p3:register(XMLValueType.FLOAT, p4 .. ".rotationPart#foldMaxLimit", "Fold max. limit", 1)
	p3:register(XMLValueType.BOOL, p4 .. ".rotationPart#limitFoldRotationMax", "Block folding if in max state")
	p3:register(XMLValueType.FLOAT, p4 .. ".rotationPart#foldRotationMinLimit", "Fold allow if inbetween this limit", 0)
	p3:register(XMLValueType.FLOAT, p4 .. ".rotationPart#foldRotationMaxLimit", "Fold allow if inbetween this limit", 1)
	p3:register(XMLValueType.FLOAT, p4 .. ".rotationPart#rotationFoldMinLimit", "Rotation allow if fold time inbetween this limit", 0)
	p3:register(XMLValueType.FLOAT, p4 .. ".rotationPart#rotationFoldMaxLimit", "Rotation allow if fold time inbetween this limit", 1)
	p3:register(XMLValueType.FLOAT, p4 .. ".rotationPart#detachMinLimit", "Detach is allowed if turn animation between these values", 0)
	p3:register(XMLValueType.FLOAT, p4 .. ".rotationPart#detachMaxLimit", "Detach is allowed if turn animation between these values", 1)
	p3:register(XMLValueType.BOOL, p4 .. ".rotationPart#rotationAllowedIfLowered", "Allow plow rotation if lowered", true)
	p3:register(XMLValueType.L10N_STRING, p4 .. ".rotationPart#detachWarning", "Warning to be displayed if not in correct turn state for detach", "warning_detachNotAllowedPlowTurn")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".directionNode#node", "Plow direction node")
	p3:register(XMLValueType.FLOAT, p4 .. ".ai#centerPosition", "Center position", 0.5)
	p3:register(XMLValueType.FLOAT, p4 .. ".ai#rotateToCenterHeadlandPos", "Rotate to center headland position", 0.5)
	p3:register(XMLValueType.FLOAT, p4 .. ".ai#rotateCompletelyHeadlandPos", "Rotate completely headland position", 0.5)
	p3:register(XMLValueType.BOOL, p4 .. ".ai#stopDuringTurn", "Stop the vehicle while the plow is turning", true)
	p3:register(XMLValueType.BOOL, p4 .. ".ai#allowTurnWhileReversing", "Allow the turn of the plow while we are reversing", true)
	p3:register(XMLValueType.BOOL, p4 .. ".rotateLeftToMax#value", "Rotate left to max", true)
	p3:register(XMLValueType.BOOL, p4 .. ".onlyActiveWhenLowered#value", "Only active when lowered", true)
	SoundManager.registerSampleXMLPaths(p3, p4 .. ".sounds", "turn(?)")
	SoundManager.registerSampleXMLPaths(p3, p4 .. ".sounds", "work(?)")
end
function Plow.prerequisitesPresent(p5)
	return SpecializationUtil.hasSpecialization(WorkArea, p5)
end
function Plow.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "processPlowArea", Plow.processPlowArea)
	SpecializationUtil.registerFunction(p6, "processPlowShareArea", Plow.processPlowShareArea)
	SpecializationUtil.registerFunction(p6, "setRotationMax", Plow.setRotationMax)
	SpecializationUtil.registerFunction(p6, "setRotationCenter", Plow.setRotationCenter)
	SpecializationUtil.registerFunction(p6, "setPlowLimitToField", Plow.setPlowLimitToField)
	SpecializationUtil.registerFunction(p6, "getIsPlowRotationAllowed", Plow.getIsPlowRotationAllowed)
	SpecializationUtil.registerFunction(p6, "getCanTogglePlowRotation", Plow.getCanTogglePlowRotation)
	SpecializationUtil.registerFunction(p6, "getPlowLimitToField", Plow.getPlowLimitToField)
	SpecializationUtil.registerFunction(p6, "getPlowForceLimitToField", Plow.getPlowForceLimitToField)
	SpecializationUtil.registerFunction(p6, "setPlowAIRequirements", Plow.setPlowAIRequirements)
end
function Plow.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsFoldAllowed", Plow.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsFoldMiddleAllowed", Plow.getIsFoldMiddleAllowed)
	SpecializationUtil.registerOverwrittenFunction(p7, "getDirtMultiplier", Plow.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p7, "getWearMultiplier", Plow.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadSpeedRotatingPartFromXML", Plow.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsSpeedRotatingPartActive", Plow.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p7, "getSpeedRotatingPartDirection", Plow.getSpeedRotatingPartDirection)
	SpecializationUtil.registerOverwrittenFunction(p7, "doCheckSpeedLimit", Plow.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadWorkAreaFromXML", Plow.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsWorkAreaActive", Plow.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p7, "getCanAIImplementContinueWork", Plow.getCanAIImplementContinueWork)
	SpecializationUtil.registerOverwrittenFunction(p7, "getAIInvertMarkersOnTurn", Plow.getAIInvertMarkersOnTurn)
	SpecializationUtil.registerOverwrittenFunction(p7, "getCanBeSelected", Plow.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p7, "isDetachAllowed", Plow.isDetachAllowed)
	SpecializationUtil.registerOverwrittenFunction(p7, "getAllowsLowering", Plow.getAllowsLowering)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsAIReadyToDrive", Plow.getIsAIReadyToDrive)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsAIPreparingToDrive", Plow.getIsAIPreparingToDrive)
end
function Plow.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", Plow)
	SpecializationUtil.registerEventListener(p8, "onPostLoad", Plow)
	SpecializationUtil.registerEventListener(p8, "onDelete", Plow)
	SpecializationUtil.registerEventListener(p8, "onReadStream", Plow)
	SpecializationUtil.registerEventListener(p8, "onWriteStream", Plow)
	SpecializationUtil.registerEventListener(p8, "onUpdate", Plow)
	SpecializationUtil.registerEventListener(p8, "onRegisterActionEvents", Plow)
	SpecializationUtil.registerEventListener(p8, "onStartWorkAreaProcessing", Plow)
	SpecializationUtil.registerEventListener(p8, "onEndWorkAreaProcessing", Plow)
	SpecializationUtil.registerEventListener(p8, "onPostAttach", Plow)
	SpecializationUtil.registerEventListener(p8, "onPreDetach", Plow)
	SpecializationUtil.registerEventListener(p8, "onDeactivate", Plow)
	SpecializationUtil.registerEventListener(p8, "onAIFieldCourseSettingsInitialized", Plow)
	SpecializationUtil.registerEventListener(p8, "onAIImplementStartTurn", Plow)
	SpecializationUtil.registerEventListener(p8, "onAIImplementTurnProgress", Plow)
	SpecializationUtil.registerEventListener(p8, "onAIImplementSideOffsetChanged", Plow)
	SpecializationUtil.registerEventListener(p8, "onAIImplementEnd", Plow)
	SpecializationUtil.registerEventListener(p8, "onStartAnimation", Plow)
	SpecializationUtil.registerEventListener(p8, "onFinishAnimation", Plow)
	SpecializationUtil.registerEventListener(p8, "onFoldTimeChanged", Plow)
	SpecializationUtil.registerEventListener(p8, "onRootVehicleChanged", Plow)
end
function Plow.onLoad(p9, _)
	if p9:getGroundReferenceNodeFromIndex(1) == nil then
		printWarning("Warning: No ground reference nodes in " .. p9.configFileName)
	end
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.rotationPart", "vehicle.plow.rotationPart")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.ploughDirectionNode#index", "vehicle.plow.directionNode#node")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.rotateLeftToMax#value", "vehicle.plow.rotateLeftToMax#value")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.animTimeCenterPosition#value", "vehicle.plow.ai#centerPosition")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.aiPlough#rotateEarly", "vehicle.plow.ai#rotateCompletelyHeadlandPos")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.onlyActiveWhenLowered#value", "vehicle.plow.onlyActiveWhenLowered#value")
	local v10 = p9.configurations.plow or 1
	local v11 = string.format("vehicle.plow.plowConfigurations.plowConfiguration(%d)", v10 - 1)
	local v12 = not p9.xmlFile:hasProperty(v11) and "vehicle.plow" or v11
	local v13 = p9.spec_plow
	v13.rotationPart = {}
	v13.rotationPart.turnAnimation = p9.xmlFile:getValue(v12 .. ".rotationPart#turnAnimationName")
	v13.rotationPart.foldMinLimit = p9.xmlFile:getValue(v12 .. ".rotationPart#foldMinLimit", 0)
	v13.rotationPart.foldMaxLimit = p9.xmlFile:getValue(v12 .. ".rotationPart#foldMaxLimit", 1)
	v13.rotationPart.limitFoldRotationMax = p9.xmlFile:getValue(v12 .. ".rotationPart#limitFoldRotationMax")
	v13.rotationPart.foldRotationMinLimit = p9.xmlFile:getValue(v12 .. ".rotationPart#foldRotationMinLimit", 0)
	v13.rotationPart.foldRotationMaxLimit = p9.xmlFile:getValue(v12 .. ".rotationPart#foldRotationMaxLimit", 1)
	v13.rotationPart.rotationFoldMinLimit = p9.xmlFile:getValue(v12 .. ".rotationPart#rotationFoldMinLimit", 0)
	v13.rotationPart.rotationFoldMaxLimit = p9.xmlFile:getValue(v12 .. ".rotationPart#rotationFoldMaxLimit", 1)
	v13.rotationPart.detachMinLimit = p9.xmlFile:getValue(v12 .. ".rotationPart#detachMinLimit", 0)
	v13.rotationPart.detachMaxLimit = p9.xmlFile:getValue(v12 .. ".rotationPart#detachMaxLimit", 1)
	v13.rotationPart.rotationAllowedIfLowered = p9.xmlFile:getValue(v12 .. ".rotationPart#rotationAllowedIfLowered", true)
	v13.rotationPart.detachWarning = string.format(p9.xmlFile:getValue(v12 .. ".rotationPart#detachWarning", "warning_detachNotAllowedPlowTurn", p9.customEnvironment, false))
	v13.directionNode = p9.xmlFile:getValue(v12 .. ".directionNode#node", p9.components[1].node, p9.components, p9.i3dMappings)
	p9:setPlowAIRequirements()
	v13.ai = {}
	v13.ai.centerPosition = p9.xmlFile:getValue(v12 .. ".ai#centerPosition", 0.5)
	v13.ai.rotateToCenterHeadlandPos = p9.xmlFile:getValue(v12 .. ".ai#rotateToCenterHeadlandPos", 0.5)
	v13.ai.rotateCompletelyHeadlandPos = p9.xmlFile:getValue(v12 .. ".ai#rotateCompletelyHeadlandPos", 0.5)
	v13.ai.stopDuringTurn = p9.xmlFile:getValue(v12 .. ".ai#stopDuringTurn", true)
	v13.ai.allowTurnWhileReversing = p9.xmlFile:getValue(v12 .. ".ai#allowTurnWhileReversing", true)
	v13.ai.lastHeadlandPosition = 0
	v13.rotateLeftToMax = p9.xmlFile:getValue(v12 .. ".rotateLeftToMax#value", true)
	v13.onlyActiveWhenLowered = p9.xmlFile:getValue(v12 .. ".onlyActiveWhenLowered#value", true)
	v13.rotationMax = false
	v13.startActivationTimeout = 2000
	v13.startActivationTime = 0
	v13.lastPlowArea = 0
	v13.limitToField = true
	v13.forceLimitToField = false
	v13.wasTurnAnimationStopped = false
	v13.isWorking = false
	if p9.isClient then
		v13.samples = {}
		v13.samples.turn = g_soundManager:loadSamplesFromXML(p9.xmlFile, v12 .. ".sounds", "turn", p9.baseDirectory, p9.components, 0, AudioGroup.VEHICLE, p9.i3dMappings, p9)
		v13.samples.work = g_soundManager:loadSamplesFromXML(p9.xmlFile, v12 .. ".sounds", "work", p9.baseDirectory, p9.components, 0, AudioGroup.VEHICLE, p9.i3dMappings, p9)
		v13.isWorkSamplePlaying = false
	end
	v13.texts = {}
	v13.texts.warningFoldingLowered = g_i18n:getText("warning_foldingNotWhileLowered")
	v13.texts.warningFoldingPlowTurned = g_i18n:getText("warning_foldingNotWhilePlowTurned")
	v13.texts.turnPlow = g_i18n:getText("action_turnPlow")
	v13.texts.allowCreateFields = g_i18n:getText("action_allowCreateFields")
	v13.texts.limitToFields = g_i18n:getText("action_limitToFields")
	v13.workAreaParameters = {}
	v13.workAreaParameters.limitToField = p9:getPlowLimitToField()
	v13.workAreaParameters.forceLimitToField = p9:getPlowForceLimitToField()
	v13.workAreaParameters.angle = 0
	v13.workAreaParameters.lastChangedArea = 0
	v13.workAreaParameters.lastStatsArea = 0
	v13.workAreaParameters.lastTotalArea = 0
	if not p9.isClient then
		SpecializationUtil.removeEventListener(p9, "onUpdate", Plow)
	end
end
function Plow.onPostLoad(p14, p15)
	if p15 ~= nil and not p15.resetVehicles then
		local v16 = p15.xmlFile:getValue(p15.key .. ".plow#rotationMax")
		if v16 ~= nil and p14:getIsPlowRotationAllowed() then
			p14:setRotationMax(v16, true, (p15.xmlFile:getValue(p15.key .. ".plow#turnAnimTime")))
			if p14.updateCylinderedInitial ~= nil then
				p14:updateCylinderedInitial(false)
			end
		end
	end
end
function Plow.onDelete(p17)
	local v18 = p17.spec_plow
	if v18.samples ~= nil then
		g_soundManager:deleteSamples(v18.samples.turn)
		g_soundManager:deleteSamples(v18.samples.work)
	end
end
function Plow.saveToXMLFile(p19, p20, p21, _)
	local v22 = p19.spec_plow
	p20:setValue(p21 .. "#rotationMax", v22.rotationMax)
	if v22.rotationPart.turnAnimation ~= nil and p19.playAnimation ~= nil then
		local v23 = p19:getAnimationTime(v22.rotationPart.turnAnimation)
		p20:setValue(p21 .. "#turnAnimTime", v23)
	end
end
function Plow.onReadStream(p24, p25, _)
	local v26 = p24.spec_plow
	local v27 = streamReadBool(p25)
	local v28
	if v26.rotationPart.turnAnimation == nil or p24.playAnimation == nil then
		v28 = nil
	else
		v28 = streamReadFloat32(p25)
	end
	p24:setRotationMax(v27, true, v28)
	if p24.updateCylinderedInitial ~= nil then
		p24:updateCylinderedInitial(false)
	end
end
function Plow.onWriteStream(p29, p30, _)
	local v31 = p29.spec_plow
	streamWriteBool(p30, v31.rotationMax)
	if v31.rotationPart.turnAnimation ~= nil and p29.playAnimation ~= nil then
		local v32 = p29:getAnimationTime(v31.rotationPart.turnAnimation)
		streamWriteFloat32(p30, v32)
	end
end
function Plow.onUpdate(p33, _, _, _, _)
	if p33.isClient then
		local v34 = p33.spec_plow
		local v35 = v34.actionEvents[InputAction.IMPLEMENT_EXTRA3]
		if v35 ~= nil then
			if p33:getPlowForceLimitToField() or not g_currentMission:getHasPlayerPermission("createFields", p33:getOwnerConnection()) then
				g_inputBinding:setActionEventActive(v35.actionEventId, false)
			else
				g_inputBinding:setActionEventActive(v35.actionEventId, true)
				if p33:getPlowLimitToField() then
					g_inputBinding:setActionEventText(v35.actionEventId, v34.texts.allowCreateFields)
				else
					g_inputBinding:setActionEventText(v35.actionEventId, v34.texts.limitToFields)
				end
			end
		end
		if v34.rotationPart.turnAnimation ~= nil then
			local v36 = v34.actionEvents[InputAction.IMPLEMENT_EXTRA]
			if v36 ~= nil then
				g_inputBinding:setActionEventActive(v36.actionEventId, p33:getCanTogglePlowRotation())
			end
		end
	end
end
function Plow.processPlowArea(p37, p38, _)
	local v39 = p37.spec_plow
	local v40, _, v41 = getWorldTranslation(p38.start)
	local v42, _, v43 = getWorldTranslation(p38.width)
	local v44, _, v45 = getWorldTranslation(p38.height)
	local v46 = v39.workAreaParameters
	local v47, v48
	if p37.tailwaterDepth < 0.1 then
		local v49
		v49, v47 = FSDensityMapUtil.updatePlowArea(v40, v41, v42, v43, v44, v45, not v46.limitToField, v46.limitFruitDestructionToField, v46.angle)
		v48 = v49 + FSDensityMapUtil.updateVineCultivatorArea(v40, v41, v42, v43, v44, v45)
	else
		v48 = 0
		v47 = 0
	end
	v46.lastChangedArea = v46.lastChangedArea + v48
	v46.lastStatsArea = v46.lastStatsArea + v48
	v46.lastTotalArea = v46.lastTotalArea + v47
	FSDensityMapUtil.eraseTireTrack(v40, v41, v42, v43, v44, v45)
	v39.isWorking = p37:getLastSpeed() > 0.5
	return v48, v47
end
function Plow.processPlowShareArea(p50, p51, _)
	local v52 = p50.spec_plow.workAreaParameters
	local v53, _, v54 = getWorldTranslation(p51.start)
	local v55, _, v56 = getWorldTranslation(p51.width)
	local v57, _, v58 = getWorldTranslation(p51.height)
	FSDensityMapUtil.updatePlowShareArea(v53, v54, v55, v56, v57, v58, not v52.limitToField, v52.limitFruitDestructionToField, 0.5)
	return 0, 0
end
function Plow.setRotationMax(p59, p60, p61, p62)
	if p61 == nil or p61 == false then
		if g_server == nil then
			g_client:getServerConnection():sendEvent(PlowRotationEvent.new(p59, p60))
		else
			g_server:broadcastEvent(PlowRotationEvent.new(p59, p60), nil, nil, p59)
		end
	end
	local v63 = p59.spec_plow
	v63.rotationMax = p60
	if v63.rotationPart.turnAnimation ~= nil then
		if p62 == nil then
			local v64 = p59:getAnimationTime(v63.rotationPart.turnAnimation)
			if v63.rotationMax then
				p59:playAnimation(v63.rotationPart.turnAnimation, 1, v64, true)
			else
				p59:playAnimation(v63.rotationPart.turnAnimation, -1, v64, true)
			end
		end
		p59:setAnimationTime(v63.rotationPart.turnAnimation, p62, true)
	end
end
function Plow.setRotationCenter(p65)
	local v66 = p65.spec_plow
	if v66.rotationPart.turnAnimation ~= nil then
		local v67 = p65:getAnimationTime(v66.rotationPart.turnAnimation)
		if v67 ~= v66.ai.centerPosition then
			p65:setAnimationStopTime(v66.rotationPart.turnAnimation, v66.ai.centerPosition)
			if v67 < v66.ai.centerPosition then
				p65:playAnimation(v66.rotationPart.turnAnimation, 1, v67, true)
				return
			end
			if v66.ai.centerPosition < v67 then
				p65:playAnimation(v66.rotationPart.turnAnimation, -1, v67, true)
			end
		end
	end
end
function Plow.setPlowLimitToField(p68, p69, p70)
	local v71 = p68.spec_plow
	if v71.limitToField ~= p69 then
		if p70 == nil or p70 == false then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(PlowLimitToFieldEvent.new(p68, p69))
			else
				g_server:broadcastEvent(PlowLimitToFieldEvent.new(p68, p69), nil, nil, p68)
			end
		end
		v71.limitToField = p69
		local v72 = v71.actionEvents[InputAction.IMPLEMENT_EXTRA3]
		if v72 ~= nil then
			local v73
			if v71.limitToField then
				v73 = v71.texts.allowCreateFields
			else
				v73 = v71.texts.limitToFields
			end
			g_inputBinding:setActionEventText(v72.actionEventId, v73)
		end
	end
end
function Plow.getIsPlowRotationAllowed(p74)
	local v75 = p74.spec_plow
	if p74.getFoldAnimTime ~= nil then
		local v76 = p74:getFoldAnimTime()
		if v75.rotationPart.rotationFoldMaxLimit < v76 or v76 < v75.rotationPart.rotationFoldMinLimit then
			return false
		end
	end
	return true
end
function Plow.getCanTogglePlowRotation(p77)
	local v78 = p77.spec_plow
	if p77:getIsPlowRotationAllowed() then
		if v78.rotationPart.rotationAllowedIfLowered or (p77.getIsLowered == nil or not p77:getIsLowered()) then
			return p77:getIsPowered() and true or false
		else
			return false
		end
	else
		return false
	end
end
function Plow.getPlowLimitToField(p79)
	return p79.spec_plow.limitToField
end
function Plow.getPlowForceLimitToField(p80)
	return p80.spec_plow.forceLimitToField or not Platform.gameplay.canCreateFields
end
function Plow.setPlowAIRequirements(p81, p82)
	if p81.clearAITerrainDetailRequiredRange ~= nil then
		p81:clearAITerrainDetailRequiredRange()
		if p82 == nil then
			p81:addAIGroundTypeRequirements(Plow.AI_REQUIRED_GROUND_TYPES)
		else
			p81:addAIGroundTypeRequirements(Plow.AI_REQUIRED_GROUND_TYPES, unpack(p82))
		end
		p81:setAIImplementVariableSideOffset(true)
	end
end
function Plow.getIsFoldAllowed(p83, p84, p85, p86)
	local v87 = p83.spec_plow
	if v87.rotationPart.limitFoldRotationMax == nil or v87.rotationPart.limitFoldRotationMax ~= v87.rotationMax then
		if v87.rotationPart.turnAnimation ~= nil and p83.getAnimationTime ~= nil then
			local v88 = p83:getAnimationTime(v87.rotationPart.turnAnimation)
			if v87.rotationPart.foldRotationMaxLimit < v88 or v88 < v87.rotationPart.foldRotationMinLimit then
				return false, v87.texts.warningFoldingPlowTurned
			end
		end
		if v87.rotationPart.rotationAllowedIfLowered or (p83.getIsLowered == nil or not p83:getIsLowered()) then
			return p84(p83, p85, p86)
		else
			return false, v87.texts.warningFoldingLowered
		end
	else
		return false, v87.texts.warningFoldingPlowTurned
	end
end
function Plow.getIsFoldMiddleAllowed(p89, p90)
	local v91 = p89.spec_plow
	if v91.rotationPart.limitFoldRotationMax ~= nil and v91.rotationPart.limitFoldRotationMax == v91.rotationMax then
		return false
	end
	if v91.rotationPart.turnAnimation ~= nil and p89.getAnimationTime ~= nil then
		local v92 = p89:getAnimationTime(v91.rotationPart.turnAnimation)
		if v91.rotationPart.foldRotationMaxLimit < v92 or v92 < v91.rotationPart.foldRotationMinLimit then
			return false
		end
	end
	return p90(p89)
end
function Plow.getDirtMultiplier(p93, p94)
	local v95 = p94(p93)
	if p93.spec_plow.isWorking then
		v95 = v95 + p93:getWorkDirtMultiplier() * p93:getLastSpeed() / p93.speedLimit
	end
	return v95
end
function Plow.getWearMultiplier(p96, p97)
	local v98 = p97(p96)
	if p96.spec_plow.isWorking then
		v98 = v98 + p96:getWorkWearMultiplier() * p96:getLastSpeed() / p96.speedLimit
	end
	return v98
end
function Plow.loadSpeedRotatingPartFromXML(p99, p100, p101, p102, p103)
	if not p100(p99, p101, p102, p103) then
		return false
	end
	p101.disableOnTurn = p102:getValue(p103 .. "#disableOnTurn", true)
	p101.turnAnimLimit = p102:getValue(p103 .. "#turnAnimLimit", 0)
	p101.turnAnimLimitSide = p102:getValue(p103 .. "#turnAnimLimitSide", 0)
	p101.invertDirectionOnRotation = p102:getValue(p103 .. "#invertDirectionOnRotation", true)
	return true
end
function Plow.getIsSpeedRotatingPartActive(p104, p105, p106)
	local v107 = p104.spec_plow
	if v107.rotationPart.turnAnimation ~= nil and p106.disableOnTurn then
		local v108 = p104:getAnimationTime(v107.rotationPart.turnAnimation)
		if v108 ~= nil then
			local v109
			if p106.turnAnimLimitSide < 0 then
				v109 = v108 <= p106.turnAnimLimit
			elseif p106.turnAnimLimitSide > 0 then
				v109 = 1 - v108 <= p106.turnAnimLimit
			else
				v109 = v108 <= p106.turnAnimLimit and true or 1 - v108 <= p106.turnAnimLimit
			end
			if not v109 then
				return false
			end
		end
	end
	return p105(p104, p106)
end
function Plow.getSpeedRotatingPartDirection(p110, p111, p112)
	local v113 = p110.spec_plow
	return v113.rotationPart.turnAnimation ~= nil and (p110:getAnimationTime(v113.rotationPart.turnAnimation) > 0.5 and p112.invertDirectionOnRotation) and -1 or p111(p110, p112)
end
function Plow.doCheckSpeedLimit(p114, p115)
	local v116 = not p115(p114) and p114.spec_plow.onlyActiveWhenLowered
	if v116 then
		v116 = p114:getIsImplementChainLowered()
	end
	return v116
end
function Plow.loadWorkAreaFromXML(p117, p118, p119, p120, p121)
	local v122 = p118(p117, p119, p120, p121)
	if p119.type == WorkAreaType.DEFAULT then
		p119.type = WorkAreaType.PLOW
	end
	return v122
end
function Plow.getDefaultSpeedLimit()
	return 15
end
function Plow.getIsWorkAreaActive(p123, p124, p125)
	if p125.type == WorkAreaType.PLOW then
		local v126 = p123.spec_plow
		if v126.startActivationTime > g_currentMission.time then
			return false
		end
		if v126.onlyActiveWhenLowered and (p123.getIsLowered ~= nil and not p123:getIsLowered(false)) then
			return false
		end
	end
	return p124(p123, p125)
end
function Plow.getCanAIImplementContinueWork(p127, p128, p129)
	local v130, v131, v132 = p128(p127, p129)
	if not v130 then
		return false, v131, v132
	end
	local v133 = p127.spec_plow
	return not v133.ai.stopDuringTurn and p129 and true or not p127:getIsAnimationPlaying(v133.rotationPart.turnAnimation)
end
function Plow.getAIInvertMarkersOnTurn(p134, _, p135)
	local v136 = p134.spec_plow
	if v136.rotationPart.turnAnimation == nil then
		return false
	elseif p135 then
		return v136.rotationMax == v136.rotateLeftToMax
	else
		return v136.rotationMax ~= v136.rotateLeftToMax
	end
end
function Plow.getCanBeSelected(_, _)
	return true
end
function Plow.isDetachAllowed(p137, p138)
	local v139 = p137.spec_plow
	if p137:getIsAnimationPlaying(v139.rotationPart.turnAnimation) then
		return false
	end
	if v139.rotationPart.turnAnimation ~= nil then
		local v140 = p137:getAnimationTime(v139.rotationPart.turnAnimation)
		if v140 < v139.rotationPart.detachMinLimit or v139.rotationPart.detachMaxLimit < v140 then
			return false, v139.rotationPart.detachWarning, true
		end
	end
	return p138(p137)
end
function Plow.getAllowsLowering(p141, p142)
	if p141:getIsAnimationPlaying(p141.spec_plow.rotationPart.turnAnimation) then
		return false
	else
		return p142(p141)
	end
end
function Plow.getIsAIReadyToDrive(p143, p144)
	local v145 = p143.spec_plow
	if v145.rotationMax or p143:getIsAnimationPlaying(v145.rotationPart.turnAnimation) then
		return false
	else
		return p144(p143)
	end
end
function Plow.getIsAIPreparingToDrive(p146, p147)
	return p146:getIsAnimationPlaying(p146.spec_plow.rotationPart.turnAnimation) and true or p147(p146)
end
function Plow.onRegisterActionEvents(p148, _, p149)
	if p148.isClient then
		local v150 = p148.spec_plow
		p148:clearActionEventsTable(v150.actionEvents)
		if p149 then
			if v150.rotationPart.turnAnimation ~= nil then
				local _, v151 = p148:addPoweredActionEvent(v150.actionEvents, InputAction.IMPLEMENT_EXTRA, p148, Plow.actionEventTurn, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v151, GS_PRIO_HIGH)
				g_inputBinding:setActionEventText(v151, v150.texts.turnPlow)
			end
			local _, v152 = p148:addActionEvent(v150.actionEvents, InputAction.IMPLEMENT_EXTRA3, p148, Plow.actionEventLimitToField, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v152, GS_PRIO_NORMAL)
		end
	end
end
function Plow.onStartWorkAreaProcessing(p153, _)
	local v154 = p153.spec_plow
	v154.isWorking = false
	local v155 = p153:getPlowLimitToField()
	local v156
	if g_currentMission:getHasPlayerPermission("createFields", p153:getOwnerConnection(), nil, true) then
		v156 = v155
	else
		v155 = true
		v156 = true
	end
	local v157, _, v158 = localDirectionToWorld(v154.directionNode, 0, 0, 1)
	local v159 = FSDensityMapUtil.convertToDensityMapAngle(MathUtil.getYRotationFromDirection(v157, v158), g_currentMission.fieldGroundSystem:getGroundAngleMaxValue())
	v154.workAreaParameters.limitToField = v155
	v154.workAreaParameters.limitFruitDestructionToField = v156
	v154.workAreaParameters.angle = v159
	v154.workAreaParameters.lastChangedArea = 0
	v154.workAreaParameters.lastStatsArea = 0
	v154.workAreaParameters.lastTotalArea = 0
end
function Plow.onEndWorkAreaProcessing(p160, p161)
	local v162 = p160.spec_plow
	if p160.isServer then
		local v163 = p160:getLastTouchedFarmlandFarmId()
		local v164 = v162.workAreaParameters.lastStatsArea
		if v164 > 0 then
			local v165 = MathUtil.areaToHa(v164, g_currentMission:getFruitPixelsToSqm())
			g_farmManager:updateFarmStats(v163, "plowedHectares", v165)
			p160:updateLastWorkedArea(v164)
		end
		if v162.isWorking then
			g_farmManager:updateFarmStats(v163, "plowedTime", p161 / 60000)
		end
	end
	if p160.isClient then
		if v162.isWorking then
			if not v162.isWorkSamplePlaying then
				g_soundManager:playSamples(v162.samples.work)
				v162.isWorkSamplePlaying = true
				return
			end
		elseif v162.isWorkSamplePlaying then
			g_soundManager:stopSamples(v162.samples.work)
			v162.isWorkSamplePlaying = false
		end
	end
end
function Plow.onPostAttach(p166, _, _, _)
	local v167 = p166.spec_plow
	v167.startActivationTime = g_currentMission.time + v167.startActivationTimeout
	if v167.wasTurnAnimationStopped then
		local v168 = v167.rotationMax and 1 or -1
		p166:playAnimation(v167.rotationPart.turnAnimation, v168, p166:getAnimationTime(v167.rotationPart.turnAnimation), true)
		v167.wasTurnAnimationStopped = false
	end
end
function Plow.onPreDetach(p169, _, _)
	local v170 = p169.spec_plow
	v170.limitToField = true
	if p169:getIsAnimationPlaying(v170.rotationPart.turnAnimation) then
		p169:stopAnimation(v170.rotationPart.turnAnimation, true)
		v170.wasTurnAnimationStopped = true
	end
end
function Plow.onDeactivate(p171)
	if p171.isClient then
		local v172 = p171.spec_plow
		g_soundManager:stopSamples(v172.samples.work)
		g_soundManager:stopSamples(v172.samples.turn)
		v172.isWorkSamplePlaying = false
	end
end
function Plow.onAIFieldCourseSettingsInitialized(_, p173)
	p173.toolFullOverlap = true
	p173.toolFullOverlapInside = true
	p173.segmentSplitAngle = 25
end
function Plow.onAIImplementStartTurn(p174)
	p174.spec_plow.ai.lastHeadlandPosition = 0
end
function Plow.onAIImplementTurnProgress(p175, p176, p177, p178)
	local v179 = p175.spec_plow
	if p178 > 0 or v179.ai.allowTurnWhileReversing then
		if v179.ai.lastHeadlandPosition <= v179.ai.rotateToCenterHeadlandPos and (v179.ai.rotateToCenterHeadlandPos < p176 and p176 < v179.ai.rotateCompletelyHeadlandPos) then
			p175:setRotationCenter()
		elseif v179.ai.lastHeadlandPosition < v179.ai.rotateCompletelyHeadlandPos and v179.ai.rotateCompletelyHeadlandPos < p176 then
			p175:setRotationMax(p177)
		end
		v179.ai.lastHeadlandPosition = p176
	end
end
function Plow.onAIImplementSideOffsetChanged(p180, p181, p182)
	if p182 then
		local v183 = p180.spec_plow
		if p180:getIsPlowRotationAllowed() then
			p180:setRotationMax(p181)
			return
		end
		v183.ai.rotationMaxToSet = p181
	end
end
function Plow.onAIImplementEnd(p184)
	p184.spec_plow.ai.rotationMaxToSet = nil
end
function Plow.onStartAnimation(p185, p186)
	local v187 = p185.spec_plow
	if p186 == v187.rotationPart.turnAnimation then
		g_soundManager:playSamples(v187.samples.turn)
	end
end
function Plow.onFinishAnimation(p188, p189)
	local v190 = p188.spec_plow
	if p189 == v190.rotationPart.turnAnimation then
		g_soundManager:stopSamples(v190.samples.turn)
	end
end
function Plow.onFoldTimeChanged(p191, _)
	if p191.isServer then
		local v192 = p191.spec_plow
		if v192.ai.rotationMaxToSet ~= nil and p191:getIsPlowRotationAllowed() then
			p191:setRotationMax(v192.ai.rotationMaxToSet)
			v192.ai.rotationMaxToSet = nil
		end
	end
end
function Plow.onRootVehicleChanged(p_u_193, p194)
	local v_u_195 = p_u_193.spec_plow
	local v196 = p_u_193.spec_foldable
	if v196 ~= nil and #v196.foldingParts > 0 then
		local v197 = p194.actionController
		if v197 == nil then
			if v_u_195.controlledActionRotateBack ~= nil then
				v_u_195.controlledActionRotateBack:remove()
				v_u_195.controlledActionRotateBack = nil
			end
		else
			if v_u_195.controlledActionRotateBack ~= nil then
				v_u_195.controlledActionRotateBack:updateParent(v197)
				return
			end
			v_u_195.controlledActionRotateBack = v197:registerAction("rotateBackPlow", nil, 3)
			v_u_195.controlledActionRotateBack:setCallback(p_u_193, Plow.actionControllerRotateBackEvent)
			v_u_195.controlledActionRotateBack:addAIEventListener(p_u_193, "onAIImplementPrepareForTransport", -1, true)
		end
	end
	local v198 = p194.actionController
	if v198 == nil then
		if v_u_195.controlledActionRotate ~= nil then
			v_u_195.controlledActionRotate:remove()
			v_u_195.controlledActionRotate = nil
		end
		return
	elseif v_u_195.controlledActionRotate == nil then
		v_u_195.controlledActionRotate = v198:registerAction("rotatePlow", nil, 3)
		v_u_195.controlledActionRotate:setCallback(p_u_193, Plow.actionControllerRotateEvent)
		v_u_195.controlledActionRotate:setFinishedFunctions(p_u_193, function(_)
			-- upvalues: (copy) p_u_193, (copy) v_u_195
			return p_u_193:getIsAnimationPlaying(v_u_195.rotationPart.turnAnimation)
		end, false, false)
		v_u_195.controlledActionRotate:addAIEventListener(p_u_193, "onAIImplementStart", 1, true)
		v_u_195.controlledActionRotate:setResetOnDeactivation(false)
	else
		v_u_195.controlledActionRotate:updateParent(v198)
	end
end
function Plow.actionEventTurn(p199, _, _, _, _)
	local v200 = p199.spec_plow
	if v200.rotationPart.turnAnimation ~= nil and p199:getCanTogglePlowRotation() then
		p199:setRotationMax(not v200.rotationMax)
	end
end
function Plow.actionEventLimitToField(p201, _, _, _, _)
	local v202 = p201.spec_plow
	if not p201:getPlowForceLimitToField() then
		p201:setPlowLimitToField(not v202.limitToField)
	end
end
function Plow.actionControllerRotateBackEvent(p203, _, p204)
	if not p204 then
		return false
	end
	local v205 = p203.spec_plow
	if v205.rotationPart.turnAnimation ~= nil and (p203:getCanTogglePlowRotation() and v205.rotationMax) then
		p203:setRotationMax(false)
	end
	return true
end
function Plow.actionControllerRotateEvent(p206, p207, _)
	local v208 = p206.spec_plow
	if v208.rotationPart.turnAnimation ~= nil and p206:getCanTogglePlowRotation() then
		if p207 < 0 then
			p206:setRotationMax(not v208.rotationMax)
		elseif not p206:getIsAnimationPlaying(v208.rotationPart.turnAnimation) then
			local v209 = p206:getAnimationTime(v208.rotationPart.turnAnimation)
			if v209 > 0 and v209 < 1 then
				p206:setRotationMax(v208.rotationMax)
			end
		end
	end
	return true
end

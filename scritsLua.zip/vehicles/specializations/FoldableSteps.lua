FoldableSteps = {}
FoldableSteps.STATE_NUM_BITS = 4
source("dataS/scripts/vehicles/specializations/events/FoldableStepsChangeStateEvent.lua")
function FoldableSteps.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
end
function FoldableSteps.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("FoldableSteps")
	v2:register(XMLValueType.STRING, "vehicle.foldableSteps#animationName", "Folding Animation Name")
	v2:register(XMLValueType.FLOAT, "vehicle.foldableSteps#animationSpeed", "Folding Animation Speed", 1)
	v2:register(XMLValueType.INT, "vehicle.foldableSteps#fillUnitIndex", "Fill unit that is allowed to be filled / blocked to fill")
	v2:register(XMLValueType.STRING, "vehicle.foldableSteps.controls#action", "Input action to toggle to full movement from state 1 to max state", "IMPLEMENT_EXTRA2")
	v2:registerAutoCompletionDataSource("vehicle.foldableSteps.controls#action", "$dataS/inputActions.xml", "actions.action#name")
	v2:register(XMLValueType.STRING, "vehicle.foldableSteps.controls#actionPos", "Input action to toggle the next fold state")
	v2:registerAutoCompletionDataSource("vehicle.foldableSteps.controls#actionPos", "$dataS/inputActions.xml", "actions.action#name")
	v2:register(XMLValueType.STRING, "vehicle.foldableSteps.controls#actionNeg", "Input action to toggle the last fold state")
	v2:registerAutoCompletionDataSource("vehicle.foldableSteps.controls#actionNeg", "$dataS/inputActions.xml", "actions.action#name")
	v2:register(XMLValueType.L10N_STRING, "vehicle.foldableSteps.controls#posText", "Text to display for full folding in positive direction")
	v2:register(XMLValueType.L10N_STRING, "vehicle.foldableSteps.controls#negText", "Text to display for full folding in negative direction")
	v2:register(XMLValueType.FLOAT, "vehicle.foldableSteps.state(?)#time", "State time of folding animation (Abs. folding time)")
	v2:register(XMLValueType.L10N_STRING, "vehicle.foldableSteps.state(?)#posText", "State text for toggle in positive direction")
	v2:register(XMLValueType.STRING, "vehicle.foldableSteps.state(?)#posContext", "Active context to be allowed to toggle in positive direction (PLAYER or VEHICLE)", "VEHICLE")
	v2:register(XMLValueType.L10N_STRING, "vehicle.foldableSteps.state(?)#negText", "State text for toggle in negative direction")
	v2:register(XMLValueType.STRING, "vehicle.foldableSteps.state(?)#negContext", "Active context to be allowed to toggle in negative direction (PLAYER or VEHICLE)", "VEHICLE")
	v2:register(XMLValueType.BOOL, "vehicle.foldableSteps.state(?)#allowTurnOn", "Turn on is allowed while in this state", false)
	v2:register(XMLValueType.BOOL, "vehicle.foldableSteps.state(?)#allowInfoHud", "Info hud is allowed while in this state", false)
	v2:register(XMLValueType.BOOL, "vehicle.foldableSteps.state(?)#allowFilling", "Allow filling while in this state", false)
	v2:setXMLSpecializationType()
	local v3 = Vehicle.xmlSchemaSavegame
	v3:register(XMLValueType.FLOAT, "vehicles.vehicle(?).foldableSteps#animTime", "Fold animation time")
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).foldableSteps#state", "Current fold state index")
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).foldableSteps#targetState", "Current target fold state index")
end
function FoldableSteps.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "setFoldableStepsFoldState", FoldableSteps.setFoldableStepsFoldState)
end
function FoldableSteps.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanBeTurnedOn", FoldableSteps.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p5, "getTurnedOnNotAllowedWarning", FoldableSteps.getTurnedOnNotAllowedWarning)
	SpecializationUtil.registerOverwrittenFunction(p5, "getRequiresPower", FoldableSteps.getRequiresPower)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAllowHudInfoTrigger", FoldableSteps.getAllowHudInfoTrigger)
	SpecializationUtil.registerOverwrittenFunction(p5, "getFillUnitSupportsToolType", FoldableSteps.getFillUnitSupportsToolType)
end
function FoldableSteps.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", FoldableSteps)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", FoldableSteps)
	SpecializationUtil.registerEventListener(p6, "onReadStream", FoldableSteps)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", FoldableSteps)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", FoldableSteps)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", FoldableSteps)
	SpecializationUtil.registerEventListener(p6, "onRegisterExternalActionEvents", FoldableSteps)
end
function FoldableSteps.onLoad(p7, p8)
	local v9 = p7.spec_foldableSteps
	if p7.xmlFile:getValue("vehicle.foldableSteps#animationName") == nil then
		SpecializationUtil.removeEventListener(p7, "onPostLoad", FoldableSteps)
		SpecializationUtil.removeEventListener(p7, "onReadStream", FoldableSteps)
		SpecializationUtil.removeEventListener(p7, "onWriteStream", FoldableSteps)
		SpecializationUtil.removeEventListener(p7, "onUpdateTick", FoldableSteps)
		SpecializationUtil.removeEventListener(p7, "onRegisterActionEvents", FoldableSteps)
	else
		v9.animationName = p7.xmlFile:getValue("vehicle.foldableSteps#animationName")
		v9.animationSpeed = p7.xmlFile:getValue("vehicle.foldableSteps#animationSpeed", 1)
		v9.action = InputAction[p7.xmlFile:getValue("vehicle.foldableSteps.controls#action", "IMPLEMENT_EXTRA2")] or InputAction.IMPLEMENT_EXTRA2
		v9.actionPos = InputAction[p7.xmlFile:getValue("vehicle.foldableSteps.controls#actionPos")]
		v9.posText = p7.xmlFile:getValue("vehicle.foldableSteps.controls#posText", nil, p7.customEnvironment, false)
		v9.actionNeg = InputAction[p7.xmlFile:getValue("vehicle.foldableSteps.controls#actionNeg")]
		v9.negText = p7.xmlFile:getValue("vehicle.foldableSteps.controls#negText", nil, p7.customEnvironment, false)
		v9.fillUnitIndex = p7.xmlFile:getValue("vehicle.foldableSteps#fillUnitIndex")
		v9.stateIndex = 1
		v9.stateTargetIndex = 1
		v9.states = {}
		for _, v10 in p7.xmlFile:iterator("vehicle.foldableSteps.state") do
			local v11 = {
				["time"] = p7.xmlFile:getValue(v10 .. "#time")
			}
			if v11.time == nil then
				Logging.xmlWarning(p7.xmlFile, "Invalid state in \'%s\'", v10)
			else
				v11.time = v11.time * 1000 / p7:getAnimationDuration(v9.animationName)
				v11.posText = p7.xmlFile:getValue(v10 .. "#posText", nil, p7.customEnvironment, false)
				v11.posContext = p7.xmlFile:getValue(v10 .. "#posContext", "VEHICLE")
				v11.negText = p7.xmlFile:getValue(v10 .. "#negText", nil, p7.customEnvironment, false)
				v11.negContext = p7.xmlFile:getValue(v10 .. "#negContext", "VEHICLE")
				v11.allowTurnOn = p7.xmlFile:getValue(v10 .. "#allowTurnOn", false)
				v11.allowInfoHud = p7.xmlFile:getValue(v10 .. "#allowInfoHud", false)
				v11.allowFilling = p7.xmlFile:getValue(v10 .. "#allowFilling", false)
				if v11.posText == nil and v11.negText == nil then
					Logging.xmlWarning(p7.xmlFile, "Missing texts for state in \'%s\'", v10)
				else
					local v12 = v9.states
					table.insert(v12, v11)
				end
			end
		end
		v9.maxState = #v9.states
		v9.texts = {}
		v9.texts.stateTextPos = g_i18n:getText("action_foldableSteps_unfold")
		v9.texts.stateTextNeg = g_i18n:getText("action_foldableSteps_fold")
		v9.texts.warningNotAllowedPlayer = g_i18n:getText("warning_actionNotAllowedPlayer")
		v9.texts.warningNotAllowedVehicle = g_i18n:getText("warning_actionNotAllowedVehicle")
		v9.texts.warningUnfoldFirst = string.format(g_i18n:getText("warning_firstUnfoldTheTool"), p7.typeDesc)
		if #v9.states == 0 then
			Logging.xmlWarning(p7.xmlFile, "No states found in \'vehicle.foldableSteps\'")
			return
		end
		if p8 ~= nil and not p8.resetVehicles then
			v9.loadedAnimTime = p8.xmlFile:getValue(p8.key .. ".foldableSteps#animTime", 0)
			v9.stateIndex = p8.xmlFile:getValue(p8.key .. ".foldableSteps#state", v9.stateIndex)
			v9.stateTargetIndex = p8.xmlFile:getValue(p8.key .. ".foldableSteps#targetState", v9.stateTargetIndex)
			return
		end
	end
end
function FoldableSteps.onPostLoad(p13, _)
	local v14 = p13.spec_foldableSteps
	if v14.loadedAnimTime ~= nil then
		p13:setAnimationTime(v14.animationName, v14.loadedAnimTime, true, false)
	end
end
function FoldableSteps.saveToXMLFile(p15, p16, p17, _)
	local v18 = p15.spec_foldableSteps
	if v18.animationName ~= nil then
		p16:setValue(p17 .. "#animTime", p15:getAnimationTime(v18.animationName))
		p16:setValue(p17 .. "#state", v18.stateIndex)
		p16:setValue(p17 .. "#targetState", v18.stateTargetIndex)
	end
end
function FoldableSteps.onReadStream(p19, p20, _)
	local v21 = p19.spec_foldableSteps
	local v22 = streamReadFloat32(p20)
	p19:setAnimationTime(v21.animationName, v22, true, false)
	v21.stateIndex = streamReadUIntN(p20, FoldableSteps.STATE_NUM_BITS)
	p19:setFoldableStepsFoldState(streamReadUIntN(p20, FoldableSteps.STATE_NUM_BITS), true)
end
function FoldableSteps.onWriteStream(p23, p24, _)
	local v25 = p23.spec_foldableSteps
	streamWriteFloat32(p24, p23:getAnimationTime(v25.animationName))
	streamWriteUIntN(p24, v25.stateIndex, FoldableSteps.STATE_NUM_BITS)
	streamWriteUIntN(p24, v25.stateTargetIndex, FoldableSteps.STATE_NUM_BITS)
end
function FoldableSteps.onUpdateTick(p26, _, _, _, _)
	local v27 = p26.spec_foldableSteps
	if v27.stateIndex ~= v27.stateTargetIndex then
		if not p26:getIsAnimationPlaying(v27.animationName) then
			v27.stateIndex = v27.stateTargetIndex
			FoldableSteps.updateActionEvents(p26, v27.actionEvents)
		end
		p26:raiseActive()
	end
end
function FoldableSteps.onRegisterActionEvents(p28, _, p29)
	if p28.isClient then
		local v30 = p28.spec_foldableSteps
		p28:clearActionEventsTable(v30.actionEvents)
		if p29 then
			local _, v31 = p28:addPoweredActionEvent(v30.actionEvents, v30.action, p28, FoldableSteps.actionEventFold, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v31, GS_PRIO_VERY_HIGH)
			if v30.actionPos ~= nil then
				local _, v32 = p28:addPoweredActionEvent(v30.actionEvents, v30.actionPos, p28, FoldableSteps.actionEventFoldPos, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v32, GS_PRIO_HIGH)
			end
			if v30.actionNeg ~= nil then
				local _, v33 = p28:addPoweredActionEvent(v30.actionEvents, v30.actionNeg, p28, FoldableSteps.actionEventFoldNeg, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v33, GS_PRIO_HIGH)
			end
			FoldableSteps.updateActionEvents(p28, v30.actionEvents)
		end
	end
end
function FoldableSteps.onRegisterExternalActionEvents(p34, p35, p36, _, _)
	if p36 == "foldableStepsFull" then
		p34:registerExternalActionEvent(p35, p36, FoldableSteps.externalActionEventFoldRegister, FoldableSteps.externalActionEventFoldUpdate)
	elseif p36 == "foldableStepsNextPos" then
		if p34.spec_foldableSteps.actionPos ~= nil then
			p34:registerExternalActionEvent(p35, p36, FoldableSteps.externalActionEventFoldPosRegister, FoldableSteps.externalActionEventFoldPosUpdate)
			return
		end
	elseif p36 == "foldableStepsNextNeg" and p34.spec_foldableSteps.actionNeg ~= nil then
		p34:registerExternalActionEvent(p35, p36, FoldableSteps.externalActionEventFoldNegRegister, FoldableSteps.externalActionEventFoldNegUpdate)
	end
end
function FoldableSteps.setFoldableStepsFoldState(p37, p38, p39)
	local v40 = p37.spec_foldableSteps
	local v41 = v40.maxState
	v40.stateTargetIndex = math.clamp(p38, 1, v41)
	local v42 = v40.states[v40.stateTargetIndex]
	local v43 = p37:getAnimationTime(v40.animationName)
	local v44 = v43 - v42.time
	if math.abs(v44) > 0.0001 then
		p37:setAnimationStopTime(v40.animationName, v42.time)
		p37:playAnimation(v40.animationName, v40.animationSpeed * -math.sign(v44), v43, true)
		p37:raiseActive()
	end
	FoldableSteps.updateActionEvents(p37, v40.actionEvents)
	FoldableStepsChangeStateEvent.sendEvent(p37, v40.stateTargetIndex, p39)
end
function FoldableSteps.updateActionEvents(p45, p46)
	local v47 = p45.spec_foldableSteps
	local v48 = v47.stateIndex ~= v47.stateTargetIndex
	local v49 = p46[v47.action]
	if v49 ~= nil then
		local v50 = v47.stateIndex < v47.maxState and v47.posText or v47.negText
		if v50 ~= nil then
			g_inputBinding:setActionEventText(v49.actionEventId, string.format(v50, p45.typeDesc))
		end
		g_inputBinding:setActionEventActive(v49.actionEventId, v50 ~= nil)
	end
	local v51 = p46[v47.actionPos]
	if v51 ~= nil then
		if v48 then
			g_inputBinding:setActionEventActive(v51.actionEventId, false)
		else
			local v52 = v47.states[v47.stateIndex]
			if v52.posText == nil then
				g_inputBinding:setActionEventActive(v51.actionEventId, false)
			else
				g_inputBinding:setActionEventText(v51.actionEventId, string.format(v47.texts.stateTextPos, string.format(v52.posText, p45.typeDesc)))
				g_inputBinding:setActionEventActive(v51.actionEventId, true)
			end
		end
	end
	local v53 = p46[v47.actionNeg]
	if v53 ~= nil then
		if not v48 then
			local v54 = v47.states[v47.stateIndex]
			if v54.negText == nil then
				g_inputBinding:setActionEventActive(v53.actionEventId, false)
			else
				g_inputBinding:setActionEventText(v53.actionEventId, string.format(v47.texts.stateTextNeg, string.format(v54.negText, p45.typeDesc)))
				g_inputBinding:setActionEventActive(v53.actionEventId, true)
			end
		end
		g_inputBinding:setActionEventActive(v53.actionEventId, false)
	end
end
function FoldableSteps.actionEventFold(p55, _, _, _, _)
	local v56 = p55.spec_foldableSteps
	local v57
	if v56.stateIndex == v56.stateTargetIndex then
		v57 = v56.stateIndex >= v56.maxState and 1 or v56.maxState
	else
		v57 = v56.stateIndex < v56.stateTargetIndex and 1 or v56.maxState
	end
	if v57 ~= nil and FoldableSteps.updateFoldStateChangeAllowed(p55, v57) then
		p55:setFoldableStepsFoldState(v57)
	end
end
function FoldableSteps.actionEventFoldPos(p58, _, _, _, _)
	local v59 = p58.spec_foldableSteps.stateTargetIndex + 1
	if FoldableSteps.updateFoldStateChangeAllowed(p58, v59, g_inputBinding:getContextName()) then
		p58:setFoldableStepsFoldState(v59)
	end
end
function FoldableSteps.actionEventFoldNeg(p60, _, _, _, _)
	local v61 = p60.spec_foldableSteps.stateTargetIndex - 1
	if FoldableSteps.updateFoldStateChangeAllowed(p60, v61, g_inputBinding:getContextName()) then
		p60:setFoldableStepsFoldState(v61)
	end
end
function FoldableSteps.updateFoldStateChangeAllowed(p62, p63, p64)
	local v65 = p62.spec_foldableSteps
	local v66, v67 = p62:getIsFoldAllowed(v65.stateIndex < p63 and p62.spec_foldable.turnOnFoldDirection or p62.spec_foldable.turnOnFoldDirection, false)
	if v66 then
		local v68, v69 = p62:getIsPowered()
		if v68 then
			if p64 ~= nil then
				local v70 = v65.states[v65.stateIndex]
				if v65.stateIndex < p63 and v70.posContext ~= p64 or p63 < v65.stateIndex and v70.negContext ~= p64 then
					if p64 == Vehicle.INPUT_CONTEXT_NAME then
						g_currentMission:showBlinkingWarning(string.format(v65.texts.warningNotAllowedPlayer, p62.typeDesc), 2000)
					else
						g_currentMission:showBlinkingWarning(string.format(v65.texts.warningNotAllowedVehicle, p62.typeDesc), 2000)
					end
					return false
				end
			end
			return true
		else
			g_currentMission:showBlinkingWarning(v69, 2000)
			return false
		end
	else
		g_currentMission:showBlinkingWarning(v67, 2000)
		return false
	end
end
function FoldableSteps.externalActionEventFoldRegister(p71, p_u_72)
	local v73 = p_u_72.spec_foldableSteps
	local _, v78 = g_inputBinding:registerActionEvent(v73.action, p71, function(_, p74, p75, p76, p77)
		-- upvalues: (copy) p_u_72
		Motorized.tryStartMotor(p_u_72)
		FoldableSteps.actionEventFold(p_u_72, p74, p75, p76, p77)
	end, false, true, false, true)
	p71.actionEventId = v78
	g_inputBinding:setActionEventTextPriority(p71.actionEventId, GS_PRIO_HIGH)
end
function FoldableSteps.externalActionEventFoldUpdate(p79, p80)
	local v81 = p80.spec_foldableSteps
	local v82 = v81.stateIndex < v81.maxState and v81.posText or v81.negText
	if v82 ~= nil then
		g_inputBinding:setActionEventText(p79.actionEventId, string.format(v82, p80.typeDesc))
	end
	g_inputBinding:setActionEventActive(p79.actionEventId, v82 ~= nil)
end
function FoldableSteps.externalActionEventFoldPosRegister(p83, p_u_84)
	local v85 = p_u_84.spec_foldableSteps
	local _, v90 = g_inputBinding:registerActionEvent(v85.actionPos, p83, function(_, p86, p87, p88, p89)
		-- upvalues: (copy) p_u_84
		Motorized.tryStartMotor(p_u_84)
		FoldableSteps.actionEventFoldPos(p_u_84, p86, p87, p88, p89)
	end, false, true, false, true)
	p83.actionEventId = v90
	g_inputBinding:setActionEventTextPriority(p83.actionEventId, GS_PRIO_HIGH)
end
function FoldableSteps.externalActionEventFoldPosUpdate(p91, p92)
	local v93 = p92.spec_foldableSteps
	if v93.stateIndex ~= v93.stateTargetIndex then
		g_inputBinding:setActionEventActive(p91.actionEventId, false)
		return
	else
		local v94 = v93.states[v93.stateIndex]
		if v94.posText == nil then
			g_inputBinding:setActionEventActive(p91.actionEventId, false)
		else
			g_inputBinding:setActionEventText(p91.actionEventId, string.format(v93.texts.stateTextPos, string.format(v94.posText, p92.typeDesc)))
			g_inputBinding:setActionEventActive(p91.actionEventId, true)
		end
	end
end
function FoldableSteps.externalActionEventFoldNegRegister(p95, p_u_96)
	local v97 = p_u_96.spec_foldableSteps
	local _, v102 = g_inputBinding:registerActionEvent(v97.actionNeg, p95, function(_, p98, p99, p100, p101)
		-- upvalues: (copy) p_u_96
		Motorized.tryStartMotor(p_u_96)
		FoldableSteps.actionEventFoldNeg(p_u_96, p98, p99, p100, p101)
	end, false, true, false, true)
	p95.actionEventId = v102
	g_inputBinding:setActionEventTextPriority(p95.actionEventId, GS_PRIO_HIGH)
end
function FoldableSteps.externalActionEventFoldNegUpdate(p103, p104)
	local v105 = p104.spec_foldableSteps
	if v105.stateIndex ~= v105.stateTargetIndex then
		g_inputBinding:setActionEventActive(p103.actionEventId, false)
		return
	else
		local v106 = v105.states[v105.stateIndex]
		if v106.negText == nil then
			g_inputBinding:setActionEventActive(p103.actionEventId, false)
		else
			g_inputBinding:setActionEventText(p103.actionEventId, string.format(v105.texts.stateTextNeg, string.format(v106.negText, p104.typeDesc)))
			g_inputBinding:setActionEventActive(p103.actionEventId, true)
		end
	end
end
function FoldableSteps.getCanBeTurnedOn(p107, p108)
	local v109 = p107.spec_foldableSteps
	if v109.animationName ~= nil then
		local v110 = v109.states[v109.stateIndex]
		if v109.stateIndex ~= v109.stateTargetIndex or not v110.allowTurnOn then
			return false
		end
	end
	return p108(p107)
end
function FoldableSteps.getTurnedOnNotAllowedWarning(p111, p112)
	local v113 = p111.spec_foldableSteps
	if v113.animationName ~= nil then
		local v114 = v113.states[v113.stateIndex]
		if v113.stateIndex ~= v113.stateTargetIndex or not v114.allowTurnOn then
			return v113.texts.warningUnfoldFirst
		end
	end
	return p112(p111)
end
function FoldableSteps.getRequiresPower(p115, p116)
	local v117 = p115.spec_foldableSteps
	return v117.animationName ~= nil and v117.stateIndex ~= v117.stateTargetIndex and true or p116(p115)
end
function FoldableSteps.getAllowHudInfoTrigger(p118, p119)
	local v120 = p118.spec_foldableSteps
	if v120.animationName == nil or v120.states[v120.stateIndex].allowInfoHud then
		return p119(p118)
	else
		return false
	end
end
function FoldableSteps.getFillUnitSupportsToolType(p121, p122, p123, p124)
	local v125 = p121.spec_foldableSteps
	if v125.animationName == nil or (p124 == ToolType.UNDEFINED or (p123 ~= v125.fillUnitIndex or v125.states[v125.stateIndex].allowFilling)) then
		return p122(p121, p123, p124)
	else
		return false
	end
end

FoliageBending = {}
FoliageBending.BENDING_NODE_XML_KEY = "vehicle.foliageBending.bendingNode(?)"
function FoliageBending.prerequisitesPresent(_)
	return true
end
function FoliageBending.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("FoliageBending")
	local v2 = FoliageBending.BENDING_NODE_XML_KEY
	v1:register(XMLValueType.NODE_INDEX, v2 .. "#node", "Bending node")
	v1:register(XMLValueType.FLOAT, v2 .. "#minX", "Min. width")
	v1:register(XMLValueType.FLOAT, v2 .. "#maxX", "Max. width")
	v1:register(XMLValueType.FLOAT, v2 .. "#minZ", "Min. length")
	v1:register(XMLValueType.FLOAT, v2 .. "#maxZ", "Max. length")
	v1:register(XMLValueType.FLOAT, v2 .. "#yOffset", "Y translation offset")
	v1:setXMLSpecializationType()
end
function FoliageBending.postInitSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("FoliageBending")
	for _, v4 in pairs(g_vehicleConfigurationManager:getConfigurations()) do
		local v5 = v4.configurationKey .. "(?)"
		v3:setXMLSharedRegistration("foliageBendingModifier", v5)
		v3:register(XMLValueType.INT, v5 .. ".foliageBendingModifier(?)#index", "Bending node index")
		v3:register(XMLValueType.VECTOR_N, v5 .. ".foliageBendingModifier(?)#indices", "Bending node indices")
		v3:register(XMLValueType.FLOAT, v5 .. ".foliageBendingModifier(?)#minX", "Min. width")
		v3:register(XMLValueType.FLOAT, v5 .. ".foliageBendingModifier(?)#maxX", "Max. width")
		v3:register(XMLValueType.FLOAT, v5 .. ".foliageBendingModifier(?)#minZ", "Min. length")
		v3:register(XMLValueType.FLOAT, v5 .. ".foliageBendingModifier(?)#maxZ", "Max. length")
		v3:register(XMLValueType.FLOAT, v5 .. ".foliageBendingModifier(?)#yOffset", "Y translation offset")
		v3:register(XMLValueType.BOOL, v5 .. ".foliageBendingModifier(?)#isActive", "Bending node is active", true)
		v3:register(XMLValueType.BOOL, v5 .. ".foliageBendingModifier(?)#overwrite", "Overwrite the bending node values and do not use the max values", true)
		v3:resetXMLSharedRegistration("foliageBendingModifier", v5)
	end
	v3:setXMLSpecializationType()
end
function FoliageBending.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "loadBendingNodeFromXML", FoliageBending.loadBendingNodeFromXML)
	SpecializationUtil.registerFunction(p6, "loadBendingNodeModifierFromXML", FoliageBending.loadBendingNodeModifierFromXML)
	SpecializationUtil.registerFunction(p6, "activateBendingNodes", FoliageBending.activateBendingNodes)
	SpecializationUtil.registerFunction(p6, "deactivateBendingNodes", FoliageBending.deactivateBendingNodes)
	SpecializationUtil.registerFunction(p6, "getFoliageBendingNodeByIndex", FoliageBending.getFoliageBendingNodeByIndex)
	SpecializationUtil.registerFunction(p6, "updateFoliageBendingAttributes", FoliageBending.updateFoliageBendingAttributes)
end
function FoliageBending.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onPostLoad", FoliageBending)
	SpecializationUtil.registerEventListener(p7, "onDelete", FoliageBending)
	SpecializationUtil.registerEventListener(p7, "onActivate", FoliageBending)
	SpecializationUtil.registerEventListener(p7, "onDeactivate", FoliageBending)
end
function FoliageBending.onPostLoad(p8, _)
	local v9 = p8.spec_foliageBending
	v9.bendingNodes = {}
	local v10 = 0
	while true do
		local v11 = string.format("vehicle.foliageBending.bendingNode(%d)", v10)
		if not p8.xmlFile:hasProperty(v11) then
			break
		end
		local v12 = {}
		if p8:loadBendingNodeFromXML(p8.xmlFile, v11, v12) then
			local v13 = v9.bendingNodes
			table.insert(v13, v12)
			v12.index = #v9.bendingNodes
		end
		v10 = v10 + 1
	end
	for v14, v15 in pairs(p8.configurations) do
		local v16 = g_vehicleConfigurationManager:getConfigurationDescByName(v14)
		local v17 = string.format("%s(%d).foliageBendingModifier", v16.configurationKey, v15 - 1)
		for _, v18 in p8.xmlFile:iterator(v17) do
			p8:loadBendingNodeModifierFromXML(p8.xmlFile, v18)
		end
	end
	if v9.bendingModifiers ~= nil then
		for _, v19 in ipairs(v9.bendingModifiers) do
			for _, v20 in ipairs(v19.indices) do
				local v21 = v9.bendingNodes[v20]
				if v21 == nil then
					Logging.xmlWarning(p8.xmlFile, "Undefined bendingNode index \'%d\' for bending modifier \'%s\'!", v20, v19.key)
				else
					if v19.overwrite then
						v21.minX = v19.minX or v21.minX
						v21.maxX = v19.maxX or v21.maxX
						v21.minZ = v19.minZ or v21.minZ
						v21.maxZ = v19.maxZ or v21.maxZ
						v21.yOffset = v19.yOffset or v21.yOffset
					else
						local v22 = v21.minX
						local v23 = v19.minX or v21.minX
						v21.minX = math.min(v22, v23)
						local v24 = v21.maxX
						local v25 = v19.maxX or v21.maxX
						v21.maxX = math.max(v24, v25)
						local v26 = v21.minZ
						local v27 = v19.minZ or v21.minZ
						v21.minZ = math.min(v26, v27)
						local v28 = v21.maxZ
						local v29 = v19.maxZ or v21.maxZ
						v21.maxZ = math.max(v28, v29)
						local v30 = v21.yOffset
						local v31 = v19.yOffset or v21.yOffset
						v21.yOffset = math.max(v30, v31)
					end
					if not v19.isActive then
						v21.isActive = false
					end
				end
			end
		end
		v9.bendingModifiers = nil
	end
end
function FoliageBending.onDelete(p32)
	p32:deactivateBendingNodes()
end
function FoliageBending.loadBendingNodeFromXML(p33, p34, p35, p36)
	local v37 = p34:getValue(p35 .. "#node", nil, p33.components, p33.i3dMappings)
	if v37 == nil then
		v37 = p33.rootNode
	end
	p36.node = v37
	p36.key = p35
	p36.minX = p34:getValue(p35 .. "#minX", -1)
	p36.maxX = p34:getValue(p35 .. "#maxX", 1)
	p36.minZ = p34:getValue(p35 .. "#minZ", -1)
	p36.maxZ = p34:getValue(p35 .. "#maxZ", 1)
	p36.yOffset = p34:getValue(p35 .. "#yOffset", 0)
	p36.isActive = true
	return true
end
function FoliageBending.loadBendingNodeModifierFromXML(p38, p39, p40)
	local v41 = {
		["index"] = p39:getValue(p40 .. "#index"),
		["indices"] = p39:getValue(p40 .. "#indices", nil, true)
	}
	if v41.index == nil and v41.indices == nil then
		Logging.xmlWarning(p38.xmlFile, "Missing bending node index for bending modifier \'%s\'", p40)
	else
		v41.indices = v41.indices or {}
		if v41.index ~= nil then
			local v42 = v41.indices
			local v43 = v41.index
			table.insert(v42, v43)
		end
		v41.minX = p39:getValue(p40 .. "#minX")
		v41.maxX = p39:getValue(p40 .. "#maxX")
		v41.minZ = p39:getValue(p40 .. "#minZ")
		v41.maxZ = p39:getValue(p40 .. "#maxZ")
		v41.yOffset = p39:getValue(p40 .. "#yOffset")
		v41.isActive = p39:getValue(p40 .. "#isActive", true)
		v41.overwrite = p39:getValue(p40 .. "#overwrite", true)
		local v44 = p38.spec_foliageBending
		if v44.bendingModifiers == nil then
			v44.bendingModifiers = {}
		end
		local v45 = v44.bendingModifiers
		table.insert(v45, v41)
	end
end
function FoliageBending.activateBendingNodes(p46)
	local v47 = p46.spec_foliageBending
	for _, v48 in ipairs(v47.bendingNodes) do
		if v48.isActive and (v48.id == nil and g_currentMission.foliageBendingSystem) then
			v48.id = g_currentMission.foliageBendingSystem:createRectangle(v48.minX, v48.maxX, v48.minZ, v48.maxZ, v48.yOffset, v48.node)
		end
	end
end
function FoliageBending.deactivateBendingNodes(p49)
	local v50 = p49.spec_foliageBending
	if v50.bendingNodes ~= nil then
		for _, v51 in ipairs(v50.bendingNodes) do
			if v51.id ~= nil then
				g_currentMission.foliageBendingSystem:destroyObject(v51.id)
				v51.id = nil
			end
		end
	end
end
function FoliageBending.getFoliageBendingNodeByIndex(p52, p53)
	return p52.spec_foliageBending.bendingNodes[p53]
end
function FoliageBending.updateFoliageBendingAttributes(p54, p55)
	local v56 = p54:getFoliageBendingNodeByIndex(p55)
	if v56 ~= nil and v56.id ~= nil then
		g_currentMission.foliageBendingSystem:setRectangleAttributes(v56.id, v56.minX, v56.maxX, v56.minZ, v56.maxZ, v56.yOffset)
	end
end
function FoliageBending.onActivate(p57)
	p57:activateBendingNodes()
end
function FoliageBending.onDeactivate(p58)
	p58:deactivateBendingNodes()
end

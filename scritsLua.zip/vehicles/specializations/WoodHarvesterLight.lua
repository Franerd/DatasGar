WoodHarvesterLight = {}
WoodHarvesterLight.SPAWN_COLLISION_MASK = CollisionFlag.STATIC_OBJECT + CollisionFlag.TREE + CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.VEHICLE + CollisionFlag.PLAYER + CollisionFlag.ANIMAL
function WoodHarvesterLight.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AutomaticArmControlHarvester, p1)
	end
	return v2
end
function WoodHarvesterLight.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("woodHarvesterLight", g_i18n:getText("shop_configuration"), "woodHarvesterLight", VehicleConfigurationItem)
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("WoodHarvesterLight")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.woodHarvesterLight.cutNode#node", "Cut node")
	v3:register(XMLValueType.FLOAT, "vehicle.woodHarvesterLight.cutNode#maxRadius", "Max. radius of the tree", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.woodHarvesterLight.cutNode#sizeY", "Size in Y direction", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.woodHarvesterLight.cutNode#sizeZ", "Size in Z direction", 1)
	v3:register(XMLValueType.STRING, "vehicle.woodHarvesterLight.cutAnimation#name", "Cut animation name")
	v3:register(XMLValueType.FLOAT, "vehicle.woodHarvesterLight.cutAnimation#speedScale", "Cut animation speed scale")
	v3:register(XMLValueType.STRING, "vehicle.woodHarvesterLight.grabAnimation#name", "Grab animation name")
	v3:register(XMLValueType.FLOAT, "vehicle.woodHarvesterLight.grabAnimation#speedScale", "Grab animation speed scale")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.woodHarvesterLight.logSpawner#startNode", "Start reference node for spawning (end node is the tree)")
	v3:register(XMLValueType.FLOAT, "vehicle.woodHarvesterLight.logSpawner#offset", "Offset from tree", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.woodHarvesterLight.logSpawner#maxSpawnWidth", "Max. spawning width to the left and right", 10)
	v3:register(XMLValueType.FLOAT, "vehicle.woodHarvesterLight.logSpawner#additionalLength", "Length of area behind the tree that can be used for the spawning", 4)
	EffectManager.registerEffectXMLPaths(v3, "vehicle.woodHarvesterLight.cutEffects")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.woodHarvesterLight.sounds", "cut")
	v3:setXMLSpecializationType()
end
function WoodHarvesterLight.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "updateLogSpawner", WoodHarvesterLight.updateLogSpawner)
	SpecializationUtil.registerFunction(p4, "onWoodHarversterLogSpawnerCallback", WoodHarvesterLight.onWoodHarversterLogSpawnerCallback)
	SpecializationUtil.registerFunction(p4, "spawnLogHeap", WoodHarvesterLight.spawnLogHeap)
	SpecializationUtil.registerFunction(p4, "spawnTreeStump", WoodHarvesterLight.spawnTreeStump)
end
function WoodHarvesterLight.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getSupportsAutoTreeAlignment", WoodHarvesterLight.getSupportsAutoTreeAlignment)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAutoAlignHasValidTree", WoodHarvesterLight.getAutoAlignHasValidTree)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAreControlledActionsAllowed", WoodHarvesterLight.getAreControlledActionsAllowed)
end
function WoodHarvesterLight.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", WoodHarvesterLight)
	SpecializationUtil.registerEventListener(p6, "onDelete", WoodHarvesterLight)
	SpecializationUtil.registerEventListener(p6, "onUpdate", WoodHarvesterLight)
	SpecializationUtil.registerEventListener(p6, "onTurnedOn", WoodHarvesterLight)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", WoodHarvesterLight)
end
function WoodHarvesterLight.onLoad(p7, _)
	local v8 = p7.spec_woodHarvesterLight
	v8.cutNode = {}
	v8.cutNode.node = p7.xmlFile:getValue("vehicle.woodHarvesterLight.cutNode#node", nil, p7.components, p7.i3dMappings)
	v8.cutNode.maxRadius = p7.xmlFile:getValue("vehicle.woodHarvesterLight.cutNode#maxRadius", 1)
	v8.cutNode.sizeY = p7.xmlFile:getValue("vehicle.woodHarvesterLight.cutNode#sizeY", 1)
	v8.cutNode.sizeZ = p7.xmlFile:getValue("vehicle.woodHarvesterLight.cutNode#sizeZ", 1)
	v8.cutAnimation = {}
	v8.cutAnimation.name = p7.xmlFile:getValue("vehicle.woodHarvesterLight.cutAnimation#name")
	v8.cutAnimation.speedScale = p7.xmlFile:getValue("vehicle.woodHarvesterLight.cutAnimation#speedScale", 1)
	v8.grabAnimation = {}
	v8.grabAnimation.name = p7.xmlFile:getValue("vehicle.woodHarvesterLight.grabAnimation#name")
	v8.grabAnimation.speedScale = p7.xmlFile:getValue("vehicle.woodHarvesterLight.grabAnimation#speedScale", 1)
	v8.logSpawner = {}
	v8.logSpawner.startNode = p7.xmlFile:getValue("vehicle.woodHarvesterLight.logSpawner#startNode", nil, p7.components, p7.i3dMappings)
	v8.logSpawner.offset = p7.xmlFile:getValue("vehicle.woodHarvesterLight.logSpawner#offset", 1)
	v8.logSpawner.maxSpawnWidth = p7.xmlFile:getValue("vehicle.woodHarvesterLight.logSpawner#maxSpawnWidth", 10)
	v8.logSpawner.additionalLength = p7.xmlFile:getValue("vehicle.woodHarvesterLight.logSpawner#additionalLength", 4)
	v8.logSpawner.currentCheckIndex = 0
	v8.logSpawner.hasValidBox = false
	v8.logSpawner.validCheckBoxIndex = 0
	v8.logSpawner.lastValidBox = {
		0,
		0,
		0,
		0
	}
	v8.logSpawner.lastBoxToCheck = {
		0,
		0,
		0,
		0
	}
	v8.logSpawner.logFilename = "data/maps/trees/logs/pineLog.i3d"
	v8.logSpawner.logSize = { 0.4, 5 }
	v8.logSpawner.logVolume = 0.66
	v8.curSplitShape = nil
	if p7.isClient then
		v8.cutEffects = g_effectManager:loadEffect(p7.xmlFile, "vehicle.woodHarvesterLight.cutEffects", p7.components, p7, p7.i3dMappings)
		v8.samples = {}
		v8.samples.cut = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.woodHarvesterLight.sounds", "cut", p7.baseDirectory, p7.components, 1, AudioGroup.VEHICLE, p7.i3dMappings, p7)
	end
	if v8.cutNode.node == nil then
		SpecializationUtil.removeEventListener(p7, "onUpdate", WoodHarvesterLight)
		SpecializationUtil.removeEventListener(p7, "onTurnedOn", WoodHarvesterLight)
		SpecializationUtil.removeEventListener(p7, "onTurnedOff", WoodHarvesterLight)
	end
	v8.texts = {}
	v8.texts.warning_woodHarvesterNoTreeInRange = g_i18n:getText("warning_woodHarvesterNoTreeInRange")
	v8.texts.warning_woodHarvesterNoSpawnPlace = g_i18n:getText("warning_woodHarvesterNoSpawnPlace")
	v8.texts.warning_woodHarvesterTreeNotAllowed = g_i18n:getText("warning_youAreNotAllowedToCutThisTree")
	v8.texts.warning_woodHarvesterTreeTypeNotSupported = g_i18n:getText("warning_treeTypeNotSupported")
	v8.texts.warning_woodHarvesterTreeTooThick = g_i18n:getText("warning_treeTooThick")
end
function WoodHarvesterLight.onDelete(p9)
	local v10 = p9.spec_woodHarvesterLight
	if p9.isClient then
		g_effectManager:deleteEffects(v10.cutEffects)
		g_soundManager:deleteSamples(v10.samples)
	end
end
function WoodHarvesterLight.onUpdate(p11, _, _, _, _)
	local v12 = p11.spec_woodHarvesterLight
	v12.curSplitShape = nil
	if p11:getIsTurnedOn() then
		local v13, v14, v15 = localToWorld(v12.cutNode.node, 0, 0, 0)
		local v16, v17, v18 = localDirectionToWorld(v12.cutNode.node, 1, 0, 0)
		local v19, v20, v21 = localDirectionToWorld(v12.cutNode.node, 0, 1, 0)
		local v22, _, _, _, _ = findSplitShape(v13, v14, v15, v16, v17, v18, v19, v20, v21, v12.cutNode.sizeY, v12.cutNode.sizeZ)
		if v22 == 0 or getUserAttribute(v22, "isTreeStump") == true then
			if p11:getAnimationTime(v12.cutAnimation.name) > 0.99 then
				p11:setAnimationTime(v12.cutAnimation.name, 0)
				if Platform.gameplay.automaticVehicleControl then
					p11:playControlledActions()
				end
			end
		else
			v12.curSplitShape = v22
			if not (p11:getIsAutomaticAlignmentActive() or p11:getIsAnimationPlaying(v12.cutAnimation.name)) then
				local v23 = p11:getAnimationTime(v12.cutAnimation.name)
				if v23 < 0.5 then
					p11:setAnimationTime(v12.cutAnimation.name, 0)
					p11:playAnimation(v12.cutAnimation.name, v12.cutAnimation.speedScale, p11:getAnimationTime(v12.cutAnimation.name))
					if p11.isClient then
						g_effectManager:setEffectTypeInfo(v12.cutEffects, FillType.WOODCHIPS)
						g_effectManager:startEffects(v12.cutEffects)
						g_soundManager:playSample(v12.samples.cut)
					end
				elseif v23 >= 0.5 then
					p11:setAnimationTime(v12.cutAnimation.name, 0)
					if p11.isClient then
						g_effectManager:stopEffects(v12.cutEffects)
						g_soundManager:stopSample(v12.samples.cut)
					end
					g_currentMission:removeKnownSplitShape(v22)
					if getVolume(v22) ~= 0 then
						p11:spawnLogHeap(getSplitType(v22), getVolume(v22))
						local v24, v25, v26 = getWorldTranslation(v22)
						p11:spawnTreeStump(v24, v25, v26)
					end
					delete(getParent(v22))
					g_treePlantManager:removingSplitShape(v22)
					local v27, _ = g_farmManager:updateFarmStats(p11:getActiveFarm(), "cutTreeCount", 1)
					if v27 ~= nil then
						g_achievementManager:tryUnlock("CutTreeFirst", v27)
						g_achievementManager:tryUnlock("CutTree", v27)
						if v27 == 1 then
							g_currentMission.introductionHelpSystem:showHint("forestryFirstTree")
						elseif v27 == 20 then
							local _, v28 = g_farmManager:getFarmStatValue(p11:getActiveFarm(), "plantedTreeCount")
							if v28 == 0 then
								g_currentMission.introductionHelpSystem:showHint("forestryStumpCutter")
							end
						end
					end
					if Platform.gameplay.automaticVehicleControl then
						p11:playControlledActions()
					end
				end
			end
		end
	end
	local v29, v30, v31, v32 = p11:getAutomaticAlignmentCurrentTarget()
	if v29 == nil then
		v12.logSpawner.lastOverlapCheckIsBlocked = false
		v12.logSpawner.pendingOverlapCheck = false
		v12.logSpawner.currentCheckIndex = 0
		v12.logSpawner.validCheckBoxIndex = 0
		v12.logSpawner.hasValidBox = false
	else
		p11:updateLogSpawner(v29, v30, v31, v32)
	end
end
function WoodHarvesterLight.onTurnedOn(p33)
	local v34 = p33.spec_woodHarvesterLight
	p33:playAnimation(v34.grabAnimation.name, v34.grabAnimation.speedScale, p33:getAnimationTime(v34.grabAnimation.name), true)
end
function WoodHarvesterLight.onTurnedOff(p35)
	local v36 = p35.spec_woodHarvesterLight
	p35:playAnimation(v36.grabAnimation.name, -v36.grabAnimation.speedScale, p35:getAnimationTime(v36.grabAnimation.name), true)
	if p35.isClient then
		g_effectManager:stopEffects(v36.cutEffects)
		g_soundManager:stopSamples(v36.samples)
	end
end
function WoodHarvesterLight.getSupportsAutoTreeAlignment(_, _)
	return true
end
function WoodHarvesterLight.getAutoAlignHasValidTree(p37, _, p38)
	local v39 = p37.spec_woodHarvesterLight
	return v39.curSplitShape ~= nil, p38 <= v39.cutNode.maxRadius
end
function WoodHarvesterLight.getAreControlledActionsAllowed(p40, p41)
	if p40:getActionControllerDirection() == 1 then
		local v42 = p40.spec_woodHarvesterLight
		local v43 = p40:getAutomaticAlignmentInvalidTreeReason()
		if v43 == AutomaticArmControlHarvester.INVALID_REASON_NONE then
			local v44, _, _, _ = p40:getAutomaticAlignmentCurrentTarget()
			if v44 == nil then
				return false, v42.texts.warning_woodHarvesterNoTreeInRange
			end
			if not v42.logSpawner.hasValidBox then
				return false, v42.texts.warning_woodHarvesterNoSpawnPlace
			end
		else
			if v43 == AutomaticArmControlHarvester.INVALID_REASON_NO_ACCESS then
				return false, v42.texts.warning_woodHarvesterTreeNotAllowed
			end
			if v43 == AutomaticArmControlHarvester.INVALID_REASON_WRONG_TYPE then
				return false, v42.texts.warning_woodHarvesterTreeTypeNotSupported
			end
			if v43 == AutomaticArmControlHarvester.INVALID_REASON_TOO_THICK then
				return false, v42.texts.warning_woodHarvesterTreeTooThick
			end
		end
	end
	return p41(p40)
end
function WoodHarvesterLight.updateLogSpawner(p45, p46, _, p47, p48)
	local v49 = p45.spec_woodHarvesterLight
	if not v49.logSpawner.pendingOverlapCheck then
		if v49.logSpawner.lastOverlapCheckIsBlocked then
			if v49.logSpawner.currentCheckIndex > v49.logSpawner.validCheckBoxIndex then
				v49.logSpawner.hasValidBox = false
				v49.logSpawner.validCheckBoxIndex = 0
			end
		else
			v49.logSpawner.hasValidBox = true
			local v50 = v49.logSpawner.lastValidBox
			local v51 = v49.logSpawner.lastValidBox
			local v52 = v49.logSpawner.lastValidBox
			local v53 = v49.logSpawner.lastValidBox
			local v54 = v49.logSpawner.lastBoxToCheck[1]
			local v55 = v49.logSpawner.lastBoxToCheck[2]
			local v56 = v49.logSpawner.lastBoxToCheck[3]
			local v57 = v49.logSpawner.lastBoxToCheck[4]
			v50[1] = v54
			v51[2] = v55
			v52[3] = v56
			v53[4] = v57
			v49.logSpawner.validCheckBoxIndex = v49.logSpawner.currentCheckIndex
			v49.logSpawner.currentCheckIndex = 0
		end
	end
	local v58 = v49.logSpawner.logSize[1] * 5
	local v59 = v49.logSpawner.logSize[2] + 0.5
	local v60 = v58 * 0.5
	local v61 = v59 * 0.5
	local v62, _, v63 = getWorldTranslation(v49.logSpawner.startNode)
	local v64, v65 = MathUtil.vector2Normalize(p46 - v62, p47 - v63)
	local v66 = MathUtil.getYRotationFromDirection(v64, v65)
	local v67 = 0
	local v68 = p48 + v49.logSpawner.offset + v58 * 0.5
	local v69 = v49.logSpawner.currentCheckIndex / 5
	local v70 = math.floor(v69) * 2
	local v71 = v49.logSpawner.currentCheckIndex % 5
	if v71 == 0 then
		v68 = v68 + v70
	elseif v71 == 1 then
		v68 = -(v68 + v70)
	elseif v71 == 2 then
		v67 = v67 - v70
		v68 = v68 + v60
	elseif v71 == 3 then
		v67 = v67 - v70
		v68 = -(v68 + v60)
	elseif v71 == 4 then
		v67 = v59 + v70
		v68 = 0
	end
	if v49.logSpawner.maxSpawnWidth < v70 then
		v49.logSpawner.currentCheckIndex = 0
	end
	local v72 = p46 + v64 * v67 + v65 * v68
	local v73 = p47 + v65 * v67 - v64 * v68
	local v74 = getTerrainHeightAtWorldPos(g_terrainNode, v72, 0, v73)
	if not v49.logSpawner.pendingOverlapCheck then
		v49.logSpawner.lastOverlapCheckIsBlocked = false
		v49.logSpawner.pendingOverlapCheck = true
		local v75 = v49.logSpawner.lastBoxToCheck
		local v76 = v49.logSpawner.lastBoxToCheck
		local v77 = v49.logSpawner.lastBoxToCheck
		local v78 = v49.logSpawner.lastBoxToCheck
		v75[1] = v72
		v76[2] = v74
		v77[3] = v73
		v78[4] = v66
		overlapBoxAsync(v72, v74, v73, 0, v66, 0, v60, 2.5, v61, "onWoodHarversterLogSpawnerCallback", p45, WoodHarvesterLight.SPAWN_COLLISION_MASK, true, true, true, true)
	end
end
function WoodHarvesterLight.onWoodHarversterLogSpawnerCallback(p79, p80, ...)
	local v81 = p79.spec_woodHarvesterLight
	if p80 ~= 0 and not (getHasClassId(p80, ClassIds.TERRAIN_TRANSFORM_GROUP) or v81.logSpawner.lastOverlapCheckIsBlocked) then
		v81.logSpawner.lastOverlapCheckIsBlocked = true
		v81.logSpawner.currentCheckIndex = v81.logSpawner.currentCheckIndex + 1
	end
	v81.logSpawner.pendingOverlapCheck = false
end
function WoodHarvesterLight.spawnLogHeap(p82, _, p83)
	local v84 = p82.spec_woodHarvesterLight
	if v84.logSpawner.hasValidBox then
		local v85 = WoodHarvesterLight.spawnLogs
		local v86 = v84.logSpawner.logFilename
		local v87 = p83 / v84.logSpawner.logVolume
		local v88 = math.floor(v87)
		v85(v86, math.max(v88, 1), v84.logSpawner.lastValidBox[1], v84.logSpawner.lastValidBox[2], v84.logSpawner.lastValidBox[3], v84.logSpawner.lastValidBox[4], v84.logSpawner.logSize[1], v84.logSpawner.logSize[2], p82:getOwnerFarmId())
	end
end
function WoodHarvesterLight.spawnLogs(p89, p90, p91, p92, p93, p94, p95, p96, p97)
	local v98, v99 = MathUtil.getDirectionFromYRotation(p94)
	local v100 = {}
	local v101
	if p90 > 2 then
		local v102 = (p90 - 1) / 2
		v101 = math.floor(v102)
	else
		v101 = 0
	end
	local v103 = p90 - v101
	local v104 = p96 * 0.5
	for v105 = 1, v103 do
		local v106 = -v103 * 0.5 * p95 + p95 * 0.5 + (v105 - 1) * p95
		local v107 = p91 + v98 * v104 + v99 * v106
		local v108 = p93 + v99 * v104 - v98 * v106
		local v109 = p91 - v98 * v104 + v99 * v106
		local v110 = p93 - v99 * v104 - v98 * v106
		local v111 = getTerrainHeightAtWorldPos(g_terrainNode, v107, p92, v108) + p95 * 0.5
		local v112 = getTerrainHeightAtWorldPos(g_terrainNode, v109, p92, v110) + p95 * 0.5
		local v113 = (v107 + v109) * 0.5
		local v114 = (v111 + v112) * 0.5
		local v115 = (v108 + v110) * 0.5
		local v116, v117, v118 = MathUtil.vector3Normalize(v107 - v109, v111 - v112, v108 - v110)
		local v119 = getTerrainHeightAtWorldPos(g_terrainNode, v113, v114, v115) + p95 * 0.5
		local v120 = {
			["sx"] = v113 + v116 * v104,
			["sy"] = v119 + v117 * v104,
			["sz"] = v115 + v118 * v104,
			["ex"] = v113 - v116 * v104,
			["ey"] = v119 - v117 * v104,
			["ez"] = v115 - v118 * v104,
			["cx"] = v113,
			["cy"] = v119,
			["cz"] = v115,
			["dx"] = v116,
			["dy"] = v117,
			["dz"] = v118
		}
		table.insert(v100, v120)
	end
	for v121 = 1, v101 do
		local v122 = v100[v121]
		local v123 = v100[v121 + 1]
		if v122 ~= nil and v123 ~= nil then
			local v124 = (v122.sx + v123.sx) * 0.5
			local v125 = (v122.sy + v123.sy) * 0.5
			local v126 = (v122.sz + v123.sz) * 0.5
			local v127 = (v122.ex + v123.ex) * 0.5
			local v128 = (v122.ey + v123.ey) * 0.5
			local v129 = (v122.ez + v123.ez) * 0.5
			local v130 = math.pow(p95, 2)
			local v131 = p95 * 0.5
			local v132 = v130 - math.pow(v131, 2)
			local v133 = math.sqrt(v132)
			local v134 = v125 + v133
			local v135 = v128 + v133
			local v136 = (v124 + v127) * 0.5
			local v137 = (v134 + v135) * 0.5
			local v138 = (v126 + v129) * 0.5
			local v139, v140, v141 = MathUtil.vector3Normalize(v124 - v127, v134 - v135, v126 - v129)
			table.insert(v100, {
				["sx"] = v124,
				["sy"] = v134,
				["sz"] = v126,
				["ex"] = v127,
				["ey"] = v135,
				["ez"] = v129,
				["cx"] = v136,
				["cy"] = v137,
				["cz"] = v138,
				["dx"] = v139,
				["dy"] = v140,
				["dz"] = v141
			})
		end
	end
	local v142 = createTransformGroup("tempHelperNode")
	link(getRootNode(), v142)
	for v143 = 1, #v100 do
		local v144 = v100[v143].cx
		local v145 = v100[v143].cy
		local v146 = v100[v143].cz
		local v147 = v100[v143].dx
		local v148 = v100[v143].dy
		local v149 = v100[v143].dz
		setTranslation(v142, v144, v145, v146)
		setDirection(v142, v147, v148, v149, 0, 1, 0)
		local v150, v151, v152 = getRotation(v142)
		local v153 = ForestryLog.new(g_currentMission:getIsServer(), g_client ~= nil)
		v153:loadFromFilename(p89, v144, v145, v146, v150, v151, v152)
		v153:setOwnerFarmId(p97)
	end
	delete(v142)
end
function WoodHarvesterLight.spawnTreeStump(_, p154, p155, p156)
	local v157 = g_treePlantManager:getTreeTypeDescFromName("pineStump")
	if v157 ~= nil then
		g_treePlantManager:plantTree(v157.index, p154, p155, p156, 0, 0, 0, 1, 1, false, nil)
	end
end

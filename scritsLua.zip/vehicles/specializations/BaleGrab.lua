BaleGrab = {}
BaleGrab.CLOSE_TIMER = 250
function BaleGrab.prerequisitesPresent(_)
	return true
end
function BaleGrab.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("BaleGrab")
	v1:register(XMLValueType.FLOAT, "vehicle.baleGrab#minSizeRound", "Min. size of round bales (for shop display only)")
	v1:register(XMLValueType.FLOAT, "vehicle.baleGrab#maxSizeRound", "Max. size of round bales (for shop display only)")
	v1:register(XMLValueType.FLOAT, "vehicle.baleGrab#minSizeSquare", "Min. size of square bales (for shop display only)")
	v1:register(XMLValueType.FLOAT, "vehicle.baleGrab#maxSizeSquare", "Max. size of square bales (for shop display only)")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.baleGrab#triggerNode", "Trigger node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.baleGrab#rootNode", "Root node", "Main component")
	v1:register(XMLValueType.STRING, "vehicle.baleGrab#dynamicMountType", "Dynamic mount type", "TYPE_FIX_ATTACH")
	v1:register(XMLValueType.FLOAT, "vehicle.baleGrab#forceAcceleration", "Force acceleration", 20)
	v1:register(XMLValueType.INT, "vehicle.baleGrab.grab(?)#componentJointIndex", "Component joint index of grab")
	v1:register(XMLValueType.FLOAT, "vehicle.baleGrab.grab(?)#dampingFactor", "Factor that is applied to the component joint rot/trans damping as soon as a bale is mounted", 20)
	v1:register(XMLValueType.INT, "vehicle.baleGrab.grab(?)#rotationAxis", "Rotation axis of component joint to detect if the grab is rotating out of the limits (only rotation or translation axis can be used)")
	v1:register(XMLValueType.ANGLE, "vehicle.baleGrab.grab(?)#rotationThreshold", "Threshold to mount the bale if the component is this angle off the component joint rotation", 5)
	v1:register(XMLValueType.INT, "vehicle.baleGrab.grab(?)#translationAxis", "Translation axis of component joint to detect if the grab is translating out of the limits (only rotation or translation axis can be used)")
	v1:register(XMLValueType.FLOAT, "vehicle.baleGrab.grab(?)#translationThreshold", "Threshold to mount the bale if the component is this translation off the component joint translation", 0.05)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.baleGrab.grab(?).movingTool(?)#node", "Node of moving tool to block while limit is exceeded")
	v1:register(XMLValueType.INT, "vehicle.baleGrab.grab(?).movingTool(?)#closingDirection", "Direction to block the moving tool", 1)
	v1:setXMLSpecializationType()
	g_storeManager:addSpecType("baleGrabMaxSizeRound", "shopListAttributeIconBaleSizeRound", BaleGrab.loadSpecValueMaxSizeRound, BaleGrab.getSpecValueMaxSizeRound, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("baleGrabMaxSizeSquare", "shopListAttributeIconBaleSizeSquare", BaleGrab.loadSpecValueMaxSizeSquare, BaleGrab.getSpecValueMaxSizeSquare, StoreSpecies.VEHICLE)
end
function BaleGrab.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "baleGrabTriggerCallback", BaleGrab.baleGrabTriggerCallback)
	SpecializationUtil.registerFunction(p2, "addDynamicMountedObject", BaleGrab.addDynamicMountedObject)
	SpecializationUtil.registerFunction(p2, "removeDynamicMountedObject", BaleGrab.removeDynamicMountedObject)
	SpecializationUtil.registerFunction(p2, "getIsBaleGrabClosed", BaleGrab.getIsBaleGrabClosed)
	SpecializationUtil.registerFunction(p2, "mountBaleGrabObject", BaleGrab.mountBaleGrabObject)
	SpecializationUtil.registerFunction(p2, "unmountBaleGrabObject", BaleGrab.unmountBaleGrabObject)
end
function BaleGrab.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "getMovingToolMoveValue", BaleGrab.getMovingToolMoveValue)
end
function BaleGrab.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", BaleGrab)
	SpecializationUtil.registerEventListener(p4, "onPostLoad", BaleGrab)
	SpecializationUtil.registerEventListener(p4, "onDelete", BaleGrab)
	SpecializationUtil.registerEventListener(p4, "onUpdateTick", BaleGrab)
end
function BaleGrab.onLoad(p_u_5, _)
	local v_u_6 = p_u_5.spec_baleGrab
	XMLUtil.checkDeprecatedXMLElements(p_u_5.xmlFile, "vehicle.baleGrab#jointType", "vehicle.baleGrab#dynamicMountType")
	XMLUtil.checkDeprecatedXMLElements(p_u_5.xmlFile, "vehicle.baleGrab#grabRefComponentJointIndex1", "vehicle.baleGrab.grab#componentJointIndex")
	XMLUtil.checkDeprecatedXMLElements(p_u_5.xmlFile, "vehicle.baleGrab#grabRefComponentJointIndex2", "vehicle.baleGrab.grab#componentJointIndex")
	XMLUtil.checkDeprecatedXMLElements(p_u_5.xmlFile, "vehicle.baleGrab#rotDiffThreshold1", "vehicle.baleGrab.grab#rotationThreshold")
	XMLUtil.checkDeprecatedXMLElements(p_u_5.xmlFile, "vehicle.baleGrab#rotDiffThreshold2", "vehicle.baleGrab.grab#rotationThreshold")
	if p_u_5.isServer then
		v_u_6.rootNode = p_u_5.xmlFile:getValue("vehicle.baleGrab#rootNode", p_u_5.rootNode, p_u_5.components, p_u_5.i3dMappings)
		v_u_6.triggerNode = p_u_5.xmlFile:getValue("vehicle.baleGrab#triggerNode", nil, p_u_5.components, p_u_5.i3dMappings)
		if v_u_6.triggerNode ~= nil then
			if CollisionFlag.getHasMaskFlagSet(v_u_6.triggerNode, CollisionFlag.DYNAMIC_OBJECT) then
				addTrigger(v_u_6.triggerNode, "baleGrabTriggerCallback", p_u_5)
			else
				Logging.xmlWarning(p_u_5.xmlFile, "BaleGrab trigger has no \'TRIGGER_DYNAMIC_OBJECT\' collision bit set!")
			end
			v_u_6.jointNode = createTransformGroup("balegrabJointNode")
			link(v_u_6.rootNode, v_u_6.jointNode)
			v_u_6.forceAcceleration = p_u_5.xmlFile:getValue("vehicle.baleGrab#forceAcceleration", 20)
			local v7 = p_u_5.xmlFile:getValue("vehicle.baleGrab#dynamicMountType", "TYPE_FIX_ATTACH")
			v_u_6.dynamicMountType = DynamicMountUtil[v7] or DynamicMountUtil.TYPE_FIX_ATTACH
			v_u_6.grabs = {}
			p_u_5.xmlFile:iterate("vehicle.baleGrab.grab", function(_, p8)
				-- upvalues: (copy) p_u_5, (copy) v_u_6
				local v_u_9 = {
					["componentJointIndex"] = p_u_5.xmlFile:getValue(p8 .. "#componentJointIndex")
				}
				if v_u_9.componentJointIndex == nil then
					Logging.xmlWarning(p_u_5.xmlFile, "Missing component joint in \'%s", p8)
				else
					v_u_9.dampingFactor = p_u_5.xmlFile:getValue(p8 .. "#dampingFactor", 20)
					v_u_9.rotationAxis = p_u_5.xmlFile:getValue(p8 .. "#rotationAxis")
					if v_u_9.rotationAxis == nil then
						v_u_9.translationAxis = p_u_5.xmlFile:getValue(p8 .. "#translationAxis")
						if v_u_9.translationAxis == nil then
							Logging.xmlWarning(p_u_5.xmlFile, "Missing rotation or translation axis in \'%s", p8)
						else
							v_u_9.translationThreshold = p_u_5.xmlFile:getValue(p8 .. "#translationThreshold", 0.05)
						end
					else
						v_u_9.rotationThreshold = p_u_5.xmlFile:getValue(p8 .. "#rotationThreshold", 5)
					end
					if v_u_9.rotationAxis ~= nil or v_u_9.translationAxis then
						v_u_9.componentJoint = p_u_5.componentJoints[v_u_9.componentJointIndex]
						if v_u_9.componentJoint == nil then
							Logging.xmlWarning(p_u_5.xmlFile, "Invalid component joint index %s in \'%s", v_u_9.componentJointIndex, p8)
						else
							v_u_9.componentJointActor0 = v_u_9.componentJoint.jointNode
							v_u_9.componentJointActor1 = v_u_9.componentJoint.jointNodeActor1
							if v_u_9.componentJointActor0 == v_u_9.componentJointActor1 then
								v_u_9.componentJointActor1 = createTransformGroup("componentJointActor1")
								if p_u_5:getParentComponent(v_u_9.componentJointActor0) == p_u_5.components[v_u_9.componentJoint.componentIndices[1]].node then
									link(p_u_5.components[v_u_9.componentJoint.componentIndices[2]].node, v_u_9.componentJointActor1)
								else
									link(p_u_5.components[v_u_9.componentJoint.componentIndices[1]].node, v_u_9.componentJointActor1)
								end
								setWorldTranslation(v_u_9.componentJointActor1, getWorldTranslation(v_u_9.componentJointActor0))
								setWorldRotation(v_u_9.componentJointActor1, getWorldRotation(v_u_9.componentJointActor0))
							end
							v_u_9.movingTools = {}
							p_u_5.xmlFile:iterate(p8 .. ".movingTool", function(_, p10)
								-- upvalues: (ref) p_u_5, (copy) v_u_9
								local v11 = {
									["node"] = p_u_5.xmlFile:getValue(p10 .. "#node", nil, p_u_5.components, p_u_5.i3dMappings)
								}
								if v11.node ~= nil then
									v11.closingDirection = p_u_5.xmlFile:getValue(p10 .. "#closingDirection")
									local v12 = v_u_9.movingTools
									table.insert(v12, v11)
								end
							end)
							v_u_9.lastValues = { 0, 0, 0 }
							v_u_9.isClosed = false
							v_u_9.closeTimer = 0
							v_u_9.jointChecksum = 0
							local v13 = v_u_6.grabs
							table.insert(v13, v_u_9)
						end
					end
				end
			end)
		end
		v_u_6.lastAllGrabsClosed = false
		v_u_6.dynamicMountedObjects = {}
		v_u_6.pendingDynamicMountObjects = {}
	end
	if v_u_6.triggerNode == nil then
		SpecializationUtil.removeEventListener(p_u_5, "onPostLoad", BaleGrab)
		SpecializationUtil.removeEventListener(p_u_5, "onDelete", BaleGrab)
		SpecializationUtil.removeEventListener(p_u_5, "onUpdateTick", BaleGrab)
	end
end
function BaleGrab.onPostLoad(p14, _)
	local v15 = p14.spec_baleGrab
	for v16 = 1, #v15.grabs do
		local v17 = v15.grabs[v16]
		for v18 = #v17.movingTools, 1, -1 do
			local v19 = v17.movingTools[v18]
			v19.movingTool = p14:getMovingToolByNode(v19.node)
			if v19.movingTool == nil then
				table.remove(v17.movingTools, v18)
			end
		end
	end
end
function BaleGrab.onDelete(p20)
	local v21 = p20.spec_baleGrab
	if v21.dynamicMountedObjects ~= nil then
		for v22, _ in pairs(v21.dynamicMountedObjects) do
			p20:unmountBaleGrabObject(v22)
		end
	end
	if v21.triggerNode ~= nil then
		removeTrigger(v21.triggerNode)
	end
end
function BaleGrab.onUpdateTick(p23, p24, _, _, _)
	if p23.isServer then
		local v25 = p23.spec_baleGrab
		local v26 = next(v25.pendingDynamicMountObjects) ~= nil
		for v27 = 1, #v25.grabs do
			local v28 = v25.grabs[v27]
			if p23:getIsBaleGrabClosed(v28) then
				local v29 = v28.closeTimer - p24
				v28.closeTimer = math.max(v29, 0)
			else
				v28.closeTimer = BaleGrab.CLOSE_TIMER
			end
			if v28.closeTimer == 0 == v28.isClosed then
				if v28.closeTimer == BaleGrab.CLOSE_TIMER then
					local v30, v31, v32 = getTranslation(v28.componentJointActor0)
					local v33, v34, v35 = getRotation(v28.componentJointActor0)
					v28.jointChecksum = v30 + v31 + v32 + v33 + v34 + v35
				end
			else
				local v36, v37, v38 = getTranslation(v28.componentJointActor0)
				local v39, v40, v41 = getRotation(v28.componentJointActor0)
				local v42 = v36 + v37 + v38 + v39 + v40 + v41
				if v28.jointChecksum == v42 then
					if next(v25.pendingDynamicMountObjects) == nil or v28.closeTimer ~= 0 then
						if next(v25.pendingDynamicMountObjects) == nil and v28.closeTimer == BaleGrab.CLOSE_TIMER then
							v28.isClosed = v28.closeTimer == 0
						end
					else
						v28.isClosed = v28.closeTimer == 0
					end
				else
					v28.jointChecksum = v42
					v28.isClosed = v28.closeTimer == 0
				end
			end
			if not v28.isClosed then
				v26 = false
			end
		end
		if v26 ~= v25.lastAllGrabsClosed then
			v25.lastAllGrabsClosed = v26
			if v26 then
				for v43, _ in pairs(v25.pendingDynamicMountObjects) do
					if v25.dynamicMountedObjects[v43] == nil and v43.dynamicMountType == MountableObject.MOUNT_TYPE_NONE then
						p23:unmountBaleGrabObject(v43)
						p23:mountBaleGrabObject(v43)
					end
				end
				for v44 = 1, #v25.grabs do
					local v45 = v25.grabs[v44]
					for v46 = 1, 3 do
						if v45.rotationAxis == nil then
							setJointTranslationLimitSpring(v45.componentJoint.jointIndex, v46 - 1, v45.componentJoint.transLimitSpring[v46], v45.componentJoint.transLimitDamping[v46] * v45.dampingFactor)
						else
							setJointRotationLimitSpring(v45.componentJoint.jointIndex, v46 - 1, v45.componentJoint.rotLimitSpring[v46], v45.componentJoint.rotLimitDamping[v46] * v45.dampingFactor)
						end
					end
				end
				return
			end
			for v47, _ in pairs(v25.dynamicMountedObjects) do
				p23:unmountBaleGrabObject(v47)
			end
			for v48 = 1, #v25.grabs do
				local v49 = v25.grabs[v48]
				for v50 = 1, 3 do
					if v49.rotationAxis == nil then
						setJointTranslationLimitSpring(v49.componentJoint.jointIndex, v50 - 1, v49.componentJoint.transLimitSpring[v50], v49.componentJoint.transLimitDamping[v50])
					else
						setJointRotationLimitSpring(v49.componentJoint.jointIndex, v50 - 1, v49.componentJoint.rotLimitSpring[v50], v49.componentJoint.rotLimitDamping[v50])
					end
				end
			end
		end
	end
end
function BaleGrab.getMovingToolMoveValue(p51, p52, p53)
	local v54 = p52(p51, p53)
	local v55 = p51.spec_baleGrab
	for v56 = 1, #v55.grabs do
		local v57 = v55.grabs[v56]
		for v58 = 1, #v57.movingTools do
			local v59 = v57.movingTools[v58]
			if v59.movingTool == p53 then
				v59.lastMoveValue = v54
				if v57.closeTimer < BaleGrab.CLOSE_TIMER and (next(v55.pendingDynamicMountObjects) ~= nil and math.sign(v54) == v59.closingDirection) then
					v54 = 0
				end
			end
		end
	end
	return v54
end
function BaleGrab.addDynamicMountedObject(p60, p61)
	p60.spec_baleGrab.dynamicMountedObjects[p61] = p61
end
function BaleGrab.removeDynamicMountedObject(p62, p63, p64)
	local v65 = p62.spec_baleGrab
	if p63.dynamicMountType == MountableObject.MOUNT_TYPE_DYNAMIC then
		p63:unmountDynamic()
	end
	v65.dynamicMountedObjects[p63] = nil
	if p64 then
		v65.pendingDynamicMountObjects[p63] = nil
	end
end
function BaleGrab.onPendingObjectDelete(p66, p67)
	local v68 = p66.spec_baleGrab
	if v68.pendingDynamicMountObjects[p67] ~= nil or v68.dynamicMountedObjects[p67] ~= nil then
		p66:removeDynamicMountedObject(p67, true)
	end
end
function BaleGrab.onPendingObjectMountStateChanged(p69, p70, p71, p72)
	if p71 ~= MountableObject.MOUNT_TYPE_NONE and p72 ~= p69 then
		local v73 = p69.spec_baleGrab
		if v73.pendingDynamicMountObjects[p70] ~= nil or v73.dynamicMountedObjects[p70] ~= nil then
			p69:removeDynamicMountedObject(p70, true)
		end
	end
end
function BaleGrab.baleGrabTriggerCallback(p74, _, p75, p76, p77, _, _)
	local v78 = p74.spec_baleGrab
	if p76 then
		local v79 = g_currentMission:getNodeObject(p75)
		if v79 ~= nil and (v79 ~= p74 and (v79.getSupportsMountDynamic ~= nil and (v79:getSupportsMountDynamic() and (v79.addMountStateChangeListener ~= nil and (v79.nodeId ~= nil or v79.rootNode ~= 0))))) then
			v78.pendingDynamicMountObjects[v79] = (v78.pendingDynamicMountObjects[v79] or 0) + 1
			if v78.pendingDynamicMountObjects[v79] == 1 then
				v79:addDeleteListener(p74, BaleGrab.onPendingObjectDelete)
				v79:addMountStateChangeListener(p74, BaleGrab.onPendingObjectMountStateChanged)
				return
			end
		end
	elseif p77 then
		local v80 = g_currentMission:getNodeObject(p75)
		if v80 ~= nil and v78.pendingDynamicMountObjects[v80] ~= nil then
			v78.pendingDynamicMountObjects[v80] = v78.pendingDynamicMountObjects[v80] - 1
			if v78.pendingDynamicMountObjects[v80] <= 0 then
				p74:removeDynamicMountedObject(v80, true)
				v80:removeDeleteListener(p74, BaleGrab.onPendingObjectDelete)
				v80:removeMountStateChangeListener(p74, BaleGrab.onPendingObjectMountStateChanged)
			end
		end
	end
end
function BaleGrab.getIsBaleGrabClosed(p81, p82)
	for v83 = 1, #p82.movingTools do
		local v84 = p82.movingTools[v83]
		local v85 = Cylindered.getMovingToolState(p81, v84.movingTool)
		if v84.closingDirection > 0 then
			if v85 < 0.01 then
				return false
			end
		elseif v85 > 0.99 then
			return false
		end
	end
	if p82.rotationAxis == nil then
		if p82.translationAxis ~= nil then
			local v86 = p82.lastValues
			local v87 = p82.lastValues
			local v88 = p82.lastValues
			local v89, v90, v91 = localToLocal(p82.componentJointActor1, p82.componentJointActor0, 0, 0, 0)
			v86[1] = v89
			v87[2] = v90
			v88[3] = v91
			if p82.translationThreshold > 0 then
				if p82.lastValues[p82.translationAxis] > p82.translationThreshold then
					return true
				end
			elseif p82.lastValues[p82.translationAxis] < p82.translationThreshold then
				return true
			end
		end
	else
		local v92 = p82.lastValues
		local v93 = p82.lastValues
		local v94 = p82.lastValues
		local v95, v96, v97 = localRotationToLocal(p82.componentJointActor1, p82.componentJointActor0, 0, 0, 0)
		v92[1] = v95
		v93[2] = v96
		v94[3] = v97
		if p82.rotationThreshold > 0 then
			if p82.lastValues[p82.rotationAxis] > p82.rotationThreshold then
				return true
			end
		elseif p82.lastValues[p82.rotationAxis] < p82.rotationThreshold then
			return true
		end
	end
	return false
end
function BaleGrab.mountBaleGrabObject(p98, p99)
	local v100 = p98.spec_baleGrab
	local v101 = p99.nodeId or p99.rootNode
	local v102, v103, v104 = localToWorld(v101, getCenterOfMass(v101))
	setWorldTranslation(v100.jointNode, v102, v103, v104)
	if not p99:mountDynamic(p98, v100.rootNode, v100.jointNode, v100.dynamicMountType, v100.forceAcceleration) then
		return false
	end
	for v105 = 1, 3 do
		setJointRotationLimitSpring(p99.dynamicMountJointIndex, v105 - 1, 10000, 10)
		setJointTranslationLimitSpring(p99.dynamicMountJointIndex, v105 - 1, 10000, 10)
	end
	p98:addDynamicMountedObject(p99)
	return true
end
function BaleGrab.unmountBaleGrabObject(p106, p107)
	p106:removeDynamicMountedObject(p107, false)
	return true
end
function BaleGrab.updateDebugValues(p108, p109)
	if p108.isServer then
		local v110 = p108.spec_baleGrab
		for v111 = 1, #v110.grabs do
			local v112 = v110.grabs[v111]
			if v112.rotationAxis == nil then
				if v112.translationAxis ~= nil then
					local v113 = false
					local v114 = v112.lastValues
					local v115 = v112.lastValues
					local v116 = v112.lastValues
					local v117, v118, v119 = localToLocal(v112.componentJointActor1, v112.componentJointActor0, 0, 0, 0)
					v114[1] = v117
					v115[2] = v118
					v116[3] = v119
					local v120
					if v112.translationThreshold > 0 then
						v120 = v112.lastValues[v112.translationAxis] > v112.translationThreshold and true or v113
					else
						v120 = v112.lastValues[v112.translationAxis] < v112.translationThreshold and true or v113
					end
					local v121 = {
						["name"] = string.format("grab (trans - %s):", getName(v112.componentJointActor0)),
						["value"] = string.format("offset: %.3f / %.3f | state: %s (t %d)", v112.lastValues[v112.translationAxis], v112.translationThreshold, v120 and "closed" or "open", v112.closeTimer)
					}
					table.insert(p109, v121)
				end
			else
				local v122 = false
				local v123 = v112.lastValues
				local v124 = v112.lastValues
				local v125 = v112.lastValues
				local v126, v127, v128 = localRotationToLocal(v112.componentJointActor1, v112.componentJointActor0, 0, 0, 0)
				v123[1] = v126
				v124[2] = v127
				v125[3] = v128
				local v129
				if v112.rotationThreshold > 0 then
					v129 = v112.lastValues[v112.rotationAxis] > v112.rotationThreshold and true or v122
				else
					v129 = v112.lastValues[v112.rotationAxis] < v112.rotationThreshold and true or v122
				end
				local v130 = {
					["name"] = string.format("grab (rot - %s):", getName(v112.componentJointActor0))
				}
				local v131 = string.format
				local v132 = v112.lastValues[v112.rotationAxis]
				local v133 = math.deg(v132)
				local v134 = v112.rotationThreshold
				v130.value = v131("offset: %.1fdeg / %.1fdeg | state: %s (t %d)", v133, math.deg(v134), v129 and "closed" or "open", v112.closeTimer)
				table.insert(p109, v130)
			end
			for v135 = 1, #v112.movingTools do
				local v136 = v112.movingTools[v135]
				local v137 = v136.lastMoveValue
				local v138 = math.sign(v137)
				local v139 = v138 == v136.closingDirection and "closing" or (v138 == 0 and "none" or "opening")
				local v140 = v138 == v136.closingDirection and (v112.closeTimer < BaleGrab.CLOSE_TIMER and next(v110.pendingDynamicMountObjects) ~= nil) and " BLOCKED" or ""
				local v141 = {
					["name"] = "movingTool:",
					["value"] = string.format("%s | direction: %s%s", getName(v136.movingTool.node), v139, v140)
				}
				table.insert(p109, v141)
			end
		end
		table.insert(p109, {
			["name"] = "--",
			["value"] = "--"
		})
		for v142, v143 in pairs(v110.pendingDynamicMountObjects) do
			local v144 = v142.nodeId or v142.rootNode
			local v145 = {
				["name"] = v110.dynamicMountedObjects[v142] == nil and "<> Pending    " or ">< Mounted    ",
				["value"] = string.format("%s (id %d, numShapes %d)", getName(v144), v144, v143)
			}
			table.insert(p109, v145)
		end
	end
end
function BaleGrab.loadSpecValueMaxSize(p146, p147, p148)
	local v149 = {
		["minSize"] = MathUtil.round(p146:getValue(p147) or 0, 2),
		["maxSize"] = MathUtil.round(p146:getValue(p148) or 0, 2)
	}
	if v149.minSize ~= 0 or v149.maxSize ~= 0 then
		return v149
	end
end
function BaleGrab.loadSpecValueMaxSizeRound(p150, _, _)
	return BaleGrab.loadSpecValueMaxSize(p150, "vehicle.baleGrab#minSizeRound", "vehicle.baleGrab#maxSizeRound")
end
function BaleGrab.loadSpecValueMaxSizeSquare(p151, _, _)
	return BaleGrab.loadSpecValueMaxSize(p151, "vehicle.baleGrab#minSizeSquare", "vehicle.baleGrab#maxSizeSquare")
end
function BaleGrab.getSpecValueMaxSize(p152, p153, _, _, _, p154, p155)
	local v156 = p153.specs[p152]
	if v156 == nil then
		return
	else
		local v157 = v156.minSize or v156.maxSize
		local v158 = v156.maxSize or v156.minSize
		if p154 == nil or not p154 then
			local v159 = g_i18n:getText("unit_cmShort")
			if v158 == v157 or (v157 == 0 or v158 == 0) then
				return string.format("%d%s", math.max(v157, v158) * 100, v159)
			else
				return string.format("%d%s-%d%s", v157 * 100, v159, v158 * 100, v159)
			end
		elseif p155 == true and (v158 ~= v157 and (v157 ~= 0 and v158 ~= 0)) then
			return v157 * 100, v158 * 100, g_i18n:getText("unit_cmShort")
		else
			return math.max(v157, v158) * 100, g_i18n:getText("unit_cmShort")
		end
	end
end
function BaleGrab.getSpecValueMaxSizeRound(p160, p161, p162, p163, p164, p165)
	return BaleGrab.getSpecValueMaxSize("baleGrabMaxSizeRound", p160, p161, p162, p163, p164, p165)
end
function BaleGrab.getSpecValueMaxSizeSquare(p166, p167, p168, p169, p170, p171)
	return BaleGrab.getSpecValueMaxSize("baleGrabMaxSizeSquare", p166, p167, p168, p169, p170, p171)
end

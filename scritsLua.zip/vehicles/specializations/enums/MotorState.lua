MotorState = {}
MotorState.OFF = 1
MotorState.IGNITION = 2
MotorState.STARTING = 3
MotorState.ON = 4
Enum(MotorState)

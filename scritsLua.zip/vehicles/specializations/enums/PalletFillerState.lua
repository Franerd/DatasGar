PalletFillerState = {}
PalletFillerState.IDLE = 1
PalletFillerState.LOADING = 2
PalletFillerState.UNLOADING = 3
Enum(PalletFillerState)

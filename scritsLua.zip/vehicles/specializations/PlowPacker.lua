PlowPacker = {}
PlowPacker.CULTIVATED_GROUND_TYPES = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.CULTIVATED,
	FieldGroundType.SEEDBED,
	FieldGroundType.ROLLED_SEEDBED
}
source("dataS/scripts/vehicles/specializations/events/PlowPackerStateEvent.lua")
function PlowPacker.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("PlowPacker")
	v1:register(XMLValueType.STRING, "vehicle.plow.packer#inputAction", "Input action name for packer toggling", "IMPLEMENT_EXTRA4")
	v1:register(XMLValueType.STRING, "vehicle.plow.packer#deactivateLeft", "Packer deactivate animation left side")
	v1:register(XMLValueType.STRING, "vehicle.plow.packer#deactivateRight", "Packer deactivate animation left side")
	v1:register(XMLValueType.FLOAT, "vehicle.plow.packer#animationSpeed", "Packer animation speed", 1)
	v1:register(XMLValueType.INT, "vehicle.plow.packer#foldingConfig", "Folding configuration with available packer", 1)
	v1:register(XMLValueType.BOOL, "vehicle.plow.packer#partialDeactivated", "Only some parts of the packer are deactivated", false)
	v1:register(XMLValueType.STRING, "vehicle.plow.packer.lowerAnimation#name", "Lower animation that is played while packer is active")
	v1:register(XMLValueType.FLOAT, "vehicle.plow.packer.lowerAnimation#speed", "Lower animation speed", 1)
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.BOOL, "vehicles.vehicle(?).plowPacker#packerState", "Packer state")
	v2:register(XMLValueType.BOOL, "vehicles.vehicle(?).plowPacker#lastPackerState", "Last packer state while turning")
end
function PlowPacker.prerequisitesPresent(p3)
	local v4 = SpecializationUtil.hasSpecialization(Plow, p3) and SpecializationUtil.hasSpecialization(Cultivator, p3)
	if v4 then
		v4 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p3)
	end
	return v4
end
function PlowPacker.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "setPackerState", PlowPacker.setPackerState)
	SpecializationUtil.registerFunction(p5, "getIsPackerAllowed", PlowPacker.getIsPackerAllowed)
end
function PlowPacker.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "setRotationMax", PlowPacker.setRotationMax)
	SpecializationUtil.registerOverwrittenFunction(p6, "setPlowAIRequirements", PlowPacker.setPlowAIRequirements)
	SpecializationUtil.registerOverwrittenFunction(p6, "setFoldState", PlowPacker.setFoldState)
	SpecializationUtil.registerOverwrittenFunction(p6, "processCultivatorArea", PlowPacker.processCultivatorArea)
	SpecializationUtil.registerOverwrittenFunction(p6, "getUseCultivatorAIRequirements", PlowPacker.getUseCultivatorAIRequirements)
end
function PlowPacker.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", PlowPacker)
	SpecializationUtil.registerEventListener(p7, "onPostLoad", PlowPacker)
	SpecializationUtil.registerEventListener(p7, "onReadStream", PlowPacker)
	SpecializationUtil.registerEventListener(p7, "onWriteStream", PlowPacker)
	SpecializationUtil.registerEventListener(p7, "onUpdate", PlowPacker)
	SpecializationUtil.registerEventListener(p7, "onUpdateTick", PlowPacker)
	SpecializationUtil.registerEventListener(p7, "onRegisterActionEvents", PlowPacker)
	SpecializationUtil.registerEventListener(p7, "onSetLowered", PlowPacker)
end
function PlowPacker.onLoad(p8, _)
	local v9 = p8.spec_plowPacker
	local v10 = p8.xmlFile:getValue("vehicle.plow.packer#inputAction", "IMPLEMENT_EXTRA4")
	if v10 ~= nil then
		v9.packerInputActionIndex = InputAction[v10]
	end
	v9.packerDeactivateLeftAnimation = p8.xmlFile:getValue("vehicle.plow.packer#deactivateLeft")
	v9.packerDeactivateRightAnimation = p8.xmlFile:getValue("vehicle.plow.packer#deactivateRight")
	v9.packerDeactivateAnimSpeed = p8.xmlFile:getValue("vehicle.plow.packer#animationSpeed", 1)
	v9.packerFoldingConfiguration = p8.xmlFile:getValue("vehicle.plow.packer#foldingConfig", 1)
	local v11
	if p8.configurations.folding == v9.packerFoldingConfiguration and v9.packerDeactivateLeftAnimation ~= nil then
		v11 = v9.packerDeactivateRightAnimation ~= nil
	else
		v11 = false
	end
	v9.packerAvailable = v11
	v9.partialDeactivated = p8.xmlFile:getValue("vehicle.plow.packer#partialDeactivated", false)
	v9.lowerAnimation = p8.xmlFile:getValue("vehicle.plow.packer.lowerAnimation#name")
	v9.lowerAnimationSpeed = p8.xmlFile:getValue("vehicle.plow.packer.lowerAnimation#speed", 1)
	v9.packerActivateText = g_i18n:getText("action_activatePacker", p8.customEnvironment)
	v9.packerDeactivateText = g_i18n:getText("action_deactivatePacker", p8.customEnvironment)
	v9.packerState = true
	v9.delayedFoldStateChange = nil
	v9.delayedLowerAnimationUpdate = false
end
function PlowPacker.onPostLoad(p12, p13)
	local v14 = p12.spec_plowPacker
	p12:setPlowAIRequirements()
	if p13 ~= nil and (not p13.resetVehicles and v14.packerAvailable) then
		local v15 = p13.xmlFile:getValue(p13.key .. ".plowPacker#packerState")
		if v15 ~= nil then
			p12:setPackerState(v15, true, true)
			AnimatedVehicle.updateAnimations(p12, 99999999, true)
		end
		v14.lastPackerState = p13.xmlFile:getValue(p13.key .. ".plowPacker#lastPackerState")
	end
end
function PlowPacker.saveToXMLFile(p16, p17, p18, _)
	local v19 = p16.spec_plowPacker
	if v19.packerAvailable then
		p17:setValue(p18 .. "#packerState", v19.packerState)
		if v19.lastPackerState ~= nil then
			p17:setValue(p18 .. "#lastPackerState", v19.lastPackerState)
		end
	end
end
function PlowPacker.onReadStream(p20, p21, _)
	if p20.spec_plowPacker.packerAvailable then
		local v22 = streamReadBool(p21)
		if p20:getIsPackerAllowed() then
			p20:setPackerState(v22, true, true)
			AnimatedVehicle.updateAnimations(p20, 99999999, true)
		end
	end
end
function PlowPacker.onWriteStream(p23, p24, _)
	local v25 = p23.spec_plowPacker
	if v25.packerAvailable then
		streamWriteBool(p24, v25.packerState)
	end
end
function PlowPacker.onUpdate(p26, _, _, _, _)
	if p26.isServer then
		local v27 = p26.spec_plowPacker
		if v27.packerAvailable then
			if v27.lastPackerState ~= nil and p26:getIsPackerAllowed() then
				if v27.lastPackerState == false then
					p26:setPackerState(false, true)
				end
				v27.lastPackerState = nil
			end
			if v27.delayedFoldStateChange ~= nil and not (p26:getIsAnimationPlaying(v27.packerDeactivateLeftAnimation) or p26:getIsAnimationPlaying(v27.packerDeactivateRightAnimation)) then
				local v28 = v27.delayedFoldStateChange
				v28.superFunc(p26, v28.direction, v28.moveToMiddle, false)
				v27.delayedFoldStateChange = nil
			end
			if v27.delayedLowerAnimationUpdate and not (p26:getIsAnimationPlaying(v27.packerDeactivateLeftAnimation) or p26:getIsAnimationPlaying(v27.packerDeactivateRightAnimation)) then
				local v29 = p26:getIsLowered()
				local v30 = p26:getAnimationTime(v27.lowerAnimation)
				if v29 and v30 <= 0.5 or not v29 and v30 > 0.5 then
					p26:playAnimation(v27.lowerAnimation, v29 and v27.lowerAnimationSpeed or -v27.lowerAnimationSpeed, nil, true)
				end
				v27.delayedLowerAnimationUpdate = false
			end
		end
	end
end
function PlowPacker.onUpdateTick(p31, _, _, _, _)
	if p31.isClient and p31.spec_plowPacker.packerAvailable then
		PlowPacker.updateActionEventText(p31)
	end
end
function PlowPacker.setRotationMax(p32, p33, p34, p35, p36)
	if p32.isServer and p32.spec_plow.rotationMax ~= p34 then
		local v37 = p32.spec_plowPacker
		if v37.packerAvailable and v37.lastPackerState == nil then
			v37.lastPackerState = v37.packerState
			p32:setPackerState(true, true)
		end
	end
	p33(p32, p34, p35, p36)
end
function PlowPacker.setPlowAIRequirements(p38, p39, p40)
	local v41 = p38.spec_plowPacker
	if v41.packerAvailable and (v41.packerState or v41.partialDeactivated) then
		return p39(p38, PlowPacker.CULTIVATED_GROUND_TYPES)
	else
		return p39(p38, p40)
	end
end
function PlowPacker.setFoldState(p42, p43, p44, p45, p46)
	local v47 = p42.spec_plowPacker
	if v47.packerAvailable and (p44 ~= 0 and (p44 ~= p42.spec_foldable.turnOnFoldDirection and (p42:getIsPackerAllowed() and not v47.packerState))) then
		if p42.isServer and v47.lastPackerState == nil then
			v47.lastPackerState = v47.packerState
			p42:setPackerState(true, true)
			v47.delayedFoldStateChange = {
				["superFunc"] = p43,
				["direction"] = p44,
				["moveToMiddle"] = p45
			}
		end
		local v48 = p42.spec_foldable
		if v48.foldMiddleAnimTime == nil then
			p45 = false
		end
		if (v48.foldMoveDirection ~= p44 or v48.moveToMiddle ~= p45) and (p46 == nil or p46 == false) then
			if g_server ~= nil then
				g_server:broadcastEvent(FoldableSetFoldDirectionEvent.new(p42, p44, p45), nil, nil, p42)
				return
			end
			g_client:getServerConnection():sendEvent(FoldableSetFoldDirectionEvent.new(p42, p44, p45))
		end
	else
		p43(p42, p44, p45, p46)
	end
end
function PlowPacker.processCultivatorArea(p49, _, p50, _)
	local v51 = p49.spec_cultivator
	local v52, _, v53 = getWorldTranslation(p50.start)
	local v54, _, v55 = getWorldTranslation(p50.width)
	local v56, _, v57 = getWorldTranslation(p50.height)
	local v58 = v51.workAreaParameters
	local v59, v60 = FSDensityMapUtil.updatePlowPackerArea(v52, v53, v54, v55, v56, v57, v58.angle)
	v58.lastChangedArea = v58.lastChangedArea + v59
	v58.lastStatsArea = v58.lastStatsArea + v59
	v58.lastTotalArea = v58.lastTotalArea + v60
	FSDensityMapUtil.eraseTireTrack(v52, v53, v54, v55, v56, v57)
	v51.isWorking = p49:getLastSpeed() > 0.5
	return v59, v60
end
function PlowPacker.getUseCultivatorAIRequirements(_, _)
	return false
end
function PlowPacker.setPackerState(p61, p62, p63, p64)
	local v65 = p61.spec_plowPacker
	if p62 == nil then
		p62 = not v65.packerState
	end
	local v66 = p63 == nil and true or p63
	if p62 ~= v65.packerState then
		v65.packerState = p62
		if v66 then
			local v67 = p62 and -1 or 1
			if p61.spec_plow.rotationMax then
				p61:playAnimation(v65.packerDeactivateLeftAnimation, v65.packerDeactivateAnimSpeed * v67, nil, true)
			else
				p61:playAnimation(v65.packerDeactivateRightAnimation, v65.packerDeactivateAnimSpeed * v67, nil, true)
			end
		end
		if p62 and v65.lowerAnimation ~= nil then
			local v68 = p61:getIsLowered()
			local v69 = p61:getAnimationTime(v65.lowerAnimation)
			if v68 and v69 <= 0.5 or not v68 and v69 > 0.5 then
				v65.delayedLowerAnimationUpdate = true
			end
		end
		p61:setPlowAIRequirements()
		PlowPackerStateEvent.sendEvent(p61, p62, v66, p64)
	end
	PlowPacker.updateActionEventText(p61)
end
function PlowPacker.getIsPackerAllowed(p70)
	if p70:getIsAnimationPlaying(p70.spec_plow.rotationPart.turnAnimation) then
		return false
	elseif p70:getFoldAnimTime() == (p70.spec_foldable.turnOnFoldDirection > 0 and 1 or 0) then
		local v71 = p70.spec_plowPacker
		if v71.delayedFoldStateChange == nil then
			return v71.packerAvailable and true or false
		else
			return false
		end
	else
		return false
	end
end
function PlowPacker.onSetLowered(p72, p73)
	local v74 = p72.spec_plowPacker
	if p72:getIsPackerAllowed() and (v74.packerState and v74.lowerAnimation ~= nil) then
		p72:playAnimation(v74.lowerAnimation, p73 and v74.lowerAnimationSpeed or -v74.lowerAnimationSpeed, nil, true)
	end
end
function PlowPacker.onRegisterActionEvents(p75, p76, _)
	if p75.isClient then
		local v77 = p75.spec_plowPacker
		if v77.packerAvailable then
			p75:clearActionEventsTable(v77.actionEvents)
			if p76 and v77.packerInputActionIndex ~= nil then
				local _, v78 = p75:addPoweredActionEvent(v77.actionEvents, v77.packerInputActionIndex, p75, PlowPacker.actionEventPackerDeactivate, false, true, false, true)
				g_inputBinding:setActionEventTextPriority(v78, GS_PRIO_NORMAL)
				PlowPacker.updateActionEventText(p75)
			end
		end
	end
end
function PlowPacker.updateActionEventText(p79)
	local v80 = p79.spec_plowPacker
	local v81 = v80.actionEvents[v80.packerInputActionIndex]
	if v81 ~= nil then
		if v80.packerState then
			g_inputBinding:setActionEventText(v81.actionEventId, v80.packerDeactivateText)
		else
			g_inputBinding:setActionEventText(v81.actionEventId, v80.packerActivateText)
		end
		g_inputBinding:setActionEventActive(v81.actionEventId, p79:getIsPackerAllowed())
	end
end
function PlowPacker.actionEventPackerDeactivate(p82, _, _, _, _, _)
	p82:setPackerState()
end

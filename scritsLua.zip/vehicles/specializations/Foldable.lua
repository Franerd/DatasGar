source("dataS/scripts/vehicles/specializations/events/FoldableSetFoldDirectionEvent.lua")
Foldable = {}
function Foldable.prerequisitesPresent(_)
	return true
end
function Foldable.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("folding", g_i18n:getText("configuration_folding"), "foldable", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Foldable")
	v1:register(XMLValueType.FLOAT, "vehicle.foldable.foldingConfigurations.foldingConfiguration(?)#workingWidth", "Working width to display in shop")
	Foldable.registerFoldingXMLPaths(v1, "vehicle.foldable.foldingConfigurations.foldingConfiguration(?).foldingParts")
	v1:register(XMLValueType.BOOL, WorkArea.WORK_AREA_XML_KEY .. "#foldLimitedOuterRange", "Fold limit outer range", false)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. ".folding#minLimit", "Min. fold limit", 0)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. ".folding#maxLimit", "Max. fold limit", 1)
	v1:register(XMLValueType.BOOL, WorkArea.WORK_AREA_XML_CONFIG_KEY .. "#foldLimitedOuterRange", "Fold limit outer range", false)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".folding#minLimit", "Min. fold limit", 0)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".folding#maxLimit", "Max. fold limit", 1)
	v1:register(XMLValueType.FLOAT, GroundReference.GROUND_REFERENCE_XML_KEY .. ".folding#minLimit", "Min. fold limit", 0)
	v1:register(XMLValueType.FLOAT, GroundReference.GROUND_REFERENCE_XML_KEY .. ".folding#maxLimit", "Max. fold limit", 1)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#foldLimitedOuterRange", "Fold limit outer range", false)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#foldMinLimit", "Min. fold limit", 0)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#foldMaxLimit", "Max. fold limit", 1)
	v1:register(XMLValueType.BOOL, Leveler.LEVELER_NODE_XML_KEY .. "#foldLimitedOuterRange", "Fold limit outer range", false)
	v1:register(XMLValueType.FLOAT, Leveler.LEVELER_NODE_XML_KEY .. "#foldMinLimit", "Min. fold limit", 0)
	v1:register(XMLValueType.FLOAT, Leveler.LEVELER_NODE_XML_KEY .. "#foldMaxLimit", "Max. fold limit", 1)
	v1:addDelayedRegistrationFunc("SlopeCompensation:compensationNode", function(p2, p3)
		p2:register(XMLValueType.FLOAT, p3 .. "#foldAngleScale", "Fold angle scale")
		p2:register(XMLValueType.BOOL, p3 .. "#invertFoldAngleScale", "Invert fold angle scale", false)
	end)
	v1:addDelayedRegistrationFunc("Cylindered:movingTool", function(p4, p5)
		p4:register(XMLValueType.FLOAT, p5 .. "#foldMinLimit", "Fold min. time", 0)
		p4:register(XMLValueType.FLOAT, p5 .. "#foldMaxLimit", "Fold max. time", 1)
		p4:register(XMLValueType.INT, p5 .. "#foldingConfigurationIndex", "Index of folding configuration to activate the moving tool")
		p4:register(XMLValueType.VECTOR_N, p5 .. "#foldingConfigurationIndices", "List of folding configuration indices to activate the moving tool")
	end)
	v1:addDelayedRegistrationFunc("Cylindered:movingPart", function(p6, p7)
		p6:register(XMLValueType.FLOAT, p7 .. "#foldMinLimit", "Fold min. time", 0)
		p6:register(XMLValueType.FLOAT, p7 .. "#foldMaxLimit", "Fold max. time", 1)
	end)
	v1:addDelayedRegistrationFunc("Attachable:support", function(p8, p9)
		p8:register(XMLValueType.FLOAT, p9 .. ".folding#minLimit", "Min. fold limit", 0)
		p8:register(XMLValueType.FLOAT, p9 .. ".folding#maxLimit", "Max. fold limit", 1)
	end)
	v1:register(XMLValueType.FLOAT, GroundAdjustedNodes.GROUND_ADJUSTED_NODE_XML_KEY .. ".foldable#minLimit", "Fold min. time", 0)
	v1:register(XMLValueType.FLOAT, GroundAdjustedNodes.GROUND_ADJUSTED_NODE_XML_KEY .. ".foldable#maxLimit", "Fold max. time", 1)
	v1:register(XMLValueType.FLOAT, Sprayer.SPRAY_TYPE_XML_KEY .. "#foldMinLimit", "Fold min. time", 0)
	v1:register(XMLValueType.FLOAT, Sprayer.SPRAY_TYPE_XML_KEY .. "#foldMaxLimit", "Fold max. time", 1)
	v1:register(XMLValueType.INT, Sprayer.SPRAY_TYPE_XML_KEY .. "#foldingConfigurationIndex", "Index of folding configuration to activate spray type")
	v1:register(XMLValueType.VECTOR_N, Sprayer.SPRAY_TYPE_XML_KEY .. "#foldingConfigurationIndices", "List of folding configuration indices to activate spray type")
	v1:register(XMLValueType.FLOAT, Attachable.INPUT_ATTACHERJOINT_XML_KEY .. "#foldMinLimit", "Fold min. time", 0)
	v1:register(XMLValueType.FLOAT, Attachable.INPUT_ATTACHERJOINT_XML_KEY .. "#foldMaxLimit", "Fold max. time", 1)
	v1:register(XMLValueType.FLOAT, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY .. "#foldMinLimit", "Fold min. time", 0)
	v1:register(XMLValueType.FLOAT, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY .. "#foldMaxLimit", "Fold max. time", 1)
	v1:register(XMLValueType.FLOAT, Attachable.INPUT_ATTACHERJOINT_XML_KEY .. ".heightNode(?)#foldMinLimit", "Fold min. time", 0)
	v1:register(XMLValueType.FLOAT, Attachable.INPUT_ATTACHERJOINT_XML_KEY .. ".heightNode(?)#foldMaxLimit", "Fold max. time", 1)
	v1:register(XMLValueType.FLOAT, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY .. ".heightNode(?)#foldMinLimit", "Fold min. time", 0)
	v1:register(XMLValueType.FLOAT, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY .. ".heightNode(?)#foldMaxLimit", "Fold max. time", 1)
	v1:register(XMLValueType.FLOAT, Enterable.ADDITIONAL_CHARACTER_XML_KEY .. "#foldMinLimit", "Fold min. time", 0)
	v1:register(XMLValueType.FLOAT, Enterable.ADDITIONAL_CHARACTER_XML_KEY .. "#foldMaxLimit", "Fold max. time", 1)
	v1:register(XMLValueType.FLOAT, Attachable.STEERING_AXLE_XML_KEY .. ".folding#minLimit", "Min. fold limit", 0)
	v1:register(XMLValueType.FLOAT, Attachable.STEERING_AXLE_XML_KEY .. ".folding#maxLimit", "Max. fold limit", 1)
	v1:register(XMLValueType.FLOAT, Wheels.WHEEL_XML_PATH .. "#versatileFoldMinLimit", "Fold min. time for versatility", 0)
	v1:register(XMLValueType.FLOAT, Wheels.WHEEL_XML_PATH .. "#versatileFoldMaxLimit", "Fold max. time for versatility", 1)
	v1:register(XMLValueType.FLOAT, FillUnit.FILL_UNIT_XML_KEY .. "#foldMinLimit", "Fold min. time for filling", 0)
	v1:register(XMLValueType.FLOAT, FillUnit.FILL_UNIT_XML_KEY .. "#foldMaxLimit", "Fold max. time for filling", 1)
	v1:register(XMLValueType.FLOAT, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#foldMinLimit", "Fold min. time for running turned on animation", 0)
	v1:register(XMLValueType.FLOAT, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#foldMaxLimit", "Fold max. time for running turned on animation", 1)
	v1:register(XMLValueType.FLOAT, Pickup.PICKUP_XML_KEY .. "#foldMinLimit", "Fold min. time for pickup lowering", 0)
	v1:register(XMLValueType.FLOAT, Pickup.PICKUP_XML_KEY .. "#foldMaxLimit", "Fold max. time for pickup lowering", 1)
	v1:register(XMLValueType.FLOAT, Cutter.CUTTER_TILT_XML_KEY .. "#foldMinLimit", "Fold min. time for cutter automatic tilt", 0)
	v1:register(XMLValueType.FLOAT, Cutter.CUTTER_TILT_XML_KEY .. "#foldMaxLimit", "Fold max. time for cutter automatic tilt", 1)
	v1:register(XMLValueType.FLOAT, VinePrepruner.PRUNER_NODE_XML_KEY .. "#foldMinLimit", "Fold min. time for pruner node update", 0)
	v1:register(XMLValueType.FLOAT, VinePrepruner.PRUNER_NODE_XML_KEY .. "#foldMaxLimit", "Fold max. time for pruner node update", 1)
	v1:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. "#foldMinLimit", "Fold min. time for shovel pickup", 0)
	v1:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. "#foldMaxLimit", "Fold max. time for shovel pickup", 1)
	v1:register(XMLValueType.FLOAT, Attachable.STEERING_ANGLE_NODE_XML_KEY .. "#foldMinLimit", "Fold min. time for steering angle nodes to update", 0)
	v1:register(XMLValueType.FLOAT, Attachable.STEERING_ANGLE_NODE_XML_KEY .. "#foldMaxLimit", "Fold max. time for steering angle nodes to update", 1)
	v1:register(XMLValueType.FLOAT, WoodHarvester.HEADER_JOINT_TILT_XML_KEY .. "#foldMinLimit", "Fold min. time for header tilt to be allowed", 0)
	v1:register(XMLValueType.FLOAT, WoodHarvester.HEADER_JOINT_TILT_XML_KEY .. "#foldMaxLimit", "Fold max. time for header tilt to be allowed", 1)
	v1:register(XMLValueType.FLOAT, Suspensions.SUSPENSION_NODE_XML_KEY .. "#foldMinLimit", "Fold min. time for suspension node to be active", 0)
	v1:register(XMLValueType.FLOAT, Suspensions.SUSPENSION_NODE_XML_KEY .. "#foldMaxLimit", "Fold max. time for suspension node to be active", 1)
	v1:setXMLSpecializationType()
	local v10 = Vehicle.xmlSchemaSavegame
	v10:register(XMLValueType.FLOAT, "vehicles.vehicle(?).foldable#foldAnimTime", "Fold animation time")
	v10:register(XMLValueType.BOOL, "vehicles.vehicle(?).foldable#isAllowed", "If folding is allowed")
end
function Foldable.registerFoldingXMLPaths(p11, p12)
	p11:register(XMLValueType.L10N_STRING, p12 .. "#objectText", "override OBJECT text inserted in folding action string", "vehicle typeDesc")
	p11:register(XMLValueType.L10N_STRING, p12 .. "#posDirectionText", "Positive direction text", "$l10n_action_foldOBJECT")
	p11:register(XMLValueType.L10N_STRING, p12 .. "#negDirectionText", "Negative direction text", "$l10n_action_unfoldOBJECT")
	p11:register(XMLValueType.L10N_STRING, p12 .. "#middlePosDirectionText", "Positive middle direction text", "$l10n_action_liftOBJECT")
	p11:register(XMLValueType.L10N_STRING, p12 .. "#middleNegDirectionText", "Negative middle direction text", "$l10n_action_lowerOBJECT")
	p11:register(XMLValueType.FLOAT, p12 .. "#startAnimTime", "Start animation time", "Depending on startMoveDirection")
	p11:register(XMLValueType.INT, p12 .. "#startMoveDirection", "Start move direction", 0)
	p11:register(XMLValueType.INT, p12 .. "#turnOnFoldDirection", "Turn on fold direction")
	p11:register(XMLValueType.BOOL, p12 .. "#allowUnfoldingByAI", "Allow folding by AI", true)
	p11:register(XMLValueType.STRING, p12 .. "#foldInputButton", "Fold Input action", "IMPLEMENT_EXTRA2")
	p11:register(XMLValueType.STRING, p12 .. "#foldMiddleInputButton", "Fold middle Input action", "LOWER_IMPLEMENT")
	p11:register(XMLValueType.FLOAT, p12 .. "#foldMiddleAnimTime", "Fold middle anim time")
	p11:register(XMLValueType.INT, p12 .. "#foldMiddleDirection", "Fold middle direction", 1)
	p11:register(XMLValueType.INT, p12 .. "#foldMiddleAIRaiseDirection", "Fold middle AI raise direction", "same as foldMiddleDirection")
	p11:register(XMLValueType.FLOAT, p12 .. "#turnOnFoldMaxLimit", "Turn on fold max. limit", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#turnOnFoldMinLimit", "Turn on fold min. limit", 0)
	p11:register(XMLValueType.FLOAT, p12 .. "#toggleCoverMaxLimit", "Toggle cover fold max. limit", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#toggleCoverMinLimit", "Toggle cover fold min. limit", 0)
	p11:register(XMLValueType.FLOAT, p12 .. "#detachingMaxLimit", "Detach fold max. limit", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#detachingMinLimit", "Detach fold min. limit", 0)
	p11:register(XMLValueType.FLOAT, p12 .. "#attachingMaxLimit", "Attach fold max. limit", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#attachingMinLimit", "Attach fold min. limit", 0)
	p11:register(XMLValueType.BOOL, p12 .. "#allowDetachingWhileFolding", "Allow detaching while folding", false)
	p11:register(XMLValueType.FLOAT, p12 .. "#loweringMaxLimit", "Lowering fold max. limit", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#loweringMinLimit", "Lowering fold min. limit", 0)
	p11:register(XMLValueType.FLOAT, p12 .. "#loadMovingToolStatesMaxLimit", "Load moving tool states fold max. limit", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#loadMovingToolStatesMinLimit", "Load moving tool states fold min. limit", 0)
	p11:register(XMLValueType.FLOAT, p12 .. "#dynamicMountMaxLimit", "Dynamic mount fold max. limit", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#dynamicMountMinLimit", "Dynamic mount fold min. limit", 0)
	p11:register(XMLValueType.FLOAT, p12 .. "#crabSteeringMinLimit", "Crab steering change fold max. limit", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#crabSteeringMaxLimit", "Crab steering change fold min. limit", 0)
	p11:register(XMLValueType.L10N_STRING, p12 .. "#unfoldWarning", "Unfold warning (Triggered when not in the right folding state for certain action (due to min/max limits))", "$l10n_warning_firstUnfoldTheTool")
	p11:register(XMLValueType.L10N_STRING, p12 .. "#detachWarning", "Detach warning (Triggered when trying to detach while currently folding)", "$l10n_warning_doNotDetachWhileFolding")
	p11:register(XMLValueType.BOOL, p12 .. "#useParentFoldingState", "The fold state can not be controlled manually. It\'s always a copy of the fold state of the parent vehicle.", false)
	p11:register(XMLValueType.BOOL, p12 .. "#ignoreFoldMiddleWhileFolded", "While the tool is folded pressing the lowering button will only control the attacher joint state, not the fold state. The lowering key has only function if the tool is unfolded. (only if fold middle time defined)", false)
	p11:register(XMLValueType.BOOL, p12 .. "#lowerWhileDetach", "If tool is in fold middle state it gets lowered on detach and lifted while it\'s attached again", false)
	p11:register(XMLValueType.BOOL, p12 .. "#keepFoldingWhileDetached", "If set to \'true\' the tool is still continuing with the folding animation after the tool is detached, otherwise it\'s stopped", "true for mobile platform, otherwise false")
	p11:register(XMLValueType.BOOL, p12 .. "#releaseBrakesWhileFolding", "If set to \'true\' the tool is releasing it\'s brakes while the folding is active", false)
	p11:register(XMLValueType.BOOL, p12 .. "#requiresPower", "Vehicle needs to be powered to change folding state", true)
	p11:register(XMLValueType.FLOAT, p12 .. ".foldingPart(?)#speedScale", "Speed scale", 1)
	p11:register(XMLValueType.INT, p12 .. ".foldingPart(?)#componentJointIndex", "Component joint index")
	p11:register(XMLValueType.INT, p12 .. ".foldingPart(?)#anchorActor", "Component joint anchor actor", 0)
	p11:register(XMLValueType.NODE_INDEX, p12 .. ".foldingPart(?)#rootNode", "Root node for animation clip")
	p11:register(XMLValueType.STRING, p12 .. ".foldingPart(?)#animationClip", "Animation clip name")
	p11:register(XMLValueType.STRING, p12 .. ".foldingPart(?)#animationName", "Animation name")
	p11:register(XMLValueType.FLOAT, p12 .. ".foldingPart(?)#delayDistance", "Distance to be moved by the vehicle until part is played")
	p11:register(XMLValueType.FLOAT, p12 .. ".foldingPart(?)#previousDuration", "lowering duration if previous part", 1)
	p11:register(XMLValueType.FLOAT, p12 .. ".foldingPart(?)#loweringDuration", "lowering duration if folding part", 1)
	p11:register(XMLValueType.FLOAT, p12 .. ".foldingPart(?)#maxDelayDuration", "Max. duration of distance delay until movement is forced. Decreases by half when not moving", 7.5)
	p11:register(XMLValueType.BOOL, p12 .. ".foldingPart(?)#aiSkipDelay", "Defines if the AI uses the delayed lowering/lifting or is controls all parts synchronized", false)
end
function Foldable.registerEvents(p13)
	SpecializationUtil.registerEvent(p13, "onFoldStateChanged")
	SpecializationUtil.registerEvent(p13, "onFoldTimeChanged")
end
function Foldable.registerFunctions(p14)
	SpecializationUtil.registerFunction(p14, "loadFoldingPartFromXML", Foldable.loadFoldingPartFromXML)
	SpecializationUtil.registerFunction(p14, "setFoldDirection", Foldable.setFoldDirection)
	SpecializationUtil.registerFunction(p14, "setFoldState", Foldable.setFoldState)
	SpecializationUtil.registerFunction(p14, "setFoldMiddleState", Foldable.setFoldMiddleState)
	SpecializationUtil.registerFunction(p14, "getIsUnfolded", Foldable.getIsUnfolded)
	SpecializationUtil.registerFunction(p14, "getFoldAnimTime", Foldable.getFoldAnimTime)
	SpecializationUtil.registerFunction(p14, "getIsFoldAllowed", Foldable.getIsFoldAllowed)
	SpecializationUtil.registerFunction(p14, "setIsFoldAllowed", Foldable.setIsFoldAllowed)
	SpecializationUtil.registerFunction(p14, "getIsFoldMiddleAllowed", Foldable.getIsFoldMiddleAllowed)
	SpecializationUtil.registerFunction(p14, "getToggledFoldDirection", Foldable.getToggledFoldDirection)
	SpecializationUtil.registerFunction(p14, "getToggledFoldMiddleDirection", Foldable.getToggledFoldMiddleDirection)
end
function Foldable.registerOverwrittenFunctions(p15)
	SpecializationUtil.registerOverwrittenFunction(p15, "allowLoadMovingToolStates", Foldable.allowLoadMovingToolStates)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadSpeedRotatingPartFromXML", Foldable.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsSpeedRotatingPartActive", Foldable.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadSlopeCompensationNodeFromXML", Foldable.loadSlopeCompensationNodeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getSlopeCompensationAngleScale", Foldable.getSlopeCompensationAngleScale)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadWheelFromXML", Foldable.loadWheelFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsVersatileYRotActive", Foldable.getIsVersatileYRotActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadWorkAreaFromXML", Foldable.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsWorkAreaActive", Foldable.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadGroundReferenceNode", Foldable.loadGroundReferenceNode)
	SpecializationUtil.registerOverwrittenFunction(p15, "updateGroundReferenceNode", Foldable.updateGroundReferenceNode)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadLevelerNodeFromXML", Foldable.loadLevelerNodeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsLevelerPickupNodeActive", Foldable.getIsLevelerPickupNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadMovingToolFromXML", Foldable.loadMovingToolFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsMovingToolActive", Foldable.getIsMovingToolActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadMovingPartFromXML", Foldable.loadMovingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsMovingPartActive", Foldable.getIsMovingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "getCanBeTurnedOn", Foldable.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsNextCoverStateAllowed", Foldable.getIsNextCoverStateAllowed)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsNextCoverStateAllowedWarning", Foldable.getIsNextCoverStateAllowedWarning)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsInWorkPosition", Foldable.getIsInWorkPosition)
	SpecializationUtil.registerOverwrittenFunction(p15, "getTurnedOnNotAllowedWarning", Foldable.getTurnedOnNotAllowedWarning)
	SpecializationUtil.registerOverwrittenFunction(p15, "isDetachAllowed", Foldable.isDetachAllowed)
	SpecializationUtil.registerOverwrittenFunction(p15, "isAttachAllowed", Foldable.isAttachAllowed)
	SpecializationUtil.registerOverwrittenFunction(p15, "getAllowsLowering", Foldable.getAllowsLowering)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsLowered", Foldable.getIsLowered)
	SpecializationUtil.registerOverwrittenFunction(p15, "getCanAIImplementContinueWork", Foldable.getCanAIImplementContinueWork)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsAIReadyToDrive", Foldable.getIsAIReadyToDrive)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsAIPreparingToDrive", Foldable.getIsAIPreparingToDrive)
	SpecializationUtil.registerOverwrittenFunction(p15, "registerLoweringActionEvent", Foldable.registerLoweringActionEvent)
	SpecializationUtil.registerOverwrittenFunction(p15, "registerSelfLoweringActionEvent", Foldable.registerSelfLoweringActionEvent)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadGroundAdjustedNodeFromXML", Foldable.loadGroundAdjustedNodeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsGroundAdjustedNodeActive", Foldable.getIsGroundAdjustedNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadSprayTypeFromXML", Foldable.loadSprayTypeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsSprayTypeActive", Foldable.getIsSprayTypeActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "getCanBeSelected", Foldable.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadInputAttacherJoint", Foldable.loadInputAttacherJoint)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsInputAttacherActive", Foldable.getIsInputAttacherActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadAdditionalCharacterFromXML", Foldable.loadAdditionalCharacterFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsAdditionalCharacterActive", Foldable.getIsAdditionalCharacterActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "getAllowDynamicMountObjects", Foldable.getAllowDynamicMountObjects)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadSupportAnimationFromXML", Foldable.loadSupportAnimationFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsSupportAnimationAllowed", Foldable.getIsSupportAnimationAllowed)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadSteeringAxleFromXML", Foldable.loadSteeringAxleFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsSteeringAxleAllowed", Foldable.getIsSteeringAxleAllowed)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadFillUnitFromXML", Foldable.loadFillUnitFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getFillUnitSupportsToolType", Foldable.getFillUnitSupportsToolType)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadTurnedOnAnimationFromXML", Foldable.loadTurnedOnAnimationFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsTurnedOnAnimationActive", Foldable.getIsTurnedOnAnimationActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadAttacherJointHeightNode", Foldable.loadAttacherJointHeightNode)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsAttacherJointHeightNodeActive", Foldable.getIsAttacherJointHeightNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadPickupFromXML", Foldable.loadPickupFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getCanChangePickupState", Foldable.getCanChangePickupState)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadCutterTiltFromXML", Foldable.loadCutterTiltFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getCutterTiltIsActive", Foldable.getCutterTiltIsActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadPreprunerNodeFromXML", Foldable.loadPreprunerNodeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsPreprunerNodeActive", Foldable.getIsPreprunerNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadShovelNode", Foldable.loadShovelNode)
	SpecializationUtil.registerOverwrittenFunction(p15, "getShovelNodeIsActive", Foldable.getShovelNodeIsActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadSteeringAngleNodeFromXML", Foldable.loadSteeringAngleNodeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "updateSteeringAngleNode", Foldable.updateSteeringAngleNode)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadWoodHarvesterHeaderTiltFromXML", Foldable.loadWoodHarvesterHeaderTiltFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsWoodHarvesterTiltStateAllowed", Foldable.getIsWoodHarvesterTiltStateAllowed)
	SpecializationUtil.registerOverwrittenFunction(p15, "loadSuspensionNodeFromXML", Foldable.loadSuspensionNodeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsSuspensionNodeActive", Foldable.getIsSuspensionNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p15, "getCanToggleCrabSteering", Foldable.getCanToggleCrabSteering)
	SpecializationUtil.registerOverwrittenFunction(p15, "getBrakeForce", Foldable.getBrakeForce)
	SpecializationUtil.registerOverwrittenFunction(p15, "getRequiresPower", Foldable.getRequiresPower)
end
function Foldable.registerEventListeners(p16)
	SpecializationUtil.registerEventListener(p16, "onLoad", Foldable)
	SpecializationUtil.registerEventListener(p16, "onPostLoad", Foldable)
	SpecializationUtil.registerEventListener(p16, "onReadStream", Foldable)
	SpecializationUtil.registerEventListener(p16, "onWriteStream", Foldable)
	SpecializationUtil.registerEventListener(p16, "onUpdate", Foldable)
	SpecializationUtil.registerEventListener(p16, "onUpdateTick", Foldable)
	SpecializationUtil.registerEventListener(p16, "onRegisterActionEvents", Foldable)
	SpecializationUtil.registerEventListener(p16, "onRegisterExternalActionEvents", Foldable)
	SpecializationUtil.registerEventListener(p16, "onDeactivate", Foldable)
	SpecializationUtil.registerEventListener(p16, "onSetLoweredAll", Foldable)
	SpecializationUtil.registerEventListener(p16, "onPostAttach", Foldable)
	SpecializationUtil.registerEventListener(p16, "onPreDetach", Foldable)
	SpecializationUtil.registerEventListener(p16, "onRootVehicleChanged", Foldable)
	SpecializationUtil.registerEventListener(p16, "onPreAttachImplement", Foldable)
	SpecializationUtil.registerEventListener(p16, "onPreDetachImplement", Foldable)
end
function Foldable.onLoad(p17, p18)
	local v19 = p17.spec_foldable
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.foldingParts", "vehicle.foldable.foldingConfigurations.foldingConfiguration.foldingParts")
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.foldable.foldingParts", "vehicle.foldable.foldingConfigurations.foldingConfiguration.foldingParts")
	local v20 = Utils.getNoNil(p17.configurations.folding, 1)
	local v21 = string.format("vehicle.foldable.foldingConfigurations.foldingConfiguration(%d).foldingParts", v20 - 1)
	v19.isFoldAllowed = true
	v19.objectText = p17.xmlFile:getValue(v21 .. "#objectText", p17.typeDesc, p17.customEnvironment, false)
	v19.posDirectionText = string.format(p17.xmlFile:getValue(v21 .. "#posDirectionText", "action_foldOBJECT", p17.customEnvironment, false), v19.objectText)
	v19.negDirectionText = string.format(p17.xmlFile:getValue(v21 .. "#negDirectionText", "action_unfoldOBJECT", p17.customEnvironment, false), v19.objectText)
	v19.middlePosDirectionText = string.format(p17.xmlFile:getValue(v21 .. "#middlePosDirectionText", "action_liftOBJECT", p17.customEnvironment, false), v19.objectText)
	v19.middleNegDirectionText = string.format(p17.xmlFile:getValue(v21 .. "#middleNegDirectionText", "action_lowerOBJECT", p17.customEnvironment, false), v19.objectText)
	v19.startAnimTime = p17.xmlFile:getValue(v21 .. "#startAnimTime")
	v19.foldMoveDirection = 0
	v19.moveToMiddle = false
	if v19.startAnimTime == nil then
		v19.startAnimTime = 0
		if p17.xmlFile:getValue(v21 .. "#startMoveDirection", 0) > 0.1 then
			v19.startAnimTime = 1
		end
	end
	v19.turnOnFoldDirection = 1
	if v19.startAnimTime > 0.5 then
		v19.turnOnFoldDirection = -1
	end
	local v22 = p17.xmlFile:getValue(v21 .. "#turnOnFoldDirection", v19.turnOnFoldDirection)
	v19.turnOnFoldDirection = math.sign(v22)
	if v19.turnOnFoldDirection == 0 then
		Logging.xmlWarning(p17.xmlFile, "Foldable \'turnOnFoldDirection\' not allowed to be 0! Only -1 and 1 are allowed")
		v19.turnOnFoldDirection = -1
	end
	v19.allowUnfoldingByAI = p17.xmlFile:getValue(v21 .. "#allowUnfoldingByAI", true)
	local v23 = p17.xmlFile:getValue(v21 .. "#foldInputButton")
	if v23 ~= nil then
		v19.foldInputButton = InputAction[v23]
	end
	v19.foldInputButton = Utils.getNoNil(v19.foldInputButton, InputAction.IMPLEMENT_EXTRA2)
	local v24 = p17.xmlFile:getValue(v21 .. "#foldMiddleInputButton")
	if v24 ~= nil then
		v19.foldMiddleInputButton = InputAction[v24]
	end
	v19.foldMiddleInputButton = Utils.getNoNil(v19.foldMiddleInputButton, InputAction.LOWER_IMPLEMENT)
	v19.foldMiddleAnimTime = p17.xmlFile:getValue(v21 .. "#foldMiddleAnimTime")
	v19.foldMiddleDirection = p17.xmlFile:getValue(v21 .. "#foldMiddleDirection", 1)
	v19.foldMiddleAIRaiseDirection = p17.xmlFile:getValue(v21 .. "#foldMiddleAIRaiseDirection", v19.foldMiddleDirection)
	v19.turnOnFoldMaxLimit = p17.xmlFile:getValue(v21 .. "#turnOnFoldMaxLimit", 1)
	v19.turnOnFoldMinLimit = p17.xmlFile:getValue(v21 .. "#turnOnFoldMinLimit", 0)
	v19.toggleCoverMaxLimit = p17.xmlFile:getValue(v21 .. "#toggleCoverMaxLimit", 1)
	v19.toggleCoverMinLimit = p17.xmlFile:getValue(v21 .. "#toggleCoverMinLimit", 0)
	v19.detachingMaxLimit = p17.xmlFile:getValue(v21 .. "#detachingMaxLimit", 1)
	v19.detachingMinLimit = p17.xmlFile:getValue(v21 .. "#detachingMinLimit", 0)
	v19.attachingMaxLimit = p17.xmlFile:getValue(v21 .. "#attachingMaxLimit", 1)
	v19.attachingMinLimit = p17.xmlFile:getValue(v21 .. "#attachingMinLimit", 0)
	v19.allowDetachingWhileFolding = p17.xmlFile:getValue(v21 .. "#allowDetachingWhileFolding", false)
	v19.loweringMaxLimit = p17.xmlFile:getValue(v21 .. "#loweringMaxLimit", 1)
	v19.loweringMinLimit = p17.xmlFile:getValue(v21 .. "#loweringMinLimit", 0)
	v19.loadMovingToolStatesMaxLimit = p17.xmlFile:getValue(v21 .. "#loadMovingToolStatesMaxLimit", 1)
	v19.loadMovingToolStatesMinLimit = p17.xmlFile:getValue(v21 .. "#loadMovingToolStatesMinLimit", 0)
	v19.dynamicMountMinLimit = p17.xmlFile:getValue(v21 .. "#dynamicMountMinLimit", 0)
	v19.dynamicMountMaxLimit = p17.xmlFile:getValue(v21 .. "#dynamicMountMaxLimit", 1)
	v19.crabSteeringMinLimit = p17.xmlFile:getValue(v21 .. "#crabSteeringMinLimit", 0)
	v19.crabSteeringMaxLimit = p17.xmlFile:getValue(v21 .. "#crabSteeringMaxLimit", 1)
	v19.unfoldWarning = string.format(p17.xmlFile:getValue(v21 .. "#unfoldWarning", "warning_firstUnfoldTheTool", p17.customEnvironment, false), v19.objectText)
	v19.detachWarning = string.format(p17.xmlFile:getValue(v21 .. "#detachWarning", "warning_doNotDetachWhileFolding", p17.customEnvironment, false), v19.objectText)
	v19.useParentFoldingState = p17.xmlFile:getValue(v21 .. "#useParentFoldingState", false)
	v19.subFoldingStateVehicles = {}
	v19.ignoreFoldMiddleWhileFolded = p17.xmlFile:getValue(v21 .. "#ignoreFoldMiddleWhileFolded", false)
	v19.lowerWhileDetach = p17.xmlFile:getValue(v21 .. "#lowerWhileDetach", false)
	v19.keepFoldingWhileDetached = p17.xmlFile:getValue(v21 .. "#keepFoldingWhileDetached", Platform.gameplay.keepFoldingWhileDetached)
	v19.releaseBrakesWhileFolding = p17.xmlFile:getValue(v21 .. "#releaseBrakesWhileFolding", false)
	v19.requiresPower = p17.xmlFile:getValue(v21 .. "#requiresPower", true)
	v19.foldAnimTime = 0
	v19.maxFoldAnimDuration = 0.0001
	v19.foldingParts = {}
	local v25 = 0
	while true do
		local v26 = string.format(v21 .. ".foldingPart(%d)", v25)
		if not p17.xmlFile:hasProperty(v26) then
			break
		end
		local v27 = {}
		if p17:loadFoldingPartFromXML(p17.xmlFile, v26, v27) then
			local v28 = v19.foldingParts
			table.insert(v28, v27)
			local v29 = v19.maxFoldAnimDuration
			local v30 = v27.animDuration
			v19.maxFoldAnimDuration = math.max(v29, v30)
		end
		v25 = v25 + 1
	end
	v19.hasFoldingParts = #v19.foldingParts > 0
	v19.actionEventsLowering = {}
	if v19.hasFoldingParts and (p18 ~= nil and not p18.resetVehicles) then
		v19.loadedFoldAnimTime = p18.xmlFile:getValue(p18.key .. ".foldable#foldAnimTime")
		v19.isFoldAllowed = p18.xmlFile:getValue(p18.key .. ".foldable#isAllowed", v19.isFoldAllowed)
	end
	if v19.loadedFoldAnimTime == nil then
		v19.loadedFoldAnimTime = v19.startAnimTime
	end
	if p17.vehicleLoadingData:getCustomParameter("foldableInvertFoldState") then
		v19.loadedFoldAnimTime = 1 - v19.loadedFoldAnimTime
	else
		local v31 = p17.vehicleLoadingData:getCustomParameter("foldableFoldingTime")
		if v31 ~= nil then
			v19.loadedFoldAnimTime = v31
		end
	end
end
function Foldable.onPostLoad(p32, _)
	local v33 = p32.spec_foldable
	Foldable.setAnimTime(p32, v33.loadedFoldAnimTime, false)
	if #v33.foldingParts == 0 or v33.useParentFoldingState then
		SpecializationUtil.removeEventListener(p32, "onReadStream", Foldable)
		SpecializationUtil.removeEventListener(p32, "onWriteStream", Foldable)
		SpecializationUtil.removeEventListener(p32, "onUpdate", Foldable)
		SpecializationUtil.removeEventListener(p32, "onUpdateTick", Foldable)
		SpecializationUtil.removeEventListener(p32, "onRegisterActionEvents", Foldable)
		SpecializationUtil.removeEventListener(p32, "onRegisterExternalActionEvents", Foldable)
		SpecializationUtil.removeEventListener(p32, "onDeactivate", Foldable)
		SpecializationUtil.removeEventListener(p32, "onSetLoweredAll", Foldable)
		SpecializationUtil.removeEventListener(p32, "onPostAttach", Foldable)
		SpecializationUtil.removeEventListener(p32, "onPreDetach", Foldable)
	end
end
function Foldable.saveToXMLFile(p34, p35, p36, _)
	local v37 = p34.spec_foldable
	if v37.hasFoldingParts then
		p35:setValue(p36 .. "#foldAnimTime", v37.foldAnimTime)
		p35:setValue(p36 .. "#isAllowed", v37.isFoldAllowed)
	end
end
function Foldable.onReadStream(p38, p39, _)
	local v40 = streamReadUIntN(p39, 2) - 1
	local v41 = streamReadBool(p39)
	local v42 = streamReadFloat32(p39)
	Foldable.setAnimTime(p38, v42, false)
	p38:setFoldState(v40, v41, true)
end
function Foldable.onWriteStream(p43, p44, _)
	local v45 = p43.spec_foldable
	local v46 = v45.foldMoveDirection
	local v47 = math.sign(v46) + 1
	streamWriteUIntN(p44, v47, 2)
	streamWriteBool(p44, v45.moveToMiddle)
	streamWriteFloat32(p44, v45.foldAnimTime)
end
function Foldable.onUpdate(p48, _, _, _, _)
	local v49 = p48.spec_foldable
	local v50 = v49.foldMoveDirection
	if math.abs(v50) > 0.1 then
		local v51 = v49.foldMoveDirection < -0.1 and 1 or 0
		local v52 = false
		for _, v53 in pairs(v49.foldingParts) do
			local v54 = v53.animCharSet
			if v49.foldMoveDirection > 0 then
				local v55
				if v54 == 0 then
					v55 = p48:getRealAnimationTime(v53.animationName)
				else
					v55 = getAnimTrackTime(v54, 0)
				end
				v52 = v55 < v53.animDuration and true or v52
				local v56 = v55 / v49.maxFoldAnimDuration
				v51 = math.max(v51, v56)
			elseif v49.foldMoveDirection < 0 then
				local v57
				if v54 == 0 then
					v57 = p48:getRealAnimationTime(v53.animationName)
				else
					v57 = getAnimTrackTime(v54, 0)
				end
				v52 = v57 > 0 and true or v52
				local v58 = v57 / v49.maxFoldAnimDuration
				v51 = math.min(v51, v58)
			end
		end
		local v59 = math.clamp(v51, 0, 1)
		if v59 ~= v49.foldAnimTime then
			v49.foldAnimTime = v59
			SpecializationUtil.raiseEvent(p48, "onFoldTimeChanged", v49.foldAnimTime)
		end
		if v49.foldMoveDirection > 0 then
			if v49.moveToMiddle and v49.foldMiddleAnimTime ~= nil then
				if v49.foldAnimTime == v49.foldMiddleAnimTime then
					v49.foldMoveDirection = 0
				end
			elseif v49.foldAnimTime == 1 then
				v49.foldMoveDirection = 0
			end
		elseif v49.foldMoveDirection < 0 then
			if v49.moveToMiddle and v49.foldMiddleAnimTime ~= nil then
				if v49.foldAnimTime == v49.foldMiddleAnimTime then
					v49.foldMoveDirection = 0
				end
			elseif v49.foldAnimTime == 0 then
				v49.foldMoveDirection = 0
			end
		end
		if v52 and p48.isServer then
			for _, v60 in pairs(v49.foldingParts) do
				if v60.componentJoint ~= nil then
					p48:setComponentJointFrame(v60.componentJoint, v60.anchorActor)
				end
			end
		end
		for _, v61 in pairs(v49.subFoldingStateVehicles) do
			Foldable.setAnimTime(v61, v49.foldAnimTime, false)
		end
	end
	for v62 = 1, #v49.foldingParts do
		local v63 = v49.foldingParts[v62]
		local v64 = v63.delayedLowering
		if v64 ~= nil and v64.currentDistance >= 0 then
			v64.currentDistance = v64.currentDistance + p48.lastMovedDistance
			if v64.prevDistance == nil and v64.startTime + v64.previousDuration < g_time then
				v64.prevDistance = v64.currentDistance
			end
			local v65 = p48.lastSpeedReal * v64.loweringDuration
			local v66 = v64.prevDistance or p48.lastSpeedReal * v64.previousDuration
			local v67 = v64.distance + v66 - v65
			local v68 = g_time
			local v69 = v64.startTime
			local v70 = v64.maxDelayDuration
			local v71 = v64.currentDistance / v67 * 0.5 + 0.5
			local v72 = v69 + v70 * math.clamp(v71, 0, 1) < v68
			if v64.aiSkipDelay then
				v72 = v72 or p48:getIsAIActive()
			end
			if v67 <= v64.currentDistance or v72 then
				p48:playAnimation(v63.animationName, v64.speedScale, v64.animTime, true)
				if v64.stopAnimTime ~= nil then
					p48:setAnimationStopTime(v63.animationName, v64.stopAnimTime)
				end
				v64.currentDistance = -1
			end
		end
	end
end
function Foldable.onUpdateTick(p73, _, _, _, _)
	local v74 = p73.spec_foldable
	if p73.isClient then
		Foldable.updateActionEventFold(p73)
		if v74.foldMiddleAnimTime ~= nil then
			Foldable.updateActionEventFoldMiddle(p73)
		end
	end
	if p73.isServer and (v74.ignoreFoldMiddleWhileFolded and p73.getAttacherVehicle ~= nil) then
		local v75 = v74.foldAnimTime - v74.foldMiddleAnimTime
		if math.abs(v75) < 0.001 and v74.foldMoveDirection == 1 == (v74.turnOnFoldDirection == 1) then
			local v76 = p73:getAttacherVehicle()
			if v76 ~= nil then
				local v77 = v76:getAttacherJointDescFromObject(p73)
				if (v77.allowsLowering or v77.isDefaultLowered) and v77.moveDown then
					p73:setFoldState(-1, false)
				end
			end
		end
	end
end
function Foldable.loadFoldingPartFromXML(p78, p79, p80, p81)
	local v82 = false
	p81.speedScale = p79:getValue(p80 .. "#speedScale", 1)
	if p81.speedScale <= 0 then
		Logging.xmlWarning(p79, "Negative speed scale for folding part \'%s\' not allowed!", p80)
		return false
	end
	local v83 = p79:getValue(p80 .. "#componentJointIndex")
	local v84
	if v83 == nil then
		v84 = nil
	else
		if v83 == 0 then
			Logging.xmlWarning(p79, "Invalid componentJointIndex for folding part \'%s\'. Indexing starts with 1!", p80)
			return false
		end
		v84 = p78.componentJoints[v83]
		p81.componentJoint = v84
	end
	p81.anchorActor = p79:getValue(p80 .. "#anchorActor", 0)
	p81.animCharSet = 0
	local v85 = p79:getValue(p80 .. "#rootNode", nil, p78.components, p78.i3dMappings)
	if v85 ~= nil then
		local v86 = getAnimCharacterSet(v85)
		if v86 ~= 0 then
			local v87 = getAnimClipIndex(v86, p79:getValue(p80 .. "#animationClip"))
			if v87 >= 0 then
				p81.animCharSet = v86
				assignAnimTrackClip(p81.animCharSet, 0, v87)
				setAnimTrackLoopState(p81.animCharSet, 0, false)
				p81.animDuration = getAnimClipDuration(p81.animCharSet, v87)
				v82 = true
			end
		end
	end
	if not v82 then
		if SpecializationUtil.hasSpecialization(AnimatedVehicle, p78.specializations) then
			local v88 = p79:getValue(p80 .. "#animationName")
			if v88 ~= nil and p78:getAnimationExists(v88) then
				p81.animDuration = p78:getAnimationDuration(v88)
				if p81.animDuration > 0 then
					p81.animationName = v88
					p78:getAnimationByName(v88).resetOnStart = true
					v82 = true
				else
					Logging.xmlWarning(p79, "Empty animation in folding part \'%s\'", p80)
				end
			end
		elseif p79:getValue(p80 .. "#animationName") ~= nil then
			Logging.xmlWarning(p79, "Found animationName in folding part \'%s\', but vehicle has no animations!", p80)
			return false
		end
	end
	if not v82 then
		Logging.xmlWarning(p79, "Invalid folding part \'%s\'. Either a animationClip or animationName needs to be defined!", p80)
		return false
	end
	local v89 = p79:getValue(p80 .. "#delayDistance")
	if v89 ~= nil then
		p81.delayedLowering = {}
		p81.delayedLowering.distance = v89
		p81.delayedLowering.previousDuration = p79:getValue(p80 .. "#previousDuration", 1) * 1000
		p81.delayedLowering.loweringDuration = p79:getValue(p80 .. "#loweringDuration", 1) * 1000
		p81.delayedLowering.maxDelayDuration = p79:getValue(p80 .. "#maxDelayDuration", 7.5) * 1000
		p81.delayedLowering.aiSkipDelay = p79:getValue(p80 .. "#aiSkipDelay", false)
		p81.delayedLowering.currentDistance = -1
		p81.delayedLowering.startTime = (1 / 0)
		p81.delayedLowering.speedScale = 0
		p81.delayedLowering.animTime = 0
		p81.delayedLowering.stopAnimTime = 0
		p81.delayedLowering.prevDistance = nil
	end
	if v84 ~= nil then
		local v90 = p78.components[v84.componentIndices[(p81.anchorActor + 1) % 2 + 1]].node
		local v91, v92, v93 = worldToLocal(v84.jointNode, getWorldTranslation(v90))
		p81.x = v91
		p81.y = v92
		p81.z = v93
		local v94, v95, v96 = worldDirectionToLocal(v84.jointNode, localDirectionToWorld(v90, 0, 1, 0))
		p81.upX = v94
		p81.upY = v95
		p81.upZ = v96
		local v97, v98, v99 = worldDirectionToLocal(v84.jointNode, localDirectionToWorld(v90, 0, 0, 1))
		p81.dirX = v97
		p81.dirY = v98
		p81.dirZ = v99
	end
	return true
end
function Foldable.setFoldDirection(p100, p101, p102)
	p100:setFoldState(p101, false, p102)
end
function Foldable.setFoldState(p103, p104, p105, p106)
	local v107 = p103.spec_foldable
	if v107.foldMiddleAnimTime == nil then
		p105 = false
	end
	if v107.foldMoveDirection ~= p104 or v107.moveToMiddle ~= p105 then
		if p106 == nil or p106 == false then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(FoldableSetFoldDirectionEvent.new(p103, p104, p105))
			else
				g_server:broadcastEvent(FoldableSetFoldDirectionEvent.new(p103, p104, p105), nil, nil, p103)
			end
		end
		v107.foldMoveDirection = p104
		v107.moveToMiddle = p105
		for _, v108 in pairs(v107.foldingParts) do
			local v109 = nil
			if v107.foldMoveDirection > 0.1 then
				if not v107.moveToMiddle or v107.foldAnimTime < v107.foldMiddleAnimTime then
					v109 = v108.speedScale
				end
			elseif v107.foldMoveDirection < -0.1 and (not v107.moveToMiddle or v107.foldAnimTime > v107.foldMiddleAnimTime) then
				v109 = -v108.speedScale
			end
			local v110 = v108.animCharSet
			if v110 == 0 then
				local v111
				if p103:getIsAnimationPlaying(v108.animationName) then
					v111 = p103:getAnimationTime(v108.animationName)
				else
					v111 = v107.foldAnimTime * v107.maxFoldAnimDuration / p103:getAnimationDuration(v108.animationName)
				end
				local v112 = p103:getIsAnimationPlaying(v108.animationName)
				p103:stopAnimation(v108.animationName, true)
				if v109 ~= nil then
					local v113
					if p105 then
						v113 = v107.foldMiddleAnimTime * v107.maxFoldAnimDuration / p103:getAnimationDuration(v108.animationName)
					else
						v113 = nil
					end
					local v114 = p104 ~= v107.turnOnFoldDirection == not p105
					if v108.delayedLowering == nil or (v114 or v112) then
						p103:playAnimation(v108.animationName, v109, v111, true)
						if p105 then
							p103:setAnimationStopTime(v108.animationName, v113)
						end
						if v108.delayedLowering ~= nil then
							v108.delayedLowering.currentDistance = -1
						end
					else
						local v115 = v108.delayedLowering
						v115.currentDistance = 0
						v115.speedScale = v109
						v115.animTime = v111
						v115.stopAnimTime = v113
						v115.startTime = g_time
						v115.prevDistance = nil
					end
				end
			elseif v109 == nil then
				disableAnimTrack(v110, 0)
			else
				if v109 > 0 then
					if getAnimTrackTime(v110, 0) < 0 then
						setAnimTrackTime(v110, 0, 0)
					end
				elseif getAnimTrackTime(v110, 0) > v108.animDuration then
					setAnimTrackTime(v110, 0, v108.animDuration)
				end
				setAnimTrackSpeedScale(v110, 0, v109)
				enableAnimTrack(v110, 0)
			end
		end
		if v107.foldMoveDirection > 0.1 then
			local v116 = v107.foldAnimTime + 0.0001
			local v117 = v107.foldAnimTime
			local v118 = math.max(v117, 1)
			v107.foldAnimTime = math.min(v116, v118)
		elseif v107.foldMoveDirection < -0.1 then
			local v119 = v107.foldAnimTime - 0.0001
			local v120 = v107.foldAnimTime
			local v121 = math.min(v120, 0)
			v107.foldAnimTime = math.max(v119, v121)
		end
		SpecializationUtil.raiseEvent(p103, "onFoldStateChanged", p104, p105)
	end
end
function Foldable.setFoldMiddleState(p122, p123)
	local v124 = p122.spec_foldable
	if v124.foldMiddleAnimTime ~= nil and p122:getIsFoldMiddleAllowed() then
		if p123 then
			p122:setFoldState(-v124.foldMiddleAIRaiseDirection, false)
			return
		end
		p122:setFoldState(v124.foldMiddleAIRaiseDirection, true)
	end
end
function Foldable.getIsUnfolded(p125)
	local v126 = p125.spec_foldable
	if v126.hasFoldingParts then
		if v126.foldMiddleAnimTime == nil then
			return v126.turnOnFoldDirection == -1 and v126.foldAnimTime == 0 or v126.turnOnFoldDirection == 1 and v126.foldAnimTime == 1
		else
			return v126.turnOnFoldDirection == -1 and v126.foldAnimTime < v126.foldMiddleAnimTime + 0.01 or v126.turnOnFoldDirection == 1 and v126.foldAnimTime > v126.foldMiddleAnimTime - 0.01
		end
	else
		return true
	end
end
function Foldable.getFoldAnimTime(p127)
	local v128 = p127.spec_foldable
	return v128.loadedFoldAnimTime or v128.foldAnimTime
end
function Foldable.setIsFoldAllowed(p129, p130)
	p129.spec_foldable.isFoldAllowed = p130
end
function Foldable.getIsFoldAllowed(p131, _, _)
	if not p131.spec_foldable.isFoldAllowed then
		return false
	end
	if p131.getAttacherVehicle ~= nil and p131:getAttacherVehicle() ~= nil then
		local v132 = p131:getActiveInputAttacherJoint()
		if v132.foldMinLimit ~= nil and v132.foldMaxLimit ~= nil then
			local v133 = p131:getFoldAnimTime()
			if v133 < v132.foldMinLimit or v132.foldMaxLimit < v133 then
				return false
			end
		end
	end
	return true
end
function Foldable.getIsFoldMiddleAllowed(p134)
	local v135 = p134.spec_foldable
	if v135.isFoldAllowed then
		return v135.foldMiddleAnimTime ~= nil
	else
		return false
	end
end
function Foldable.getToggledFoldDirection(p136)
	local v137 = p136.spec_foldable
	local v138
	if v137.foldMiddleAnimTime == nil then
		v138 = 0.5
	elseif v137.foldMiddleDirection > 0 then
		v138 = (1 + v137.foldMiddleAnimTime) * 0.5
	else
		v138 = v137.foldMiddleAnimTime * 0.5
	end
	return not v137.moveToMiddle and ((v137.foldMoveDirection > 0.1 or v137.foldMoveDirection == 0 and v138 < v137.foldAnimTime) and -1 or 1) or v137.foldMiddleDirection
end
function Foldable.getToggledFoldMiddleDirection(p139)
	local v140 = p139.spec_foldable
	local v141
	if v140.foldMiddleAnimTime == nil then
		v141 = 0
	else
		v141 = v140.foldMoveDirection > 0.1 and -1 or 1
		if v140.foldMiddleDirection > 0 then
			if v140.foldAnimTime >= v140.foldMiddleAnimTime - 0.01 then
				return -1
			end
		else
			if v140.foldAnimTime <= v140.foldMiddleAnimTime + 0.01 then
				return 1
			end
			v141 = -1
		end
	end
	return v141
end
function Foldable.allowLoadMovingToolStates(p142, p143)
	local v144 = p142.spec_foldable
	if v144.foldAnimTime > v144.loadMovingToolStatesMaxLimit or v144.foldAnimTime < v144.loadMovingToolStatesMinLimit then
		return false
	else
		return p143(p142)
	end
end
function Foldable.loadSpeedRotatingPartFromXML(p145, p146, p147, p148, p149)
	if not p146(p145, p147, p148, p149) then
		return false
	end
	p147.foldLimitedOuterRange = p148:getValue(p149 .. "#foldLimitedOuterRange", false)
	local v150, v151
	if p147.foldLimitedOuterRange then
		v150 = 0.5
		v151 = 0.5
	else
		v150 = 0
		v151 = 1
	end
	p147.foldMinLimit = p148:getValue(p149 .. "#foldMinLimit", v150)
	p147.foldMaxLimit = p148:getValue(p149 .. "#foldMaxLimit", v151)
	return true
end
function Foldable.getIsSpeedRotatingPartActive(p152, p153, p154)
	local v155 = p152.spec_foldable
	if p154.foldLimitedOuterRange then
		if v155.foldAnimTime <= p154.foldMaxLimit and v155.foldAnimTime > p154.foldMinLimit then
			return false
		end
	elseif v155.foldAnimTime > p154.foldMaxLimit or v155.foldAnimTime < p154.foldMinLimit then
		return false
	end
	return p153(p152, p154)
end
function Foldable.loadSlopeCompensationNodeFromXML(p156, p157, p158, p159, p160)
	p158.foldAngleScale = p159:getValue(p160 .. "#foldAngleScale")
	p158.invertFoldAngleScale = p159:getValue(p160 .. "#invertFoldAngleScale", false)
	return p157(p156, p158, p159, p160)
end
function Foldable.getSlopeCompensationAngleScale(p161, p162, p163)
	local v164 = p162(p161, p163)
	if p163.foldAngleScale ~= nil then
		local v165 = p161.spec_foldable
		local v166 = 1 - v165.foldAnimTime
		if p163.invertFoldAngleScale then
			v166 = 1 - v166
		end
		if v165.foldMiddleAnimTime ~= nil then
			return v164 * MathUtil.lerp(p163.foldAngleScale, 1, v166 / (1 - v165.foldMiddleAnimTime))
		end
		v164 = v164 * MathUtil.lerp(p163.foldAngleScale, 1, v166)
	end
	return v164
end
function Foldable.loadWheelFromXML(p167, p168, p169)
	p169.versatileFoldMinLimit = p169.xmlObject:getValue("#versatileFoldMinLimit", 0)
	p169.versatileFoldMaxLimit = p169.xmlObject:getValue("#versatileFoldMaxLimit", 1)
	return p168(p167, p169)
end
function Foldable.getIsVersatileYRotActive(p170, p171, p172)
	local v173 = p170.spec_foldable
	if v173.foldAnimTime > p172.versatileFoldMaxLimit or v173.foldAnimTime < p172.versatileFoldMinLimit then
		return false
	else
		return p171(p170, p172)
	end
end
function Foldable.loadWorkAreaFromXML(p174, p175, p176, p177, p178)
	p176.foldLimitedOuterRange = p177:getValue(p178 .. "#foldLimitedOuterRange", false)
	local v179, v180
	if p176.foldLimitedOuterRange then
		v179 = 0.5
		v180 = 0.5
	else
		v179 = 0
		v180 = 1
	end
	XMLUtil.checkDeprecatedXMLElements(p177, p178 .. "#foldMinLimit", p178 .. ".folding#minLimit")
	XMLUtil.checkDeprecatedXMLElements(p177, p178 .. "#foldMaxLimit", p178 .. ".folding#maxLimit")
	p176.foldMinLimit = p177:getValue(p178 .. ".folding#minLimit", v179)
	p176.foldMaxLimit = p177:getValue(p178 .. ".folding#maxLimit", v180)
	return p175(p174, p176, p177, p178)
end
function Foldable.getIsWorkAreaActive(p181, p182, p183)
	local v184 = p181.spec_foldable
	if p183.foldLimitedOuterRange then
		if v184.foldAnimTime <= p183.foldMaxLimit and v184.foldAnimTime > p183.foldMinLimit then
			return false
		end
	elseif v184.foldAnimTime > p183.foldMaxLimit or v184.foldAnimTime < p183.foldMinLimit then
		return false
	end
	return p182(p181, p183)
end
function Foldable.loadGroundReferenceNode(p185, p186, p187, p188, p189)
	local v190 = p186(p185, p187, p188, p189)
	if v190 then
		p189.foldMinLimit = p187:getValue(p188 .. ".folding#minLimit", 0)
		p189.foldMaxLimit = p187:getValue(p188 .. ".folding#maxLimit", 1)
	end
	return v190
end
function Foldable.updateGroundReferenceNode(p191, p192, p193)
	p192(p191, p193)
	local v194 = p191:getFoldAnimTime()
	if p193.foldMaxLimit < v194 or v194 < p193.foldMinLimit then
		p193.isActive = false
	end
end
function Foldable.loadLevelerNodeFromXML(p195, p196, p197, p198, p199)
	p197.foldLimitedOuterRange = p198:getValue(p199 .. "#foldLimitedOuterRange", false)
	local v200, v201
	if p197.foldLimitedOuterRange then
		v200 = 0.5
		v201 = 0.5
	else
		v200 = 0
		v201 = 1
	end
	p197.foldMinLimit = p198:getValue(p199 .. "#foldMinLimit", v200)
	p197.foldMaxLimit = p198:getValue(p199 .. "#foldMaxLimit", v201)
	return p196(p195, p197, p198, p199)
end
function Foldable.getIsLevelerPickupNodeActive(p202, p203, p204)
	local v205 = p202.spec_foldable
	if p204.foldLimitedOuterRange then
		if v205.foldAnimTime <= p204.foldMaxLimit and v205.foldAnimTime > p204.foldMinLimit then
			return false
		end
	elseif v205.foldAnimTime > p204.foldMaxLimit or v205.foldAnimTime < p204.foldMinLimit then
		return false
	end
	return p203(p202, p204)
end
function Foldable.loadMovingToolFromXML(p206, p207, p208, p209, p210)
	if not p207(p206, p208, p209, p210) then
		return false
	end
	p210.foldMinLimit = p208:getValue(p209 .. "#foldMinLimit", 0)
	p210.foldMaxLimit = p208:getValue(p209 .. "#foldMaxLimit", 1)
	p210.hasRequiredFoldingConfiguration = true
	if p206.configurations.folding ~= nil then
		local v211 = p208:getValue(p209 .. "#foldingConfigurationIndex")
		if v211 ~= nil and p206.configurations.folding ~= v211 then
			p210.hasRequiredFoldingConfiguration = false
		end
		local v212 = p208:getValue(p209 .. "#foldingConfigurationIndices", nil, true)
		if v212 ~= nil and #v212 > 0 then
			p210.hasRequiredFoldingConfiguration = false
			for v213 = 1, #v212 do
				if p206.configurations.folding == v212[v213] then
					p210.hasRequiredFoldingConfiguration = true
					break
				end
			end
		end
	end
	return true
end
function Foldable.getIsMovingToolActive(p214, p215, p216)
	if p216.hasRequiredFoldingConfiguration then
		local v217 = p214:getFoldAnimTime()
		if p216.foldMaxLimit < v217 or v217 < p216.foldMinLimit then
			return false
		else
			return p215(p214, p216)
		end
	else
		return false
	end
end
function Foldable.loadMovingPartFromXML(p218, p219, p220, p221, p222)
	if not p219(p218, p220, p221, p222) then
		return false
	end
	p222.foldMinLimit = p220:getValue(p221 .. "#foldMinLimit", 0)
	p222.foldMaxLimit = p220:getValue(p221 .. "#foldMaxLimit", 1)
	return true
end
function Foldable.getIsMovingPartActive(p223, p224, p225)
	if p225.foldMaxLimit ~= 1 or p225.foldMinLimit ~= 0 then
		local v226 = p223:getFoldAnimTime()
		if p225.foldMaxLimit < v226 or v226 < p225.foldMinLimit then
			return false
		end
	end
	return p224(p223, p225)
end
function Foldable.getCanBeTurnedOn(p227, p228)
	local v229 = p227.spec_foldable
	if v229.foldAnimTime > v229.turnOnFoldMaxLimit or v229.foldAnimTime < v229.turnOnFoldMinLimit then
		return false
	else
		return p228(p227)
	end
end
function Foldable.getIsNextCoverStateAllowed(p230, p231, p232)
	if not p231(p230, p232) then
		return false
	end
	local v233 = p230.spec_foldable
	return v233.foldAnimTime <= v233.toggleCoverMaxLimit and v233.foldAnimTime >= v233.toggleCoverMinLimit
end
function Foldable.getIsNextCoverStateAllowedWarning(p234, p235, p236)
	local v237 = p234.spec_foldable
	if v237.foldAnimTime > v237.toggleCoverMaxLimit or v237.foldAnimTime < v237.toggleCoverMinLimit then
		return v237.unfoldWarning
	else
		return p235(p234, p236)
	end
end
function Foldable.getIsInWorkPosition(p238, p239)
	local v240 = p238.spec_foldable
	if v240.turnOnFoldDirection == 0 or (#v240.foldingParts == 0 or v240.turnOnFoldDirection == -1 and v240.foldAnimTime == 0) or v240.turnOnFoldDirection == 1 and v240.foldAnimTime == 1 then
		return p239(p238)
	else
		return false
	end
end
function Foldable.getTurnedOnNotAllowedWarning(p241, p242)
	local v243 = p241.spec_foldable
	if v243.foldAnimTime > v243.turnOnFoldMaxLimit or v243.foldAnimTime < v243.turnOnFoldMinLimit then
		return v243.unfoldWarning
	else
		return p242(p241)
	end
end
function Foldable.isDetachAllowed(p244, p245)
	local v246 = p244.spec_foldable
	if v246.foldAnimTime > v246.detachingMaxLimit or v246.foldAnimTime < v246.detachingMinLimit then
		return false, v246.unfoldWarning
	end
	if not v246.allowDetachingWhileFolding then
		if v246.foldMiddleAnimTime == nil then
			::l7::
			if v246.foldAnimTime > 0 and v246.foldAnimTime < 1 then
				return false, v246.detachWarning
			end
			goto l5
		end
		local v247 = v246.foldAnimTime - v246.foldMiddleAnimTime
		if math.abs(v247) > 0.001 then
			goto l7
		end
	end
	::l5::
	return p245(p244)
end
function Foldable.isAttachAllowed(p248, p249, p250, p251)
	local v252 = p248.spec_foldable
	if v252.foldAnimTime > v252.attachingMaxLimit or v252.foldAnimTime < v252.attachingMinLimit then
		return false, v252.unfoldWarning
	else
		return p249(p248, p250, p251)
	end
end
function Foldable.getAllowsLowering(p253, p254)
	local v255 = p253.spec_foldable
	if v255.foldAnimTime > v255.loweringMaxLimit or v255.foldAnimTime < v255.loweringMinLimit then
		return false, v255.unfoldWarning
	else
		return p254(p253)
	end
end
function Foldable.getIsLowered(p256, p257, p258)
	local v259 = p256.spec_foldable
	if not p256:getIsFoldMiddleAllowed() or (v259.foldMiddleAnimTime == nil or v259.foldMiddleInputButton == nil) then
		return p257(p256, p258)
	end
	if v259.ignoreFoldMiddleWhileFolded and p256:getFoldAnimTime() > v259.foldMiddleAnimTime and true or false then
		return p257(p256, p258)
	end
	if v259.foldMoveDirection == 0 then
		if v259.foldMiddleDirection > 0 and v259.foldAnimTime < 0.01 then
			return true
		end
		if v259.foldMiddleDirection < 0 then
			local v260 = 1 - v259.foldAnimTime
			if math.abs(v260) < 0.01 then
				return true
			end
		end
	elseif v259.foldMiddleDirection > 0 then
		if v259.foldAnimTime < v259.foldMiddleAnimTime + 0.01 then
			local v261
			if v259.foldMoveDirection < 0 then
				v261 = v259.moveToMiddle ~= true
			else
				v261 = false
			end
			return v261
		end
	elseif v259.foldAnimTime > v259.foldMiddleAnimTime - 0.01 then
		local v262
		if v259.foldMoveDirection > 0 then
			v262 = v259.moveToMiddle ~= true
		else
			v262 = false
		end
		return v262
	end
	return false
end
function Foldable.registerLoweringActionEvent(p263, p264, p265, p266, p267, p268, p269, p270, p271, p272, p273, p274, p275)
	local v276 = p263.spec_foldable
	if v276.hasFoldingParts and v276.foldMiddleAnimTime ~= nil then
		p263:clearActionEventsTable(v276.actionEventsLowering)
		local v277, v278
		if v276.requiresPower then
			v277, v278 = p263:addPoweredActionEvent(v276.actionEventsLowering, v276.foldMiddleInputButton, p263, Foldable.actionEventFoldMiddle, false, true, false, true, nil, nil, p275)
		else
			v277, v278 = p263:addActionEvent(v276.actionEventsLowering, v276.foldMiddleInputButton, p263, Foldable.actionEventFoldMiddle, false, true, false, true, nil, nil, p275)
		end
		g_inputBinding:setActionEventTextPriority(v278, GS_PRIO_HIGH)
		Foldable.updateActionEventFoldMiddle(p263)
		if v276.foldMiddleInputButton == p266 then
			return v277, v278
		end
	end
	return p264(p263, p265, p266, p267, p268, p269, p270, p271, p272, p273, p274)
end
function Foldable.registerSelfLoweringActionEvent(p279, p280, p281, p282, p283, p284, p285, p286, p287, p288, p289, p290, p291)
	return Foldable.registerLoweringActionEvent(p279, p280, p281, p282, p283, p284, p285, p286, p287, p288, p289, p290, p291)
end
function Foldable.loadGroundAdjustedNodeFromXML(p292, p293, p294, p295, p296)
	if not p293(p292, p294, p295, p296) then
		return false
	end
	XMLUtil.checkDeprecatedXMLElements(p294, p295 .. "#foldMinLimit", p295 .. ".foldable#minLimit")
	XMLUtil.checkDeprecatedXMLElements(p294, p295 .. "#foldMaxLimit", p295 .. ".foldable#maxLimit")
	p296.foldMinLimit = p294:getValue(p295 .. ".foldable#minLimit", 0)
	p296.foldMaxLimit = p294:getValue(p295 .. ".foldable#maxLimit", 1)
	return true
end
function Foldable.getIsGroundAdjustedNodeActive(p297, p298, p299, p300)
	local v301 = p297.spec_foldable.foldAnimTime
	if v301 == nil or p299.foldMaxLimit >= v301 and v301 >= p299.foldMinLimit then
		return p298(p297, p299, p300)
	else
		return false
	end
end
function Foldable.loadSprayTypeFromXML(p302, p303, p304, p305, p306)
	p306.foldMinLimit = p304:getValue(p305 .. "#foldMinLimit")
	p306.foldMaxLimit = p304:getValue(p305 .. "#foldMaxLimit")
	p306.hasRequiredFoldingConfiguration = true
	if p302.configurations.folding ~= nil then
		local v307 = p304:getValue(p305 .. "#foldingConfigurationIndex")
		if v307 ~= nil and p302.configurations.folding ~= v307 then
			p306.hasRequiredFoldingConfiguration = false
		end
		local v308 = p304:getValue(p305 .. "#foldingConfigurationIndices", nil, true)
		if v308 ~= nil and #v308 > 0 then
			p306.hasRequiredFoldingConfiguration = false
			for v309 = 1, #v308 do
				if p302.configurations.folding == v308[v309] then
					p306.hasRequiredFoldingConfiguration = true
					break
				end
			end
		end
	end
	return p303(p302, p304, p305, p306)
end
function Foldable.getIsSprayTypeActive(p310, p311, p312)
	local v313 = p310.spec_foldable
	if p312.foldMinLimit ~= nil and p312.foldMaxLimit ~= nil then
		local v314 = v313.foldAnimTime
		if v314 ~= nil and (p312.foldMaxLimit < v314 or v314 < p312.foldMinLimit) then
			return false
		end
	end
	if p312.hasRequiredFoldingConfiguration then
		return p311(p310, p312)
	else
		return false
	end
end
function Foldable.getCanBeSelected(_, _)
	return true
end
function Foldable.loadInputAttacherJoint(p315, p316, p317, p318, p319, p320)
	p319.foldMinLimit = p317:getValue(p318 .. "#foldMinLimit")
	p319.foldMaxLimit = p317:getValue(p318 .. "#foldMaxLimit")
	return p316(p315, p317, p318, p319, p320)
end
function Foldable.getIsInputAttacherActive(p321, p322, p323)
	if p323.foldMinLimit ~= nil and p323.foldMaxLimit ~= nil then
		local v324 = p321:getFoldAnimTime()
		if v324 < p323.foldMinLimit or p323.foldMaxLimit < v324 then
			return false
		end
	end
	return p322(p321, p323)
end
function Foldable.loadAdditionalCharacterFromXML(p325, p326, p327)
	local v328 = p325.spec_enterable
	v328.additionalCharacterFoldMinLimit = p327:getValue("vehicle.enterable.additionalCharacter#foldMinLimit")
	v328.additionalCharacterFoldMaxLimit = p327:getValue("vehicle.enterable.additionalCharacter#foldMaxLimit")
	return p326(p325, p327)
end
function Foldable.getIsAdditionalCharacterActive(p329, p330)
	local v331 = p329.spec_enterable
	if v331.additionalCharacterFoldMinLimit ~= nil and v331.additionalCharacterFoldMaxLimit ~= nil then
		local v332 = p329:getFoldAnimTime()
		if v331.additionalCharacterFoldMinLimit <= v332 and v332 <= v331.additionalCharacterFoldMaxLimit then
			return true
		end
	end
	return p330(p329)
end
function Foldable.getAllowDynamicMountObjects(p333, p334)
	local v335 = p333.spec_foldable
	local v336 = p333:getFoldAnimTime()
	if v336 < v335.dynamicMountMinLimit or v335.dynamicMountMaxLimit < v336 then
		return false
	else
		return p334(p333)
	end
end
function Foldable.loadSupportAnimationFromXML(p337, p338, p339, p340, p341)
	XMLUtil.checkDeprecatedXMLElements(p337.xmlFile, p341 .. "#foldMinLimit", p341 .. ".folding#minLimit")
	XMLUtil.checkDeprecatedXMLElements(p337.xmlFile, p341 .. "#foldMaxLimit", p341 .. ".folding#maxLimit")
	p339.foldMinLimit = p340:getValue(p341 .. ".folding#minLimit", 0)
	p339.foldMaxLimit = p340:getValue(p341 .. ".folding#maxLimit", 1)
	return p338(p337, p339, p340, p341)
end
function Foldable.getIsSupportAnimationAllowed(p342, p343, p344)
	local v345 = p342:getFoldAnimTime()
	if v345 < p344.foldMinLimit or p344.foldMaxLimit < v345 then
		return false
	else
		return p343(p342, p344)
	end
end
function Foldable.loadSteeringAxleFromXML(p346, p347, p348, p349, p350)
	XMLUtil.checkDeprecatedXMLElements(p346.xmlFile, p350 .. "#foldMinLimit", p350 .. ".folding#minLimit")
	XMLUtil.checkDeprecatedXMLElements(p346.xmlFile, p350 .. "#foldMaxLimit", p350 .. ".folding#maxLimit")
	p348.foldMinLimit = p349:getValue(p350 .. ".folding#minLimit", 0)
	p348.foldMaxLimit = p349:getValue(p350 .. ".folding#maxLimit", 1)
	return p347(p346, p348, p349, p350)
end
function Foldable.getIsSteeringAxleAllowed(p351, p352)
	local v353 = p351.spec_attachable
	local v354 = p351:getFoldAnimTime()
	if v354 < v353.foldMinLimit or v353.foldMaxLimit < v354 then
		return false
	else
		return p352(p351)
	end
end
function Foldable.loadFillUnitFromXML(p355, p356, p357, p358, p359, p360)
	p359.foldMinLimit = p357:getValue(p358 .. "#foldMinLimit", 0)
	p359.foldMaxLimit = p357:getValue(p358 .. "#foldMaxLimit", 1)
	return p356(p355, p357, p358, p359, p360)
end
function Foldable.getFillUnitSupportsToolType(p361, p362, p363, p364)
	if p364 ~= ToolType.UNDEFINED then
		local v365 = p361.spec_fillUnit.fillUnits[p363]
		if v365 ~= nil and (v365.foldMinLimit ~= nil and v365.foldMaxLimit ~= nil) then
			local v366 = p361:getFoldAnimTime()
			if v366 < v365.foldMinLimit or v365.foldMaxLimit < v366 then
				return false
			end
		end
	end
	return p362(p361, p363, p364)
end
function Foldable.loadTurnedOnAnimationFromXML(p367, p368, p369, p370, p371)
	p371.foldMinLimit = p369:getValue(p370 .. "#foldMinLimit", 0)
	p371.foldMaxLimit = p369:getValue(p370 .. "#foldMaxLimit", 1)
	return p368(p367, p369, p370, p371)
end
function Foldable.getIsTurnedOnAnimationActive(p372, p373, p374)
	local v375 = p372:getFoldAnimTime()
	if v375 < p374.foldMinLimit or p374.foldMaxLimit < v375 then
		return false
	else
		return p373(p372, p374)
	end
end
function Foldable.loadAttacherJointHeightNode(p376, p377, p378, p379, p380, p381)
	p380.foldMinLimit = p378:getValue(p379 .. "#foldMinLimit", 0)
	p380.foldMaxLimit = p378:getValue(p379 .. "#foldMaxLimit", 1)
	return p377(p376, p378, p379, p380, p381)
end
function Foldable.getIsAttacherJointHeightNodeActive(p382, p383, p384)
	local v385 = p382:getFoldAnimTime()
	if v385 < p384.foldMinLimit or p384.foldMaxLimit < v385 then
		return false
	else
		return p383(p382, p384)
	end
end
function Foldable.loadPickupFromXML(p386, p387, p388, p389, p390)
	p390.foldMinLimit = p388:getValue(p389 .. "#foldMinLimit", 0)
	p390.foldMaxLimit = p388:getValue(p389 .. "#foldMaxLimit", 1)
	return p387(p386, p388, p389, p390)
end
function Foldable.getCanChangePickupState(p391, p392, p393, p394)
	local v395 = p391:getFoldAnimTime()
	if v395 < p393.foldMinLimit or p393.foldMaxLimit < v395 then
		return false
	else
		return p392(p391, p393, p394)
	end
end
function Foldable.loadCutterTiltFromXML(p396, p397, p398, p399, p400)
	if not p397(p396, p398, p399, p400) then
		return false
	end
	p400.foldMinLimit = p398:getValue(p399 .. "#foldMinLimit", 0)
	p400.foldMaxLimit = p398:getValue(p399 .. "#foldMaxLimit", 1)
	return true
end
function Foldable.getCutterTiltIsActive(p401, p402, p403)
	local v404, v405 = p402(p401, p403)
	if v404 then
		local v406 = p401:getFoldAnimTime()
		if v406 < p403.foldMinLimit or p403.foldMaxLimit < v406 then
			return false, true
		else
			return true, false
		end
	else
		return v404, v405
	end
end
function Foldable.loadPreprunerNodeFromXML(p407, p408, p409, p410, p411)
	if not p408(p407, p409, p410, p411) then
		return false
	end
	p411.foldMinLimit = p409:getValue(p410 .. "#foldMinLimit", 0)
	p411.foldMaxLimit = p409:getValue(p410 .. "#foldMaxLimit", 1)
	return true
end
function Foldable.getIsPreprunerNodeActive(p412, p413, p414)
	local v415 = p412:getFoldAnimTime()
	if v415 < p414.foldMinLimit or p414.foldMaxLimit < v415 then
		return false
	else
		return p413(p412, p414)
	end
end
function Foldable.loadShovelNode(p416, p417, p418, p419, p420)
	p417(p416, p418, p419, p420)
	p420.foldMinLimit = p418:getValue(p419 .. "#foldMinLimit", 0)
	p420.foldMaxLimit = p418:getValue(p419 .. "#foldMaxLimit", 1)
	return true
end
function Foldable.getShovelNodeIsActive(p421, p422, p423)
	local v424 = p421:getFoldAnimTime()
	if v424 < p423.foldMinLimit or p423.foldMaxLimit < v424 then
		return false
	else
		return p422(p421, p423)
	end
end
function Foldable.loadSteeringAngleNodeFromXML(p425, p426, p427, p428, p429)
	if not p426(p425, p427, p428, p429) then
		return false
	end
	p427.foldMinLimit = p428:getValue(p429 .. "#foldMinLimit", 0)
	p427.foldMaxLimit = p428:getValue(p429 .. "#foldMaxLimit", 1)
	return true
end
function Foldable.updateSteeringAngleNode(p430, p431, p432, p433, p434)
	local v435 = p430:getFoldAnimTime()
	if v435 >= p432.foldMinLimit and p432.foldMaxLimit >= v435 then
		return p431(p430, p432, p433, p434)
	end
end
function Foldable.loadWoodHarvesterHeaderTiltFromXML(p436, p437, p438, p439, p440)
	if not p437(p436, p438, p439, p440) then
		return false
	end
	p438.foldMinLimit = p439:getValue(p440 .. "#foldMinLimit", 0)
	p438.foldMaxLimit = p439:getValue(p440 .. "#foldMaxLimit", 1)
	return true
end
function Foldable.getIsWoodHarvesterTiltStateAllowed(p441, p442, p443)
	local v444 = p441:getFoldAnimTime()
	if v444 < p443.foldMinLimit or p443.foldMaxLimit < v444 then
		return false
	else
		return p442(p441, p443)
	end
end
function Foldable.loadSuspensionNodeFromXML(p445, p446, p447, p448, p449)
	if not p446(p445, p447, p448, p449) then
		return false
	end
	p449.foldMinLimit = p447:getValue(p448 .. "#foldMinLimit", 0)
	p449.foldMaxLimit = p447:getValue(p448 .. "#foldMaxLimit", 1)
	return true
end
function Foldable.getIsSuspensionNodeActive(p450, p451, p452)
	local v453 = p450:getFoldAnimTime()
	if v453 < p452.foldMinLimit or p452.foldMaxLimit < v453 then
		return false
	else
		return p451(p450, p452)
	end
end
function Foldable.getCanToggleCrabSteering(p454, p455)
	local v456 = p454.spec_foldable
	local v457 = p454:getFoldAnimTime()
	if v457 < v456.crabSteeringMinLimit or v456.crabSteeringMaxLimit < v457 then
		return false, v456.unfoldWarning
	else
		return p455(p454)
	end
end
function Foldable.getBrakeForce(p458, p459)
	local v460 = p458.spec_foldable
	return v460.releaseBrakesWhileFolding and v460.foldMoveDirection ~= 0 and 0 or p459(p458)
end
function Foldable.getRequiresPower(p461, p462)
	return p461.spec_foldable.foldMoveDirection ~= 0 and true or p462(p461)
end
function Foldable.onRegisterActionEvents(p463, _, p464)
	if p463.isClient then
		local v465 = p463.spec_foldable
		p463:clearActionEventsTable(v465.actionEvents)
		if p464 then
			local v466
			if v465.foldMiddleAnimTime == nil then
				v466 = false
			else
				v466 = v465.foldMiddleAnimTime == 1
			end
			if not v466 then
				local v467
				if v465.requiresPower then
					local v468
					v468, v467 = p463:addPoweredActionEvent(v465.actionEvents, v465.foldInputButton, p463, Foldable.actionEventFold, false, true, false, true, nil)
				else
					local v469
					v469, v467 = p463:addActionEvent(v465.actionEvents, v465.foldInputButton, p463, Foldable.actionEventFold, false, true, false, true, nil)
				end
				g_inputBinding:setActionEventTextPriority(v467, GS_PRIO_HIGH)
				Foldable.updateActionEventFold(p463)
				local _, v470 = p463:addPoweredActionEvent(v465.actionEvents, InputAction.FOLD_ALL_IMPLEMENTS, p463, Foldable.actionEventFoldAll, false, true, false, true, nil)
				g_inputBinding:setActionEventTextVisibility(v470, false)
			end
		end
	end
end
function Foldable.onRegisterExternalActionEvents(p471, p472, p473, _, _)
	if p473 == "folding" and p471.spec_foldable.hasFoldingParts then
		p471:registerExternalActionEvent(p472, p473, Foldable.externalActionEventRegister, Foldable.externalActionEventUpdate)
	end
end
function Foldable.getCanAIImplementContinueWork(p474, p475, p476)
	local v477, v478, v479 = p475(p474, p476)
	if not v477 then
		return false, v478, v479
	end
	local v480 = p474.spec_foldable
	if v480.hasFoldingParts and v480.allowUnfoldingByAI then
		if v480.foldMiddleAnimTime == nil then
			if v480.foldAnimTime ~= 0 and v480.foldAnimTime ~= 1 then
				return false
			end
		else
			local v481 = v480.foldAnimTime - v480.foldMiddleAnimTime
			if math.abs(v481) > 0.001 and (v480.foldAnimTime ~= 0 and v480.foldAnimTime ~= 1) then
				return v480.foldAnimTime > 0 and (v480.foldAnimTime < v480.foldMiddleAnimTime and v480.foldMoveDirection > 0)
			end
		end
	end
	return v477
end
function Foldable.getIsAIReadyToDrive(p482, p483)
	local v484 = p482.spec_foldable
	if v484.hasFoldingParts and v484.allowUnfoldingByAI then
		if v484.turnOnFoldDirection > 0 then
			if v484.foldAnimTime > 0 then
				return false
			end
		elseif v484.foldAnimTime < 1 then
			return false
		end
	end
	return p483(p482)
end
function Foldable.getIsAIPreparingToDrive(p485, p486)
	local v487 = p485.spec_foldable
	return v487.hasFoldingParts and (v487.allowUnfoldingByAI and (v487.foldAnimTime ~= v487.foldMiddleAnimTime and (v487.foldAnimTime ~= 0 and v487.foldAnimTime ~= 1))) and true or p486(p485)
end
function Foldable.onDeactivate(p488)
	local v489 = p488.spec_foldable
	if not (v489.keepFoldingWhileDetached or v489.lowerWhileDetach) then
		p488:setFoldDirection(0, true)
	end
end
function Foldable.onSetLoweredAll(p490, p491, _)
	p490:setFoldMiddleState(p491)
end
function Foldable.onPostAttach(p492, p493, _, p494)
	if p492.spec_foldable.lowerWhileDetach and (p493 ~= nil and (not p493:getAttacherJointByJointDescIndex(p494).moveDown and p492:getFoldAnimTime() < 0.001)) then
		p492:setFoldState(1, true, true)
	end
end
function Foldable.onRootVehicleChanged(p495, p496)
	local v_u_497 = p495.spec_foldable
	if v_u_497.hasFoldingParts then
		local v498 = p496.actionController
		if v498 == nil then
			if v_u_497.controlledActionFold ~= nil then
				v_u_497.controlledActionFold:remove()
			end
			if v_u_497.controlledActionLower ~= nil then
				v_u_497.controlledActionLower:remove()
			end
			if v_u_497.controlledActionLowerAIStart ~= nil then
				v_u_497.controlledActionLowerAIStart:remove()
			end
		else
			if v_u_497.controlledActionFold ~= nil then
				v_u_497.controlledActionFold:updateParent(v498)
				if v_u_497.controlledActionLower ~= nil then
					v_u_497.controlledActionLower:updateParent(v498)
				end
				if v_u_497.controlledActionLowerAIStart ~= nil then
					v_u_497.controlledActionLowerAIStart:updateParent(v498)
				end
				return
			end
			v_u_497.controlledActionFold = v498:registerAction("fold", v_u_497.toggleTurnOnInputBinding, 4)
			v_u_497.controlledActionFold:setCallback(p495, Foldable.actionControllerFoldEvent)
			v_u_497.controlledActionFold:setFinishedFunctions(p495, function(p499)
				-- upvalues: (copy) v_u_497
				if v_u_497.turnOnFoldDirection < 0 then
					local v500 = p499:getFoldAnimTime()
					return v500 == 1 and true or v500 <= (v_u_497.foldMiddleAnimTime or 0)
				else
					local v501 = p499:getFoldAnimTime()
					return v501 == 0 and true or (v_u_497.foldMiddleAnimTime or 1) <= v501
				end
			end, true, true)
			if v_u_497.allowUnfoldingByAI then
				v_u_497.controlledActionFold:addAIEventListener(p495, "onAIFieldWorkerPrepareForWork", 1)
				v_u_497.controlledActionFold:addAIEventListener(p495, "onAIImplementPrepareForWork", 1)
				v_u_497.controlledActionFold:addAIEventListener(p495, "onAIImplementPrepareForTransport", -1, true)
				if Platform.gameplay.foldAfterAIFinished then
					v_u_497.controlledActionFold:addAIEventListener(p495, "onAIImplementEnd", -1, true)
					v_u_497.controlledActionFold:addAIEventListener(p495, "onAIFieldWorkerEnd", -1)
				end
			end
			if p495:getIsFoldMiddleAllowed() then
				v_u_497.controlledActionLower = v498:registerAction("lowerFoldable", v_u_497.toggleTurnOnInputBinding, 3)
				v_u_497.controlledActionLower:setCallback(p495, Foldable.actionControllerLowerEvent)
				v_u_497.controlledActionLower:setFinishedFunctions(p495, p495.getFoldAnimTime, v_u_497.turnOnFoldDirection < 0 and 0 or 1, v_u_497.foldMiddleAnimTime)
				v_u_497.controlledActionLower:setResetOnDeactivation(false)
				if v_u_497.allowUnfoldingByAI then
					v_u_497.controlledActionLower:addAIEventListener(p495, "onAIImplementStartLine", 1)
					v_u_497.controlledActionLower:addAIEventListener(p495, "onAIImplementEndLine", -1)
				end
				v_u_497.controlledActionLowerAIStart = v498:registerAction("lowerFoldableAIStart", v_u_497.toggleTurnOnInputBinding, 3)
				v_u_497.controlledActionLowerAIStart:setCallback(p495, Foldable.actionControllerLowerEventAIStart)
				v_u_497.controlledActionLowerAIStart:setFinishedFunctions(p495, p495.getFoldAnimTime, v_u_497.turnOnFoldDirection < 0 and 0 or 1, v_u_497.foldMiddleAnimTime)
				v_u_497.controlledActionLowerAIStart:setResetOnDeactivation(false)
				if v_u_497.allowUnfoldingByAI then
					v_u_497.controlledActionLowerAIStart:addAIEventListener(p495, "onAIImplementStart", -1)
					return
				end
			end
		end
	end
end
function Foldable.actionControllerFoldEvent(p502, p503)
	local v504 = p502.spec_foldable
	if v504.hasFoldingParts then
		if p502:getIsFoldMiddleAllowed() and (v504.foldAnimTime > 0 and v504.foldAnimTime < v504.foldMiddleAnimTime) then
			return false
		end
		local v505 = v504.turnOnFoldDirection * p503
		if p502:getIsFoldAllowed(v505, false) then
			if v505 == v504.turnOnFoldDirection then
				if v505 < 0 and v504.foldAnimTime > 0 or v505 > 0 and v504.foldAnimTime < 1 then
					p502:setFoldState(v505, true)
				end
			elseif v505 < 0 and v504.foldAnimTime > 0 or v505 > 0 and v504.foldAnimTime < 1 then
				p502:setFoldState(v505, false)
			end
			return true
		end
	end
	return false
end
function Foldable.actionControllerLowerEvent(p506, p507)
	local v508 = p506.spec_foldable
	if v508.hasFoldingParts then
		local v509 = v508.turnOnFoldDirection * p507
		if p506:getIsFoldMiddleAllowed() then
			if v509 == v508.turnOnFoldDirection then
				p506:setFoldState(v509, false)
			elseif v508.foldMiddleDirection > 0 then
				if v508.foldAnimTime > v508.foldMiddleAnimTime then
					p506:setFoldState(-v509, true)
				else
					p506:setFoldState(v509, true)
				end
			elseif v508.foldAnimTime < v508.foldMiddleAnimTime then
				p506:setFoldState(-v509, true)
			else
				p506:setFoldState(v509, true)
			end
			return true
		end
	end
	return false
end
function Foldable.actionControllerLowerEventAIStart(p510, p511)
	local v512 = p510.spec_foldable
	if v512.hasFoldingParts then
		local v513 = v512.turnOnFoldDirection * p511
		if p510:getIsFoldMiddleAllowed() then
			if v512.foldAnimTime >= v512.foldMiddleAnimTime then
				return true
			end
			if v512.foldMiddleDirection > 0 then
				if v512.foldAnimTime > v512.foldMiddleAnimTime then
					p510:setFoldState(-v513, true)
				else
					p510:setFoldState(v513, true)
				end
			elseif v512.foldAnimTime < v512.foldMiddleAnimTime then
				p510:setFoldState(-v513, true)
			else
				p510:setFoldState(v513, true)
			end
		end
	end
	return true
end
function Foldable.onPreDetach(p514, _, _)
	local v515 = p514.spec_foldable
	if v515.lowerWhileDetach and v515.foldMiddleAnimTime ~= nil then
		local v516 = p514:getFoldAnimTime() - v515.foldMiddleAnimTime
		if math.abs(v516) < 0.001 then
			p514:setFoldState(-1, false, true)
		end
	end
end
function Foldable.onPreAttachImplement(p517, p518, _, _)
	local v519 = p518.spec_foldable
	if v519 ~= nil and v519.useParentFoldingState then
		p517.spec_foldable.subFoldingStateVehicles[p518] = p518
		Foldable.setAnimTime(p518, p517.spec_foldable.foldAnimTime, false)
	end
end
function Foldable.onPreDetachImplement(p520, p521)
	local v522 = p521.object.spec_foldable
	if v522 ~= nil and v522.useParentFoldingState then
		p520.spec_foldable.subFoldingStateVehicles[p521.object] = nil
	end
end
function Foldable.setAnimTime(p523, p524, p525)
	local v526 = p523.spec_foldable
	v526.foldAnimTime = p524
	v526.loadedFoldAnimTime = nil
	for _, v527 in pairs(v526.foldingParts) do
		if v527.animCharSet == 0 then
			p524 = v526.foldAnimTime * v526.maxFoldAnimDuration / p523:getAnimationDuration(v527.animationName)
			p523:setAnimationTime(v527.animationName, p524, true)
		else
			enableAnimTrack(v527.animCharSet, 0)
			setAnimTrackTime(v527.animCharSet, 0, v526.foldAnimTime * v527.animDuration, true)
			disableAnimTrack(v527.animCharSet, 0)
		end
	end
	local v528 = p525 == nil and true or p525
	if p523.updateCylinderedInitial ~= nil then
		p523:updateCylinderedInitial(v528)
	end
	if v528 and p523.isServer then
		for _, v529 in pairs(v526.foldingParts) do
			if v529.componentJoint ~= nil then
				local v530 = v529.componentJoint
				local v531 = v530.jointNode
				if v529.anchorActor == 1 then
					v531 = v530.jointNodeActor1
				end
				local v532 = p523.components[v530.componentIndices[(v529.anchorActor + 1) % 2 + 1]].node
				local v533, v534, v535 = localToWorld(v531, v529.x, v529.y, v529.z)
				local v536, v537, v538 = localDirectionToWorld(v531, v529.upX, v529.upY, v529.upZ)
				local v539, v540, v541 = localDirectionToWorld(v531, v529.dirX, v529.dirY, v529.dirZ)
				setWorldTranslation(v532, v533, v534, v535)
				I3DUtil.setWorldDirection(v532, v539, v540, v541, v536, v537, v538)
				p523:setComponentJointFrame(v530, v529.anchorActor)
			end
		end
	end
	for _, v542 in pairs(v526.subFoldingStateVehicles) do
		Foldable.setAnimTime(v542, p524, v528)
	end
	SpecializationUtil.raiseEvent(p523, "onFoldTimeChanged", v526.foldAnimTime)
end
function Foldable.updateActionEventFold(p543)
	local v544 = p543.spec_foldable
	local v545 = v544.actionEvents[v544.foldInputButton]
	if v545 ~= nil then
		local v546
		if p543:getToggledFoldDirection() == v544.turnOnFoldDirection then
			v546 = v544.negDirectionText
		else
			v546 = v544.posDirectionText
		end
		g_inputBinding:setActionEventText(v545.actionEventId, v546)
		g_inputBinding:setActionEventActive(v545.actionEventId, p543:getIsFoldAllowed())
	end
end
function Foldable.updateActionEventFoldMiddle(p547)
	local v548 = p547.spec_foldable
	local v549 = v548.actionEventsLowering[v548.foldMiddleInputButton]
	if v549 ~= nil then
		local v550 = p547:getIsFoldMiddleAllowed()
		g_inputBinding:setActionEventActive(v549.actionEventId, v550)
		if v550 then
			local v551 = p547:getToggledFoldMiddleDirection() == v548.foldMiddleDirection
			if v548.ignoreFoldMiddleWhileFolded and p547:getFoldAnimTime() > v548.foldMiddleAnimTime then
				v551 = p547:getIsLowered(true)
			end
			local v552
			if v551 then
				v552 = v548.middlePosDirectionText
			else
				v552 = v548.middleNegDirectionText
			end
			g_inputBinding:setActionEventText(v549.actionEventId, v552)
		end
	end
end
function Foldable.actionEventFold(p553, _, _, _, _)
	local v554 = p553.spec_foldable
	if v554.hasFoldingParts then
		local v555 = p553:getToggledFoldDirection()
		local v556, v557 = p553:getIsFoldAllowed(v555, false)
		if v556 then
			if v555 == v554.turnOnFoldDirection then
				p553:setFoldState(v555, true)
				return
			end
			p553:setFoldState(v555, false)
			if p553:getIsFoldMiddleAllowed() and p553.getAttacherVehicle ~= nil then
				local v558 = p553:getAttacherVehicle()
				local v559 = v558:getAttacherJointIndexFromObject(p553)
				if v559 ~= nil then
					local v560 = v558:getJointMoveDown(v559)
					local v561 = v555 == v554.turnOnFoldDirection
					if v561 ~= v560 then
						v558:setJointMoveDown(v559, v561)
						return
					end
				end
			end
		elseif v557 ~= nil then
			g_currentMission:showBlinkingWarning(v557, 2000)
		end
	end
end
function Foldable.actionEventFoldMiddle(p562, _, _, _, _)
	local v563 = p562.spec_foldable
	if v563.hasFoldingParts and p562:getIsFoldMiddleAllowed() then
		if v563.ignoreFoldMiddleWhileFolded and p562:getFoldAnimTime() > v563.foldMiddleAnimTime and true or false then
			if p562.getAttacherVehicle ~= nil then
				local v564 = p562:getAttacherVehicle()
				if v564 ~= nil then
					v564:handleLowerImplementEvent(p562)
				end
			end
		else
			local v565 = p562:getToggledFoldMiddleDirection()
			if v565 ~= 0 then
				if v565 == v563.turnOnFoldDirection then
					p562:setFoldState(v565, false)
				else
					p562:setFoldState(v565, true)
				end
				if p562.getAttacherVehicle ~= nil then
					local v566 = p562:getAttacherVehicle()
					local v567 = v566:getAttacherJointIndexFromObject(p562)
					if v567 ~= nil then
						local v568 = v566:getJointMoveDown(v567)
						local v569 = v565 == v563.turnOnFoldDirection
						if v569 ~= v568 then
							v566:setJointMoveDown(v567, v569)
							return
						end
					end
				end
			end
		end
	end
end
function Foldable.actionEventFoldAll(p570, _, _, _, _)
	local v571 = p570.spec_foldable
	if v571.hasFoldingParts then
		local v572 = true
		local v573 = nil
		local v574 = p570:getToggledFoldDirection()
		local v575, v576 = p570:getIsFoldAllowed(v574, false)
		if v575 then
			if v574 == v571.turnOnFoldDirection then
				p570:setFoldState(v574, true)
				v572 = false
			else
				p570:setFoldState(v574, false)
				v572 = false
			end
		elseif v576 ~= nil then
			v573 = v576
		end
		local v577 = p570.rootVehicle:getChildVehicles()
		for v578 = 1, #v577 do
			local v579 = v577[v578]
			if v579.setFoldState ~= nil then
				local v580 = v579.spec_foldable
				if #v580.foldingParts > 0 then
					local v581 = v579:getToggledFoldDirection()
					local v582, v583 = v579:getIsFoldAllowed(v574, false)
					if v582 then
						if v574 == v571.turnOnFoldDirection == (v581 == v580.turnOnFoldDirection) then
							if v581 == v580.turnOnFoldDirection then
								v579:setFoldState(v581, true)
							else
								v579:setFoldState(v581, false)
							end
							v572 = false
						end
					elseif v583 ~= nil then
						v573 = v583
					end
				end
			end
		end
		if v572 and v573 ~= nil then
			g_currentMission:showBlinkingWarning(v573, 2000)
		end
	end
end
function Foldable.externalActionEventRegister(p584, p_u_585)
	local v_u_586 = p_u_585.spec_foldable
	local _, v593 = g_inputBinding:registerActionEvent(v_u_586.foldInputButton, p584, function(_, p587, p588, p589, p590)
		-- upvalues: (copy) p_u_585, (copy) v_u_586
		Motorized.tryStartMotor(p_u_585)
		if v_u_586.requiresPower then
			local v591, v592 = p_u_585:getIsPowered()
			if v591 then
				Foldable.actionEventFold(p_u_585, p587, p588, p589, p590)
				return
			end
			if p588 ~= 0 and v592 ~= nil then
				g_currentMission:showBlinkingWarning(v592, 2000)
				return
			end
		else
			Foldable.actionEventFold(p_u_585, p587, p588, p589, p590)
		end
	end, false, true, false, true)
	p584.actionEventId = v593
	g_inputBinding:setActionEventTextPriority(p584.actionEventId, GS_PRIO_HIGH)
end
function Foldable.externalActionEventUpdate(p594, p595)
	local v596 = p595.spec_foldable
	if p594.actionEventId ~= nil then
		local v597
		if p595:getToggledFoldDirection() == v596.turnOnFoldDirection then
			v597 = v596.negDirectionText
		else
			v597 = v596.posDirectionText
		end
		g_inputBinding:setActionEventText(p594.actionEventId, v597)
	end
end

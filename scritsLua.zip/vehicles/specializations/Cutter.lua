Cutter = {}
Cutter.AUTO_TILT_COLLISION_MASK = CollisionFlag.TERRAIN + CollisionFlag.TERRAIN_DELTA + CollisionFlag.STATIC_OBJECT
Cutter.CUTTER_TILT_XML_KEY = "vehicle.cutter.automaticTilt"
function Cutter.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("cutter", false, true, true)
	g_workAreaTypeManager:addWorkAreaType("haulmDrop", false, false, false)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Cutter")
	v1:register(XMLValueType.STRING, "vehicle.cutter#fruitTypes", "List with supported fruit types")
	v1:register(XMLValueType.STRING, "vehicle.cutter#fruitTypeCategories", "List with supported fruit types categories")
	v1:register(XMLValueType.STRING, "vehicle.cutter#fruitTypeConverter", "Name of fruit type converter")
	v1:register(XMLValueType.STRING, "vehicle.cutter#fillTypeConverter", "Name of fill type converter (defines the supported fill types for pickup headers)")
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.cutter.animationNodes")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.cutter.effect")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.cutter.fillEffect")
	v1:register(XMLValueType.NODE_INDEX, Cutter.CUTTER_TILT_XML_KEY .. ".automaticTiltNode(?)#node", "Automatic tilt node")
	v1:register(XMLValueType.ANGLE, Cutter.CUTTER_TILT_XML_KEY .. ".automaticTiltNode(?)#minAngle", "Min. angle", -5)
	v1:register(XMLValueType.ANGLE, Cutter.CUTTER_TILT_XML_KEY .. ".automaticTiltNode(?)#maxAngle", "Max. angle", 5)
	v1:register(XMLValueType.ANGLE, Cutter.CUTTER_TILT_XML_KEY .. ".automaticTiltNode(?)#maxSpeed", "Max. angle change per second", 1)
	v1:register(XMLValueType.NODE_INDEX, Cutter.CUTTER_TILT_XML_KEY .. "#raycastNode1", "Raycast node 1")
	v1:register(XMLValueType.NODE_INDEX, Cutter.CUTTER_TILT_XML_KEY .. "#raycastNode2", "Raycast node 2")
	v1:register(XMLValueType.BOOL, "vehicle.cutter#allowsForageGrowthState", "Allows forage growth state", false)
	v1:register(XMLValueType.BOOL, "vehicle.cutter#allowCuttingWhileRaised", "Allow cutting while raised", false)
	v1:register(XMLValueType.INT, "vehicle.cutter#movingDirection", "Moving direction", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.cutter#strawRatio", "Straw ratio", 1)
	v1:register(XMLValueType.TIME, "vehicle.cutter.haulmDrop#delay", "Delay between pickup and haulm drop", 0)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.cutter.spikedDrums.spikedDrum(?)#node", "Spiked drum node (Needs to rotate on X axis)")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.cutter.spikedDrums.spikedDrum(?)#spline", "Reference spline")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.cutter.spikedDrums.spikedDrum(?).spike(?)#node", "Spike that is translated on Y axis depending on spline")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.cutter.sounds", "cut")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. ".chopperArea#index", "Chopper area index")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".chopperArea#index", "Chopper area index")
	v1:register(XMLValueType.BOOL, RandomlyMovingParts.RANDOMLY_MOVING_PART_XML_KEY .. "#moveOnlyIfCut", "Move only if cutters cuts something", false)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#rotateIfTurnedOn", "Rotate only if turned on", false)
	v1:register(XMLValueType.BOOL, Attachable.INPUT_ATTACHERJOINT_XML_KEY .. "#useFruitCutHeight", "The lower distance to ground is used from the cutHeight defined in the current fruit type", true)
	v1:register(XMLValueType.BOOL, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY .. "#useFruitCutHeight", "The lower distance to ground is used from the cutHeight defined in the current fruit type", true)
	v1:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.FLOAT, "vehicles.vehicle(?).cutter#cutHeight", "Last used cut height")
end
function Cutter.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(WorkArea, p2) and SpecializationUtil.hasSpecialization(TestAreas, p2)
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(FruitExtraObjects, p2)
	end
	return v3
end
function Cutter.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "readCutterFromStream", Cutter.readCutterFromStream)
	SpecializationUtil.registerFunction(p4, "writeCutterToStream", Cutter.writeCutterToStream)
	SpecializationUtil.registerFunction(p4, "getCombine", Cutter.getCombine)
	SpecializationUtil.registerFunction(p4, "getAllowCutterAIFruitRequirements", Cutter.getAllowCutterAIFruitRequirements)
	SpecializationUtil.registerFunction(p4, "processCutterArea", Cutter.processCutterArea)
	SpecializationUtil.registerFunction(p4, "processPickupCutterArea", Cutter.processPickupCutterArea)
	SpecializationUtil.registerFunction(p4, "processHaulmDropArea", Cutter.processHaulmDropArea)
	SpecializationUtil.registerFunction(p4, "getCutterLoad", Cutter.getCutterLoad)
	SpecializationUtil.registerFunction(p4, "getCutterStoneMultiplier", Cutter.getCutterStoneMultiplier)
	SpecializationUtil.registerFunction(p4, "loadCutterTiltFromXML", Cutter.loadCutterTiltFromXML)
	SpecializationUtil.registerFunction(p4, "getCutterTiltIsAvailable", Cutter.getCutterTiltIsAvailable)
	SpecializationUtil.registerFunction(p4, "getCutterTiltIsActive", Cutter.getCutterTiltIsActive)
	SpecializationUtil.registerFunction(p4, "getCutterTiltDelta", Cutter.getCutterTiltDelta)
	SpecializationUtil.registerFunction(p4, "tiltRaycastDetectionCallback", Cutter.tiltRaycastDetectionCallback)
	SpecializationUtil.registerFunction(p4, "setCutterCutHeight", Cutter.setCutterCutHeight)
end
function Cutter.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadSpeedRotatingPartFromXML", Cutter.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsSpeedRotatingPartActive", Cutter.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadRandomlyMovingPartFromXML", Cutter.loadRandomlyMovingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsRandomlyMovingPartActive", Cutter.getIsRandomlyMovingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsWorkAreaActive", Cutter.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", Cutter.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadWorkAreaFromXML", Cutter.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDirtMultiplier", Cutter.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", Cutter.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "isAttachAllowed", Cutter.isAttachAllowed)
	SpecializationUtil.registerOverwrittenFunction(p5, "getConsumingLoad", Cutter.getConsumingLoad)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsGroundReferenceNodeThreshold", Cutter.getIsGroundReferenceNodeThreshold)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDefaultAllowComponentMassReduction", Cutter.getDefaultAllowComponentMassReduction)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadInputAttacherJoint", Cutter.loadInputAttacherJoint)
	SpecializationUtil.registerOverwrittenFunction(p5, "getFruitExtraObjectTypeData", Cutter.getFruitExtraObjectTypeData)
end
function Cutter.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", Cutter)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", Cutter)
	SpecializationUtil.registerEventListener(p6, "onDelete", Cutter)
	SpecializationUtil.registerEventListener(p6, "onReadStream", Cutter)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", Cutter)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", Cutter)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", Cutter)
	SpecializationUtil.registerEventListener(p6, "onUpdate", Cutter)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", Cutter)
	SpecializationUtil.registerEventListener(p6, "onStartWorkAreaProcessing", Cutter)
	SpecializationUtil.registerEventListener(p6, "onEndWorkAreaProcessing", Cutter)
	SpecializationUtil.registerEventListener(p6, "onTurnedOn", Cutter)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", Cutter)
	SpecializationUtil.registerEventListener(p6, "onAIImplementStart", Cutter)
	SpecializationUtil.registerEventListener(p6, "onAIFieldCourseSettingsInitialized", Cutter)
end
function Cutter.onLoad(p_u_7, p8)
	local v_u_9 = p_u_7.spec_cutter
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.cutter.animationNodes.animationNode", "cutter")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.turnedOnScrollers", "vehicle.cutter.animationNodes.animationNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.cutter.turnedOnScrollers", "vehicle.cutter.animationNodes.animationNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.cutter.reelspikes", "vehicle.cutter.rotationNodes.rotationNode or vehicle.turnOnVehicle.turnedOnAnimation")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.cutter.threshingParticleSystems.threshingParticleSystem", "vehicle.cutter.fillEffect.effectNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.cutter.threshingParticleSystems.emitterShape", "vehicle.cutter.fillEffect.effectNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.cutter#convertedFillTypeCategories", "vehicle.cutter#fruitTypeConverter")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.cutter#startAnimationName", "vehicle.turnOnVehicle.turnOnAnimation#name")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.cutter.testAreas", "vehicle.workAreas.workArea.testAreas")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.cutter#useWindrowed", "Windrows are now picked up if a fillTypeConverter is defined and the work area uses \'processPickupCutterArea\'")
	local v10 = nil
	local v11 = p_u_7.xmlFile:getValue("vehicle.cutter#fruitTypes")
	local v12 = p_u_7.xmlFile:getValue("vehicle.cutter#fruitTypeCategories")
	if v12 == nil or v11 ~= nil then
		if v12 == nil and v11 ~= nil then
			v10 = g_fruitTypeManager:getFruitTypeIndicesByNames(v11, "Warning: Cutter has invalid fruitType \'%s\' in \'" .. p_u_7.configFileName .. "\'")
		end
	else
		v10 = g_fruitTypeManager:getFruitTypeIndicesByCategoryNames(v12, "Warning: Cutter has invalid fruitTypeCategory \'%s\' in \'" .. p_u_7.configFileName .. "\'")
	end
	v_u_9.currentCutHeight = 0
	v_u_9.outputFillTypes = {}
	v_u_9.fruitTypeConverters = {}
	local v13 = p_u_7.xmlFile:getValue("vehicle.cutter#fruitTypeConverter")
	if v13 ~= nil then
		local v14 = g_fruitTypeManager:getConverterDataByName(v13)
		if v14 ~= nil then
			for v15, v16 in pairs(v14) do
				v_u_9.fruitTypeConverters[v15] = v16
			end
		end
	end
	if v10 ~= nil then
		v_u_9.fruitTypeIndices = {}
		for _, v17 in pairs(v10) do
			local v18 = v_u_9.fruitTypeIndices
			table.insert(v18, v17)
			if #v_u_9.fruitTypeIndices == 1 then
				p_u_7:setCutterCutHeight((g_fruitTypeManager:getCutHeightByFruitTypeIndex(v17, v_u_9.allowsForageGrowthState)))
			end
		end
		for _, v19 in ipairs(v_u_9.fruitTypeIndices) do
			if v_u_9.fruitTypeConverters[v19] == nil then
				local v20 = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v19)
				if v20 ~= nil then
					local v21 = v_u_9.outputFillTypes
					table.insert(v21, v20)
				end
			else
				local v22 = v_u_9.outputFillTypes
				local v23 = v_u_9.fruitTypeConverters[v19].fillTypeIndex
				table.insert(v22, v23)
			end
		end
	end
	v_u_9.fillTypeConverter = nil
	local v24 = p_u_7.xmlFile:getValue("vehicle.cutter#fillTypeConverter")
	if v24 ~= nil then
		local v25 = g_fillTypeManager:getConverterDataByName(v24)
		if v25 == nil then
			Logging.xmlWarning(p_u_7.xmlFile, "Cutter has invalid fillTypeConverter \'%s\'", v25)
		else
			v_u_9.fillTypeConverter = v25
			for _, v26 in pairs(v25) do
				local v27 = v_u_9.outputFillTypes
				local v28 = v26.targetFillTypeIndex
				table.insert(v27, v28)
			end
		end
	end
	if #v_u_9.outputFillTypes == 0 then
		Logging.xmlWarning(p_u_7.xmlFile, "Cutter has no valid fruit/fill type definition (requires either fruitTypes/fruitTypeCategories or fillTypeConverter attribute)")
	end
	if p_u_7.isClient then
		v_u_9.animationNodes = g_animationManager:loadAnimations(p_u_7.xmlFile, "vehicle.cutter.animationNodes", p_u_7.components, p_u_7, p_u_7.i3dMappings)
		v_u_9.spikedDrums = {}
		p_u_7.xmlFile:iterate("vehicle.cutter.spikedDrums.spikedDrum", function(_, p29)
			-- upvalues: (copy) p_u_7, (copy) v_u_9
			local v_u_30 = {
				["node"] = p_u_7.xmlFile:getValue(p29 .. "#node", nil, p_u_7.components, p_u_7.i3dMappings)
			}
			if v_u_30.node == nil then
				Logging.xmlWarning(p_u_7.xmlFile, "No drum node defined for spiked drum \'%s\'", p29)
				return
			else
				v_u_30.spline = p_u_7.xmlFile:getValue(p29 .. "#spline", nil, p_u_7.components, p_u_7.i3dMappings)
				if v_u_30.spline == nil then
					Logging.xmlWarning(p_u_7.xmlFile, "No spline defined for spiked drum \'%s\'", p29)
					return
				else
					setVisibility(v_u_30.spline, false)
					v_u_30.spikes = {}
					p_u_7.xmlFile:iterate(p29 .. ".spike", function(_, p31)
						-- upvalues: (ref) p_u_7, (copy) v_u_30
						local v32 = {
							["node"] = p_u_7.xmlFile:getValue(p31 .. "#node", nil, p_u_7.components, p_u_7.i3dMappings)
						}
						if v32.node ~= nil then
							local v33 = createTransformGroup(getName(v32.node) .. "Parent")
							link(getParent(v32.node), v33, getChildIndex(v32.node))
							setTranslation(v33, getTranslation(v32.node))
							setRotation(v33, getRotation(v32.node))
							link(v33, v32.node)
							setTranslation(v32.node, 0, 0, 0)
							setRotation(v32.node, 0, 0, 0)
							local _, v34, v35 = localToLocal(v32.node, v_u_30.node, 0, 0, 0)
							local v36 = -MathUtil.getYRotationFromDirection(v34, v35) / 6.283185307179586
							if v36 < 0 then
								v36 = v36 + 1
							end
							v32.initalTime = v36
							local v37 = v_u_30.spikes
							table.insert(v37, v32)
						end
					end)
					local v38 = {}
					for v39 = 0, 1, 0.01 do
						local v40, v41, v42 = getSplinePosition(v_u_30.spline, v39)
						local _, v43, v44 = worldToLocal(v_u_30.node, v40, v41, v42)
						local v45 = -MathUtil.getYRotationFromDirection(v43, v44) / 6.283185307179586
						if v45 < 0 then
							v45 = v45 + 1
						end
						table.insert(v38, {
							["alpha"] = v45,
							["time"] = v39
						})
					end
					local v46 = {
						["alpha"] = v38[1].alpha - 1e-6,
						["time"] = 1
					}
					table.insert(v38, v46)
					table.sort(v38, function(p47, p48)
						return p47.alpha < p48.alpha
					end)
					v_u_30.splineCurve = AnimCurve.new(linearInterpolator1)
					for v49 = 1, #v38 do
						v_u_30.splineCurve:addKeyframe({
							v38[v49].time,
							["time"] = v38[v49].alpha
						})
					end
					for v50 = 1, #v_u_9.animationNodes do
						local v51 = v_u_9.animationNodes[v50]
						if v51.node == v_u_30.node then
							v_u_30.animationNode = v51
						end
					end
					if v_u_30.animationNode == nil then
						Logging.xmlWarning(p_u_7.xmlFile, "Could not find animation node for spikedDrum \'%s\'", getName(v_u_30.node))
					else
						local v52 = v_u_9.spikedDrums
						table.insert(v52, v_u_30)
					end
				end
			end
		end)
		v_u_9.cutterEffects = g_effectManager:loadEffect(p_u_7.xmlFile, "vehicle.cutter.effect", p_u_7.components, p_u_7, p_u_7.i3dMappings)
		v_u_9.fillEffects = g_effectManager:loadEffect(p_u_7.xmlFile, "vehicle.cutter.fillEffect", p_u_7.components, p_u_7, p_u_7.i3dMappings)
		v_u_9.samples = {}
		v_u_9.samples.cut = g_soundManager:loadSampleFromXML(p_u_7.xmlFile, "vehicle.cutter.sounds", "cut", p_u_7.baseDirectory, p_u_7.components, 0, AudioGroup.VEHICLE, p_u_7.i3dMappings, p_u_7)
	end
	v_u_9.lastAutomaticTiltRaycastPosition = { 0, 0, 0 }
	v_u_9.automaticTilt = {}
	v_u_9.automaticTilt.isAvailable = false
	v_u_9.automaticTilt.hasNodes = false
	if p_u_7:loadCutterTiltFromXML(p_u_7.xmlFile, Cutter.CUTTER_TILT_XML_KEY, v_u_9.automaticTilt) then
		v_u_9.automaticTilt.currentDelta = 0
		v_u_9.automaticTilt.lastHit = { 0, 0, 0 }
		v_u_9.automaticTilt.raycastHit = true
		v_u_9.automaticTilt.isAvailable = true
		v_u_9.automaticTilt.hasNodes = #v_u_9.automaticTilt.nodes > 0
	end
	if not Platform.gameplay.allowAutomaticHeaderTilt and v_u_9.automaticTilt.hasNodes then
		Logging.xmlWarning(p_u_7.xmlFile, "Automatic header tilt is not allowed on this platform!")
		v_u_9.automaticTilt.hasNodes = false
	end
	v_u_9.allowsForageGrowthState = p_u_7.xmlFile:getValue("vehicle.cutter#allowsForageGrowthState", false)
	v_u_9.allowCuttingWhileRaised = p_u_7.xmlFile:getValue("vehicle.cutter#allowCuttingWhileRaised", false)
	local v53 = p_u_7.xmlFile:getValue("vehicle.cutter#movingDirection", 1)
	v_u_9.movingDirection = math.sign(v53)
	v_u_9.strawRatio = p_u_7.xmlFile:getValue("vehicle.cutter#strawRatio", 1)
	v_u_9.delay = p_u_7.xmlFile:getValue("vehicle.cutter.haulmDrop#delay", 0)
	if v_u_9.delay ~= 0 then
		v_u_9.valueDelay = ValueDelay.new(v_u_9.delay)
	end
	v_u_9.useWindrow = false
	v_u_9.currentInputFillType = FillType.UNKNOWN
	v_u_9.currentInputFillTypeSent = FillType.UNKNOWN
	v_u_9.currentInputFruitType = FruitType.UNKNOWN
	v_u_9.currentInputFruitTypeAI = FruitType.UNKNOWN
	v_u_9.lastValidInputFruitType = FruitType.UNKNOWN
	v_u_9.currentInputFruitTypeSent = FruitType.UNKNOWN
	v_u_9.currentOutputFillType = FillType.UNKNOWN
	v_u_9.currentConversionFactor = 1
	v_u_9.currentGrowthStateTime = 0
	v_u_9.currentGrowthStateTimer = 0
	v_u_9.currentGrowthState = 0
	v_u_9.lastAreaBiggerZero = false
	v_u_9.lastAreaBiggerZeroSent = false
	v_u_9.lastAreaBiggerZeroTime = -1
	v_u_9.workAreaParameters = {}
	v_u_9.workAreaParameters.lastLiters = 0
	v_u_9.workAreaParameters.lastArea = 0
	v_u_9.workAreaParameters.lastMultiplierArea = 0
	v_u_9.workAreaParameters.fruitTypeIndicesToUse = {}
	v_u_9.workAreaParameters.lastFruitTypeToUse = {}
	v_u_9.workAreaParameters.lastOutputFillType = nil
	v_u_9.lastOutputFillTypes = {}
	v_u_9.lastPrioritizedOutputType = FillType.UNKNOWN
	v_u_9.lastOutputTime = 0
	v_u_9.cutterLoad = 0
	v_u_9.isWorking = false
	v_u_9.stoneLastState = 0
	v_u_9.stoneWearMultiplierData = g_currentMission.stoneSystem:getWearMultiplierByType("CUTTER")
	v_u_9.workAreaParameters.countArea = true
	if p8 ~= nil and not p8.resetVehicles then
		v_u_9.currentCutHeight = p8.xmlFile:getValue(p8.key .. ".cutter#cutHeight", v_u_9.currentCutHeight)
	end
	v_u_9.dirtyFlag = p_u_7:getNextDirtyFlag()
	v_u_9.effectDirtyFlag = p_u_7:getNextDirtyFlag()
end
function Cutter.onPostLoad(p54, _)
	if p54.addCutterToCombine ~= nil then
		p54:addCutterToCombine(p54)
	end
	p54:setCutterCutHeight(p54.spec_cutter.currentCutHeight)
end
function Cutter.onDelete(p55)
	local v56 = p55.spec_cutter
	g_effectManager:deleteEffects(v56.cutterEffects)
	g_effectManager:deleteEffects(v56.fillEffects)
	g_animationManager:deleteAnimations(v56.animationNodes)
	g_soundManager:deleteSamples(v56.samples)
end
function Cutter.onReadStream(p57, p58, p59)
	p57:readCutterFromStream(p58, p59)
	local v60 = p57.spec_cutter
	v60.lastAreaBiggerZero = streamReadBool(p58)
	if v60.lastAreaBiggerZero then
		v60.lastAreaBiggerZeroTime = g_currentMission.time
	end
	p57:setTestAreaRequirements(v60.currentInputFruitType, nil, v60.allowsForageGrowthState)
end
function Cutter.onWriteStream(p61, p62, p63)
	p61:writeCutterToStream(p62, p63)
	local v64 = p61.spec_cutter
	streamWriteBool(p62, v64.lastAreaBiggerZeroSent)
end
function Cutter.onReadUpdateStream(p65, p66, _, p67)
	if p67:getIsServer() then
		local v68 = p65.spec_cutter
		if streamReadBool(p66) then
			p65:readCutterFromStream(p66, p67)
		end
		v68.lastAreaBiggerZero = streamReadBool(p66)
		if v68.lastAreaBiggerZero then
			v68.lastAreaBiggerZeroTime = g_currentMission.time
		end
		p65:setTestAreaRequirements(v68.currentInputFruitType, nil, v68.allowsForageGrowthState)
	end
end
function Cutter.onWriteUpdateStream(p69, p70, p71, p72)
	if not p71:getIsServer() then
		local v73 = p69.spec_cutter
		if streamWriteBool(p70, bitAND(p72, v73.effectDirtyFlag) ~= 0) then
			p69:writeCutterToStream(p70, p71)
		end
		streamWriteBool(p70, v73.lastAreaBiggerZeroSent)
	end
end
function Cutter.readCutterFromStream(p74, p75, _)
	local v76 = p74.spec_cutter
	v76.currentGrowthState = streamReadUIntN(p75, 4)
	v76.currentInputFruitType = streamReadUIntN(p75, FruitTypeManager.SEND_NUM_BITS)
	if streamReadBool(p75) then
		v76.lastValidInputFruitType = v76.currentInputFruitType
	else
		v76.currentInputFruitType = FruitType.UNKNOWN
	end
	v76.currentOutputFillType = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v76.currentInputFruitType)
	if v76.fruitTypeConverters[v76.currentInputFruitType] ~= nil then
		v76.currentOutputFillType = v76.fruitTypeConverters[v76.currentInputFruitType].fillTypeIndex
		v76.currentConversionFactor = v76.fruitTypeConverters[v76.currentInputFruitType].conversionFactor
	end
	v76.useWindrow = streamReadBool(p75)
	if v76.useWindrow then
		v76.currentInputFillType = streamReadUIntN(p75, FillTypeManager.SEND_NUM_BITS)
	end
end
function Cutter.writeCutterToStream(p77, p78, _)
	local v79 = p77.spec_cutter
	streamWriteUIntN(p78, v79.currentGrowthState, 4)
	streamWriteUIntN(p78, v79.currentInputFruitType, FruitTypeManager.SEND_NUM_BITS)
	streamWriteBool(p78, v79.currentInputFruitType == v79.lastValidInputFruitType)
	if streamWriteBool(p78, v79.useWindrow) then
		streamWriteUIntN(p78, v79.currentInputFillType, FillTypeManager.SEND_NUM_BITS)
	end
end
function Cutter.saveToXMLFile(p80, p81, p82, _)
	local v83 = p80.spec_cutter
	p81:setValue(p82 .. "#cutHeight", v83.currentCutHeight)
end
function Cutter.onUpdate(p84, p85, _, _, _)
	local v86 = p84.spec_cutter
	if v86.automaticTilt.hasNodes then
		local v87, v88, v89 = p84:getCutterTiltDelta()
		local v90 = -v87
		if p84.isActive then
			for v91 = 1, #v86.automaticTilt.nodes do
				local v92 = v86.automaticTilt.nodes[v91]
				local _, _, v93 = getRotation(v92.node)
				if not v88 and v89 then
					v90 = -v93
				end
				if math.abs(v90) > 0.00001 then
					local v94 = math.abs(v90) / 0.01745
					local v95 = math.pow(v94, 2)
					local v96 = v93 + math.min(v95, 1) * math.sign(v90) * v92.maxSpeed * p85
					local v97 = v92.minAngle
					local v98 = v92.maxAngle
					local v99 = math.clamp(v96, v97, v98)
					setRotation(v92.node, 0, 0, v99)
					if p84.setMovingToolDirty ~= nil then
						p84:setMovingToolDirty(v92.node)
					end
				end
			end
		end
	end
	if p84.isClient then
		for v100 = 1, #v86.spikedDrums do
			local v101 = v86.spikedDrums[v100]
			if v101.animationNode.state ~= RotationAnimation.STATE_OFF then
				local v102, _, _ = getRotation(v101.node)
				if v102 < 0 then
					v102 = v102 + 6.283185307179586
				end
				local v103 = v102 / 6.283185307179586
				for v104 = 1, #v101.spikes do
					local v105 = v101.spikes[v104]
					local v106 = v101.splineCurve:get((v103 + v105.initalTime) % 1)
					local v107, v108, v109 = getSplinePosition(v101.spline, v106)
					local _, v110, _ = worldToLocal(getParent(v105.node), v107, v108, v109)
					setTranslation(v105.node, 0, v110, 0)
				end
			end
		end
	end
end
function Cutter.onUpdateTick(p111, p112, _, _, _)
	local v113 = p111.spec_cutter
	local v114 = p111:getIsTurnedOn() and (p111.movingDirection == v113.movingDirection and p111:getLastSpeed() > 0.5 and (v113.allowCuttingWhileRaised or p111:getIsLowered(true)))
	if v114 then
		v114 = v113.workAreaParameters.combineVehicle ~= nil
	end
	if v114 then
		local v115, v116, v117, v118, v119 = p111:getTestAreaWidthByWorkAreaIndex(1)
		local v120 = p111:getTestAreaChargeByWorkAreaIndex(1)
		if not v113.useWindrow then
			v113.cutterLoad = v113.cutterLoad * 0.95 + v120 * 0.05
		end
		local v121 = false
		if v115 == (-1 / 0) and v116 == (1 / 0) then
			v115 = 0
			v116 = 0
			v121 = true
		elseif not v119 and v113.lastAreaBiggerZeroTime + 300 < g_currentMission.time then
			v115 = 0
			v116 = 0
			v121 = true
		end
		local v122
		if v113.movingDirection > 0 then
			v122 = v115 * -1
			v115 = v116 * -1
			if v115 >= v122 then
				local v123 = v122
				v122 = v115
				v115 = v123
			end
		else
			v122 = v116
		end
		local v124 = v117 == 0 and 0 or v115 / v117
		local v125 = v118 == 0 and 0 or v122 / v118
		local v126 = v113.currentInputFruitType
		if v126 ~= v113.lastValidInputFruitType then
			v126 = nil
		end
		if v126 ~= nil then
			p111:updateFruitExtraObjects()
		end
		local v127 = v113.lastAreaBiggerZeroTime + 300 > g_currentMission.time
		local v128 = v113.currentInputFillType
		if v113.useWindrow then
			if v127 then
				v113.cutterLoad = v113.cutterLoad * 0.95 + 0.05
			else
				v113.cutterLoad = v113.cutterLoad * 0.9
			end
		end
		if p111.isClient then
			local v129 = false
			if v128 == nil or (v128 == FillType.UNKNOWN or not v127) then
				g_effectManager:stopEffects(v113.fillEffects)
			else
				g_effectManager:setEffectTypeInfo(v113.fillEffects, v128)
				g_effectManager:setMinMaxWidth(v113.fillEffects, v115, v122, v124, v125, v121)
				g_effectManager:startEffects(v113.fillEffects)
				v129 = true
			end
			if v126 == nil or (v126 == FruitType.UNKNOWN or v121) then
				g_effectManager:stopEffects(v113.cutterEffects)
			else
				g_effectManager:setEffectTypeInfo(v113.cutterEffects, v128, v126, v113.currentGrowthState)
				g_effectManager:setMinMaxWidth(v113.cutterEffects, v115, v122, v124, v125, v121)
				g_effectManager:startEffects(v113.cutterEffects)
				v129 = true
			end
			if v129 then
				if not g_soundManager:getIsSamplePlaying(v113.samples.cut) then
					g_soundManager:playSample(v113.samples.cut)
				end
			elseif g_soundManager:getIsSamplePlaying(v113.samples.cut) then
				g_soundManager:stopSample(v113.samples.cut)
			end
		end
	else
		if p111.isClient then
			g_effectManager:stopEffects(v113.cutterEffects)
			g_effectManager:stopEffects(v113.fillEffects)
			g_soundManager:stopSample(v113.samples.cut)
		end
		v113.cutterLoad = v113.cutterLoad * 0.9
	end
	v113.lastOutputTime = v113.lastOutputTime + p112
	if v113.lastOutputTime > 500 then
		v113.lastPrioritizedOutputType = FillType.UNKNOWN
		local v130 = 0
		for v131, _ in pairs(v113.lastOutputFillTypes) do
			if v130 < v113.lastOutputFillTypes[v131] then
				v113.lastPrioritizedOutputType = v131
				v130 = v113.lastOutputFillTypes[v131]
			end
			v113.lastOutputFillTypes[v131] = 0
		end
		v113.lastOutputTime = 0
	end
	local v132 = v113.automaticTilt
	local v133, _ = p111:getCutterTiltIsActive(v132)
	if v133 and (v132 ~= nil and (v132.raycastNode1 ~= nil and v132.raycastNode2 ~= nil)) then
		v132.currentDelta = 0
		local v134, v135, v136 = localToWorld(v132.raycastNode1, 0, 1, 0)
		local v137, v138, v139 = localDirectionToWorld(v132.raycastNode1, 0, -1, 0)
		v132.raycastHit = false
		raycastAll(v134, v135, v136, v137, v138, v139, 2, "tiltRaycastDetectionCallback", p111, Cutter.AUTO_TILT_COLLISION_MASK)
		local v140 = v132.lastHit[1]
		local v141 = v132.lastHit[2]
		local v142 = v132.lastHit[3]
		local v143, v144, v145 = getWorldTranslation(v132.raycastNode1)
		if not v132.raycastHit then
			v140, v141, v142 = localToWorld(v132.raycastNode1, 0, -1, 0)
		end
		local v146, v147, v148 = localToWorld(v132.raycastNode2, 0, 1, 0)
		local v149, v150, v151 = localDirectionToWorld(v132.raycastNode2, 0, -1, 0)
		v132.raycastHit = false
		raycastAll(v146, v147, v148, v149, v150, v151, 2, "tiltRaycastDetectionCallback", p111, Cutter.AUTO_TILT_COLLISION_MASK)
		local v152 = v132.lastHit[1]
		local v153 = v132.lastHit[2]
		local v154 = v132.lastHit[3]
		local v155, v156, v157 = getWorldTranslation(v132.raycastNode2)
		if not v132.raycastHit then
			v152, v153, v154 = localToWorld(v132.raycastNode2, 0, -1, 0)
		end
		local v158 = v141 - v153
		local v159 = v152 + v149 * v158
		local v160 = v153 + v150 * v158
		local v161 = v154 + v151 * v158
		local v162 = MathUtil.vector3Length(v140 - v159, v141 - v160, v142 - v161)
		local v163 = v141 < v153 and -1 or 1
		local v164 = math.abs(v158) / v162
		local v165 = math.atan(v164) * v163
		local v166 = v156 - v144
		local v167 = MathUtil.vector3Length(v143 - v155, v144 - v156, v145 - v157)
		local v168 = v144 < v156 and -1 or 1
		local v169 = math.abs(v166) / v167
		local v170 = math.atan(v169) * v168
		if v165 == v165 and v170 == v170 then
			v132.currentDelta = v165 - v170
		end
	end
end
function Cutter.getCombine(p171, p172, p173)
	local v174 = p171.spec_cutter
	if p171.verifyCombine ~= nil then
		return p171:verifyCombine(p172 or v174.currentInputFruitType, p173 or v174.currentOutputFillType)
	end
	if p171.getAttacherVehicle ~= nil then
		local v175 = p171:getAttacherVehicle()
		if v175 ~= nil and v175.verifyCombine ~= nil then
			return v175:verifyCombine(p172 or v174.currentInputFruitType, p173 or v174.currentOutputFillType)
		end
	end
	return nil
end
function Cutter.getAllowCutterAIFruitRequirements(_)
	return true
end
function Cutter.processCutterArea(p176, p177, p178)
	local v179 = p176.spec_cutter
	if v179.workAreaParameters.combineVehicle == nil then
		return 0, 0
	end
	local v180 = g_currentMission.fieldGroundSystem
	local v181, _, v182 = getWorldTranslation(p177.start)
	local v183, _, v184 = getWorldTranslation(p177.width)
	local v185, _, v186 = getWorldTranslation(p177.height)
	local v187 = 0
	local v188 = 0
	local v189 = 0
	for _, v190 in ipairs(v179.workAreaParameters.fruitTypeIndicesToUse) do
		local v191 = v180:getChopperTypeValue(g_fruitTypeManager:getFruitTypeByIndex(v190).chopperType)
		local v192, v193, v194, v195, v196, v197, v198, v199, v200, v201, _, v202 = FSDensityMapUtil.cutFruitArea(v190, v181, v182, v183, v184, v185, v186, true, v179.allowsForageGrowthState, v191)
		if v192 > 0 then
			v187 = v187 + v193
			if p176.isServer then
				if v201 == v179.currentGrowthState then
					v179.currentGrowthStateTimer = 0
					v179.currentGrowthStateTime = g_time
				else
					v179.currentGrowthStateTimer = v179.currentGrowthStateTimer + p178
					if v179.currentGrowthStateTimer > 500 or v179.currentGrowthStateTime + 1000 < g_time then
						v179.currentGrowthState = v201
						v179.currentGrowthStateTimer = 0
					end
				end
				if v190 ~= v179.currentInputFruitType then
					v179.currentInputFruitType = v190
					v179.currentGrowthState = v201
					v179.currentOutputFillType = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v179.currentInputFruitType)
					if v179.fruitTypeConverters[v179.currentInputFruitType] ~= nil then
						v179.currentOutputFillType = v179.fruitTypeConverters[v179.currentInputFruitType].fillTypeIndex
						v179.currentConversionFactor = v179.fruitTypeConverters[v179.currentInputFruitType].conversionFactor
					end
					p176:setCutterCutHeight((g_fruitTypeManager:getCutHeightByFruitTypeIndex(v190, v179.allowsForageGrowthState)))
				end
				p176:setTestAreaRequirements(v190, nil, v179.allowsForageGrowthState)
				if v202 > 0 then
					v179.currentInputFruitTypeAI = v190
				end
				v179.currentInputFillType = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v190)
				v179.useWindrow = false
			end
			v189 = v192 * g_currentMission:getHarvestScaleMultiplier(v190, v194, v195, v196, v197, v198, v199, v200)
			v179.workAreaParameters.lastFruitType = v190
			v188 = v192
			break
		end
	end
	if v188 > 0 then
		if p177.chopperAreaIndex ~= nil and v179.workAreaParameters.lastFruitType ~= nil then
			local v203 = p176:getWorkAreaByIndex(p177.chopperAreaIndex)
			if v203 == nil then
				Logging.xmlWarning(p176.xmlFile, "Invalid chopperAreaIndex \'%d\' for workArea \'%d\'!", p177.chopperAreaIndex, p177.index)
				p177.chopperAreaIndex = nil
			else
				local v204
				v181, v204, v182 = getWorldTranslation(v203.start)
				local v205
				v183, v205, v184 = getWorldTranslation(v203.width)
				local v206
				v185, v206, v186 = getWorldTranslation(v203.height)
				local v207 = g_fruitTypeManager:getFruitTypeByIndex(v179.workAreaParameters.lastFruitType)
				if v207.chopperType == nil then
					if v207.chopperUseHaulm and FSDensityMapUtil.updateFruitHaulmArea(v179.workAreaParameters.lastFruitType, v181, v182, v183, v184, v185, v186) > 0 then
						FSDensityMapUtil.eraseTireTrack(v181, v182, v183, v184, v185, v186)
					end
				else
					local v208 = FieldChopperType.getValueByType(v207.chopperType)
					if v208 ~= nil then
						FSDensityMapUtil.setGroundTypeLayerArea(v181, v182, v183, v184, v185, v186, v208)
					end
				end
			end
		end
		v179.stoneLastState = FSDensityMapUtil.getStoneArea(v181, v182, v183, v184, v185, v186)
		v179.isWorking = true
	end
	v179.workAreaParameters.lastArea = v179.workAreaParameters.lastArea + v188
	v179.workAreaParameters.lastMultiplierArea = v179.workAreaParameters.lastMultiplierArea + v189
	return v179.workAreaParameters.lastArea, v187
end
function Cutter.processPickupCutterArea(p209, p210, _)
	local v211 = p209.spec_cutter
	if v211.workAreaParameters.combineVehicle ~= nil then
		local v212, v213, v214 = getWorldTranslation(p210.start)
		local v215, v216, v217 = getWorldTranslation(p210.width)
		local v218, v219, v220 = getWorldTranslation(p210.height)
		local v221, v222, v223, v224, v225, v226, v227 = DensityMapHeightUtil.getLineByAreaDimensions(v212, v213, v214, v215, v216, v217, v218, v219, v220)
		local v228 = false
		for v229, v230 in pairs(v211.fillTypeConverter) do
			if v211.workAreaParameters.lastOutputFillType == nil or v230.targetFillTypeIndex == v211.workAreaParameters.lastOutputFillType then
				local v231 = -DensityMapHeightUtil.tipToGroundAroundLine(p209, (-1 / 0), v229, v221, v222, v223, v224, v225, v226, v227, nil, nil, false, nil)
				if p209.isServer and v231 > 0 then
					v211.currentOutputFillType = v230.targetFillTypeIndex
					v211.currentConversionFactor = v230.conversionFactor
					v211.useWindrow = true
					v211.currentInputFillType = v229
					local v232 = g_fruitTypeManager:getCutWindrowHarvestFillLevel(v229, v231)
					v211.workAreaParameters.lastLiters = v232
					v211.workAreaParameters.lastOutputFillType = v230.targetFillTypeIndex
					v211.stoneLastState = FSDensityMapUtil.getStoneArea(v212, v214, v215, v217, v218, v220)
					v211.isWorking = true
					p209:setTestAreaRequirements(nil, v229, nil)
					v228 = true
					break
				end
			end
		end
		if not p209.isServer and v211.lastAreaBiggerZeroTime + 300 > g_currentMission.time and true or v228 then
			return 1, 1
		end
		v211.workAreaParameters.lastOutputFillType = nil
	end
	return 0, 0
end
function Cutter.processHaulmDropArea(p233, p234, p235)
	local v236 = p233.spec_cutter
	if v236.valueDelay ~= nil then
		local v237 = v236.lastAreaBiggerZeroTime >= g_currentMission.time - 150
		if v236.valueDelay:add(v237 and 1 or 0, p235) == 0 then
			return 0, 0
		end
	end
	local v238 = v236.currentInputFruitType
	if v238 == nil or v238 == FruitType.UNKNOWN then
		return 0, 0
	end
	local v239, _, v240 = getWorldTranslation(p234.start)
	local v241, _, v242 = getWorldTranslation(p234.width)
	local v243, _, v244 = getWorldTranslation(p234.height)
	local v245 = FSDensityMapUtil.updateFruitHaulmArea(v238, v239, v240, v241, v242, v243, v244)
	if v245 > 0 then
		FSDensityMapUtil.eraseTireTrack(v239, v240, v241, v242, v243, v244)
	end
	return v245, v245
end
function Cutter.onStartWorkAreaProcessing(p246, _)
	local v247 = p246.spec_cutter
	local v249, v249, v250 = p246:getCombine()
	if v249 == nil then
		local _ = v250 == nil
	end
	v247.workAreaParameters.combineVehicle = v249
	v247.workAreaParameters.lastLiters = 0
	v247.workAreaParameters.lastArea = 0
	v247.workAreaParameters.lastMultiplierArea = 0
	if v247.workAreaParameters.lastFruitType == nil then
		v247.workAreaParameters.fruitTypeIndicesToUse = v247.fruitTypeIndices
	else
		for v251 = 1, #v247.workAreaParameters.lastFruitTypeToUse do
			v247.workAreaParameters.lastFruitTypeToUse[v251] = nil
		end
		v247.workAreaParameters.lastFruitTypeToUse[1] = v247.workAreaParameters.lastFruitType
		v247.workAreaParameters.fruitTypeIndicesToUse = v247.workAreaParameters.lastFruitTypeToUse
	end
	if v250 ~= nil then
		for v252 = 1, #v247.workAreaParameters.lastFruitTypeToUse do
			v247.workAreaParameters.lastFruitTypeToUse[v252] = nil
		end
		local v253 = g_fruitTypeManager:getFruitTypeIndexByFillTypeIndex(v250)
		for v254, v255 in pairs(v247.fruitTypeConverters) do
			if v255.fillTypeIndex == v250 then
				local v256 = v247.workAreaParameters.lastFruitTypeToUse
				table.insert(v256, v254)
				v253 = nil
			end
		end
		if v253 ~= nil then
			local v257 = v247.workAreaParameters.lastFruitTypeToUse
			table.insert(v257, v253)
		end
		v247.workAreaParameters.fruitTypeIndicesToUse = v247.workAreaParameters.lastFruitTypeToUse
	end
	v247.workAreaParameters.lastFruitType = nil
	v247.isWorking = false
end
function Cutter.onEndWorkAreaProcessing(p258, _, _)
	if p258.isServer then
		local v259 = p258.spec_cutter
		local v260 = v259.workAreaParameters.lastArea
		local v261 = v259.workAreaParameters.lastLiters
		if v260 > 0 or v261 > 0 then
			if v259.workAreaParameters.combineVehicle ~= nil then
				local v262 = v259.workAreaParameters.lastFruitType
				if p258:getIsAIActive() then
					local v263 = p258:getAIFruitRequirements()
					local v264 = v263[1]
					if #v263 == 1 and (v264 ~= nil and v264.fruitType ~= FruitType.UNKNOWN) then
						v262 = v264.fruitType
					end
				end
				local v265 = g_fruitTypeManager:getFruitTypeAreaLiters(v262, v259.workAreaParameters.lastMultiplierArea, false) + v261
				local v266 = v259.currentOutputFillType
				if v259.lastOutputFillTypes[v266] == nil then
					v259.lastOutputFillTypes[v266] = v260
				else
					v259.lastOutputFillTypes[v266] = v259.lastOutputFillTypes[v266] + v260
				end
				local v267
				if v259.lastPrioritizedOutputType == FillType.UNKNOWN then
					v267 = v266
				else
					v267 = v259.lastPrioritizedOutputType
				end
				local v268 = v259.currentConversionFactor or 1
				local v269 = v265 * v268
				local v270 = p258:getLastTouchedFarmlandFarmId()
				if v259.workAreaParameters.combineVehicle:addCutterArea(v260, v269, v262, v267, v259.strawRatio * (1 / v268), v270, p258:getCutterLoad()) > 0 and v267 == v266 then
					v259.lastValidInputFruitType = v262
				end
			end
			local v271 = MathUtil.areaToHa(v260, g_currentMission:getFruitPixelsToSqm())
			g_farmManager:updateFarmStats(p258:getLastTouchedFarmlandFarmId(), "threshedHectares", v271)
			p258:updateLastWorkedArea(v260)
			v259.lastAreaBiggerZero = v260 > 0 and true or v261 > 0
			if v259.lastAreaBiggerZero then
				v259.lastAreaBiggerZeroTime = g_currentMission.time
			end
			if v259.lastAreaBiggerZero ~= v259.lastAreaBiggerZeroSent then
				p258:raiseDirtyFlags(v259.dirtyFlag)
				v259.lastAreaBiggerZeroSent = v259.lastAreaBiggerZero
			end
			if v259.currentInputFruitType ~= v259.currentInputFruitTypeSent then
				p258:raiseDirtyFlags(v259.effectDirtyFlag)
				v259.currentInputFruitTypeSent = v259.currentInputFruitType
			end
			if v259.currentInputFillType ~= v259.currentInputFillTypeSent then
				p258:raiseDirtyFlags(v259.effectDirtyFlag)
				v259.currentInputFillTypeSent = v259.currentInputFillType
			end
			if p258:getAllowCutterAIFruitRequirements() and p258.setAIFruitRequirements ~= nil then
				local v272 = p258:getAIFruitRequirements()
				local v273 = v272[1]
				if #v272 > 1 or (v273 == nil or v273.fruitType == FruitType.UNKNOWN) then
					local v274 = g_fruitTypeManager:getFruitTypeByIndex(v259.currentInputFruitTypeAI)
					if v274 ~= nil then
						local v275 = v259.allowsForageGrowthState and v274.minForageGrowthState or v274.minHarvestingGrowthState
						p258:setAIFruitRequirements(v259.currentInputFruitTypeAI, v275, v274.maxHarvestingGrowthState)
					end
				end
			end
		end
	end
end
function Cutter.getCutterLoad(p276)
	local v277 = p276:getLastSpeed() / p276.speedLimit
	local v278 = math.clamp(v277, 0, 1) * 0.75 + 0.25
	return p276.spec_cutter.cutterLoad * v278
end
function Cutter.getCutterStoneMultiplier(p279)
	local v280 = p279.spec_cutter
	return (v280.stoneLastState == 0 or v280.stoneWearMultiplierData == nil) and 1 or (v280.stoneWearMultiplierData[v280.stoneLastState] or 1)
end
function Cutter.loadCutterTiltFromXML(p_u_281, p_u_282, p283, p_u_284)
	p_u_284.nodes = {}
	p_u_282:iterate(p283 .. ".automaticTiltNode", function(_, p285)
		-- upvalues: (copy) p_u_282, (copy) p_u_281, (copy) p_u_284
		local v286 = {
			["node"] = p_u_282:getValue(p285 .. "#node", nil, p_u_281.components, p_u_281.i3dMappings)
		}
		if v286.node ~= nil then
			v286.minAngle = p_u_282:getValue(p285 .. "#minAngle", -5)
			v286.maxAngle = p_u_282:getValue(p285 .. "#maxAngle", 5)
			v286.maxSpeed = p_u_282:getValue(p285 .. "#maxSpeed", 2) / 1000
			local v287 = p_u_284.nodes
			table.insert(v287, v286)
		end
	end)
	p_u_284.raycastNode1 = p_u_282:getValue(p283 .. "#raycastNode1", nil, p_u_281.components, p_u_281.i3dMappings)
	p_u_284.raycastNode2 = p_u_282:getValue(p283 .. "#raycastNode2", nil, p_u_281.components, p_u_281.i3dMappings)
	if p_u_284.raycastNode1 == nil or p_u_284.raycastNode2 == nil then
		return false
	end
	local v288, _, _ = localToLocal(p_u_284.raycastNode1, p_u_281.rootNode, 0, 0, 0)
	local v289, _, _ = localToLocal(p_u_284.raycastNode2, p_u_281.rootNode, 0, 0, 0)
	if v288 < v289 then
		local v290 = p_u_284.raycastNode1
		p_u_284.raycastNode1 = p_u_284.raycastNode2
		p_u_284.raycastNode2 = v290
	end
	return true
end
function Cutter.getCutterTiltIsAvailable(p291)
	return p291.spec_cutter.automaticTilt.isAvailable
end
function Cutter.getCutterTiltIsActive(p292, p293)
	if p293.isAvailable and p292.isActive then
		if p292:getIsLowered(true) and (p292.getAttacherVehicle == nil or p292:getAttacherVehicle() ~= nil) then
			return true, false
		else
			return false, true
		end
	else
		return false, false
	end
end
function Cutter.getCutterTiltDelta(p294)
	local v295 = p294.spec_cutter
	local v296, v297 = p294:getCutterTiltIsActive(v295.automaticTilt)
	return v296 and v295.automaticTilt.currentDelta or 0, v296, v297
end
function Cutter.tiltRaycastDetectionCallback(p298, p299, p300, p301, p302, _)
	if getRigidBodyType(p299) ~= RigidBodyType.STATIC then
		return true
	end
	local v303 = p298.spec_cutter.automaticTilt
	v303.lastHit[1] = p300
	v303.lastHit[2] = p301
	v303.lastHit[3] = p302
	v303.raycastHit = true
	return false
end
function Cutter.setCutterCutHeight(p304, p305)
	if p305 ~= nil then
		p304.spec_cutter.currentCutHeight = p305
		if p304.spec_attachable ~= nil then
			local v306 = p304:getActiveInputAttacherJoint()
			if v306 == nil or not v306.useFruitCutHeight then
				local v307 = p304:getInputAttacherJoints()
				for v308 = 1, #v307 do
					local v309 = v307[v308]
					if v309.useFruitCutHeight and (v309.jointType == AttacherJoints.JOINTTYPE_CUTTER or v309.jointType == AttacherJoints.JOINTTYPE_CUTTERHARVESTER) then
						v309.lowerDistanceToGround = p305
					end
				end
			elseif v306.jointType == AttacherJoints.JOINTTYPE_CUTTER or v306.jointType == AttacherJoints.JOINTTYPE_CUTTERHARVESTER then
				v306.lowerDistanceToGround = p305
				return
			end
		end
	end
end
function Cutter.loadSpeedRotatingPartFromXML(p310, p311, p312, p313, p314)
	if not p311(p310, p312, p313, p314) then
		return false
	end
	p312.rotateIfTurnedOn = p313:getValue(p314 .. "#rotateIfTurnedOn", false)
	return true
end
function Cutter.getIsSpeedRotatingPartActive(p315, p316, p317)
	if p317.rotateIfTurnedOn and not p315:getIsTurnedOn() then
		return false
	else
		return p316(p315, p317)
	end
end
function Cutter.loadRandomlyMovingPartFromXML(p318, p319, p320, p321, p322)
	local v323 = p319(p318, p320, p321, p322)
	p320.moveOnlyIfCut = p321:getValue(p322 .. "#moveOnlyIfCut", false)
	return v323
end
function Cutter.getIsRandomlyMovingPartActive(p324, p325, p326)
	local v327 = p325(p324, p326)
	if p326.moveOnlyIfCut then
		if v327 then
			v327 = p324.spec_cutter.lastAreaBiggerZeroTime >= g_currentMission.time - 150
		end
	end
	return v327
end
function Cutter.getIsWorkAreaActive(p328, p329, p330)
	if p330.type == WorkAreaType.CUTTER then
		local v331 = p328.spec_cutter
		if (p328.getAllowsLowering == nil or p328:getAllowsLowering()) and not (v331.allowCuttingWhileRaised or p328:getIsLowered(true)) then
			return false
		end
	end
	return p329(p328, p330)
end
function Cutter.doCheckSpeedLimit(p332, p333)
	local v334 = not p333(p332) and p332:getIsTurnedOn()
	if v334 then
		v334 = p332.getIsLowered == nil and true or p332:getIsLowered()
	end
	return v334
end
function Cutter.loadWorkAreaFromXML(p335, p336, p337, p338, p339)
	local v340 = p336(p335, p337, p338, p339)
	p337.chopperAreaIndex = p338:getValue(p339 .. ".chopperArea#index")
	return v340
end
function Cutter.getDirtMultiplier(p341, p342)
	if p341.spec_cutter.isWorking then
		return p342(p341) + p341:getWorkDirtMultiplier() * p341:getLastSpeed() / p341.speedLimit
	else
		return p342(p341)
	end
end
function Cutter.getWearMultiplier(p343, p344)
	local v345 = p343.spec_cutter
	if not v345.isWorking then
		return p344(p343)
	end
	local v346 = (v345.stoneLastState == 0 or v345.stoneWearMultiplierData == nil) and 1 or (v345.stoneWearMultiplierData[v345.stoneLastState] or 1)
	return p344(p343) + p343:getWorkWearMultiplier() * p343:getLastSpeed() / p343.speedLimit * v346
end
function Cutter.isAttachAllowed(p347, p348, p349, p350)
	local v351 = p347.spec_cutter
	if p350.spec_combine == nil or p350:getIsCutterCompatible(v351.outputFillTypes) then
		return p348(p347, p349, p350)
	else
		return false, g_i18n:getText("warning_cutterNotCompatible")
	end
end
function Cutter.getConsumingLoad(p352, p353)
	local v354, v355 = p353(p352)
	return v354 + p352:getCutterLoad(), v355 + 1
end
function Cutter.getIsGroundReferenceNodeThreshold(p356, p357, p358)
	return p357(p356, p358) + p356.spec_cutter.currentCutHeight
end
function Cutter.getDefaultAllowComponentMassReduction(_)
	return true
end
function Cutter.loadInputAttacherJoint(p359, p360, p361, p362, p363, p364)
	if not p360(p359, p361, p362, p363, p364) then
		return false
	end
	p363.useFruitCutHeight = p361:getValue(p362 .. "#useFruitCutHeight", true)
	return true
end
function Cutter.getFruitExtraObjectTypeData(p365, _)
	return p365.spec_cutter.lastValidInputFruitType, nil
end
function Cutter.onTurnedOn(p366)
	if p366.isClient then
		local v367 = p366.spec_cutter
		g_animationManager:startAnimations(v367.animationNodes)
	end
end
function Cutter.onTurnedOff(p368)
	local v369 = p368.spec_cutter
	if p368.isClient then
		g_animationManager:stopAnimations(v369.animationNodes)
	end
	v369.currentInputFruitType = FruitType.UNKNOWN
	v369.currentInputFruitTypeSent = FruitType.UNKNOWN
	v369.currentInputFruitTypeAI = FruitType.UNKNOWN
	v369.currentInputFillType = FillType.UNKNOWN
	v369.currentOutputFillType = FillType.UNKNOWN
end
function Cutter.onAIImplementStart(p370)
	if p370:getAllowCutterAIFruitRequirements() then
		p370:clearAIFruitRequirements()
		local v371 = p370.spec_cutter
		for _, v372 in ipairs(v371.fruitTypeIndices) do
			local v373 = g_fruitTypeManager:getFruitTypeByIndex(v372)
			if v373 ~= nil then
				local v374 = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v372)
				if v371.fruitTypeConverters[v372] ~= nil then
					v374 = v371.fruitTypeConverters[v372].fillTypeIndex
				end
				if p370:getCombine(v372, v374) ~= nil then
					local v375 = v371.allowsForageGrowthState and v373.minForageGrowthState or v373.minHarvestingGrowthState
					p370:addAIFruitRequirement(v373.index, v375, v373.maxHarvestingGrowthState)
				end
			end
		end
	end
end
function Cutter.onAIFieldCourseSettingsInitialized(_, p376)
	p376.headlandsFirst = true
	p376.workInitialSegment = true
	p376.cornerCutOutSupported = true
end
function Cutter.getDefaultSpeedLimit()
	return 10
end
function Cutter.updateDebugValues(p377, p378)
	local v379 = p377.spec_cutter
	local v380 = {
		["name"] = "lastPrioritizedOutputType",
		["value"] = string.format("%s", g_fillTypeManager:getFillTypeNameByIndex(v379.lastPrioritizedOutputType))
	}
	table.insert(p378, v380)
	local v381 = {
		["name"] = "currentCutHeight",
		["value"] = string.format("%.2f", v379.currentCutHeight)
	}
	table.insert(p378, v381)
	local v382 = 0
	for _, v383 in pairs(v379.lastOutputFillTypes) do
		v382 = v382 + v383
	end
	for v384, v385 in pairs(v379.lastOutputFillTypes) do
		local v386 = {
			["name"] = string.format("buffer (%s)", g_fillTypeManager:getFillTypeNameByIndex(v384)),
			["value"] = string.format("%.0f%%", v385 / math.max(v382, 0.01) * 100)
		}
		table.insert(p378, v386)
	end
end

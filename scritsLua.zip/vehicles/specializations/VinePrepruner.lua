VinePrepruner = {}
VinePrepruner.PRUNER_NODE_XML_KEY = "vehicle.vinePrepruner.prunerNode(?)"
function VinePrepruner.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("VinePrepruner")
	v1:register(XMLValueType.STRING, "vehicle.vinePrepruner#fruitType", "Fruit type")
	local v2 = VinePrepruner.PRUNER_NODE_XML_KEY
	v1:register(XMLValueType.NODE_INDEX, v2 .. "#node", "Pruner node that adjusts translation depending on raycast distance")
	v1:register(XMLValueType.FLOAT, v2 .. "#offset", "Offset from raycast node to center of pruning unit", 0.5)
	v1:register(XMLValueType.INT, v2 .. "#axis", "Move axis", 1)
	v1:register(XMLValueType.INT, v2 .. "#direction", "Translation direction", 1)
	v1:register(XMLValueType.FLOAT, v2 .. "#transMin", "Min. translation", 0)
	v1:register(XMLValueType.FLOAT, v2 .. "#transMax", "Max. translation", 1)
	v1:register(XMLValueType.FLOAT, v2 .. "#transSpeed", "Translation speed (m/sec)", 0.5)
	v1:register(XMLValueType.INT, v2 .. "#numBits", "Number of bits to sync state in multiplayer", 8)
	v1:register(XMLValueType.STRING, "vehicle.vinePrepruner.poleAnimation#name", "Name of pole animation (will be triggered as soon as pole has been detected)")
	v1:register(XMLValueType.FLOAT, "vehicle.vinePrepruner.poleAnimation#speedScale", "Animation speed scale", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.vinePrepruner.poleAnimation#poleThreshold", "Defines when the pole is detected as percentage of segment length", 0.1)
	EffectManager.registerEffectXMLPaths(v1, "vehicle.vinePrepruner.effect")
	v1:setXMLSpecializationType()
end
function VinePrepruner.prerequisitesPresent(p3)
	return SpecializationUtil.hasSpecialization(VineDetector, p3)
end
function VinePrepruner.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "loadPreprunerNodeFromXML", VinePrepruner.loadPreprunerNodeFromXML)
	SpecializationUtil.registerFunction(p4, "getIsPreprunerNodeActive", VinePrepruner.getIsPreprunerNodeActive)
end
function VinePrepruner.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", VinePrepruner.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanStartVineDetection", VinePrepruner.getCanStartVineDetection)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsValidVinePlaceable", VinePrepruner.getIsValidVinePlaceable)
	SpecializationUtil.registerOverwrittenFunction(p5, "handleVinePlaceable", VinePrepruner.handleVinePlaceable)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAIImplementUseVineSegment", VinePrepruner.getAIImplementUseVineSegment)
end
function VinePrepruner.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", VinePrepruner)
	SpecializationUtil.registerEventListener(p6, "onDelete", VinePrepruner)
	SpecializationUtil.registerEventListener(p6, "onReadStream", VinePrepruner)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", VinePrepruner)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", VinePrepruner)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", VinePrepruner)
	SpecializationUtil.registerEventListener(p6, "onUpdate", VinePrepruner)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", VinePrepruner)
	SpecializationUtil.registerEventListener(p6, "onAnimationPartChanged", VinePrepruner)
end
function VinePrepruner.onLoad(p_u_7, _)
	local v_u_8 = p_u_7.spec_vinePrepruner
	local v9 = p_u_7.xmlFile:getValue("vehicle.vinePrepruner#fruitType")
	local v10 = g_fruitTypeManager:getFruitTypeByName(v9)
	if v10 == nil then
		v_u_8.fruitTypeIndex = FruitType.GRAPE
	else
		v_u_8.fruitTypeIndex = v10.index
	end
	v_u_8.prunerNodes = {}
	p_u_7.xmlFile:iterate("vehicle.vinePrepruner.prunerNode", function(_, p11)
		-- upvalues: (copy) p_u_7, (copy) v_u_8
		local v12 = {}
		if p_u_7:loadPreprunerNodeFromXML(p_u_7.xmlFile, p11, v12) then
			local v13 = v_u_8.prunerNodes
			table.insert(v13, v12)
		end
	end)
	v_u_8.poleAnimation = {}
	v_u_8.poleAnimation.name = p_u_7.xmlFile:getValue("vehicle.vinePrepruner.poleAnimation#name")
	v_u_8.poleAnimation.speedScale = p_u_7.xmlFile:getValue("vehicle.vinePrepruner.poleAnimation#speedScale", 1)
	v_u_8.poleAnimation.poleThreshold = 1 - p_u_7.xmlFile:getValue("vehicle.vinePrepruner.poleAnimation#poleThreshold", 0.1)
	v_u_8.lastWorkTime = -10000
	v_u_8.effectState = false
	if p_u_7.isClient then
		v_u_8.effects = g_effectManager:loadEffect(p_u_7.xmlFile, "vehicle.vinePrepruner.effect", p_u_7.components, p_u_7, p_u_7.i3dMappings)
	end
	v_u_8.dirtyFlag = p_u_7:getNextDirtyFlag()
end
function VinePrepruner.onDelete(p14)
	local v15 = p14.spec_vinePrepruner
	g_effectManager:deleteEffects(v15.effects)
end
function VinePrepruner.onReadStream(p16, p17, _)
	VinePrepruner.readPrePrunerFromStream(p16, p17, true)
end
function VinePrepruner.onWriteStream(p18, p19, _)
	VinePrepruner.writePrePrunerToStream(p18, p19)
end
function VinePrepruner.onReadUpdateStream(p20, p21, _, p22)
	if p22:getIsServer() and streamReadBool(p21) then
		VinePrepruner.readPrePrunerFromStream(p20, p21)
	end
end
function VinePrepruner.onWriteUpdateStream(p23, p24, p25, p26)
	if not p25:getIsServer() then
		local v27 = p23.spec_vinePrepruner
		if streamWriteBool(p24, bitAND(p26, v27.dirtyFlag) ~= 0) then
			VinePrepruner.writePrePrunerToStream(p23, p24)
		end
	end
end
function VinePrepruner.readPrePrunerFromStream(p28, p29, p30)
	local v31 = p28.spec_vinePrepruner
	for v32 = 1, #v31.prunerNodes do
		local v33 = v31.prunerNodes[v32]
		local v34 = 2 ^ v33.numBits - 1
		v33.transTarget = streamReadUIntN(p29, v33.numBits) / v34 * (v33.transMax - v33.transMin) + v33.transMin
		if p30 then
			v33.curTrans[v33.axis] = v33.transTarget
			setTranslation(v33.node, v33.curTrans[1], v33.curTrans[2], v33.curTrans[3])
		end
	end
	local v35 = streamReadBool(p29)
	if v35 ~= v31.effectState then
		v31.effectState = v35
		if v35 then
			g_effectManager:setEffectTypeInfo(v31.cutterEffects, nil, v31.fruitTypeIndex, nil)
			g_effectManager:startEffects(v31.effects)
			return
		end
		g_effectManager:stopEffects(v31.effects)
	end
end
function VinePrepruner.writePrePrunerToStream(p36, p37)
	local v38 = p36.spec_vinePrepruner
	for v39 = 1, #v38.prunerNodes do
		local v40 = v38.prunerNodes[v39]
		local v41 = 2 ^ v40.numBits - 1
		local v42 = (v40.transTarget - v40.transMin) / (v40.transMax - v40.transMin)
		streamWriteUIntN(p37, v42 * v41, v40.numBits)
	end
	streamWriteBool(p37, v38.effectState)
end
function VinePrepruner.onUpdate(p43, p44, _, _, _)
	local v45 = p43.spec_vinePrepruner
	for v46 = 1, #v45.prunerNodes do
		local v47 = v45.prunerNodes[v46]
		if p43:getIsPreprunerNodeActive(v47) then
			local v48 = v47.curTrans[v47.axis]
			if v47.transTarget ~= v48 then
				local v49 = v47.transTarget - v48
				local v50 = math.sign(v49)
				local v51 = v50 >= 0 and math.min or math.max
				v47.curTrans[v47.axis] = v51(v48 + v47.transSpeed * p44 * v50, v47.transTarget)
				setTranslation(v47.node, v47.curTrans[1], v47.curTrans[2], v47.curTrans[3])
			end
		end
	end
	if p43.isServer then
		local v52 = v45.lastWorkTime + 1000 > g_time
		if v52 ~= v45.effectState then
			v45.effectState = v52
			if p43.isClient then
				if v52 then
					g_effectManager:setEffectTypeInfo(v45.cutterEffects, nil, v45.fruitTypeIndex, nil)
					g_effectManager:startEffects(v45.effects)
				else
					g_effectManager:stopEffects(v45.effects)
				end
			end
			p43:raiseDirtyFlags(v45.dirtyFlag)
		end
	end
end
function VinePrepruner.onTurnedOff(p53)
	p53:cancelVineDetection()
end
function VinePrepruner.onAnimationPartChanged(p54, p55)
	local v56 = p54.spec_vinePrepruner
	for v57 = 1, #v56.prunerNodes do
		local v58 = v56.prunerNodes[v57]
		if v58.node == p55 then
			local v59 = v58.curTrans
			local v60 = v58.curTrans
			local v61 = v58.curTrans
			local v62, v63, v64 = getTranslation(v58.node)
			v59[1] = v62
			v60[2] = v63
			v61[3] = v64
		end
	end
end
function VinePrepruner.loadPreprunerNodeFromXML(p65, _, p66, p67)
	p67.node = p65.xmlFile:getValue(p66 .. "#node", nil, p65.components, p65.i3dMappings)
	if p67.node == nil then
		return false
	end
	p67.offset = p65.xmlFile:getValue(p66 .. "#offset", 0.5)
	p67.axis = p65.xmlFile:getValue(p66 .. "#axis", 1)
	p67.direction = p65.xmlFile:getValue(p66 .. "#direction", 1)
	p67.transMin = p65.xmlFile:getValue(p66 .. "#transMin", 0)
	p67.transMax = p65.xmlFile:getValue(p66 .. "#transMax", 1)
	p67.transSpeed = p65.xmlFile:getValue(p66 .. "#transSpeed", 0.5) / 1000
	p67.curTrans = { getTranslation(p67.node) }
	p67.transTarget = p67.curTrans[p67.axis]
	p67.numBits = p65.xmlFile:getValue(p66 .. "#numBits", 8)
	return true
end
function VinePrepruner.getIsPreprunerNodeActive(_, _)
	return true
end
function VinePrepruner.getCanStartVineDetection(p68, p69)
	if p69(p68) then
		if p68:getIsTurnedOn() then
			return p68.movingDirection ~= 0
		else
			return false
		end
	else
		return false
	end
end
function VinePrepruner.getIsValidVinePlaceable(p70, p71, p72)
	if not p71(p70, p72) then
		return false
	end
	local v73 = p70.spec_vinePrepruner
	return p72:getVineFruitType() == v73.fruitTypeIndex
end
function VinePrepruner.handleVinePlaceable(p74, p75, p76, p77, p78, p79, p80, p81)
	if not p75(p74, p76, p77, p78, p79, p80, p81) then
		return false
	end
	if p77 == nil then
		return false
	end
	local v82 = p74.spec_vinePrepruner
	local v83, v84, v85 = p74:getFirstVineHitPosition()
	local v86, v87, v88 = p74:getCurrentVineHitPosition()
	if p77:prepareVine(p76, v83, v84, v85, v86, v87, v88) > 0 then
		v82.lastWorkTime = g_time
	end
	if v82.poleAnimation.name ~= nil then
		local _, _, v89 = worldToLocal(p76, v83, v84, v85)
		local _, _, v90 = worldToLocal(p76, v86, v87, v88)
		local v91 = v90 - v89
		local v92 = math.sign(v91) >= 0 and 1 or -1
		local v93 = v90 / p77:getPanelLength()
		if v92 < 0 then
			v93 = 1 - v93
		end
		if not p74:getIsAnimationPlaying(v82.poleAnimation.name) then
			if v82.poleAnimation.poleThreshold < v93 then
				if p74:getAnimationTime(v82.poleAnimation.name) < 0.5 then
					p74:playAnimation(v82.poleAnimation.name, v82.poleAnimation.speedScale)
				end
			elseif p74:getAnimationTime(v82.poleAnimation.name) > 0.5 then
				p74:playAnimation(v82.poleAnimation.name, -v82.poleAnimation.speedScale)
			end
		end
	end
	for v94 = 1, #v82.prunerNodes do
		local v95 = v82.prunerNodes[v94]
		local v96 = (p81 - v95.offset) * v95.direction
		local v97 = v95.transMin
		local v98 = v95.transMax
		v95.transTarget = math.clamp(v96, v97, v98)
		p74:raiseDirtyFlags(v82.dirtyFlag)
	end
	return true
end
function VinePrepruner.getAIImplementUseVineSegment(p99, _, p100, p101, p102)
	if p102 >= 0 then
		return p100:getHasSegmentTargetGrowthState(p101, p99.spec_vinePrepruner.fruitTypeIndex, false, true)
	else
		return false
	end
end
function VinePrepruner.doCheckSpeedLimit(p103, p104)
	return p104(p103) or p103:getIsTurnedOn()
end
function VinePrepruner.getDefaultSpeedLimit()
	return 5
end

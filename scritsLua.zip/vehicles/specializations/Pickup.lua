source("dataS/scripts/vehicles/specializations/events/PickupSetStateEvent.lua")
Pickup = {}
Pickup.PICKUP_XML_KEY = "vehicle.pickup"
function Pickup.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
end
function Pickup.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Pickup")
	v2:register(XMLValueType.STRING, Pickup.PICKUP_XML_KEY .. ".animation#name", "Pickup animation name")
	v2:register(XMLValueType.FLOAT, Pickup.PICKUP_XML_KEY .. ".animation#lowerSpeed", "Pickup animation lower speed")
	v2:register(XMLValueType.FLOAT, Pickup.PICKUP_XML_KEY .. ".animation#liftSpeed", "Pickup animation lift speed")
	v2:register(XMLValueType.BOOL, Pickup.PICKUP_XML_KEY .. ".animation#isDefaultLowered", "Pickup animation is default lowered")
	v2:setXMLSpecializationType()
end
function Pickup.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "allowPickingUp", Pickup.allowPickingUp)
	SpecializationUtil.registerFunction(p3, "setPickupState", Pickup.setPickupState)
	SpecializationUtil.registerFunction(p3, "loadPickupFromXML", Pickup.loadPickupFromXML)
	SpecializationUtil.registerFunction(p3, "getCanChangePickupState", Pickup.getCanChangePickupState)
end
function Pickup.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsLowered", Pickup.getIsLowered)
	SpecializationUtil.registerOverwrittenFunction(p4, "getDirtMultiplier", Pickup.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p4, "getWearMultiplier", Pickup.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p4, "registerLoweringActionEvent", Pickup.registerLoweringActionEvent)
	SpecializationUtil.registerOverwrittenFunction(p4, "registerSelfLoweringActionEvent", Pickup.registerSelfLoweringActionEvent)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanDischargeToGround", Pickup.getCanDischargeToGround)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanDischargeToObject", Pickup.getCanDischargeToObject)
end
function Pickup.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", Pickup)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", Pickup)
	SpecializationUtil.registerEventListener(p5, "onReadStream", Pickup)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", Pickup)
	SpecializationUtil.registerEventListener(p5, "onSetLoweredAll", Pickup)
	SpecializationUtil.registerEventListener(p5, "onRootVehicleChanged", Pickup)
	SpecializationUtil.registerEventListener(p5, "onFoldTimeChanged", Pickup)
end
function Pickup.onLoad(p6, _)
	p6:loadPickupFromXML(p6.xmlFile, "vehicle.pickup", p6.spec_pickup)
end
function Pickup.onPostLoad(p7, _)
	local v8 = p7.spec_pickup
	if v8.animationName ~= "" then
		local v9
		if v8.animationIsDefaultLowered then
			v8.isLowered = true
			v9 = 20
		else
			v9 = -20
		end
		p7:playAnimation(v8.animationName, v9, nil, true)
		AnimatedVehicle.updateAnimations(p7, 99999999, true)
	end
end
function Pickup.onReadStream(p10, p11, _)
	p10:setPickupState(streamReadBool(p11), true)
end
function Pickup.onWriteStream(p12, p13, _)
	local v14 = p12.spec_pickup
	streamWriteBool(p13, v14.isLowered)
end
function Pickup.onSetLoweredAll(p15, p16, _)
	p15:setPickupState(p16)
end
function Pickup.onRootVehicleChanged(p17, p18)
	local v19 = p17.spec_pickup
	if v19.animationName ~= "" then
		local v20 = p18.actionController
		if v20 == nil then
			if v19.controlledAction ~= nil then
				v19.controlledAction:remove()
			end
		else
			if v19.controlledAction ~= nil then
				v19.controlledAction:updateParent(v20)
				return
			end
			v19.controlledAction = v20:registerAction("lowerPickup", InputAction.LOWER_IMPLEMENT, 2)
			v19.controlledAction:setCallback(p17, Pickup.actionControllerLowerPickupEvent)
			v19.controlledAction:setFinishedFunctions(p17, p17.getIsLowered, true, false)
			v19.controlledAction:setIsSaved(true)
			if p17:getAINeedsLowering() then
				v19.controlledAction:addAIEventListener(p17, "onAIImplementStartLine", 1)
				v19.controlledAction:addAIEventListener(p17, "onAIImplementEndLine", -1)
				v19.controlledAction:addAIEventListener(p17, "onAIImplementStart", -1)
				return
			end
		end
	end
end
function Pickup.onFoldTimeChanged(p21, _)
	Pickup.updateActionEvents(p21)
end
function Pickup.actionControllerLowerPickupEvent(p22, p23)
	p22:setPickupState(p23 > 0)
	return true
end
function Pickup.setPickupState(p24, p25, p26)
	local v27 = p24.spec_pickup
	if p25 ~= v27.isLowered then
		PickupSetStateEvent.sendEvent(p24, p25, p26)
		v27.isLowered = p25
		if v27.animationName ~= "" then
			local v28
			if p24:getIsAnimationPlaying(v27.animationName) then
				v28 = p24:getAnimationTime(v27.animationName)
			else
				v28 = nil
			end
			if p25 then
				p24:playAnimation(v27.animationName, v27.animationLowerSpeed, v28, true)
			else
				p24:playAnimation(v27.animationName, v27.animationLiftSpeed, v28, true)
			end
		end
		Pickup.updateActionEvents(p24)
	end
end
function Pickup.allowPickingUp(p29)
	return p29.spec_pickup.isLowered
end
function Pickup.getIsLowered(p30, _, _)
	return p30.spec_pickup.isLowered
end
function Pickup.loadPickupFromXML(p31, p32, p33, p34)
	XMLUtil.checkDeprecatedXMLElements(p32, "vehicle.pickupAnimation", p33 .. ".animation")
	p34.isLowered = false
	p34.animationName = p32:getValue(p33 .. ".animation#name", "")
	if not p31:getAnimationExists(p34.animationName) then
		p34.animationName = ""
		p34.isLowered = true
	end
	p34.animationLowerSpeed = p32:getValue(p33 .. ".animation#lowerSpeed", 1)
	p34.animationLiftSpeed = p32:getValue(p33 .. ".animation#liftSpeed", -p34.animationLowerSpeed)
	p34.animationIsDefaultLowered = p32:getValue(p33 .. ".animation#isDefaultLowered", false)
	return true
end
function Pickup.getCanChangePickupState(_, _, _)
	return true
end
function Pickup.getDirtMultiplier(p35, p36)
	if p35.spec_pickup.isLowered and (p35.getIsTurnedOn == nil or p35:getIsTurnedOn()) then
		return p36(p35) + p35:getWorkDirtMultiplier() * p35:getLastSpeed() / p35.speedLimit
	else
		return p36(p35)
	end
end
function Pickup.getWearMultiplier(p37, p38)
	if p37.spec_pickup.isLowered and (p37.getIsTurnedOn == nil or p37:getIsTurnedOn()) then
		return p38(p37) + p37:getWorkWearMultiplier() * p37:getLastSpeed() / p37.speedLimit
	else
		return p38(p37)
	end
end
function Pickup.registerLoweringActionEvent(p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50)
	local v51 = p39.spec_pickup
	if v51.animationName ~= "" then
		local _, v52 = p39:addPoweredActionEvent(v51.actionEvents, InputAction.LOWER_IMPLEMENT, p39, Pickup.actionEventTogglePickup, p45, p46, p47, p48, p49, p50)
		g_inputBinding:setActionEventTextPriority(v52, GS_PRIO_HIGH)
		Pickup.updateActionEvents(p39)
		if p42 == InputAction.LOWER_IMPLEMENT then
			return
		end
	end
	p40(p39, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50)
end
function Pickup.registerSelfLoweringActionEvent(p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63, p64, p65)
	return Pickup.registerLoweringActionEvent(p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63, p64, p65)
end
function Pickup.getCanDischargeToGround(p66, p67, p68)
	if p66.spec_pickup.allowWhileTipping or not p66.spec_pickup.isLowered then
		return p67(p66, p68)
	else
		return false
	end
end
function Pickup.getCanDischargeToObject(p69, p70, p71)
	if p69.spec_pickup.allowWhileTipping or not p69.spec_pickup.isLowered then
		return p70(p69, p71)
	else
		return false
	end
end
function Pickup.updateActionEvents(p72)
	local v73 = p72.spec_pickup
	if v73.animationName ~= "" then
		local v74 = v73.actionEvents[InputAction.LOWER_IMPLEMENT]
		if v74 ~= nil then
			if v73.isLowered then
				g_inputBinding:setActionEventText(v74.actionEventId, string.format(g_i18n:getText("action_liftOBJECT"), g_i18n:getText("typeDesc_pickup")))
			else
				g_inputBinding:setActionEventText(v74.actionEventId, string.format(g_i18n:getText("action_lowerOBJECT"), g_i18n:getText("typeDesc_pickup")))
			end
			g_inputBinding:setActionEventActive(v74.actionEventId, p72:getCanChangePickupState(v73, not v73.isLowered))
		end
	end
end
function Pickup.actionEventTogglePickup(p75, _, _, _, _)
	local v76 = p75.spec_pickup
	if p75:getCanChangePickupState(v76, not v76.isLowered) then
		p75:setPickupState(not v76.isLowered)
	end
end

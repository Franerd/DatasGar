GroundAdjustedNodes = {}
GroundAdjustedNodes.GROUND_ADJUSTED_NODE_XML_KEY = "vehicle.groundAdjustedNodes.groundAdjustedNode(?)"
GroundAdjustedNodes.COLLISION_MASK = CollisionFlag.TERRAIN + CollisionFlag.STATIC_OBJECT
GroundAdjustedNodes.COLLISION_MASK_WATER = GroundAdjustedNodes.COLLISION_MASK + CollisionFlag.WATER
function GroundAdjustedNodes.prerequisitesPresent(_)
	return true
end
function GroundAdjustedNodes.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("GroundAdjustedNodes")
	local v2 = GroundAdjustedNodes.GROUND_ADJUSTED_NODE_XML_KEY
	v1:register(XMLValueType.FLOAT, "vehicle.groundAdjustedNodes#maxUpdateDistance", "If the player is more than this distance away the nodes will no longer be updated", 100)
	v1:register(XMLValueType.FLOAT, "vehicle.groundAdjustedNodes#maxUpdateDistanceWobble", "If the player is more than this distance away the wobble effect which is applied on the field will not be shown anymore", 50)
	v1:register(XMLValueType.BOOL, "vehicle.groundAdjustedNodes#adjustToWater", "If \'true\', the adjust node will be placed on top of any water plane", false)
	v1:register(XMLValueType.BOOL, "vehicle.groundAdjustedNodes#onlyActiveWhileAttached", "Defines if the tool needs to be attached to have the ground adjusted nodes active", true)
	v1:register(XMLValueType.FLOAT, v2 .. "#activationTime", "In this time after the activation of the node the #moveSpeedStateChange will be used", 0)
	v1:register(XMLValueType.FLOAT, v2 .. "#yOffset", "Raycast Y translation offset (Raycast will start this distance above the node)")
	v1:register(XMLValueType.NODE_INDEX, v2 .. ".raycastNode(?)#node", "Ground adjusted raycast node")
	v1:register(XMLValueType.FLOAT, v2 .. ".raycastNode(?)#distance", "Ground adjusted raycast distance", 4)
	v1:register(XMLValueType.INT, v2 .. ".raycastNode(?)#updateFrame", "Defines the frame delay between two raycasts", "Number of raycasts")
	v1:register(XMLValueType.FLOAT, v2 .. ".raycastNode(?)#yOffset", "Raycast Y translation offset (Raycast will start this distance above the node)", 0)
	GroundAdjustedNodes.registerAdjustNodeXMLPaths(v1, v2)
	GroundAdjustedNodes.registerAdjustNodeXMLPaths(v1, v2 .. ".adjustNode(?)")
	v1:addDelayedRegistrationFunc("AnimatedVehicle:part", function(p3, p4)
		p3:register(XMLValueType.FLOAT, p4 .. "#startGroundAdjustScale", "Start scale of ground adjusted node (blending between detected ground and inactive position)")
		p3:register(XMLValueType.FLOAT, p4 .. "#endGroundAdjustScale", "Start scale of ground adjusted node (blending between detected ground and inactive position)")
	end)
	v1:setXMLSpecializationType()
end
function GroundAdjustedNodes.registerAdjustNodeXMLPaths(p5, p6)
	p5:register(XMLValueType.NODE_INDEX, p6 .. "#node", "Ground adjusted node")
	p5:register(XMLValueType.FLOAT, p6 .. "#minY", "Min. Y translation", "translation in i3d - 1")
	p5:register(XMLValueType.FLOAT, p6 .. "#maxY", "Max. Y translation", "minY + 1")
	p5:register(XMLValueType.FLOAT, p6 .. "#moveSpeed", "Move speed", 1)
	p5:register(XMLValueType.BOOL, p6 .. "#resetIfNotActive", "Reset node to start translation if not active", true)
	p5:register(XMLValueType.FLOAT, p6 .. "#moveSpeedStateChange", "Move speed while node is inactive or active an in range of #activationTime", "#moveSpeed")
	p5:register(XMLValueType.FLOAT, p6 .. "#updateThreshold", "Position of node will be updated if change is greater than this value", 0.002)
	p5:register(XMLValueType.FLOAT, p6 .. "#inActiveOffsetY", "Offset of the in active position in Y, will be applied on top of the current position in i3d", 0)
	p5:register(XMLValueType.FLOAT, p6 .. "#inActiveY", "Adjust node will go to this state while it\'s not active", "Position in i3d file")
	p5:register(XMLValueType.BOOL, p6 .. "#averageInActivePosY", "While nodes are turned off the average Y position will be used as target for all nodes", false)
end
function GroundAdjustedNodes.registerFunctions(p7)
	SpecializationUtil.registerFunction(p7, "loadGroundAdjustedNodeFromXML", GroundAdjustedNodes.loadGroundAdjustedNodeFromXML)
	SpecializationUtil.registerFunction(p7, "loadGroundAdjustedAdjustNodeFromXML", GroundAdjustedNodes.loadGroundAdjustedAdjustNodeFromXML)
	SpecializationUtil.registerFunction(p7, "initGroundAdjustedAdjustNode", GroundAdjustedNodes.initGroundAdjustedAdjustNode)
	SpecializationUtil.registerFunction(p7, "loadGroundAdjustedRaycastNodeFromXML", GroundAdjustedNodes.loadGroundAdjustedRaycastNodeFromXML)
	SpecializationUtil.registerFunction(p7, "getIsGroundAdjustedNodeActive", GroundAdjustedNodes.getIsGroundAdjustedNodeActive)
	SpecializationUtil.registerFunction(p7, "updateGroundAdjustedRaycasts", GroundAdjustedNodes.updateGroundAdjustedRaycasts)
	SpecializationUtil.registerFunction(p7, "updateGroundAdjustedNode", GroundAdjustedNodes.updateGroundAdjustedNode)
end
function GroundAdjustedNodes.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", GroundAdjustedNodes)
	SpecializationUtil.registerEventListener(p8, "onLoadFinished", GroundAdjustedNodes)
	SpecializationUtil.registerEventListener(p8, "onUpdate", GroundAdjustedNodes)
	SpecializationUtil.registerEventListener(p8, "onRegisterAnimationValueTypes", GroundAdjustedNodes)
end
function GroundAdjustedNodes.onLoad(p_u_9, _)
	local v_u_10 = p_u_9.spec_groundAdjustedNodes
	v_u_10.raycastNodesByNode = {}
	v_u_10.maxUpdateDistance = p_u_9.xmlFile:getValue("vehicle.groundAdjustedNodes#maxUpdateDistance", 100)
	v_u_10.maxUpdateDistanceWobble = p_u_9.xmlFile:getValue("vehicle.groundAdjustedNodes#maxUpdateDistanceWobble", 50)
	v_u_10.adjustToWater = p_u_9.xmlFile:getValue("vehicle.groundAdjustedNodes#adjustToWater", false)
	v_u_10.onlyActiveWhileAttached = p_u_9.xmlFile:getValue("vehicle.groundAdjustedNodes#onlyActiveWhileAttached", true)
	v_u_10.groundAdjustedNodes = {}
	p_u_9.xmlFile:iterate("vehicle.groundAdjustedNodes.groundAdjustedNode", function(_, p11)
		-- upvalues: (copy) p_u_9, (copy) v_u_10
		local v12 = {}
		if p_u_9:loadGroundAdjustedNodeFromXML(p_u_9.xmlFile, p11, v12) then
			local v13 = v_u_10.groundAdjustedNodes
			table.insert(v13, v12)
		end
	end)
	if #v_u_10.groundAdjustedNodes == 0 then
		SpecializationUtil.removeEventListener(p_u_9, "onLoadFinished", GroundAdjustedNodes)
		SpecializationUtil.removeEventListener(p_u_9, "onUpdate", GroundAdjustedNodes)
		SpecializationUtil.removeEventListener(p_u_9, "onRegisterAnimationValueTypes", GroundAdjustedNodes)
	end
end
function GroundAdjustedNodes.onLoadFinished(p14, _)
	local v15 = p14.spec_groundAdjustedNodes
	for _, v16 in pairs(v15.groundAdjustedNodes) do
		v16.isActive = p14:getIsGroundAdjustedNodeActive(v16, true)
		if v16.isActive then
			for v17 = 1, #v16.adjustNodes do
				local v18 = v16.adjustNodes[v17]
				setTranslation(v18.node, v18.x, v18.curY, v18.z)
				if p14.setMovingToolDirty ~= nil then
					p14:setMovingToolDirty(v18.node)
				end
			end
		end
	end
end
function GroundAdjustedNodes.onUpdate(p19, p20, _, _, _)
	local v21 = p19.spec_groundAdjustedNodes
	if p19.currentUpdateDistance < v21.maxUpdateDistance then
		p19:updateGroundAdjustedRaycasts(p20)
		for _, v22 in pairs(v21.groundAdjustedNodes) do
			p19:updateGroundAdjustedNode(v22, p20)
		end
	end
end
function GroundAdjustedNodes.loadGroundAdjustedNodeFromXML(p_u_23, p_u_24, p_u_25, p_u_26)
	local v_u_27 = p_u_23.spec_groundAdjustedNodes
	p_u_26.yOffset = p_u_24:getValue(p_u_25 .. "#yOffset")
	p_u_26.activationTime = p_u_24:getValue(p_u_25 .. "#activationTime", 0) * 1000
	p_u_26.activationTimer = 0
	p_u_26.activeScale = 1
	p_u_26.adjustNodes = {}
	local v28 = {}
	if p_u_23:loadGroundAdjustedAdjustNodeFromXML(p_u_24, p_u_25, p_u_26, v28, false) then
		local v29 = p_u_26.adjustNodes
		table.insert(v29, v28)
	end
	p_u_24:iterate(p_u_25 .. ".adjustNode", function(_, p30)
		-- upvalues: (copy) p_u_23, (copy) p_u_24, (copy) p_u_26
		local v31 = {}
		if p_u_23:loadGroundAdjustedAdjustNodeFromXML(p_u_24, p30, p_u_26, v31, true) then
			local v32 = p_u_26.adjustNodes
			table.insert(v32, v31)
		end
	end)
	p_u_26.raycastNodes = {}
	p_u_24:iterate(p_u_25 .. ".raycastNode", function(_, p33)
		-- upvalues: (copy) p_u_23, (copy) p_u_24, (copy) p_u_26, (copy) p_u_25, (copy) v_u_27
		local v34 = p_u_23:loadGroundAdjustedRaycastNodeFromXML(p_u_24, p33, p_u_26, {})
		if v34 ~= nil then
			if #p_u_26.raycastNodes > 2 then
				Logging.xmlWarning(p_u_23.xmlFile, "Max. two raycast nodes are allowed per groundAdjustedNode! (%s)", p_u_25)
				return
			end
			local v35 = p_u_26.raycastNodes
			table.insert(v35, v34)
			v_u_27.raycastNodesByNode[v34.node] = v34
		end
	end)
	for v36 = 1, #p_u_26.adjustNodes do
		p_u_23:initGroundAdjustedAdjustNode(p_u_26, p_u_26.adjustNodes[v36])
	end
	if #p_u_26.raycastNodes > 0 and #p_u_26.adjustNodes > 0 then
		p_u_26.isActive = false
		return true
	else
		Logging.xmlWarning(p_u_23.xmlFile, "No raycastNodes or adjust nodes defined for groundAdjustedNode \'%s\'!", p_u_25)
		return false
	end
end
function GroundAdjustedNodes.loadGroundAdjustedRaycastNodeFromXML(p37, p38, p39, p40, p_u_41)
	XMLUtil.checkDeprecatedXMLElements(p38, p39 .. "#index", p39 .. "#node")
	local v42 = p38:getValue(p39 .. "#node", nil, p37.components, p37.i3dMappings)
	if v42 == nil then
		Logging.xmlWarning(p38, "Missing \'node\' for groundAdjustedNodes raycast \'%s\'!", p39)
		return false
	end
	p_u_41.node = v42
	p_u_41.maxDistance = p38:getValue(p39 .. "#distance", 4)
	p_u_41.lastRaycastDistance = p_u_41.maxDistance
	p_u_41.yOffset = p38:getValue(p39 .. "#yOffset", p40.yOffset or 0)
	local v43 = p37.spec_groundAdjustedNodes
	if v43.raycastNodesByNode[v42] == nil then
		function p_u_41.groundAdjustRaycastCallback(_, p44, _, _, _, p45)
			-- upvalues: (copy) p_u_41
			if getHasTrigger(p44) then
				return true
			end
			if p44 ~= 0 then
				p_u_41.lastRaycastDistance = p45
			end
			return false
		end
		p_u_41.parent = p40
		return p_u_41
	end
	local v46 = v43.raycastNodesByNode[v42]
	local v47 = p_u_41.yOffset - v46.yOffset
	if math.abs(v47) < 0.01 then
		local v48 = p_u_41.maxDistance - v46.maxDistance
		if math.abs(v48) < 0.01 then
			return v43.raycastNodesByNode[v42]
		end
	end
	Logging.xmlWarning(p38, "Found multiple groundAdjustedNode raycasts with different settings for \'%s\'!", getName(v42))
	return nil
end
function GroundAdjustedNodes.loadGroundAdjustedAdjustNodeFromXML(p49, p50, p51, _, p52, p53)
	local v54 = p50:getValue(p51 .. "#node", nil, p49.components, p49.i3dMappings)
	if v54 == nil then
		if p53 == true then
			Logging.xmlWarning(p50, "Missing \'node\' for groundAdjustedNode \'%s\'!", p51)
		end
		return false
	end
	local v55, v56, v57 = getTranslation(v54)
	p52.node = v54
	p52.x = v55
	p52.y = v56
	p52.z = v57
	p52.minY = p50:getValue(p51 .. "#minY", v56 - 1)
	p52.maxY = p50:getValue(p51 .. "#maxY", p52.minY + 1)
	p52.moveSpeed = p50:getValue(p51 .. "#moveSpeed", 1) / 1000
	p52.moveSpeedStateChange = p50:getValue(p51 .. "#moveSpeedStateChange", p52.moveSpeed * 1000) / 1000
	p52.resetIfNotActive = p50:getValue(p51 .. "#resetIfNotActive", true)
	p52.updateThreshold = p50:getValue(p51 .. "#updateThreshold", 0.002)
	p52.inActiveY = p50:getValue(p51 .. "#inActiveY", v56) + p50:getValue(p51 .. "#inActiveOffsetY", 0)
	p52.averageInActivePosY = p50:getValue(p51 .. "#averageInActivePosY", false)
	p52.targetY = p52.inActiveY
	p52.curY = p52.inActiveY
	p52.lastY = p52.inActiveY
	p52.lastOffsetDistance = math.random() * 10000
	return true
end
function GroundAdjustedNodes.initGroundAdjustedAdjustNode(_, p58, p59)
	if #p58.raycastNodes == 2 then
		local v60, _, v61 = localToLocal(p59.node, getParent(p58.raycastNodes[1].node), 0, 0, 0)
		local v62, _, v63 = localToLocal(p58.raycastNodes[1].node, getParent(p58.raycastNodes[1].node), 0, 0, 0)
		local v64, _, v65 = localToLocal(p58.raycastNodes[2].node, getParent(p58.raycastNodes[1].node), 0, 0, 0)
		local v66 = v64 - v62
		local v67 = v65 - v63
		local v68 = MathUtil.vector2Length(v64 - v62, v65 - v63)
		local v69, v70 = MathUtil.vector2Normalize(v66, v67)
		p59.alpha = MathUtil.getProjectOnLineParameter(v60, v61, v62, v63, v69, v70) / v68
	end
end
function GroundAdjustedNodes.updateGroundAdjustedRaycasts(p71, _)
	local v72 = p71.spec_groundAdjustedNodes
	for _, v73 in pairs(v72.raycastNodesByNode) do
		if v73.parent.isActive and v73.parent.activeScale > 0 then
			local v74, v75, v76 = localToWorld(v73.node, 0, v73.yOffset, 0)
			v73.lastIsOnField = getDensityAtWorldPos(g_currentMission.terrainDetailId, v74, 0, v76) ~= 0
			if v73.lastIsOnField and not v72.adjustToWater then
				local v77 = getTerrainHeightAtWorldPos(g_terrainNode, v74, 0, v76)
				if v77 - 10 < v75 then
					local v78 = v75 - v77
					local v79 = v73.maxDistance
					v73.lastRaycastDistance = math.min(v78, v79)
				end
			else
				local v80, v81, v82 = localDirectionToWorld(v73.node, 0, -1, 0)
				local v83 = GroundAdjustedNodes.COLLISION_MASK
				if v72.adjustToWater then
					v83 = GroundAdjustedNodes.COLLISION_MASK_WATER
				end
				raycastAll(v74, v75, v76, v80, v81, v82, v73.maxDistance, "groundAdjustRaycastCallback", v73, v83)
			end
		end
	end
end
local v_u_84 = {
	["randomFrequency"] = 3.5,
	["persistence"] = 0,
	["numOctaves"] = 6,
	["randomSeed"] = 99,
	["maxOffset"] = 0.015
}
local v_u_85 = math.sin
function GroundAdjustedNodes.updateGroundAdjustedNode(p86, p87, p88)
	-- upvalues: (copy) v_u_85, (copy) v_u_84
	local v89 = p86.spec_groundAdjustedNodes
	local v90 = p87.isActive
	p87.isActive = p86:getIsGroundAdjustedNodeActive(p87)
	if p87.isActive then
		local v91 = p87.activationTimer - p88
		p87.activationTimer = math.max(v91, 0)
	else
		if p87.averageInActivePosY and v90 then
			local v92 = v89.groundAdjustedNodes
			local v93 = 0
			local v94 = 0
			for _, v95 in pairs(v92) do
				for v96 = 1, #v95.adjustNodes do
					local v97 = v95.adjustNodes[v96]
					if v97.averageInActivePosY then
						v93 = v93 + v97.curY
						v94 = v94 + 1
					end
				end
			end
			if v94 > 0 then
				p87.inActiveY = v93 / v94
				for _, v98 in pairs(v92) do
					for v99 = 1, #v98.adjustNodes do
						local v100 = v98.adjustNodes[v99]
						if v100.averageInActivePosY then
							v100.inActiveY = v93 / v94
						end
					end
				end
			end
		end
		p87.activationTimer = p87.activationTime
	end
	for v101 = 1, #p87.adjustNodes do
		local v102 = p87.adjustNodes[v101]
		if p87.isActive and p87.activeScale > 0 then
			if not v90 then
				local _, v103, _ = getTranslation(v102.node)
				v102.curY = v103
			end
			local v104 = p87.raycastNodes[1]
			local v105
			if #p87.raycastNodes == 2 then
				v105 = p87.raycastNodes[1].lastRaycastDistance * (1 - v102.alpha) + p87.raycastNodes[2].lastRaycastDistance * v102.alpha
			else
				v105 = p87.raycastNodes[1].lastRaycastDistance
			end
			local _, v106, _ = localToLocal(v104.node, getParent(v102.node), 0, v104.yOffset - v105, 0)
			if p86.currentUpdateDistance < v89.maxUpdateDistanceWobble and v104.lastIsOnField then
				v102.lastOffsetDistance = v102.lastOffsetDistance + p86.lastMovedDistance * p86.movingDirection * 0.1
				local v107 = v102.lastOffsetDistance
				v106 = v106 + (v_u_85(v107 * 15.7079) * 0.4 + v_u_85(v107 * 41.46902) * 0.4 + v_u_85(v107 * 62.83185) * 0.3) * v_u_84.maxOffset
			end
			local v108 = v102.minY
			local v109 = v102.maxY
			v102.targetY = math.clamp(v106, v108, v109)
		elseif v102.resetIfNotActive then
			v102.targetY = v102.inActiveY
		end
		v102.targetY = v102.targetY * p87.activeScale + v102.inActiveY * (1 - p87.activeScale)
		if v102.targetY ~= v102.curY then
			local v110 = (not p87.isActive or p87.activationTimer > 0) and v102.moveSpeedStateChange or v102.moveSpeed
			if v102.targetY > v102.curY then
				local v111 = v102.curY + v110 * p88
				local v112 = v102.targetY
				v102.curY = math.min(v111, v112)
			else
				local v113 = v102.curY - v110 * p88
				local v114 = v102.targetY
				v102.curY = math.max(v113, v114)
			end
			local v115 = v102.lastY - v102.curY
			if math.abs(v115) > v102.updateThreshold then
				setTranslation(v102.node, v102.x, v102.curY, v102.z)
				v102.lastY = v102.curY
				if p86.setMovingToolDirty ~= nil then
					p86:setMovingToolDirty(v102.node)
				end
			end
		end
	end
end
function GroundAdjustedNodes.getIsGroundAdjustedNodeActive(p116, _, p117)
	return not p116.spec_groundAdjustedNodes.onlyActiveWhileAttached or (p116.getAttacherVehicle == nil and true or (p116:getAttacherVehicle() ~= nil and true or p117))
end
function GroundAdjustedNodes.onRegisterAnimationValueTypes(p_u_118)
	p_u_118:registerAnimationValueType("groundAdjustScale", "startGroundAdjustScale", "endGroundAdjustScale", false, AnimationValueFloat, function(p119, p120, p121)
		p119.node = p120:getValue(p121 .. "#node", nil, p119.part.components, p119.part.i3dMappings)
		if p119.node == nil then
			return false
		end
		p119:setWarningInformation("node: " .. getName(p119.node))
		p119:addCompareParameters("node")
		return true
	end, function(p122)
		-- upvalues: (copy) p_u_118
		if p122.groundAdjustedNode == nil then
			local v123 = p_u_118.spec_groundAdjustedNodes
			for _, v124 in pairs(v123.groundAdjustedNodes) do
				for _, v125 in pairs(v124.adjustNodes) do
					if v125.node == p122.node then
						p122.groundAdjustedNode = v124
						break
					end
				end
				if p122.groundAdjustedNode ~= nil then
					break
				end
			end
			if p122.groundAdjustedNode == nil then
				Logging.xmlWarning(p122.xmlFile, "Could not find groundAdjustedNode for node \'%s\'!", getName(p122.node))
				return 0
			end
		end
		return p122.groundAdjustedNode.activeScale
	end, function(p126, p127)
		if p126.groundAdjustedNode ~= nil then
			p126.groundAdjustedNode.activeScale = p127
		end
	end)
end

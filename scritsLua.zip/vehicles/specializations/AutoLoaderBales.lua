AutoLoaderBales = {}
function AutoLoaderBales.prerequisitesPresent(_)
	return true
end
function AutoLoaderBales.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("AutoLoaderBales")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.autoLoaderBales.trigger#node", "Bale pickup trigger node")
	v1:register(XMLValueType.STRING, "vehicle.autoLoaderBales.baleTypes.baleType(?)#fillTypes", "List of supported fill types (if empty, all fill types are allowed)")
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoaderBales.baleTypes.baleType(?)#diameter", "Bale diameter", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoaderBales.baleTypes.baleType(?)#width", "Bale width", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoaderBales.baleTypes.baleType(?)#height", "Bale height", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoaderBales.baleTypes.baleType(?)#length", "Bale length", 0)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.autoLoaderBales.baleTypes.baleType(?).spawnPlace#node", "Node to spawn the bale")
	v1:register(XMLValueType.INT, "vehicle.autoLoaderBales.baleTypes.baleType(?).spawnPlace#numBales", "Number of bales that can be loaded", 1)
	v1:register(XMLValueType.VECTOR_3, "vehicle.autoLoaderBales.baleTypes.baleType(?).spawnPlace#offsetDirection", "Defines the axis in which the additional bales are moved", "0 1 0")
	v1:register(XMLValueType.BOOL, "vehicle.autoLoaderBales.baleTypes.baleType(?).spawnPlace#mountBale", "Defines if the bale is mounted or just moved to the position of the spawn node", true)
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	Bale.registerSavegameXMLPaths(v2, "vehicles.vehicle(?).autoLoaderBales.bale(?)")
end
function AutoLoaderBales.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "autoLoaderBalesTriggerCallback", AutoLoaderBales.autoLoaderBalesTriggerCallback)
	SpecializationUtil.registerFunction(p3, "getAutoLoadBaleTypeFromBale", AutoLoaderBales.getAutoLoadBaleTypeFromBale)
	SpecializationUtil.registerFunction(p3, "doAutoLoadBale", AutoLoaderBales.doAutoLoadBale)
	SpecializationUtil.registerFunction(p3, "getIsBaleAutoLoadable", AutoLoaderBales.getIsBaleAutoLoadable)
end
function AutoLoaderBales.registerOverwrittenFunctions(_) end
function AutoLoaderBales.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", AutoLoaderBales)
	SpecializationUtil.registerEventListener(p4, "onLoadFinished", AutoLoaderBales)
	SpecializationUtil.registerEventListener(p4, "onDelete", AutoLoaderBales)
	SpecializationUtil.registerEventListener(p4, "onUpdate", AutoLoaderBales)
end
function AutoLoaderBales.onLoad(p_u_5, _)
	local v_u_6 = p_u_5.spec_autoLoaderBales
	v_u_6.balesInTrigger = {}
	v_u_6.balePickupDelay = 0
	v_u_6.mountedBales = {}
	v_u_6.numMountedBales = 0
	v_u_6.loadedBaleType = nil
	if p_u_5.isServer then
		v_u_6.triggerId = p_u_5.xmlFile:getValue("vehicle.autoLoaderBales.trigger#node", nil, p_u_5.components, p_u_5.i3dMappings)
		if v_u_6.triggerId ~= nil then
			addTrigger(v_u_6.triggerId, "autoLoaderBalesTriggerCallback", p_u_5)
		end
		v_u_6.baleTypes = {}
		p_u_5.xmlFile:iterate("vehicle.autoLoaderBales.baleTypes.baleType", function(_, p7)
			-- upvalues: (copy) p_u_5, (copy) v_u_6
			local v8 = {
				["spawnNode"] = p_u_5.xmlFile:getValue(p7 .. ".spawnPlace#node", nil, p_u_5.components, p_u_5.i3dMappings)
			}
			if v8.spawnNode == nil then
				Logging.xmlWarning(p_u_5.xmlFile, "Missing spawn place node in \'%s\'", p7)
				return
			else
				v8.numBales = p_u_5.xmlFile:getValue(p7 .. ".spawnPlace#numBales", 1)
				v8.offsetDirection = p_u_5.xmlFile:getValue(p7 .. ".spawnPlace#offsetDirection", "0 1 0", true)
				v8.mountBale = p_u_5.xmlFile:getValue(p7 .. ".spawnPlace#mountBale", true)
				v8.diameter = MathUtil.round(p_u_5.xmlFile:getValue(p7 .. "#diameter", 0), 2)
				v8.width = MathUtil.round(p_u_5.xmlFile:getValue(p7 .. "#width", 0), 2)
				v8.height = MathUtil.round(p_u_5.xmlFile:getValue(p7 .. "#height", 0), 2)
				v8.length = MathUtil.round(p_u_5.xmlFile:getValue(p7 .. "#length", 0), 2)
				local v9 = p_u_5.xmlFile:getValue(p7 .. "#fillTypes")
				v8.fillTypes = g_fillTypeManager:getFillTypesByNames(v9, "Warning: \'" .. p_u_5.xmlFile:getFilename() .. "\' has invalid fillType \'%s\'.")
				if (v8.diameter == 0 or v8.width == 0) and (v8.width == 0 or (v8.height == 0 or v8.length == 0)) then
					Logging.xmlWarning(p_u_5.xmlFile, "Incomplete bale size defintion in \'%s\'", p7)
				else
					local v10 = v_u_6.baleTypes
					table.insert(v10, v8)
				end
			end
		end)
	end
end
function AutoLoaderBales.onLoadFinished(p_u_11, p_u_12)
	if p_u_12 ~= nil and not p_u_12.resetVehicles then
		p_u_12.xmlFile:iterate(p_u_12.key .. ".autoLoaderBales.bale", function(_, p13)
			-- upvalues: (copy) p_u_12, (copy) p_u_11
			local v14 = {}
			Bale.loadBaleAttributesFromXMLFile(v14, p_u_12.xmlFile, p13, p_u_12.resetVehicles)
			local v15 = Bale.new(p_u_11.isServer, p_u_11.isClient)
			if v15:loadFromConfigXML(v14.xmlFilename, 0, 0, 0, 0, 0, 0, v14.uniqueId) then
				v15:applyBaleAttributes(v14)
				local v16 = p_u_11:getAutoLoadBaleTypeFromBale(v15)
				if v16 ~= nil then
					p_u_11:doAutoLoadBale(v16, v15)
					return
				end
				v15:delete()
			end
		end)
	end
end
function AutoLoaderBales.onDelete(p17)
	local v18 = p17.spec_autoLoaderBales
	if v18.triggerId ~= nil then
		removeTrigger(v18.triggerId)
	end
	if v18.mountedBales ~= nil then
		for v19, _ in pairs(v18.mountedBales) do
			v19:removeDeleteListener(p17, AutoLoaderBales.onDeleteAutoLoaderBalesObject)
			v19:unmountKinematic()
			v19:setNeedsSaving(true)
			v18.mountedBales[v19] = nil
		end
	end
end
function AutoLoaderBales.saveToXMLFile(p20, p21, p22, _)
	local v23 = p20.spec_autoLoaderBales
	local v24 = 0
	for v25, _ in pairs(v23.mountedBales) do
		v25:saveToXMLFile(p21, (string.format("%s.bale(%d)", p22, v24)))
		v24 = v24 + 1
	end
end
function AutoLoaderBales.onUpdate(p26, _, _, _, _)
	local v27 = p26.spec_autoLoaderBales
	local v28 = v27.balePickupDelay - 1
	v27.balePickupDelay = math.max(v28, 0)
	if v27.balePickupDelay == 0 then
		local v29 = 0
		local v30 = nil
		local v31 = nil
		for v32, v33 in pairs(v27.balesInTrigger) do
			if v33 > 0 and p26:getIsBaleAutoLoadable(v32) then
				local v34 = p26:getAutoLoadBaleTypeFromBale(v32)
				if v34 ~= nil and v27.numMountedBales < v34.numBales then
					local _, v35, _ = getWorldTranslation(v32.nodeId)
					if v29 < v35 then
						v31 = v34
						v30 = v32
						v29 = v35
					end
				end
			end
		end
		if v30 ~= nil then
			p26:doAutoLoadBale(v31, v30)
			v27.balesInTrigger[v30] = nil
			v27.balePickupDelay = 10
		end
	end
end
function AutoLoaderBales.onDeleteAutoLoaderBalesObject(p36, p37)
	local v38 = p36.spec_autoLoaderBales
	if v38.mountedBales[p37] ~= nil then
		v38.mountedBales[p37] = nil
		v38.numMountedBales = v38.numMountedBales - 1
	end
	v38.balesInTrigger[p37] = nil
	if next(v38.mountedBales) == nil then
		v38.loadedBaleType = nil
	end
end
function AutoLoaderBales.onBaleDeleted(p39, p40)
	p39.spec_autoLoaderBales.balesInTrigger[p40] = nil
end
function AutoLoaderBales.autoLoaderBalesTriggerCallback(p41, _, p42, p43, _, _, _)
	if p42 == 0 then
		return
	else
		local v44 = g_currentMission:getNodeObject(p42)
		if v44 == nil then
			return
		elseif v44:isa(Bale) and (g_currentMission.accessHandler:canFarmAccess(p41:getActiveFarm(), v44) and v44:getAllowPickup()) then
			local v45 = p41.spec_autoLoaderBales
			if p43 then
				v45.balesInTrigger[v44] = (v45.balesInTrigger[v44] or 0) + 1
				if v45.balesInTrigger[v44] == 1 then
					v44:addDeleteListener(p41, AutoLoaderBales.onBaleDeleted)
					return
				end
			else
				v45.balesInTrigger[v44] = (v45.balesInTrigger[v44] or 0) - 1
				if v45.balesInTrigger[v44] <= 0 then
					v45.balesInTrigger[v44] = nil
					v44:removeDeleteListener(p41, AutoLoaderBales.onBaleDeleted)
				end
			end
		end
	end
end
function AutoLoaderBales.getAutoLoadBaleTypeFromBale(p46, p47)
	local v48 = p46.spec_autoLoaderBales
	local v49 = p47:getFillType()
	for v50 = 1, #v48.baleTypes do
		local v51 = v48.baleTypes[v50]
		if v48.loadedBaleType == nil or v51 == v48.loadedBaleType then
			local v52 = #v51.fillTypes == 0
			for v53 = 1, #v51.fillTypes do
				if v51.fillTypes[v53] == v49 then
					v52 = true
					break
				end
			end
			if v52 and p47:getBaleMatchesSize(v51.diameter, v51.width, v51.height, v51.length) then
				return v51
			end
		end
	end
	return nil
end
function AutoLoaderBales.doAutoLoadBale(p54, p55, p56)
	local v57 = p54.spec_autoLoaderBales
	if p55.mountBale then
		local v58, v59, v60
		if p56.isRoundbale then
			v58 = p55.offsetDirection[1] * v57.numMountedBales * p56.diameter
			v59 = p55.offsetDirection[2] * v57.numMountedBales * p56.diameter
			v60 = p55.offsetDirection[3] * v57.numMountedBales * p56.width
		else
			v58 = p55.offsetDirection[1] * v57.numMountedBales * p56.width
			v59 = p55.offsetDirection[2] * v57.numMountedBales * p56.height
			v60 = p55.offsetDirection[3] * v57.numMountedBales * p56.length
		end
		p56:mountKinematic(p54, p55.spawnNode, v58, v59, v60, 0, 0, 0)
		p56:setNeedsSaving(false)
		v57.mountedBales[p56] = true
		p56:addDeleteListener(p54, AutoLoaderBales.onDeleteAutoLoaderBalesObject)
		v57.loadedBaleType = p55
		v57.numMountedBales = v57.numMountedBales + 1
	else
		removeFromPhysics(p56.nodeId)
		setTranslation(p56.nodeId, getWorldTranslation(p55.spawnNode))
		setWorldRotation(p56.nodeId, getWorldRotation(p55.spawnNode))
		addToPhysics(p56.nodeId)
		local v61, v62, v63 = getLinearVelocity(p54:getParentComponent(p55.spawnNode))
		setLinearVelocity(p56.nodeId, v61, v62, v63)
	end
end
function AutoLoaderBales.getIsBaleAutoLoadable(_, p64)
	return p64.mountObject == nil
end

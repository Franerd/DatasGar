Mulcher = {}
Mulcher.AI_REQUIRED_GROUND_TYPES = {
	FieldGroundType.SOWN,
	FieldGroundType.DIRECT_SOWN,
	FieldGroundType.PLANTED,
	FieldGroundType.RIDGE_SOWN,
	FieldGroundType.HARVEST_READY,
	FieldGroundType.HARVEST_READY_OTHER,
	FieldGroundType.GRASS,
	FieldGroundType.GRASS_CUT
}
function Mulcher.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("mulcher", true, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Mulcher")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.mulcher.effects.effect(?)")
	v1:register(XMLValueType.INT, "vehicle.mulcher.effects.effect(?)#workAreaIndex", "Work area index", 1)
	v1:register(XMLValueType.INT, "vehicle.mulcher.effects.effect(?)#activeDirection", "If vehicle is driving into this direction the effect will be activated (0 = any direction)", 0)
	SoundManager.registerSampleXMLPaths(v1, "vehicle.mulcher.sounds", "idle(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.mulcher.sounds", "work(?)")
	v1:setXMLSpecializationType()
end
function Mulcher.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(WorkArea, p2)
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(GroundReference, p2)
	end
	return v3
end
function Mulcher.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "processMulcherArea", Mulcher.processMulcherArea)
end
function Mulcher.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", Mulcher.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDoGroundManipulation", Mulcher.getDoGroundManipulation)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDirtMultiplier", Mulcher.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", Mulcher.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAIImplementUseVineSegment", Mulcher.getAIImplementUseVineSegment)
end
function Mulcher.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onDelete", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onReadStream", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onDeactivate", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onStartWorkAreaProcessing", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onEndWorkAreaProcessing", Mulcher)
	SpecializationUtil.registerEventListener(p6, "onAIFieldCourseSettingsInitialized", Mulcher)
end
function Mulcher.onLoad(p7, _)
	if p7:getGroundReferenceNodeFromIndex(1) == nil then
		printWarning("Warning: No ground reference nodes in  " .. p7.configFileName)
	end
	local v8 = p7.spec_mulcher
	if p7.isClient then
		v8.samples = {}
		v8.samples.idle = g_soundManager:loadSamplesFromXML(p7.xmlFile, "vehicle.mulcher.sounds", "idle", p7.baseDirectory, p7.components, 0, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.samples.work = g_soundManager:loadSamplesFromXML(p7.xmlFile, "vehicle.mulcher.sounds", "work", p7.baseDirectory, p7.components, 0, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.isWorkSamplePlaying = false
		v8.isIdleSamplePlaying = false
	end
	v8.effects = {}
	v8.workAreaToEffects = {}
	local v9 = 0
	while true do
		local v10 = string.format("vehicle.mulcher.effects.effect(%d)", v9)
		if not p7.xmlFile:hasProperty(v10) then
			break
		end
		local v11 = g_effectManager:loadEffect(p7.xmlFile, v10, p7.components, p7, p7.i3dMappings)
		if v11 ~= nil then
			local v12 = {
				["effects"] = v11,
				["workAreaIndex"] = p7.xmlFile:getValue(v10 .. "#workAreaIndex", 1),
				["activeDirection"] = p7.xmlFile:getValue(v10 .. "#activeDirection", 0),
				["activeTime"] = -1,
				["activeTimeDuration"] = 250,
				["isActive"] = false,
				["isActiveSent"] = false
			}
			for _, v13 in ipairs(v11) do
				if v13:isa(CultivatorMotionPathEffect) then
					v13.autoTurnOffSpeed = (-1 / 0)
				end
			end
			local v14 = v8.effects
			table.insert(v14, v12)
		end
		v9 = v9 + 1
	end
	v8.effectFillType = FillType.WHEAT
	if p7.addAIGroundTypeRequirements ~= nil then
		p7:addAIGroundTypeRequirements(Mulcher.AI_REQUIRED_GROUND_TYPES)
		p7:clearAIFruitRequirements()
		for _, v15 in ipairs(g_fruitTypeManager:getFruitTypes()) do
			if v15.isCultivationAllowed then
				if v15.mulchedState > v15.cutState then
					p7:addAIFruitRequirement(v15.index, 2, v15.mulchedState - 1)
				else
					p7:addAIFruitRequirement(v15.index, 2, 15)
				end
			end
		end
		local v16 = g_currentMission.weedSystem
		if v16 ~= nil then
			local v17 = v16:getMulcherReplacements()
			if v17.custom ~= nil then
				for _, v18 in ipairs(v17.custom) do
					local v19 = v18.fruitType
					if v19.terrainDataPlaneId ~= nil then
						for v20, _ in pairs(v18.replacements) do
							p7:addAIFruitRequirement(v19.index, v20, v20)
						end
					end
				end
			end
		end
	end
	v8.isWorking = false
	v8.isWorkingIdle = false
	v8.lastWorkTime = (-1 / 0)
	v8.stoneLastState = 0
	v8.stoneWearMultiplierData = g_currentMission.stoneSystem:getWearMultiplierByType("MULCHER")
	v8.effectDirtyFlag = p7:getNextDirtyFlag()
	if not p7.isClient or #v8.effects == 0 then
		SpecializationUtil.removeEventListener(p7, "onUpdateTick", Mulcher)
	end
end
function Mulcher.onPostLoad(p21, _)
	local v22 = p21.spec_mulcher
	for v23 = #v22.effects, 1, -1 do
		local v24 = v22.effects[v23]
		local v25 = p21:getWorkAreaByIndex(v24.workAreaIndex)
		if v25 == nil then
			Logging.xmlWarning(p21.xmlFile, "Invalid workAreaIndex \'%d\' for effect \'vehicle.mulcher.effects.effect(%d)\'!", v24.workAreaIndex, v23)
			table.remove(v22.effects, v23)
		else
			if v22.workAreaToEffects[v25.index] == nil then
				v22.workAreaToEffects[v25.index] = {}
			end
			local v26 = v22.workAreaToEffects[v25.index]
			table.insert(v26, v24)
		end
	end
end
function Mulcher.onDelete(p27)
	local v28 = p27.spec_mulcher
	if v28.samples ~= nil then
		g_soundManager:deleteSamples(v28.samples.idle)
		g_soundManager:deleteSamples(v28.samples.work)
	end
	if v28.effects ~= nil then
		for _, v29 in ipairs(v28.effects) do
			g_effectManager:deleteEffects(v29.effects)
		end
	end
end
function Mulcher.onReadStream(p30, p31, _)
	local v32 = p30.spec_mulcher
	for _, v33 in ipairs(v32.effects) do
		if streamReadBool(p31) then
			g_effectManager:setEffectTypeInfo(v33.effects, v32.effectFillType)
			g_effectManager:startEffects(v33.effects)
		else
			g_effectManager:stopEffects(v33.effects)
		end
	end
end
function Mulcher.onWriteStream(p34, p35, _)
	local v36 = p34.spec_mulcher
	for _, v37 in ipairs(v36.effects) do
		streamWriteBool(p35, v37.isActive)
	end
end
function Mulcher.onReadUpdateStream(p38, p39, _, p40)
	if p40:getIsServer() then
		local v41 = p38.spec_mulcher
		if streamReadBool(p39) then
			for _, v42 in ipairs(v41.effects) do
				if streamReadBool(p39) then
					g_effectManager:setEffectTypeInfo(v42.effects, v41.effectFillType)
					g_effectManager:startEffects(v42.effects)
				else
					g_effectManager:stopEffects(v42.effects)
				end
			end
		end
	end
end
function Mulcher.onWriteUpdateStream(p43, p44, p45, p46)
	if not p45:getIsServer() then
		local v47 = p43.spec_mulcher
		if streamWriteBool(p44, bitAND(p46, v47.effectDirtyFlag) ~= 0) then
			for _, v48 in ipairs(v47.effects) do
				streamWriteBool(p44, v48.isActive)
			end
		end
	end
end
function Mulcher.onUpdateTick(p49, _, _, _, _)
	if p49.isServer then
		local v50 = p49.spec_mulcher
		for _, v51 in ipairs(v50.effects) do
			if v51.isActive and g_currentMission.time > v51.activeTime then
				v51.isActive = false
				p49:raiseDirtyFlags(v50.effectDirtyFlag)
				g_effectManager:stopEffects(v51.effects)
			end
		end
	end
end
function Mulcher.processMulcherArea(p52, p53, _)
	local v54 = p52.spec_mulcher
	v54.isWorkingIdle = p52:getLastSpeed() > 0.5
	local v55, _, v56 = getWorldTranslation(p53.start)
	local v57, _, v58 = getWorldTranslation(p53.width)
	local v59, _, v60 = getWorldTranslation(p53.height)
	local v61, v62 = FSDensityMapUtil.updateMulcherArea(v55, v56, v57, v58, v59, v60)
	if v61 > 0 and v54.isWorkingIdle then
		local v63 = v54.workAreaToEffects[p53.index]
		if v63 ~= nil then
			for _, v64 in ipairs(v63) do
				if v64.activeDirection == 0 or p52.movingDirection == v64.activeDirection then
					v64.activeTime = g_currentMission.time + v64.activeTimeDuration
					if not v64.isActive then
						g_effectManager:setEffectTypeInfo(v64.effects, v54.effectFillType)
						g_effectManager:startEffects(v64.effects)
						v64.isActive = true
						p52:raiseDirtyFlags(v54.effectDirtyFlag)
					end
				end
			end
		end
		v54.lastWorkTime = g_time
	end
	FSDensityMapUtil.eraseTireTrack(v55, v56, v57, v58, v59, v60)
	v54.isWorking = g_time - v54.lastWorkTime < 500
	if v54.isWorking then
		v54.stoneLastState = FSDensityMapUtil.getStoneArea(v55, v56, v57, v58, v59, v60)
		return v61, v62
	else
		v54.stoneLastState = 0
		return v61, v62
	end
end
function Mulcher.doCheckSpeedLimit(p65, p66)
	return p66(p65) or p65:getIsImplementChainLowered()
end
function Mulcher.getDoGroundManipulation(p67, p68)
	if p67.spec_mulcher.isWorking then
		return p68(p67)
	else
		return false
	end
end
function Mulcher.getDirtMultiplier(p69, p70)
	local v71 = p69.spec_mulcher
	local v72 = p70(p69)
	if v71.isWorking then
		v72 = v72 + p69:getWorkDirtMultiplier() * p69:getLastSpeed() / v71.speedLimit
	end
	return v72
end
function Mulcher.getWearMultiplier(p73, p74)
	local v75 = p73.spec_mulcher
	local v76 = p74(p73)
	if v75.isWorking then
		local v77 = (v75.stoneLastState == 0 or v75.stoneWearMultiplierData == nil) and 1 or (v75.stoneWearMultiplierData[v75.stoneLastState] or 1)
		v76 = v76 + p73:getWorkWearMultiplier() * p73:getLastSpeed() / v75.speedLimit * v77
	end
	return v76
end
function Mulcher.getAIImplementUseVineSegment(p78, _, p79, p80, p81)
	local v82, v83, v84, v85, v86, v87 = p79:getSegmentSideArea(p80, p81)
	local v88, v89 = AIVehicleUtil.getAIAreaOfVehicle(p78, v82, v83, v84, v85, v86, v87)
	if v89 > 0 then
		return v88 / v89 > 0.01
	else
		return false
	end
end
function Mulcher.loadWorkAreaFromXML(p90, p91, p92, p93, p94)
	local v95 = p91(p90, p92, p93, p94)
	if p92.type == WorkAreaType.DEFAULT then
		p92.type = WorkAreaType.MULCHER
	end
	return v95
end
function Mulcher.onDeactivate(p96)
	local v97 = p96.spec_mulcher
	if p96.isClient then
		g_soundManager:stopSamples(v97.samples.idle)
		g_soundManager:stopSamples(v97.samples.work)
		v97.isWorkSamplePlaying = false
		v97.isIdleSamplePlaying = false
	end
	for _, v98 in ipairs(v97.effects) do
		g_effectManager:stopEffects(v98.effects)
	end
end
function Mulcher.onStartWorkAreaProcessing(p99, _)
	local v100 = p99.spec_mulcher
	v100.isWorking = false
	v100.isWorkingIdle = false
end
function Mulcher.onEndWorkAreaProcessing(p101, _)
	local v102 = p101.spec_mulcher
	if p101.isClient then
		if v102.isWorking then
			if not v102.isWorkSamplePlaying then
				g_soundManager:playSamples(v102.samples.work)
				v102.isWorkSamplePlaying = true
			end
		elseif v102.isWorkSamplePlaying then
			g_soundManager:stopSamples(v102.samples.work)
			v102.isWorkSamplePlaying = false
		end
		if v102.isWorkingIdle then
			if not v102.isIdleSamplePlaying then
				g_soundManager:playSamples(v102.samples.idle)
				v102.isIdleSamplePlaying = true
				return
			end
		elseif v102.isIdleSamplePlaying then
			g_soundManager:stopSamples(v102.samples.idle)
			v102.isIdleSamplePlaying = false
		end
	end
end
function Mulcher.onAIFieldCourseSettingsInitialized(_, p103)
	p103.headlandsFirst = true
	p103.workInitialSegment = true
end
function Mulcher.getDefaultSpeedLimit()
	return 15
end

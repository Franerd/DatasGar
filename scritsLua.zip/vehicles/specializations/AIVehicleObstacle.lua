AIVehicleObstacle = {}
function AIVehicleObstacle.prerequisitesPresent(_)
	return true
end
function AIVehicleObstacle.registerFunctions(p1)
	SpecializationUtil.registerFunction(p1, "createAIVehicleObstacle", AIVehicleObstacle.createAIVehicleObstacle)
	SpecializationUtil.registerFunction(p1, "removeAIVehicleObstacle", AIVehicleObstacle.removeAIVehicleObstacle)
	SpecializationUtil.registerFunction(p1, "updateAIVehicleObstacleState", AIVehicleObstacle.updateAIVehicleObstacleState)
	SpecializationUtil.registerFunction(p1, "getCanHaveAIVehicleObstacle", AIVehicleObstacle.getCanHaveAIVehicleObstacle)
	SpecializationUtil.registerFunction(p1, "getNeedAIVehicleObstacle", AIVehicleObstacle.getNeedAIVehicleObstacle)
	SpecializationUtil.registerFunction(p1, "getAIVehicleObstacleMaxBrakeAcceleration", AIVehicleObstacle.getAIVehicleObstacleMaxBrakeAcceleration)
	SpecializationUtil.registerFunction(p1, "setAIVehicleObstacleStateDirty", AIVehicleObstacle.setAIVehicleObstacleStateDirty)
	SpecializationUtil.registerFunction(p1, "getAIVehicleObstacleIsPassable", AIVehicleObstacle.getAIVehicleObstacleIsPassable)
end
function AIVehicleObstacle.registerOverwrittenFunctions(p2)
	SpecializationUtil.registerOverwrittenFunction(p2, "addToPhysics", AIVehicleObstacle.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p2, "removeFromPhysics", AIVehicleObstacle.removeFromPhysics)
end
function AIVehicleObstacle.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", AIVehicleObstacle)
	SpecializationUtil.registerEventListener(p3, "onDelete", AIVehicleObstacle)
	SpecializationUtil.registerEventListener(p3, "onUpdate", AIVehicleObstacle)
	SpecializationUtil.registerEventListener(p3, "onEnterVehicle", AIVehicleObstacle)
	SpecializationUtil.registerEventListener(p3, "onLeaveVehicle", AIVehicleObstacle)
end
function AIVehicleObstacle.onLoad(p4, _)
	p4.spec_aiVehicleObstacle.needsUpdate = false
end
function AIVehicleObstacle.onDelete(p5)
	p5:removeAIVehicleObstacle()
end
function AIVehicleObstacle.onUpdate(p6, _, _, _, _)
	local v7 = p6.spec_aiVehicleObstacle
	if p6.isServer and v7.needsUpdate then
		p6:updateAIVehicleObstacleState()
		v7.needsUpdate = false
	end
end
function AIVehicleObstacle.createAIVehicleObstacle(p8)
	if p8.isAddedToPhysics then
		local v9 = p8:getAIVehicleObstacleMaxBrakeAcceleration()
		for _, v10 in ipairs(p8.components) do
			if v10.obstacleId == nil then
				g_currentMission.aiSystem:addObstacle(v10.node, 0, 0, 0, 0, 0, 0, v9)
				v10.obstacleId = v10.node
			end
			g_currentMission.aiSystem:setObstacleIsPassable(v10.node, p8:getAIVehicleObstacleIsPassable())
		end
	end
end
function AIVehicleObstacle.removeAIVehicleObstacle(p11)
	if p11.components ~= nil then
		for _, v12 in ipairs(p11.components) do
			if v12.obstacleId ~= nil then
				g_currentMission.aiSystem:removeObstacle(v12.node)
				v12.obstacleId = nil
			end
		end
	end
end
function AIVehicleObstacle.updateAIVehicleObstacleState(p13)
	if p13.isServer then
		if p13:getCanHaveAIVehicleObstacle() then
			if p13:getNeedAIVehicleObstacle() then
				p13:createAIVehicleObstacle()
				return
			end
		else
			p13:removeAIVehicleObstacle()
		end
	end
end
function AIVehicleObstacle.setAIVehicleObstacleStateDirty(p14)
	p14.spec_aiVehicleObstacle.needsUpdate = true
	p14:raiseActive()
end
function AIVehicleObstacle.getCanHaveAIVehicleObstacle(p15)
	if p15.isAddedToPhysics then
		if p15.propertyState == VehiclePropertyState.SHOP_CONFIG then
			return false
		else
			return (p15.rootVehicle == p15 or (p15.rootVehicle.getCanHaveAIVehicleObstacle == nil or p15.rootVehicle:getCanHaveAIVehicleObstacle())) and true or false
		end
	else
		return false
	end
end
function AIVehicleObstacle.getNeedAIVehicleObstacle(_)
	return true
end
function AIVehicleObstacle.getAIVehicleObstacleIsPassable(p16)
	return p16.getIsControlled == nil and true or not p16:getIsControlled()
end
function AIVehicleObstacle.getAIVehicleObstacleMaxBrakeAcceleration(_)
	return 5
end
function AIVehicleObstacle.onEnterVehicle(p17, _)
	p17:setAIVehicleObstacleStateDirty()
end
function AIVehicleObstacle.onLeaveVehicle(p18)
	p18:setAIVehicleObstacleStateDirty()
end
function AIVehicleObstacle.addToPhysics(p19, p20)
	if not p20(p19) then
		return false
	end
	p19:setAIVehicleObstacleStateDirty()
	return true
end
function AIVehicleObstacle.removeFromPhysics(p21, p22)
	if not p22(p21) then
		return false
	end
	p21:setAIVehicleObstacleStateDirty()
	return true
end

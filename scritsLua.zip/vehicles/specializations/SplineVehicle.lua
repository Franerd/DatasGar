SplineVehicle = {}
function SplineVehicle.prerequisitesPresent(_)
	return true
end
function SplineVehicle.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("SplineVehicle")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.splineVehicle.dollies#frontNode", "Front node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.splineVehicle.dollies#backNode", "Back node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.splineVehicle.dollies#dolly1Node", "Front dolly node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.splineVehicle.dollies#dolly2Node", "Back dolly node")
	v1:register(XMLValueType.BOOL, "vehicle.splineVehicle.dollies#alignDollys", "Align dollies", true)
	v1:register(XMLValueType.BOOL, Dischargeable.DISCHARGE_NODE_XML_PATH .. "#needsIsEntered", "Vehicle needs to be entered to do raycasting", true)
	v1:register(XMLValueType.BOOL, Dischargeable.DISCHARGE_NODE_CONFIG_XML_PATH .. "#needsIsEntered", "Vehicle needs to be entered to do raycasting", true)
	v1:setXMLSpecializationType()
end
function SplineVehicle.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "getFrontToBackDistance", SplineVehicle.getFrontToBackDistance)
	SpecializationUtil.registerFunction(p2, "getSplineTimeFromDistance", SplineVehicle.getSplineTimeFromDistance)
	SpecializationUtil.registerFunction(p2, "getSplinePositionAndTimeFromDistance", SplineVehicle.getSplinePositionAndTimeFromDistance)
	SpecializationUtil.registerFunction(p2, "alignToSplineTime", SplineVehicle.alignToSplineTime)
	SpecializationUtil.registerFunction(p2, "getCurrentSplinePosition", SplineVehicle.getCurrentSplinePosition)
end
function SplineVehicle.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "getLastSpeed", SplineVehicle.getLastSpeed)
	SpecializationUtil.registerOverwrittenFunction(p3, "setTrainSystem", SplineVehicle.setTrainSystem)
	SpecializationUtil.registerOverwrittenFunction(p3, "getCurrentSurfaceSound", SplineVehicle.getCurrentSurfaceSound)
	SpecializationUtil.registerOverwrittenFunction(p3, "getAreSurfaceSoundsActive", SplineVehicle.getAreSurfaceSoundsActive)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsDischargeNodeActive", SplineVehicle.getIsDischargeNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p3, "loadDischargeNode", SplineVehicle.loadDischargeNode)
end
function SplineVehicle.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", SplineVehicle)
	SpecializationUtil.registerEventListener(p4, "onUpdate", SplineVehicle)
end
function SplineVehicle.onLoad(p5, _)
	local v6 = p5.spec_splineVehicle
	v6.frontNode = p5.xmlFile:getValue("vehicle.splineVehicle.dollies#frontNode", nil, p5.components, p5.i3dMappings)
	v6.backNode = p5.xmlFile:getValue("vehicle.splineVehicle.dollies#backNode", nil, p5.components, p5.i3dMappings)
	v6.frontToBackDistance = calcDistanceFrom(v6.frontNode, v6.backNode)
	v6.dolly1Node = p5.xmlFile:getValue("vehicle.splineVehicle.dollies#dolly1Node", nil, p5.components, p5.i3dMappings)
	v6.dolly2Node = p5.xmlFile:getValue("vehicle.splineVehicle.dollies#dolly2Node", nil, p5.components, p5.i3dMappings)
	v6.dollyToDollyDistance = calcDistanceFrom(v6.dolly1Node, v6.dolly2Node)
	v6.rootNodeToBackDistance = calcDistanceFrom(v6.backNode, p5.rootNode)
	v6.rootNodeToFrontDistance = calcDistanceFrom(v6.frontNode, p5.rootNode)
	v6.alignDollys = p5.xmlFile:getValue("vehicle.splineVehicle.dollies#alignDollys", true)
	v6.splinePosition = 0
	v6.lastSplinePosition = 0
	v6.currentSplinePosition = 0
	v6.splinePositionSpeed = 0
	v6.splinePositionSpeedReal = 0
	v6.splineSpeed = 0
	v6.firstUpdate = true
end
function SplineVehicle.setTrainSystem(p7, p8, p9)
	p8(p7, p9)
	local v10 = p7.spec_splineVehicle
	v10.splineLength = p9:getSplineLength()
	v10.frontToBackSplineTime = v10.frontToBackDistance / v10.splineLength
	v10.dollyToDollySplineTime = v10.dollyToDollyDistance / v10.splineLength
	v10.rootNodeToBackSplineTime = v10.rootNodeToBackDistance / v10.splineLength
	v10.rootNodeToFrontSplineTime = v10.rootNodeToFrontDistance / v10.splineLength
end
function SplineVehicle.getCurrentSplinePosition(p11)
	return p11.spec_splineVehicle.splinePosition
end
function SplineVehicle.getFrontToBackDistance(p12)
	return p12.spec_splineVehicle.frontToBackDistance
end
function SplineVehicle.onUpdate(p13, _, _, _, _)
	if p13.isClient then
		local v14 = p13.spec_splineVehicle
		if v14.trainSystem ~= nil then
			v14.splinePositionSpeed = v14.splinePositionSpeed * 0.975 + v14.splinePositionSpeedReal * 0.025
		end
	end
end
function SplineVehicle.getSplineTimeFromDistance(p15, p16, p17, p18)
	if p15.trainSystem ~= nil then
		local v19 = p18 >= 0
		local _, _, _, v20 = getSplinePositionWithDistance(p15.trainSystem:getSpline(), p16, p17, v19, 0.01)
		return SplineUtil.getValidSplineTime(v20)
	end
end
function SplineVehicle.getSplinePositionAndTimeFromDistance(p21, p22, p23, p24)
	if p21.trainSystem ~= nil then
		local v25 = p24 >= 0
		local v26, v27, v28, v29 = getSplinePositionWithDistance(p21.trainSystem:getSpline(), p22, p23, v25, 0.01)
		return v26, v27, v28, SplineUtil.getValidSplineTime(v29)
	end
end
function SplineVehicle.alignToSplineTime(p30, p31, p32, p33)
	if p30.trainSystem ~= nil then
		local v34 = p30.spec_splineVehicle
		local v35 = p30.trainSystem:getLengthSplineTime()
		local v36 = math.max(v35, 0.25)
		local v37 = p33 - v34.splinePosition
		if v36 < math.abs(v37) then
			if v37 > 0 then
				v37 = v37 - 1
			else
				v37 = v37 + 1
			end
		end
		p30.movingDirection = 1
		if v37 < 0 then
			p30.movingDirection = -1
		end
		local v38, v39, v40, v41 = p30:getSplinePositionAndTimeFromDistance(p33, v34.rootNodeToFrontDistance, -1.2 * v34.rootNodeToFrontSplineTime)
		local v42, v43, v44 = localToWorld(getParent(p31), v38, v39, v40)
		local v45, v46, v47, v48 = p30:getSplinePositionAndTimeFromDistance(v41, v34.dollyToDollyDistance, -1.2 * v34.dollyToDollySplineTime)
		local v49, v50, v51 = localToWorld(getParent(p31), v45, v46, v47)
		setDirection(p30.rootNode, v42 - v49, v43 - v50, v44 - v51, 0, 1, 0)
		local v52, v53, v54, v55 = getWorldQuaternion(p30.rootNode)
		setWorldTranslation(p30.rootNode, v42, v43 + p32, v44)
		local v56 = p30.components[1].networkInterpolators
		v56.quaternion:setQuaternion(v52, v53, v54, v55)
		v56.position:setPosition(v42, v43 + p32, v44)
		if v34.alignDollys then
			local v57, v58, v59 = getSplineDirection(p31, v41)
			local v60, v61, v62 = getSplineDirection(p31, v48)
			local v63, v64, v65 = localDirectionToLocal(p31, getParent(v34.dolly1Node), v57, v58, v59)
			local v66, v67, v68 = localDirectionToLocal(p31, getParent(v34.dolly2Node), v60, v61, v62)
			setDirection(v34.dolly1Node, v63, v64, v65, 0, 1, 0)
			setDirection(v34.dolly2Node, v66, v67, v68, 0, 1, 0)
		end
		local v69 = g_physicsDt
		if g_server == nil then
			v69 = g_physicsDtUnclamped
		end
		v34.splinePositionSpeedReal = v37 * v34.trainSystem:getSplineLength() * (1000 / v69)
		if p30.isServer then
			v34.splinePositionSpeed = v34.splinePositionSpeedReal
		end
		v34.splinePosition = p33
		if v34.firstUpdate then
			v34.splinePositionSpeedReal = 0
			v34.splinePositionSpeed = 0
			v34.firstUpdate = false
		end
		return p30:getSplineTimeFromDistance(p33, v34.frontToBackDistance, -1.2 * v34.frontToBackSplineTime)
	end
end
function SplineVehicle.getLastSpeed(p70, _, _)
	local v71 = p70.spec_splineVehicle.splinePositionSpeed * 3.6
	return math.abs(v71)
end
function SplineVehicle.getCurrentSurfaceSound(p72)
	return p72.spec_wheels.surfaceNameToSound.railroad
end
function SplineVehicle.getAreSurfaceSoundsActive(p73, _)
	local v74 = p73.rootVehicle
	return (v74 == nil or v74 == p73) and true or v74:getAreSurfaceSoundsActive()
end
function SplineVehicle.loadDischargeNode(p75, p76, p77, p78, p79)
	if not p76(p75, p77, p78, p79) then
		return false
	end
	p79.needsIsEntered = p77:getValue(p78 .. "#needsIsEntered", true)
	return true
end
function SplineVehicle.getIsDischargeNodeActive(p80, p81, p82)
	if p82.needsIsEntered then
		local v83 = p80:getRootVehicle()
		if v83 ~= nil and (v83.getIsControlled ~= nil and not v83:getIsControlled()) then
			return false
		end
	end
	return p81(p80, p82)
end

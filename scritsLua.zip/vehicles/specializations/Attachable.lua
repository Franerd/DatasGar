Attachable = {}
Attachable.INPUT_ATTACHERJOINT_XML_KEY = "vehicle.attachable.inputAttacherJoints.inputAttacherJoint(?)"
Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY = "vehicle.attachable.inputAttacherJointConfigurations.inputAttacherJointConfiguration(?).inputAttacherJoint(?)"
Attachable.STEERING_AXLE_XML_KEY = "vehicle.attachable.steeringAxleAngleScale"
Attachable.STEERING_ANGLE_NODE_XML_KEY = "vehicle.attachable.steeringAngleNodes.steeringAngleNode(?)"
Attachable.LOWER_LINK_BALL_FILENAME = "data/shared/assets/lowerLinkBalls/lowerLinkBall%02d.i3d"
function Attachable.prerequisitesPresent(_)
	return true
end
function Attachable.registerEvents(p1)
	SpecializationUtil.registerEvent(p1, "onPreAttach")
	SpecializationUtil.registerEvent(p1, "onPostAttach")
	SpecializationUtil.registerEvent(p1, "onPreDetach")
	SpecializationUtil.registerEvent(p1, "onPostDetach")
	SpecializationUtil.registerEvent(p1, "onSetLowered")
	SpecializationUtil.registerEvent(p1, "onSetLoweredAll")
	SpecializationUtil.registerEvent(p1, "onLeaveRootVehicle")
end
function Attachable.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "loadInputAttacherJoint", Attachable.loadInputAttacherJoint)
	SpecializationUtil.registerFunction(p2, "loadAttacherJointHeightNode", Attachable.loadAttacherJointHeightNode)
	SpecializationUtil.registerFunction(p2, "getIsAttacherJointHeightNodeActive", Attachable.getIsAttacherJointHeightNodeActive)
	SpecializationUtil.registerFunction(p2, "getInputAttacherJointByJointDescIndex", Attachable.getInputAttacherJointByJointDescIndex)
	SpecializationUtil.registerFunction(p2, "getInputAttacherJointIndexByNode", Attachable.getInputAttacherJointIndexByNode)
	SpecializationUtil.registerFunction(p2, "getAttacherVehicle", Attachable.getAttacherVehicle)
	SpecializationUtil.registerFunction(p2, "getShowAttachableMapHotspot", Attachable.getShowAttachableMapHotspot)
	SpecializationUtil.registerFunction(p2, "getInputAttacherJoints", Attachable.getInputAttacherJoints)
	SpecializationUtil.registerFunction(p2, "getIsAttachedTo", Attachable.getIsAttachedTo)
	SpecializationUtil.registerFunction(p2, "getActiveInputAttacherJointDescIndex", Attachable.getActiveInputAttacherJointDescIndex)
	SpecializationUtil.registerFunction(p2, "getActiveInputAttacherJoint", Attachable.getActiveInputAttacherJoint)
	SpecializationUtil.registerFunction(p2, "getAllowsLowering", Attachable.getAllowsLowering)
	SpecializationUtil.registerFunction(p2, "loadSupportAnimationFromXML", Attachable.loadSupportAnimationFromXML)
	SpecializationUtil.registerFunction(p2, "getIsSupportAnimationAllowed", Attachable.getIsSupportAnimationAllowed)
	SpecializationUtil.registerFunction(p2, "getIsReadyToFinishDetachProcess", Attachable.getIsReadyToFinishDetachProcess)
	SpecializationUtil.registerFunction(p2, "startDetachProcess", Attachable.startDetachProcess)
	SpecializationUtil.registerFunction(p2, "getIsImplementChainLowered", Attachable.getIsImplementChainLowered)
	SpecializationUtil.registerFunction(p2, "getIsInWorkPosition", Attachable.getIsInWorkPosition)
	SpecializationUtil.registerFunction(p2, "getAttachbleAirConsumerUsage", Attachable.getAttachbleAirConsumerUsage)
	SpecializationUtil.registerFunction(p2, "isDetachAllowed", Attachable.isDetachAllowed)
	SpecializationUtil.registerFunction(p2, "isAttachAllowed", Attachable.isAttachAllowed)
	SpecializationUtil.registerFunction(p2, "getIsInputAttacherActive", Attachable.getIsInputAttacherActive)
	SpecializationUtil.registerFunction(p2, "getSteeringAxleBaseVehicle", Attachable.getSteeringAxleBaseVehicle)
	SpecializationUtil.registerFunction(p2, "loadSteeringAxleFromXML", Attachable.loadSteeringAxleFromXML)
	SpecializationUtil.registerFunction(p2, "getIsSteeringAxleAllowed", Attachable.getIsSteeringAxleAllowed)
	SpecializationUtil.registerFunction(p2, "loadSteeringAngleNodeFromXML", Attachable.loadSteeringAngleNodeFromXML)
	SpecializationUtil.registerFunction(p2, "updateSteeringAngleNode", Attachable.updateSteeringAngleNode)
	SpecializationUtil.registerFunction(p2, "attachableAddToolCameras", Attachable.attachableAddToolCameras)
	SpecializationUtil.registerFunction(p2, "attachableRemoveToolCameras", Attachable.attachableRemoveToolCameras)
	SpecializationUtil.registerFunction(p2, "preAttach", Attachable.preAttach)
	SpecializationUtil.registerFunction(p2, "postAttach", Attachable.postAttach)
	SpecializationUtil.registerFunction(p2, "preDetach", Attachable.preDetach)
	SpecializationUtil.registerFunction(p2, "postDetach", Attachable.postDetach)
	SpecializationUtil.registerFunction(p2, "setLowered", Attachable.setLowered)
	SpecializationUtil.registerFunction(p2, "setLoweredAll", Attachable.setLoweredAll)
	SpecializationUtil.registerFunction(p2, "setToolBottomArmWidthByIndex", Attachable.setToolBottomArmWidthByIndex)
	SpecializationUtil.registerFunction(p2, "updateInputAttacherJointGraphics", Attachable.updateInputAttacherJointGraphics)
	SpecializationUtil.registerFunction(p2, "setIsAdditionalAttachment", Attachable.setIsAdditionalAttachment)
	SpecializationUtil.registerFunction(p2, "getIsAdditionalAttachment", Attachable.getIsAdditionalAttachment)
	SpecializationUtil.registerFunction(p2, "setIsSupportVehicle", Attachable.setIsSupportVehicle)
	SpecializationUtil.registerFunction(p2, "getIsSupportVehicle", Attachable.getIsSupportVehicle)
	SpecializationUtil.registerFunction(p2, "registerLoweringActionEvent", Attachable.registerLoweringActionEvent)
	SpecializationUtil.registerFunction(p2, "getLoweringActionEventState", Attachable.getLoweringActionEventState)
	SpecializationUtil.registerFunction(p2, "getAllowMultipleAttachments", Attachable.getAllowMultipleAttachments)
	SpecializationUtil.registerFunction(p2, "resolveMultipleAttachments", Attachable.resolveMultipleAttachments)
	SpecializationUtil.registerFunction(p2, "getBlockFoliageDestruction", Attachable.getBlockFoliageDestruction)
	SpecializationUtil.registerFunction(p2, "setIsDetachingBlocked", Attachable.setIsDetachingBlocked)
end
function Attachable.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "findRootVehicle", Attachable.findRootVehicle)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsActive", Attachable.getIsActive)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsOperating", Attachable.getIsOperating)
	SpecializationUtil.registerOverwrittenFunction(p3, "getBrakeForce", Attachable.getBrakeForce)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsFoldAllowed", Attachable.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p3, "getCanToggleTurnedOn", Attachable.getCanToggleTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p3, "getCanImplementBeUsedForAI", Attachable.getCanImplementBeUsedForAI)
	SpecializationUtil.registerOverwrittenFunction(p3, "getCanAIImplementContinueWork", Attachable.getCanAIImplementContinueWork)
	SpecializationUtil.registerOverwrittenFunction(p3, "getAreControlledActionsAllowed", Attachable.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p3, "getDeactivateOnLeave", Attachable.getDeactivateOnLeave)
	SpecializationUtil.registerOverwrittenFunction(p3, "getActiveFarm", Attachable.getActiveFarm)
	SpecializationUtil.registerOverwrittenFunction(p3, "getCanBeSelected", Attachable.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsLowered", Attachable.getIsLowered)
	SpecializationUtil.registerOverwrittenFunction(p3, "mountDynamic", Attachable.mountDynamic)
	SpecializationUtil.registerOverwrittenFunction(p3, "getOwnerConnection", Attachable.getOwnerConnection)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsInUse", Attachable.getIsInUse)
	SpecializationUtil.registerOverwrittenFunction(p3, "getUpdatePriority", Attachable.getUpdatePriority)
	SpecializationUtil.registerOverwrittenFunction(p3, "getCanBeReset", Attachable.getCanBeReset)
	SpecializationUtil.registerOverwrittenFunction(p3, "loadAdditionalLightAttributesFromXML", Attachable.loadAdditionalLightAttributesFromXML)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsLightActive", Attachable.getIsLightActive)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsPowered", Attachable.getIsPowered)
	SpecializationUtil.registerOverwrittenFunction(p3, "getConnectionHoseConfigIndex", Attachable.getConnectionHoseConfigIndex)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsMapHotspotVisible", Attachable.getIsMapHotspotVisible)
	SpecializationUtil.registerOverwrittenFunction(p3, "getPowerTakeOffConfigIndex", Attachable.getPowerTakeOffConfigIndex)
	SpecializationUtil.registerOverwrittenFunction(p3, "loadDashboardGroupFromXML", Attachable.loadDashboardGroupFromXML)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsDashboardGroupActive", Attachable.getIsDashboardGroupActive)
	SpecializationUtil.registerOverwrittenFunction(p3, "setWorldPositionQuaternion", Attachable.setWorldPositionQuaternion)
	SpecializationUtil.registerOverwrittenFunction(p3, "addToPhysics", Attachable.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p3, "removeFromPhysics", Attachable.removeFromPhysics)
end
function Attachable.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", Attachable)
	SpecializationUtil.registerEventListener(p4, "onPostLoad", Attachable)
	SpecializationUtil.registerEventListener(p4, "onLoadFinished", Attachable)
	SpecializationUtil.registerEventListener(p4, "onPreInitComponentPlacement", Attachable)
	SpecializationUtil.registerEventListener(p4, "onPreDelete", Attachable)
	SpecializationUtil.registerEventListener(p4, "onDelete", Attachable)
	SpecializationUtil.registerEventListener(p4, "onReadStream", Attachable)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", Attachable)
	SpecializationUtil.registerEventListener(p4, "onUpdate", Attachable)
	SpecializationUtil.registerEventListener(p4, "onUpdateTick", Attachable)
	SpecializationUtil.registerEventListener(p4, "onDeactivate", Attachable)
	SpecializationUtil.registerEventListener(p4, "onSelect", Attachable)
	SpecializationUtil.registerEventListener(p4, "onUnselect", Attachable)
	SpecializationUtil.registerEventListener(p4, "onStateChange", Attachable)
	SpecializationUtil.registerEventListener(p4, "onRootVehicleChanged", Attachable)
	SpecializationUtil.registerEventListener(p4, "onFoldStateChanged", Attachable)
	SpecializationUtil.registerEventListener(p4, "onRegisterAnimationValueTypes", Attachable)
end
function Attachable.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("inputAttacherJoint", g_i18n:getText("configuration_inputAttacherJoint"), "attachable", VehicleConfigurationItem)
	local v5 = Vehicle.xmlSchema
	v5:setXMLSpecializationType("Attachable")
	Attachable.registerInputAttacherJointXMLPaths(v5, Attachable.INPUT_ATTACHERJOINT_XML_KEY)
	Attachable.registerInputAttacherJointXMLPaths(v5, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY)
	ObjectChangeUtil.registerObjectChangeXMLPaths(v5, Attachable.INPUT_ATTACHERJOINT_XML_KEY)
	ObjectChangeUtil.registerObjectChangeXMLPaths(v5, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY)
	Attachable.registerSupportXMLPaths(v5, "vehicle.attachable.inputAttacherJointConfigurations.inputAttacherJointConfiguration(?).support(?)")
	v5:register(XMLValueType.INT, "vehicle.attachable#connectionHoseConfigId", "Connection hose configuration index to use")
	v5:register(XMLValueType.INT, "vehicle.attachable#powerTakeOffConfigId", "Power take off configuration index to use")
	v5:register(XMLValueType.INT, "vehicle.attachable.inputAttacherJointConfigurations.inputAttacherJointConfiguration(?)#connectionHoseConfigId", "Connection hose configuration index to use")
	v5:register(XMLValueType.INT, "vehicle.attachable.inputAttacherJointConfigurations.inputAttacherJointConfiguration(?)#powerTakeOffConfigId", "Power take off configuration index to use")
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.brakeForce#force", "Brake force", 0)
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.brakeForce#maxForce", "Brake force when vehicle reached mass of #maxForceMass", 0)
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.brakeForce#maxForceMass", "When this mass is reached the vehicle will brake with #maxForce", 0)
	v5:register(XMLValueType.BOOL, "vehicle.attachable.brakeForce#includeAttachables", "Defines if the mass of the attached vehicles is included in the calculations", false)
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.brakeForce#loweredForce", "Brake force while the tool is lowered")
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.airConsumer#usage", "Air consumption while fully braking", 0)
	v5:register(XMLValueType.BOOL, "vehicle.attachable#allowFoldingWhileAttached", "Allow folding while attached", true)
	v5:register(XMLValueType.BOOL, "vehicle.attachable#allowFoldingWhileLowered", "Allow folding while lowered", true)
	v5:register(XMLValueType.BOOL, "vehicle.attachable#blockFoliageDestruction", "If active the vehicle will block the complete foliage destruction of the vehicle chain", false)
	v5:register(XMLValueType.BOOL, "vehicle.attachable.power#requiresExternalPower", "Tool requires external power from a vehicle with motor to work", true)
	v5:register(XMLValueType.L10N_STRING, "vehicle.attachable.power#attachToPowerWarning", "Warning to be displayed if no vehicle with motor is attached", "warning_attachToPower")
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.steeringAxleAngleScale#startSpeed", "Start speed", 10)
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.steeringAxleAngleScale#endSpeed", "End speed", 30)
	v5:register(XMLValueType.BOOL, "vehicle.attachable.steeringAxleAngleScale#backwards", "Is active backwards", false)
	v5:register(XMLValueType.ANGLE, "vehicle.attachable.steeringAxleAngleScale#speed", "Speed (Degrees per second)", 60)
	v5:register(XMLValueType.BOOL, "vehicle.attachable.steeringAxleAngleScale#useSuperAttachable", "Use super attachable", false)
	v5:register(XMLValueType.NODE_INDEX, "vehicle.attachable.steeringAxleAngleScale.targetNode#node", "Target node")
	v5:register(XMLValueType.ANGLE, "vehicle.attachable.steeringAxleAngleScale.targetNode#refAngle", "Reference angle to transfer from angle between vehicles to defined min. and max. rot for target node")
	v5:register(XMLValueType.ANGLE, "vehicle.attachable.steeringAxleAngleScale#minRot", "Min Rotation", 0)
	v5:register(XMLValueType.ANGLE, "vehicle.attachable.steeringAxleAngleScale#maxRot", "Max Rotation", 0)
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.steeringAxleAngleScale#direction", "Direction", 1)
	v5:register(XMLValueType.BOOL, "vehicle.attachable.steeringAxleAngleScale#forceUsage", "Force usage of steering axle, even if attacher vehicle does not have steering bar nodes", false)
	v5:register(XMLValueType.BOOL, "vehicle.attachable.steeringAxleAngleScale#speedDependent", "Steering axle angle is scaled based on speed with #startSpeed and #endSpeed", true)
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.steeringAxleAngleScale#distanceDelay", "The steering angle is updated delayed after vehicle has been moved this distance", 0)
	v5:register(XMLValueType.INT, "vehicle.attachable.steeringAxleAngleScale#referenceComponentIndex", "If defined the given component is used for steering angle reference. Y between root component and this component will result in steering angle.")
	v5:register(XMLValueType.NODE_INDEX, Attachable.STEERING_ANGLE_NODE_XML_KEY .. "#node", "Steering angle node")
	v5:register(XMLValueType.ANGLE, Attachable.STEERING_ANGLE_NODE_XML_KEY .. "#speed", "Change speed (degree per second)", 25)
	v5:register(XMLValueType.FLOAT, Attachable.STEERING_ANGLE_NODE_XML_KEY .. "#scale", "Scale of vehicle to vehicle angle that is applied", 1)
	v5:register(XMLValueType.ANGLE, Attachable.STEERING_ANGLE_NODE_XML_KEY .. "#offset", "Angle offset", 0)
	v5:register(XMLValueType.FLOAT, Attachable.STEERING_ANGLE_NODE_XML_KEY .. "#minSpeed", "Min. speed of vehicle to update", 0)
	Attachable.registerSupportXMLPaths(v5, "vehicle.attachable.support(?)")
	v5:register(XMLValueType.STRING, "vehicle.attachable.lowerAnimation#name", "Animation name")
	v5:register(XMLValueType.FLOAT, "vehicle.attachable.lowerAnimation#speed", "Animation speed", 1)
	v5:register(XMLValueType.INT, "vehicle.attachable.lowerAnimation#directionOnDetach", "Direction on detach", 0)
	v5:register(XMLValueType.BOOL, "vehicle.attachable.lowerAnimation#defaultLowered", "Is default lowered", false)
	VehicleCamera.registerCameraXMLPaths(v5, "vehicle.attachable.toolCameras.toolCamera(?)")
	SoundManager.registerSampleXMLPaths(v5, "vehicle.attachable.sounds", "active(?)")
	for v6 = 1, #Lights.ADDITIONAL_LIGHT_ATTRIBUTES_KEYS do
		local v7 = Lights.ADDITIONAL_LIGHT_ATTRIBUTES_KEYS[v6]
		v5:register(XMLValueType.INT, v7 .. "#inputAttacherJointIndex", "Index of input attacher joint that needs to be active to activate light")
	end
	v5:register(XMLValueType.BOOL, Dashboard.GROUP_XML_KEY .. "#isAttached", "Tool is attached")
	v5:addDelayedRegistrationFunc("AnimatedVehicle:part", function(p8, p9)
		p8:register(XMLValueType.INT, p9 .. "#inputAttacherJointIndex", "Input Attacher Joint Index [1..n]")
		p8:register(XMLValueType.VECTOR_3, p9 .. "#lowerRotLimitScaleStart", "Lower rotation limit start")
		p8:register(XMLValueType.VECTOR_3, p9 .. "#lowerRotLimitScaleEnd", "Lower rotation limit end")
		p8:register(XMLValueType.VECTOR_3, p9 .. "#upperRotLimitScaleStart", "Upper rotation limit start")
		p8:register(XMLValueType.VECTOR_3, p9 .. "#upperRotLimitScaleEnd", "Upper rotation limit end")
		p8:register(XMLValueType.VECTOR_3, p9 .. "#lowerTransLimitScaleStart", "Lower translation limit start")
		p8:register(XMLValueType.VECTOR_3, p9 .. "#lowerTransLimitScaleEnd", "Lower translation limit end")
		p8:register(XMLValueType.VECTOR_3, p9 .. "#upperTransLimitScaleStart", "Upper translation limit start")
		p8:register(XMLValueType.VECTOR_3, p9 .. "#upperTransLimitScaleEnd", "Upper translation limit end")
		p8:register(XMLValueType.ANGLE, p9 .. "#lowerRotationOffsetStart", "Lower rotation offset start")
		p8:register(XMLValueType.ANGLE, p9 .. "#lowerRotationOffsetEnd", "Lower rotation offset end")
		p8:register(XMLValueType.ANGLE, p9 .. "#upperRotationOffsetStart", "Upper rotation offset start")
		p8:register(XMLValueType.ANGLE, p9 .. "#upperRotationOffsetEnd", "Upper rotation offset end")
		p8:register(XMLValueType.FLOAT, p9 .. "#lowerDistanceToGroundStart", "Lower distance to ground start")
		p8:register(XMLValueType.FLOAT, p9 .. "#lowerDistanceToGroundEnd", "Lower distance to ground end")
		p8:register(XMLValueType.FLOAT, p9 .. "#upperDistanceToGroundStart", "Upper distance to ground start")
		p8:register(XMLValueType.FLOAT, p9 .. "#upperDistanceToGroundEnd", "Upper distance to ground end")
	end)
	v5:setXMLSpecializationType()
	local v10 = Vehicle.xmlSchemaSavegame
	v10:register(XMLValueType.FLOAT, "vehicles.vehicle(?).attachable#lowerAnimTime", "Lower animation time")
	v10:register(XMLValueType.BOOL, "vehicles.vehicle(?).attachable#isDetachingBlocked", "If detaching is blocked")
end
function Attachable.registerInputAttacherJointXMLPaths(p11, p12)
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#node", "Joint Node")
	p11:register(XMLValueType.NODE_INDEX, p12 .. ".heightNode(?)#node", "Height Node")
	p11:register(XMLValueType.STRING, p12 .. "#jointType", "Joint type")
	p11:register(XMLValueType.STRING, p12 .. ".subType#name", "If defined this type needs to match with the sub type in the attacher vehicle")
	p11:register(XMLValueType.BOOL, p12 .. ".subType#showWarning", "Show warning if user tries to attach with a different sub type", true)
	p11:register(XMLValueType.BOOL, p12 .. "#needsTrailerJoint", "Needs trailer joint (only if no joint type is given)", false)
	p11:register(XMLValueType.BOOL, p12 .. "#needsLowJoint", "Needs low trailer joint (only if no joint type is given)", false)
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#topReferenceNode", "Top Reference Node")
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#rootNode", "Root node", "Parent component of attacher joint node")
	p11:register(XMLValueType.BOOL, p12 .. "#allowsDetaching", "Allows detaching", true)
	p11:register(XMLValueType.BOOL, p12 .. "#fixedRotation", "Fixed rotation (Rot limit is freezed)", false)
	p11:register(XMLValueType.BOOL, p12 .. "#hardAttach", "Implement is hard attached", false)
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#nodeVisual", "Visual joint node")
	p11:register(XMLValueType.FLOAT, p12 .. ".distanceToGround#lower", "Lower distance to ground")
	p11:register(XMLValueType.FLOAT, p12 .. ".distanceToGround#upper", "Upper distance to ground")
	p11:register(XMLValueType.STRING, p12 .. ".distanceToGround.vehicle(?)#filename", "Vehicle filename to activate these distances")
	p11:register(XMLValueType.FLOAT, p12 .. ".distanceToGround.vehicle(?)#lower", "Lower distance to ground while attached to this vehicle")
	p11:register(XMLValueType.FLOAT, p12 .. ".distanceToGround.vehicle(?)#upper", "Upper distance to ground while attached to this vehicle")
	p11:register(XMLValueType.ANGLE, p12 .. "#lowerRotationOffset", "Rotation offset if lowered")
	p11:register(XMLValueType.ANGLE, p12 .. "#upperRotationOffset", "Rotation offset if lifted", "8 degrees for implements")
	p11:register(XMLValueType.BOOL, p12 .. "#allowsJointRotLimitMovement", "Rotation limit is changed during lifting/lowering", true)
	p11:register(XMLValueType.BOOL, p12 .. "#allowsJointTransLimitMovement", "Translation limit is changed during lifting/lowering", true)
	p11:register(XMLValueType.BOOL, p12 .. "#needsToolbar", "Needs toolbar", false)
	p11:register(XMLValueType.VECTOR_N, p12 .. ".bottomArm#categories", "Bottom arm categories (0-4). Defines the width of the lower links and the ball size. Can be multiple categories separated by a whitespace if the tool support more than one.")
	p11:register(XMLValueType.VECTOR_N, p12 .. ".bottomArm#widths", "Manual definition of the available lower link widths. Overwrites the category definition. Multiple width values separated by a whitespace.")
	p11:register(XMLValueType.INT, p12 .. ".bottomArm#ballType", "Ball type to load (1: regular ball, 2: ball with guide cone)", 1)
	p11:register(XMLValueType.STRING, p12 .. ".bottomArm#ballFilename", "Path to custom ball i3d file to use")
	p11:register(XMLValueType.BOOL, p12 .. ".bottomArm#ballDefaultVisibility", "Defines if the balls are also visible while the tool is not attached", "\'true\' if no toolbar is used (\'needsToolbar\' attribute)")
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#steeringBarLeftNode", "Left steering bar node (Node of movingPart that should point towards the steeringBar left node of the tractor)")
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#steeringBarRightNode", "Right steering bar node (Node of movingPart that should point towards the steeringBar right node of the tractor)")
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#drawbarNode", "Drawbar node (Node of movingPart that should point towards the attacherJoint node of the tractor)")
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#bottomArmLeftNode", "Left bottom arm node (Node can be used as movingTool target from the tractor)")
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#bottomArmRightNode", "Right bottom arm node (Node can be used as movingTool target from the tractor)")
	p11:register(XMLValueType.VECTOR_3, p12 .. "#upperRotLimitScale", "Upper rot limit scale", "0 0 0")
	p11:register(XMLValueType.VECTOR_3, p12 .. "#lowerRotLimitScale", "Lower rot limit scale", "0 0 0")
	p11:register(XMLValueType.FLOAT, p12 .. "#rotLimitThreshold", "Defines when the transition from upper to lower rot limit starts (0: directly, 0.9: after 90% of lowering)", 0)
	p11:register(XMLValueType.VECTOR_3, p12 .. "#upperTransLimitScale", "Upper trans limit scale", "0 0 0")
	p11:register(XMLValueType.VECTOR_3, p12 .. "#lowerTransLimitScale", "Lower trans limit scale", "0 0 0")
	p11:register(XMLValueType.FLOAT, p12 .. "#transLimitThreshold", "Defines when the transition from upper to lower trans limit starts (0: directly, 0.9: after 90% of lowering)", 0)
	p11:register(XMLValueType.VECTOR_3, p12 .. "#rotLimitSpring", "Rotation limit spring", "0 0 0")
	p11:register(XMLValueType.VECTOR_3, p12 .. "#rotLimitDamping", "Rotation limit damping", "1 1 1")
	p11:register(XMLValueType.VECTOR_3, p12 .. "#rotLimitForceLimit", "Rotation limit force limit", "-1 -1 -1")
	p11:register(XMLValueType.VECTOR_3, p12 .. "#transLimitSpring", "Translation limit spring", "0 0 0")
	p11:register(XMLValueType.VECTOR_3, p12 .. "#transLimitDamping", "Translation limit damping", "1 1 1")
	p11:register(XMLValueType.VECTOR_3, p12 .. "#transLimitForceLimit", "Translation limit force limit", "-1 -1 -1")
	p11:register(XMLValueType.INT, p12 .. "#attachAngleLimitAxis", "Direction axis which is used to calculate angle to enable attach", 1)
	p11:register(XMLValueType.FLOAT, p12 .. "#attacherHeight", "Height of attacher", "0.9 for trailer, 0.55 for trailer low")
	p11:register(XMLValueType.BOOL, p12 .. "#needsLowering", "Needs lowering")
	p11:register(XMLValueType.BOOL, p12 .. "#allowsLowering", "Allows lowering")
	p11:register(XMLValueType.BOOL, p12 .. "#isDefaultLowered", "Is default lowered", false)
	p11:register(XMLValueType.BOOL, p12 .. "#useFoldingLoweredState", "Use folding lowered state", false)
	p11:register(XMLValueType.BOOL, p12 .. "#forceSelectionOnAttach", "Is selected on attach", true)
	p11:register(XMLValueType.BOOL, p12 .. "#forceAllowDetachWhileLifted", "Attacher vehicle can be always detached no matter if we are lifted or not", false)
	p11:register(XMLValueType.INT, p12 .. "#forcedAttachingDirection", "Tool can be only attached in this direction", 0)
	p11:register(XMLValueType.BOOL, p12 .. "#allowFolding", "Folding is allowed while attached to this attacher joint", true)
	p11:register(XMLValueType.BOOL, p12 .. "#allowTurnOn", "Turn on is allowed while attached to this attacher joint", true)
	p11:register(XMLValueType.BOOL, p12 .. "#allowAI", "Toggling of AI is allowed while attached to this attacher joint", true)
	p11:register(XMLValueType.BOOL, p12 .. "#allowDetachWhileParentLifted", "If set to false the parent vehicle needs to be lowered to be able to detach this implement", true)
	p11:register(XMLValueType.BOOL, p12 .. "#useTopLights", "Defines if the tool attached to this attacher activates to automatic switch to the top lights", true)
	p11:register(XMLValueType.INT, p12 .. ".dependentAttacherJoint(?)#attacherJointIndex", "Dependent attacher joint index")
	p11:register(XMLValueType.NODE_INDEX, p12 .. ".additionalObjects.additionalObject(?)#node", "Additional object node")
	p11:register(XMLValueType.STRING, p12 .. ".additionalObjects.additionalObject(?)#attacherVehiclePath", "Path to vehicle for object activation")
	p11:register(XMLValueType.STRING, p12 .. ".additionalAttachment#filename", "Path to additional attachment")
	p11:register(XMLValueType.INT, p12 .. ".additionalAttachment#inputAttacherJointIndex", "Input attacher joint index of additional attachment")
	p11:register(XMLValueType.BOOL, p12 .. ".additionalAttachment#needsLowering", "Additional implements needs lowering")
	p11:register(XMLValueType.STRING, p12 .. ".additionalAttachment#jointType", "Additional implement joint type")
end
function Attachable.registerSupportXMLPaths(p13, p14)
	p13:addDelayedRegistrationPath(p14, "Attachable:support")
	p13:register(XMLValueType.STRING, p14 .. "#animationName", "Animation name")
	p13:register(XMLValueType.BOOL, p14 .. "#delayedOnLoad", "Defines if the animation is played onPostLoad or onPreInitComponentPlacement -> useful if the animation collides e.g. with the folding animation", false)
	p13:register(XMLValueType.BOOL, p14 .. "#delayedOnAttach", "Defines if the animation is played before or after the attaching process", true)
	p13:register(XMLValueType.BOOL, p14 .. "#detachAfterAnimation", "Defines if the vehicle is detached after the animation has played", true)
	p13:register(XMLValueType.FLOAT, p14 .. "#detachAnimationTime", "Defines when in the support animation the vehicle is detached (detachAfterAnimation needs to be true)", 1)
end
function Attachable.onLoad(p_u_15, _)
	local v_u_16 = p_u_15.spec_attachable
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.attacherJoint", "vehicle.inputAttacherJoints.inputAttacherJoint")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.needsLowering", "vehicle.inputAttacherJoints.inputAttacherJoint#needsLowering")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.allowsLowering", "vehicle.inputAttacherJoints.inputAttacherJoint#allowsLowering")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.isDefaultLowered", "vehicle.inputAttacherJoints.inputAttacherJoint#isDefaultLowered")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.forceSelectionOnAttach#value", "vehicle.inputAttacherJoints.inputAttacherJoint#forceSelectionOnAttach")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.topReferenceNode#index", "vehicle.attacherJoint#topReferenceNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.attachRootNode#index", "vehicle.attacherJoint#rootNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.inputAttacherJoints", "vehicle.attachable.inputAttacherJoints")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.inputAttacherJointConfigurations", "vehicle.attachable.inputAttacherJointConfigurations")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.brakeForce", "vehicle.attachable.brakeForce#force")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.attachable.brakeForce", "vehicle.attachable.brakeForce#force", nil, true)
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.steeringAxleAngleScale", "vehicle.attachable.steeringAxleAngleScale")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.support", "vehicle.attachable.support")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.lowerAnimation", "vehicle.attachable.lowerAnimation")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.toolCameras", "vehicle.attachable.toolCameras")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.attachable.toolCameras#count", "vehicle.attachable.toolCameras")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.attachable.toolCameras.toolCamera1", "vehicle.attachable.toolCamera")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.attachable.toolCameras.toolCamera2", "vehicle.attachable.toolCamera")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.attachable.toolCameras.toolCamera3", "vehicle.attachable.toolCamera")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.foldable.foldingParts#onlyFoldOnDetach", "vehicle.attachable#allowFoldingWhileAttached")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.maximalAirConsumptionPerFullStop", "vehicle.attachable.airConsumer#usage (is now in usage per second at full brake power)")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.attachable.steeringAxleAngleScale#targetNode", "vehicle.attachable.steeringAxleAngleScale.targetNode#node")
	v_u_16.attacherJoint = nil
	v_u_16.supportAnimations = {}
	p_u_15.xmlFile:iterate("vehicle.attachable.support", function(_, p17)
		-- upvalues: (copy) p_u_15, (copy) v_u_16
		local v18 = {}
		if p_u_15:loadSupportAnimationFromXML(v18, p_u_15.xmlFile, p17) then
			local v19 = v_u_16.supportAnimations
			table.insert(v19, v18)
		end
	end)
	v_u_16.inputAttacherJoints = {}
	p_u_15.xmlFile:iterate("vehicle.attachable.inputAttacherJoints.inputAttacherJoint", function(p20, p21)
		-- upvalues: (copy) p_u_15, (copy) v_u_16
		local v22 = {}
		if p_u_15:loadInputAttacherJoint(p_u_15.xmlFile, p21, v22, p20 - 1) then
			local v23 = v_u_16.inputAttacherJoints
			table.insert(v23, v22)
		end
	end)
	if p_u_15.configurations.inputAttacherJoint ~= nil then
		local v24 = string.format("vehicle.attachable.inputAttacherJointConfigurations.inputAttacherJointConfiguration(%d)", p_u_15.configurations.inputAttacherJoint - 1)
		p_u_15.xmlFile:iterate(v24 .. ".inputAttacherJoint", function(p25, p26)
			-- upvalues: (copy) p_u_15, (copy) v_u_16
			local v27 = {}
			if p_u_15:loadInputAttacherJoint(p_u_15.xmlFile, p26, v27, p25 - 1) then
				local v28 = v_u_16.inputAttacherJoints
				table.insert(v28, v27)
			end
		end)
		p_u_15.xmlFile:iterate(v24 .. ".support", function(_, p29)
			-- upvalues: (copy) p_u_15, (copy) v_u_16
			local v30 = {}
			if p_u_15:loadSupportAnimationFromXML(v30, p_u_15.xmlFile, p29) then
				local v31 = v_u_16.supportAnimations
				table.insert(v31, v30)
			end
		end)
	end
	v_u_16.brakeForce = p_u_15.xmlFile:getValue("vehicle.attachable.brakeForce#force", 0) * 10
	v_u_16.maxBrakeForce = p_u_15.xmlFile:getValue("vehicle.attachable.brakeForce#maxForce", 0) * 10
	v_u_16.loweredBrakeForce = p_u_15.xmlFile:getValue("vehicle.attachable.brakeForce#loweredForce", -1) * 10
	v_u_16.maxBrakeForceMass = p_u_15.xmlFile:getValue("vehicle.attachable.brakeForce#maxForceMass", 0) / 1000
	v_u_16.maxBrakeForceMassIncludeAttachables = p_u_15.xmlFile:getValue("vehicle.attachable.brakeForce#includeAttachables", false)
	v_u_16.airConsumerUsage = p_u_15.xmlFile:getValue("vehicle.attachable.airConsumer#usage", 0)
	v_u_16.allowFoldingWhileAttached = p_u_15.xmlFile:getValue("vehicle.attachable#allowFoldingWhileAttached", true)
	v_u_16.allowFoldingWhileLowered = p_u_15.xmlFile:getValue("vehicle.attachable#allowFoldingWhileLowered", true)
	v_u_16.blockFoliageDestruction = p_u_15.xmlFile:getValue("vehicle.attachable#blockFoliageDestruction", false)
	v_u_16.requiresExternalPower = p_u_15.xmlFile:getValue("vehicle.attachable.power#requiresExternalPower", true)
	v_u_16.attachToPowerWarning = p_u_15.xmlFile:getValue("vehicle.attachable.power#attachToPowerWarning", "warning_attachToPower", p_u_15.customEnvironment)
	v_u_16.updateWheels = true
	v_u_16.updateSteeringAxleAngle = true
	v_u_16.isDetachingBlocked = false
	v_u_16.isSelected = false
	v_u_16.attachTime = 0
	v_u_16.steeringAxleAngle = 0
	v_u_16.steeringAxleTargetAngle = 0
	p_u_15:loadSteeringAxleFromXML(v_u_16, p_u_15.xmlFile, "vehicle.attachable.steeringAxleAngleScale")
	if v_u_16.steeringAxleDistanceDelay > 0 then
		v_u_16.steeringAxleTargetAngleHistory = {}
		local v32 = v_u_16.steeringAxleDistanceDelay / 0.1
		for v33 = 1, math.floor(v32) do
			v_u_16.steeringAxleTargetAngleHistory[v33] = 0
		end
		v_u_16.steeringAxleTargetAngleHistoryIndex = 1
		v_u_16.steeringAxleTargetAngleHistoryMoved = 1
	end
	v_u_16.steeringAngleNodes = {}
	p_u_15.xmlFile:iterate("vehicle.attachable.steeringAngleNodes.steeringAngleNode", function(_, p34)
		-- upvalues: (copy) p_u_15, (copy) v_u_16
		local v35 = {}
		if p_u_15:loadSteeringAngleNodeFromXML(v35, p_u_15.xmlFile, p34) then
			local v36 = v_u_16.steeringAngleNodes
			table.insert(v36, v35)
		end
	end)
	v_u_16.detachingInProgress = false
	v_u_16.lowerAnimation = p_u_15.xmlFile:getValue("vehicle.attachable.lowerAnimation#name")
	v_u_16.lowerAnimationSpeed = p_u_15.xmlFile:getValue("vehicle.attachable.lowerAnimation#speed", 1)
	v_u_16.lowerAnimationDirectionOnDetach = p_u_15.xmlFile:getValue("vehicle.attachable.lowerAnimation#directionOnDetach", 0)
	v_u_16.lowerAnimationDefaultLowered = p_u_15.xmlFile:getValue("vehicle.attachable.lowerAnimation#defaultLowered", false)
	v_u_16.toolCameras = {}
	p_u_15.xmlFile:iterate("vehicle.attachable.toolCameras.toolCamera", function(_, p37)
		-- upvalues: (copy) p_u_15, (copy) v_u_16
		local v38 = VehicleCamera.new(p_u_15)
		if v38:loadFromXML(p_u_15.xmlFile, p37) then
			local v39 = v_u_16.toolCameras
			table.insert(v39, v38)
		end
	end)
	if p_u_15.isClient then
		v_u_16.samples = {}
		v_u_16.samples.active = g_soundManager:loadSamplesFromXML(p_u_15.xmlFile, "vehicle.attachable.sounds", "active", p_u_15.baseDirectory, p_u_15.components, 0, AudioGroup.VEHICLE, p_u_15.i3dMappings, p_u_15)
		v_u_16.isActiveSamplePlaying = false
	end
	v_u_16.isHardAttached = false
	v_u_16.isAdditionalAttachment = false
	v_u_16.texts = {}
	v_u_16.texts.liftObject = g_i18n:getText("action_liftOBJECT")
	v_u_16.texts.lowerObject = g_i18n:getText("action_lowerOBJECT")
	v_u_16.texts.warningFoldingAttached = g_i18n:getText("warning_foldingNotWhileAttached")
	v_u_16.texts.warningFoldingLowered = g_i18n:getText("warning_foldingNotWhileLowered")
	v_u_16.texts.warningFoldingAttacherJoint = g_i18n:getText("warning_foldingNotWhileAttachedToAttacherJoint")
	v_u_16.texts.lowerImplementFirst = g_i18n:getText("warning_lowerImplementFirst")
end
function Attachable.onPostLoad(p40, _)
	local v41 = p40.spec_attachable
	for _, v42 in ipairs(v41.supportAnimations) do
		if not v42.delayedOnLoad and p40:getIsSupportAnimationAllowed(v42) then
			p40:playAnimation(v42.animationName, 1, nil, true, false)
			AnimatedVehicle.updateAnimationByName(p40, v42.animationName, 9999999, true)
		end
	end
	if p40.brake ~= nil then
		local v43 = p40:getBrakeForce()
		if v43 > 0 then
			p40:brake(v43, true)
		end
	end
	local v44
	if #v41.steeringAngleNodes > 0 or v41.steeringAxleTargetNode ~= nil then
		v44 = true
	elseif p40.getWheels == nil then
		v44 = false
	else
		v44 = #p40:getWheels() > 0
	end
	v41.updateSteeringAxleAngle = v44
	if #v41.inputAttacherJoints == 0 then
		SpecializationUtil.removeEventListener(p40, "onUpdate", Attachable)
	end
end
function Attachable.onLoadFinished(p45, _)
	local v46 = p45.spec_attachable
	for v47, v48 in ipairs(v46.inputAttacherJoints) do
		v48.jointInfo = g_currentMission.vehicleSystem:registerInputAttacherJoint(p45, v47, v48)
	end
end
function Attachable.onPreInitComponentPlacement(p49, p50)
	local v51 = p49.spec_attachable
	for _, v52 in ipairs(v51.supportAnimations) do
		if v52.delayedOnLoad and p49:getIsSupportAnimationAllowed(v52) then
			p49:playAnimation(v52.animationName, 1, nil, true, false)
			AnimatedVehicle.updateAnimationByName(p49, v52.animationName, 9999999, true)
		end
	end
	for _, v53 in ipairs(v51.inputAttacherJoints) do
		if v53.drawbarNode ~= nil then
			p49:setMovingPartReferenceNode(v53.drawbarNode, v53.node, false)
			p49:setMovingPartReferenceNode(v53.drawbarNode, nil, false)
		end
	end
	if p50 == nil or p50.resetVehicles then
		if v51.lowerAnimationDefaultLowered then
			p49:playAnimation(v51.lowerAnimation, 1, nil, true, false)
			AnimatedVehicle.updateAnimationByName(p49, v51.lowerAnimation, 9999999, true)
		end
	else
		if v51.lowerAnimation ~= nil and p49.playAnimation ~= nil then
			local v54 = p50.xmlFile:getValue(p50.key .. ".attachable#lowerAnimTime")
			if v54 ~= nil then
				local v55 = v54 < 0.5 and -1 or 1
				p49:playAnimation(v51.lowerAnimation, v55, nil, true, false)
				p49:setAnimationTime(v51.lowerAnimation, v54)
				AnimatedVehicle.updateAnimationByName(p49, v51.lowerAnimation, 9999999, true)
				if p49.updateCylinderedInitial ~= nil then
					p49:updateCylinderedInitial(false)
				end
			end
		end
		v51.isDetachingBlocked = p50.xmlFile:getValue(p50.key .. ".attachable#isDetachingBlocked", false)
	end
end
function Attachable.onPreDelete(p56)
	local v57 = p56.spec_attachable
	if v57.attacherVehicle ~= nil then
		v57.attacherVehicle:detachImplementByObject(p56, true)
	end
	if v57.inputAttacherJoints ~= nil then
		for v58 = 1, #v57.inputAttacherJoints do
			local v59 = v57.inputAttacherJoints[v58]
			g_currentMission.vehicleSystem:removeInputAttacherJoint(v59.jointInfo)
		end
	end
end
function Attachable.onDelete(p60)
	local v61 = p60.spec_attachable
	if v61.toolCameras ~= nil then
		for _, v62 in ipairs(v61.toolCameras) do
			v62:delete()
		end
	end
	if v61.inputAttacherJoints ~= nil then
		for v63 = 1, #v61.inputAttacherJoints do
			local v64 = v61.inputAttacherJoints[v63]
			if v64.bottomArm ~= nil and v64.bottomArm.sharedLoadRequestIdBalls ~= nil then
				g_i3DManager:releaseSharedI3DFile(v64.bottomArm.sharedLoadRequestIdBalls)
			end
		end
	end
	if v61.samples ~= nil then
		g_soundManager:deleteSamples(v61.samples.active)
	end
end
function Attachable.saveToXMLFile(p65, p66, p67, _)
	local v68 = p65.spec_attachable
	if v68.lowerAnimation ~= nil and p65.playAnimation ~= nil then
		local v69 = p65:getAnimationTime(v68.lowerAnimation)
		p66:setValue(p67 .. "#lowerAnimTime", v69)
	end
	p66:setValue(p67 .. "#isDetachingBlocked", Utils.getNoNil(v68.isDetachingBlocked, false))
end
function Attachable.onReadStream(p70, p71, _)
	if streamReadBool(p71) then
		local v72 = NetworkUtil.readNodeObject(p71)
		local v73 = streamReadInt8(p71)
		local v74 = streamReadInt8(p71)
		local v75 = streamReadBool(p71)
		local v76 = streamReadInt8(p71)
		if v72 ~= nil and v72:getIsSynchronized() then
			v72:attachImplement(p70, v73, v74, true, v76, v75, true, true)
			v72:setJointMoveDown(v74, v75, true)
		end
	end
end
function Attachable.onWriteStream(p77, p78, _)
	local v79 = p77.spec_attachable
	streamWriteBool(p78, v79.attacherVehicle ~= nil)
	if v79.attacherVehicle ~= nil then
		local v80 = v79.attacherVehicle.spec_attacherJoints
		local v81 = v79.attacherVehicle:getImplementIndexByObject(p77)
		local v82 = v80.attachedImplements[v81]
		local v83 = v79.inputAttacherJointDescIndex
		local v84 = v82.jointDescIndex
		local v85 = v80.attacherJoints[v84].moveDown
		NetworkUtil.writeNodeObject(p78, v79.attacherVehicle)
		streamWriteInt8(p78, v83)
		streamWriteInt8(p78, v84)
		streamWriteBool(p78, v85)
		streamWriteInt8(p78, v81)
	end
end
function Attachable.onUpdate(p86, p87, _, _, _)
	local v88 = p86.spec_attachable
	local v89 = nil
	if v88.updateSteeringAxleAngle and (p86:getLastSpeed() > 0.25 or not p86.finishedFirstUpdate) then
		local v90 = 0
		local v91 = p86:getSteeringAxleBaseVehicle()
		if v91 == nil and v88.steeringAxleReferenceComponentNode == nil or p86.movingDirection < 0 and not v88.steeringAxleUpdateBackwards then
			if p86:getLastSpeed() > 0.2 then
				v90 = 0
			end
		else
			v89 = Utils.getYRotationBetweenNodes(p86.steeringAxleNode, v88.steeringAxleReferenceComponentNode or v91.steeringAxleNode)
			local v92
			if v88.steeringAxleAngleScaleSpeedDependent then
				local v93 = v88.steeringAxleAngleScaleStart
				local v94 = v88.steeringAxleAngleScaleEnd
				local v95 = 1 + (p86:getLastSpeed() - v93) * 1 / (v93 - v94)
				v92 = math.clamp(v95, 0, 1)
			else
				v92 = 1
			end
			v90 = v89 * v92
		end
		local v96 = not p86:getIsSteeringAxleAllowed() and 0 or v90
		if v88.steeringAxleDistanceDelay > 0 then
			v88.steeringAxleTargetAngleHistoryMoved = v88.steeringAxleTargetAngleHistoryMoved + p86.lastMovedDistance
			if v88.steeringAxleTargetAngleHistoryMoved > 0.1 then
				v88.steeringAxleTargetAngleHistory[v88.steeringAxleTargetAngleHistoryIndex] = v96
				v88.steeringAxleTargetAngleHistoryIndex = v88.steeringAxleTargetAngleHistoryIndex + 1
				if v88.steeringAxleTargetAngleHistoryIndex > #v88.steeringAxleTargetAngleHistory then
					v88.steeringAxleTargetAngleHistoryIndex = 1
				end
			end
			local v97 = v88.steeringAxleTargetAngleHistoryIndex + 1
			local v98 = #v88.steeringAxleTargetAngleHistory < v97 and 1 or v97
			v88.steeringAxleTargetAngle = v88.steeringAxleTargetAngleHistory[v98]
		else
			v88.steeringAxleTargetAngle = v96
		end
		local v99 = v88.steeringAxleTargetAngle - v88.steeringAxleAngle
		local v100 = math.sign(v99)
		local v101 = v88.steeringAxleAngleSpeed
		local v102 = not p86.finishedFirstUpdate and 9999 or v101
		if v100 == 1 then
			local v103 = v88.steeringAxleAngle + v100 * p87 * v102
			local v104 = v88.steeringAxleTargetAngle
			v88.steeringAxleAngle = math.min(v103, v104)
		else
			local v105 = v88.steeringAxleAngle + v100 * p87 * v102
			local v106 = v88.steeringAxleTargetAngle
			v88.steeringAxleAngle = math.max(v105, v106)
		end
		if v88.steeringAxleTargetNode ~= nil then
			local v107
			if v88.steeringAxleTargetNodeRefAngle == nil then
				local v108 = v88.steeringAxleAngle
				local v109 = v88.steeringAxleAngleMinRot
				local v110 = v88.steeringAxleAngleMaxRot
				v107 = math.clamp(v108, v109, v110)
			else
				local v111 = v88.steeringAxleAngle / v88.steeringAxleTargetNodeRefAngle
				local v112 = math.clamp(v111, -1, 1)
				if v112 >= 0 then
					v107 = v88.steeringAxleAngleMaxRot * v112
				else
					v107 = v88.steeringAxleAngleMinRot * -v112
				end
			end
			setRotation(v88.steeringAxleTargetNode, 0, v107 * v88.steeringAxleDirection, 0)
			p86:setMovingToolDirty(v88.steeringAxleTargetNode)
		end
	end
	local v113 = #v88.steeringAngleNodes
	if v113 > 0 and v89 == nil then
		local v114 = p86:getSteeringAxleBaseVehicle()
		if v114 ~= nil then
			v89 = Utils.getYRotationBetweenNodes(p86.steeringAxleNode, v114.steeringAxleNode)
		end
	end
	if v89 ~= nil then
		for v115 = 1, v113 do
			p86:updateSteeringAngleNode(v88.steeringAngleNodes[v115], v89, p87)
		end
	end
	local v116 = p86:getAttacherVehicle()
	if v88.detachingInProgress and p86:getIsReadyToFinishDetachProcess() then
		if v116 ~= nil then
			v116:detachImplementByObject(p86)
		end
		v88.detachingInProgress = false
	end
	if v116 ~= nil and (p86.currentUpdateDistance < v116.spec_attacherJoints.maxUpdateDistance and p86.updateLoopIndex == v116.updateLoopIndex) then
		local v117 = v116:getImplementByObject(p86)
		if v117 ~= nil then
			v116:updateAttacherJointGraphics(v117, p87, true)
			p86:updateInputAttacherJointGraphics(v117, p87, true)
		end
	end
end
function Attachable.onUpdateTick(p118, _, _, _, _)
	local v119 = p118.spec_attachable
	for v120 = 1, #v119.inputAttacherJoints do
		local v121 = v119.inputAttacherJoints[v120]
		g_currentMission.vehicleSystem:updateInputAttacherJoint(v121.jointInfo)
	end
	if p118.isClient then
		if p118.lastSpeed > 0.00027 then
			if not v119.isActiveSamplePlaying then
				g_soundManager:playSamples(v119.samples.active)
				v119.isActiveSamplePlaying = true
				return
			end
		elseif v119.isActiveSamplePlaying then
			g_soundManager:stopSamples(v119.samples.active)
			v119.isActiveSamplePlaying = false
		end
	end
end
function Attachable.loadInputAttacherJoint(p_u_122, p_u_123, p124, p_u_125, _)
	XMLUtil.checkDeprecatedXMLElements(p_u_123, p124 .. "#index", p124 .. "#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_123, p124 .. "#indexVisual", p124 .. "#nodeVisual")
	XMLUtil.checkDeprecatedXMLElements(p_u_123, p124 .. "#ptoInputNode", "vehicle.powerTakeOffs.input")
	XMLUtil.checkDeprecatedXMLElements(p_u_123, p124 .. "#lowerDistanceToGround", p124 .. ".distanceToGround#lower")
	XMLUtil.checkDeprecatedXMLElements(p_u_123, p124 .. "#upperDistanceToGround", p124 .. ".distanceToGround#upper")
	local v_u_126 = p_u_123:getValue(p124 .. "#node", nil, p_u_122.components, p_u_122.i3dMappings)
	if v_u_126 == nil then
		return false
	end
	p_u_125.node = v_u_126
	p_u_125.heightNodes = {}
	p_u_123:iterate(p124 .. ".heightNode", function(_, p127)
		-- upvalues: (copy) p_u_122, (copy) p_u_123, (copy) v_u_126, (copy) p_u_125
		local v128 = {}
		if p_u_122:loadAttacherJointHeightNode(p_u_123, p127, v128, v_u_126) then
			local v129 = p_u_125.heightNodes
			table.insert(v129, v128)
		end
	end)
	local v130 = p_u_123:getValue(p124 .. "#jointType")
	local v131 = nil
	if v130 == nil then
		Logging.xmlWarning(p_u_122.xmlFile, "Missing jointType for inputAttacherJoint \'%s\'!", p124)
	else
		v131 = AttacherJoints.jointTypeNameToInt[v130]
		if v131 == nil then
			Logging.xmlWarning(p_u_122.xmlFile, "Invalid jointType \'%s\' for inputAttacherJoint \'%s\'!", tostring(v130), p124)
		end
	end
	if v131 == nil then
		local v132 = p_u_123:getValue(p124 .. "#needsTrailerJoint", false)
		local v133 = p_u_123:getValue(p124 .. "#needsLowJoint", false)
		if v132 then
			if v133 then
				v131 = AttacherJoints.JOINTTYPE_TRAILERLOW
			else
				v131 = AttacherJoints.JOINTTYPE_TRAILER
			end
		else
			v131 = AttacherJoints.JOINTTYPE_IMPLEMENT
		end
	end
	p_u_125.jointType = v131
	local v134 = p_u_123:getValue(p124 .. ".subType#name")
	if not string.isNilOrWhitespace(v134) then
		p_u_125.subTypes = string.split(v134, " ")
	end
	p_u_125.subTypeShowWarning = p_u_123:getValue(p124 .. ".subType#showWarning", true)
	local v135 = p_u_122:getParentComponent(p_u_125.node)
	p_u_125.jointOrigTrans = { getTranslation(p_u_125.node) }
	p_u_125.jointOrigOffsetComponent = { localToLocal(v135, p_u_125.node, 0, 0, 0) }
	p_u_125.jointOrigRotOffsetComponent = { localRotationToLocal(v135, p_u_125.node, 0, 0, 0) }
	p_u_125.topReferenceNode = p_u_123:getValue(p124 .. "#topReferenceNode", nil, p_u_122.components, p_u_122.i3dMappings)
	p_u_125.rootNode = p_u_123:getValue(p124 .. "#rootNode", v135, p_u_122.components, p_u_122.i3dMappings)
	p_u_125.rootNodeBackup = p_u_125.rootNode
	p_u_125.allowsDetaching = p_u_123:getValue(p124 .. "#allowsDetaching", true)
	p_u_125.fixedRotation = p_u_123:getValue(p124 .. "#fixedRotation", false)
	p_u_125.hardAttach = p_u_123:getValue(p124 .. "#hardAttach", false)
	if p_u_125.hardAttach and #p_u_122.components > 1 then
		Logging.xmlWarning(p_u_122.xmlFile, "hardAttach only available for single component vehicles! InputAttacherJoint \'%s\'!", p124)
		p_u_125.hardAttach = false
	end
	p_u_125.visualNode = p_u_123:getValue(p124 .. "#nodeVisual", nil, p_u_122.components, p_u_122.i3dMappings)
	if p_u_125.hardAttach and p_u_125.visualNode ~= nil then
		p_u_125.visualNodeData = {
			["parent"] = getParent(p_u_125.visualNode),
			["translation"] = { getTranslation(p_u_125.visualNode) },
			["rotation"] = { getRotation(p_u_125.visualNode) },
			["index"] = getChildIndex(p_u_125.visualNode)
		}
	end
	if v131 == AttacherJoints.JOINTTYPE_IMPLEMENT or (v131 == AttacherJoints.JOINTTYPE_CUTTER or v131 == AttacherJoints.JOINTTYPE_CUTTERHARVESTER) then
		if p_u_123:getValue(p124 .. ".distanceToGround#lower") == nil then
			Logging.xmlWarning(p_u_122.xmlFile, "Missing \'.distanceToGround#lower\' for inputAttacherJoint \'%s\'!", p124)
		end
		if p_u_123:getValue(p124 .. ".distanceToGround#upper") == nil then
			Logging.xmlWarning(p_u_122.xmlFile, "Missing \'.distanceToGround#upper\' for inputAttacherJoint \'%s\'!", p124)
		end
	end
	p_u_125.lowerDistanceToGround = p_u_123:getValue(p124 .. ".distanceToGround#lower", 0.7)
	p_u_125.upperDistanceToGround = p_u_123:getValue(p124 .. ".distanceToGround#upper", 1)
	if p_u_125.lowerDistanceToGround > p_u_125.upperDistanceToGround then
		Logging.xmlWarning(p_u_122.xmlFile, "distanceToGround#lower may not be larger than distanceToGround#upper for inputAttacherJoint \'%s\'. Switching values!", p124)
		local v136 = p_u_125.lowerDistanceToGround
		p_u_125.lowerDistanceToGround = p_u_125.upperDistanceToGround
		p_u_125.upperDistanceToGround = v136
	end
	p_u_125.distanceToGroundByVehicle = {}
	p_u_123:iterate(p124 .. ".distanceToGround.vehicle", function(_, p137)
		-- upvalues: (copy) p_u_123, (copy) p_u_125
		local v138 = {
			["filename"] = p_u_123:getValue(p137 .. "#filename")
		}
		if v138.filename ~= nil then
			v138.filename = v138.filename:lower()
			v138.lower = p_u_123:getValue(p137 .. "#lower", p_u_125.lowerDistanceToGround)
			v138.upper = p_u_123:getValue(p137 .. "#upper", p_u_125.upperDistanceToGround)
			local v139 = p_u_125.distanceToGroundByVehicle
			table.insert(v139, v138)
		end
	end)
	p_u_125.lowerDistanceToGroundOriginal = p_u_125.lowerDistanceToGround
	p_u_125.upperDistanceToGroundOriginal = p_u_125.upperDistanceToGround
	p_u_125.lowerRotationOffset = p_u_123:getValue(p124 .. "#lowerRotationOffset", 0)
	local v140 = v131 == AttacherJoints.JOINTTYPE_IMPLEMENT and 8 or 0
	p_u_125.upperRotationOffset = p_u_123:getValue(p124 .. "#upperRotationOffset", v140)
	p_u_125.allowsJointRotLimitMovement = p_u_123:getValue(p124 .. "#allowsJointRotLimitMovement", true)
	p_u_125.allowsJointTransLimitMovement = p_u_123:getValue(p124 .. "#allowsJointTransLimitMovement", true)
	p_u_125.needsToolbar = p_u_123:getValue(p124 .. "#needsToolbar", false)
	if p_u_125.needsToolbar and v131 ~= AttacherJoints.JOINTTYPE_IMPLEMENT then
		Logging.xmlWarning(p_u_122.xmlFile, "\'needsToolbar\' requires jointType \'implement\' for inputAttacherJoint \'%s\'!", p124)
		p_u_125.needsToolbar = false
	end
	if v131 == AttacherJoints.JOINTTYPE_IMPLEMENT and not p_u_125.needsToolbar then
		p_u_125.bottomArm = {}
		local v141 = p_u_123:getValue(p124 .. ".bottomArm#categories", "", true)
		for _, v142 in ipairs(v141) do
			if v142 < 0 or v142 > 4 then
				Logging.xmlWarning(p_u_123, "Bottom arm category should be between 0 and 4 in \'%s\'", p124)
			end
		end
		p_u_125.bottomArm.widths = p_u_123:getValue(p124 .. ".bottomArm#widths", nil, true)
		if p_u_125.bottomArm.widths == nil or #p_u_125.bottomArm.widths == 0 then
			p_u_125.bottomArm.widths = {}
			for _, v143 in ipairs(v141) do
				local v144 = p_u_125.bottomArm.widths
				local v145 = AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY[v143]
				table.insert(v144, v145)
			end
		end
		p_u_125.bottomArm.ballType = p_u_123:getValue(p124 .. ".bottomArm#ballType", 1)
		p_u_125.bottomArm.ballDefaultVisibility = p_u_123:getValue(p124 .. ".bottomArm#ballDefaultVisibility", not p_u_125.needsToolbar)
		p_u_125.bottomArm.ballFilename = p_u_123:getValue(p124 .. ".bottomArm#ballFilename")
		if p_u_125.bottomArm.ballFilename == nil then
			p_u_125.bottomArm.ballFilename = string.format(Attachable.LOWER_LINK_BALL_FILENAME, p_u_125.bottomArm.ballType)
		else
			p_u_125.bottomArm.ballFilename = Utils.getFilename(p_u_125.bottomArm.ballFilename, p_u_122.baseDirectory)
		end
		if #p_u_125.bottomArm.widths > 0 and p_u_125.bottomArm.ballFilename ~= nil then
			if fileExists(p_u_125.bottomArm.ballFilename) then
				p_u_125.bottomArm.sharedLoadRequestIdBalls = p_u_122:loadSubSharedI3DFile(p_u_125.bottomArm.ballFilename, false, false, Attachable.onBottomArmBallsI3DLoaded, p_u_122, p_u_125)
			else
				Logging.xmlWarning(p_u_123, "Unable to load lower link balls from \'%s\' in \'%s\'", p_u_125.bottomArm.ballFilename, p124)
			end
		end
	end
	if p_u_122.setMovingPartReferenceNode ~= nil then
		p_u_125.steeringBarLeftNode = p_u_123:getValue(p124 .. "#steeringBarLeftNode", nil, p_u_122.components, p_u_122.i3dMappings)
		p_u_125.steeringBarRightNode = p_u_123:getValue(p124 .. "#steeringBarRightNode", nil, p_u_122.components, p_u_122.i3dMappings)
		p_u_125.drawbarNode = p_u_123:getValue(p124 .. "#drawbarNode", nil, p_u_122.components, p_u_122.i3dMappings)
	end
	p_u_125.bottomArmLeftNode = p_u_123:getValue(p124 .. "#bottomArmLeftNode", nil, p_u_122.components, p_u_122.i3dMappings)
	p_u_125.bottomArmRightNode = p_u_123:getValue(p124 .. "#bottomArmRightNode", nil, p_u_122.components, p_u_122.i3dMappings)
	p_u_125.upperRotLimitScale = p_u_123:getValue(p124 .. "#upperRotLimitScale", "0 0 0", true)
	p_u_125.lowerRotLimitScale = p_u_123:getValue(p124 .. "#lowerRotLimitScale", nil, true)
	if p_u_125.lowerRotLimitScale == nil then
		local v146 = p_u_125.lowerDistanceToGround - p_u_125.upperDistanceToGround
		if math.abs(v146) > 0.0001 then
			if v131 == AttacherJoints.JOINTTYPE_IMPLEMENT then
				p_u_125.lowerRotLimitScale = { 0, 0, 1 }
			else
				p_u_125.lowerRotLimitScale = { 1, 1, 1 }
			end
		else
			p_u_125.lowerRotLimitScale = { 0, 0, 0 }
		end
	end
	p_u_125.rotLimitThreshold = p_u_123:getValue(p124 .. "#rotLimitThreshold", 0)
	p_u_125.upperTransLimitScale = p_u_123:getValue(p124 .. "#upperTransLimitScale", "0 0 0", true)
	p_u_125.lowerTransLimitScale = p_u_123:getValue(p124 .. "#lowerTransLimitScale", "0 1 0", true)
	p_u_125.transLimitThreshold = p_u_123:getValue(p124 .. "#transLimitThreshold", 0)
	p_u_125.rotLimitSpring = p_u_123:getValue(p124 .. "#rotLimitSpring", "0 0 0", true)
	p_u_125.rotLimitDamping = p_u_123:getValue(p124 .. "#rotLimitDamping", "1 1 1", true)
	p_u_125.rotLimitForceLimit = p_u_123:getValue(p124 .. "#rotLimitForceLimit", "-1 -1 -1", true)
	p_u_125.transLimitSpring = p_u_123:getValue(p124 .. "#transLimitSpring", "0 0 0", true)
	p_u_125.transLimitDamping = p_u_123:getValue(p124 .. "#transLimitDamping", "1 1 1", true)
	p_u_125.transLimitForceLimit = p_u_123:getValue(p124 .. "#transLimitForceLimit", "-1 -1 -1", true)
	p_u_125.attachAngleLimitAxis = p_u_123:getValue(p124 .. "#attachAngleLimitAxis", 1)
	p_u_125.attacherHeight = p_u_123:getValue(p124 .. "#attacherHeight")
	if p_u_125.attacherHeight == nil then
		if v131 == AttacherJoints.JOINTTYPE_TRAILER then
			p_u_125.attacherHeight = 0.9
		elseif v131 == AttacherJoints.JOINTTYPE_TRAILERLOW then
			p_u_125.attacherHeight = 0.55
		elseif v131 == AttacherJoints.JOINTTYPE_TRAILERCAR then
			p_u_125.attacherHeight = 0.55
		end
	end
	local v147 = p_u_125.jointType ~= AttacherJoints.JOINTTYPE_TRAILER and (p_u_125.jointType ~= AttacherJoints.JOINTTYPE_TRAILERLOW and p_u_125.jointType ~= AttacherJoints.JOINTTYPE_TRAILERCAR)
	local v148 = p_u_125.jointType ~= AttacherJoints.JOINTTYPE_TRAILER and (p_u_125.jointType ~= AttacherJoints.JOINTTYPE_TRAILERLOW and p_u_125.jointType ~= AttacherJoints.JOINTTYPE_TRAILERCAR) and true or false
	p_u_125.needsLowering = p_u_123:getValue(p124 .. "#needsLowering", v147)
	p_u_125.allowsLowering = p_u_123:getValue(p124 .. "#allowsLowering", v148)
	p_u_125.isDefaultLowered = p_u_123:getValue(p124 .. "#isDefaultLowered", false)
	p_u_125.useFoldingLoweredState = p_u_123:getValue(p124 .. "#useFoldingLoweredState", false)
	p_u_125.forceSelection = p_u_123:getValue(p124 .. "#forceSelectionOnAttach", true)
	p_u_125.forceAllowDetachWhileLifted = p_u_123:getValue(p124 .. "#forceAllowDetachWhileLifted", false)
	p_u_125.forcedAttachingDirection = p_u_123:getValue(p124 .. "#forcedAttachingDirection", 0)
	p_u_125.allowFolding = p_u_123:getValue(p124 .. "#allowFolding", true)
	p_u_125.allowTurnOn = p_u_123:getValue(p124 .. "#allowTurnOn", true)
	p_u_125.allowAI = p_u_123:getValue(p124 .. "#allowAI", true)
	p_u_125.allowDetachWhileParentLifted = p_u_123:getValue(p124 .. "#allowDetachWhileParentLifted", true)
	p_u_125.useTopLights = p_u_123:getValue(p124 .. "#useTopLights", true)
	p_u_125.dependentAttacherJoints = {}
	local v149 = 0
	while true do
		local v150 = string.format(p124 .. ".dependentAttacherJoint(%d)", v149)
		if not p_u_123:hasProperty(v150) then
			break
		end
		local v151 = p_u_123:getValue(v150 .. "#attacherJointIndex")
		if v151 ~= nil then
			local v152 = p_u_125.dependentAttacherJoints
			table.insert(v152, v151)
		end
		v149 = v149 + 1
	end
	if p_u_125.hardAttach then
		p_u_125.needsLowering = false
		p_u_125.allowsLowering = false
		p_u_125.isDefaultLowered = false
		p_u_125.upperRotationOffset = 0
	end
	p_u_125.changeObjects = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p_u_123, p124, p_u_125.changeObjects, p_u_122.components, p_u_122)
	ObjectChangeUtil.setObjectChanges(p_u_125.changeObjects, false, p_u_122, p_u_122.setMovingToolDirty)
	p_u_125.additionalObjects = {}
	local v153 = 0
	while true do
		local v154 = string.format("%s.additionalObjects.additionalObject(%d)", p124, v153)
		if not p_u_123:hasProperty(v154) then
			break
		end
		local v155 = {
			["node"] = p_u_123:getValue(v154 .. "#node", nil, p_u_122.components, p_u_122.i3dMappings),
			["attacherVehiclePath"] = p_u_123:getValue(v154 .. "#attacherVehiclePath")
		}
		if v155.node ~= nil and v155.attacherVehiclePath ~= nil then
			v155.attacherVehiclePath = NetworkUtil.convertToNetworkFilename(v155.attacherVehiclePath)
			local v156 = p_u_125.additionalObjects
			table.insert(v156, v155)
		end
		v153 = v153 + 1
	end
	p_u_125.additionalAttachment = {}
	local v157 = p_u_123:getValue(p124 .. ".additionalAttachment#filename")
	if v157 ~= nil then
		p_u_125.additionalAttachment.filename = Utils.getFilename(v157, p_u_122.customEnvironment)
	end
	p_u_125.additionalAttachment.inputAttacherJointIndex = p_u_123:getValue(p124 .. ".additionalAttachment#inputAttacherJointIndex", 1)
	p_u_125.additionalAttachment.needsLowering = p_u_123:getValue(p124 .. ".additionalAttachment#needsLowering", false)
	local v158 = p_u_123:getValue(p124 .. ".additionalAttachment#jointType")
	local v159
	if v158 == nil then
		v159 = nil
	else
		v159 = AttacherJoints.jointTypeNameToInt[v158]
		if v159 == nil then
			Logging.xmlWarning(p_u_122.xmlFile, "Invalid jointType \'%s\' for additonal implement \'%s\'!", tostring(v158), p_u_125.additionalAttachment.filename)
		end
	end
	p_u_125.additionalAttachment.jointType = v159 or AttacherJoints.JOINTTYPE_IMPLEMENT
	return true
end
function Attachable.loadAttacherJointHeightNode(p160, p161, p162, p163, p164)
	p163.node = p161:getValue(p162 .. "#node", nil, p160.components, p160.i3dMappings)
	p163.attacherJointNode = p164
	return true
end
function Attachable.getIsAttacherJointHeightNodeActive(_, _)
	return true
end
function Attachable.getInputAttacherJointByJointDescIndex(p165, p166)
	return p165.spec_attachable.inputAttacherJoints[p166]
end
function Attachable.getInputAttacherJointIndexByNode(p167, p168)
	local v169 = p167.spec_attachable
	for v170 = 1, #v169.inputAttacherJoints do
		if v169.inputAttacherJoints[v170].node == p168 then
			return v170
		end
	end
	return nil
end
function Attachable.getAttacherVehicle(p171)
	return p171.spec_attachable.attacherVehicle
end
function Attachable.getShowAttachableMapHotspot(p172)
	return p172.spec_attachable.attacherVehicle == nil
end
function Attachable.getInputAttacherJoints(p173)
	return p173.spec_attachable.inputAttacherJoints
end
function Attachable.getIsAttachedTo(p174, p175)
	if p175 == p174 then
		return true
	end
	local v176 = p174.spec_attachable
	if v176.attacherVehicle ~= nil then
		if v176.attacherVehicle == p175 then
			return true
		end
		if v176.attacherVehicle.getIsAttachedTo ~= nil then
			return v176.attacherVehicle:getIsAttachedTo(p175)
		end
	end
	return false
end
function Attachable.getActiveInputAttacherJointDescIndex(p177)
	return p177.spec_attachable.inputAttacherJointDescIndex
end
function Attachable.getActiveInputAttacherJoint(p178)
	return p178.spec_attachable.attacherJoint
end
function Attachable.getAllowsLowering(p179)
	local v180 = p179.spec_attachable
	if v180.isAdditionalAttachment and not v180.additionalAttachmentNeedsLowering then
		return false, nil
	else
		local v181 = p179:getActiveInputAttacherJoint()
		if v181 == nil or v181.allowsLowering then
			return true, nil
		else
			return false, nil
		end
	end
end
function Attachable.loadSupportAnimationFromXML(_, p182, p183, p184)
	p182.animationName = p183:getValue(p184 .. "#animationName")
	p182.delayedOnLoad = p183:getValue(p184 .. "#delayedOnLoad", false)
	p182.delayedOnAttach = p183:getValue(p184 .. "#delayedOnAttach", true)
	p182.detachAfterAnimation = p183:getValue(p184 .. "#detachAfterAnimation", true)
	p182.detachAnimationTime = p183:getValue(p184 .. "#detachAnimationTime", 1)
	return p182.animationName ~= nil
end
function Attachable.getIsSupportAnimationAllowed(p185, _)
	return p185.playAnimation ~= nil
end
function Attachable.getIsReadyToFinishDetachProcess(p186)
	local v187 = p186.spec_attachable
	local v188 = true
	for v189 = 1, #v187.supportAnimations do
		local v190 = v187.supportAnimations[v189]
		if v190.detachAfterAnimation then
			if v190.detachAnimationTime >= 1 then
				if p186:getIsAnimationPlaying(v190.animationName) then
					v188 = false
				end
			elseif p186:getAnimationTime(v190.animationName) < v190.detachAnimationTime then
				v188 = false
			end
		end
	end
	return v188
end
function Attachable.startDetachProcess(p191)
	local v192 = p191.spec_attachable
	for v193 = 1, #v192.supportAnimations do
		if v192.supportAnimations[v193].detachAfterAnimation and p191:getIsSupportAnimationAllowed(v192.supportAnimations[v193]) then
			p191:playAnimation(v192.supportAnimations[v193].animationName, 1, nil, true)
		end
	end
	if not p191:getIsReadyToFinishDetachProcess() then
		v192.detachingInProgress = true
		return false
	end
	v192.detachingInProgress = false
	local v194 = p191:getAttacherVehicle()
	if v194 ~= nil then
		v194:detachImplementByObject(p191)
	end
	return true
end
function Attachable.getIsImplementChainLowered(p195, p196)
	if not p195:getIsLowered(p196) then
		return false
	end
	local v197 = p195:getAttacherVehicle()
	return (v197 == nil or (v197.getAllowsLowering == nil or (not v197:getAllowsLowering() or v197:getIsImplementChainLowered(p196)))) and true or false
end
function Attachable.getIsInWorkPosition(_)
	return true
end
function Attachable.getAttachbleAirConsumerUsage(p198)
	return p198.spec_attachable.airConsumerUsage
end
function Attachable.isDetachAllowed(p199)
	local v200 = p199.spec_attachable
	if v200.isDetachingBlocked then
		return false
	end
	if v200.attacherJoint ~= nil then
		if v200.attacherJoint.allowsDetaching == false then
			return false, nil, false
		end
		if v200.attacherJoint.allowDetachWhileParentLifted == false then
			local v201 = p199:getAttacherVehicle()
			if v201 ~= nil and (v201.getIsLowered ~= nil and not v201:getIsLowered(true)) then
				return false, string.format(v200.texts.lowerImplementFirst, v201.typeDesc), true
			end
		end
	end
	if v200.isAdditionalAttachment then
		return false
	end
	local v202 = p199:getAttacherVehicle()
	if v202 ~= nil then
		local v203 = v202:getImplementByObject(p199)
		if v203 ~= nil and v203.attachingIsInProgress then
			return false
		end
	end
	return true, nil
end
function Attachable.isAttachAllowed(p204, p205, _)
	if g_currentMission.accessHandler:canFarmAccess(p205, p204) then
		if p204.spec_attachable.detachingInProgress then
			return false, nil
		else
			return true, nil
		end
	else
		return false, nil
	end
end
function Attachable.getIsInputAttacherActive(_, _)
	return true
end
function Attachable.getSteeringAxleBaseVehicle(p206)
	local v207 = p206.spec_attachable
	if v207.steeringAxleUseSuperAttachable and (v207.attacherVehicle ~= nil and v207.attacherVehicle.getAttacherVehicle ~= nil) then
		return v207.attacherVehicle:getAttacherVehicle()
	elseif v207.attacherVehicle == nil or not (v207.steeringAxleForceUsage or v207.attacherVehicle:getCanSteerAttachable(p206)) then
		return nil
	else
		return v207.attacherVehicle
	end
end
function Attachable.loadSteeringAxleFromXML(p208, p209, p210, p211)
	p209.steeringAxleAngleScaleStart = p210:getValue(p211 .. "#startSpeed", 10)
	p209.steeringAxleAngleScaleEnd = p210:getValue(p211 .. "#endSpeed", 30)
	p209.steeringAxleAngleScaleSpeedDependent = p210:getValue(p211 .. "#speedDependent", true)
	p209.steeringAxleUpdateBackwards = p210:getValue(p211 .. "#backwards", false)
	p209.steeringAxleAngleSpeed = p210:getValue(p211 .. "#speed", 60) * 0.001
	p209.steeringAxleUseSuperAttachable = p210:getValue(p211 .. "#useSuperAttachable", false)
	p209.steeringAxleTargetNode = p210:getValue(p211 .. ".targetNode#node", nil, p208.components, p208.i3dMappings)
	p209.steeringAxleTargetNodeRefAngle = p210:getValue(p211 .. ".targetNode#refAngle")
	p209.steeringAxleAngleMinRot = p210:getValue(p211 .. "#minRot", 0)
	p209.steeringAxleAngleMaxRot = p210:getValue(p211 .. "#maxRot", 0)
	p209.steeringAxleDirection = p210:getValue(p211 .. "#direction", 1)
	p209.steeringAxleForceUsage = p210:getValue(p211 .. "#forceUsage", p209.steeringAxleTargetNode ~= nil)
	p209.steeringAxleDistanceDelay = p210:getValue(p211 .. "#distanceDelay", 0)
	local v212 = p210:getValue(p211 .. "#referenceComponentIndex")
	if v212 ~= nil then
		local v213 = p208.components[v212]
		if v213 ~= nil then
			p209.steeringAxleReferenceComponentNode = v213.node
		end
	end
end
function Attachable.getIsSteeringAxleAllowed(_)
	return true
end
function Attachable.loadSteeringAngleNodeFromXML(p214, p215, p216, p217)
	p215.node = p216:getValue(p217 .. "#node", nil, p214.components, p214.i3dMappings)
	p215.speed = p216:getValue(p217 .. "#speed", 25) / 1000
	p215.scale = p216:getValue(p217 .. "#scale", 1)
	p215.offset = p216:getValue(p217 .. "#offset", 0)
	p215.minSpeed = p216:getValue(p217 .. "#minSpeed", 0)
	p215.currentAngle = 0
	return true
end
function Attachable.updateSteeringAngleNode(p218, p219, p220, p221)
	if p218.lastSpeed * 3600 > p219.minSpeed then
		local v222 = p220 - p219.currentAngle
		local v223 = math.sign(v222)
		local v224 = (v223 < 0 and math.max or math.min)(p219.currentAngle + p219.speed * p221 * v223, p220)
		if v224 ~= p219.currentAngle then
			p219.currentAngle = v224
			setRotation(p219.node, 0, p219.offset + p219.currentAngle * p219.scale, 0)
			if p218.setMovingToolDirty ~= nil then
				p218:setMovingToolDirty(p219.node)
			end
		end
	end
end
function Attachable.attachableAddToolCameras(p225)
	local v226 = p225.spec_attachable
	if #v226.toolCameras > 0 then
		local v227 = p225.rootVehicle
		if v227 ~= nil and v227.addToolCameras ~= nil then
			v227:addToolCameras(v226.toolCameras)
		end
	end
end
function Attachable.attachableRemoveToolCameras(p228)
	local v229 = p228.spec_attachable
	if #v229.toolCameras > 0 then
		local v230 = p228.rootVehicle
		if v230 ~= nil and v230.removeToolCameras ~= nil then
			v230:removeToolCameras(v229.toolCameras)
		end
	end
end
function Attachable.preAttach(p231, p232, p233, p234, p235)
	local v236 = p231.spec_attachable
	v236.attacherVehicle = p232
	v236.attacherJoint = v236.inputAttacherJoints[p233]
	v236.inputAttacherJointDescIndex = p233
	local v237 = p232:getAttacherJointByJointDescIndex(p234)
	local v238 = v236.attacherJoint.distanceToGroundByVehicle
	if #v236.attacherJoint.distanceToGroundByVehicle > 0 then
		local v239 = true
		for v240 = 1, #v238 do
			local v241 = v238[v240]
			if p232.configFileName:lower():endsWith(v241.filename) then
				v236.attacherJoint.lowerDistanceToGround = v241.lower
				v236.attacherJoint.upperDistanceToGround = v241.upper
				v239 = false
			end
		end
		if v239 then
			v236.attacherJoint.lowerDistanceToGround = v236.attacherJoint.lowerDistanceToGroundOriginal
			v236.attacherJoint.upperDistanceToGround = v236.attacherJoint.upperDistanceToGroundOriginal
		end
	end
	for _, v242 in ipairs(v236.attacherJoint.additionalObjects) do
		setVisibility(v242.node, v242.attacherVehiclePath == NetworkUtil.convertToNetworkFilename(p232.configFileName))
	end
	if v236.attacherJoint.bottomArm ~= nil and v236.attacherJoint.bottomArm.ballsNode ~= nil then
		local v243 = v237.bottomArm == nil and true or v237.bottomArm.ballVisibility
		setVisibility(v236.attacherJoint.bottomArm.ballsNode, v243)
	end
	for _, v244 in ipairs(v236.supportAnimations) do
		if p231:getIsSupportAnimationAllowed(v244) and not v244.delayedOnAttach then
			local v245 = p231.propertyState == VehiclePropertyState.SHOP_CONFIG and true or p235
			p231:playAnimation(v244.animationName, -1, nil, true, not v245)
			if v245 then
				AnimatedVehicle.updateAnimationByName(p231, v244.animationName, 9999999, true)
			end
		end
	end
	SpecializationUtil.raiseEvent(p231, "onPreAttach", p232, p233, p234)
end
function Attachable.postAttach(p246, p247, p248, p249, p250)
	local v251 = p246.spec_attachable
	local v252 = p246.rootVehicle
	if v252 ~= nil and (v252.getIsControlled ~= nil and v252:getIsControlled()) then
		p246:activate()
	end
	if p246.setLightsTypesMask ~= nil then
		local v253 = p247.spec_lights
		if v253 ~= nil then
			p246:setLightsTypesMask(v253.lightsTypesMask, true, true)
			p246:setBeaconLightsVisibility(v253.beaconLightsActive, true, true)
			p246:setTurnLightState(v253.turnLightState, true, true)
		end
	end
	v251.attachTime = g_currentMission.time
	for _, v254 in ipairs(v251.supportAnimations) do
		if p246:getIsSupportAnimationAllowed(v254) and v254.delayedOnAttach then
			local v255 = p246.propertyState == VehiclePropertyState.SHOP_CONFIG and true or p250
			p246:playAnimation(v254.animationName, -1, nil, true, not v255)
			if v255 then
				AnimatedVehicle.updateAnimationByName(p246, v254.animationName, 9999999, true)
			end
		end
	end
	p246:attachableAddToolCameras()
	ObjectChangeUtil.setObjectChanges(v251.attacherJoint.changeObjects, true, p246, p246.setMovingToolDirty)
	local v_u_256 = p247:getAttacherJointByJointDescIndex(p249)
	if v251.attacherJoint.steeringBarLeftNode ~= nil and v_u_256.steeringBarLeftNode ~= nil then
		p246:setMovingPartReferenceNode(v251.attacherJoint.steeringBarLeftNode, v_u_256.steeringBarLeftNode, false)
	end
	if v251.attacherJoint.steeringBarRightNode ~= nil and v_u_256.steeringBarRightNode ~= nil then
		p246:setMovingPartReferenceNode(v251.attacherJoint.steeringBarRightNode, v_u_256.steeringBarRightNode, false)
	end
	if v251.attacherJoint.drawbarNode ~= nil then
		p246:setMovingPartReferenceNode(v251.attacherJoint.drawbarNode, v_u_256.jointTransform, false)
	end
	local v257 = p246.rootVehicle.actionController
	if v257 ~= nil then
		local v258 = p246:getActiveInputAttacherJoint()
		if v258 ~= nil and (v258.needsLowering and (v258.allowsLowering and (v_u_256.allowsLowering and (v258.lowerDistanceToGround ~= v258.upperDistanceToGround or v251.lowerAnimation ~= nil)))) then
			v251.controlledAction = v257:registerAction("lower", InputAction.LOWER_IMPLEMENT, 2)
			v251.controlledAction:setCallback(p246, Attachable.actionControllerLowerImplementEvent)
			v251.controlledAction:setFinishedFunctions(p246, function()
				-- upvalues: (copy) v_u_256
				return v_u_256.moveDown
			end, true, false)
			v251.controlledAction:setIsSaved(true)
			v251.controlledAction:setIsAvailableFunction(function()
				return true
			end)
			v251.controlledAction:setIsAccessibleFunction(function()
				return true
			end)
			if p246:getAINeedsLowering() then
				v251.controlledAction:addAIEventListener(p246, "onAIImplementStartLine", 1, true)
				v251.controlledAction:addAIEventListener(p246, "onAIImplementEndLine", -1)
				v251.controlledAction:addAIEventListener(p246, "onAIImplementStart", -1)
				v251.controlledAction:addAIEventListener(p246, "onAIImplementPrepareForTransport", -1)
			end
		end
	end
	SpecializationUtil.raiseEvent(p246, "onPostAttach", p247, p248, p249, p250)
end
function Attachable.preDetach(p259, p260, p261)
	local v262 = p259.spec_attachable
	if v262.controlledAction ~= nil then
		v262.controlledAction:remove()
		v262.controlledAction = nil
	end
	SpecializationUtil.raiseEvent(p259, "onPreDetach", p260, p261)
end
function Attachable.postDetach(p263, _)
	local v264 = p263.spec_attachable
	p263:deactivate()
	ObjectChangeUtil.setObjectChanges(v264.attacherJoint.changeObjects, false, p263, p263.setMovingToolDirty)
	if v264.attacherJoint.steeringBarLeftNode ~= nil then
		p263:setMovingPartReferenceNode(v264.attacherJoint.steeringBarLeftNode, nil, false)
	end
	if v264.attacherJoint.steeringBarRightNode ~= nil then
		p263:setMovingPartReferenceNode(v264.attacherJoint.steeringBarRightNode, nil, false)
	end
	if v264.attacherJoint.drawbarNode ~= nil then
		p263:setMovingPartReferenceNode(v264.attacherJoint.drawbarNode, nil, false)
	end
	if p263.playAnimation ~= nil then
		for _, v265 in ipairs(v264.supportAnimations) do
			if p263:getIsSupportAnimationAllowed(v265) then
				if v265.detachAfterAnimation then
					if p263:getAnimationTime(v265.animationName) < 1 then
						p263:playAnimation(v265.animationName, 1, nil, true)
					end
				else
					p263:playAnimation(v265.animationName, 1, nil, true)
				end
			end
		end
		if v264.lowerAnimation ~= nil and v264.lowerAnimationDirectionOnDetach ~= 0 then
			p263:playAnimation(v264.lowerAnimation, v264.lowerAnimationDirectionOnDetach, nil, true)
		end
	end
	p263:attachableRemoveToolCameras()
	for _, v266 in ipairs(v264.attacherJoint.additionalObjects) do
		setVisibility(v266.node, false)
	end
	if v264.attacherJoint.bottomArm ~= nil and v264.attacherJoint.bottomArm.ballsNode ~= nil then
		setVisibility(v264.attacherJoint.bottomArm.ballsNode, v264.attacherJoint.bottomArm.ballDefaultVisibility)
	end
	v264.attacherVehicle = nil
	v264.attacherJoint = nil
	v264.attacherJointIndex = nil
	v264.inputAttacherJointDescIndex = nil
	SpecializationUtil.raiseEvent(p263, "onPostDetach")
end
function Attachable.setLowered(p267, p268)
	local v269 = p267.spec_attachable
	if v269.lowerAnimation ~= nil and p267.playAnimation ~= nil then
		local v270 = p267:getAnimationTime(v269.lowerAnimation)
		if p268 and v270 < 1 then
			p267:playAnimation(v269.lowerAnimation, v269.lowerAnimationSpeed, v270, true)
		elseif not p268 and v270 > 0 then
			p267:playAnimation(v269.lowerAnimation, -v269.lowerAnimationSpeed, v270, true)
		end
	end
	if v269.attacherJoint ~= nil then
		for _, v271 in pairs(v269.attacherJoint.dependentAttacherJoints) do
			if p267.getAttacherJoints == nil then
				Logging.xmlWarning(p267.xmlFile, "Failed to lower dependent attacher joint index \'%d\', AttacherJoint specialization is missing!", v271)
			elseif p267:getAttacherJoints()[v271] == nil then
				Logging.xmlWarning(p267.xmlFile, "Failed to lower dependent attacher joint index \'%d\', No attacher joint defined!", v271)
			else
				p267:setJointMoveDown(v271, p268, true)
			end
		end
	end
	SpecializationUtil.raiseEvent(p267, "onSetLowered", p268)
end
function Attachable.setLoweredAll(p272, p273, p274)
	p272:getAttacherVehicle():handleLowerImplementByAttacherJointIndex(p274, p273)
	SpecializationUtil.raiseEvent(p272, "onSetLoweredAll", p273, p274)
end
function Attachable.setToolBottomArmWidthByIndex(p275, p276, p277)
	local v278 = p275:getInputAttacherJointByJointDescIndex(p276)
	if v278 ~= nil and (v278.bottomArm ~= nil and v278.bottomArm.ballsNodeLeft ~= nil) then
		local v279 = v278.bottomArm.widths[p277] or 0.5
		setTranslation(v278.bottomArm.ballsNodeLeft, v279 * 0.5, 0, 0)
		setTranslation(v278.bottomArm.ballsNodeRight, -v279 * 0.5, 0, 0)
		local v280 = AttacherJoints.getClosestLowerLinkCategoryIndex(v279)
		local _ = AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY[v280] or 0.056
	end
end
function Attachable.updateInputAttacherJointGraphics(p281, p282, p283)
	if not p282.attachingIsInProgress then
		local v284 = p281:getAttacherVehicle():getAttacherJointByJointDescIndex(p282.jointDescIndex)
		local v285 = p281:getInputAttacherJointByJointDescIndex(p282.inputJointDescIndex)
		if v285 ~= nil then
			if v285.steeringBarLeftNode ~= nil and v284.steeringBarLeftNode ~= nil then
				p281:updateMovingPartByNode(v285.steeringBarLeftNode, p283)
			end
			if v285.steeringBarRightNode ~= nil and v284.steeringBarRightNode ~= nil then
				p281:updateMovingPartByNode(v285.steeringBarRightNode, p283)
			end
			if v285.drawbarNode ~= nil then
				p281:updateMovingPartByNode(v285.drawbarNode, p283)
			end
		end
	end
end
function Attachable.setIsAdditionalAttachment(p286, p287, p288)
	local v289 = p286.spec_attachable
	v289.isAdditionalAttachment = true
	v289.additionalAttachmentNeedsLowering = p287
	if p288 then
		p286:requestActionEventUpdate()
		if not p287 and v289.controlledAction ~= nil then
			v289.controlledAction:remove()
		end
	end
end
function Attachable.getIsAdditionalAttachment(p290)
	return p290.spec_attachable.isAdditionalAttachment
end
function Attachable.setIsSupportVehicle(p291, p292)
	p291.spec_attachable.isSupportVehicle = p292 == nil and true or p292
end
function Attachable.getIsSupportVehicle(p293)
	return p293.spec_attachable.isSupportVehicle
end
function Attachable.registerLoweringActionEvent(p294, p295, p296, p297, p298, p299, p300, p301, p302, p303, p304)
	return p294:addPoweredActionEvent(p295, p296, p297, p298, p299, p300, p301, p302, p303, p304)
end
function Attachable.getLoweringActionEventState(p305)
	local v306 = p305:getAttacherVehicle()
	local v307
	if v306 == nil then
		v307 = false
	else
		local v308 = v306:getAttacherJointDescFromObject(p305)
		local v309 = p305:getActiveInputAttacherJoint()
		v307 = v308.allowsLowering
		if v307 then
			v307 = v309.allowsLowering
		end
	end
	local v310 = p305.spec_attachable
	local v311
	if p305:getIsLowered() then
		v311 = string.format(v310.texts.liftObject, p305.typeDesc)
	else
		v311 = string.format(v310.texts.lowerObject, p305.typeDesc)
	end
	return v307, v311
end
function Attachable.getAllowMultipleAttachments(_)
	return false
end
function Attachable.resolveMultipleAttachments(_) end
function Attachable.getBlockFoliageDestruction(p312)
	return p312.spec_attachable.blockFoliageDestruction
end
function Attachable.setIsDetachingBlocked(p313, p314)
	p313.spec_attachable.isDetachingBlocked = p314
end
function Attachable.onDeactivate(p315)
	if p315.brake ~= nil then
		local v316 = p315:getBrakeForce()
		if v316 > 0 then
			p315:brake(v316, true)
		end
	end
	if p315.isClient then
		local v317 = p315.spec_attachable
		if v317.isActiveSamplePlaying then
			g_soundManager:stopSamples(v317.samples.active)
			v317.isActiveSamplePlaying = false
		end
	end
end
function Attachable.onSelect(p318, _)
	local v319 = p318:getAttacherVehicle()
	if v319 ~= nil then
		v319:setSelectedImplementByObject(p318)
	end
end
function Attachable.onUnselect(p320)
	local v321 = p320:getAttacherVehicle()
	if v321 ~= nil then
		v321:setSelectedImplementByObject(nil)
	end
end
function Attachable.findRootVehicle(p322, p323)
	local v324 = p322.spec_attachable
	if v324.attacherVehicle == nil then
		return p323(p322)
	else
		return v324.attacherVehicle:findRootVehicle()
	end
end
function Attachable.getIsActive(p325, p326)
	if p326(p325) then
		return true
	else
		local v327 = p325.spec_attachable
		if v327.attacherVehicle == nil then
			return false
		else
			return v327.attacherVehicle:getIsActive()
		end
	end
end
function Attachable.getIsOperating(p328, p329)
	local v330 = p328.spec_attachable
	local v331 = p329(p328)
	if not v331 and v330.attacherVehicle ~= nil then
		v331 = v330.attacherVehicle:getIsOperating()
	end
	return v331
end
function Attachable.getBrakeForce(p332, p333)
	local v334 = p333(p332)
	local v335 = p332.spec_attachable
	local v336 = v335.brakeForce
	if v335.maxBrakeForceMass > 0 then
		local v337 = (p332:getTotalMass(not v335.maxBrakeForceMassIncludeAttachables) - p332.defaultMass) / (v335.maxBrakeForceMass - p332.defaultMass)
		local v338 = math.max(v337, 0)
		local v339 = math.min(v338, 1)
		v336 = MathUtil.lerp(v335.brakeForce, v335.maxBrakeForce, v339)
	end
	if v335.loweredBrakeForce >= 0 and p332:getIsLowered(false) then
		v336 = v335.loweredBrakeForce
	end
	return math.max(v334, v336)
end
function Attachable.getIsFoldAllowed(p340, p341, _, _)
	local v342 = p340.spec_attachable
	if v342.allowFoldingWhileAttached or p340:getAttacherVehicle() == nil then
		if v342.allowFoldingWhileLowered or not p340:getIsLowered() then
			if v342.attacherJoint == nil or v342.attacherJoint.allowFolding then
				return p341(p340)
			else
				return false, v342.texts.warningFoldingAttacherJoint
			end
		else
			return false, v342.texts.warningFoldingLowered
		end
	else
		return false, v342.texts.warningFoldingAttached
	end
end
function Attachable.getCanToggleTurnedOn(p343, p344)
	local v345 = p343:getAttacherVehicle()
	if v345 ~= nil then
		local v346 = v345:getAttacherJointDescFromObject(p343)
		if v346 ~= nil and not v346.canTurnOnImplement then
			return false
		end
	end
	local v347 = p343.spec_attachable
	if v347.attacherJoint == nil or v347.attacherJoint.allowTurnOn then
		return p344(p343)
	else
		return false
	end
end
function Attachable.getCanImplementBeUsedForAI(p348, p349)
	local v350 = p348.spec_attachable
	if v350.attacherJoint == nil or v350.attacherJoint.allowAI then
		if v350.detachingInProgress then
			return false
		else
			return p349(p348)
		end
	else
		return false
	end
end
function Attachable.getDeactivateOnLeave(p351, p352)
	local v353 = p351:getAttacherVehicle()
	if v353 == nil or v353:getDeactivateOnLeave() then
		return p352(p351)
	else
		return false
	end
end
function Attachable.getCanAIImplementContinueWork(p354, p355, p356)
	local v357, v358, v359 = p355(p354, p356)
	if not v357 then
		return false, v358, v359
	end
	local v360 = p354.spec_attachable
	local v361
	if v360.lowerAnimation == nil then
		v361 = true
	else
		local v362 = p354:getAnimationTime(v360.lowerAnimation)
		v361 = v362 ~= 1 and v362 ~= 0 and p354:getIsAnimationPlaying(v360.lowerAnimation)
		if v361 then
			v361 = p354:getAnimationSpeed(v360.lowerAnimation) < 0
		end
	end
	if v360.attacherVehicle ~= nil then
		local v363 = v360.attacherVehicle:getAttacherJointDescFromObject(p354)
		if v363.allowsLowering and (p354:getAINeedsLowering() and v363.moveDown) then
			if v363.moveAlpha ~= v363.lowerAlpha and v363.moveAlpha ~= v363.upperAlpha then
				v361 = false
			end
		end
	end
	return v361
end
function Attachable.getAreControlledActionsAllowed(p364, p365)
	local v366 = p364.spec_attachable
	for v367 = 1, #v366.supportAnimations do
		if p364:getIsAnimationPlaying(v366.supportAnimations[v367].animationName) then
			return false
		end
	end
	return p365(p364)
end
function Attachable.getActiveFarm(p368, p369)
	local v370 = p368.spec_attachable
	if p368.spec_enterable == nil or p368.spec_enterable.controllerFarmId == 0 then
		if v370.attacherVehicle == nil then
			return p369(p368)
		else
			return v370.attacherVehicle:getActiveFarm()
		end
	else
		return p369(p368)
	end
end
function Attachable.getCanBeSelected(_, _)
	return true
end
function Attachable.getIsLowered(p371, p372, p373)
	local v374 = p371:getAttacherVehicle()
	if v374 ~= nil then
		local v375 = v374:getAttacherJointDescFromObject(p371)
		if v375 ~= nil then
			if v375.allowsLowering or v375.isDefaultLowered then
				return v375.moveDown
			else
				return p373
			end
		end
	end
	return p372(p371, p373)
end
function Attachable.mountDynamic(p376, p377, p378, p379, p380, p381, p382)
	if p376.spec_attachable.attacherVehicle == nil then
		return p377(p376, p378, p379, p380, p381, p382)
	else
		return false
	end
end
function Attachable.getOwnerConnection(p383, p384)
	local v385 = p383.spec_attachable
	if v385.attacherVehicle == nil then
		return p384(p383)
	else
		return v385.attacherVehicle:getOwnerConnection()
	end
end
function Attachable.getIsInUse(p386, p387, p388)
	local v389 = p386:getAttacherVehicle()
	if v389 == nil then
		return p387(p386, p388)
	else
		return v389:getIsInUse(p388)
	end
end
function Attachable.getUpdatePriority(p390, p391, p392, p393, p394, p395, p396, p397, p398)
	local v399 = p390:getAttacherVehicle()
	if v399 == nil then
		return p391(p390, p392, p393, p394, p395, p396, p397)
	else
		return v399:getUpdatePriority(p392, p393, p394, p395, p396, p397, p398)
	end
end
function Attachable.getCanBeReset(p400, p401)
	if p400:getIsAdditionalAttachment() then
		return false
	elseif p400:getIsSupportVehicle() then
		return false
	else
		return p401(p400)
	end
end
function Attachable.loadAdditionalLightAttributesFromXML(p402, p403, p404, p405, p406)
	if not p403(p402, p404, p405, p406) then
		return false
	end
	p406.inputAttacherJointIndex = p404:getValue(p405 .. "#inputAttacherJointIndex")
	return true
end
function Attachable.getIsLightActive(p407, p408, p409)
	if p409.inputAttacherJointIndex == nil or p409.inputAttacherJointIndex == p407:getActiveInputAttacherJointDescIndex() then
		return p408(p407, p409)
	else
		return false
	end
end
function Attachable.getIsPowered(p410, p411)
	local v412 = p410:getAttacherVehicle()
	if v412 == nil then
		local v413 = p410.spec_attachable
		if v413.requiresExternalPower and not SpecializationUtil.hasSpecialization(Motorized, p410.specializations) then
			return false, v413.attachToPowerWarning
		end
	else
		local v414, v415 = v412:getIsPowered()
		if not v414 then
			return v414, v415
		end
	end
	return p411(p410)
end
function Attachable.getConnectionHoseConfigIndex(p416, p417)
	local v418 = p417(p416)
	local v419 = p416.xmlFile:getValue("vehicle.attachable#connectionHoseConfigId", v418)
	if p416.configurations.inputAttacherJoint ~= nil then
		local v420 = string.format("vehicle.attachable.inputAttacherJointConfigurations.inputAttacherJointConfiguration(%d)", p416.configurations.inputAttacherJoint - 1)
		v419 = p416.xmlFile:getValue(v420 .. "#connectionHoseConfigId", v419)
	end
	return v419
end
function Attachable.getIsMapHotspotVisible(p421, p422)
	if p422(p421) then
		if p421:getIsAdditionalAttachment() then
			return false
		elseif p421:getIsSupportVehicle() then
			return false
		else
			return p421:getShowAttachableMapHotspot()
		end
	else
		return false
	end
end
function Attachable.getPowerTakeOffConfigIndex(p423, p424)
	local v425 = p424(p423)
	local v426 = p423.xmlFile:getValue("vehicle.attachable#powerTakeOffConfigId", v425)
	if p423.configurations.inputAttacherJoint ~= nil then
		local v427 = string.format("vehicle.attachable.inputAttacherJointConfigurations.inputAttacherJointConfiguration(%d)", p423.configurations.inputAttacherJoint - 1)
		v426 = p423.xmlFile:getValue(v427 .. "#powerTakeOffConfigId", v426)
	end
	return v426
end
function Attachable.loadDashboardGroupFromXML(p428, p429, p430, p431, p432)
	if not p429(p428, p430, p431, p432) then
		return false
	end
	p432.isAttached = p430:getValue(p431 .. "#isAttached")
	return true
end
function Attachable.getIsDashboardGroupActive(p433, p434, p435)
	if p435.isAttached == nil or p435.isAttached == (p433:getAttacherVehicle() ~= nil) then
		return p434(p433, p435)
	else
		return false
	end
end
function Attachable.setWorldPositionQuaternion(p436, p437, p438, p439, p440, p441, p442, p443, p444, p445, p446)
	if p436.isServer then
		return p437(p436, p438, p439, p440, p441, p442, p443, p444, p445, p446)
	end
	if not p436.spec_attachable.isHardAttached then
		return p437(p436, p438, p439, p440, p441, p442, p443, p444, p445, p446)
	end
end
function Attachable.addToPhysics(p447, p448)
	if not p448(p447) then
		return false
	end
	local v449 = p447.spec_attachable
	local v450 = p447:getAttacherVehicle()
	if v450 ~= nil then
		if v450.isAddedToPhysics then
			local v451 = v450:getImplementByObject(p447)
			if v451 ~= nil and not v449.isHardAttached then
				v450:createAttachmentJoint(v451, true)
			end
		elseif v449.isHardAttached then
			p447.isAddedToPhysics = false
			if p447.isServer then
				removeWakeUpReport(p447.rootNode)
			end
		end
	end
	return true
end
function Attachable.removeFromPhysics(p452, p453)
	local v454 = p452.spec_attachable
	local v455 = p452:getAttacherVehicle()
	if v455 ~= nil and v455.isAddedToPhysics then
		local v456 = v455:getImplementByObject(p452)
		if v456 ~= nil and not v454.isHardAttached then
			local v457 = v455.spec_attacherJoints.attacherJoints[v456.jointDescIndex]
			if v457.jointIndex ~= 0 then
				v457.jointIndex = 0
			end
		end
	end
	return p453(p452)
end
function Attachable.actionControllerLowerImplementEvent(p458, p459)
	local v460 = p458.spec_attachable
	if not p458:getAllowsLowering() then
		return false
	end
	local v461 = p459 >= 0
	local v462 = v460.attacherVehicle:getAttacherJointIndexFromObject(p458)
	if v460.attacherVehicle:getJointMoveDown(v462) ~= v461 then
		v460.attacherVehicle:setJointMoveDown(v462, v461, false)
	end
	return true
end
function Attachable.onStateChange(p463, p464, _)
	if p463.getAILowerIfAnyIsLowered ~= nil and p463:getAILowerIfAnyIsLowered() then
		if p464 == VehicleStateChange.AI_START_LINE then
			Attachable.actionControllerLowerImplementEvent(p463, 1)
			return
		end
		if p464 == VehicleStateChange.AI_END_LINE then
			Attachable.actionControllerLowerImplementEvent(p463, -1)
		end
	end
end
function Attachable.onRootVehicleChanged(p465, p466)
	local v467 = p465.spec_attachable
	local v468 = p466.actionController
	if v468 ~= nil and v467.controlledAction ~= nil then
		v467.controlledAction:updateParent(v468)
	end
end
function Attachable.onFoldStateChanged(p469, p470, p471)
	local v472 = p469.spec_foldable
	if v472.foldMiddleAnimTime ~= nil then
		if not p471 and p470 == v472.turnOnFoldDirection then
			SpecializationUtil.raiseEvent(p469, "onSetLowered", true)
			return
		end
		SpecializationUtil.raiseEvent(p469, "onSetLowered", false)
	end
end
function Attachable.onRegisterAnimationValueTypes(p_u_473)
	local function v477(p474, p475, p476)
		p474.inputAttacherJointIndex = p475:getValue(p476 .. "#inputAttacherJointIndex")
		if p474.inputAttacherJointIndex == nil then
			return false
		end
		p474:setWarningInformation("inputAttacherJointIndex: " .. p474.inputAttacherJointIndex)
		p474:addCompareParameters("inputAttacherJointIndex")
		return true
	end
	local function v_u_479(...)
		-- upvalues: (copy) p_u_473
		if p_u_473.isServer then
			local v478 = p_u_473:getAttacherVehicle()
			if v478 ~= nil then
				v478:updateAttacherJointSettingsByObject(p_u_473, ...)
			end
		end
	end
	p_u_473:registerAnimationValueType("lowerRotLimitScale", "lowerRotLimitScaleStart", "lowerRotLimitScaleEnd", false, AnimationValueFloat, v477, function(p480)
		-- upvalues: (copy) p_u_473
		if p480.inputAttacherJointIndex ~= nil and p480.inputAttacherJoint == nil then
			p480.inputAttacherJoint = p_u_473:getInputAttacherJointByJointDescIndex(p480.inputAttacherJointIndex)
			if p480.inputAttacherJoint == nil then
				Logging.xmlWarning(p_u_473.xmlFile, "Unknown inputAttacherJointIndex \'%s\' for animation part.", p480.inputAttacherJointIndex)
				p480.inputAttacherJointIndex = nil
			end
		end
		if p480.inputAttacherJoint == nil then
			return 0, 0, 0
		end
		local v481 = p480.inputAttacherJoint.lowerRotLimitScale
		return unpack(v481)
	end, function(p482, p483, p484, p485)
		-- upvalues: (copy) v_u_479
		if p482.inputAttacherJoint ~= nil then
			p482.inputAttacherJoint.lowerRotLimitScale[1] = p483
			p482.inputAttacherJoint.lowerRotLimitScale[2] = p484
			p482.inputAttacherJoint.lowerRotLimitScale[3] = p485
			v_u_479(true)
		end
	end)
	p_u_473:registerAnimationValueType("upperRotLimitScale", "upperRotLimitScaleStart", "upperRotLimitScaleEnd", false, AnimationValueFloat, v477, function(p486)
		-- upvalues: (copy) p_u_473
		if p486.inputAttacherJointIndex ~= nil and p486.inputAttacherJoint == nil then
			p486.inputAttacherJoint = p_u_473:getInputAttacherJointByJointDescIndex(p486.inputAttacherJointIndex)
			if p486.inputAttacherJoint == nil then
				Logging.xmlWarning(p_u_473.xmlFile, "Unknown inputAttacherJointIndex \'%s\' for animation part.", p486.inputAttacherJointIndex)
				p486.inputAttacherJointIndex = nil
			end
		end
		if p486.inputAttacherJoint == nil then
			return 0, 0, 0
		end
		local v487 = p486.inputAttacherJoint.upperRotLimitScale
		return unpack(v487)
	end, function(p488, p489, p490, p491)
		-- upvalues: (copy) v_u_479
		if p488.inputAttacherJoint ~= nil then
			p488.inputAttacherJoint.upperRotLimitScale[1] = p489
			p488.inputAttacherJoint.upperRotLimitScale[2] = p490
			p488.inputAttacherJoint.upperRotLimitScale[3] = p491
			v_u_479(true)
		end
	end)
	p_u_473:registerAnimationValueType("lowerTransLimitScale", "lowerTransLimitScaleStart", "lowerTransLimitScaleEnd", false, AnimationValueFloat, v477, function(p492)
		-- upvalues: (copy) p_u_473
		if p492.inputAttacherJointIndex ~= nil and p492.inputAttacherJoint == nil then
			p492.inputAttacherJoint = p_u_473:getInputAttacherJointByJointDescIndex(p492.inputAttacherJointIndex)
			if p492.inputAttacherJoint == nil then
				Logging.xmlWarning(p_u_473.xmlFile, "Unknown inputAttacherJointIndex \'%s\' for animation part.", p492.inputAttacherJointIndex)
				p492.inputAttacherJointIndex = nil
			end
		end
		if p492.inputAttacherJoint == nil then
			return 0, 0, 0
		end
		local v493 = p492.inputAttacherJoint.lowerTransLimitScale
		return unpack(v493)
	end, function(p494, p495, p496, p497)
		-- upvalues: (copy) v_u_479
		if p494.inputAttacherJoint ~= nil then
			p494.inputAttacherJoint.lowerTransLimitScale[1] = p495
			p494.inputAttacherJoint.lowerTransLimitScale[2] = p496
			p494.inputAttacherJoint.lowerTransLimitScale[3] = p497
			v_u_479(true)
		end
	end)
	p_u_473:registerAnimationValueType("upperTransLimitScale", "upperTransLimitScaleStart", "upperTransLimitScaleEnd", false, AnimationValueFloat, v477, function(p498)
		-- upvalues: (copy) p_u_473
		if p498.inputAttacherJointIndex ~= nil and p498.inputAttacherJoint == nil then
			p498.inputAttacherJoint = p_u_473:getInputAttacherJointByJointDescIndex(p498.inputAttacherJointIndex)
			if p498.inputAttacherJoint == nil then
				Logging.xmlWarning(p_u_473.xmlFile, "Unknown inputAttacherJointIndex \'%s\' for animation part.", p498.inputAttacherJointIndex)
				p498.inputAttacherJointIndex = nil
			end
		end
		if p498.inputAttacherJoint == nil then
			return 0, 0, 0
		end
		local v499 = p498.inputAttacherJoint.upperTransLimitScale
		return unpack(v499)
	end, function(p500, p501, p502, p503)
		-- upvalues: (copy) v_u_479
		if p500.inputAttacherJoint ~= nil then
			p500.inputAttacherJoint.upperTransLimitScale[1] = p501
			p500.inputAttacherJoint.upperTransLimitScale[2] = p502
			p500.inputAttacherJoint.upperTransLimitScale[3] = p503
			v_u_479(true)
		end
	end)
	p_u_473:registerAnimationValueType("lowerRotationOffset", "lowerRotationOffsetStart", "lowerRotationOffsetEnd", false, AnimationValueFloat, v477, function(p504)
		-- upvalues: (copy) p_u_473
		if p504.inputAttacherJointIndex ~= nil and p504.inputAttacherJoint == nil then
			p504.inputAttacherJoint = p_u_473:getInputAttacherJointByJointDescIndex(p504.inputAttacherJointIndex)
			if p504.inputAttacherJoint == nil then
				Logging.xmlWarning(p_u_473.xmlFile, "Unknown inputAttacherJointIndex \'%s\' for animation part.", p504.inputAttacherJointIndex)
				p504.inputAttacherJointIndex = nil
			end
		end
		return p504.inputAttacherJoint == nil and 0 or p504.inputAttacherJoint.lowerRotationOffset
	end, function(p505, p506)
		-- upvalues: (copy) v_u_479
		if p505.inputAttacherJoint ~= nil then
			p505.inputAttacherJoint.lowerRotationOffset = p506
			v_u_479(false, true)
		end
	end)
	p_u_473:registerAnimationValueType("upperRotationOffset", "upperRotationOffsetStart", "upperRotationOffsetEnd", false, AnimationValueFloat, v477, function(p507)
		-- upvalues: (copy) p_u_473
		if p507.inputAttacherJointIndex ~= nil and p507.inputAttacherJoint == nil then
			p507.inputAttacherJoint = p_u_473:getInputAttacherJointByJointDescIndex(p507.inputAttacherJointIndex)
			if p507.inputAttacherJoint == nil then
				Logging.xmlWarning(p_u_473.xmlFile, "Unknown inputAttacherJointIndex \'%s\' for animation part.", p507.inputAttacherJointIndex)
				p507.inputAttacherJointIndex = nil
			end
		end
		return p507.inputAttacherJoint == nil and 0 or p507.inputAttacherJoint.upperRotationOffset
	end, function(p508, p509)
		-- upvalues: (copy) v_u_479
		if p508.inputAttacherJoint ~= nil then
			p508.inputAttacherJoint.upperRotationOffset = p509
			v_u_479(false, true)
		end
	end)
	p_u_473:registerAnimationValueType("lowerDistanceToGround", "lowerDistanceToGroundStart", "lowerDistanceToGroundEnd", false, AnimationValueFloat, v477, function(p510)
		-- upvalues: (copy) p_u_473
		if p510.inputAttacherJointIndex ~= nil and p510.inputAttacherJoint == nil then
			p510.inputAttacherJoint = p_u_473:getInputAttacherJointByJointDescIndex(p510.inputAttacherJointIndex)
			if p510.inputAttacherJoint == nil then
				Logging.xmlWarning(p_u_473.xmlFile, "Unknown inputAttacherJointIndex \'%s\' for animation part.", p510.inputAttacherJointIndex)
				p510.inputAttacherJointIndex = nil
			end
		end
		return p510.inputAttacherJoint == nil and 0 or p510.inputAttacherJoint.lowerDistanceToGround
	end, function(p511, p512)
		-- upvalues: (copy) v_u_479
		if p511.inputAttacherJoint ~= nil then
			p511.inputAttacherJoint.lowerDistanceToGround = p512
			v_u_479(false, false, true)
		end
	end)
	p_u_473:registerAnimationValueType("upperDistanceToGround", "upperDistanceToGroundStart", "upperDistanceToGroundEnd", false, AnimationValueFloat, v477, function(p513)
		-- upvalues: (copy) p_u_473
		if p513.inputAttacherJointIndex ~= nil and p513.inputAttacherJoint == nil then
			p513.inputAttacherJoint = p_u_473:getInputAttacherJointByJointDescIndex(p513.inputAttacherJointIndex)
			if p513.inputAttacherJoint == nil then
				Logging.xmlWarning(p_u_473.xmlFile, "Unknown inputAttacherJointIndex \'%s\' for animation part.", p513.inputAttacherJointIndex)
				p513.inputAttacherJointIndex = nil
			end
		end
		return p513.inputAttacherJoint == nil and 0 or p513.inputAttacherJoint.upperDistanceToGround
	end, function(p514, p515)
		-- upvalues: (copy) v_u_479
		if p514.inputAttacherJoint ~= nil then
			p514.inputAttacherJoint.upperDistanceToGround = p515
			v_u_479(false, false, true)
		end
	end)
end
function Attachable.onBottomArmBallsI3DLoaded(_, p516, _, p517)
	if p516 ~= 0 then
		local v518 = getChildAt(p516, 0)
		if getNumOfChildren(v518) == 3 then
			link(p517.node, v518)
			setTranslation(v518, 0, 0, 0)
			setRotation(v518, 0, 1.5707963267948966, 0)
			p517.bottomArm.ballsNode = v518
			p517.bottomArm.ballsNodeLeft = getChildAt(v518, 0)
			p517.bottomArm.ballsNodeRight = getChildAt(v518, 1)
			p517.bottomArm.ballsNodeTop = getChildAt(v518, 2)
			local v519 = p517.bottomArm.widths[#p517.bottomArm.widths]
			setTranslation(p517.bottomArm.ballsNodeLeft, v519 * 0.5, 0, 0)
			setTranslation(p517.bottomArm.ballsNodeRight, -v519 * 0.5, 0, 0)
			setVisibility(p517.bottomArm.ballsNode, p517.bottomArm.ballDefaultVisibility)
			setVisibility(p517.bottomArm.ballsNodeTop, p517.topReferenceNode ~= nil)
			if p517.topReferenceNode ~= nil then
				link(p517.topReferenceNode, p517.bottomArm.ballsNodeTop)
			end
		else
			Logging.warning("Loaded balls i3d node has wrong amount of nodes. One root node with 3 (left, right, top) ball nodes is required! (%s)", p517.bottomArm.ballFilename)
		end
		delete(p516)
	end
end

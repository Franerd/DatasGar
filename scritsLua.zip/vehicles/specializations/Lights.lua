source("dataS/scripts/vehicles/specializations/events/VehicleSetBeaconLightEvent.lua")
source("dataS/scripts/vehicles/specializations/events/VehicleSetTurnLightEvent.lua")
source("dataS/scripts/vehicles/specializations/events/VehicleSetLightEvent.lua")
source("dataS/scripts/vehicles/specializations/components/SharedLight.lua")
source("dataS/scripts/vehicles/specializations/components/BeaconLight.lua")
source("dataS/scripts/vehicles/specializations/components/StaticLight.lua")
source("dataS/scripts/vehicles/specializations/components/StaticLightCompound.lua")
source("dataS/scripts/vehicles/specializations/components/RealLight.lua")
Lights = {}
Lights.TURNLIGHT_OFF = 0
Lights.TURNLIGHT_LEFT = 1
Lights.TURNLIGHT_RIGHT = 2
Lights.TURNLIGHT_HAZARD = 3
Lights.turnLightSendNumBits = 3
Lights.LIGHT_TYPE_DEFAULT = 0
Lights.LIGHT_TYPE_WORK_BACK = 1
Lights.LIGHT_TYPE_WORK_FRONT = 2
Lights.LIGHT_TYPE_HIGHBEAM = 3
Lights.sharedLightXMLSchema = nil
Lights.beaconLightXMLSchema = nil
Lights.ADDITIONAL_LIGHT_ATTRIBUTES_KEYS = {
	"vehicle.lights.sharedLight(?)",
	"vehicle.lights.realLights.low.light(?)",
	"vehicle.lights.realLights.low.topLight(?)",
	"vehicle.lights.realLights.low.bottomLight(?)",
	"vehicle.lights.realLights.low.brakeLight(?)",
	"vehicle.lights.realLights.low.reverseLight(?)",
	"vehicle.lights.realLights.low.turnLightLeft(?)",
	"vehicle.lights.realLights.low.turnLightRight(?)",
	"vehicle.lights.realLights.low.interiorLight(?)",
	"vehicle.lights.realLights.high.light(?)",
	"vehicle.lights.realLights.high.topLight(?)",
	"vehicle.lights.realLights.high.bottomLight(?)",
	"vehicle.lights.realLights.high.brakeLight(?)",
	"vehicle.lights.realLights.high.reverseLight(?)",
	"vehicle.lights.realLights.high.turnLightLeft(?)",
	"vehicle.lights.realLights.high.turnLightRight(?)",
	"vehicle.lights.realLights.high.interiorLight(?)",
	"vehicle.lights.defaultLights.defaultLight(?)",
	"vehicle.lights.topLights.topLight(?)",
	"vehicle.lights.bottomLights.bottomLight(?)",
	"vehicle.lights.brakeLights.brakeLight(?)",
	"vehicle.lights.reverseLights.reverseLight(?)",
	"vehicle.lights.dayTimeLights.dayTimeLight(?)",
	"vehicle.lights.turnLights.turnLightLeft(?)",
	"vehicle.lights.turnLights.turnLightRight(?)",
	"vehicle.lights.staticLightCompounds.staticLightCompound(?).node(?)"
}
function Lights.prerequisitesPresent(_)
	return true
end
function Lights.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("beaconLight", g_i18n:getText("configuration_beacon"), "lights", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Lights")
	v1:register(XMLValueType.FLOAT, "vehicle.lights#reverseLightActivationSpeed", "Speed which needs to be reached to activate reverse lights (km/h)", 1)
	v1:register(XMLValueType.VECTOR_N, "vehicle.lights.states.state(?)#lightTypes", "Light states")
	v1:register(XMLValueType.VECTOR_N, "vehicle.lights.states.automaticState#lightTypes", "Light states while ai is active", "0")
	v1:register(XMLValueType.VECTOR_N, "vehicle.lights.states.automaticState#lightTypesWork", "Light states while ai is working", "0 1 2")
	SharedLight.registerXMLPaths(v1, "vehicle.lights.sharedLight(?)")
	Lights.registerRealLightSetupXMLPath(v1, "vehicle.lights.realLights.low")
	Lights.registerRealLightSetupXMLPath(v1, "vehicle.lights.realLights.high")
	StaticLight.registerXMLPaths(v1, "vehicle.lights.defaultLights.defaultLight(?)")
	StaticLight.registerXMLPaths(v1, "vehicle.lights.topLights.topLight(?)")
	StaticLight.registerXMLPaths(v1, "vehicle.lights.bottomLights.bottomLight(?)")
	StaticLight.registerXMLPaths(v1, "vehicle.lights.brakeLights.brakeLight(?)")
	StaticLight.registerXMLPaths(v1, "vehicle.lights.reverseLights.reverseLight(?)")
	StaticLight.registerXMLPaths(v1, "vehicle.lights.dayTimeLights.dayTimeLight(?)")
	StaticLight.registerXMLPaths(v1, "vehicle.lights.turnLights.turnLightLeft(?)")
	StaticLight.registerXMLPaths(v1, "vehicle.lights.turnLights.turnLightRight(?)")
	StaticLightCompound.registerXMLPaths(v1, "vehicle.lights.staticLightCompounds.staticLightCompound(?)")
	BeaconLight.registerVehicleXMLPaths(v1, "vehicle.lights.beaconLights.beaconLight(?)")
	v1:register(XMLValueType.BOOL, "vehicle.lights.beaconLights.beaconLight(?)#alwaysActive", "Defines if the beacon light is always active while the vehicle is entered", false)
	BeaconLight.registerVehicleXMLPaths(v1, "vehicle.lights.beaconLightConfigurations.beaconLightConfiguration(?).beaconLight(?)")
	v1:register(XMLValueType.BOOL, "vehicle.lights.beaconLightConfigurations.beaconLightConfiguration(?).beaconLight(?)#alwaysActive", "Defines if the beacon light is always active while the vehicle is entered", false)
	SoundManager.registerSampleXMLPaths(v1, "vehicle.lights.sounds", "toggleLights")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.lights.sounds", "turnLight")
	Dashboard.registerDashboardXMLPaths(v1, "vehicle.lights.dashboards", {
		"lightState",
		"turnLightLeft",
		"turnLightRight",
		"turnLight",
		"turnLightHazard",
		"turnLightAny",
		"beaconLight"
	})
	Dashboard.addDelayedRegistrationFunc(v1, function(p2, p3)
		p2:register(XMLValueType.VECTOR_N, p3 .. "#lightTypes", "Light types")
		p2:register(XMLValueType.VECTOR_N, p3 .. "#excludedLightTypes", "Excluded light types")
	end)
	for v4 = 1, #Lights.ADDITIONAL_LIGHT_ATTRIBUTES_KEYS do
		local v5 = Lights.ADDITIONAL_LIGHT_ATTRIBUTES_KEYS[v4]
		v1:register(XMLValueType.BOOL, v5 .. "#isTopLight", "Light is only active when switched to top light mode", false)
		v1:register(XMLValueType.BOOL, v5 .. "#isBottomLight", "Light is only active when not switched to top light mode", false)
	end
	v1:register(XMLValueType.VECTOR_N, Dashboard.GROUP_XML_KEY .. "#lightTypes", "Defined light types need to be enabled to activate group")
	v1:register(XMLValueType.VECTOR_N, Dashboard.GROUP_XML_KEY .. "#excludedLightTypes", "Defined light types need to be disabled to activate group")
	v1:setXMLSpecializationType()
end
function Lights.registerRealLightSetupXMLPath(p6, p7)
	RealLight.registerXMLPaths(p6, p7 .. ".light(?)")
	RealLight.registerXMLPaths(p6, p7 .. ".topLight(?)")
	RealLight.registerXMLPaths(p6, p7 .. ".bottomLight(?)")
	RealLight.registerXMLPaths(p6, p7 .. ".brakeLight(?)")
	RealLight.registerXMLPaths(p6, p7 .. ".reverseLight(?)")
	RealLight.registerXMLPaths(p6, p7 .. ".dayTimeLight(?)")
	RealLight.registerXMLPaths(p6, p7 .. ".turnLightLeft(?)")
	RealLight.registerXMLPaths(p6, p7 .. ".turnLightRight(?)")
	RealLight.registerXMLPaths(p6, p7 .. ".interiorLight(?)")
end
function Lights.registerEvents(p8)
	SpecializationUtil.registerEvent(p8, "onTurnLightStateChanged")
	SpecializationUtil.registerEvent(p8, "onTopLightsVisibilityChanged")
	SpecializationUtil.registerEvent(p8, "onBrakeLightsVisibilityChanged")
	SpecializationUtil.registerEvent(p8, "onReverseLightsVisibilityChanged")
	SpecializationUtil.registerEvent(p8, "onLightsTypesMaskChanged")
	SpecializationUtil.registerEvent(p8, "onBeaconLightsVisibilityChanged")
end
function Lights.registerFunctions(p9)
	SpecializationUtil.registerFunction(p9, "loadRealLightSetup", Lights.loadRealLightSetup)
	SpecializationUtil.registerFunction(p9, "applyAdditionalActiveLightType", Lights.applyAdditionalActiveLightType)
	SpecializationUtil.registerFunction(p9, "getIsActiveForLights", Lights.getIsActiveForLights)
	SpecializationUtil.registerFunction(p9, "getIsActiveForInteriorLights", Lights.getIsActiveForInteriorLights)
	SpecializationUtil.registerFunction(p9, "getCanToggleLight", Lights.getCanToggleLight)
	SpecializationUtil.registerFunction(p9, "getUseHighProfile", Lights.getUseHighProfile)
	SpecializationUtil.registerFunction(p9, "setNextLightsState", Lights.setNextLightsState)
	SpecializationUtil.registerFunction(p9, "setLightsTypesMask", Lights.setLightsTypesMask)
	SpecializationUtil.registerFunction(p9, "getLightsTypesMask", Lights.getLightsTypesMask)
	SpecializationUtil.registerFunction(p9, "setTurnLightState", Lights.setTurnLightState)
	SpecializationUtil.registerFunction(p9, "getTurnLightState", Lights.getTurnLightState)
	SpecializationUtil.registerFunction(p9, "setTopLightsVisibility", Lights.setTopLightsVisibility)
	SpecializationUtil.registerFunction(p9, "setBrakeLightsVisibility", Lights.setBrakeLightsVisibility)
	SpecializationUtil.registerFunction(p9, "setBeaconLightsVisibility", Lights.setBeaconLightsVisibility)
	SpecializationUtil.registerFunction(p9, "getBeaconLightsVisibility", Lights.getBeaconLightsVisibility)
	SpecializationUtil.registerFunction(p9, "setReverseLightsVisibility", Lights.setReverseLightsVisibility)
	SpecializationUtil.registerFunction(p9, "setInteriorLightsVisibility", Lights.setInteriorLightsVisibility)
	SpecializationUtil.registerFunction(p9, "getInteriorLightBrightness", Lights.getInteriorLightBrightness)
	SpecializationUtil.registerFunction(p9, "deactivateLights", Lights.deactivateLights)
	SpecializationUtil.registerFunction(p9, "getDeactivateLightsOnLeave", Lights.getDeactivateLightsOnLeave)
	SpecializationUtil.registerFunction(p9, "loadSharedLight", Lights.loadSharedLight)
	SpecializationUtil.registerFunction(p9, "loadAdditionalLightAttributesFromXML", Lights.loadAdditionalLightAttributesFromXML)
	SpecializationUtil.registerFunction(p9, "getIsLightActive", Lights.getIsLightActive)
	SpecializationUtil.registerFunction(p9, "getStaticLightFromNode", Lights.getStaticLightFromNode)
	SpecializationUtil.registerFunction(p9, "getRealLightFromNode", Lights.getRealLightFromNode)
	SpecializationUtil.registerFunction(p9, "updateAutomaticLights", Lights.updateAutomaticLights)
	SpecializationUtil.registerFunction(p9, "lightsWeatherChanged", Lights.lightsWeatherChanged)
	SpecializationUtil.registerFunction(p9, "deactivateBeaconLights", Lights.deactivateBeaconLights)
end
function Lights.registerOverwrittenFunctions(p10)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadDashboardGroupFromXML", Lights.loadDashboardGroupFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsDashboardGroupActive", Lights.getIsDashboardGroupActive)
end
function Lights.registerEventListeners(p11)
	SpecializationUtil.registerEventListener(p11, "onLoad", Lights)
	SpecializationUtil.registerEventListener(p11, "onLoadFinished", Lights)
	SpecializationUtil.registerEventListener(p11, "onRegisterDashboardValueTypes", Lights)
	SpecializationUtil.registerEventListener(p11, "onDelete", Lights)
	SpecializationUtil.registerEventListener(p11, "onReadStream", Lights)
	SpecializationUtil.registerEventListener(p11, "onWriteStream", Lights)
	SpecializationUtil.registerEventListener(p11, "onUpdate", Lights)
	SpecializationUtil.registerEventListener(p11, "onUpdateTick", Lights)
	SpecializationUtil.registerEventListener(p11, "onRegisterActionEvents", Lights)
	SpecializationUtil.registerEventListener(p11, "onRegisterExternalActionEvents", Lights)
	SpecializationUtil.registerEventListener(p11, "onEnterVehicle", Lights)
	SpecializationUtil.registerEventListener(p11, "onLeaveVehicle", Lights)
	SpecializationUtil.registerEventListener(p11, "onStartMotor", Lights)
	SpecializationUtil.registerEventListener(p11, "onStopMotor", Lights)
	SpecializationUtil.registerEventListener(p11, "onStartReverseDirectionChange", Lights)
	SpecializationUtil.registerEventListener(p11, "onPostAttach", Lights)
	SpecializationUtil.registerEventListener(p11, "onPostDetach", Lights)
	SpecializationUtil.registerEventListener(p11, "onAutomatedTrainTravelActive", Lights)
	SpecializationUtil.registerEventListener(p11, "onAIDriveableActive", Lights)
	SpecializationUtil.registerEventListener(p11, "onAIDriveableEnd", Lights)
	SpecializationUtil.registerEventListener(p11, "onAIFieldWorkerStart", Lights)
	SpecializationUtil.registerEventListener(p11, "onAIFieldWorkerActive", Lights)
	SpecializationUtil.registerEventListener(p11, "onAIJobVehicleBlock", Lights)
	SpecializationUtil.registerEventListener(p11, "onAIJobVehicleContinue", Lights)
	SpecializationUtil.registerEventListener(p11, "onAIFieldWorkerEnd", Lights)
	SpecializationUtil.registerEventListener(p11, "onVehiclePhysicsUpdate", Lights)
	SpecializationUtil.registerEventListener(p11, "onDeactivate", Lights)
	SpecializationUtil.registerEventListener(p11, "onRequiresTopLightsChanged", Lights)
end
function Lights.onLoad(p_u_12, _)
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.lights.low.light#decoration", "vehicle.lights.defaultLights#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.lights.high.light#decoration", "vehicle.lights.defaultLights#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.lights.low.light#realLight", "vehicle.lights.realLights.low.light#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.lights.high.light#realLight", "vehicle.lights.realLights.high.light#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.brakeLights.brakeLight#realLight", "vehicle.lights.realLights.high.brakeLight#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.brakeLights.brakeLight#decoration", "vehicle.lights.brakeLights.brakeLight#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.reverseLights.reverseLight#realLight", "vehicle.lights.realLights.high.reverseLight#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.reverseLights.reverseLight#decoration", "vehicle.lights.reverseLights.reverseLight#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.turnLights.turnLightLeft#realLight", "vehicle.lights.realLights.high.turnLightLeft#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.turnLights.turnLightLeft#decoration", "vehicle.lights.turnLights.turnLightLeft#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.turnLights.turnLightRight#realLight", "vehicle.lights.realLights.high.turnLightRight#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.turnLights.turnLightRight#decoration", "vehicle.lights.turnLights.turnLightRight#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.reverseLights.reverseLight#realLight", "vehicle.lights.realLights.high.reverseLight#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.reverseLights.reverseLight#decoration", "vehicle.lights.reverseLights.reverseLight#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.lights.states.aiState#lightTypes", "vehicle.lights.states.automaticState#lightTypes")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.lights.states.aiState#lightTypesWork", "vehicle.lights.states.automaticState#lightTypesWork")
	local v_u_13 = p_u_12.spec_lights
	v_u_13.reverseLightActivationSpeed = p_u_12.xmlFile:getValue("vehicle.lights#reverseLightActivationSpeed", 1) / 3600
	v_u_13.sharedLoadRequestIds = {}
	v_u_13.xmlLoadingHandles = {}
	v_u_13.lightsTypesMask = 0
	v_u_13.currentLightState = 0
	v_u_13.maxLightState = Lights.LIGHT_TYPE_HIGHBEAM
	v_u_13.numLightTypes = 0
	v_u_13.lightStates = {}
	v_u_13.lastIsActiveForLights = false
	local v14 = 0
	local v15 = {}
	while true do
		local v16 = string.format("vehicle.lights.states.state(%d)", v14)
		if not p_u_12.xmlFile:hasProperty(v16) then
			break
		end
		local v17 = p_u_12.xmlFile:getValue(v16 .. "#lightTypes", nil, true) or {}
		for _, v18 in pairs(v17) do
			if v15[v18] == nil then
				v15[v18] = v18
				v_u_13.numLightTypes = v_u_13.numLightTypes + 1
				local v19 = v_u_13.maxLightState
				v_u_13.maxLightState = math.max(v19, v18)
			end
		end
		local v20 = v_u_13.lightStates
		table.insert(v20, v17)
		v14 = v14 + 1
	end
	local function v27(p21, p22, p23)
		local v24 = p21:getValue(p22, p23, true)
		local v25 = 0
		for _, v26 in pairs(v24) do
			v25 = bitOR(v25, 2 ^ v26)
		end
		return v25
	end
	v_u_13.automaticLightsTypesMask = v27(p_u_12.xmlFile, "vehicle.lights.states.automaticState#lightTypes", "0")
	v_u_13.automaticLightsTypesMaskWork = v27(p_u_12.xmlFile, "vehicle.lights.states.automaticState#lightTypesWork", "0 1 2")
	v_u_13.interiorLightsBrightness = 0
	v_u_13.interiorLightsAvailable = false
	v_u_13.realLights = {}
	v_u_13.realLights.low = {}
	p_u_12:loadRealLightSetup(p_u_12.xmlFile, "vehicle.lights.realLights.low", v_u_13.realLights.low)
	v_u_13.realLights.high = {}
	p_u_12:loadRealLightSetup(p_u_12.xmlFile, "vehicle.lights.realLights.high", v_u_13.realLights.high)
	v_u_13.staticLights = {}
	v_u_13.staticLights.defaultLights = StaticLight.loadLightsFromXML(nil, p_u_12.xmlFile, "vehicle.lights.defaultLights.defaultLight", p_u_12, p_u_12.components, p_u_12.i3dMappings, true)
	v_u_13.staticLights.topLights = StaticLight.loadLightsFromXML(nil, p_u_12.xmlFile, "vehicle.lights.topLights.topLight", p_u_12, p_u_12.components, p_u_12.i3dMappings, false)
	v_u_13.staticLights.bottomLights = StaticLight.loadLightsFromXML(nil, p_u_12.xmlFile, "vehicle.lights.bottomLights.bottomLight", p_u_12, p_u_12.components, p_u_12.i3dMappings, false)
	v_u_13.staticLights.brakeLights = StaticLight.loadLightsFromXML(nil, p_u_12.xmlFile, "vehicle.lights.brakeLights.brakeLight", p_u_12, p_u_12.components, p_u_12.i3dMappings, false)
	v_u_13.staticLights.reverseLights = StaticLight.loadLightsFromXML(nil, p_u_12.xmlFile, "vehicle.lights.reverseLights.reverseLight", p_u_12, p_u_12.components, p_u_12.i3dMappings, false)
	v_u_13.staticLights.dayTimeLights = StaticLight.loadLightsFromXML(nil, p_u_12.xmlFile, "vehicle.lights.dayTimeLights.dayTimeLight", p_u_12, p_u_12.components, p_u_12.i3dMappings, false)
	v_u_13.staticLights.turnLightsLeft = StaticLight.loadLightsFromXML(nil, p_u_12.xmlFile, "vehicle.lights.turnLights.turnLightLeft", p_u_12, p_u_12.components, p_u_12.i3dMappings, false)
	v_u_13.staticLights.turnLightsRight = StaticLight.loadLightsFromXML(nil, p_u_12.xmlFile, "vehicle.lights.turnLights.turnLightRight", p_u_12, p_u_12.components, p_u_12.i3dMappings, false)
	v_u_13.staticLightCompounds = {}
	for _, v28 in p_u_12.xmlFile:iterator("vehicle.lights.staticLightCompounds.staticLightCompound") do
		local v29 = StaticLightCompound.new(p_u_12)
		if v29:loadFromXML(p_u_12.xmlFile, v28, p_u_12.components, p_u_12.i3dMappings, p_u_12) then
			local v30 = v_u_13.staticLightCompounds
			table.insert(v30, v29)
		end
	end
	v_u_13.sharedLights = {}
	p_u_12.xmlFile:iterate("vehicle.lights.sharedLight", function(_, p31)
		-- upvalues: (copy) p_u_12
		p_u_12:loadSharedLight(p_u_12.xmlFile, p31)
	end)
	for _, v32 in pairs(v_u_13.staticLights) do
		for _, v33 in ipairs(v32) do
			if v33.lightTypes ~= nil then
				local v34 = v_u_13.maxLightState
				local v35 = v33.lightTypes
				local v36 = unpack
				v_u_13.maxLightState = math.max(v34, v36(v35))
			end
		end
	end
	for _, v37 in pairs(v_u_13.realLights) do
		for _, v38 in pairs(v37) do
			for _, v39 in ipairs(v38) do
				if v39.lightTypes ~= nil then
					local v40 = v_u_13.maxLightState
					local v41 = v39.lightTypes
					local v42 = unpack
					v_u_13.maxLightState = math.max(v40, v42(v41))
				end
			end
		end
	end
	v_u_13.maxLightStateMask = 2 ^ (v_u_13.maxLightState + 1) - 1
	v_u_13.additionalLightTypes = {}
	v_u_13.additionalLightTypes.bottomLight = v_u_13.maxLightState + 1
	v_u_13.additionalLightTypes.topLight = v_u_13.maxLightState + 2
	v_u_13.additionalLightTypes.brakeLight = v_u_13.maxLightState + 3
	v_u_13.additionalLightTypes.turnLightLeft = v_u_13.maxLightState + 4
	v_u_13.additionalLightTypes.turnLightRight = v_u_13.maxLightState + 5
	v_u_13.additionalLightTypes.turnLightAny = v_u_13.maxLightState + 6
	v_u_13.additionalLightTypes.reverseLight = v_u_13.maxLightState + 7
	v_u_13.additionalLightTypes.interiorLight = v_u_13.maxLightState + 8
	v_u_13.totalNumLightTypes = v_u_13.additionalLightTypes.interiorLight + 1
	if v_u_13.totalNumLightTypes > 31 then
		Logging.xmlError(p_u_12.xmlFile, "Max. number of light types reached (31). Please reduce them.")
		v_u_13.totalNumLightTypes = 31
	end
	v_u_13.topLightsVisibility = false
	v_u_13.brakeLightsVisibility = false
	v_u_13.reverseLightsVisibility = false
	v_u_13.turnLightState = Lights.TURNLIGHT_OFF
	v_u_13.turnLightTriState = 0.5
	v_u_13.turnLightRepetitionCount = nil
	v_u_13.actionEventsActiveChange = {}
	v_u_13.beaconLightsActive = false
	v_u_13.beaconLights = {}
	v_u_13.alwaysActiveBeaconLights = {}
	local v43 = string.format("vehicle.lights.beaconLightConfigurations.beaconLightConfiguration(%d)", (p_u_12.configurations.beaconLight or 1) - 1)
	p_u_12.xmlFile:iterate(v43 .. ".beaconLight", function(_, p44)
		-- upvalues: (copy) p_u_12, (copy) v_u_13
		if p_u_12.xmlFile:hasProperty(p44 .. "#alwaysActive") then
			BeaconLight.loadFromVehicleXML(v_u_13.alwaysActiveBeaconLights, p_u_12.xmlFile, p44, p_u_12)
		else
			BeaconLight.loadFromVehicleXML(v_u_13.beaconLights, p_u_12.xmlFile, p44, p_u_12)
		end
	end)
	p_u_12.xmlFile:iterate("vehicle.lights.beaconLights.beaconLight", function(_, p45)
		-- upvalues: (copy) p_u_12, (copy) v_u_13
		if p_u_12.xmlFile:hasProperty(p45 .. "#alwaysActive") then
			BeaconLight.loadFromVehicleXML(v_u_13.alwaysActiveBeaconLights, p_u_12.xmlFile, p45, p_u_12)
		else
			BeaconLight.loadFromVehicleXML(v_u_13.beaconLights, p_u_12.xmlFile, p45, p_u_12)
		end
	end)
	if p_u_12.isClient ~= nil then
		v_u_13.samples = {}
		v_u_13.samples.toggleLights = g_soundManager:loadSampleFromXML(p_u_12.xmlFile, "vehicle.lights.sounds", "toggleLights", p_u_12.baseDirectory, p_u_12.components, 1, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
		v_u_13.samples.turnLight = g_soundManager:loadSampleFromXML(p_u_12.xmlFile, "vehicle.lights.sounds", "turnLight", p_u_12.baseDirectory, p_u_12.components, 1, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
	end
	if g_currentMission ~= nil and g_currentMission.environment ~= nil then
		g_messageCenter:subscribe(MessageType.DAY_NIGHT_CHANGED, p_u_12.lightsWeatherChanged, p_u_12)
	end
end
function Lights.onLoadFinished(p46, _)
	local v47 = p46.spec_lights
	p46:applyAdditionalActiveLightType(v47.staticLights.topLights, v47.additionalLightTypes.topLight)
	p46:applyAdditionalActiveLightType(v47.staticLights.bottomLights, v47.additionalLightTypes.bottomLight)
	p46:applyAdditionalActiveLightType(v47.staticLights.brakeLights, v47.additionalLightTypes.brakeLight)
	p46:applyAdditionalActiveLightType(v47.staticLights.reverseLights, v47.additionalLightTypes.reverseLight)
	p46:applyAdditionalActiveLightType(v47.staticLights.turnLightsLeft, v47.additionalLightTypes.turnLightLeft, true)
	p46:applyAdditionalActiveLightType(v47.staticLights.turnLightsLeft, v47.additionalLightTypes.turnLightAny, true)
	p46:applyAdditionalActiveLightType(v47.staticLights.turnLightsRight, v47.additionalLightTypes.turnLightRight, true)
	p46:applyAdditionalActiveLightType(v47.staticLights.turnLightsRight, v47.additionalLightTypes.turnLightAny, true)
	for _, v48 in pairs(v47.realLights) do
		p46:applyAdditionalActiveLightType(v48.topLights, v47.additionalLightTypes.topLight)
		p46:applyAdditionalActiveLightType(v48.bottomLights, v47.additionalLightTypes.bottomLight)
		p46:applyAdditionalActiveLightType(v48.brakeLights, v47.additionalLightTypes.brakeLight)
		p46:applyAdditionalActiveLightType(v48.reverseLights, v47.additionalLightTypes.reverseLight)
		p46:applyAdditionalActiveLightType(v48.turnLightsLeft, v47.additionalLightTypes.turnLightLeft, true)
		p46:applyAdditionalActiveLightType(v48.turnLightsLeft, v47.additionalLightTypes.turnLightAny, true)
		p46:applyAdditionalActiveLightType(v48.turnLightsRight, v47.additionalLightTypes.turnLightRight, true)
		p46:applyAdditionalActiveLightType(v48.turnLightsRight, v47.additionalLightTypes.turnLightAny, true)
		p46:applyAdditionalActiveLightType(v48.interiorLights, v47.additionalLightTypes.interiorLight)
		for _, v49 in pairs(v48) do
			for _, v50 in ipairs(v49) do
				v50:finalize()
			end
		end
	end
	if p46:getIsInShowroom() then
		for _, v51 in ipairs(v47.staticLights.dayTimeLights) do
			v51:setState(true)
		end
	end
end
function Lights.onRegisterDashboardValueTypes(p_u_52)
	local v_u_53 = p_u_52.spec_lights
	local v54 = DashboardValueType.new("lights", "lightState")
	v54:setValue(v_u_53, function(_, p55)
		-- upvalues: (copy) v_u_53, (copy) p_u_52
		if p55.displayTypeIndex == Dashboard.TYPES.MULTI_STATE then
			return v_u_53.lightsTypesMask
		end
		local v56 = false
		if p55.lightTypes ~= nil then
			for _, v57 in pairs(p55.lightTypes) do
				if bitAND(v_u_53.lightsTypesMask, 2 ^ v57) ~= 0 or v57 == -1 and p_u_52:getIsActiveForLights(true) then
					v56 = true
					break
				end
			end
		end
		if v56 and p55.excludedLightTypes ~= nil then
			for _, v58 in pairs(p55.excludedLightTypes) do
				if bitAND(v_u_53.lightsTypesMask, 2 ^ v58) ~= 0 then
					v56 = false
					break
				end
			end
		end
		return v56 and 1 or 0
	end)
	v54:setAdditionalFunctions(Lights.dashboardLightAttributes, Lights.dashboardLightState)
	p_u_52:registerDashboardValueType(v54)
	local v59 = DashboardValueType.new("lights", "turnLightLeft")
	v59:setValue(v_u_53, "turnLightState")
	v59:setValueCompare(Lights.TURNLIGHT_LEFT, Lights.TURNLIGHT_HAZARD)
	p_u_52:registerDashboardValueType(v59)
	local v60 = DashboardValueType.new("lights", "turnLightRight")
	v60:setValue(v_u_53, "turnLightState")
	v60:setValueCompare(Lights.TURNLIGHT_RIGHT, Lights.TURNLIGHT_HAZARD)
	p_u_52:registerDashboardValueType(v60)
	local v61 = DashboardValueType.new("lights", "turnLight")
	v61:setValue(v_u_53, "turnLightTriState")
	v61:setIdleValue(0.5)
	p_u_52:registerDashboardValueType(v61)
	local v62 = DashboardValueType.new("lights", "turnLightHazard")
	v62:setValue(v_u_53, "turnLightState")
	v62:setValueCompare(Lights.TURNLIGHT_HAZARD)
	p_u_52:registerDashboardValueType(v62)
	local v63 = DashboardValueType.new("lights", "turnLightAny")
	v63:setValue(v_u_53, "turnLightState")
	v63:setValueCompare(Lights.TURNLIGHT_LEFT, Lights.TURNLIGHT_RIGHT, Lights.TURNLIGHT_HAZARD)
	p_u_52:registerDashboardValueType(v63)
	local v64 = DashboardValueType.new("lights", "beaconLight")
	v64:setValue(v_u_53, function(p65)
		return p65.beaconLightsActive and 1 or 0
	end)
	p_u_52:registerDashboardValueType(v64)
end
function Lights.onDelete(p66)
	local v67 = p66.spec_lights
	if v67.sharedLights ~= nil then
		for _, v68 in ipairs(v67.sharedLights) do
			v68:delete()
		end
		v67.sharedLights = {}
	end
	if v67.beaconLights ~= nil then
		for _, v69 in ipairs(v67.beaconLights) do
			v69:delete()
		end
		v67.beaconLights = {}
	end
	if v67.alwaysActiveBeaconLights ~= nil then
		for _, v70 in ipairs(v67.alwaysActiveBeaconLights) do
			v70:delete()
		end
		v67.alwaysActiveBeaconLights = {}
	end
	if v67.xmlLoadingHandles ~= nil then
		for v71, _ in pairs(v67.xmlLoadingHandles) do
			v71:delete()
			v67.xmlLoadingHandles[v71] = nil
		end
	end
	if v67.sharedLoadRequestIds ~= nil then
		for _, v72 in ipairs(v67.sharedLoadRequestIds) do
			g_i3DManager:releaseSharedI3DFile(v72)
		end
	end
	if v67.staticLightCompounds ~= nil then
		v67.staticLightCompounds = {}
	end
	g_soundManager:deleteSamples(v67.samples)
end
function Lights.onReadStream(p73, p74, _)
	local v75 = p73.spec_lights
	p73:setLightsTypesMask(streamReadUIntN(p74, v75.totalNumLightTypes), true, true)
	p73:setBeaconLightsVisibility(streamReadBool(p74), true, true)
end
function Lights.onWriteStream(p76, p77, _)
	local v78 = p76.spec_lights
	streamWriteUIntN(p77, v78.lightsTypesMask, v78.totalNumLightTypes)
	streamWriteBool(p77, v78.beaconLightsActive)
end
function Lights.onUpdate(p79, _, _, p80, _)
	if p79.isClient then
		local v81 = p79.spec_lights
		if v81.turnLightState ~= Lights.TURNLIGHT_OFF then
			local v82 = getShaderTimeSec()
			local _, v83 = math.modf(v82)
			local v84 = v83 - 0.5
			local v85 = 4 * math.abs(v84) - 0.8
			local v86 = math.clamp(v85, 0, 1)
			if v81.turnLightState == Lights.TURNLIGHT_LEFT or v81.turnLightState == Lights.TURNLIGHT_HAZARD then
				for _, v87 in pairs(v81.activeTurnLightSetup.turnLightsLeft) do
					v87:setCharge(v86)
				end
			end
			if v81.turnLightState == Lights.TURNLIGHT_RIGHT or v81.turnLightState == Lights.TURNLIGHT_HAZARD then
				for _, v88 in pairs(v81.activeTurnLightSetup.turnLightsRight) do
					v88:setCharge(v86)
				end
			end
			if v81.samples.turnLight ~= nil and p80 then
				local v89 = v82 - 0.8
				local v90 = math.floor(v89)
				if v81.turnLightRepetitionCount ~= nil and v90 ~= v81.turnLightRepetitionCount then
					g_soundManager:playSample(v81.samples.turnLight)
				end
				v81.turnLightRepetitionCount = v90
			end
			p79:raiseActive()
		end
	end
end
function Lights.onUpdateTick(p91, _, _, _, _)
	if p91.isClient then
		local v92 = p91.spec_lights
		local v93 = p91:getIsActiveForLights()
		if v93 ~= v92.lastIsActiveForLights then
			for _, v94 in ipairs(v92.alwaysActiveBeaconLights) do
				v94:setIsActive(v93, false)
			end
			v92.lastIsActiveForLights = v93
		end
		if v92.interiorLightsAvailable then
			p91:setInteriorLightsVisibility(p91:getIsActiveForInteriorLights())
		end
		for _, v95 in ipairs(v92.actionEventsActiveChange) do
			g_inputBinding:setActionEventActive(v95, v93)
		end
		g_inputBinding:setActionEventActive(v92.actionEventIdLight, v93)
		if Platform.gameplay.automaticLights and (p91 == p91.rootVehicle and not p91:getIsAIActive()) then
			p91:updateAutomaticLights(not g_currentMission.environment.isSunOn and v93, p91.rootVehicle:getActionControllerDirection() == -1)
		end
	end
end
function Lights.getIsActiveForLights(p96, p97)
	if p97 == true and not p96:getIsPowered() then
		return false
	elseif p96.getIsEntered == nil or not (p96:getIsEntered() and p96:getCanToggleLight()) then
		if p96.attacherVehicle == nil then
			return false
		else
			return p96.attacherVehicle:getIsActiveForLights()
		end
	else
		return true
	end
end
function Lights.getIsActiveForInteriorLights(_)
	return false
end
function Lights.getCanToggleLight(p98)
	local v99 = p98.spec_lights
	if p98:getIsAIActive() then
		return false
	elseif v99.numLightTypes == 0 then
		return false
	else
		return g_localPlayer:getCurrentVehicle() == p98
	end
end
function Lights.getUseHighProfile(_)
	local v100 = g_gameSettings:getValue(GameSettings.SETTING.LIGHTS_PROFILE)
	return Utils.getNoNil(Platform.gameplay.lightsProfile, v100) >= GS_PROFILE_HIGH
end
function Lights.setNextLightsState(p101, p102)
	local v103 = p101.spec_lights
	if v103.lightStates ~= nil and #v103.lightStates > 0 then
		local v104 = bitAND(v103.lightsTypesMask, v103.maxLightStateMask)
		local v105 = v103.currentLightState + p102
		local v106 = (#v103.lightStates < v105 or v103.currentLightState == 0 and v104 > 0) and 0 or (v105 < 0 and #v103.lightStates or v105)
		local v107 = bitAND(v103.lightsTypesMask, bitNOT(v103.maxLightStateMask))
		if v106 > 0 then
			for _, v108 in pairs(v103.lightStates[v106]) do
				v107 = bitOR(v107, 2 ^ v108)
			end
		end
		v103.currentLightState = v106
		p101:setLightsTypesMask(v107)
	end
end
function Lights.setLightsTypesMask(p109, p110, p111, p112)
	local v113 = p109.spec_lights
	local v114
	if p109.isServer then
		v114 = bitAND(p110, v113.maxLightStateMask)
		if v113.turnLightState == Lights.TURNLIGHT_LEFT then
			v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.turnLightLeft)
		end
		if v113.turnLightState == Lights.TURNLIGHT_RIGHT then
			v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.turnLightRight)
		end
		if v113.turnLightState == Lights.TURNLIGHT_HAZARD then
			v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.turnLightAny)
		end
		if bitAND(v114, 2 ^ Lights.LIGHT_TYPE_DEFAULT) ~= 0 then
			if v113.topLightsVisibility then
				v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.topLight)
			else
				v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.bottomLight)
			end
		end
		if v113.brakeLightsVisibility then
			v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.brakeLight)
		end
		if v113.reverseLightsVisibility then
			v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.reverseLight)
		end
		if v113.interiorLightsVisibility then
			v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.interiorLight)
		end
	else
		local v115 = bitAND(p110, bitNOT(2 ^ v113.additionalLightTypes.bottomLight))
		local v116 = bitAND(v115, bitNOT(2 ^ v113.additionalLightTypes.interiorLight))
		if bitAND(v116, 2 ^ Lights.LIGHT_TYPE_DEFAULT) ~= 0 then
			if v113.topLightsVisibility then
				v116 = bitOR(v116, 2 ^ v113.additionalLightTypes.topLight)
			else
				v116 = bitOR(v116, 2 ^ v113.additionalLightTypes.bottomLight)
			end
		end
		v114 = bitAND(v116, bitNOT(2 ^ v113.additionalLightTypes.topLight))
		if v113.interiorLightsVisibility then
			v114 = bitOR(v114, 2 ^ v113.additionalLightTypes.interiorLight)
		end
	end
	if v114 ~= v113.lightsTypesMask or p111 then
		if p112 == nil or p112 == false then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(VehicleSetLightEvent.new(p109, v114, v113.totalNumLightTypes))
			else
				g_server:broadcastEvent(VehicleSetLightEvent.new(p109, v114, v113.totalNumLightTypes), nil, nil, p109)
			end
		end
		if bitAND(v114, v113.maxLightStateMask) ~= bitAND(v113.lightsTypesMask, v113.maxLightStateMask) and p109.isClient then
			g_soundManager:playSample(v113.samples.toggleLights)
		end
		local v117 = v113.realLights.low
		if p109:getUseHighProfile() then
			v117 = v113.realLights.high
		end
		for _, v118 in pairs(v113.staticLights) do
			for _, v119 in ipairs(v118) do
				v119:setLightTypesMask(v114)
			end
		end
		for _, v120 in pairs(v113.realLights) do
			for _, v121 in pairs(v120) do
				for _, v122 in ipairs(v121) do
					v122:setLightTypesMask(v120 == v117 and v114 and v114 or 0)
				end
			end
		end
		for _, v123 in pairs(v113.staticLightCompounds) do
			v123:setLightTypesMask(v114, p109)
		end
		v113.lightsTypesMask = v114
		SpecializationUtil.raiseEvent(p109, "onLightsTypesMaskChanged", v114)
	end
	return true
end
function Lights.getLightsTypesMask(p124)
	return p124.spec_lights.lightsTypesMask
end
function Lights.setBeaconLightsVisibility(p125, p126, p127, p128)
	local v129 = p125.spec_lights
	if p126 ~= v129.beaconLightsActive or p127 then
		if p128 == nil or p128 == false then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(VehicleSetBeaconLightEvent.new(p125, p126))
			else
				g_server:broadcastEvent(VehicleSetBeaconLightEvent.new(p125, p126), nil, nil, p125)
			end
		end
		local v130 = p125:getIsActiveForInput(true)
		v129.beaconLightsActive = p126
		for _, v131 in pairs(v129.beaconLights) do
			v131:setIsActive(p126, v130)
		end
		SpecializationUtil.raiseEvent(p125, "onBeaconLightsVisibilityChanged", p126)
	end
	return true
end
function Lights.getBeaconLightsVisibility(p132)
	return p132.spec_lights.beaconLightsActive
end
function Lights.setTurnLightState(p133, p134, p135, p136)
	local v137 = p133.spec_lights
	if p134 ~= v137.turnLightState or p135 then
		if p136 == nil or p136 == false then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(VehicleSetTurnLightEvent.new(p133, p134))
			else
				g_server:broadcastEvent(VehicleSetTurnLightEvent.new(p133, p134), nil, nil, p133)
			end
		end
		local v138 = v137.realLights.low
		if p133:getUseHighProfile() then
			v138 = v137.realLights.high
		end
		v137.activeTurnLightSetup = v138
		v137.turnLightState = p134
		v137.turnLightTriState = v137.turnLightState == Lights.TURNLIGHT_LEFT and 0 or (v137.turnLightState == Lights.TURNLIGHT_RIGHT and 1 or 0.5)
		v137.turnLightRepetitionCount = nil
		if p133.isServer then
			p133:setLightsTypesMask(v137.lightsTypesMask, nil)
		end
		SpecializationUtil.raiseEvent(p133, "onTurnLightStateChanged", p134)
	end
	return true
end
function Lights.getTurnLightState(p139)
	return p139.spec_lights.turnLightState
end
function Lights.setTopLightsVisibility(p140, p141)
	local v142 = p140.spec_lights
	if p141 ~= v142.topLightsVisibility then
		v142.topLightsVisibility = p141
		p140:setLightsTypesMask(v142.lightsTypesMask)
		SpecializationUtil.raiseEvent(p140, "onTopLightsVisibilityChanged", p141)
	end
	return true
end
function Lights.setBrakeLightsVisibility(p143, p144)
	local v145 = p143.spec_lights
	if p144 ~= v145.brakeLightsVisibility then
		v145.brakeLightsVisibility = p144
		p143:setLightsTypesMask(v145.lightsTypesMask)
		SpecializationUtil.raiseEvent(p143, "onBrakeLightsVisibilityChanged", p144)
	end
	return true
end
function Lights.setReverseLightsVisibility(p146, p147)
	local v148 = p146.spec_lights
	if p147 ~= v148.reverseLightsVisibility then
		v148.reverseLightsVisibility = p147
		p146:setLightsTypesMask(v148.lightsTypesMask)
		SpecializationUtil.raiseEvent(p146, "onReverseLightsVisibilityChanged", p147)
	end
	return true
end
function Lights.setInteriorLightsVisibility(p149, p150)
	local v151 = p149.spec_lights
	local v152, v153 = p149:getInteriorLightBrightness(true)
	if v152 == 0 then
		p150 = false
	end
	if p150 ~= v151.interiorLightsVisibility or v153 then
		v151.interiorLightsVisibility = p150
		p149:setLightsTypesMask(v151.lightsTypesMask, true, true)
	end
	return true
end
function Lights.getInteriorLightBrightness(p154, p155)
	local v156 = p154.spec_lights
	local v157
	if p155 then
		local v158 = g_currentMission.environment.currentHour + g_currentMission.environment.currentMinute / 60
		local v159 = v158 >= 10 and 0 or 1 - (v158 - 8) / 2
		if v158 > 16 then
			v159 = (v158 - 16) / 2
		end
		local v160 = v156.interiorLightsBrightness
		v156.interiorLightsBrightness = math.clamp(v159, 0, 1)
		v157 = v156.interiorLightsBrightness ~= v160
	else
		v157 = false
	end
	return v156.interiorLightsBrightness, v157
end
function Lights.deactivateLights(p161, p162)
	local v163 = p161.spec_lights
	p161:setLightsTypesMask(0, true, true)
	p161:setBeaconLightsVisibility(false, true, true)
	if not p162 or v163.turnLightState ~= Lights.TURNLIGHT_HAZARD then
		p161:setTurnLightState(Lights.TURNLIGHT_OFF, true, true)
	end
	p161:setBrakeLightsVisibility(false)
	p161:setReverseLightsVisibility(false)
	p161:setInteriorLightsVisibility(false)
	v163.currentLightState = 0
end
function Lights.deactivateBeaconLights(p164)
	local v165 = p164.spec_lights
	for _, v166 in pairs(v165.beaconLights) do
		v166:setIsActive(false, true)
	end
end
function Lights.loadDashboardGroupFromXML(p167, p168, p169, p170, p171)
	if not p168(p167, p169, p170, p171) then
		return false
	end
	p171.lightTypes = p169:getValue(p170 .. "#lightTypes", nil, true)
	p171.excludedLightTypes = p169:getValue(p170 .. "#excludedLightTypes", nil, true)
	return true
end
function Lights.getIsDashboardGroupActive(p172, p173, p174)
	if p174.lightTypes ~= nil or p174.excludedLightTypes ~= nil then
		local v175 = p172.spec_lights
		if p174.lightTypes ~= nil then
			local v176 = false
			for _, v177 in pairs(p174.lightTypes) do
				if bitAND(v175.lightsTypesMask, 2 ^ v177) ~= 0 then
					v176 = true
					break
				end
			end
			if not v176 then
				return false
			end
		end
		if p174.excludedLightTypes ~= nil then
			for _, v178 in pairs(p174.excludedLightTypes) do
				if bitAND(v175.lightsTypesMask, 2 ^ v178) ~= 0 then
					return false
				end
			end
		end
	end
	return p173(p172, p174)
end
function Lights.getDeactivateLightsOnLeave(_)
	return true
end
function Lights.loadSharedLight(p179, _, p180)
	local v_u_181 = p179.spec_lights
	local v_u_182 = SharedLight.new(p179, v_u_181.staticLights)
	v_u_182:loadFromVehicleXML(p180, p179.baseDirectory, function(p183)
		-- upvalues: (copy) v_u_181, (copy) v_u_182
		if p183 then
			local v184 = v_u_181.sharedLights
			local v185 = v_u_182
			table.insert(v184, v185)
			if v_u_182.staticLightCompound ~= nil then
				local v186 = v_u_181.staticLightCompounds
				local v187 = v_u_182.staticLightCompound
				table.insert(v186, v187)
			end
		end
	end)
end
function Lights.loadAdditionalLightAttributesFromXML(_, p188, p189, p190)
	p190.isTopLight = p188:getValue(p189 .. "#isTopLight", false)
	p190.isBottomLight = p188:getValue(p189 .. "#isBottomLight", false)
	return true
end
function Lights.getIsLightActive(p191, p192)
	if p192.isTopLight then
		if not p191.spec_lights.topLightsVisibility then
			return false
		end
	elseif p192.isBottomLight and p191.spec_lights.topLightsVisibility then
		return false
	end
	return true
end
function Lights.getStaticLightFromNode(p193, p194)
	local v195 = p193.spec_lights
	for _, v196 in pairs(v195.staticLights) do
		for _, v197 in ipairs(v196) do
			if v197.node == p194 then
				return v197
			end
		end
	end
end
function Lights.getRealLightFromNode(p198, p199)
	local v200 = p198.spec_lights
	for _, v201 in pairs(v200.realLights) do
		for _, v202 in pairs(v201) do
			for _, v203 in ipairs(v202) do
				if v203.node == p199 then
					return v203
				end
			end
		end
	end
end
function Lights.updateAutomaticLights(p204, p205, p206)
	local v207 = p204.spec_lights
	if p205 then
		local v208 = p206 and v207.automaticLightsTypesMaskWork or v207.automaticLightsTypesMask
		if v207.lightsTypesMask ~= v208 then
			p204:setLightsTypesMask(v208)
			return
		end
	elseif v207.lightsTypesMask ~= 0 then
		p204:setLightsTypesMask(0)
	end
end
function Lights.lightsWeatherChanged(p209)
	local v210 = p209.spec_lights
	g_inputBinding:setActionEventTextVisibility(v210.actionEventIdLight, not g_currentMission.environment.isSunOn)
end
function Lights.onRegisterActionEvents(p211, _, p212)
	if p211.isClient and (p211.getIsEntered ~= nil and p211:getIsEntered()) then
		local v213 = p211.spec_lights
		p211:clearActionEventsTable(v213.actionEvents)
		if p212 then
			local _, v214 = p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_LIGHTS, p211, Lights.actionEventToggleLights, false, true, false, true, nil)
			v213.actionEventIdLight = v214
			local _, v215 = p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_LIGHTS_BACK, p211, Lights.actionEventToggleLightsBack, false, true, false, true, nil)
			local _, v216 = p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_LIGHT_FRONT, p211, Lights.actionEventToggleLightFront, false, true, false, true, nil)
			local _, v217 = p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_WORK_LIGHT_BACK, p211, Lights.actionEventToggleWorkLightBack, false, true, false, true, nil)
			local _, v218 = p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_WORK_LIGHT_FRONT, p211, Lights.actionEventToggleWorkLightFront, false, true, false, true, nil)
			local _, v219 = p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_HIGH_BEAM_LIGHT, p211, Lights.actionEventToggleHighBeamLight, false, true, false, true, nil)
			p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_TURNLIGHT_HAZARD, p211, Lights.actionEventToggleTurnLightHazard, false, true, false, true, nil)
			p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_TURNLIGHT_LEFT, p211, Lights.actionEventToggleTurnLightLeft, false, true, false, true, nil)
			p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_TURNLIGHT_RIGHT, p211, Lights.actionEventToggleTurnLightRight, false, true, false, true, nil)
			local _, v220 = p211:addActionEvent(v213.actionEvents, InputAction.TOGGLE_BEACON_LIGHTS, p211, Lights.actionEventToggleBeaconLights, false, true, false, true, nil)
			v213.actionEventsActiveChange = {
				v216,
				v217,
				v218,
				v219,
				v220
			}
			for _, v221 in pairs(v213.actionEvents) do
				if v221.actionEventId ~= nil then
					g_inputBinding:setActionEventTextVisibility(v221.actionEventId, false)
					g_inputBinding:setActionEventTextPriority(v221.actionEventId, GS_PRIO_LOW)
				end
			end
			g_inputBinding:setActionEventTextVisibility(v213.actionEventIdLight, not g_currentMission.environment.isSunOn)
			g_inputBinding:setActionEventTextVisibility(v215, false)
		end
	end
end
function Lights.onRegisterExternalActionEvents(p222, p223, p224, _, _)
	if p224 == "lights" and #p222.spec_lights.lightStates > 0 then
		p222:registerExternalActionEvent(p223, p224, Lights.externalActionEventRegister, Lights.externalActionEventUpdate)
	end
end
function Lights.onEnterVehicle(p225, _)
	local v226 = p225.spec_lights
	p225:setLightsTypesMask(v226.lightsTypesMask, true, true)
	p225:setBeaconLightsVisibility(v226.beaconLightsActive, true, true)
	p225:setTurnLightState(v226.turnLightState, true, true)
end
function Lights.onLeaveVehicle(p227)
	if p227:getDeactivateLightsOnLeave() then
		p227:deactivateLights(true)
		p227:deactivateBeaconLights()
	end
end
function Lights.onDeactivate(p228)
	if p228:getDeactivateLightsOnLeave() then
		p228:deactivateBeaconLights()
	end
end
function Lights.onRequiresTopLightsChanged(p229, p230)
	p229:setTopLightsVisibility(p230)
end
function Lights.onStartMotor(p231)
	local v232 = p231.spec_lights
	p231:setLightsTypesMask(v232.lightsTypesMask, true, true)
	for _, v233 in ipairs(v232.staticLights.dayTimeLights) do
		v233:setState(true)
	end
end
function Lights.onStopMotor(p234)
	local v235 = p234.spec_lights
	p234:setLightsTypesMask(v235.lightsTypesMask, true, true)
	for _, v236 in ipairs(v235.staticLights.dayTimeLights) do
		v236:setState((p234:getIsInShowroom()))
	end
end
function Lights.onStartReverseDirectionChange(p237)
	local v238 = p237.spec_lights
	if v238.lightsTypesMask > 0 then
		p237:setLightsTypesMask(v238.lightsTypesMask, true, true)
	end
end
function Lights.onPostAttach(p239, p240, _, _)
	if p240.getLightsTypesMask ~= nil then
		p239:setLightsTypesMask(p240:getLightsTypesMask(), true, true)
		p239:setBeaconLightsVisibility(p240:getBeaconLightsVisibility(), true, true)
		p239:setTurnLightState(p240:getTurnLightState(), true, true)
	end
end
function Lights.onPostDetach(p241)
	p241:deactivateLights()
end
function Lights.onAutomatedTrainTravelActive(p242)
	p242:updateAutomaticLights(not g_currentMission.environment.isSunOn, false)
end
function Lights.onAIDriveableActive(p243)
	p243:updateAutomaticLights(not g_currentMission.environment.isSunOn, false)
end
function Lights.onAIDriveableEnd(p244)
	if p244.getIsControlled ~= nil and not p244:getIsControlled() then
		p244:setLightsTypesMask(0)
	end
	p244:setBeaconLightsVisibility(false, true, true)
end
function Lights.onAIFieldWorkerStart(p245)
	p245:setBeaconLightsVisibility(false, true, true)
end
function Lights.onAIFieldWorkerActive(p246)
	p246:updateAutomaticLights(not g_currentMission.environment.isSunOn, true)
end
function Lights.onAIJobVehicleBlock(p247)
	p247:setBeaconLightsVisibility(true, true, true)
end
function Lights.onAIJobVehicleContinue(p248)
	p248:setBeaconLightsVisibility(false, true, true)
end
function Lights.onAIFieldWorkerEnd(p249)
	if p249.getIsControlled ~= nil and not p249:getIsControlled() then
		p249:setLightsTypesMask(0)
	end
	p249:setBeaconLightsVisibility(false, true, true)
end
function Lights.onVehiclePhysicsUpdate(p250, p251, p252, p253, p254)
	local v255 = not p253
	if v255 then
		v255 = math.abs(p252) > 0
	end
	p250:setBrakeLightsVisibility(v255)
	local v256 = p250.spec_drivable == nil and 1 or p250.spec_drivable.reverserDirection
	local v257
	if p254 < -p250.spec_lights.reverseLightActivationSpeed or p251 < 0 then
		v257 = v256 == 1
	else
		v257 = false
	end
	p250:setReverseLightsVisibility(v257)
end
function Lights.loadRealLightSetup(p258, p259, p260, p261, _)
	p261.defaultLights = RealLight.loadLightsFromXML(nil, p259, p260 .. ".light", p258, p258.components, p258.i3dMappings, true)
	p261.topLights = RealLight.loadLightsFromXML(nil, p259, p260 .. ".topLight", p258, p258.components, p258.i3dMappings, false)
	p261.bottomLights = RealLight.loadLightsFromXML(nil, p259, p260 .. ".bottomLight", p258, p258.components, p258.i3dMappings, false)
	p261.brakeLights = RealLight.loadLightsFromXML(nil, p259, p260 .. ".brakeLight", p258, p258.components, p258.i3dMappings, false)
	p261.reverseLights = RealLight.loadLightsFromXML(nil, p259, p260 .. ".reverseLight", p258, p258.components, p258.i3dMappings, false)
	p261.turnLightsLeft = RealLight.loadLightsFromXML(nil, p259, p260 .. ".turnLightLeft", p258, p258.components, p258.i3dMappings, false)
	p261.turnLightsRight = RealLight.loadLightsFromXML(nil, p259, p260 .. ".turnLightRight", p258, p258.components, p258.i3dMappings, false)
	p261.interiorLights = RealLight.loadLightsFromXML(nil, p259, p260 .. ".interiorLight", p258, p258.components, p258.i3dMappings, false)
	for _, v262 in ipairs(p261.interiorLights) do
		v262:setChargeFunction(p258.getInteriorLightBrightness, p258)
		p258.spec_lights.interiorLightsAvailable = true
	end
end
function Lights.applyAdditionalActiveLightType(_, p263, p264, p265)
	for _, v266 in ipairs(p263) do
		local v267 = v266.lightTypes
		table.insert(v267, p264)
		if p265 then
			v266:setIsBlinking(true)
		end
	end
end
function Lights.actionEventToggleLightFront(p268, _, _, _, _)
	local v269 = p268.spec_lights
	if p268:getCanToggleLight() and v269.numLightTypes >= 1 then
		p268:setLightsTypesMask((bitXOR(v269.lightsTypesMask, 2 ^ Lights.LIGHT_TYPE_DEFAULT)))
	end
end
function Lights.actionEventToggleLights(p270, _, _, _, _)
	if p270:getCanToggleLight() then
		p270:setNextLightsState(1)
	end
end
function Lights.actionEventToggleLightsBack(p271, _, _, _, _)
	if p271:getCanToggleLight() then
		p271:setNextLightsState(-1)
	end
end
function Lights.actionEventToggleWorkLightBack(p272, _, _, _, _)
	local v273 = p272.spec_lights
	if p272:getCanToggleLight() then
		p272:setLightsTypesMask((bitXOR(v273.lightsTypesMask, 2 ^ Lights.LIGHT_TYPE_WORK_BACK)))
	end
end
function Lights.actionEventToggleWorkLightFront(p274, _, _, _, _)
	local v275 = p274.spec_lights
	if p274:getCanToggleLight() then
		p274:setLightsTypesMask((bitXOR(v275.lightsTypesMask, 2 ^ Lights.LIGHT_TYPE_WORK_FRONT)))
	end
end
function Lights.actionEventToggleHighBeamLight(p276, _, _, _, _)
	local v277 = p276.spec_lights
	if p276:getCanToggleLight() then
		p276:setLightsTypesMask((bitXOR(v277.lightsTypesMask, 2 ^ Lights.LIGHT_TYPE_HIGHBEAM)))
	end
end
function Lights.actionEventToggleTurnLightHazard(p278, _, _, _, _)
	local v279 = p278.spec_lights
	if p278:getCanToggleLight() then
		local v280 = Lights.TURNLIGHT_OFF
		if v279.turnLightState ~= Lights.TURNLIGHT_HAZARD then
			v280 = Lights.TURNLIGHT_HAZARD
		end
		p278:setTurnLightState(v280)
	end
end
function Lights.actionEventToggleTurnLightLeft(p281, _, _, _, _)
	local v282 = p281.spec_lights
	if p281:getCanToggleLight() then
		local v283 = Lights.TURNLIGHT_OFF
		if v282.turnLightState ~= Lights.TURNLIGHT_LEFT then
			v283 = Lights.TURNLIGHT_LEFT
		end
		p281:setTurnLightState(v283)
	end
end
function Lights.actionEventToggleTurnLightRight(p284, _, _, _, _)
	local v285 = p284.spec_lights
	if p284:getCanToggleLight() then
		local v286 = Lights.TURNLIGHT_OFF
		if v285.turnLightState ~= Lights.TURNLIGHT_RIGHT then
			v286 = Lights.TURNLIGHT_RIGHT
		end
		p284:setTurnLightState(v286)
	end
end
function Lights.actionEventToggleBeaconLights(p287, _, _, _, _)
	local v288 = p287.spec_lights
	if p287:getCanToggleLight() then
		p287:setBeaconLightsVisibility(not v288.beaconLightsActive)
	end
end
function Lights.externalActionEventRegister(p289, p_u_290)
	local _, v291 = g_inputBinding:registerActionEvent(InputAction.TOGGLE_LIGHTS_EXTERNAL, p289, function(_, _, _, _, _)
		-- upvalues: (copy) p_u_290
		p_u_290:setNextLightsState(1)
	end, false, true, false, true)
	p289.actionEventId = v291
	g_inputBinding:setActionEventTextPriority(p289.actionEventId, GS_PRIO_HIGH)
	g_inputBinding:setActionEventText(p289.actionEventId, g_i18n:getText("input_TOGGLE_LIGHTS"))
end
function Lights.externalActionEventUpdate(_, _) end
function Lights.dashboardLightAttributes(p292, p293, p294, p295, _)
	p295.lightTypes = p293:getValue(p294 .. "#lightTypes", nil, true)
	p295.excludedLightTypes = p293:getValue(p294 .. "#excludedLightTypes", nil, true)
	p295.lightStates = {}
	for v296 = 0, p292.spec_lights.maxLightState do
		p295.lightStates[v296] = false
	end
	return true
end
function Lights.dashboardLightState(p297, p298, p299, p300, p301, p302)
	local v303 = p297.spec_lights.lightsTypesMask
	if p298.displayTypeIndex == Dashboard.TYPES.MULTI_STATE then
		local v304 = false
		for v305 = 0, p297.spec_lights.maxLightState do
			p298.lightStates[v305] = bitAND(v303, 2 ^ v305) ~= 0
			v304 = v304 or p298.lightStates[v305]
		end
		if v304 then
			Dashboard.defaultDashboardStateFunc(p297, p298, p298.lightStates, p300, p301, p302)
		else
			Dashboard.defaultDashboardStateFunc(p297, p298, -1, p300, p301, p302)
		end
	else
		Dashboard.defaultDashboardStateFunc(p297, p298, p299, p300, p301, p302)
		return
	end
end
function Lights.consoleCommandTopLights()
	local v306 = g_localPlayer:getCurrentVehicle()
	if v306 ~= nil and v306.setTopLightsVisibility ~= nil then
		v306:setTopLightsVisibility(not v306.spec_lights.topLightsVisibility)
	end
end
addConsoleCommand("gsVehicleDebugTopLights", "Toggles between top and bottom lights", "Lights.consoleCommandTopLights", nil)
function Lights.consoleCommandProfile()
	if g_gameSettings:getValue(GameSettings.SETTING.LIGHTS_PROFILE) >= GS_PROFILE_HIGH then
		g_gameSettings:setValue(GameSettings.SETTING.LIGHTS_PROFILE, GS_PROFILE_LOW)
		Logging.info("Activated LOW light setup.")
	else
		g_gameSettings:setValue(GameSettings.SETTING.LIGHTS_PROFILE, GS_PROFILE_VERY_HIGH)
		Logging.info("Activated HIGH light setup.")
	end
end
addConsoleCommand("gsLightProfileToggle", "Toggles between high and low light profile on vehicles & placeables", "Lights.consoleCommandProfile", nil)

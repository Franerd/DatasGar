VineCutter = {}
function VineCutter.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("vineCutter", g_i18n:getText("shop_configuration"), "vineCutter", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("VineCutter")
	v1:register(XMLValueType.STRING, "vehicle.vineCutter#fruitType", "Fruit type")
	v1:register(XMLValueType.STRING, "vehicle.vineCutter.vineCutterConfigurations.vineCutterConfiguration(?)#fruitType", "Fruit type")
	v1:setXMLSpecializationType()
end
function VineCutter.prerequisitesPresent(p2)
	return SpecializationUtil.hasSpecialization(VineDetector, p2)
end
function VineCutter.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getCombine", VineCutter.getCombine)
	SpecializationUtil.registerFunction(p3, "harvestCallback", VineCutter.harvestCallback)
end
function VineCutter.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "doCheckSpeedLimit", VineCutter.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanStartVineDetection", VineCutter.getCanStartVineDetection)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsValidVinePlaceable", VineCutter.getIsValidVinePlaceable)
	SpecializationUtil.registerOverwrittenFunction(p4, "handleVinePlaceable", VineCutter.handleVinePlaceable)
	SpecializationUtil.registerOverwrittenFunction(p4, "clearCurrentVinePlaceable", VineCutter.clearCurrentVinePlaceable)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAIImplementUseVineSegment", VineCutter.getAIImplementUseVineSegment)
end
function VineCutter.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", VineCutter)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", VineCutter)
	SpecializationUtil.registerEventListener(p5, "onDraw", VineCutter)
	SpecializationUtil.registerEventListener(p5, "onTurnedOff", VineCutter)
end
function VineCutter.onLoad(p6, _)
	local v7 = p6.spec_vineCutter
	local v8 = p6.configurations.vineCutter or 1
	local v9 = string.format("vehicle.vineCutter.vineCutterConfigurations.vineCutterConfiguration(%d)", v8 - 1)
	local v10 = p6.xmlFile:getValue(v9 .. "#fruitType")
	if v10 == nil then
		v10 = p6.xmlFile:getValue("vehicle.vineCutter#fruitType")
	end
	local v11 = g_fruitTypeManager:getFruitTypeByName(v10)
	if v11 == nil then
		v7.inputFruitTypeIndex = FruitType.GRAPE
	else
		v7.inputFruitTypeIndex = v11.index
	end
	v7.outputFillTypeIndex = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v7.inputFruitTypeIndex)
	v7.showFarmlandNotOwnedWarning = false
	v7.warningYouDontHaveAccessToThisLand = g_i18n:getText("warning_youDontHaveAccessToThisLand")
end
function VineCutter.onPostLoad(p12, _)
	if p12.addCutterToCombine ~= nil then
		p12:addCutterToCombine(p12)
	end
end
function VineCutter.onDraw(p13, _, _, _)
	local v14 = p13.spec_vineCutter
	if v14.showFarmlandNotOwnedWarning then
		g_currentMission:showBlinkingWarning(v14.warningYouDontHaveAccessToThisLand)
	end
end
function VineCutter.onTurnedOff(p15)
	p15:cancelVineDetection()
	local v16 = p15.spec_vineCutter
	if v16.lastHarvestingPlaceable ~= nil and v16.lastHarvestingNode ~= nil then
		v16.lastHarvestingPlaceable:setShakingFactor(v16.lastHarvestingNode, 0, 0, 0, 0)
	end
	v16.showFarmlandNotOwnedWarning = false
end
function VineCutter.getCanStartVineDetection(p17, p18)
	if p18(p17) then
		if p17:getIsTurnedOn() then
			return p17.movingDirection >= 0
		else
			return false
		end
	else
		return false
	end
end
function VineCutter.getIsValidVinePlaceable(p19, p20, p21)
	if not p20(p19, p21) then
		return false
	end
	local v22 = p19.spec_vineCutter
	return p21:getVineFruitType() == v22.inputFruitTypeIndex
end
function VineCutter.handleVinePlaceable(p23, p24, p25, p26, p27, p28, p29, p30)
	local v31 = p23.spec_vineCutter
	v31.showFarmlandNotOwnedWarning = false
	if not p24(p23, p25, p26, p27, p28, p29, p30) then
		return false
	end
	local v32 = g_farmlandManager:getFarmlandIdAtWorldPosition(p27, p29)
	if v32 == nil then
		v31.showFarmlandNotOwnedWarning = true
		return false
	end
	if v32 == FarmlandManager.NOT_BUYABLE_FARM_ID then
		v31.showFarmlandNotOwnedWarning = true
		return false
	end
	local v33 = g_farmlandManager:getFarmlandOwner(v32)
	local v34 = p23:getOwnerFarmId()
	local v35
	if v33 == 0 then
		v35 = false
	else
		v35 = g_currentMission.accessHandler:canFarmAccessOtherId(v34, v33)
	end
	if not v35 then
		v31.showFarmlandNotOwnedWarning = true
		return false
	end
	local v37, v37, v38 = p23:getCombine()
	if v37 == nil then
		local _ = v38 == nil
	end
	if v37 == nil then
		if v31.lastHarvestingNode ~= nil then
			v31.lastHarvestingPlaceable:setShakingFactor(v31.lastHarvestingNode, 0, 0, 0, 0)
		end
		return false
	end
	if p26 == nil then
		return false
	end
	local v39, v40, v41 = p23:getFirstVineHitPosition()
	local v42, v43, v44 = p23:getCurrentVineHitPosition()
	v31.currentCombineVehicle = v37
	v31.lastTouchedFarmlandFarmId = v33
	p26:harvestVine(p25, v39, v40, v41, v42, v43, v44, p23.harvestCallback, p23)
	p26:setShakingFactor(p25, v42, v43, v44, 1)
	if v31.lastHarvestingNode ~= nil and v31.lastHarvestingNode ~= p25 then
		v31.lastHarvestingPlaceable:setShakingFactor(v31.lastHarvestingNode, v42, v43, v44, 0)
	end
	v31.lastHarvestingNode = p25
	v31.lastHarvestingPlaceable = p26
	return true
end
function VineCutter.clearCurrentVinePlaceable(p45, p46)
	p46(p45)
	local v47 = p45.spec_vineCutter
	if v47.lastHarvestingPlaceable ~= nil and v47.lastHarvestingNode ~= nil then
		v47.lastHarvestingPlaceable:setShakingFactor(v47.lastHarvestingNode, 0, 0, 0, 0)
	end
	v47.lastHarvestingPlaceable = nil
	v47.lastHarvestingNode = nil
	v47.showFarmlandNotOwnedWarning = false
end
function VineCutter.getAIImplementUseVineSegment(p48, _, p49, p50, p51)
	if p51 >= 0 then
		return p49:getHasSegmentTargetGrowthState(p50, p48.spec_vineCutter.inputFruitTypeIndex, true, false)
	else
		return false
	end
end
function VineCutter.harvestCallback(p52, _, p53, _, p54, p55, p56, p57)
	local v58 = p52.spec_vineCutter
	local _ = p53 * g_currentMission:getHarvestScaleMultiplier(v58.inputFruitTypeIndex, p55, p56, 1, p54, 1, 1, 0)
	local v59 = g_fruitTypeManager:getFruitTypeAreaLiters(v58.inputFruitTypeIndex, p53, false)
	v58.currentCombineVehicle:addCutterArea(p53, v59, v58.inputFruitTypeIndex, v58.outputFillTypeIndex, 0, v58.lastTouchedFarmlandFarmId, 1)
	if v58.inputFruitTypeIndex == FruitType.GRAPE then
		g_farmManager:updateFarmStats(v58.lastTouchedFarmlandFarmId, "harvestedGrapes", p57)
		return
	elseif v58.inputFruitTypeIndex == FruitType.OLIVE then
		g_farmManager:updateFarmStats(v58.lastTouchedFarmlandFarmId, "harvestedOlives", p57)
	else
		local v60 = MathUtil.areaToHa(p53, g_currentMission:getFruitPixelsToSqm())
		g_farmManager:updateFarmStats(v58.lastTouchedFarmlandFarmId, "threshedHectares", v60)
		g_farmManager:updateFarmStats(v58.lastTouchedFarmlandFarmId, "workedHectares", v60)
	end
end
function VineCutter.doCheckSpeedLimit(p61, p62)
	return p62(p61) or p61:getIsTurnedOn()
end
function VineCutter.getCombine(p63)
	local v64 = p63.spec_vineCutter
	if p63.verifyCombine ~= nil then
		return p63:verifyCombine(v64.inputFruitTypeIndex, v64.outputFillTypeIndex)
	end
	if p63.getAttacherVehicle ~= nil then
		local v65 = p63:getAttacherVehicle()
		if v65 ~= nil and v65.verifyCombine ~= nil then
			return v65:verifyCombine(v64.inputFruitTypeIndex, v64.outputFillTypeIndex)
		end
	end
	return nil
end
function VineCutter.getDefaultSpeedLimit()
	return 5
end

TestAreas = {}
function TestAreas.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("TestAreas")
	v1:register(XMLValueType.BOOL, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#autoGenerate", "Automatically generate test areas", false)
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#rootNode", "Root node as reference for width")
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#startNode", "Left node reference for automatic calculation")
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#widthNode", "Right node reference for automatic calculation")
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#zOffset", "Offset in Z direction", 0)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#xOffset", "Offset for both sides mirrored (negative value will shrink area, positive will increase area on both sides)", 0)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#length", "Length of area itself", 0.5)
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#numAreas", "Number of used areas", 10)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#areaWidthScale", "Width percentage of each individual area", 0.9)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. ".testAreas#scale", "Scale of test areas over width of work area", 1)
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_KEY .. ".testAreas.testArea(?)#startNode", "Start Node")
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_KEY .. ".testAreas.testArea(?)#widthNode", "Width Node")
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_KEY .. ".testAreas.testArea(?)#heightNode", "Height Node")
	v1:register(XMLValueType.BOOL, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#autoGenerate", "Automatically generate test areas", false)
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#rootNode", "Root node as reference for width")
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#startNode", "Left node reference for automatic calculation")
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#widthNode", "Right node reference for automatic calculation")
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#zOffset", "Offset in Z direction", 0)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#xOffset", "Offset for both sides mirrored (negative value will shrink area, positive will increase area on both sides)", 0)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#length", "Length of area itself", 0.5)
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#numAreas", "Number of used areas", 10)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#areaWidthScale", "Width percentage of each individual area", 0.9)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas#scale", "Scale of test areas over width of work area", 1)
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas.testArea(?)#startNode", "Start Node")
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas.testArea(?)#widthNode", "Width Node")
	v1:register(XMLValueType.NODE_INDEX, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".testAreas.testArea(?)#heightNode", "Height Node")
	v1:setXMLSpecializationType()
end
function TestAreas.prerequisitesPresent(p2)
	return SpecializationUtil.hasSpecialization(WorkArea, p2)
end
function TestAreas.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "readTestAreasStream", TestAreas.readTestAreasStream)
	SpecializationUtil.registerFunction(p3, "writeTestAreasStream", TestAreas.writeTestAreasStream)
	SpecializationUtil.registerFunction(p3, "generateTestAreasForWorkArea", TestAreas.generateTestAreasForWorkArea)
	SpecializationUtil.registerFunction(p3, "calculateTestAreaDimensions", TestAreas.calculateTestAreaDimensions)
	SpecializationUtil.registerFunction(p3, "registerTestAreaForWorkArea", TestAreas.registerTestAreaForWorkArea)
	SpecializationUtil.registerFunction(p3, "setTestAreaRequirements", TestAreas.setTestAreaRequirements)
	SpecializationUtil.registerFunction(p3, "getIsTestAreaActive", TestAreas.getIsTestAreaActive)
	SpecializationUtil.registerFunction(p3, "processTestArea", TestAreas.processTestArea)
	SpecializationUtil.registerFunction(p3, "getTestAreaWidthByWorkAreaIndex", TestAreas.getTestAreaWidthByWorkAreaIndex)
	SpecializationUtil.registerFunction(p3, "getTestAreaChargeByWorkAreaIndex", TestAreas.getTestAreaChargeByWorkAreaIndex)
end
function TestAreas.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadWorkAreaFromXML", TestAreas.loadWorkAreaFromXML)
end
function TestAreas.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onPreLoad", TestAreas)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", TestAreas)
	SpecializationUtil.registerEventListener(p5, "onReadStream", TestAreas)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", TestAreas)
	SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", TestAreas)
	SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", TestAreas)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", TestAreas)
end
function TestAreas.onPreLoad(p6, _)
	local v7 = p6.spec_testAreas
	v7.testAreas = {}
	v7.testAreasByWorkArea = {}
	v7.testAreasByWorkAreaIndex = {}
	v7.testAreaDirtyFlag = p6:getNextDirtyFlag()
end
function TestAreas.onPostLoad(p8, _)
	local v9 = p8.spec_testAreas
	for v10, v11 in pairs(v9.testAreasByWorkArea) do
		v9.testAreasByWorkAreaIndex[v10.index] = v11
	end
end
function TestAreas.onReadStream(p12, p13, p14)
	p12:readTestAreasStream(p13, p14)
end
function TestAreas.onWriteStream(p15, p16, p17)
	p15:writeTestAreasStream(p16, p17)
end
function TestAreas.onReadUpdateStream(p18, p19, _, p20)
	if p20:getIsServer() and streamReadBool(p19) then
		p18:readTestAreasStream(p19, p20)
	end
end
function TestAreas.onWriteUpdateStream(p21, p22, p23, p24)
	if not p23:getIsServer() and streamWriteBool(p22, bitAND(p24, p21.spec_testAreas.testAreaDirtyFlag) ~= 0) then
		p21:writeTestAreasStream(p22, p23)
	end
end
function TestAreas.readTestAreasStream(p25, p26, _)
	local v27 = p25.spec_testAreas
	for v28 = 1, #v27.testAreas do
		v27.testAreas[v28].hasContact = false
	end
	local v29 = false
	local v30 = 0
	local v31 = 0
	for v32 = 1, #v27.testAreas do
		local v33 = v27.testAreas[v32]
		v33.hasContact = streamReadBool(p26)
		if v33.hasContact then
			v30 = v32
			v29 = true
			break
		end
	end
	if v29 then
		for v34 = #v27.testAreas, 1, -1 do
			local v35 = v27.testAreas[v34]
			v35.hasContact = streamReadBool(p26)
			if v35.hasContact then
				v31 = v34
				break
			end
		end
	end
	if v30 ~= 0 and v31 ~= 0 then
		for v36 = v30, v31 do
			v27.testAreas[v36].hasContact = true
		end
	end
end
function TestAreas.writeTestAreasStream(p37, p38, _)
	local v39 = p37.spec_testAreas
	local v40 = false
	for v41 = 1, #v39.testAreas do
		local v42 = v39.testAreas[v41]
		streamWriteBool(p38, v42.hasContact)
		if v42.hasContact then
			v40 = true
			break
		end
	end
	if v40 then
		for v43 = #v39.testAreas, 1, -1 do
			local v44 = v39.testAreas[v43]
			streamWriteBool(p38, v44.hasContact)
			if v44.hasContact then
				break
			end
		end
	end
end
function TestAreas.onUpdateTick(p45, _, _, _, _)
	local v46 = p45.spec_testAreas
	for v47, v48 in pairs(v46.testAreasByWorkArea) do
		if p45:getIsWorkAreaActive(v47) then
			v47.testAreaCurrentWidthMin = (-1 / 0)
			v47.testAreaCurrentWidthMax = (1 / 0)
			local v49 = #v48
			local v50 = v49
			local v51 = -1
			local v52 = false
			for v53 = 1, v49 do
				local v54 = v48[v53]
				if p45:processTestArea(v54) then
					v47.testAreaCurrentWidthMin = v54.minWidthValue
					v47.testAreaCurrentWidthMax = v54.maxWidthValue
					v51 = v53
					v52 = true
					break
				end
				v49 = v49 - 1
			end
			if v52 then
				local v55 = false
				for v56 = v50, v51 + 1, -1 do
					local v57 = v48[v56]
					if v55 then
						v57.hasContact = true
					elseif p45:processTestArea(v57) then
						v47.testAreaCurrentWidthMax = v57.maxWidthValue
						v55 = true
					else
						v49 = v49 - 1
					end
				end
			end
			if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
				local v58 = localToWorld
				local v59 = v47.testAreaRootNode
				local v60 = v47.testAreaCurrentWidthMin
				local v61 = v47.testAreaMinX
				local v62, v63, v64 = v58(v59, math.max(v60, v61), 0, 0)
				local v65 = localToWorld
				local v66 = v47.testAreaRootNode
				local v67 = v47.testAreaCurrentWidthMax
				local v68 = v47.testAreaMaxX
				local v69, v70, v71 = v65(v66, math.min(v67, v68), 0, 0)
				drawDebugLine(v62, v63, v64, 0, 1, 0, v62, v63 + 2, v64, 0, 1, 0)
				drawDebugLine(v69, v70, v71, 0, 1, 0, v69, v70 + 1, v71, 0, 1, 0)
			end
		else
			v47.testAreaCurrentWidthMin = (-1 / 0)
			v47.testAreaCurrentWidthMax = (1 / 0)
		end
	end
end
function TestAreas.loadWorkAreaFromXML(p_u_72, p73, p_u_74, p_u_75, p76)
	if not p73(p_u_72, p_u_74, p_u_75, p76) then
		return false
	end
	if not Platform.gameplay.allowTestAreas and p_u_75:hasProperty(p76 .. ".testAreas") then
		Logging.xmlWarning(p_u_75, "TestAreas not allowed on this platform in \'%s\'", p76)
	end
	p_u_74.automaticTestAreas = p_u_75:getValue(p76 .. ".testAreas#autoGenerate", false)
	p_u_74.testAreaRootNode = p_u_75:getValue(p76 .. ".testAreas#rootNode", nil, p_u_72.components, p_u_72.i3dMappings)
	p_u_74.testAreaStartNode = p_u_75:getValue(p76 .. ".testAreas#startNode", p_u_74.start, p_u_72.components, p_u_72.i3dMappings)
	p_u_74.testAreaWidthNode = p_u_75:getValue(p76 .. ".testAreas#widthNode", p_u_74.width, p_u_72.components, p_u_72.i3dMappings)
	p_u_74.testAreaXOffset = p_u_75:getValue(p76 .. ".testAreas#xOffset", 0)
	p_u_74.testAreaZOffset = p_u_75:getValue(p76 .. ".testAreas#zOffset", 0)
	p_u_74.testAreaNumAreas = p_u_75:getValue(p76 .. ".testAreas#numAreas", 10)
	p_u_74.testAreaLength = p_u_75:getValue(p76 .. ".testAreas#length", 0.5)
	p_u_74.testAreaWidthScale = p_u_75:getValue(p76 .. ".testAreas#areaWidthScale", 0.9)
	p_u_74.testAreaScale = p_u_75:getValue(p76 .. ".testAreas#scale", 1)
	p_u_74.testAreaMinX = 0
	p_u_74.testAreaMaxX = 0
	if p_u_74.automaticTestAreas then
		if p_u_74.testAreaRootNode == nil then
			p_u_74.testAreaRootNode = createTransformGroup("testAreaRootNode")
			link(getParent(p_u_74.testAreaStartNode), p_u_74.testAreaRootNode)
			local v77, v78, v79 = getWorldTranslation(p_u_74.testAreaStartNode)
			local v80, v81, v82 = getWorldTranslation(p_u_74.testAreaWidthNode)
			setWorldTranslation(p_u_74.testAreaRootNode, (v77 + v80) * 0.5, (v78 + v81) * 0.5, (v79 + v82) * 0.5)
		end
		p_u_72:generateTestAreasForWorkArea(p_u_74)
	else
		if p_u_74.testAreaRootNode == nil then
			p_u_74.testAreaRootNode = p_u_72.components[1].node
		end
		p_u_75:iterate(p76 .. ".testAreas.testArea", function(_, p83)
			-- upvalues: (copy) p_u_75, (copy) p_u_72, (copy) p_u_74
			local v84 = {
				["start"] = p_u_75:getValue(p83 .. "#startNode", nil, p_u_72.components, p_u_72.i3dMappings),
				["width"] = p_u_75:getValue(p83 .. "#widthNode", nil, p_u_72.components, p_u_72.i3dMappings),
				["height"] = p_u_75:getValue(p83 .. "#heightNode", nil, p_u_72.components, p_u_72.i3dMappings)
			}
			if v84.start ~= nil and (v84.width ~= nil and v84.height ~= nil) then
				p_u_72:calculateTestAreaDimensions(p_u_74, v84)
				p_u_72:registerTestAreaForWorkArea(p_u_74, v84)
			end
		end)
	end
	p_u_74.hasTestAreas = p_u_74.testAreaRootNode ~= nil
	p_u_74.testAreaCurrentWidthMin = (-1 / 0)
	p_u_74.testAreaCurrentWidthMax = (1 / 0)
	return true
end
function TestAreas.generateTestAreasForWorkArea(p85, p86)
	p86.testAreaParent = createTransformGroup("testAreaParent")
	link(getParent(p86.testAreaStartNode), p86.testAreaParent)
	setTranslation(p86.testAreaParent, getTranslation(p86.testAreaStartNode))
	local v87, v88, v89 = localToLocal(p86.testAreaStartNode, p86.testAreaWidthNode, 0, 0, 0)
	local v90, v91, v92 = MathUtil.vector3Normalize(v87, v88, v89)
	local v93, v94, v95 = localDirectionToLocal(p86.testAreaStartNode, getParent(p86.testAreaStartNode), v90, v91, v92)
	I3DUtil.setDirection(p86.testAreaParent, v93, v94, v95, 0, 1, 0)
	local v96 = calcDistanceFrom(p86.testAreaStartNode, p86.testAreaWidthNode)
	local v97 = v96 * p86.testAreaScale / p86.testAreaNumAreas
	local v98 = -v96 * (1 - p86.testAreaScale) * 0.5
	local v99 = v97 * (1 - p86.testAreaWidthScale) * 0.5 + p86.testAreaXOffset
	for v100 = 1, p86.testAreaNumAreas do
		local v101 = createTransformGroup(string.format("testArea%dStart", v100))
		local v102 = createTransformGroup(string.format("testArea%dWidth", v100))
		local v103 = createTransformGroup(string.format("testArea%dHeight", v100))
		link(p86.testAreaParent, v101)
		link(p86.testAreaParent, v102)
		link(p86.testAreaParent, v103)
		local v104 = -((v100 - 1) * v97) - v99 + v98
		local v105 = -(v100 * v97) + v99 + v98
		setTranslation(v101, -(p86.testAreaZOffset + p86.testAreaLength), 0, v104)
		setTranslation(v102, -(p86.testAreaZOffset + p86.testAreaLength), 0, v105)
		setTranslation(v103, -p86.testAreaZOffset, 0, v104)
		local v106 = {
			["start"] = v101,
			["width"] = v102,
			["height"] = v103,
			["areaSideOffset"] = v99
		}
		p85:calculateTestAreaDimensions(p86, v106)
		p85:registerTestAreaForWorkArea(p86, v106)
	end
end
function TestAreas.calculateTestAreaDimensions(_, p107, p108)
	p108.areaSideOffset = p108.areaSideOffset or 0
	local v109, _, _ = worldToLocal(p107.testAreaRootNode, getWorldTranslation(p108.start))
	local v110, _, _ = worldToLocal(p107.testAreaRootNode, getWorldTranslation(p108.width))
	p108.minWidthValue = v109 + p108.areaSideOffset
	p108.maxWidthValue = v110 - p108.areaSideOffset
	local v111 = p107.testAreaMinX
	local v112 = p108.minWidthValue
	local v113 = p108.maxWidthValue
	p107.testAreaMinX = math.min(v111, v112, v113)
	local v114 = p107.testAreaMaxX
	local v115 = p108.minWidthValue
	local v116 = p108.maxWidthValue
	p107.testAreaMaxX = math.max(v114, v115, v116)
end
function TestAreas.registerTestAreaForWorkArea(p117, p118, p119)
	p119.hasContact = false
	p119.hasContactSent = false
	local v120 = p117.spec_testAreas
	if v120.testAreasByWorkArea[p118] == nil then
		v120.testAreasByWorkArea[p118] = {}
	end
	local v121 = v120.testAreasByWorkArea[p118]
	table.insert(v121, p119)
	local v122 = v120.testAreas
	table.insert(v122, p119)
end
function TestAreas.setTestAreaRequirements(p123, p124, p125, p126)
	local v127 = p123.spec_testAreas
	if p124 == FruitType.UNKNOWN then
		p124 = nil
	end
	if p125 == FillType.UNKNOWN then
		p125 = nil
	end
	v127.fruitTypeIndex = p124
	v127.fillTypeIndex = p125
	v127.allowsForageGrowthState = p126
end
function TestAreas.getIsTestAreaActive(_, _)
	return true
end
function TestAreas.processTestArea(p128, p129)
	local v130 = p128.spec_testAreas
	local v131, _, v132 = getWorldTranslation(p129.start)
	local v133, _, v134 = getWorldTranslation(p129.width)
	local v135, _, v136 = getWorldTranslation(p129.height)
	if p128.isServer and (v130.fruitTypeIndex ~= nil or v130.fillTypeIndex ~= nil) then
		if p128:getIsTestAreaActive(p129) then
			if v130.fruitTypeIndex == nil then
				p129.hasContact = DensityMapHeightUtil.getFillLevelAtArea(v130.fillTypeIndex, v131, v132, v133, v134, v135, v136) > 0
			else
				local v137, _, _, _ = FSDensityMapUtil.getFruitArea(v130.fruitTypeIndex, v131, v132, v133, v134, v135, v136, nil, v130.allowsForageGrowthState)
				p129.hasContact = v137 > 0
			end
			if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
				local v138, v139, v140, v141, v142, v143 = MathUtil.getXZWidthAndHeight(v131, v132, v133, v134, v135, v136)
				DebugUtil.drawDebugParallelogram(v138, v139, v140, v141, v142, v143, 0.2, p129.hasContact and 0 or 1, p129.hasContact and 1 or 0, 0, 0.5)
				DebugGizmo.renderAtNode(p129.start, getName(p129.start), true, 1, true)
				DebugGizmo.renderAtNode(p129.width, getName(p129.width), true, 1, true)
				DebugGizmo.renderAtNode(p129.height, getName(p129.height), true, 1, true)
			end
			if p129.hasContactSent ~= p129.hasContact then
				p128:raiseDirtyFlags(v130.testAreaDirtyFlag)
				p129.hasContactSent = p129.hasContact
			end
		end
	elseif (v130.fruitTypeIndex ~= nil or v130.fillTypeIndex ~= nil) and VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
		local v144, v145, v146, v147, v148, v149 = MathUtil.getXZWidthAndHeight(v131, v132, v133, v134, v135, v136)
		DebugUtil.drawDebugParallelogram(v144, v145, v146, v147, v148, v149, 0.2, p129.hasContact and 0 or 1, p129.hasContact and 1 or 0, 0, 0.5)
	end
	return p129.hasContact
end
function TestAreas.getTestAreaWidthByWorkAreaIndex(p150, p151)
	local v152 = p150.spec_testAreas
	local v153 = p150:getWorkAreaByIndex(p151)
	if v153 == nil then
		return (-1 / 0), (1 / 0), 0, 0, false
	end
	if v152.testAreasByWorkAreaIndex[p151] ~= nil then
		return v153.testAreaCurrentWidthMin, v153.testAreaCurrentWidthMax, v153.testAreaMinX, v153.testAreaMaxX, true
	end
	local v154 = p150:getWorkAreaWidth(p151) * 0.5
	return -v154, v154, -v154, v154, false
end
function TestAreas.getTestAreaChargeByWorkAreaIndex(p155, p156)
	local v157 = p155.spec_testAreas.testAreasByWorkAreaIndex[p156]
	if v157 == nil then
		return 1
	end
	local v158 = 0
	for v159 = 1, #v157 do
		if v157[v159].hasContact then
			v158 = v158 + 1
		end
	end
	return v158 / #v157
end

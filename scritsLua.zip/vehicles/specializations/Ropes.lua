Ropes = {}
function Ropes.prerequisitesPresent(_)
	return true
end
function Ropes.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Ropes")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.ropes.rope(?)#baseNode", "Base node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.ropes.rope(?)#targetNode", "Target node")
	v1:register(XMLValueType.VECTOR_4, "vehicle.ropes.rope(?)#baseParameters", "Base parameters")
	v1:register(XMLValueType.VECTOR_4, "vehicle.ropes.rope(?)#targetParameters", "Target parameters")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.ropes.rope(?).baseParameterAdjuster(?)#node", "Adjuster node")
	v1:register(XMLValueType.INT, "vehicle.ropes.rope(?).baseParameterAdjuster(?)#rotationAxis", "Rotation axis")
	v1:register(XMLValueType.VECTOR_ROT_2, "vehicle.ropes.rope(?).baseParameterAdjuster(?)#rotationRange", "Rotation range")
	v1:register(XMLValueType.INT, "vehicle.ropes.rope(?).baseParameterAdjuster(?)#translationAxis", "Translation axis")
	v1:register(XMLValueType.VECTOR_2, "vehicle.ropes.rope(?).baseParameterAdjuster(?)#translationRange", "Translation range")
	v1:register(XMLValueType.VECTOR_4, "vehicle.ropes.rope(?).baseParameterAdjuster(?)#minTargetParameters", "Min. target parameters")
	v1:register(XMLValueType.VECTOR_4, "vehicle.ropes.rope(?).baseParameterAdjuster(?)#maxTargetParameters", "Max. target parameters")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.ropes.rope(?).targetParameterAdjuster(?)#node", "Adjuster node")
	v1:register(XMLValueType.INT, "vehicle.ropes.rope(?).targetParameterAdjuster(?)#rotationAxis", "Rotation axis")
	v1:register(XMLValueType.VECTOR_ROT_2, "vehicle.ropes.rope(?).targetParameterAdjuster(?)#rotationRange", "Rotation range")
	v1:register(XMLValueType.INT, "vehicle.ropes.rope(?).targetParameterAdjuster(?)#translationAxis", "Translation axis")
	v1:register(XMLValueType.VECTOR_2, "vehicle.ropes.rope(?).targetParameterAdjuster(?)#translationRange", "Translation range")
	v1:register(XMLValueType.VECTOR_4, "vehicle.ropes.rope(?).targetParameterAdjuster(?)#minTargetParameters", "Min. target parameters")
	v1:register(XMLValueType.VECTOR_4, "vehicle.ropes.rope(?).targetParameterAdjuster(?)#maxTargetParameters", "Max. target parameters")
	v1:setXMLSpecializationType()
end
function Ropes.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "loadAdjusterNode", Ropes.loadAdjusterNode)
	SpecializationUtil.registerFunction(p2, "updateRopes", Ropes.updateRopes)
	SpecializationUtil.registerFunction(p2, "updateAdjusterNodes", Ropes.updateAdjusterNodes)
end
function Ropes.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", Ropes)
	SpecializationUtil.registerEventListener(p3, "onLoadFinished", Ropes)
	SpecializationUtil.registerEventListener(p3, "onPostUpdate", Ropes)
end
function Ropes.onLoad(p4, _)
	local v5 = p4.spec_ropes
	if p4.isClient then
		v5.ropes = {}
		for _, v6 in p4.xmlFile:iterator("vehicle.ropes.rope") do
			local v7 = {
				["baseNode"] = p4.xmlFile:getValue(v6 .. "#baseNode", nil, p4.components, p4.i3dMappings),
				["targetNode"] = p4.xmlFile:getValue(v6 .. "#targetNode", nil, p4.components, p4.i3dMappings),
				["baseParameters"] = p4.xmlFile:getValue(v6 .. "#baseParameters", nil, true)
			}
			if v7.baseParameters == nil then
				Logging.xmlWarning(p4.xmlFile, "Missing values for \'%s\'", v6 .. "#baseParameters")
			else
				v7.targetParameters = p4.xmlFile:getValue(v6 .. "#targetParameters", nil, true)
				if v7.targetParameters == nil then
					Logging.xmlWarning(p4.xmlFile, "Missing values for \'%s\'", v6 .. "#targetParameters")
				else
					setShaderParameter(v7.baseNode, "cv0", v7.baseParameters[1], v7.baseParameters[2], v7.baseParameters[3], v7.baseParameters[4], false)
					setShaderParameter(v7.baseNode, "cv1", 0, 0, 0, 0, false)
					local v8, v9, v10 = localToLocal(v7.targetNode, v7.baseNode, v7.targetParameters[1], v7.targetParameters[2], v7.targetParameters[3])
					setShaderParameter(v7.baseNode, "cv3", v8, v9, v10, 0, false)
					v7.baseParameterAdjusters = {}
					for _, v11 in p4.xmlFile:iterator(v6 .. "baseParameterAdjuster") do
						local v12 = {}
						if p4:loadAdjusterNode(v12, p4.xmlFile, v11) then
							local v13 = v7.baseParameterAdjusters
							table.insert(v13, v12)
						end
					end
					v7.targetParameterAdjusters = {}
					for _, v14 in p4.xmlFile:iterator(v6 .. "targetParameterAdjuster") do
						local v15 = {}
						if p4:loadAdjusterNode(v15, p4.xmlFile, v14) then
							local v16 = v7.targetParameterAdjusters
							table.insert(v16, v15)
						end
					end
					local v17 = v5.ropes
					table.insert(v17, v7)
				end
			end
		end
	end
	if not p4.isClient or #v5.ropes == 0 then
		SpecializationUtil.removeEventListener(p4, "onLoadFinished", Ropes)
		SpecializationUtil.removeEventListener(p4, "onPostUpdate", Ropes)
	end
end
function Ropes.onLoadFinished(p18, _)
	p18:updateRopes(9999)
end
function Ropes.onUpdate(p19, p20, p21, p22, p23)
	Ropes.onPostUpdate(p19, p20, p21, p22, p23)
end
function Ropes.onPostUpdate(p24, p25, _, _, _)
	p24:updateRopes(p25)
end
function Ropes.loadAdjusterNode(p26, p27, p28, p29)
	XMLUtil.checkDeprecatedXMLElements(p28, p29 .. "#index", p29 .. "#node")
	local v30 = p28:getValue(p29 .. "#node", nil, p26.components, p26.i3dMappings)
	if v30 == nil then
		Logging.xmlWarning(p26.xmlFile, "Missing node attribute in \'%s\'", p29)
		return false
	end
	p27.node = v30
	p27.rotationAxis = p28:getValue(p29 .. "#rotationAxis", 1)
	p27.rotationRange = p28:getValue(p29 .. "#rotationRange", nil, true)
	p27.translationAxis = p28:getValue(p29 .. "#translationAxis", 1)
	p27.translationRange = p28:getValue(p29 .. "#translationRange", nil, true)
	p27.minTargetParameters = p28:getValue(p29 .. "#minTargetParameters", nil, true)
	if p27.minTargetParameters == nil then
		Logging.xmlWarning(p26.xmlFile, "Missing minTargetParameters attribute in \'%s\'", p29)
		return false
	end
	p27.maxTargetParameters = p28:getValue(p29 .. "#maxTargetParameters", nil, true)
	if p27.maxTargetParameters ~= nil then
		return true
	end
	Logging.xmlWarning(p26.xmlFile, "Missing maxTargetParameters attribute in \'%s\'", p29)
	return false
end
function Ropes.updateRopes(p31, _)
	local v32 = p31.spec_ropes
	for _, v33 in pairs(v32.ropes) do
		local v34, v35, v36 = p31:updateAdjusterNodes(v33.baseParameterAdjusters)
		setShaderParameter(v33.baseNode, "cv0", v33.baseParameters[1] + v34, v33.baseParameters[2] + v35, v33.baseParameters[3] + v36, 0, false)
		local v37, v38, v39 = localToLocal(v33.targetNode, v33.baseNode, 0, 0, 0)
		setShaderParameter(v33.baseNode, "cv2", 0, 0, 0, 0, false)
		setShaderParameter(v33.baseNode, "cv3", v37, v38, v39, 0, false)
		local v40, v41, v42 = p31:updateAdjusterNodes(v33.targetParameterAdjusters)
		local v43, v44, v45 = localToLocal(v33.targetNode, v33.baseNode, v33.targetParameters[1] + v40, v33.targetParameters[2] + v41, v33.targetParameters[3] + v42)
		setShaderParameter(v33.baseNode, "cv4", v43, v44, v45, 0, false)
	end
end
function Ropes.updateAdjusterNodes(_, p46)
	local v47 = 0
	local v48 = 0
	local v49 = 0
	for _, v50 in pairs(p46) do
		if v50.rotationAxis == nil or v50.rotationRange == nil then
			if v50.translationAxis ~= nil and v50.translationRange ~= nil then
				local v51 = (({ getTranslation(v50.node) })[v50.translationAxis] - v50.translationRange[1]) / (v50.translationRange[2] - v50.translationRange[1])
				local v52 = math.min(1, v51)
				local v53 = math.max(0, v52)
				local v54, v55, v56 = MathUtil.vector3ArrayLerp(v50.minTargetParameters, v50.maxTargetParameters, v53)
				v47 = v47 + v54
				v48 = v48 + v55
				v49 = v49 + v56
			end
		else
			local v57 = (({ getRotation(v50.node) })[v50.rotationAxis] - v50.rotationRange[1]) / (v50.rotationRange[2] - v50.rotationRange[1])
			local v58 = math.min(1, v57)
			local v59 = math.max(0, v58)
			local v60, v61, v62 = MathUtil.vector3ArrayLerp(v50.minTargetParameters, v50.maxTargetParameters, v59)
			v47 = v47 + v60
			v48 = v48 + v61
			v49 = v49 + v62
		end
	end
	return v47, v48, v49
end

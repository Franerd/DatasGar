AILoadable = {}
function AILoadable.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(FillUnit, p1)
end
function AILoadable.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("FillUnit")
	v2:register(XMLValueType.BOOL, FillUnit.FILL_UNIT_XML_KEY .. "#allowAILoading", "Allows ai loading", false)
	v2:register(XMLValueType.NODE_INDEX, FillUnit.FILL_UNIT_XML_KEY .. "#aiLoadingNode", "AI loading node", "exactFillRootNode")
	v2:setXMLSpecializationType()
end
function AILoadable.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getAILoadingNodeZAlignedOffset", AILoadable.getAILoadingNodeZAlignedOffset)
	SpecializationUtil.registerFunction(p3, "getAIFillUnits", AILoadable.getAIFillUnits)
	SpecializationUtil.registerFunction(p3, "aiPrepareLoading", AILoadable.aiPrepareLoading)
	SpecializationUtil.registerFunction(p3, "aiFinishLoading", AILoadable.aiFinishLoading)
	SpecializationUtil.registerFunction(p3, "aiStartLoadingFromTrigger", AILoadable.aiStartLoadingFromTrigger)
	SpecializationUtil.registerFunction(p3, "aiStoppedLoadingFromTrigger", AILoadable.aiStoppedLoadingFromTrigger)
	SpecializationUtil.registerFunction(p3, "aiCancelLoadingFromTrigger", AILoadable.aiCancelLoadingFromTrigger)
	SpecializationUtil.registerFunction(p3, "aiFinishedLoadingFromTrigger", AILoadable.aiFinishedLoadingFromTrigger)
	SpecializationUtil.registerFunction(p3, "getAIHasFinishedLoading", AILoadable.getAIHasFinishedLoading)
end
function AILoadable.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadFillUnitFromXML", AILoadable.loadFillUnitFromXML)
end
function AILoadable.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onPreLoad", AILoadable)
	SpecializationUtil.registerEventListener(p5, "onLoad", AILoadable)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", AILoadable)
	SpecializationUtil.registerEventListener(p5, "onUpdate", AILoadable)
end
function AILoadable.onPreLoad(p6)
	p6.spec_aiLoadable.aiFillUnits = {}
end
function AILoadable.onLoad(p7)
	p7.spec_aiLoadable.currentFillUnitIndex = nil
end
function AILoadable.onPostLoad(p8)
	local v9 = p8.spec_aiLoadable
	if v9.aiFillUnits ~= nil then
		for _, v10 in ipairs(v9.aiFillUnits) do
			v10.inputAttacherJointOffsets = {}
			if p8.getInputAttacherJoints ~= nil then
				for _, v11 in ipairs(p8:getInputAttacherJoints()) do
					local v12, v13, v14 = localToLocal(v10.aiLoadingNode, v11.node, 0, 0, 0)
					local v15 = v10.inputAttacherJointOffsets
					table.insert(v15, { v12, v13, v14 })
				end
			end
			if p8.getAIRootNode ~= nil then
				local v16 = p8:getAIRootNode()
				v10.aiRootNodeOffsets = { localToLocal(v10.aiLoadingNode, v16, 0, 0, 0) }
			end
		end
	end
end
function AILoadable.onUpdate(p17, _, _, _, _)
	local v18 = p17.spec_aiLoadable
	if v18.currentFillUnitIndex ~= nil and (not v18.isAILoadingRunning and p17:getAIHasFinishedLoading(v18.currentFillUnitIndex)) then
		p17:aiFinishedLoadingFromTrigger()
	end
end
function AILoadable.loadFillUnitFromXML(p19, p20, p21, p22, p23, p24)
	if not p20(p19, p21, p22, p23, p24) then
		return false
	end
	p23.allowAILoading = p21:getValue(p22 .. "#allowAILoading", false)
	if p23.allowAILoading then
		p23.aiLoadingNode = p21:getValue(p22 .. "#aiLoadingNode", nil, p19.components, p19.i3dMappings) or p23.exactFillRootNode
		if p23.aiLoadingNode == nil then
			Logging.xmlWarning(p19.xmlFile, "AILoadingNode not found for fillUnit \'%s\'!", p22)
		else
			local v25 = p19.spec_aiLoadable.aiFillUnits
			table.insert(v25, p23)
		end
	end
	return true
end
function AILoadable.getAIFillUnits(p26)
	return p26.spec_aiLoadable.aiFillUnits
end
function AILoadable.getAILoadingNodeZAlignedOffset(p27, p28, p29)
	local v30 = p27:getFillUnitByIndex(p28)
	if p29 == p27 then
		return v30.aiRootNodeOffsets[1], v30.aiRootNodeOffsets[2], v30.aiRootNodeOffsets[3]
	end
	local v31 = p27:getActiveInputAttacherJointDescIndex()
	local v32 = v30.inputAttacherJointOffsets[v31]
	local v33 = v32[1]
	local v34 = v32[2]
	local v35 = v32[3]
	local v36 = p27:getAttacherVehicle()
	while p29 ~= v36 do
		local v37 = v36:getAttacherJointDescFromObject(p27)
		local v38 = v36:getActiveInputAttacherJointDescIndex()
		local v39 = v37.inputAttacherJointOffsets[v38]
		local v40, v41, v42, v43, v44, v45, v46, v47, v48, v49, v50, v51 = unpack(v39)
		local v52 = v40 + v49 * v33 + v46 * v34 + v43 * v35
		local v53 = v41 + v50 * v33 + v47 * v34 + v44 * v35
		v35 = v42 + v51 * v33 + v48 * v34 + v45 * v35
		local v54 = v36:getAttacherVehicle()
		v34 = v53
		v33 = v52
		p27 = v36
		v36 = v54
	end
	local v55 = p29:getAttacherJointDescFromObject(p27).aiRootNodeOffset
	local v56, v57, v58, v59, v60, v61, v62, v63, v64, v65, v66, v67 = unpack(v55)
	return v56 + v65 * v33 + v62 * v34 + v59 * v35, v57 + v66 * v33 + v63 * v34 + v60 * v35, v58 + v67 * v33 + v64 * v34 + v61 * v35
end
function AILoadable.aiPrepareLoading(_, _, _) end
function AILoadable.aiStartLoadingFromTrigger(p68, p69, p70, p71, p72)
	local v73 = p68.spec_aiLoadable
	v73.task = p72
	v73.isAILoadingRunning = true
	v73.currentFillUnitIndex = p70
	p69:setIsLoading(true, p68, p70, p71, false)
end
function AILoadable.aiCancelLoadingFromTrigger(p74, p75, p76, p77, _)
	p75:setIsLoading(false, p74, p76, p77, false)
end
function AILoadable.aiStoppedLoadingFromTrigger(p78)
	p78.spec_aiLoadable.isAILoadingRunning = false
end
function AILoadable.aiFinishedLoadingFromTrigger(p79)
	local v80 = p79.spec_aiLoadable
	if v80.task ~= nil then
		v80.task:finishedLoading()
	end
	v80.currentFillUnitIndex = nil
	v80.task = nil
end
function AILoadable.aiFinishLoading(_, _, _) end
function AILoadable.getAIHasFinishedLoading(_, _)
	return true
end

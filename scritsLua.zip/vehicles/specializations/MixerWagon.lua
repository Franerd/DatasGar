source("dataS/scripts/vehicles/specializations/events/MixerWagonBaleNotAcceptedEvent.lua")
MixerWagon = {}
source("dataS/scripts/gui/hud/extensions/MixerWagonHUDExtension.lua")
function MixerWagon.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Trailer, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p1)
	end
	return v2
end
function MixerWagon.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("MixerWagon")
	AnimationManager.registerAnimationNodesXMLPaths(v3, "vehicle.mixerWagon.mixAnimationNodes")
	AnimationManager.registerAnimationNodesXMLPaths(v3, "vehicle.mixerWagon.pickupAnimationNodes")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.mixerWagon.baleTriggers.baleTrigger(?)#node", "Bale trigger node")
	v3:register(XMLValueType.FLOAT, "vehicle.mixerWagon.baleTriggers.baleTrigger(?)#pickupSpeed", "Bale pickup speed in liter per second", 500)
	v3:register(XMLValueType.BOOL, "vehicle.mixerWagon.baleTriggers.baleTrigger(?)#needsSetIsTurnedOn", "Vehicle needs to be turned on to pickup bales with this trigger", false)
	v3:register(XMLValueType.BOOL, "vehicle.mixerWagon.baleTriggers.baleTrigger(?)#useEffect", "Filling effect is played while picking up a bale", false)
	v3:register(XMLValueType.TIME, "vehicle.mixerWagon#mixingTime", "Mixing time after the fill level was changed", 5)
	v3:register(XMLValueType.INT, "vehicle.mixerWagon#fillUnitIndex", "Fill unit index", 1)
	v3:register(XMLValueType.STRING, "vehicle.mixerWagon#recipe", "Recipe fill type name")
	EffectManager.registerEffectXMLPaths(v3, "vehicle.mixerWagon.fillEffect")
	v3:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.FLOAT, "vehicles.vehicle(?).mixerWagon.fillType(?)#fillLevel", "Fill level", 0)
end
function MixerWagon.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "mixerWagonBaleTriggerCallback", MixerWagon.mixerWagonBaleTriggerCallback)
	SpecializationUtil.registerFunction(p4, "onMixerWagonBaleDeleted", MixerWagon.onMixerWagonBaleDeleted)
end
function MixerWagon.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "addFillUnitFillLevel", MixerWagon.addFillUnitFillLevel)
	SpecializationUtil.registerOverwrittenFunction(p5, "getFillUnitAllowsFillType", MixerWagon.getFillUnitAllowsFillType)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDischargeFillType", MixerWagon.getDischargeFillType)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsBaleAutoLoadable", MixerWagon.getIsBaleAutoLoadable)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDoConsumePtoPower", MixerWagon.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p5, "getConsumingLoad", MixerWagon.getConsumingLoad)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsPowerTakeOffActive", MixerWagon.getIsPowerTakeOffActive)
end
function MixerWagon.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onDelete", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onReadStream", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onUpdate", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onDraw", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onTurnedOn", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", MixerWagon)
	SpecializationUtil.registerEventListener(p6, "onFillUnitFillLevelChanged", MixerWagon)
end
function MixerWagon.onLoad(p_u_7, _)
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagonBaleTrigger#index", "vehicle.mixerWagon.baleTrigger#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagon.baleTrigger#index", "vehicle.mixerWagon.baleTrigger#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagonPickupStartSound", "vehicle.turnOnVehicle.sounds.start")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagonPickupStopSound", "vehicle.turnOnVehicle.sounds.stop")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagonPickupSound", "vehicle.turnOnVehicle.sounds.work")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagonRotatingParts.mixerWagonRotatingPart#type", "vehicle.mixerWagon.mixAnimationNodes.animationNode", "mixerWagonMix")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagonRotatingParts.mixerWagonRotatingPart#type", "vehicle.mixerWagon.pickupAnimationNodes.animationNode", "mixerWagonPickup")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagonRotatingParts.mixerWagonScroller", "vehicle.mixerWagon.pickupAnimationNodes.pickupAnimationNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mixerWagon.baleTrigger#node", "vehicle.mixerWagon.baleTriggers.baleTrigger#node")
	local v_u_8 = p_u_7.spec_mixerWagon
	if p_u_7.isClient then
		v_u_8.mixAnimationNodes = g_animationManager:loadAnimations(p_u_7.xmlFile, "vehicle.mixerWagon.mixAnimationNodes", p_u_7.components, p_u_7, p_u_7.i3dMappings)
		v_u_8.pickupAnimationNodes = g_animationManager:loadAnimations(p_u_7.xmlFile, "vehicle.mixerWagon.pickupAnimationNodes", p_u_7.components, p_u_7, p_u_7.i3dMappings)
		v_u_8.fillEffects = g_effectManager:loadEffect(p_u_7.xmlFile, "vehicle.mixerWagon.fillEffect", p_u_7.components, p_u_7, p_u_7.i3dMappings)
		v_u_8.fillEffectsFillType = FillType.UNKNOWN
		v_u_8.fillEffectsState = false
	end
	if p_u_7.isServer then
		v_u_8.baleTriggers = {}
		p_u_7.xmlFile:iterate("vehicle.mixerWagon.baleTriggers.baleTrigger", function(_, p9)
			-- upvalues: (copy) p_u_7, (copy) v_u_8
			local v10 = {
				["node"] = p_u_7.xmlFile:getValue(p9 .. "#node", nil, p_u_7.components, p_u_7.i3dMappings)
			}
			if v10.node ~= nil then
				addTrigger(v10.node, "mixerWagonBaleTriggerCallback", p_u_7)
				v10.pickupSpeed = p_u_7.xmlFile:getValue(p9 .. "#pickupSpeed", 500) / 1000
				v10.needsSetIsTurnedOn = p_u_7.xmlFile:getValue(p9 .. "#needsSetIsTurnedOn", false)
				v10.useEffect = p_u_7.xmlFile:getValue(p9 .. "#useEffect", false)
				v10.balesInTrigger = {}
				local v11 = v_u_8.baleTriggers
				table.insert(v11, v10)
			end
		end)
	end
	v_u_8.activeTimerMax = p_u_7.xmlFile:getValue("vehicle.mixerWagon#mixingTime", 5)
	v_u_8.activeTimer = 0
	v_u_8.fillUnitIndex = p_u_7.xmlFile:getValue("vehicle.mixerWagon#fillUnitIndex", 1)
	v_u_8.mixerWagonFillTypes = {}
	v_u_8.fillTypeToMixerWagonFillType = {}
	local v12 = p_u_7.xmlFile:getValue("vehicle.mixerWagon#recipe")
	if v12 ~= nil then
		local v13 = g_fillTypeManager:getFillTypeIndexByName(v12)
		if v13 == nil then
			Logging.xmlError(p_u_7.xmlFile, "MixerWagon recipe \'%s\' not defined!", v12)
		end
		local v14 = g_currentMission.animalFoodSystem:getRecipeByFillTypeIndex(v13)
		if v14 == nil then
			Logging.xmlWarning(p_u_7.xmlFile, "MixerWagon recipe \'%s\' not defined!", v12)
		end
		if v14 ~= nil then
			for _, v15 in ipairs(v14.ingredients) do
				local v16 = {
					["fillLevel"] = 0,
					["fillTypes"] = {},
					["name"] = v15.name,
					["minPercentage"] = v15.minPercentage,
					["maxPercentage"] = v15.maxPercentage,
					["ratio"] = v15.ratio
				}
				for _, v17 in ipairs(v15.fillTypes) do
					v16.fillTypes[v17] = true
					v_u_8.fillTypeToMixerWagonFillType[v17] = v16
				end
				local v18 = v_u_8.mixerWagonFillTypes
				table.insert(v18, v16)
			end
		end
	end
	if #v_u_8.mixerWagonFillTypes > 0 then
		local v19 = p_u_7:getFillUnitByIndex(v_u_8.fillUnitIndex)
		if v19 ~= nil then
			v19.needsSaving = false
			v19.synchronizeFillLevel = false
		end
	end
	v_u_8.dirtyFlag = p_u_7:getNextDirtyFlag()
	v_u_8.effectDirtyFlag = p_u_7:getNextDirtyFlag()
	v_u_8.hudExtension = MixerWagonHUDExtension.new(p_u_7)
end
function MixerWagon.onPostLoad(p20, p21)
	if p21 ~= nil then
		local v22 = p20.spec_mixerWagon
		for v23, v24 in ipairs(v22.mixerWagonFillTypes) do
			local v25 = p21.key .. string.format(".mixerWagon.fillType(%d)#fillLevel", v23 - 1)
			local v26 = p21.xmlFile:getValue(v25, 0)
			if v26 > 0 then
				p20:addFillUnitFillLevel(p20:getOwnerFarmId(), v22.fillUnitIndex, v26, next(v24.fillTypes), ToolType.UNDEFINED, nil)
			end
		end
	end
	if p20.spec_hudInfoTrigger == nil or p20.spec_hudInfoTrigger.triggerNode == nil then
		Logging.xmlDevWarning(p20.xmlFile, "Missing hudInfoTrigger for mixer wagon. Required for external mixer wagon hud visibility!")
	end
end
function MixerWagon.onDelete(p27)
	local v28 = p27.spec_mixerWagon
	if v28.baleTriggers ~= nil then
		for v29 = 1, #v28.baleTriggers do
			removeTrigger(v28.baleTriggers[v29].node)
		end
	end
	g_animationManager:deleteAnimations(v28.mixAnimationNodes)
	g_animationManager:deleteAnimations(v28.pickupAnimationNodes)
	g_effectManager:deleteEffects(v28.fillEffects)
	if v28.hudExtension ~= nil then
		g_currentMission.hud:removeInfoExtension(v28.hudExtension)
		v28.hudExtension:delete()
	end
end
function MixerWagon.saveToXMLFile(p30, p31, p32, _)
	local v33 = p30.spec_mixerWagon
	for v34, v35 in ipairs(v33.mixerWagonFillTypes) do
		p31:setValue(string.format("%s.fillType(%d)", p32, v34 - 1) .. "#fillLevel", v35.fillLevel)
	end
end
function MixerWagon.onReadStream(p36, p37, _)
	local v38 = p36.spec_mixerWagon
	for _, v39 in ipairs(v38.mixerWagonFillTypes) do
		local v40 = streamReadFloat32(p37)
		if v40 > 0 then
			p36:addFillUnitFillLevel(p36:getOwnerFarmId(), v38.fillUnitIndex, v40, next(v39.fillTypes), ToolType.UNDEFINED, nil)
		end
	end
	v38.fillEffectsFillType = streamReadUIntN(p37, FillTypeManager.SEND_NUM_BITS)
end
function MixerWagon.onWriteStream(p41, p42, _)
	local v43 = p41.spec_mixerWagon
	for _, v44 in ipairs(v43.mixerWagonFillTypes) do
		streamWriteFloat32(p42, v44.fillLevel)
	end
	streamWriteUIntN(p42, v43.fillEffectsFillType, FillTypeManager.SEND_NUM_BITS)
end
function MixerWagon.onReadUpdateStream(p45, p46, _, p47)
	if p47:getIsServer() then
		local v48 = p45.spec_mixerWagon
		if streamReadBool(p46) then
			for _, v49 in ipairs(v48.mixerWagonFillTypes) do
				local v50 = streamReadFloat32(p46) - v49.fillLevel
				if v50 ~= 0 then
					p45:addFillUnitFillLevel(p45:getOwnerFarmId(), v48.fillUnitIndex, v50, next(v49.fillTypes), ToolType.UNDEFINED, nil)
				end
			end
		end
		if streamReadBool(p46) then
			v48.fillEffectsFillType = streamReadUIntN(p46, FillTypeManager.SEND_NUM_BITS)
		end
	end
end
function MixerWagon.onWriteUpdateStream(p51, p52, p53, p54)
	if not p53:getIsServer() then
		local v55 = p51.spec_mixerWagon
		if streamWriteBool(p52, bitAND(p54, v55.dirtyFlag) ~= 0) then
			for _, v56 in ipairs(v55.mixerWagonFillTypes) do
				streamWriteFloat32(p52, v56.fillLevel)
			end
		end
		if streamWriteBool(p52, bitAND(p54, v55.effectDirtyFlag) ~= 0) then
			streamWriteUIntN(p52, v55.fillEffectsFillType, FillTypeManager.SEND_NUM_BITS)
		end
	end
end
function MixerWagon.onUpdate(p57, p58, _, _, _)
	local v59 = p57.spec_mixerWagon
	local v60 = p57:getTipState()
	local v61 = p57:getIsTurnedOn()
	local v62 = v60 == Trailer.TIPSTATE_OPENING and true or v60 == Trailer.TIPSTATE_OPEN
	if p57:getIsPowered() and (v59.activeTimer > 0 or (v61 or v62)) then
		v59.activeTimer = v59.activeTimer - p58
		g_animationManager:startAnimations(v59.mixAnimationNodes)
	else
		g_animationManager:stopAnimations(v59.mixAnimationNodes)
	end
	if p57.isServer then
		local v63 = FillType.UNKNOWN
		if p57:getFillUnitFreeCapacity(v59.fillUnitIndex) > 0 then
			for v64 = 1, #v59.baleTriggers do
				local v65 = v59.baleTriggers[v64]
				if not v65.needsSetIsTurnedOn or p57:getIsTurnedOn() then
					for v66, _ in pairs(v65.balesInTrigger) do
						local v67 = v66:getFillLevel()
						local v68 = v65.pickupSpeed * p58
						local v69 = math.min(v68, v67)
						local v70 = v66:getFillType()
						local v71 = v67 - p57:addFillUnitFillLevel(p57:getOwnerFarmId(), v59.fillUnitIndex, v69, v70, ToolType.BALE, nil)
						v66:setFillLevel(v71)
						if v71 < 0.01 then
							v66:delete()
							v65.balesInTrigger[v66] = nil
						end
						if v65.useEffect then
							v63 = v70
						end
					end
				end
			end
		end
		local v72
		if v63 == FillType.UNKNOWN and p57.getIsShovelEffectState ~= nil then
			local v73
			v73, v72 = p57:getIsShovelEffectState()
			if not v73 then
				v72 = v63
			end
		else
			v72 = v63
		end
		if v59.fillEffectsFillType ~= v72 then
			v59.fillEffectsFillType = v72
			p57:raiseDirtyFlags(v59.effectDirtyFlag)
		end
	end
	if p57.isClient then
		local v74 = v59.fillEffectsFillType ~= FillType.UNKNOWN
		if v74 ~= v59.fillEffectsState then
			if v74 then
				g_effectManager:setEffectTypeInfo(v59.fillEffects, v59.fillEffectsFillType)
				g_effectManager:startEffects(v59.fillEffects)
			else
				g_effectManager:stopEffects(v59.fillEffects)
			end
			v59.fillEffectsState = v74
		end
	end
end
function MixerWagon.onDraw(p75)
	local v76 = p75.spec_mixerWagon
	if v76.hudExtension ~= nil then
		g_currentMission.hud:addInfoExtension(v76.hudExtension)
	end
end
function MixerWagon.mixerWagonBaleTriggerCallback(p77, p78, p79, p80, p81, _, _)
	if p79 ~= 0 then
		local v82 = g_currentMission:getNodeObject(p79)
		if v82 ~= nil and v82:isa(Bale) then
			local v83 = p77.spec_mixerWagon
			if p77:getFillUnitSupportsFillType(v83.fillUnitIndex, v82:getFillType()) then
				for v84 = 1, #v83.baleTriggers do
					local v85 = v83.baleTriggers[v84]
					if v85.node == p78 then
						if p80 then
							v85.balesInTrigger[v82] = (v85.balesInTrigger[v82] or 0) + 1
							if v85.balesInTrigger[v82] == 1 then
								v82:addDeleteListener(p77, p77.onMixerWagonBaleDeleted)
							end
						elseif p81 then
							v85.balesInTrigger[v82] = (v85.balesInTrigger[v82] or 1) - 1
							if v85.balesInTrigger[v82] == 0 then
								v85.balesInTrigger[v82] = nil
								v82:removeDeleteListener(p77, p77.onMixerWagonBaleDeleted)
							end
						end
					end
				end
				return
			end
			if p80 and p79 == v82.nodeId then
				g_currentMission:broadcastEventToFarm(MixerWagonBaleNotAcceptedEvent.new(), p77:getOwnerFarmId(), true)
			end
		end
	end
end
function MixerWagon.onMixerWagonBaleDeleted(p86, p87)
	local v88 = p86.spec_mixerWagon
	for v89 = 1, #v88.baleTriggers do
		v88.baleTriggers[v89].balesInTrigger[p87] = nil
	end
end
function MixerWagon.addFillUnitFillLevel(p90, p91, p92, p93, p94, p95, p96, p97)
	local v98 = p90.spec_mixerWagon
	if p93 ~= v98.fillUnitIndex then
		return p91(p90, p92, p93, p94, p95, p96, p97)
	end
	if #v98.mixerWagonFillTypes == 0 then
		if p94 ~= 0 and p90:getIsSynchronized() then
			v98.activeTimer = v98.activeTimerMax
		end
		return p91(p90, p92, p93, p94, p95, p96, p97)
	end
	local v99 = p90:getFillUnitFillLevel(p93)
	local v100 = v98.fillTypeToMixerWagonFillType[p95]
	if p95 == FillType.FORAGE and p94 > 0 then
		for _, v101 in pairs(v98.mixerWagonFillTypes) do
			p90:addFillUnitFillLevel(p92, p93, p94 * v101.ratio, next(v101.fillTypes), p96, p97)
		end
		return p94
	end
	if v100 == nil then
		if p94 >= 0 or v99 <= 0 then
			return 0
		end
		local v102 = -v99
		local v103 = math.max(p94, v102)
		local v104 = 0
		for _, v105 in pairs(v98.mixerWagonFillTypes) do
			local v106 = v103 * (v105.fillLevel / v99)
			local v107 = v105.fillLevel + v106
			v105.fillLevel = math.max(v107, 0)
			v104 = v104 + v105.fillLevel
		end
		if v104 < 0.1 then
			for _, v108 in pairs(v98.mixerWagonFillTypes) do
				v108.fillLevel = 0
			end
			v103 = -v99
		end
		p90:raiseDirtyFlags(v98.dirtyFlag)
		return p91(p90, p92, p93, v103, p95, p96, p97)
	end
	local v109 = p90:getFillUnitCapacity(p93) - v99
	if p94 > 0 then
		v100.fillLevel = v100.fillLevel + math.min(v109, p94)
		if p90:getIsSynchronized() then
			v98.activeTimer = v98.activeTimerMax
		end
	else
		local v110 = v100.fillLevel + p94
		v100.fillLevel = math.max(0, v110)
	end
	local v111 = 0
	for _, v112 in pairs(v98.mixerWagonFillTypes) do
		v111 = v111 + v112.fillLevel
	end
	local v113 = math.clamp(v111, 0, p90:getFillUnitCapacity(p93))
	local v114 = FillType.UNKNOWN
	local v115 = false
	local v116 = false
	for _, v117 in pairs(v98.mixerWagonFillTypes) do
		if v113 == v117.fillLevel then
			v114 = next(v100.fillTypes)
			v116 = true
			break
		end
	end
	if not v116 then
		v115 = true
		for _, v118 in pairs(v98.mixerWagonFillTypes) do
			if v118.fillLevel < v118.minPercentage * v113 - 0.01 or v118.fillLevel > v118.maxPercentage * v113 + 0.01 then
				v115 = false
				break
			end
		end
	end
	if v115 then
		v114 = FillType.FORAGE
	elseif not v116 then
		v114 = FillType.FORAGE_MIXING
	end
	p90:raiseDirtyFlags(v98.dirtyFlag)
	p90:setFillUnitFillType(p93, v114)
	return p91(p90, p92, p93, v113 - v99, v114, p96, p97)
end
function MixerWagon.getFillUnitAllowsFillType(p119, p120, p121, p122)
	local v123 = p119.spec_mixerWagon
	return v123.fillUnitIndex == p121 and (#v123.mixerWagonFillTypes > 0 and v123.fillTypeToMixerWagonFillType[p122] ~= nil) and true or p120(p119, p121, p122)
end
function MixerWagon.getDischargeFillType(p124, p125, p126)
	local v127 = p124.spec_mixerWagon
	local v128 = p126.fillUnitIndex
	if v128 ~= v127.fillUnitIndex then
		return p125(p124, p126)
	end
	local v129 = p124:getFillUnitFillType(v128)
	local v130 = p124:getFillUnitFillLevel(v128)
	if v129 == FillType.FORAGE_MIXING and v130 > 0 then
		for _, v131 in pairs(v127.mixerWagonFillTypes) do
			if v131.fillLevel > 0 then
				v129 = next(v131.fillTypes)
				break
			end
		end
	end
	return v129, 1
end
function MixerWagon.getIsBaleAutoLoadable(p132, p133, p134)
	local v135 = p132.spec_mixerWagon
	if p132:getIsTurnedOn() then
		for v136 = 1, #v135.baleTriggers do
			local v137 = v135.baleTriggers[v136]
			if next(v137.balesInTrigger) ~= nil then
				return false
			end
		end
		local v138 = p132:getFillUnitFillType(v135.fillUnitIndex)
		if v138 == FillType.UNKNOWN or p134:getFillType() == v138 then
			if p132:getFillUnitFreeCapacity(v135.fillUnitIndex) <= 0 then
				return false
			else
				return p133(p132, p134)
			end
		else
			return false
		end
	else
		return false
	end
end
function MixerWagon.getDoConsumePtoPower(p139, p140)
	return p139.spec_mixerWagon.activeTimer > 0 and true or p140(p139)
end
function MixerWagon.getConsumingLoad(p141, p142)
	local v143, v144 = p142(p141)
	return v143 + (p141.spec_mixerWagon.activeTimer > 0 and 1 or 0), v144 + 1
end
function MixerWagon.getIsPowerTakeOffActive(p145, p146)
	return p145.spec_mixerWagon.activeTimer > 0 and true or p146(p145)
end
function MixerWagon.onFillUnitFillLevelChanged(p147, p148, _, _, _, _, _)
	local v149 = p147.spec_mixerWagon
	if v149.fillUnitIndex == p148 and p147:getFillUnitFillLevel(p148) == 0 then
		for _, v150 in pairs(v149.mixerWagonFillTypes) do
			v150.fillLevel = 0
		end
	end
end
function MixerWagon.onTurnedOn(p151)
	if p151.isClient then
		local v152 = p151.spec_mixerWagon
		g_animationManager:startAnimations(v152.pickupAnimationNodes)
	end
end
function MixerWagon.onTurnedOff(p153)
	if p153.isClient then
		local v154 = p153.spec_mixerWagon
		g_animationManager:stopAnimations(v154.pickupAnimationNodes)
	end
end
function MixerWagon.updateDebugValues(p155, p156)
	local v157 = p155.spec_mixerWagon
	local v158 = {
		["name"] = "Forage isOK"
	}
	local v159 = p155:getFillUnitFillType(v157.fillUnitIndex) == FillType.FORAGE
	v158.value = tostring(v159)
	table.insert(p156, v158)
	for _, v160 in ipairs(v157.mixerWagonFillTypes) do
		local v161 = ""
		for v162, _ in pairs(v160.fillTypes) do
			local v163 = g_fillTypeManager
			v161 = v161 .. " " .. tostring(v163:getFillTypeNameByIndex(v162))
		end
		local v164 = {
			["name"] = v161,
			["value"] = v160.fillLevel
		}
		table.insert(p156, v164)
	end
end

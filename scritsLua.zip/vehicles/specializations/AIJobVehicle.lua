source("dataS/scripts/vehicles/specializations/events/AIJobVehicleStateEvent.lua")
AIJobVehicle = {}
function AIJobVehicle.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AIVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Drivable, p1)
	end
	return v2
end
function AIJobVehicle.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("AIJobVehicle")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.ai.steeringNode#node", "Steering node")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.ai.reverserNode#node", "Reverser node")
	v3:register(XMLValueType.FLOAT, "vehicle.ai.steeringSpeed", "Speed of steering", 1)
	v3:register(XMLValueType.BOOL, "vehicle.ai#supportsAIJobs", "If true vehicle supports ai jobs", true)
	v3:setXMLSpecializationType()
	local v4 = Vehicle.xmlSchemaSavegame
	v4:register(XMLValueType.BOOL, "vehicles.vehicle(?).aiJobVehicle#isAIStartAllowed", "If ai start is allowed", true)
	v4:register(XMLValueType.BOOL, "vehicles.vehicle(?).aiJobVehicle#isAIStopAllowed", "If ai stop is allowed", true)
end
function AIJobVehicle.registerEvents(p5)
	SpecializationUtil.registerEvent(p5, "onAIJobStarted")
	SpecializationUtil.registerEvent(p5, "onAIJobFinished")
	SpecializationUtil.registerEvent(p5, "onAIJobVehicleBlock")
	SpecializationUtil.registerEvent(p5, "onAIJobVehicleContinue")
end
function AIJobVehicle.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "getShowAIToggleActionEvent", AIJobVehicle.getShowAIToggleActionEvent)
	SpecializationUtil.registerFunction(p6, "stopCurrentAIJob", AIJobVehicle.stopCurrentAIJob)
	SpecializationUtil.registerFunction(p6, "skipCurrentTask", AIJobVehicle.skipCurrentTask)
	SpecializationUtil.registerFunction(p6, "aiJobStarted", AIJobVehicle.aiJobStarted)
	SpecializationUtil.registerFunction(p6, "aiJobFinished", AIJobVehicle.aiJobFinished)
	SpecializationUtil.registerFunction(p6, "toggleAIVehicle", AIJobVehicle.toggleAIVehicle)
	SpecializationUtil.registerFunction(p6, "getCanToggleAIVehicle", AIJobVehicle.getCanToggleAIVehicle)
	SpecializationUtil.registerFunction(p6, "getCanStartAIVehicle", AIJobVehicle.getCanStartAIVehicle)
	SpecializationUtil.registerFunction(p6, "getCanStopAIVehicle", AIJobVehicle.getCanStopAIVehicle)
	SpecializationUtil.registerFunction(p6, "setAIMapHotspotBlinking", AIJobVehicle.setAIMapHotspotBlinking)
	SpecializationUtil.registerFunction(p6, "getCurrentHelper", AIJobVehicle.getCurrentHelper)
	SpecializationUtil.registerFunction(p6, "aiBlock", AIJobVehicle.aiBlock)
	SpecializationUtil.registerFunction(p6, "aiContinue", AIJobVehicle.aiContinue)
	SpecializationUtil.registerFunction(p6, "getAIDirectionNode", AIJobVehicle.getAIDirectionNode)
	SpecializationUtil.registerFunction(p6, "getAISteeringNode", AIJobVehicle.getAISteeringNode)
	SpecializationUtil.registerFunction(p6, "getAIReverserNode", AIJobVehicle.getAIReverserNode)
	SpecializationUtil.registerFunction(p6, "getAISteeringSpeed", AIJobVehicle.getAISteeringSpeed)
	SpecializationUtil.registerFunction(p6, "getAIJobFarmId", AIJobVehicle.getAIJobFarmId)
	SpecializationUtil.registerFunction(p6, "getStartableAIJob", AIJobVehicle.getStartableAIJob)
	SpecializationUtil.registerFunction(p6, "getHasStartableAIJob", AIJobVehicle.getHasStartableAIJob)
	SpecializationUtil.registerFunction(p6, "getStartAIJobText", AIJobVehicle.getStartAIJobText)
	SpecializationUtil.registerFunction(p6, "getJob", AIJobVehicle.getJob)
	SpecializationUtil.registerFunction(p6, "getLastJob", AIJobVehicle.getLastJob)
	SpecializationUtil.registerFunction(p6, "setIsAIStartAllowed", AIJobVehicle.setIsAIStartAllowed)
	SpecializationUtil.registerFunction(p6, "setIsAIStopAllowed", AIJobVehicle.setIsAIStopAllowed)
end
function AIJobVehicle.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsVehicleControlledByPlayer", AIJobVehicle.getIsVehicleControlledByPlayer)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsActive", AIJobVehicle.getIsActive)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsAIActive", AIJobVehicle.getIsAIActive)
	SpecializationUtil.registerOverwrittenFunction(p7, "getAllowTireTracks", AIJobVehicle.getAllowTireTracks)
	SpecializationUtil.registerOverwrittenFunction(p7, "getDeactivateOnLeave", AIJobVehicle.getDeactivateOnLeave)
	SpecializationUtil.registerOverwrittenFunction(p7, "getStopMotorOnLeave", AIJobVehicle.getStopMotorOnLeave)
	SpecializationUtil.registerOverwrittenFunction(p7, "getDisableVehicleCharacterOnLeave", AIJobVehicle.getDisableVehicleCharacterOnLeave)
	SpecializationUtil.registerOverwrittenFunction(p7, "getFullName", AIJobVehicle.getFullName)
	SpecializationUtil.registerOverwrittenFunction(p7, "getActiveFarm", AIJobVehicle.getActiveFarm)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsMapHotspotVisible", AIJobVehicle.getIsMapHotspotVisible)
	SpecializationUtil.registerOverwrittenFunction(p7, "getMapHotspot", AIJobVehicle.getMapHotspot)
	SpecializationUtil.registerOverwrittenFunction(p7, "getDeactivateLightsOnLeave", AIJobVehicle.getDeactivateLightsOnLeave)
end
function AIJobVehicle.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", AIJobVehicle)
	SpecializationUtil.registerEventListener(p8, "onDelete", AIJobVehicle)
	SpecializationUtil.registerEventListener(p8, "onUpdate", AIJobVehicle)
	SpecializationUtil.registerEventListener(p8, "onSetBroken", AIJobVehicle)
	SpecializationUtil.registerEventListener(p8, "onReadStream", AIJobVehicle)
	SpecializationUtil.registerEventListener(p8, "onWriteStream", AIJobVehicle)
	SpecializationUtil.registerEventListener(p8, "onAIModeChanged", AIJobVehicle)
end
function AIJobVehicle.onLoad(p9, p10)
	local v11 = p9.spec_aiJobVehicle
	v11.actionEvents = {}
	v11.job = nil
	v11.lastJob = nil
	v11.startedFarmId = nil
	v11.aiSteeringSpeed = p9.xmlFile:getValue("vehicle.ai.steeringSpeed", 1) * 0.001
	v11.steeringNode = p9.xmlFile:getValue("vehicle.ai.steeringNode#node", nil, p9.components, p9.i3dMappings)
	v11.reverserNode = p9.xmlFile:getValue("vehicle.ai.reverserNode#node", nil, p9.components, p9.i3dMappings)
	v11.supportsAIJobs = p9.xmlFile:getValue("vehicle.ai#supportsAIJobs", true)
	v11.isAIStartAllowed = true
	v11.isAIStopAllowed = true
	v11.texts = {}
	v11.texts.dismissEmployee = g_i18n:getText("action_dismissEmployee")
	v11.texts.openHelperMenu = g_i18n:getText("action_openHelperMenu")
	v11.texts.hireEmployee = g_i18n:getText("action_hireEmployee")
	if p10 ~= nil then
		local v12 = g_currentMission.aiJobTypeManager
		local v13 = p10.key .. ".aiJobVehicle"
		local v14 = v13 .. ".lastJob"
		local v15 = v12:getJobTypeIndexByName((p10.xmlFile:getString(v14 .. "#type")))
		if v15 ~= nil then
			local v16 = v12:createJob(v15)
			if v16 ~= nil and v16.loadFromXMLFile ~= nil then
				v16:loadFromXMLFile(p10.xmlFile, v14)
				v11.lastJob = v16
			end
		end
		v11.isAIStartAllowed = p10.xmlFile:getValue(v13 .. "#isAIStartAllowed", v11.isAIStartAllowed)
		v11.isAIStopAllowed = p10.xmlFile:getValue(v13 .. "#isAIStopAllowed", v11.isAIStopAllowed)
	end
end
function AIJobVehicle.onDelete(p17)
	local v18 = p17.spec_aiJobVehicle
	if v18.job ~= nil then
		p17:stopCurrentAIJob()
	end
	if v18.mapAIHotspot ~= nil then
		v18.mapAIHotspot:delete()
		v18.mapAIHotspot = nil
	end
end
function AIJobVehicle.onReadStream(p19, p20, p21)
	if streamReadBool(p20) then
		local v22 = streamReadInt32(p20)
		local v23 = streamReadUIntN(p20, FarmManager.FARM_ID_SEND_NUM_BITS)
		local v24 = streamReadUInt8(p20)
		p19:aiJobStarted(g_currentMission.aiSystem:getJobById(v22), v24, v23)
	end
	if streamReadBool(p20) then
		local v25 = streamReadInt32(p20)
		local v26 = p19.spec_aiJobVehicle
		v26.lastJob = g_currentMission.aiJobTypeManager:createJob(v25)
		v26.lastJob:readStream(p20, p21)
	end
end
function AIJobVehicle.onWriteStream(p27, p28, p29)
	local v30 = p27.spec_aiJobVehicle
	if streamWriteBool(p28, v30.job ~= nil) then
		streamWriteInt32(p28, v30.job.jobId)
		streamWriteUIntN(p28, v30.startedFarmId, FarmManager.FARM_ID_SEND_NUM_BITS)
		streamWriteUInt8(p28, v30.currentHelper.index)
	end
	if streamWriteBool(p28, v30.lastJob ~= nil) then
		local v31 = g_currentMission.aiJobTypeManager:getJobTypeIndex(v30.lastJob)
		streamWriteInt32(p28, v31)
		v30.lastJob:writeStream(p28, p29)
	end
end
function AIJobVehicle.onAIModeChanged(p32, p33)
	if p33 ~= AIModeSelection.MODE.WORKER and p32.spec_aiJobVehicle.job ~= nil then
		p32:stopCurrentAIJob(AIMessageSuccessStoppedByUser.new())
	end
end
function AIJobVehicle.onUpdate(p34, _, _, _, _)
	if p34:getIsAIActive() then
		p34:raiseActive()
	end
end
function AIJobVehicle.getShowAIToggleActionEvent(p35)
	if p35:getAIDirectionNode() == nil then
		return false
	elseif g_currentMission.disableAIVehicle then
		return false
	elseif g_currentMission:getHasPlayerPermission("hireAssistant") then
		return (p35:getIsAIActive() or not g_currentMission.aiSystem:getAILimitedReached()) and true or false
	else
		return false
	end
end
function AIJobVehicle.stopCurrentAIJob(p36, p37)
	local v38 = p36.spec_aiJobVehicle
	if v38.job ~= nil then
		g_currentMission.aiSystem:stopJob(v38.job, p37)
	end
end
function AIJobVehicle.skipCurrentTask(p39)
	local v40 = p39.spec_aiJobVehicle
	if v40.job ~= nil then
		g_currentMission.aiSystem:skipCurrentTask(v40.job)
	end
end
function AIJobVehicle.aiJobStarted(p41, p42, p43, p44)
	local v45 = p41.spec_aiJobVehicle
	if not p41:getIsAIActive() then
		if p41.isServer then
			g_server:broadcastEvent(AIJobVehicleStateEvent.new(p41, p42, p43, p44))
			g_currentMission.aiSystem:addJobVehicle(p41)
		end
		v45.job = p42
		v45.lastJob = p42
		v45.startedFarmId = p44
		v45.currentHelperIndex = p43
		v45.currentHelper = g_helperManager:getHelperByIndex(p43)
		g_helperManager:useHelper(v45.currentHelper)
		if p41.isServer then
			g_farmManager:updateFarmStats(p44, "workersHired", 1)
		end
		if p41.setRandomVehicleCharacter ~= nil then
			p41:setRandomVehicleCharacter(v45.currentHelper)
		end
		if v45.mapAIHotspot == nil then
			v45.mapAIHotspot = AIHotspot.new()
			v45.mapAIHotspot:setVehicle(p41)
		end
		v45.mapAIHotspot:setAIHelperName(v45.currentHelper.name)
		g_currentMission:addMapHotspot(v45.mapAIHotspot)
		if Platform.isMobile then
			p41:updateMapHotspot()
		end
		SpecializationUtil.raiseEvent(p41, "onAIJobStarted", p42)
		p41:requestActionEventUpdate()
		p41:raiseActive()
	end
	g_messageCenter:publish(MessageType.AI_VEHICLE_STATE_CHANGE, true, p41)
end
function AIJobVehicle.aiJobFinished(p46)
	local v47 = p46.spec_aiJobVehicle
	if p46:getIsAIActive() then
		if p46.isServer then
			g_server:broadcastEvent(AIJobVehicleStateEvent.new(p46, nil, nil, nil))
			g_currentMission.aiSystem:removeJobVehicle(p46)
		end
		g_helperManager:releaseHelper(v47.currentHelper)
		v47.currentHelperIndex = nil
		v47.currentHelper = nil
		if p46.isServer then
			g_farmManager:updateFarmStats(v47.startedFarmId, "workersHired", -1)
		end
		if p46.restoreVehicleCharacter ~= nil then
			p46:restoreVehicleCharacter()
		end
		if v47.mapAIHotspot ~= nil then
			g_currentMission:removeMapHotspot(v47.mapAIHotspot)
		end
		SpecializationUtil.raiseEvent(p46, "onAIJobFinished", v47.job)
		v47.job = nil
		if Platform.isMobile then
			p46:updateMapHotspot()
		end
		p46:requestActionEventUpdate()
	end
	g_messageCenter:publish(MessageType.AI_VEHICLE_STATE_CHANGE, false, p46)
end
function AIJobVehicle.getIsVehicleControlledByPlayer(p48, p49)
	if p49(p48) then
		return p48.spec_aiJobVehicle.job == nil
	else
		return false
	end
end
function AIJobVehicle.getIsInUse(p50, p51, p52)
	return p50:getIsAIActive() and true or p51(p50, p52)
end
function AIJobVehicle.getIsActive(p53, p54)
	return p53:getIsAIActive() and true or p54(p53)
end
function AIJobVehicle.getAIJobFarmId(p55)
	return p55.spec_aiJobVehicle.startedFarmId
end
function AIJobVehicle.getIsAIActive(p56, p57)
	return p57(p56) or p56.spec_aiJobVehicle.job ~= nil
end
function AIJobVehicle.getStartableAIJob(_)
	return nil
end
function AIJobVehicle.getHasStartableAIJob(_)
	return false
end
function AIJobVehicle.getStartAIJobText(p58)
	local v59 = p58.spec_aiJobVehicle
	if p58:getHasStartableAIJob() then
		return v59.texts.hireEmployee
	else
		return v59.texts.openHelperMenu
	end
end
function AIJobVehicle.getJob(p60)
	return p60.spec_aiJobVehicle.job
end
function AIJobVehicle.getLastJob(p61)
	return p61.spec_aiJobVehicle.lastJob
end
function AIJobVehicle.toggleAIVehicle(p62)
	if p62:getIsAIActive() then
		p62:stopCurrentAIJob(AIMessageSuccessStoppedByUser.new())
		return
	else
		local v63 = p62:getStartableAIJob()
		if v63 == nil then
			if g_guidedTourManager:getIsTourRunning() then
				return
			elseif Platform.isMobile then
				g_gui:changeScreen(nil, InGameMenu)
				g_messageCenter:publish(MessageType.GUI_INGAME_OPEN_AI_SCREEN, p62)
				local v64 = g_currentMission.hud:getIngameMap()
				v64:updateHotspotSorting()
				local v65 = g_inGameMenu.pageMapMobile.inGameMap:getPlayerHotspot(v64.hotspotsSorted[true])
				g_inGameMenu.pageMapMobile:onClickHotspot(nil, v65)
				g_inGameMenu.pageMapMobile:onClickPagingAI()
			else
				g_gui:showGui("InGameMenu")
				g_messageCenter:publish(MessageType.GUI_INGAME_OPEN_AI_SCREEN, p62)
			end
		else
			g_client:getServerConnection():sendEvent(AIJobStartRequestEvent.new(v63, p62:getOwnerFarmId()))
			return
		end
	end
end
function AIJobVehicle.getCanToggleAIVehicle(p66)
	if p66:getIsAIActive() then
		return p66:getCanStopAIVehicle()
	else
		return p66:getCanStartAIVehicle()
	end
end
function AIJobVehicle.getCanStopAIVehicle(p67)
	return p67.spec_aiJobVehicle.isAIStopAllowed and true or false
end
function AIJobVehicle.getCanStartAIVehicle(p68)
	if g_currentMission.disableAIVehicle then
		return false
	elseif p68:getOwnerFarmId() == AccessHandler.EVERYONE then
		return false
	else
		local v69 = p68.spec_aiJobVehicle
		if v69.supportsAIJobs then
			if v69.isAIStartAllowed then
				if p68:getAIDirectionNode() == nil then
					return false
				elseif g_currentMission.aiSystem:getAILimitedReached() then
					return false
				elseif p68:getIsAIActive() then
					return false
				else
					return not p68.isBroken
				end
			else
				return false
			end
		else
			return false
		end
	end
end
function AIJobVehicle.setIsAIStartAllowed(p70, p71)
	p70.spec_aiJobVehicle.isAIStartAllowed = p71
end
function AIJobVehicle.setIsAIStopAllowed(p72, p73)
	p72.spec_aiJobVehicle.isAIStopAllowed = p73
end
function AIJobVehicle.setAIMapHotspotBlinking(p74, p75)
	local v76 = p74.spec_aiJobVehicle
	if v76.mapAIHotspot ~= nil then
		v76.mapAIHotspot:setBlinking(p75)
	end
end
function AIJobVehicle.getMapHotspot(p77, p78)
	local v79 = p77.spec_aiJobVehicle
	if p77:getIsAIActive() and v79.mapAIHotspot ~= nil then
		return v79.mapAIHotspot
	else
		return p78(p77)
	end
end
function AIJobVehicle.getDeactivateLightsOnLeave(p80, p81)
	local v82 = p81(p80)
	if v82 then
		v82 = not p80:getIsAIActive()
	end
	return v82
end
function AIJobVehicle.onSetBroken(p83)
	if p83:getIsAIActive() then
		p83:stopCurrentAIJob(AIMessageErrorVehicleBroken.new())
	end
end
function AIJobVehicle.getDeactivateOnLeave(p84, p85)
	local v86 = p85(p84)
	if v86 then
		v86 = not p84:getIsAIActive()
	end
	return v86
end
function AIJobVehicle.getStopMotorOnLeave(p87, p88)
	local v89 = p88(p87)
	if v89 then
		v89 = not p87:getIsAIActive()
	end
	return v89
end
function AIJobVehicle.getDisableVehicleCharacterOnLeave(p90, p91)
	local v92 = p91(p90)
	if v92 then
		v92 = not p90:getIsAIActive()
	end
	return v92
end
function AIJobVehicle.getAllowTireTracks(p93, p94)
	local v95 = p94(p93)
	if v95 then
		v95 = not p93:getIsAIActive()
	end
	return v95
end
function AIJobVehicle.getCurrentHelper(p96)
	return p96.spec_aiJobVehicle.currentHelper
end
function AIJobVehicle.getFullName(p97, p98)
	local v99 = p98(p97)
	if p97:getIsAIActive() then
		local v100 = g_i18n:getText("ui_helper")
		local v101 = p97:getCurrentHelper()
		if v101 ~= nil then
			v100 = v100 .. " " .. v101.name
		end
		v99 = v99 .. " (" .. v100 .. ")"
	end
	return v99
end
function AIJobVehicle.aiBlock(p102)
	if p102.isClient and g_localPlayer.farmId == p102:getAIJobFarmId() then
		local v103 = p102:getCurrentHelper()
		local v104 = v103 == nil and "" or v103.name
		local v105 = string.format(g_i18n:getText("ai_messageErrorBlockedByObject"), v104)
		g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, v105)
	end
	p102:raiseAIEvent("onAIJobVehicleBlock", "onAIImplementJobVehicleBlock")
end
function AIJobVehicle.aiContinue(p106)
	p106:raiseAIEvent("onAIJobVehicleContinue", "onAIImplementJobVehicleContinue")
end
function AIJobVehicle.getAIDirectionNode(p107)
	return p107.components[1].node
end
function AIJobVehicle.getAISteeringNode(p108)
	return p108.spec_aiJobVehicle.steeringNode or p108:getAIDirectionNode()
end
function AIJobVehicle.getAIReverserNode(p109)
	return p109.spec_aiJobVehicle.reverserNode or p109:getAISteeringNode()
end
function AIJobVehicle.getAISteeringSpeed(p110)
	return p110.spec_aiJobVehicle.aiSteeringSpeed
end
function AIJobVehicle.saveToXMLFile(p111, p112, p113, p114)
	local v115 = p111.spec_aiJobVehicle
	if v115.lastJob ~= nil then
		local v116 = v115.lastJob.jobTypeIndex
		local v117 = g_currentMission.aiJobTypeManager:getJobTypeByIndex(v116)
		p112:setString(p113 .. ".lastJob#type", v117.name)
		v115.lastJob:saveToXMLFile(p112, p113 .. ".lastJob", p114)
	end
	p112:setValue(p113 .. "#isAIStartAllowed", v115.isAIStartAllowed)
end
function AIJobVehicle.saveStatsToXMLFile(p118, p119, p120)
	setXMLBool(p119, p120 .. "#isAIActive", p118:getIsAIActive())
end
function AIJobVehicle.getActiveFarm(p121, p122)
	local v123 = p121:getAIJobFarmId()
	if v123 == nil then
		return p122(p121)
	else
		return v123
	end
end
function AIJobVehicle.getIsMapHotspotVisible(p124, p125)
	if p125(p124) then
		return not p124:getIsAIActive()
	else
		return false
	end
end

CylinderedFoldable = {}
function CylinderedFoldable.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Cylindered, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Foldable, p1)
	end
	return v2
end
function CylinderedFoldable.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("CylinderedFoldable")
	v3:register(XMLValueType.BOOL, "vehicle.cylindered#loadMovingToolStatesAfterFolding", "Load moving tool states after folding state was loaded", false)
	v3:register(XMLValueType.FLOAT, "vehicle.cylindered#loadMovingToolStatesFoldTime", "Fold time in which moving tool states should be loaded")
	v3:setXMLSpecializationType()
end
function CylinderedFoldable.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", CylinderedFoldable)
	SpecializationUtil.registerEventListener(p4, "onPreInitComponentPlacement", CylinderedFoldable)
	SpecializationUtil.registerEventListener(p4, "onReadStream", CylinderedFoldable)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", CylinderedFoldable)
end
function CylinderedFoldable.onLoad(p5, _)
	local v6 = p5.spec_cylinderedFoldable
	v6.loadMovingToolStatesAfterFolding = p5.xmlFile:getValue("vehicle.cylindered#loadMovingToolStatesAfterFolding", false)
	v6.loadMovingToolStatesFoldTime = p5.xmlFile:getValue("vehicle.cylindered#loadMovingToolStatesFoldTime")
end
function CylinderedFoldable.onPreInitComponentPlacement(p7, p8)
	local v9 = p7.spec_cylinderedFoldable
	if v9.loadMovingToolStatesAfterFolding then
		local v10 = v9.loadMovingToolStatesFoldTime
		if v10 == nil or p7:getFoldAnimTime() == v10 then
			Cylindered.onPostLoad(p7, p8)
		end
	end
end
function CylinderedFoldable.onReadStream(p11, p12, p13)
	AnimatedVehicle.updateAnimations(p11, 9999999)
	if streamReadBool(p12) then
		Cylindered.onReadStream(p11, p12, p13)
	end
	if p13:getIsServer() then
		for v14 = 1, #p11.spec_cylindered.movingTools do
			local v15 = p11.spec_cylindered.movingTools[v14]
			if v15.dirtyFlag ~= nil then
				p11:updateDependentAnimations(v15, 9999)
			end
		end
	end
end
function CylinderedFoldable.onWriteStream(p16, p17, p18)
	local v19 = p16.spec_cylinderedFoldable
	if streamWriteBool(p17, v19.loadMovingToolStatesFoldTime == nil and true or p16:getFoldAnimTime() == v19.loadMovingToolStatesFoldTime) then
		Cylindered.onWriteStream(p16, p17, p18)
	end
end

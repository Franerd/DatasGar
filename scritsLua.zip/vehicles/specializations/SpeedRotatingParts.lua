SpeedRotatingParts = {}
SpeedRotatingParts.DEFAULT_MAX_UPDATE_DISTANCE = 50
SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY = "vehicle.speedRotatingParts.speedRotatingPart(?)"
function SpeedRotatingParts.prerequisitesPresent(_)
	return true
end
function SpeedRotatingParts.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("SpeedRotatingParts")
	v1:register(XMLValueType.NODE_INDEX, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#node", "Speed rotating part node")
	v1:register(XMLValueType.NODE_INDICES, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#nodes", "Speed rotating part nodes (first node will be used as main repr node and the others just copy the rotation values)")
	v1:register(XMLValueType.NODE_INDEX, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#shaderNode", "Speed rotating part shader node")
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#useRotation", "Use shader rotation", true)
	v1:register(XMLValueType.VECTOR_2, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#scrollScale", "Shader scroll speed")
	v1:register(XMLValueType.INT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#shaderComponent", "Shader parameter component to control", "Default based on available shader attributes")
	v1:register(XMLValueType.VECTOR_N, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#shaderComponentSpeeds", "Speed factor for different shader components (usable with \'vtxRotate\' shader variation)")
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#scrollLength", "Shader scroll length")
	v1:register(XMLValueType.NODE_INDEX, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#driveNode", "Drive node to apply x drive", "speedRotatingPart#node")
	v1:register(XMLValueType.INT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#refComponentIndex", "Reference component index")
	v1:register(XMLValueType.INT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#wheelIndex", "Reference wheel index")
	v1:register(XMLValueType.NODE_INDICES, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#wheelNodes", "List of reference wheel nodes (repr or drive node). The average speed of the wheels WITH ground contact is used.")
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#hasConfigWheels", "Defined wheels are part of configurations, so no warning is displayed while they are not found.", false)
	v1:register(XMLValueType.NODE_INDEX, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#dirRefNode", "Direction reference node")
	v1:register(XMLValueType.NODE_INDEX, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#dirFrameNode", "Direction reference frame")
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#alignDirection", "Align direction", false)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#applySteeringAngle", "Apply steering angle", false)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#useWheelReprTranslation", "Apply wheel repr translation", true)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#updateXDrive", "Update X drive", true)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#versatileYRot", "Versatile Y rot", false)
	v1:register(XMLValueType.ANGLE, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#minYRot", "Min. Y rotation")
	v1:register(XMLValueType.ANGLE, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#maxYRot", "Max. Y rotation")
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#wheelScale", "Wheel scale")
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#radius", "Radius", 1)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#onlyActiveWhenLowered", "Only active if lowered", false)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#stopIfNotActive", "Stop if not active", false)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#fadeOutTime", "Fade out time", 3)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#activationSpeed", "Min. speed for activation", 1)
	v1:register(XMLValueType.NODE_INDEX, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#speedReferenceNode", "Speed reference node")
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#hasTireTracks", "Has Tire Tracks", false)
	v1:register(XMLValueType.INT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#tireTrackAtlasIndex", "Index on tire track atlas", 0)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#tireTrackWidth", "Width of tire tracks", 0.5)
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#tireTrackInverted", "Tire track texture inverted", false)
	v1:register(XMLValueType.NODE_INDEX, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#tireTrackWheelNode", "Reference wheel for the tire tracks (radius, ground contact, etc)")
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#maxUpdateDistance", "Max. distance from current camera to vehicle to update part", SpeedRotatingParts.DEFAULT_MAX_UPDATE_DISTANCE)
	v1:setXMLSpecializationType()
end
function SpeedRotatingParts.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "loadSpeedRotatingPartFromXML", SpeedRotatingParts.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerFunction(p2, "getIsSpeedRotatingPartActive", SpeedRotatingParts.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerFunction(p2, "getSpeedRotatingPartDirection", SpeedRotatingParts.getSpeedRotatingPartDirection)
	SpecializationUtil.registerFunction(p2, "updateSpeedRotatingPart", SpeedRotatingParts.updateSpeedRotatingPart)
end
function SpeedRotatingParts.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "validateWashableNode", SpeedRotatingParts.validateWashableNode)
end
function SpeedRotatingParts.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", SpeedRotatingParts)
	SpecializationUtil.registerEventListener(p4, "onReadStream", SpeedRotatingParts)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", SpeedRotatingParts)
	SpecializationUtil.registerEventListener(p4, "onReadUpdateStream", SpeedRotatingParts)
	SpecializationUtil.registerEventListener(p4, "onWriteUpdateStream", SpeedRotatingParts)
	SpecializationUtil.registerEventListener(p4, "onUpdate", SpeedRotatingParts)
	SpecializationUtil.registerEventListener(p4, "onUpdateTick", SpeedRotatingParts)
end
function SpeedRotatingParts.onLoad(p5, _)
	local v6 = p5.spec_speedRotatingParts
	XMLUtil.checkDeprecatedXMLElements(p5.xmlFile, "vehicle.speedRotatingParts.speedRotatingPart(0)#index", "vehicle.speedRotatingParts.speedRotatingPart(0)#node")
	v6.individualUpdateDistance = false
	v6.speedRotatingParts = {}
	local v7 = nil
	for _, v8 in p5.xmlFile:iterator("vehicle.speedRotatingParts.speedRotatingPart") do
		local v9 = {}
		if p5:loadSpeedRotatingPartFromXML(v9, p5.xmlFile, v8) then
			local v10 = v6.speedRotatingParts
			table.insert(v10, v9)
			if v7 ~= nil and v7 ~= v9.maxUpdateDistance then
				v6.individualUpdateDistance = true
			end
			v7 = v9.maxUpdateDistance
		elseif v9.tireTrackNodeIndex ~= nil then
			p5:removeTireTrackNode(v9.tireTrackNodeIndex)
		end
	end
	v6.maxUpdateDistance = v7 or SpeedRotatingParts.DEFAULT_MAX_UPDATE_DISTANCE
	v6.dirtyFlag = p5:getNextDirtyFlag()
	if #v6.speedRotatingParts == 0 then
		SpecializationUtil.removeEventListener(p5, "onReadStream", SpeedRotatingParts)
		SpecializationUtil.removeEventListener(p5, "onWriteStream", SpeedRotatingParts)
		SpecializationUtil.removeEventListener(p5, "onReadUpdateStream", SpeedRotatingParts)
		SpecializationUtil.removeEventListener(p5, "onWriteUpdateStream", SpeedRotatingParts)
		SpecializationUtil.removeEventListener(p5, "onUpdate", SpeedRotatingParts)
		SpecializationUtil.removeEventListener(p5, "onUpdateTick", SpeedRotatingParts)
	end
end
function SpeedRotatingParts.onReadStream(p11, p12, _)
	local v13 = p11.spec_speedRotatingParts
	for v14 = 1, #v13.speedRotatingParts do
		local v15 = v13.speedRotatingParts[v14]
		if v15.versatileYRot then
			v15.steeringAngle = streamReadUIntN(p12, 9) / 511 * 3.141592653589793 * 2
		end
	end
end
function SpeedRotatingParts.onWriteStream(p16, p17, _)
	local v18 = p16.spec_speedRotatingParts
	for v19 = 1, #v18.speedRotatingParts do
		local v20 = v18.speedRotatingParts[v19]
		if v20.versatileYRot then
			local v21 = v20.steeringAngle % 6.283185307179586
			local v22 = streamWriteUIntN
			local v23 = v21 / 6.283185307179586 * 511
			local v24 = math.floor(v23)
			v22(p17, math.clamp(v24, 0, 511), 9)
		end
	end
end
function SpeedRotatingParts.onReadUpdateStream(p25, p26, _, p27)
	if p27.isServer and streamReadBool(p26) then
		local v28 = p25.spec_speedRotatingParts
		for v29 = 1, #v28.speedRotatingParts do
			local v30 = v28.speedRotatingParts[v29]
			if v30.versatileYRot then
				v30.steeringAngle = streamReadUIntN(p26, 9) / 511 * 3.141592653589793 * 2
			end
		end
	end
end
function SpeedRotatingParts.onWriteUpdateStream(p31, p32, p33, p34)
	if not p33.isServer then
		local v35 = p31.spec_speedRotatingParts
		if streamWriteBool(p32, bitAND(p34, v35.dirtyFlag) ~= 0) then
			for v36 = 1, #v35.speedRotatingParts do
				local v37 = v35.speedRotatingParts[v36]
				if v37.versatileYRot then
					local v38 = v37.steeringAngle % 6.283185307179586
					local v39 = streamWriteUIntN
					local v40 = v38 / 6.283185307179586 * 511
					local v41 = math.floor(v40)
					v39(p32, math.clamp(v41, 0, 511), 9)
				end
			end
		end
	end
end
function SpeedRotatingParts.onUpdate(p42, p43, _, _, _)
	local v44 = p42.spec_speedRotatingParts
	if v44.individualUpdateDistance or p42.currentUpdateDistance < v44.maxUpdateDistance then
		for v45 = 1, #v44.speedRotatingParts do
			local v46 = v44.speedRotatingParts[v45]
			if (not v44.individualUpdateDistance or p42.currentUpdateDistance < v46.maxUpdateDistance) and (v46.isActive or v46.lastSpeed ~= 0 and not v46.stopIfNotActive) then
				p42:updateSpeedRotatingPart(v46, p43, v46.isActive)
			end
		end
	end
end
function SpeedRotatingParts.onUpdateTick(p47, _, _, _, _)
	local v48 = p47.spec_speedRotatingParts
	if v48.individualUpdateDistance or p47.currentUpdateDistance < v48.maxUpdateDistance then
		for v49 = 1, #v48.speedRotatingParts do
			local v50 = v48.speedRotatingParts[v49]
			if not v48.individualUpdateDistance or p47.currentUpdateDistance < v50.maxUpdateDistance then
				v50.isActive = p47:getIsSpeedRotatingPartActive(v50)
			end
		end
	end
end
function SpeedRotatingParts.loadSpeedRotatingPartFromXML(p_u_51, p_u_52, p53, p54)
	XMLUtil.checkDeprecatedXMLElements(p53, p54 .. "#vtxPositionArrayFilename", "Array should be assigned properly inside i3d.")
	p_u_52.reprNodes = p53:getValue(p54 .. "#nodes", nil, p_u_51.components, p_u_51.i3dMappings, true)
	p_u_52.repr = p53:getValue(p54 .. "#node", p_u_52.reprNodes[1], p_u_51.components, p_u_51.i3dMappings)
	p_u_52.shaderNode = p53:getValue(p54 .. "#shaderNode", nil, p_u_51.components, p_u_51.i3dMappings)
	if #p_u_52.reprNodes > 0 and p_u_52.reprNodes[1] == p_u_52.repr then
		table.remove(p_u_52.reprNodes, 1)
	end
	p_u_52.shaderParameterName = "offsetUV"
	p_u_52.shaderParameterPrevName = nil
	p_u_52.shaderParameterComponent = 3
	p_u_52.shaderParameterSpeedScale = 1
	p_u_52.shaderParameterValues = {
		0,
		0,
		0,
		0
	}
	if p_u_52.shaderNode ~= nil then
		p_u_52.useShaderRotation = p53:getValue(p54 .. "#useRotation", true)
		p_u_52.scrollScale = p53:getValue(p54 .. "#scrollScale", "1 0", true)
		p_u_52.scrollLength = p53:getValue(p54 .. "#scrollLength")
		if getHasShaderParameter(p_u_52.shaderNode, "rotationAngle") then
			p_u_52.shaderParameterName = "rotationAngle"
			p_u_52.shaderParameterPrevName = "prevRotationAngle"
			p_u_52.shaderParameterComponent = 1
			p_u_52.shaderParameterSpeedScale = -1
		end
		if getHasShaderParameter(p_u_52.shaderNode, "scrollPos") then
			p_u_52.shaderParameterName = "scrollPos"
			p_u_52.shaderParameterPrevName = "prevScrollPos"
			p_u_52.shaderParameterComponent = 1
			p_u_52.shaderParameterSpeedScale = 1
		end
		p_u_52.shaderParameterComponent = p53:getValue(p54 .. "#shaderComponent", p_u_52.shaderParameterComponent)
		p_u_52.shaderComponentSpeeds = p53:getValue(p54 .. "#shaderComponentSpeeds", nil, true)
	end
	if p_u_52.repr == nil and p_u_52.shaderNode == nil then
		local v55 = Logging.xmlWarning
		local v56 = p_u_51.xmlFile
		local v57 = getXMLString(p53.handle, p54 .. "#node") or getXMLString(p53.handle, p54 .. "#shaderNode")
		v55(v56, "Invalid speedRotationPart node \'%s\' in \'%s\'", tostring(v57), p54)
		return false
	end
	p_u_52.driveNode = p53:getValue(p54 .. "#driveNode", p_u_52.repr, p_u_51.components, p_u_51.i3dMappings)
	local v58 = p53:getValue(p54 .. "#refComponentIndex")
	if v58 == nil or p_u_51.components[v58] == nil then
		p_u_52.componentNode = p_u_51:getParentComponent((Utils.getNoNil(p_u_52.driveNode, p_u_52.shaderNode)))
	else
		p_u_52.componentNode = p_u_51.components[v58].node
	end
	p_u_52.xDrive = 0
	local v59 = p53:getValue(p54 .. "#wheelIndex")
	local v60 = p53:getValue(p54 .. "#wheelNodes", nil, p_u_51.components, p_u_51.i3dMappings, true)
	if v59 ~= nil or #v60 > 0 then
		if p_u_51.getWheels == nil then
			Logging.xmlWarning(p_u_51.xmlFile, "wheelIndex for speedRotatingPart \'%s\' given, but no wheels loaded/defined", p54)
		else
			local v61 = {}
			if v59 ~= nil then
				local v62 = p_u_51:getWheelFromWheelIndex(v59)
				if v62 == nil then
					if not p53:getValue(p54 .. "#hasConfigWheels", false) then
						Logging.xmlWarning(p_u_51.xmlFile, "Invalid wheel index \'%s\' for speedRotatingPart \'%s\'", v59, p54)
					end
				else
					table.insert(v61, v62)
				end
			end
			if #v60 > 0 then
				for _, v63 in ipairs(v60) do
					local v64 = p_u_51:getWheelByWheelNode(v63)
					if v64 == nil then
						if not p53:getValue(p54 .. "#hasConfigWheels", false) then
							Logging.xmlWarning(p_u_51.xmlFile, "Invalid wheel node \'%s\' for speedRotatingPart \'%s\'", getName(v63), p54)
						end
					else
						table.insert(v61, v64)
					end
				end
			end
			if #v61 == 0 then
				return false
			end
			for _, v65 in ipairs(v61) do
				v65.syncContactState = true
				if not v65.physics.isSynchronized then
					Logging.xmlWarning(p_u_51.xmlFile, "Referenced wheel \'%s\' for speedRotatingPart \'%s\' is not synchronized in multiplayer", getName(v65.repr), p54)
				end
			end
			p_u_52.wheels = v61
			p_u_52.lastWheelXRot = {}
		end
	end
	p_u_52.hasTireTracks = p53:getValue(p54 .. "#hasTireTracks", false)
	p_u_52.tireTrackAtlasIndex = p53:getValue(p54 .. "#tireTrackAtlasIndex", 0)
	p_u_52.tireTrackWidth = p53:getValue(p54 .. "#tireTrackWidth", 0.5)
	p_u_52.tireTrackInverted = p53:getValue(p54 .. "#tireTrackInverted", false)
	p_u_52.tireTrackWheelNode = p53:getValue(p54 .. "#tireTrackWheelNode", nil, p_u_51.components, p_u_51.i3dMappings)
	if p_u_52.hasTireTracks and Platform.gameplay.wheelTireTracks then
		local function v66()
			-- upvalues: (copy) p_u_51, (copy) p_u_52
			return p_u_51:getIsSpeedRotatingPartActive(p_u_52)
		end
		local v67
		if p_u_52.wheels == nil then
			if p_u_52.tireTrackWheelNode == nil then
				Logging.xmlWarning(p_u_51.xmlFile, "Tire tracks for speedRotationPart \'%s\' defined, but no wheels or tireTrackWheelNode given", p54)
				return false
			end
			v67 = p_u_51:getWheelByWheelNode(p_u_52.tireTrackWheelNode)
		else
			v67 = p_u_52.wheels[1]
		end
		p_u_52.tireTrackNodeIndex = p_u_51:addTireTrackNode(v67, p_u_52.componentNode, p_u_52.driveNode, p_u_52.tireTrackAtlasIndex, p_u_52.tireTrackWidth, v67.physics.radius, p_u_52.tireTrackInverted, v66)
	end
	p_u_52.dirRefNode = p53:getValue(p54 .. "#dirRefNode", nil, p_u_51.components, p_u_51.i3dMappings)
	p_u_52.dirFrameNode = p53:getValue(p54 .. "#dirFrameNode", nil, p_u_51.components, p_u_51.i3dMappings)
	p_u_52.alignDirection = p53:getValue(p54 .. "#alignDirection", false)
	p_u_52.applySteeringAngle = p53:getValue(p54 .. "#applySteeringAngle", false)
	p_u_52.useWheelReprTranslation = p53:getValue(p54 .. "#useWheelReprTranslation", true)
	p_u_52.updateXDrive = p53:getValue(p54 .. "#updateXDrive", true)
	p_u_52.versatileYRot = p53:getValue(p54 .. "#versatileYRot", false)
	if p_u_52.versatileYRot and p_u_52.repr == nil then
		Logging.xmlWarning(p_u_51.xmlFile, "Versatile speedRotationPart \'%s\' does not support shaderNodes", p54)
		return false
	end
	p_u_52.minYRot = p53:getValue(p54 .. "#minYRot")
	p_u_52.maxYRot = p53:getValue(p54 .. "#maxYRot")
	p_u_52.steeringAngle = 0
	p_u_52.steeringAngleSent = 0
	p_u_52.speedReferenceNode = p53:getValue(p54 .. "#speedReferenceNode", nil, p_u_51.components, p_u_51.i3dMappings)
	if p_u_52.speedReferenceNode ~= nil and p_u_52.speedReferenceNode == p_u_52.driveNode then
		Logging.xmlWarning(p_u_51.xmlFile, "Ignoring speedRotationPart \'%s\' because speedReferenceNode is identical with driveNode. Need to be different!", p54)
		return false
	end
	p_u_52.wheelScale = p53:getValue(p54 .. "#wheelScale")
	if p_u_52.wheelScale == nil then
		local v68, v69
		if p_u_52.wheels == nil or p_u_52.speedReferenceNode ~= nil then
			v68 = 1
			v69 = 1
		else
			v69 = p_u_52.wheels[1].physics.radius
			v68 = p_u_52.wheels[1].physics.radius
		end
		p_u_52.wheelScale = v69 / p53:getValue(p54 .. "#radius", v68)
	end
	p_u_52.wheelScaleBackup = p_u_52.wheelScale
	p_u_52.onlyActiveWhenLowered = p53:getValue(p54 .. "#onlyActiveWhenLowered", false)
	p_u_52.stopIfNotActive = p53:getValue(p54 .. "#stopIfNotActive", false)
	p_u_52.fadeOutTime = p53:getValue(p54 .. "#fadeOutTime", 3) * 1000
	p_u_52.activationSpeed = p53:getValue(p54 .. "#activationSpeed", 1)
	p_u_52.lastSpeed = 0
	p_u_52.lastDir = 1
	p_u_52.maxUpdateDistance = p53:getValue(p54 .. "#maxUpdateDistance", SpeedRotatingParts.DEFAULT_MAX_UPDATE_DISTANCE)
	if p_u_51.isServer and p_u_52.versatileYRot then
		p_u_52.maxUpdateDistance = (1 / 0)
	end
	return true
end
function SpeedRotatingParts.getIsSpeedRotatingPartActive(p70, p71)
	return not p71.onlyActiveWhenLowered and true or ((p70.getIsLowered == nil or p70:getIsLowered()) and true or false)
end
function SpeedRotatingParts.getSpeedRotatingPartDirection(_, _)
	return 1
end
function SpeedRotatingParts.updateSpeedRotatingPart(p72, p73, p74, p75)
	local v76 = p72.spec_speedRotatingParts
	local v77 = p73.lastSpeed
	local v78 = p73.lastDir
	if p73.repr ~= nil and (p72.isServer or not p73.versatileYRot) then
		local _, v79, _ = getRotation(p73.repr)
		p73.steeringAngle = v79
	end
	local v80
	if p75 then
		if p73.speedReferenceNode == nil then
			if p73.wheels == nil then
				v80 = p72.lastSpeedReal * p74
				v78 = p72.movingDirection
			else
				local v81 = 0
				local v82 = 0
				v78 = 0
				for v83, v84 in ipairs(p73.wheels) do
					if p73.lastWheelXRot[v83] == nil then
						p73.lastWheelXRot[v83] = v84.physics.netInfo.xDrive
					end
					if v84.physics.contact ~= WheelContactType.NONE or #p73.wheels == 1 then
						local v85 = v84.physics.netInfo.xDrive - p73.lastWheelXRot[v83]
						if v85 > 3.141592653589793 then
							v85 = v85 - 6.283185307179586
						elseif v85 < -3.141592653589793 then
							v85 = v85 + 6.283185307179586
						end
						v81 = v81 + math.abs(v85)
						if math.sign(v85) ~= 0 then
							v78 = math.sign(v85)
						end
						v82 = v82 + 1
					end
					p73.lastWheelXRot[v83] = v84.physics.netInfo.xDrive
				end
				v80 = v82 <= 0 and 0 or v81 / v82
				if not p73.versatileYRot then
					local _, v86, _ = getRotation(p73.wheels[1].repr)
					p73.steeringAngle = v86
				end
			end
		else
			local v87, v88, v89 = getWorldTranslation(p73.speedReferenceNode)
			if p73.lastPosition == nil then
				p73.lastPosition = { v87, v88, v89 }
			end
			local v90, v91, v92 = worldDirectionToLocal(p73.speedReferenceNode, v87 - p73.lastPosition[1], v88 - p73.lastPosition[2], v89 - p73.lastPosition[3])
			v80 = MathUtil.vector3Length(v90, v91, v92)
			v78 = v92 > 0.001 and 1 or (v92 < -0.001 and -1 or 0)
			local v93 = p73.lastPosition
			local v94 = p73.lastPosition
			local v95 = p73.lastPosition
			v93[1] = v87
			v94[2] = v88
			v95[3] = v89
		end
		p73.brakeForce = v80 * p74 / p73.fadeOutTime
	else
		local v96 = v77 - p73.brakeForce
		v80 = math.max(v96, 0)
		if p73.wheels ~= nil then
			for v97, _ in pairs(p73.lastWheelXRot) do
				p73.lastWheelXRot[v97] = nil
			end
		end
	end
	p73.lastSpeed = v80
	p73.lastDir = v78
	if p73.updateXDrive then
		p73.xDrive = (p73.xDrive + v80 * v78 * p72:getSpeedRotatingPartDirection(p73) * p73.wheelScale) % 6.283185307179586
	end
	if p73.versatileYRot then
		if v80 > 0.0017 and (p72.isServer and p72:getLastSpeed(true) > p73.activationSpeed) then
			local v98, v99, v100 = localToLocal(p73.repr, p73.componentNode, 0, 0, 0)
			p73.steeringAngle = Utils.getVersatileRotation(p73.repr, p73.componentNode, p74, v98, v99, v100, p73.steeringAngle, p73.minYRot, p73.maxYRot)
			local v101 = p73.steeringAngle % 6.283185307179586 / 6.283185307179586 * 511
			local v102 = math.floor(v101)
			if v102 ~= p73.steeringAngleSent then
				p73.steeringAngleSent = v102
				p72:raiseDirtyFlags(v76.dirtyFlag)
			end
		end
	else
		if p73.componentNode ~= nil and (p73.dirRefNode ~= nil and not p73.alignDirection) then
			p73.steeringAngle = Utils.getYRotationBetweenNodes(p73.componentNode, p73.dirRefNode)
			local _, v103, _ = localToLocal(p73.driveNode, p73.wheels[1].driveNode, 0, 0, 0)
			setTranslation(p73.driveNode, 0, v103, 0)
		end
		if p73.dirRefNode ~= nil and p73.alignDirection then
			local v104, v105, v106 = localDirectionToWorld(p73.dirFrameNode, 0, 1, 0)
			local v107, v108, v109 = localDirectionToWorld(p73.dirRefNode, 0, 0, 1)
			I3DUtil.setWorldDirection(p73.repr, v107, v108, v109, v104, v105, v106, 2)
			if p73.wheels ~= nil and p73.useWheelReprTranslation then
				local _, v110, _ = localToLocal(p73.wheels[1].driveNode, getParent(p73.repr), 0, 0, 0)
				setTranslation(p73.repr, 0, v110, 0)
			end
		end
	end
	if p73.driveNode ~= nil then
		if p73.repr == p73.driveNode then
			local v111 = p73.steeringAngle
			local v112 = not p73.applySteeringAngle and 0 or v111
			setRotation(p73.repr, p73.xDrive, v112, 0)
			for _, v113 in ipairs(p73.reprNodes) do
				setRotation(v113, p73.xDrive, v112, 0)
			end
		else
			if not p73.alignDirection and (p73.versatileYRot or p73.applySteeringAngle) then
				setRotation(p73.repr, 0, p73.steeringAngle, 0)
				for _, v114 in ipairs(p73.reprNodes) do
					setRotation(v114, 0, p73.steeringAngle, 0)
				end
			end
			setRotation(p73.driveNode, p73.xDrive, 0, 0)
		end
	end
	if p73.shaderNode ~= nil then
		if p73.useShaderRotation then
			local v115 = p73.shaderParameterValues
			if p73.shaderComponentSpeeds == nil then
				if p73.scrollLength == nil then
					v115[p73.shaderParameterComponent] = p73.xDrive * p73.shaderParameterSpeedScale
				else
					v115[p73.shaderParameterComponent] = p73.xDrive * p73.shaderParameterSpeedScale % p73.scrollLength
				end
			else
				for v116, v117 in ipairs(p73.shaderComponentSpeeds) do
					if p73.scrollLength == nil then
						v115[v116] = p73.xDrive * p73.shaderParameterSpeedScale * v117
					else
						v115[v116] = p73.xDrive * p73.shaderParameterSpeedScale * v117 % p73.scrollLength
					end
				end
			end
			if p73.shaderParameterPrevName == nil then
				setShaderParameter(p73.shaderNode, p73.shaderParameterName, v115[1], v115[2], v115[3], v115[4], false)
			else
				g_animationManager:setPrevShaderParameter(p73.shaderNode, p73.shaderParameterName, v115[1], v115[2], v115[3], v115[4], false, p73.shaderParameterPrevName)
			end
		end
		local v118 = p73.xDrive % 3.141592653589793 / 6.283185307179586
		setShaderParameter(p73.shaderNode, "offsetUV", v118 * p73.scrollScale[1], v118 * p73.scrollScale[2], 0, 0, false)
	end
end
function SpeedRotatingParts.validateWashableNode(p119, p120, p121)
	local v122 = p119.spec_speedRotatingParts
	for _, v123 in pairs(v122.speedRotatingParts) do
		if v123.wheels ~= nil then
			local v124 = {}
			if v123.repr ~= nil then
				I3DUtil.getNodesByShaderParam(v123.repr, "scratches_dirt_snow_wetness", v124)
			end
			for _, v125 in ipairs(v123.reprNodes) do
				I3DUtil.getNodesByShaderParam(v125, "scratches_dirt_snow_wetness", v124)
			end
			if v123.shaderNode ~= nil then
				I3DUtil.getNodesByShaderParam(v123.shaderNode, "scratches_dirt_snow_wetness", v124)
			end
			if v123.driveNode ~= nil then
				I3DUtil.getNodesByShaderParam(v123.driveNode, "scratches_dirt_snow_wetness", v124)
			end
			if v124[p121] ~= nil then
				local v126 = {
					["wheel"] = v123.wheels[1]
				}
				v126.fieldDirtMultiplier = v126.wheel.physics.fieldDirtMultiplier
				v126.streetDirtMultiplier = v126.wheel.physics.streetDirtMultiplier
				v126.waterWetnessFactor = v126.wheel.physics.waterWetnessFactor
				v126.minDirtPercentage = v126.wheel.physics.minDirtPercentage
				v126.maxDirtOffset = v126.wheel.physics.maxDirtOffset
				v126.dirtColorChangeSpeed = v126.wheel.physics.dirtColorChangeSpeed
				v126.isSnowNode = true
				return false, p119.updateWheelDirtAmount, v126.wheel, v126
			end
		end
	end
	return p120(p119, p121)
end

BigBag = {}
function BigBag.prerequisitesPresent(_)
	return true
end
function BigBag.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("BigBag")
	v1:register(XMLValueType.INT, "vehicle.bigBag#fillUnitIndex", "Fill unit index")
	v1:register(XMLValueType.STRING, "vehicle.bigBag.sizeAnimation#name", "Name of size animation")
	v1:register(XMLValueType.FLOAT, "vehicle.bigBag.sizeAnimation#minTime", "Min. animation that is used while it\'s empty", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.bigBag.sizeAnimation#maxTime", "Max. animation that is used while it\'s full", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.bigBag.sizeAnimation#liftShrinkTime", "Time of animation that is reduced while the big bag is lifted", 0.2)
	v1:register(XMLValueType.INT, "vehicle.bigBag.componentJoint#index", "Component Joint Index", 1)
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.bigBag.componentJoint#minRotLimit", "Rot Limit if trans limit is at min")
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.bigBag.componentJoint#maxRotLimit", "Rot Limit if trans limit is at max")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.bigBag.componentJoint#minTransLimit", "Trans Limit if big bag is empty")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.bigBag.componentJoint#maxTransLimit", "Trans Limit if big bag is full")
	v1:register(XMLValueType.FLOAT, "vehicle.bigBag.componentJoint#angularDamping", "Angular damping of components", 0.01)
	v1:setXMLSpecializationType()
end
function BigBag.registerFunctions(_) end
function BigBag.registerOverwrittenFunctions(p2)
	SpecializationUtil.registerOverwrittenFunction(p2, "getInfoBoxTitle", BigBag.getInfoBoxTitle)
end
function BigBag.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", BigBag)
	SpecializationUtil.registerEventListener(p3, "onUpdate", BigBag)
	SpecializationUtil.registerEventListener(p3, "onFillUnitFillLevelChanged", BigBag)
end
function BigBag.onLoad(p4, _)
	local v5 = p4.spec_bigBag
	v5.fillUnitIndex = p4.xmlFile:getValue("vehicle.bigBag#fillUnitIndex", 1)
	v5.sizeAnimationName = p4.xmlFile:getValue("vehicle.bigBag.sizeAnimation#name")
	v5.sizeAnimationMinTime = p4.xmlFile:getValue("vehicle.bigBag.sizeAnimation#minTime", 0)
	v5.sizeAnimationMaxTime = p4.xmlFile:getValue("vehicle.bigBag.sizeAnimation#maxTime", 1)
	v5.sizeAnimationLiftShrinkTime = p4.xmlFile:getValue("vehicle.bigBag.sizeAnimation#liftShrinkTime", 0.2)
	v5.componentJointIndex = p4.xmlFile:getValue("vehicle.bigBag.componentJoint#index", 1)
	local v6 = p4.componentJoints[v5.componentJointIndex]
	if v6 ~= nil then
		v5.minRotLimit = p4.xmlFile:getValue("vehicle.bigBag.componentJoint#minRotLimit", nil, true)
		v5.maxRotLimit = p4.xmlFile:getValue("vehicle.bigBag.componentJoint#maxRotLimit", nil, true)
		v5.minTransLimit = p4.xmlFile:getValue("vehicle.bigBag.componentJoint#minTransLimit", nil, true)
		v5.maxTransLimit = p4.xmlFile:getValue("vehicle.bigBag.componentJoint#maxTransLimit", nil, true)
		v5.componentJoint = v6
		v5.jointNode = v6.jointNode
		v5.jointNodeReferenceNode = createTransformGroup("jointNodeReference")
		link(p4.components[v6.componentIndices[2]].node, v5.jointNodeReferenceNode)
		setWorldTranslation(v5.jointNodeReferenceNode, getWorldTranslation(v5.jointNode))
		setWorldRotation(v5.jointNodeReferenceNode, getWorldRotation(v5.jointNode))
		v5.component1 = p4.components[v5.componentJoint.componentIndices[1]]
		v5.component2 = p4.components[v5.componentJoint.componentIndices[2]]
		v5.angularDamping = p4.xmlFile:getValue("vehicle.bigBag.componentJoint#angularDamping", 0.01)
		setAngularDamping(v5.component1.node, v5.angularDamping)
		setAngularDamping(v5.component2.node, v5.angularDamping)
		v5.lastJointLimitAlpha = -1
	end
	v5.currentShrinkTime = 0
	v5.currentSizeTime = 1
	v5.currentAnimationTime = 1
end
function BigBag.onUpdate(p7, _, _, _, _)
	local v8 = p7.spec_bigBag
	if v8.jointNode ~= nil then
		local v9, _, _ = MathUtil.lerp(v8.minTransLimit[1], v8.maxTransLimit[1], p7:getFillUnitFillLevelPercentage(v8.fillUnitIndex))
		local v10, _, _ = localToLocal(v8.jointNode, v8.jointNodeReferenceNode, 0, 0, 0)
		local v11 = (v10 / v9 + 1) / 2
		local v12 = 1 - math.clamp(v11, 0, 1)
		v8.currentShrinkTime = v12 * v8.sizeAnimationLiftShrinkTime
		if p7.isServer then
			local v13 = v8.lastJointLimitAlpha - v12
			if math.abs(v13) > 0.05 then
				if v8.minRotLimit ~= nil and v8.maxRotLimit ~= nil then
					local v14, v15, v16 = MathUtil.vector3ArrayLerp(v8.minRotLimit, v8.maxRotLimit, v12)
					p7:setComponentJointRotLimit(v8.componentJoint, 1, -v14, v14)
					p7:setComponentJointRotLimit(v8.componentJoint, 2, -v15, v15)
					p7:setComponentJointRotLimit(v8.componentJoint, 3, -v16, v16)
				end
				v8.lastJointLimitAlpha = v12
			end
		end
		local v17 = v8.currentSizeTime * (1 - v8.currentShrinkTime)
		local v18 = v17 - v8.currentAnimationTime
		if math.abs(v18) > 0.01 then
			p7:setAnimationTime(v8.sizeAnimationName, v17)
			v8.currentAnimationTime = v17
		end
	end
end
function BigBag.onFillUnitFillLevelChanged(p19, p20, _, _, _, _, _)
	local v21 = p19.spec_bigBag
	if v21.fillUnitIndex == p20 then
		local v22 = p19:getFillUnitFillLevelPercentage(p20)
		v21.currentSizeTime = v22 * (v21.sizeAnimationMaxTime - v21.sizeAnimationMinTime) + v21.sizeAnimationMinTime
		v21.currentAnimationTime = v21.currentSizeTime * (1 - v21.currentShrinkTime)
		p19:setAnimationTime(v21.sizeAnimationName, v21.currentAnimationTime)
		if p19.isServer and (v21.minTransLimit ~= nil and v21.maxTransLimit ~= nil) then
			local v23, v24, v25 = MathUtil.vector3ArrayLerp(v21.minTransLimit, v21.maxTransLimit, v22)
			p19:setComponentJointTransLimit(v21.componentJoint, 1, -v23, v23)
			p19:setComponentJointTransLimit(v21.componentJoint, 2, -v24, v24)
			p19:setComponentJointTransLimit(v21.componentJoint, 3, -v25, v25)
		end
	end
end
function BigBag.getInfoBoxTitle(_, _)
	return g_i18n:getText("shopItem_bigBag")
end

AIImplement = {}
function AIImplement.prerequisitesPresent(_)
	return true
end
function AIImplement.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("ai", g_i18n:getText("configuration_design"), "ai", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("AIImplement")
	AIImplement.registerAIImplementXMLPaths(v1, "vehicle.ai")
	AIImplement.registerAIImplementXMLPaths(v1, "vehicle.ai.aiConfigurations.aiConfiguration(?)")
	v1:setXMLSpecializationType()
end
function AIImplement.registerAIImplementXMLPaths(p2, p3)
	p2:register(XMLValueType.FLOAT, p3 .. ".minTurningRadius#value", "Min turning radius")
	AIImplement.registerAIImplementBaseXMLPaths(p2, p3)
	p2:register(XMLValueType.BOOL, p3 .. ".needsLowering#value", "AI needs to lower this tool", true)
	p2:register(XMLValueType.BOOL, p3 .. ".needsLowering#lowerIfAnyIsLowered", "Lower tool of any attached ai tool is lowered", false)
	p2:register(XMLValueType.BOOL, p3 .. ".needsRootAlignment#value", "Tool needs to point in the same direction as the root while working", true)
	p2:register(XMLValueType.BOOL, p3 .. ".allowTurnBackward#value", "Worker is allowed the turn backward with this tool", true)
	p2:register(XMLValueType.FLOAT, p3 .. ".allowTurnBackward#straighteningSegmentLength", "Controls the length of the extra straightening segment after the turn to get the tool straight again")
	p2:register(XMLValueType.BOOL, p3 .. ".blockTurnBackward#value", "Can be used for non ai tools to block ai from driving backward", false)
	p2:register(XMLValueType.BOOL, p3 .. ".isVineyardTool#value", "Field work AI for this tool can only be used in vine yards", false)
	p2:register(XMLValueType.BOOL, p3 .. ".isVineyardTool#betweenRows", "Defines if the tool is used to work between the vine yard rows", false)
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".toolReverserDirectionNode#node", "Reverser direction node, target node if driving backward")
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".turningRadiusLimitation#rotationJointNode", "Turn radius limitation joint node")
	p2:register(XMLValueType.VECTOR_N, p3 .. ".turningRadiusLimitation#wheelIndices", "Turn radius limitation wheel indices")
	p2:register(XMLValueType.FLOAT, p3 .. ".turningRadiusLimitation#radius", "Turn radius limitation radius")
	p2:register(XMLValueType.FLOAT, p3 .. ".turningRadiusLimitation#initialTurnRadiusFactor", "Increase or decrease the turn radius while the tool is still folded (initial drive to the first segment)", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".turningRadiusLimitation#rotLimitFactor", "Changes the rot limit of attacher joint or component joint for turning radius calculation", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".lookAheadSize#value", "Look a head size to check ground in front of tool", 2)
	p2:register(XMLValueType.BOOL, p3 .. ".useAttributesOfAttachedImplement#value", "Use AI attributes (area & fruit/ground requirements) of first attached implement", false)
	p2:register(XMLValueType.BOOL, p3 .. ".hasNoFullCoverageArea#value", "Tool as a no full coverage area (e.g. plows)", false)
	p2:register(XMLValueType.FLOAT, p3 .. ".hasNoFullCoverageArea#offset", "Non full coverage area offset", 0)
	p2:register(XMLValueType.BOOL, p3 .. ".headlandTailAvoidance#enabled", "Course generation setting to help long vehicles to stay inside field boundaries (sugarbeet harvesters for example)", false)
	p2:register(XMLValueType.FLOAT, p3 .. ".overlap#value", "Defines the ai line to line overlap", AIVehicleUtil.AREA_OVERLAP)
end
function AIImplement.registerAIImplementBaseXMLPaths(p4, p5)
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".areaMarkers#leftNode", "AI area left node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".areaMarkers#rightNode", "AI area right node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".areaMarkers#backNode", "AI area back node")
	p4:register(XMLValueType.FLOAT, p5 .. ".areaMarkers#sideOffset", "Side offset of the ai markers to the center of the leading vehicle", 0)
	p4:register(XMLValueType.BOOL, p5 .. ".areaMarkers#sideOffsetHeadlandAlternate", "Alternate the side offset during headland work", false)
	p4:register(XMLValueType.FLOAT, p5 .. ".areaMarkers#width", "Working width of the ai implement", "automatically calculated based on distance between ai markers while activating the ai")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".sizeMarkers#leftNode", "Size area left node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".sizeMarkers#rightNode", "Size area right node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".sizeMarkers#backNode", "Size area back node")
	AIImplement.registerAICollisionTriggerXMLPaths(p4, p5)
end
function AIImplement.registerAICollisionTriggerXMLPaths(p6, p7)
	p6:register(XMLValueType.BOOL, p7 .. ".collisionTrigger#useSize", "Use vehicle size box to calculate the ai collision box (will be placed in front of it)", false)
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".collisionTrigger#node", "Collision trigger node")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".collisionTrigger#backNode", "Collision trigger node while driving backwards (Z-Axis pointing backwards)")
	p6:register(XMLValueType.FLOAT, p7 .. ".collisionTrigger#width", "Width of ai collision trigger", 4)
	p6:register(XMLValueType.FLOAT, p7 .. ".collisionTrigger#height", "Width of ai collision trigger", 3)
	p6:register(XMLValueType.FLOAT, p7 .. ".collisionTrigger#length", "Max. length of ai collision trigger", 5)
end
function AIImplement.registerEvents(p8)
	SpecializationUtil.registerEvent(p8, "onAIImplementStart")
	SpecializationUtil.registerEvent(p8, "onAIImplementActive")
	SpecializationUtil.registerEvent(p8, "onAIImplementEnd")
	SpecializationUtil.registerEvent(p8, "onAIImplementPrepareForWork")
	SpecializationUtil.registerEvent(p8, "onAIImplementStartLine")
	SpecializationUtil.registerEvent(p8, "onAIImplementEndLine")
	SpecializationUtil.registerEvent(p8, "onAIImplementStartTurn")
	SpecializationUtil.registerEvent(p8, "onAIImplementTurnProgress")
	SpecializationUtil.registerEvent(p8, "onAIImplementEndTurn")
	SpecializationUtil.registerEvent(p8, "onAIImplementSideOffsetChanged")
	SpecializationUtil.registerEvent(p8, "onAIImplementBlock")
	SpecializationUtil.registerEvent(p8, "onAIImplementContinue")
	SpecializationUtil.registerEvent(p8, "onAIImplementPrepareForTransport")
	SpecializationUtil.registerEvent(p8, "onAIImplementJobVehicleBlock")
	SpecializationUtil.registerEvent(p8, "onAIImplementJobVehicleContinue")
end
function AIImplement.registerFunctions(p9)
	SpecializationUtil.registerFunction(p9, "loadAICollisionTriggerFromXML", AIImplement.loadAICollisionTriggerFromXML)
	SpecializationUtil.registerFunction(p9, "loadAIImplementBaseSetupFromXML", AIImplement.loadAIImplementBaseSetupFromXML)
	SpecializationUtil.registerFunction(p9, "getCustomAIImplementBaseSetup", AIImplement.getCustomAIImplementBaseSetup)
	SpecializationUtil.registerFunction(p9, "getCanAIImplementContinueWork", AIImplement.getCanAIImplementContinueWork)
	SpecializationUtil.registerFunction(p9, "getCanImplementBeUsedForAI", AIImplement.getCanImplementBeUsedForAI)
	SpecializationUtil.registerFunction(p9, "getAIMinTurningRadius", AIImplement.getAIMinTurningRadius)
	SpecializationUtil.registerFunction(p9, "getAIMarkers", AIImplement.getAIMarkers)
	SpecializationUtil.registerFunction(p9, "updateAIMarkerWidth", AIImplement.updateAIMarkerWidth)
	SpecializationUtil.registerFunction(p9, "setAIMarkersInverted", AIImplement.setAIMarkersInverted)
	SpecializationUtil.registerFunction(p9, "calcAIMarkerAttacherJointOffset", AIImplement.calcAIMarkerAttacherJointOffset)
	SpecializationUtil.registerFunction(p9, "getAIMarkerAttacherJointOffset", AIImplement.getAIMarkerAttacherJointOffset)
	SpecializationUtil.registerFunction(p9, "getAIInvertMarkersOnTurn", AIImplement.getAIInvertMarkersOnTurn)
	SpecializationUtil.registerFunction(p9, "getAISizeMarkers", AIImplement.getAISizeMarkers)
	SpecializationUtil.registerFunction(p9, "getAILookAheadSize", AIImplement.getAILookAheadSize)
	SpecializationUtil.registerFunction(p9, "getAIHasNoFullCoverageArea", AIImplement.getAIHasNoFullCoverageArea)
	SpecializationUtil.registerFunction(p9, "getAIAreaOverlap", AIImplement.getAIAreaOverlap)
	SpecializationUtil.registerFunction(p9, "getImplementAllowAutomaticSteering", AIImplement.getImplementAllowAutomaticSteering)
	SpecializationUtil.registerFunction(p9, "getAIImplementCollisionTrigger", AIImplement.getAIImplementCollisionTrigger)
	SpecializationUtil.registerFunction(p9, "getAIImplementCollisionTriggers", AIImplement.getAIImplementCollisionTriggers)
	SpecializationUtil.registerFunction(p9, "getAINeedsLowering", AIImplement.getAINeedsLowering)
	SpecializationUtil.registerFunction(p9, "getAILowerIfAnyIsLowered", AIImplement.getAILowerIfAnyIsLowered)
	SpecializationUtil.registerFunction(p9, "getAINeedsRootAlignment", AIImplement.getAINeedsRootAlignment)
	SpecializationUtil.registerFunction(p9, "getAIAllowTurnBackward", AIImplement.getAIAllowTurnBackward)
	SpecializationUtil.registerFunction(p9, "getAIBlockTurnBackward", AIImplement.getAIBlockTurnBackward)
	SpecializationUtil.registerFunction(p9, "getAIIsVineyardTool", AIImplement.getAIIsVineyardTool)
	SpecializationUtil.registerFunction(p9, "getAIToolReverserDirectionNode", AIImplement.getAIToolReverserDirectionNode)
	SpecializationUtil.registerFunction(p9, "getAITurnRadiusLimitation", AIImplement.getAITurnRadiusLimitation)
	SpecializationUtil.registerFunction(p9, "setAIImplementVariableSideOffset", AIImplement.setAIImplementVariableSideOffset)
	SpecializationUtil.registerFunction(p9, "getAIImplementSideOffset", AIImplement.getAIImplementSideOffset)
	SpecializationUtil.registerFunction(p9, "setAIFruitProhibitions", AIImplement.setAIFruitProhibitions)
	SpecializationUtil.registerFunction(p9, "addAIFruitProhibitions", AIImplement.addAIFruitProhibitions)
	SpecializationUtil.registerFunction(p9, "clearAIFruitProhibitions", AIImplement.clearAIFruitProhibitions)
	SpecializationUtil.registerFunction(p9, "getAIFruitProhibitions", AIImplement.getAIFruitProhibitions)
	SpecializationUtil.registerFunction(p9, "setAIFruitRequirements", AIImplement.setAIFruitRequirements)
	SpecializationUtil.registerFunction(p9, "addAIFruitRequirement", AIImplement.addAIFruitRequirement)
	SpecializationUtil.registerFunction(p9, "clearAIFruitRequirements", AIImplement.clearAIFruitRequirements)
	SpecializationUtil.registerFunction(p9, "getAIFruitRequirements", AIImplement.getAIFruitRequirements)
	SpecializationUtil.registerFunction(p9, "setAIDensityHeightTypeRequirements", AIImplement.setAIDensityHeightTypeRequirements)
	SpecializationUtil.registerFunction(p9, "addAIDensityHeightTypeRequirement", AIImplement.addAIDensityHeightTypeRequirement)
	SpecializationUtil.registerFunction(p9, "clearAIDensityHeightTypeRequirements", AIImplement.clearAIDensityHeightTypeRequirements)
	SpecializationUtil.registerFunction(p9, "getAIDensityHeightTypeRequirements", AIImplement.getAIDensityHeightTypeRequirements)
	SpecializationUtil.registerFunction(p9, "getAIImplementUseVineSegment", AIImplement.getAIImplementUseVineSegment)
	SpecializationUtil.registerFunction(p9, "addAITerrainDetailRequiredRange", AIImplement.addAITerrainDetailRequiredRange)
	SpecializationUtil.registerFunction(p9, "addAIGroundTypeRequirements", AIImplement.addAIGroundTypeRequirements)
	SpecializationUtil.registerFunction(p9, "clearAITerrainDetailRequiredRange", AIImplement.clearAITerrainDetailRequiredRange)
	SpecializationUtil.registerFunction(p9, "getAITerrainDetailRequiredRange", AIImplement.getAITerrainDetailRequiredRange)
	SpecializationUtil.registerFunction(p9, "addAITerrainDetailProhibitedRange", AIImplement.addAITerrainDetailProhibitedRange)
	SpecializationUtil.registerFunction(p9, "clearAITerrainDetailProhibitedRange", AIImplement.clearAITerrainDetailProhibitedRange)
	SpecializationUtil.registerFunction(p9, "getAITerrainDetailProhibitedRange", AIImplement.getAITerrainDetailProhibitedRange)
	SpecializationUtil.registerFunction(p9, "getFieldCropsQuery", AIImplement.getFieldCropsQuery)
	SpecializationUtil.registerFunction(p9, "updateFieldCropsQuery", AIImplement.updateFieldCropsQuery)
	SpecializationUtil.registerFunction(p9, "compareFieldCropsQuery", AIImplement.compareFieldCropsQuery)
	SpecializationUtil.registerFunction(p9, "createFieldCropsQuery", AIImplement.createFieldCropsQuery)
	SpecializationUtil.registerFunction(p9, "getIsAIImplementInLine", AIImplement.getIsAIImplementInLine)
	SpecializationUtil.registerFunction(p9, "aiImplementStartLine", AIImplement.aiImplementStartLine)
	SpecializationUtil.registerFunction(p9, "aiImplementEndLine", AIImplement.aiImplementEndLine)
end
function AIImplement.registerOverwrittenFunctions(p10)
	SpecializationUtil.registerOverwrittenFunction(p10, "addVehicleToAIImplementList", AIImplement.addVehicleToAIImplementList)
	SpecializationUtil.registerOverwrittenFunction(p10, "getAllowTireTracks", AIImplement.getAllowTireTracks)
	SpecializationUtil.registerOverwrittenFunction(p10, "getDoConsumePtoPower", AIImplement.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p10, "checkMovingPartDirtyUpdateNode", AIImplement.checkMovingPartDirtyUpdateNode)
end
function AIImplement.registerEventListeners(p11)
	SpecializationUtil.registerEventListener(p11, "onLoad", AIImplement)
	SpecializationUtil.registerEventListener(p11, "onPostLoad", AIImplement)
	SpecializationUtil.registerEventListener(p11, "onAIFieldCourseSettingsInitialized", AIImplement)
end
function AIImplement.onLoad(p12, _)
	local v13 = p12.spec_aiImplement
	local v14 = "vehicle.ai"
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".areaMarkers#leftIndex", v14 .. ".areaMarkers#leftNode")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".areaMarkers#rightIndex", v14 .. ".areaMarkers#rightNode")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".areaMarkers#backIndex", v14 .. ".areaMarkers#backNode")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".sizeMarkers#leftIndex", v14 .. ".sizeMarkers#leftNode")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".sizeMarkers#rightIndex", v14 .. ".sizeMarkers#rightNode")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".sizeMarkers#backIndex", v14 .. ".sizeMarkers#backNode")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".trafficCollisionTrigger#index", v14 .. ".collisionTrigger#node")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".trafficCollisionTrigger#node", v14 .. ".collisionTrigger#node")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".collisionTrigger#index", v14 .. ".collisionTrigger#node")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, "vehicle.aiLookAheadSize#value", v14 .. ".lookAheadSize#value")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".toolReverserDirectionNode#index", v14 .. ".toolReverserDirectionNode#node")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".turningRadiusLimiation", v14 .. ".turningRadiusLimitation")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".forceTurnNoBackward#value", v14 .. ".allowTurnBackward#value (inverted)")
	XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, v14 .. ".needsLowering#lowerIfAnyIsLowerd", v14 .. ".allowTurnBackward#lowerIfAnyIsLowered")
	local v15 = Utils.getNoNil(p12.configurations.ai, 1)
	local v16 = string.format("vehicle.ai.aiConfigurations.aiConfiguration(%d)", v15 - 1)
	if p12.xmlFile:hasProperty(v16) then
		v14 = v16
	end
	v13.minTurningRadius = p12.xmlFile:getValue(v14 .. ".minTurningRadius#value")
	v13.inputAttacherJointToMarkerOffset = {}
	v13.aiBaseSetups = {}
	p12:loadAIImplementBaseSetupFromXML(p12.xmlFile, v14, nil)
	v13.needsLowering = p12.xmlFile:getValue(v14 .. ".needsLowering#value", true)
	v13.lowerIfAnyIsLowered = p12.xmlFile:getValue(v14 .. ".needsLowering#lowerIfAnyIsLowered", false)
	v13.needsRootAlignment = p12.xmlFile:getValue(v14 .. ".needsRootAlignment#value", true)
	v13.allowTurnBackward = p12.xmlFile:getValue(v14 .. ".allowTurnBackward#value", true)
	v13.blockTurnBackward = p12.xmlFile:getValue(v14 .. ".blockTurnBackward#value", false)
	v13.straighteningSegmentLength = p12.xmlFile:getValue(v14 .. ".allowTurnBackward#straighteningSegmentLength")
	v13.isVineyardTool = p12.xmlFile:getValue(v14 .. ".isVineyardTool#value", false)
	v13.isVineyardToolBetweenRows = p12.xmlFile:getValue(v14 .. ".isVineyardTool#betweenRows", false)
	v13.toolReverserDirectionNode = p12.xmlFile:getValue(v14 .. ".toolReverserDirectionNode#node", nil, p12.components, p12.i3dMappings)
	v13.turningRadiusLimitation = {}
	v13.turningRadiusLimitation.rotationJoint = p12.xmlFile:getValue(v14 .. ".turningRadiusLimitation#rotationJointNode", nil, p12.components, p12.i3dMappings)
	if v13.turningRadiusLimitation.rotationJoint ~= nil then
		v13.turningRadiusLimitation.wheelIndices = p12.xmlFile:getValue(v14 .. ".turningRadiusLimitation#wheelIndices", nil, true)
	end
	v13.turningRadiusLimitation.radius = p12.xmlFile:getValue(v14 .. ".turningRadiusLimitation#radius")
	v13.turningRadiusLimitation.initialTurnRadiusFactor = p12.xmlFile:getValue(v14 .. ".turningRadiusLimitation#initialTurnRadiusFactor")
	v13.turningRadiusLimitation.rotLimitFactor = p12.xmlFile:getValue(v14 .. ".turningRadiusLimitation#rotLimitFactor", 1)
	v13.lookAheadSize = p12.xmlFile:getValue(v14 .. ".lookAheadSize#value", 2)
	v13.useAttributesOfAttachedImplement = p12.xmlFile:getValue(v14 .. ".useAttributesOfAttachedImplement#value", false)
	v13.hasNoFullCoverageArea = p12.xmlFile:getValue(v14 .. ".hasNoFullCoverageArea#value", false)
	v13.hasNoFullCoverageAreaOffset = p12.xmlFile:getValue(v14 .. ".hasNoFullCoverageArea#offset", 0)
	v13.headlandTailAvoidanceEnabled = p12.xmlFile:getValue(v14 .. ".headlandTailAvoidance#enabled", false)
	v13.overlap = p12.xmlFile:getValue(v14 .. ".overlap#value")
	v13.terrainDetailRequiredValueRanges = {}
	v13.terrainDetailProhibitedValueRanges = {}
	v13.requiredFruitTypes = {}
	v13.prohibitedFruitTypes = {}
	v13.requiredDensityHeightTypes = {}
	v13.fieldGroundSystem = g_currentMission.fieldGroundSystem
	local _, v17, v18 = v13.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
	v13.groundTypeFirstChannel = v17
	v13.groundTypeNumChannels = v18
	v13.fieldCropyQuery = nil
	v13.fieldCropyQueryValid = false
	v13.isLineStarted = false
end
function AIImplement.onPostLoad(p19, _)
	local v20 = p19.spec_aiImplement
	if p19.getWheels ~= nil and v20.turningRadiusLimitation.wheelIndices ~= nil then
		v20.turningRadiusLimitation.wheels = {}
		local v21 = p19:getWheels()
		for _, v22 in ipairs(v20.turningRadiusLimitation.wheelIndices) do
			if v21[v22] == nil then
				Logging.xmlWarning(p19.xmlFile, "Unknown wheel index \'%s\' defined in \'%s\'", v22, "vehicle.ai.turningRadiusLimitation#wheelIndices")
			else
				local v23 = v20.turningRadiusLimitation.wheels
				local v24 = v21[v22]
				table.insert(v23, v24)
			end
		end
	end
	if v20.leftMarker ~= nil and v20.backMarker ~= nil then
		p19:calcAIMarkerAttacherJointOffset(v20.leftMarker, v20.rightMarker, v20.backMarker)
	end
	if v20.aiBaseSetups ~= nil then
		for _, v25 in ipairs(v20.aiBaseSetups) do
			if v25.leftMarker ~= nil and v25.backMarker ~= nil then
				p19:calcAIMarkerAttacherJointOffset(v25.leftMarker, v25.rightMarker, v25.backMarker)
			end
		end
	end
end
function AIImplement.onAIFieldCourseSettingsInitialized(p26, p27)
	local v28 = p26.spec_aiImplement
	if v28.isVineyardTool then
		p27.isVineyardTool = true
	end
	if v28.isVineyardToolBetweenRows then
		p27.isVineyardRowTool = true
	end
	if v28.headlandTailAvoidanceEnabled then
		p27.headlandTailAvoidance = true
	end
	if v28.straighteningSegmentLength ~= nil then
		p27.toolStraighteningSegmentLength = v28.straighteningSegmentLength
	end
	local v29 = p26:getCustomAIImplementBaseSetup()
	if v29 ~= nil and v29.sideOffsetHeadlandAlternate ~= nil then
		v28 = v29
	end
	if v28.sideOffsetHeadlandAlternate ~= nil then
		p27.sideOffsetHeadlandAlternate = v28.sideOffsetHeadlandAlternate
	end
end
function AIImplement.loadAICollisionTriggerFromXML(p30, p31, p32)
	local v33 = {
		["node"] = p31:getValue(p32 .. ".collisionTrigger#node", nil, p30.components, p30.i3dMappings)
	}
	if v33.node ~= nil then
		if getHasClassId(v33.node, ClassIds.SHAPE) then
			Logging.xmlWarning(p31, "Obsolete ai collision trigger ground. Please replace with empty transform group and add size attributes. \'%s\'", p32 .. ".collisionTrigger#node")
		end
		v33.width = p31:getValue(p32 .. ".collisionTrigger#width", 4)
		v33.height = p31:getValue(p32 .. ".collisionTrigger#height", 3)
		v33.length = p31:getValue(p32 .. ".collisionTrigger#length", 5)
		v33.backNode = p31:getValue(p32 .. ".collisionTrigger#backNode", nil, p30.components, p30.i3dMappings)
		v33.backNodeDirection = 1
		if v33.backNode == nil then
			v33.backNode = p30.spec_aiImplement.backMarker or p30.spec_aiImplement.sizeBackMarker
			v33.backNodeDirection = -1
			if v33.backNode == nil then
				v33.backNode = createTransformGroup("aiCollisionNodeBack")
				link(p30.rootNode, v33.backNode)
				setTranslation(v33.backNode, p30.size.widthOffset, 0, -p30.size.length * 0.5 - p30.size.lengthOffset)
				return v33
			end
		end
		return v33
	end
	if not p31:getValue(p32 .. ".collisionTrigger#useSize", false) then
		return nil
	end
	v33.node = createTransformGroup("aiCollisionTrigger")
	link(p30.rootNode, v33.node)
	setTranslation(v33.node, p30.size.widthOffset, 0, p30.size.length * 0.5 + p30.size.lengthOffset)
	v33.width = p31:getValue(p32 .. ".collisionTrigger#width", p30.size.width)
	v33.height = p31:getValue(p32 .. ".collisionTrigger#height", p30.size.height)
	v33.length = p31:getValue(p32 .. ".collisionTrigger#length", 5)
	v33.backNode = createTransformGroup("aiCollisionNodeBack")
	link(p30.rootNode, v33.backNode)
	setTranslation(v33.backNode, p30.size.widthOffset, 0, -p30.size.length * 0.5 - p30.size.lengthOffset)
	return v33
end
function AIImplement.loadAIImplementBaseSetupFromXML(p34, p35, p36, p37)
	local v38 = p34.spec_aiImplement
	local v39 = p37 ~= nil and {} or v38
	v39.leftMarker = p35:getValue(p36 .. ".areaMarkers#leftNode", nil, p34.components, p34.i3dMappings)
	v39.rightMarker = p35:getValue(p36 .. ".areaMarkers#rightNode", nil, p34.components, p34.i3dMappings)
	v39.backMarker = p35:getValue(p36 .. ".areaMarkers#backNode", nil, p34.components, p34.i3dMappings)
	v39.aiMarkersInverted = false
	v39.sideOffset = p35:getValue(p36 .. ".areaMarkers#sideOffset")
	v39.sideOffsetHeadlandAlternate = p35:getValue(p36 .. ".areaMarkers#sideOffsetHeadlandAlternate")
	v39.aiMarkerWidth = p35:getValue(p36 .. ".areaMarkers#width")
	v39.variableSideOffset = false
	if v39.aiMarkerWidth == nil then
		if v39.leftMarker == nil or v39.rightMarker == nil then
			v39.aiMarkerWidth = 0
		else
			v39.aiMarkerWidth = calcDistanceFrom(v39.leftMarker, v39.rightMarker)
		end
	end
	v39.sizeLeftMarker = p35:getValue(p36 .. ".sizeMarkers#leftNode", nil, p34.components, p34.i3dMappings)
	v39.sizeRightMarker = p35:getValue(p36 .. ".sizeMarkers#rightNode", nil, p34.components, p34.i3dMappings)
	v39.sizeBackMarker = p35:getValue(p36 .. ".sizeMarkers#backNode", nil, p34.components, p34.i3dMappings)
	v39.collisionTrigger = p34:loadAICollisionTriggerFromXML(p35, p36)
	if p37 ~= nil then
		v39.availableFunc = p37
		local v40 = p34.spec_aiImplement.aiBaseSetups
		table.insert(v40, v39)
	end
	return true
end
function AIImplement.getCustomAIImplementBaseSetup(p41)
	local v42 = p41.spec_aiImplement
	for _, v43 in ipairs(v42.aiBaseSetups) do
		if v43.availableFunc(p41) then
			return v43
		end
	end
	return nil
end
function AIImplement.getCanAIImplementContinueWork(_, _)
	return true, false, nil
end
function AIImplement.getCanImplementBeUsedForAI(p44)
	local v45, v46, v47, _, _ = p44:getAIMarkers()
	return v45 ~= nil and (v46 ~= nil and v47 ~= nil)
end
function AIImplement.addVehicleToAIImplementList(p48, p49, p50)
	if p48:getCanImplementBeUsedForAI() then
		table.insert(p50, {
			["object"] = p48
		})
	end
	p49(p48, p50)
end
function AIImplement.getAllowTireTracks(p51, p52)
	local v53 = p52(p51)
	if v53 then
		v53 = not p51:getIsAIActive()
	end
	return v53
end
function AIImplement.getDoConsumePtoPower(p54, p55)
	local v56 = p54.rootVehicle
	if v56.getAIFieldWorkerIsTurning == nil or not v56:getAIFieldWorkerIsTurning() then
		return p55(p54)
	else
		return false
	end
end
function AIImplement.checkMovingPartDirtyUpdateNode(p57, p58, p59, p60)
	p58(p57, p59, p60)
	local v61 = p57.spec_aiImplement
	if p59 == v61.leftMarker or (p59 == v61.rightMarker or p59 == v61.backMarker) then
		Logging.xmlError(p57.xmlFile, "Found ai marker node \'%s\' in active dirty moving part \'%s\' with limited update distance. Remove limit or adjust hierarchy for correct function. (maxUpdateDistance=\'-\')", getName(p59), getName(p60.node))
	end
	if p59 == v61.sizeLeftMarker or (p59 == v61.sizeRightMarker or p59 == v61.sizeBackMarker) then
		Logging.xmlError(p57.xmlFile, "Found ai size marker node \'%s\' in active dirty moving part \'%s\' with limited update distance. Remove limit or adjust hierarchy for correct function. (maxUpdateDistance=\'-\')", getName(p59), getName(p60.node))
	end
	if v61.collisionTrigger ~= nil and p59 == v61.collisionTrigger.node then
		Logging.xmlError(p57.xmlFile, "Found ai collision trigger \'%s\' in active dirty moving part \'%s\' with limited update distance. Remove limit or adjust hierarchy for correct function. (maxUpdateDistance=\'-\')", getName(p59), getName(p60.node))
	end
end
function AIImplement.getAIMinTurningRadius(p62)
	return p62.spec_aiImplement.minTurningRadius
end
function AIImplement.getAIMarkers(p63)
	local v64 = p63.spec_aiImplement
	if v64.useAttributesOfAttachedImplement and p63.getAttachedImplements ~= nil then
		for _, v65 in ipairs(p63:getAttachedImplements()) do
			if v65.object.getAIMarkers ~= nil then
				return v65.object:getAIMarkers()
			end
		end
	end
	local v66 = p63:getCustomAIImplementBaseSetup()
	if v66 == nil or v66.rightMarker == nil then
		v66 = v64
	end
	if v64.aiMarkersInverted then
		return v66.rightMarker, v66.leftMarker, v66.backMarker, true, v66.aiMarkerWidth
	else
		return v66.leftMarker, v66.rightMarker, v66.backMarker, false, v66.aiMarkerWidth
	end
end
function AIImplement.updateAIMarkerWidth(p67)
	local v68 = p67.spec_aiImplement
	if v68.leftMarker ~= nil and (v68.backMarker ~= nil and v68.aiMarkerWidth == nil) then
		if v68.leftMarker == nil or v68.rightMarker == nil then
			v68.aiMarkerWidth = 0
		else
			v68.aiMarkerWidth = calcDistanceFrom(v68.leftMarker, v68.rightMarker)
		end
	end
	if v68.aiBaseSetups ~= nil then
		for _, v69 in ipairs(v68.aiBaseSetups) do
			if v69.aiMarkerWidth == nil then
				if v69.leftMarker == nil or v69.rightMarker == nil then
					v69.aiMarkerWidth = 0
				else
					v69.aiMarkerWidth = calcDistanceFrom(v69.leftMarker, v69.rightMarker)
				end
			end
		end
	end
end
function AIImplement.setAIMarkersInverted(p70, _)
	local v71 = p70.spec_aiImplement
	v71.aiMarkersInverted = not v71.aiMarkersInverted
end
function AIImplement.calcAIMarkerAttacherJointOffset(p72, p73, p74, p75)
	local v76 = p72.spec_aiImplement
	if p72.getInputAttacherJoints ~= nil then
		for v77, v78 in ipairs(p72:getInputAttacherJoints()) do
			local v79 = {
				["leftMarker"] = p73
			}
			local v80, _, _ = localToLocal(p73, v78.node, 0, 0, 0)
			local v81, _, _ = localToLocal(p74, v78.node, 0, 0, 0)
			v79.frontOffset = (v80 > 0 and math.min or math.max)(v80, v81)
			local v82, _, _ = localToLocal(p75, v78.node, 0, 0, 0)
			v79.backOffset = v82
			if v76.inputAttacherJointToMarkerOffset[v77] == nil then
				v76.inputAttacherJointToMarkerOffset[v77] = {}
			end
			local v83 = v76.inputAttacherJointToMarkerOffset[v77]
			table.insert(v83, v79)
		end
	end
end
function AIImplement.getAIMarkerAttacherJointOffset(p84, p85)
	if p84.getActiveInputAttacherJointDescIndex ~= nil then
		local v86 = p84:getActiveInputAttacherJointDescIndex()
		local v87 = p84.spec_aiImplement.inputAttacherJointToMarkerOffset[v86]
		if v87 ~= nil then
			for _, v88 in ipairs(v87) do
				if v88.leftMarker == p85 then
					return v88
				end
			end
		end
	end
	return nil
end
function AIImplement.getAIInvertMarkersOnTurn(_, _)
	return false
end
function AIImplement.getAISizeMarkers(p89)
	local v90 = p89.spec_aiImplement
	local v91 = p89:getCustomAIImplementBaseSetup()
	if v91 ~= nil and v91.sizeLeftMarker ~= nil then
		v90 = v91
	end
	return v90.sizeLeftMarker, v90.sizeRightMarker, v90.sizeBackMarker
end
function AIImplement.getAILookAheadSize(p92)
	return p92.spec_aiImplement.lookAheadSize
end
function AIImplement.getAIHasNoFullCoverageArea(p93)
	return p93.spec_aiImplement.hasNoFullCoverageArea, p93.spec_aiImplement.hasNoFullCoverageAreaOffset
end
function AIImplement.getAIAreaOverlap(p94)
	return p94.spec_aiImplement.overlap
end
function AIImplement.getImplementAllowAutomaticSteering(_)
	return false
end
function AIImplement.getAIImplementCollisionTrigger(p95)
	local v96 = p95.spec_aiImplement
	local v97 = p95:getCustomAIImplementBaseSetup()
	if v97 ~= nil and v97.collisionTrigger ~= nil then
		v96 = v97
	end
	return v96.collisionTrigger
end
function AIImplement.getAIImplementCollisionTriggers(p98, p99)
	local v100 = p98:getAIImplementCollisionTrigger()
	if v100 ~= nil then
		p99[p98] = v100
	end
end
function AIImplement.getAINeedsLowering(p101)
	return p101.spec_aiImplement.needsLowering
end
function AIImplement.getAILowerIfAnyIsLowered(p102)
	return p102.spec_aiImplement.lowerIfAnyIsLowered
end
function AIImplement.getAINeedsRootAlignment(p103)
	return p103.spec_aiImplement.needsRootAlignment
end
function AIImplement.getAIAllowTurnBackward(p104)
	return p104.spec_aiImplement.allowTurnBackward
end
function AIImplement.getAIBlockTurnBackward(p105)
	return p105.spec_aiImplement.blockTurnBackward
end
function AIImplement.getAIIsVineyardTool(p106)
	return p106.spec_aiImplement.isVineyardTool
end
function AIImplement.getAIToolReverserDirectionNode(p107)
	return p107.spec_aiImplement.toolReverserDirectionNode
end
function AIImplement.getAITurnRadiusLimitation(p108)
	local v109 = p108.spec_aiImplement.turningRadiusLimitation
	return v109.radius, v109.rotationJoint, v109.wheels, v109.rotLimitFactor, v109.initialTurnRadiusFactor
end
function AIImplement.setAIImplementVariableSideOffset(p110, p111)
	p110.spec_aiImplement.variableSideOffset = p111
end
function AIImplement.getAIImplementSideOffset(p112)
	local v113 = p112.spec_aiImplement
	local v114 = p112:getCustomAIImplementBaseSetup()
	if v114 == nil or v114.sideOffset == nil then
		v114 = v113
	end
	return v114.sideOffset or 0, v113.variableSideOffset
end
function AIImplement.setAIFruitRequirements(p115, p116, p117, p118)
	p115:clearAIFruitRequirements()
	p115:addAIFruitRequirement(p116, p117, p118)
end
function AIImplement.addAIFruitRequirement(p119, p120, p121, p122, p123, p124, p125)
	local v126 = p119.spec_aiImplement.requiredFruitTypes
	table.insert(v126, {
		["fruitType"] = p120 or 0,
		["minGrowthState"] = p121 or 0,
		["maxGrowthState"] = p122 or 0,
		["customMapId"] = p123,
		["customMapStartChannel"] = p124,
		["customMapNumChannels"] = p125
	})
	p119:updateFieldCropsQuery()
end
function AIImplement.clearAIFruitRequirements(p127)
	local v128 = p127.spec_aiImplement
	if #v128.requiredFruitTypes > 0 then
		v128.requiredFruitTypes = {}
	end
	p127:updateFieldCropsQuery()
end
function AIImplement.getAIFruitRequirements(p129)
	return p129.spec_aiImplement.requiredFruitTypes
end
function AIImplement.setAIDensityHeightTypeRequirements(p130, p131)
	p130:clearAIDensityHeightTypeRequirements()
	p130:addAIDensityHeightTypeRequirement(p131)
end
function AIImplement.addAIDensityHeightTypeRequirement(p132, p133)
	local v134 = p132.spec_aiImplement.requiredDensityHeightTypes
	table.insert(v134, {
		["fillType"] = p133 or 0
	})
	p132:updateFieldCropsQuery()
end
function AIImplement.clearAIDensityHeightTypeRequirements(p135)
	local v136 = p135.spec_aiImplement
	if #v136.requiredDensityHeightTypes > 0 then
		v136.requiredDensityHeightTypes = {}
	end
	p135:updateFieldCropsQuery()
end
function AIImplement.getAIDensityHeightTypeRequirements(p137)
	return p137.spec_aiImplement.requiredDensityHeightTypes
end
function AIImplement.getAIImplementUseVineSegment(_, _, _, _)
	return true
end
function AIImplement.setAIFruitProhibitions(p138, p139, p140, p141)
	p138:clearAIFruitProhibitions()
	p138:addAIFruitProhibitions(p139, p140, p141)
end
function AIImplement.addAIFruitProhibitions(p142, p143, p144, p145, p146, p147, p148)
	local v149 = p142.spec_aiImplement.prohibitedFruitTypes
	table.insert(v149, {
		["fruitType"] = p143 or 0,
		["minGrowthState"] = p144 or 0,
		["maxGrowthState"] = p145 or 0,
		["customMapId"] = p146,
		["customMapStartChannel"] = p147,
		["customMapNumChannels"] = p148
	})
	p142:updateFieldCropsQuery()
end
function AIImplement.clearAIFruitProhibitions(p150)
	local v151 = p150.spec_aiImplement
	if #v151.prohibitedFruitTypes > 0 then
		v151.prohibitedFruitTypes = {}
	end
	p150:updateFieldCropsQuery()
end
function AIImplement.getAIFruitProhibitions(p152)
	return p152.spec_aiImplement.prohibitedFruitTypes
end
function AIImplement.addAITerrainDetailRequiredRange(p153, p154, p155, p156, p157)
	local v158 = p153.spec_aiImplement
	local v159 = v158.terrainDetailRequiredValueRanges
	local v160 = {
		p154,
		p155,
		p156 or v158.groundTypeFirstChannel,
		p157 or v158.groundTypeNumChannels
	}
	table.insert(v159, v160)
	p153:updateFieldCropsQuery()
end
function AIImplement.addAIGroundTypeRequirements(p161, p162, p163, p164, p165, p166, p167, p168)
	local v169 = p161.spec_aiImplement
	for v170 = 1, #p162 do
		local v171 = p162[v170]
		if v171 ~= p163 and (v171 ~= p164 and (v171 ~= p165 and (v171 ~= p166 and (v171 ~= p167 and v171 ~= p168)))) then
			local v172 = FieldGroundType.getValueByType(v171)
			local v173 = v169.terrainDetailRequiredValueRanges
			local v174 = {
				v172,
				v172,
				v169.groundTypeFirstChannel,
				v169.groundTypeNumChannels
			}
			table.insert(v173, v174)
		end
	end
	p161:updateFieldCropsQuery()
end
function AIImplement.clearAITerrainDetailRequiredRange(p175)
	p175.spec_aiImplement.terrainDetailRequiredValueRanges = {}
	p175:updateFieldCropsQuery()
end
function AIImplement.getAITerrainDetailRequiredRange(p176)
	local v177 = p176.spec_aiImplement
	if v177.useAttributesOfAttachedImplement and p176.getAttachedImplements ~= nil then
		for _, v178 in ipairs(p176:getAttachedImplements()) do
			if v178.object.getAITerrainDetailRequiredRange ~= nil then
				return v178.object:getAITerrainDetailRequiredRange()
			end
		end
	end
	return v177.terrainDetailRequiredValueRanges
end
function AIImplement.addAITerrainDetailProhibitedRange(p179, p180, p181, p182, p183)
	local v184 = p179.spec_aiImplement.terrainDetailProhibitedValueRanges
	table.insert(v184, {
		p180,
		p181,
		p182,
		p183
	})
	p179:updateFieldCropsQuery()
end
function AIImplement.clearAITerrainDetailProhibitedRange(p185)
	p185.spec_aiImplement.terrainDetailProhibitedValueRanges = {}
	p185:updateFieldCropsQuery()
end
function AIImplement.getAITerrainDetailProhibitedRange(p186)
	local v187 = p186.spec_aiImplement
	if v187.useAttributesOfAttachedImplement and p186.getAttachedImplements ~= nil then
		for _, v188 in ipairs(p186:getAttachedImplements()) do
			if v188.object.getAITerrainDetailProhibitedRange ~= nil then
				return v188.object:getAITerrainDetailProhibitedRange()
			end
		end
	end
	return v187.terrainDetailProhibitedValueRanges
end
function AIImplement.getFieldCropsQuery(p189)
	local v190 = p189.spec_aiImplement
	if v190.fieldCropyQuery == nil then
		p189:createFieldCropsQuery()
	end
	return v190.fieldCropyQuery, v190.fieldCropyQueryValid
end
function AIImplement.updateFieldCropsQuery(p191)
	if p191.spec_aiImplement.fieldCropyQuery ~= nil then
		p191:createFieldCropsQuery()
	end
end
function AIImplement.compareFieldCropsQuery(p192, p193)
	if p193.getAIFruitRequirements == nil then
		return false
	end
	local v194 = p192:getAIFruitRequirements()
	local v195 = p193:getAIFruitRequirements()
	for _, v196 in ipairs(v194) do
		local v197 = false
		for _, v198 in ipairs(v195) do
			if v196.fruitType == v198.fruitType and (v196.minGrowthState == v198.minGrowthState and (v196.maxGrowthState == v198.maxGrowthState and (v196.customMapId == v198.customMapId and (v196.customMapStartChannel == v198.customMapStartChannel and v196.customMapNumChannels == v198.customMapNumChannels)))) then
				v197 = true
				break
			end
		end
		if not v197 then
			return false
		end
	end
	local v199 = p192:getAIFruitProhibitions()
	local v200 = p193:getAIFruitProhibitions()
	for _, v201 in ipairs(v199) do
		local v202 = false
		for _, v203 in ipairs(v200) do
			if v201.fruitType == v203.fruitType and (v201.minGrowthState == v203.minGrowthState and (v201.maxGrowthState == v203.maxGrowthState and (v201.customMapId == v203.customMapId and (v201.customMapStartChannel == v203.customMapStartChannel and v201.customMapNumChannels == v203.customMapNumChannels)))) then
				v202 = true
				break
			end
		end
		if not v202 then
			return false
		end
	end
	local v204 = p192:getAITerrainDetailRequiredRange()
	local v205 = p193:getAITerrainDetailRequiredRange()
	for _, v206 in ipairs(v204) do
		local v207 = false
		for _, v208 in ipairs(v205) do
			if v206[1] == v208[1] and (v206[2] == v208[2] and (v206[3] == v208[3] and v206[4] == v208[4])) then
				v207 = true
				break
			end
		end
		if not v207 then
			return false
		end
	end
	local v209 = p192:getAITerrainDetailProhibitedRange()
	local v210 = p193:getAITerrainDetailProhibitedRange()
	for _, v211 in ipairs(v209) do
		local v212 = false
		for _, v213 in ipairs(v210) do
			if v211[1] == v213[1] and (v211[2] == v213[2] and (v211[3] == v213[3] and v211[4] == v213[4])) then
				v212 = true
				break
			end
		end
		if not v212 then
			return false
		end
	end
	return true
end
function AIImplement.createFieldCropsQuery(p214)
	local v215, v216, v217 = g_currentMission.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
	if v215 ~= nil then
		local v218 = p214.spec_aiImplement
		v218.fieldCropyQueryValid = false
		local v219 = FieldCropsQuery.new(v215)
		local v220 = p214:getAIFruitRequirements()
		for v221 = 1, #v220 do
			local v222 = v220[v221]
			if v222.customMapId == nil and v222.fruitType ~= FruitType.UNKNOWN then
				local v223 = g_fruitTypeManager:getFruitTypeByIndex(v222.fruitType)
				if v223.terrainDataPlaneId ~= nil then
					v219:addRequiredCropType(v223.terrainDataPlaneId, v222.minGrowthState, v222.maxGrowthState, v223.startStateChannel, v223.numStateChannels, v216, v217)
				end
			elseif v222.customMapId ~= nil then
				v219:addRequiredDensityMapValue(v222.customMapId, v222.minGrowthState, v222.maxGrowthState, v222.customMapStartChannel, v222.customMapNumChannels)
			end
			v218.fieldCropyQueryValid = true
		end
		local v224 = p214:getAIFruitProhibitions()
		for v225 = 1, #v224 do
			local v226 = v224[v225]
			if v226.customMapId == nil and v226.fruitType ~= FruitType.UNKNOWN then
				local v227 = g_fruitTypeManager:getFruitTypeByIndex(v226.fruitType)
				v219:addProhibitedCropType(v227.terrainDataPlaneId, v226.minGrowthState, v226.maxGrowthState, v227.startStateChannel, v227.numStateChannels, v216, v217)
			elseif v226.customMapId ~= nil then
				v219:addProhibitedDensityMapValue(v226.customMapId, v226.minGrowthState, v226.maxGrowthState, v226.customMapStartChannel, v226.customMapNumChannels)
			end
			v218.fieldCropyQueryValid = true
		end
		local v228 = p214:getAITerrainDetailRequiredRange()
		for v229 = 1, #v228 do
			local v230 = v228[v229]
			v219:addRequiredGroundValue(v230[1], v230[2], v230[3], v230[4])
			v218.fieldCropyQueryValid = true
		end
		local v231 = p214:getAITerrainDetailProhibitedRange()
		for v232 = 1, #v231 do
			local v233 = v231[v232]
			v219:addProhibitedGroundValue(v233[1], v233[2], v233[3], v233[4])
			v218.fieldCropyQueryValid = true
		end
		v218.fieldCropyQuery = v219
	end
end
function AIImplement.getIsAIImplementInLine(p234)
	return p234.spec_aiImplement.isLineStarted
end
function AIImplement.aiImplementStartLine(p235)
	p235.spec_aiImplement.isLineStarted = true
	SpecializationUtil.raiseEvent(p235, "onAIImplementStartLine")
	if p235.rootVehicle.actionController ~= nil then
		p235.rootVehicle.actionController:onAIEvent(p235, "onAIImplementStartLine")
	end
end
function AIImplement.aiImplementEndLine(p236)
	p236.spec_aiImplement.isLineStarted = false
	SpecializationUtil.raiseEvent(p236, "onAIImplementEndLine")
	if p236.rootVehicle.actionController ~= nil then
		p236.rootVehicle.actionController:onAIEvent(p236, "onAIImplementEndLine")
	end
end

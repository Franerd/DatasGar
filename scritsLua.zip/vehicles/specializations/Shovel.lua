Shovel = {}
Shovel.SHOVEL_NODE_XML_KEY = "vehicle.shovel.shovelNode(?)"
function Shovel.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(FillUnit, p1) and (SpecializationUtil.hasSpecialization(FillVolume, p1) and SpecializationUtil.hasSpecialization(Dischargeable, p1))
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(BunkerSiloInteractor, p1)
	end
	return v2
end
function Shovel.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Shovel")
	v3:register(XMLValueType.BOOL, "vehicle.shovel#ignoreFillUnitFillType", "Ignore fill unit fill type", false)
	v3:register(XMLValueType.BOOL, "vehicle.shovel#useSpeedLimit", "Use speed limit while shovel is turned on", false)
	v3:register(XMLValueType.NODE_INDEX, Shovel.SHOVEL_NODE_XML_KEY .. "#node", "Shovel node")
	v3:register(XMLValueType.INT, Shovel.SHOVEL_NODE_XML_KEY .. "#fillUnitIndex", "Fill unit index", 1)
	v3:register(XMLValueType.INT, Shovel.SHOVEL_NODE_XML_KEY .. "#loadInfoIndex", "Load info index", 1)
	v3:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. "#width", "Shovel node width", 1)
	v3:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. "#length", "Shovel node length", 0.5)
	v3:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. "#yOffset", "Shovel node y offset", 0)
	v3:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. "#zOffset", "Shovel node z offset", 0)
	v3:register(XMLValueType.BOOL, Shovel.SHOVEL_NODE_XML_KEY .. "#needsMovement", "Needs movement", true)
	v3:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. "#fillLitersPerSecond", "Fill liters per second", "inf.")
	v3:register(XMLValueType.ANGLE, Shovel.SHOVEL_NODE_XML_KEY .. "#maxPickupAngle", "Max. pickup angle")
	v3:register(XMLValueType.BOOL, Shovel.SHOVEL_NODE_XML_KEY .. "#needsAttacherVehicle", "Needs attacher vehicle connected", true)
	v3:register(XMLValueType.BOOL, Shovel.SHOVEL_NODE_XML_KEY .. "#resetFillLevel", "Reset fill level to zero while the shovel node is not active", false)
	v3:register(XMLValueType.BOOL, Shovel.SHOVEL_NODE_XML_KEY .. "#ignoreFillLevel", "Ignore fill level of the fill unit while filling", false)
	v3:register(XMLValueType.BOOL, Shovel.SHOVEL_NODE_XML_KEY .. "#ignoreFarmlandState", "Ignore farmland state for pickup", false)
	v3:register(XMLValueType.BOOL, Shovel.SHOVEL_NODE_XML_KEY .. ".smoothing#allowed", "Leveler smoothes while driving backward", false)
	v3:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. ".smoothing#radius", "Smooth ground radius", 0.5)
	v3:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. ".smoothing#overlap", "Radius overlap", 1.7)
	v3:register(XMLValueType.INT, "vehicle.shovel.dischargeInfo#dischargeNodeIndex", "Discharge node index", 1)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.shovel.dischargeInfo#node", "Discharge info node")
	v3:register(XMLValueType.ANGLE, "vehicle.shovel.dischargeInfo#minSpeedAngle", "Discharge info min. speed angle")
	v3:register(XMLValueType.ANGLE, "vehicle.shovel.dischargeInfo#maxSpeedAngle", "Discharge info max. speed angle")
	EffectManager.registerEffectXMLPaths(v3, "vehicle.shovel.fillEffect")
	v3:setXMLSpecializationType()
end
function Shovel.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "loadShovelNode", Shovel.loadShovelNode)
	SpecializationUtil.registerFunction(p4, "getShovelNodeIsActive", Shovel.getShovelNodeIsActive)
	SpecializationUtil.registerFunction(p4, "getCanShovelAtPosition", Shovel.getCanShovelAtPosition)
	SpecializationUtil.registerFunction(p4, "getShovelTipFactor", Shovel.getShovelTipFactor)
	SpecializationUtil.registerFunction(p4, "getIsShovelEffectState", Shovel.getIsShovelEffectState)
end
function Shovel.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsDischargeNodeActive", Shovel.getIsDischargeNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDischargeNodeEmptyFactor", Shovel.getDischargeNodeEmptyFactor)
	SpecializationUtil.registerOverwrittenFunction(p5, "handleDischarge", Shovel.handleDischarge)
	SpecializationUtil.registerOverwrittenFunction(p5, "handleDischargeOnEmpty", Shovel.handleDischargeOnEmpty)
	SpecializationUtil.registerOverwrittenFunction(p5, "handleDischargeRaycast", Shovel.handleDischargeRaycast)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanToggleDischargeToObject", Shovel.getCanToggleDischargeToObject)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanToggleDischargeToGround", Shovel.getCanToggleDischargeToGround)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", Shovel.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", Shovel.doCheckSpeedLimit)
end
function Shovel.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", Shovel)
	SpecializationUtil.registerEventListener(p6, "onReadStream", Shovel)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", Shovel)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", Shovel)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", Shovel)
	SpecializationUtil.registerEventListener(p6, "onDelete", Shovel)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", Shovel)
	SpecializationUtil.registerEventListener(p6, "onFillUnitFillLevelChanged", Shovel)
end
function Shovel.onLoad(p7, _)
	local v8 = p7.spec_shovel
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.shovel#pickUpNode", "vehicle.shovel.shovelNode#node")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.shovel#pickUpWidth", "vehicle.shovel.shovelNode#width")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.shovel#pickUpLength", "vehicle.shovel.shovelNode#length")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.shovel#pickUpYOffset")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.shovel#pickUpRequiresMovement", "vehicle.shovel.shovelNode#needsMovement")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.shovel#pickUpNeedsToBeTurnedOn", "vehicle.shovel.shovelNode#needsActivation")
	v8.ignoreFillUnitFillType = p7.xmlFile:getValue("vehicle.shovel#ignoreFillUnitFillType", false)
	v8.useSpeedLimit = p7.xmlFile:getValue("vehicle.shovel#useSpeedLimit", false)
	v8.shovelNodes = {}
	local v9 = 0
	while true do
		local v10 = string.format("vehicle.shovel.shovelNode(%d)", v9)
		if not p7.xmlFile:hasProperty(v10) then
			break
		end
		local v11 = {}
		if p7:loadShovelNode(p7.xmlFile, v10, v11) then
			local v12 = v8.shovelNodes
			table.insert(v12, v11)
		end
		v9 = v9 + 1
	end
	v8.shovelDischargeInfo = {}
	v8.shovelDischargeInfo.dischargeNodeIndex = p7.xmlFile:getValue("vehicle.shovel.dischargeInfo#dischargeNodeIndex", 1)
	v8.shovelDischargeInfo.node = p7.xmlFile:getValue("vehicle.shovel.dischargeInfo#node", nil, p7.components, p7.i3dMappings)
	if v8.shovelDischargeInfo.node ~= nil then
		local v13 = p7.xmlFile:getValue("vehicle.shovel.dischargeInfo#minSpeedAngle")
		local v14 = p7.xmlFile:getValue("vehicle.shovel.dischargeInfo#maxSpeedAngle")
		if v13 == nil or v14 == nil then
			Logging.xmlWarning(p7.xmlFile, "Missing \'minSpeedAngle\' or \'maxSpeedAngle\' for dischargeNode \'vehicle.shovel.dischargeInfo\'")
			return false
		end
		v8.shovelDischargeInfo.minSpeedAngle = v13
		v8.shovelDischargeInfo.maxSpeedAngle = v14
	end
	if p7.isClient then
		v8.fillEffects = g_effectManager:loadEffect(p7.xmlFile, "vehicle.shovel.fillEffect", p7.components, p7, p7.i3dMappings)
		v8.fillEffectTime = 0
	end
	v8.effectDirtyFlag = p7:getNextDirtyFlag()
	v8.loadingFillType = FillType.UNKNOWN
	v8.lastValidFillType = FillType.UNKNOWN
	v8.smoothAccumulation = 0
	if #v8.shovelNodes == 0 then
		SpecializationUtil.removeEventListener(p7, "onReadStream", Shovel)
		SpecializationUtil.removeEventListener(p7, "onWriteStream", Shovel)
		SpecializationUtil.removeEventListener(p7, "onReadUpdateStream", Shovel)
		SpecializationUtil.removeEventListener(p7, "onWriteUpdateStream", Shovel)
		SpecializationUtil.removeEventListener(p7, "onUpdateTick", Shovel)
		SpecializationUtil.removeEventListener(p7, "onFillUnitFillLevelChanged", Shovel)
	end
	return true
end
function Shovel.onDelete(p15)
	local v16 = p15.spec_shovel
	g_effectManager:deleteEffects(v16.fillEffects)
end
function Shovel.onReadStream(p17, p18, _)
	p17.spec_shovel.loadingFillType = streamReadUIntN(p18, FillTypeManager.SEND_NUM_BITS)
end
function Shovel.onWriteStream(p19, p20, _)
	local v21 = p19.spec_shovel
	streamWriteUIntN(p20, v21.loadingFillType, FillTypeManager.SEND_NUM_BITS)
end
function Shovel.onReadUpdateStream(p22, p23, _, p24)
	if p24:getIsServer() then
		local v25 = p22.spec_shovel
		if streamReadBool(p23) then
			v25.loadingFillType = streamReadUIntN(p23, FillTypeManager.SEND_NUM_BITS)
		end
	end
end
function Shovel.onWriteUpdateStream(p26, p27, p28, p29)
	if not p28:getIsServer() then
		local v30 = p26.spec_shovel
		if streamWriteBool(p27, bitAND(p29, v30.effectDirtyFlag) ~= 0) then
			streamWriteUIntN(p27, v30.loadingFillType, FillTypeManager.SEND_NUM_BITS)
		end
	end
end
function Shovel.onUpdateTick(p31, p32, _, _, _)
	local v33 = p31.spec_shovel
	if p31.isServer then
		local v34 = FillType.UNKNOWN
		for _, v35 in pairs(v33.shovelNodes) do
			local v36
			if p31:getShovelNodeIsActive(v35) then
				local v37 = p31:getFillUnitFillLevel(v35.fillUnitIndex)
				local v38 = p31:getFillUnitCapacity(v35.fillUnitIndex)
				local v39
				if v35.ignoreFillLevel then
					v39 = (1 / 0)
				else
					local v40 = v38 - v37
					local v41 = v35.fillUnitIndex
					v39 = math.min(v40, p31:getFillUnitFreeCapacity(v41))
				end
				local v42 = v35.fillLitersPerSecond * p32
				local v43 = math.min(v39, v42)
				if v43 > 0 then
					v36 = p31:getFillUnitFillType(v35.fillUnitIndex)
					if v37 / v38 < p31:getFillTypeChangeThreshold() then
						v36 = FillType.UNKNOWN
					end
					local v44 = g_densityMapHeightManager:getMinValidLiterValue(v36) or 0
					local v45, v46, v47 = localToWorld(v35.node, -v35.width * 0.5, v35.yOffset, v35.zOffset)
					local v48, v49, v50 = localToWorld(v35.node, v35.width * 0.5, v35.yOffset, v35.zOffset)
					local v51 = v35.length
					if p31:getCanShovelAtPosition(v35) then
						if v36 == FillType.UNKNOWN or v33.ignoreFillUnitFillType then
							v36 = DensityMapHeightUtil.getFillTypeAtLine(v45, v46, v47, v48, v49, v50, v51)
						end
						if v36 == FillType.UNKNOWN or not (p31:getFillUnitSupportsFillType(v35.fillUnitIndex, v36) and p31:getFillUnitAllowsFillType(v35.fillUnitIndex, v36)) then
							v36 = v34
						else
							local v52, v53 = DensityMapHeightUtil.tipToGroundAroundLine(p31, -v43 - v44, v36, v45, v46, v47, v48, v49, v50, v51, nil, v35.lineOffset, true, nil)
							v35.lineOffset = v53
							if not v35.ignoreFillLevel and v43 < -v52 then
								p31:setFillUnitCapacity(v35.fillUnitIndex, v37 - v52)
								v35.capacityChanged = true
							end
							if v52 < 0 then
								local v54 = p31:getFillVolumeLoadInfo(v35.loadInfoIndex)
								p31:addFillUnitFillLevel(p31:getOwnerFarmId(), v35.fillUnitIndex, -v52, v36, ToolType.UNDEFINED, v54)
								p31:notifiyBunkerSilo(v52, v36, (v45 + v48) * 0.5, (v46 + v49) * 0.5, (v47 + v50) * 0.5)
							else
								v36 = v34
							end
						end
					else
						v36 = v34
					end
				else
					v36 = v34
				end
			elseif v35.resetFillLevel then
				local v55 = p31:getFillUnitFillLevel(v35.fillUnitIndex)
				if v55 > 0 then
					p31:addFillUnitFillLevel(p31:getOwnerFarmId(), v35.fillUnitIndex, -v55, p31:getFillUnitFillType(v35.fillUnitIndex), ToolType.UNDEFINED)
					v36 = v34
				else
					v36 = v34
				end
			else
				v36 = v34
			end
			if v35.allowsSmoothing then
				local _, v56, _ = localDirectionToWorld(v35.node, 0, 0, 1)
				if math.acos(v56) > v35.maxPickupAngle then
					local v57 = 0
					if p31.lastSpeedReal > 0.0002 then
						local v58 = v33.smoothAccumulation
						local v59 = p31.lastMovedDistance * 0.5
						local v60 = 0.0003 * p32
						v57 = v58 + math.max(v59, v60)
						v33.smoothAccumulation = v57 - DensityMapHeightUtil.getRoundedHeightValue(v57)
					else
						v33.smoothAccumulation = 0
					end
					if v57 > 0 then
						DensityMapHeightUtil.smoothAroundLine(v35.node, v35.width, v35.smoothGroundRadius, v35.smoothOverlap, v57, true)
						v34 = v36
					else
						v34 = v36
					end
				else
					v34 = v36
				end
			else
				v34 = v36
			end
		end
		if v34 == FillType.UNKNOWN then
			v33.fillEffectTime = v33.fillEffectTime - p32
			if v33.fillEffectTime > 0 then
				v34 = v33.loadingFillType
			end
		else
			v33.fillEffectTime = 500
		end
		if v33.loadingFillType ~= v34 then
			v33.loadingFillType = v34
			p31:raiseDirtyFlags(v33.effectDirtyFlag)
		end
	end
	if p31.isClient then
		if v33.loadingFillType ~= FillType.UNKNOWN then
			g_effectManager:setEffectTypeInfo(v33.fillEffects, v33.loadingFillType)
			g_effectManager:startEffects(v33.fillEffects)
			return
		end
		g_effectManager:stopEffects(v33.fillEffects)
	end
end
function Shovel.onFillUnitFillLevelChanged(p61, p62, _, _, _, _, _)
	if p61.isServer then
		local v63 = p61.spec_shovel
		for _, v64 in pairs(v63.shovelNodes) do
			if v64.fillUnitIndex == p62 and v64.capacityChanged then
				local v65 = p61:getFillUnitByIndex(p62)
				if v65.fillLevel <= v65.defaultCapacity then
					p61:setFillUnitCapacity(p62, v65.defaultCapacity)
					v64.capacityChanged = false
				end
			end
		end
	end
end
function Shovel.loadShovelNode(p66, p67, p68, p69)
	p69.node = p67:getValue(p68 .. "#node", nil, p66.components, p66.i3dMappings)
	if p69.node == nil then
		Logging.xmlWarning(p66.xmlFile, "Missing \'node\' for shovelNode \'%s\'!", p68)
		return false
	end
	p69.fillUnitIndex = p67:getValue(p68 .. "#fillUnitIndex", 1)
	p69.loadInfoIndex = p67:getValue(p68 .. "#loadInfoIndex", 1)
	p69.width = p67:getValue(p68 .. "#width", 1)
	p69.length = p67:getValue(p68 .. "#length", 0.5)
	p69.yOffset = p67:getValue(p68 .. "#yOffset", 0)
	p69.zOffset = p67:getValue(p68 .. "#zOffset", 0)
	p69.needsMovement = p67:getValue(p68 .. "#needsMovement", true)
	p69.lastPosition = { 0, 0, 0 }
	p69.fillLitersPerSecond = p67:getValue(p68 .. "#fillLitersPerSecond", (1 / 0)) / 1000
	p69.maxPickupAngle = p67:getValue(p68 .. "#maxPickupAngle")
	p69.needsAttacherVehicle = p67:getValue(p68 .. "#needsAttacherVehicle", true)
	p69.resetFillLevel = p67:getValue(p68 .. "#resetFillLevel", false)
	p69.ignoreFillLevel = p67:getValue(p68 .. "#ignoreFillLevel", false)
	p69.ignoreFarmlandState = p67:getValue(p68 .. "#ignoreFarmlandState", false)
	p69.allowsSmoothing = p67:getValue(p68 .. ".smoothing#allowed", false)
	p69.smoothGroundRadius = p67:getValue(p68 .. ".smoothing#radius", 0.5)
	p69.smoothOverlap = p67:getValue(p68 .. ".smoothing#overlap", 1.7)
	return true
end
function Shovel.getShovelNodeIsActive(p70, p71)
	local v72 = true
	if p71.needsMovement then
		local v73, v74, v75 = getWorldTranslation(p71.node)
		local _, _, v76 = worldToLocal(p71.node, p71.lastPosition[1], p71.lastPosition[2], p71.lastPosition[3])
		if v72 then
			v72 = v76 < 0
		end
		p71.lastPosition[1] = v73
		p71.lastPosition[2] = v74
		p71.lastPosition[3] = v75
	end
	if p71.maxPickupAngle ~= nil then
		local _, v77, _ = localDirectionToWorld(p71.node, 0, 0, 1)
		if math.acos(v77) > p71.maxPickupAngle then
			return false
		end
	end
	if p71.needsAttacherVehicle and (p70.getAttacherVehicle ~= nil and p70:getAttacherVehicle() == nil) then
		return false
	else
		return v72
	end
end
function Shovel.getIsDischargeNodeActive(p78, p79, p80)
	local v81 = p78.spec_shovel.shovelDischargeInfo
	if v81.node == nil or (v81.dischargeNodeIndex ~= p80.index or p78:getShovelTipFactor() ~= 0) then
		return p79(p78, p80)
	else
		return false
	end
end
function Shovel.getDischargeNodeEmptyFactor(p82, p83, p84)
	local v85 = p82.spec_shovel
	local v86 = p83(p82, p84)
	local v87 = v85.shovelDischargeInfo
	if v87.node == nil or v87.dischargeNodeIndex ~= p84.index then
		return v86
	else
		return v86 * p82:getShovelTipFactor()
	end
end
function Shovel.handleDischarge(p88, p89, p90, p91, p92, p93)
	local v94 = p88.spec_shovel
	if p90.index ~= v94.shovelDischargeInfo.dischargeNodeIndex or v94.shovelDischargeInfo.node == nil then
		p89(p88, p90, p91, p92, p93)
	end
end
function Shovel.handleDischargeOnEmpty(p95, p96, p97, p98, p99)
	if p95.spec_shovel.shovelDischargeInfo.node == nil then
		p96(p95, p97, p98, p99)
	end
end
function Shovel.handleDischargeRaycast(p100, p101, p102, p103, p104, p105, p106, p107)
	local v108 = p100.spec_shovel
	if v108.shovelDischargeInfo.node == nil or v108.shovelDischargeInfo.dischargeNodeIndex ~= p102.index then
		p101(p100, p102, p103, p104, p105, p106, p107)
	elseif p103 == nil then
		if p100:getFillUnitFillLevel(p102.fillUnitIndex) > 0 and p100:getShovelTipFactor() > 0 then
			if p100:getCanDischargeToGround(p102) then
				p100:setDischargeState(Dischargeable.DISCHARGE_STATE_GROUND, true)
				return
			end
			if p100:getIsActiveForInput(true) then
				if not p100:getCanDischargeToLand(p102) then
					g_currentMission:showBlinkingWarning(g_i18n:getText("warning_youDontHaveAccessToThisLand"), 500)
					return
				end
				if not p100:getCanDischargeAtPosition(p102) then
					local v109 = p100:getDischargeNotAllowedWarning(p102)
					g_currentMission:showBlinkingWarning(v109, 500)
					return
				end
			end
		end
	else
		local v110 = p100:getDischargeFillType(p102)
		if p103:getFillUnitAllowsFillType(p106, v110) and p103:getFillUnitFreeCapacity(p106, v110, p100:getOwnerFarmId()) > 0 then
			p100:setDischargeState(Dischargeable.DISCHARGE_STATE_OBJECT, true)
			return
		end
		if p100:getDischargeState() == Dischargeable.DISCHARGE_STATE_OBJECT then
			p100:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF, true)
			return
		end
	end
end
function Shovel.getCanToggleDischargeToObject(p111, p112)
	if p111.spec_shovel.shovelDischargeInfo.node == nil then
		return p112(p111)
	else
		return false
	end
end
function Shovel.getCanToggleDischargeToGround(p113, p114)
	if p113.spec_shovel.shovelDischargeInfo.node == nil then
		return p114(p113)
	else
		return false
	end
end
function Shovel.getShovelTipFactor(p115)
	local v116 = p115.spec_shovel.shovelDischargeInfo
	if v116.node ~= nil then
		local _, v117, _ = localDirectionToWorld(v116.node, 0, 0, 1)
		local v118 = math.acos(v117)
		if v116.minSpeedAngle < v118 then
			local v119 = (v118 - v116.minSpeedAngle) / (v116.maxSpeedAngle - v116.minSpeedAngle)
			local v120 = math.min(1, v119)
			return math.max(0, v120)
		end
	end
	return 0
end
function Shovel.getIsShovelEffectState(p121)
	local v122 = p121.spec_shovel
	return v122.loadingFillType ~= FillType.UNKNOWN, v122.loadingFillType
end
function Shovel.getWearMultiplier(p123, p124)
	local v125 = p123.spec_shovel
	local v126 = p124(p123)
	if v125.loadingFillType ~= FillType.UNKNOWN then
		v126 = v126 + p123:getWorkWearMultiplier()
	end
	return v126
end
function Shovel.doCheckSpeedLimit(p127, p128)
	local v129 = not p128(p127) and p127.spec_shovel.useSpeedLimit
	if v129 then
		v129 = p127.getIsTurnedOn == nil and true or p127:getIsTurnedOn()
	end
	return v129
end
function Shovel.getCanShovelAtPosition(p130, p131)
	if p131 == nil then
		return false
	elseif p131.ignoreFarmlandState then
		return true
	else
		local v132, _, v133 = localToWorld(p131.node, -p131.width * 0.5, 0, 0)
		local v134 = p130:getActiveFarm()
		local v135, _, v136 = localToWorld(p131.node, p131.width * 0.5, 0, 0)
		if g_currentMission.accessHandler:canFarmAccessLand(v134, v132, v133) then
			return g_currentMission.accessHandler:canFarmAccessLand(v134, v135, v136)
		else
			return false
		end
	end
end
function Shovel.updateDebugValues(p137, p138)
	local v139 = p137.spec_shovel.shovelDischargeInfo
	if v139.node ~= nil then
		local _, v140, _ = localDirectionToWorld(v139.node, 0, 0, 1)
		local v141 = math.acos(v140)
		local v142 = {
			["name"] = "angle",
			["value"] = math.deg(v141)
		}
		table.insert(p138, v142)
		local v143 = {
			["name"] = "minSpeedAngle"
		}
		local v144 = v139.minSpeedAngle
		v143.value = math.deg(v144)
		table.insert(p138, v143)
		local v145 = {
			["name"] = "maxSpeedAngle"
		}
		local v146 = v139.maxSpeedAngle
		v145.value = math.deg(v146)
		table.insert(p138, v145)
		if v139.minSpeedAngle < v141 then
			local v147 = (v141 - v139.minSpeedAngle) / (v139.maxSpeedAngle - v139.minSpeedAngle)
			local v148 = math.min(1, v147)
			local v149 = {
				["name"] = "factor",
				["value"] = math.max(0, v148)
			}
			table.insert(p138, v149)
			return
		end
		table.insert(p138, {
			["name"] = "factor",
			["value"] = "Out of Range - 0"
		})
	end
end

source("dataS/scripts/vehicles/specializations/events/MowerToggleWindrowDropEvent.lua")
Mower = {}
function Mower.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("mower", false, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Mower")
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.mower.animationNodes")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.mower.cutterEffects")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.mower.dropEffects.dropEffect(?)")
	v1:register(XMLValueType.INT, "vehicle.mower.dropEffects.dropEffect(?)#dropAreaIndex", "Drop area index", 1)
	v1:register(XMLValueType.INT, "vehicle.mower.dropEffects.dropEffect(?)#workAreaIndex", "Work area index", 1)
	v1:register(XMLValueType.STRING, "vehicle.mower#fruitTypeConverter", "Fruit type converter name")
	v1:register(XMLValueType.INT, "vehicle.mower#fillUnitIndex", "Fill unit index")
	v1:register(XMLValueType.FLOAT, "vehicle.mower#pickupFillScale", "Pickup fill scale", 1)
	v1:register(XMLValueType.L10N_STRING, "vehicle.mower.toggleWindrowDrop#enableText", "Enable windrow drop text")
	v1:register(XMLValueType.L10N_STRING, "vehicle.mower.toggleWindrowDrop#disableText", "Disable windrow drop text")
	v1:register(XMLValueType.STRING, "vehicle.mower.toggleWindrowDrop#animationName", "Windrow drop animation name")
	v1:register(XMLValueType.FLOAT, "vehicle.mower.toggleWindrowDrop#animationEnableSpeed", "Animation enable speed", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.mower.toggleWindrowDrop#animationDisableSpeed", "Animation disable speed", "inversed \'animationEnableSpeed\'")
	v1:register(XMLValueType.BOOL, "vehicle.mower.toggleWindrowDrop#startEnabled", "Start windrow drop enabled", false)
	SoundManager.registerSampleXMLPaths(v1, "vehicle.mower.sounds", "cut(?)")
	v1:register(XMLValueType.BOOL, WorkArea.WORK_AREA_XML_KEY .. ".mower#dropWindrow", "Drop windrow", true)
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. ".mower#dropAreaIndex", "Drop area index", 1)
	v1:register(XMLValueType.BOOL, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".mower#dropWindrow", "Drop windrow", true)
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".mower#dropAreaIndex", "Drop area index", 1)
	v1:setXMLSpecializationType()
end
function Mower.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(WorkArea, p2) and SpecializationUtil.hasSpecialization(TurnOnVehicle, p2)
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(FruitExtraObjects, p2)
	end
	return v3
end
function Mower.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "processMowerArea", Mower.processMowerArea)
	SpecializationUtil.registerFunction(p4, "processDropArea", Mower.processDropArea)
	SpecializationUtil.registerFunction(p4, "getDropArea", Mower.getDropArea)
	SpecializationUtil.registerFunction(p4, "setDropEffectEnabled", Mower.setDropEffectEnabled)
	SpecializationUtil.registerFunction(p4, "setCutSoundEnabled", Mower.setCutSoundEnabled)
	SpecializationUtil.registerFunction(p4, "setUseMowerWindrowDropAreas", Mower.setUseMowerWindrowDropAreas)
end
function Mower.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadWorkAreaFromXML", Mower.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", Mower.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanBeSelected", Mower.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDirtMultiplier", Mower.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", Mower.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getFruitExtraObjectTypeData", Mower.getFruitExtraObjectTypeData)
end
function Mower.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", Mower)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", Mower)
	SpecializationUtil.registerEventListener(p6, "onDelete", Mower)
	SpecializationUtil.registerEventListener(p6, "onReadStream", Mower)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", Mower)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", Mower)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", Mower)
	SpecializationUtil.registerEventListener(p6, "onUpdate", Mower)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", Mower)
	SpecializationUtil.registerEventListener(p6, "onTurnedOn", Mower)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", Mower)
	SpecializationUtil.registerEventListener(p6, "onStartWorkAreaProcessing", Mower)
	SpecializationUtil.registerEventListener(p6, "onEndWorkAreaProcessing", Mower)
	SpecializationUtil.registerEventListener(p6, "onAIFieldCourseSettingsInitialized", Mower)
end
function Mower.onLoad(p_u_7, _)
	local v_u_8 = p_u_7.spec_mower
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mowerEffects.mowerEffect", "vehicle.mower.dropEffects.dropEffect")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mowerEffects.mowerEffect#mowerCutArea", "vehicle.mower.dropEffects.dropEffect#dropAreaIndex")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.mower.turnOnNodes.turnOnNode", "mower")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mowerStartSound", "vehicle.turnOnVehicle.sounds.start")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mowerStopSound", "vehicle.turnOnVehicle.sounds.stop")
	XMLUtil.checkDeprecatedXMLElements(p_u_7.xmlFile, "vehicle.mowerSound", "vehicle.turnOnVehicle.sounds.work")
	if p_u_7.isClient then
		v_u_8.animationNodes = g_animationManager:loadAnimations(p_u_7.xmlFile, "vehicle.mower.animationNodes", p_u_7.components, p_u_7, p_u_7.i3dMappings)
		v_u_8.samples = {}
		v_u_8.samples.cut = g_soundManager:loadSamplesFromXML(p_u_7.xmlFile, "vehicle.mower.sounds", "cut", p_u_7.baseDirectory, p_u_7.components, 0, AudioGroup.VEHICLE, p_u_7.i3dMappings, p_u_7)
	end
	v_u_8.dropEffects = {}
	p_u_7.xmlFile:iterate("vehicle.mower.dropEffects.dropEffect", function(_, p9)
		-- upvalues: (copy) p_u_7, (copy) v_u_8
		local v10 = g_effectManager:loadEffect(p_u_7.xmlFile, p9, p_u_7.components, p_u_7, p_u_7.i3dMappings)
		if v10 ~= nil then
			local v11 = {
				["effects"] = v10,
				["dropAreaIndex"] = p_u_7.xmlFile:getValue(p9 .. "#dropAreaIndex", 1),
				["workAreaIndex"] = p_u_7.xmlFile:getValue(p9 .. "#workAreaIndex", 1)
			}
			if p_u_7:getWorkAreaByIndex(v11.dropAreaIndex) ~= nil then
				if p_u_7:getWorkAreaByIndex(v11.workAreaIndex) == nil then
					Logging.xmlWarning(p_u_7.xmlFile, "Invalid workAreaIndex \'%s\' in \'%s\'", v11.workAreaIndex, p9)
				else
					v11.activeTime = -1
					v11.activeTimeDuration = 750
					v11.isActive = false
					v11.isActiveSent = false
					local v12 = v_u_8.dropEffects
					table.insert(v12, v11)
				end
			end
			Logging.xmlWarning(p_u_7.xmlFile, "Invalid dropAreaIndex \'%s\' in \'%s\'", v11.dropAreaIndex, p9)
		end
	end)
	v_u_8.cutterEffects = g_effectManager:loadEffect(p_u_7.xmlFile, "vehicle.mower.cutterEffects", p_u_7.components, p_u_7, p_u_7.i3dMappings)
	if v_u_8.dropAreas == nil then
		v_u_8.dropAreas = {}
	end
	v_u_8.fruitTypeConverters = {}
	local v13 = p_u_7.xmlFile:getValue("vehicle.mower#fruitTypeConverter")
	if v13 == nil then
		printWarning(string.format("Warning: Missing fruit type converter in \'%s\'", p_u_7.configFileName))
	else
		local v14 = g_fruitTypeManager:getConverterDataByName(v13)
		if v14 ~= nil then
			for v15, v16 in pairs(v14) do
				v_u_8.fruitTypeConverters[v15] = v16
			end
		end
	end
	v_u_8.fillUnitIndex = p_u_7.xmlFile:getValue("vehicle.mower#fillUnitIndex")
	v_u_8.pickupFillScale = p_u_7.xmlFile:getValue("vehicle.mower#pickupFillScale", 1)
	v_u_8.toggleWindrowDropEnableText = p_u_7.xmlFile:getValue("vehicle.mower.toggleWindrowDrop#enableText", nil, p_u_7.customEnvironment, false)
	v_u_8.toggleWindrowDropDisableText = p_u_7.xmlFile:getValue("vehicle.mower.toggleWindrowDrop#disableText", nil, p_u_7.customEnvironment, false)
	v_u_8.toggleWindrowDropAnimation = p_u_7.xmlFile:getValue("vehicle.mower.toggleWindrowDrop#animationName")
	v_u_8.enableWindrowDropAnimationSpeed = p_u_7.xmlFile:getValue("vehicle.mower.toggleWindrowDrop#animationEnableSpeed", 1)
	v_u_8.disableWindrowDropAnimationSpeed = p_u_7.xmlFile:getValue("vehicle.mower.toggleWindrowDrop#animationDisableSpeed", -v_u_8.enableWindrowDropAnimationSpeed)
	v_u_8.useWindrowDropAreas = p_u_7.xmlFile:getValue("vehicle.mower.toggleWindrowDrop#startEnabled", false)
	v_u_8.workAreaParameters = {}
	v_u_8.workAreaParameters.lastChangedArea = 0
	v_u_8.workAreaParameters.lastStatsArea = 0
	v_u_8.workAreaParameters.lastTotalArea = 0
	v_u_8.workAreaParameters.lastUsedAreas = 0
	v_u_8.workAreaParameters.lastUsedAreasSum = 0
	v_u_8.workAreaParameters.lastUsedAreasPct = 0
	v_u_8.workAreaParameters.lastUsedAreasTime = 0
	v_u_8.workAreaParameters.lastCutTime = (-1 / 0)
	v_u_8.workAreaParameters.lastInputFruitType = FruitType.UNKNOWN
	v_u_8.workAreaParameters.lastInputGrowthState = 0
	v_u_8.isWorking = false
	v_u_8.isCutting = false
	v_u_8.lastDropTime = (-1 / 0)
	v_u_8.effectsAreRunning = false
	v_u_8.lastFruitTypeIndex = FruitType.UNKNOWN
	v_u_8.lastFruitGrowthState = 0
	v_u_8.stoneLastState = 0
	v_u_8.stoneWearMultiplierData = g_currentMission.stoneSystem:getWearMultiplierByType("MOWER")
	v_u_8.dirtyFlag = p_u_7:getNextDirtyFlag()
	v_u_8.effectDirtyFlag = p_u_7:getNextDirtyFlag()
	if p_u_7.addAITerrainDetailRequiredRange ~= nil then
		local _, v17, v18 = g_currentMission.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
		local v19 = FieldGroundType.getValueByType(FieldGroundType.GRASS)
		p_u_7:addAITerrainDetailRequiredRange(v19, v19, v17, v18)
		local v20 = FieldGroundType.getValueByType(FieldGroundType.SOWN)
		p_u_7:addAITerrainDetailRequiredRange(v20, v20, v17, v18)
		local v21 = FieldGroundType.getValueByType(FieldGroundType.HARVEST_READY)
		p_u_7:addAITerrainDetailRequiredRange(v21, v21, v17, v18)
	end
	if p_u_7.addAIFruitRequirement ~= nil then
		for v22, _ in pairs(v_u_8.fruitTypeConverters) do
			local v23 = g_fruitTypeManager:getFruitTypeByIndex(v22)
			p_u_7:addAIFruitRequirement(v23.index, v23.minHarvestingGrowthState, v23.maxHarvestingGrowthState)
		end
	end
	if #v_u_8.cutterEffects == 0 then
		SpecializationUtil.removeEventListener(p_u_7, "onUpdate", Mower)
	end
end
function Mower.onPostLoad(p24, _)
	local v25 = p24.spec_mower
	v25.workAreas = p24:getTypedWorkAreas(WorkAreaType.MOWER)
	for v26 = 1, #v25.workAreas do
		local v27 = v25.workAreas[v26]
		v27.dropEffects = {}
		for _, v28 in pairs(v25.dropEffects) do
			if v28.workAreaIndex == v27.index then
				local v29 = v27.dropEffects
				table.insert(v29, v28)
			end
		end
	end
end
function Mower.onDelete(p30)
	local v31 = p30.spec_mower
	if p30.isClient then
		g_animationManager:deleteAnimations(v31.animationNodes)
		if v31.samples ~= nil then
			g_soundManager:deleteSamples(v31.samples.cut)
		end
	end
	if v31.dropEffects ~= nil then
		for _, v32 in pairs(v31.dropEffects) do
			g_effectManager:deleteEffects(v32.effects)
		end
	end
	g_effectManager:deleteEffects(v31.cutterEffects)
end
function Mower.onReadStream(p33, p34, _)
	local v35 = p33.spec_mower
	if v35.toggleWindrowDropEnableText ~= nil and v35.toggleWindrowDropDisableText ~= nil then
		p33:setUseMowerWindrowDropAreas(streamReadBool(p34), true)
	end
end
function Mower.onWriteStream(p36, p37, _)
	local v38 = p36.spec_mower
	if v38.toggleWindrowDropEnableText ~= nil and v38.toggleWindrowDropDisableText ~= nil then
		streamWriteBool(p37, v38.useWindrowDropAreas)
	end
end
function Mower.onReadUpdateStream(p39, p40, _, p41)
	if p41:getIsServer() then
		local v42 = p39.spec_mower
		if #v42.dropEffects > 0 then
			if streamReadBool(p40) then
				for _, v43 in ipairs(v42.dropEffects) do
					v43.fillType = streamReadUIntN(p40, FillTypeManager.SEND_NUM_BITS)
					p39:setDropEffectEnabled(v43, streamReadBool(p40))
				end
			end
		else
			p39:setCutSoundEnabled(streamReadBool(p40))
		end
		if streamReadBool(p40) then
			local v44 = streamReadBool(p40)
			if v44 then
				v42.lastFruitGrowthState = streamReadUIntN(p40, 4)
				local v45 = streamReadUIntN(p40, FruitTypeManager.SEND_NUM_BITS)
				if v45 ~= v42.lastFruitTypeIndex then
					p39:updateFruitExtraObjects()
					v42.lastFruitTypeIndex = v45
				end
				p39:setTestAreaRequirements(v42.lastFruitTypeIndex)
			end
			if v44 ~= v42.effectsAreRunning then
				v42.effectsAreRunning = v44
				if not v44 then
					g_effectManager:stopEffects(v42.cutterEffects)
				end
			end
		end
	end
end
function Mower.onWriteUpdateStream(p46, p47, p48, p49)
	if not p48:getIsServer() then
		local v50 = p46.spec_mower
		if #v50.dropEffects > 0 then
			if streamWriteBool(p47, bitAND(p49, v50.dirtyFlag) ~= 0) then
				for _, v51 in ipairs(v50.dropEffects) do
					streamWriteUIntN(p47, v51.fillType or FillType.UNKNOWN, FillTypeManager.SEND_NUM_BITS)
					streamWriteBool(p47, v51.isActiveSent)
				end
			end
		else
			streamWriteBool(p47, v50.isCutting)
		end
		if streamWriteBool(p47, bitAND(p49, v50.effectDirtyFlag) ~= 0) and streamWriteBool(p47, v50.effectsAreRunning) then
			streamWriteUIntN(p47, v50.lastFruitGrowthState, 4)
			streamWriteUIntN(p47, v50.lastFruitTypeIndex, FruitTypeManager.SEND_NUM_BITS)
		end
	end
end
function Mower.onUpdate(p52, _, _, _, _)
	local v53 = p52.spec_mower
	if p52:getIsTurnedOn() and p52:getLastSpeed() > 0.5 then
		local v54, v55, v56, v57 = p52:getTestAreaWidthByWorkAreaIndex(1)
		local v58
		if v54 == (-1 / 0) and v55 == (1 / 0) then
			v54 = 0
			v55 = 0
			v58 = true
		else
			v58 = false
		end
		local v59
		if p52.movingDirection > 0 then
			v59 = v54 * -1
			v54 = v55 * -1
			if v54 >= v59 then
				local v60 = v59
				v59 = v54
				v54 = v60
			end
		else
			v59 = v55
		end
		local v61, v62, v63
		if p52.isServer then
			v61 = FruitType.UNKNOWN
			if g_time - v53.workAreaParameters.lastCutTime < 500 then
				v61 = v53.workAreaParameters.lastInputFruitType
				v62 = v53.workAreaParameters.lastInputGrowthState
			else
				v62 = 3
			end
			v63 = not v58
			if v63 then
				if v61 == nil then
					v63 = false
				else
					v63 = v61 ~= FruitType.UNKNOWN
				end
			end
			if v63 then
				if not v53.effectsAreRunning then
					v53.effectsAreRunning = true
					p52:raiseDirtyFlags(v53.effectDirtyFlag)
				end
			elseif v53.effectsAreRunning then
				g_effectManager:stopEffects(v53.cutterEffects)
				v53.effectsAreRunning = false
				p52:raiseDirtyFlags(v53.effectDirtyFlag)
			end
			if v61 ~= v53.lastFruitTypeIndex then
				v53.lastFruitTypeIndex = v61
				p52:updateFruitExtraObjects()
			end
			v53.lastFruitGrowthState = v62
		else
			v61 = v53.lastFruitTypeIndex
			v62 = v53.lastFruitGrowthState
			v63 = v53.effectsAreRunning
			if v63 then
				v63 = v53.lastFruitTypeIndex ~= FruitType.UNKNOWN
			end
		end
		if v63 then
			g_effectManager:setEffectTypeInfo(v53.cutterEffects, nil, v61, v62)
			g_effectManager:setMinMaxWidth(v53.cutterEffects, v54, v59, v54 / v56, v59 / v57, v58)
			g_effectManager:startEffects(v53.cutterEffects)
			return
		end
	elseif v53.effectsAreRunning then
		g_effectManager:stopEffects(v53.cutterEffects)
		v53.effectsAreRunning = false
		p52:raiseDirtyFlags(v53.effectDirtyFlag)
	end
end
function Mower.processMowerArea(p64, p65, _)
	local v66 = p64.spec_mower
	local v67, _, v68 = getWorldTranslation(p65.start)
	local v69, _, v70 = getWorldTranslation(p65.width)
	local v71, _, v72 = getWorldTranslation(p65.height)
	if p64:getLastSpeed() > 1 then
		v66.isWorking = true
		v66.stoneLastState = FSDensityMapUtil.getStoneArea(v67, v68, v69, v70, v71, v72)
	else
		v66.stoneLastState = 0
	end
	local v73 = p64:getIsAIActive()
	for v74, v75 in pairs(v66.fruitTypeConverters) do
		local v76, v77, v78, v79, v80, v81, v82, v83, v84, v85, _ = FSDensityMapUtil.updateMowerArea(v74, v67, v68, v69, v70, v71, v72, v73)
		if v76 > 0 then
			local v86 = g_currentMission:getHarvestScaleMultiplier(v74, v78, v79, v80, v81, v82, v83, v84)
			local v87 = g_fruitTypeManager:getFruitTypeAreaLiters(v74, v76, true) * v86 * v75.conversionFactor
			p65.lastPickupLiters = v87
			p65.pickedUpLiters = v87
			local v88 = p64:getDropArea(p65)
			if v88 == nil then
				if v66.fillUnitIndex ~= nil and p64.isServer then
					p64:addFillUnitFillLevel(p64:getOwnerFarmId(), v66.fillUnitIndex, v87, v75.fillTypeIndex, ToolType.UNDEFINED)
				end
			else
				v88.litersToDrop = v88.litersToDrop + v87
				v88.fillType = v75.fillTypeIndex
				v88.workAreaIndex = p65.index
				if v88.fillType == FillType.GRASS_WINDROW then
					local v89, v90, v91, v92, v93, v94, v95 = DensityMapHeightUtil.getLineByArea(p65.start, p65.width, p65.height, true)
					local v96, v97 = DensityMapHeightUtil.tipToGroundAroundLine(p64, (-1 / 0), FillType.DRYGRASS_WINDROW, v89, v90, v91, v92, v93, v94, v95, nil, p65.lineOffset or 0, false, nil, false)
					p65.lineOffset = v97
					v88.litersToDrop = v88.litersToDrop - v96
				end
				local v98 = v88.litersToDrop
				v88.litersToDrop = math.min(v98, 1000)
			end
			v66.workAreaParameters.lastInputFruitType = v74
			v66.workAreaParameters.lastInputGrowthState = v85
			v66.workAreaParameters.lastCutTime = g_time
			v66.workAreaParameters.lastChangedArea = v66.workAreaParameters.lastChangedArea + v76
			v66.workAreaParameters.lastStatsArea = v66.workAreaParameters.lastStatsArea + v76
			v66.workAreaParameters.lastTotalArea = v66.workAreaParameters.lastTotalArea + v77
			v66.workAreaParameters.lastUsedAreas = v66.workAreaParameters.lastUsedAreas + 1
			p64:setTestAreaRequirements(v74)
		end
	end
	v66.workAreaParameters.lastUsedAreasSum = v66.workAreaParameters.lastUsedAreasSum + 1
	return v66.workAreaParameters.lastChangedArea, v66.workAreaParameters.lastTotalArea
end
function Mower.processDropArea(p99, p100, _)
	if p100.litersToDrop > g_densityMapHeightManager:getMinValidLiterValue(p100.fillType) then
		local v101, _, v102 = getWorldTranslation(p100.start)
		local v103, _, v104 = getWorldTranslation(p100.width)
		local v105, _, v106 = getWorldTranslation(p100.height)
		local v107 = math.random()
		local v108 = v101 + v107 * (v105 - v101)
		local v109 = v102 + v107 * (v106 - v102)
		local v110 = getTerrainHeightAtWorldPos(g_terrainNode, v108, 0, v109)
		local v111 = math.random()
		local v112 = v103 + v111 * (v105 - v101)
		local v113 = v104 + v111 * (v106 - v102)
		local v114 = getTerrainHeightAtWorldPos(g_terrainNode, v112, 0, v113)
		local v115, v116 = DensityMapHeightUtil.tipToGroundAroundLine(p99, p100.litersToDrop, p100.fillType, v108, v110, v109, v112, v114, v113, 0, nil, p100.dropLineOffset, false, nil, false)
		p100.litersToDrop = p100.litersToDrop - v115
		p100.dropLineOffset = v116
		if v115 ~= 0 then
			p99.spec_mower.lastDropTime = g_time
		end
	end
end
function Mower.getDropArea(p117, p118)
	if not p118.dropWindrow then
		return nil
	end
	local v119
	if p118.dropAreaIndex == nil then
		v119 = nil
	else
		v119 = p117.spec_workArea.workAreas[p118.dropAreaIndex]
		if v119 == nil then
			local v120 = printWarning
			local v121 = p118.dropAreaIndex
			local v122 = tostring(v121)
			local v123 = p117.configFileName
			v120("Warning: Invalid dropAreaIndex \'" .. v122 .. "\' in \'" .. tostring(v123) .. "\'!")
			p118.dropAreaIndex = nil
		end
		if v119.type ~= WorkAreaType.AUXILIARY then
			Logging.xmlWarning(p117.xmlFile, "Invalid dropAreaIndex \'%s\'. Drop area type needs to be \'AUXILIARY\'!", p118.dropAreaIndex)
			p118.dropAreaIndex = nil
			v119 = nil
		end
	end
	return v119
end
function Mower.setDropEffectEnabled(p124, p125, p126)
	p125.isActive = p126
	if p124.isClient then
		if p126 then
			g_effectManager:setEffectTypeInfo(p125.effects, p125.fillType)
			g_effectManager:startEffects(p125.effects)
			return
		end
		g_effectManager:stopEffects(p125.effects)
	end
end
function Mower.setCutSoundEnabled(p127, p128)
	if p127.isClient then
		local v129 = p127.spec_mower
		if p128 then
			for v130 = 1, #v129.samples.cut do
				if not g_soundManager:getIsSamplePlaying(v129.samples.cut[v130]) then
					g_soundManager:playSample(v129.samples.cut[v130])
				end
			end
			return
		end
		for v131 = 1, #v129.samples.cut do
			if g_soundManager:getIsSamplePlaying(v129.samples.cut[v131]) then
				g_soundManager:stopSample(v129.samples.cut[v131])
			end
		end
	end
end
function Mower.setUseMowerWindrowDropAreas(p132, p133, p134)
	local v135 = p132.spec_mower
	if p133 ~= v135.useWindrowDropAreas then
		MowerToggleWindrowDropEvent.sendEvent(p132, p133, p134)
		v135.useWindrowDropAreas = p133
		if v135.toggleWindrowDropAnimation ~= nil and p132.playAnimation ~= nil then
			local v136 = v135.enableWindrowDropAnimationSpeed
			if not p133 then
				v136 = v135.disableWindrowDropAnimationSpeed
			end
			p132:playAnimation(v135.toggleWindrowDropAnimation, v136, nil, true)
		end
	end
end
function Mower.loadWorkAreaFromXML(p137, p138, p139, p140, p141)
	local v142 = p138(p137, p139, p140, p141)
	if p139.type == WorkAreaType.DEFAULT then
		p139.type = WorkAreaType.MOWER
	end
	if p139.type == WorkAreaType.MOWER then
		p139.dropWindrow = p140:getValue(p141 .. ".mower#dropWindrow", true)
		p139.dropAreaIndex = p140:getValue(p141 .. ".mower#dropAreaIndex", 1)
		p139.lastPickupLiters = 0
		p139.pickedUpLiters = 0
	end
	if p139.type == WorkAreaType.AUXILIARY then
		p139.litersToDrop = 0
		if p137.spec_mower.dropAreas == nil then
			p137.spec_mower.dropAreas = {}
		end
		local v143 = p137.spec_mower.dropAreas
		table.insert(v143, p139)
	end
	return v142
end
function Mower.onRegisterActionEvents(p144, _, p145)
	if p144.isClient then
		local v146 = p144.spec_mower
		p144:clearActionEventsTable(v146.actionEvents)
		if p145 and (v146.toggleWindrowDropEnableText ~= nil and v146.toggleWindrowDropDisableText ~= nil) then
			local _, v147 = p144:addActionEvent(v146.actionEvents, InputAction.IMPLEMENT_EXTRA3, p144, Mower.actionEventToggleDrop, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v147, GS_PRIO_LOW)
			Mower.updateActionEventToggleDrop(p144)
		end
	end
end
function Mower.doCheckSpeedLimit(p148, p149)
	local v150 = not p149(p148) and p148:getIsTurnedOn()
	if v150 then
		v150 = p148.getIsLowered == nil and true or p148:getIsLowered()
	end
	return v150
end
function Mower.getCanBeSelected(_, _)
	return true
end
function Mower.getDirtMultiplier(p151, p152)
	local v153 = p151.spec_mower
	local v154 = p152(p151)
	if v153.isWorking then
		v154 = v154 + p151:getWorkDirtMultiplier() * p151:getLastSpeed() / p151.speedLimit
	end
	return v154
end
function Mower.getWearMultiplier(p155, p156)
	local v157 = p155.spec_mower
	local v158 = p156(p155)
	if v157.isWorking then
		local v159 = (v157.stoneLastState == 0 or v157.stoneWearMultiplierData == nil) and 1 or (v157.stoneWearMultiplierData[v157.stoneLastState] or 1)
		v158 = v158 + p155:getWorkWearMultiplier() * p155:getLastSpeed() / p155.speedLimit * v159
	end
	return v158
end
function Mower.getFruitExtraObjectTypeData(p160, _)
	return p160.spec_mower.lastFruitTypeIndex, nil
end
function Mower.onTurnedOn(p161)
	if p161.isClient then
		local v162 = p161.spec_mower
		g_animationManager:startAnimations(v162.animationNodes)
	end
end
function Mower.onTurnedOff(p163)
	local v164 = p163.spec_mower
	if p163.isClient then
		for _, v165 in pairs(v164.dropEffects) do
			p163:setDropEffectEnabled(v165, false)
		end
		g_animationManager:stopAnimations(v164.animationNodes)
	end
	g_effectManager:stopEffects(v164.cutterEffects)
	v164.effectsAreRunning = false
end
function Mower.onStartWorkAreaProcessing(p166, _)
	local v167 = p166.spec_mower
	if p166.isServer then
		for _, v168 in pairs(v167.dropEffects) do
			if v168.isActive ~= v168.isActiveSent then
				v168.isActiveSent = v168.isActive
				p166:setDropEffectEnabled(v168, v168.isActiveSent)
				p166:raiseDirtyFlags(v167.dirtyFlag)
			end
			v168.isActive = false
		end
	end
	local v169 = p166:getTypedWorkAreas(WorkAreaType.MOWER)
	for v170 = 1, #v169 do
		v169[v170].pickedUpLiters = 0
	end
	v167.workAreaParameters.lastChangedArea = 0
	v167.workAreaParameters.lastStatsArea = 0
	v167.workAreaParameters.lastTotalArea = 0
	v167.isWorking = false
end
function Mower.onEndWorkAreaProcessing(p171, p172, _)
	local v173 = p171.spec_mower
	for _, v174 in ipairs(v173.dropAreas) do
		p171:processDropArea(v174, p172)
	end
	for v175 = 1, #v173.workAreas do
		local v176 = v173.workAreas[v175]
		for v177 = 1, #v176.dropEffects do
			local v178 = v176.dropEffects[v177]
			local v179 = p171:getDropArea(v176)
			if v178.dropAreaIndex == v179.index then
				if v176.pickedUpLiters > 0 then
					if v178.fillType ~= v179.fillType then
						v178.fillType = v179.fillType
						g_effectManager:setEffectTypeInfo(v178.effects, v178.fillType)
					end
					v178.activeTime = v178.activeTimeDuration
					v178.isActive = true
				else
					local v180 = v178.activeTime - p172
					v178.activeTime = math.max(v180, 0)
					if v178.activeTime > 0 then
						v178.isActive = true
					end
				end
			end
		end
	end
	if p171.isServer then
		local v181 = v173.workAreaParameters.lastStatsArea
		if v181 > 0 then
			local v182 = MathUtil.areaToHa(v181, g_currentMission:getFruitPixelsToSqm())
			g_farmManager:updateFarmStats(p171:getLastTouchedFarmlandFarmId(), "threshedHectares", v182)
			p171:updateLastWorkedArea(v181)
		end
		local v183 = g_time - v173.lastDropTime < 500
		if v173.isCutting ~= v183 then
			v173.isCutting = v183
			p171:raiseDirtyFlags(v173.dirtyFlag)
			p171:setCutSoundEnabled(v173.isCutting)
		end
	end
	v173.workAreaParameters.lastUsedAreasTime = v173.workAreaParameters.lastUsedAreasTime + p172
	if v173.workAreaParameters.lastUsedAreasTime > 500 then
		local v184 = v173.workAreaParameters
		local v185 = v173.workAreaParameters.lastUsedAreas
		local v186 = v173.workAreaParameters.lastUsedAreasSum
		v184.lastUsedAreasPct = v185 / math.max(v186, 0.01)
		v173.workAreaParameters.lastUsedAreas = 0
		v173.workAreaParameters.lastUsedAreasSum = 0
		v173.workAreaParameters.lastUsedAreasTime = 0
	end
end
function Mower.onAIFieldCourseSettingsInitialized(_, p187)
	p187.headlandsFirst = true
	p187.workInitialSegment = true
	p187.cornerCutOutSupported = true
end
function Mower.getMowerLoadPercentage(p188)
	return p188.spec_mower == nil and 0 or p188.spec_mower.workAreaParameters.lastUsedAreasPct
end
g_soundManager:registerModifierType("MOWER_LOAD", Mower.getMowerLoadPercentage)
function Mower.getDefaultSpeedLimit()
	return 20
end
function Mower.actionEventToggleDrop(p189, _, _, _, _)
	p189:setUseMowerWindrowDropAreas(not p189.spec_mower.useWindrowDropAreas)
end
function Mower.updateActionEventToggleDrop(p190)
	local v191 = p190.spec_mower
	local v192 = v191.actionEvents[InputAction.IMPLEMENT_EXTRA3]
	if v192 ~= nil then
		local v193 = string.format(v191.toggleWindrowDropDisableText, p190.typeDesc)
		if not v191.useWindrowDropAreas then
			v193 = string.format(v191.toggleWindrowDropEnableText, p190.typeDesc)
		end
		g_inputBinding:setActionEventText(v192.actionEventId, v193)
	end
end

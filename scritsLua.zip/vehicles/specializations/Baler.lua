source("dataS/scripts/vehicles/specializations/events/BalerSetIsUnloadingBaleEvent.lua")
source("dataS/scripts/vehicles/specializations/events/BalerSetBaleTimeEvent.lua")
source("dataS/scripts/vehicles/specializations/events/BalerCreateBaleEvent.lua")
source("dataS/scripts/vehicles/specializations/events/BalerDropFromPlatformEvent.lua")
source("dataS/scripts/vehicles/specializations/events/BalerAutomaticDropEvent.lua")
source("dataS/scripts/vehicles/specializations/events/BalerBaleTypeEvent.lua")
Baler = {}
Baler.CONSUMABLE_TYPE_NAME_ROUND = "BALE_NET"
Baler.CONSUMABLE_TYPE_NAME_SQUARE = "BALE_TWINE"
Baler.UNLOADING_CLOSED = 1
Baler.UNLOADING_OPENING = 2
Baler.UNLOADING_OPEN = 3
Baler.UNLOADING_CLOSING = 4
function Baler.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("baler", g_i18n:getText("shop_configuration"), "baler", VehicleConfigurationItem)
	AIFieldWorker.registerDriveStrategy(function(p1)
		return SpecializationUtil.hasSpecialization(Baler, p1.specializations)
	end, AIDriveStrategyBaler)
	g_workAreaTypeManager:addWorkAreaType("baler", false, false, true)
	g_storeManager:addSpecType("balerBaleSizeRound", "shopListAttributeIconBaleSizeRound", Baler.loadSpecValueBaleSizeRound, Baler.getSpecValueBaleSizeRound, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("balerBaleSizeSquare", "shopListAttributeIconBaleSizeSquare", Baler.loadSpecValueBaleSizeSquare, Baler.getSpecValueBaleSizeSquare, StoreSpecies.VEHICLE)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Baler")
	Baler.registerBalerXMLPaths(v2, "vehicle.baler")
	Baler.registerBalerXMLPaths(v2, "vehicle.baler.balerConfigurations.balerConfiguration(?)")
	v2:register(XMLValueType.BOOL, FillUnit.ALARM_TRIGGER_XML_KEY .. "#needsBaleLoaded", "Alarm triggers only when a full bale is loaded", false)
	v2:setXMLSpecializationType()
	local v3 = Vehicle.xmlSchemaSavegame
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).baler#numBales", "Number of bales")
	v3:register(XMLValueType.STRING, "vehicles.vehicle(?).baler.bale(?)#filename", "XML Filename of bale")
	v3:register(XMLValueType.STRING, "vehicles.vehicle(?).baler.bale(?)#variationId", "Variation ID of the bale")
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).baler.bale(?)#ownerFarmId", "Owner of the bale")
	v3:register(XMLValueType.STRING, "vehicles.vehicle(?).baler.bale(?)#fillType", "Bale fill type index")
	v3:register(XMLValueType.FLOAT, "vehicles.vehicle(?).baler.bale(?)#fillLevel", "Bale fill level")
	v3:register(XMLValueType.FLOAT, "vehicles.vehicle(?).baler.bale(?)#baleTime", "Bale time")
	v3:register(XMLValueType.BOOL, "vehicles.vehicle(?).baler#platformReadyToDrop", "Platform is ready to drop", false)
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).baler#baleTypeIndex", "Current bale type index", 1)
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).baler#preSelectedBaleTypeIndex", "Pre selected bale type index", 1)
	v3:register(XMLValueType.FLOAT, "vehicles.vehicle(?).baler#fillUnitCapacity", "Current baler capacity depending on bale size")
	v3:register(XMLValueType.BOOL, "vehicles.vehicle(?).baler#bufferUnloadingStarted", "Baler buffer unloading in progress")
	v3:register(XMLValueType.STRING, "vehicles.vehicle(?).baler#workAreaMissionUniqueId", "Workarea mission unique id")
end
function Baler.registerBalerXMLPaths(p4, p5)
	p4:register(XMLValueType.FLOAT, p5 .. "#fillScale", "Fill scale", 1)
	p4:register(XMLValueType.INT, p5 .. "#fillUnitIndex", "Fill unit index", 1)
	p4:register(XMLValueType.FLOAT, p5 .. "#consumableUsage", "Usage of bale net or twine per bale", 0.025)
	p4:register(XMLValueType.BOOL, p5 .. "#useDropLandOwnershipForBales", "Defines if the produced bales are always owned by the land owner of the current location while dropping the bale. If not, the owner is either the owner from the last workArea pickup location (if available) or the owner of the bale as default.", false)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleAnimation#spacing", "Spacing between bales", 0)
	p4:register(XMLValueType.BOOL, p5 .. ".baleAnimation#enableCollision", "Enable collision of bales with any other object", true)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleAnimation.key(?)#time", "Key time")
	p4:register(XMLValueType.VECTOR_TRANS, p5 .. ".baleAnimation.key(?)#pos", "Key position")
	p4:register(XMLValueType.VECTOR_ROT, p5 .. ".baleAnimation.key(?)#rot", "Key rotation")
	p4:register(XMLValueType.STRING, p5 .. ".baleAnimation#closeAnimationName", "Close animation name")
	p4:register(XMLValueType.FLOAT, p5 .. ".baleAnimation#closeAnimationSpeed", "Close animation speed", 1)
	p4:register(XMLValueType.BOOL, p5 .. ".automaticDrop#enabled", "Automatic drop default enabled", "true on mobile")
	p4:register(XMLValueType.BOOL, p5 .. ".automaticDrop#toggleable", "Automatic bale drop can be toggled", "false on mobile")
	p4:register(XMLValueType.L10N_STRING, p5 .. ".baleTypes#changeText", "Change bale size text", "action_changeBaleSize")
	p4:register(XMLValueType.BOOL, p5 .. ".baleTypes.baleType(?)#isRoundBale", "Is round bale", false)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleTypes.baleType(?)#width", "Bale width", 1.2)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleTypes.baleType(?)#height", "Bale height", 0.9)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleTypes.baleType(?)#length", "Bale length", 2.4)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleTypes.baleType(?)#diameter", "Bale diameter", 2.8)
	p4:register(XMLValueType.BOOL, p5 .. ".baleTypes.baleType(?)#isDefault", "Bale type is selected by default", false)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleTypes.baleType(?)#consumableUsage", "Usage of bale net or twine per bale", 0.025)
	p4:register(XMLValueType.STRING, p5 .. ".baleTypes.baleType(?)#chamberBaleVariationId", "Variation identifier of the dummy bale in the chamber", "DEFAULT")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".baleTypes.baleType(?).nodes#baleNode", "Bale link node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".baleTypes.baleType(?).nodes#baleRootNode", "Bale root node", "Same as baleNode")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".baleTypes.baleType(?).nodes#scaleNode", "Bale scale node")
	p4:register(XMLValueType.VECTOR_3, p5 .. ".baleTypes.baleType(?).nodes#scaleComponents", "Bale scale component")
	p4:register(XMLValueType.STRING, p5 .. ".baleTypes.baleType(?).animations#fillAnimation", "Fill animation while this bale type is active")
	p4:register(XMLValueType.STRING, p5 .. ".baleTypes.baleType(?).animations#unloadAnimation", "Unload animation while this bale type is active")
	p4:register(XMLValueType.FLOAT, p5 .. ".baleTypes.baleType(?).animations#unloadAnimationSpeed", "Unload animation speed", 1)
	p4:register(XMLValueType.TIME, p5 .. ".baleTypes.baleType(?).animations#dropAnimationTime", "Specific time in #unloadAnimation when to drop the bale", "At the end of the unloading animation")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".baleTypes.baleType(?).detailVisibilityCutNode(?)#node", "Reference node for details visibility cut")
	p4:register(XMLValueType.INT, p5 .. ".baleTypes.baleType(?).detailVisibilityCutNode(?)#axis", "Axis of visibility cut [1, 3]", 3)
	p4:register(XMLValueType.INT, p5 .. ".baleTypes.baleType(?).detailVisibilityCutNode(?)#direction", "Direction of visibility cut [-1, 1]", 1)
	ObjectChangeUtil.registerObjectChangeXMLPaths(p4, p5 .. ".baleTypes.baleType(?)")
	p4:register(XMLValueType.FLOAT, p5 .. "#unfinishedBaleThreshold", "Threshold to unload a unfinished bale", 2000)
	p4:register(XMLValueType.BOOL, p5 .. "#canUnloadUnfinishedBale", "Can unload unfinished bale", false)
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "work")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "eject")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "unload")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "door")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "knotCleaning")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "bufferOverloadingStart(?)")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "bufferOverloadingStop(?)")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "bufferOverloadingWork(?)")
	AnimationManager.registerAnimationNodesXMLPaths(p4, p5 .. ".animationNodes")
	AnimationManager.registerAnimationNodesXMLPaths(p4, p5 .. ".unloadAnimationNodes")
	EffectManager.registerEffectXMLPaths(p4, p5 .. ".fillEffect")
	EffectManager.registerEffectXMLPaths(p4, p5 .. ".additiveEffects")
	p4:register(XMLValueType.STRING, p5 .. ".knotingAnimation#name", "Knoting animation name")
	p4:register(XMLValueType.FLOAT, p5 .. ".knotingAnimation#speed", "Knoting animation speed", 1)
	p4:register(XMLValueType.STRING, p5 .. ".compactingAnimation#name", "Compacting animation name")
	p4:register(XMLValueType.FLOAT, p5 .. ".compactingAnimation#interval", "Compacting interval", 60)
	p4:register(XMLValueType.FLOAT, p5 .. ".compactingAnimation#compactTime", "Compacting time", 5)
	p4:register(XMLValueType.FLOAT, p5 .. ".compactingAnimation#speed", "Compacting animation speed", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".compactingAnimation#minFillLevelTime", "Compacting min. fill level animation target time", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".compactingAnimation#maxFillLevelTime", "Compacting max. fill level animation target time", 0.1)
	p4:register(XMLValueType.STRING, p5 .. "#maxPickupLitersPerSecond", "Max pickup liters per second", 500)
	p4:register(XMLValueType.BOOL, p5 .. ".baleUnloading#allowed", "Bale unloading allowed", false)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleUnloading#time", "Bale unloading time", 4)
	p4:register(XMLValueType.FLOAT, p5 .. ".baleUnloading#foldThreshold", "Bale unloading fold threshold", 0.25)
	p4:register(XMLValueType.L10N_STRING, p5 .. ".automaticDrop#textPos", "Positive toggle automatic drop text", "action_toggleAutomaticBaleDropPos")
	p4:register(XMLValueType.L10N_STRING, p5 .. ".automaticDrop#textNeg", "Negative toggle automatic drop text", "action_toggleAutomaticBaleDropNeg")
	p4:register(XMLValueType.STRING, p5 .. ".platform#animationName", "Platform animation")
	p4:register(XMLValueType.FLOAT, p5 .. ".platform#nextBaleTime", "Animation time when directly the next bale is unloaded after dropping from platform", 0)
	p4:register(XMLValueType.BOOL, p5 .. ".platform#automaticDrop", "Bale is automatically dropped from platform", "true on mobile")
	p4:register(XMLValueType.FLOAT, p5 .. ".platform#aiSpeed", "Speed of AI while dropping a bale from platform (km/h)", 3)
	p4:register(XMLValueType.INT, p5 .. ".buffer#fillUnitIndex", "Buffer fill unit index")
	p4:register(XMLValueType.INT, p5 .. ".buffer#unloadInfoIndex", "Fill volume unload info index index", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".buffer#capacityPercentage", "If set, this percentage of the bale capacity is set for the buffer. If not set the defined capacity from the xml is used.")
	p4:register(XMLValueType.TIME, p5 .. ".buffer#overloadingDuration", "Duration of overloading from buffer to baler unit (sec)", 0.5)
	p4:register(XMLValueType.TIME, p5 .. ".buffer#overloadingDelay", "Time until the real overloading is starting (can be used to wait for the effects to be fully fade in) (sec)", 0)
	p4:register(XMLValueType.FLOAT, p5 .. ".buffer#overloadingStartFillLevelPct", "Fill level percentage [0-1] of the buffer to start the overloading", 1)
	p4:register(XMLValueType.BOOL, p5 .. ".buffer#fillMainUnitAfterOverload", "After overloading the full buffer to the main unit it will continue filling the main unit until it\'s full", false)
	p4:register(XMLValueType.STRING, p5 .. ".buffer#balerDisplayType", "Forced fill type to display on baler unit")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".buffer.dummyBale#node", "Dummy bale link node")
	p4:register(XMLValueType.VECTOR_3, p5 .. ".buffer.dummyBale#scaleComponents", "Dummy bale link scale components", "1 1 0")
	p4:register(XMLValueType.STRING, p5 .. ".buffer.overloadAnimation#name", "Name of overload animation")
	p4:register(XMLValueType.FLOAT, p5 .. ".buffer.overloadAnimation#speedScale", "Speed of overload animation", 1)
	p4:register(XMLValueType.STRING, p5 .. ".buffer.loadingStateAnimation#name", "Name of loading state animation")
	p4:register(XMLValueType.FLOAT, p5 .. ".buffer.loadingStateAnimation#speedScale", "Speed of loading state animation", 1)
	EffectManager.registerEffectXMLPaths(p4, p5 .. ".buffer.overloadingEffect")
	AnimationManager.registerAnimationNodesXMLPaths(p4, p5 .. ".buffer.overloadingAnimationNodes")
	p4:register(XMLValueType.FLOAT, p5 .. ".variableSpeedLimit#targetLiterPerSecond", "Target liters per second", 200)
	p4:register(XMLValueType.TIME, p5 .. ".variableSpeedLimit#changeInterval", "Interval which adjusts speed limit to conditions", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".variableSpeedLimit#minSpeedLimit", "Min. speed limit", 5)
	p4:register(XMLValueType.FLOAT, p5 .. ".variableSpeedLimit#maxSpeedLimit", "Max. speed limit", 15)
	p4:register(XMLValueType.FLOAT, p5 .. ".variableSpeedLimit#defaultSpeedLimit", "Default speed limit", 10)
	p4:register(XMLValueType.STRING, p5 .. ".variableSpeedLimit.target(?)#fillType", "Name of fill type")
	p4:register(XMLValueType.FLOAT, p5 .. ".variableSpeedLimit.target(?)#targetLiterPerSecond", "Target liters per second with this fill type", 200)
	p4:register(XMLValueType.FLOAT, p5 .. ".variableSpeedLimit.target(?)#defaultSpeedLimit", "Default speed limit with this fill type", 10)
	p4:register(XMLValueType.INT, p5 .. ".additives#fillUnitIndex", "Additives fill unit index")
	p4:register(XMLValueType.FLOAT, p5 .. ".additives#usage", "Usage per picked up liter", 0.0000275)
	p4:register(XMLValueType.STRING, p5 .. ".additives#fillTypes", "Fill types to apply additives", "GRASS_WINDROW")
	p4:register(XMLValueType.BOOL, p5 .. ".additives#appliedByBufferOverloading", "Additives are applied while the buffer unit is overloaded into main unit", false)
end
function Baler.prerequisitesPresent(p6)
	local v7 = SpecializationUtil.hasSpecialization(FillUnit, p6) and SpecializationUtil.hasSpecialization(WorkArea, p6) and (SpecializationUtil.hasSpecialization(TurnOnVehicle, p6) and SpecializationUtil.hasSpecialization(AnimatedVehicle, p6))
	if v7 then
		v7 = SpecializationUtil.hasSpecialization(Consumable, p6)
	end
	return v7
end
function Baler.registerEvents(p8)
	SpecializationUtil.registerEvent(p8, "onBalerUnloadingStarted")
	SpecializationUtil.registerEvent(p8, "onBalerUnloadingFinished")
end
function Baler.registerFunctions(p9)
	SpecializationUtil.registerFunction(p9, "processBalerArea", Baler.processBalerArea)
	SpecializationUtil.registerFunction(p9, "setBaleTypeIndex", Baler.setBaleTypeIndex)
	SpecializationUtil.registerFunction(p9, "isUnloadingAllowed", Baler.isUnloadingAllowed)
	SpecializationUtil.registerFunction(p9, "getTimeFromLevel", Baler.getTimeFromLevel)
	SpecializationUtil.registerFunction(p9, "moveBales", Baler.moveBales)
	SpecializationUtil.registerFunction(p9, "moveBale", Baler.moveBale)
	SpecializationUtil.registerFunction(p9, "setIsUnloadingBale", Baler.setIsUnloadingBale)
	SpecializationUtil.registerFunction(p9, "getIsBaleUnloading", Baler.getIsBaleUnloading)
	SpecializationUtil.registerFunction(p9, "dropBale", Baler.dropBale)
	SpecializationUtil.registerFunction(p9, "finishBale", Baler.finishBale)
	SpecializationUtil.registerFunction(p9, "createBale", Baler.createBale)
	SpecializationUtil.registerFunction(p9, "setBaleTime", Baler.setBaleTime)
	SpecializationUtil.registerFunction(p9, "getCanUnloadUnfinishedBale", Baler.getCanUnloadUnfinishedBale)
	SpecializationUtil.registerFunction(p9, "setBalerAutomaticDrop", Baler.setBalerAutomaticDrop)
	SpecializationUtil.registerFunction(p9, "updateDummyBale", Baler.updateDummyBale)
	SpecializationUtil.registerFunction(p9, "deleteDummyBale", Baler.deleteDummyBale)
	SpecializationUtil.registerFunction(p9, "createDummyBale", Baler.createDummyBale)
	SpecializationUtil.registerFunction(p9, "handleUnloadingBaleEvent", Baler.handleUnloadingBaleEvent)
	SpecializationUtil.registerFunction(p9, "dropBaleFromPlatform", Baler.dropBaleFromPlatform)
	SpecializationUtil.registerFunction(p9, "getBalerBaleOwnerFarmId", Baler.getBalerBaleOwnerFarmId)
	SpecializationUtil.registerFunction(p9, "getIsRoundBaler", Baler.getIsRoundBaler)
end
function Baler.registerOverwrittenFunctions(p10)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadSpeedRotatingPartFromXML", Baler.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "doCheckSpeedLimit", Baler.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsSpeedRotatingPartActive", Baler.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "getCanBeTurnedOn", Baler.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsFoldAllowed", Baler.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsWorkAreaActive", Baler.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "getConsumingLoad", Baler.getConsumingLoad)
	SpecializationUtil.registerOverwrittenFunction(p10, "getRequiresPower", Baler.getRequiresPower)
	SpecializationUtil.registerOverwrittenFunction(p10, "getCanBeSelected", Baler.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsAttachedTo", Baler.getIsAttachedTo)
	SpecializationUtil.registerOverwrittenFunction(p10, "getAllowDynamicMountFillLevelInfo", Baler.getAllowDynamicMountFillLevelInfo)
	SpecializationUtil.registerOverwrittenFunction(p10, "getAlarmTriggerIsActive", Baler.getAlarmTriggerIsActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadAlarmTrigger", Baler.loadAlarmTrigger)
	SpecializationUtil.registerOverwrittenFunction(p10, "getShowConsumableEmptyWarning", Baler.getShowConsumableEmptyWarning)
	SpecializationUtil.registerOverwrittenFunction(p10, "addToPhysics", Baler.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p10, "removeFromPhysics", Baler.removeFromPhysics)
end
function Baler.registerEventListeners(p11)
	SpecializationUtil.registerEventListener(p11, "onLoad", Baler)
	SpecializationUtil.registerEventListener(p11, "onPostLoad", Baler)
	SpecializationUtil.registerEventListener(p11, "onLoadFinished", Baler)
	SpecializationUtil.registerEventListener(p11, "onDelete", Baler)
	SpecializationUtil.registerEventListener(p11, "onReadStream", Baler)
	SpecializationUtil.registerEventListener(p11, "onWriteStream", Baler)
	SpecializationUtil.registerEventListener(p11, "onReadUpdateStream", Baler)
	SpecializationUtil.registerEventListener(p11, "onWriteUpdateStream", Baler)
	SpecializationUtil.registerEventListener(p11, "onUpdate", Baler)
	SpecializationUtil.registerEventListener(p11, "onUpdateTick", Baler)
	SpecializationUtil.registerEventListener(p11, "onDraw", Baler)
	SpecializationUtil.registerEventListener(p11, "onRegisterActionEvents", Baler)
	SpecializationUtil.registerEventListener(p11, "onRegisterExternalActionEvents", Baler)
	SpecializationUtil.registerEventListener(p11, "onStartWorkAreaProcessing", Baler)
	SpecializationUtil.registerEventListener(p11, "onEndWorkAreaProcessing", Baler)
	SpecializationUtil.registerEventListener(p11, "onTurnedOn", Baler)
	SpecializationUtil.registerEventListener(p11, "onTurnedOff", Baler)
	SpecializationUtil.registerEventListener(p11, "onRootVehicleChanged", Baler)
	SpecializationUtil.registerEventListener(p11, "onChangedFillType", Baler)
	SpecializationUtil.registerEventListener(p11, "onFillUnitFillLevelChanged", Baler)
	SpecializationUtil.registerEventListener(p11, "onConsumableVariationChanged", Baler)
end
function Baler.onLoad(p_u_12, p13)
	local v_u_14 = p_u_12.spec_baler
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.fillScale#value", "vehicle.baler#fillScale")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.baler.animationNodes.animationNode", "baler")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.balingAnimation#name", "vehicle.turnOnVehicle.turnedOnAnimation#name")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.fillParticleSystems", "vehicle.baler.fillEffect with effectClass \'ParticleEffect\'")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.uvScrollParts.uvScrollPart", "vehicle.baler.animationNodes.animationNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.balerAlarm", "vehicle.fillUnit.fillUnitConfigurations.fillUnitConfiguration.fillUnits.fillUnit.alarmTriggers.alarmTrigger.alarmSound")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.baleAnimation#node", "vehicle.baler.baleTypes.baleType#baleNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.baleAnimation#baleNode", "vehicle.baler.baleTypes.baleType#baleNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.baleAnimation#scaleNode", "vehicle.baler.baleTypes.baleType#scaleNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.baleAnimation#baleScaleComponent", "vehicle.baler.baleTypes.baleType#scaleComponents")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.baleAnimation#unloadAnimationName", "vehicle.baler.baleTypes.baleType#unloadAnimation")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.baleAnimation#unloadAnimationSpeed", "vehicle.baler.baleTypes.baleType#unloadAnimationSpeed")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.baleAnimation#baleDropAnimTime", "vehicle.baler.baleTypes.baleType#dropAnimationTime")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler#toggleAutomaticDropTextPos", "vehicle.baler.automaticDrop#textPos")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler#toggleAutomaticDropTextNeg", "vehicle.baler.automaticDrop#textNeg")
	XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, "vehicle.baler.baleAnimation#firstBaleMarker", "Please adjust bale nodes to match the default balers")
	local v15 = p_u_12.configurations.baler or 1
	local v16 = string.format("vehicle.baler.balerConfigurations.balerConfiguration(%d)", v15 - 1)
	local v17 = not p_u_12.xmlFile:hasProperty(v16) and "vehicle.baler" or v16
	v_u_14.fillScale = p_u_12.xmlFile:getValue(v17 .. "#fillScale", 1)
	v_u_14.fillUnitIndex = p_u_12.xmlFile:getValue(v17 .. "#fillUnitIndex", 1)
	v_u_14.consumableUsage = p_u_12.xmlFile:getValue(v17 .. "#consumableUsage", 0.025)
	v_u_14.useDropLandOwnershipForBales = p_u_12.xmlFile:getValue(v17 .. "#useDropLandOwnershipForBales", false)
	if p_u_12.xmlFile:hasProperty(v17 .. ".baleAnimation") then
		local v18 = AnimCurve.new(linearInterpolatorN)
		local v_u_19 = {}
		local v_u_20 = nil
		local v_u_21 = nil
		local v_u_22 = nil
		local v_u_23 = 0
		p_u_12.xmlFile:iterate(v17 .. ".baleAnimation.key", function(_, p24)
			-- upvalues: (copy) p_u_12, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (copy) v_u_19
			XMLUtil.checkDeprecatedXMLElements(p_u_12.xmlFile, p24 .. "#time")
			local v25 = {}
			local v26, v27, v28 = p_u_12.xmlFile:getValue(p24 .. "#pos")
			v25.x = v26
			v25.y = v27
			v25.z = v28
			if v25.x == nil then
				Logging.xmlWarning(p_u_12.xmlFile, "Missing values for \'%s\'", p24 .. "#pos")
			else
				local v29, v30, v31 = p_u_12.xmlFile:getValue(p24 .. "#rot", "0 0 0")
				v25.rx = v29
				v25.ry = v30
				v25.rz = v31
				if v_u_20 ~= nil then
					v25.length = MathUtil.vector3Length(v_u_20 - v25.x, v_u_21 - v25.y, v_u_22 - v25.z)
					v_u_23 = v_u_23 + v25.length
					v25.pos = v_u_23
				end
				local v32 = v_u_19
				table.insert(v32, v25)
				local v33 = v25.x
				local v34 = v25.y
				local v35 = v25.z
				v_u_20 = v33
				v_u_21 = v34
				v_u_22 = v35
			end
		end)
		local v36 = v_u_23
		for v37 = 1, #v_u_19 do
			local v38 = v_u_19[v37]
			local v39 = v38.pos == nil and 0 or v38.pos / v36
			v18:addKeyframe({
				v38.x,
				v38.y,
				v38.z,
				v38.rx,
				v38.ry,
				v38.rz,
				["time"] = v39
			})
		end
		if #v_u_19 > 0 then
			v_u_14.baleAnimCurve = v18
			v_u_14.baleAnimLength = v36
			v_u_14.baleAnimSpacing = p_u_12.xmlFile:getValue(v17 .. ".baleAnimation#spacing", 0)
			v_u_14.baleAnimEnableCollision = p_u_12.xmlFile:getValue(v17 .. ".baleAnimation#enableCollision", true)
		end
	end
	v_u_14.hasUnloadingAnimation = true
	v_u_14.isRoundBaler = false
	v_u_14.lastBaleVariationId = nil
	local v_u_40 = 1
	v_u_14.baleTypes = {}
	p_u_12.xmlFile:iterate(v17 .. ".baleTypes.baleType", function(p41, p42)
		-- upvalues: (copy) v_u_14, (copy) p_u_12, (ref) v_u_40
		if #v_u_14.baleTypes >= BalerBaleTypeEvent.MAX_NUM_BALE_TYPES then
			Logging.xmlError(p_u_12.xmlFile, "Too many bale types defined. Max. amount is \'%d\'! \'%s\'", BalerBaleTypeEvent.MAX_NUM_BALE_TYPES, p42)
			return false
		else
			local v_u_43 = {
				["index"] = p41,
				["isRoundBale"] = p_u_12.xmlFile:getValue(p42 .. "#isRoundBale", false),
				["width"] = MathUtil.round(p_u_12.xmlFile:getValue(p42 .. "#width", 1.2), 2),
				["height"] = MathUtil.round(p_u_12.xmlFile:getValue(p42 .. "#height", 0.9), 2),
				["length"] = MathUtil.round(p_u_12.xmlFile:getValue(p42 .. "#length", 2.4), 2),
				["diameter"] = MathUtil.round(p_u_12.xmlFile:getValue(p42 .. "#diameter", 1.8), 2)
			}
			if v_u_43.isRoundBale then
				v_u_14.isRoundBaler = true
			end
			v_u_43.isDefault = p_u_12.xmlFile:getValue(p42 .. "#isDefault", false)
			if v_u_43.isDefault then
				v_u_40 = p41
			end
			v_u_43.consumableUsage = p_u_12.xmlFile:getValue(p42 .. "#consumableUsage", v_u_14.consumableUsage)
			v_u_43.chamberBaleVariationId = p_u_12.xmlFile:getValue(p42 .. "#chamberBaleVariationId", "DEFAULT")
			v_u_43.baleNode = p_u_12.xmlFile:getValue(p42 .. ".nodes#baleNode", nil, p_u_12.components, p_u_12.i3dMappings)
			local v44, v45 = p_u_12.xmlFile:getValue(p42 .. ".nodes#baleRootNode", v_u_43.baleNode, p_u_12.components, p_u_12.i3dMappings)
			v_u_43.baleRootNode = v44
			v_u_43.baleNodeComponent = v45
			if v_u_43.baleRootNode ~= nil and v_u_43.baleNodeComponent == nil then
				v_u_43.baleNodeComponent = p_u_12:getParentComponent(v_u_43.baleRootNode)
			end
			if v_u_43.baleNode == nil then
				Logging.xmlError(p_u_12.xmlFile, "Missing baleNode for bale type. \'%s\'", p42)
			else
				v_u_43.scaleNode = p_u_12.xmlFile:getValue(p42 .. ".nodes#scaleNode", nil, p_u_12.components, p_u_12.i3dMappings)
				v_u_43.scaleComponents = p_u_12.xmlFile:getValue(p42 .. ".nodes#scaleComponents", nil, true)
				v_u_43.animations = {}
				v_u_43.animations.fill = p_u_12.xmlFile:getValue(p42 .. ".animations#fillAnimation")
				v_u_43.animations.unloading = p_u_12.xmlFile:getValue(p42 .. ".animations#unloadAnimation")
				v_u_43.animations.unloadingSpeed = p_u_12.xmlFile:getValue(p42 .. ".animations#unloadAnimationSpeed", 1)
				v_u_43.animations.dropAnimationTime = p_u_12.xmlFile:getValue(p42 .. ".animations#dropAnimationTime", p_u_12:getAnimationDuration(v_u_43.animations.unloading) / 1000)
				v_u_43.detailVisibilityCutNodes = {}
				p_u_12.xmlFile:iterate(p42 .. ".detailVisibilityCutNode", function(_, p46)
					-- upvalues: (ref) p_u_12, (copy) v_u_43
					local v47 = {
						["node"] = p_u_12.xmlFile:getValue(p46 .. "#node", nil, p_u_12.components, p_u_12.i3dMappings)
					}
					if v47.node ~= nil then
						v47.axis = p_u_12.xmlFile:getValue(p46 .. "#axis", 3)
						v47.direction = p_u_12.xmlFile:getValue(p46 .. "#direction", 1)
						local v48 = v_u_43.detailVisibilityCutNodes
						table.insert(v48, v47)
					end
				end)
				v_u_43.changeObjects = {}
				ObjectChangeUtil.loadObjectChangeFromXML(p_u_12.xmlFile, p42, v_u_43.changeObjects, p_u_12.components, p_u_12)
				local v49 = v_u_14.baleTypes
				table.insert(v49, v_u_43)
				local v50 = v_u_14
				local v51 = v_u_14.hasUnloadingAnimation
				if v51 then
					v51 = v_u_43.animations.unloading ~= nil
				end
				v50.hasUnloadingAnimation = v51
			end
		end
	end)
	local v52 = v_u_14.baleTypes[v_u_40]
	if v52 ~= nil then
		ObjectChangeUtil.setObjectChanges(v52.changeObjects, true, p_u_12, p_u_12.setMovingToolDirty)
	end
	v_u_14.changeBaleTypeText = p_u_12.xmlFile:getValue(v17 .. ".baleTypes#changeText", "action_changeBaleSize", p_u_12.customEnvironment)
	v_u_14.preSelectedBaleTypeIndex = v_u_40
	v_u_14.currentBaleTypeIndex = v_u_40
	v_u_14.currentBaleXMLFilename = nil
	v_u_14.currentBaleTypeDefinition = nil
	if #v_u_14.baleTypes == 0 then
		Logging.xmlError(p_u_12.xmlFile, "No baleTypes definded for baler.")
	end
	if v_u_14.hasUnloadingAnimation then
		v_u_14.automaticDrop = p_u_12.xmlFile:getValue(v17 .. ".automaticDrop#enabled", Platform.gameplay.automaticBaleDrop)
		v_u_14.toggleableAutomaticDrop = p_u_12.xmlFile:getValue(v17 .. ".automaticDrop#toggleable", not Platform.gameplay.automaticBaleDrop)
		v_u_14.toggleAutomaticDropTextPos = p_u_12.xmlFile:getValue(v17 .. ".automaticDrop#textPos", "action_toggleAutomaticBaleDropPos", p_u_12.customEnvironment)
		v_u_14.toggleAutomaticDropTextNeg = p_u_12.xmlFile:getValue(v17 .. ".automaticDrop#textNeg", "action_toggleAutomaticBaleDropNeg", p_u_12.customEnvironment)
		v_u_14.baleCloseAnimationName = p_u_12.xmlFile:getValue(v17 .. ".baleAnimation#closeAnimationName")
		v_u_14.baleCloseAnimationSpeed = p_u_12.xmlFile:getValue(v17 .. ".baleAnimation#closeAnimationSpeed", 1)
		local v53 = p_u_12:getAnimationByName(v_u_14.baleCloseAnimationName)
		if v_u_14.baleCloseAnimationName == nil or v53 == nil then
			Logging.xmlError(p_u_12.xmlFile, "Failed to find baler close animation. (%s)", v17 .. ".baleAnimation#closeAnimationName")
		else
			v53.resetOnStart = false
		end
	end
	v_u_14.unfinishedBaleThreshold = p_u_12.xmlFile:getValue(v17 .. "#unfinishedBaleThreshold", 2000)
	v_u_14.canUnloadUnfinishedBale = p_u_12.xmlFile:getValue(v17 .. "#canUnloadUnfinishedBale", false)
	v_u_14.lastBaleFillLevel = nil
	if p_u_12.isClient then
		v_u_14.samples = {}
		v_u_14.samples.work = g_soundManager:loadSampleFromXML(p_u_12.xmlFile, v17 .. ".sounds", "work", p_u_12.baseDirectory, p_u_12.components, 0, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
		v_u_14.samples.eject = g_soundManager:loadSampleFromXML(p_u_12.xmlFile, v17 .. ".sounds", "eject", p_u_12.baseDirectory, p_u_12.components, 0, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
		v_u_14.samples.unload = g_soundManager:loadSampleFromXML(p_u_12.xmlFile, v17 .. ".sounds", "unload", p_u_12.baseDirectory, p_u_12.components, 0, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
		v_u_14.samples.door = g_soundManager:loadSampleFromXML(p_u_12.xmlFile, v17 .. ".sounds", "door", p_u_12.baseDirectory, p_u_12.components, 1, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
		v_u_14.samples.knotCleaning = g_soundManager:loadSampleFromXML(p_u_12.xmlFile, v17 .. ".sounds", "knotCleaning", p_u_12.baseDirectory, p_u_12.components, 1, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
		v_u_14.knotCleaningTimer = 10000
		v_u_14.knotCleaningTime = 120000
		v_u_14.animationNodes = g_animationManager:loadAnimations(p_u_12.xmlFile, v17 .. ".animationNodes", p_u_12.components, p_u_12, p_u_12.i3dMappings)
		v_u_14.unloadAnimationNodes = g_animationManager:loadAnimations(p_u_12.xmlFile, v17 .. ".unloadAnimationNodes", p_u_12.components, p_u_12, p_u_12.i3dMappings)
		v_u_14.fillEffects = g_effectManager:loadEffect(p_u_12.xmlFile, v17 .. ".fillEffect", p_u_12.components, p_u_12, p_u_12.i3dMappings)
		v_u_14.fillEffectType = FillType.UNKNOWN
		v_u_14.additiveEffects = g_effectManager:loadEffect(p_u_12.xmlFile, v17 .. ".additiveEffects", p_u_12.components, p_u_12, p_u_12.i3dMappings)
		v_u_14.knotingAnimation = p_u_12.xmlFile:getValue(v17 .. ".knotingAnimation#name")
		v_u_14.knotingAnimationSpeed = p_u_12.xmlFile:getValue(v17 .. ".knotingAnimation#speed", 1)
		v_u_14.compactingAnimation = p_u_12.xmlFile:getValue(v17 .. ".compactingAnimation#name")
		v_u_14.compactingAnimationInterval = p_u_12.xmlFile:getValue(v17 .. ".compactingAnimation#interval", 60) * 1000
		v_u_14.compactingAnimationCompactTime = p_u_12.xmlFile:getValue(v17 .. ".compactingAnimation#compactTime", 5) * 1000
		v_u_14.compactingAnimationCompactTimer = v_u_14.compactingAnimationCompactTime
		v_u_14.compactingAnimationTime = v_u_14.compactingAnimationInterval
		v_u_14.compactingAnimationSpeed = p_u_12.xmlFile:getValue(v17 .. ".compactingAnimation#speed", 1)
		v_u_14.compactingAnimationMinTime = p_u_12.xmlFile:getValue(v17 .. ".compactingAnimation#minFillLevelTime", 1)
		v_u_14.compactingAnimationMaxTime = p_u_12.xmlFile:getValue(v17 .. ".compactingAnimation#maxFillLevelTime", 0.1)
	end
	v_u_14.lastAreaBiggerZero = false
	v_u_14.lastAreaBiggerZeroSent = false
	v_u_14.lastAreaBiggerZeroTime = 0
	v_u_14.workAreaParameters = {}
	v_u_14.workAreaParameters.lastPickedUpLiters = 0
	v_u_14.fillUnitOverflowFillLevel = 0
	v_u_14.maxPickupLitersPerSecond = p_u_12.xmlFile:getValue(v17 .. "#maxPickupLitersPerSecond", 500)
	v_u_14.pickUpLitersBuffer = ValueBuffer.new(750)
	v_u_14.unloadingState = Baler.UNLOADING_CLOSED
	v_u_14.pickupFillTypes = {}
	v_u_14.bales = {}
	v_u_14.dummyBale = {}
	v_u_14.dummyBale.currentBaleFillType = FillType.UNKNOWN
	v_u_14.dummyBale.currentBale = nil
	v_u_14.dummyBale.currentBaleLength = 0
	v_u_14.allowsBaleUnloading = p_u_12.xmlFile:getValue(v17 .. ".baleUnloading#allowed", false)
	v_u_14.baleUnloadingTime = p_u_12.xmlFile:getValue(v17 .. ".baleUnloading#time", 4) * 1000
	v_u_14.baleFoldThreshold = p_u_12.xmlFile:getValue(v17 .. ".baleUnloading#foldThreshold", 0.25) * p_u_12:getFillUnitCapacity(v_u_14.fillUnitIndex)
	v_u_14.platformAnimation = p_u_12.xmlFile:getValue(v17 .. ".platform#animationName")
	v_u_14.platformAnimationNextBaleTime = p_u_12.xmlFile:getValue(v17 .. ".platform#nextBaleTime", 0)
	v_u_14.platformAutomaticDrop = p_u_12.xmlFile:getValue(v17 .. ".platform#automaticDrop", Platform.gameplay.automaticBaleDrop)
	v_u_14.platformAIDropSpeed = p_u_12.xmlFile:getValue(v17 .. ".platform#aiSpeed", 3)
	v_u_14.hasPlatform = v_u_14.platformAnimation ~= nil
	v_u_14.hasDynamicMountPlatform = SpecializationUtil.hasSpecialization(DynamicMountAttacher, p_u_12.specializations)
	if v_u_14.hasPlatform then
		v_u_14.automaticDrop = true
	end
	v_u_14.platformReadyToDrop = false
	v_u_14.platformDropInProgress = false
	v_u_14.platformDelayedDropping = false
	v_u_14.platformMountDelay = -1
	v_u_14.buffer = {}
	v_u_14.buffer.fillUnitIndex = p_u_12.xmlFile:getValue(v17 .. ".buffer#fillUnitIndex")
	v_u_14.buffer.unloadInfoIndex = p_u_12.xmlFile:getValue(v17 .. ".buffer#unloadInfoIndex", 1)
	v_u_14.buffer.capacityPercentage = p_u_12.xmlFile:getValue(v17 .. ".buffer#capacityPercentage")
	v_u_14.buffer.overloadingDuration = p_u_12.xmlFile:getValue(v17 .. ".buffer#overloadingDuration", 1)
	v_u_14.buffer.overloadingDelay = p_u_12.xmlFile:getValue(v17 .. ".buffer#overloadingDelay", 0)
	v_u_14.buffer.overloadingTimer = 0
	v_u_14.buffer.overloadingStartFillLevelPct = MathUtil.round(p_u_12.xmlFile:getValue(v17 .. ".buffer#overloadingStartFillLevelPct", 1), 2)
	v_u_14.buffer.fillMainUnitAfterOverload = p_u_12.xmlFile:getValue(v17 .. ".buffer#fillMainUnitAfterOverload", false)
	v_u_14.buffer.unloadingStarted = false
	v_u_14.buffer.fillLevelToEmpty = 0
	v_u_14.buffer.dummyBale = {}
	v_u_14.buffer.dummyBale.available = p_u_12.xmlFile:hasProperty(v17 .. ".buffer.dummyBale")
	v_u_14.buffer.dummyBale.linkNode = p_u_12.xmlFile:getValue(v17 .. ".buffer.dummyBale#node", nil, p_u_12.components, p_u_12.i3dMappings)
	v_u_14.buffer.dummyBale.scaleComponents = p_u_12.xmlFile:getValue(v17 .. ".buffer.dummyBale#scaleComponents", "1 1 0", true)
	v_u_14.buffer.overloadAnimation = p_u_12.xmlFile:getValue(v17 .. ".buffer.overloadAnimation#name")
	v_u_14.buffer.overloadAnimationSpeed = p_u_12.xmlFile:getValue(v17 .. ".buffer.overloadAnimation#speedScale", 1)
	v_u_14.buffer.loadingStateAnimation = p_u_12.xmlFile:getValue(v17 .. ".buffer.loadingStateAnimation#name")
	v_u_14.buffer.loadingStateAnimationSpeed = p_u_12.xmlFile:getValue(v17 .. ".buffer.loadingStateAnimation#speedScale", 1)
	if p_u_12.isClient then
		v_u_14.buffer.overloadingEffects = g_effectManager:loadEffect(p_u_12.xmlFile, v17 .. ".buffer.overloadingEffect", p_u_12.components, p_u_12, p_u_12.i3dMappings)
		v_u_14.buffer.overloadingAnimationNodes = g_animationManager:loadAnimations(p_u_12.xmlFile, v17 .. ".buffer.overloadingAnimationNodes", p_u_12.components, p_u_12, p_u_12.i3dMappings)
		v_u_14.buffer.samplesOverloadingStart = g_soundManager:loadSamplesFromXML(p_u_12.xmlFile, v17 .. ".sounds", "bufferOverloadingStart", p_u_12.baseDirectory, p_u_12.components, 1, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
		v_u_14.buffer.samplesOverloadingStop = g_soundManager:loadSamplesFromXML(p_u_12.xmlFile, v17 .. ".sounds", "bufferOverloadingStop", p_u_12.baseDirectory, p_u_12.components, 1, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
		v_u_14.buffer.samplesOverloadingWork = g_soundManager:loadSamplesFromXML(p_u_12.xmlFile, v17 .. ".sounds", "bufferOverloadingWork", p_u_12.baseDirectory, p_u_12.components, 0, AudioGroup.VEHICLE, p_u_12.i3dMappings, p_u_12)
	end
	v_u_14.nonStopBaling = v_u_14.buffer.fillUnitIndex ~= nil
	if v_u_14.nonStopBaling ~= nil then
		local v54 = p_u_12.xmlFile:getValue(v17 .. ".buffer#balerDisplayType")
		local v55 = g_fillTypeManager:getFillTypeIndexByName(v54)
		if v55 ~= nil then
			p_u_12:setFillUnitFillTypeToDisplay(v_u_14.fillUnitIndex, v55, true)
		end
	end
	v_u_14.variableSpeedLimit = {}
	v_u_14.variableSpeedLimit.enabled = p_u_12.xmlFile:hasProperty(v17 .. ".variableSpeedLimit")
	v_u_14.variableSpeedLimit.pickupPerSecond = 0
	v_u_14.variableSpeedLimit.pickupPerSecondTimer = 0
	v_u_14.variableSpeedLimit.targetLiterPerSecond = p_u_12.xmlFile:getValue(v17 .. ".variableSpeedLimit#targetLiterPerSecond", 200)
	v_u_14.variableSpeedLimit.changeInterval = p_u_12.xmlFile:getValue(v17 .. ".variableSpeedLimit#changeInterval", 1)
	v_u_14.variableSpeedLimit.minSpeedLimit = p_u_12.xmlFile:getValue(v17 .. ".variableSpeedLimit#minSpeedLimit", 5)
	v_u_14.variableSpeedLimit.maxSpeedLimit = p_u_12.xmlFile:getValue(v17 .. ".variableSpeedLimit#maxSpeedLimit", 15)
	v_u_14.variableSpeedLimit.defaultSpeedLimit = p_u_12.xmlFile:getValue(v17 .. ".variableSpeedLimit#defaultSpeedLimit", 10)
	v_u_14.variableSpeedLimit.backupSpeedLimit = p_u_12.speedLimit
	v_u_14.variableSpeedLimit.usedBackupSpeedLimit = false
	v_u_14.variableSpeedLimit.lastAdjustedSpeedLimit = nil
	v_u_14.variableSpeedLimit.lastAdjustedSpeedLimitType = nil
	v_u_14.variableSpeedLimit.fillTypeToTargetLiterPerSecond = {}
	p_u_12.xmlFile:iterate(v17 .. ".variableSpeedLimit.target", function(_, p56)
		-- upvalues: (copy) p_u_12, (copy) v_u_14
		local v57 = g_fillTypeManager:getFillTypeIndexByName(p_u_12.xmlFile:getValue(p56 .. "#fillType"))
		if v57 ~= nil then
			local v58 = {
				["targetLiterPerSecond"] = p_u_12.xmlFile:getValue(p56 .. "#targetLiterPerSecond", 200),
				["defaultSpeedLimit"] = p_u_12.xmlFile:getValue(p56 .. "#defaultSpeedLimit", 10)
			}
			v_u_14.variableSpeedLimit.fillTypeToTargetLiterPerSecond[v57] = v58
		end
	end)
	v_u_14.additives = {}
	v_u_14.additives.fillUnitIndex = p_u_12.xmlFile:getValue(v17 .. ".additives#fillUnitIndex")
	v_u_14.additives.available = p_u_12:getFillUnitByIndex(v_u_14.additives.fillUnitIndex) ~= nil
	v_u_14.additives.usage = p_u_12.xmlFile:getValue(v17 .. ".additives#usage", 0.0000275)
	local v59 = p_u_12.xmlFile:getValue(v17 .. ".additives#fillTypes", "GRASS_WINDROW")
	v_u_14.additives.fillTypes = g_fillTypeManager:getFillTypesByNames(v59, "Warning: \'" .. p_u_12.xmlFile:getFilename() .. "\' has invalid fillType \'%s\'.")
	v_u_14.additives.appliedByBufferOverloading = p_u_12.xmlFile:getValue(v17 .. ".additives#appliedByBufferOverloading", false)
	v_u_14.additives.isActiveTimer = 0
	v_u_14.additives.isActive = false
	v_u_14.isBaleUnloading = false
	v_u_14.balesToUnload = 0
	v_u_14.texts = {}
	v_u_14.texts.warningFoldingBaleLoaded = g_i18n:getText("warning_foldingNotWhileBaleLoaded")
	v_u_14.texts.warningFoldingTurnedOn = g_i18n:getText("warning_foldingNotWhileTurnedOn")
	v_u_14.texts.warningTooManyBales = g_i18n:getText("warning_tooManyBales")
	v_u_14.texts.unloadUnfinishedBale = g_i18n:getText("action_unloadUnfinishedBale")
	v_u_14.texts.unloadBaler = g_i18n:getText("action_unloadBaler")
	v_u_14.texts.closeBack = g_i18n:getText("action_closeBack")
	v_u_14.showBaleLimitWarning = false
	v_u_14.dirtyFlag = p_u_12:getNextDirtyFlag()
	if p13 ~= nil and not p13.resetVehicles then
		p_u_12:setBaleTypeIndex(p13.xmlFile:getValue(p13.key .. ".baler#baleTypeIndex", v_u_14.currentBaleTypeIndex), true, true)
		p_u_12:setBaleTypeIndex(p13.xmlFile:getValue(p13.key .. ".baler#preSelectedBaleTypeIndex", v_u_14.preSelectedBaleTypeIndex), nil, true)
		local v60 = p13.xmlFile:getValue(p13.key .. ".baler#fillUnitCapacity")
		if v60 ~= nil then
			local v61 = v60 == 0 and (1 / 0) or v60
			p_u_12:setFillUnitCapacity(v_u_14.fillUnitIndex, v61)
			if v_u_14.buffer.capacityPercentage ~= nil then
				p_u_12:setFillUnitCapacity(v_u_14.fillUnitIndex, v61 * v_u_14.buffer.capacityPercentage, false)
			end
		end
		v_u_14.workAreaParameters.lastMissionUniqueId = p13.xmlFile:getValue(p13.key .. ".baler#workAreaMissionUniqueId")
		if v_u_14.nonStopBaling then
			v_u_14.buffer.unloadingStarted = p13.xmlFile:getValue(p13.key .. ".baler#bufferUnloadingStarted", v_u_14.buffer.unloadingStarted)
		end
	end
end
function Baler.onPostLoad(p62, p63)
	local v64 = p62.spec_baler
	for v65, v66 in pairs(p62:getFillUnitSupportedFillTypes(v64.fillUnitIndex)) do
		if v66 and v65 ~= FillType.UNKNOWN then
			v64.pickupFillTypes[v65] = 0
		end
	end
	if p63 ~= nil and not p63.resetVehicles then
		local v67 = p63.xmlFile:getValue(p63.key .. ".baler#numBales")
		if v67 ~= nil then
			v64.balesToLoad = {}
			for v68 = 1, v67 do
				local v69 = string.format("%s.baler.bale(%d)", p63.key, v68 - 1)
				local v70 = {}
				local v71 = p63.xmlFile:getValue(v69 .. "#filename")
				local v72 = p63.xmlFile:getValue(v69 .. "#fillType")
				local v73 = g_fillTypeManager:getFillTypeByName(v72)
				if v71 ~= nil and v73 ~= nil then
					v70.filename = v71
					v70.fillType = v73.index
					v70.fillLevel = p63.xmlFile:getValue(v69 .. "#fillLevel")
					v70.baleTime = p63.xmlFile:getValue(v69 .. "#baleTime")
					v70.variationId = p63.xmlFile:getValue(v69 .. "#variationId")
					v70.ownerFarmId = p63.xmlFile:getValue(v69 .. "#ownerFarmId")
					local v74 = v64.balesToLoad
					table.insert(v74, v70)
				end
			end
		end
		if v64.hasPlatform then
			v64.platformReadyToDrop = p63.xmlFile:getValue(p63.key .. ".baler#platformReadyToDrop", v64.platformReadyToDrop)
			if v64.platformReadyToDrop then
				p62:setAnimationTime(v64.platformAnimation, 1, true)
				p62:setAnimationTime(v64.platformAnimation, 0, true)
				v64.platformMountDelay = 1
			end
		end
	end
end
function Baler.onLoadFinished(p75, _)
	local v76 = p75.spec_baler
	if p75.isServer and (v76.createBaleNextFrame ~= nil and v76.createBaleNextFrame) then
		p75:finishBale()
		v76.createBaleNextFrame = nil
	end
	if v76.balesToLoad ~= nil then
		for _, v77 in ipairs(v76.balesToLoad) do
			if p75:createBale(v77.fillType, v77.fillLevel, nil, v77.baleTime, v77.filename, v77.ownerFarmId, v77.variationId, true) then
				p75:setBaleTime(#v76.bales, v77.baleTime, true)
			end
		end
		v76.balesToLoad = nil
	end
end
function Baler.onDelete(p78)
	local v79 = p78.spec_baler
	if v79.bales ~= nil then
		if (v79.dropBalesOnDelete or v79.dropBalesOnDelete == nil) and (p78.isReconfigurating == nil or not p78.isReconfigurating) then
			for v80, _ in pairs(v79.bales) do
				p78:dropBale(v80)
			end
		else
			for _, v81 in pairs(v79.bales) do
				if v81.baleObject ~= nil then
					v81.baleObject:delete()
				end
			end
		end
	end
	p78:deleteDummyBale(v79.dummyBale)
	if v79.buffer ~= nil then
		if v79.buffer.dummyBale.available then
			p78:deleteDummyBale(v79.buffer.dummyBale)
		end
		g_soundManager:deleteSamples(v79.buffer.samplesOverloadingStart)
		g_soundManager:deleteSamples(v79.buffer.samplesOverloadingWork)
		g_soundManager:deleteSamples(v79.buffer.samplesOverloadingStop)
		g_effectManager:deleteEffects(v79.buffer.overloadingEffects)
		g_animationManager:deleteAnimations(v79.buffer.overloadingAnimationNodes)
	end
	g_soundManager:deleteSamples(v79.samples)
	g_effectManager:deleteEffects(v79.fillEffects)
	g_effectManager:deleteEffects(v79.additiveEffects)
	g_animationManager:deleteAnimations(v79.animationNodes)
	g_animationManager:deleteAnimations(v79.unloadAnimationNodes)
end
function Baler.saveToXMLFile(p82, p83, p84, _)
	local v85 = p82.spec_baler
	if not v85.hasUnloadingAnimation or p82:getFillUnitFreeCapacity(v85.fillUnitIndex) > 0 then
		p83:setValue(p84 .. "#numBales", #v85.bales)
		for v86, v87 in ipairs(v85.bales) do
			local v88 = string.format("%s.bale(%d)", p84, v86 - 1)
			p83:setValue(v88 .. "#filename", v87.filename)
			p83:setValue(v88 .. "#variationId", v87.baleObject:getVariationId())
			p83:setValue(v88 .. "#ownerFarmId", v87.baleObject:getOwnerFarmId())
			local v89 = v87.fillType == FillType.UNKNOWN and "UNKNOWN" or g_fillTypeManager:getFillTypeNameByIndex(v87.fillType)
			p83:setValue(v88 .. "#fillType", v89)
			p83:setValue(v88 .. "#fillLevel", v87.fillLevel)
			if v85.baleAnimCurve ~= nil then
				p83:setValue(v88 .. "#baleTime", v87.time)
			end
		end
	end
	if v85.hasPlatform then
		p83:setValue(p84 .. "#platformReadyToDrop", v85.platformReadyToDrop)
	end
	p83:setValue(p84 .. "#baleTypeIndex", v85.currentBaleTypeIndex)
	p83:setValue(p84 .. "#preSelectedBaleTypeIndex", v85.preSelectedBaleTypeIndex)
	p83:setValue(p84 .. "#fillUnitCapacity", p82:getFillUnitCapacity(v85.fillUnitIndex))
	local v90 = g_missionManager:getMissionByUniqueId(v85.workAreaParameters.lastMissionUniqueId)
	if v90 ~= nil and v90:getIsRunning() then
		p83:setValue(p84 .. "#workAreaMissionUniqueId", v90:getUniqueId())
	end
	if v85.nonStopBaling then
		p83:setValue(p84 .. "#bufferUnloadingStarted", v85.buffer.unloadingStarted)
	end
end
function Baler.onReadStream(p91, p92, _)
	local v93 = p91.spec_baler
	if v93.hasUnloadingAnimation then
		local v94 = streamReadUIntN(p92, 7)
		local v95 = streamReadFloat32(p92)
		if v94 == Baler.UNLOADING_CLOSED or v94 == Baler.UNLOADING_CLOSING then
			p91:setIsUnloadingBale(false, true)
			p91:setRealAnimationTime(v93.baleCloseAnimationName, v95)
		elseif v94 == Baler.UNLOADING_OPEN or v94 == Baler.UNLOADING_OPENING then
			p91:setIsUnloadingBale(true, true)
			p91:setRealAnimationTime(v93.baleUnloadAnimationName, v95)
		end
	end
	for v96 = 1, streamReadUInt8(p92) do
		p91:createBale(streamReadIntN(p92, FillTypeManager.SEND_NUM_BITS), (streamReadFloat32(p92)))
		if v93.baleAnimCurve ~= nil then
			p91:setBaleTime(v96, (streamReadFloat32(p92)))
		end
	end
	v93.lastAreaBiggerZero = streamReadBool(p92)
	if v93.hasPlatform then
		v93.platformReadyToDrop = streamReadBool(p92)
		if v93.platformReadyToDrop then
			p91:setAnimationTime(v93.platformAnimation, 1, true)
			p91:setAnimationTime(v93.platformAnimation, 0, true)
		end
	end
	v93.currentBaleTypeIndex = streamReadUIntN(p92, BalerBaleTypeEvent.BALE_TYPE_SEND_NUM_BITS)
	v93.preSelectedBaleTypeIndex = streamReadUIntN(p92, BalerBaleTypeEvent.BALE_TYPE_SEND_NUM_BITS)
	local v97 = streamReadFloat32(p92)
	p91:setFillUnitCapacity(v93.fillUnitIndex, v97)
	local v98 = streamReadFloat32(p92)
	local v99 = p91:getFillUnitByIndex(v93.fillUnitIndex)
	if v99 ~= nil then
		v99.fillLevel = v98
	end
end
function Baler.onWriteStream(p100, p101, _)
	local v102 = p100.spec_baler
	if v102.hasUnloadingAnimation then
		streamWriteUIntN(p101, v102.unloadingState, 7)
		local v103 = 0
		if v102.unloadingState == Baler.UNLOADING_CLOSED or v102.unloadingState == Baler.UNLOADING_CLOSING then
			v103 = p100:getRealAnimationTime(v102.baleCloseAnimationName)
		elseif v102.unloadingState == Baler.UNLOADING_OPEN or v102.unloadingState == Baler.UNLOADING_OPENING then
			v103 = p100:getRealAnimationTime(v102.baleUnloadAnimationName)
		end
		streamWriteFloat32(p101, v103)
	end
	streamWriteUInt8(p101, #v102.bales)
	for v104 = 1, #v102.bales do
		local v105 = v102.bales[v104]
		streamWriteIntN(p101, v105.fillType, FillTypeManager.SEND_NUM_BITS)
		streamWriteFloat32(p101, v105.fillLevel)
		if v102.baleAnimCurve ~= nil then
			streamWriteFloat32(p101, v105.time)
		end
	end
	streamWriteBool(p101, v102.lastAreaBiggerZero)
	if v102.hasPlatform then
		streamWriteBool(p101, v102.platformReadyToDrop)
	end
	streamWriteUIntN(p101, v102.currentBaleTypeIndex, BalerBaleTypeEvent.BALE_TYPE_SEND_NUM_BITS)
	streamWriteUIntN(p101, v102.preSelectedBaleTypeIndex, BalerBaleTypeEvent.BALE_TYPE_SEND_NUM_BITS)
	streamWriteFloat32(p101, p100:getFillUnitCapacity(v102.fillUnitIndex))
	streamWriteFloat32(p101, p100:getFillUnitFillLevel(v102.fillUnitIndex))
end
function Baler.onReadUpdateStream(p106, p107, _, p108)
	local v109 = p106.spec_baler
	if p108:getIsServer() and streamReadBool(p107) then
		v109.lastAreaBiggerZero = streamReadBool(p107)
		v109.fillEffectType = streamReadUIntN(p107, FillTypeManager.SEND_NUM_BITS)
		v109.showBaleLimitWarning = streamReadBool(p107)
		if v109.nonStopBaling then
			v109.buffer.unloadingStarted = streamReadBool(p107)
			if v109.buffer.unloadingStarted then
				local v110 = p106:getFillUnitFillType(v109.buffer.fillUnitIndex)
				if v110 == FillType.UNKNOWN then
					v110 = p106:getFillUnitFillType(v109.fillUnitIndex)
				end
				g_effectManager:setEffectTypeInfo(v109.buffer.overloadingEffects, v110)
				g_effectManager:startEffects(v109.buffer.overloadingEffects)
				g_soundManager:playSamples(v109.buffer.samplesOverloadingStart)
				g_soundManager:playSamples(v109.buffer.samplesOverloadingWork, 0, v109.buffer.samplesOverloadingStart[0])
				g_animationManager:startAnimations(v109.buffer.overloadingAnimationNodes)
			else
				g_effectManager:stopEffects(v109.buffer.overloadingEffects)
				g_soundManager:stopSamples(v109.buffer.samplesOverloadingStart)
				if g_soundManager:getIsSamplePlaying(v109.buffer.samplesOverloadingWork[0]) then
					g_soundManager:stopSamples(v109.buffer.samplesOverloadingWork)
					g_soundManager:playSamples(v109.buffer.samplesOverloadingStop)
				end
				g_animationManager:stopAnimations(v109.buffer.overloadingAnimationNodes)
			end
		end
		v109.additives.isActive = streamReadBool(p107)
		if v109.additives.isActive then
			g_effectManager:setEffectTypeInfo(v109.additiveEffects, FillType.LIQUIDFERTILIZER)
			g_effectManager:startEffects(v109.additiveEffects)
			return
		end
		g_effectManager:stopEffects(v109.additiveEffects)
	end
end
function Baler.onWriteUpdateStream(p111, p112, p113, p114)
	local v115 = p111.spec_baler
	if not p113:getIsServer() and streamWriteBool(p112, bitAND(p114, v115.dirtyFlag) ~= 0) then
		streamWriteBool(p112, v115.lastAreaBiggerZero)
		streamWriteUIntN(p112, v115.fillEffectTypeSent, FillTypeManager.SEND_NUM_BITS)
		streamWriteBool(p112, v115.showBaleLimitWarning)
		if v115.nonStopBaling then
			streamWriteBool(p112, v115.buffer.unloadingStarted)
		end
		streamWriteBool(p112, v115.additives.isActive)
	end
end
function Baler.onUpdate(p116, p117, _, _, _)
	local v118 = p116.spec_baler
	if p116.isClient then
		if v118.baleToMount ~= nil then
			local v119 = NetworkUtil.getObject(v118.baleToMount.baleServerId)
			if v119 ~= nil then
				v119:mountKinematic(p116, v118.baleToMount.jointNode, 0, 0, 0, 0, 0, 0)
				v118.baleToMount.baleInfo.baleObject = v119
				v118.baleToMount.baleInfo.baleServerId = v118.baleToMount.baleServerId
				v118.baleToMount = nil
			end
		end
		local v120 = v118.baleTypes[v118.currentBaleTypeIndex]
		if v120 ~= nil and #v120.detailVisibilityCutNodes > 0 then
			for v121 = 1, #v118.bales do
				local v122 = v118.bales[v121]
				if v122.baleObject ~= nil then
					v122.baleObject:resetDetailVisibilityCut()
					if v122.time < 1 then
						for v123 = 1, #v120.detailVisibilityCutNodes do
							local v124 = v120.detailVisibilityCutNodes[v123]
							v122.baleObject:setDetailVisibilityCutNode(v124.node, v124.axis, v124.direction)
						end
					end
				end
			end
			if v118.dummyBale.currentBale ~= nil then
				for v125 = 1, #v120.detailVisibilityCutNodes do
					local v126 = v120.detailVisibilityCutNodes[v125]
					Bale.setBaleMeshVisibilityCut(v118.dummyBale.currentBale, v126.node, v126.axis, v126.direction, true)
				end
			end
		end
	end
	if p116.isServer then
		if p116.isAddedToPhysics and (v118.createBaleNextFrame ~= nil and v118.createBaleNextFrame) then
			p116:finishBale()
			v118.createBaleNextFrame = nil
		end
		if v118.variableSpeedLimit.enabled then
			v118.variableSpeedLimit.pickupPerSecondTimer = v118.variableSpeedLimit.pickupPerSecondTimer + p117
			if v118.variableSpeedLimit.pickupPerSecondTimer > v118.variableSpeedLimit.changeInterval then
				local v127 = v118.variableSpeedLimit.defaultSpeedLimit
				local v128 = v118.variableSpeedLimit.targetLiterPerSecond
				local v129 = p116:getFillUnitFillType(v118.fillUnitIndex)
				if v129 == FillType.UNKNOWN and v118.nonStopBaling then
					v129 = p116:getFillUnitFillType(v118.buffer.fillUnitIndex)
				end
				if v129 ~= nil and v118.variableSpeedLimit.fillTypeToTargetLiterPerSecond[v129] ~= nil then
					local v130 = v118.variableSpeedLimit.fillTypeToTargetLiterPerSecond[v129]
					v127 = v130.defaultSpeedLimit
					v128 = v130.targetLiterPerSecond
				end
				local v131 = v118.variableSpeedLimit.pickupPerSecond / (v118.variableSpeedLimit.changeInterval / 1000)
				if v131 > 0 then
					if v118.variableSpeedLimit.usedBackupSpeedLimit then
						v118.variableSpeedLimit.usedBackupSpeedLimit = false
						p116.speedLimit = v118.variableSpeedLimit.lastAdjustedSpeedLimit or v127
						if (v118.variableSpeedLimit.lastAdjustedSpeedLimitType or v129) ~= v129 then
							p116.speedLimit = v127
						end
					end
					local v132 = v128 * 0.15
					local v133 = v131 * 2 / v128
					local v134 = math.floor(v133)
					local v135 = math.max(v134, 1)
					if v128 + v132 < v131 then
						local v136 = p116.speedLimit - v135
						local v137 = v118.variableSpeedLimit.minSpeedLimit
						p116.speedLimit = math.max(v136, v137)
					elseif v131 < v128 - v132 then
						local v138 = p116.speedLimit + v135
						local v139 = v118.variableSpeedLimit.maxSpeedLimit
						p116.speedLimit = math.min(v138, v139)
					end
					v118.variableSpeedLimit.lastAdjustedSpeedLimit = p116.speedLimit
					v118.variableSpeedLimit.lastAdjustedSpeedLimitType = v129
				else
					v118.variableSpeedLimit.usedBackupSpeedLimit = true
					p116.speedLimit = v118.variableSpeedLimit.backupSpeedLimit
				end
				v118.variableSpeedLimit.pickupPerSecondTimer = 0
				v118.variableSpeedLimit.pickupPerSecond = 0
			end
		end
	end
end
function Baler.onUpdateTick(p140, p141, _, _, _)
	local v142 = p140.spec_baler
	local v143 = false
	local v144 = p140:getIsTurnedOn()
	if v144 then
		v143 = not g_currentMission.slotSystem:getCanAddLimitedObjects(SlotSystem.LIMITED_OBJECT_BALE, 1) and true or v143
		if p140.isClient then
			if v142.lastAreaBiggerZero and v142.fillEffectType ~= FillType.UNKNOWN then
				v142.lastAreaBiggerZeroTime = 500
			elseif v142.lastAreaBiggerZeroTime > 0 then
				local v145 = v142.lastAreaBiggerZeroTime - p141
				v142.lastAreaBiggerZeroTime = math.max(v145, 0)
			end
			if v142.lastAreaBiggerZeroTime > 0 then
				if v142.fillEffectType ~= FillType.UNKNOWN then
					g_effectManager:setEffectTypeInfo(v142.fillEffects, v142.fillEffectType)
				end
				g_effectManager:startEffects(v142.fillEffects)
				local v146 = v142.pickUpLitersBuffer:get(1000) / v142.maxPickupLitersPerSecond
				g_effectManager:setDensity(v142.fillEffects, (math.max(v146, 0.4)))
			else
				g_effectManager:stopEffects(v142.fillEffects)
			end
			if v142.knotCleaningTimer <= g_currentMission.time then
				g_soundManager:playSample(v142.samples.knotCleaning)
				v142.knotCleaningTimer = g_currentMission.time + v142.knotCleaningTime
			end
			if v142.compactingAnimation ~= nil and v142.unloadingState == Baler.UNLOADING_CLOSED then
				if v142.compactingAnimationTime <= g_currentMission.time then
					local v147 = p140:getFillUnitFillLevelPercentage(v142.fillUnitIndex)
					local v148 = MathUtil.lerp(v142.compactingAnimationMinTime, v142.compactingAnimationMaxTime, v147)
					if v148 > 0 then
						p140:setAnimationStopTime(v142.compactingAnimation, (math.clamp(v148, 0, 1)))
						p140:playAnimation(v142.compactingAnimation, v142.compactingAnimationSpeed, p140:getAnimationTime(v142.compactingAnimation), false)
						v142.compactingAnimationTime = (1 / 0)
					end
				end
				if v142.compactingAnimationTime == (1 / 0) and not p140:getIsAnimationPlaying(v142.compactingAnimation) then
					v142.compactingAnimationCompactTimer = v142.compactingAnimationCompactTimer - p141
					if v142.compactingAnimationCompactTimer < 0 then
						p140:playAnimation(v142.compactingAnimation, -v142.compactingAnimationSpeed, p140:getAnimationTime(v142.compactingAnimation), false)
						v142.compactingAnimationCompactTimer = v142.compactingAnimationCompactTime
					end
					if p140:getAnimationTime(v142.compactingAnimation) == 0 then
						v142.compactingAnimationTime = g_currentMission.time + v142.compactingAnimationInterval
					end
				end
			end
		end
	elseif v142.isBaleUnloading and p140.isServer then
		p140:moveBales(p141 / v142.baleUnloadingTime)
	end
	if p140.isClient and v142.unloadingState == Baler.UNLOADING_OPEN then
		local v149 = v142.baleTypes[v142.currentBaleTypeIndex]
		if getNumOfChildren(v149.baleNode) > 0 then
			delete(getChildAt(v149.baleNode, 0))
		end
	end
	if v142.unloadingState == Baler.UNLOADING_OPENING then
		local v150 = v142.baleTypes[v142.currentBaleTypeIndex]
		local v151 = p140:getIsAnimationPlaying(v150.animations.unloading)
		if v151 and p140:getRealAnimationTime(v150.animations.unloading) < v150.animations.dropAnimationTime then
			g_animationManager:startAnimations(v142.unloadAnimationNodes)
		else
			if #v142.bales > 0 then
				p140:dropBale(1)
				if p140.isServer then
					p140:addFillUnitFillLevel(p140:getOwnerFarmId(), v142.fillUnitIndex, (-1 / 0), p140:getFillUnitFillType(v142.fillUnitIndex), ToolType.UNDEFINED)
					v142.buffer.unloadingStarted = false
					for v152, _ in pairs(v142.pickupFillTypes) do
						v142.pickupFillTypes[v152] = 0
					end
					if p140:getFillUnitFillLevel(v142.fillUnitIndex) == 0 and v142.preSelectedBaleTypeIndex ~= v142.currentBaleTypeIndex then
						p140:setBaleTypeIndex(v142.preSelectedBaleTypeIndex, true)
					end
				end
			end
			if not v151 then
				v142.unloadingState = Baler.UNLOADING_OPEN
				if p140.isClient then
					g_soundManager:stopSample(v142.samples.eject)
					g_soundManager:stopSample(v142.samples.door)
					g_animationManager:stopAnimations(v142.unloadAnimationNodes)
				end
			end
		end
	elseif v142.unloadingState == Baler.UNLOADING_CLOSING and not p140:getIsAnimationPlaying(v142.baleCloseAnimationName) then
		v142.unloadingState = Baler.UNLOADING_CLOSED
		if p140.isClient then
			g_soundManager:stopSample(v142.samples.door)
		end
	end
	if (v142.unloadingState == Baler.UNLOADING_OPEN or v142.unloadingState == Baler.UNLOADING_CLOSING) and (not p140.isServer and #v142.bales > 0) then
		p140:dropBale(1)
	end
	Baler.updateActionEvents(p140)
	if p140.isServer then
		if v142.automaticDrop ~= nil and v142.automaticDrop or p140:getIsAIActive() then
			if p140:isUnloadingAllowed() and (v142.hasUnloadingAnimation or v142.allowsBaleUnloading) and (v142.unloadingState == Baler.UNLOADING_CLOSED and #v142.bales > 0) then
				p140:setIsUnloadingBale(true)
			end
			if v142.hasUnloadingAnimation and v142.unloadingState == Baler.UNLOADING_OPEN then
				p140:setIsUnloadingBale(false)
			end
		end
		v142.pickUpLitersBuffer:add(v142.workAreaParameters.lastPickedUpLiters)
		if v142.additives.isActiveTimer > 0 then
			v142.additives.isActiveTimer = v142.additives.isActiveTimer - p141
			if v142.additives.isActiveTimer < 0 then
				v142.additives.isActiveTimer = 0
				v142.additives.isActive = false
				if p140.isClient then
					g_effectManager:stopEffects(v142.additiveEffects)
				end
				p140:raiseDirtyFlags(v142.dirtyFlag)
			end
		end
		if v142.platformAutomaticDrop and v142.platformReadyToDrop then
			p140:dropBaleFromPlatform(true)
		end
		if v142.hasPlatform then
			if #v142.bales > 0 and v142.platformReadyToDrop then
				p140:dropBaleFromPlatform(true)
			end
			if v142.hasDynamicMountPlatform then
				if v142.platformMountDelay > 0 then
					v142.platformMountDelay = v142.platformMountDelay - 1
					if v142.platformMountDelay == 0 then
						p140:forceDynamicMountPendingObjects(true)
					end
				elseif v142.platformReadyToDrop and not p140:getHasDynamicMountedObjects() then
					p140:dropBaleFromPlatform(false)
				end
			end
		end
		if v142.nonStopBaling then
			local v153 = v142.buffer.unloadingStarted
			local v154 = p140:getFillUnitFillLevel(v142.buffer.fillUnitIndex)
			if v154 > 0 then
				local v155 = p140:getFillUnitCapacity(v142.buffer.fillUnitIndex)
				if v144 and MathUtil.round(v154 / v155, 2) >= v142.buffer.overloadingStartFillLevelPct then
					local v156 = p140:getFillUnitCapacity(v142.fillUnitIndex)
					if (v156 == 0 or (v156 == (1 / 0) or p140:getFillUnitFreeCapacity(v142.fillUnitIndex) > 0)) and (not v142.buffer.unloadingStarted and v142.unloadingState == Baler.UNLOADING_CLOSED) then
						v142.buffer.unloadingStarted = true
						v142.buffer.overloadingTimer = 0
						if v142.buffer.overloadAnimation ~= nil then
							p140:playAnimation(v142.buffer.overloadAnimation, v142.buffer.overloadAnimationSpeed)
						end
					end
				end
				if v142.buffer.unloadingStarted then
					v142.buffer.overloadingTimer = v142.buffer.overloadingTimer + p141
					if v142.buffer.overloadingTimer >= v142.buffer.overloadingDelay and p140:getFillUnitFreeCapacity(v142.fillUnitIndex) > 0 then
						local v157 = p140:getFillUnitCapacity(v142.buffer.fillUnitIndex) / v142.buffer.overloadingDuration * p141
						local v158 = math.min(v157, v154)
						local v159 = p140:getFillUnitFillType(v142.buffer.fillUnitIndex)
						local v160 = p140:getFillVolumeUnloadInfo(v142.buffer.unloadInfoIndex)
						local v161 = p140:addFillUnitFillLevel(p140:getOwnerFarmId(), v142.buffer.fillUnitIndex, -v158, v159, ToolType.UNDEFINED, v160)
						local v162 = p140:getFillUnitFillType(v142.fillUnitIndex)
						if v162 ~= FillType.UNKNOWN then
							v159 = v162
						end
						local v163 = -v161
						if v142.additives.available and v142.additives.appliedByBufferOverloading then
							local v164 = false
							for v165 = 1, #v142.additives.fillTypes do
								if v159 == v142.additives.fillTypes[v165] then
									v164 = true
									break
								end
							end
							if v164 then
								local v166 = p140:getFillUnitFillLevel(v142.additives.fillUnitIndex)
								if v166 > 0 then
									local v167 = v142.additives.usage * v163
									if v167 > 0 then
										local v168 = v166 / v167
										v163 = v163 * (1 + 0.05 * math.min(v168, 1))
										p140:addFillUnitFillLevel(p140:getOwnerFarmId(), v142.additives.fillUnitIndex, -v167, p140:getFillUnitFillType(v142.additives.fillUnitIndex), ToolType.UNDEFINED)
										v142.additives.isActiveTimer = 250
										v142.additives.isActive = true
										p140:raiseDirtyFlags(v142.dirtyFlag)
										if p140.isClient then
											g_effectManager:setEffectTypeInfo(v142.additiveEffects, FillType.LIQUIDFERTILIZER)
											g_effectManager:startEffects(v142.additiveEffects)
										end
									end
								end
							end
						end
						p140:addFillUnitFillLevel(p140:getOwnerFarmId(), v142.fillUnitIndex, v163, v159, ToolType.UNDEFINED, nil)
						if v142.buffer.fillLevelToEmpty > 0 then
							local v169 = v142.buffer
							local v170 = v142.buffer.fillLevelToEmpty - v158
							v169.fillLevelToEmpty = math.max(v170, 0)
							if v142.buffer.fillLevelToEmpty == 0 then
								v142.platformDelayedDropping = true
								v142.buffer.unloadingStarted = false
							end
						end
					end
					if p140:getFillUnitFillLevelPercentage(v142.fillUnitIndex) == 1 or not v144 then
						v142.buffer.unloadingStarted = false
					end
				end
			elseif not v142.buffer.fillMainUnitAfterOverload then
				v142.buffer.unloadingStarted = false
			end
			if v153 ~= v142.buffer.unloadingStarted then
				if p140.isClient then
					if v142.buffer.unloadingStarted then
						local v171 = p140:getFillUnitFillType(v142.buffer.fillUnitIndex)
						g_effectManager:setEffectTypeInfo(v142.buffer.overloadingEffects, v171)
						g_effectManager:startEffects(v142.buffer.overloadingEffects)
						g_animationManager:startAnimations(v142.buffer.overloadingAnimationNodes)
						g_soundManager:playSamples(v142.buffer.samplesOverloadingStart)
						g_soundManager:playSamples(v142.buffer.samplesOverloadingWork, 0, v142.buffer.samplesOverloadingStart[1])
					else
						g_effectManager:stopEffects(v142.buffer.overloadingEffects)
						g_animationManager:stopAnimations(v142.buffer.overloadingAnimationNodes)
						g_soundManager:stopSamples(v142.buffer.samplesOverloadingStart)
						if g_soundManager:getIsSamplePlaying(v142.buffer.samplesOverloadingWork[1]) then
							g_soundManager:stopSamples(v142.buffer.samplesOverloadingWork)
							g_soundManager:playSamples(v142.buffer.samplesOverloadingStop)
						end
					end
				end
				p140:raiseDirtyFlags(v142.dirtyFlag)
			end
			if v142.buffer.overloadAnimation ~= nil and (not p140:getIsAnimationPlaying(v142.buffer.overloadAnimation) and p140:getAnimationTime(v142.buffer.overloadAnimation) > 0.5) then
				p140:playAnimation(v142.buffer.overloadAnimation, -v142.buffer.overloadAnimationSpeed)
			end
			if v144 then
				p140:raiseActive()
			end
		end
	end
	if p140.isServer and v142.showBaleLimitWarning ~= v143 then
		v142.showBaleLimitWarning = v143
		p140:raiseDirtyFlags(v142.dirtyFlag)
	end
	if v142.hasPlatform then
		if v142.platformDelayedDropping and not v142.platformDropInProgress then
			Baler.actionEventUnloading(p140)
			v142.platformDelayedDropping = false
		end
		if v142.platformDropInProgress and not p140:getIsAnimationPlaying(v142.platformAnimation) then
			v142.platformDropInProgress = false
		end
	end
end
function Baler.onDraw(p172)
	local v173 = p172.spec_baler
	if v173.showBaleLimitWarning then
		g_currentMission:showBlinkingWarning(v173.texts.warningTooManyBales, 100)
	end
end
function Baler.getIsFoldAllowed(p174, p175, p176, p177)
	local v178 = p174.spec_baler
	if #v178.bales > 0 and p174:getFillUnitFillLevel(v178.fillUnitIndex) > v178.baleFoldThreshold then
		return false, v178.texts.warningFoldingBaleLoaded
	elseif #v178.bales > 1 then
		return false, v178.texts.warningFoldingBaleLoaded
	elseif p174:getIsTurnedOn() then
		return false, v178.texts.warningFoldingTurnedOn
	elseif v178.hasPlatform and (v178.platformReadyToDrop or v178.platformDropInProgress) then
		return false, v178.texts.warningFoldingBaleLoaded
	else
		return p175(p174, p176, p177)
	end
end
function Baler.onChangedFillType(p179, p180, p181, _)
	local v182 = p179.spec_baler
	if p180 == v182.fillUnitIndex or p180 == v182.buffer.fillUnitIndex then
		local v183 = p179:getFillUnitFillType(v182.fillUnitIndex)
		if v183 == FillType.UNKNOWN then
			v183 = p181
		end
		if v183 ~= FillType.UNKNOWN then
			local v184 = v182.baleTypes[v182.currentBaleTypeIndex]
			v182.currentBaleTypeDefinition = v184
			local v185, v186 = g_baleManager:getBaleXMLFilename(v183, v184.isRoundBale, v184.width, v184.height, v184.length, v184.diameter, p179.customEnvironment)
			v182.currentBaleXMLFilename = v185
			v182.currentBaleIndex = v186
			local v187 = g_baleManager:getBaleCapacityByBaleIndex(v182.currentBaleIndex, v183)
			if p180 == v182.fillUnitIndex then
				p179:setFillUnitCapacity(p180, v187, false)
			elseif v182.buffer.capacityPercentage ~= nil then
				p179:setFillUnitCapacity(p180, v187 * v182.buffer.capacityPercentage, false)
			end
			ObjectChangeUtil.setObjectChanges(v184.changeObjects, true, p179, p179.setMovingToolDirty)
			if v182.currentBaleXMLFilename == nil then
				Logging.warning("Could not find bale for given bale type definition \'%s\'", v184.index)
			end
		end
	end
end
function Baler.onFillUnitFillLevelChanged(p188, p189, p190, p191, p192, _, p193)
	local v194 = p188.spec_baler
	if p189 == v194.fillUnitIndex then
		local v195 = v194.baleTypes[v194.currentBaleTypeIndex]
		local v196 = p188:getFillUnitFillLevel(v194.fillUnitIndex)
		local v197 = p188:getFillUnitCapacity(v194.fillUnitIndex)
		if p188:updateDummyBale(v194.dummyBale, p191, v196, v197) then
			for v198 = 1, #v194.baleTypes do
				p188:setAnimationTime(v194.baleTypes[v198].animations.fill, 0)
			end
		end
		if v196 > 0 then
			p188:setAnimationTime(v195.animations.fill, v196 / v197)
		end
		if p188.isServer and p190 > 0 then
			if p188:getFillUnitFreeCapacity(v194.fillUnitIndex) <= 0 then
				if p188.isAddedToPhysics then
					p188:finishBale()
				else
					v194.createBaleNextFrame = true
				end
				v194.fillUnitOverflowFillLevel = p190 - p193
				return
			end
			if v194.fillUnitOverflowFillLevel > 0 and p190 > 0 then
				local v199 = v194.fillUnitOverflowFillLevel
				v194.fillUnitOverflowFillLevel = 0
				v194.fillUnitOverflowFillLevel = v199 - p188:addFillUnitFillLevel(p188:getOwnerFarmId(), v194.fillUnitIndex, v199, p191, p192)
				return
			end
		end
	elseif v194.nonStopBaling and (p189 == v194.buffer.fillUnitIndex and v194.buffer.dummyBale.available) then
		local v200 = p188:getFillUnitFillLevel(v194.buffer.fillUnitIndex)
		local v201 = p188:getFillUnitCapacity(v194.buffer.fillUnitIndex)
		if v194.buffer.overloadAnimation ~= nil and (p188:getAnimationTime(v194.buffer.overloadAnimation) > 0 and v200 > 0) then
			return
		end
		p188:updateDummyBale(v194.buffer.dummyBale, p191, v200, v201)
	end
end
function Baler.onConsumableVariationChanged(p202, _, p203)
	if p203.bale_variation ~= nil then
		p202.spec_baler.lastBaleVariationId = p203.bale_variation
	end
end
function Baler.onTurnedOn(p204)
	if p204.setFoldState ~= nil and #p204.spec_foldable.foldingParts > 0 then
		p204:setFoldState(p204.spec_foldable.turnOnFoldDirection, false, true)
	end
	if p204.isClient then
		local v205 = p204.spec_baler
		g_animationManager:startAnimations(v205.animationNodes)
		g_soundManager:playSample(v205.samples.work)
	end
	p204:raiseActive()
end
function Baler.onTurnedOff(p206)
	if p206.isClient then
		local v207 = p206.spec_baler
		g_effectManager:stopEffects(v207.fillEffects)
		g_effectManager:stopEffects(v207.additiveEffects)
		g_effectManager:stopEffects(v207.buffer.overloadingEffects)
		g_animationManager:stopAnimations(v207.animationNodes)
		g_soundManager:stopSample(v207.samples.work)
		g_soundManager:stopSample(v207.samples.eject)
		g_soundManager:stopSample(v207.samples.unload)
		g_soundManager:stopSample(v207.samples.door)
		g_soundManager:stopSample(v207.samples.knotCleaning)
		g_soundManager:stopSamples(v207.buffer.samplesOverloadingStart)
		if g_soundManager:getIsSamplePlaying(v207.buffer.samplesOverloadingWork[1]) then
			g_soundManager:stopSamples(v207.buffer.samplesOverloadingWork)
			g_soundManager:playSamples(v207.buffer.samplesOverloadingStop)
		end
	end
end
function Baler.onRootVehicleChanged(p208, p209)
	local v210 = p208.spec_baler
	local v211 = p209.actionController
	if v211 == nil then
		if v210.controlledAction ~= nil then
			v210.controlledAction:remove()
			v210.controlledAction = nil
		end
		return
	elseif v210.controlledAction == nil then
		v210.controlledAction = v211:registerAction("baleUnload", nil, 1)
		v210.controlledAction:setCallback(p208, Baler.actionControllerBaleUnloadEvent)
		v210.controlledAction:setFinishedFunctions(p208, Baler.getIsBaleUnloading, false, false)
	else
		v210.controlledAction:updateParent(v211)
	end
end
function Baler.actionControllerBaleUnloadEvent(p212, p213)
	if p213 < 0 then
		local v214 = p212.spec_baler
		if p212:isUnloadingAllowed() and (v214.allowsBaleUnloading and (v214.unloadingState == Baler.UNLOADING_CLOSED and #v214.bales > 0)) then
			p212:setIsUnloadingBale(true)
		end
	end
	return true
end
function Baler.doCheckSpeedLimit(p215, p216)
	local v217 = not p216(p215) and p215:getIsTurnedOn()
	if v217 then
		v217 = p215:getIsLowered()
	end
	return v217
end
function Baler.setBaleTypeIndex(p218, p219, p220, p221)
	local v222 = p218.spec_baler
	v222.preSelectedBaleTypeIndex = p219
	if p218:getFillUnitFillLevel(v222.fillUnitIndex) == 0 or p220 then
		v222.currentBaleTypeIndex = p219
	end
	Baler.updateActionEvents(p218)
	BalerBaleTypeEvent.sendEvent(p218, p219, p220, p221)
end
function Baler.isUnloadingAllowed(p223)
	local v224 = p223.spec_baler
	if (v224.platformReadyToDrop or v224.platformDropInProgress) and v224.unloadingState ~= Baler.UNLOADING_OPEN then
		return false
	end
	if p223.spec_baleWrapper ~= nil then
		return p223:allowsGrabbingBale()
	end
	local v225 = (v224.allowsBaleUnloading and true or false) and (v224.allowsBaleUnloading and not p223:getIsTurnedOn())
	if v225 then
		v225 = not v224.isBaleUnloading
	end
	return v225
end
function Baler.handleUnloadingBaleEvent(p226)
	local v227 = p226.spec_baler
	if p226:isUnloadingAllowed() and (v227.hasUnloadingAnimation or v227.allowsBaleUnloading) then
		if v227.unloadingState == Baler.UNLOADING_CLOSED then
			if #v227.bales > 0 or p226:getCanUnloadUnfinishedBale() then
				p226:setIsUnloadingBale(true)
				return
			end
		elseif v227.unloadingState == Baler.UNLOADING_OPEN and v227.hasUnloadingAnimation then
			p226:setIsUnloadingBale(false)
		end
	end
end
function Baler.dropBaleFromPlatform(p228, p229, p230)
	local v231 = p228.spec_baler
	if v231.platformReadyToDrop then
		p228:setAnimationTime(v231.platformAnimation, 0, false)
		p228:playAnimation(v231.platformAnimation, 1, p228:getAnimationTime(v231.platformAnimation), true)
		if p229 == true then
			p228:setAnimationStopTime(v231.platformAnimation, v231.platformAnimationNextBaleTime)
		end
		v231.platformReadyToDrop = false
		v231.platformDropInProgress = true
		if p228.isServer and v231.hasDynamicMountPlatform then
			p228:forceUnmountDynamicMountedObjects()
		end
	end
	BalerDropFromPlatformEvent.sendEvent(p228, p229, p230)
end
function Baler.getBalerBaleOwnerFarmId(p232, p233, p234)
	local v235
	if p232.spec_baler.useDropLandOwnershipForBales then
		local v236 = g_farmlandManager:getFarmlandIdAtWorldPosition(p233, p234)
		v235 = g_farmlandManager:getFarmlandOwner(v236)
	else
		v235 = p232:getLastTouchedFarmlandFarmId()
	end
	if v235 == FarmManager.SPECTATOR_FARM_ID then
		v235 = p232:getOwnerFarmId()
	end
	return v235
end
function Baler.getIsRoundBaler(p237)
	return p237.spec_baler.isRoundBaler
end
function Baler.setIsUnloadingBale(p238, p239, p240)
	local v241 = p238.spec_baler
	if v241.hasUnloadingAnimation then
		if p239 then
			if v241.unloadingState ~= Baler.UNLOADING_OPENING then
				if #v241.bales == 0 and (v241.canUnloadUnfinishedBale and p238:getFillUnitFillLevel(v241.fillUnitIndex) > v241.unfinishedBaleThreshold) then
					local v242 = p238:getFillUnitFillType(v241.fillUnitIndex)
					local v243 = p238:getFillUnitFillLevel(v241.fillUnitIndex)
					local v244 = p238:getFillUnitFreeCapacity(v241.fillUnitIndex)
					v241.lastBaleFillLevel = v243
					p238:setFillUnitFillLevelToDisplay(v241.fillUnitIndex, v243)
					p238:addFillUnitFillLevel(p238:getOwnerFarmId(), v241.fillUnitIndex, v244, v242, ToolType.UNDEFINED)
					v241.buffer.unloadingStarted = false
				end
				BalerSetIsUnloadingBaleEvent.sendEvent(p238, p239, p240)
				v241.unloadingState = Baler.UNLOADING_OPENING
				if p238.isClient then
					g_soundManager:playSample(v241.samples.eject)
					g_soundManager:playSample(v241.samples.door)
				end
				local v245 = v241.baleTypes[v241.currentBaleTypeIndex]
				p238:playAnimation(v245.animations.unloading, v245.animations.unloadingSpeed, nil, true)
				return
			end
		elseif v241.unloadingState ~= Baler.UNLOADING_CLOSING and v241.unloadingState ~= Baler.UNLOADING_CLOSED then
			BalerSetIsUnloadingBaleEvent.sendEvent(p238, p239, p240)
			v241.unloadingState = Baler.UNLOADING_CLOSING
			if p238.isClient then
				g_soundManager:playSample(v241.samples.door)
			end
			p238:playAnimation(v241.baleCloseAnimationName, v241.baleCloseAnimationSpeed, nil, true)
			return
		end
	elseif v241.allowsBaleUnloading and p239 then
		BalerSetIsUnloadingBaleEvent.sendEvent(p238, p239, p240)
		v241.isBaleUnloading = true
		v241.balesToUnload = #v241.bales
		if p238.isClient then
			g_soundManager:playSample(v241.samples.unload)
		end
		SpecializationUtil.raiseEvent(p238, "onBalerUnloadingStarted", v241.balesToUnload)
	end
end
function Baler.getIsBaleUnloading(p246)
	return p246.spec_baler.isBaleUnloading
end
function Baler.getTimeFromLevel(p247, p248)
	local v249 = p247.spec_baler
	if v249.currentBaleTypeDefinition == nil then
		return 0
	end
	local v250 = v249.currentBaleTypeDefinition.length + v249.baleAnimSpacing
	return p248 / p247:getFillUnitCapacity(v249.fillUnitIndex) * (v250 / v249.baleAnimLength)
end
function Baler.moveBales(p251, p252)
	for v253 = #p251.spec_baler.bales, 1, -1 do
		p251:moveBale(v253, p252)
	end
end
function Baler.moveBale(p254, p255, p256, p257)
	p254:setBaleTime(p255, p254.spec_baler.bales[p255].time + p256, p257)
end
function Baler.setBaleTime(p258, p259, p260, p261)
	local v262 = p258.spec_baler
	if v262.baleAnimCurve ~= nil then
		local v263 = v262.bales[p259]
		if v263 ~= nil then
			v263.time = p260
			if p258.isServer then
				local v264, v265, v266, v267, v268, v269 = v262.baleAnimCurve:get(v263.time)
				setTranslation(v263.baleJointNode, v264, v265, v266)
				setRotation(v263.baleJointNode, v267, v268, v269)
				if v263.baleJointIndex ~= 0 then
					setJointFrame(v263.baleJointIndex, 0, v263.baleJointNode)
				end
			end
			if v263.time >= 1 then
				p258:dropBale(p259)
			end
			if #v262.bales == 0 then
				v262.isBaleUnloading = false
				if p258.isClient then
					g_soundManager:stopSample(v262.samples.unload)
				end
				SpecializationUtil.raiseEvent(p258, "onBalerUnloadingFinished", v262.balesToUnload)
			end
			if p258.isServer and (p261 == nil or not p261) then
				g_server:broadcastEvent(BalerSetBaleTimeEvent.new(p258, p259, v263.time), nil, nil, p258)
			end
		end
	end
end
function Baler.finishBale(p270)
	local v271 = p270.spec_baler
	if v271.baleTypes ~= nil then
		local v272 = p270:getFillUnitFillType(v271.fillUnitIndex)
		if v271.hasUnloadingAnimation then
			if p270:createBale(v272, p270:getFillUnitCapacity(v271.fillUnitIndex)) then
				local v273 = v271.bales[#v271.bales]
				g_server:broadcastEvent(BalerCreateBaleEvent.new(p270, v272, 0, NetworkUtil.getObjectId(v273.baleObject)), nil, nil, p270)
				return
			end
			Logging.error("Failed to create bale!")
		else
			p270:addFillUnitFillLevel(p270:getOwnerFarmId(), v271.fillUnitIndex, (-1 / 0), v272, ToolType.UNDEFINED)
			v271.buffer.unloadingStarted = false
			for v274, _ in pairs(v271.pickupFillTypes) do
				v271.pickupFillTypes[v274] = 0
			end
			if not p270:createBale(v272, p270:getFillUnitCapacity(v271.fillUnitIndex)) then
				Logging.error("Failed to create bale!")
				return
			end
			local v275 = v271.bales[#v271.bales]
			g_server:broadcastEvent(BalerCreateBaleEvent.new(p270, v272, v275.time), nil, nil, p270)
			if p270:getFillUnitFillLevel(v271.fillUnitIndex) == 0 and v271.preSelectedBaleTypeIndex ~= v271.currentBaleTypeIndex then
				p270:setBaleTypeIndex(v271.preSelectedBaleTypeIndex, true)
				return
			end
		end
	end
end
function Baler.createBale(p276, p277, p278, p279, p280, p281, p282, p283, p284)
	local v285 = p276.spec_baler
	if v285.knotingAnimation ~= nil and not p284 then
		p276:playAnimation(v285.knotingAnimation, v285.knotingAnimationSpeed, nil, true)
	end
	local v286 = false
	local v287 = v285.baleTypes[v285.currentBaleTypeIndex]
	if p280 == nil then
		p276:deleteDummyBale(v285.dummyBale)
	end
	local v288 = {
		["filename"] = p281 or v285.currentBaleXMLFilename,
		["time"] = p280
	}
	if v288.time == nil and v285.baleAnimLength ~= nil then
		v288.time = v287.length * 0.5 / v285.baleAnimLength
	end
	v288.fillType = p277
	v288.fillLevel = p278
	if v285.hasUnloadingAnimation then
		if not p284 then
			p276:updateConsumable(Baler.CONSUMABLE_TYPE_NAME_ROUND, -v287.consumableUsage)
		end
		if p276.isServer then
			local v289 = Bale.new(p276.isServer, p276.isClient)
			local v290, v291, v292 = getWorldTranslation(v287.baleRootNode)
			local v293, v294, v295 = getWorldRotation(v287.baleRootNode)
			if v289:loadFromConfigXML(v288.filename, v290, v291, v292, v293, v294, v295) then
				v289:setFillType(p277)
				v289:setFillLevel(p278)
				v289:setVariationId(p283 or v285.lastBaleVariationId)
				if p282 == nil then
					v289:setOwnerFarmId(p276:getBalerBaleOwnerFarmId(v290, v292), true)
				else
					v289:setOwnerFarmId(p282, true)
				end
				v289:register()
				v289:mountKinematic(p276, v287.baleRootNode, 0, 0, 0, 0, 0, 0)
				v288.baleObject = v289
				v286 = true
			end
		elseif p279 ~= nil then
			local v296 = NetworkUtil.getObject(p279)
			if v296 == nil then
				v285.baleToMount = {
					["baleServerId"] = p279,
					["jointNode"] = v287.baleRootNode,
					["baleInfo"] = v288
				}
				v286 = true
			else
				v288.baleServerId = p279
				v296:mountKinematic(p276, v287.baleRootNode, 0, 0, 0, 0, 0, 0)
				v286 = true
			end
		end
	elseif not p284 then
		p276:updateConsumable(Baler.CONSUMABLE_TYPE_NAME_SQUARE, -v287.consumableUsage)
	end
	if p276.isServer and not v285.hasUnloadingAnimation then
		local v297, v298, v299 = getWorldTranslation(v287.baleRootNode)
		local v300, v301, v302 = getWorldRotation(v287.baleRootNode)
		local v303 = createTransformGroup("BaleJointTG")
		link(v287.baleRootNode, v303)
		if v288.time == nil then
			setTranslation(v303, 0, 0, 0)
			setRotation(v303, 0, 0, 0)
		else
			local v304, v305, v306, v307, v308, v309 = v285.baleAnimCurve:get(v288.time)
			setTranslation(v303, v304, v305, v306)
			setRotation(v303, v307, v308, v309)
			v297, v298, v299 = getWorldTranslation(v303)
			v300, v301, v302 = getWorldRotation(v303)
		end
		local v310 = Bale.new(p276.isServer, p276.isClient)
		if v310:loadFromConfigXML(v288.filename, v297, v298, v299, v300, v301, v302) then
			v310:setFillType(p277)
			v310:setFillLevel(p278)
			v310:setVariationId(p283 or v285.lastBaleVariationId)
			if p282 == nil then
				v310:setOwnerFarmId(p276:getBalerBaleOwnerFarmId(v297, v299), true)
			else
				v310:setOwnerFarmId(p282, true)
			end
			v310:register()
			v310:setCanBeSold(false)
			v310:setNeedsSaving(false)
			local v311 = JointConstructor.new()
			v311:setActors(v287.baleNodeComponent, v310.nodeId)
			v311:setJointTransforms(v303, v310.nodeId)
			for v312 = 1, 3 do
				v311:setRotationLimit(v312 - 1, 0, 0)
				v311:setTranslationLimit(v312 - 1, true, 0, 0)
			end
			v311:setEnableCollision(false)
			local v313 = v311:finalize()
			v288.baleJointNode = v303
			v288.baleJointIndex = v313
			v288.baleObject = v310
			v310.baleJointIndex = v313
			for v314 = 1, #v285.bales do
				local v315 = v285.bales[v314]
				setPairCollision(v315.baleObject.nodeId, v310.nodeId, false)
			end
			if v285.baleAnimEnableCollision then
				v286 = true
			else
				setCollisionFilterMask(v310.nodeId, 0)
				v286 = true
			end
		end
	elseif not (p276.isServer or v285.hasUnloadingAnimation) then
		v286 = true
	end
	if v286 then
		local v316 = v285.bales
		table.insert(v316, v288)
	end
	return v286
end
function Baler.dropBale(p317, p318)
	local v319 = p317.spec_baler
	local v320 = v319.bales[p318]
	if v320.baleObject ~= nil then
		local v321 = g_missionManager:getMissionByUniqueId(v319.workAreaParameters.lastMissionUniqueId)
		if v321 ~= nil and v321.addBale ~= nil then
			v321:addBale(v320.baleObject)
		end
	end
	if p317.isServer then
		local v322 = v320.baleObject
		if v320.baleJointIndex == nil then
			v322:unmountKinematic()
		else
			removeJoint(v320.baleJointIndex)
			delete(v320.baleJointNode)
		end
		if not v319.baleAnimEnableCollision then
			setCollisionFilterMask(v322.nodeId, CollisionPreset.BALE.mask)
		end
		for v323 = 1, #v319.bales do
			if v323 ~= p318 then
				local v324 = v319.bales[v323]
				setPairCollision(v324.baleObject.nodeId, v322.nodeId, true)
			end
		end
		if v319.lastBaleFillLevel ~= nil and #v319.bales == 1 then
			v322:setFillLevel(v319.lastBaleFillLevel)
			v319.lastBaleFillLevel = nil
		end
		v322.baleJointIndex = nil
		v322:setCanBeSold(true)
		v322:setNeedsSaving(true)
		if v322.nodeId ~= nil and v322.nodeId ~= 0 then
			local v325 = v319.baleTypes[v319.currentBaleTypeIndex]
			local v326, v327, v328 = getWorldTranslation(v322.nodeId)
			local v329, v330, v331 = getVelocityAtWorldPos(v325.baleNodeComponent or p317.components[1].node, v326, v327, v328)
			setLinearVelocity(v322.nodeId, v329, v330, v331)
			g_farmManager:updateFarmStats(p317:getBalerBaleOwnerFarmId(v326, v328), "baleCount", 1)
		end
	elseif v319.hasUnloadingAnimation then
		local v332 = NetworkUtil.getObject(v320.baleServerId)
		if v332 ~= nil then
			v332:unmountKinematic()
		end
	end
	table.remove(v319.bales, p318)
	if v319.hasPlatform then
		if not v319.platformReadyToDrop then
			v319.platformReadyToDrop = true
		end
		if v319.hasDynamicMountPlatform then
			v319.platformMountDelay = 5
		end
	end
end
function Baler.updateDummyBale(p333, p334, p335, p336, p337)
	local v338 = p333.spec_baler
	local v339 = p334.baleTypeDef or v338.baleTypes[v338.currentBaleTypeIndex]
	local v340
	if (p334.linkNode or v339.baleNode) == nil or (p336 <= 0 or (p336 >= p337 or p334.currentBale ~= nil and p334.currentBaleFillType == p335)) then
		v340 = false
	else
		if p334.currentBale ~= nil then
			p333:deleteDummyBale(p334)
		end
		p333:createDummyBale(p334, p335)
		v340 = true
	end
	if p334.currentBale ~= nil then
		local v341 = p334.linkNode or v339.scaleNode
		if v341 ~= nil and p337 > 0 then
			local v342 = p336 / p337
			local v343 = v339.isRoundBale and v342 and v342 or 1
			local v344 = p334.scaleComponents or v339.scaleComponents
			local v345, v346
			if v344 == nil then
				v345 = v342
				v346 = 1
			else
				v346 = 1
				v343 = 1
				v345 = 1
				for v347, v348 in ipairs(v344) do
					if v348 > 0 then
						if v347 == 1 then
							v346 = v342 * v348
						elseif v347 == 2 then
							v343 = v342 * v348
						else
							v345 = v342 * v348
						end
					end
				end
			end
			setScale(v341, v346, v343, v345)
		end
	end
	return v340
end
function Baler.deleteDummyBale(_, p349)
	if p349 ~= nil then
		if p349.currentBale ~= nil then
			delete(p349.currentBale)
			p349.currentBale = nil
		end
		if p349.sharedLoadRequestId ~= nil then
			g_i3DManager:releaseSharedI3DFile(p349.sharedLoadRequestId)
			p349.sharedLoadRequestId = nil
		end
	end
end
function Baler.createDummyBale(p350, p351, p352)
	local v353 = p350.spec_baler
	if v353.currentBaleXMLFilename ~= nil then
		local v354 = v353.baleTypes[v353.currentBaleTypeIndex]
		local v355, v356 = Bale.createDummyBale(v353.currentBaleXMLFilename, p352, v354.chamberBaleVariationId)
		local v357 = p351.linkNode or v354.baleNode
		link(v357, v355)
		p351.currentBale = v355
		p351.baleTypeDef = v354
		p351.currentBaleFillType = p352
		p351.sharedLoadRequestId = v356
	end
end
function Baler.getCanUnloadUnfinishedBale(p358)
	local v359 = p358.spec_baler
	local v360 = v359.canUnloadUnfinishedBale
	if v360 then
		v360 = p358:getFillUnitFillLevel(v359.fillUnitIndex) > v359.unfinishedBaleThreshold
	end
	return v360
end
function Baler.setBalerAutomaticDrop(p361, p362, p363)
	local v364 = p361.spec_baler
	if p362 == nil then
		if v364.hasPlatform then
			p362 = not v364.platformAutomaticDrop
		else
			p362 = not v364.automaticDrop
		end
	end
	if v364.hasPlatform then
		v364.platformAutomaticDrop = p362
	else
		v364.automaticDrop = p362
	end
	p361:requestActionEventUpdate()
	BalerAutomaticDropEvent.sendEvent(p361, p362, p363)
end
function Baler.getCanBeTurnedOn(p365, p366)
	if p365.spec_baler.isBaleUnloading then
		return false
	else
		return p366(p365)
	end
end
function Baler.loadSpeedRotatingPartFromXML(p367, p368, p369, p370, p371)
	p369.rotateOnlyIfFillLevelIncreased = p370:getValue(p371 .. "#rotateOnlyIfFillLevelIncreased", false)
	return p368(p367, p369, p370, p371)
end
function Baler.getIsSpeedRotatingPartActive(p372, p373, p374)
	local v375 = p372.spec_baler
	if p374.rotateOnlyIfFillLevelIncreased == nil or (not p374.rotateOnlyIfFillLevelIncreased or v375.lastAreaBiggerZeroTime ~= 0) then
		return p373(p372, p374)
	else
		return false
	end
end
function Baler.getDefaultSpeedLimit()
	return 25
end
function Baler.getIsWorkAreaActive(p376, p377, p378)
	local v379 = p376.spec_baler
	if g_currentMission.slotSystem:getCanAddLimitedObjects(SlotSystem.LIMITED_OBJECT_BALE, 1) or not p376:getIsTurnedOn() then
		if p376:getFillUnitFreeCapacity(v379.buffer.fillUnitIndex or v379.fillUnitIndex) == 0 then
			return false
		elseif p376.allowPickingUp == nil or p376:allowPickingUp() then
			if p376:getConsumableIsAvailable(Baler.CONSUMABLE_TYPE_NAME_ROUND) and p376:getConsumableIsAvailable(Baler.CONSUMABLE_TYPE_NAME_SQUARE) then
				if v379.hasUnloadingAnimation and (not v379.nonStopBaling and (#v379.bales > 0 or v379.unloadingState ~= Baler.UNLOADING_CLOSED)) then
					return false
				else
					return p377(p376, p378)
				end
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end
end
function Baler.getConsumingLoad(p380, p381)
	local v382, v383 = p381(p380)
	local v384 = p380.spec_baler
	return v382 + v384.pickUpLitersBuffer:get(1000) / v384.maxPickupLitersPerSecond, v383 + 1
end
function Baler.getRequiresPower(p385, p386)
	local v387 = p385.spec_baler
	if v387.nonStopBaling then
		if p385:getFillUnitFillLevelPercentage(v387.buffer.fillUnitIndex) > v387.buffer.overloadingStartFillLevelPct then
			return true
		end
		if v387.buffer.unloadingStarted then
			return true
		end
	end
	return v387.unloadingState ~= Baler.UNLOADING_CLOSED and true or (p385:getIsTurnedOn() and true or p386(p385))
end
function Baler.getCanBeSelected(_, _)
	return true
end
function Baler.getIsAttachedTo(p388, p389, p390)
	if p389(p388, p390) then
		return true
	end
	local v391 = p388.spec_baler
	for v392 = 1, #v391.bales do
		if v391.bales[v392].baleObject == p390 then
			return true
		end
	end
	return false
end
function Baler.getAllowDynamicMountFillLevelInfo(_, _)
	return false
end
function Baler.getAlarmTriggerIsActive(p393, p394, p395)
	local v396 = p394(p393, p395)
	if p395.needsBaleLoaded and (p393.spec_baler ~= nil and #p393.spec_baler.bales == 0) then
		return false
	else
		return v396
	end
end
function Baler.loadAlarmTrigger(p397, p398, p399, p400, p401, p402)
	local v403 = p398(p397, p399, p400, p401, p402)
	p401.needsBaleLoaded = p399:getValue(p400 .. "#needsBaleLoaded", false)
	return v403
end
function Baler.getShowConsumableEmptyWarning(p404, p405, p406)
	if p406 ~= Baler.CONSUMABLE_TYPE_NAME_ROUND and p406 ~= Baler.CONSUMABLE_TYPE_NAME_SQUARE then
		return p405(p404, p406)
	end
	local v407 = p404:getIsTurnedOn()
	if v407 then
		v407 = p405(p404, p406)
	end
	return v407
end
function Baler.addToPhysics(p408, p409)
	if not p409(p408) then
		return false
	end
	local v410 = p408.spec_baler
	local v411 = v410.baleTypes[v410.currentBaleTypeIndex]
	for v412, v413 in pairs(v410.bales) do
		local v414 = v413.baleObject
		if v414 ~= nil then
			v413.baleObject:addToPhysics()
			if not v410.hasUnloadingAnimation then
				local v415 = JointConstructor.new()
				v415:setActors(v411.baleNodeComponent, v414.nodeId)
				v415:setJointTransforms(v413.baleJointNode, v414.nodeId)
				for v416 = 1, 3 do
					v415:setRotationLimit(v416 - 1, 0, 0)
					v415:setTranslationLimit(v416 - 1, true, 0, 0)
				end
				v415:setEnableCollision(false)
				v413.baleJointIndex = v415:finalize()
				v413.baleObject = v414
				for v417, v418 in pairs(v410.bales) do
					if v417 ~= v412 then
						setPairCollision(v418.baleObject.nodeId, v414.nodeId, false)
					end
				end
			end
		end
	end
	return true
end
function Baler.removeFromPhysics(p419, p420)
	if not p420(p419) then
		return false
	end
	local v421 = p419.spec_baler
	for _, v422 in pairs(v421.bales) do
		if v422.baleObject ~= nil then
			v422.baleObject:removeFromPhysics()
			if not v421.hasUnloadingAnimation and v422.baleJointIndex ~= nil then
				removeJoint(v422.baleJointIndex)
				v422.baleJointIndex = nil
			end
		end
	end
	return true
end
function Baler.processBalerArea(p423, p424, _)
	local v425 = p423.spec_baler
	local v426, v427, v428, v429, v430, v431, v432 = DensityMapHeightUtil.getLineByArea(p424.start, p424.width, p424.height)
	if p423.isServer then
		v425.fillEffectType = FillType.UNKNOWN
	end
	local v433 = p423:getMissionByWorkArea(p424)
	for v434, _ in pairs(v425.pickupFillTypes) do
		local v435 = -DensityMapHeightUtil.tipToGroundAroundLine(p423, (-1 / 0), v434, v426, v427, v428, v429, v430, v431, v432, nil, nil, false, nil)
		if v435 > 0 then
			if p423.isServer then
				v425.fillEffectType = v434
				if v425.additives.available and not v425.additives.appliedByBufferOverloading then
					local v436 = false
					for v437 = 1, #v425.additives.fillTypes do
						if v434 == v425.additives.fillTypes[v437] then
							v436 = true
							break
						end
					end
					if v436 then
						local v438 = p423:getFillUnitFillLevel(v425.additives.fillUnitIndex)
						if v438 > 0 then
							local v439 = v425.additives.usage * v435
							if v439 > 0 then
								local v440 = v438 / v439
								v435 = v435 * (1 + 0.05 * math.min(v440, 1))
								p423:addFillUnitFillLevel(p423:getOwnerFarmId(), v425.additives.fillUnitIndex, -v439, p423:getFillUnitFillType(v425.additives.fillUnitIndex), ToolType.UNDEFINED)
								v425.additives.isActiveTimer = 250
								v425.additives.isActive = true
								p423:raiseDirtyFlags(v425.dirtyFlag)
								if p423.isClient then
									g_effectManager:setEffectTypeInfo(v425.additiveEffects, FillType.LIQUIDFERTILIZER)
									g_effectManager:startEffects(v425.additiveEffects)
								end
							end
						end
					end
				end
			end
			v425.pickupFillTypes[v434] = v425.pickupFillTypes[v434] + v435
			local v441 = v425.workAreaParameters
			local v442
			if v433 == nil then
				v442 = nil
			else
				v442 = v433:getUniqueId() or nil
			end
			v441.lastMissionUniqueId = v442
			v425.workAreaParameters.lastPickedUpLiters = v425.workAreaParameters.lastPickedUpLiters + v435
			return v435, v435
		end
	end
	return 0, 0
end
function Baler.onRegisterActionEvents(p443, _, p444)
	if p443.isClient then
		local v445 = p443.spec_baler
		p443:clearActionEventsTable(v445.actionEvents)
		if p444 then
			if not (v445.automaticDrop and v445.platformAutomaticDrop) then
				local _, v446 = p443:addPoweredActionEvent(v445.actionEvents, InputAction.IMPLEMENT_EXTRA3, p443, Baler.actionEventUnloading, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v446, GS_PRIO_HIGH)
			end
			if #v445.baleTypes > 1 then
				local _, v447 = p443:addPoweredActionEvent(v445.actionEvents, InputAction.TOGGLE_BALE_TYPES, p443, Baler.actionEventToggleSize, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v447, GS_PRIO_HIGH)
			end
			if v445.toggleableAutomaticDrop then
				local _, v448 = p443:addPoweredActionEvent(v445.actionEvents, InputAction.IMPLEMENT_EXTRA4, p443, Baler.actionEventToggleAutomaticDrop, false, true, false, true, nil)
				local v449 = v445.automaticDrop
				if v445.hasPlatform then
					v449 = v445.platformAutomaticDrop
				end
				g_inputBinding:setActionEventText(v448, v449 and v445.toggleAutomaticDropTextNeg or v445.toggleAutomaticDropTextPos)
				g_inputBinding:setActionEventTextPriority(v448, GS_PRIO_HIGH)
			end
			Baler.updateActionEvents(p443)
		end
	end
end
function Baler.onRegisterExternalActionEvents(p450, p451, p452, _, _)
	local v453 = p450.spec_baler
	if p452 == "balerDrop" then
		p450:registerExternalActionEvent(p451, p452, Baler.externalActionEventUnloadRegister, Baler.externalActionEventUnloadUpdate)
	elseif p452 == "balerAutomaticDrop" then
		if v453.toggleableAutomaticDrop then
			p450:registerExternalActionEvent(p451, p452, Baler.externalActionEventAutomaticUnloadRegister, Baler.externalActionEventAutomaticUnloadUpdate)
			return
		end
	elseif p452 == "balerBaleSize" and #v453.baleTypes > 1 then
		p450:registerExternalActionEvent(p451, p452, Baler.externalActionEventBaleTypeRegister, Baler.externalActionEventBaleTypeUpdate)
	end
end
function Baler.onStartWorkAreaProcessing(p454, _)
	local v455 = p454.spec_baler
	if p454.isServer then
		v455.lastAreaBiggerZero = false
		v455.workAreaParameters.lastPickedUpLiters = 0
	end
end
function Baler.onEndWorkAreaProcessing(p456, _, _)
	local v457 = p456.spec_baler
	if p456.isServer then
		local v458 = FillType.UNKNOWN
		local v459 = 0
		for v460, v461 in pairs(v457.pickupFillTypes) do
			if v459 < v461 then
				v458 = v460
				v459 = v461
			end
		end
		local v462 = v457.workAreaParameters.lastPickedUpLiters
		if v462 > 0 then
			v457.lastAreaBiggerZero = true
			local v463 = v462 * v457.fillScale
			v457.variableSpeedLimit.pickupPerSecond = v457.variableSpeedLimit.pickupPerSecond + v463
			if not v457.hasUnloadingAnimation then
				p456:moveBales((p456:getTimeFromLevel(v463)))
			end
			local v464 = v457.fillUnitIndex
			if v457.nonStopBaling then
				if v457.buffer.fillMainUnitAfterOverload and v457.buffer.unloadingStarted then
					if p456:getFillUnitFreeCapacity(v457.fillUnitIndex) <= 0 then
						v464 = v457.buffer.fillUnitIndex
					end
				else
					v464 = v457.buffer.fillUnitIndex
				end
			end
			if v457.buffer.loadingStateAnimation ~= nil then
				local v465 = p456:getAnimationTime(v457.buffer.loadingStateAnimation)
				if v464 == v457.fillUnitIndex then
					if v465 >= 0.99 then
						p456:playAnimation(v457.buffer.loadingStateAnimation, -v457.buffer.loadingStateAnimationSpeed)
					end
				elseif v465 <= 0.01 then
					p456:playAnimation(v457.buffer.loadingStateAnimation, v457.buffer.loadingStateAnimationSpeed)
				end
			end
			p456:setFillUnitFillType(v464, v458)
			p456:addFillUnitFillLevel(p456:getOwnerFarmId(), v464, v463, v458, ToolType.UNDEFINED)
		end
		if v457.lastAreaBiggerZero ~= v457.lastAreaBiggerZeroSent then
			p456:raiseDirtyFlags(v457.dirtyFlag)
			v457.lastAreaBiggerZeroSent = v457.lastAreaBiggerZero
		end
		if v457.fillEffectType ~= v457.fillEffectTypeSent then
			v457.fillEffectTypeSent = v457.fillEffectType
			p456:raiseDirtyFlags(v457.dirtyFlag)
		end
	end
end
function Baler.actionEventUnloading(p466, _, _, _, _)
	local v467 = p466.spec_baler
	if v467.hasPlatform then
		if p466:getCanUnloadUnfinishedBale() and not v467.platformReadyToDrop then
			p466:handleUnloadingBaleEvent()
		else
			p466:dropBaleFromPlatform(false)
		end
	else
		p466:handleUnloadingBaleEvent()
		return
	end
end
function Baler.actionEventToggleSize(p468, _, _, _, _)
	local v469 = p468.spec_baler
	local v470 = v469.preSelectedBaleTypeIndex + 1
	p468:setBaleTypeIndex(#v469.baleTypes < v470 and 1 or v470)
end
function Baler.actionEventToggleAutomaticDrop(p471, _, _, _, _)
	p471:setBalerAutomaticDrop()
end
function Baler.updateActionEvents(p472)
	local v473 = p472.spec_baler
	local v474 = v473.actionEvents[InputAction.IMPLEMENT_EXTRA3]
	if v474 ~= nil then
		local v475 = false
		if not v473.automaticDrop and (p472:isUnloadingAllowed() and (v473.hasUnloadingAnimation or v473.allowsBaleUnloading)) then
			if v473.unloadingState == Baler.UNLOADING_CLOSED then
				if p472:getCanUnloadUnfinishedBale() then
					g_inputBinding:setActionEventText(v474.actionEventId, v473.texts.unloadUnfinishedBale)
					v475 = true
				end
				if #v473.bales > 0 then
					g_inputBinding:setActionEventText(v474.actionEventId, v473.texts.unloadBaler)
					v475 = true
				end
			elseif v473.unloadingState == Baler.UNLOADING_OPEN and v473.hasUnloadingAnimation then
				g_inputBinding:setActionEventText(v474.actionEventId, v473.texts.closeBack)
				v475 = true
			end
		end
		if v473.platformReadyToDrop then
			g_inputBinding:setActionEventText(v474.actionEventId, v473.texts.unloadBaler)
			v475 = true
		end
		g_inputBinding:setActionEventActive(v474.actionEventId, v475)
	end
	if v473.toggleableAutomaticDrop then
		local v476 = v473.actionEvents[InputAction.IMPLEMENT_EXTRA4]
		if v476 ~= nil then
			local v477 = v473.automaticDrop
			if v473.hasPlatform then
				v477 = v473.platformAutomaticDrop
			end
			g_inputBinding:setActionEventText(v476.actionEventId, v477 and v473.toggleAutomaticDropTextNeg or v473.toggleAutomaticDropTextPos)
		end
	end
	if #v473.baleTypes > 1 then
		local v478 = v473.actionEvents[InputAction.TOGGLE_BALE_TYPES]
		if v478 ~= nil then
			local v479 = v473.baleTypes[v473.preSelectedBaleTypeIndex]
			local v480
			if v473.hasUnloadingAnimation then
				v480 = v479.diameter
			else
				v480 = v479.length
			end
			g_inputBinding:setActionEventText(v478.actionEventId, v473.changeBaleTypeText:format(v480 * 100))
		end
	end
end
function Baler.externalActionEventUnloadRegister(p481, p_u_482)
	local _, v487 = g_inputBinding:registerActionEvent(InputAction.IMPLEMENT_EXTRA3, p481, function(_, p483, p484, p485, p486)
		-- upvalues: (copy) p_u_482
		if not p_u_482.spec_baler.automaticDrop then
			Baler.actionEventUnloading(p_u_482, p483, p484, p485, p486)
		end
	end, false, true, false, true)
	p481.actionEventId = v487
	g_inputBinding:setActionEventTextPriority(p481.actionEventId, GS_PRIO_HIGH)
end
function Baler.externalActionEventUnloadUpdate(p488, p489)
	local v490 = p489.spec_baler
	local v491 = false
	if p489:isUnloadingAllowed() and (v490.hasUnloadingAnimation or v490.allowsBaleUnloading) then
		if v490.unloadingState == Baler.UNLOADING_CLOSED then
			if p489:getCanUnloadUnfinishedBale() then
				g_inputBinding:setActionEventText(p488.actionEventId, v490.texts.unloadUnfinishedBale)
				v491 = true
			end
			if #v490.bales > 0 then
				g_inputBinding:setActionEventText(p488.actionEventId, v490.texts.unloadBaler)
				v491 = true
			end
		elseif v490.unloadingState == Baler.UNLOADING_OPEN and v490.hasUnloadingAnimation then
			g_inputBinding:setActionEventText(p488.actionEventId, v490.texts.closeBack)
			v491 = true
		end
	end
	if v490.platformReadyToDrop then
		g_inputBinding:setActionEventText(p488.actionEventId, v490.texts.unloadBaler)
		v491 = true
	end
	g_inputBinding:setActionEventActive(p488.actionEventId, v491)
end
function Baler.externalActionEventAutomaticUnloadRegister(p492, p_u_493)
	local _, v498 = g_inputBinding:registerActionEvent(InputAction.IMPLEMENT_EXTRA4, p492, function(_, p494, p495, p496, p497)
		-- upvalues: (copy) p_u_493
		Baler.actionEventToggleAutomaticDrop(p_u_493, p494, p495, p496, p497)
	end, false, true, false, true)
	p492.actionEventId = v498
	g_inputBinding:setActionEventTextPriority(p492.actionEventId, GS_PRIO_HIGH)
end
function Baler.externalActionEventAutomaticUnloadUpdate(p499, p500)
	local v501 = p500.spec_baler
	local v502 = v501.automaticDrop
	if v501.hasPlatform then
		v502 = v501.platformAutomaticDrop
	end
	g_inputBinding:setActionEventText(p499.actionEventId, v502 and v501.toggleAutomaticDropTextNeg or v501.toggleAutomaticDropTextPos)
end
function Baler.externalActionEventBaleTypeRegister(p503, p_u_504)
	local _, v509 = g_inputBinding:registerActionEvent(InputAction.TOGGLE_BALE_TYPES, p503, function(_, p505, p506, p507, p508)
		-- upvalues: (copy) p_u_504
		Baler.actionEventToggleSize(p_u_504, p505, p506, p507, p508)
	end, false, true, false, true)
	p503.actionEventId = v509
	g_inputBinding:setActionEventTextPriority(p503.actionEventId, GS_PRIO_HIGH)
end
function Baler.externalActionEventBaleTypeUpdate(p510, p511)
	local v512 = p511.spec_baler
	local v513 = v512.baleTypes[v512.preSelectedBaleTypeIndex]
	local v514
	if v512.hasUnloadingAnimation then
		v514 = v513.diameter
	else
		v514 = v513.length
	end
	g_inputBinding:setActionEventText(p510.actionEventId, v512.changeBaleTypeText:format(v514 * 100))
end
function Baler.loadSpecValueBaleSize(p_u_515, _, _)
	local v_u_516 = {
		["isRoundBaler"] = false,
		["minDiameter"] = (1 / 0),
		["maxDiameter"] = (-1 / 0),
		["minLength"] = (1 / 0),
		["maxLength"] = (-1 / 0)
	}
	p_u_515:iterate(p_u_515:getRootName() .. ".baler.baleTypes.baleType", function(_, p517)
		-- upvalues: (copy) v_u_516, (copy) p_u_515
		v_u_516.isRoundBaler = p_u_515:getValue(p517 .. "#isRoundBale", v_u_516.isRoundBaler)
		local v518 = MathUtil.round(p_u_515:getValue(p517 .. "#diameter", 0), 2)
		local v519 = v_u_516
		local v520 = v_u_516.minDiameter
		v519.minDiameter = math.min(v520, v518)
		local v521 = v_u_516
		local v522 = v_u_516.maxDiameter
		v521.maxDiameter = math.max(v522, v518)
		local v523 = MathUtil.round(p_u_515:getValue(p517 .. "#length", 0), 2)
		local v524 = v_u_516
		local v525 = v_u_516.minLength
		v524.minLength = math.min(v525, v523)
		local v526 = v_u_516
		local v527 = v_u_516.maxLength
		v526.maxLength = math.max(v527, v523)
	end)
	if v_u_516.minDiameter == (1 / 0) and v_u_516.minLength == (1 / 0) then
		return nil
	else
		return v_u_516
	end
end
function Baler.getSpecValueBaleSize(p528, _, _, _, p529, p530, p531)
	local v532 = p531 and p528.specs.balerBaleSizeRound or p528.specs.balerBaleSizeSquare
	if v532 == nil then
		if p529 and p530 then
			return 0, 0, ""
		elseif p529 then
			return 0, ""
		else
			return ""
		end
	else
		local v533 = v532.isRoundBaler and v532.minDiameter or v532.minLength
		local v534 = v532.isRoundBaler and v532.maxDiameter or v532.maxLength
		if p529 == nil or not p529 then
			local v535 = g_i18n:getText("unit_cmShort")
			if v534 == v533 then
				return string.format("%d%s", v533 * 100, v535)
			else
				return string.format("%d%s-%d%s", v533 * 100, v535, v534 * 100, v535)
			end
		elseif p530 == true and v534 ~= v533 then
			return v533 * 100, v534 * 100, g_i18n:getText("unit_cmShort")
		else
			return v533 * 100, g_i18n:getText("unit_cmShort")
		end
	end
end
function Baler.loadSpecValueBaleSizeRound(p536, p537, p538)
	local v539 = Baler.loadSpecValueBaleSize(p536, p537, p538)
	if v539 == nil or not v539.isRoundBaler then
		return nil
	else
		return v539
	end
end
function Baler.loadSpecValueBaleSizeSquare(p540, p541, p542)
	local v543 = Baler.loadSpecValueBaleSize(p540, p541, p542)
	if v543 == nil or v543.isRoundBaler then
		return nil
	else
		return v543
	end
end
function Baler.getSpecValueBaleSizeRound(p544, p545, p546, p547, p548, p549)
	if p544.specs.balerBaleSizeRound == nil or not p544.specs.balerBaleSizeRound.isRoundBaler then
		return nil
	else
		return Baler.getSpecValueBaleSize(p544, p545, p546, p547, p548, p549, true)
	end
end
function Baler.getSpecValueBaleSizeSquare(p550, p551, p552, p553, p554, p555)
	if p550.specs.balerBaleSizeSquare == nil or p550.specs.balerBaleSizeSquare.isRoundBaler then
		return nil
	else
		return Baler.getSpecValueBaleSize(p550, p551, p552, p553, p554, p555, false)
	end
end

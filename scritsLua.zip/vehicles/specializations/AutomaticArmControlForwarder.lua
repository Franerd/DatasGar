AutomaticArmControlForwarder = {}
AutomaticArmControlForwarder.STATE_NONE = 0
AutomaticArmControlForwarder.STATE_MOVE_UP = 1
AutomaticArmControlForwarder.STATE_ALIGN_X = 2
AutomaticArmControlForwarder.STATE_ALIGN_Z = 3
AutomaticArmControlForwarder.STATE_ALIGN_Y = 4
AutomaticArmControlForwarder.STATE_FINISHED = 5
AutomaticArmControlForwarder.NEXT_STATE = {
	[AutomaticArmControlForwarder.STATE_MOVE_UP] = AutomaticArmControlForwarder.STATE_ALIGN_X,
	[AutomaticArmControlForwarder.STATE_ALIGN_X] = AutomaticArmControlForwarder.STATE_ALIGN_Z,
	[AutomaticArmControlForwarder.STATE_ALIGN_Z] = AutomaticArmControlForwarder.STATE_ALIGN_Y,
	[AutomaticArmControlForwarder.STATE_ALIGN_Y] = AutomaticArmControlForwarder.STATE_FINISHED
}
function AutomaticArmControlForwarder.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Cylindered, p1)
end
function AutomaticArmControlForwarder.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("automaticArmControlForwarder", g_i18n:getText("shop_configuration"), "automaticArmControlForwarder", VehicleConfigurationItem)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("AutomaticArmControlForwarder")
	AutomaticArmControlForwarder.registerXMLPaths(v2, "vehicle.automaticArmControlForwarder")
	AutomaticArmControlForwarder.registerXMLPaths(v2, "vehicle.automaticArmControlForwarder.automaticArmControlForwarderConfigurations.automaticArmControlForwarderConfiguration(?)")
	v2:setXMLSpecializationType()
end
function AutomaticArmControlForwarder.registerXMLPaths(p3, p4)
	p3:register(XMLValueType.BOOL, p4 .. "#requiresEasyArmControl", "If \'true\' then it is only available if easy arm control is enabled", true)
	p3:register(XMLValueType.FLOAT, p4 .. "#foldMinLimit", "Min. folding time to activate the automatic control", 0)
	p3:register(XMLValueType.FLOAT, p4 .. "#foldMaxLimit", "Max. folding time to activate the automatic control", 1)
	p3:register(XMLValueType.NODE_INDEX, p4 .. "#rootNode", "Root reference node (placed inside the X alignment arm with Z facing in working direction)")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".treeTrigger(?)#node", "Tree detection trigger")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".xAlignment#movingToolNode", "Moving tool to do alignment on X axis (most likely Y-Rot tool)")
	p3:register(XMLValueType.FLOAT, p4 .. ".xAlignment#speedScale", "Speed scale used to control the moving tool", 1)
	p3:register(XMLValueType.FLOAT, p4 .. ".xAlignment#offset", "X alignment offset from tree detection node", "Automatically calculated with the difference on X between xAlignment and zAlignment node")
	p3:register(XMLValueType.ANGLE, p4 .. ".xAlignment#threshold", "X alignment angle threshold (if angle to target is below this value the Y and Z alignment will start)", 1)
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".zAlignment#movingToolNode", "Moving tool to do alignment on Z axis (EasyArmControl Z Target)")
	p3:register(XMLValueType.FLOAT, p4 .. ".zAlignment#speedScale", "Speed scale used to control the moving tool", 1)
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".zAlignment#referenceNode", "Reference node which is tried to be moved right in front of the tree")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".yAlignment#movingToolNode", "Moving tool to do alignment on Y axis (EasyArmControl Y Target)")
	p3:register(XMLValueType.FLOAT, p4 .. ".yAlignment#speedScale", "Speed scale used to control the moving tool", 1)
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".yAlignment#referenceNode", "Reference node which is tried to be moved right in front of the tree")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".yAlignment.moveUp#referenceNode", "Reference node for the height before X alignment is performed")
	p3:register(XMLValueType.FLOAT, p4 .. ".yAlignment.moveUp#maxOffset", "Max. X offset from the reference node to move up the crane before rotating it out (also the min. x offset when moving the crane in)")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".xToolAlignment#movingToolNode", "Moving tool to do alignment on X axis (most likely Y-Rot tool)")
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".xToolAlignment#referenceNode", "Reference node for angle offset calculation (needs to be inside the moving tool)")
	p3:register(XMLValueType.FLOAT, p4 .. ".xToolAlignment#speedScale", "Speed scale used to control the moving tool", 1)
	p3:register(XMLValueType.FLOAT, p4 .. ".xToolAlignment#offset", "X alignment offset from tree detection node", "Automatically calculated with the difference on X between xAlignment and zAlignment node")
	p3:register(XMLValueType.ANGLE, p4 .. ".xToolAlignment#threshold", "X alignment angle threshold (if angle to target is below this value the Y and Z alignment will start)", 1)
	TargetTreeMarker.registerXMLPaths(p3, p4 .. ".treeMarker")
	p3:register(XMLValueType.COLOR, p4 .. ".treeMarker#targetColor", "Color of tree is available to alignment, but not ready for cut yet", "2 2 0")
	p3:register(XMLValueType.COLOR, p4 .. ".treeMarker#tooThickColor", "Color of tree is too thick to be cut", "2 0 0")
end
function AutomaticArmControlForwarder.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "getIsAutoTreeAlignmentAllowed", AutomaticArmControlForwarder.getIsAutoTreeAlignmentAllowed)
	SpecializationUtil.registerFunction(p5, "setTreeArmAlignmentInput", AutomaticArmControlForwarder.setTreeArmAlignmentInput)
	SpecializationUtil.registerFunction(p5, "doTreeArmAlignment", AutomaticArmControlForwarder.doTreeArmAlignment)
	SpecializationUtil.registerFunction(p5, "resetAutomaticAlignment", AutomaticArmControlForwarder.resetAutomaticAlignment)
	SpecializationUtil.registerFunction(p5, "getIsAutomaticAlignmentActive", AutomaticArmControlForwarder.getIsAutomaticAlignmentActive)
	SpecializationUtil.registerFunction(p5, "getIsAutomaticAlignmentFinished", AutomaticArmControlForwarder.getIsAutomaticAlignmentFinished)
	SpecializationUtil.registerFunction(p5, "getAutomaticAlignmentTargetTree", AutomaticArmControlForwarder.getAutomaticAlignmentTargetTree)
	SpecializationUtil.registerFunction(p5, "getAutomaticAlignmentAvailableTargetTree", AutomaticArmControlForwarder.getAutomaticAlignmentAvailableTargetTree)
	SpecializationUtil.registerFunction(p5, "getAutomaticAlignmentCurrentTarget", AutomaticArmControlForwarder.getAutomaticAlignmentCurrentTarget)
	SpecializationUtil.registerFunction(p5, "getBestTreeToAutoAlign", AutomaticArmControlForwarder.getBestTreeToAutoAlign)
	SpecializationUtil.registerFunction(p5, "onTreeAutoTriggerCallback", AutomaticArmControlForwarder.onTreeAutoTriggerCallback)
end
function AutomaticArmControlForwarder.registerOverwrittenFunctions(_) end
function AutomaticArmControlForwarder.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", AutomaticArmControlForwarder)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", AutomaticArmControlForwarder)
	SpecializationUtil.registerEventListener(p6, "onDelete", AutomaticArmControlForwarder)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", AutomaticArmControlForwarder)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", AutomaticArmControlForwarder)
	SpecializationUtil.registerEventListener(p6, "onUpdate", AutomaticArmControlForwarder)
	SpecializationUtil.registerEventListener(p6, "onAutoLoadForwaderMountedTree", AutomaticArmControlForwarder)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", AutomaticArmControlForwarder)
end
function AutomaticArmControlForwarder.onLoad(p_u_7, _)
	local v_u_8 = p_u_7.spec_automaticArmControlForwarder
	local v9 = Utils.getNoNil(p_u_7.configurations.automaticArmControlForwarder, 1)
	local v10 = string.format("vehicle.automaticArmControlForwarder.automaticArmControlForwarderConfigurations.automaticArmControlForwarderConfiguration(%d)", v9 - 1)
	local v11 = not p_u_7.xmlFile:hasProperty(v10) and "vehicle.automaticArmControlForwarder" or v10
	v_u_8.xAlignment = {}
	v_u_8.zAlignment = {}
	v_u_8.yAlignment = {}
	v_u_8.xToolAlignment = {}
	v_u_8.rootNode = p_u_7.xmlFile:getValue(v11 .. "#rootNode", nil, p_u_7.components, p_u_7.i3dMappings)
	if v_u_8.rootNode == nil then
		SpecializationUtil.removeEventListener(p_u_7, "onDelete", AutomaticArmControlForwarder)
		SpecializationUtil.removeEventListener(p_u_7, "onUpdate", AutomaticArmControlForwarder)
		SpecializationUtil.removeEventListener(p_u_7, "onRegisterActionEvents", AutomaticArmControlForwarder)
	else
		v_u_8.treeTriggers = {}
		p_u_7.xmlFile:iterate(v11 .. ".treeTrigger", function(_, p12)
			-- upvalues: (copy) p_u_7, (copy) v_u_8
			local v13 = p_u_7.xmlFile:getValue(p12 .. "#node", nil, p_u_7.components, p_u_7.i3dMappings)
			if v13 ~= nil then
				addTrigger(v13, "onTreeAutoTriggerCallback", p_u_7)
				local v14 = v_u_8.treeTriggers
				table.insert(v14, v13)
			end
		end)
		v_u_8.foundTrees = {}
		v_u_8.foundValidTargetServer = false
		v_u_8.lastFoundValidTarget = false
		v_u_8.lastTargetRadius = 1
		v_u_8.lastTargetTrans = { 0, 0, 0 }
		v_u_8.lastTargetDirection = { 0, 0, 1 }
		v_u_8.lastTreeId = nil
		v_u_8.state = AutomaticArmControlForwarder.STATE_NONE
		v_u_8.xAlignment = {}
		v_u_8.xAlignment.movingToolNode = p_u_7.xmlFile:getValue(v11 .. ".xAlignment#movingToolNode", nil, p_u_7.components, p_u_7.i3dMappings)
		v_u_8.xAlignment.speedScale = p_u_7.xmlFile:getValue(v11 .. ".xAlignment#speedScale", 1)
		v_u_8.xAlignment.offset = p_u_7.xmlFile:getValue(v11 .. ".xAlignment#offset")
		v_u_8.xAlignment.threshold = p_u_7.xmlFile:getValue(v11 .. ".xAlignment#threshold", 1)
		v_u_8.zAlignment = {}
		v_u_8.zAlignment.movingToolNode = p_u_7.xmlFile:getValue(v11 .. ".zAlignment#movingToolNode", nil, p_u_7.components, p_u_7.i3dMappings)
		v_u_8.zAlignment.speedScale = p_u_7.xmlFile:getValue(v11 .. ".zAlignment#speedScale", 1)
		v_u_8.zAlignment.referenceNode = p_u_7.xmlFile:getValue(v11 .. ".zAlignment#referenceNode", nil, p_u_7.components, p_u_7.i3dMappings)
		v_u_8.yAlignment = {}
		v_u_8.yAlignment.movingToolNode = p_u_7.xmlFile:getValue(v11 .. ".yAlignment#movingToolNode", nil, p_u_7.components, p_u_7.i3dMappings)
		v_u_8.yAlignment.speedScale = p_u_7.xmlFile:getValue(v11 .. ".yAlignment#speedScale", 1)
		v_u_8.yAlignment.referenceNode = p_u_7.xmlFile:getValue(v11 .. ".yAlignment#referenceNode", nil, p_u_7.components, p_u_7.i3dMappings)
		v_u_8.yAlignment.upReferenceNode = p_u_7.xmlFile:getValue(v11 .. ".yAlignment.moveUp#referenceNode", nil, p_u_7.components, p_u_7.i3dMappings)
		v_u_8.yAlignment.upMaxOffset = p_u_7.xmlFile:getValue(v11 .. ".yAlignment.moveUp#maxOffset", 2)
		v_u_8.xToolAlignment = {}
		v_u_8.xToolAlignment.movingToolNode = p_u_7.xmlFile:getValue(v11 .. ".xToolAlignment#movingToolNode", nil, p_u_7.components, p_u_7.i3dMappings)
		v_u_8.xToolAlignment.referenceNode = p_u_7.xmlFile:getValue(v11 .. ".xToolAlignment#referenceNode", nil, p_u_7.components, p_u_7.i3dMappings)
		v_u_8.xToolAlignment.speedScale = p_u_7.xmlFile:getValue(v11 .. ".xToolAlignment#speedScale", 1)
		v_u_8.xToolAlignment.offset = p_u_7.xmlFile:getValue(v11 .. ".xToolAlignment#offset")
		v_u_8.xToolAlignment.threshold = p_u_7.xmlFile:getValue(v11 .. ".xToolAlignment#threshold", 1)
		v_u_8.treeMarker = TargetTreeMarker.new(p_u_7, p_u_7.rootNode)
		v_u_8.treeMarker:loadFromXML(p_u_7.xmlFile, v11 .. ".treeMarker", p_u_7.baseDirectory)
		v_u_8.treeMarker.cutColor = { v_u_8.treeMarker.color[1], v_u_8.treeMarker.color[2], v_u_8.treeMarker.color[3] }
		v_u_8.treeMarker.targetColor = p_u_7.xmlFile:getValue(v11 .. ".treeMarker#targetColor", "2 2 0", true)
		v_u_8.treeMarker.tooThickColor = p_u_7.xmlFile:getValue(v11 .. ".treeMarker#tooThickColor", "2 0 0", true)
		v_u_8.requiresEasyArmControl = p_u_7.xmlFile:getValue(v11 .. "#requiresEasyArmControl", true)
		v_u_8.foldMinLimit = p_u_7.xmlFile:getValue(v11 .. "#foldMinLimit", 0)
		v_u_8.foldMaxLimit = p_u_7.xmlFile:getValue(v11 .. "#foldMaxLimit", 1)
		if v_u_8.xAlignment.offset == nil and (v_u_8.yAlignment.referenceNode ~= nil and v_u_8.xAlignment.movingToolNode ~= nil) then
			local v15, _, _ = localToLocal(v_u_8.yAlignment.referenceNode, v_u_8.xAlignment.movingToolNode, 0, 0, 0)
			v_u_8.xAlignment.offset = -v15
		end
		v_u_8.controlInputLastValue = 0
		v_u_8.controlInputTimer = 0
		v_u_8.dirtyFlag = p_u_7:getNextDirtyFlag()
		if Platform.gameplay.automaticVehicleControl then
			SpecializationUtil.removeEventListener(p_u_7, "onRegisterActionEvents", AutomaticArmControlForwarder)
			return
		end
	end
end
function AutomaticArmControlForwarder.onPostLoad(p16, _)
	local v17 = p16.spec_automaticArmControlForwarder
	if v17.xAlignment.movingToolNode ~= nil then
		v17.xAlignment.movingTool = p16:getMovingToolByNode(v17.xAlignment.movingToolNode)
	end
	if v17.zAlignment.movingToolNode ~= nil then
		v17.zAlignment.movingTool = p16:getMovingToolByNode(v17.zAlignment.movingToolNode)
	end
	if v17.yAlignment.movingToolNode ~= nil then
		v17.yAlignment.movingTool = p16:getMovingToolByNode(v17.yAlignment.movingToolNode)
	end
	if v17.xToolAlignment.movingToolNode ~= nil then
		v17.xToolAlignment.movingTool = p16:getMovingToolByNode(v17.xToolAlignment.movingToolNode)
	end
end
function AutomaticArmControlForwarder.onDelete(p18)
	local v19 = p18.spec_automaticArmControlForwarder
	if v19.treeMarker ~= nil then
		v19.treeMarker:delete()
	end
	if v19.treeTriggers ~= nil then
		for v20 = 1, #v19.treeTriggers do
			removeTrigger(v19.treeTriggers[v20])
		end
		v19.treeTriggers = nil
	end
end
function AutomaticArmControlForwarder.onReadUpdateStream(p21, p22, _, p23)
	local v24 = p21.spec_automaticArmControlForwarder
	if v24.rootNode ~= nil then
		if p23:getIsServer() then
			if streamReadBool(p22) then
				v24.foundValidTargetServer = streamReadBool(p22)
			end
		elseif streamReadBool(p22) then
			v24.controlInputLastValue = streamReadBool(p22) and 1 or 0
			v24.controlInputTimer = 250
			return
		end
	end
end
function AutomaticArmControlForwarder.onWriteUpdateStream(p25, p26, p27, p28)
	local v29 = p25.spec_automaticArmControlForwarder
	if v29.rootNode ~= nil then
		if p27:getIsServer() then
			if streamWriteBool(p26, bitAND(p28, v29.dirtyFlag) ~= 0) then
				streamWriteBool(p26, v29.controlInputLastValue ~= 0)
				return
			end
		elseif streamWriteBool(p26, bitAND(p28, v29.dirtyFlag) ~= 0) then
			streamWriteBool(p26, v29.foundValidTargetServer)
		end
	end
end
function AutomaticArmControlForwarder.onUpdate(p30, p31, _, p32, _)
	local v33 = p30.spec_automaticArmControlForwarder
	local v34 = false
	if p30:getIsAutoTreeAlignmentAllowed() then
		local v35 = v33.lastTreeId
		if v33.state == AutomaticArmControlForwarder.STATE_NONE or v33.state == AutomaticArmControlForwarder.STATE_FINISHED then
			v35 = p30:getBestTreeToAutoAlign(v33.rootNode, v33.foundTrees)
		elseif v33.foundTrees[v35] == nil then
			v35 = nil
		end
		if v35 == nil or not entityExists(v35) then
			v33.lastTreeId = nil
		else
			local v36, v37, v38, v39, v40, v41, v42
			if g_currentMission:getNodeObject(v35) == nil then
				local v43, v44, v45 = getWorldTranslation(v35)
				v36, v37, v38, v39, v40, v41, v42 = SplitShapeUtil.getTreeOffsetPosition(v35, v43, v44, v45, 3)
			else
				v36, v37, v38 = getWorldTranslation(v35)
				v39, v40, v41 = localDirectionToWorld(v35, 0, 0, 1)
				v42 = getUserAttribute(v35, "logRadius") or 0.5
			end
			if v36 == nil then
				v33.lastTreeId = nil
			else
				v33.lastTreeId = v35
				v33.lastTargetRadius = v42
				local v46 = v33.lastTargetTrans
				local v47 = v33.lastTargetTrans
				local v48 = v33.lastTargetTrans
				v46[1] = v36
				v47[2] = v37
				v48[3] = v38
				local v49 = v33.lastTargetDirection
				local v50 = v33.lastTargetDirection
				local v51 = v33.lastTargetDirection
				v49[1] = v39
				v50[2] = v40
				v51[3] = v41
				v34 = true
			end
		end
	else
		v33.lastTreeId = nil
	end
	if p30.isClient then
		local v52 = v33.foundValidTargetServer
		if v52 then
			if not v34 then
				p32 = v34
			end
		else
			p32 = v52
		end
		v33.treeMarker:setIsActive(p32)
		if p32 then
			v33.treeMarker:setPosition(v33.lastTargetTrans[1], v33.lastTargetTrans[2], v33.lastTargetTrans[3], v33.lastTargetDirection[1], v33.lastTargetDirection[2], v33.lastTargetDirection[3], v33.lastTargetRadius + 0.005)
		end
		AutomaticArmControlForwarder.updateActionEvents(p30, p32)
	end
	if p30.isServer then
		if v34 ~= v33.lastFoundValidTarget then
			v33.foundValidTargetServer = v34
			v33.lastFoundValidTarget = v34
			p30:raiseDirtyFlags(v33.dirtyFlag)
			v33.state = AutomaticArmControlForwarder.STATE_NONE
		end
		if v33.controlInputTimer > 0 then
			v33.controlInputTimer = v33.controlInputTimer - p31
			if v33.controlInputTimer <= 0 then
				v33.controlInputLastValue = 0
				v33.controlInputTimer = 0
			end
			p30:setTreeArmAlignmentInput(v33.controlInputLastValue)
		end
	end
end
function AutomaticArmControlForwarder.onAutoLoadForwaderMountedTree(p53, p54)
	p53.spec_automaticArmControlForwarder.foundTrees[p54] = nil
end
function AutomaticArmControlForwarder.onRegisterActionEvents(p55, _, p56)
	if p55.isClient then
		local v57 = p55.spec_automaticArmControlForwarder
		p55:clearActionEventsTable(v57.actionEvents)
		if p56 then
			local _, v58 = p55:addPoweredActionEvent(v57.actionEvents, InputAction.TREE_AUTOMATIC_ALIGN, p55, AutomaticArmControlForwarder.actionEvent, true, false, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v58, GS_PRIO_VERY_HIGH)
			AutomaticArmControlForwarder.updateActionEvents(p55, false)
		end
	end
end
function AutomaticArmControlForwarder.actionEvent(p59, _, p60, _, _)
	p59:setTreeArmAlignmentInput(p60)
end
function AutomaticArmControlForwarder.updateActionEvents(p61, p62)
	local v63 = p61.spec_automaticArmControlForwarder.actionEvents[InputAction.TREE_AUTOMATIC_ALIGN]
	if v63 ~= nil then
		g_inputBinding:setActionEventActive(v63.actionEventId, p62)
	end
end
function AutomaticArmControlForwarder.getIsAutoTreeAlignmentAllowed(p64)
	local v65 = p64.spec_automaticArmControlForwarder
	if p64.getIsControlled ~= nil and not p64:getIsControlled() then
		return false
	end
	if v65.requiresEasyArmControl and (p64.spec_cylindered.easyArmControl == nil or not p64.spec_cylindered.easyArmControl.state) then
		return false
	end
	if p64.getFoldAnimTime ~= nil then
		local v66 = p64:getFoldAnimTime()
		if v66 < v65.foldMinLimit or v65.foldMaxLimit < v66 then
			return false
		end
	end
	return true
end
function AutomaticArmControlForwarder.setTreeArmAlignmentInput(p67, p68)
	local v69 = p67.spec_automaticArmControlForwarder
	if p67.isServer then
		if p68 > 0 and (v69.state ~= AutomaticArmControlForwarder.STATE_FINISHED and v69.foundValidTargetServer) then
			p67:doTreeArmAlignment(v69.lastTargetTrans[1], v69.lastTargetTrans[2], v69.lastTargetTrans[3], v69.lastTargetDirection[1], v69.lastTargetDirection[2], v69.lastTargetDirection[3], 1)
			return
		end
		if p68 == 0 then
			v69.state = AutomaticArmControlForwarder.STATE_NONE
			return
		end
	else
		v69.controlInputLastValue = p68
		if p68 > 0 then
			p67:raiseDirtyFlags(v69.dirtyFlag)
		end
	end
end
function AutomaticArmControlForwarder.doTreeArmAlignment(p70, p71, p72, p73, p74, p75, p76, p77, p78)
	local v79 = p70.spec_automaticArmControlForwarder
	if v79.state == AutomaticArmControlForwarder.STATE_NONE then
		if p78 == true then
			v79.state = AutomaticArmControlForwarder.STATE_MOVE_UP
		elseif v79.yAlignment.referenceNode == nil or v79.yAlignment.upReferenceNode == nil then
			v79.state = AutomaticArmControlForwarder.STATE_ALIGN_X
		else
			local v80, _, _ = localToLocal(v79.yAlignment.referenceNode, v79.yAlignment.upReferenceNode, 0, 0, 0)
			if p77 == 1 and math.abs(v80) < v79.yAlignment.upMaxOffset or p77 == -1 and math.abs(v80) > v79.yAlignment.upMaxOffset then
				v79.state = AutomaticArmControlForwarder.STATE_MOVE_UP
			else
				v79.state = AutomaticArmControlForwarder.STATE_ALIGN_X
			end
		end
	end
	if v79.xAlignment.movingTool ~= nil and v79.state == AutomaticArmControlForwarder.STATE_ALIGN_X then
		local _, v81 = AutomaticArmControlForwarder.movingToolXAlignment(p70, v79.xAlignment.movingTool, p71, p72, p73, v79.xAlignment.referenceNode, v79.xAlignment.threshold, v79.xAlignment.speedScale, v79.xAlignment.offset)
		if v79.xToolAlignment.movingTool == nil then
			if v81 then
				v79.state = AutomaticArmControlForwarder.NEXT_STATE[v79.state]
			end
		else
			local v82, v83, v84 = getWorldTranslation(v79.xToolAlignment.referenceNode or v79.xToolAlignment.movingTool.node)
			local v85 = v82 + p74
			local v86 = v83 + p75
			local v87 = v84 + p76
			local _, v88 = AutomaticArmControlForwarder.movingToolXAlignment(p70, v79.xToolAlignment.movingTool, v85, v86, v87, v79.xToolAlignment.referenceNode, v79.xToolAlignment.threshold, v79.xToolAlignment.speedScale, v79.xToolAlignment.offset, true)
			if v81 and v88 then
				v79.state = AutomaticArmControlForwarder.NEXT_STATE[v79.state]
			end
		end
	end
	if v79.zAlignment.movingTool ~= nil and v79.zAlignment.referenceNode ~= nil then
		local _, _, v89 = worldToLocal(v79.rootNode, p71, p72, p73)
		local _, _, v90 = localToLocal(v79.zAlignment.referenceNode, v79.rootNode, 0, 0, 0)
		local v91
		if v79.state == AutomaticArmControlForwarder.STATE_ALIGN_Z then
			v91 = v90 - v89
			if math.abs(v91) < 0.03 then
				v79.state = AutomaticArmControlForwarder.NEXT_STATE[v79.state]
			end
		else
			v91 = 0
		end
		if math.abs(v91) > 0.03 then
			v79.zAlignment.movingTool.externalMove = -(v91 + 0.5 * math.sign(v91)) * v79.zAlignment.speedScale
		else
			v79.zAlignment.movingTool.externalMove = 0
		end
	end
	if v79.yAlignment.movingTool ~= nil and (v79.yAlignment.referenceNode ~= nil and (v79.state == AutomaticArmControlForwarder.STATE_ALIGN_Y or v79.state == AutomaticArmControlForwarder.STATE_MOVE_UP)) then
		if v79.state == AutomaticArmControlForwarder.STATE_MOVE_UP then
			local v92, v93
			v92, p72, v93 = getWorldTranslation(v79.yAlignment.upReferenceNode)
		end
		local _, v94, _ = getWorldTranslation(v79.yAlignment.referenceNode)
		local v95 = p72 - v94
		if math.abs(v95) > 0.03 then
			v79.yAlignment.movingTool.externalMove = (v95 + 0.5 * math.sign(v95)) * v79.yAlignment.speedScale
			return
		end
		v79.yAlignment.movingTool.externalMove = 0
		v79.state = AutomaticArmControlForwarder.NEXT_STATE[v79.state]
	end
end
function AutomaticArmControlForwarder.movingToolXAlignment(p96, p97, p98, p99, p100, p101, p102, p103, _, p104)
	local v105, _, v106 = worldToLocal(p101 or p97.node, p98, p99, p100)
	local v107, v108 = MathUtil.vector2Normalize(v105, v106)
	local v109 = MathUtil.getYRotationFromDirection(v107, v108) * p103
	if p104 == true then
		if v109 > 1.5707963267948966 then
			v109 = v109 - 3.141592653589793
		elseif v109 < -1.5707963267948966 then
			v109 = v109 + 3.141592653589793
		end
	end
	local v110 = p97.curRot[p97.rotationAxis]
	local v111 = AutomaticArmControlForwarder.calculateMovingToolTargetMove(p96, p97, v110 + v109)
	if v111 == 0 then
		if math.abs(v109) < p102 then
			return v111, true
		end
	else
		p97.externalMove = v111
	end
	return v111, false
end
function AutomaticArmControlForwarder.calculateMovingToolTargetMove(p112, p113, p114)
	local v115 = p113.lastRotSpeed / p113.rotAcceleration
	local v116 = p113.lastRotSpeed
	local v117 = p113.curRot[p113.rotationAxis]
	local v118 = -p113.rotAcceleration * math.sign(v115)
	local v119 = MathUtil.round(v115 / g_currentDt) * g_currentDt
	for _ = 1, math.abs(v119) do
		v116 = v116 + v118
		v117 = v117 + v116
	end
	local v120 = 0.001
	local v121, v122
	if p113.rotMin == nil or p113.rotMax == nil then
		local v123 = p113.curRot[p113.rotationAxis]
		v121 = MathUtil.normalizeRotationForShortestPath(v123, p114)
		v122 = MathUtil.normalizeRotationForShortestPath(v117, p114)
		v120 = 0.0001
	else
		v121 = Cylindered.getMovingToolState(p112, p113)
		v122 = MathUtil.inverseLerp(p113.rotMin, p113.rotMax, v117)
		p114 = MathUtil.inverseLerp(p113.rotMin, p113.rotMax, p114)
	end
	local v124
	if p114 < v121 then
		local v125 = p113.rotSpeed
		v124 = -math.sign(v125)
		if v122 < p114 then
			return 0
		end
	else
		local v126 = p113.rotSpeed
		v124 = math.sign(v126)
		if p114 < v122 then
			return 0
		end
	end
	local v127 = p114 - v121
	return math.abs(v127) < v120 and 0 or v124
end
function AutomaticArmControlForwarder.resetAutomaticAlignment(p128)
	p128.spec_automaticArmControlForwarder.state = AutomaticArmControlForwarder.STATE_NONE
end
function AutomaticArmControlForwarder.getIsAutomaticAlignmentActive(p129)
	local v130 = p129.spec_automaticArmControlForwarder
	local v131
	if v130.state == AutomaticArmControlForwarder.STATE_NONE then
		v131 = false
	else
		v131 = v130.state ~= AutomaticArmControlForwarder.STATE_FINISHED
	end
	return v131
end
function AutomaticArmControlForwarder.getIsAutomaticAlignmentFinished(p132)
	return p132.spec_automaticArmControlForwarder.state == AutomaticArmControlForwarder.STATE_FINISHED
end
function AutomaticArmControlForwarder.getAutomaticAlignmentTargetTree(p133)
	return p133.spec_automaticArmControlForwarder.lastTreeId
end
function AutomaticArmControlForwarder.getAutomaticAlignmentAvailableTargetTree(p134)
	local v135 = p134.spec_automaticArmControlForwarder
	return p134:getBestTreeToAutoAlign(v135.rootNode, v135.foundTrees)
end
function AutomaticArmControlForwarder.getAutomaticAlignmentCurrentTarget(p136)
	local v137 = p136.spec_automaticArmControlForwarder
	if v137.lastFoundValidTarget then
		return v137.lastTargetTrans[1], v137.lastTargetTrans[2], v137.lastTargetTrans[3], v137.lastTargetDirection[1], v137.lastTargetDirection[2], v137.lastTargetDirection[3]
	else
		return nil, nil, nil, nil, nil, nil
	end
end
function AutomaticArmControlForwarder.getBestTreeToAutoAlign(_, p138, p139)
	local v140 = (1 / 0)
	local v141 = nil
	for v142, v143 in pairs(p139) do
		if v143 and entityExists(v142) then
			local v144 = g_currentMission:getNodeObject(v142)
			if v144 == nil or v144.dynamicMountType == MountableObject.MOUNT_TYPE_NONE then
				local v145 = calcDistanceFrom(p138, v142)
				local v146, v147, v148 = localToLocal(v142, p138, 0, 0, 0)
				local v149, v150 = MathUtil.vector2Normalize(v146, v148)
				local v151 = MathUtil.getYRotationFromDirection(v149, v150)
				local v152 = math.abs(v151)
				local v153 = math.deg(v152) + v145 * 2 - v147 * 10
				if v153 < v140 then
					v141 = v142
					v140 = v153
				end
			end
		end
	end
	return v141
end
function AutomaticArmControlForwarder.onTreeAutoTriggerCallback(p154, _, p155, p156, p157, _, _)
	if getHasClassId(p155, ClassIds.MESH_SPLIT_SHAPE) then
		local v158 = p154.spec_automaticArmControlForwarder
		if p156 then
			v158.foundTrees[p155] = true
			return
		end
		if p157 then
			v158.foundTrees[p155] = nil
		end
	end
end
function AutomaticArmControlForwarder.drawDebugCircleRange(p159, p160, p161, p162, p163)
	local v164 = p163 - p162
	local v165 = 0
	local v166 = 0
	for v167 = 1, p161 do
		local v168 = 1.5707963267948966 + p162 + (v167 - 1) / p161 * v164
		local v169 = 1.5707963267948966 + p162 + v167 / p161 * v164
		local v170 = math.cos(v168) * p160
		local v171 = math.sin(v168) * p160
		local v172, v173, v174 = localToWorld(p159, v165 + v170, 0, v166 + v171)
		local v175 = math.cos(v169) * p160
		local v176 = math.sin(v169) * p160
		local v177, v178, v179 = localToWorld(p159, v165 + v175, 0, v166 + v176)
		drawDebugLine(v172, v173, v174, 1, 0, 0, v177, v178, v179, 1, 0, 0)
	end
end

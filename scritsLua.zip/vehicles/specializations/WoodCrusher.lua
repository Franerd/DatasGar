WoodCrusher = {}
WoodCrusher.DAMAGED_YIELD_DECREASE = 0.4
function WoodCrusher.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(FillUnit, p1)
	end
	return v2
end
function WoodCrusher.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("WoodCrusher")
	WoodCrusher.registerWoodCrusherXMLPaths(v3, "vehicle.woodCrusher")
	v3:register(XMLValueType.BOOL, "vehicle.woodCrusher#moveColDisableCollisionPairs", "Activate collision between move collisions and components", true)
	v3:register(XMLValueType.INT, "vehicle.woodCrusher#fillUnitIndex", "Fill unit index", 1)
	v3:setXMLSpecializationType()
end
function WoodCrusher.registerWoodCrusherXMLPaths(p4, p5)
	p4:register(XMLValueType.NODE_INDEX, p5 .. "#cutNode", "Cut node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. "#mainDrumRefNode", "Main drum reference node")
	p4:register(XMLValueType.FLOAT, p5 .. "#mainDrumRefNodeMaxY", "Max tree size the main drum can handle")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".moveTriggers.trigger(?)#node", "Move trigger")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".moveCollisions.collision(?)#node", "Move collision")
	p4:register(XMLValueType.FLOAT, p5 .. "#moveVelocityZ", "Move velocity Z (m/s)", 0.8)
	p4:register(XMLValueType.FLOAT, p5 .. "#moveMaxForce", "Move max. force (kN)", 7)
	p4:register(XMLValueType.NODE_INDEX, p5 .. "#shapeSizeDetectionNode", "At this node the tree shape size will be detected to set the #mainDrumRefNode")
	p4:register(XMLValueType.FLOAT, p5 .. "#cutSizeY", "Cut size Y", 1)
	p4:register(XMLValueType.FLOAT, p5 .. "#cutSizeZ", "Cut size Z", 1)
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".downForceNodes.downForceNode(?)#node", "Down force node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".downForceNodes.downForceNode(?)#trigger", "Additional trigger (If defined the tree needs to be present in the mover trigger and inside this trigger)")
	p4:register(XMLValueType.FLOAT, p5 .. ".downForceNodes.downForceNode(?)#force", "Down force (kN)", 2)
	p4:register(XMLValueType.FLOAT, p5 .. ".downForceNodes.downForceNode(?)#sizeY", "Size Y in which the down force node detects trees", "Cut size Y")
	p4:register(XMLValueType.FLOAT, p5 .. ".downForceNodes.downForceNode(?)#sizeZ", "Size Z in which the down force node detects trees", "Cut size Z")
	p4:register(XMLValueType.BOOL, p5 .. "#automaticallyTurnOn", "Automatically turned on", false)
	EffectManager.registerEffectXMLPaths(p4, p5 .. ".crushEffects")
	AnimationManager.registerAnimationNodesXMLPaths(p4, p5 .. ".animationNodes")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "start")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "stop")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "work")
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".sounds", "idle")
end
function WoodCrusher.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "onCrushedSplitShape", WoodCrusher.onCrushedSplitShape)
end
function WoodCrusher.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "getDirtMultiplier", WoodCrusher.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p7, "getWearMultiplier", WoodCrusher.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p7, "getCanBeTurnedOn", WoodCrusher.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p7, "getConsumingLoad", WoodCrusher.getConsumingLoad)
	SpecializationUtil.registerOverwrittenFunction(p7, "getRequiresPower", WoodCrusher.getRequiresPower)
end
function WoodCrusher.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", WoodCrusher)
	SpecializationUtil.registerEventListener(p8, "onDelete", WoodCrusher)
	SpecializationUtil.registerEventListener(p8, "onReadUpdateStream", WoodCrusher)
	SpecializationUtil.registerEventListener(p8, "onWriteUpdateStream", WoodCrusher)
	SpecializationUtil.registerEventListener(p8, "onUpdate", WoodCrusher)
	SpecializationUtil.registerEventListener(p8, "onUpdateTick", WoodCrusher)
	SpecializationUtil.registerEventListener(p8, "onTurnedOn", WoodCrusher)
	SpecializationUtil.registerEventListener(p8, "onTurnedOff", WoodCrusher)
end
function WoodCrusher.onLoad(p9, _)
	local v10 = p9.spec_woodCrusher
	WoodCrusher.loadWoodCrusher(p9, v10, p9.xmlFile, p9.components, p9.i3dMappings)
	if p9.xmlFile:getValue("vehicle.woodCrusher#moveColDisableCollisionPairs", true) then
		for _, v11 in pairs(p9.components) do
			for _, v12 in pairs(v10.moveColNodes) do
				setPairCollision(v11.node, v12.node, false)
			end
		end
	end
	v10.fillUnitIndex = p9.xmlFile:getValue("vehicle.woodCrusher#fillUnitIndex", 1)
end
function WoodCrusher.onDelete(p13)
	WoodCrusher.deleteWoodCrusher(p13, p13.spec_woodCrusher)
end
function WoodCrusher.onReadUpdateStream(p14, p15, _, p16)
	if p16:getIsServer() then
		local v17 = p14.spec_woodCrusher
		if streamReadBool(p15) then
			v17.crushingTime = 1000
			return
		end
		v17.crushingTime = 0
	end
end
function WoodCrusher.onWriteUpdateStream(p18, p19, p20, _)
	if not p20:getIsServer() then
		local v21 = p18.spec_woodCrusher
		streamWriteBool(p19, v21.crushingTime > 0)
	end
end
function WoodCrusher.onUpdate(p22, p23, _, _, _)
	WoodCrusher.updateWoodCrusher(p22, p22.spec_woodCrusher, p23, p22:getIsTurnedOn())
end
function WoodCrusher.onUpdateTick(p24, p25, _, _, _)
	WoodCrusher.updateTickWoodCrusher(p24, p24.spec_woodCrusher, p25, p24:getIsTurnedOn())
	local v26 = p24.spec_woodCrusher
	if p24.isServer and (g_currentMission.missionInfo.automaticMotorStartEnabled and (v26.turnOnAutomatically and p24.setIsTurnedOn ~= nil)) then
		if next(v26.moveTriggerNodes) ~= nil then
			if p24.getIsMotorStarted == nil then
				if p24.attacherVehicle ~= nil and (p24.attacherVehicle.getIsMotorStarted ~= nil and not p24.attacherVehicle:getIsMotorStarted()) then
					p24.attacherVehicle:startMotor()
				end
			elseif not p24:getIsMotorStarted() then
				p24:startMotor()
			end
			if (p24.getIsControlled == nil or not p24:getIsControlled()) and (not p24:getIsTurnedOn() and p24:getCanBeTurnedOn()) then
				p24:setIsTurnedOn(true)
			end
			v26.turnOffTimer = 3000
			return
		end
		if p24:getIsTurnedOn() then
			if v26.turnOffTimer == nil then
				v26.turnOffTimer = 3000
			end
			v26.turnOffTimer = v26.turnOffTimer - p25
			if v26.turnOffTimer < 0 and not p24:getRootVehicle().isControlled then
				if p24.getIsMotorStarted ~= nil and p24:getIsMotorStarted() then
					p24:stopMotor()
				end
				p24:setIsTurnedOn(false)
			end
		end
	end
end
function WoodCrusher.onTurnedOn(p27)
	WoodCrusher.turnOnWoodCrusher(p27, p27.spec_woodCrusher)
end
function WoodCrusher.onTurnedOff(p28)
	WoodCrusher.turnOffWoodCrusher(p28, p28.spec_woodCrusher)
end
function WoodCrusher.getCanBeTurnedOn(p29, p30)
	if p29.spec_woodCrusher.turnOnAutomatically then
		return false
	else
		return p30(p29)
	end
end
function WoodCrusher.getConsumingLoad(p31, p32)
	local v33, v34 = p32(p31)
	if p31.spec_woodCrusher.crushingTime > 0 then
		v33 = v33 + 1
	end
	return v33, v34 + 1
end
function WoodCrusher.getRequiresPower(p35, p36)
	return p35:getIsTurnedOn() and true or p36(p35)
end
function WoodCrusher.getDirtMultiplier(p37, p38)
	local v39 = p38(p37)
	if p37.spec_woodCrusher.crushingTime > 0 then
		v39 = v39 + p37:getWorkDirtMultiplier()
	end
	return v39
end
function WoodCrusher.getWearMultiplier(p40, p41)
	local v42 = p41(p40)
	if p40.spec_woodCrusher.crushingTime > 0 then
		v42 = v42 + p40:getWorkWearMultiplier()
	end
	return v42
end
function WoodCrusher.onCrushedSplitShape(p43, p44, p45)
	local v46 = p43.spec_woodCrusher
	local v47 = p43:getVehicleDamage()
	if v47 > 0 then
		p45 = p45 * (1 - v47 * WoodCrusher.DAMAGED_YIELD_DECREASE)
	end
	p43:addFillUnitFillLevel(p43:getOwnerFarmId(), v46.fillUnitIndex, p45 * p44.volumeToLiter * p44.woodChipsPerLiter, FillType.WOODCHIPS, ToolType.UNDEFINED)
end
function WoodCrusher.loadWoodCrusher(p_u_48, p_u_49, p_u_50, p_u_51, p_u_52)
	p_u_49.vehicle = p_u_48
	p_u_49.woodCrusherSplitShapeCallback = WoodCrusher.woodCrusherSplitShapeCallback
	p_u_49.woodCrusherMoveTriggerCallback = WoodCrusher.woodCrusherMoveTriggerCallback
	p_u_49.woodCrusherDownForceTriggerCallback = WoodCrusher.woodCrusherDownForceTriggerCallback
	local v53 = p_u_50:getRootName()
	local v54 = v53 .. ".woodCrusher"
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".woodCrusher.moveTrigger(0)#index", v53 .. ".woodCrusher.moveTriggers.trigger#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".woodCrusher.moveCollision(0)#index", v53 .. ".woodCrusher.moveCollisions.collision#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".woodCrusher.emitterShape(0)", v53 .. ".woodCrusher.crushEffects with effectClass \'ParticleEffect\'")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".woodCrusherStartSound", v53 .. ".woodCrusher.sounds.start")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".woodCrusherIdleSound", v53 .. ".woodCrusher.sounds.idle")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".woodCrusherWorkSound", v53 .. ".woodCrusher.sounds.work")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".woodCrusherStopSound", v53 .. ".woodCrusher.sounds.stop")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".turnedOnRotationNodes.turnedOnRotationNode#type", v53 .. ".woodCrusher.animationNodes.animationNode", "woodCrusher")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v53 .. ".turnedOnScrollers.turnedOnScroller", v53 .. ".woodCrusher.animationNodes.animationNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v54 .. "#downForceNode", v54 .. ".downForceNodes.downForceNode#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v54 .. "#downForce", v54 .. ".downForceNodes.downForceNode#force")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v54 .. "#downForceSizeY", v54 .. ".downForceNodes.downForceNode#sizeY")
	XMLUtil.checkDeprecatedXMLElements(p_u_50, v54 .. "#downForceSizeZ", v54 .. ".downForceNodes.downForceNode#sizeZ")
	p_u_49.cutNode = p_u_50:getValue(v54 .. "#cutNode", nil, p_u_51, p_u_52)
	p_u_49.mainDrumRefNode = p_u_50:getValue(v54 .. "#mainDrumRefNode", nil, p_u_51, p_u_52)
	p_u_49.mainDrumRefNodeMaxY = p_u_50:getValue(v54 .. "#mainDrumRefNodeMaxY", (1 / 0))
	if p_u_49.mainDrumRefNode ~= nil then
		local v55 = createTransformGroup("mainDrumRefNodeParent")
		link(getParent(p_u_49.mainDrumRefNode), v55, getChildIndex(p_u_49.mainDrumRefNode))
		setTranslation(v55, getTranslation(p_u_49.mainDrumRefNode))
		setRotation(v55, getRotation(p_u_49.mainDrumRefNode))
		link(v55, p_u_49.mainDrumRefNode)
		setTranslation(p_u_49.mainDrumRefNode, 0, 0, 0)
		setRotation(p_u_49.mainDrumRefNode, 0, 0, 0)
	end
	p_u_49.moveTriggers = {}
	local v56 = 0
	while true do
		local v57 = string.format("%s.moveTriggers.trigger(%d)", v54, v56)
		if not p_u_50:hasProperty(v57) then
			break
		end
		local v58 = p_u_50:getValue(v57 .. "#node", nil, p_u_51, p_u_52)
		if v58 ~= nil then
			if not CollisionFlag.getHasMaskFlagSet(v58, CollisionFlag.TREE) then
				Logging.xmlWarning(p_u_48.xmlFile, "Missing collision filter mask %s. Please add this bit to move trigger node \'%s\' in \'%s\'", CollisionFlag.getBitAndName(CollisionFlag.TREE), getName(v58), v57)
				break
			end
			local v59 = p_u_49.moveTriggers
			table.insert(v59, v58)
		end
		v56 = v56 + 1
	end
	p_u_49.moveColNodes = {}
	local v60 = 0
	while true do
		local v61 = string.format("%s.moveCollisions.collision(%d)", v54, v60)
		if not p_u_50:hasProperty(v61) then
			break
		end
		local v62 = {
			["node"] = p_u_50:getValue(v61 .. "#node", nil, p_u_51, p_u_52)
		}
		if v62.node ~= nil then
			local v63, v64, v65 = getTranslation(v62.node)
			v62.transX = v63
			v62.transY = v64
			v62.transZ = v65
			local v66 = p_u_49.moveColNodes
			table.insert(v66, v62)
		end
		v60 = v60 + 1
	end
	p_u_49.moveVelocityZ = p_u_50:getValue(v54 .. "#moveVelocityZ", 0.8)
	p_u_49.moveMaxForce = p_u_50:getValue(v54 .. "#moveMaxForce", 7)
	p_u_49.shapeSizeDetectionNode = p_u_50:getValue(v54 .. "#shapeSizeDetectionNode", nil, p_u_51, p_u_52)
	p_u_49.cutSizeY = p_u_50:getValue(v54 .. "#cutSizeY", 1)
	p_u_49.cutSizeZ = p_u_50:getValue(v54 .. "#cutSizeZ", 1)
	p_u_49.downForceNodes = {}
	p_u_49.downForceTriggers = {}
	p_u_50:iterate(v54 .. ".downForceNodes.downForceNode", function(_, p67)
		-- upvalues: (copy) p_u_50, (copy) p_u_51, (copy) p_u_52, (copy) p_u_49, (copy) p_u_48
		local v68 = {
			["node"] = p_u_50:getValue(p67 .. "#node", nil, p_u_51, p_u_52)
		}
		if v68.node ~= nil then
			v68.force = p_u_50:getValue(p67 .. "#force", 2)
			v68.trigger = p_u_50:getValue(p67 .. "#trigger", nil, p_u_51, p_u_52)
			v68.sizeY = p_u_50:getValue(p67 .. "#sizeY", p_u_49.cutSizeY)
			v68.sizeZ = p_u_50:getValue(p67 .. "#sizeZ", p_u_49.cutSizeZ)
			v68.woodCrusher = p_u_49
			v68.triggerNodes = {}
			if v68.trigger ~= nil and (p_u_49.downForceTriggers[v68.trigger] == nil and p_u_48.isServer) then
				p_u_49.downForceTriggers[v68.trigger] = true
				addTrigger(v68.trigger, "woodCrusherDownForceTriggerCallback", p_u_49)
			end
			local v69 = p_u_49.downForceNodes
			table.insert(v69, v68)
		end
	end)
	p_u_49.moveTriggerNodes = {}
	if p_u_48.isServer and p_u_49.moveTriggers ~= nil then
		for _, v70 in pairs(p_u_49.moveTriggers) do
			addTrigger(v70, "woodCrusherMoveTriggerCallback", p_u_49)
		end
	end
	p_u_49.crushNodes = {}
	p_u_49.crushingTime = 0
	p_u_49.turnOnAutomatically = p_u_50:getValue(v54 .. "#automaticallyTurnOn", false)
	if p_u_48.isClient then
		p_u_49.crushEffects = g_effectManager:loadEffect(p_u_50, v54 .. ".crushEffects", p_u_51, p_u_48, p_u_52)
		p_u_49.animationNodes = g_animationManager:loadAnimations(p_u_50, v54 .. ".animationNodes", p_u_51, p_u_48, p_u_52)
		p_u_49.isWorkSamplePlaying = false
		p_u_49.samples = {}
		p_u_49.samples.start = g_soundManager:loadSampleFromXML(p_u_50, v54 .. ".sounds", "start", p_u_48.baseDirectory, p_u_51, 1, AudioGroup.VEHICLE, p_u_52, p_u_48)
		p_u_49.samples.stop = g_soundManager:loadSampleFromXML(p_u_50, v54 .. ".sounds", "stop", p_u_48.baseDirectory, p_u_51, 1, AudioGroup.VEHICLE, p_u_52, p_u_48)
		p_u_49.samples.work = g_soundManager:loadSampleFromXML(p_u_50, v54 .. ".sounds", "work", p_u_48.baseDirectory, p_u_51, 0, AudioGroup.VEHICLE, p_u_52, p_u_48)
		p_u_49.samples.idle = g_soundManager:loadSampleFromXML(p_u_50, v54 .. ".sounds", "idle", p_u_48.baseDirectory, p_u_51, 0, AudioGroup.VEHICLE, p_u_52, p_u_48)
	end
end
function WoodCrusher.deleteWoodCrusher(_, p71)
	if p71.moveTriggers ~= nil then
		for _, v72 in pairs(p71.moveTriggers) do
			removeTrigger(v72)
		end
	end
	if p71.downForceTriggers ~= nil then
		for v73, _ in pairs(p71.downForceTriggers) do
			removeTrigger(v73)
		end
	end
	g_effectManager:deleteEffects(p71.crushEffects)
	g_soundManager:deleteSamples(p71.samples)
	g_animationManager:deleteAnimations(p71.animationNodes)
end
function WoodCrusher.updateWoodCrusher(p74, p75, p76, p77)
	if p77 and p74.isServer then
		for v78 in pairs(p75.crushNodes) do
			WoodCrusher.crushSplitShape(p74, p75, v78)
			p75.crushNodes[v78] = nil
			p75.moveTriggerNodes[v78] = nil
		end
		local v79 = 0
		for v80 in pairs(p75.moveTriggerNodes) do
			if entityExists(v80) then
				for v81 = 1, #p75.downForceNodes do
					local v82 = p75.downForceNodes[v81]
					if v82.triggerNodes[v80] ~= nil or v82.trigger == nil then
						local v83, v84, v85 = getWorldTranslation(v82.node)
						local v86, v87, v88 = localDirectionToWorld(v82.node, 1, 0, 0)
						local v89, v90, v91 = localDirectionToWorld(v82.node, 0, 1, 0)
						local v92, v93, v94, v95 = testSplitShape(v80, v83, v84, v85, v86, v87, v88, v89, v90, v91, v82.sizeY, v82.sizeZ)
						if v92 ~= nil then
							local v96, v97, v98 = localToWorld(v82.node, 0, (v92 + v93) * 0.5, (v94 + v95) * 0.5)
							local v99, v100, v101 = localDirectionToWorld(v82.node, 0, -v82.force, 0)
							addForce(v80, v99, v100, v101, v96, v97, v98, false)
						end
					end
				end
				if p75.shapeSizeDetectionNode ~= nil then
					local v102, v103, v104 = getWorldTranslation(p75.shapeSizeDetectionNode)
					local v105, v106, v107 = localDirectionToWorld(p75.shapeSizeDetectionNode, 1, 0, 0)
					local v108, v109, v110 = localDirectionToWorld(p75.shapeSizeDetectionNode, 0, 1, 0)
					local v111, v112, _, _ = testSplitShape(v80, v102, v103, v104, v105, v106, v107, v108, v109, v110, p75.cutSizeY, p75.cutSizeZ)
					if v111 ~= nil and p75.mainDrumRefNode ~= nil then
						v79 = math.max(v79, v112)
					end
				end
			else
				p75.moveTriggerNodes[v80] = nil
			end
		end
		if p75.mainDrumRefNode ~= nil then
			local v113, v114, v115 = getTranslation(p75.mainDrumRefNode)
			local v116 = p75.mainDrumRefNodeMaxY
			local v117 = math.min(v79, v116)
			local v118
			if v114 < v117 then
				local v119 = v114 + 0.0003 * p76
				v118 = math.min(v119, v117)
			else
				local v120 = v114 - 0.0003 * p76
				v118 = math.max(v120, v117)
			end
			setTranslation(p75.mainDrumRefNode, v113, v118, v115)
		end
		if next(p75.moveTriggerNodes) ~= nil or p75.crushingTime > 0 then
			p74:raiseActive()
		end
	end
end
function WoodCrusher.updateTickWoodCrusher(p121, p122, p123, p124)
	if p124 and p121.isServer then
		if p122.cutNode ~= nil and next(p122.moveTriggerNodes) ~= nil then
			local v125, v126, v127 = getWorldTranslation(p122.cutNode)
			local v128, v129, v130 = localDirectionToWorld(p122.cutNode, 1, 0, 0)
			local v131, v132, v133 = localDirectionToWorld(p122.cutNode, 0, 1, 0)
			for v134 in pairs(p122.moveTriggerNodes) do
				local v135, v136 = getSplitShapePlaneExtents(v134, v125, v126, v127, v128, v129, v130)
				if v136 ~= nil and v135 ~= nil then
					if v135 <= 0.4 then
						p122.moveTriggerNodes[v134] = nil
						WoodCrusher.crushSplitShape(p121, p122, v134)
					elseif v136 >= 0.2 then
						p121.shapeBeingCut = v134
						local v137 = splitShape(v134, v125, v126, v127, v128, v129, v130, v131, v132, v133, p122.cutSizeY, p122.cutSizeZ, "woodCrusherSplitShapeCallback", p122)
						g_treePlantManager:removingSplitShape(v134)
						if v137 ~= nil then
							p122.moveTriggerNodes[v134] = nil
						end
					end
				end
			end
		end
		if p121.isServer and p122.moveColNodes ~= nil then
			for _, v138 in pairs(p122.moveColNodes) do
				setTranslation(v138.node, v138.transX, v138.transY + math.random() * 0.005, v138.transZ)
			end
		end
	end
	if p122.crushingTime > 0 then
		local v139 = p122.crushingTime - p123
		p122.crushingTime = math.max(v139, 0)
	end
	local v140 = p122.crushingTime > 0
	if p121.isClient then
		if v140 then
			g_effectManager:setEffectTypeInfo(p122.crushEffects, FillType.WOODCHIPS)
			g_effectManager:startEffects(p122.crushEffects)
		else
			g_effectManager:stopEffects(p122.crushEffects)
		end
		if p124 and v140 then
			if not p122.isWorkSamplePlaying then
				g_soundManager:playSample(p122.samples.work)
				p122.isWorkSamplePlaying = true
				return
			end
		elseif p122.isWorkSamplePlaying then
			g_soundManager:stopSample(p122.samples.work)
			p122.isWorkSamplePlaying = false
		end
	end
end
function WoodCrusher.turnOnWoodCrusher(p141, p142)
	if p141.isServer and p142.moveColNodes ~= nil then
		for _, v143 in pairs(p142.moveColNodes) do
			setFrictionVelocity(v143.node, p142.moveVelocityZ)
		end
	end
	if p141.isClient then
		g_soundManager:stopSamples(p142.samples)
		p142.isWorkSamplePlaying = false
		g_soundManager:playSample(p142.samples.start)
		g_soundManager:playSample(p142.samples.idle, 0, p142.samples.start)
		if p141.isClient then
			g_animationManager:startAnimations(p142.animationNodes)
		end
	end
end
function WoodCrusher.turnOffWoodCrusher(p144, p145)
	if p144.isServer then
		for v146 in pairs(p145.crushNodes) do
			WoodCrusher.crushSplitShape(p144, p145, v146)
			p145.crushNodes[v146] = nil
		end
		if p145.moveColNodes ~= nil then
			for _, v147 in pairs(p145.moveColNodes) do
				setFrictionVelocity(v147.node, 0)
			end
		end
	end
	if p144.isClient then
		g_effectManager:stopEffects(p145.crushEffects)
		g_soundManager:stopSamples(p145.samples)
		g_soundManager:playSample(p145.samples.stop)
		p145.isWorkSamplePlaying = false
		if p144.isClient then
			g_animationManager:stopAnimations(p145.animationNodes)
		end
	end
end
function WoodCrusher.crushSplitShape(p148, p149, p150)
	local v151 = g_splitShapeManager:getSplitTypeByIndex(getSplitType(p150))
	if v151 ~= nil and v151.woodChipsPerLiter > 0 then
		local v152 = getVolume(p150)
		delete(p150)
		p149.crushingTime = 1000
		p148:onCrushedSplitShape(v151, v152)
	end
end
function WoodCrusher.woodCrusherSplitShapeCallback(p153, p154, p155, _, _, _, _, _)
	if not p155 then
		p153.crushNodes[p154] = p154
		g_treePlantManager:addingSplitShape(p154, p153.shapeBeingCut)
	end
end
function WoodCrusher.woodCrusherMoveTriggerCallback(p156, _, p157, p158, p159, _, _)
	if g_currentMission.nodeToObject[p157] == nil and getRigidBodyType(p157) == RigidBodyType.DYNAMIC then
		local v160 = g_splitShapeManager:getSplitTypeByIndex(getSplitType(p157))
		if v160 ~= nil and v160.woodChipsPerLiter > 0 then
			if p158 then
				p156.moveTriggerNodes[p157] = Utils.getNoNil(p156.moveTriggerNodes[p157], 0) + 1
				p156.vehicle:raiseActive()
				return
			end
			if p159 then
				local v161 = p156.moveTriggerNodes[p157]
				if v161 ~= nil then
					local v162 = v161 - 1
					if v162 == 0 then
						p156.moveTriggerNodes[p157] = nil
						return
					end
					p156.moveTriggerNodes[p157] = v162
				end
			end
		end
	end
end
function WoodCrusher.woodCrusherDownForceTriggerCallback(p163, p164, p165, p166, p167, _, _)
	if g_currentMission.nodeToObject[p165] == nil and getRigidBodyType(p165) == RigidBodyType.DYNAMIC then
		local v168 = g_splitShapeManager:getSplitTypeByIndex(getSplitType(p165))
		if v168 ~= nil and v168.woodChipsPerLiter > 0 then
			for v169 = 1, #p163.downForceNodes do
				local v170 = p163.downForceNodes[v169]
				if v170.trigger == p164 then
					if p166 then
						v170.triggerNodes[p165] = Utils.getNoNil(v170.triggerNodes[p165], 0) + 1
						p163.vehicle:raiseActive()
					elseif p167 then
						local v171 = v170.triggerNodes[p165]
						if v171 ~= nil then
							local v172 = v171 - 1
							if v172 == 0 then
								v170.triggerNodes[p165] = nil
							else
								v170.triggerNodes[p165] = v172
							end
						end
					end
				end
			end
		end
	end
end

ChainRollers = {}
function ChainRollers.prerequisitesPresent(_)
	return true
end
function ChainRollers.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("ChainRollers")
	v1:register(XMLValueType.FLOAT, "vehicle.chainRollers#maxUpdateDistance", "If the player is more than this distance away the nodes will no longer be updated", 100)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.chainRollers.chainRoller(?)#elementsNode", "Root node that contains every chain link")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.chainRollers.chainRoller(?)#endReferenceNode", "Reference node for the alignment of the last chain link")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.chainRollers.chainRoller(?).splineNode(?)#node", "Regular transform group(s) that define the spline (at least two have to be defined)")
	v1:addDelayedRegistrationFunc("Cylindered:movingTool", function(p2, p3)
		p2:register(XMLValueType.NODE_INDICES, p3 .. ".chainRollers#splineNodes", "Spline nodes to update")
	end)
	v1:addDelayedRegistrationFunc("Cylindered:movingPart", function(p4, p5)
		p4:register(XMLValueType.NODE_INDICES, p5 .. ".chainRollers#splineNodes", "Spline nodes to update")
	end)
	v1:setXMLSpecializationType()
end
function ChainRollers.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "loadChainRollerFromXML", ChainRollers.loadChainRollerFromXML)
	SpecializationUtil.registerFunction(p6, "updateChainRoller", ChainRollers.updateChainRoller)
end
function ChainRollers.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadExtraDependentParts", ChainRollers.loadExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p7, "updateExtraDependentParts", ChainRollers.updateExtraDependentParts)
end
function ChainRollers.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", ChainRollers)
	SpecializationUtil.registerEventListener(p8, "onLoadFinished", ChainRollers)
	SpecializationUtil.registerEventListener(p8, "onPostUpdate", ChainRollers)
end
function ChainRollers.onLoad(p_u_9, _)
	local v_u_10 = p_u_9.spec_chainRollers
	if p_u_9.xmlFile:hasProperty("vehicle.chainRollers") then
		v_u_10.maxUpdateDistance = p_u_9.xmlFile:getValue("vehicle.chainRollers#maxUpdateDistance", 100)
		v_u_10.chainRollers = {}
		v_u_10.chainRollerSplineNodeToSpline = {}
		p_u_9.xmlFile:iterate("vehicle.chainRollers.chainRoller", function(_, p11)
			-- upvalues: (copy) p_u_9, (copy) v_u_10
			local v12 = {}
			if p_u_9:loadChainRollerFromXML(p_u_9.xmlFile, p11, v12) then
				local v13 = v_u_10.chainRollers
				table.insert(v13, v12)
			end
		end)
		if #v_u_10.chainRollers == 0 then
			SpecializationUtil.removeEventListener(p_u_9, "onLoadFinished", ChainRollers)
			SpecializationUtil.removeEventListener(p_u_9, "onPostUpdate", ChainRollers)
		end
	else
		SpecializationUtil.removeEventListener(p_u_9, "onLoadFinished", ChainRollers)
		SpecializationUtil.removeEventListener(p_u_9, "onPostUpdate", ChainRollers)
	end
end
function ChainRollers.onLoadFinished(p14, _)
	ChainRollers.onPostUpdate(p14, 99999, false, false, false)
end
function ChainRollers.onPostUpdate(p15, p16, _, _, _)
	local v17 = p15.spec_chainRollers
	if p15.currentUpdateDistance < v17.maxUpdateDistance then
		for v18, v19 in pairs(v17.chainRollerSplineNodeToSpline) do
			if v19.isDirty then
				setSplineCV(v19.spline, v19.index, localToLocal(v18, v19.spline, 0, 0, 0))
				v19.isDirty = false
				v19.chainRoller.isDirty = true
			end
		end
		for _, v20 in pairs(v17.chainRollers) do
			if v20.isDirty then
				p15:updateChainRoller(v20, p16)
				v20.isDirty = false
			end
		end
		if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
			for _, v21 in pairs(v17.chainRollers) do
				for v22 = 1, #v21.splineNodes - 1 do
					local v23, v24, v25 = getWorldTranslation(v21.splineNodes[v22])
					local v26, v27, v28 = getWorldTranslation(v21.splineNodes[v22 + 1])
					drawDebugLine(v23, v24, v25, 1, 0, 0, v26, v27, v28, 1, 0, 0, false)
					drawDebugPoint(v23, v24, v25, 1, 0, 0, 1, false)
					drawDebugPoint(v26, v27, v28, 1, 0, 0, 1, false)
				end
				for v29 = 0, 99 do
					local v30 = v29 / 100
					local v31, v32, v33 = getSplinePosition(v21.spline, v30)
					local v34, v35, v36 = getSplinePosition(v21.spline, v30 + 0.01)
					drawDebugLine(v31, v32, v33, 0, 1, 0, v34, v35, v36, 0, 1, 0, false)
				end
			end
		end
	end
end
function ChainRollers.loadChainRollerFromXML(p_u_37, p_u_38, p39, p_u_40)
	local v41 = p_u_37.spec_chainRollers
	p_u_40.elementsNode = p_u_38:getValue(p39 .. "#elementsNode", nil, p_u_37.components, p_u_37.i3dMappings)
	if p_u_40.elementsNode == nil then
		Logging.xmlWarning(p_u_38, "Missing \'elementsNode\' for chainRoller \'%s\'!", p39)
		return false
	end
	p_u_40.elements = {}
	for v42 = 1, getNumOfChildren(p_u_40.elementsNode) do
		local v43 = getChildAt(p_u_40.elementsNode, v42 - 1)
		local v44 = p_u_40.elements
		table.insert(v44, v43)
	end
	p_u_40.numElements = #p_u_40.elements
	if p_u_40.numElements == 0 then
		Logging.xmlWarning(p_u_38, "Missing elements inside \'elementsNode\' for chainRoller \'%s\'!", p39)
		return false
	end
	p_u_40.endReferenceNode = p_u_38:getValue(p39 .. "#endReferenceNode", nil, p_u_37.components, p_u_37.i3dMappings)
	p_u_40.splineNodes = {}
	p_u_38:iterate(p39 .. ".splineNode", function(_, p45)
		-- upvalues: (copy) p_u_38, (copy) p_u_37, (copy) p_u_40
		local v46 = p_u_38:getValue(p45 .. "#node", nil, p_u_37.components, p_u_37.i3dMappings)
		if v46 == nil then
			Logging.xmlWarning(p_u_38, "Missing \'node\' for chainRoller spline \'%s\'!", p45)
			return false
		end
		local v47 = p_u_40.splineNodes
		table.insert(v47, v46)
	end)
	if #p_u_40.splineNodes < 2 then
		Logging.xmlWarning(p_u_38, "Missing spline nodes for chainRoller \'%s\', at least two are required!", p39)
		return false
	end
	local v48 = {}
	for _, v49 in pairs(p_u_40.splineNodes) do
		local v50, v51, v52 = getTranslation(v49)
		table.insert(v48, v50)
		table.insert(v48, v51)
		table.insert(v48, v52)
	end
	p_u_40.spline = createSplineFromEditPoints(getParent(p_u_40.splineNodes[1]), v48, false, false)
	setVisibility(p_u_40.spline, false)
	for v53, v54 in pairs(p_u_40.splineNodes) do
		v41.chainRollerSplineNodeToSpline[v54] = {
			["chainRoller"] = p_u_40,
			["spline"] = p_u_40.spline,
			["index"] = v53 - 1,
			["isDirty"] = false
		}
	end
	p_u_40.isDirty = true
	return true
end
function ChainRollers.updateChainRoller(_, p55, _)
	local v56 = nil
	local v57 = nil
	local v58 = nil
	local v59 = nil
	for v60 = 1, p55.numElements do
		local v61 = p55.elements[v60]
		local v62 = (v60 - 1) / (p55.numElements - 1)
		local v63, v64, v65 = getSplinePosition(p55.spline, v62)
		setWorldTranslation(v61, v63, v64, v65)
		if v56 ~= nil then
			local v66, v67, v68 = MathUtil.vector3Normalize(v63 - v56, v64 - v57, v65 - v58)
			local v69, v70, v71 = worldDirectionToLocal(p55.elementsNode, v66, v67, v68)
			setDirection(v59, v69, v70, v71, 0, 1, 0)
		end
		v59 = v61
		v58 = v65
		v57 = v64
		v56 = v63
	end
	if p55.endReferenceNode ~= nil then
		local v72 = p55.elements[p55.numElements]
		local v73, v74, v75 = getWorldTranslation(p55.endReferenceNode)
		local v76, v77, v78 = MathUtil.vector3Normalize(v73 - v56, v74 - v57, v75 - v58)
		local v79, v80, v81 = worldDirectionToLocal(p55.elementsNode, v76, v77, v78)
		setDirection(v72, v79, v80, v81, 0, 1, 0)
	end
end
function ChainRollers.loadExtraDependentParts(p82, p83, p84, p85, p86)
	if not p83(p82, p84, p85, p86) then
		return false
	end
	local v87 = p84:getValue(p85 .. ".chainRollers#splineNodes", nil, p82.components, p82.i3dMappings, true)
	if v87 ~= nil and #v87 > 0 then
		p86.chainRollerSplineNodes = v87
	end
	return true
end
function ChainRollers.updateExtraDependentParts(p88, p89, p90, p91)
	p89(p88, p90, p91)
	if p90.chainRollerSplineNodes ~= nil then
		local v92 = p88.spec_chainRollers
		for v93 = 1, #p90.chainRollerSplineNodes do
			local v94 = p90.chainRollerSplineNodes[v93]
			local v95 = v92.chainRollerSplineNodeToSpline[v94]
			if v95 ~= nil then
				v95.isDirty = true
			end
		end
	end
end

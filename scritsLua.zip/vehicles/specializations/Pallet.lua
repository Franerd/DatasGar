Pallet = {}
Pallet.PHYSICS_FIX_ENABLED = true
function Pallet.prerequisitesPresent(_)
	return true
end
function Pallet.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Pallet")
	v1:register(XMLValueType.INT, "vehicle.pallet#fillUnitIndex", "Fill unit index", 1)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pallet#node", "Root visual pallet node")
	v1:register(XMLValueType.NODE_INDICES, "vehicle.pallet#linkNode", "Link node for externally loaded visual pallet (can be multiple link nodes separated by space)")
	v1:register(XMLValueType.FILENAME, "vehicle.pallet#filename", "Path to visual pallet i3d file to load", "$data/objects/pallets/shared/euroPallet/euroPallet.i3d")
	v1:register(XMLValueType.FILENAME, "vehicle.pallet.texture(?)#diffuse", "Path to the diffuse texture to use (if multiple are defined it will switch between them randomly)")
	v1:register(XMLValueType.INT, "vehicle.pallet.content(?)#fillUnitIndex", "Fill unit index for this content", "pallet#fillUnitIndex")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pallet.content(?).object(?)#node", "Object node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pallet.content(?).object(?)#tensionBeltNode", "Object used for tension belt calculations")
	v1:register(XMLValueType.BOOL, "vehicle.pallet.content(?).object(?)#useAsTensionBeltMesh", "Flag for toggling object node being used as tension belt node", true)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pallet.straps.strap(?)#startNode", "Start node of the strap")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pallet.straps.strap(?)#endNode", "End node of the strap")
	v1:register(XMLValueType.STRING, "vehicle.pallet.straps.strap(?)#tensionBeltType", "Type of the tension belt to use", "basic")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pallet.straps.strap(?).intersectionNode(?)#node", "Intersection node")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.pallet.sounds", "unload")
	v1:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.FLOAT, "vehicles.vehicle(?).pallet#age", "Random age of the pallet [0-1]")
end
function Pallet.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "onPalletI3DFileLoaded", Pallet.onPalletI3DFileLoaded)
	SpecializationUtil.registerFunction(p2, "getInfoBoxTitle", Pallet.getInfoBoxTitle)
	SpecializationUtil.registerFunction(p2, "collectPalletTensionBeltNodes", Pallet.collectPalletTensionBeltNodes)
	SpecializationUtil.registerFunction(p2, "setPalletTensionBeltNodesDirty", Pallet.setPalletTensionBeltNodesDirty)
	SpecializationUtil.registerFunction(p2, "updatePalletStraps", Pallet.updatePalletStraps)
end
function Pallet.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "getMeshNodes", Pallet.getMeshNodes)
	SpecializationUtil.registerOverwrittenFunction(p3, "loadComponentFromXML", Pallet.loadComponentFromXML)
	SpecializationUtil.registerOverwrittenFunction(p3, "getAutoLoadSize", Pallet.getAutoLoadSize)
	SpecializationUtil.registerOverwrittenFunction(p3, "autoLoad", Pallet.autoLoad)
	SpecializationUtil.registerOverwrittenFunction(p3, "getShowInVehiclesOverview", Pallet.getShowInVehiclesOverview)
	SpecializationUtil.registerOverwrittenFunction(p3, "getCanBeReset", Pallet.getCanBeReset)
	SpecializationUtil.registerOverwrittenFunction(p3, "getIsMapHotspotVisible", Pallet.getIsMapHotspotVisible)
end
function Pallet.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onPreLoad", Pallet)
	SpecializationUtil.registerEventListener(p4, "onLoad", Pallet)
	SpecializationUtil.registerEventListener(p4, "onPostLoad", Pallet)
	SpecializationUtil.registerEventListener(p4, "onDelete", Pallet)
	SpecializationUtil.registerEventListener(p4, "onFillUnitFillLevelChanged", Pallet)
end
function Pallet.onPreLoad(p5, _)
	p5.isPallet = true
	p5.allowsInput = false
end
function Pallet.onLoad(p6, p7)
	local v8 = p6.spec_pallet
	v8.fillUnitIndex = p6.xmlFile:getValue("vehicle.pallet#fillUnitIndex", 1)
	v8.node = p6.xmlFile:getValue("vehicle.pallet#node", nil, p6.components, p6.i3dMappings)
	if v8.node ~= nil and not getHasClassId(v8.node, ClassIds.SHAPE) then
		Logging.xmlWarning(p6.xmlFile, "Pallet node must be a shape in \'vehicle.pallet#node\'")
		v8.node = nil
	end
	v8.nodes = { v8.node }
	v8.tensionBeltNodes = { v8.node }
	v8.linkNodes = p6.xmlFile:getValue("vehicle.pallet#linkNode", nil, p6.components, p6.i3dMappings, true)
	if #v8.linkNodes > 0 then
		v8.filename = p6.xmlFile:getValue("vehicle.pallet#filename", "$data/objects/pallets/shared/euroPallet/euroPallet.i3d", p6.baseDirectory)
		if v8.filename ~= nil then
			v8.sharedLoadRequestId = p6:loadSubSharedI3DFile(v8.filename, true, true, p6.onPalletI3DFileLoaded, p6)
		end
	end
	v8.textures = {}
	for _, v9 in p6.xmlFile:iterator("vehicle.pallet.texture") do
		local v10 = {
			["diffuse"] = p6.xmlFile:getValue(v9 .. "#diffuse", nil, p6.baseDirectory)
		}
		if v10.diffuse ~= nil then
			local v11 = v8.textures
			table.insert(v11, v10)
		end
	end
	if p7 ~= nil then
		v8.palletAge = p7.xmlFile:getValue(p7.key .. ".pallet#age")
	end
	if v8.palletAge == nil then
		if p6.propertyState == VehiclePropertyState.SHOP_CONFIG then
			v8.palletAge = 0
		else
			v8.palletAge = math.random()
		end
	end
	v8.contents = {}
	for _, v12 in p6.xmlFile:iterator("vehicle.pallet.content") do
		local v13 = {
			["objects"] = {},
			["fillUnitIndex"] = p6.xmlFile:getValue(v12 .. "#fillUnitIndex", v8.fillUnitIndex)
		}
		for _, v14 in p6.xmlFile:iterator(v12 .. ".object") do
			local v15 = {
				["node"] = p6.xmlFile:getValue(v14 .. "#node", nil, p6.components, p6.i3dMappings)
			}
			if v15.node ~= nil then
				v15.useAsTensionBeltMesh = p6.xmlFile:getValue(v14 .. "#useAsTensionBeltMesh", true)
				if v15.useAsTensionBeltMesh then
					local v16 = p6.xmlFile:getValue(v14 .. "#tensionBeltNode", nil, p6.components, p6.i3dMappings)
					if v16 == nil then
						if not getShapeIsCPUMesh(v15.node) then
							Logging.xmlWarning(p6.xmlFile, "Shape \'%s\' defined in \'%s\' does not have \'CPU-Mesh\' flag set. Either set the flag on the mesh or add a custom tension belt node using xml attribute \'#tensionBeltNode\'", getName(v15.node), v14 .. "#node")
						end
					elseif getShapeIsCPUMesh(v16) then
						v15.tensionBeltNode = v16
					else
						Logging.xmlWarning(p6.xmlFile, "Shape \'%s\' defined in \'%s\' does not have \'CPU-Mesh\' flag set. Ignoring this node", getName(v16), v14 .. "#tensionBeltNode")
					end
				end
				v15.isActive = false
				setVisibility(v15.node, v15.isActive)
				local v17 = v13.objects
				table.insert(v17, v15)
			end
		end
		if #v13.objects > 0 then
			v13.numObjects = #v13.objects
			local v18 = v8.contents
			table.insert(v18, v13)
		end
	end
	v8.straps = {}
	for _, v19 in p6.xmlFile:iterator("vehicle.pallet.straps.strap") do
		local v20 = {
			["startNode"] = p6.xmlFile:getValue(v19 .. "#startNode", nil, p6.components, p6.i3dMappings),
			["endNode"] = p6.xmlFile:getValue(v19 .. "#endNode", nil, p6.components, p6.i3dMappings)
		}
		if v20.startNode == nil or v20.endNode == nil then
			Logging.xmlWarning(p6.xmlFile, "Invalid strap definition. Both start and end node must be defined")
		else
			local v21 = p6.xmlFile:getValue(v19 .. "#tensionBeltType", "basic")
			v20.beltData = g_tensionBeltManager:getBeltData(v21)
			if v20.beltData == nil then
				Logging.xmlWarning(p6.xmlFile, "Invalid tension belt type \'%s\' defined for strap", v21)
			else
				v20.intersectionNodes = {}
				for _, v22 in p6.xmlFile:iterator(v19 .. ".intersectionNode") do
					local v23 = p6.xmlFile:getValue(v22 .. "#node", nil, p6.components, p6.i3dMappings)
					if v23 ~= nil then
						local v24 = v20.intersectionNodes
						table.insert(v24, v23)
					end
				end
				local v25 = v8.straps
				table.insert(v25, v20)
			end
		end
	end
	v8.strapMeshes = {}
	v8.tensionBeltMeshes = {}
	v8.tensionBeltMeshesDirty = true
	if p6.isClient then
		v8.samples = {}
		v8.samples.unload = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.pallet.sounds", "unload", p6.baseDirectory, p6.components, 1, AudioGroup.VEHICLE, p6.i3dMappings, p6)
	end
	g_currentMission.slotSystem:addLimitedObject(SlotSystem.LIMITED_OBJECT_PALLET, p6)
	p6.dynamicMountForkXLimit = 0.01
	p6.dynamicMountForkYLimit = 0.1
end
function Pallet.onPostLoad(p26, _)
	local v27 = p26.spec_pallet
	if #v27.nodes > 0 then
		for _, v28 in ipairs(v27.nodes) do
			local v29 = getMaterial(v28, 0)
			local v30 = #v27.textures
			if v30 > 0 then
				local v31
				if v30 == 1 then
					v31 = setMaterialDiffuseMapFromFile(v29, v27.textures[1].diffuse, true, true, false)
				else
					local v32 = v27.palletAge * (v30 - 1)
					local v33 = math.floor(v32)
					local v34 = math.ceil(v32)
					local v35 = setMaterialDiffuseMapFromFile(v29, v27.textures[v33 + 1].diffuse, true, true, false)
					local v36 = setMaterialCustomMapFromFile(v35, v27.textures[v34 + 1].diffuse, "mCustomDiffuse", true, true, false)
					v31 = setMaterialCustomParameter(v36, "blendScale", v32 - v33, 0, 0, 0, false)
				end
				setMaterial(v28, v31, 0)
			end
		end
	end
end
function Pallet.onDelete(p37)
	local v38 = p37.spec_pallet
	if p37.isClient then
		g_soundManager:deleteSamples(v38.samples)
	end
	if v38.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(v38.sharedLoadRequestId)
		v38.sharedLoadRequestId = nil
	end
	g_currentMission.slotSystem:removeLimitedObject(SlotSystem.LIMITED_OBJECT_PALLET, p37)
end
function Pallet.saveToXMLFile(p39, p40, p41, _)
	local v42 = p39.spec_pallet
	p40:setValue(p41 .. "#age", v42.palletAge)
end
function Pallet.loadComponentFromXML(p43, p44, p45, p46, p47, p48, p49)
	if not Platform.gameplay.hasDynamicPallets and getRigidBodyType(p45.node) == RigidBodyType.DYNAMIC then
		setRigidBodyType(p45.node, RigidBodyType.KINEMATIC)
	end
	return p44(p43, p45, p46, p47, p48, p49)
end
function Pallet.onFillUnitFillLevelChanged(p50, p51, _, _, _, _, _)
	local v52 = p50.spec_pallet
	for v53 = 1, #v52.contents do
		local v54 = v52.contents[v53]
		if v54.fillUnitIndex == p51 then
			local v55 = p50:getFillUnitFillLevelPercentage(p51)
			local v56 = v54.numObjects * v55
			local v57 = math.floor(v56)
			local v58 = v57 == 0 and v55 and 1 or v57
			for v59 = 1, #v54.objects do
				local v60 = v54.objects[v59]
				local v61 = v59 <= v58
				if v60.isActive ~= v61 then
					local v62 = v60.isActive
					if v62 then
						v62 = not v61
					end
					if v62 and p50.isClient then
						g_soundManager:playSample(v52.samples.unload)
					end
					v60.isActive = v61
					setVisibility(v60.node, v60.isActive)
					p50:setPalletTensionBeltNodesDirty()
				end
			end
		end
	end
end
function Pallet.getMeshNodes(p63, p64)
	local v65 = p63.spec_pallet
	if v65.tensionBeltMeshesDirty then
		v65.tensionBeltMeshes = {}
		p63:collectPalletTensionBeltNodes(v65.tensionBeltMeshes)
		v65.tensionBeltMeshesDirty = false
	end
	if #v65.tensionBeltMeshes > 0 then
		return v65.tensionBeltMeshes
	else
		return p64(p63)
	end
end
function Pallet.collectPalletTensionBeltNodes(p66, p67)
	local v68 = p66.spec_pallet
	if #v68.tensionBeltNodes > 0 then
		for _, v69 in ipairs(v68.tensionBeltNodes) do
			table.insert(p67, v69)
		end
	end
	for v70 = 1, #v68.contents do
		local v71 = v68.contents[v70]
		for v72 = 1, #v71.objects do
			local v73 = v71.objects[v72]
			if v73.isActive and v73.useAsTensionBeltMesh then
				local v74 = v73.tensionBeltNode or v73.node
				table.insert(p67, v74)
			end
		end
	end
end
function Pallet.setPalletTensionBeltNodesDirty(p75)
	p75.spec_pallet.tensionBeltMeshesDirty = true
end
function Pallet.updatePalletStraps(p76)
	local v77 = p76.spec_pallet
	for v78 = #v77.strapMeshes, 1, -1 do
		delete(v77.strapMeshes[v78])
		v77.strapMeshes[v78] = nil
	end
	local v79 = p76:getMeshNodes()
	for _, v80 in ipairs(v77.straps) do
		local v81 = TensionBeltGeometryConstructor.new()
		v81:setWidth(v80.beltData.width)
		v81:setMaterial(v80.beltData.material.materialId)
		v81:setUVscale(v80.beltData.material.uvScale)
		v81:setMaxEdgeLength(0.1)
		v81:setFixedPoints(v80.startNode, v80.endNode)
		v81:setGeometryBias(0.005)
		v81:setLinkNode(v80.startNode)
		for _, v82 in pairs(v80.intersectionNodes) do
			local v83, v84, v85 = getWorldTranslation(v82)
			local v86, v87, v88 = localDirectionToWorld(v82, 1, 0, 0)
			v81:addIntersectionPoint(v83, v84, v85, v86, v87, v88)
		end
		for _, v89 in ipairs(v79) do
			v81:addShape(v89, -100, 100, -100, 100)
		end
		local v90, _, v91 = v81:finalize()
		local v92 = 0
		for v93 = 1, #v80.intersectionNodes - 1 do
			local v94 = v80.intersectionNodes[v93]
			local v95 = v80.intersectionNodes[v93 + 1]
			v92 = v92 + calcDistanceFrom(v94, v95)
		end
		local v96
		if #v80.intersectionNodes > 0 then
			v96 = v92 + calcDistanceFrom(v80.startNode, v80.intersectionNodes[1]) + calcDistanceFrom(v80.intersectionNodes[#v80.intersectionNodes], v80.endNode)
		else
			v96 = calcDistanceFrom(v80.startNode, v80.endNode)
		end
		if v91 < v96 + 0.025 then
			delete(v90)
		else
			local v97 = v77.strapMeshes
			table.insert(v97, v90)
		end
	end
end
function Pallet.onPalletI3DFileLoaded(p98, p99, p100)
	if p100 == LoadI3DFailedReason.NONE then
		local v101 = p98.spec_pallet
		local v102 = getChildAt(p99, 0)
		if getHasClassId(v102, ClassIds.SHAPE) then
			for v103, v104 in ipairs(v101.linkNodes) do
				if v103 == 1 then
					link(v104, v102)
					local v105 = v101.nodes
					table.insert(v105, v102)
					local v106 = getChildAt(v102, 0)
					if v106 ~= 0 then
						local v107 = v101.tensionBeltNodes
						table.insert(v107, v106)
					end
				else
					local v108 = clone(v102, false, false, false)
					link(v104, v108)
					local v109 = v101.nodes
					table.insert(v109, v108)
					local v110 = getChildAt(v108, 0)
					if v110 ~= 0 then
						local v111 = v101.tensionBeltNodes
						table.insert(v111, v110)
					end
				end
			end
		end
		delete(p99)
	end
end
function Pallet.getInfoBoxTitle(_)
	return g_i18n:getText("infohud_pallet")
end
function Pallet.getAutoLoadSize(p112, _)
	local v113 = p112.size
	return v113.length, v113.height, v113.width
end
function Pallet.autoLoad(p114, _, p115, p116, p117, p118, p119, p120)
	p114:mountKinematic(p115, p116, p117 + p119 * 0.5, 0, p118 + p120 * 0.5, 0, 1.5707963267948966, 0)
	return true
end
function Pallet.getShowInVehiclesOverview(_, _)
	return false
end
function Pallet.getCanBeReset(_, _)
	return false
end
function Pallet.getIsMapHotspotVisible(_, _)
	return false
end

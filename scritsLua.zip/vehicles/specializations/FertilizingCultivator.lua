FertilizingCultivator = {}
function FertilizingCultivator.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Cultivator, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Sprayer, p1)
	end
	return v2
end
function FertilizingCultivator.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("FertilizingCultivator")
	v3:register(XMLValueType.BOOL, "vehicle.fertilizingCultivator#needsSetIsTurnedOn", "Needs to be turned on to spray", false)
	v3:setXMLSpecializationType()
end
function FertilizingCultivator.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "processCultivatorArea", FertilizingCultivator.processCultivatorArea)
	SpecializationUtil.registerOverwrittenFunction(p4, "setSprayerAITerrainDetailProhibitedRange", FertilizingCultivator.setSprayerAITerrainDetailProhibitedRange)
end
function FertilizingCultivator.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", FertilizingCultivator)
end
function FertilizingCultivator.onLoad(p6, _)
	p6.spec_fertilizingCultivator.needsSetIsTurnedOn = p6.xmlFile:getValue("vehicle.fertilizingCultivator#needsSetIsTurnedOn", false)
	p6.spec_sprayer.useSpeedLimit = false
	p6:clearAITerrainDetailRequiredRange()
	p6:updateCultivatorAIRequirements()
end
function FertilizingCultivator.processCultivatorArea(p7, _, p8, _)
	local v9 = p7.spec_fertilizingCultivator
	local v10 = p7.spec_cultivator
	local v11 = p7.spec_sprayer
	local v12, _, v13 = getWorldTranslation(p8.start)
	local v14, _, v15 = getWorldTranslation(p8.width)
	local v16, _, v17 = getWorldTranslation(p8.height)
	local v18 = v10.workAreaParameters
	local v19 = v11.workAreaParameters
	if (v11.isSlurryTanker and g_currentMission.missionInfo.helperSlurrySource == 1 or (v11.isManureSpreader and g_currentMission.missionInfo.helperManureSource == 1 or v11.isFertilizerSprayer and not g_currentMission.missionInfo.helperBuyFertilizer)) and p7:getIsAIActive() then
		if v19.sprayFillType == nil or v19.sprayFillType == FillType.UNKNOWN then
			if v19.lastAIHasSprayed ~= nil then
				p7.rootVehicle:stopCurrentAIJob(AIMessageErrorOutOfFill.new())
				v19.lastAIHasSprayed = nil
			end
		else
			v19.lastAIHasSprayed = true
		end
	end
	local v20 = SprayType.FERTILIZER
	if v19.sprayFillLevel <= 0 or v9.needsSetIsTurnedOn and not p7:getIsTurnedOn() then
		v20 = nil
	end
	local v21, v22
	if v10.isEnabled then
		if v10.useDeepMode then
			local v23
			v23, v21 = FSDensityMapUtil.updateCultivatorArea(v12, v13, v14, v15, v16, v17, not v18.limitToField, v18.limitFruitDestructionToField, v18.angle, v20)
			v22 = v23 + FSDensityMapUtil.updateVineCultivatorArea(v12, v13, v14, v15, v16, v17)
		else
			local v24
			v24, v21 = FSDensityMapUtil.updateDiscHarrowArea(v12, v13, v14, v15, v16, v17, not v18.limitToField, v18.limitFruitDestructionToField, v18.angle, v20)
			v22 = v24 + FSDensityMapUtil.updateVineCultivatorArea(v12, v13, v14, v15, v16, v17)
		end
		v18.lastChangedArea = v18.lastChangedArea + v22
		v18.lastTotalArea = v18.lastTotalArea + v21
		v18.lastStatsArea = v18.lastStatsArea + v22
	else
		v22 = 0
		v21 = 0
	end
	if v10.isSubsoiler then
		FSDensityMapUtil.updateSubsoilerArea(v12, v13, v14, v15, v16, v17)
	end
	FSDensityMapUtil.eraseTireTrack(v12, v13, v14, v15, v16, v17)
	if v20 ~= nil then
		local v25 = v11.doubledAmountIsActive and 2 or 1
		local v26, v27 = FSDensityMapUtil.updateSprayArea(v12, v13, v14, v15, v16, v17, v20, v25)
		v19.lastChangedArea = v19.lastChangedArea + v26
		v19.lastTotalArea = v19.lastTotalArea + v27
		v19.lastStatsArea = 0
		v19.isActive = true
	end
	v10.isWorking = p7:getLastSpeed() > 0.5
	return v22, v21
end
function FertilizingCultivator.setSprayerAITerrainDetailProhibitedRange(p28, _, p29)
	if p28.addAITerrainDetailProhibitedRange ~= nil then
		p28:clearAITerrainDetailProhibitedRange()
		local v30 = g_sprayTypeManager:getSprayTypeByFillTypeIndex(p29)
		if v30 ~= nil then
			local v31 = g_currentMission
			local v32, v33, v34 = v31.fieldGroundSystem:getDensityMapData(FieldDensityMap.SPRAY_TYPE)
			local v35, v36, v37 = v31.fieldGroundSystem:getDensityMapData(FieldDensityMap.SPRAY_LEVEL)
			local v38 = v31.fieldGroundSystem:getMaxValue(FieldDensityMap.SPRAY_LEVEL)
			p28:addAIFruitProhibitions(0, v30.sprayGroundType, v30.sprayGroundType, v32, v33, v34)
			p28:addAIFruitProhibitions(0, v38, v38, v35, v36, v37)
		end
	end
end

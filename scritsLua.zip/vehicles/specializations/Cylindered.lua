Cylindered = {}
Cylindered.DIRTY_COLLISION_UPDATE_CHECK = false
Cylindered.MOVING_TOOL_SEND_MIN_RESOLUTION = 0.006981317007977318
Cylindered.MOVING_TOOLS_XML_KEYS = { "vehicle.cylindered.movingTools", "vehicle.cylindered.cylinderedConfigurations.cylinderedConfiguration(?).movingTools" }
Cylindered.MOVING_PART_XML_KEYS = { "vehicle.cylindered.movingParts.movingPart(?)", "vehicle.cylindered.cylinderedConfigurations.cylinderedConfiguration(?).movingParts.movingPart(?)" }
Cylindered.DASHBOARD_XML_KEYS = { "vehicle.cylindered.dashboards", "vehicle.cylindered.cylinderedConfigurations.cylinderedConfiguration(?).dashboards" }
Cylindered.SOUND_TYPE_EVENT = 0
Cylindered.SOUND_TYPE_CONTINUES = 1
Cylindered.SOUND_TYPE_ENDING = 2
Cylindered.SOUND_TYPE_STARTING = 3
Cylindered.SOUND_ACTION_TRANSLATING_END = 0
Cylindered.SOUND_ACTION_TRANSLATING_END_POS = 1
Cylindered.SOUND_ACTION_TRANSLATING_END_NEG = 2
Cylindered.SOUND_ACTION_TRANSLATING_START = 3
Cylindered.SOUND_ACTION_TRANSLATING_START_POS = 4
Cylindered.SOUND_ACTION_TRANSLATING_START_NEG = 5
Cylindered.SOUND_ACTION_TRANSLATING_POS = 6
Cylindered.SOUND_ACTION_TRANSLATING_NEG = 7
Cylindered.SOUND_ACTION_TOOL_MOVE_END = 8
Cylindered.SOUND_ACTION_TOOL_MOVE_END_POS = 9
Cylindered.SOUND_ACTION_TOOL_MOVE_END_NEG = 10
Cylindered.SOUND_ACTION_TOOL_MOVE_END_POS_LIMIT = 11
Cylindered.SOUND_ACTION_TOOL_MOVE_END_NEG_LIMIT = 12
Cylindered.SOUND_ACTION_TOOL_MOVE_START = 13
Cylindered.SOUND_ACTION_TOOL_MOVE_START_POS = 14
Cylindered.SOUND_ACTION_TOOL_MOVE_START_NEG = 15
Cylindered.SOUND_ACTION_TOOL_MOVE_START_POS_LIMIT = 16
Cylindered.SOUND_ACTION_TOOL_MOVE_START_NEG_LIMIT = 17
Cylindered.SOUND_ACTION_TOOL_MOVE_POS = 18
Cylindered.SOUND_ACTION_TOOL_MOVE_NEG = 19
function Cylindered.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(VehicleSettings, p1)
end
function Cylindered.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("cylindered", g_i18n:getText("shop_configuration"), "cylindered", VehicleConfigurationItem)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Cylindered")
	v2:register(XMLValueType.TIME, "vehicle.cylindered.movingTools#powerConsumingActiveTimeOffset", "Power consumer deactivation delay. After the moving tool has not been moved this long it will no longer consume power.", 5)
	Cylindered.registerSoundXMLPaths(v2, "vehicle.cylindered.sounds")
	Cylindered.registerSoundXMLPaths(v2, "vehicle.cylindered.cylinderedConfigurations.cylinderedConfiguration(?).sounds")
	for _, v3 in ipairs(Cylindered.MOVING_TOOLS_XML_KEYS) do
		Cylindered.registerMovingToolXMLPaths(v2, v3 .. ".movingTool(?)")
		Cylindered.registerEasyArmControlXMLPaths(v2, v3 .. ".easyArmControl")
		v2:register(XMLValueType.L10N_STRING, v3 .. ".controlGroups.controlGroup(?)#name", "Control group name")
	end
	for _, v4 in ipairs(Cylindered.MOVING_PART_XML_KEYS) do
		Cylindered.registerMovingPartXMLPaths(v2, v4)
	end
	v2:addDelayedRegistrationFunc("Cylindered:movingPart", function(p5, p6)
		p5:register(XMLValueType.INT, p6 .. "#inputAttacherJointIndex", "Input Attacher Joint Index [1..n]")
	end)
	for _, v7 in ipairs(Cylindered.DASHBOARD_XML_KEYS) do
		Dashboard.registerDashboardXMLPaths(v2, v7, { "movingTool" })
		v2:register(XMLValueType.STRING, v7 .. ".dashboard(?)#axis", "Moving tool input action name")
		v2:register(XMLValueType.INT, v7 .. ".dashboard(?)#attacherJointIndex", "Index of attacher joint that has to be connected")
		v2:register(XMLValueType.NODE_INDEX, v7 .. ".dashboard(?)#attacherJointNode", "Node of attacher joint that has to be connected")
		v2:register(XMLValueType.NODE_INDICES, v7 .. ".dashboard(?)#attacherJointNodes", "List of attacher joints nodes that has to be connected (on of them)")
	end
	ObjectChangeUtil.addAdditionalObjectChangeXMLPaths(v2, function(p8, p9)
		p8:register(XMLValueType.ANGLE, p9 .. "#movingToolRotMaxActive", "Moving tool max. rotation if object change active")
		p8:register(XMLValueType.ANGLE, p9 .. "#movingToolRotMaxInactive", "Moving tool max. rotation if object change inactive")
		p8:register(XMLValueType.ANGLE, p9 .. "#movingToolRotMinActive", "Moving tool min. rotation if object change active")
		p8:register(XMLValueType.ANGLE, p9 .. "#movingToolRotMinInactive", "Moving tool min. rotation if object change inactive")
		p8:register(XMLValueType.ANGLE, p9 .. "#movingToolStartRotActive", "Moving tool start rotation if object change inactive")
		p8:register(XMLValueType.ANGLE, p9 .. "#movingToolStartRotInactive", "Moving tool start rotation if object change inactive")
		p8:register(XMLValueType.FLOAT, p9 .. "#movingToolTransMaxActive", "Moving tool max. translation if object change active")
		p8:register(XMLValueType.FLOAT, p9 .. "#movingToolTransMaxInactive", "Moving tool max. translation if object change inactive")
		p8:register(XMLValueType.FLOAT, p9 .. "#movingToolTransMinActive", "Moving tool min. translation if object change active")
		p8:register(XMLValueType.FLOAT, p9 .. "#movingToolTransMinInactive", "Moving tool min. translation if object change inactive")
		p8:register(XMLValueType.FLOAT, p9 .. "#movingToolStartTransActive", "Moving tool start translation if object change inactive")
		p8:register(XMLValueType.FLOAT, p9 .. "#movingToolStartTransInactive", "Moving tool start translation if object change inactive")
		p8:register(XMLValueType.BOOL, p9 .. "#movingPartUpdateActive", "moving part active state if object change active")
		p8:register(XMLValueType.BOOL, p9 .. "#movingPartUpdateInactive", "moving part active state if object change inactive")
	end)
	v2:register(XMLValueType.NODE_INDEX, Dischargeable.DISCHARGE_NODE_XML_PATH .. ".movingToolActivation#node", "Moving tool node")
	v2:register(XMLValueType.BOOL, Dischargeable.DISCHARGE_NODE_XML_PATH .. ".movingToolActivation#isInverted", "Activation is inverted", false)
	v2:register(XMLValueType.FLOAT, Dischargeable.DISCHARGE_NODE_XML_PATH .. ".movingToolActivation#openFactor", "Open factor", 1)
	v2:register(XMLValueType.FLOAT, Dischargeable.DISCHARGE_NODE_XML_PATH .. ".movingToolActivation#openOffset", "Open offset", 0)
	v2:register(XMLValueType.NODE_INDEX, Dischargeable.DISCHARGE_NODE_CONFIG_XML_PATH .. ".movingToolActivation#node", "Moving tool node")
	v2:register(XMLValueType.BOOL, Dischargeable.DISCHARGE_NODE_CONFIG_XML_PATH .. ".movingToolActivation#isInverted", "Activation is inverted", false)
	v2:register(XMLValueType.FLOAT, Dischargeable.DISCHARGE_NODE_CONFIG_XML_PATH .. ".movingToolActivation#openFactor", "Open factor", 1)
	v2:register(XMLValueType.FLOAT, Dischargeable.DISCHARGE_NODE_CONFIG_XML_PATH .. ".movingToolActivation#openOffset", "Open offset", 0)
	v2:register(XMLValueType.NODE_INDEX, Shovel.SHOVEL_NODE_XML_KEY .. ".movingToolActivation#node", "Moving tool node")
	v2:register(XMLValueType.BOOL, Shovel.SHOVEL_NODE_XML_KEY .. ".movingToolActivation#isInverted", "Activation is inverted", false)
	v2:register(XMLValueType.FLOAT, Shovel.SHOVEL_NODE_XML_KEY .. ".movingToolActivation#openFactor", "Open factor", 1)
	v2:register(XMLValueType.NODE_INDEX, DynamicMountAttacher.DYNAMIC_MOUNT_GRAB_XML_PATH .. ".movingToolActivation#node", "Moving tool node")
	v2:register(XMLValueType.BOOL, DynamicMountAttacher.DYNAMIC_MOUNT_GRAB_XML_PATH .. ".movingToolActivation#isInverted", "Activation is inverted", false)
	v2:register(XMLValueType.FLOAT, DynamicMountAttacher.DYNAMIC_MOUNT_GRAB_XML_PATH .. ".movingToolActivation#openFactor", "Open factor", 1)
	v2:addDelayedRegistrationFunc("AnimatedVehicle:part", function(p10, p11)
		p10:register(XMLValueType.NODE_INDEX, p11 .. "#startReferencePoint", "Start reference point")
		p10:register(XMLValueType.NODE_INDEX, p11 .. "#endReferencePoint", "End reference point")
	end)
	v2:setXMLSpecializationType()
	local v12 = Vehicle.xmlSchemaSavegame
	v12:register(XMLValueType.FLOAT, "vehicles.vehicle(?).cylindered.movingTool(?)#translation", "Current translation value")
	v12:register(XMLValueType.ANGLE, "vehicles.vehicle(?).cylindered.movingTool(?)#rotation", "Current rotation in rad")
	v12:register(XMLValueType.FLOAT, "vehicles.vehicle(?).cylindered.movingTool(?)#animationTime", "Current animation time")
end
function Cylindered.registerSoundXMLPaths(p13, p14)
	SoundManager.registerSampleXMLPaths(p13, p14, "hydraulic")
	SoundManager.registerSampleXMLPaths(p13, p14, "actionSound(?)")
	p13:register(XMLValueType.STRING, p14 .. ".actionSound(?)#actionNames", "Target actions on given nodes")
	p13:register(XMLValueType.STRING, p14 .. ".actionSound(?)#nodes", "Nodes that can activate this sound on given action events")
	p13:register(XMLValueType.FLOAT, p14 .. ".actionSound(?).pitch#dropOffFactor", "Factor that is applied to pitch while drop off time is active", 1)
	p13:register(XMLValueType.FLOAT, p14 .. ".actionSound(?).pitch#dropOffTime", "After this time the sound will be deactivated", 0)
end
function Cylindered.registerEasyArmControlXMLPaths(p15, p16)
	p15:register(XMLValueType.NODE_INDEX, p16 .. "#rootNode", "Root node")
	p15:register(XMLValueType.NODE_INDEX, p16 .. "#node", "Node")
	p15:register(XMLValueType.NODE_INDEX, p16 .. "#targetNodeZ", "Z target node")
	p15:register(XMLValueType.NODE_INDEX, p16 .. "#refNode", "Reference node")
	p15:register(XMLValueType.FLOAT, p16 .. "#maxTotalDistance", "Max. total distance the arms can move from rootNode", "automatically calculated")
	p15:register(XMLValueType.FLOAT, p16 .. ".targetMovement#speed", "Target node move speed", 1)
	p15:register(XMLValueType.FLOAT, p16 .. ".targetMovement#acceleration", "Target node move acceleration", 50)
	p15:register(XMLValueType.FLOAT, p16 .. ".zTranslationNodes#minMoveRatio", "Min. ratio between translation and rotation movement [0: only rotation, 1: only translation]", 0.2)
	p15:register(XMLValueType.FLOAT, p16 .. ".zTranslationNodes#maxMoveRatio", "Max. ratio between translation and rotation movement [0: only rotation, 1: only translation]", 0.8)
	p15:register(XMLValueType.FLOAT, p16 .. ".zTranslationNodes#moveRatioMinDir", "Defines direction value when the translation parts start to move", 0)
	p15:register(XMLValueType.FLOAT, p16 .. ".zTranslationNodes#moveRatioMaxDir", "Defines direction value when the rotation parts stop to move", 1)
	p15:register(XMLValueType.BOOL, p16 .. ".zTranslationNodes#allowNegativeTrans", "Allow translation movement if translation parts are pointing towards the root node", false)
	p15:register(XMLValueType.FLOAT, p16 .. ".zTranslationNodes#minNegativeTrans", "Min. translation percentage when moving the translation parts into negative direction while they are pointing towards the root node", 0)
	p15:register(XMLValueType.NODE_INDEX, p16 .. ".zTranslationNodes.zTranslationNode(?)#node", "Z translation node")
	p15:register(XMLValueType.NODE_INDEX, p16 .. ".xRotationNodes.xRotationNode1#node", "X translation node")
	p15:register(XMLValueType.NODE_INDEX, p16 .. ".xRotationNodes.xRotationNode2#node", "X translation node")
end
function Cylindered.registerMovingToolXMLPaths(p17, p18)
	p17:addDelayedRegistrationPath(p18, "Cylindered:movingTool")
	p17:register(XMLValueType.NODE_INDEX, p18 .. "#node", "Node")
	p17:register(XMLValueType.BOOL, p18 .. "#isEasyControlTarget", "Is easy control target", false)
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#rotSpeed", "Rotation speed")
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#rotAcceleration", "Rotation acceleration")
	p17:register(XMLValueType.INT, p18 .. ".rotation#rotationAxis", "Rotation axis", 1)
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#rotMax", "Max. rotation")
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#rotMin", "Min. rotation")
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#startRot", "Start rotation")
	p17:register(XMLValueType.BOOL, p18 .. ".rotation#syncMaxRotLimits", "Synchronize max. rotation limits", false)
	p17:register(XMLValueType.BOOL, p18 .. ".rotation#syncMinRotLimits", "Synchronize min. rotation limits", false)
	p17:register(XMLValueType.INT, p18 .. ".rotation#rotSendNumBits", "Number of bits to synchronize", "automatically calculated by rotation range")
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#attachRotMax", "Max. rotation value set during attach")
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#attachRotMin", "Min. rotation value set during attach")
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#detachingRotMaxLimit", "Max. rotation to detach vehicle")
	p17:register(XMLValueType.ANGLE, p18 .. ".rotation#detachingRotMinLimit", "Min. rotation to detach vehicle")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#transSpeed", "Translation speed")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#transAcceleration", "Translation acceleration")
	p17:register(XMLValueType.INT, p18 .. ".translation#translationAxis", "Translation axis")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#transMax", "Max. translation")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#transMin", "Min. translation")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#startTrans", "Start translation")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#attachTransMax", "Max. translation value set during attach")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#attachTransMin", "Min. translation value set during attach")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#detachingTransMaxLimit", "Max. translation to detach vehicle")
	p17:register(XMLValueType.FLOAT, p18 .. ".translation#detachingTransMinLimit", "Min. translation to detach vehicle")
	p17:register(XMLValueType.BOOL, p18 .. "#playSound", "Play sound", false)
	p17:register(XMLValueType.STRING, p18 .. ".animation#animName", "Animation name")
	p17:register(XMLValueType.FLOAT, p18 .. ".animation#animSpeed", "Animation speed")
	p17:register(XMLValueType.FLOAT, p18 .. ".animation#animAcceleration", "Animation acceleration")
	p17:register(XMLValueType.INT, p18 .. ".animation#animSendNumBits", "Number of bits to synchronize", 8)
	p17:register(XMLValueType.FLOAT, p18 .. ".animation#animMaxTime", "Animation max. time", 1)
	p17:register(XMLValueType.FLOAT, p18 .. ".animation#animMinTime", "Animation min. time", 0)
	p17:register(XMLValueType.FLOAT, p18 .. ".animation#animStartTime", "Animation start time")
	p17:register(XMLValueType.STRING, p18 .. ".controls#iconName", "Icon identifier")
	p17:registerAutoCompletionDataSource(p18 .. ".controls#iconName", "$dataS/axisIcons.xml", "axisIcons.icon#name")
	p17:register(XMLValueType.INT, p18 .. ".controls#groupIndex", "Control group index", 0)
	p17:register(XMLValueType.STRING, p18 .. ".controls#axis", "Input action name")
	p17:register(XMLValueType.BOOL, p18 .. ".controls#invertAxis", "Invert input axis", false)
	p17:register(XMLValueType.FLOAT, p18 .. ".controls#mouseSpeedFactor", "Mouse speed factor", 1)
	p17:register(XMLValueType.BOOL, p18 .. "#allowSaving", "Allow saving", true)
	p17:register(XMLValueType.FLOAT, p18 .. "#aiActivePosition", "Position of the moving tool (trans, rot, anim) while the AI is active [0-1]. Position will then be enforced when the AI starts to work.")
	p17:register(XMLValueType.BOOL, p18 .. "#isIntitialDirty", "Is initial dirty", true)
	p17:register(XMLValueType.NODE_INDEX, p18 .. "#delayedNode", "Delayed node")
	p17:register(XMLValueType.INT, p18 .. "#delayedFrames", "Delayed frames", 3)
	p17:register(XMLValueType.BOOL, p18 .. "#isConsumingPower", "While tool is moving the power consumer is set active", false)
	p17:register(XMLValueType.NODE_INDEX, p18 .. ".dependentPart(?)#node", "Dependent part")
	p17:register(XMLValueType.STRING, p18 .. ".dependentPart(?)#maxUpdateDistance", "Max. distance to vehicle root to update dependent part (\'-\' means unlimited)", "-")
	p17:register(XMLValueType.VECTOR_N, p18 .. "#wheelIndices", "List of wheel indices to update")
	p17:register(XMLValueType.STRING, p18 .. "#wheelNodes", "List of wheel nodes to update")
	p17:register(XMLValueType.BOOL, p18 .. ".inputAttacherJoint#value", "Update input attacher joint")
	p17:register(XMLValueType.VECTOR_N, p18 .. ".attacherJoint#jointIndices", "List of attacher joints to update")
	p17:register(XMLValueType.BOOL, p18 .. ".attacherJoint#ignoreWarning", "No warning is printed if the joint index is not available (due to configurations)", false)
	p17:register(XMLValueType.INT, p18 .. "#fillUnitIndex", "Fill unit index")
	p17:register(XMLValueType.FLOAT, p18 .. "#minFillLevel", "Min. fill level")
	p17:register(XMLValueType.FLOAT, p18 .. "#maxFillLevel", "Max. fill level")
	p17:register(XMLValueType.FLOAT, p18 .. "#foldMinLimit", "Min. fold time", 0)
	p17:register(XMLValueType.FLOAT, p18 .. "#foldMaxLimit", "Max. fold time", 1)
	Cylindered.registerDependentComponentJointXMLPaths(p17, p18)
	Cylindered.registerDependentAnimationXMLPaths(p17, p18)
	Cylindered.registerDependentMovingToolXMLPaths(p17, p18)
end
function Cylindered.registerMovingPartXMLPaths(p19, p20)
	p19:addDelayedRegistrationPath(p20, "Cylindered:movingPart")
	p19:register(XMLValueType.NODE_INDEX, p20 .. "#node", "Node")
	p19:register(XMLValueType.NODE_INDEX, p20 .. "#referenceFrame", "Reference frame")
	p19:register(XMLValueType.NODE_INDEX, p20 .. "#referencePoint", "Reference point")
	p19:register(XMLValueType.NODE_INDICES, p20 .. "#referencePoints", "List of reference points (average position will be used as reference)")
	p19:register(XMLValueType.BOOL, p20 .. "#invertZ", "Invert Z axis", false)
	p19:register(XMLValueType.BOOL, p20 .. "#scaleZ", "Allow Z axis scaling", false)
	p19:register(XMLValueType.INT, p20 .. "#limitedAxis", "Limited axis")
	p19:register(XMLValueType.BOOL, p20 .. "#isActiveDirty", "Part is permanently updated", false)
	p19:register(XMLValueType.BOOL, p20 .. "#playSound", "Play hydraulic sound", false)
	p19:register(XMLValueType.BOOL, p20 .. "#moveToReferenceFrame", "Move to reference frame", false)
	p19:register(XMLValueType.BOOL, p20 .. "#doLineAlignment", "Do line alignment (line as ref point)", false)
	p19:register(XMLValueType.BOOL, p20 .. "#doInversedLineAlignment", "Do inversed line alignment (line inside part and fixed ref point)", false)
	p19:register(XMLValueType.BOOL, p20 .. "#do3DLineAlignment", "Do 3D line alignment (X and Y rotation is aligned to the given line - line is only allowed to have two points!)", false)
	p19:register(XMLValueType.FLOAT, p20 .. ".orientationLine#partLength", "Part length (Distance from part to line)", 0.5)
	p19:register(XMLValueType.NODE_INDEX, p20 .. ".orientationLine#referenceTransNode", "Node that is moved to the current line position and at the same time is used a referencePoint for the directional alignment of the movingPart")
	p19:register(XMLValueType.NODE_INDEX, p20 .. ".orientationLine#partLengthNode", "Node to measure the part length dynamically")
	p19:register(XMLValueType.NODE_INDEX, p20 .. ".orientationLine.lineNode(?)#node", "Line node")
	p19:register(XMLValueType.BOOL, p20 .. "#doDirectionAlignment", "Do direction alignment", true)
	p19:register(XMLValueType.BOOL, p20 .. "#doRotationAlignment", "Do rotation alignment", false)
	p19:register(XMLValueType.FLOAT, p20 .. "#rotMultiplier", "Rotation multiplier for rotation alignment", 0)
	p19:register(XMLValueType.ANGLE, p20 .. "#minRot", "Min. rotation for limited axis")
	p19:register(XMLValueType.ANGLE, p20 .. "#maxRot", "Max. rotation for limited axis")
	p19:register(XMLValueType.BOOL, p20 .. "#alignToWorldY", "Align part to world Y axis", false)
	p19:register(XMLValueType.NODE_INDEX, p20 .. "#localReferencePoint", "Local reference point")
	p19:register(XMLValueType.NODE_INDEX, p20 .. "#referenceDistancePoint", "Z translation will be used as reference distance")
	p19:register(XMLValueType.FLOAT, p20 .. "#referenceDistance", "Reference distance to be used instead of the current distance in the i3d (distance between node and ref point - or local ref point and ref point)")
	p19:register(XMLValueType.FLOAT, p20 .. "#localReferenceDistance", "Predefined reference distance", "calculated automatically")
	p19:register(XMLValueType.BOOL, p20 .. "#updateLocalReferenceDistance", "Update distance to local reference point", false)
	p19:register(XMLValueType.BOOL, p20 .. "#dynamicLocalReferenceDistance", "Local reference distance will be calculated based on the initial distance and the localReferencePoint direction", false)
	p19:register(XMLValueType.BOOL, p20 .. "#localReferenceTranslate", "Translate to local reference node", false)
	p19:register(XMLValueType.FLOAT, p20 .. "#referenceDistanceThreshold", "Distance threshold to update moving part while isActiveDirty", 0.0001)
	p19:register(XMLValueType.BOOL, p20 .. "#useLocalOffset", "Use local offset", false)
	p19:register(XMLValueType.FLOAT, p20 .. "#directionThreshold", "Direction threshold to update part if vehicle is inactive", 0.0001)
	p19:register(XMLValueType.FLOAT, p20 .. "#directionThresholdActive", "Direction threshold to update part if vehicle is inactive", 0.0001)
	p19:register(XMLValueType.STRING, p20 .. "#maxUpdateDistance", "Max. distance to vehicle root while isActiveDirty is set (\'-\' means unlimited)")
	p19:register(XMLValueType.BOOL, p20 .. "#smoothedDirectionScale", "If moving part is deactivated e.g. due to folding limits the direction is slowly interpolated back to the start direction depending on #smoothedDirectionTime", false)
	p19:register(XMLValueType.TIME, p20 .. "#smoothedDirectionTime", "Defines how low it takes until the part is back in original direction (sec.)", 2)
	p19:register(XMLValueType.BOOL, p20 .. "#debug", "Enables debug rendering for this part", false)
	p19:register(XMLValueType.NODE_INDEX, p20 .. ".dependentPart(?)#node", "Dependent part")
	p19:register(XMLValueType.STRING, p20 .. ".dependentPart(?)#maxUpdateDistance", "Max. distance to vehicle root to update dependent part (\'-\' means unlimited)", "-")
	p19:register(XMLValueType.BOOL, p20 .. "#divideTranslatingDistance", "If true all translating parts will move at the same time. If false they start to move in the order from the xml", true)
	p19:register(XMLValueType.NODE_INDEX, p20 .. ".translatingPart(?)#node", "Translating part")
	p19:register(XMLValueType.FLOAT, p20 .. ".translatingPart(?)#referenceDistance", "Reference distance")
	p19:register(XMLValueType.FLOAT, p20 .. ".translatingPart(?)#minZTrans", "Min. Z Translation")
	p19:register(XMLValueType.FLOAT, p20 .. ".translatingPart(?)#maxZTrans", "Max. Z Translation")
	p19:register(XMLValueType.BOOL, p20 .. ".translatingPart(?)#divideTranslatingDistance", "Define individual division per translating part. E.g. one part is extending without division and two other parts extend afterwards at the same speed.", "movingPart#divideTranslatingDistance")
	p19:register(XMLValueType.VECTOR_N, p20 .. "#wheelIndices", "List of wheel indices to update")
	p19:register(XMLValueType.STRING, p20 .. "#wheelNodes", "List of wheel nodes to update")
	p19:register(XMLValueType.BOOL, p20 .. ".inputAttacherJoint#value", "Update input attacher joint")
	p19:register(XMLValueType.VECTOR_N, p20 .. ".attacherJoint#jointIndices", "List of attacher joints to update")
	p19:register(XMLValueType.BOOL, p20 .. ".attacherJoint#ignoreWarning", "No warning is printed if the joint index is not available (due to configurations)", false)
	Cylindered.registerDependentComponentJointXMLPaths(p19, p20)
	Cylindered.registerCopyLocalDirectionXMLPaths(p19, p20)
	Cylindered.registerDependentAnimationXMLPaths(p19, p20)
	Cylindered.registerDependentMovingToolXMLPaths(p19, p20)
end
function Cylindered.registerDependentComponentJointXMLPaths(p21, p22)
	p21:register(XMLValueType.INT, p22 .. ".componentJoint(?)#index", "Dependent component joint index")
	p21:register(XMLValueType.BOOL, p22 .. ".componentJoint(?)#ignoreWarning", "Ignore if the index could not be found (due to configurations for example)", false)
	p21:register(XMLValueType.INT, p22 .. ".componentJoint(?)#anchorActor", "Dependent component anchor actor")
end
function Cylindered.registerCopyLocalDirectionXMLPaths(p23, p24)
	p23:register(XMLValueType.NODE_INDEX, p24 .. ".copyLocalDirectionPart(?)#node", "Copy local direction part")
	p23:register(XMLValueType.VECTOR_3, p24 .. ".copyLocalDirectionPart(?)#dirScale", "Direction scale")
	p23:register(XMLValueType.VECTOR_3, p24 .. ".copyLocalDirectionPart(?)#upScale", "Up vector scale")
	Cylindered.registerDependentComponentJointXMLPaths(p23, p24 .. ".copyLocalDirectionPart(?)")
end
function Cylindered.registerDependentAnimationXMLPaths(p25, p26)
	p25:register(XMLValueType.STRING, p26 .. ".dependentAnimation(?)#name", "Dependent animation name")
	p25:register(XMLValueType.INT, p26 .. ".dependentAnimation(?)#translationAxis", "Translation axis")
	p25:register(XMLValueType.INT, p26 .. ".dependentAnimation(?)#rotationAxis", "Rotation axis")
	p25:register(XMLValueType.INT, p26 .. ".dependentAnimation(?)#useTranslatingPartIndex", "Use translation part index")
	p25:register(XMLValueType.FLOAT, p26 .. ".dependentAnimation(?)#minValue", "Min. reference value")
	p25:register(XMLValueType.FLOAT, p26 .. ".dependentAnimation(?)#maxValue", "Max. reference value")
	p25:register(XMLValueType.BOOL, p26 .. ".dependentAnimation(?)#invert", "Invert reference value", false)
end
function Cylindered.registerDependentMovingToolXMLPaths(p27, p28)
	p27:register(XMLValueType.NODE_INDEX, p28 .. ".dependentMovingTool(?)#node", "Dependent part")
	p27:register(XMLValueType.INT, p28 .. ".dependentMovingTool(?)#axis", "Rotation axis of the moving part which is used as reference in the rotationBasedLimits", 1)
	p27:register(XMLValueType.FLOAT, p28 .. ".dependentMovingTool(?)#speedScale", "Speed scale")
	p27:register(XMLValueType.BOOL, p28 .. ".dependentMovingTool(?)#requiresMovement", "Requires movement", false)
	p27:register(XMLValueType.ANGLE, p28 .. ".dependentMovingTool(?).rotationBasedLimits.limit(?)#rotation", "Rotation")
	p27:register(XMLValueType.ANGLE, p28 .. ".dependentMovingTool(?).rotationBasedLimits.limit(?)#rotMin", "Min. rotation")
	p27:register(XMLValueType.ANGLE, p28 .. ".dependentMovingTool(?).rotationBasedLimits.limit(?)#rotMax", "Max. rotation")
	p27:register(XMLValueType.FLOAT, p28 .. ".dependentMovingTool(?).rotationBasedLimits.limit(?)#transMin", "Min. translation")
	p27:register(XMLValueType.FLOAT, p28 .. ".dependentMovingTool(?).rotationBasedLimits.limit(?)#transMax", "Max. translation")
	p27:register(XMLValueType.VECTOR_2, p28 .. ".dependentMovingTool(?)#minTransLimits", "Min. translation limits")
	p27:register(XMLValueType.VECTOR_2, p28 .. ".dependentMovingTool(?)#maxTransLimits", "Max. translation limits")
	p27:register(XMLValueType.VECTOR_ROT_2, p28 .. ".dependentMovingTool(?)#minRotLimits", "Min. rotation limits")
	p27:register(XMLValueType.VECTOR_ROT_2, p28 .. ".dependentMovingTool(?)#maxRotLimits", "Max. rotation limits")
end
function Cylindered.registerEvents(p29)
	SpecializationUtil.registerEvent(p29, "onMovingToolChanged")
end
function Cylindered.registerFunctions(p30)
	SpecializationUtil.registerFunction(p30, "loadMovingPartsFromXML", Cylindered.loadMovingPartsFromXML)
	SpecializationUtil.registerFunction(p30, "loadMovingPartFromXML", Cylindered.loadMovingPartFromXML)
	SpecializationUtil.registerFunction(p30, "loadMovingToolsFromXML", Cylindered.loadMovingToolsFromXML)
	SpecializationUtil.registerFunction(p30, "loadMovingToolFromXML", Cylindered.loadMovingToolFromXML)
	SpecializationUtil.registerFunction(p30, "loadDependentMovingTools", Cylindered.loadDependentMovingTools)
	SpecializationUtil.registerFunction(p30, "loadEasyArmControlFromXML", Cylindered.loadEasyArmControlFromXML)
	SpecializationUtil.registerFunction(p30, "loadDependentParts", Cylindered.loadDependentParts)
	SpecializationUtil.registerFunction(p30, "resolveDependentPartData", Cylindered.resolveDependentPartData)
	SpecializationUtil.registerFunction(p30, "loadDependentComponentJoints", Cylindered.loadDependentComponentJoints)
	SpecializationUtil.registerFunction(p30, "loadDependentAttacherJoints", Cylindered.loadDependentAttacherJoints)
	SpecializationUtil.registerFunction(p30, "loadDependentWheels", Cylindered.loadDependentWheels)
	SpecializationUtil.registerFunction(p30, "loadDependentTranslatingParts", Cylindered.loadDependentTranslatingParts)
	SpecializationUtil.registerFunction(p30, "loadExtraDependentParts", Cylindered.loadExtraDependentParts)
	SpecializationUtil.registerFunction(p30, "loadDependentAnimations", Cylindered.loadDependentAnimations)
	SpecializationUtil.registerFunction(p30, "loadCopyLocalDirectionParts", Cylindered.loadCopyLocalDirectionParts)
	SpecializationUtil.registerFunction(p30, "loadRotationBasedLimits", Cylindered.loadRotationBasedLimits)
	SpecializationUtil.registerFunction(p30, "loadActionSoundsFromXML", Cylindered.loadActionSoundsFromXML)
	SpecializationUtil.registerFunction(p30, "checkMovingPartDirtyUpdateNode", Cylindered.checkMovingPartDirtyUpdateNode)
	SpecializationUtil.registerFunction(p30, "updateDirtyMovingParts", Cylindered.updateDirtyMovingParts)
	SpecializationUtil.registerFunction(p30, "setMovingToolDirty", Cylindered.setMovingToolDirty)
	SpecializationUtil.registerFunction(p30, "setMovingPartReferenceNode", Cylindered.setMovingPartReferenceNode)
	SpecializationUtil.registerFunction(p30, "updateMovingPartByNode", Cylindered.updateMovingPartByNode)
	SpecializationUtil.registerFunction(p30, "updateCylinderedInitial", Cylindered.updateCylinderedInitial)
	SpecializationUtil.registerFunction(p30, "allowLoadMovingToolStates", Cylindered.allowLoadMovingToolStates)
	SpecializationUtil.registerFunction(p30, "getMovingToolByNode", Cylindered.getMovingToolByNode)
	SpecializationUtil.registerFunction(p30, "getMovingPartByNode", Cylindered.getMovingPartByNode)
	SpecializationUtil.registerFunction(p30, "getTranslatingPartByNode", Cylindered.getTranslatingPartByNode)
	SpecializationUtil.registerFunction(p30, "getIsMovingToolActive", Cylindered.getIsMovingToolActive)
	SpecializationUtil.registerFunction(p30, "getIsMovingPartActive", Cylindered.getIsMovingPartActive)
	SpecializationUtil.registerFunction(p30, "getMovingToolMoveValue", Cylindered.getMovingToolMoveValue)
	SpecializationUtil.registerFunction(p30, "setDelayedData", Cylindered.setDelayedData)
	SpecializationUtil.registerFunction(p30, "updateDelayedTool", Cylindered.updateDelayedTool)
	SpecializationUtil.registerFunction(p30, "updateEasyControl", Cylindered.updateEasyControl)
	SpecializationUtil.registerFunction(p30, "setIsEasyControlActive", Cylindered.setIsEasyControlActive)
	SpecializationUtil.registerFunction(p30, "setEasyControlForcedTransMove", Cylindered.setEasyControlForcedTransMove)
	SpecializationUtil.registerFunction(p30, "updateExtraDependentParts", Cylindered.updateExtraDependentParts)
	SpecializationUtil.registerFunction(p30, "updateDependentAnimations", Cylindered.updateDependentAnimations)
	SpecializationUtil.registerFunction(p30, "updateDependentToolLimits", Cylindered.updateDependentToolLimits)
	SpecializationUtil.registerFunction(p30, "onMovingPartSoundEvent", Cylindered.onMovingPartSoundEvent)
	SpecializationUtil.registerFunction(p30, "updateMovingToolSoundEvents", Cylindered.updateMovingToolSoundEvents)
	SpecializationUtil.registerFunction(p30, "updateControlGroups", Cylindered.updateControlGroups)
end
function Cylindered.registerOverwrittenFunctions(p31)
	SpecializationUtil.registerOverwrittenFunction(p31, "isDetachAllowed", Cylindered.isDetachAllowed)
	SpecializationUtil.registerOverwrittenFunction(p31, "loadObjectChangeValuesFromXML", Cylindered.loadObjectChangeValuesFromXML)
	SpecializationUtil.registerOverwrittenFunction(p31, "setObjectChangeValues", Cylindered.setObjectChangeValues)
	SpecializationUtil.registerOverwrittenFunction(p31, "loadDischargeNode", Cylindered.loadDischargeNode)
	SpecializationUtil.registerOverwrittenFunction(p31, "getDischargeNodeEmptyFactor", Cylindered.getDischargeNodeEmptyFactor)
	SpecializationUtil.registerOverwrittenFunction(p31, "loadShovelNode", Cylindered.loadShovelNode)
	SpecializationUtil.registerOverwrittenFunction(p31, "getShovelNodeIsActive", Cylindered.getShovelNodeIsActive)
	SpecializationUtil.registerOverwrittenFunction(p31, "loadDynamicMountGrabFromXML", Cylindered.loadDynamicMountGrabFromXML)
	SpecializationUtil.registerOverwrittenFunction(p31, "getIsDynamicMountGrabOpened", Cylindered.getIsDynamicMountGrabOpened)
	SpecializationUtil.registerOverwrittenFunction(p31, "setComponentJointFrame", Cylindered.setComponentJointFrame)
	SpecializationUtil.registerOverwrittenFunction(p31, "getAdditionalSchemaText", Cylindered.getAdditionalSchemaText)
	SpecializationUtil.registerOverwrittenFunction(p31, "getWearMultiplier", Cylindered.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p31, "getDoConsumePtoPower", Cylindered.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p31, "getConsumingLoad", Cylindered.getConsumingLoad)
end
function Cylindered.registerEventListeners(p32)
	SpecializationUtil.registerEventListener(p32, "onLoad", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onPostLoad", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onLoadFinished", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onRegisterDashboardValueTypes", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onDelete", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onReadStream", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onWriteStream", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onReadUpdateStream", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onWriteUpdateStream", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onUpdate", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onUpdateTick", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onUpdateEnd", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onPostUpdate", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onPostUpdateTick", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onDraw", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onRegisterActionEvents", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onPostAttach", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onSelect", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onUnselect", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onDeactivate", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onAnimationPartChanged", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onAIImplementStart", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onVehicleSettingChanged", Cylindered)
	SpecializationUtil.registerEventListener(p32, "onRegisterAnimationValueTypes", Cylindered)
end
function Cylindered.onLoad(p33, _)
	local v_u_34 = p33.spec_cylindered
	XMLUtil.checkDeprecatedXMLElements(p33.xmlFile, "vehicle.movingParts", "vehicle.cylindered.movingParts")
	XMLUtil.checkDeprecatedXMLElements(p33.xmlFile, "vehicle.movingTools", "vehicle.cylindered.movingTools")
	XMLUtil.checkDeprecatedXMLElements(p33.xmlFile, "vehicle.cylinderedHydraulicSound", "vehicle.cylindered.sounds.hydraulic")
	XMLUtil.checkDeprecatedXMLElements(p33.xmlFile, "vehicle.cylindered.movingParts#isActiveDirtyTimeOffset")
	XMLUtil.checkDeprecatedXMLElements(p33.xmlFile, "vehicle.cylindered.movingParts.sounds", "vehicle.cylindered.sounds")
	local v35 = p33.configurations.cylindered or 1
	local v36 = string.format("vehicle.cylindered.cylinderedConfigurations.cylinderedConfiguration(%d)", v35 - 1)
	v_u_34.activeDirtyMovingParts = {}
	v_u_34.referenceNodes = {}
	v_u_34.nodesToMovingParts = {}
	v_u_34.movingParts = {}
	p33.anyMovingPartsDirty = false
	v_u_34.detachLockNodes = nil
	p33:loadMovingPartsFromXML(p33.xmlFile, "vehicle.cylindered.movingParts.movingPart")
	p33:loadMovingPartsFromXML(p33.xmlFile, v36 .. ".movingParts.movingPart")
	if Cylindered.DIRTY_COLLISION_UPDATE_CHECK then
		local function v_u_41(p37, p38)
			-- upvalues: (copy) v_u_34, (copy) v_u_41
			table.insert(p38, p37)
			if p37.dependentPartNodes ~= nil then
				for v39 = 1, #p37.dependentPartNodes do
					local v40 = v_u_34.nodesToMovingParts[p37.dependentPartNodes[v39]]
					if v40 ~= nil then
						table.insert(p38, v40)
						v_u_41(v40, p38)
					end
				end
			end
		end
		v_u_34.realActiveDirtyParts = {}
		local function v45(p42, p43, p44)
			if getHasClassId(p42, ClassIds.SHAPE) then
				Logging.xmlError(p43, "Found collision \'%s\' as child of isActiveDirty movingPart \'%s\'. This can cause the vehicle to never sleep!", getName(p42), p44)
			end
		end
		for v46 = 1, #v_u_34.movingParts do
			local v47 = v_u_34.movingParts[v46]
			if v47.isActiveDirty and v47.directionThreshold == 0.0001 then
				v_u_41(v47, v_u_34.realActiveDirtyParts)
			end
		end
		for v48 = 1, #v_u_34.realActiveDirtyParts do
			local v49 = v_u_34.realActiveDirtyParts[v48]
			I3DUtil.checkForChildCollisions(v49.node, v45, p33.xmlFile, getName(v49.node))
		end
	end
	v_u_34.powerConsumingActiveTimeOffset = p33.xmlFile:getValue("vehicle.cylindered.movingTools#powerConsumingActiveTimeOffset", 5)
	v_u_34.powerConsumingTimer = -1
	for _, v50 in pairs(v_u_34.movingParts) do
		p33:resolveDependentPartData(v50.dependentPartData, v_u_34.referenceNodes)
	end
	local function v_u_56(p51, p52, p53)
		-- upvalues: (copy) v_u_56
		for _, v54 in ipairs(p52) do
			if v54 == p51 then
				return
			end
		end
		if p51.isDependentPart ~= true or p53 == true then
			table.insert(p52, p51)
			for _, v55 in pairs(p51.dependentPartData) do
				v_u_56(v55.part, p52, true)
			end
		end
	end
	local v57 = {}
	for _, v58 in ipairs(v_u_34.movingParts) do
		v_u_56(v58, v57)
	end
	v_u_34.movingParts = v57
	v_u_34.controlGroups = {}
	v_u_34.controlGroupMapping = {}
	v_u_34.currentControlGroupIndex = 1
	v_u_34.controlGroupNames = {}
	for _, v59 in ipairs(Cylindered.MOVING_TOOLS_XML_KEYS) do
		for _, v60 in p33.xmlFile:iterator(v59 .. ".controlGroups.controlGroup") do
			local v61 = p33.xmlFile:getValue(v60 .. "#name", "", p33.customEnvironment, false)
			if v61 ~= nil then
				local v62 = v_u_34.controlGroupNames
				table.insert(v62, v61)
			end
		end
	end
	v_u_34.nodesToMovingTools = {}
	v_u_34.movingTools = {}
	p33:loadMovingToolsFromXML(p33.xmlFile, "vehicle.cylindered.movingTools.movingTool")
	p33:loadMovingToolsFromXML(p33.xmlFile, v36 .. ".movingTools.movingTool")
	table.sort(v_u_34.controlGroups, function(p63, p64)
		return p63 < p64
	end)
	for _, v65 in ipairs(v_u_34.controlGroups) do
		local v66 = p33:addSubselection(v65)
		v_u_34.controlGroupMapping[v66] = v65
	end
	for _, v67 in pairs(v_u_34.movingTools) do
		p33:resolveDependentPartData(v67.dependentPartData, v_u_34.referenceNodes)
		for v68 = #v67.dependentMovingTools, 1, -1 do
			local v69 = v67.dependentMovingTools[v68]
			local v70 = v_u_34.nodesToMovingTools[v69.node]
			if v70 == nil then
				Logging.xmlWarning(p33.xmlFile, "Dependent moving tool \'%s\' not defined. Ignoring it!", getName(v69.node))
				table.remove(v67.dependentMovingTools, v68)
			else
				v69.movingTool = v70
			end
		end
	end
	for _, v71 in pairs(v_u_34.movingParts) do
		for v72 = #v71.dependentMovingTools, 1, -1 do
			local v73 = v71.dependentMovingTools[v72]
			local v74 = v_u_34.nodesToMovingTools[v73.node]
			if v74 == nil then
				Logging.xmlWarning(p33.xmlFile, "Dependent moving tool \'%s\' not defined. Ignoring it!", getName(v73.node))
				table.remove(v71.dependentMovingTools, v72)
			else
				v73.movingTool = v74
			end
		end
	end
	v_u_34.referenceNodes = nil
	local v75 = v36 .. ".movingTools.easyArmControl"
	local v76 = not p33.xmlFile:hasProperty(v75) and "vehicle.cylindered.movingTools.easyArmControl" or v75
	if p33.xmlFile:hasProperty(v76) then
		local v77 = {}
		if p33:loadEasyArmControlFromXML(p33.xmlFile, v76, v77) then
			v_u_34.easyArmControl = v77
		end
	end
	if p33.xmlFile:hasProperty(v36) then
		local v78 = DashboardValueType.new("cylindered", "movingTool")
		v78:setXMLKey(v36 .. ".dashboards")
		v78:setValue(p33, Cylindered.getMovingToolDashboardState)
		v78:setRange(0, 1)
		v78:setAdditionalFunctions(Cylindered.movingToolDashboardAttributes, nil)
		v78:setIdleValue(0.5)
		p33:registerDashboardValueType(v78)
	end
	v_u_34.samples = {}
	v_u_34.actionSamples = {}
	if p33.isClient then
		v_u_34.samples.hydraulic = g_soundManager:loadSampleFromXML(p33.xmlFile, v36 .. ".sounds", "hydraulic", p33.baseDirectory, p33.components, 0, AudioGroup.VEHICLE, p33.i3dMappings, p33)
		if v_u_34.samples.hydraulic == nil then
			v_u_34.samples.hydraulic = g_soundManager:loadSampleFromXML(p33.xmlFile, "vehicle.cylindered.sounds", "hydraulic", p33.baseDirectory, p33.components, 0, AudioGroup.VEHICLE, p33.i3dMappings, p33)
		end
		v_u_34.isHydraulicSamplePlaying = false
		v_u_34.nodesToSamples = {}
		v_u_34.activeSamples = {}
		v_u_34.endingSamples = {}
		v_u_34.endingSamplesBySample = {}
		v_u_34.startingSamples = {}
		v_u_34.startingSamplesBySample = {}
		p33:loadActionSoundsFromXML(p33.xmlFile, "vehicle.cylindered.sounds")
		p33:loadActionSoundsFromXML(p33.xmlFile, v36 .. ".sounds")
	end
	v_u_34.cylinderedDirtyFlag = p33:getNextDirtyFlag()
	v_u_34.cylinderedInputDirtyFlag = p33:getNextDirtyFlag()
	p33:registerVehicleSetting(GameSettings.SETTING.EASY_ARM_CONTROL, true)
	v_u_34.isLoading = true
end
function Cylindered.onPostLoad(p_u_79, p80)
	local v81 = p_u_79.spec_cylindered
	for _, v82 in pairs(v81.movingTools) do
		if p_u_79:getIsMovingToolActive(v82) then
			if v82.startRot ~= nil then
				v82.curRot[v82.rotationAxis] = v82.startRot
				local v83 = setRotation
				local v84 = v82.node
				local v85 = v82.curRot
				v83(v84, unpack(v85))
				SpecializationUtil.raiseEvent(p_u_79, "onMovingToolChanged", v82, 0, 0)
			end
			if v82.startTrans ~= nil then
				v82.curTrans[v82.translationAxis] = v82.startTrans
				local v86 = setTranslation
				local v87 = v82.node
				local v88 = v82.curTrans
				v86(v87, unpack(v88))
				SpecializationUtil.raiseEvent(p_u_79, "onMovingToolChanged", v82, 0, 0)
			end
			if v82.animStartTime ~= nil then
				p_u_79:setAnimationTime(v82.animName, v82.animStartTime, nil, false)
				SpecializationUtil.raiseEvent(p_u_79, "onMovingToolChanged", v82, 0, 0)
			end
			if v82.delayedNode ~= nil then
				p_u_79:setDelayedData(v82, true)
			end
			if v82.isIntitialDirty then
				Cylindered.setDirty(p_u_79, v82)
			end
		end
	end
	for _, v89 in pairs(v81.movingParts) do
		p_u_79:loadDependentAttacherJoints(p_u_79.xmlFile, v89.key, v89)
		p_u_79:loadDependentWheels(p_u_79.xmlFile, v89.key, v89)
	end
	for _, v90 in pairs(v81.movingTools) do
		p_u_79:loadDependentAttacherJoints(p_u_79.xmlFile, v90.key, v90)
		p_u_79:loadDependentWheels(p_u_79.xmlFile, v90.key, v90)
	end
	if p_u_79:allowLoadMovingToolStates() and (p80 ~= nil and not p80.resetVehicles) then
		local v91 = 0
		for _, v92 in ipairs(v81.movingTools) do
			if v92.saving then
				if p_u_79:getIsMovingToolActive(v92) then
					local v93 = string.format("%s.cylindered.movingTool(%d)", p80.key, v91)
					local v94 = false
					if v92.transSpeed ~= nil then
						local v95 = p80.xmlFile:getValue(v93 .. "#translation")
						if v95 ~= nil then
							if v92.transMax ~= nil then
								local v96 = v92.transMax
								v95 = math.min(v95, v96)
							end
							if v92.transMin ~= nil then
								local v97 = v92.transMin
								v95 = math.max(v95, v97)
							end
						end
						if v95 ~= nil then
							local v98 = v95 - v92.curTrans[v92.translationAxis]
							if math.abs(v98) > 0.0001 then
								v92.curTrans = { getTranslation(v92.node) }
								v92.curTrans[v92.translationAxis] = v95
								local v99 = setTranslation
								local v100 = v92.node
								local v101 = v92.curTrans
								v99(v100, unpack(v101))
								v94 = true
							end
						end
					end
					if v92.rotSpeed ~= nil then
						local v102 = p80.xmlFile:getValue(v93 .. "#rotation")
						if v102 ~= nil then
							if v92.rotMax ~= nil then
								local v103 = v92.rotMax
								v102 = math.min(v102, v103)
							end
							if v92.rotMin ~= nil then
								local v104 = v92.rotMin
								v102 = math.max(v102, v104)
							end
						end
						if v102 ~= nil then
							local v105 = v102 - v92.curRot[v92.rotationAxis]
							if math.abs(v105) > 0.0001 then
								v92.curRot = { getRotation(v92.node) }
								v92.curRot[v92.rotationAxis] = v102
								local v106 = setRotation
								local v107 = v92.node
								local v108 = v92.curRot
								v106(v107, unpack(v108))
								v94 = true
							end
						end
					end
					if v92.animSpeed ~= nil then
						local v109 = p80.xmlFile:getValue(v93 .. "#animationTime")
						if v109 ~= nil then
							if v92.animMinTime ~= nil then
								local v110 = v92.animMinTime
								v109 = math.max(v109, v110)
							end
							if v92.animMaxTime ~= nil then
								local v111 = v92.animMaxTime
								v109 = math.min(v109, v111)
							end
							v92.curAnimTime = v109
							p_u_79:setAnimationTime(v92.animName, v109, true, false)
						end
					end
					if v94 then
						Cylindered.setDirty(p_u_79, v92)
						SpecializationUtil.raiseEvent(p_u_79, "onMovingToolChanged", v92, 0, 0)
					end
					if v92.delayedNode ~= nil then
						p_u_79:setDelayedData(v92, true)
					end
				end
				v91 = v91 + 1
			end
			for _, v112 in pairs(v92.dependentMovingTools) do
				Cylindered.updateRotationBasedLimits(p_u_79, v92, v112)
			end
		end
	end
	p_u_79:updateEasyControl(9999, true)
	p_u_79:updateCylinderedInitial(false)
	local v113 = #v81.movingTools > 0
	local v114 = #v81.movingParts > 0
	if not v113 then
		SpecializationUtil.removeEventListener(p_u_79, "onReadStream", Cylindered)
		SpecializationUtil.removeEventListener(p_u_79, "onWriteStream", Cylindered)
		SpecializationUtil.removeEventListener(p_u_79, "onReadUpdateStream", Cylindered)
		SpecializationUtil.removeEventListener(p_u_79, "onWriteUpdateStream", Cylindered)
		SpecializationUtil.removeEventListener(p_u_79, "onUpdate", Cylindered)
		if not v114 then
			SpecializationUtil.removeEventListener(p_u_79, "onUpdateTick", Cylindered)
			SpecializationUtil.removeEventListener(p_u_79, "onPostUpdate", Cylindered)
			SpecializationUtil.removeEventListener(p_u_79, "onPostUpdateTick", Cylindered)
		end
	end
	if not (p_u_79.isClient and v113) then
		SpecializationUtil.removeEventListener(p_u_79, "onDraw", Cylindered)
		SpecializationUtil.removeEventListener(p_u_79, "onRegisterActionEvents", Cylindered)
	end
	if g_isDevelopmentVersion then
		local function v_u_118(p_u_115)
			-- upvalues: (copy) p_u_79, (copy) v_u_118
			I3DUtil.iterateRecursively(p_u_115.node, function(p116, _)
				-- upvalues: (ref) p_u_79, (copy) p_u_115
				p_u_79:checkMovingPartDirtyUpdateNode(p116, p_u_115)
			end)
			if p_u_115.dependentPartData ~= nil then
				for _, v117 in pairs(p_u_115.dependentPartData) do
					if v117.part ~= nil then
						v_u_118(v117.part)
					end
				end
			end
		end
		for v119 = 1, #v81.movingParts do
			local v120 = v81.movingParts[v119]
			if v120.isActiveDirty and v120.maxUpdateDistance ~= (1 / 0) then
				v_u_118(v120)
			end
		end
	end
end
function Cylindered.onLoadFinished(p121, _)
	local v122 = p121.spec_cylindered
	v122.isLoading = false
	for v123 = 1, #v122.movingTools do
		local v124 = v122.movingTools[v123]
		if v124.delayedHistoryIndex ~= nil and v124.delayedHistoryIndex > 0 then
			p121:updateDelayedTool(v124, true)
		end
	end
end
function Cylindered.onRegisterDashboardValueTypes(p125)
	local v126 = DashboardValueType.new("cylindered", "movingTool")
	v126:setValue(p125, Cylindered.getMovingToolDashboardState)
	v126:setRange(0, 1)
	v126:setAdditionalFunctions(Cylindered.movingToolDashboardAttributes, nil)
	v126:setIdleValue(0.5)
	p125:registerDashboardValueType(v126)
end
function Cylindered.onDelete(p127)
	local v128 = p127.spec_cylindered
	g_soundManager:deleteSamples(v128.samples)
	g_soundManager:deleteSamples(v128.actionSamples)
	if v128.movingTools ~= nil then
		for _, v129 in pairs(v128.movingTools) do
			if v129.icon ~= nil then
				v129.icon:delete()
				v129.icon = nil
			end
		end
	end
end
function Cylindered.saveToXMLFile(p130, p131, p132, _)
	local v133 = p130.spec_cylindered
	local v134 = 0
	for _, v135 in ipairs(v133.movingTools) do
		if v135.saving then
			local v136 = string.format("%s.movingTool(%d)", p132, v134)
			if v135.transSpeed ~= nil then
				p131:setValue(v136 .. "#translation", v135.curTrans[v135.translationAxis])
			end
			if v135.rotSpeed ~= nil then
				p131:setValue(v136 .. "#rotation", v135.curRot[v135.rotationAxis])
			end
			if v135.animSpeed ~= nil then
				p131:setValue(v136 .. "#animationTime", v135.curAnimTime)
			end
			v134 = v134 + 1
		end
	end
end
function Cylindered.onReadStream(p137, p138, p139)
	local v140 = p137.spec_cylindered
	if p139:getIsServer() and streamReadBool(p138) then
		for v141 = 1, #v140.movingTools do
			local v142 = v140.movingTools[v141]
			if v142.dirtyFlag ~= nil then
				v142.networkTimeInterpolator:reset()
				if v142.transSpeed ~= nil then
					local v143 = streamReadFloat32(p138)
					v142.curTrans[v142.translationAxis] = v143
					local v144 = setTranslation
					local v145 = v142.node
					local v146 = v142.curTrans
					v144(v145, unpack(v146))
					v142.networkInterpolators.translation:setValue(v142.curTrans[v142.translationAxis])
				end
				if v142.rotSpeed ~= nil then
					local v147 = streamReadFloat32(p138)
					v142.curRot[v142.rotationAxis] = v147
					local v148 = setRotation
					local v149 = v142.node
					local v150 = v142.curRot
					v148(v149, unpack(v150))
					v142.networkInterpolators.rotation:setAngle(v147)
				end
				if v142.animSpeed ~= nil then
					local v151 = streamReadFloat32(p138)
					v142.curAnimTime = v151
					p137:setAnimationTime(v142.animName, v142.curAnimTime, nil, false)
					v142.networkInterpolators.animation:setValue(v151)
				end
				if v142.delayedNode ~= nil then
					p137:setDelayedData(v142, true)
				end
				Cylindered.setDirty(p137, v142)
				SpecializationUtil.raiseEvent(p137, "onMovingToolChanged", v142, 0, 0)
			end
		end
	end
end
function Cylindered.onWriteStream(p152, p153, p154)
	local v155 = p152.spec_cylindered
	if not p154:getIsServer() and streamWriteBool(p153, p152:allowLoadMovingToolStates()) then
		for v156 = 1, #v155.movingTools do
			local v157 = v155.movingTools[v156]
			if v157.dirtyFlag ~= nil then
				if v157.transSpeed ~= nil then
					streamWriteFloat32(p153, v157.curTrans[v157.translationAxis])
				end
				if v157.rotSpeed ~= nil then
					streamWriteFloat32(p153, v157.curRot[v157.rotationAxis])
				end
				if v157.animSpeed ~= nil then
					v157.curAnimTime = p152:getAnimationTime(v157.animName)
					streamWriteFloat32(p153, v157.curAnimTime)
				end
			end
		end
	end
end
function Cylindered.onReadUpdateStream(p158, p159, _, p160)
	local v161 = p158.spec_cylindered
	if p160:getIsServer() then
		if streamReadBool(p159) then
			for _, v162 in ipairs(v161.movingTools) do
				if v162.dirtyFlag ~= nil and streamReadBool(p159) then
					v162.networkTimeInterpolator:startNewPhaseNetwork()
					if v162.transSpeed ~= nil then
						local v163 = streamReadFloat32(p159)
						local v164 = v163 - v162.curTrans[v162.translationAxis]
						if math.abs(v164) > 0.0001 then
							v162.networkInterpolators.translation:setTargetValue(v163)
						end
					end
					if v162.rotSpeed ~= nil then
						local v165
						if v162.rotMin == nil or v162.rotMax == nil then
							v165 = NetworkUtil.readCompressedAngle(p159)
						else
							if v162.syncMinRotLimits then
								v162.rotMin = streamReadFloat32(p159)
							end
							if v162.syncMaxRotLimits then
								v162.rotMax = streamReadFloat32(p159)
							end
							v162.networkInterpolators.rotation:setMinMax(v162.rotMin, v162.rotMax)
							v165 = NetworkUtil.readCompressedRange(p159, v162.rotMin, v162.rotMax, v162.rotSendNumBits)
						end
						local v166 = v165 - v162.curRot[v162.rotationAxis]
						if math.abs(v166) > 0.0001 then
							v162.networkInterpolators.rotation:setTargetAngle(v165)
						end
					end
					if v162.animSpeed ~= nil then
						local v167 = streamReadBool(p159)
						local v168 = NetworkUtil.readCompressedRange(p159, v162.animMinTime, v162.animMaxTime, v162.animSendNumBits)
						local v169 = v168 - v162.curAnimTime
						if math.abs(v169) > 0.0001 then
							v162.networkInterpolators.animation:setTargetValue(v168)
							if v167 then
								v162.networkInterpolators.animation:setValue(v168)
							end
						end
					end
				end
			end
		end
	elseif streamReadBool(p159) then
		for _, v170 in ipairs(v161.movingTools) do
			if v170.axisActionIndex ~= nil then
				v170.move = (streamReadUIntN(p159, 12) / 4095 * 2 - 1) * 5
				local v171 = v170.move
				if math.abs(v171) < 0.01 then
					v170.move = 0
				end
			end
		end
		return
	end
end
function Cylindered.onWriteUpdateStream(p172, p173, p174, p175)
	local v176 = p172.spec_cylindered
	if p174:getIsServer() then
		if streamWriteBool(p173, bitAND(p175, v176.cylinderedInputDirtyFlag) ~= 0) then
			for _, v177 in ipairs(v176.movingTools) do
				if v177.axisActionIndex ~= nil then
					local v178 = v177.moveToSend / 5
					local v179 = (math.clamp(v178, -1, 1) + 1) / 2 * 4095
					streamWriteUIntN(p173, v179, 12)
				end
			end
			return
		end
	elseif streamWriteBool(p173, bitAND(p175, v176.cylinderedDirtyFlag) ~= 0) then
		for _, v180 in ipairs(v176.movingTools) do
			if v180.dirtyFlag ~= nil then
				local v181 = streamWriteBool
				local v182
				if bitAND(p175, v180.dirtyFlag) == 0 then
					v182 = false
				else
					v182 = p172:getIsMovingToolActive(v180)
				end
				if v181(p173, v182) then
					if v180.transSpeed ~= nil then
						streamWriteFloat32(p173, v180.curTrans[v180.translationAxis])
					end
					if v180.rotSpeed ~= nil then
						local v183 = v180.curRot[v180.rotationAxis]
						if v180.rotMin == nil or v180.rotMax == nil then
							NetworkUtil.writeCompressedAngle(p173, v183)
						else
							if v180.syncMinRotLimits then
								streamWriteFloat32(p173, v180.rotMin)
							end
							if v180.syncMaxRotLimits then
								streamWriteFloat32(p173, v180.rotMax)
							end
							NetworkUtil.writeCompressedRange(p173, v183, v180.rotMin, v180.rotMax, v180.rotSendNumBits)
						end
					end
					if v180.animSpeed ~= nil then
						local v184 = p172:getAnimationTime(v180.animName)
						local v185 = v184 - v180.curAnimTime
						local v186 = math.abs(v185) > 0.001
						streamWriteBool(p173, v186 or v180.networkInterpolators.resetAnimInterpolation)
						v180.networkInterpolators.resetAnimInterpolation = false
						v180.curAnimTime = v184
						NetworkUtil.writeCompressedRange(p173, v180.curAnimTime, v180.animMinTime, v180.animMaxTime, v180.animSendNumBits)
					end
				end
			end
		end
	end
end
function Cylindered.onUpdate(p187, p188, _, _, _)
	local v189 = p187.spec_cylindered
	v189.movingToolNeedsSound = false
	v189.movingPartNeedsSound = false
	p187:updateEasyControl(p188)
	if p187.isServer then
		for v190 = 1, #v189.movingTools do
			local v191 = v189.movingTools[v190]
			local v192 = 0
			local v193 = 0
			local v194 = 0
			local v195 = p187:getMovingToolMoveValue(v191)
			v191.externalMove = 0
			if v191.curTargetPosition ~= nil then
				local v196 = Cylindered.getMovingToolState(p187, v191) - v191.curTargetPosition
				if math.abs(v196) < 0.001 then
					v191.curTargetPosition = nil
					v191.curTargetDirection = nil
				else
					v195 = v191.curTargetDirection
				end
			end
			if math.abs(v195) > 0 then
				if v191.rotSpeed ~= nil then
					v192 = v195 * v191.rotSpeed
					if v191.rotAcceleration ~= nil then
						local v197 = v192 - v191.lastRotSpeed
						if math.abs(v197) >= v191.rotAcceleration * p188 then
							if v191.lastRotSpeed < v192 then
								v192 = v191.lastRotSpeed + v191.rotAcceleration * p188
							else
								v192 = v191.lastRotSpeed - v191.rotAcceleration * p188
							end
						end
					end
				end
				if v191.transSpeed ~= nil then
					v193 = v195 * v191.transSpeed
					if v191.transAcceleration ~= nil then
						local v198 = v193 - v191.lastTransSpeed
						if math.abs(v198) >= v191.transAcceleration * p188 then
							if v191.lastTransSpeed < v193 then
								v193 = v191.lastTransSpeed + v191.transAcceleration * p188
							else
								v193 = v191.lastTransSpeed - v191.transAcceleration * p188
							end
						end
					end
				end
				if v191.animSpeed ~= nil then
					v194 = v195 * v191.animSpeed
					if v191.animAcceleration ~= nil then
						local v199 = v194 - v191.lastAnimSpeed
						if math.abs(v199) >= v191.animAcceleration * p188 then
							if v191.lastAnimSpeed < v194 then
								v194 = v191.lastAnimSpeed + v191.animAcceleration * p188
							else
								v194 = v191.lastAnimSpeed - v191.animAcceleration * p188
							end
						end
					end
				end
			else
				if v191.rotAcceleration ~= nil then
					if v191.lastRotSpeed < 0 then
						local v200 = v191.lastRotSpeed + v191.rotAcceleration * p188
						v192 = math.min(v200, 0)
					else
						local v201 = v191.lastRotSpeed - v191.rotAcceleration * p188
						v192 = math.max(v201, 0)
					end
				end
				if v191.transAcceleration ~= nil then
					if v191.lastTransSpeed < 0 then
						local v202 = v191.lastTransSpeed + v191.transAcceleration * p188
						v193 = math.min(v202, 0)
					else
						local v203 = v191.lastTransSpeed - v191.transAcceleration * p188
						v193 = math.max(v203, 0)
					end
				end
				if v191.animAcceleration ~= nil then
					if v191.lastAnimSpeed < 0 then
						local v204 = v191.lastAnimSpeed + v191.animAcceleration * p188
						v194 = math.min(v204, 0)
					else
						local v205 = v191.lastAnimSpeed - v191.animAcceleration * p188
						v194 = math.max(v205, 0)
					end
				end
			end
			local v206 = false
			if v192 == nil or v192 == 0 then
				v191.lastRotSpeed = 0
			else
				v206 = v206 or Cylindered.setToolRotation(p187, v191, v192, p188)
			end
			if v193 == nil or v193 == 0 then
				v191.lastTransSpeed = 0
			else
				v206 = v206 or Cylindered.setToolTranslation(p187, v191, v193, p188)
			end
			if v194 == nil or v194 == 0 then
				v191.lastAnimSpeed = 0
			else
				v206 = v206 or Cylindered.setToolAnimation(p187, v191, v194, p188)
			end
			for _, v207 in pairs(v191.dependentMovingTools) do
				if v207.speedScale ~= nil and (not v207.requiresMovement or v206) then
					v207.movingTool.externalMove = v207.movingTool.externalMove + v207.speedScale * v191.move
				end
				Cylindered.updateRotationBasedLimits(p187, v191, v207)
				p187:updateDependentToolLimits(v191, v207)
			end
			if v206 then
				if v191.playSound then
					v189.movingToolNeedsSound = true
				end
				Cylindered.setDirty(p187, v191)
				v191.networkPositionIsDirty = true
				p187:raiseDirtyFlags(v191.dirtyFlag)
				p187:raiseDirtyFlags(v189.cylinderedDirtyFlag)
				v191.networkDirtyNextFrame = true
				if v191.isConsumingPower then
					v189.powerConsumingTimer = v189.powerConsumingActiveTimeOffset
				end
			elseif v191.networkDirtyNextFrame then
				p187:raiseDirtyFlags(v191.dirtyFlag)
				p187:raiseDirtyFlags(v189.cylinderedDirtyFlag)
				v191.networkDirtyNextFrame = nil
			end
		end
	else
		for v208 = 1, #v189.movingTools do
			local v209 = v189.movingTools[v208]
			v209.networkTimeInterpolator:update(p188)
			local v210 = v209.networkTimeInterpolator:getAlpha()
			local v211 = false
			if p187:getIsMovingToolActive(v209) then
				if v209.rotSpeed ~= nil then
					local v212 = v209.networkInterpolators.rotation:getInterpolatedValue(v210)
					local v213 = v212 - v209.curRot[v209.rotationAxis]
					if math.abs(v213) > 0.0001 then
						v209.curRot[v209.rotationAxis] = v212
						setRotation(v209.node, v209.curRot[1], v209.curRot[2], v209.curRot[3])
						v211 = true
					end
				end
				if v209.transSpeed ~= nil then
					local v214 = v209.networkInterpolators.translation:getInterpolatedValue(v210)
					local v215 = v214 - v209.curTrans[v209.translationAxis]
					if math.abs(v215) > 0.0001 then
						v209.curTrans[v209.translationAxis] = v214
						setTranslation(v209.node, v209.curTrans[1], v209.curTrans[2], v209.curTrans[3])
						v211 = true
					end
				end
				if v209.animSpeed ~= nil then
					local v216 = v209.networkInterpolators.animation:getInterpolatedValue(v210)
					local v217 = v216 - v209.curAnimTime
					if math.abs(v217) > 0.0001 then
						v209.curAnimTime = v216
						p187:setAnimationTime(v209.animName, v216, nil, true)
						v211 = true
					end
				end
				if v211 then
					Cylindered.setDirty(p187, v209)
					SpecializationUtil.raiseEvent(p187, "onMovingToolChanged", v209, 0, p188)
				end
			end
			for _, v218 in pairs(v209.dependentMovingTools) do
				if not (v218.movingTool.syncMinRotLimits and v218.movingTool.syncMaxRotLimits) then
					Cylindered.updateRotationBasedLimits(p187, v209, v218)
					p187:updateDependentToolLimits(v209, v218)
				end
			end
			if v209.networkTimeInterpolator:isInterpolating() then
				p187:raiseActive()
			end
		end
	end
	for v219 = 1, #v189.movingTools do
		local v220 = v189.movingTools[v219]
		if v220.delayedHistoryIndex ~= nil and v220.delayedHistoryIndex > 0 then
			p187:updateDelayedTool(v220)
		end
		if v220.smoothedMove ~= 0 and v220.lastInputTime + 50 < g_time then
			v220.smoothedMove = 0
		end
	end
	if v189.powerConsumingTimer > 0 then
		v189.powerConsumingTimer = v189.powerConsumingTimer - p188
	end
	if next(v189.activeSamples) ~= nil then
		p187:raiseActive()
	end
end
function Cylindered.setDelayedData(_, p221, p222)
	local v223, v224, v225 = getTranslation(p221.node)
	local v226, v227, v228 = getRotation(p221.node)
	p221.delayedHistroyData[p221.delayedFrames] = {
		["rot"] = { v226, v227, v228 },
		["trans"] = { v223, v224, v225 }
	}
	if p222 then
		for v229 = 1, p221.delayedFrames - 1 do
			p221.delayedHistroyData[v229] = p221.delayedHistroyData[p221.delayedFrames]
		end
	end
	p221.delayedHistoryIndex = p221.delayedFrames
end
function Cylindered.updateDelayedTool(p230, p231, p232)
	local v233 = p230.spec_cylindered
	if p232 ~= nil and p232 then
		for v234 = 1, p231.delayedFrames - 1 do
			p231.delayedHistroyData[v234] = p231.delayedHistroyData[p231.delayedFrames]
		end
	end
	local v235 = p231.delayedHistroyData[1]
	for v236 = 1, p231.delayedFrames - 1 do
		p231.delayedHistroyData[v236] = p231.delayedHistroyData[v236 + 1]
	end
	local v237 = setRotation
	local v238 = p231.delayedNode
	local v239 = v235.rot
	v237(v238, unpack(v239))
	local v240 = setTranslation
	local v241 = p231.delayedNode
	local v242 = v235.trans
	v240(v241, unpack(v242))
	p231.delayedHistoryIndex = p231.delayedHistoryIndex - 1
	local v243 = v233.nodesToMovingParts[p231.delayedNode]
	local v244 = v233.nodesToMovingTools[p231.delayedNode]
	if v243 ~= nil then
		Cylindered.setDirty(p230, v243)
	end
	if v233.nodesToMovingTools[p231.delayedNode] ~= nil then
		Cylindered.setDirty(p230, v244)
	end
end
function Cylindered.loadEasyArmControlFromXML(p_u_245, p_u_246, p247, p_u_248)
	XMLUtil.checkDeprecatedXMLElements(p_u_246, p247 .. ".xRotationNodes#maxDistance")
	XMLUtil.checkDeprecatedXMLElements(p_u_246, p247 .. ".xRotationNodes#transRotRatio")
	p_u_248.rootNode = p_u_246:getValue(p247 .. "#rootNode", nil, p_u_245.components, p_u_245.i3dMappings)
	p_u_248.targetNodeY = p_u_246:getValue(p247 .. "#node", nil, p_u_245.components, p_u_245.i3dMappings)
	p_u_248.targetNodeZ = p_u_246:getValue(p247 .. "#targetNodeZ", p_u_248.targetNodeY, p_u_245.components, p_u_245.i3dMappings)
	p_u_248.state = false
	if p_u_248.targetNodeZ == nil or p_u_248.targetNodeY == nil then
		Logging.xmlError(p_u_246, "Missing easy control targets!")
		return false
	end
	local v249 = p_u_245:getMovingToolByNode(p_u_248.targetNodeY)
	local v250 = p_u_245:getMovingToolByNode(p_u_248.targetNodeZ)
	if v249 == nil or v250 == nil then
		Logging.xmlError(p_u_246, "Missing moving tools for easy control targets!")
		return false
	end
	p_u_248.targetNode = p_u_248.targetNodeZ
	if getParent(p_u_248.targetNodeY) == p_u_248.targetNodeZ then
		p_u_248.targetNode = p_u_248.targetNodeY
	end
	p_u_248.targetRefNode = p_u_246:getValue(p247 .. "#refNode", nil, p_u_245.components, p_u_245.i3dMappings)
	p_u_248.lastValidPositionY = { getTranslation(p_u_248.targetNodeY) }
	p_u_248.lastValidPositionZ = { getTranslation(p_u_248.targetNodeZ) }
	p_u_248.moveSpeed = p_u_246:getValue(p247 .. ".targetMovement#speed", 1) / 1000
	p_u_248.moveAcceleration = p_u_246:getValue(p247 .. ".targetMovement#acceleration", 50) / 1000000
	p_u_248.lastSpeedY = 0
	p_u_248.lastSpeedZ = 0
	p_u_248.minTransMoveRatio = p_u_246:getValue(p247 .. ".zTranslationNodes#minMoveRatio", 0.2)
	p_u_248.maxTransMoveRatio = p_u_246:getValue(p247 .. ".zTranslationNodes#maxMoveRatio", 0.8)
	p_u_248.transMoveRatioMinDir = p_u_246:getValue(p247 .. ".zTranslationNodes#moveRatioMinDir", 0)
	p_u_248.transMoveRatioMaxDir = p_u_246:getValue(p247 .. ".zTranslationNodes#moveRatioMaxDir", 1)
	p_u_248.allowNegativeTrans = p_u_246:getValue(p247 .. ".zTranslationNodes#allowNegativeTrans", false)
	p_u_248.minNegativeTrans = p_u_246:getValue(p247 .. ".zTranslationNodes#minNegativeTrans", 0)
	p_u_248.forcedTransMove = nil
	p_u_248.zTranslationNodes = {}
	local v_u_251 = 0
	p_u_246:iterate(p247 .. ".zTranslationNodes.zTranslationNode", function(_, p252)
		-- upvalues: (copy) p_u_246, (copy) p_u_245, (ref) v_u_251, (copy) p_u_248
		local v253 = p_u_246:getValue(p252 .. "#node", nil, p_u_245.components, p_u_245.i3dMappings)
		if v253 ~= nil then
			local v254 = p_u_245:getMovingToolByNode(v253)
			if v254 ~= nil then
				local v255 = v254.transMin - v254.transMax
				local v256 = math.abs(v255)
				v_u_251 = v_u_251 + v256
				v254.easyArmControlActive = false
				local v257 = p_u_248.zTranslationNodes
				local v258 = {
					["node"] = v253,
					["movingTool"] = v254,
					["maxDistance"] = v256,
					["transFactor"] = 0,
					["startTranslation"] = { getTranslation(v253) }
				}
				table.insert(v257, v258)
			end
		end
	end)
	local v259 = v_u_251
	for _, v260 in ipairs(p_u_248.zTranslationNodes) do
		v260.transFactor = v260.maxDistance / v259
	end
	p_u_248.xRotationNodes = {}
	for v261 = 1, 2 do
		local v262 = string.format("%s.xRotationNodes.xRotationNode%d", p247, v261)
		if not p_u_246:hasProperty(v262) then
			Logging.xmlWarning(p_u_246, "Missing second xRotation node for easy control!")
			return false
		end
		XMLUtil.checkDeprecatedXMLElements(p_u_246, v262 .. "#refNode")
		local v263 = p_u_246:getValue(v262 .. "#node", nil, p_u_245.components, p_u_245.i3dMappings)
		if v263 ~= nil then
			local v264 = p_u_245:getMovingToolByNode(v263)
			if v264 ~= nil then
				v264.easyArmControlActive = false
				local v265 = p_u_248.xRotationNodes
				local v266 = {
					["node"] = v263,
					["movingTool"] = v264,
					["startRotation"] = { getRotation(v263) }
				}
				table.insert(v265, v266)
			end
		end
	end
	if #p_u_248.xRotationNodes ~= 2 then
		Logging.xmlWarning(p_u_246, "Easy arm control requires two x rotation nodes! Only %d given. (%s)", #p_u_248.xRotationNodes, p247)
		return false
	end
	if p_u_248.targetRefNode ~= nil then
		local v267, v268, _ = localToLocal(p_u_248.targetRefNode, p_u_248.xRotationNodes[2].node, 0, 0, 0)
		if math.abs(v267) > 0.0001 or math.abs(v268) > 0.0001 then
			Logging.xmlWarning(p_u_246, "Invalid position of \'%s\'. Offset to second xRotation node is not 0 on X or Y axis (x: %f y: %f)", p247 .. "#refNode", v267, v268)
			return false
		end
	end
	local v269, v270, _ = localToLocal(p_u_248.xRotationNodes[2].node, p_u_248.xRotationNodes[1].node, 0, 0, 0)
	if math.abs(v269) > 0.0001 or math.abs(v270) > 0.0001 then
		Logging.xmlWarning(p_u_246, "Invalid position of xRotationNode2. Offset to second xRotationNode1 is not 0 on X or Y axis (x: %f y: %f)", v269, v270)
		return false
	end
	local v271 = calcDistanceFrom(p_u_248.rootNode, p_u_248.xRotationNodes[1].node)
	if v271 > 0.05 then
		Logging.xmlWarning(p_u_246, "Distance between easyArmControl rootNode and xRotationNode1 is to big (%.2f). They should be at the same position.", v271)
		return false
	end
	p_u_248.maxTotalDistance = p_u_246:getValue(p247 .. "#maxTotalDistance")
	if p_u_248.maxTotalDistance == nil then
		for v272 = 1, #p_u_248.xRotationNodes do
			local v273 = p_u_248.xRotationNodes[v272]
			local v274 = {
				getRotation(v273.node),
				[v273.movingTool.rotationAxis] = v273.movingTool.rotMin
			}
			setRotation(v273.node, v274[1], v274[2], v274[3])
		end
		for v275 = 1, #p_u_248.zTranslationNodes do
			local v276 = p_u_248.zTranslationNodes[v275]
			local v277 = {
				getTranslation(v276.node),
				[v276.movingTool.translationAxis] = v276.movingTool.transMax
			}
			setTranslation(v276.node, v277[1], v277[2], v277[3])
		end
		p_u_248.maxTotalDistance = calcDistanceFrom(p_u_248.rootNode, p_u_248.targetRefNode)
		p_u_248.maxTransDistance = calcDistanceFrom(p_u_248.xRotationNodes[#p_u_248.xRotationNodes].node, p_u_248.targetRefNode)
		for v278 = 1, #p_u_248.xRotationNodes do
			local v279 = p_u_248.xRotationNodes[v278]
			setRotation(v279.node, v279.startRotation[1], v279.startRotation[2], v279.startRotation[3])
		end
		for v280 = 1, #p_u_248.zTranslationNodes do
			local v281 = p_u_248.zTranslationNodes[v280]
			setTranslation(v281.node, v281.startTranslation[1], v281.startTranslation[2], v281.startTranslation[3])
		end
	end
	return true
end
function Cylindered.updateEasyControl(p282, p283, p284)
	local v285 = p282.spec_cylindered
	local v286 = v285.easyArmControl
	if v286 ~= nil then
		local v287 = p282:getMovingToolByNode(v286.targetNodeY)
		local v288 = p282:getMovingToolByNode(v286.targetNodeZ)
		local v289 = p282:getMovingToolMoveValue(v287)
		local v290 = p282:getMovingToolMoveValue(v288)
		local v291
		if v289 == 0 and v290 == 0 then
			v291 = false
		else
			v291 = true
			if v289 ~= 0 and v287.isConsumingPower or v290 ~= 0 and v288.isConsumingPower then
				v285.powerConsumingTimer = v285.powerConsumingActiveTimeOffset
			end
		end
		if p282.isServer and (v286.state and v291) then
			local v292 = v289 * v286.moveSpeed
			if v286.moveAcceleration ~= nil then
				local v293 = v292 - v286.lastSpeedY
				if math.abs(v293) >= v286.moveAcceleration * p283 then
					if v286.lastSpeedY < v292 then
						v292 = v286.lastSpeedY + v286.moveAcceleration * p283
					else
						v292 = v286.lastSpeedY - v286.moveAcceleration * p283
					end
				end
			end
			local v294 = v290 * v286.moveSpeed
			if v286.moveAcceleration ~= nil then
				local v295 = v294 - v286.lastSpeedZ
				if math.abs(v295) >= v286.moveAcceleration * p283 then
					if v286.lastSpeedZ < v294 then
						v294 = v286.lastSpeedZ + v286.moveAcceleration * p283
					else
						v294 = v286.lastSpeedZ - v286.moveAcceleration * p283
					end
				end
			end
			v286.lastSpeedY = v292
			local v296 = v292 * p283
			v286.lastSpeedZ = v294
			local v297 = v294 * p283
			local v298, v299, v300 = localDirectionToWorld(v286.rootNode, 0, v296, v297)
			local v301, v302, v303 = getWorldTranslation(v286.targetRefNode)
			local v304 = v301 + v298
			local v305 = v302 + v299
			local v306 = v303 + v300
			local v307, v308, v309 = worldToLocal(v286.rootNode, v304, v305, v306)
			local v310 = MathUtil.vector3Length(v307, v308, v309)
			local v311 = v286.maxTotalDistance / v310
			if v311 < 1 then
				local v312 = v307 * v311
				local v313 = v308 * v311
				local v314 = v309 * v311
				v304, v305, v306 = localToWorld(v286.rootNode, v312, v313, v314)
				v310 = v286.maxTotalDistance
			end
			local v315 = MathUtil.vector3Length(localToLocal(v286.xRotationNodes[2].node, v286.xRotationNodes[1].node, 0, 0, 0))
			local _, _, v316 = localToLocal(v286.targetRefNode, v286.xRotationNodes[2].node, 0, 0, 0)
			local _, v317, v318 = localToLocal(v286.xRotationNodes[1].node, v286.rootNode, 0, 0, 0)
			local _, v319, v320 = worldToLocal(v286.rootNode, v304, v305, v306)
			local v321 = #v286.zTranslationNodes
			if v321 > 0 then
				local v322, v323 = MathUtil.vector2Normalize(math.abs(v296), (math.abs(v297)))
				if v296 == 0 and v297 == 0 then
					v322 = 0
					v323 = 0
				end
				local v324, v325, v326 = localDirectionToWorld(v286.zTranslationNodes[1].node, 0, 0, 1)
				local _, v327, v328 = worldDirectionToLocal(v286.rootNode, v324, v325, v326)
				local v329 = MathUtil.dotProduct(0, v322, v323, 0, v327, v328)
				local v330 = math.acos(v329)
				if v330 > 1.5707963267948966 then
					v330 = -v330 + 3.141592653589793
				end
				local v331 = (1 - v330 / 1.5707963267948966 - v286.transMoveRatioMinDir) / (v286.transMoveRatioMaxDir - v286.transMoveRatioMinDir)
				local v332 = v286.minTransMoveRatio
				local v333 = v286.maxTransMoveRatio
				local v334 = math.clamp(v331, v332, v333)
				local _, _, v335 = worldToLocal(v286.xRotationNodes[2].node, v304, v305, v306)
				local v336 = v335 - v316
				local v337
				if v286.allowNegativeTrans or v328 >= 0 then
					v337 = 0
				else
					v334 = v336 > 0 and -2 or v334
					v337 = v286.minNegativeTrans * -v328
				end
				local v338 = v336 * v334
				for v339 = 1, v321 do
					local v340 = v286.zTranslationNodes[v339].movingTool
					local v341 = v338 / v321
					if v286.forcedTransMove ~= nil then
						v341 = v286.forcedTransMove * v340.transSpeed * p283
						v286.forcedTransMove = nil
					end
					local v342 = v340.curTrans[v340.translationAxis]
					local v343 = (v340.transMax - v340.transMin) * v337 + v340.transMin
					local v344 = v342 + v341
					local v345 = v340.transMax
					local v346 = math.clamp(v344, v343, v345) - v342
					Cylindered.setAbsoluteToolTranslation(p282, v340, v342 + v346)
				end
				v316 = MathUtil.vector3Length(worldToLocal(v286.xRotationNodes[2].node, getWorldTranslation(v286.targetRefNode)))
			end
			local v347, v348, _, _ = MathUtil.getCircleCircleIntersection(v318, v317, v315, v320, v319, v316)
			if v347 ~= nil and v348 ~= nil then
				local v349 = v286.xRotationNodes[1].movingTool
				local v350 = v286.xRotationNodes[2].movingTool
				local v351 = -math.atan2(v348, v347)
				local v352 = v349.rotMin
				local v353 = v349.rotMax
				local v354 = math.clamp(v351, v352, v353)
				Cylindered.setAbsoluteToolRotation(p282, v286.xRotationNodes[1].movingTool, v354, p284)
				local v355 = (v315 * v315 + v316 * v316 - v310 * v310) / (2 * v315 * v316)
				local v356 = 3.141592653589793 - math.acos(v355)
				local v357 = v356 + 0
				local v358 = v350.rotMin
				local v359 = v350.rotMax
				local v360 = math.clamp(v357, v358, v359)
				local v361 = v356 - v360
				Cylindered.setAbsoluteToolRotation(p282, v286.xRotationNodes[2].movingTool, v360, p284)
				local v362 = v354 + v361 * 0.5
				local v363 = v349.rotMin
				local v364 = v349.rotMax
				local v365 = math.clamp(v362, v363, v364)
				Cylindered.setAbsoluteToolRotation(p282, v286.xRotationNodes[1].movingTool, v365, p284)
			end
		end
	end
end
function Cylindered.setIsEasyControlActive(p366, p367)
	local v368 = p366.spec_cylindered
	local v369 = v368.easyArmControl
	if v369 ~= nil then
		if p366.isServer then
			if v369 ~= nil then
				local v370 = p366:getMovingToolByNode(v369.targetNodeY)
				local v371 = p366:getMovingToolByNode(v369.targetNodeZ)
				if p367 then
					local v372 = getParent(v369.targetNodeY)
					if v372 == v369.targetNodeZ then
						v372 = getParent(v369.targetNodeZ)
					end
					local _, v373, _ = localToLocal(v369.targetRefNode, v372, 0, 0, 0)
					local _, v374, _ = getTranslation(v369.targetNodeY)
					if Cylindered.setToolTranslation(p366, v370, nil, 0, v373 - v374) then
						Cylindered.setDirty(p366, v370)
					end
					local _, _, v375 = localToLocal(v369.targetRefNode, v372, 0, 0, 0)
					local _, _, v376 = getTranslation(v369.targetNodeZ)
					if Cylindered.setToolTranslation(p366, v371, nil, 0, v375 - v376) then
						Cylindered.setDirty(p366, v371)
					end
					local v377 = v369.lastValidPositionY
					local v378 = v369.lastValidPositionY
					local v379 = v369.lastValidPositionY
					local v380, v381, v382 = getTranslation(v369.targetNodeY)
					v377[1] = v380
					v378[2] = v381
					v379[3] = v382
					local v383 = v369.lastValidPositionZ
					local v384 = v369.lastValidPositionZ
					local v385 = v369.lastValidPositionZ
					local v386, v387, v388 = getTranslation(v369.targetNodeZ)
					v383[1] = v386
					v384[2] = v387
					v385[3] = v388
					p366:raiseDirtyFlags(v368.cylinderedDirtyFlag)
				end
				v369.state = p367
			end
		else
			v369.state = p367
		end
	end
	p366:requestActionEventUpdate()
end
function Cylindered.setEasyControlForcedTransMove(p389, p390)
	local v391 = p389.spec_cylindered.easyArmControl
	if v391 ~= nil then
		v391.forcedTransMove = p390
	end
end
function Cylindered.updateExtraDependentParts(_, _, _) end
function Cylindered.updateDependentAnimations(p392, p393, _)
	if #p393.dependentAnimations > 0 then
		for _, v394 in ipairs(p393.dependentAnimations) do
			local v395 = v394.translationAxis == nil and 0 or (({ getTranslation(v394.node) })[v394.translationAxis] - v394.minValue) / (v394.maxValue - v394.minValue)
			if v394.rotationAxis ~= nil then
				v395 = (({ getRotation(v394.node) })[v394.rotationAxis] - v394.minValue) / (v394.maxValue - v394.minValue)
			end
			local v396 = math.clamp(v395, 0, 1)
			if v394.invert then
				v396 = 1 - v396
			end
			v394.lastPos = v396
			p392:setAnimationTime(v394.name, v396, true, true)
		end
	end
end
function Cylindered.updateDependentToolLimits(p397, p398, p399)
	if p399.minTransLimits ~= nil or p399.maxTransLimits ~= nil then
		local v400 = Cylindered.getMovingToolState(p397, p398)
		if p399.minTransLimits ~= nil then
			p399.movingTool.transMin = MathUtil.lerp(p399.minTransLimits[1], p399.minTransLimits[2], 1 - v400)
		end
		if p399.maxTransLimits ~= nil then
			p399.movingTool.transMax = MathUtil.lerp(p399.maxTransLimits[1], p399.maxTransLimits[2], 1 - v400)
		end
		if Cylindered.setToolTranslation(p397, p399.movingTool, 0, 0) then
			Cylindered.setDirty(p397, p399.movingTool)
		end
	end
	if p399.minRotLimits ~= nil or p399.maxRotLimits ~= nil then
		local v401 = Cylindered.getMovingToolState(p397, p398)
		if p399.minRotLimits ~= nil then
			p399.movingTool.rotMin = MathUtil.lerp(p399.minRotLimits[1], p399.minRotLimits[2], 1 - v401)
		end
		if p399.maxRotLimits ~= nil then
			p399.movingTool.rotMax = MathUtil.lerp(p399.maxRotLimits[1], p399.maxRotLimits[2], 1 - v401)
		end
		p399.movingTool.networkInterpolators.rotation:setMinMax(p399.movingTool.rotMin, p399.movingTool.rotMax)
		if Cylindered.setToolRotation(p397, p399.movingTool, 0, 0) then
			Cylindered.setDirty(p397, p399.movingTool)
		end
	end
end
function Cylindered.onMovingPartSoundEvent(p402, p403, p404, p405)
	if p403.samplesByAction ~= nil then
		local v406 = p403.samplesByAction[p404]
		if v406 ~= nil then
			for v407 = 1, #v406 do
				local v408 = v406[v407]
				if p405 == Cylindered.SOUND_TYPE_EVENT then
					if v408.loops == 0 then
						v408.loops = 1
					end
					g_soundManager:playSample(v408)
				elseif p405 == Cylindered.SOUND_TYPE_CONTINUES then
					if g_soundManager:getIsSamplePlaying(v408) then
						if v408.lastActivationPart == p403 then
							v408.lastActivationTime = g_time
						end
					else
						g_soundManager:playSample(v408)
						v408.lastActivationTime = g_time
						v408.lastActivationPart = p403
						local v409 = p402.spec_cylindered.activeSamples
						table.insert(v409, v408)
					end
				elseif p405 == Cylindered.SOUND_TYPE_ENDING then
					local v410 = p402.spec_cylindered
					if v410.endingSamplesBySample[v408] == nil then
						v408.lastActivationTime = g_time
						local v411 = v410.endingSamples
						table.insert(v411, v408)
						v410.endingSamplesBySample[v408] = v408
					else
						v408.lastActivationTime = g_time
					end
				elseif p405 == Cylindered.SOUND_TYPE_STARTING then
					local v412 = p402.spec_cylindered
					if v412.startingSamplesBySample[v408] == nil then
						if v408.loops == 0 then
							v408.loops = 1
						end
						g_soundManager:playSample(v408)
						v408.lastActivationTime = g_time
						local v413 = v412.startingSamples
						table.insert(v413, v408)
						v412.startingSamplesBySample[v408] = v408
					else
						v408.lastActivationTime = g_time
					end
				end
			end
		end
	end
end
function Cylindered.updateMovingToolSoundEvents(p414, p415, p416, p417, p418)
	if p415.samplesByAction ~= nil then
		p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_END, Cylindered.SOUND_TYPE_ENDING)
		p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_START, Cylindered.SOUND_TYPE_STARTING)
		if p416 then
			p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_POS, Cylindered.SOUND_TYPE_CONTINUES)
			p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_END_POS, Cylindered.SOUND_TYPE_ENDING)
			p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_START_POS, Cylindered.SOUND_TYPE_STARTING)
			if p417 then
				p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_END_POS_LIMIT, Cylindered.SOUND_TYPE_ENDING)
			end
			if p418 then
				p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_START_POS_LIMIT, Cylindered.SOUND_TYPE_STARTING)
				return
			end
		else
			p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_NEG, Cylindered.SOUND_TYPE_CONTINUES)
			p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_END_NEG, Cylindered.SOUND_TYPE_ENDING)
			p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_START_NEG, Cylindered.SOUND_TYPE_STARTING)
			if p417 then
				p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_END_NEG_LIMIT, Cylindered.SOUND_TYPE_ENDING)
			end
			if p418 then
				p414:onMovingPartSoundEvent(p415, Cylindered.SOUND_ACTION_TOOL_MOVE_START_NEG_LIMIT, Cylindered.SOUND_TYPE_STARTING)
			end
		end
	end
end
function Cylindered.updateControlGroups(p419)
	local v420 = p419.spec_cylindered
	p419:clearSubselections()
	for v421, _ in pairs(v420.controlGroupMapping) do
		v420.controlGroupMapping[v421] = nil
	end
	for _, v422 in ipairs(v420.controlGroups) do
		local v423 = false
		for _, v424 in pairs(v420.movingTools) do
			if v424.axisActionIndex ~= nil and (v424.controlGroupIndex == v422 and v424.lastIsActiveState) then
				v423 = true
				break
			end
		end
		if v423 then
			local v425 = p419:addSubselection(v422)
			v420.controlGroupMapping[v425] = v422
		end
	end
	p419.rootVehicle:updateSelectableObjects()
	if p419.rootVehicle:getSelectedVehicle() == p419 then
		p419.rootVehicle:setSelectedVehicle(p419, 99999, false)
	end
end
function Cylindered.onUpdateTick(p426, p427, _, _, _)
	if p426.isClient then
		local v428 = p426.spec_cylindered
		local v429 = false
		for _, v430 in pairs(v428.movingTools) do
			if v430.axisActionIndex ~= nil then
				local v431 = p426:getIsMovingToolActive(v430)
				if v431 ~= v430.lastIsActiveState then
					v430.lastIsActiveState = v431
					v429 = true
				end
				if v428.currentControlGroupIndex == v430.controlGroupIndex then
					local v432 = v428.actionEvents[v430.axisActionIndex]
					if v432 ~= nil then
						g_inputBinding:setActionEventActive(v432.actionEventId, v431)
					end
				end
			end
		end
		if v429 then
			p426:updateControlGroups()
		end
		for v433 = #v428.activeSamples, 1, -1 do
			local v434 = v428.activeSamples[v433]
			if v434.lastActivationTime + p427 * 3 < g_time then
				if v434.lastActivationTime + p427 * 3 + v434.dropOffTime >= g_time then
					if not v434.dropOffActive then
						v434.dropOffActive = true
						g_soundManager:setSamplePitchOffset(v434, g_soundManager:getCurrentSamplePitch(v434) * (v434.dropOffFactor - 1))
					end
				else
					v434.dropOffActive = false
					g_soundManager:setSamplePitchOffset(v434, 0)
					g_soundManager:stopSample(v434)
					table.remove(v428.activeSamples, v433)
				end
			end
		end
		for v435 = #v428.endingSamples, 1, -1 do
			local v436 = v428.endingSamples[v435]
			if v436.lastActivationTime + p427 < g_time then
				if v436.loops == 0 then
					v436.loops = 1
				end
				g_soundManager:playSample(v436)
				table.remove(v428.endingSamples, v435)
				v428.endingSamplesBySample[v436] = nil
			end
		end
		for v437 = #v428.startingSamples, 1, -1 do
			local v438 = v428.startingSamples[v437]
			if v438.lastActivationTime + p427 < g_time then
				table.remove(v428.startingSamples, v437)
				v428.startingSamplesBySample[v438] = nil
			end
		end
	end
end
function Cylindered.onUpdateEnd(p439, p440, _, _, _)
	local v441 = p439.spec_cylindered
	for _, v442 in pairs(v441.activeDirtyMovingParts) do
		Cylindered.setDirty(p439, v442)
	end
	p439:updateDirtyMovingParts(p440, true)
end
function Cylindered.onPostUpdate(p443, p444, _, _, _)
	local v445 = p443.spec_cylindered
	for _, v446 in pairs(v445.activeDirtyMovingParts) do
		if p443.currentUpdateDistance < v446.maxUpdateDistance then
			Cylindered.setDirty(p443, v446)
		end
	end
	p443:updateDirtyMovingParts(p444, true)
end
function Cylindered.onPostUpdateTick(p447, p448, _, _, _)
	p447:updateDirtyMovingParts(p448, false)
end
function Cylindered.updateDirtyMovingParts(p449, p450, p451)
	local v452 = p449.spec_cylindered
	for v453 = 1, #v452.movingTools do
		local v454 = v452.movingTools[v453]
		if v454.isDirty then
			if v454.playSound then
				v452.movingToolNeedsSound = true
			end
			Cylindered.updateWheels(p449, v454)
			if p449.isServer then
				Cylindered.updateComponentJoints(p449, v454, false)
			end
			p449:updateExtraDependentParts(v454, p450)
			p449:updateDependentAnimations(v454, p450)
			v454.isDirty = false
		end
	end
	if p449.anyMovingPartsDirty then
		for v455 = 1, #v452.movingParts do
			local v456 = v452.movingParts[v455]
			if v456.isDirty then
				local v457 = p449:getIsMovingPartActive(v456)
				if v457 or v456.smoothedDirectionScale and v456.smoothedDirectionScaleAlpha ~= 0 then
					Cylindered.updateMovingPart(p449, v456, false, nil, v457)
					p449:updateExtraDependentParts(v456, p450)
					p449:updateDependentAnimations(v456, p450)
					if v456.playSound then
						v452.cylinderedHydraulicSoundPartNumber = v455
						v452.movingPartNeedsSound = true
					end
				end
			elseif v452.isClient and v452.cylinderedHydraulicSoundPartNumber == v455 then
				v452.movingPartNeedsSound = false
			end
		end
		p449.anyMovingPartsDirty = false
	end
	if p451 and p449.isClient then
		if v452.movingToolNeedsSound or v452.movingPartNeedsSound then
			if not v452.isHydraulicSamplePlaying then
				g_soundManager:playSample(v452.samples.hydraulic)
				v452.isHydraulicSamplePlaying = true
			end
			p449:raiseActive()
			return
		end
		if v452.isHydraulicSamplePlaying then
			g_soundManager:stopSample(v452.samples.hydraulic)
			v452.isHydraulicSamplePlaying = false
		end
	end
end
function Cylindered.onDraw(p458, _, p459, _)
	local v460 = p458.spec_cylindered
	if #v460.controlGroupNames > 1 and (p459 and v460.currentControlGroupIndex ~= 0) then
		g_currentMission:addExtraPrintText(string.format(g_i18n:getText("action_selectedControlGroup"), v460.controlGroupNames[v460.currentControlGroupIndex], v460.currentControlGroupIndex))
	end
end
function Cylindered.loadMovingPartsFromXML(p461, p462, p463)
	local v464 = p461.spec_cylindered
	for _, v465 in p462:iterator(p463) do
		local v466 = {}
		if p461:loadMovingPartFromXML(p462, v465, v466) then
			if v464.referenceNodes[v466.node] == nil then
				v464.referenceNodes[v466.node] = {}
			end
			if v464.nodesToMovingParts[v466.node] == nil then
				local v467 = v464.referenceNodes[v466.node]
				table.insert(v467, v466)
				p461:loadDependentParts(p462, v465, v466)
				p461:loadDependentComponentJoints(p462, v465, v466)
				p461:loadCopyLocalDirectionParts(p462, v465, v466)
				p461:loadExtraDependentParts(p462, v465, v466)
				p461:loadDependentAnimations(p462, v465, v466)
				v466.key = v465
				local v468 = v464.movingParts
				table.insert(v468, v466)
				if v466.isActiveDirty then
					local v469 = v464.activeDirtyMovingParts
					table.insert(v469, v466)
				end
				v464.nodesToMovingParts[v466.node] = v466
			else
				Logging.xmlWarning(p462, "Moving part with node \'%s\' already exists!", getName(v466.node))
			end
		end
	end
end
function Cylindered.loadMovingPartFromXML(p470, p471, p472, p473)
	XMLUtil.checkDeprecatedXMLElements(p471, p472 .. "#index", p472 .. "#node")
	local v474 = p471:getValue(p472 .. "#node", nil, p470.components, p470.i3dMappings)
	local v475 = p471:getValue(p472 .. "#referenceFrame", nil, p470.components, p470.i3dMappings)
	if v474 == nil or v475 == nil then
		return false
	end
	p473.referencePoint = p471:getValue(p472 .. "#referencePoint", nil, p470.components, p470.i3dMappings)
	p473.referencePoints = p471:getValue(p472 .. "#referencePoints", nil, p470.components, p470.i3dMappings, true)
	p473.numReferencePoints = #p473.referencePoints
	p473.hasReferencePoints = p473.numReferencePoints > 0 and true or p473.referencePoint ~= nil
	p473.node = v474
	p473.parent = getParent(v474)
	p473.referenceFrame = v475
	p473.invertZ = p471:getValue(p472 .. "#invertZ", false)
	p473.scaleZ = p471:getValue(p472 .. "#scaleZ", false)
	p473.limitedAxis = p471:getValue(p472 .. "#limitedAxis")
	p473.isActiveDirty = p471:getValue(p472 .. "#isActiveDirty", false)
	p473.playSound = p471:getValue(p472 .. "#playSound", false)
	p473.moveToReferenceFrame = p471:getValue(p472 .. "#moveToReferenceFrame", false)
	if p473.moveToReferenceFrame then
		local v476, v477, v478 = worldToLocal(v475, getWorldTranslation(v474))
		p473.referenceFrameOffset = { v476, v477, v478 }
	end
	if p473.referenceFrame == p473.node then
		Logging.xmlWarning(p471, "Reference frame equals moving part node. This can lead to bad behaviours! Node \'%s\' in \'%s\'.", getName(p473.node), p472)
	end
	p473.doLineAlignment = p471:getValue(p472 .. "#doLineAlignment", false)
	p473.doInversedLineAlignment = p471:getValue(p472 .. "#doInversedLineAlignment", false)
	p473.do3DLineAlignment = p471:getValue(p472 .. "#do3DLineAlignment", false)
	p473.partLength = p471:getValue(p472 .. ".orientationLine#partLength", 0.5)
	p473.partLengthNode = p471:getValue(p472 .. ".orientationLine#partLengthNode", nil, p470.components, p470.i3dMappings)
	p473.orientationLineNodes = {}
	for _, v479 in p470.xmlFile:iterator(p472 .. ".orientationLine.lineNode") do
		local v480 = p471:getValue(v479 .. "#node", nil, p470.components, p470.i3dMappings)
		if v480 ~= nil then
			if p473.doInversedLineAlignment then
				local _, _, v481 = localToLocal(v480, p473.node, 0, 0, 0)
				if v481 >= 0 then
					goto l16
				end
				Logging.xmlWarning(p471, "Local orientation line node \'%s\' is in negative Z direction to the movingPart node. This is not allowed! (%s)", getName(v480), v479)
			else
				::l16::
				local v482 = p473.orientationLineNodes
				table.insert(v482, v480)
			end
		end
	end
	if p473.do3DLineAlignment then
		if #p473.orientationLineNodes == 2 then
			p473.orientationLineTransNode = p471:getValue(p472 .. ".orientationLine#referenceTransNode", nil, p470.components, p470.i3dMappings)
			if p473.orientationLineTransNode == nil then
				Logging.xmlWarning(p471, "Failed to load 3D line alignment from xml. Missing referenceTransNode! (movingPart \'%s\')", getName(v474))
				p473.do3DLineAlignment = false
			end
		else
			Logging.xmlWarning(p471, "Failed to load 3D line alignment from xml. Requires exactly two line nodes! (movingPart \'%s\')", getName(v474))
			p473.do3DLineAlignment = false
		end
	end
	p473.doDirectionAlignment = p471:getValue(p472 .. "#doDirectionAlignment", true)
	p473.doRotationAlignment = p471:getValue(p472 .. "#doRotationAlignment", false)
	p473.rotMultiplier = p471:getValue(p472 .. "#rotMultiplier", 0)
	if p473.doDirectionAlignment and p473.doRotationAlignment then
		Logging.xmlWarning(p471, "Direction alignment and rotation alignment used at the same time for movingPart \'%s\' in \'%s\'", getName(v474), p472)
		return false
	end
	if p473.doDirectionAlignment and (p473.doLineAlignment or (p473.doInversedLineAlignment or p473.do3DLineAlignment)) then
		Logging.xmlWarning(p471, "Direction alignment and line alignment used at the same time for movingPart \'%s\' in \'%s\'", getName(v474), p472)
		return false
	end
	local v483 = p471:getValue(p472 .. "#minRot")
	local v484 = p471:getValue(p472 .. "#maxRot")
	if v483 ~= nil and v484 ~= nil then
		if p473.limitedAxis == nil then
			Logging.xmlWarning(p471, "minRot/maxRot requires the use of limitedAxis in for movingPart \'%s\' in \'%s\'", getName(v474), p472)
		else
			p473.minRot = MathUtil.getValidLimit(v483)
			p473.maxRot = MathUtil.getValidLimit(v484)
		end
	end
	p473.alignToWorldY = p471:getValue(p472 .. "#alignToWorldY", false)
	if p473.hasReferencePoints then
		local v485 = p471:getValue(p472 .. "#localReferencePoint", nil, p470.components, p470.i3dMappings)
		local v486, v487, v488
		if p473.referencePoint == nil then
			local v489 = 0
			local v490 = 0
			local v491 = 0
			for _, v492 in ipairs(p473.referencePoints) do
				local v493, v494, v495 = worldToLocal(v474, getWorldTranslation(v492))
				v489 = v489 + v493
				v490 = v490 + v494
				v491 = v491 + v495
			end
			v486 = v489 / p473.numReferencePoints
			v487 = v490 / p473.numReferencePoints
			v488 = v491 / p473.numReferencePoints
		else
			v486, v487, v488 = worldToLocal(v474, getWorldTranslation(p473.referencePoint))
		end
		if v485 == nil then
			p473.referenceDistance = 0
			p473.localReferencePoint = { v486, v487, v488 }
		else
			local v496, v497, v498 = worldToLocal(v474, getWorldTranslation(v485))
			p473.referenceDistance = MathUtil.vector3Length(v486 - v496, v487 - v497, v488 - v498)
			p473.lastReferenceDistance = p473.referenceDistance
			p473.localReferencePoint = { v496, v497, v498 }
			p473.localReferenceAngleSide = v497 * (v488 - v498) - v498 * (v487 - v497)
			p473.localReferencePointNode = v485
			p473.updateLocalReferenceDistance = p471:getValue(p472 .. "#updateLocalReferenceDistance", false)
			p473.localReferenceTranslate = p471:getValue(p472 .. "#localReferenceTranslate", false)
			if p473.localReferenceTranslate then
				p473.localReferenceTranslation = { getTranslation(p473.node) }
			end
			p473.dynamicLocalReferenceDistance = p471:getValue(p472 .. "#dynamicLocalReferenceDistance", false)
		end
		p473.referenceDistanceThreshold = p471:getValue(p472 .. "#referenceDistanceThreshold", 0.0001)
		p473.useLocalOffset = p471:getValue(p472 .. "#useLocalOffset", false)
		p473.referenceDistance = p471:getValue(p472 .. "#referenceDistance", p473.referenceDistance)
		p473.referenceDistancePoint = p471:getValue(p472 .. "#referenceDistancePoint", nil, p470.components, p470.i3dMappings)
		p473.localReferenceDistance = p471:getValue(p472 .. "#localReferenceDistance", MathUtil.vector2Length(p473.localReferencePoint[2], p473.localReferencePoint[3]))
		p470:loadDependentTranslatingParts(p471, p472, p473)
	end
	p470:loadDependentMovingTools(p471, p472, p473)
	p473.directionThreshold = p471:getValue(p472 .. "#directionThreshold", 0.0001)
	p473.directionThresholdActive = p471:getValue(p472 .. "#directionThresholdActive", 0.00001)
	if p473.doDirectionAlignment and not p473.hasReferencePoints then
		p473.directionThreshold = 0
		p473.directionThresholdActive = 0
	end
	p473.maxUpdateDistance = p471:getValue(p472 .. "#maxUpdateDistance", "-")
	if p473.maxUpdateDistance == "-" then
		p473.maxUpdateDistance = (1 / 0)
	else
		local v499 = p473.maxUpdateDistance
		p473.maxUpdateDistance = tonumber(v499)
	end
	if p473.isActiveDirty and (p471:getString(p472 .. "#maxUpdateDistance") == nil or p473.maxUpdateDistance == nil) then
		Logging.xmlWarning(p471, "No max. update distance set for isActiveDirty moving part \'%s\'! Use #maxUpdateDistance attribute.", getName(v474))
	end
	p473.smoothedDirectionScale = p471:getValue(p472 .. "#smoothedDirectionScale", false)
	p473.smoothedDirectionTime = 1 / p471:getValue(p472 .. "#smoothedDirectionTime", 2)
	p473.smoothedDirectionScaleAlpha = nil
	if p473.smoothedDirectionScale then
		p473.initialDirection = { localDirectionToLocal(p473.node, getParent(p473.node), 0, 0, 1) }
	end
	p473.debug = p471:getValue(p472 .. "#debug", false)
	if p473.debug then
		Logging.xmlWarning(p471, "MovingPart debug enabled for moving part \'%s\'", getName(v474))
	end
	p473.lastDirection = { 0, 0, 0 }
	p473.lastUpVector = { 0, 0, 0 }
	p473.isDirty = false
	p473.isPart = true
	p473.isActive = true
	return true
end
function Cylindered.loadMovingToolsFromXML(p500, p501, p502)
	local v503 = p500.spec_cylindered
	for _, v504 in p501:iterator(p502) do
		local v505 = {}
		if p500:loadMovingToolFromXML(p501, v504, v505) then
			if v503.referenceNodes[v505.node] == nil then
				v503.referenceNodes[v505.node] = {}
			end
			if v503.nodesToMovingTools[v505.node] == nil then
				local v506 = v503.referenceNodes[v505.node]
				table.insert(v506, v505)
				p500:loadDependentMovingTools(p501, v504, v505)
				p500:loadDependentParts(p501, v504, v505)
				p500:loadDependentComponentJoints(p501, v504, v505)
				p500:loadExtraDependentParts(p501, v504, v505)
				p500:loadDependentAnimations(p501, v504, v505)
				v505.isActive = true
				v505.key = v504
				local v507 = v503.movingTools
				table.insert(v507, v505)
				v503.nodesToMovingTools[v505.node] = v505
			else
				Logging.xmlWarning(p501, "Moving tool with node \'%s\' already exists!", getName(v505.node))
			end
		end
	end
end
function Cylindered.loadMovingToolFromXML(p508, p509, p510, p511)
	local v512 = p508.spec_cylindered
	XMLUtil.checkDeprecatedXMLElements(p509, p510 .. "#index", p510 .. "#node")
	local v513 = p509:getValue(p510 .. "#node", nil, p508.components, p508.i3dMappings)
	if v513 == nil then
		return false
	end
	p511.node = v513
	p511.externalMove = 0
	p511.easyArmControlActive = true
	p511.isEasyControlTarget = p509:getValue(p510 .. "#isEasyControlTarget", false)
	p511.networkInterpolators = {}
	XMLUtil.checkDeprecatedXMLElements(p509, p510 .. "#rotSpeed", p510 .. ".rotation#rotSpeed")
	local v514 = p509:getValue(p510 .. ".rotation#rotSpeed")
	if v514 ~= nil then
		p511.rotSpeed = v514 / 1000
	end
	local v515 = p509:getValue(p510 .. ".rotation#rotAcceleration")
	if v515 ~= nil then
		p511.rotAcceleration = v515 / 1000000
	end
	p511.lastRotSpeed = 0
	p511.rotMax = p509:getValue(p510 .. ".rotation#rotMax")
	p511.rotMin = p509:getValue(p510 .. ".rotation#rotMin")
	p511.syncMaxRotLimits = p509:getValue(p510 .. ".rotation#syncMaxRotLimits", false)
	p511.syncMinRotLimits = p509:getValue(p510 .. ".rotation#syncMinRotLimits", false)
	p511.rotSendNumBits = p509:getValue(p510 .. ".rotation#rotSendNumBits")
	p511.attachRotMax = p509:getValue(p510 .. ".rotation#attachRotMax")
	p511.attachRotMin = p509:getValue(p510 .. ".rotation#attachRotMin")
	if p511.rotSendNumBits == nil then
		if p511.rotMin == nil or p511.rotMax == nil then
			p511.rotSendNumBits = 11
		else
			local v516 = (p511.rotMax - p511.rotMin) / Cylindered.MOVING_TOOL_SEND_MIN_RESOLUTION
			local v517 = math.ceil(v516)
			local _ = v517 <= 2047
			local v518 = 11
			local v519 = v517 <= 1023 and 10 or v518
			local v520 = v517 <= 511 and 9 or v519
			local v521 = v517 <= 255 and 8 or v520
			local v522 = v517 <= 127 and 7 or v521
			local v523 = v517 <= 63 and 6 or v522
			local v524 = v517 <= 31 and 5 or v523
			local v525 = v517 <= 15 and 4 or v524
			local v526 = v517 <= 7 and 3 or v525
			local v527 = v517 <= 3 and 2 or v526
			p511.rotSendNumBits = v517 <= 1 and 1 or v527
		end
	end
	if p511.rotMin ~= nil and (p511.rotMax ~= nil and p511.rotMin >= p511.rotMax) then
		Logging.xmlWarning(p509, "Rotation min value is greater or equal to max value for movingTool \'%s\' in \'%s\'", getName(v513), p510)
		return false
	end
	XMLUtil.checkDeprecatedXMLElements(p509, p510 .. "#transSpeed", p510 .. ".rotation#transSpeed")
	local v528 = p509:getValue(p510 .. ".translation#transSpeed")
	if v528 ~= nil then
		p511.transSpeed = v528 / 1000
	end
	local v529 = p509:getValue(p510 .. ".translation#transAcceleration")
	if v529 ~= nil then
		p511.transAcceleration = v529 / 1000000
	end
	p511.lastTransSpeed = 0
	p511.transMax = p509:getValue(p510 .. ".translation#transMax")
	p511.transMin = p509:getValue(p510 .. ".translation#transMin")
	p511.attachTransMax = p509:getValue(p510 .. ".translation#attachTransMax")
	p511.attachTransMin = p509:getValue(p510 .. ".translation#attachTransMin")
	p511.playSound = p509:getValue(p510 .. "#playSound", false)
	if p511.transMin ~= nil and (p511.transMax ~= nil and p511.transMin >= p511.transMax) then
		Logging.xmlWarning(p509, "Translation min value is greater or equal to max value for movingTool \'%s\' in \'%s\'", getName(v513), p510)
		return false
	end
	p511.isConsumingPower = p509:getValue(p510 .. "#isConsumingPower", false)
	if SpecializationUtil.hasSpecialization(AnimatedVehicle, p508.specializations) then
		local v530 = p509:getValue(p510 .. ".animation#animSpeed")
		if v530 ~= nil then
			p511.animSpeed = v530 / 1000
		end
		local v531 = p509:getValue(p510 .. ".animation#animAcceleration")
		if v531 ~= nil then
			p511.animAcceleration = v531 / 1000000
		end
		p511.curAnimTime = 0
		p511.lastAnimSpeed = 0
		p511.animName = p509:getValue(p510 .. ".animation#animName")
		p511.animSendNumBits = p509:getValue(p510 .. ".animation#animSendNumBits", 8)
		local v532 = p509:getValue(p510 .. ".animation#animMaxTime", 1)
		p511.animMaxTime = math.min(v532, 1)
		local v533 = p509:getValue(p510 .. ".animation#animMinTime", 0)
		p511.animMinTime = math.max(v533, 0)
		if p511.animMinTime >= p511.animMaxTime then
			Logging.xmlWarning(p509, "Animation min value is greater or equal to max value for movingTool \'%s\' in \'%s\'", getName(v513), p510)
			return false
		end
		p511.animStartTime = p509:getValue(p510 .. ".animation#animStartTime")
		if p511.animStartTime ~= nil then
			p511.curAnimTime = p511.animStartTime
		end
		p511.networkInterpolators.animation = InterpolatorValue.new(p511.curAnimTime)
		p511.networkInterpolators.animation:setMinMax(0, 1)
		p511.networkInterpolators.resetAnimInterpolation = false
	end
	XMLUtil.checkDeprecatedXMLElements(p509, p510 .. ".controls#iconFilename", p510 .. ".controls#iconName")
	local v534 = p509:getValue(p510 .. ".controls#iconName")
	if v534 ~= nil then
		if InputHelpElement.AXIS_ICON[v534] == nil then
			v534 = (p508.customEnvironment or "") .. v534
		end
		p511.axisActionIcon = v534
	end
	p511.controlGroupIndex = p509:getValue(p510 .. ".controls#groupIndex", 0)
	if p511.controlGroupIndex ~= 0 then
		if v512.controlGroupNames[p511.controlGroupIndex] == nil then
			Logging.xmlWarning(p509, "ControlGroup \'%d\' not defined for \'%s\'!", p511.controlGroupIndex, p510)
		else
			table.addElement(v512.controlGroups, p511.controlGroupIndex)
		end
	end
	p511.axis = p509:getValue(p510 .. ".controls#axis")
	if p511.axis ~= nil then
		p511.axisActionIndex = InputAction[p511.axis]
	end
	p511.invertAxis = p509:getValue(p510 .. ".controls#invertAxis", false)
	p511.mouseSpeedFactor = p509:getValue(p510 .. ".controls#mouseSpeedFactor", 1)
	if p511.rotSpeed ~= nil or (p511.transSpeed ~= nil or p511.animSpeed ~= nil) then
		p511.dirtyFlag = p508:getNextDirtyFlag()
		p511.saving = p509:getValue(p510 .. "#allowSaving", true)
	end
	p511.aiActivePosition = p509:getValue(p510 .. "#aiActivePosition")
	p511.isDirty = false
	p511.isIntitialDirty = p509:getValue(p510 .. "#isIntitialDirty", true)
	p511.rotationAxis = p509:getValue(p510 .. ".rotation#rotationAxis", 1)
	p511.translationAxis = p509:getValue(p510 .. ".translation#translationAxis", 3)
	local v535 = p509:getValue(p510 .. ".rotation#detachingRotMaxLimit")
	local v536 = p509:getValue(p510 .. ".rotation#detachingRotMinLimit")
	local v537 = p509:getValue(p510 .. ".translation#detachingTransMaxLimit")
	local v538 = p509:getValue(p510 .. ".translation#detachingTransMinLimit")
	if v535 ~= nil or (v536 ~= nil or (v537 ~= nil or v538 ~= nil)) then
		if v512.detachLockNodes == nil then
			v512.detachLockNodes = {}
		end
		v512.detachLockNodes[p511] = {
			["detachingRotMaxLimit"] = v535,
			["detachingRotMinLimit"] = v536,
			["detachingTransMinLimit"] = v538,
			["detachingTransMaxLimit"] = v537
		}
	end
	local v539, v540, v541 = getRotation(v513)
	p511.curRot = { v539, v540, v541 }
	local v542, v543, v544 = getTranslation(v513)
	p511.curTrans = { v542, v543, v544 }
	p511.startRot = p509:getValue(p510 .. ".rotation#startRot")
	p511.startTrans = p509:getValue(p510 .. ".translation#startTrans")
	p511.move = 0
	p511.moveToSend = 0
	p511.smoothedMove = 0
	p511.lastInputTime = 0
	XMLUtil.checkDeprecatedXMLElements(p509, p510 .. "#delayedIndex", p510 .. "#delayedNode")
	p511.delayedNode = p509:getValue(p510 .. "#delayedNode", nil, p508.components, p508.i3dMappings)
	if p511.delayedNode ~= nil then
		p511.delayedFrames = p509:getValue(p510 .. "#delayedFrames", 3)
		p511.currentDelayedData = {
			["rot"] = { v539, v540, v541 },
			["trans"] = { v542, v543, v544 }
		}
		p511.delayedHistroyData = {}
		for v545 = 1, p511.delayedFrames do
			p511.delayedHistroyData[v545] = {
				["rot"] = { v539, v540, v541 },
				["trans"] = { v542, v543, v544 }
			}
		end
		p511.delayedHistoryIndex = 0
	end
	p511.networkInterpolators.translation = InterpolatorValue.new(p511.curTrans[p511.translationAxis])
	p511.networkInterpolators.translation:setMinMax(p511.transMin, p511.transMax)
	p511.networkInterpolators.rotation = InterpolatorAngle.new(p511.curRot[p511.rotationAxis])
	p511.networkInterpolators.rotation:setMinMax(p511.rotMin, p511.rotMax)
	p511.networkTimeInterpolator = InterpolationTime.new(1.2)
	p511.isTool = true
	return true
end
function Cylindered.loadDependentMovingTools(p546, p547, p548, p549)
	p549.dependentMovingTools = {}
	local v550 = 0
	while true do
		local v551 = p548 .. string.format(".dependentMovingTool(%d)", v550)
		if not p547:hasProperty(v551) then
			break
		end
		XMLUtil.checkDeprecatedXMLElements(p547, v551 .. "#index", v551 .. "#index")
		local v552 = p547:getValue(v551 .. "#node", nil, p546.components, p546.i3dMappings)
		local v553 = p547:getValue(v551 .. "#speedScale")
		local v554 = p547:getValue(v551 .. "#requiresMovement", false)
		local v555 = p547:getValue(v551 .. "#axis", 1)
		local v556 = AnimCurve.new(Cylindered.limitInterpolator)
		local v557 = 0
		local v558 = false
		while true do
			local v559 = string.format("%s.limit(%d)", v551 .. ".rotationBasedLimits", v557)
			if not p547:hasProperty(v559) then
				break
			end
			local v560 = p546:loadRotationBasedLimits(p547, v559, p549)
			if v560 ~= nil then
				v556:addKeyframe(v560)
				v558 = true
			end
			v557 = v557 + 1
		end
		if not v558 then
			v556 = nil
		end
		local v561 = p547:getValue(v551 .. "#minTransLimits", nil, true)
		local v562 = p547:getValue(v551 .. "#maxTransLimits", nil, true)
		local v563 = p547:getValue(v551 .. "#minRotLimits", nil, true)
		local v564 = p547:getValue(v551 .. "#maxRotLimits", nil, true)
		if v552 ~= nil and (v556 ~= nil or (v553 ~= nil or (v561 ~= nil or (v562 ~= nil or (v563 ~= nil or v564 ~= nil))))) then
			local v565 = p549.dependentMovingTools
			table.insert(v565, {
				["node"] = v552,
				["axis"] = v555,
				["rotation"] = { 0, 0, 0 },
				["rotationBasedLimits"] = v556,
				["speedScale"] = v553,
				["requiresMovement"] = v554,
				["minTransLimits"] = v561,
				["maxTransLimits"] = v562,
				["minRotLimits"] = v563,
				["maxRotLimits"] = v564
			})
		end
		v550 = v550 + 1
	end
end
function Cylindered.loadDependentParts(p_u_566, p_u_567, p568, p_u_569)
	p_u_569.dependentPartData = {}
	p_u_567:iterate(p568 .. ".dependentPart", function(_, p570)
		-- upvalues: (copy) p_u_567, (copy) p_u_566, (copy) p_u_569
		XMLUtil.checkDeprecatedXMLElements(p_u_567, p570 .. "#index", p570 .. "#node")
		local v571 = {
			["node"] = p_u_567:getValue(p570 .. "#node", nil, p_u_566.components, p_u_566.i3dMappings)
		}
		if v571.node ~= nil then
			v571.maxUpdateDistance = p_u_567:getValue(p570 .. "#maxUpdateDistance", "-")
			if v571.maxUpdateDistance == "-" then
				v571.maxUpdateDistance = (1 / 0)
			else
				local v572 = v571.maxUpdateDistance
				v571.maxUpdateDistance = tonumber(v572)
			end
			v571.part = nil
			local v573 = p_u_569.dependentPartData
			table.insert(v573, v571)
		end
	end)
end
function Cylindered.resolveDependentPartData(_, p574, p575)
	for _, v576 in pairs(p574) do
		if v576.part == nil and p575[v576.node] ~= nil then
			for v577 = 1, #p575[v576.node] do
				local v578 = p575[v576.node][v577]
				if v577 == 1 then
					v576.part = v578
					v578.isDependentPart = true
				else
					local v579 = {
						["node"] = v576.node,
						["maxUpdateDistance"] = v576.maxUpdateDistance,
						["part"] = v578
					}
					table.insert(p574, v579)
					v578.isDependentPart = true
				end
			end
		end
	end
	for v580 = #p574, 1, -1 do
		if p574[v580].part == nil then
			table.remove(p574, v580)
		end
	end
end
function Cylindered.loadDependentComponentJoints(p581, p582, p583, p584)
	if p581.isServer then
		p584.componentJoints = {}
		XMLUtil.checkDeprecatedXMLElements(p582, p583 .. "#componentJointIndex", p583 .. ".componentJoint#index")
		XMLUtil.checkDeprecatedXMLElements(p582, p583 .. "#anchorActor", p583 .. ".componentJoint#anchorActor")
		local v585 = 0
		while true do
			local v586 = p583 .. string.format(".componentJoint(%d)", v585)
			if not p582:hasProperty(v586) then
				break
			end
			local v587 = p582:getValue(v586 .. "#index")
			if v587 == nil or p581.componentJoints[v587] == nil then
				if not p582:getValue(v586 .. "#ignoreWarning") then
					Logging.xmlWarning(p582, "Invalid index for \'%s\'", v586)
				end
			else
				local v588 = p582:getValue(v586 .. "#anchorActor", 0)
				local v589 = p581.componentJoints[v587]
				local v590 = {
					["componentJoint"] = v589,
					["anchorActor"] = v588,
					["index"] = v587
				}
				local v591 = v589.jointNode
				if v590.anchorActor == 1 then
					v591 = v589.jointNodeActor1
				end
				local v592 = p581.components[v589.componentIndices[2]].node
				local v593, v594, v595 = localToLocal(v592, v591, 0, 0, 0)
				v590.x = v593
				v590.y = v594
				v590.z = v595
				local v596, v597, v598 = localDirectionToLocal(v592, v591, 0, 1, 0)
				v590.upX = v596
				v590.upY = v597
				v590.upZ = v598
				local v599, v600, v601 = localDirectionToLocal(v592, v591, 0, 0, 1)
				v590.dirX = v599
				v590.dirY = v600
				v590.dirZ = v601
				local v602 = p584.componentJoints
				table.insert(v602, v590)
			end
			v585 = v585 + 1
		end
	end
end
function Cylindered.loadDependentAttacherJoints(p603, p604, p605, p606)
	XMLUtil.checkDeprecatedXMLElements(p604, p605 .. "#jointIndices", p605 .. ".attacherJoint#jointIndices")
	local v607 = p604:getValue(p605 .. ".attacherJoint#jointIndices", nil, true)
	if v607 ~= nil then
		local v608 = p604:getValue(p605 .. ".attacherJoint#ignoreWarning", false)
		p606.attacherJoints = {}
		local v609
		if p603.getAttacherJoints == nil then
			v609 = nil
		else
			v609 = p603:getAttacherJoints()
		end
		if v609 ~= nil then
			for v610 = 1, #v607 do
				if v609[v607[v610]] == nil then
					if not v608 then
						Logging.xmlWarning(p604, "Invalid attacher joint index \'%s\' for \'%s\'!", v607[v610], p605)
					end
				else
					local v611 = p606.attacherJoints
					local v612 = v609[v607[v610]]
					table.insert(v611, v612)
				end
			end
		end
	end
	XMLUtil.checkDeprecatedXMLElements(p604, p605 .. "#inputAttacherJoint", p605 .. ".inputAttacherJoint#value")
	p606.inputAttacherJoint = p604:getValue(p605 .. ".inputAttacherJoint#value", false)
end
function Cylindered.loadDependentWheels(p613, p614, p615, p616)
	if SpecializationUtil.hasSpecialization(Wheels, p613.specializations) then
		local v617 = p614:getValue(p615 .. "#wheelIndices", nil, true)
		if v617 ~= nil then
			p616.wheels = {}
			for _, v618 in pairs(v617) do
				local v619 = p613:getWheelFromWheelIndex(v618)
				if v619 == nil then
					Logging.xmlWarning(p614, "Invalid wheelIndex \'%s\' for \'%s\'!", v618, p615)
				else
					local v620 = p616.wheels
					table.insert(v620, v619)
				end
			end
		end
		local v621 = p614:getValue(p615 .. "#wheelNodes")
		if v621 ~= nil and v621 ~= "" then
			p616.wheels = p616.wheels or {}
			local v622 = string.split(v621, " ")
			for v623 = 1, #v622 do
				local v624 = p613:getWheelByWheelNode(v622[v623])
				if v624 == nil then
					Logging.xmlWarning(p614, "Invalid wheelNode \'%s\' for \'%s\'!", v622[v623], p615)
				else
					local v625 = p616.wheels
					table.insert(v625, v624)
				end
			end
		end
	end
end
function Cylindered.loadDependentTranslatingParts(p626, p627, p628, p629)
	p629.translatingParts = {}
	if p629.hasReferencePoints then
		p629.divideTranslatingDistance = p627:getValue(p628 .. "#divideTranslatingDistance", true)
		p629.translatingPartsDivider = 0
		local v630 = 0
		while true do
			local v631 = p628 .. string.format(".translatingPart(%d)", v630)
			if not p627:hasProperty(v631) then
				break
			end
			XMLUtil.checkDeprecatedXMLElements(p627, v631 .. "#index", v631 .. "#node")
			local v632 = p627:getValue(v631 .. "#node", nil, p626.components, p626.i3dMappings)
			if v632 ~= nil then
				local v633 = {
					["node"] = v632
				}
				local v634, v635, v636 = getTranslation(v632)
				v633.startPos = { v634, v635, v636 }
				v633.lastZ = v636
				local v637
				if p629.referencePoint == nil then
					local v638 = 0
					for _, v639 in ipairs(p629.referencePoints) do
						local _, _, v640 = worldToLocal(v632, getWorldTranslation(v639))
						v638 = v638 + v640
					end
					v637 = v638 / p629.numReferencePoints
				else
					local v641, v642
					v641, v642, v637 = worldToLocal(v632, getWorldTranslation(p629.referencePoint))
				end
				v633.referenceDistance = p627:getValue(v631 .. "#referenceDistance", v637)
				v633.minZTrans = p627:getValue(v631 .. "#minZTrans")
				v633.maxZTrans = p627:getValue(v631 .. "#maxZTrans")
				v633.divideTranslatingDistance = p627:getValue(v631 .. "#divideTranslatingDistance", p629.divideTranslatingDistance)
				if v633.divideTranslatingDistance then
					p629.translatingPartsDivider = p629.translatingPartsDivider + 1
				end
				local v643 = p629.translatingParts
				table.insert(v643, v633)
			end
			v630 = v630 + 1
		end
		local v644 = p629.translatingPartsDivider
		p629.translatingPartsDivider = math.max(v644, 1)
		p629.numTranslatingParts = #p629.translatingParts
	end
end
function Cylindered.loadExtraDependentParts(_, _, _, _)
	return true
end
function Cylindered.loadDependentAnimations(_, p645, p646, p647)
	p647.dependentAnimations = {}
	local v648 = 0
	while true do
		local v649 = string.format("%s.dependentAnimation(%d)", p646, v648)
		if not p645:hasProperty(v649) then
			break
		end
		local v650 = p645:getValue(v649 .. "#name")
		if v650 ~= nil then
			local v651 = {
				["name"] = v650,
				["lastPos"] = 0,
				["translationAxis"] = p645:getValue(v649 .. "#translationAxis"),
				["rotationAxis"] = p645:getValue(v649 .. "#rotationAxis"),
				["node"] = p647.node
			}
			local v652 = p645:getValue(v649 .. "#useTranslatingPartIndex")
			if v652 ~= nil and p647.translatingParts[v652] ~= nil then
				v651.node = p647.translatingParts[v652].node
			end
			v651.minValue = p645:getValue(v649 .. "#minValue")
			v651.maxValue = p645:getValue(v649 .. "#maxValue")
			if v651.rotationAxis ~= nil then
				v651.minValue = MathUtil.degToRad(v651.minValue)
				v651.maxValue = MathUtil.degToRad(v651.maxValue)
			end
			v651.invert = p645:getValue(v649 .. "#invert", false)
			local v653 = p647.dependentAnimations
			table.insert(v653, v651)
		end
		v648 = v648 + 1
	end
end
function Cylindered.loadCopyLocalDirectionParts(p654, p655, p656, p657)
	p657.copyLocalDirectionParts = {}
	for _, v658 in p655:iterator(p656 .. ".copyLocalDirectionPart") do
		XMLUtil.checkDeprecatedXMLElements(p655, v658 .. "#index", v658 .. "#node")
		local v659 = p655:getValue(v658 .. "#node", nil, p654.components, p654.i3dMappings)
		if v659 ~= nil then
			local v660 = {
				["node"] = v659,
				["dirScale"] = p655:getValue(v658 .. "#dirScale", nil, true),
				["upScale"] = p655:getValue(v658 .. "#upScale", nil, true)
			}
			if v660.dirScale == nil then
				Logging.xmlWarning(p655, "Missing values for \'%s\'", v658 .. "#dirScale")
			elseif v660.upScale == nil then
				Logging.xmlWarning(p655, "Missing values for \'%s\'", v658 .. "#upScale")
			else
				p654:loadDependentComponentJoints(p655, v658, v660)
				local v661 = p657.copyLocalDirectionParts
				table.insert(v661, v660)
			end
		end
	end
end
function Cylindered.loadRotationBasedLimits(_, p662, p663, p664)
	local v665 = p662:getValue(p663 .. "#rotation")
	local v666 = p662:getValue(p663 .. "#rotMin")
	local v667 = p662:getValue(p663 .. "#rotMax")
	local v668 = p662:getValue(p663 .. "#transMin")
	local v669 = p662:getValue(p663 .. "#transMax")
	if v665 == nil or v666 == nil and (v667 == nil and (v668 == nil and v669 == nil)) then
		return nil
	end
	if p664.rotMin ~= nil and p664.rotMax ~= nil then
		v665 = (v665 - p664.rotMin) / (p664.rotMax - p664.rotMin)
	end
	return {
		["rotMin"] = v666,
		["rotMax"] = v667,
		["transMin"] = v668,
		["transMax"] = v669,
		["time"] = v665
	}
end
function Cylindered.loadActionSoundsFromXML(p670, p671, p672)
	local v673 = p670.spec_cylindered
	local v674 = 0
	while true do
		local v675 = string.format("actionSound(%d)", v674)
		local v676 = p672 .. "." .. v675
		if not p671:hasProperty(v676) then
			break
		end
		local v677 = g_soundManager:loadSampleFromXML(p671, p672, v675, p670.baseDirectory, p670.components, 0, AudioGroup.VEHICLE, p670.i3dMappings, p670)
		if v677 ~= nil then
			local v678 = p671:getValue(v676 .. "#actionNames")
			local v679 = string.split(v678:trim(), " ")
			local v680 = p671:getValue(v676 .. "#nodes")
			local v681 = string.split(v680, " ")
			for v682 = 1, #v681 do
				v681[v682] = I3DUtil.indexToObject(p670.components, v681[v682], p670.i3dMappings)
			end
			for v683 = 1, #v679 do
				local v684 = "SOUND_ACTION_" .. v679[v683]:upper()
				local v685 = Cylindered[v684]
				if v685 == nil then
					Logging.xmlWarning(p671, "Unable to find sound action \'%s\' for sound \'%s\'", v684, v676)
				else
					for v686 = 1, #v681 do
						local v687 = v681[v686]
						if v687 ~= nil then
							if v673.nodesToSamples[v687] == nil then
								v673.nodesToSamples[v687] = {}
							end
							if v673.nodesToSamples[v687][v685] == nil then
								v673.nodesToSamples[v687][v685] = {}
							end
							local v688 = p670:getMovingPartByNode(v687) or (p670:getTranslatingPartByNode(v687) or p670:getMovingToolByNode(v687))
							if v688 == nil then
								Logging.xmlWarning(p671, "Unable to find movingPart or translatingPart for node \'%s\' in %s", getName(v687), v676)
							else
								v688.samplesByAction = v673.nodesToSamples[v687]
							end
							local v689 = v673.nodesToSamples[v687][v685]
							table.insert(v689, v677)
						end
					end
				end
			end
			v677.dropOffFactor = p671:getValue(v676 .. ".pitch#dropOffFactor", 1)
			v677.dropOffTime = p671:getValue(v676 .. ".pitch#dropOffTime", 0) * 1000
			v677.actionNames = v679
			v677.nodes = v681
			local v690 = v673.actionSamples
			table.insert(v690, v677)
		end
		v674 = v674 + 1
	end
end
function Cylindered.checkMovingPartDirtyUpdateNode(_, _, _) end
function Cylindered.setMovingToolDirty(p691, p692, p693, p694)
	local v695 = p691.spec_cylindered.nodesToMovingTools[p692]
	if v695 ~= nil then
		if v695.transSpeed ~= nil then
			local v696 = v695.curTrans[v695.translationAxis]
			local v697 = v695.curTrans
			local v698 = v695.curTrans
			local v699 = v695.curTrans
			local v700, v701, v702 = getTranslation(v695.node)
			v697[1] = v700
			v698[2] = v701
			v699[3] = v702
			local v703 = v695.curTrans[v695.translationAxis]
			local v704 = v703 - v696
			if math.abs(v704) > 0.0001 then
				local v705 = v704 > 0
				local v706 = v703 - (v695.transMax or (1 / 0))
				local v707
				if math.abs(v706) < 0.0001 then
					v707 = true
				else
					local v708 = v703 - (v695.transMin or (1 / 0))
					v707 = math.abs(v708) < 0.0001
				end
				local v709 = v696 - (v695.transMax or (1 / 0))
				local v710
				if math.abs(v709) < 0.0001 then
					v710 = true
				else
					local v711 = v696 - (v695.transMin or (1 / 0))
					v710 = math.abs(v711) < 0.0001
				end
				p691:updateMovingToolSoundEvents(v695, v705, v707, v710)
			end
		end
		if v695.rotSpeed ~= nil then
			local v712 = v695.curRot[v695.rotationAxis]
			local v713 = v695.curRot
			local v714 = v695.curRot
			local v715 = v695.curRot
			local v716, v717, v718 = getRotation(v695.node)
			v713[1] = v716
			v714[2] = v717
			v715[3] = v718
			local v719 = v695.curRot[v695.rotationAxis]
			local v720 = v719 - v712
			if math.abs(v720) > 0.0001 then
				local v721 = v720 > 0
				local v722 = v719 - (v695.rotMax or (1 / 0))
				local v723
				if math.abs(v722) < 0.0001 then
					v723 = true
				else
					local v724 = v719 - (v695.rotMin or (1 / 0))
					v723 = math.abs(v724) < 0.0001
				end
				local v725 = v712 - (v695.rotMax or (1 / 0))
				local v726
				if math.abs(v725) < 0.0001 then
					v726 = true
				else
					local v727 = v712 - (v695.rotMin or (1 / 0))
					v726 = math.abs(v727) < 0.0001
				end
				p691:updateMovingToolSoundEvents(v695, v721, v723, v726)
			end
		end
		Cylindered.setDirty(p691, v695)
		if not p691.isServer and p691.isClient then
			v695.networkInterpolators.translation:setValue(v695.curTrans[v695.translationAxis])
			v695.networkInterpolators.rotation:setAngle(v695.curRot[v695.rotationAxis])
		end
		if p693 or p691.finishedFirstUpdate and not p691.isActive then
			p691:updateDirtyMovingParts(p694 or g_currentDt, true)
		end
	end
end
function Cylindered.setMovingPartReferenceNode(p728, p729, p730, p731)
	local v732 = p728.spec_cylindered
	local v733 = p728:getMovingPartByNode(p729)
	if v733 ~= nil then
		if v733.referencePointOrig == nil then
			v733.referencePointOrig = v733.referencePoint
		end
		if p730 == nil then
			v733.referencePoint = v733.referencePointOrig
		else
			v733.referencePoint = p730
		end
		if p731 ~= nil then
			if p731 then
				table.addElement(v732.activeDirtyMovingParts, v733)
			elseif not v733.isActiveDirty then
				table.removeElement(v732.activeDirtyMovingParts, v733)
			end
		end
		Cylindered.updateMovingPart(p728, v733, false, true, true)
		p728:updateExtraDependentParts(v733, 99999)
		p728:updateDependentAnimations(v733, 99999)
		for _, v734 in pairs(v733.dependentPartData) do
			if (v734.part.referencePointOrig or v734.part.referencePoint) == v733.referencePointOrig then
				p728:setMovingPartReferenceNode(v734.part.node, p730, p731)
			end
		end
	end
end
function Cylindered.updateMovingPartByNode(p735, p736, p737)
	local v738 = p735.spec_cylindered.nodesToMovingParts[p736]
	if v738 ~= nil then
		Cylindered.updateMovingPart(p735, v738, false, true, true)
		p735:updateExtraDependentParts(v738, p737)
		p735:updateDependentAnimations(v738, p737)
	end
end
function Cylindered.updateCylinderedInitial(p739, p740, p741)
	local v742 = p740 == nil and true or p740
	if p741 == nil then
		p741 = false
	end
	local v743 = p739.spec_cylindered
	for _, v744 in pairs(v743.activeDirtyMovingParts) do
		Cylindered.setDirty(p739, v744)
	end
	for _, v745 in ipairs(v743.movingTools) do
		if v745.isDirty then
			Cylindered.updateWheels(p739, v745)
			if p739.isServer then
				Cylindered.updateComponentJoints(p739, v745, v742)
			end
			v745.isDirty = p741
		end
		p739:updateExtraDependentParts(v745, 9999)
		p739:updateDependentAnimations(v745, 9999)
	end
	for _, v746 in ipairs(v743.movingParts) do
		local v747 = p739:getIsMovingPartActive(v746)
		if v747 or v746.smoothedDirectionScale and v746.smoothedDirectionScaleAlpha ~= 0 then
			if v746.isDirty then
				Cylindered.updateMovingPart(p739, v746, v742, nil, v747, false)
				Cylindered.updateWheels(p739, v746)
				v746.isDirty = p741
			end
			p739:updateExtraDependentParts(v746, 9999)
			p739:updateDependentAnimations(v746, 9999)
		end
	end
end
function Cylindered.allowLoadMovingToolStates(_, _)
	return true
end
function Cylindered.getMovingToolByNode(p748, p749)
	return p748.spec_cylindered.nodesToMovingTools[p749]
end
function Cylindered.getMovingPartByNode(p750, p751)
	return p750.spec_cylindered.nodesToMovingParts[p751]
end
function Cylindered.getTranslatingPartByNode(p752, p753)
	local v754 = p752.spec_cylindered
	for v755 = 1, #v754.movingParts do
		local v756 = v754.movingParts[v755]
		if v756.translatingParts ~= nil then
			for v757 = 1, v756.numTranslatingParts do
				if v756.translatingParts[v757].node == p753 then
					return v756.translatingParts[v757]
				end
			end
		end
	end
	return nil
end
function Cylindered.getIsMovingToolActive(_, p758)
	return p758.isActive
end
function Cylindered.getIsMovingPartActive(_, p759)
	return p759.isActive
end
function Cylindered.getMovingToolMoveValue(_, p760)
	return p760.move + p760.externalMove
end
function Cylindered.isDetachAllowed(p761, p762)
	local v763 = p761.spec_cylindered
	if v763.detachLockNodes ~= nil then
		for v764, v765 in pairs(v763.detachLockNodes) do
			local v766 = v764.node
			local v767 = { getRotation(v766) }
			if v765.detachingRotMinLimit ~= nil and v767[v764.rotationAxis] < v765.detachingRotMinLimit then
				return false, nil
			end
			if v765.detachingRotMaxLimit ~= nil and v767[v764.rotationAxis] > v765.detachingRotMaxLimit then
				return false, nil
			end
			local v768 = { getTranslation(v766) }
			if v765.detachingTransMinLimit ~= nil and v768[v764.translationAxis] < v765.detachingTransMinLimit then
				return false, nil
			end
			if v765.detachingTransMaxLimit ~= nil and v768[v764.translationAxis] > v765.detachingTransMaxLimit then
				return false, nil
			end
		end
	end
	return p762(p761)
end
function Cylindered.loadObjectChangeValuesFromXML(p_u_769, p770, p771, p772, p_u_773, p774)
	p770(p_u_769, p771, p772, p_u_773, p774)
	local v775 = p_u_769.spec_cylindered
	if v775.nodesToMovingTools ~= nil and v775.nodesToMovingTools[p_u_773] ~= nil then
		local v776 = v775.nodesToMovingTools[p_u_773]
		local v777 = p772 .. "#movingToolRotMaxActive"
		local v778 = v776.rotMax or 0
		p774.movingToolRotMaxActive = p771:getValue(v777, (math.deg(v778)))
		local v779 = p772 .. "#movingToolRotMaxInactive"
		local v780 = v776.rotMax or 0
		p774.movingToolRotMaxInactive = p771:getValue(v779, (math.deg(v780)))
		local v781 = p772 .. "#movingToolRotMinActive"
		local v782 = v776.rotMin or 0
		p774.movingToolRotMinActive = p771:getValue(v781, (math.deg(v782)))
		local v783 = p772 .. "#movingToolRotMinInactive"
		local v784 = v776.rotMin or 0
		p774.movingToolRotMinInactive = p771:getValue(v783, (math.deg(v784)))
		p774.movingToolStartRotActive = p771:getValue(p772 .. "#movingToolStartRotActive")
		p774.movingToolStartRotInactive = p771:getValue(p772 .. "#movingToolStartRotInactive")
		p774.movingToolTransMaxActive = p771:getValue(p772 .. "#movingToolTransMaxActive", v776.transMax)
		p774.movingToolTransMaxInactive = p771:getValue(p772 .. "#movingToolTransMaxInactive", v776.transMax)
		p774.movingToolTransMinActive = p771:getValue(p772 .. "#movingToolTransMinActive", v776.transMin)
		p774.movingToolTransMinInactive = p771:getValue(p772 .. "#movingToolTransMinInactive", v776.transMin)
		p774.movingToolStartTransActive = p771:getValue(p772 .. "#movingToolStartTransActive")
		p774.movingToolStartTransInactive = p771:getValue(p772 .. "#movingToolStartTransInactive")
	end
	ObjectChangeUtil.loadValueType(p774.values, p771, p772, "movingPartUpdate", nil, function(p785)
		-- upvalues: (copy) p_u_769, (copy) p_u_773
		if p_u_769.getMovingPartByNode ~= nil then
			local v786 = p_u_769:getMovingPartByNode(p_u_773)
			if v786 ~= nil then
				v786.isActive = p785
			end
		end
	end, false)
end
function Cylindered.setObjectChangeValues(p787, p788, p789, p790)
	p788(p787, p789, p790)
	local v791 = p787.spec_cylindered
	if v791.nodesToMovingTools ~= nil and v791.nodesToMovingTools[p789.node] ~= nil then
		local v792 = v791.nodesToMovingTools[p789.node]
		if p790 then
			v792.rotMax = p789.movingToolRotMaxActive
			v792.rotMin = p789.movingToolRotMinActive
			v792.transMax = p789.movingToolTransMaxActive
			v792.transMin = p789.movingToolTransMinActive
			v792.startRot = p789.movingToolStartRotActive or v792.startRot
			v792.startTrans = p789.movingToolStartTransActive or v792.startTrans
			return
		end
		v792.rotMax = p789.movingToolRotMaxInactive
		v792.rotMin = p789.movingToolRotMinInactive
		v792.transMax = p789.movingToolTransMaxInactive
		v792.transMin = p789.movingToolTransMinInactive
		v792.startRot = p789.movingToolStartRotInactive or v792.startRot
		v792.startTrans = p789.movingToolStartTransInactive or v792.startTrans
	end
end
function Cylindered.loadDischargeNode(p793, p794, p795, p796, p797)
	if not p794(p793, p795, p796, p797) then
		return false
	end
	local v798 = p796 .. ".movingToolActivation"
	if p795:hasProperty(v798) then
		p797.movingToolActivation = {}
		p797.movingToolActivation.node = p795:getValue(v798 .. "#node", nil, p793.components, p793.i3dMappings)
		p797.movingToolActivation.isInverted = p795:getValue(v798 .. "#isInverted", false)
		p797.movingToolActivation.openFactor = p795:getValue(v798 .. "#openFactor", 1)
		p797.movingToolActivation.openOffset = p795:getValue(v798 .. "#openOffset", 0)
		p797.movingToolActivation.openOffsetInv = 1 - p797.movingToolActivation.openOffset
	end
	return true
end
function Cylindered.getDischargeNodeEmptyFactor(p799, p800, p801)
	if p801.movingToolActivation == nil then
		return p800(p799, p801)
	end
	local v802 = p799.spec_cylindered
	local v803 = p801.movingToolActivation
	local v804 = p800(p799, p801)
	local v805 = v802.nodesToMovingTools[v803.node]
	local v806 = Cylindered.getMovingToolState(p799, v805)
	local v807 = math.clamp(v806, 0, 1)
	if v803.isInverted then
		local v808 = v807 - 1
		v807 = math.abs(v808)
	end
	local v809 = v807 - v803.openOffset
	local v810 = math.max(v809, 0) / v803.openOffsetInv / v803.openFactor
	return v804 * math.clamp(v810, 0, 1)
end
function Cylindered.loadShovelNode(p811, p812, p813, p814, p815)
	if not p812(p811, p813, p814, p815) then
		return false
	end
	local v816 = p814 .. ".movingToolActivation"
	if not p813:hasProperty(v816) then
		return true
	end
	p815.movingToolActivation = {}
	p815.movingToolActivation.node = p813:getValue(v816 .. "#node", nil, p811.components, p811.i3dMappings)
	p815.movingToolActivation.isInverted = p813:getValue(v816 .. "#isInverted", false)
	p815.movingToolActivation.openFactor = p813:getValue(v816 .. "#openFactor", 1)
	return true
end
function Cylindered.getShovelNodeIsActive(p817, p818, p819)
	local v820 = p818(p817, p819)
	if not v820 or p819.movingToolActivation == nil then
		return v820
	end
	local v821 = p817.spec_cylindered
	local v822 = p819.movingToolActivation
	local v823 = v821.nodesToMovingTools[v822.node]
	local v824 = Cylindered.getMovingToolState(p817, v823)
	if v822.isInverted then
		local v825 = v824 - 1
		v824 = math.abs(v825)
	end
	return v822.openFactor < v824
end
function Cylindered.loadDynamicMountGrabFromXML(p826, p827, p828, p829, p830)
	if not p827(p826, p828, p829, p830) then
		return false
	end
	local v831 = p829 .. ".movingToolActivation"
	if not p828:hasProperty(v831) then
		return true
	end
	p830.movingToolActivation = {}
	p830.movingToolActivation.node = p828:getValue(v831 .. "#node", nil, p826.components, p826.i3dMappings)
	p830.movingToolActivation.isInverted = p828:getValue(v831 .. "#isInverted", false)
	p830.movingToolActivation.openFactor = p828:getValue(v831 .. "#openFactor", 1)
	return true
end
function Cylindered.getIsDynamicMountGrabOpened(p832, p833, p834)
	local v835 = p833(p832, p834)
	if not v835 or p834.movingToolActivation == nil then
		return v835
	end
	local v836 = p832.spec_cylindered
	local v837 = p834.movingToolActivation
	local v838 = v836.nodesToMovingTools[v837.node]
	local v839 = Cylindered.getMovingToolState(p832, v838)
	if v837.isInverted then
		local v840 = v839 - 1
		v839 = math.abs(v840)
	end
	return v837.openFactor < v839
end
function Cylindered.setComponentJointFrame(p841, p842, p843, p844)
	p842(p841, p843, p844)
	local v845 = p841.spec_cylindered
	for _, v846 in ipairs(v845.movingTools) do
		for _, v847 in ipairs(v846.componentJoints) do
			local v848 = p841.componentJoints[v847.index]
			local v849 = v848.jointNode
			if v847.anchorActor == 1 then
				v849 = v848.jointNodeActor1
			end
			local v850 = p841.components[v848.componentIndices[2]].node
			local v851, v852, v853 = localToLocal(v850, v849, 0, 0, 0)
			v847.x = v851
			v847.y = v852
			v847.z = v853
			local v854, v855, v856 = localDirectionToLocal(v850, v849, 0, 1, 0)
			v847.upX = v854
			v847.upY = v855
			v847.upZ = v856
			local v857, v858, v859 = localDirectionToLocal(v850, v849, 0, 0, 1)
			v847.dirX = v857
			v847.dirY = v858
			v847.dirZ = v859
		end
	end
end
function Cylindered.getAdditionalSchemaText(p860, p861)
	local v862 = p861(p860)
	if p860.isClient and p860:getIsActiveForInput(true) then
		local v863 = p860.spec_cylindered
		if #v863.controlGroupNames > 1 and v863.currentControlGroupIndex ~= 0 then
			local v864 = v863.currentControlGroupIndex
			v862 = tostring(v864)
		end
	end
	return v862
end
function Cylindered.getWearMultiplier(p865, p866)
	local v867 = p865.spec_cylindered
	local v868 = p866(p865)
	if v867.isHydraulicSamplePlaying then
		v868 = v868 + p865:getWorkWearMultiplier()
	end
	return v868
end
function Cylindered.getDoConsumePtoPower(p869, p870)
	return p870(p869) or p869.spec_cylindered.powerConsumingTimer > 0
end
function Cylindered.getConsumingLoad(p871, p872)
	local v873, v874 = p872(p871)
	local v875 = p871.spec_cylindered
	local v876 = v875.powerConsumingTimer / v875.powerConsumingActiveTimeOffset
	return v873 + math.max(v876, 0), v874 + 1
end
function Cylindered.onRegisterActionEvents(p877, _, p878)
	if p877.isClient then
		local v879 = p877.spec_cylindered
		p877:clearActionEventsTable(v879.actionEvents)
		if p878 then
			for v880 = 1, #v879.movingTools do
				local v881 = v879.movingTools[v880]
				local v882 = v881.controlGroupIndex == 0 and true or v881.controlGroupIndex == v879.currentControlGroupIndex
				local v883 = g_gameSettings:getValue(GameSettings.SETTING.EASY_ARM_CONTROL)
				local v884 = not (v883 and v881.easyArmControlActive or v883)
				if v884 then
					v884 = not v881.isEasyControlTarget
				end
				if v881.axisActionIndex ~= nil and (v882 and v884) then
					local _, v885 = p877:addPoweredActionEvent(v879.actionEvents, v881.axisActionIndex, p877, Cylindered.actionEventInput, true, false, true, true, v880, v881.axisActionIcon)
					g_inputBinding:setActionEventTextPriority(v885, GS_PRIO_NORMAL)
				end
			end
		end
	end
end
function Cylindered.onPostAttach(p886, _, _, _)
	local v887 = p886.spec_cylindered
	for _, v888 in ipairs(v887.movingTools) do
		local v889 = false
		if v888.transSpeed ~= nil then
			local v890 = v888.curTrans[v888.translationAxis]
			local v891 = false
			if v888.attachTransMax == nil or v888.attachTransMax >= v890 then
				if v888.attachTransMin ~= nil and v890 < v888.attachTransMin then
					v890 = v888.attachTransMin
					v891 = true
				end
			else
				v890 = v888.attachTransMax
				v891 = true
			end
			if v891 then
				v888.curTrans[v888.translationAxis] = v890
				local v892 = setTranslation
				local v893 = v888.node
				local v894 = v888.curTrans
				v892(v893, unpack(v894))
				v889 = true
			end
		end
		if v888.rotSpeed ~= nil then
			local v895 = v888.curRot[v888.rotationAxis]
			local v896 = false
			if v888.attachRotMax == nil or v888.attachRotMax >= v895 then
				if v888.attachRotMin ~= nil and v895 < v888.attachRotMin then
					v895 = v888.attachRotMin
					v896 = true
				end
			else
				v895 = v888.attachRotMax
				v896 = true
			end
			if v896 then
				v888.curRot[v888.rotationAxis] = v895
				local v897 = setRotation
				local v898 = v888.node
				local v899 = v888.curRot
				v897(v898, unpack(v899))
				v889 = true
			end
		end
		if v889 then
			Cylindered.setDirty(p886, v888)
		end
	end
end
function Cylindered.onSelect(p900, p901)
	local v902 = p900.spec_cylindered
	local v903 = v902.controlGroupMapping[p901]
	if v903 == nil then
		v902.currentControlGroupIndex = 0
	else
		v902.currentControlGroupIndex = v903
	end
end
function Cylindered.onUnselect(p904)
	p904.spec_cylindered.currentControlGroupIndex = 0
end
function Cylindered.onDeactivate(p905)
	if p905.isClient then
		local v906 = p905.spec_cylindered
		g_soundManager:stopSample(v906.samples.hydraulic)
		v906.isHydraulicSamplePlaying = false
		for _, v907 in ipairs(v906.movingTools) do
			v907.move = 0
			v907.externalMove = 0
		end
	end
end
function Cylindered.onAnimationPartChanged(p908, p909)
	p908:setMovingToolDirty(p909)
end
function Cylindered.onAIImplementStart(p910)
	local v911 = p910.spec_cylindered
	for _, v912 in ipairs(v911.movingTools) do
		if v912.aiActivePosition ~= nil then
			v912.curTargetPosition = v912.aiActivePosition
			v912.curTargetDirection = v912.curTargetPosition - Cylindered.getMovingToolState(p910, v912)
		end
	end
end
function Cylindered.onVehicleSettingChanged(p913, p914, p915)
	if p914 == GameSettings.SETTING.EASY_ARM_CONTROL then
		p913:setIsEasyControlActive(p915)
	end
end
function Cylindered.onRegisterAnimationValueTypes(p_u_916)
	p_u_916:registerAnimationValueType("movingPartReferencePoint", "", "", false, AnimationValueFloat, function(p917, p918, p919)
		p917.node = p918:getValue(p919 .. "#node", nil, p917.part.components, p917.part.i3dMappings)
		p917.startReferencePoint = p918:getValue(p919 .. "#startReferencePoint", nil, p917.part.components, p917.part.i3dMappings)
		p917.endReferencePoint = p918:getValue(p919 .. "#endReferencePoint", nil, p917.part.components, p917.part.i3dMappings)
		if p917.node == nil or (p917.startReferencePoint == nil or p917.endReferencePoint == nil) then
			return false
		end
		p917:setWarningInformation("node: " .. getName(p917.node))
		p917:addCompareParameters("node")
		p917.animatedReferencePoint = createTransformGroup("animatedReferencePoint_" .. getName(p917.node))
		link(getParent(p917.node), p917.animatedReferencePoint)
		setWorldTranslation(p917.animatedReferencePoint, getWorldTranslation(p917.startReferencePoint))
		p917.startValue = { 0 }
		p917.endValue = { 1 }
		return true
	end, function(p920)
		local v921 = p920.startValue or p920.endValue
		if p920.animation.currentSpeed < 0 then
			v921 = p920.endValue or p920.startValue
		end
		return v921[1]
	end, function(p922, p923)
		-- upvalues: (copy) p_u_916
		if p922.movingPart == nil then
			p922.movingPart = p_u_916:getMovingPartByNode(p922.node)
		end
		local v924, v925, v926 = localToLocal(p922.startReferencePoint, getParent(p922.node), 0, 0, 0)
		local v927, v928, v929 = localToLocal(p922.endReferencePoint, getParent(p922.node), 0, 0, 0)
		local v930, v931, v932 = MathUtil.vector3Lerp(v924, v925, v926, v927, v928, v929, p923)
		setTranslation(p922.animatedReferencePoint, v930, v931, v932)
		if p922.movingPart ~= nil then
			if p923 == 1 then
				p_u_916:setMovingPartReferenceNode(p922.movingPart, p922.endReferencePoint)
				return
			end
			if p923 == 0 then
				p_u_916:setMovingPartReferenceNode(p922.movingPart, p922.startReferencePoint)
				return
			end
			p_u_916:setMovingPartReferenceNode(p922.movingPart, p922.animatedReferencePoint)
		end
	end)
end
function Cylindered.setToolTranslation(p933, p934, p935, p936, p937)
	local v938 = p934.curTrans
	local v939 = p934.curTrans
	local v940 = p934.curTrans
	local v941, v942, v943 = getTranslation(p934.node)
	v938[1] = v941
	v939[2] = v942
	v940[3] = v943
	local v944 = p934.curTrans[p934.translationAxis]
	local v945
	if p935 == nil then
		v945 = v944 + p937
	else
		v945 = v944 + p935 * p936
	end
	if p934.transMax ~= nil then
		local v946 = p934.transMax
		v945 = math.min(v945, v946)
	end
	if p934.transMin ~= nil then
		local v947 = p934.transMin
		v945 = math.max(v945, v947)
	end
	local v948 = v945 - v944
	if p936 ~= 0 then
		p934.lastTransSpeed = v948 / p936
	end
	if math.abs(v948) <= 0.0001 then
		return false
	end
	p934.curTrans[p934.translationAxis] = v945
	setTranslation(p934.node, p934.curTrans[1], p934.curTrans[2], p934.curTrans[3])
	p933:updateMovingToolSoundEvents(p934, v948 > 0, v945 == p934.transMax and true or v945 == p934.transMin, v944 == p934.transMax and true or v944 == p934.transMin)
	SpecializationUtil.raiseEvent(p933, "onMovingToolChanged", p934, p935, p936)
	return true
end
function Cylindered.setAbsoluteToolTranslation(p949, p950, p951)
	local v952 = p950.curTrans
	local v953 = p950.curTrans
	local v954 = p950.curTrans
	local v955, v956, v957 = getTranslation(p950.node)
	v952[1] = v955
	v953[2] = v956
	v954[3] = v957
	local v958 = p950.curTrans[p950.translationAxis]
	if Cylindered.setToolTranslation(p949, p950, nil, 0, p951 - v958) then
		Cylindered.setDirty(p949, p950)
		p949:raiseDirtyFlags(p950.dirtyFlag)
		p949:raiseDirtyFlags(p949.spec_cylindered.cylinderedDirtyFlag)
	end
end
function Cylindered.setToolRotation(p959, p960, p961, p962, p963)
	local v964 = p960.curRot
	local v965 = p960.curRot
	local v966 = p960.curRot
	local v967, v968, v969 = getRotation(p960.node)
	v964[1] = v967
	v965[2] = v968
	v966[3] = v969
	local v970 = p960.curRot[p960.rotationAxis]
	local v971
	if p961 == nil then
		v971 = v970 + p963
	else
		v971 = v970 + p961 * p962
	end
	if p960.rotMax ~= nil then
		local v972 = p960.rotMax
		v971 = math.min(v971, v972)
	end
	if p960.rotMin ~= nil then
		local v973 = p960.rotMin
		v971 = math.max(v971, v973)
	end
	local v974 = v971 - p960.curRot[p960.rotationAxis]
	if p961 ~= nil and p962 ~= 0 then
		p960.lastRotSpeed = v974 / p962
	end
	if math.abs(v974) <= 0.0001 then
		return false
	end
	if p960.rotMin == nil and p960.rotMax == nil then
		if v971 > 6.283185307179586 then
			v971 = v971 - 6.283185307179586
		end
		if v971 < 0 then
			v971 = v971 + 6.283185307179586
		end
	end
	p960.curRot[p960.rotationAxis] = v971
	setRotation(p960.node, p960.curRot[1], p960.curRot[2], p960.curRot[3])
	p959:updateMovingToolSoundEvents(p960, v974 > 0, v971 == p960.rotMax and true or v971 == p960.rotMin, v970 == p960.rotMax and true or v970 == p960.rotMin)
	SpecializationUtil.raiseEvent(p959, "onMovingToolChanged", p960, p961, p962)
	return true
end
function Cylindered.setAbsoluteToolRotation(p975, p976, p977, p978)
	local v979 = p976.curRot
	local v980 = p976.curRot
	local v981 = p976.curRot
	local v982, v983, v984 = getRotation(p976.node)
	v979[1] = v982
	v980[2] = v983
	v981[3] = v984
	local v985 = p976.curRot[p976.rotationAxis]
	if Cylindered.setToolRotation(p975, p976, nil, 0, p977 - v985) then
		Cylindered.setDirty(p975, p976)
		if p978 ~= nil and p978 then
			p975:updateDelayedTool(p976)
		end
		p975:raiseDirtyFlags(p976.dirtyFlag)
		p975:raiseDirtyFlags(p975.spec_cylindered.cylinderedDirtyFlag)
	end
end
function Cylindered.setToolAnimation(p986, p987, p988, p989)
	local v990 = p986:getAnimationTime(p987.animName)
	local v991 = v990 - p987.curAnimTime
	if math.abs(v991) > 0.001 then
		p987.networkInterpolators.resetAnimInterpolation = true
	end
	p987.curAnimTime = v990
	local v992 = p987.curAnimTime + p988 * p989
	local v993 = p987.curAnimTime
	if p987.animMaxTime ~= nil then
		local v994 = p987.animMaxTime
		v992 = math.min(v992, v994)
	end
	if p987.animMinTime ~= nil then
		local v995 = p987.animMinTime
		v992 = math.max(v992, v995)
	end
	local v996 = v992 - p987.curAnimTime
	if p989 ~= 0 then
		p987.lastAnimSpeed = v996 / p989
	end
	if math.abs(v996) <= 0.0001 then
		return false
	end
	p987.curAnimTime = v992
	p986:setAnimationTime(p987.animName, v992, nil, true)
	p986:updateMovingToolSoundEvents(p987, v996 > 0, (v992 == p987.animMaxTime or (v992 == p987.animMinTime or v992 == 0)) and true or v992 == 1, (v993 == p987.animMaxTime or (v993 == p987.animMinTime or v993 == 0)) and true or v993 == 1)
	SpecializationUtil.raiseEvent(p986, "onMovingToolChanged", p987, p988, p989)
	return true
end
function Cylindered.getMovingToolState(p997, p998)
	local v999 = 0
	if p998.rotMax == nil or p998.rotMin == nil then
		if p998.transMax == nil or p998.transMin == nil then
			if p998.animName == nil then
				return v999
			else
				return p997:getAnimationTime(p998.animName)
			end
		else
			return (p998.curTrans[p998.translationAxis] - p998.transMin) / (p998.transMax - p998.transMin)
		end
	else
		return (p998.curRot[p998.rotationAxis] - p998.rotMin) / (p998.rotMax - p998.rotMin)
	end
end
function Cylindered.setDirty(p1000, p1001)
	if not p1001.isDirty or p1000.spec_cylindered.isLoading then
		p1001.isDirty = true
		p1000.anyMovingPartsDirty = true
		if p1001.delayedNode ~= nil then
			p1000:setDelayedData(p1001)
		end
		if p1001.isTool then
			Cylindered.updateAttacherJoints(p1000, p1001)
			Cylindered.updateWheels(p1000, p1001)
		end
		for _, v1002 in pairs(p1001.dependentPartData) do
			if p1000.currentUpdateDistance < v1002.maxUpdateDistance then
				Cylindered.setDirty(p1000, v1002.part)
			end
		end
	end
end
function Cylindered.updateWheels(_, p1003)
	if p1003.wheels ~= nil then
		for _, v1004 in pairs(p1003.wheels) do
			v1004.physics:updateShapePosition()
			for _, v1005 in ipairs(v1004.wheelChocks) do
				v1005:update()
			end
		end
	end
end
function Cylindered.updateMovingPart(p1006, p1007, p1008, p1009, p1010, p1011)
	local v1012 = nil
	local v1013 = nil
	local v1014 = nil
	local v1015 = 0
	local v1016 = 0
	local v1017 = 0
	local v1018 = false
	local v1019 = false
	if p1007.hasReferencePoints then
		if p1007.moveToReferenceFrame then
			local v1020, v1021, v1022 = localToLocal(p1007.referenceFrame, getParent(p1007.node), p1007.referenceFrameOffset[1], p1007.referenceFrameOffset[2], p1007.referenceFrameOffset[3])
			setTranslation(p1007.node, v1020, v1021, v1022)
			v1018 = true
		end
		if p1007.referencePoint == nil then
			local v1023 = 0
			local v1024 = 0
			local v1025 = 0
			for _, v1026 in ipairs(p1007.referencePoints) do
				local v1027, v1028, v1029 = getWorldTranslation(v1026)
				v1023 = v1023 + v1027
				v1024 = v1024 + v1028
				v1025 = v1025 + v1029
			end
			v1012 = v1023 / p1007.numReferencePoints
			v1013 = v1024 / p1007.numReferencePoints
			v1014 = v1025 / p1007.numReferencePoints
		else
			v1012, v1013, v1014 = getWorldTranslation(p1007.referencePoint)
		end
		if p1007.referenceDistance == 0 then
			if p1007.useLocalOffset then
				local v1030, v1031, v1032 = worldToLocal(p1007.node, v1012, v1013, v1014)
				v1015, v1016, v1017 = localDirectionToWorld(p1007.node, v1030 - p1007.localReferencePoint[1], v1031 - p1007.localReferencePoint[2], v1032)
			else
				local v1033, v1034, v1035 = getWorldTranslation(p1007.node)
				v1015 = v1012 - v1033
				v1016 = v1013 - v1034
				v1017 = v1014 - v1035
			end
		else
			if p1007.updateLocalReferenceDistance then
				local _, v1036, v1037 = worldToLocal(p1007.node, getWorldTranslation(p1007.localReferencePointNode))
				p1007.localReferenceDistance = MathUtil.vector2Length(v1036, v1037)
			end
			if p1007.referenceDistancePoint ~= nil then
				local _, _, v1038 = worldToLocal(p1007.node, getWorldTranslation(p1007.referenceDistancePoint))
				p1007.referenceDistance = v1038
			end
			if p1007.localReferenceTranslate then
				local _, v1039, v1040 = worldToLocal(p1007.node, v1012, v1013, v1014)
				if math.abs(v1039) < p1007.referenceDistance then
					local v1041 = p1007.referenceDistance * p1007.referenceDistance - v1039 * v1039
					local v1042 = math.sqrt(v1041)
					local v1043 = v1040 - v1042 - p1007.localReferenceDistance
					local v1044 = v1040 + v1042 - p1007.localReferenceDistance
					if math.abs(v1044) >= math.abs(v1043) then
						v1044 = v1043
					end
					local v1045 = getParent(p1007.node)
					local v1046 = p1007.localReferenceTranslation
					local v1047, v1048, v1049 = unpack(v1046)
					local _, _, v1050 = localToLocal(v1045, p1007.node, v1047, v1048, v1049)
					local v1051, v1052, v1053 = localDirectionToLocal(p1007.node, v1045, 0, 0, v1044 - v1050)
					setTranslation(p1007.node, v1047 + v1051, v1048 + v1052, v1049 + v1053)
					v1018 = true
				end
			else
				local v1054 = p1007.localReferenceDistance
				local v1055 = p1007.referenceDistance
				if p1007.dynamicLocalReferenceDistance then
					local _, v1056, v1057 = worldToLocal(p1007.node, getWorldTranslation(p1007.localReferencePointNode))
					local _, v1058, v1059 = worldToLocal(p1007.node, localToWorld(p1007.localReferencePointNode, 0, 0, p1007.referenceDistance))
					v1055 = MathUtil.vector2Length(v1056 - v1058, v1057 - v1059)
				end
				local _, v1060, v1061 = worldToLocal(p1007.node, v1012, v1013, v1014)
				local v1064, v1065, v1064, v1065 = MathUtil.getCircleCircleIntersection(0, 0, v1054, v1060, v1061, v1055)
				local v1066 = true
				if p1007.referenceDistanceThreshold > 0 then
					local v1067, v1068, v1069 = getWorldTranslation(p1007.localReferencePointNode)
					local v1070 = MathUtil.vector3Length(v1012 - v1067, v1013 - v1068, v1014 - v1069) - p1007.referenceDistance
					if math.abs(v1070) < p1007.referenceDistanceThreshold then
						v1066 = false
					end
				end
				if v1066 and v1064 ~= nil then
					if v1064 ~= nil then
						local _ = v1064 * (v1061 - v1065) - v1065 * (v1060 - v1064) < 0 == (p1007.localReferenceAngleSide < 0)
					end
					v1015, v1016, v1017 = localDirectionToWorld(p1007.node, 0, v1064, v1065)
					v1018 = true
				end
			end
		end
		if p1007.doInversedLineAlignment then
			if p1007.doInversedLineAlignmentRoot == nil then
				p1007.doInversedLineAlignmentRoot = createTransformGroup("inversedLineAlignmentRoot")
				link(getParent(p1007.node), p1007.doInversedLineAlignmentRoot, getChildIndex(p1007.node))
				setTranslation(p1007.doInversedLineAlignmentRoot, getTranslation(p1007.node))
				setRotation(p1007.doInversedLineAlignmentRoot, getRotation(p1007.node))
				link(p1007.doInversedLineAlignmentRoot, p1007.node)
				setTranslation(p1007.node, 0, 0, 0)
				setRotation(p1007.node, 0, 0, 0)
			end
			for v1071 = 1, #p1007.orientationLineNodes - 1 do
				local v1072 = p1007.orientationLineNodes[v1071]
				local v1073 = p1007.orientationLineNodes[v1071 + 1]
				local _, v1074, v1075 = localToLocal(v1072, p1007.node, 0, 0, 0)
				local _, v1076, v1077 = localToLocal(v1073, p1007.node, 0, 0, 0)
				local v1078 = MathUtil.vector2Length(v1074, v1075)
				local v1079 = MathUtil.vector2Length(v1076, v1077)
				local v1080, v1081, v1082 = getWorldTranslation(p1007.doInversedLineAlignmentRoot)
				local v1083 = MathUtil.vector3Length(v1012 - v1080, v1013 - v1081, v1014 - v1082)
				if not MathUtil.getIsOutOfBounds(v1083, v1078, v1079) then
					local v1084 = (v1083 - v1078) / (v1079 - v1078)
					local v1085 = MathUtil.lerp(v1074, v1076, v1084)
					local v1086 = MathUtil.lerp(v1075, v1077, v1084)
					local v1087, v1088, v1089 = localDirectionToWorld(p1007.referenceFrame, 0, 1, 0)
					local v1090, v1091, v1092 = localDirectionToWorld(p1007.doInversedLineAlignmentRoot, 0, -v1085, v1086)
					I3DUtil.setWorldDirection(p1007.node, v1090, v1091, v1092, v1087, v1088, v1089, p1007.limitedAxis, p1007.minRot, p1007.maxRot)
					local v1093, v1094, v1095 = getWorldTranslation(p1007.doInversedLineAlignmentRoot)
					v1015 = v1012 - v1093
					v1016 = v1013 - v1094
					v1017 = v1014 - v1095
					I3DUtil.setWorldDirection(p1007.doInversedLineAlignmentRoot, v1015, v1016, v1017, v1087, v1088, v1089, p1007.limitedAxis, p1007.minRot, p1007.maxRot)
					v1018 = true
					break
				end
			end
		end
	else
		if p1007.alignToWorldY then
			local v1096, v1097, v1098 = localDirectionToWorld(getRootNode(), 0, 1, 0)
			local v1099, v1100, v1101 = worldDirectionToLocal(p1007.referenceFrame, v1096, v1097, v1098)
			if v1101 < 0 then
				v1101 = -v1101
			end
			v1015, v1016, v1017 = localDirectionToWorld(p1007.referenceFrame, v1099, v1100, v1101)
			v1018 = true
		elseif p1007.doDirectionAlignment then
			v1015, v1016, v1017 = localDirectionToWorld(p1007.referenceFrame, 0, 0, 1)
			v1018 = true
		end
		if p1007.moveToReferenceFrame then
			local v1102, v1103, v1104 = localToLocal(p1007.referenceFrame, getParent(p1007.node), p1007.referenceFrameOffset[1], p1007.referenceFrameOffset[2], p1007.referenceFrameOffset[3])
			setTranslation(p1007.node, v1102, v1103, v1104)
			v1018 = true
		end
		if p1007.doLineAlignment then
			local v1105 = false
			for v1106 = 1, #p1007.orientationLineNodes - 1 do
				local v1107 = p1007.orientationLineNodes[v1106]
				local v1108 = p1007.orientationLineNodes[v1106 + 1]
				local _, v1109, v1110 = localToLocal(v1107, p1007.referenceFrame, 0, 0, 0)
				local _, v1111, v1112 = localToLocal(v1108, p1007.referenceFrame, 0, 0, 0)
				local _, v1113, v1114 = localToLocal(p1007.node, p1007.referenceFrame, 0, 0, 0)
				local v1115 = p1007.partLength
				if p1007.partLengthNode ~= nil then
					v1115 = calcDistanceFrom(p1007.node, p1007.partLengthNode)
				end
				local v1116, v1119, v1120, v1119, v1120 = MathUtil.getCircleLineIntersection(v1113, v1114, v1115, v1109, v1110, v1111, v1112)
				if v1116 then
					local v1121 = nil
					local v1122 = nil
					if v1119 == nil or v1120 == nil then
						if v1119 == nil or v1120 == nil then
							v1120 = v1122
							v1119 = v1121
						else
							v1105 = true
						end
					else
						v1105 = true
					end
					if v1105 and not (MathUtil.isNan(v1119) or MathUtil.isNan(v1120)) then
						v1015, v1016, v1017 = localDirectionToWorld(p1007.referenceFrame, 0, v1119, v1120)
						v1018 = true
						v1019 = true
						break
					end
				end
			end
		end
		if p1007.do3DLineAlignment then
			local v1123 = p1007.partLength
			if p1007.partLengthNode ~= nil then
				v1123 = calcDistanceFrom(p1007.node, p1007.partLengthNode)
			end
			local v1124 = p1007.orientationLineNodes[1]
			local v1125 = p1007.orientationLineNodes[2]
			local v1126, v1127, v1128 = getWorldTranslation(p1007.node)
			local v1129, v1130, v1131 = getWorldTranslation(v1124)
			local v1132, v1133, v1134 = getWorldTranslation(v1125)
			local v1135 = MathUtil.vector3Length(v1129 - v1126, v1130 - v1127, v1131 - v1128)
			local v1136 = MathUtil.vector3Length(v1132 - v1126, v1133 - v1127, v1134 - v1128)
			local v1137 = MathUtil.inverseLerp(v1135, v1136, v1123)
			local v1138 = math.clamp(v1137, 0, 1)
			local v1139, v1140, v1141 = MathUtil.vector3Lerp(v1129, v1130, v1131, v1132, v1133, v1134, v1138)
			v1015, v1016, v1017 = MathUtil.vector3Normalize(v1139 - v1126, v1140 - v1127, v1141 - v1128)
			setWorldTranslation(p1007.orientationLineTransNode, v1139, v1140, v1141)
			v1019 = true
		end
	end
	if p1007.smoothedDirectionScale then
		if p1007.smoothedDirectionScaleAlpha == nil then
			p1007.smoothedDirectionScaleAlpha = p1010 and 1 or 0
		end
		local v1142 = g_currentDt or 9999
		if p1010 then
			local v1143 = p1007.smoothedDirectionScaleAlpha + v1142 * p1007.smoothedDirectionTime
			p1007.smoothedDirectionScaleAlpha = math.min(v1143, 1)
		else
			local v1144 = p1007.smoothedDirectionScaleAlpha - v1142 * p1007.smoothedDirectionTime
			p1007.smoothedDirectionScaleAlpha = math.max(v1144, 0)
		end
		local v1145 = localDirectionToWorld
		local v1146 = getParent(p1007.node)
		local v1147 = p1007.initialDirection
		local v1148, v1149, v1150 = v1145(v1146, unpack(v1147))
		v1015, v1016, v1017 = MathUtil.vector3Lerp(v1148, v1149, v1150, v1015, v1016, v1017, p1007.smoothedDirectionScaleAlpha)
	end
	if (p1007.doDirectionAlignment or v1019) and (v1015 ~= 0 or (v1016 ~= 0 or v1017 ~= 0)) then
		local v1151, v1152, v1153 = localDirectionToWorld(p1007.referenceFrame, 0, 1, 0)
		if p1007.invertZ then
			v1015 = -v1015
			v1016 = -v1016
			v1017 = -v1017
		end
		local v1154 = p1007.directionThresholdActive
		if not p1006.isActive and (p1007.directionThreshold ~= nil and p1007.directionThreshold > 0) then
			v1154 = p1007.directionThreshold
		end
		local v1155, v1156, v1157 = worldDirectionToLocal(p1007.parent, v1015, v1016, v1017)
		local v1158 = p1007.lastDirection
		local v1159 = p1007.lastUpVector
		local v1160 = v1158[1] - v1155
		if v1154 >= math.abs(v1160) then
			local v1161 = v1158[2] - v1156
			if v1154 >= math.abs(v1161) then
				local v1162 = v1158[3] - v1157
				if v1154 >= math.abs(v1162) then
					local v1163 = v1159[1] - v1151
					if v1154 >= math.abs(v1163) then
						local v1164 = v1159[2] - v1152
						if v1154 < math.abs(v1164) then
							goto l99
						end
						local v1165 = v1159[3] - v1153
						if v1154 < math.abs(v1165) then
							goto l99
						end
						v1018 = false
						::l110::
						if p1007.scaleZ and p1007.localReferenceDistance ~= nil then
							local v1166 = MathUtil.vector3Length(v1015, v1016, v1017)
							setScale(p1007.node, 1, 1, v1166 / p1007.localReferenceDistance)
							if p1007.debug then
								DebugGizmo.renderAtNode(p1007.node, string.format("scale:%.2f", v1166 / p1007.localReferenceDistance))
							end
						end
						goto l88
					end
				end
			end
		end
		::l99::
		I3DUtil.setWorldDirection(p1007.node, v1015, v1016, v1017, v1151, v1152, v1153, p1007.limitedAxis, p1007.minRot, p1007.maxRot)
		if p1007.debug then
			local v1167, v1168, v1169 = getWorldTranslation(p1007.node)
			drawDebugPoint(v1167, v1168, v1169, 1, 0, 0, 1, false)
			local v1170
			if p1007.hasReferencePoints then
				local v1171, v1172
				v1171, v1172, v1170 = worldToLocal(p1007.node, v1012, v1013, v1014)
			else
				v1170 = 1
			end
			local v1173, v1174, v1175 = MathUtil.vector3Normalize(v1015, v1016, v1017)
			drawDebugLine(v1167, v1168, v1169, 1, 0, 0, v1167 + v1173 * v1170, v1168 + v1174 * v1170, v1169 + v1175 * v1170, 0, 1, 0, true)
			if p1007.referencePoint ~= nil then
				local v1176, v1177, v1178 = getWorldTranslation(p1007.referencePoint)
				drawDebugPoint(v1176, v1177, v1178, 0, 1, 0, 1, false)
				drawDebugPoint(v1012, v1013, v1014, 0, 0, 1, 1, false)
			end
		end
		v1158[1] = v1155
		v1158[2] = v1156
		v1158[3] = v1157
		v1159[1] = v1151
		v1159[2] = v1152
		v1159[3] = v1153
		v1018 = true
		goto l110
	else
		::l88::
		if p1007.doRotationAlignment then
			local v1179, v1180, v1181 = getRotation(p1007.referenceFrame)
			local v1182 = v1179 * p1007.rotMultiplier
			local v1183 = v1180 * p1007.rotMultiplier
			local v1184 = v1181 * p1007.rotMultiplier
			local v1185, v1186, v1187 = getRotation(p1007.node)
			local v1188 = v1182 - v1185
			if math.abs(v1188) > 0.0001 then
				::l117::
				setRotation(p1007.node, v1182, v1183, v1184)
				v1018 = true
				goto l115
			end
			local v1189 = v1183 - v1186
			if math.abs(v1189) > 0.0001 then
				goto l117
			end
			local v1190 = v1184 - v1187
			if math.abs(v1190) > 0.0001 then
				goto l117
			end
		end
		::l115::
		if p1007.hasReferencePoints and p1007.numTranslatingParts > 0 then
			local _, _, v1191 = worldToLocal(p1007.node, v1012, v1013, v1014)
			for v1192 = 1, p1007.numTranslatingParts do
				local v1193 = p1007.translatingParts[v1192]
				local v1194 = v1191 - v1193.referenceDistance
				if p1007.translatingPartsDivider ~= 1 and v1193.divideTranslatingDistance then
					v1194 = v1194 / p1007.translatingPartsDivider
				end
				if v1193.minZTrans ~= nil then
					local v1195 = v1193.minZTrans
					v1194 = math.max(v1195, v1194)
				end
				if v1193.maxZTrans ~= nil then
					local v1196 = v1193.maxZTrans
					v1194 = math.min(v1196, v1194)
				end
				if not v1193.divideTranslatingDistance then
					v1191 = v1191 - (v1194 - v1193.startPos[3])
				end
				if p1007.referenceDistanceThreshold == 0 then
					::l133::
					if p1011 ~= false and (p1007.samplesByAction ~= nil or v1193.samplesByAction ~= nil) and v1194 ~= v1193.lastZ then
						local v1197 = v1193.lastZ - v1194
						if math.abs(v1197) > 0.0001 then
							p1006:onMovingPartSoundEvent(p1007, Cylindered.SOUND_ACTION_TRANSLATING_END, Cylindered.SOUND_TYPE_ENDING)
							p1006:onMovingPartSoundEvent(v1193, Cylindered.SOUND_ACTION_TRANSLATING_END, Cylindered.SOUND_TYPE_ENDING)
							p1006:onMovingPartSoundEvent(p1007, Cylindered.SOUND_ACTION_TRANSLATING_START, Cylindered.SOUND_TYPE_STARTING)
							p1006:onMovingPartSoundEvent(v1193, Cylindered.SOUND_ACTION_TRANSLATING_START, Cylindered.SOUND_TYPE_STARTING)
							if v1193.lastZ + 0.0001 < v1194 then
								p1006:onMovingPartSoundEvent(p1007, Cylindered.SOUND_ACTION_TRANSLATING_POS, Cylindered.SOUND_TYPE_CONTINUES)
								p1006:onMovingPartSoundEvent(v1193, Cylindered.SOUND_ACTION_TRANSLATING_POS, Cylindered.SOUND_TYPE_CONTINUES)
								p1006:onMovingPartSoundEvent(p1007, Cylindered.SOUND_ACTION_TRANSLATING_END_POS, Cylindered.SOUND_TYPE_ENDING)
								p1006:onMovingPartSoundEvent(v1193, Cylindered.SOUND_ACTION_TRANSLATING_END_POS, Cylindered.SOUND_TYPE_ENDING)
								p1006:onMovingPartSoundEvent(p1007, Cylindered.SOUND_ACTION_TRANSLATING_START_POS, Cylindered.SOUND_TYPE_STARTING)
								p1006:onMovingPartSoundEvent(v1193, Cylindered.SOUND_ACTION_TRANSLATING_START_POS, Cylindered.SOUND_TYPE_STARTING)
							elseif v1194 < v1193.lastZ - 0.0001 then
								p1006:onMovingPartSoundEvent(p1007, Cylindered.SOUND_ACTION_TRANSLATING_NEG, Cylindered.SOUND_TYPE_CONTINUES)
								p1006:onMovingPartSoundEvent(v1193, Cylindered.SOUND_ACTION_TRANSLATING_NEG, Cylindered.SOUND_TYPE_CONTINUES)
								p1006:onMovingPartSoundEvent(p1007, Cylindered.SOUND_ACTION_TRANSLATING_END_NEG, Cylindered.SOUND_TYPE_ENDING)
								p1006:onMovingPartSoundEvent(v1193, Cylindered.SOUND_ACTION_TRANSLATING_END_NEG, Cylindered.SOUND_TYPE_ENDING)
								p1006:onMovingPartSoundEvent(p1007, Cylindered.SOUND_ACTION_TRANSLATING_START_NEG, Cylindered.SOUND_TYPE_STARTING)
								p1006:onMovingPartSoundEvent(v1193, Cylindered.SOUND_ACTION_TRANSLATING_START_NEG, Cylindered.SOUND_TYPE_STARTING)
							end
						end
					end
					v1193.lastZ = v1194
					setTranslation(v1193.node, v1193.startPos[1], v1193.startPos[2], v1194)
					v1018 = true
				else
					local v1198 = v1193.lastZ - v1194
					if math.abs(v1198) > p1007.referenceDistanceThreshold then
						goto l133
					end
				end
			end
		end
		if v1018 then
			if p1007.copyLocalDirectionParts ~= nil then
				for _, v1199 in pairs(p1007.copyLocalDirectionParts) do
					local v1200, v1201, v1202 = localDirectionToWorld(p1007.node, 0, 0, 1)
					local v1203, v1204, v1205 = worldDirectionToLocal(getParent(p1007.node), v1200, v1201, v1202)
					local v1206 = v1203 * v1199.dirScale[1]
					local v1207 = v1204 * v1199.dirScale[2]
					local v1208 = v1205 * v1199.dirScale[3]
					local v1209, v1210, v1211 = localDirectionToWorld(p1007.node, 0, 1, 0)
					local v1212, v1213, v1214 = worldDirectionToLocal(getParent(p1007.node), v1209, v1210, v1211)
					local v1215 = v1212 * v1199.upScale[1]
					local v1216 = v1213 * v1199.upScale[2]
					local v1217 = v1214 * v1199.upScale[3]
					setDirection(v1199.node, v1206, v1207, v1208, v1215, v1216, v1217)
					if p1006.isServer then
						Cylindered.updateComponentJoints(p1006, v1199, p1008)
					end
				end
			end
			if p1006.isServer then
				Cylindered.updateComponentJoints(p1006, p1007, p1008)
				Cylindered.updateAttacherJoints(p1006, p1007)
				Cylindered.updateWheels(p1006, p1007)
			end
			Cylindered.updateWheels(p1006, p1007)
			for _, v1218 in pairs(p1007.dependentMovingTools) do
				Cylindered.updateRotationBasedLimits(p1006, p1007, v1218)
			end
		end
		if p1009 then
			for _, v1219 in pairs(p1007.dependentPartData) do
				if p1006.currentUpdateDistance < v1219.maxUpdateDistance then
					local v1220 = v1219.part
					local v1221 = p1006:getIsMovingPartActive(v1220)
					if v1221 or v1220.smoothedDirectionScale and v1220.smoothedDirectionScaleAlpha ~= 0 then
						Cylindered.updateMovingPart(p1006, v1220, p1008, p1009, v1221)
					end
				end
			end
		end
		p1007.isDirty = false
		return
	end
end
function Cylindered.updateComponentJoints(p1222, p1223, p1224)
	if p1222.isServer and p1223.componentJoints ~= nil then
		for _, v1225 in ipairs(p1223.componentJoints) do
			local v1226 = v1225.componentJoint
			local v1227 = v1226.jointNode
			if v1225.anchorActor == 1 then
				v1227 = v1226.jointNodeActor1
			end
			if p1224 then
				local v1228 = p1222.components[v1226.componentIndices[2]].node
				local v1229, v1230, v1231 = localToWorld(v1227, v1225.x, v1225.y, v1225.z)
				local v1232, v1233, v1234 = localDirectionToWorld(v1227, v1225.upX, v1225.upY, v1225.upZ)
				local v1235, v1236, v1237 = localDirectionToWorld(v1227, v1225.dirX, v1225.dirY, v1225.dirZ)
				setWorldTranslation(v1228, v1229, v1230, v1231)
				I3DUtil.setWorldDirection(v1228, v1235, v1236, v1237, v1232, v1233, v1234)
			end
			p1222:setComponentJointFrame(v1226, v1225.anchorActor)
		end
	end
end
function Cylindered.updateAttacherJoints(p1238, p1239)
	if p1238.isServer then
		if p1239.attacherJoints ~= nil then
			for _, v1240 in ipairs(p1239.attacherJoints) do
				if v1240.jointIndex ~= 0 then
					setJointFrame(v1240.jointIndex, 0, v1240.jointTransform)
				end
			end
		end
		if p1239.inputAttacherJoint and p1238.getAttacherVehicle ~= nil then
			local v1241 = p1238:getAttacherVehicle()
			if v1241 ~= nil then
				local v1242 = v1241:getAttacherJoints()
				if v1242 ~= nil then
					local v1243 = v1241:getAttacherJointIndexFromObject(p1238)
					if v1243 ~= nil then
						local v1244 = v1242[v1243]
						local v1245 = p1238:getActiveInputAttacherJoint()
						if v1245 ~= nil then
							local v1246 = v1244.jointOrigTrans[1] + v1244.jointPositionOffset[1]
							local v1247 = v1244.jointOrigTrans[2] + v1244.jointPositionOffset[2]
							local v1248 = v1244.jointOrigTrans[3] + v1244.jointPositionOffset[3]
							local v1249, v1250, v1251 = getTranslation(v1244.jointTransform)
							local v1252 = setTranslation
							local v1253 = v1244.jointTransform
							local v1254 = v1244.jointOrigTrans
							v1252(v1253, unpack(v1254))
							local v1255, v1256, v1257 = localToWorld(getParent(v1244.jointTransform), v1246, v1247, v1248)
							local v1258, v1259, v1260 = worldToLocal(v1244.jointTransform, v1255, v1256, v1257)
							setTranslation(v1244.jointTransform, v1249, v1250, v1251)
							local v1261, v1262, v1263 = localToWorld(v1245.node, v1258, v1259, v1260)
							local v1264, v1265, v1266 = worldToLocal(getParent(v1245.node), v1261, v1262, v1263)
							setTranslation(v1245.node, v1264, v1265, v1266)
							setJointFrame(v1244.jointIndex, 1, v1245.node)
							local v1267 = setTranslation
							local v1268 = v1245.node
							local v1269 = v1245.jointOrigTrans
							v1267(v1268, unpack(v1269))
						end
					end
				end
			end
		end
	end
end
function Cylindered.limitInterpolator(p1270, p1271, p1272)
	local v1273 = 1 - p1272
	local v1274 = nil
	local v1275 = nil
	local v1276 = nil
	local v1277
	if p1270.rotMin == nil or p1271.rotMin == nil then
		v1277 = nil
	else
		v1277 = p1270.rotMin * p1272 + p1271.rotMin * v1273
	end
	if p1270.rotMax ~= nil and p1271.rotMax ~= nil then
		v1274 = p1270.rotMax * p1272 + p1271.rotMax * v1273
	end
	if p1270.transMin ~= nil and p1271.transMin ~= nil then
		v1275 = p1270.minTrans * p1272 + p1271.transMin * v1273
	end
	if p1270.transMax ~= nil and p1271.transMax ~= nil then
		v1276 = p1270.transMax * p1272 + p1271.transMax * v1273
	end
	return v1277, v1274, v1275, v1276
end
function Cylindered.updateRotationBasedLimits(p1278, p1279, p1280)
	if p1280.rotationBasedLimits ~= nil then
		local v1281
		if p1279.isTool then
			v1281 = Cylindered.getMovingToolState(p1278, p1279)
		else
			local v1282 = p1280.rotation
			local v1283 = p1280.rotation
			local v1284 = p1280.rotation
			local v1285, v1286, v1287 = getRotation(p1279.node)
			v1282[1] = v1285
			v1283[2] = v1286
			v1284[3] = v1287
			v1281 = p1280.rotation[p1280.axis]
		end
		local v1288, v1289, v1290, v1291 = p1280.rotationBasedLimits:get(v1281)
		if v1288 ~= nil then
			p1280.movingTool.rotMin = v1288
		end
		if v1289 ~= nil then
			p1280.movingTool.rotMax = v1289
		end
		if v1290 ~= nil then
			p1280.movingTool.transMin = v1290
		end
		if v1291 ~= nil then
			p1280.movingTool.transMax = v1291
		end
		if p1278.isServer then
			local v1292 = false
			if v1288 ~= nil or v1289 ~= nil then
				v1292 = v1292 or Cylindered.setToolRotation(p1278, p1280.movingTool, 0, 0)
			end
			if v1290 ~= nil or v1291 ~= nil then
				v1292 = v1292 or Cylindered.setToolTranslation(p1278, p1280.movingTool, 0, 0)
			end
			if v1292 then
				Cylindered.setDirty(p1278, p1280.movingTool)
				p1278:raiseDirtyFlags(p1280.movingTool.dirtyFlag)
				p1278:raiseDirtyFlags(p1278.spec_cylindered.cylinderedDirtyFlag)
				return
			end
		elseif v1288 ~= nil or v1289 ~= nil then
			p1280.movingTool.networkInterpolators.rotation:setMinMax(p1280.movingTool.rotMin, p1280.movingTool.rotMax)
		end
	end
end
function Cylindered.actionEventInput(p1293, _, p1294, p_u_1295, _, p1296)
	local v1297 = p1293.spec_cylindered
	local v_u_1298 = v1297.movingTools[p_u_1295]
	if v_u_1298 ~= nil then
		v_u_1298.lastInputTime = g_time
		local v1299
		if v_u_1298.invertAxis then
			v1299 = -p1294
		else
			v1299 = p1294
		end
		local v_u_1300 = v1299 * g_gameSettings:getValue(GameSettings.SETTING.VEHICLE_ARM_SENSITIVITY)
		if p1296 then
			v_u_1300 = v_u_1300 * 16.666 / g_currentDt * v_u_1298.mouseSpeedFactor
			if v_u_1298.moveLocked then
				if math.abs(p1294) < 0.75 then
					local v1301 = math.abs(v_u_1300)
					local v1302 = v_u_1298.lockTool.move
					if math.abs(v1302) * 2 < v1301 then
						v_u_1298.moveLocked = false
					else
						v_u_1300 = 0
					end
				else
					v_u_1298.moveLocked = false
				end
			else
				local function v1309(p1303)
					-- upvalues: (copy) p_u_1295, (ref) v_u_1300, (copy) v_u_1298
					for v1304, v1305 in ipairs(p1303) do
						if v1304 ~= p_u_1295 and (v1305.move ~= nil and v1305.move ~= 0) then
							local v1306 = v_u_1300
							local v1307 = math.abs(v1306)
							local v1308 = v1305.move
							if math.abs(v1308) < v1307 then
								v1305.move = 0
								v1305.moveToSend = 0
								v1305.moveLocked = true
								v1305.lockTool = v_u_1298
							else
								v_u_1300 = 0
								v_u_1298.moveLocked = true
								v_u_1298.lockTool = v1305
							end
						end
					end
				end
				v1309(v1297.movingTools)
				if p1293.getAttachedImplements ~= nil then
					for _, v1310 in pairs(p1293:getAttachedImplements()) do
						local v1311 = v1310.object
						if v1311.spec_cylindered ~= nil then
							v1309(v1311.spec_cylindered.movingTools)
						end
					end
				end
			end
		end
		if v_u_1300 ~= v_u_1298.move then
			v_u_1298.move = v_u_1300
		end
		if v_u_1298.move ~= v_u_1298.moveToSend then
			v_u_1298.moveToSend = v_u_1298.move
			p1293:raiseDirtyFlags(v1297.cylinderedInputDirtyFlag)
		end
		v_u_1298.smoothedMove = v_u_1298.smoothedMove * 0.9 + v_u_1300 * 0.1
	end
end
function Cylindered.getMovingToolDashboardState(p1312, p1313)
	local v1314
	if p1313.attacherJointNodes == nil then
		v1314 = p1312
	else
		if p1313.attacherJointIndices == nil then
			p1313.attacherJointIndices = {}
		end
		v1314 = p1312
		for _, v1315 in ipairs(p1313.attacherJointNodes) do
			local v1316 = p1312:getAttacherJointIndexByNode(v1315)
			if v1316 ~= nil then
				local v1317 = p1313.attacherJointIndices
				table.insert(v1317, v1316)
			end
		end
		p1313.attacherJointNodes = nil
		if #p1313.attacherJointIndices == 0 then
			p1313.attacherJointIndices = nil
		end
	end
	if p1313.attacherJointIndices ~= nil then
		v1314 = nil
		for _, v1318 in ipairs(p1313.attacherJointIndices) do
			local v1319 = p1312:getImplementFromAttacherJointIndex(v1318)
			if v1319 ~= nil then
				v1314 = v1319.object
				break
			end
		end
	end
	if v1314 ~= nil then
		local v1320 = v1314.spec_cylindered
		if v1320 ~= nil then
			for _, v1321 in ipairs(v1320.movingTools) do
				if v1321.axis == p1313.axis then
					local v1322 = v1321.controlGroupIndex == 0 and true or v1321.controlGroupIndex == v1320.currentControlGroupIndex
					local v1323
					if v1320.easyArmControl == nil then
						v1323 = false
					else
						v1323 = v1320.easyArmControl.state
					end
					local v1324 = not (v1323 and v1321.easyArmControlActive or v1323)
					if v1324 then
						v1324 = not v1321.isEasyControlTarget
					end
					if v1322 and v1324 then
						return (v1321.smoothedMove + 1) / 2
					end
				end
			end
		end
	end
	return 0.5
end
function Cylindered.movingToolDashboardAttributes(p1325, p1326, p1327, p1328, _, _)
	p1328.axis = p1326:getValue(p1327 .. "#axis")
	if p1328.axis == nil then
		Logging.xmlWarning(p1326, "Misssing axis attribute for dashboard \'%s\'", p1327)
		return false
	end
	local v1329 = p1326:getValue(p1327 .. "#attacherJointIndex")
	if v1329 ~= nil then
		p1328.attacherJointIndices = {}
		local v1330 = p1328.attacherJointIndices
		table.insert(v1330, v1329)
	end
	p1328.attacherJointNode = p1326:getValue(p1327 .. "#attacherJointNode", nil, p1325.components, p1325.i3dMappings)
	p1328.attacherJointNodes = p1326:getValue(p1327 .. "#attacherJointNodes", nil, p1325.components, p1325.i3dMappings, true)
	local v1331 = p1328.attacherJointNodes
	local v1332 = p1328.attacherJointNode
	table.insert(v1331, v1332)
	if #p1328.attacherJointNodes == 0 then
		p1328.attacherJointNodes = nil
	end
	return true
end

Wheels = {}
Wheels.VRAM_PER_WHEEL = 524288
Wheels.CONFIG_XML_PATH = "vehicle.wheels.wheelConfigurations.wheelConfiguration"
Wheels.WHEELS_XML_PATH = "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).wheels"
Wheels.WHEEL_XML_PATH = "vehicle.wheels.wheelConfigurations.wheelConfiguration(?).wheels.wheel(?)"
Wheels.xmlSchema = nil
Wheels.xmlSchemaHub = nil
Wheels.xmlSchemaConnector = nil
source("dataS/scripts/vehicles/wheels/WheelContactType.lua")
source("dataS/scripts/vehicles/wheels/Wheel.lua")
function Wheels.prerequisitesPresent(_)
	return true
end
function Wheels.registerEvents(p1)
	SpecializationUtil.registerEvent(p1, "onBrake")
	SpecializationUtil.registerEvent(p1, "onFinishedWheelLoading")
	SpecializationUtil.registerEvent(p1, "onWheelConfigurationChanged")
end
function Wheels.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "getSteeringRotTimeByCurvature", Wheels.getSteeringRotTimeByCurvature)
	SpecializationUtil.registerFunction(p2, "getTurningRadiusByRotTime", Wheels.getTurningRadiusByRotTime)
	SpecializationUtil.registerFunction(p2, "loadHubsFromXML", Wheels.loadHubsFromXML)
	SpecializationUtil.registerFunction(p2, "loadHubFromXML", Wheels.loadHubFromXML)
	SpecializationUtil.registerFunction(p2, "onWheelHubI3DLoaded", Wheels.onWheelHubI3DLoaded)
	SpecializationUtil.registerFunction(p2, "loadAckermannSteeringFromXML", Wheels.loadAckermannSteeringFromXML)
	SpecializationUtil.registerFunction(p2, "loadWheelsFromXML", Wheels.loadWheelsFromXML)
	SpecializationUtil.registerFunction(p2, "loadWheelFromXML", Wheels.loadWheelFromXML)
	SpecializationUtil.registerFunction(p2, "getIsVersatileYRotActive", Wheels.getIsVersatileYRotActive)
	SpecializationUtil.registerFunction(p2, "getWheelFromWheelIndex", Wheels.getWheelFromWheelIndex)
	SpecializationUtil.registerFunction(p2, "getWheelByWheelNode", Wheels.getWheelByWheelNode)
	SpecializationUtil.registerFunction(p2, "getWheels", Wheels.getWheels)
	SpecializationUtil.registerFunction(p2, "getCurrentSurfaceSound", Wheels.getCurrentSurfaceSound)
	SpecializationUtil.registerFunction(p2, "getAreSurfaceSoundsActive", Wheels.getAreSurfaceSoundsActive)
	SpecializationUtil.registerFunction(p2, "brake", Wheels.brake)
	SpecializationUtil.registerFunction(p2, "getBrakeForce", Wheels.getBrakeForce)
	SpecializationUtil.registerFunction(p2, "setCustomBrakeForce", Wheels.setCustomBrakeForce)
	SpecializationUtil.registerFunction(p2, "updateWheelDirtAmount", Wheels.updateWheelDirtAmount)
	SpecializationUtil.registerFunction(p2, "updateWheelMudAmount", Wheels.updateWheelMudAmount)
	SpecializationUtil.registerFunction(p2, "forceUpdateWheelPhysics", Wheels.forceUpdateWheelPhysics)
	SpecializationUtil.registerFunction(p2, "onWheelSnowHeightChanged", Wheels.onWheelSnowHeightChanged)
	SpecializationUtil.registerFunction(p2, "getSteeringNodeByNode", Wheels.getSteeringNodeByNode)
	SpecializationUtil.registerFunction(p2, "updateSteeringNodes", Wheels.updateSteeringNodes)
end
function Wheels.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "addToPhysics", Wheels.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p3, "removeFromPhysics", Wheels.removeFromPhysics)
	SpecializationUtil.registerOverwrittenFunction(p3, "getComponentMass", Wheels.getComponentMass)
	SpecializationUtil.registerOverwrittenFunction(p3, "getVehicleWorldXRot", Wheels.getVehicleWorldXRot)
	SpecializationUtil.registerOverwrittenFunction(p3, "getVehicleWorldDirection", Wheels.getVehicleWorldDirection)
	SpecializationUtil.registerOverwrittenFunction(p3, "validateWashableNode", Wheels.validateWashableNode)
	SpecializationUtil.registerOverwrittenFunction(p3, "getAIDirectionNode", Wheels.getAIDirectionNode)
	SpecializationUtil.registerOverwrittenFunction(p3, "getAIRootNode", Wheels.getAIRootNode)
	SpecializationUtil.registerOverwrittenFunction(p3, "getSupportsMountKinematic", Wheels.getSupportsMountKinematic)
	SpecializationUtil.registerOverwrittenFunction(p3, "loadBendingNodeFromXML", Wheels.loadBendingNodeFromXML)
end
function Wheels.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onPreLoad", Wheels)
	SpecializationUtil.registerEventListener(p4, "onLoad", Wheels)
	SpecializationUtil.registerEventListener(p4, "onLoadFinished", Wheels)
	SpecializationUtil.registerEventListener(p4, "onRegisterDashboardValueTypes", Wheels)
	SpecializationUtil.registerEventListener(p4, "onDelete", Wheels)
	SpecializationUtil.registerEventListener(p4, "onReadStream", Wheels)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", Wheels)
	SpecializationUtil.registerEventListener(p4, "onReadUpdateStream", Wheels)
	SpecializationUtil.registerEventListener(p4, "onWriteUpdateStream", Wheels)
	SpecializationUtil.registerEventListener(p4, "onUpdate", Wheels)
	SpecializationUtil.registerEventListener(p4, "onPostUpdate", Wheels)
	SpecializationUtil.registerEventListener(p4, "onUpdateTick", Wheels)
	SpecializationUtil.registerEventListener(p4, "onUpdateEnd", Wheels)
	SpecializationUtil.registerEventListener(p4, "onLeaveVehicle", Wheels)
	SpecializationUtil.registerEventListener(p4, "onPreAttach", Wheels)
	SpecializationUtil.registerEventListener(p4, "onPostDetach", Wheels)
	SpecializationUtil.registerEventListener(p4, "onRegisterAnimationValueTypes", Wheels)
	SpecializationUtil.registerEventListener(p4, "onPostAttachImplement", Wheels)
end
function Wheels.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("wheel", g_i18n:getText("configuration_wheelSetup"), "wheels", VehicleConfigurationItemWheel, g_i18n:getText("configuration_wheelBrand"), Wheels.getBrands, Wheels.getWheelsByBrand, 2)
	g_vehicleConfigurationManager:addConfigurationType("rimColor", g_i18n:getText("configuration_rimColor"), nil, VehicleConfigurationItemColor)
	g_storeManager:addSpecType("wheels", "shopListAttributeIconWheels", Wheels.loadSpecValueWheels, Wheels.getSpecValueWheels, StoreSpecies.VEHICLE)
	g_storeManager:addVRamUsageFunction(Wheels.getVRamUsageFromXML)
	local v5 = Vehicle.xmlSchema
	v5:setXMLSpecializationType("Wheels")
	v5:register(XMLValueType.STRING, "vehicle.wheels.wheelConfigurations#tireCategories", "List of tire categories to include in the automatic wheel config generation (separated by whitespace)")
	v5:register(XMLValueType.STRING_LIST, "vehicle.wheels.wheelConfigurations#customBrandOrder", "Custom brand order for dynamic configurations (names of the brands separated by whitespace)")
	v5:register(XMLValueType.STRING, "vehicle.wheels.wheelConfigurations.tireCombination(?)#brand", "Brand name of the combination")
	v5:register(XMLValueType.STRING, "vehicle.wheels.wheelConfigurations.tireCombination(?)#names", "List of tire names that are allowed to be mixed. Otherwise all mixes are allowed. Does not effect configuration with all tires from the same name. (separated by whitespace)")
	v5:register(XMLValueType.INT, Wheels.CONFIG_XML_PATH .. "(?)#numDynamicConfigurations", "Max. number of dynamic configurations per brand", "unlimited")
	v5:register(XMLValueType.STRING, Wheels.CONFIG_XML_PATH .. "(?)#tireCategories", "List of tire categories to include in the automatic wheel config generation (separated by whitespace)")
	v5:register(XMLValueType.STRING, Wheels.CONFIG_XML_PATH .. "(?).tireCombination(?)#brand", "Brand name of the combination")
	v5:register(XMLValueType.STRING, Wheels.CONFIG_XML_PATH .. "(?).tireCombination(?)#names", "List of tire names that are allowed to be mixed. Otherwise all mixes are allowed. Does not effect configuration with all tires from the same name. (separated by whitespace)")
	local v6 = Wheels.WHEELS_XML_PATH
	v5:register(XMLValueType.FLOAT, v6 .. "#autoRotateBackSpeed", "Auto rotate back speed", 1)
	v5:register(XMLValueType.BOOL, v6 .. "#speedDependentRotateBack", "Speed dependent auto rotate back speed", true)
	v5:register(XMLValueType.INT, v6 .. "#differentialIndex", "Differential index")
	v5:register(XMLValueType.INT, v6 .. "#ackermannSteeringIndex", "Ackermann steering index")
	v5:register(XMLValueType.FLOAT, v6 .. "#ackermannSteeringAngle", "Ackermann steering angle to set while this config is active")
	v5:register(XMLValueType.BOOL, v6 .. "#isCareWheelConfiguration", "All wheels will be care wheels")
	v5:register(XMLValueType.STRING, v6 .. "#baseConfig", "Base for this configuration")
	v5:register(XMLValueType.BOOL, v6 .. "#hasSurfaceSounds", "Has surface sounds", true)
	v5:register(XMLValueType.STRING, v6 .. "#surfaceSoundTireType", "Tire type that is used for surface sounds", "Tire type of first wheel")
	v5:register(XMLValueType.NODE_INDEX, v6 .. "#surfaceSoundLinkNode", "Surface sound link node", "Root component")
	Wheel.registerXMLPaths(v5, v6 .. ".wheel(?)")
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.rimMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.rimMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.rimMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.innerRimMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.innerRimMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.innerRimMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.outerRimMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.outerRimMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.outerRimMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.additionalMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.additionalMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.additionalMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.hubMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.hubMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubMaterial#useRimColor", "Use rim color", false)
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.hubBoltMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubBoltMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.hubBoltMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubBoltMaterial#useRimColor", "Use rim color", false)
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.hubs.material")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.material#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.hubs.material#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.material#useRimColor", "Use rim color", false)
	v5:register(XMLValueType.NODE_INDEX, "vehicle.wheels.hubs.hub(?)#linkNode", "Link node")
	v5:register(XMLValueType.STRING, "vehicle.wheels.hubs.hub(?)#filename", "Filename")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?)#isLeft", "Is left side", false)
	v5:register(XMLValueType.FLOAT, "vehicle.wheels.hubs.hub(?)#offset", "X axis offset")
	v5:register(XMLValueType.VECTOR_SCALE, "vehicle.wheels.hubs.hub(?)#scale", "Hub scale")
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.hubs.hub(?).material")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?).material#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.hubs.hub(?).material#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?).material#useRimColor", "Use rim color", false)
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.hubs.hub(?).boltMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?).boltMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.hubs.hub(?).boltMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?).boltMaterial#useRimColor", "Use rim color", false)
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.hubs.hub(?).additionalMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?).additionalMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.hubs.hub(?).additionalMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?).additionalMaterial#useRimColor", "Use rim color", false)
	VehicleMaterial.registerXMLPaths(v5, "vehicle.wheels.hubs.hub(?).boltAdditionalMaterial")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?).boltAdditionalMaterial#useBaseColor", "Use base vehicle color", false)
	v5:register(XMLValueType.INT, "vehicle.wheels.hubs.hub(?).boltAdditionalMaterial#useDesignColorIndex", "Use color of the design color with the defined index (1-16)")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.hubs.hub(?).boltAdditionalMaterial#useRimColor", "Use rim color", false)
	v5:addDelayedRegistrationFunc("AnimatedVehicle:part", function(p7, p8)
		p7:register(XMLValueType.INT, p8 .. "#wheelIndex", "Wheel index [1..n]")
		p7:register(XMLValueType.ANGLE, p8 .. "#startSteeringAngle", "Start steering angle")
		p7:register(XMLValueType.ANGLE, p8 .. "#endSteeringAngle", "End steering angle")
		p7:register(XMLValueType.FLOAT, p8 .. "#startBrakeFactor", "Start brake force factor")
		p7:register(XMLValueType.FLOAT, p8 .. "#endBrakeFactor", "End brake force factor")
	end)
	v5:register(XMLValueType.NODE_INDEX, "vehicle.wheels.dynamicallyLoadedWheels.dynamicallyLoadedWheel(?)#linkNode", "Link node")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.dynamicallyLoadedWheels.dynamicallyLoadedWheel(?)#isLeft", "Is Left", false)
	v5:register(XMLValueType.STRING, "vehicle.wheels.dynamicallyLoadedWheels.dynamicallyLoadedWheel(?)#filename", "Filename")
	v5:register(XMLValueType.STRING, "vehicle.wheels.dynamicallyLoadedWheels.dynamicallyLoadedWheel(?)#configId", "Wheel config id", "default")
	v5:register(XMLValueType.BOOL, "vehicle.wheels.dynamicallyLoadedWheels.dynamicallyLoadedWheel(?)#isShallowWaterObstacle", "The dynamically loaded wheel will interact with the shallow water simulation", false)
	WheelVisual.registerXMLPaths(v5, "vehicle.wheels.dynamicallyLoadedWheels.dynamicallyLoadedWheel(?)")
	Wheels.registerAckermannSteeringXMLPaths(v5, "vehicle.wheels.ackermannSteeringConfigurations.ackermannSteering(?)")
	v5:register(XMLValueType.NODE_INDEX, "vehicle.wheels.steeringNodes.steeringNode(?)#node", "Additional node that is used for steering (Same behaviour as wheels using the ackermann steering setting)")
	v5:register(XMLValueType.FLOAT, "vehicle.wheels.steeringNodes.steeringNode(?)#rotScale", "Scale factor for rotation", 1)
	v5:register(XMLValueType.VECTOR_N, FoliageBending.BENDING_NODE_XML_KEY .. "#wheelIndices", "Wheel Indices to calculate the bending node size automatically")
	Dashboard.registerDashboardXMLPaths(v5, "vehicle.wheels.dashboards", { "brake" })
	v5:setXMLSpecializationType()
	Wheels.xmlSchema = XMLSchema.new("wheel")
	Wheels.xmlSchema:register(XMLValueType.STRING, "wheel.metadata#brand", "Wheel tire brand", "LIZARD")
	Wheels.xmlSchema:registerAutoCompletionDataSource("wheel.metadata#brand", "$dataS/brands.xml", "brands.brand#name")
	Wheels.xmlSchema:register(XMLValueType.STRING, "wheel.metadata#name", "Wheel tire name", "Tire")
	Wheels.xmlSchema:register(XMLValueType.STRING, "wheel.metadata#category", "Wheel tire category for automatic wheel configurations")
	Wheels.xmlSchema:register(XMLValueType.BOOL, "wheel.metadata#allowMixture", "Allow mixing with other tires from the same brand", false)
	Wheels.xmlSchema:register(XMLValueType.INT, "wheel.metadata#priority", "Tire priority for selection in the shop (wheels with high prio will be shown first)", 1)
	Wheel.registerXMLPaths(Wheels.xmlSchema, "wheel.default")
	Wheel.registerXMLPaths(Wheels.xmlSchema, "wheel.configurations.configuration(?)")
	Wheels.xmlSchema:register(XMLValueType.STRING, "wheel.configurations.configuration(?)#id", "Configuration Id")
	Wheels.xmlSchemaHub = XMLSchema.new("wheelHub")
	local v9 = Wheels.xmlSchemaHub
	v9:register(XMLValueType.STRING, "hub.filename", "I3D filename")
	v9:register(XMLValueType.STRING, "hub.nodes#left", "Index of left node in hub i3d file")
	v9:register(XMLValueType.STRING, "hub.nodes#right", "Index of right node in hub i3d file")
	Wheels.xmlSchemaConnector = XMLSchema.new("wheelConnector")
	local v10 = Wheels.xmlSchemaConnector
	v10:register(XMLValueType.STRING, "connector.file#name", "I3D filename")
	v10:register(XMLValueType.STRING, "connector.file#leftNode", "Index of left node in connector i3d file")
	v10:register(XMLValueType.STRING, "connector.file#rightNode", "Index of right node in connector i3d file")
	Vehicle.xmlSchemaSavegame:register(XMLValueType.STRING, "vehicles.vehicle(?).wheels#lastConfigId", "Last selected wheel configuration id")
end
function Wheels.registerAckermannSteeringXMLPaths(p11, p12)
	p11:register(XMLValueType.FLOAT, p12 .. "#rotSpeed", "Rotation speed")
	p11:register(XMLValueType.FLOAT, p12 .. "#rotMax", "Max. rotation")
	p11:register(XMLValueType.INT, p12 .. "#rotCenterWheel1", "Rotation center wheel 1")
	p11:register(XMLValueType.INT, p12 .. "#rotCenterWheel2", "Rotation center wheel 2")
	p11:register(XMLValueType.VECTOR_N, p12 .. "#rotCenterWheels", "List of wheel indices which represent the steering center")
	p11:register(XMLValueType.NODE_INDEX, p12 .. "#rotCenterNode", "Rotation center node (Used if rotCenterWheelX not given)")
	p11:register(XMLValueType.VECTOR_2, p12 .. "#rotCenter", "Center position (from root component) (Used if rotCenterWheelX not given)")
	p11:register(XMLValueType.FLOAT, p12 .. "#minTurningRadius", "Overwrites the automatically calculated turning radius for this config")
end
function Wheels.onPreLoad(p13, _)
	local v14 = p13.spec_wheels
	v14.wheelConfigurationId = p13.configurations.wheel or 1
	v14.configKey = string.format("vehicle.wheels.wheelConfigurations.wheelConfiguration(%d)", v14.wheelConfigurationId - 1)
	v14.configItem = ConfigurationUtil.getConfigItemByConfigId(p13.configFileName, "wheel", v14.wheelConfigurationId)
	if v14.configItem ~= nil then
		v14.configItem:applyGeneratedConfiguration(p13.xmlFile)
		v14.configKey = v14.configItem.configKey
		v14.lastWheelConfigSaveId = v14.configItem.saveId
	end
end
function Wheels.onLoad(p_u_15, _)
	local v_u_16 = p_u_15.spec_wheels
	v_u_16.sharedLoadRequestIds = {}
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.driveGroundParticleSystems", "vehicle.wheels.wheelConfigurations.wheelConfiguration.wheels.wheel#hasParticles")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheelConfigurations.wheelConfiguration", "vehicle.wheels.wheelConfigurations.wheelConfiguration")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.rimColor", "vehicle.wheels.rimColor")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.hubColor", "vehicle.wheels.hubs.color0")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.dynamicallyLoadedWheels", "vehicle.wheels.dynamicallyLoadedWheels")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.ackermannSteeringConfigurations", "vehicle.wheels.ackermannSteeringConfigurations")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheels.wheel", "vehicle.wheels.wheelConfigurations.wheelConfiguration.wheels.wheel")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheels.wheel#repr", "vehicle.wheels.wheelConfigurations.wheelConfiguration.wheels.wheel.physics#repr")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheelConfigurations.wheelConfiguration.wheels.wheel#repr", "vehicle.wheels.wheelConfigurations.wheelConfiguration.wheels.wheel.physics#repr")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheels.wheelConfigurations.wheelConfiguration.wheels.wheel#repr", "vehicle.wheels.wheelConfigurations.wheelConfiguration.wheels.wheel.physics#repr")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheels.wheelConfigurations.wheelConfiguration.wheels.wheel#configIndex", "vehicle.wheels.wheelConfigurations.wheelConfiguration.wheels.wheel#configId")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.ackermannSteering", "vehicle.wheels.ackermannSteeringConfigurations.ackermannSteering")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheel.rimColor", "vehicle.wheels.rimMaterial")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheel.hubs.rimColor.color0", "vehicle.wheels.hubMaterial")
	XMLUtil.checkDeprecatedXMLElements(p_u_15.xmlFile, "vehicle.wheel.hubs.rimColor.color1", "vehicle.wheels.hubBoltMaterial")
	v_u_16.configurationIndexToParentConfigIndex = Wheels.createConfigToParentConfigMapping(p_u_15.xmlFile)
	if v_u_16.configItem ~= nil then
		v_u_16.configItem:applyObjectChanges(p_u_15, v_u_16.configurationIndexToParentConfigIndex)
	end
	local function v23(p17, p18, p19)
		-- upvalues: (copy) p_u_15, (copy) v_u_16
		local v20 = VehicleMaterial.new(p_u_15.baseDirectory)
		if v20:loadFromXML(p_u_15.xmlFile, p18, p_u_15.customEnvironment) then
			v_u_16[p17] = v20
		else
			v20 = nil
		end
		if p_u_15.xmlFile:getValue(p18 .. "#useBaseColor") then
			v_u_16[p17] = VehicleConfigurationItemColor.getMaterialByColorConfiguration(p_u_15, "baseColor") or v_u_16[p17]
			return
		else
			local v21 = p_u_15.xmlFile:getValue(p18 .. "#useDesignColorIndex")
			if v21 == nil then
				if v20 == nil and not p19 or p_u_15.xmlFile:getBool(p18 .. "#useRimColor", false) then
					v_u_16[p17] = VehicleConfigurationItemColor.getMaterialByColorConfiguration(p_u_15, "rimColor") or (v_u_16.rimMaterial or v_u_16[p17])
					if v_u_16[p17] == nil then
						v_u_16[p17] = VehicleMaterial.new(p_u_15.baseDirectory)
						v_u_16[p17]:setTemplateName("RIM_DEFAULT")
					end
				end
			else
				local v22 = v21 < 2 and "designColor" or string.format("designColor%d", v21)
				v_u_16[p17] = VehicleConfigurationItemColor.getMaterialByColorConfiguration(p_u_15, v22) or v_u_16[p17]
			end
		end
	end
	v23("rimMaterial", "vehicle.wheels.rimMaterial", false)
	v23("innerRimMaterial", "vehicle.wheels.innerRimMaterial", false)
	v23("outerRimMaterial", "vehicle.wheels.outerRimMaterial", false)
	v23("additionalMaterial", "vehicle.wheels.additionalMaterial", false)
	v23("hubMaterial", "vehicle.wheels.hubMaterial", true)
	v23("hubBoltMaterial", "vehicle.wheels.hubBoltMaterial", true)
	p_u_15:loadHubsFromXML()
	p_u_15.maxRotTime = 0
	p_u_15.minRotTime = 0
	p_u_15.rotatedTimeInterpolator = InterpolatorValue.new(0)
	p_u_15.autoRotateBackSpeed = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#autoRotateBackSpeed", 1)
	p_u_15.speedDependentRotateBack = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#speedDependentRotateBack", true)
	p_u_15.differentialIndex = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#differentialIndex")
	v_u_16.ackermannSteeringIndex = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#ackermannSteeringIndex")
	v_u_16.ackermannSteeringAngle = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#ackermannSteeringAngle")
	v_u_16.isCareWheelConfiguration = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#isCareWheelConfiguration")
	local v24 = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#hasSurfaceSounds", true)
	v_u_16.wheelSmoothAccumulation = 0
	v_u_16.currentUpdateIndex = 1
	v_u_16.wheels = {}
	v_u_16.wheelsByNode = {}
	p_u_15:loadWheelsFromXML(p_u_15.xmlFile, v_u_16.configKey, v_u_16.wheelConfigurationId)
	if v24 then
		local v25 = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#surfaceSoundLinkNode", p_u_15.components[1].node, p_u_15.components, p_u_15.i3dMappings)
		local v26 = (#v_u_16.wheels <= 0 or v_u_16.wheels[1].physics.tireType == nil) and "" or WheelsUtil.getTireTypeName(v_u_16.wheels[1].physics.tireType)
		local v27 = WheelXMLObject.getValueStatic(v_u_16.wheelConfigurationId, v_u_16.configurationIndexToParentConfigIndex, p_u_15.xmlFile, Wheels.CONFIG_XML_PATH, ".wheels", "#surfaceSoundTireType", v26)
		v_u_16.surfaceSounds = {}
		v_u_16.surfaceIdToSound = {}
		v_u_16.surfaceNameToSound = {}
		v_u_16.currentSurfaceSound = nil
		local v28 = g_currentMission.surfaceSounds
		for v29 = 1, #v28 do
			local v30 = v28[v29]
			if v30.type:lower() == ("wheel_" .. v27):lower() then
				local v31 = g_soundManager:cloneSample(v30.sample, v25, p_u_15)
				v31.sampleName = v30.name
				local v32 = v_u_16.surfaceSounds
				table.insert(v32, v31)
				v_u_16.surfaceIdToSound[v30.materialId] = v31
				v_u_16.surfaceNameToSound[v30.name] = v31
			end
		end
		for v33 = 1, #v28 do
			local v34 = v28[v33]
			if v_u_16.surfaceNameToSound[v34.name] == nil and v34.type == "wheel" then
				local v35 = g_soundManager:cloneSample(v34.sample, v25, p_u_15)
				v35.sampleName = v34.name
				local v36 = v_u_16.surfaceSounds
				table.insert(v36, v35)
				v_u_16.surfaceIdToSound[v34.materialId] = v35
				v_u_16.surfaceNameToSound[v34.name] = v35
			end
		end
	end
	v_u_16.dynamicallyLoadedWheels = {}
	p_u_15.xmlFile:iterate("vehicle.wheels.dynamicallyLoadedWheels.dynamicallyLoadedWheel", function(p37, p38)
		-- upvalues: (copy) p_u_15, (copy) v_u_16
		local v39 = p_u_15.xmlFile:getValue(p38 .. "#linkNode", p_u_15.components[1].node, p_u_15.components, p_u_15.i3dMappings)
		local v40 = p_u_15.xmlFile:getValue(p38 .. "#isLeft", false)
		local v41 = p_u_15.xmlFile:getValue(p38 .. "#isShallowWaterObstacle", false)
		local v42 = WheelXMLObject.new(p_u_15.xmlFile, "vehicle.wheels.dynamicallyLoadedWheels.dynamicallyLoadedWheel", p37, "", {})
		local v43 = WheelVisual.new(p_u_15, nil, v39, v40, 0, p_u_15.baseDirectory)
		if v43:loadFromXML(v42) then
			if v41 then
				v43:addShallowWaterObstacle()
			end
			v43.name = v42.externalWheelName
			local v44 = v_u_16.dynamicallyLoadedWheels
			table.insert(v44, v43)
		else
			v43:delete()
		end
		v42:delete()
	end)
	v_u_16.steeringNodes = {}
	p_u_15.xmlFile:iterate("vehicle.wheels.steeringNodes.steeringNode", function(_, p45)
		-- upvalues: (copy) p_u_15, (copy) v_u_16
		local v46 = p_u_15.xmlFile:getValue(p45 .. "#node", nil, p_u_15.components, p_u_15.i3dMappings)
		if v46 ~= nil then
			local v47 = {
				["node"] = v46,
				["rotScale"] = p_u_15.xmlFile:getValue(p45 .. "#rotScale", 1)
			}
			v47.rotScaleOrig = v47.rotScale
			v47.rotScaleTarget = v47.rotScale
			v47.rotScaleTargetSpeed = 1
			v47.offset = 0
			v47.offsetTarget = 0
			v47.offsetTargetSpeed = 1
			for _, v48 in pairs(p_u_15.componentJoints) do
				if v48.jointNode == v46 then
					v47.componentJoint = v48
					break
				end
			end
			local v49 = v_u_16.steeringNodes
			table.insert(v49, v47)
		end
	end)
	v_u_16.hasSteeringNodes = #v_u_16.steeringNodes > 0
	v_u_16.networkTimeInterpolator = InterpolationTime.new(1.2)
	p_u_15:loadAckermannSteeringFromXML(p_u_15.xmlFile, v_u_16.ackermannSteeringIndex, v_u_16.ackermannSteeringAngle)
	SpecializationUtil.raiseEvent(p_u_15, "onFinishedWheelLoading", p_u_15.xmlFile, v_u_16.configKey .. ".wheels")
	v_u_16.brakePedal = 0
	v_u_16.dirtyFlag = p_u_15:getNextDirtyFlag()
	g_messageCenter:subscribe(MessageType.SNOW_HEIGHT_CHANGED, p_u_15.onWheelSnowHeightChanged, p_u_15)
end
function Wheels.onLoadFinished(p50, p51)
	local v52 = p50.spec_wheels
	if p50.isServer then
		for _, v53 in pairs(v52.wheels) do
			p50.defaultMass = p50.defaultMass + v53:getMass()
		end
		if p51 ~= nil and not p51.resetVehicles then
			local v54 = p51.xmlFile:getValue(p51.key .. ".wheels#lastConfigId")
			if v54 ~= nil and (v52.configItem ~= nil and v52.configItem.saveId ~= v54) then
				for _, v55 in pairs(v52.wheels) do
					local v56 = p50:getWashableNodeByCustomIndex(v55)
					if v56 ~= nil then
						p50:setNodeDirtAmount(v56, 0, true)
					end
					if v55.wheelMudMeshes ~= nil then
						local v57 = p50:getWashableNodeByCustomIndex(v55.wheelMudMeshes)
						if v57 ~= nil then
							p50:setNodeDirtAmount(v57, 0, true)
						end
					end
				end
				SpecializationUtil.raiseEvent(p50, "onWheelConfigurationChanged")
			end
		end
	end
	if v52.rimMaterial ~= nil then
		v52.rimMaterial:applyToVehicle(p50, "rim_inner_mat")
		v52.rimMaterial:applyToVehicle(p50, "rim_outer_mat")
	end
	if v52.innerRimMaterial ~= nil then
		v52.innerRimMaterial:applyToVehicle(p50, "rim_inner_mat")
	end
	if v52.outerRimMaterial ~= nil then
		v52.outerRimMaterial:applyToVehicle(p50, "rim_outer_mat")
	end
	if v52.additionalMaterial ~= nil then
		v52.additionalMaterial:applyToVehicle(p50, "rim_additional_mat")
	end
	if v52.hubMaterial ~= nil then
		v52.hubMaterial:applyToVehicle(p50, "hub_main_mat")
	end
	if v52.hubBoltMaterial ~= nil then
		v52.hubBoltMaterial:applyToVehicle(p50, "hub_bolt_mat")
	end
	for _, v58 in ipairs(v52.hubs) do
		if v58.material ~= nil then
			v58.material:apply(v58.node, "hub_main_mat")
		end
		if v58.boltMaterial ~= nil then
			v58.boltMaterial:apply(v58.node, "hub_bolt_mat")
		end
		if v58.additionalMaterial ~= nil then
			v58.additionalMaterial:apply(v58.node, "hub_main_additional_mat")
		end
		if v58.boltAdditionalMaterial ~= nil then
			v58.boltAdditionalMaterial:apply(v58.node, "hub_bolt_additional_mat")
		end
	end
	for _, v59 in pairs(v52.wheels) do
		v59:postLoad()
	end
	for _, v60 in pairs(v52.dynamicallyLoadedWheels) do
		v60:postLoad()
	end
end
function Wheels.onRegisterDashboardValueTypes(p61)
	local v62 = p61.spec_wheels
	local v63 = DashboardValueType.new("wheels", "brake")
	v63:setValue(v62, "brakePedal")
	v63:setRange(0, 1)
	p61:registerDashboardValueType(v63)
end
function Wheels.saveToXMLFile(p64, p65, p66, _)
	local v67 = p64.spec_wheels
	if v67.lastWheelConfigSaveId ~= nil then
		p65:setValue(p66 .. "#lastConfigId", v67.lastWheelConfigSaveId)
	end
end
function Wheels.onDelete(p68)
	local v69 = p68.spec_wheels
	if v69.sharedLoadRequestIds ~= nil then
		for _, v70 in pairs(v69.sharedLoadRequestIds) do
			g_i3DManager:releaseSharedI3DFile(v70)
		end
	end
	if v69.hubs ~= nil then
		for _, v71 in pairs(v69.hubs) do
			delete(v71.node)
		end
	end
	if v69.wheels ~= nil then
		for _, v72 in pairs(v69.wheels) do
			v72:delete()
		end
	end
	if v69.dynamicallyLoadedWheels ~= nil then
		for _, v73 in ipairs(v69.dynamicallyLoadedWheels) do
			v73:delete()
		end
	end
	g_soundManager:deleteSamples(v69.surfaceSounds)
end
function Wheels.onReadStream(p74, p75, p76)
	if p76.isServer then
		local v77 = p74.spec_wheels
		v77.networkTimeInterpolator:reset()
		for v78 = 1, #v77.wheels do
			local v79 = v77.wheels[v78]
			if v79.physics.isSynchronized then
				v79:readStream(p75, true)
			end
		end
		p74.rotatedTimeInterpolator:setValue(0)
	end
end
function Wheels.onWriteStream(p80, p81, p82)
	if not p82.isServer then
		local v83 = p80.spec_wheels
		for v84 = 1, #v83.wheels do
			local v85 = v83.wheels[v84]
			if v85.physics.isSynchronized then
				v85:writeStream(p81)
			end
		end
	end
end
function Wheels.onReadUpdateStream(p86, p87, _, p88)
	if p88.isServer and streamReadBool(p87) then
		local v89 = p86.spec_wheels
		v89.networkTimeInterpolator:startNewPhaseNetwork()
		for v90 = 1, #v89.wheels do
			local v91 = v89.wheels[v90]
			if v91.physics.isSynchronized then
				v91:readStream(p87, false)
			end
		end
		if p86.maxRotTime ~= 0 and p86.minRotTime ~= 0 then
			local v92 = p86.maxRotTime - p86.minRotTime
			local v93 = math.max(v92, 0.001)
			local v94 = streamReadUIntN(p87, 8)
			local v95 = p86.rotatedTime
			if math.abs(v95) < 0.001 then
				p86.rotatedTime = 0
			end
			local v96 = v94 / 255 * v93 + p86.minRotTime
			p86.rotatedTimeInterpolator:setTargetValue(v96)
		end
	end
end
function Wheels.onWriteUpdateStream(p97, p98, p99, p100)
	if not p99.isServer then
		local v101 = p97.spec_wheels
		if streamWriteBool(p98, bitAND(p100, v101.dirtyFlag) ~= 0) then
			for v102 = 1, #v101.wheels do
				local v103 = v101.wheels[v102]
				if v103.physics.isSynchronized then
					v103:writeStream(p98)
				end
			end
			if p97.maxRotTime ~= 0 and p97.minRotTime ~= 0 then
				local v104 = p97.maxRotTime - p97.minRotTime
				local v105 = math.max(v104, 0.001)
				local v106 = (p97.rotatedTime - p97.minRotTime) / v105 * 255
				local v107 = math.floor(v106)
				local v108 = math.clamp(v107, 0, 255)
				streamWriteUIntN(p98, v108, 8)
			end
		end
	end
end
function Wheels.onUpdate(p109, p110, _, _, _)
	local v111 = p109.spec_wheels
	if not p109.isServer and p109.isClient then
		v111.networkTimeInterpolator:update(p110)
		local v112 = v111.networkTimeInterpolator:getAlpha()
		p109.rotatedTime = p109.rotatedTimeInterpolator:getInterpolatedValue(v112)
		for v113 = 1, #v111.wheels do
			v111.wheels[v113]:clientUpdate(p110, v112)
		end
		if v111.networkTimeInterpolator:isInterpolating() then
			p109:raiseActive()
		end
	end
	if p109.finishedFirstUpdate then
		local v114 = g_currentMission.environment.weather:getGroundWetness()
		for _, v115 in ipairs(v111.wheels) do
			v115:update(p110, v111.currentUpdateIndex, v114)
		end
		v111.currentUpdateIndex = v111.currentUpdateIndex + 1
		if v111.currentUpdateIndex > 4 then
			v111.currentUpdateIndex = 1
		end
		if p109.isActive then
			local v116 = g_currentMission.missionInfo.fruitDestruction
			if v116 then
				v116 = not p109:getIsAIActive()
			end
			if v116 then
				v116 = p109.getBlockFoliageDestruction == nil and true or not p109:getBlockFoliageDestruction()
			end
			for _, v117 in ipairs(v111.wheels) do
				v117.destruction:update(p110, v116)
			end
		end
		if v111.surfaceSounds ~= nil then
			if p109:getAreSurfaceSoundsActive() then
				local v118 = p109:getCurrentSurfaceSound()
				if v118 ~= v111.currentSurfaceSound then
					if v111.currentSurfaceSound ~= nil then
						g_soundManager:stopSample(v111.currentSurfaceSound)
					end
					if v118 ~= nil then
						g_soundManager:playSample(v118)
					end
					v111.currentSurfaceSound = v118
				end
			elseif v111.currentSurfaceSound ~= nil then
				g_soundManager:stopSample(v111.currentSurfaceSound)
				v111.currentSurfaceSound = nil
			end
		end
		if v111.hasSteeringNodes then
			p109:updateSteeringNodes(p110)
		end
	end
	if #v111.wheels > 0 and p109.isServer then
		p109:raiseDirtyFlags(v111.dirtyFlag)
	end
end
function Wheels.onPostUpdate(p119, p120, _, _, _)
	if p119.isServer then
		local v121 = p119.spec_wheels
		for _, v122 in ipairs(v121.wheels) do
			v122:postUpdate(p120)
		end
	end
end
function Wheels.onUpdateTick(p123, p124, _, _, _)
	local v125 = p123.spec_wheels
	local v126 = g_currentMission.environment.weather:getGroundWetness()
	for _, v127 in pairs(v125.wheels) do
		v127:updateTick(p124, v126)
	end
end
function Wheels.onUpdateEnd(p128, _, _, _, _)
	if p128.isClient then
		local v129 = p128.spec_wheels
		for _, v130 in pairs(v129.wheels) do
			v130:onUpdateEnd()
		end
		if v129.currentSurfaceSound ~= nil then
			g_soundManager:stopSample(v129.currentSurfaceSound)
			v129.currentSurfaceSound = nil
		end
	end
end
function Wheels.loadHubsFromXML(p_u_131)
	p_u_131.spec_wheels.hubs = {}
	p_u_131.xmlFile:iterate("vehicle.wheels.hubs.hub", function(_, p132)
		-- upvalues: (copy) p_u_131
		p_u_131:loadHubFromXML(p_u_131.xmlFile, p132)
	end)
end
function Wheels.loadHubMaterial(p133, p134, p135, p136, p137)
	local v138 = VehicleMaterial.new(p133.baseDirectory)
	if v138:loadFromXML(p134, p135, p133.customEnvironment) then
		p136[p137] = v138
	end
	if p134:getValue(p135 .. "#useBaseColor", false) then
		p136[p137] = VehicleConfigurationItemColor.getMaterialByColorConfiguration(p133, "baseColor") or p136[p137]
	elseif p134:getValue(p135 .. "#useRimColor", false) then
		p136[p137] = VehicleConfigurationItemColor.getMaterialByColorConfiguration(p133, "rimColor") or (p133.spec_wheels.rimMaterial or p136[p137])
		if p136[p137] == nil then
			p136[p137] = VehicleMaterial.new(self.baseDirectory)
			p136[p137]:setTemplateName("RIM_DEFAULT")
			return
		end
	else
		local v139 = p134:getValue(p135 .. "#useDesignColorIndex")
		if v139 ~= nil then
			local v140 = v139 < 2 and "designColor" or string.format("designColor%d", v139)
			p136[p137] = VehicleConfigurationItemColor.getMaterialByColorConfiguration(p133, v140) or p136[p137]
		end
	end
end
function Wheels.loadHubFromXML(p141, p142, p143)
	local v144 = p141.spec_wheels
	local v145 = p142:getValue(p143 .. "#linkNode", nil, p141.components, p141.i3dMappings)
	if v145 ~= nil then
		local v146 = {
			["linkNode"] = v145,
			["isLeft"] = p142:getValue(p143 .. "#isLeft")
		}
		local v147 = p142:getValue(p143 .. "#filename")
		v146.xmlFilename = Utils.getFilename(v147, p141.baseDirectory)
		local v148 = XMLFile.load("wheelHubXml", v146.xmlFilename, Wheels.xmlSchemaHub)
		if v148 ~= nil then
			local v149 = v148:getValue("hub.filename")
			if v149 == nil then
				Logging.xmlError(v148, "Unable to retrieve hub i3d filename!")
				return
			end
			v146.i3dFilename = Utils.getFilename(v149, p141.baseDirectory)
			Wheels.loadHubMaterial(p141, p142, p143 .. ".material", v146, "material")
			Wheels.loadHubMaterial(p141, p142, p143 .. ".boltMaterial", v146, "boltMaterial")
			Wheels.loadHubMaterial(p141, p142, p143 .. ".additionalMaterial", v146, "additionalMaterial")
			Wheels.loadHubMaterial(p141, p142, p143 .. ".boltAdditionalMaterial", v146, "boltAdditionalMaterial")
			v146.nodeStr = v148:getValue("hub.nodes#" .. (v146.isLeft and "left" or "right"))
			local v150 = p141:loadSubSharedI3DFile(v146.i3dFilename, false, false, p141.onWheelHubI3DLoaded, p141, {
				["hub"] = v146,
				["linkNode"] = v145,
				["xmlFile"] = p142,
				["key"] = p143
			})
			local v151 = v144.sharedLoadRequestIds
			table.insert(v151, v150)
			v148:delete()
		end
		return true
	end
	Logging.xmlError(p142, "Missing link node for hub \'%s\'", p143)
end
function Wheels.onWheelHubI3DLoaded(p152, p153, _, p154)
	local v155 = p152.spec_wheels
	local v156 = p154.hub
	local v157 = p154.linkNode
	local v158 = p154.xmlFile
	local v159 = p154.key
	if p153 == 0 then
		if not (p152.isDeleting or p152.isDeleted) then
			Logging.xmlError(v158, "Unable to load \'%s\' in hub \'%s\'", v156.i3dFilename, v156.xmlFilename)
		end
		return
	else
		v156.node = I3DUtil.indexToObject(p153, v156.nodeStr, p152.i3dMappings)
		if v156.node == nil then
			Logging.xmlError(v158, "Could not find hub node \'%s\' in \'%s\'", v156.nodeStr, v156.xmlFilename)
		else
			link(v157, v156.node)
			delete(p153)
			local v160 = v158:getValue(v159 .. "#offset")
			if v160 ~= nil then
				if not v156.isLeft then
					v160 = v160 * -1
				end
				setTranslation(v156.node, v160, 0, 0)
			end
			local v161 = v158:getValue(v159 .. "#scale", nil, true)
			if v161 ~= nil then
				setScale(v156.node, v161[1], v161[2], v161[3])
			end
			local v162 = v155.hubs
			table.insert(v162, v156)
		end
	end
end
function Wheels.loadAckermannSteeringFromXML(p163, p164, p165, p166)
	local v167 = p163.spec_wheels
	local v168, _ = ConfigurationUtil.getXMLConfigurationKey(p164, p165, "vehicle.wheels.ackermannSteeringConfigurations.ackermannSteering", nil, "ackermann")
	v167.steeringCenterNode = nil
	if v168 ~= nil then
		local v169 = p164:getValue(v168 .. "#rotSpeed")
		local v170 = p166 or p164:getValue(v168 .. "#rotMax")
		local v171 = nil
		local v172 = nil
		local v173 = p164:getValue(v168 .. "#rotCenterWheel1")
		if v173 == nil or v167.wheels[v173] == nil then
			local v174, _ = p164:getValue(v168 .. "#rotCenterNode", nil, p163.components, p163.i3dMappings)
			if v174 == nil then
				local v175 = p164:getValue(v168 .. "#rotCenterWheels", nil, true)
				if v175 == nil or #v175 <= 0 then
					local v176 = p164:getValue(v168 .. "#rotCenter", nil, true)
					if v176 ~= nil then
						v171 = v176[1]
						v172 = v176[2]
					end
				else
					local v177 = 0
					local v178 = 0
					local v179 = 0
					for v180 = 1, #v175 do
						local v181 = v167.wheels[v175[v180]]
						if v181 ~= nil then
							local v182, _, v183 = localToLocal(v181.node, p163.components[1].node, v181.physics.positionX, 0, v181.physics.positionZ)
							v177 = v177 + v182
							v178 = v178 + v183
							v179 = v179 + 1
						end
					end
					if v179 > 0 then
						v171 = v177 / v179
						v172 = v178 / v179
					end
				end
			else
				local v184
				v171, v184, v172 = localToLocal(v174, p163.components[1].node, 0, 0, 0)
				v167.steeringCenterNode = v174
			end
		else
			local v185 = v167.wheels[v173]
			local v186
			v171, v186, v172 = localToLocal(v185.node, p163.components[1].node, v185.physics.positionX, v185.physics.positionY, v185.physics.positionZ)
			local v187 = p164:getValue(v168 .. "#rotCenterWheel2")
			if v187 ~= nil and v167.wheels[v187] ~= nil then
				if v187 == v173 then
					Logging.xmlWarning(p164, "The ackermann steering wheels are identical (both index %d). Are you sure this is correct? (%s)", v173, v168)
				end
				local v188 = v167.wheels[v187]
				local v189, _, v190 = localToLocal(v188.node, p163.components[1].node, v188.physics.positionX, v188.physics.positionY, v188.physics.positionZ)
				v171 = 0.5 * (v171 + v189)
				v172 = 0.5 * (v172 + v190)
			end
		end
		if v167.steeringCenterNode == nil then
			v167.steeringCenterNode = createTransformGroup("steeringCenterNode")
			link(p163.components[1].node, v167.steeringCenterNode)
			if v171 ~= nil and v172 ~= nil then
				setTranslation(v167.steeringCenterNode, v171, 0, v172)
			end
		end
		if v169 ~= nil and (v170 ~= nil and v171 ~= nil) then
			local v191 = math.rad(v169)
			local v192 = math.abs(v191)
			local v193 = math.rad(v170)
			local v194 = math.abs(v193)
			local v195 = 0
			local v196 = false
			for _, v197 in ipairs(v167.wheels) do
				if v197.physics.rotSpeed ~= 0 then
					local v198, _, v199 = localToLocal(v197.repr, v167.steeringCenterNode, 0, 0, 0)
					local v200 = math.abs(v199) / math.tan(v194) + math.abs(v198)
					if v195 <= v200 then
						v195 = v200
						v196 = true
					end
				end
			end
			for _, v201 in ipairs(v167.steeringNodes) do
				local v202, _, v203 = localToLocal(v201.node, v167.steeringCenterNode, 0, 0, 0)
				local v204 = math.abs(v203) / math.tan(v194) + math.abs(v202)
				if v195 <= v204 then
					v195 = v204
					v196 = true
				end
			end
			local v205 = Utils.getNoNil(p163.maxRotation, 0)
			p163.maxRotation = math.max(v205, v194)
			p163.maxTurningRadius = p164:getValue(v168 .. "#minTurningRadius", v195)
			p163.wheelSteeringDuration = v194 / v192
			if v196 then
				for _, v206 in ipairs(v167.wheels) do
					if v206.physics.rotSpeed ~= 0 then
						local v207, _, v208 = localToLocal(v206.repr, v167.steeringCenterNode, 0, 0, 0)
						local v209
						if v195 - v207 == 0 then
							v209 = 1.5707963267948966 * math.sign(v208)
						else
							local v210 = v208 / (v195 - v207)
							v209 = math.atan(v210)
						end
						local v211
						if v195 + v207 == 0 then
							v211 = -1.5707963267948966 * math.sign(v208)
						else
							local v212 = v208 / (v195 + v207)
							v211 = -math.atan(v212)
						end
						local v213 = v209 < v211
						if v213 then
							local v214 = v209
							v209 = v211
							v211 = v214
						end
						v206:setSteeringValues(v211, v209, v209 / p163.wheelSteeringDuration, -v211 / p163.wheelSteeringDuration, v213)
					end
				end
				for _, v215 in ipairs(v167.steeringNodes) do
					local v216, _, v217 = localToLocal(v215.node, v167.steeringCenterNode, 0, 0, 0)
					local v218
					if v195 - v216 == 0 then
						v218 = 1.5707963267948966 * math.sign(v217)
					else
						local v219 = v217 / (v195 - v216)
						v218 = math.atan(v219)
					end
					local v220
					if v195 + v216 == 0 then
						v220 = -1.5707963267948966 * math.sign(v217)
					else
						local v221 = v217 / (v195 + v216)
						v220 = -math.atan(v221)
					end
					local v222 = v218 < v220
					if v222 then
						local v223 = v218
						v218 = v220
						v220 = v223
					end
					v215.rotMin = v220
					v215.rotMax = v218
					v215.rotSpeed = v218 / p163.wheelSteeringDuration
					v215.rotSpeedNeg = -v220 / p163.wheelSteeringDuration
					if v222 then
						local v224 = -v215.rotSpeedNeg
						local v225 = -v215.rotSpeed
						v215.rotSpeed = v224
						v215.rotSpeedNeg = v225
					end
				end
			end
		end
	end
	for _, v226 in ipairs(v167.wheels) do
		if v226.physics.rotSpeed ~= 0 then
			if v226.physics.rotMax >= 0 == (v226.physics.rotSpeed >= 0) then
				local v227 = v226.physics.rotMax / v226.physics.rotSpeed
				local v228 = p163.maxRotTime
				p163.maxRotTime = math.max(v227, v228)
			end
			if v226.physics.rotMin >= 0 == (v226.physics.rotSpeed >= 0) then
				local v229 = v226.physics.rotMin / v226.physics.rotSpeed
				local v230 = p163.maxRotTime
				p163.maxRotTime = math.max(v229, v230)
			end
			local v231 = v226.physics.rotSpeedNeg
			if v231 == nil or v231 == 0 then
				v231 = v226.physics.rotSpeed
			end
			if v226.physics.rotMax >= 0 ~= (v231 >= 0) then
				local v232 = v226.physics.rotMax / v231
				local v233 = p163.minRotTime
				p163.minRotTime = math.min(v232, v233)
			end
			if v226.physics.rotMin >= 0 ~= (v231 >= 0) then
				local v234 = v226.physics.rotMin / v231
				local v235 = p163.minRotTime
				p163.minRotTime = math.min(v234, v235)
			end
		end
		if v226.physics.rotSpeedLimit ~= nil then
			v226.physics.rotSpeedDefault = v226.physics.rotSpeed
			v226.physics.rotSpeedNegDefault = v226.physics.rotSpeedNeg
			v226.physics.currentRotSpeedAlpha = 1
		end
	end
	for _, v236 in ipairs(v167.steeringNodes) do
		local v237 = v236.rotMax / v236.rotSpeed
		local v238 = p163.maxRotTime
		p163.maxRotTime = math.max(v237, v238)
		local v239 = v236.rotSpeedNeg
		if v239 == nil or v239 == 0 then
			v239 = v236.rotSpeed
		end
		local v240 = v236.rotMin / v239
		local v241 = p163.minRotTime
		p163.minRotTime = math.min(v240, v241)
	end
end
function Wheels.loadWheelsFromXML(p242, p243, p244, p245)
	local v246 = p242.spec_wheels
	local v247 = 0
	while true do
		local v248 = string.format(".wheels.wheel(%d)", v247)
		if not p243:hasProperty(p244 .. v248) then
			break
		end
		local v249 = Wheel.new(p242, p242.xmlFile, Wheels.CONFIG_XML_PATH, v248, v247 + 1, p245, v246.configurationIndexToParentConfigIndex, p242.baseDirectory)
		if p242:loadWheelFromXML(v249) then
			v249:finalize()
			if v246.isCareWheelConfiguration ~= nil then
				v249:setIsCareWheel(v246.isCareWheelConfiguration)
			end
			local v250 = v246.wheels
			table.insert(v250, v249)
		end
		v247 = v247 + 1
	end
end
function Wheels.loadWheelFromXML(_, p251)
	return p251:loadFromXML()
end
function Wheels.addToPhysics(p252, p253)
	if not p253(p252) then
		return false
	end
	local v254 = p252.spec_wheels
	local v255 = p252:getBrakeForce()
	for _, v256 in pairs(v254.wheels) do
		v256:addToPhysics(v255)
	end
	if p252.isServer then
		p252:brake(v255)
	end
	return true
end
function Wheels.removeFromPhysics(p257, p258)
	local v259 = p258(p257)
	if p257.isServer then
		local v260 = p257.spec_wheels
		for _, v261 in pairs(v260.wheels) do
			v261:removeFromPhysics()
		end
	end
	return v259
end
function Wheels.getComponentMass(p262, p263, p264)
	local v265 = p263(p262, p264)
	local v266 = p262.spec_wheels
	for _, v267 in pairs(v266.wheels) do
		if v267.node == p264.node then
			v265 = v265 + v267:getMass()
		end
	end
	return v265
end
function Wheels.getVehicleWorldXRot(p268, p269)
	local v270 = p268.spec_wheels
	local v271 = (1 / 0)
	local v272 = (-1 / 0)
	local v273 = 0
	local v274 = 0
	local v275 = 0
	for v276 = 1, #v270.wheels do
		local v277 = v270.wheels[v276]
		if v277.physics.hasGroundContact then
			local v278 = v277.physics.netInfo
			local v279 = v277.physics.radius
			local _, _, v280 = localToLocal(v277.node, p268.components[1].node, 0, 0, v278.z)
			local _, v281, _ = localToWorld(v277.node, v278.x, v278.y - v279, v278.z)
			if v280 < v271 then
				v274 = v281
				v271 = v280
			end
			if v272 < v280 then
				v273 = v281
				v272 = v280
			end
		end
	end
	if v271 ~= (1 / 0) then
		local v282 = v273 - v274
		if v282 ~= 0 then
			local v283 = v272 - v271
			if v283 < 0.25 and p269 ~= nil then
				return p269(p268)
			end
			local v284 = v283 / v282
			v275 = 1.5707963267948966 - math.atan(v284)
			if v275 > 1.5707963267948966 then
				v275 = v275 - 3.141592653589793
			end
		end
	end
	return v275
end
function Wheels.getVehicleWorldDirection(p285, p286)
	local v287 = p285.spec_wheels
	local v288 = 0
	local v289 = 0
	local v290 = 0
	local v291 = 0
	local v292 = 0
	for v293 = 1, #v287.wheels do
		local v294 = v287.wheels[v293]
		if v294.physics.hasGroundContact then
			local v295 = v294.physics.netInfo
			local _, _, v296 = localToLocal(v294.node, p285.components[1].node, v295.x, v295.y, v295.z)
			v288 = v288 + v296
			local v297, v298, v299 = localDirectionToWorld(v294.node, v294.physics.directionZ, v294.physics.directionX, -v294.physics.directionY)
			v289 = v289 + v297
			v290 = v290 + v298
			v291 = v291 + v299
			v292 = v292 + 1
		end
	end
	if v292 > 0 then
		v289 = v289 / v292
		local _ = v290 / v292
		v291 = v291 / v292
	end
	if v292 <= 2 then
		return 0, 0, 0
	end
	local v300 = v288 / v292
	local v301 = 0
	local v302 = 0
	local v303 = 0
	local v304 = 0
	local v305 = 0
	local v306 = 0
	local v307 = 0
	local v308 = 0
	for v309 = 1, #v287.wheels do
		local v310 = v287.wheels[v309]
		if v310.physics.hasGroundContact then
			local v311 = v310.physics.netInfo
			local v312 = v310.physics.radius
			local v313, v314, v315 = localToLocal(v310.node, p285.components[1].node, v311.x + v310.physics.directionX * v312, v311.y + v310.physics.directionY * v312, v311.z + v310.physics.directionZ * v312)
			if v300 + 0.25 < v315 then
				v303 = v303 + v313
				v304 = v304 + v314
				v301 = v301 + v315
				v302 = v302 + 1
			elseif v315 < v300 - 0.25 then
				v305 = v305 + v313
				v306 = v306 + v314
				v307 = v307 + v315
				v308 = v308 + 1
			end
		end
	end
	if v302 <= 0 or v308 <= 0 then
		return p286(p285)
	end
	local v316 = v303 / v302
	local v317 = v304 / v302
	local v318 = v301 / v302
	local v319 = v305 / v308
	local v320 = v306 / v308
	local v321 = v307 / v308
	local v322, v323, v324 = localToWorld(p285.components[1].node, v316, v317, v318)
	local v325, v326, v327 = localToWorld(p285.components[1].node, v319, v320, v321)
	if VehicleDebug.state == VehicleDebug.DEBUG_TRANSMISSION then
		DebugGizmo.renderAtPosition(v322, v323, v324, 1, 0, 0, 0, 1, 0, "frontWheels")
		DebugGizmo.renderAtPosition(v325, v326, v327, 1, 0, 0, 0, 1, 0, "backWheels")
	end
	local v328 = v322 - v325
	local v329 = v323 - v326
	local v330 = v324 - v327
	local _, v331, _ = MathUtil.vector3Normalize(v328, v329, v330)
	return MathUtil.vector3Normalize(v289, v331, v291)
end
function Wheels.validateWashableNode(p_u_332, p333, p334)
	if p_u_332.loadingStep >= SpecializationLoadStep.FINISHED then
		local v335 = p_u_332.spec_wheels
		for v336 = 1, #v335.wheels do
			local v_u_337 = v335.wheels[v336]
			local v338 = v_u_337.driveNode
			if v_u_337.linkNode ~= v_u_337.driveNode then
				v338 = v_u_337.linkNode
			end
			if v_u_337.wheelDirtNodes == nil then
				v_u_337.wheelDirtNodes = {}
				I3DUtil.getNodesByShaderParam(v338, "scratches_dirt_snow_wetness", v_u_337.wheelDirtNodes)
			end
			if v_u_337.wheelMudMeshes == nil then
				v_u_337.wheelMudMeshes = {}
				I3DUtil.getNodesByShaderParam(v338, "mudAmount", v_u_337.wheelMudMeshes)
			end
			if v_u_337.wheelDirtNodes[p334] ~= nil then
				local v_u_348 = {
					["wheel"] = v_u_337,
					["fieldDirtMultiplier"] = v_u_337.physics.fieldDirtMultiplier,
					["streetDirtMultiplier"] = v_u_337.physics.streetDirtMultiplier,
					["waterWetnessFactor"] = v_u_337.physics.waterWetnessFactor,
					["minDirtPercentage"] = v_u_337.physics.minDirtPercentage,
					["maxDirtOffset"] = v_u_337.physics.maxDirtOffset,
					["dirtColorChangeSpeed"] = v_u_337.physics.dirtColorChangeSpeed,
					["isSnowNode"] = true,
					["loadFromSavegameFunc"] = function(p339, p340)
						-- upvalues: (copy) v_u_348, (copy) p_u_332, (copy) v_u_337
						v_u_348.wheel.physics.snowScale = p339:getValue(p340 .. "#snowScale", 0)
						v_u_348.wheel.physics.lastSnowScale = v_u_348.wheel.physics.snowScale
						local v341, v342 = g_currentMission.environment:getDirtColors()
						local v343, v344, v345 = MathUtil.vector3ArrayLerp(v341, v342, v_u_348.wheel.physics.snowScale)
						p_u_332:setNodeDirtColor(p_u_332:getWashableNodeByCustomIndex(v_u_337), v343, v344, v345, true)
					end,
					["saveToSavegameFunc"] = function(p346, p347)
						-- upvalues: (copy) v_u_348
						p346:setValue(p347 .. "#snowScale", v_u_348.wheel.physics.snowScale)
					end
				}
				return false, p_u_332.updateWheelDirtAmount, v_u_337, v_u_348
			end
			if v_u_337.wheelMudMeshes[p334] ~= nil then
				local v349 = {
					["wheel"] = v_u_337,
					["fieldDirtMultiplier"] = v_u_337.physics.fieldDirtMultiplier,
					["streetDirtMultiplier"] = v_u_337.physics.streetDirtMultiplier,
					["waterWetnessFactor"] = v_u_337.physics.waterWetnessFactor,
					["minDirtPercentage"] = v_u_337.physics.minDirtPercentage,
					["maxDirtOffset"] = v_u_337.physics.maxDirtOffset,
					["dirtColorChangeSpeed"] = v_u_337.physics.dirtColorChangeSpeed,
					["isSnowNode"] = true,
					["cleaningMultiplier"] = 4
				}
				rotateAboutLocalAxis(p334, math.random() * 3.14, 1, 0, 0)
				return false, p_u_332.updateWheelMudAmount, v_u_337.wheelMudMeshes, v349
			end
		end
	end
	return p333(p_u_332, p334)
end
function Wheels.getAIDirectionNode(p350, p351)
	return p350.spec_wheels.steeringCenterNode or p351(p350)
end
function Wheels.getAIRootNode(p352, p353)
	return p352.spec_wheels.steeringCenterNode or p353(p352)
end
function Wheels.getSupportsMountKinematic(p354, p355)
	local v356
	if #p354.spec_wheels.wheels == 0 then
		v356 = p355(p354)
	else
		v356 = false
	end
	return v356
end
function Wheels.loadBendingNodeFromXML(p357, p358, p359, p360, p361, ...)
	if not p358(p357, p359, p360, p361, ...) then
		return false
	end
	local v362 = p359:getValue(p360 .. "#wheelIndices", nil, true)
	if v362 ~= nil and #v362 > 0 then
		p361.minX = (1 / 0)
		p361.maxX = (-1 / 0)
		p361.minZ = (1 / 0)
		p361.maxZ = (-1 / 0)
		for _, v363 in ipairs(v362) do
			local v364 = p357:getWheelFromWheelIndex(v363)
			if v364 == nil then
				Logging.xmlWarning(p359, "Unable to find wheel index \'%s\' in \'%s\'", v363, p360)
			else
				local v365, _, v366 = localToLocal(v364.driveNode, p361.node, v364.physics.wheelShapeWidth * 0.5 + 0.05 + v364.physics.wheelShapeWidthOffset, 0, v364.physics.radius * 0.5 + 0.05)
				local v367, _, v368 = localToLocal(v364.driveNode, p361.node, -(v364.physics.wheelShapeWidth * 0.5 + 0.05 - v364.physics.wheelShapeWidthOffset), 0, -(v364.physics.radius * 0.5 + 0.05))
				local v369 = p361.minX
				p361.minX = math.min(v369, v365, v367)
				local v370 = p361.maxX
				p361.maxX = math.max(v370, v365, v367)
				local v371 = p361.minZ
				p361.minZ = math.min(v371, v366, v368)
				local v372 = p361.maxZ
				p361.maxZ = math.max(v372, v366, v368)
			end
		end
		p361.minX = p359:getValue(p360 .. "#minX", p361.minX)
		p361.maxX = p359:getValue(p360 .. "#maxX", p361.maxX)
		p361.minZ = p359:getValue(p360 .. "#minZ", p361.minZ)
		p361.maxZ = p359:getValue(p360 .. "#maxZ", p361.maxZ)
	end
	return true
end
function Wheels.updateWheelDirtAmount(p373, p374, p375, _, _, _, p376)
	local v377 = p373.spec_washable.lastDirtMultiplier
	local v378 = v377 == 0 and 0 or p375 * p373.spec_washable.dirtDuration * v377
	local v379
	if p374.wheel == nil or (p374.wheel.physics.contact ~= WheelContactType.NONE or p374.wheel.forceWheelDirtUpdate == true) then
		local v380 = p374.wheel.physics
		local v381 = v380:getIsOnField()
		local v382 = p373.lastSpeed * 3600
		if v381 then
			v378 = v378 * p374.fieldDirtMultiplier
		elseif p374.dirtAmount > p374.minDirtPercentage then
			local v383 = v382 / 20
			v378 = v378 * p374.streetDirtMultiplier * v383
		end
		if p374.wetness < 0.25 then
			local v384 = p373.spec_washable.washableNodes[1].dirtAmount
			local v385 = p374.maxDirtOffset
			local v386 = 1 - v384
			local v387 = v385 * (math.pow(v386, 2) * 0.75 + 0.25)
			local v388 = p374.maxDirtOffset
			local v389 = 1 - v384
			local v390 = v388 * (math.pow(v389, 2) * 0.95 + 0.05)
			if v387 < v384 - p374.dirtAmount then
				v378 = v378 < 0 and 0 or v378
			else
				v378 = v384 - p374.dirtAmount < -v390 and v378 > 0 and 0 or v378
			end
		end
		local v391 = v380.hasSnowContact and (p376 or 0) < 1 and 1 or -0.25
		local v392 = v382 / 5
		local v393 = math.min(v392, 2)
		local v394 = v380.snowScale + v391 * p375 * p374.dirtColorChangeSpeed * v393
		local v395 = math.max(v394, 0)
		v380.snowScale = math.min(v395, 1)
		if v380.snowScale ~= v380.lastSnowScale then
			local v396, v397 = g_currentMission.environment:getDirtColors()
			local v398, v399, v400 = MathUtil.vector3ArrayLerp(v396, v397, v380.snowScale)
			p373:setNodeDirtColor(p374, v398, v399, v400)
			v380.lastSnowScale = v380.snowScale
		end
		if v380.hasWaterContact then
			local v401 = p375 * p373.spec_washable.wetDuration * p374.waterWetnessFactor
			local v402 = p373.lastSpeed * 3600 / 10
			v379 = v401 * (1 + math.min(v402, 1))
		else
			local v403 = -p375 * p373.spec_washable.dryDuration
			local v404 = p373.lastSpeed * 3600 / 10
			v379 = v403 * (math.min(v404, 1) * 5)
		end
		p374.wheel.forceWheelDirtUpdate = false
	else
		v379 = 0
	end
	return v378, v379
end
function Wheels.updateWheelMudAmount(p405, p406, p407, _, p408, _, _)
	local v409 = p405.spec_washable.lastDirtMultiplier
	local v410 = v409 == 0 and 0 or p407 * p405.spec_washable.dirtDuration * v409
	if p406.wheelDirtNode == nil then
		p406.wheelDirtNode = p405:getWashableNodeByCustomIndex(p406.wheel)
		if p406.wheelDirtNode == nil then
			return 0, 0
		end
	end
	if p406.wheel ~= nil and (p406.wheel.physics.contact == WheelContactType.NONE and p406.wheel.forceWheelDirtUpdate ~= true) then
		return 0, p406.wheelDirtNode.wetness - p406.wetness
	end
	local v411 = p405.lastSpeed * 3600
	local v412 = (WheelEffects.MAX_MUD_AMOUNT[p406.wheel.physics.densityType] or 0) * (p408 > 0.1 and 1 or 0.5)
	local v413 = p406.wheelDirtNode.dirtAmount
	if p406.dirtAmount < v412 and v413 > 0.75 then
		v410 = v410 * p406.fieldDirtMultiplier * 2
	elseif v412 < p406.dirtAmount or v413 < 0.75 then
		local v414 = v411 / 20
		v410 = v410 * p406.streetDirtMultiplier * 2 * v414
	end
	local v415 = p406.wheelDirtNode.wetness - p406.wetness
	local v416 = p406.color
	local v417 = p406.wheelDirtNode.color
	if v416[1] ~= v417[1] or (v416[2] ~= v417[2] or v416[3] ~= v417[3]) then
		p405:setNodeDirtColor(p406, v417[1], v417[2], v417[3])
	end
	return v410, v415
end
function Wheels.forceUpdateWheelPhysics(p418, _)
	local v419 = p418.spec_wheels
	for v420 = 1, #v419.wheels do
		v419.wheels[v420]:updatePhysics(p418:getBrakeForce())
	end
end
function Wheels.onWheelSnowHeightChanged(p421, p422, _)
	if p422 <= 0 then
		local v423 = p421.spec_wheels
		local v424 = false
		for v425 = 1, #v423.wheels do
			if v423.wheels[v425].physics.snowScale > 0 then
				v423.wheels[v425].physics.snowScale = 0
				v423.wheels[v425].forceWheelDirtUpdate = true
				v424 = true
			end
		end
		if v424 then
			p421:raiseActive()
		end
	end
end
function Wheels.getSteeringNodeByNode(p426, p427)
	local v428 = p426.spec_wheels
	for _, v429 in ipairs(v428.steeringNodes) do
		if v429.node == p427 then
			return v429
		end
	end
	return nil
end
function Wheels.updateSteeringNodes(p430, p431)
	local v432 = p430.spec_wheels
	for _, v433 in ipairs(v432.steeringNodes) do
		local v434
		if p430.rotatedTime > 0 or v433.rotSpeedNeg == nil then
			v434 = p430.rotatedTime * v433.rotSpeed
		else
			v434 = p430.rotatedTime * v433.rotSpeedNeg
		end
		if v433.rotMax < v434 then
			v434 = v433.rotMax
		elseif v434 < v433.rotMin then
			v434 = v433.rotMin
		end
		if v433.rotScale ~= v433.rotScaleTarget then
			local v435 = v433.rotScaleTarget - v433.rotScale
			local v436 = math.sign(v435)
			local v437 = p431 * v433.rotScaleTargetSpeed * v436
			v433.rotScale = (v436 > 0 and math.min or math.max)(v433.rotScale + v437, v433.rotScaleTarget)
		end
		local v438 = v434 * v433.rotScale
		if v433.offset ~= v433.offsetTarget then
			local v439 = v433.offsetTarget - v433.offset
			local v440 = math.sign(v439)
			local v441 = p431 * v433.offsetTargetSpeed * v440
			v433.offset = (v440 > 0 and math.min or math.max)(v433.offset + v441, v433.offsetTarget)
		end
		local v442 = v438 + v433.offset
		local _, v443, _ = getRotation(v433.node)
		local v444 = v443 - v442
		if math.abs(v444) > 0.004 then
			setRotation(v433.node, 0, v442, 0)
			if p430.isServer and v433.componentJoint ~= nil then
				p430:setComponentJointFrame(v433.componentJoint, 0)
			end
		end
	end
end
function Wheels.getCurrentSurfaceSound(p445)
	local v446 = p445.spec_wheels
	local v447 = #v446.wheels
	for v448, v449 in ipairs(v446.wheels) do
		if v449.syncContactState or v448 == v447 then
			local v450, v451 = v449.physics:getSurfaceSoundAttributes()
			if v450 ~= nil then
				return v446.surfaceNameToSound[v450]
			end
			if v451 ~= nil then
				return v446.surfaceIdToSound[v451]
			end
		end
	end
	return nil
end
function Wheels.getAreSurfaceSoundsActive(p452)
	return p452.isActiveForLocalSound
end
function Wheels.getIsVersatileYRotActive(_, _)
	return true
end
function Wheels.getWheelFromWheelIndex(p453, p454)
	return p453.spec_wheels.wheels[p454]
end
function Wheels.getWheelByWheelNode(p455, p456)
	local v457 = p455.spec_wheels
	if type(p456) == "string" then
		local v458 = p455.i3dMappings[p456]
		if v458 ~= nil then
			p456 = v458.nodeId
		end
	end
	for v459 = 1, #v457.wheels do
		local v460 = v457.wheels[v459]
		if v460.repr == p456 or (v460.driveNode == p456 or v460.linkNode == p456) then
			return v460
		end
	end
	return nil
end
function Wheels.getWheels(p461)
	return p461.spec_wheels.wheels
end
function Wheels.brake(p462, p463)
	local v464 = p462.spec_wheels
	if p463 ~= v464.brakePedal then
		v464.brakePedal = p463
		for _, v465 in pairs(v464.wheels) do
			v465:setBrakePedal(v464.brakePedal)
		end
		SpecializationUtil.raiseEvent(p462, "onBrake", v464.brakePedal)
	end
end
function Wheels.setCustomBrakeForce(p466, p467)
	p466.spec_wheels.customBrakeForce = p467
end
function Wheels.getBrakeForce(p468)
	return p468.spec_wheels.customBrakeForce or 0
end
function Wheels.onLeaveVehicle(p469)
	local v470 = p469.spec_wheels
	if p469.isServer and p469.isAddedToPhysics then
		local v471 = p469:getBrakeForce()
		for _, v472 in pairs(v470.wheels) do
			v472:updatePhysics(v471, 0)
		end
	end
end
function Wheels.onPreAttach(p473)
	local v474 = p473.spec_wheels
	for _, v475 in pairs(v474.wheels) do
		v475:onPreAttach()
	end
end
function Wheels.onPostDetach(p476)
	local v477 = p476.spec_wheels
	for _, v478 in pairs(v477.wheels) do
		v478:onPostDetach()
	end
end
function Wheels.getSteeringRotTimeByCurvature(p479, p480)
	local v481
	if p480 == 0 then
		v481 = 0
	else
		local v482 = p479.spec_wheels
		local v483 = p480 > 0 and (-1 / 0) or (1 / 0)
		for _, v484 in ipairs(v482.wheels) do
			if v484.physics.rotSpeed ~= 0 then
				local v485, _, v486 = localToLocal(v484.repr, v482.steeringCenterNode, 0, 0, 0)
				local v487 = v486 * math.abs(p480) / (1 - math.abs(p480) * math.abs(v485))
				local v488 = math.atan(v487) / v484.physics.rotSpeed
				if p480 > 0 then
					local v489 = -v488
					v483 = math.max(v483, v489)
				else
					v483 = math.min(v483, v488)
				end
			end
		end
		v481 = v483 * -1
	end
	return v481
end
function Wheels.getTurningRadiusByRotTime(p490, p491)
	local v492 = p490.spec_wheels
	local v493 = (1 / 0)
	if v492.steeringCenterNode ~= nil then
		for _, v494 in ipairs(v492.wheels) do
			if v494.physics.rotSpeed ~= 0 then
				local v495 = p491 * v494.physics.rotSpeed
				local v496 = math.abs(v495)
				if v496 > 0 then
					local v497, _, v498 = localToLocal(v494.repr, v492.steeringCenterNode, 0, 0, 0)
					local v499 = math.abs(v498) / math.tan(v496) + math.abs(v497)
					if v499 < v493 then
						v493 = v499
					end
				end
			end
		end
	end
	return v493
end
function Wheels.onRegisterAnimationValueTypes(p_u_500)
	p_u_500:registerAnimationValueType("steeringAngle", "startSteeringAngle", "endSteeringAngle", false, AnimationValueFloat, function(p501, p502, p503)
		-- upvalues: (copy) p_u_500
		p501.wheelIndex = p502:getValue(p503 .. "#wheelIndex")
		p501.wheelNode = p502:getValue(p503 .. "#node", nil, p_u_500.components, p_u_500.i3dMappings)
		if p501.wheelIndex == nil and not p501.wheelNode then
			return false
		end
		if p501.wheelIndex == nil then
			p501:setWarningInformation("wheelNode: " .. getName(p501.wheelNode))
			p501:addCompareParameters("wheelNode")
		else
			p501:setWarningInformation("wheelIndex: " .. p501.wheelIndex)
			p501:addCompareParameters("wheelIndex")
		end
		return true
	end, function(p504)
		-- upvalues: (copy) p_u_500
		if p504.wheelIndex == nil and p504.wheelNode == nil then
			return 0
		end
		if p504.wheel == nil and p504.wheelIndex ~= nil then
			p504.wheel = p_u_500:getWheelFromWheelIndex(p504.wheelIndex)
			if p504.wheel == nil then
				Logging.xmlWarning(p_u_500.xmlFile, "Unknown wheel index \'%s\' for animation part.", p504.wheelIndex)
				p504.wheelIndex = nil
				return 0
			end
		end
		if p504.wheel == nil and p504.wheelNode ~= nil then
			p504.wheel = p_u_500:getWheelByWheelNode(p504.wheelNode)
			if p504.wheel == nil then
				Logging.xmlWarning(p_u_500.xmlFile, "Unknown wheel node \'%s\' for animation part.", getName(p504.wheelNode))
				p504.wheelNode = nil
				return 0
			end
		end
		return p504.wheel.physics.steeringAngle
	end, function(p505, p506)
		if p505.wheel ~= nil then
			p505.wheel.physics.steeringAngle = p506
		end
	end)
	p_u_500:registerAnimationValueType("brakeFactor", "startBrakeFactor", "endBrakeFactor", false, AnimationValueFloat, function(p507, p508, p509)
		-- upvalues: (copy) p_u_500
		p507.wheelIndex = p508:getValue(p509 .. "#wheelIndex")
		p507.wheelNode = p508:getValue(p509 .. "#node", nil, p_u_500.components, p_u_500.i3dMappings)
		if p507.wheelIndex == nil and not p507.wheelNode then
			return false
		end
		if p507.wheelIndex == nil then
			p507:setWarningInformation("wheelNode: " .. getName(p507.wheelNode))
			p507:addCompareParameters("wheelNode")
		else
			p507:setWarningInformation("wheelIndex: " .. p507.wheelIndex)
			p507:addCompareParameters("wheelIndex")
		end
		return true
	end, function(p510)
		-- upvalues: (copy) p_u_500
		if p510.wheel == nil and p510.wheelIndex ~= nil then
			p510.wheel = p_u_500:getWheelFromWheelIndex(p510.wheelIndex)
			if p510.wheel == nil then
				Logging.xmlWarning(p_u_500.xmlFile, "Unknown wheel index \'%s\' for animation part.", p510.wheelIndex)
				p510.wheelIndex = nil
				return 0
			end
		end
		if p510.wheel == nil and p510.wheelNode ~= nil then
			p510.wheel = p_u_500:getWheelByWheelNode(p510.wheelNode)
			if p510.wheel == nil then
				Logging.xmlWarning(p_u_500.xmlFile, "Unknown wheel node \'%s\' for animation part.", getName(p510.wheelNode))
				p510.wheelNode = nil
				return 0
			end
		end
		return p510.wheel.physics.brakeFactor
	end, function(p511, p512)
		-- upvalues: (copy) p_u_500
		if p511.wheel ~= nil then
			p511.wheel.physics.brakeFactor = p512
			p511.wheel:updatePhysics(p_u_500:getBrakeForce())
		end
	end)
end
function Wheels.onPostAttachImplement(p513, _, _, _)
	SpecializationUtil.raiseEvent(p513, "onBrake", p513.spec_wheels.brakePedal)
end
function Wheels.getWheelSuspensionModfier(p514)
	local v515 = p514.spec_wheels
	local v516 = #v515.wheels
	if v516 <= 0 then
		return 0
	end
	local v517 = 0
	for _, v518 in ipairs(v515.wheels) do
		v517 = v517 + (v518.physics.deltaY - v518.physics.netInfo.suspensionLength)
	end
	local v519 = v517 / v516
	local v520 = 0
	for _, v521 in ipairs(v515.wheels) do
		local v522 = v519 - (v521.physics.deltaY - v521.physics.netInfo.suspensionLength)
		local v523 = math.abs(v522)
		v520 = math.max(v523, v520)
	end
	return v520
end
g_soundManager:registerModifierType("WHEEL_SUSPENSION", Wheels.getWheelSuspensionModfier)
function Wheels.getTireNames(p524)
	local v525 = p524.spec_wheels
	if v525 == nil then
		return nil
	else
		local v526 = {}
		for _, v527 in ipairs(v525.wheels) do
			if v527.name ~= nil then
				v526[v527.name] = true
			end
		end
		for _, v528 in ipairs(v525.dynamicallyLoadedWheels) do
			if v528.name ~= nil then
				v526[v528.name] = true
			end
		end
		if table.size(v526) == 0 then
			return nil
		else
			return v526
		end
	end
end
function Wheels.getBrands(p529)
	local v530 = {}
	local v531 = {}
	for _, v532 in ipairs(p529) do
		if v532.isSelectable ~= false and (v532.wheelBrandName ~= nil and v530[v532.wheelBrandName] == nil) then
			local v533 = {
				["title"] = v532.wheelBrandName,
				["icon"] = v532.wheelBrandIconFilename
			}
			table.insert(v531, v533)
			v530[v532.wheelBrandName] = true
		end
	end
	return v531
end
function Wheels.getWheelsByBrand(p534, p535)
	local v536 = {}
	for _, v537 in ipairs(p534) do
		if v537.isSelectable ~= false and v537.wheelBrandName == p535.title then
			table.insert(v536, v537)
		end
	end
	return v536
end
function Wheels.loadSpecValueWheelWeight(p_u_538, _, _)
	local v539 = g_storeManager:getItemByXMLFilename(p_u_538.filename)
	local v_u_540 = nil
	if v539.configurations ~= nil then
		local v541 = v539.configurations.wheel
		if v541 ~= nil then
			for _, v542 in ipairs(v541) do
				if v542.isSelectable and v542.isDefault then
					v_u_540 = v542
					break
				end
			end
			if v_u_540 == nil then
				for _, v543 in ipairs(v541) do
					if v543.isSelectable then
						v_u_540 = v543
						break
					end
				end
			end
		end
	end
	local v_u_544 = 0
	if v_u_540 ~= nil then
		v_u_540:applyGeneratedConfiguration(p_u_538)
		local v_u_545 = Wheels.createConfigToParentConfigMapping(p_u_538)
		p_u_538:iterate(v_u_540.configKey .. ".wheels.wheel", function(p546, _)
			-- upvalues: (copy) p_u_538, (ref) v_u_540, (copy) v_u_545, (ref) v_u_544
			local v547 = string.format(".wheels.wheel(%d)", p546 - 1)
			local v548 = WheelXMLObject.new(p_u_538, "vehicle.wheels.wheelConfigurations.wheelConfiguration", v_u_540.index, v547, v_u_545)
			v548:setXMLLoadKey("")
			local v549 = v548:cacheWheelMass()
			v548:delete()
			v_u_544 = v_u_544 + v549
		end)
	end
	return v_u_544
end
function Wheels.loadSpecValueWheels(_, _, _)
	return nil
end
function Wheels.getSpecValueWheels(_, p550)
	if p550 == nil then
		return nil
	else
		local v551 = Wheels.getTireNames(p550)
		if v551 == nil then
			return nil
		else
			return table.concatKeys(v551, " / ")
		end
	end
end
function Wheels.getVRamUsageFromXML(p_u_552)
	if not p_u_552:hasProperty("vehicle.wheels") then
		return 0, 0
	end
	local v_u_553 = 0
	p_u_552:iterate("vehicle.wheels.wheelConfigurations.wheelConfiguration", function(p554, p555)
		-- upvalues: (copy) p_u_552, (ref) v_u_553
		if p_u_552:getValue(p555 .. "#isDefault") then
			v_u_553 = p554
			return false
		end
	end)
	local v556 = string.format("vehicle.wheels.wheelConfigurations.wheelConfiguration(%d)", v_u_553)
	local v_u_557 = 0
	local v_u_558 = {}
	p_u_552:iterate(v556 .. ".wheels.wheel", function(_, p559)
		-- upvalues: (copy) p_u_552, (copy) v_u_558, (ref) v_u_557
		local v560 = p_u_552:getString(p559 .. "#filename")
		if v560 ~= nil and v_u_558[v560] == nil then
			v_u_557 = v_u_557 + 1
			v_u_558[v560] = true
		end
	end)
	return v_u_557 * Wheels.VRAM_PER_WHEEL, 0
end
function Wheels.createConfigToParentConfigMapping(p_u_561)
	local v_u_562 = {}
	local v_u_563 = {}
	p_u_561:iterate("vehicle.wheels.wheelConfigurations.wheelConfiguration", function(p564, p565)
		-- upvalues: (copy) p_u_561, (copy) v_u_562
		v_u_562[p_u_561:getValue(p565 .. "#saveId", (tostring(p564)))] = p564
	end)
	p_u_561:iterate("vehicle.wheels.wheelConfigurations.wheelConfiguration", function(p566, p567)
		-- upvalues: (copy) p_u_561, (copy) v_u_562, (copy) v_u_563
		XMLUtil.checkDeprecatedXMLElements(p_u_561, p567 .. ".wheels.foliageBendingModifier", p567 .. ".foliageBendingModifier")
		local v568 = p_u_561:getValue(p567 .. ".wheels#baseConfig")
		if v568 ~= nil then
			local v569 = v_u_562[v568]
			if p566 == v569 then
				Logging.xmlError(p_u_561, "Wheel configuration %s references itself as baseConfig! Ignoring this reference", p567)
				return
			end
			v_u_563[p566] = v569
		end
	end)
	return v_u_563
end

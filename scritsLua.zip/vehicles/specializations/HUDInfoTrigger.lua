HUDInfoTrigger = {}
function HUDInfoTrigger.prerequisitesPresent(_)
	return true
end
function HUDInfoTrigger.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("HUDInfoTrigger")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.hudInfoTrigger#triggerNode", "Player or vehicle trigger node")
	v1:setXMLSpecializationType()
end
function HUDInfoTrigger.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "getIsPlayerInHudInfoTrigger", HUDInfoTrigger.getIsPlayerInHudInfoTrigger)
	SpecializationUtil.registerFunction(p2, "getAllowHudInfoTrigger", HUDInfoTrigger.getAllowHudInfoTrigger)
end
function HUDInfoTrigger.registerOverwrittenFunctions(_) end
function HUDInfoTrigger.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", HUDInfoTrigger)
	SpecializationUtil.registerEventListener(p3, "onDelete", HUDInfoTrigger)
	SpecializationUtil.registerEventListener(p3, "onUpdate", HUDInfoTrigger)
end
function HUDInfoTrigger.onLoad(p4, _)
	local v5 = p4.spec_hudInfoTrigger
	v5.triggerNode = p4.xmlFile:getValue("vehicle.hudInfoTrigger#triggerNode", nil, p4.components, p4.i3dMappings)
	if v5.triggerNode == nil then
		SpecializationUtil.removeEventListener(p4, "onDelete", HUDInfoTrigger)
		SpecializationUtil.removeEventListener(p4, "onUpdate", HUDInfoTrigger)
	else
		v5.callbackId = addTrigger(v5.triggerNode, "onHudInfoTriggerCallback", p4, false, HUDInfoTrigger.onHudInfoTriggerCallback)
		v5.enteredObjects = {}
	end
end
function HUDInfoTrigger.onDelete(p6)
	local v7 = p6.spec_hudInfoTrigger
	if v7.triggerNode ~= nil then
		removeTrigger(v7.triggerNode, v7.callbackId)
	end
end
function HUDInfoTrigger.onUpdate(p8, _, _, p9, _)
	if not p9 and p8:getIsPlayerInHudInfoTrigger() then
		p8.rootVehicle:draw()
		p8:raiseActive()
	end
end
function HUDInfoTrigger.onHudInfoTriggerCallback(p10, _, p11, p12, p13, _)
	local v14 = g_currentMission:getNodeObject(p11)
	if v14 == nil and (g_localPlayer ~= nil and p11 == g_localPlayer.rootNode) then
		v14 = g_localPlayer
	end
	if v14 ~= nil and v14 ~= p10 then
		local v15 = NetworkUtil.getObjectId(v14)
		if v15 ~= nil then
			local v16 = p10.spec_hudInfoTrigger
			if p12 then
				v16.enteredObjects[v15] = (v16.enteredObjects[v15] or 0) + 1
				p10:raiseActive()
				return
			end
			if p13 then
				v16.enteredObjects[v15] = (v16.enteredObjects[v15] or 0) - 1
				if v16.enteredObjects[v15] <= 0 then
					v16.enteredObjects[v15] = nil
				end
			end
		end
	end
end
function HUDInfoTrigger.getAllowHudInfoTrigger(_)
	return true
end
function HUDInfoTrigger.getIsPlayerInHudInfoTrigger(p17)
	if not p17:getAllowHudInfoTrigger() then
		return false
	end
	local v18 = p17.spec_hudInfoTrigger
	local v19 = g_localPlayer
	if v19 == nil then
		return false
	end
	if not v19:getIsInVehicle() then
		local v20 = NetworkUtil.getObjectId(g_localPlayer)
		return v18.enteredObjects[v20] ~= nil
	end
	local v21 = v19:getCurrentVehicle()
	if v21 == nil then
		return false
	end
	local v22 = v21.childVehicles
	for _, v23 in ipairs(v22) do
		local v24 = NetworkUtil.getObjectId(v23)
		if v18.enteredObjects[v24] ~= nil then
			return true
		end
	end
	return false
end

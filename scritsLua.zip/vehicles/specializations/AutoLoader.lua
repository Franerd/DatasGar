AutoLoader = {}
function AutoLoader.prerequisitesPresent(_)
	return true
end
function AutoLoader.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("AutoLoader")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.autoLoader.areas.area(?)#node", "Area root node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.autoLoader.areas.area(?).trigger(?)#node", "Trigger node")
	v1:register(XMLValueType.BOOL, "vehicle.autoLoader.areas.area(?).trigger(?)#alwaysActive", "Sets a trigger always active")
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoader.areas.area(?)#length", "Area length")
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoader.areas.area(?)#width", "Area width")
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoader.areas.area(?)#height", "Area height (only used for collision checks)")
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoader.areas.area(?)#spacing", "Area spacing")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).autoLoader.mountedObject(?)#mountPosX", "Mount position x")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).autoLoader.mountedObject(?)#mountPosZ", "Mount position z")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).autoLoader.mountedObject(?)#mountSizeX", "Mount size x")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).autoLoader.mountedObject(?)#mountSizeZ", "Mount size z")
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).autoLoader.mountedObject(?)#mountAreaIndex", "Mount area index")
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).autoLoader.mountedObject(?)#vehicleUniqueId", "Vehicle unique id")
	Bale.registerSavegameXMLPaths(v2, "vehicles.vehicle(?).autoLoader.mountedObject(?).bale")
end
function AutoLoader.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "autoLoaderPickupTriggerCallback", AutoLoader.autoLoaderPickupTriggerCallback)
	SpecializationUtil.registerFunction(p3, "autoLoaderOverlapCallback", AutoLoader.autoLoaderOverlapCallback)
	SpecializationUtil.registerFunction(p3, "getIsValidAutoLoaderObject", AutoLoader.getIsValidAutoLoaderObject)
	SpecializationUtil.registerFunction(p3, "getIsAutoLoadingAllowed", AutoLoader.getIsAutoLoadingAllowed)
	SpecializationUtil.registerFunction(p3, "onUnmountObject", AutoLoader.onUnmountObject)
end
function AutoLoader.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getDynamicMountTimeToMount", AutoLoader.getDynamicMountTimeToMount)
	SpecializationUtil.registerOverwrittenFunction(p4, "addToPhysics", AutoLoader.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p4, "removeFromPhysics", AutoLoader.removeFromPhysics)
end
function AutoLoader.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", AutoLoader)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", AutoLoader)
	SpecializationUtil.registerEventListener(p5, "onDelete", AutoLoader)
	SpecializationUtil.registerEventListener(p5, "onUpdate", AutoLoader)
	SpecializationUtil.registerEventListener(p5, "onRootVehicleChanged", AutoLoader)
end
function AutoLoader.onLoad(p_u_6, _)
	local v_u_7 = p_u_6.spec_autoLoader
	if p_u_6.isServer then
		v_u_7.collsionMask = CollisionFlag.VEHICLE + CollisionFlag.DYNAMIC_OBJECT
		v_u_7.pendingObjects = {}
		v_u_7.mountedObjects = {}
		v_u_7.triggerToAreas = {}
		v_u_7.alwaysActiveTriggers = {}
		v_u_7.skippedObjects = {}
		p_u_6.xmlFile:iterate("vehicle.autoLoader.areas.area", function(_, p8)
			-- upvalues: (copy) p_u_6, (copy) v_u_7
			local v9 = p_u_6.xmlFile:getValue(p8 .. "#node", nil, p_u_6.components, p_u_6.i3dMappings)
			local v10 = p_u_6.xmlFile:getValue(p8 .. "#length", 6)
			local v11 = p_u_6.xmlFile:getValue(p8 .. "#width", 2.5)
			local v12 = p_u_6.xmlFile:getValue(p8 .. "#height", 4)
			local v13 = p_u_6.xmlFile:getValue(p8 .. "#spacing", 0.1)
			if v9 ~= nil then
				if v_u_7.areas == nil then
					v_u_7.areas = {}
				end
				local v_u_14 = {
					["node"] = v9,
					["index"] = #v_u_7.areas + 1,
					["width"] = v11,
					["length"] = v10,
					["height"] = v12,
					["spacing"] = v13,
					["grid"] = PlacementGrid2D.new(v9, v11, v10, v13, PlacementGrid2D.MODE_SIDES)
				}
				p_u_6.xmlFile:iterate(p8 .. ".trigger", function(_, p15)
					-- upvalues: (ref) p_u_6, (ref) v_u_7, (copy) v_u_14
					local v16 = p_u_6.xmlFile:getValue(p15 .. "#node", nil, p_u_6.components, p_u_6.i3dMappings)
					if v_u_7.triggerToAreas[v16] == nil then
						addTrigger(v16, "autoLoaderPickupTriggerCallback", p_u_6)
						v_u_7.triggerToAreas[v16] = {}
					end
					if p_u_6.xmlFile:getValue(p15 .. "#alwaysActive") then
						v_u_7.alwaysActiveTriggers[v16] = true
					end
					local v17 = v_u_7.triggerToAreas[v16]
					local v18 = v_u_14
					table.insert(v17, v18)
				end)
				local v19 = v_u_7.areas
				table.insert(v19, v_u_14)
			end
		end)
	end
	v_u_7.isAutoLoadingActive = false
	v_u_7.warningNoSpace = g_i18n:getText("autoLoader_warningNoSpace")
	v_u_7.warningTooLarge = g_i18n:getText("autoLoader_warningTooLarge")
end
function AutoLoader.onPostLoad(p_u_20, p21)
	if p21 ~= nil then
		local v_u_22 = p_u_20.spec_autoLoader
		if not p21.resetVehicles then
			local v_u_23 = p21.xmlFile
			local v24 = string.format("%s.autoLoader.mountedObject", p21.key)
			v_u_22.pendingVehicles = {}
			v_u_23:iterate(v24, function(_, p25)
				-- upvalues: (copy) v_u_23, (copy) v_u_22, (copy) p_u_20
				local v26 = v_u_23:getValue(p25 .. "#mountPosX")
				local v27 = v_u_23:getValue(p25 .. "#mountPosZ")
				local v28 = v_u_23:getValue(p25 .. "#mountSizeX")
				local v29 = v_u_23:getValue(p25 .. "#mountSizeZ")
				local v30 = v_u_23:getValue(p25 .. "#mountAreaIndex")
				local v31 = v_u_23:getValue(p25 .. "#vehicleUniqueId")
				local v32 = v_u_22.areas[v30]
				if v32 ~= nil then
					if v31 ~= nil then
						local v33 = v_u_22.pendingVehicles
						table.insert(v33, {
							["posX"] = v26,
							["posZ"] = v27,
							["sizeX"] = v28,
							["sizeZ"] = v29,
							["area"] = v32,
							["vehicleUniqueId"] = v31
						})
						return
					end
					if v_u_23:hasProperty(p25 .. ".bale") then
						local v34 = Bale.new(p_u_20.isServer, p_u_20.isClient)
						if v34:loadFromXMLFile(v_u_23, p25 .. ".bale", false) then
							v34:register()
							if v34:autoLoad(p_u_20, v32.node, v26, v27, v28, v29) then
								v_u_22.mountedObjects[v34] = {
									v26,
									v27,
									v28,
									v29,
									v32.index
								}
								v_u_22.pendingObjects[v34] = nil
								v32.grid:blockAreaLocal(v26, v27, v28, v29)
								return
							end
						else
							Logging.xmlWarning(v_u_23, "Could not load autoLoader bale for \'%s\'", p25)
							v34:delete()
						end
					end
				end
			end)
		end
	end
end
function AutoLoader.onDelete(p35)
	local v36 = p35.spec_autoLoader
	if p35.isServer then
		for v37, _ in pairs(v36.pendingObjects) do
			v37:removeDeleteListener(p35, AutoLoader.onDeletePendingObject)
		end
		for v38, _ in pairs(v36.mountedObjects) do
			v38:unmountKinematic()
		end
		if v36.areas ~= nil then
			for _, v39 in ipairs(v36.areas) do
				v39.grid:delete()
			end
		end
		if v36.triggerToAreas ~= nil then
			for v40, _ in pairs(v36.triggerToAreas) do
				removeTrigger(v40)
			end
		end
	end
	v36.skippedObjects = nil
	v36.pendingObjects = nil
	v36.mountedObjects = nil
end
function AutoLoader.saveToXMLFile(p41, p42, p43, _)
	local v44 = p41.spec_autoLoader
	local v45 = 0
	for v46, v47 in pairs(v44.mountedObjects) do
		local v48 = string.format("%s.mountedObject(%d)", p43, v45)
		p42:setValue(v48 .. "#mountPosX", v47[1])
		p42:setValue(v48 .. "#mountPosZ", v47[2])
		p42:setValue(v48 .. "#mountSizeX", v47[3])
		p42:setValue(v48 .. "#mountSizeZ", v47[4])
		p42:setValue(v48 .. "#mountAreaIndex", v47[5])
		if v46:isa(Vehicle) then
			p42:setValue(v48 .. "#vehicleUniqueId", v46:getUniqueId())
		elseif v46:isa(Bale) then
			v46:saveToXMLFile(p42, v48 .. ".bale")
		end
		v45 = v45 + 1
	end
end
function AutoLoader.onUpdate(p49, p50, _, _, _)
	local v51 = p49.spec_autoLoader
	if p49.isServer and v51.areas ~= nil then
		for v52, v53 in pairs(v51.skippedObjects) do
			local v54 = v53 - p50
			v51.skippedObjects[v52] = v54 > 0 and v54 and v54 or nil
		end
		if v51.pendingVehicles ~= nil then
			for _, v55 in ipairs(v51.pendingVehicles) do
				local v56 = v55.vehicleUniqueId
				local v57 = g_currentMission.vehicleSystem:getVehicleByUniqueId(v56)
				if v57 ~= nil then
					local v58 = v55.area
					local v59 = v55.posX
					local v60 = v55.posZ
					local v61 = v55.sizeX
					local v62 = v55.sizeZ
					if v57:autoLoad(p49, v58.node, v59, v60, v61, v62) then
						v51.mountedObjects[v57] = {
							v59,
							v60,
							v61,
							v62,
							v58.index
						}
						v51.pendingObjects[v57] = nil
						v57:removeDeleteListener(p49, AutoLoader.onDeletePendingObject)
						v58.grid:blockAreaLocal(v59, v60, v61, v62)
					end
				end
			end
			v51.pendingVehicles = nil
		end
		if v51.needGridUpdate then
			v51.needGridUpdate = false
			for _, v63 in ipairs(v51.areas) do
				v63.grid:reset()
				for v64, _ in pairs(v51.mountedObjects) do
					local v65, v66, v67, v68, v69, v70, v71, v72, v73, v74, v75, v76 = v64:getAutoLoadBoundingBox()
					v63.grid:blockAreaByBoundingBox(v65, v66, v67, v68, v69, v70, v71, v72, v73, v74, v75, v76)
				end
			end
		end
		local v77 = false
		local v78 = false
		for v79, v80 in pairs(v51.pendingObjects) do
			if v79.isDeleted then
				v51.pendingObjects[v79] = true
			else
				if (v51.isAutoLoadingActive or v51.alwaysActiveTriggers[v80] == true) and v79:getAutoLoadIsAllowed() then
					local v81, v82, v83 = v79:getAutoLoadSize()
					local v84 = v51.triggerToAreas[v80]
					for _, v85 in ipairs(v84) do
						if v81 <= v85.width and (v82 <= v85.height and v83 <= v85.length) then
							local v86 = false
							for _ = 1, 3 do
								local v87, v88 = v85.grid:getFreePosition(v81, v83)
								if v87 == nil then
									v77 = true
								else
									local v89, v90, v91 = localToWorld(v85.node, v87 + v81 * 0.5, v82 * 0.5, v88 + v83 * 0.5)
									local v92, v93, v94 = getWorldRotation(v85.node)
									v51.isAreaBlocked = false
									v51.currentPendingObject = v79
									overlapBox(v89, v90, v91, v92, v93, v94, v81 * 0.5, v82 * 0.5, v83 * 0.5, "autoLoaderOverlapCallback", p49, v51.collsionMask, true, true, false, true)
									v51.currentPendingObject = nil
									if v51.isAreaBlocked then
										v85.grid:blockAreaLocal(v87, v88, v81, v83)
									elseif v79:autoLoad(p49, v85.node, v87, v88, v81, v83) then
										v51.mountedObjects[v79] = {
											v87,
											v88,
											v81,
											v83,
											v85.index
										}
										v51.pendingObjects[v79] = nil
										v79:removeDeleteListener(p49, AutoLoader.onDeletePendingObject)
										v85.grid:blockAreaLocal(v87, v88, v81, v83)
										v86 = true
										v77 = false
										v78 = false
										break
									end
								end
							end
							if v86 then
								break
							end
						else
							v78 = true
						end
					end
				end
				if v77 and v51.warningNoSpace ~= nil then
					g_currentMission:showBlinkingWarning(v51.warningNoSpace, 2000)
				elseif v78 and v51.warningTooLarge ~= nil then
					g_currentMission:showBlinkingWarning(v51.warningTooLarge, 2000)
				end
			end
		end
		if Platform.gameplay.automaticVehicleControl and v51.isAutoLoadingActive then
			p49.rootVehicle:playControlledActions()
		end
	end
end
function AutoLoader.onDraw(p95)
	local v96 = p95.spec_autoLoader
	if v96.areas ~= nil then
		for _, v97 in ipairs(v96.areas) do
			v97.grid:drawDebug()
		end
	end
end
function AutoLoader.addToPhysics(p98, p99)
	if not p99(p98) then
		return false
	end
	if p98.isServer then
		local v100 = p98.spec_autoLoader
		for v101, _ in pairs(v100.mountedObjects) do
			if v101.addToPhysics ~= nil then
				v101:addToPhysics()
			end
		end
	end
	return true
end
function AutoLoader.removeFromPhysics(p102, p103)
	local v104 = p103(p102)
	if p102.isServer then
		local v105 = p102.spec_autoLoader
		for v106, _ in pairs(v105.mountedObjects) do
			if v106.removeFromPhysics ~= nil then
				v106:removeFromPhysics()
			end
		end
	end
	return v104
end
function AutoLoader.onUnmountObject(p107, p108)
	local v109 = p107.spec_autoLoader
	v109.skippedObjects[p108] = 3000
	v109.mountedObjects[p108] = nil
	v109.needGridUpdate = true
	p107:raiseActive()
end
function AutoLoader.getIsValidAutoLoaderObject(p110, p111)
	if p111 == nil then
		return false
	elseif p111 == p110 then
		return false
	elseif p110.spec_autoLoader.mountedObjects[p111] == nil then
		if p111:isa(Vehicle) or p111:isa(Bale) then
			if p111.getAutoLoadIsSupported == nil or not p111:getAutoLoadIsSupported() then
				return false
			else
				return g_currentMission.accessHandler:canFarmAccess(p110:getActiveFarm(), p111) and true or false
			end
		else
			return false
		end
	else
		return false
	end
end
function AutoLoader.autoLoaderPickupTriggerCallback(p112, p113, p114, p115, p116, _, _)
	local v117 = p112.spec_autoLoader
	if p115 then
		local v118 = g_currentMission:getNodeObject(p114)
		if p114 ~= 0 and (p112:getIsAutoLoadingAllowed() and (v118 == nil or v117.mountedObjects[v118] == nil)) then
			local v119
			if v117.skippedObjects[v118] == nil then
				v119 = false
			else
				v119 = v117.alwaysActiveTriggers[p113] == true
			end
			if p112:getIsValidAutoLoaderObject(v118) and (v117.pendingObjects[v118] ~= p113 and not v119) then
				v117.pendingObjects[v118] = p113
				v118:addDeleteListener(p112, AutoLoader.onDeletePendingObject)
				v117.needGridUpdate = true
				p112:raiseActive()
				return
			end
		end
	elseif p116 then
		local v120 = g_currentMission:getNodeObject(p114)
		if v120 ~= nil and v117.pendingObjects[v120] ~= nil then
			v117.pendingObjects[v120] = nil
			v120:removeDeleteListener(p112, AutoLoader.onDeletePendingObject)
		end
	end
end
function AutoLoader.autoLoaderOverlapCallback(p121, p122)
	if p122 ~= 0 and (getHasClassId(p122, ClassIds.SHAPE) and not getHasTrigger(p122)) then
		local v123 = g_currentMission:getNodeObject(p122)
		local v124 = p121.spec_autoLoader
		if v123 ~= p121 and (v124.mountedObjects[v123] == nil and v124.currentPendingObject ~= v123) then
			v124.isAreaBlocked = true
			return false
		end
	end
	return true
end
function AutoLoader.getIsAutoLoadingAllowed(p125)
	local _, v126, _ = getWorldTranslation(p125.components[1].node)
	local _, v127, _ = localToWorld(p125.components[1].node, 0, 1, 0)
	return v127 - v126 >= 0.5
end
function AutoLoader.getDynamicMountTimeToMount(p128, _)
	return p128:getIsAutoLoadingAllowed() and -1 or (1 / 0)
end
function AutoLoader.onRootVehicleChanged(p_u_129, p130)
	local v131 = p_u_129.spec_autoLoader
	local v132 = p130.actionController
	if v132 == nil then
		if v131.controlledAction ~= nil then
			v131.controlledAction:remove()
			v131.controlledAction = nil
		end
		return
	elseif v131.controlledAction == nil then
		v131.controlledAction = v132:registerAction("autoLoaderLoad", nil, 4)
		v131.controlledAction:setCallback(p_u_129, AutoLoader.actionControllerEvent)
		v131.controlledAction:setIsAvailableFunction(function()
			-- upvalues: (copy) p_u_129
			return next(p_u_129.spec_autoLoader.pendingObjects) ~= nil
		end)
		v131.controlledAction:setActionIcons("AUTO_LOAD", "AUTO_LOAD", false)
	else
		v131.controlledAction:updateParent(v132)
	end
end
function AutoLoader.actionControllerEvent(p133, p134)
	local v135 = p133.spec_autoLoader
	if p134 < 0 then
		v135.isAutoLoadingActive = false
	else
		v135.isAutoLoadingActive = true
	end
	return true
end
function AutoLoader.onDeletePendingObject(p136, p137)
	p136.spec_autoLoader.pendingObjects[p137] = nil
end

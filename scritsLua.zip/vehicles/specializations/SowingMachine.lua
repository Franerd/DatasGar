source("dataS/scripts/vehicles/specializations/events/SetSeedIndexEvent.lua")
SowingMachine = {}
SowingMachine.DAMAGED_USAGE_INCREASE = 0.3
SowingMachine.AI_REQUIRED_GROUND_TYPES = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.CULTIVATED,
	FieldGroundType.SEEDBED,
	FieldGroundType.PLOWED,
	FieldGroundType.ROLLED_SEEDBED,
	FieldGroundType.RIDGE
}
SowingMachine.AI_OUTPUT_GROUND_TYPES = {
	FieldGroundType.SOWN,
	FieldGroundType.DIRECT_SOWN,
	FieldGroundType.PLANTED,
	FieldGroundType.RIDGE_SOWN,
	FieldGroundType.ROLLER_LINES,
	FieldGroundType.HARVEST_READY,
	FieldGroundType.HARVEST_READY_OTHER,
	FieldGroundType.GRASS,
	FieldGroundType.GRASS_CUT
}
function SowingMachine.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("sowingMachine", true, true, true)
	g_storeManager:addSpecType("seedFillTypes", "shopListAttributeIconSeeds", SowingMachine.loadSpecValueSeedFillTypes, SowingMachine.getSpecValueSeedFillTypes, StoreSpecies.VEHICLE)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("SowingMachine")
	v1:register(XMLValueType.BOOL, "vehicle.sowingMachine.allowFillFromAirWhileTurnedOn#value", "Allow fill from air while turned on")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.sowingMachine.directionNode#node", "Direction node")
	v1:register(XMLValueType.BOOL, "vehicle.sowingMachine.useDirectPlanting#value", "Use direct planting", false)
	v1:register(XMLValueType.BOOL, "vehicle.sowingMachine.waterSeeding#value", "Seeding in water is required or prohibited (false: prohibited, true: required)", false)
	v1:register(XMLValueType.STRING, "vehicle.sowingMachine.seedFruitTypeCategories", "Seed fruit type categories")
	v1:register(XMLValueType.STRING, "vehicle.sowingMachine.seedFruitTypes", "Seed fruit types")
	v1:register(XMLValueType.STRING, "vehicle.sowingMachine.seedFillType", "Name of seeds fill type to use", "SEEDS")
	v1:register(XMLValueType.BOOL, "vehicle.sowingMachine.needsActivation#value", "Needs activation", false)
	v1:register(XMLValueType.BOOL, "vehicle.sowingMachine.requiresFilling#value", "Requires filling", true)
	v1:register(XMLValueType.STRING, "vehicle.sowingMachine.fieldGroundType#value", "Defines the field ground type", "SOWN")
	v1:register(XMLValueType.BOOL, "vehicle.sowingMachine.fieldGroundType#ridgeSeeding", "Defines if the sowing machine can seed into created ridges or destroys them", false)
	SoundManager.registerSampleXMLPaths(v1, "vehicle.sowingMachine.sounds", "work(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.sowingMachine.sounds", "airBlower(?)")
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.sowingMachine.animationNodes")
	v1:register(XMLValueType.STRING, "vehicle.sowingMachine.changeSeedInputButton", "Input action name", "IMPLEMENT_EXTRA3")
	v1:register(XMLValueType.INT, "vehicle.sowingMachine#fillUnitIndex", "Fill unit index", 1)
	v1:register(XMLValueType.INT, "vehicle.sowingMachine#unloadInfoIndex", "Unload info index", 1)
	v1:register(XMLValueType.STRING, "vehicle.sowingMachine#consumableName", "Define a consumable that is emptied instead of the fill unit")
	v1:register(XMLValueType.FLOAT, "vehicle.sowingMachine#seedUsageScale", "Seed usage scale (Can be used to increase or decrease the usage for certain tools)", 1)
	EffectManager.registerEffectXMLPaths(v1, "vehicle.sowingMachine.effects")
	v1:register(XMLValueType.STRING, "vehicle.storeData.specs.seedFruitTypeCategories", "Seed fruit type categories")
	v1:register(XMLValueType.STRING, "vehicle.storeData.specs.seedFruitTypes", "Seed fruit types")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).sowingMachine#selectedSeedFruitType", "Selected fruit type name")
	v2:register(XMLValueType.BOOL, "vehicles.vehicle(?).sowingMachine#allowsSeedChanging", "If seed change is allowed")
end
function SowingMachine.prerequisitesPresent(p3)
	local v4 = SpecializationUtil.hasSpecialization(FillUnit, p3) and SpecializationUtil.hasSpecialization(WorkArea, p3)
	if v4 then
		v4 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p3)
	end
	return v4
end
function SowingMachine.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "setSeedFruitType", SowingMachine.setSeedFruitType)
	SpecializationUtil.registerFunction(p5, "setSeedIndex", SowingMachine.setSeedIndex)
	SpecializationUtil.registerFunction(p5, "changeSeedIndex", SowingMachine.changeSeedIndex)
	SpecializationUtil.registerFunction(p5, "getIsSeedChangeAllowed", SowingMachine.getIsSeedChangeAllowed)
	SpecializationUtil.registerFunction(p5, "setIsSeedChangeAllowed", SowingMachine.setIsSeedChangeAllowed)
	SpecializationUtil.registerFunction(p5, "getSowingMachineFillUnitIndex", SowingMachine.getSowingMachineFillUnitIndex)
	SpecializationUtil.registerFunction(p5, "getSowingMachineSeedFillTypeIndex", SowingMachine.getSowingMachineSeedFillTypeIndex)
	SpecializationUtil.registerFunction(p5, "getCurrentSeedTypeIcon", SowingMachine.getCurrentSeedTypeIcon)
	SpecializationUtil.registerFunction(p5, "processSowingMachineArea", SowingMachine.processSowingMachineArea)
	SpecializationUtil.registerFunction(p5, "getUseSowingMachineAIRequirements", SowingMachine.getUseSowingMachineAIRequirements)
	SpecializationUtil.registerFunction(p5, "setFillTypeSourceDisplayFillType", SowingMachine.setFillTypeSourceDisplayFillType)
	SpecializationUtil.registerFunction(p5, "updateMissionSowingWarning", SowingMachine.updateMissionSowingWarning)
	SpecializationUtil.registerFunction(p5, "getCanPlantOutsideSeason", SowingMachine.getCanPlantOutsideSeason)
	SpecializationUtil.registerFunction(p5, "getSowingMachineCanConsume", SowingMachine.getSowingMachineCanConsume)
end
function SowingMachine.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDrawFirstFillText", SowingMachine.getDrawFirstFillText)
	SpecializationUtil.registerOverwrittenFunction(p6, "getAreControlledActionsAllowed", SowingMachine.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitAllowsFillType", SowingMachine.getFillUnitAllowsFillType)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanBeTurnedOn", SowingMachine.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanToggleTurnedOn", SowingMachine.getCanToggleTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p6, "getAllowFillFromAir", SowingMachine.getAllowFillFromAir)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDirectionSnapAngle", SowingMachine.getDirectionSnapAngle)
	SpecializationUtil.registerOverwrittenFunction(p6, "addFillUnitFillLevel", SowingMachine.addFillUnitFillLevel)
	SpecializationUtil.registerOverwrittenFunction(p6, "doCheckSpeedLimit", SowingMachine.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDirtMultiplier", SowingMachine.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getWearMultiplier", SowingMachine.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "loadWorkAreaFromXML", SowingMachine.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanBeSelected", SowingMachine.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanAIImplementContinueWork", SowingMachine.getCanAIImplementContinueWork)
end
function SowingMachine.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onPostLoad", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onDelete", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onReadStream", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onWriteStream", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onUpdate", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onUpdateTick", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onRegisterActionEvents", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onTurnedOn", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onTurnedOff", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onStartWorkAreaProcessing", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onEndWorkAreaProcessing", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onDeactivate", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onStateChange", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onChangedFillType", SowingMachine)
	SpecializationUtil.registerEventListener(p7, "onAIFieldCourseSettingsInitialized", SowingMachine)
end
function SowingMachine.onLoad(p8, p9)
	local v10 = p8.spec_sowingMachine
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.sowingMachine.animationNodes.animationNode", "sowingMachine")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.turnedOnScrollers", "vehicle.sowingMachine.scrollerNodes.scrollerNode")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.useDirectPlanting", "vehicle.sowingMachine.useDirectPlanting#value")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.needsActivation#value", "vehicle.sowingMachine.needsActivation#value")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.sowingEffects", "vehicle.sowingMachine.effects")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.sowingEffectsWithFixedFillType", "vehicle.sowingMachine.fixedEffects")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.sowingMachine#supportsAiWithoutSowingMachine", "vehicle.turnOnVehicle.aiRequiresTurnOn")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.sowingMachine.directionNode#index", "vehicle.sowingMachine.directionNode#node")
	v10.allowFillFromAirWhileTurnedOn = p8.xmlFile:getValue("vehicle.sowingMachine.allowFillFromAirWhileTurnedOn#value", true)
	v10.directionNode = p8.xmlFile:getValue("vehicle.sowingMachine.directionNode#node", p8.components[1].node, p8.components, p8.i3dMappings)
	v10.useDirectPlanting = p8.xmlFile:getValue("vehicle.sowingMachine.useDirectPlanting#value", false)
	v10.waterSeeding = p8.xmlFile:getValue("vehicle.sowingMachine.waterSeeding#value", false)
	v10.isWorking = false
	v10.isProcessing = false
	v10.stoneLastState = 0
	v10.stoneWearMultiplierData = g_currentMission.stoneSystem:getWearMultiplierByType("SOWINGMACHINE")
	v10.seeds = {}
	local v11 = {}
	local v12 = p8.xmlFile:getValue("vehicle.sowingMachine.seedFruitTypeCategories")
	local v13 = p8.xmlFile:getValue("vehicle.sowingMachine.seedFruitTypes")
	if v12 == nil or v13 ~= nil then
		if v12 == nil and v13 ~= nil then
			v11 = g_fruitTypeManager:getFruitTypeIndicesByNames(v13, "Warning: \'" .. p8.configFileName .. "\' has invalid fruitType \'%s\'.")
		else
			printWarning("Warning: \'" .. p8.configFileName .. "\' a sowingMachine needs either the \'seedFruitTypeCategories\' or \'seedFruitTypes\' element.")
		end
	else
		v11 = g_fruitTypeManager:getFruitTypeIndicesByCategoryNames(v12, "Warning: \'" .. p8.configFileName .. "\' has invalid fruitTypeCategory \'%s\'.")
	end
	if v11 ~= nil then
		for _, v14 in pairs(v11) do
			local v15 = v10.seeds
			table.insert(v15, v14)
		end
	end
	local v16 = p8.xmlFile:getValue("vehicle.sowingMachine.seedFillType", "SEEDS")
	v10.seedFillType = FillType[v16] or FillType.SEEDS
	v10.needsActivation = p8.xmlFile:getValue("vehicle.sowingMachine.needsActivation#value", false)
	v10.requiresFilling = p8.xmlFile:getValue("vehicle.sowingMachine.requiresFilling#value", true)
	v10.fieldGroundType = FieldGroundType.getValueByName(p8.xmlFile:getValue("vehicle.sowingMachine.fieldGroundType#value", "SOWN"))
	v10.ridgeSeeding = p8.xmlFile:getValue("vehicle.sowingMachine.fieldGroundType#ridgeSeeding", false)
	if p8.isClient then
		v10.isWorkSamplePlaying = false
		v10.samples = {}
		v10.samples.work = g_soundManager:loadSamplesFromXML(p8.xmlFile, "vehicle.sowingMachine.sounds", "work", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v10.samples.airBlower = g_soundManager:loadSamplesFromXML(p8.xmlFile, "vehicle.sowingMachine.sounds", "airBlower", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v10.sampleFillEnabled = false
		v10.sampleFillStopTime = -1
		v10.lastFillLevel = -1
		v10.animationNodes = g_animationManager:loadAnimations(p8.xmlFile, "vehicle.sowingMachine.animationNodes", p8.components, p8, p8.i3dMappings)
		g_animationManager:setFillType(v10.animationNodes, FillType.UNKNOWN)
		local v17 = p8.xmlFile:getValue("vehicle.sowingMachine.changeSeedInputButton")
		if v17 ~= nil then
			v10.changeSeedInputButton = InputAction[v17]
		end
		v10.changeSeedInputButton = Utils.getNoNil(v10.changeSeedInputButton, InputAction.TOGGLE_SEEDS)
	end
	v10.currentSeed = 1
	v10.allowsSeedChanging = true
	v10.showFruitCanNotBePlantedWarning = false
	v10.showWrongFruitForMissionWarning = false
	v10.showWaterPlantingRequiredWarning = false
	v10.showWaterPlantingProhibitedWarning = false
	v10.showFieldTypeWarningRegularRequired = false
	v10.showFieldTypeWarningRiceRequired = false
	v10.warnings = {}
	v10.warnings.fruitCanNotBePlanted = g_i18n:getText("warning_theSelectedFruitTypeIsNotAvailableOnThisMap")
	v10.warnings.wrongFruitForMission = g_i18n:getText("warning_theSelectedFruitTypeIsWrongForTheMission")
	v10.warnings.wrongPlantingTime = g_i18n:getText("warning_theSelectedFruitTypeCantBePlantedInThisPeriod")
	v10.fillUnitIndex = p8.xmlFile:getValue("vehicle.sowingMachine#fillUnitIndex", 1)
	v10.unloadInfoIndex = p8.xmlFile:getValue("vehicle.sowingMachine#unloadInfoIndex", 1)
	v10.consumableName = p8.xmlFile:getValue("vehicle.sowingMachine#consumableName")
	if v10.consumableName ~= nil and p8.updateConsumable == nil then
		Logging.xmlWarning("Sowing machine has consumableName \'%s\' attribute defined but has no consumable specialization!", v10.consumableName)
		v10.consumableName = nil
	end
	v10.seedUsageScale = p8.xmlFile:getValue("vehicle.sowingMachine#seedUsageScale", 1)
	if p8:getFillUnitByIndex(v10.fillUnitIndex) == nil then
		Logging.xmlError(p8.xmlFile, "FillUnit \'%d\' not defined!", v10.fillUnitIndex)
		p8:setLoadingState(VehicleLoadingState.ERROR)
	else
		v10.fillTypeSources = {}
		if p8.isClient then
			v10.effects = g_effectManager:loadEffect(p8.xmlFile, "vehicle.sowingMachine.effects", p8.components, p8, p8.i3dMappings)
		end
		v10.workAreaParameters = {}
		v10.workAreaParameters.seedsFruitType = nil
		v10.workAreaParameters.angle = 0
		v10.workAreaParameters.lastChangedArea = 0
		v10.workAreaParameters.lastStatsArea = 0
		v10.workAreaParameters.lastArea = 0
		p8:setSeedIndex(1, true)
		if p9 ~= nil then
			local v18 = p9.xmlFile:getValue(p9.key .. ".sowingMachine#selectedSeedFruitType")
			if v18 ~= nil then
				local v19 = g_fruitTypeManager:getFruitTypeByName(v18)
				if v19 ~= nil then
					p8:setSeedFruitType(v19.index, true)
				end
			end
			v10.allowsSeedChanging = p9.xmlFile:getValue(p9.key .. ".sowingMachine#allowsSeedChanging", v10.allowsSeedChanging)
		end
		if not p8.isClient then
			SpecializationUtil.removeEventListener(p8, "onUpdate", SowingMachine)
			SpecializationUtil.removeEventListener(p8, "onUpdateTick", SowingMachine)
		end
		p8.needWaterInfo = true
	end
end
function SowingMachine.onPostLoad(p20, _)
	SowingMachine.updateAiParameters(p20)
end
function SowingMachine.onDelete(p21)
	if p21.isClient then
		local v22 = p21.spec_sowingMachine
		if v22.samples ~= nil then
			g_soundManager:deleteSamples(v22.samples.work)
			g_soundManager:deleteSamples(v22.samples.airBlower)
		end
		g_effectManager:deleteEffects(v22.effects)
		g_animationManager:deleteAnimations(v22.animationNodes)
	end
end
function SowingMachine.saveToXMLFile(p23, p24, p25, _)
	local v26 = p23.spec_sowingMachine
	local v27 = v26.seeds[v26.currentSeed]
	local v28 = (v27 == nil or v27 == FruitType.UNKNOWN) and "unknown" or g_fruitTypeManager:getFruitTypeByIndex(v27).name
	p24:setValue(p25 .. "#selectedSeedFruitType", v28)
	if v26.allowsSeedChanging ~= nil then
		p24:setValue(p25 .. "#allowsSeedChanging", v26.allowsSeedChanging)
	end
end
function SowingMachine.onReadStream(p29, p30, _)
	p29:setSeedIndex(streamReadUInt8(p30), true)
end
function SowingMachine.onWriteStream(p31, p32, _)
	local v33 = p31.spec_sowingMachine
	streamWriteUInt8(p32, v33.currentSeed)
end
function SowingMachine.onUpdate(p34, _, _, _, _)
	local v35 = p34.spec_sowingMachine
	if v35.isProcessing then
		local v36 = p34:getFillUnitForcedMaterialFillType(v35.fillUnitIndex)
		if v36 ~= nil then
			g_effectManager:setEffectTypeInfo(v35.effects, v36)
			g_effectManager:startEffects(v35.effects)
			return
		end
	else
		g_effectManager:stopEffects(v35.effects)
	end
end
function SowingMachine.onUpdateTick(p37, _, _, _, _)
	local v38 = p37.spec_sowingMachine
	local v39 = v38.actionEvents[v38.changeSeedInputButton]
	if v39 ~= nil then
		g_inputBinding:setActionEventActive(v39.actionEventId, p37:getIsSeedChangeAllowed())
	end
	if p37.isActiveForInputIgnoreSelectionIgnoreAI then
		if v38.showFruitCanNotBePlantedWarning then
			g_currentMission:showBlinkingWarning(v38.warnings.fruitCanNotBePlanted, 5000)
			return
		end
		if v38.showWrongFruitForMissionWarning then
			g_currentMission:showBlinkingWarning(v38.warnings.wrongFruitForMission, 5000)
			return
		end
		if v38.showWrongPlantingTimeWarning then
			g_currentMission:showBlinkingWarning(string.format(v38.warnings.wrongPlantingTime, g_i18n:formatPeriod()), 5000)
			return
		end
		if v38.showWaterPlantingRequiredWarning then
			g_currentMission:showBlinkingWarning(g_i18n:getText("warning_seedingInWaterRequired"), 5000)
			return
		end
		if v38.showWaterPlantingProhibitedWarning then
			g_currentMission:showBlinkingWarning(g_i18n:getText("warning_seedingInWaterProhibited"), 5000)
			return
		end
		if v38.showFieldTypeWarningRegularRequired then
			g_currentMission:showBlinkingWarning(g_i18n:getText("warning_seedingOnRegularFieldRequired"), 5000)
			return
		end
		if v38.showFieldTypeWarningRiceRequired then
			g_currentMission:showBlinkingWarning(g_i18n:getText("warning_seedingOnRiceFieldRequired"), 5000)
		end
	end
end
function SowingMachine.setSeedIndex(p40, p41, p42)
	local v43 = p40.spec_sowingMachine
	SetSeedIndexEvent.sendEvent(p40, p41, p42)
	local v44 = math.max(p41, 1)
	local v45 = #v43.seeds
	v43.currentSeed = math.min(v44, v45)
	local v46 = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v43.seeds[v43.currentSeed])
	if v46 ~= nil then
		p40:setFillUnitFillTypeToDisplay(v43.fillUnitIndex, v46, true)
		p40:setFillTypeSourceDisplayFillType(v46)
	end
	SowingMachine.updateAiParameters(p40)
	SowingMachine.updateChooseSeedActionEvent(p40)
end
function SowingMachine.changeSeedIndex(p47, p48)
	local v49 = p47.spec_sowingMachine
	local v50 = v49.currentSeed + p48
	p47:setSeedIndex(#v49.seeds < v50 and 1 or (v50 < 1 and #v49.seeds or v50))
end
function SowingMachine.setSeedFruitType(p51, p52, p53)
	local v54 = p51.spec_sowingMachine
	for v55, v56 in ipairs(v54.seeds) do
		if v56 == p52 then
			p51:setSeedIndex(v55, p53)
			return
		end
	end
end
function SowingMachine.setIsSeedChangeAllowed(p57, p58)
	p57.spec_sowingMachine.allowsSeedChanging = p58
end
function SowingMachine.getIsSeedChangeAllowed(p59)
	return p59.spec_sowingMachine.allowsSeedChanging
end
function SowingMachine.getSowingMachineFillUnitIndex(p60)
	return p60.spec_sowingMachine.fillUnitIndex
end
function SowingMachine.getSowingMachineSeedFillTypeIndex(p61)
	local v62 = p61.spec_sowingMachine
	return g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v62.seeds[v62.currentSeed])
end
function SowingMachine.getCurrentSeedTypeIcon(p63)
	local v64 = p63.spec_sowingMachine
	local v65 = g_fruitTypeManager:getFillTypeByFruitTypeIndex(v64.seeds[v64.currentSeed])
	if v65 == nil then
		return nil
	else
		return v65.hudOverlayFilename
	end
end
function SowingMachine.processSowingMachineArea(p66, p67, _)
	local v68 = p66.spec_sowingMachine
	local v69 = 0
	local v70 = 0
	v68.isWorking = p66:getLastSpeed() > 0.5
	if v68.waterSeeding and not p66.isInWater then
		v68.showWaterPlantingRequiredWarning = true
		if p66:getIsAIActive() then
			p66.rootVehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
		end
		return v69, v70
	end
	if not v68.waterSeeding and p66.isInWater then
		v68.showWaterPlantingProhibitedWarning = true
		if p66:getIsAIActive() then
			p66.rootVehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
		end
		return v69, v70
	end
	if not v68.workAreaParameters.isActive then
		return v69, v70
	end
	if not (p66:getIsAIActive() and g_currentMission.missionInfo.helperBuySeeds) and v68.workAreaParameters.seedsVehicle == nil then
		if p66:getIsAIActive() then
			p66.rootVehicle:stopCurrentAIJob(AIMessageErrorOutOfFill.new())
		end
		return v69, v70
	end
	if not v68.workAreaParameters.canFruitBePlanted then
		return v69, v70
	end
	local v71, _, v72 = getWorldTranslation(p67.start)
	local v73, _, v74 = getWorldTranslation(p67.width)
	local v75, _, v76 = getWorldTranslation(p67.height)
	local v77 = g_fruitTypeManager:getFruitTypeByIndex(v68.workAreaParameters.seedsFruitType)
	if v77.seedRequiredFieldType ~= nil then
		local v78 = (v71 + v73 + v75) / 3
		local v79 = (v72 + v74 + v76) / 3
		if FSDensityMapUtil.getFieldTypeAtWorldPos(v78, v79) ~= v77.seedRequiredFieldType then
			if v77.seedRequiredFieldType == FieldType.RICE then
				v68.showFieldTypeWarningRiceRequired = true
				if p66:getIsAIActive() then
					p66.rootVehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
				end
			else
				v68.showFieldTypeWarningRegularRequired = true
			end
		end
	end
	v68.isProcessing = v68.isWorking
	local v80
	if v68.useDirectPlanting then
		local v81, _ = FSDensityMapUtil.updateDirectSowingArea(v68.workAreaParameters.seedsFruitType, v71, v72, v73, v74, v75, v76, v68.workAreaParameters.fieldGroundType, v68.workAreaParameters.ridgeSeeding, v68.workAreaParameters.angle, nil)
		v80 = v69 + v81
	else
		local v82, _ = FSDensityMapUtil.updateSowingArea(v68.workAreaParameters.seedsFruitType, v71, v72, v73, v74, v75, v76, v68.workAreaParameters.fieldGroundType, v68.workAreaParameters.ridgeSeeding, v68.workAreaParameters.angle, nil)
		v80 = v69 + v82
	end
	if v68.isWorking then
		v68.stoneLastState = FSDensityMapUtil.getStoneArea(v71, v72, v73, v74, v75, v76)
	else
		v68.stoneLastState = 0
	end
	v68.workAreaParameters.lastChangedArea = v68.workAreaParameters.lastChangedArea + v80
	v68.workAreaParameters.lastStatsArea = v68.workAreaParameters.lastStatsArea + v80
	v68.workAreaParameters.lastTotalArea = v68.workAreaParameters.lastTotalArea + 0
	FSDensityMapUtil.eraseTireTrack(v71, v72, v73, v74, v75, v76)
	p66:updateMissionSowingWarning(v71, v72)
	return v80, v70
end
function SowingMachine.updateMissionSowingWarning(p83, p84, p85)
	local v86 = p83.spec_sowingMachine
	v86.showWrongFruitForMissionWarning = false
	if p83:getLastTouchedFarmlandFarmId() == 0 then
		local v87 = g_missionManager:getMissionAtWorldPosition(p84, p85)
		if v87 ~= nil and (v87.type.name == "sow" and v87.fruitType ~= v86.workAreaParameters.seedsFruitType) then
			v86.showWrongFruitForMissionWarning = true
		end
	end
end
function SowingMachine.getUseSowingMachineAIRequirements(p88)
	return p88:getAIRequiresTurnOn() or p88:getIsTurnedOn()
end
function SowingMachine.setFillTypeSourceDisplayFillType(p89, p90)
	local v91 = p89.spec_sowingMachine
	if v91.fillTypeSources[v91.seedFillType] ~= nil then
		for _, v92 in ipairs(v91.fillTypeSources[v91.seedFillType]) do
			local v93 = v92.vehicle
			local v94 = v93:getFillUnitFillLevel(v92.fillUnitIndex)
			if v94 > 0 and v93:getFillUnitFillType(v92.fillUnitIndex) == v91.seedFillType then
				v93:setFillUnitFillTypeToDisplay(v92.fillUnitIndex, p90)
				return
			end
			if v94 == 0 then
				local v95 = v93:getFillUnitSupportedFillTypes(v92.fillUnitIndex)
				local v96 = 0
				for _, v97 in pairs(v95) do
					if v97 then
						v96 = v96 + 1
					end
				end
				if v96 == 1 and v95[v91.seedFillType] == true then
					v93:setFillUnitFillTypeToDisplay(v92.fillUnitIndex, p90)
					return
				end
			end
		end
	end
end
function SowingMachine.getDrawFirstFillText(p98, p99)
	local v100 = p98.spec_sowingMachine
	if p98.isClient and (p98:getIsActiveForInput() and p98:getIsSelected()) then
		if v100.consumableName == nil then
			if p98:getFillUnitFillLevel(v100.fillUnitIndex) <= 0 and p98:getFillUnitCapacity(v100.fillUnitIndex) ~= 0 then
				return true
			end
		elseif not p98:getConsumableIsAvailable(v100.consumableName) then
			return true
		end
	end
	return p99(p98)
end
function SowingMachine.getAreControlledActionsAllowed(p101, p102)
	local v103 = p101.spec_sowingMachine
	if v103.requiresFilling then
		if v103.consumableName == nil then
			if p101:getFillUnitFillLevel(v103.fillUnitIndex) <= 0 and p101:getFillUnitCapacity(v103.fillUnitIndex) ~= 0 then
				return false, g_i18n:getText("info_firstFillTheTool")
			end
		elseif not p101:getConsumableIsAvailable(v103.consumableName) then
			return false, g_i18n:getText("info_firstFillTheTool")
		end
	end
	return p102(p101)
end
function SowingMachine.getFillUnitAllowsFillType(p104, p105, p106, p107)
	if p105(p104, p106, p107) then
		return true
	end
	local v108 = p104.spec_fillUnit
	if v108.fillUnits[p106] ~= nil and p104:getFillUnitSupportsFillType(p106, p107) then
		local v109 = p104.spec_sowingMachine
		if p107 == v109.seedFillType or v108.fillUnits[p106].fillType == v109.seedFillType then
			return true
		end
	end
	return false
end
function SowingMachine.getCanBeTurnedOn(p110, p111)
	if p110.spec_sowingMachine.needsActivation then
		return p111(p110)
	else
		return false
	end
end
function SowingMachine.getCanToggleTurnedOn(p112, p113)
	if p112.spec_sowingMachine.needsActivation then
		return p113(p112)
	else
		return false
	end
end
function SowingMachine.getCanPlantOutsideSeason(_)
	return false
end
function SowingMachine.getSowingMachineCanConsume(p114)
	local v115 = p114.spec_sowingMachine
	if v115.consumableName ~= nil then
		return p114:getConsumableIsAvailable(v115.consumableName)
	end
	if p114:getFillUnitFillLevel(v115.fillUnitIndex) > 0 or p114:getFillUnitCapacity(v115.fillUnitIndex) == 0 then
		return true
	end
end
function SowingMachine.getAllowFillFromAir(p116, p117)
	local v118 = p116.spec_sowingMachine
	if p116:getIsTurnedOn() and not v118.allowFillFromAirWhileTurnedOn then
		return false
	else
		return p117(p116)
	end
end
function SowingMachine.getDirectionSnapAngle(p119, p120)
	local v121 = p119.spec_sowingMachine
	local v122 = v121.seeds[v121.currentSeed]
	local v123 = g_fruitTypeManager:getFruitTypeByIndex(v122)
	local v124 = v123 == nil and 0 or v123.directionSnapAngle
	return math.max(v124, p120(p119))
end
function SowingMachine.addFillUnitFillLevel(p125, p126, p127, p128, p129, p130, p131, p132)
	local v133 = p125.spec_sowingMachine
	if p128 == v133.fillUnitIndex then
		if p125:getFillUnitSupportsFillType(p128, p130) then
			p130 = v133.seedFillType
			p125:setFillUnitForcedMaterialFillType(p128, p130)
		end
		local v134 = v133.seeds[v133.currentSeed]
		if v134 ~= nil then
			local v135 = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v134)
			if v135 ~= nil and p125:getFillUnitSupportsFillType(p128, v135) then
				p125:setFillUnitForcedMaterialFillType(p128, v135)
			end
		end
	end
	return p126(p125, p127, p128, p129, p130, p131, p132)
end
function SowingMachine.doCheckSpeedLimit(p136, p137)
	local v138 = p136.spec_sowingMachine
	local v139 = not p137(p136) and (p136.getIsImplementChainLowered == nil or p136:getIsImplementChainLowered())
	if v139 then
		v139 = not v138.needsActivation or p136:getIsTurnedOn()
	end
	return v139
end
function SowingMachine.getDirtMultiplier(p140, p141)
	local v142 = p140.spec_sowingMachine
	local v143 = p141(p140)
	if p140.movingDirection > 0 and (v142.isWorking and (not v142.needsActivation or p140:getIsTurnedOn())) then
		v143 = v143 + p140:getWorkDirtMultiplier() * p140:getLastSpeed() / p140.speedLimit
	end
	return v143
end
function SowingMachine.getWearMultiplier(p144, p145)
	local v146 = p144.spec_sowingMachine
	local v147 = p145(p144)
	if p144.movingDirection > 0 and (v146.isWorking and (not v146.needsActivation or p144:getIsTurnedOn())) then
		local v148 = (v146.stoneLastState == 0 or v146.stoneWearMultiplierData == nil) and 1 or (v146.stoneWearMultiplierData[v146.stoneLastState] or 1)
		v147 = v147 + p144:getWorkWearMultiplier() * p144:getLastSpeed() / p144.speedLimit * v148
	end
	return v147
end
function SowingMachine.loadWorkAreaFromXML(p149, p150, p151, p152, p153)
	local v154 = p150(p149, p151, p152, p153)
	if p151.type == WorkAreaType.DEFAULT then
		p151.type = WorkAreaType.SOWINGMACHINE
	end
	return v154
end
function SowingMachine.getCanBeSelected(_, _)
	return true
end
function SowingMachine.getCanAIImplementContinueWork(p155, p156, p157)
	local v158, v159, v160 = p156(p155, p157)
	if not v158 then
		return false, v159, v160
	end
	if not p155:getCanPlantOutsideSeason() then
		local v161 = p155.spec_sowingMachine
		if v161.workAreaParameters.seedsFruitType ~= nil and not g_fruitTypeManager:getFruitTypeByIndex(v161.workAreaParameters.seedsFruitType):getIsPlantableInPeriod(g_currentMission.missionInfo.growthMode, g_currentMission.environment.currentPeriod) then
			return false, true, AIMessageErrorWrongSeason.new()
		end
	end
	return v158, v159, v160
end
function SowingMachine.onRegisterActionEvents(p162, _, p163)
	if p162.isClient then
		local v164 = p162.spec_sowingMachine
		p162:clearActionEventsTable(v164.actionEvents)
		if p163 and #v164.seeds > 1 then
			local _, v165 = p162:addActionEvent(v164.actionEvents, v164.changeSeedInputButton, p162, SowingMachine.actionEventToggleSeedType, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v165, GS_PRIO_HIGH)
			SowingMachine.updateChooseSeedActionEvent(p162)
			local _, v166 = p162:addPoweredActionEvent(v164.actionEvents, InputAction.TOGGLE_SEEDS_BACK, p162, SowingMachine.actionEventToggleSeedTypeBack, false, true, false, true, nil)
			g_inputBinding:setActionEventTextVisibility(v166, false)
		end
	end
end
function SowingMachine.updateChooseSeedActionEvent(p167)
	local v168 = p167.spec_sowingMachine
	local v169 = v168.actionEvents[v168.changeSeedInputButton]
	if v169 ~= nil then
		local v170 = g_fillTypeManager:getFillTypeByIndex(g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v168.seeds[v168.currentSeed]))
		local v171 = (v170 == nil or v170 == FillType.UNKNOWN) and "" or string.format(" (%s)", v170.title)
		g_inputBinding:setActionEventText(v169.actionEventId, string.format("%s%s", g_i18n:getText("action_chooseSeed"), v171))
	end
end
function SowingMachine.onTurnedOn(p172)
	local v173 = p172.spec_sowingMachine
	if p172.isClient then
		g_soundManager:playSamples(v173.samples.airBlower)
		g_animationManager:startAnimations(v173.animationNodes)
	end
	if p172.isServer and v173.fillTypeSources[v173.seedFillType] ~= nil then
		for _, v174 in ipairs(v173.fillTypeSources[v173.seedFillType]) do
			if v174.vehicle.setIsTurnedOn ~= nil then
				v174.vehicle:setIsTurnedOn(true)
			end
		end
	end
	SowingMachine.updateAiParameters(p172)
end
function SowingMachine.onTurnedOff(p175)
	local v176 = p175.spec_sowingMachine
	if p175.isClient then
		g_soundManager:stopSamples(v176.samples.airBlower)
		g_animationManager:stopAnimations(v176.animationNodes)
	end
	if p175.isServer and v176.fillTypeSources[v176.seedFillType] ~= nil then
		for _, v177 in ipairs(v176.fillTypeSources[v176.seedFillType]) do
			if v177.vehicle.setIsTurnedOn ~= nil then
				v177.vehicle:setIsTurnedOn(false)
			end
		end
	end
	SowingMachine.updateAiParameters(p175)
end
function SowingMachine.onStartWorkAreaProcessing(p178, _)
	local v179 = p178.spec_sowingMachine
	v179.isWorking = false
	v179.isProcessing = false
	local v180 = v179.seeds[v179.currentSeed]
	local v181, _, v182 = localDirectionToWorld(v179.directionNode, 0, 0, 1)
	local v183 = MathUtil.getYRotationFromDirection(v181, v182)
	local v184 = g_fruitTypeManager:getFruitTypeByIndex(v180)
	if v184 ~= nil and v184.directionSnapAngle ~= 0 then
		local v185 = v183 / v184.directionSnapAngle + 0.5
		v183 = math.floor(v185) * v184.directionSnapAngle
	end
	local v186 = FSDensityMapUtil.convertToDensityMapAngle(v183, g_currentMission.fieldGroundSystem:getGroundAngleMaxValue())
	local v187 = nil
	local v188 = nil
	local v189 = nil
	local v190
	if v179.consumableName == nil then
		v190 = p178:getFillUnitFillLevel(v179.fillUnitIndex) > 0
	else
		v190 = p178:getConsumableIsAvailable(v179.consumableName)
	end
	local v191
	if v190 then
		v188 = v179.fillUnitIndex
		v189 = v179.unloadInfoIndex
		v191 = p178
	elseif v179.fillTypeSources[v179.seedFillType] == nil then
		v191 = p178
		p178 = v187
	else
		v191 = p178
		p178 = v187
		for _, v192 in ipairs(v179.fillTypeSources[v179.seedFillType]) do
			local v193 = v192.vehicle
			if v193:getFillUnitFillLevel(v192.fillUnitIndex) > 0 and v193:getFillUnitFillType(v192.fillUnitIndex) == v179.seedFillType then
				v188 = v192.fillUnitIndex
				p178 = v193
				break
			end
			v187 = p178
			p178 = v191
			v191 = p178
			p178 = v187
		end
	end
	if p178 ~= nil and p178 ~= v191 then
		local v194 = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v180)
		if v194 ~= nil then
			p178:setFillUnitFillTypeToDisplay(v188, v194)
		end
	end
	local v195 = v191:getIsTurnedOn()
	local v196 = v184 ~= nil and v184.terrainDataPlaneId ~= nil
	if v179.showWrongFruitForMissionWarning then
		v179.showWrongFruitForMissionWarning = false
	end
	local v197 = v191:getCanPlantOutsideSeason() and true or g_fruitTypeManager:getFruitTypeByIndex(v180):getIsPlantableInPeriod(g_currentMission.missionInfo.growthMode, g_currentMission.environment.currentPeriod)
	local v198 = p178 ~= v179.workAreaParameters.seedsVehicle and true or v188 ~= v179.workAreaParameters.seedsVehicleFillUnitIndex
	v179.showFruitCanNotBePlantedWarning = not v196
	local v199 = not (v197 or (v195 or v179.needsActivation))
	if v199 then
		v199 = v191:getIsLowered()
	end
	v179.showWrongPlantingTimeWarning = v199
	v179.showWaterPlantingRequiredWarning = false
	v179.showWaterPlantingProhibitedWarning = false
	v179.showFieldTypeWarningRegularRequired = false
	v179.showFieldTypeWarningRiceRequired = false
	v179.workAreaParameters.isActive = not v179.needsActivation or v195
	v179.workAreaParameters.canFruitBePlanted = v196 and v197
	v179.workAreaParameters.seedsFruitType = v180
	v179.workAreaParameters.fieldGroundType = v179.fieldGroundType
	v179.workAreaParameters.ridgeSeeding = v179.ridgeSeeding
	v179.workAreaParameters.angle = v186
	v179.workAreaParameters.seedsVehicle = p178
	v179.workAreaParameters.seedsVehicleFillUnitIndex = v188
	v179.workAreaParameters.seedsVehicleUnloadInfoIndex = v189
	v179.workAreaParameters.lastTotalArea = 0
	v179.workAreaParameters.lastChangedArea = 0
	v179.workAreaParameters.lastStatsArea = 0
	if v198 then
		SowingMachine.updateAiParameters(v191)
	end
end
function SowingMachine.onEndWorkAreaProcessing(p200, p201, _)
	local v202 = p200.spec_sowingMachine
	if p200.isServer then
		local v203 = p200:getLastTouchedFarmlandFarmId()
		if v202.workAreaParameters.lastChangedArea > 0 then
			local v204 = g_fruitTypeManager:getFruitTypeByIndex(v202.workAreaParameters.seedsFruitType)
			local v205 = MathUtil.areaToHa(v202.workAreaParameters.lastChangedArea, g_currentMission:getFruitPixelsToSqm())
			local v206 = v204.seedUsagePerSqm * v205 * 10000 * v202.seedUsageScale
			local v207 = MathUtil.areaToHa(v202.workAreaParameters.lastStatsArea, g_currentMission:getFruitPixelsToSqm())
			local v208 = p200:getVehicleDamage()
			if v208 > 0 then
				v206 = v206 * (1 + v208 * SowingMachine.DAMAGED_USAGE_INCREASE)
			end
			g_farmManager:updateFarmStats(v203, "seedUsage", v206)
			g_farmManager:updateFarmStats(v203, "sownHectares", v207)
			p200:updateLastWorkedArea(v202.workAreaParameters.lastStatsArea)
			if p200:getIsAIActive() and g_currentMission.missionInfo.helperBuySeeds then
				local v209 = v206 * g_currentMission.economyManager:getCostPerLiter(v202.seedFillType, false) * 1.5
				g_farmManager:updateFarmStats(v203, "expenses", v209)
				g_currentMission:addMoney(-v209, p200:getOwnerFarmId(), MoneyType.PURCHASE_SEEDS)
			elseif v202.consumableName == nil then
				local v210 = v202.workAreaParameters.seedsVehicle
				local v211 = v202.workAreaParameters.seedsVehicleFillUnitIndex
				local v212 = v202.workAreaParameters.seedsVehicleUnloadInfoIndex
				local v213 = v210:getFillUnitFillType(v211)
				local v214
				if v210.getFillVolumeUnloadInfo == nil then
					v214 = nil
				else
					v214 = v210:getFillVolumeUnloadInfo(v212)
				end
				v210:addFillUnitFillLevel(p200:getOwnerFarmId(), v211, -v206, v213, ToolType.UNDEFINED, v214)
			else
				p200:updateConsumable(v202.consumableName, -v206, true)
			end
		end
		p200:updateLastWorkedArea(0)
		if v202.isWorking then
			g_farmManager:updateFarmStats(v203, "sownTime", p201 / 60000)
		end
	end
	if p200.isClient then
		if v202.isWorking then
			if not v202.isWorkSamplePlaying then
				g_soundManager:playSamples(v202.samples.work)
				v202.isWorkSamplePlaying = true
				return
			end
		elseif v202.isWorkSamplePlaying then
			g_soundManager:stopSamples(v202.samples.work)
			v202.isWorkSamplePlaying = false
		end
	end
end
function SowingMachine.onDeactivate(p215)
	local v216 = p215.spec_sowingMachine
	if p215.isClient then
		g_soundManager:stopSamples(v216.samples.work)
		g_soundManager:stopSamples(v216.samples.airBlower)
		v216.isWorkSamplePlaying = false
	end
end
function SowingMachine.onStateChange(p217, p218, _)
	if p218 == VehicleStateChange.ATTACH or (p218 == VehicleStateChange.DETACH or VehicleStateChange.FILLTYPE_CHANGE) then
		local v219 = p217.spec_sowingMachine
		v219.fillTypeSources = {}
		if v219.seedFillType ~= nil then
			v219.fillTypeSources[v219.seedFillType] = {}
			local v220 = p217.rootVehicle
			FillUnit.addFillTypeSources(v219.fillTypeSources, v220, p217, { v219.seedFillType })
			local v221 = g_fruitTypeManager:getFillTypeIndexByFruitTypeIndex(v219.seeds[v219.currentSeed])
			if v221 ~= nil then
				p217:setFillTypeSourceDisplayFillType(v221)
			end
		end
	end
end
function SowingMachine.onChangedFillType(p222, p223, p224, _)
	local v225 = p222.spec_sowingMachine
	if p223 == v225.fillUnitIndex then
		g_animationManager:setFillType(v225.animationNodes, p224)
	end
end
function SowingMachine.onAIFieldCourseSettingsInitialized(p226, p227)
	if p226.spec_sowingMachine.fieldGroundType == FieldGroundType.PLANTED then
		p227.headlandsFirst = true
		p227.workInitialSegment = true
	end
end
function SowingMachine.updateAiParameters(p228)
	local v229 = p228.spec_sowingMachine
	if p228.addAITerrainDetailRequiredRange ~= nil then
		p228:clearAITerrainDetailRequiredRange()
		p228:clearAITerrainDetailProhibitedRange()
		p228:clearAIFruitProhibitions()
		local v230 = p228.rootVehicle:getChildVehicles()
		local v231 = false
		local v232 = false
		local v233 = false
		for v234 = 1, #v230 do
			local v235 = v230[v234]
			if SpecializationUtil.hasSpecialization(Cultivator, v235.specializations) then
				v235:updateCultivatorEnabledState()
				if v235:getIsCultivationEnabled() then
					v235:updateCultivatorAIRequirements()
					v231 = true
				end
			end
			if SpecializationUtil.hasSpecialization(Weeder, v235.specializations) then
				v235:updateWeederAIRequirements()
				v232 = true
			end
			if SpecializationUtil.hasSpecialization(Roller, v235.specializations) then
				v235:updateRollerAIRequirements()
				v233 = true
			end
		end
		if v231 then
			if p228:getUseSowingMachineAIRequirements() then
				p228:addAIGroundTypeRequirements(SowingMachine.AI_REQUIRED_GROUND_TYPES)
				p228:addAIGroundTypeRequirements(SowingMachine.AI_OUTPUT_GROUND_TYPES)
			end
		elseif v232 then
			if p228:getUseSowingMachineAIRequirements() then
				p228:clearAITerrainDetailRequiredRange()
				p228:addAIGroundTypeRequirements(SowingMachine.AI_REQUIRED_GROUND_TYPES)
			end
		elseif v233 then
			if p228:getUseSowingMachineAIRequirements() then
				p228:clearAITerrainDetailRequiredRange()
				p228:addAIGroundTypeRequirements(SowingMachine.AI_REQUIRED_GROUND_TYPES)
			end
		else
			p228:addAIGroundTypeRequirements(SowingMachine.AI_REQUIRED_GROUND_TYPES)
			if v229.useDirectPlanting then
				p228:addAIGroundTypeRequirements(SowingMachine.AI_OUTPUT_GROUND_TYPES)
			end
		end
		if p228:getUseSowingMachineAIRequirements() then
			local v236 = v229.seeds[v229.currentSeed]
			local v237 = g_fruitTypeManager:getFruitTypeByIndex(v236)
			if v237 ~= nil then
				if v237.cutState < v237.maxHarvestingGrowthState then
					p228:clearAIFruitProhibitions()
					p228:addAIFruitProhibitions(v236, 0, v237.cutState - 1)
					p228:addAIFruitProhibitions(v236, v237.cutState + 1, v237.maxHarvestingGrowthState)
					return
				end
				p228:setAIFruitProhibitions(v236, 0, v237.maxHarvestingGrowthState)
			end
		end
	end
end
function SowingMachine.getDefaultSpeedLimit()
	return 15
end
function SowingMachine.actionEventToggleSeedType(p238, _, _, _, _)
	if p238:getIsSeedChangeAllowed() then
		p238:changeSeedIndex(1)
	end
end
function SowingMachine.actionEventToggleSeedTypeBack(p239, _, _, _, _)
	if p239:getIsSeedChangeAllowed() then
		p239:changeSeedIndex(-1)
	end
end
function SowingMachine.loadSpecValueSeedFillTypes(p240, _, _)
	return {
		["categories"] = Utils.getNoNil(p240:getValue("vehicle.storeData.specs.seedFruitTypeCategories"), p240:getValue("vehicle.sowingMachine.seedFruitTypeCategories")),
		["names"] = Utils.getNoNil(p240:getValue("vehicle.storeData.specs.seedFruitTypes"), p240:getValue("vehicle.sowingMachine.seedFruitTypes"))
	}
end
function SowingMachine.getSpecValueSeedFillTypes(p241, _)
	local v242 = nil
	if p241.specs.seedFillTypes ~= nil then
		local v243 = p241.specs.seedFillTypes
		if v243.categories == nil or v243.names ~= nil then
			if v243.categories == nil and v243.names ~= nil then
				v242 = g_fruitTypeManager:getFillTypeIndicesByFruitTypeNames(v243.names, nil)
			end
		else
			v242 = g_fruitTypeManager:getFillTypeIndicesByFruitTypeCategoryName(v243.categories, nil)
		end
		if v242 ~= nil then
			return v242
		end
	end
	return nil
end

DynamicMountAttacher = {}
DynamicMountAttacher.DYNAMIC_MOUNT_GRAB_XML_PATH = "vehicle.dynamicMountAttacher.grab"
function DynamicMountAttacher.prerequisitesPresent(_)
	return true
end
function DynamicMountAttacher.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("DynamicMountAttacher")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicMountAttacher#node", "Attacher node")
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMountAttacher#forceLimitScale", "Force limit", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMountAttacher#timeToMount", "No movement time until mounting", 1000)
	v1:register(XMLValueType.INT, "vehicle.dynamicMountAttacher#numObjectBits", "Number of object bits to sync", 5)
	v1:register(XMLValueType.STRING, "vehicle.dynamicMountAttacher.grab#openMountType", "Open mount type", "TYPE_FORK")
	v1:register(XMLValueType.STRING, "vehicle.dynamicMountAttacher.grab#closedMountType", "Closed mount type", "TYPE_AUTO_ATTACH_XYZ")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicMountAttacher.fork(?)#node", "Fork collision node (starting from FS25 one combined node for front and back part)")
	v1:register(XMLValueType.STRING, "vehicle.dynamicMountAttacher.fork(?)#mountType", "Mount type that is used if object is mounted via this fork node", "FORK")
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMountAttacher.fork(?)#forceLimitScale", "Force limit that is used if object is mounted via this fork node", 1)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicMountAttacher#triggerNode", "Trigger node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicMountAttacher#rootNode", "Root node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicMountAttacher#jointNode", "Joint node")
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMountAttacher#forceAcceleration", "Force acceleration", 30)
	v1:register(XMLValueType.STRING, "vehicle.dynamicMountAttacher#mountType", "Mount type", "TYPE_AUTO_ATTACH_XZ")
	v1:register(XMLValueType.BOOL, "vehicle.dynamicMountAttacher#transferMass", "If this is set to \'true\' the mass of the object to mount is transferred to our own component. This improves physics stability", false)
	v1:register(XMLValueType.STRING, "vehicle.dynamicMountAttacher.lockPosition(?)#xmlFilename", "XML filename of vehicle to lock (needs to match only the end of the filename)")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicMountAttacher.lockPosition(?)#jointNode", "Joint node (Represents the position of the other vehicles root node)")
	ObjectChangeUtil.registerObjectChangeXMLPaths(v1, "vehicle.dynamicMountAttacher.lockPosition(?)")
	v1:register(XMLValueType.STRING, "vehicle.dynamicMountAttacher.animation#name", "Animation name")
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMountAttacher.animation#speed", "Animation speed", 1)
	v1:addDelayedRegistrationFunc("Cylindered:movingTool", function(p2, p3)
		p2:register(XMLValueType.BOOL, p3 .. ".dynamicMountAttacher#value", "Update dynamic mount attacher joints")
	end)
	v1:addDelayedRegistrationFunc("Cylindered:movingPart", function(p4, p5)
		p4:register(XMLValueType.BOOL, p5 .. ".dynamicMountAttacher#value", "Update dynamic mount attacher joints")
	end)
	v1:register(XMLValueType.BOOL, "vehicle.dynamicMountAttacher#allowFoldingWhileMounted", "Folding is allowed while a object is mounted", true)
	v1:setXMLSpecializationType()
end
function DynamicMountAttacher.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "writeDynamicMountObjectsToStream", DynamicMountAttacher.writeDynamicMountObjectsToStream)
	SpecializationUtil.registerFunction(p6, "readDynamicMountObjectsFromStream", DynamicMountAttacher.readDynamicMountObjectsFromStream)
	SpecializationUtil.registerFunction(p6, "getAllowDynamicMountObjects", DynamicMountAttacher.getAllowDynamicMountObjects)
	SpecializationUtil.registerFunction(p6, "dynamicMountTriggerCallback", DynamicMountAttacher.dynamicMountTriggerCallback)
	SpecializationUtil.registerFunction(p6, "lockDynamicMountedObject", DynamicMountAttacher.lockDynamicMountedObject)
	SpecializationUtil.registerFunction(p6, "addDynamicMountedObject", DynamicMountAttacher.addDynamicMountedObject)
	SpecializationUtil.registerFunction(p6, "removeDynamicMountedObject", DynamicMountAttacher.removeDynamicMountedObject)
	SpecializationUtil.registerFunction(p6, "setDynamicMountAnimationState", DynamicMountAttacher.setDynamicMountAnimationState)
	SpecializationUtil.registerFunction(p6, "getAllowDynamicMountFillLevelInfo", DynamicMountAttacher.getAllowDynamicMountFillLevelInfo)
	SpecializationUtil.registerFunction(p6, "loadDynamicMountGrabFromXML", DynamicMountAttacher.loadDynamicMountGrabFromXML)
	SpecializationUtil.registerFunction(p6, "getIsDynamicMountGrabOpened", DynamicMountAttacher.getIsDynamicMountGrabOpened)
	SpecializationUtil.registerFunction(p6, "getDynamicMountTimeToMount", DynamicMountAttacher.getDynamicMountTimeToMount)
	SpecializationUtil.registerFunction(p6, "getHasDynamicMountedObjects", DynamicMountAttacher.getHasDynamicMountedObjects)
	SpecializationUtil.registerFunction(p6, "forceDynamicMountPendingObjects", DynamicMountAttacher.forceDynamicMountPendingObjects)
	SpecializationUtil.registerFunction(p6, "forceUnmountDynamicMountedObjects", DynamicMountAttacher.forceUnmountDynamicMountedObjects)
	SpecializationUtil.registerFunction(p6, "getDynamicMountAttacherSettingsByNode", DynamicMountAttacher.getDynamicMountAttacherSettingsByNode)
end
function DynamicMountAttacher.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "getFillLevelInformation", DynamicMountAttacher.getFillLevelInformation)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadExtraDependentParts", DynamicMountAttacher.loadExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p7, "updateExtraDependentParts", DynamicMountAttacher.updateExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsAttachedTo", DynamicMountAttacher.getIsAttachedTo)
	SpecializationUtil.registerOverwrittenFunction(p7, "getAdditionalComponentMass", DynamicMountAttacher.getAdditionalComponentMass)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsFoldAllowed", DynamicMountAttacher.getIsFoldAllowed)
end
function DynamicMountAttacher.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", DynamicMountAttacher)
	SpecializationUtil.registerEventListener(p8, "onDelete", DynamicMountAttacher)
	SpecializationUtil.registerEventListener(p8, "onReadUpdateStream", DynamicMountAttacher)
	SpecializationUtil.registerEventListener(p8, "onWriteUpdateStream", DynamicMountAttacher)
	SpecializationUtil.registerEventListener(p8, "onUpdateTick", DynamicMountAttacher)
	SpecializationUtil.registerEventListener(p8, "onPreAttachImplement", DynamicMountAttacher)
end
function DynamicMountAttacher.onLoad(p_u_9, _)
	local v_u_10 = p_u_9.spec_dynamicMountAttacher
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.dynamicMountAttacher#index", "vehicle.dynamicMountAttacher#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.dynamicMountAttacher.mountCollisionMask", "vehicle.dynamicMountAttacher.fork")
	v_u_10.dynamicMountAttacherNode = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#node", nil, p_u_9.components, p_u_9.i3dMappings)
	v_u_10.dynamicMountAttacherForceLimitScale = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#forceLimitScale", 1)
	v_u_10.dynamicMountAttacherTimeToMount = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#timeToMount", 1000)
	v_u_10.numObjectBits = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#numObjectBits", 5)
	v_u_10.maxNumObjectsToSend = 2 ^ v_u_10.numObjectBits - 1
	if p_u_9.xmlFile:hasProperty("vehicle.dynamicMountAttacher.grab") then
		v_u_10.dynamicMountAttacherGrab = {}
		p_u_9:loadDynamicMountGrabFromXML(p_u_9.xmlFile, "vehicle.dynamicMountAttacher.grab", v_u_10.dynamicMountAttacherGrab)
	end
	v_u_10.pendingDynamicMountObjects = {}
	v_u_10.lockPositions = {}
	if p_u_9.isServer then
		v_u_10.forks = {}
		for _, v11 in p_u_9.xmlFile:iterator("vehicle.dynamicMountAttacher.fork") do
			local v12 = {
				["node"] = p_u_9.xmlFile:getValue(v11 .. "#node", nil, p_u_9.components, p_u_9.i3dMappings)
			}
			if v12.node == nil then
				Logging.xmlWarning(p_u_9.xmlFile, "Missing node or fork in \'%s\'", v11)
			elseif getCollisionFilterGroup(v12.node) == CollisionFlag.VEHICLE_FORK then
				local v13 = p_u_9.xmlFile:getValue(v11 .. "#mountType", "FORK")
				v12.mountType = DynamicMountUtil["TYPE_" .. v13] or DynamicMountUtil.TYPE_FORK
				v12.forceLimitScale = p_u_9.xmlFile:getValue(v11 .. "#forceLimitScale", v_u_10.dynamicMountAttacherForceLimitScale)
				local v14 = v_u_10.forks
				table.insert(v14, v12)
			else
				Logging.xmlWarning(p_u_9.xmlFile, "Fork node \'%s\' has invalid collision filter group, should have %s!", getName(v12.node), CollisionFlag.getBitAndName(CollisionFlag.VEHICLE_FORK))
			end
		end
		local v15 = {
			["triggerNode"] = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#triggerNode", nil, p_u_9.components, p_u_9.i3dMappings),
			["rootNode"] = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#rootNode", nil, p_u_9.components, p_u_9.i3dMappings),
			["jointNode"] = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#jointNode", nil, p_u_9.components, p_u_9.i3dMappings)
		}
		if v15.triggerNode ~= nil and (v15.rootNode ~= nil and v15.jointNode ~= nil) then
			local v16 = getCollisionFilterMask(v15.triggerNode)
			if bitAND(v16, CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.VEHICLE) > 0 then
				addTrigger(v15.triggerNode, "dynamicMountTriggerCallback", p_u_9)
				v15.forceAcceleration = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#forceAcceleration", 30)
				local v17 = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#mountType", "TYPE_AUTO_ATTACH_XZ")
				v15.mountType = Utils.getNoNil(DynamicMountUtil[v17], DynamicMountUtil.TYPE_AUTO_ATTACH_XZ)
				v15.currentMountType = v15.mountType
				v15.component = p_u_9:getParentComponent(v15.triggerNode)
				v_u_10.dynamicMountAttacherTrigger = v15
			else
				Logging.xmlWarning(p_u_9.xmlFile, "Dynamic Mount trigger has invalid collision filter mask, should have %s or %s!", CollisionFlag.getBitAndName(CollisionFlag.DYNAMIC_OBJECT), CollisionFlag.getBitAndName(CollisionFlag.VEHICLE))
			end
			if string.contains(string.lower(getName(v15.jointNode)), "cutter") and bitAND(v16, CollisionFlag.VEHICLE) == 0 then
				Logging.xmlWarning(p_u_9.xmlFile, "Dynamic Mount trigger has invalid collision filter mask, should have %s for cutter trailers!", CollisionFlag.getBitAndName(CollisionFlag.VEHICLE))
			end
			g_currentMission:addNodeObject(v15.triggerNode, p_u_9)
		end
		v_u_10.transferMass = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#transferMass", false)
		p_u_9.xmlFile:iterate("vehicle.dynamicMountAttacher.lockPosition", function(_, p18)
			-- upvalues: (copy) p_u_9, (copy) v_u_10
			local v19 = {
				["xmlFilename"] = p_u_9.xmlFile:getValue(p18 .. "#xmlFilename"),
				["jointNode"] = p_u_9.xmlFile:getValue(p18 .. "#jointNode", nil, p_u_9.components, p_u_9.i3dMappings)
			}
			if v19.xmlFilename == nil or v19.jointNode == nil then
				Logging.xmlWarning(p_u_9.xmlFile, "Invalid lock position \'%s\'. Missing xmlFilename or jointNode!", p18)
			else
				v19.xmlFilename = v19.xmlFilename:gsub("$data", "data")
				v19.objectChanges = {}
				ObjectChangeUtil.loadObjectChangeFromXML(p_u_9.xmlFile, p18, v19.objectChanges, p_u_9.components, p_u_9)
				local v20 = v_u_10.lockPositions
				table.insert(v20, v19)
			end
		end)
	end
	v_u_10.animationName = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher.animation#name")
	v_u_10.animationSpeed = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher.animation#speed", 1)
	if v_u_10.animationName ~= nil then
		p_u_9:playAnimation(v_u_10.animationName, v_u_10.animationSpeed, p_u_9:getAnimationTime(v_u_10.animationName), true)
	end
	v_u_10.allowFoldingWhileMounted = p_u_9.xmlFile:getValue("vehicle.dynamicMountAttacher#allowFoldingWhileMounted", true)
	v_u_10.dynamicMountedObjects = {}
	v_u_10.dynamicMountedObjectsDirtyFlag = p_u_9:getNextDirtyFlag()
end
function DynamicMountAttacher.onDelete(p21)
	local v22 = p21.spec_dynamicMountAttacher
	if p21.isServer and v22.dynamicMountedObjects ~= nil then
		for v23, _ in pairs(v22.dynamicMountedObjects) do
			v23:unmountDynamic()
		end
	end
	if v22.dynamicMountAttacherTrigger ~= nil then
		removeTrigger(v22.dynamicMountAttacherTrigger.triggerNode)
		g_currentMission:removeNodeObject(v22.dynamicMountAttacherTrigger.triggerNode)
	end
end
function DynamicMountAttacher.onReadUpdateStream(p24, p25, _, p26)
	if p26:getIsServer() then
		local v27 = p24.spec_dynamicMountAttacher
		if streamReadBool(p25) then
			p24:setDynamicMountAnimationState(p24:readDynamicMountObjectsFromStream(p25, v27.dynamicMountedObjects) > 0)
			p24:readDynamicMountObjectsFromStream(p25, v27.pendingDynamicMountObjects)
		end
	end
end
function DynamicMountAttacher.onWriteUpdateStream(p28, p29, p30, p31)
	if not p30:getIsServer() then
		local v32 = p28.spec_dynamicMountAttacher
		if streamWriteBool(p29, bitAND(p31, v32.dynamicMountedObjectsDirtyFlag) ~= 0) then
			p28:writeDynamicMountObjectsToStream(p29, v32.dynamicMountedObjects)
			p28:writeDynamicMountObjectsToStream(p29, v32.pendingDynamicMountObjects)
		end
	end
end
function DynamicMountAttacher.onUpdateTick(p33, _, _, _, _)
	if p33.isServer then
		local v34 = p33.spec_dynamicMountAttacher
		if p33:getAllowDynamicMountObjects() then
			for v35, _ in pairs(v34.pendingDynamicMountObjects) do
				p33:raiseActive()
				if v34.dynamicMountedObjects[v35] == nil and v35.lastMoveTime + p33:getDynamicMountTimeToMount() < g_currentMission.time then
					local v36 = false
					local v37
					if v35.components == nil then
						v37 = nil
					else
						if v35.getCanBeMounted == nil then
							v36 = entityExists(v35.components[1].node) and true or v36
						else
							v36 = v35:getCanBeMounted()
						end
						v37 = v35.components[1].node
					end
					if v35.nodeId ~= nil then
						if v35.getCanBeMounted == nil then
							v36 = entityExists(v35.nodeId) and true or v36
						else
							v36 = v35:getCanBeMounted()
						end
						v37 = v35.nodeId
					end
					if v36 then
						local v38 = v34.dynamicMountAttacherTrigger
						local v39 = createTransformGroup("dynamicMountObjectJoint")
						link(v38.jointNode, v39)
						setWorldTranslation(v39, getWorldTranslation(v37))
						if v35:mountDynamic(p33, v38.rootNode, v39, v38.mountType, v38.forceAcceleration) then
							v35.additionalDynamicMountJointNode = v39
							p33:addDynamicMountedObject(v35)
						else
							delete(v39)
						end
					else
						v34.pendingDynamicMountObjects[v35] = nil
						p33:raiseDirtyFlags(v34.dynamicMountedObjectsDirtyFlag)
					end
				end
			end
		else
			for v40, _ in pairs(v34.dynamicMountedObjects) do
				p33:removeDynamicMountedObject(v40, false)
				v40:unmountDynamic()
				if v40.additionalDynamicMountJointNode ~= nil then
					delete(v40.additionalDynamicMountJointNode)
					v40.additionalDynamicMountJointNode = nil
				end
			end
		end
		if v34.dynamicMountAttacherGrab ~= nil then
			for v41, _ in pairs(v34.dynamicMountedObjects) do
				local v42 = v34.dynamicMountAttacherGrab.closedMountType
				if p33:getIsDynamicMountGrabOpened(v34.dynamicMountAttacherGrab) then
					v42 = v34.dynamicMountAttacherGrab.openMountType
				end
				if v34.dynamicMountAttacherGrab.currentMountType ~= v42 then
					v34.dynamicMountAttacherGrab.currentMountType = v42
					local v43, v44, v45 = getWorldTranslation(v34.dynamicMountAttacherNode)
					setJointPosition(v41.dynamicMountJointIndex, 1, v43, v44, v45)
					if v42 == DynamicMountUtil.TYPE_FORK then
						setJointRotationLimit(v41.dynamicMountJointIndex, 0, true, 0, 0)
						setJointRotationLimit(v41.dynamicMountJointIndex, 1, true, 0, 0)
						setJointRotationLimit(v41.dynamicMountJointIndex, 2, true, 0, 0)
						if v41.dynamicMountSingleAxisFreeX then
							setJointTranslationLimit(v41.dynamicMountJointIndex, 0, false, 0, 0)
						else
							setJointTranslationLimit(v41.dynamicMountJointIndex, 0, true, -0.01, 0.01)
						end
						if v41.dynamicMountSingleAxisFreeY then
							setJointTranslationLimit(v41.dynamicMountJointIndex, 1, false, 0, 0)
						else
							setJointTranslationLimit(v41.dynamicMountJointIndex, 1, true, -0.01, 0.01)
						end
						setJointTranslationLimit(v41.dynamicMountJointIndex, 2, false, 0, 0)
					else
						setJointRotationLimit(v41.dynamicMountJointIndex, 0, true, 0, 0)
						setJointRotationLimit(v41.dynamicMountJointIndex, 1, true, 0, 0)
						setJointRotationLimit(v41.dynamicMountJointIndex, 2, true, 0, 0)
						if v42 == DynamicMountUtil.TYPE_AUTO_ATTACH_XYZ or v42 == DynamicMountUtil.TYPE_FIX_ATTACH then
							setJointTranslationLimit(v41.dynamicMountJointIndex, 0, true, -0.01, 0.01)
							setJointTranslationLimit(v41.dynamicMountJointIndex, 1, true, -0.01, 0.01)
							setJointTranslationLimit(v41.dynamicMountJointIndex, 2, true, -0.01, 0.01)
						elseif v42 == DynamicMountUtil.TYPE_AUTO_ATTACH_XZ then
							setJointTranslationLimit(v41.dynamicMountJointIndex, 0, true, -0.01, 0.01)
							setJointTranslationLimit(v41.dynamicMountJointIndex, 1, false, 0, 0)
							setJointTranslationLimit(v41.dynamicMountJointIndex, 2, true, -0.01, 0.01)
						elseif v42 == DynamicMountUtil.TYPE_AUTO_ATTACH_Y then
							setJointTranslationLimit(v41.dynamicMountJointIndex, 0, false, 0, 0)
							setJointTranslationLimit(v41.dynamicMountJointIndex, 1, true, -0.01, 0.01)
							setJointTranslationLimit(v41.dynamicMountJointIndex, 2, false, 0, 0)
						end
					end
				end
			end
		end
	end
end
function DynamicMountAttacher.lockDynamicMountedObject(p46, p47, p48, p49, p50, p51, p52, p53)
	local v54 = p46.spec_dynamicMountAttacher
	DynamicMountUtil.unmountDynamic(p47, false)
	p47:removeFromPhysics()
	v54.pendingDynamicMountObjects[p47] = nil
	p47:setWorldPosition(p48, p49, p50, p51, p52, p53, 1, true)
	p47:addToPhysics()
	local v55 = v54.dynamicMountAttacherTrigger
	if not p47:mountDynamic(p46, v55.rootNode, v55.jointNode, v55.mountType, v55.forceAcceleration) then
		p46:removeDynamicMountedObject(p47, false)
	end
end
function DynamicMountAttacher.addDynamicMountedObject(p56, p57)
	local v58 = p56.spec_dynamicMountAttacher
	if v58.dynamicMountedObjects[p57] == nil then
		v58.dynamicMountedObjects[p57] = p57
		local v59 = false
		if p57.getMountableLockPositions ~= nil then
			local v60 = p57:getMountableLockPositions()
			for v61 = 1, #v60 do
				local v62 = v60[v61]
				if string.endsWith(p56.configFileName, v62.xmlFilename) then
					local v63 = I3DUtil.indexToObject(p56.components, v62.jointNode, p56.i3dMappings)
					if v63 ~= nil then
						local v64, v65, v66 = localToWorld(v63, v62.transOffset[1], v62.transOffset[2], v62.transOffset[3])
						local v67, v68, v69 = localRotationToWorld(v63, v62.rotOffset[1], v62.rotOffset[2], v62.rotOffset[3])
						p56:lockDynamicMountedObject(p57, v64, v65, v66, v67, v68, v69)
						v59 = true
						break
					end
				end
			end
		end
		if not v59 and p57:isa(Vehicle) then
			for v70 = 1, #v58.lockPositions do
				local v71 = v58.lockPositions[v70]
				if string.endsWith(p57.configFileName, v71.xmlFilename) then
					local v72, v73, v74 = getWorldTranslation(v71.jointNode)
					local v75, v76, v77 = getWorldRotation(v71.jointNode)
					p56:lockDynamicMountedObject(p57, v72, v73, v74, v75, v76, v77)
					ObjectChangeUtil.setObjectChanges(v71.objectChanges, true, p56, p56.setMovingToolDirty)
					break
				end
			end
		end
		if v58.transferMass and (p57.setReducedComponentMass ~= nil and p57:getAllowComponentMassReduction()) then
			p57:setReducedComponentMass(true)
			p56:setMassDirty()
		end
		p56:setDynamicMountAnimationState(true)
		p56:raiseDirtyFlags(v58.dynamicMountedObjectsDirtyFlag)
	end
end
function DynamicMountAttacher.removeDynamicMountedObject(p78, p79, p80)
	local v81 = p78.spec_dynamicMountAttacher
	v81.dynamicMountedObjects[p79] = nil
	if p80 then
		v81.pendingDynamicMountObjects[p79] = nil
	end
	for v82 = 1, #v81.lockPositions do
		ObjectChangeUtil.setObjectChanges(v81.lockPositions[v82].objectChanges, false, p78, p78.setMovingToolDirty)
	end
	if v81.transferMass then
		p78:setMassDirty()
	end
	p78:setDynamicMountAnimationState(false)
	p78:raiseDirtyFlags(v81.dynamicMountedObjectsDirtyFlag)
end
function DynamicMountAttacher.setDynamicMountAnimationState(p83, p84)
	local v85 = p83.spec_dynamicMountAttacher
	if p84 then
		p83:playAnimation(v85.animationName, v85.animationSpeed, p83:getAnimationTime(v85.animationName), true)
	else
		p83:playAnimation(v85.animationName, -v85.animationSpeed, p83:getAnimationTime(v85.animationName), true)
	end
end
function DynamicMountAttacher.writeDynamicMountObjectsToStream(p86, p87, p88)
	local v89 = p86.spec_dynamicMountAttacher
	local v90 = table.size(p88)
	local v91 = v89.maxNumObjectsToSend
	local v92 = math.min(v90, v91)
	streamWriteUIntN(p87, v92, v89.numObjectBits)
	local v93 = 0
	for v94, _ in pairs(p88) do
		v93 = v93 + 1
		if v93 <= v92 then
			NetworkUtil.writeNodeObject(p87, v94)
		else
			Logging.xmlWarning(p86.xmlFile, "Not enough bits to send all mounted objects. Please increase \'%s\'", "vehicle.dynamicMountAttacher#numObjectBits")
		end
	end
end
function DynamicMountAttacher.readDynamicMountObjectsFromStream(p95, p96, p97)
	local v98 = p95.spec_dynamicMountAttacher
	local v99 = streamReadUIntN(p96, v98.numObjectBits)
	for v100, _ in pairs(p97) do
		p97[v100] = nil
	end
	for _ = 1, v99 do
		local v101 = NetworkUtil.readNodeObject(p96)
		if v101 ~= nil then
			p97[v101] = v101
		end
	end
	return v99
end
function DynamicMountAttacher.getAllowDynamicMountObjects(_)
	return true
end
function DynamicMountAttacher.dynamicMountTriggerCallback(p102, _, p103, p104, p105, _, _)
	local v106 = p102.spec_dynamicMountAttacher
	if getRigidBodyType(p103) == RigidBodyType.DYNAMIC and not getHasTrigger(p103) then
		if p104 then
			local v107 = g_currentMission:getNodeObject(p103)
			if v107 == nil then
				v107 = g_currentMission.nodeToObject[p103]
			end
			if v107 == p102.rootVehicle or p102.spec_attachable ~= nil and p102.spec_attachable.attacherVehicle == v107 then
				v107 = nil
			end
			if v107 ~= nil and v107 ~= p102 then
				local v108 = v107.getSupportsMountDynamic ~= nil and v107:getSupportsMountDynamic()
				if v108 then
					v108 = v107.lastMoveTime ~= nil
				end
				local v109 = v107.getSupportsTensionBelts ~= nil and v107:getSupportsTensionBelts()
				if v109 then
					v109 = v107.lastMoveTime ~= nil
				end
				if v108 or v109 then
					v106.pendingDynamicMountObjects[v107] = Utils.getNoNil(v106.pendingDynamicMountObjects[v107], 0) + 1
					if v106.pendingDynamicMountObjects[v107] == 1 then
						p102:raiseDirtyFlags(v106.dynamicMountedObjectsDirtyFlag)
						return
					end
				end
			end
		elseif p105 then
			local v110 = g_currentMission:getNodeObject(p103)
			if v110 == nil then
				v110 = g_currentMission.nodeToObject[p103]
			end
			if v110 ~= nil and v106.pendingDynamicMountObjects[v110] ~= nil then
				local v111 = v106.pendingDynamicMountObjects[v110] - 1
				if v111 == 0 then
					v106.pendingDynamicMountObjects[v110] = nil
					if v106.dynamicMountedObjects[v110] ~= nil then
						p102:removeDynamicMountedObject(v110, false)
						v110:unmountDynamic()
						if v110.additionalDynamicMountJointNode ~= nil then
							delete(v110.additionalDynamicMountJointNode)
							v110.additionalDynamicMountJointNode = nil
						end
					end
					p102:raiseDirtyFlags(v106.dynamicMountedObjectsDirtyFlag)
					return
				end
				v106.pendingDynamicMountObjects[v110] = v111
			end
		end
	end
end
function DynamicMountAttacher.getAllowDynamicMountFillLevelInfo(_)
	return true
end
function DynamicMountAttacher.loadDynamicMountGrabFromXML(p112, _, p113, p114)
	local v115 = p112.xmlFile:getValue(p113 .. "#openMountType")
	p114.openMountType = Utils.getNoNil(DynamicMountUtil[v115], DynamicMountUtil.TYPE_FORK)
	local v116 = p112.xmlFile:getValue(p113 .. "#closedMountType")
	p114.closedMountType = Utils.getNoNil(DynamicMountUtil[v116], DynamicMountUtil.TYPE_AUTO_ATTACH_XYZ)
	p114.currentMountType = p114.openMountType
	return true
end
function DynamicMountAttacher.getIsDynamicMountGrabOpened(_, _)
	return true
end
function DynamicMountAttacher.getDynamicMountTimeToMount(p117)
	return p117.spec_dynamicMountAttacher.dynamicMountAttacherTimeToMount
end
function DynamicMountAttacher.getHasDynamicMountedObjects(p118)
	return next(p118.spec_dynamicMountAttacher.dynamicMountedObjects) ~= nil
end
function DynamicMountAttacher.forceDynamicMountPendingObjects(p119, p120)
	if p119:getAllowDynamicMountObjects() then
		local v121 = p119.spec_dynamicMountAttacher
		for v122, _ in pairs(v121.pendingDynamicMountObjects) do
			if v121.dynamicMountedObjects[v122] == nil and (not p120 or v122:isa(Bale)) then
				local v123 = v121.dynamicMountAttacherTrigger
				if v122:mountDynamic(p119, v123.rootNode, v123.jointNode, v123.mountType, v123.forceAcceleration) then
					p119:addDynamicMountedObject(v122)
				end
			end
		end
	end
end
function DynamicMountAttacher.forceUnmountDynamicMountedObjects(p124)
	local v125 = p124.spec_dynamicMountAttacher
	for v126, _ in pairs(v125.dynamicMountedObjects) do
		p124:removeDynamicMountedObject(v126, false)
		v126:unmountDynamic()
		if v126.additionalDynamicMountJointNode ~= nil then
			delete(v126.additionalDynamicMountJointNode)
			v126.additionalDynamicMountJointNode = nil
		end
	end
end
function DynamicMountAttacher.getDynamicMountAttacherSettingsByNode(p127, p128)
	local v129 = p127.spec_dynamicMountAttacher
	for _, v130 in pairs(v129.forks) do
		if v130.node == p128 then
			return v130.mountType, v130.forceLimitScale
		end
	end
	return DynamicMountUtil.TYPE_FORK, 1
end
function DynamicMountAttacher.getFillLevelInformation(p131, p132, p133)
	p132(p131, p133)
	if p131:getAllowDynamicMountFillLevelInfo() then
		local v134 = p131.spec_dynamicMountAttacher
		for v135, _ in pairs(v134.dynamicMountedObjects) do
			if v135.getFillLevelInformation == nil then
				if v135.getFillLevel ~= nil and v135.getFillType ~= nil then
					local v136 = v135:getFillType()
					local v137 = v135:getFillLevel()
					local v138
					if v135.getCapacity == nil then
						v138 = v137
					else
						v138 = v135:getCapacity()
					end
					p133:addFillLevel(v136, v137, v138)
				end
			else
				v135:getFillLevelInformation(p133)
			end
		end
	end
end
function DynamicMountAttacher.loadExtraDependentParts(p139, p140, p141, p142, p143)
	if not p140(p139, p141, p142, p143) then
		return false
	end
	p143.updateDynamicMountAttacher = p141:getValue(p142 .. ".dynamicMountAttacher#value")
	return true
end
function DynamicMountAttacher.updateExtraDependentParts(p144, p145, p146, p147)
	p145(p144, p146, p147)
	if p144.isServer and (p146.updateDynamicMountAttacher ~= nil and p146.updateDynamicMountAttacher) then
		local v148 = p144.spec_dynamicMountAttacher
		for v149, _ in pairs(v148.dynamicMountedObjects) do
			setJointFrame(v149.dynamicMountJointIndex, 0, v149.dynamicMountJointNode)
		end
	end
end
function DynamicMountAttacher.getIsAttachedTo(p150, p151, p152)
	if p151(p150, p152) then
		return true
	end
	local v153 = p150.spec_dynamicMountAttacher
	for v154, _ in pairs(v153.dynamicMountedObjects) do
		if v154 == p152 then
			return true
		end
	end
	for v155, _ in pairs(v153.pendingDynamicMountObjects) do
		if v155 == p152 then
			return true
		end
	end
	return false
end
function DynamicMountAttacher.getAdditionalComponentMass(p156, p157, p158)
	local v159 = p157(p156, p158)
	local v160 = p156.spec_dynamicMountAttacher
	if v160.dynamicMountAttacherTrigger ~= nil and (v160.transferMass and v160.dynamicMountAttacherTrigger.component == p158.node) then
		for v161, _ in pairs(v160.dynamicMountedObjects) do
			if v161.getAllowComponentMassReduction ~= nil and v161:getAllowComponentMassReduction() then
				v159 = v159 + (v161:getDefaultMass() - 0.1)
			end
		end
	end
	return v159
end
function DynamicMountAttacher.getIsFoldAllowed(p162, p163, p164, p165)
	if p162.spec_dynamicMountAttacher.allowFoldingWhileMounted or not p162:getHasDynamicMountedObjects() then
		return p163(p162, p164, p165)
	else
		return false, g_i18n:getText("warning_toolIsFull")
	end
end
function DynamicMountAttacher.onPreAttachImplement(p166, p167, _, _)
	local v168 = p167.spec_dynamicMountAttacher
	if v168 ~= nil and p166.isServer then
		v168.pendingDynamicMountObjects[p166] = nil
		if v168.dynamicMountedObjects[p166] ~= nil then
			p167:removeDynamicMountedObject(p166, false)
			p166:unmountDynamic()
			if p167.additionalDynamicMountJointNode ~= nil then
				delete(p167.additionalDynamicMountJointNode)
				p167.additionalDynamicMountJointNode = nil
			end
		end
	end
end
function DynamicMountAttacher.updateDebugValues(p169, p170)
	local v171 = p169.spec_dynamicMountAttacher
	if p169.isServer then
		local v172 = p169.lastMoveTime + v171.dynamicMountAttacherTimeToMount - g_currentMission.time
		local v173 = {
			["name"] = "timeToMount:",
			["value"] = string.format("%d", v172)
		}
		table.insert(p170, v173)
		for v174, _ in pairs(v171.pendingDynamicMountObjects) do
			local v175 = {
				["name"] = "pendingDynamicMountObject:"
			}
			local v176 = string.format
			local v177 = v174.configFileNameClean or v174
			local v178 = v174.lastMoveTime + v171.dynamicMountAttacherTimeToMount - g_currentMission.time
			v175.value = v176("%s timeToMount: %d", v177, (math.max(v178, 0)))
			table.insert(p170, v175)
		end
		for v179, _ in pairs(v171.dynamicMountedObjects) do
			local v180 = v179.configFileNameClean
			if not v180 then
				if v179.xmlFilename then
					v180 = Utils.getFilenameFromPath(v179.xmlFilename) or v179
				else
					v180 = v179
				end
			end
			local v181 = DebugUtil.tableToColor(v179)
			local v182 = {
				["name"] = "dynamicMountedObjects:",
				["value"] = string.format("%s jointIndex:%s mountOffset:%.3f triggerCount:%s", v180, v179.dynamicMountJointIndex, v179.dynamicMountJointNodeDynamicMountOffset or -1, v179.dynamicMountObjectTriggerCount),
				["color"] = v181
			}
			table.insert(p170, v182)
			local v183 = v179.nodeId or v179.rootNode
			if v183 ~= nil then
				local v184, v185, v186 = getWorldTranslation(v183)
				drawDebugPoint(v184, v185, v186, v181[1], v181[2], v181[3], v181[4], false)
			end
		end
	end
	local v187 = {
		["name"] = "allowMountObjects:",
		["value"] = string.format("%s", p169:getAllowDynamicMountObjects())
	}
	table.insert(p170, v187)
	if v171.dynamicMountAttacherGrab ~= nil then
		local v188 = {
			["name"] = "grabOpened:",
			["value"] = string.format("%s", p169:getIsDynamicMountGrabOpened(v171.dynamicMountAttacherGrab))
		}
		table.insert(p170, v188)
	end
end

TreeSaplingPallet = {}
function TreeSaplingPallet.prerequisitesPresent(_)
	return true
end
function TreeSaplingPallet.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("treeSaplingType", g_i18n:getText("configuration_treeType"), "treeSaplingPallet", VehicleConfigurationItemTreeSapling)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("TreeSaplingPallet")
	v1:register(XMLValueType.INT, "vehicle.treeSaplingPallet#fillUnitIndex", "Index of the saplings fill unit", 1)
	v1:register(XMLValueType.STRING, "vehicle.treeSaplingPallet#treeType", "Tree Type Name", "spruce1")
	v1:register(XMLValueType.STRING, "vehicle.treeSaplingPallet#variationName", "Stage variation name to use", "DEFAULT")
	v1:register(XMLValueType.FILENAME, "vehicle.treeSaplingPallet#filename", "Custom tree sapling i3d file")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.treeSaplingPallet.saplingNodes.saplingNode(?)#node", "Sapling link node")
	v1:register(XMLValueType.BOOL, "vehicle.treeSaplingPallet.saplingNodes.saplingNode(?)#randomize", "Randomize rotation and scale of saplings", true)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.treeSaplingPallet.treeSaplingTypeConfigurations.treeSaplingTypeConfiguration(?).saplingNodes.saplingNode(?)#node", "Sapling link node")
	v1:register(XMLValueType.BOOL, "vehicle.treeSaplingPallet.treeSaplingTypeConfigurations.treeSaplingTypeConfiguration(?).saplingNodes.saplingNode(?)#randomize", "Randomize rotation and scale of saplings", true)
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).treeSaplingPallet#treeTypeName", "Name of currently loaded tree type")
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).treeSaplingPallet#variationName", "Name of currently loaded tree stage variation")
end
function TreeSaplingPallet.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "onTreeSaplingLoaded", TreeSaplingPallet.onTreeSaplingLoaded)
	SpecializationUtil.registerFunction(p3, "getTreeSaplingPalletType", TreeSaplingPallet.getTreeSaplingPalletType)
	SpecializationUtil.registerFunction(p3, "setTreeSaplingPalletType", TreeSaplingPallet.setTreeSaplingPalletType)
	SpecializationUtil.registerFunction(p3, "updateTreeSaplingVisuals", TreeSaplingPallet.updateTreeSaplingVisuals)
	SpecializationUtil.registerFunction(p3, "updateTreeSaplingPalletNodes", TreeSaplingPallet.updateTreeSaplingPalletNodes)
end
function TreeSaplingPallet.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "showInfo", TreeSaplingPallet.showInfo)
end
function TreeSaplingPallet.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", TreeSaplingPallet)
	SpecializationUtil.registerEventListener(p5, "onDelete", TreeSaplingPallet)
	SpecializationUtil.registerEventListener(p5, "onFillUnitFillLevelChanged", TreeSaplingPallet)
end
function TreeSaplingPallet.onLoad(p_u_6, p7)
	local v_u_8 = p_u_6.spec_treeSaplingPallet
	local v9 = p_u_6.configurations.treeSaplingType or 1
	local v10 = string.format("vehicle.treeSaplingPallet.treeSaplingTypeConfigurations.treeSaplingTypeConfiguration(%d)", v9 - 1)
	local v11 = not p_u_6.xmlFile:hasProperty(v10) and "vehicle.treeSaplingPallet" or v10
	v_u_8.saplingNodes = {}
	v_u_8.fillUnitIndex = p_u_6.xmlFile:getValue("vehicle.treeSaplingPallet#fillUnitIndex", 1)
	v_u_8.treeTypeName = p_u_6.xmlFile:getValue("vehicle.treeSaplingPallet#treeType", "spruce")
	v_u_8.variationName = p_u_6.xmlFile:getValue("vehicle.treeSaplingPallet#variationName")
	v_u_8.treeTypeFilename = p_u_6.xmlFile:getValue("vehicle.treeSaplingPallet#filename", nil, p_u_6.baseDirectory)
	local v12 = ConfigurationUtil.getConfigItemByConfigId(p_u_6.configFileName, "treeSaplingType", v9)
	if v12 ~= nil then
		v_u_8.fillUnitIndex = v12.fillUnitIndex or v_u_8.fillUnitIndex
		v_u_8.treeTypeName = v12.treeTypeName or v_u_8.treeTypeName
		v_u_8.variationName = v12.variationName or v_u_8.variationName
		v_u_8.treeTypeFilename = v12.treeTypeFilename or v_u_8.treeTypeFilename
	end
	if p7 ~= nil then
		v_u_8.treeTypeName = p7.xmlFile:getValue(p7.key .. ".treeSaplingPallet#treeTypeName", v_u_8.treeTypeName)
		v_u_8.variationName = p7.xmlFile:getValue(p7.key .. ".treeSaplingPallet#variationName", v_u_8.variationName)
	end
	if v_u_8.treeTypeFilename == nil then
		local v13 = g_treePlantManager:getTreeTypeDescFromName(v_u_8.treeTypeName)
		if v13 ~= nil then
			local v14 = v13.stages[1]
			if v14 ~= nil then
				local v15 = nil
				for _, v16 in ipairs(v14) do
					if string.lower(v16.name or "DEFAULT") == string.lower(v_u_8.variationName or "DEFAULT") then
						v15 = v16
						break
					end
				end
				if v15 ~= nil then
					v_u_8.treeTypeFilename = v15.palletFilename or v15.filename
				end
			end
		end
	end
	if v_u_8.treeTypeFilename ~= nil then
		local v17 = v11 .. ".saplingNodes.saplingNode"
		local v18 = not p_u_6.xmlFile:hasProperty(v17) and "vehicle.treeSaplingPallet.saplingNodes.saplingNode" or v17
		p_u_6.xmlFile:iterate(v18, function(_, p19)
			-- upvalues: (copy) p_u_6, (copy) v_u_8
			local v20 = {
				["node"] = p_u_6.xmlFile:getValue(p19 .. "#node", nil, p_u_6.components, p_u_6.i3dMappings)
			}
			if v20.node ~= nil then
				if p_u_6.xmlFile:getValue(p19 .. "#randomize", true) then
					setRotation(v20.node, 0, math.random(0, 6.283185307179586), 0)
					setScale(v20.node, 1, math.random(90, 110) / 100, 1)
				end
				local v21 = v_u_8.saplingNodes
				table.insert(v21, v20)
			end
		end)
	end
	if v_u_8.treeTypeFilename ~= nil then
		v_u_8.infoBoxLineTitle = g_i18n:getText("configuration_treeType", p_u_6.customEnvironment)
		v_u_8.infoBoxLineValue = p_u_6.spec_treeSaplingPallet.title
	end
	p_u_6:updateTreeSaplingVisuals()
end
function TreeSaplingPallet.onDelete(p22)
	local v23 = p22.spec_treeSaplingPallet
	if v23.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(v23.sharedLoadRequestId)
		v23.sharedLoadRequestId = nil
	end
	if v23.saplingNodes ~= nil then
		for _, v24 in ipairs(v23.saplingNodes) do
			if v24.saplingShape ~= nil then
				delete(v24.saplingShape)
				v24.saplingShape = nil
			end
		end
	end
end
function TreeSaplingPallet.saveToXMLFile(p25, p26, p27, _)
	local v28 = p25.spec_treeSaplingPallet
	if v28.treeTypeName ~= nil then
		p26:setValue(p27 .. "#treeTypeName", v28.treeTypeName)
	end
	if v28.variationName ~= nil then
		p26:setValue(p27 .. "#variationName", v28.variationName)
	end
end
function TreeSaplingPallet.getTreeSaplingPalletType(p29)
	local v30 = p29.spec_treeSaplingPallet
	return v30.treeTypeName, v30.variationName
end
function TreeSaplingPallet.setTreeSaplingPalletType(p31, p32, p33)
	local v34 = p31.spec_treeSaplingPallet
	if p32 ~= v34.treeTypeName or v34.variationName ~= p33 then
		v34.treeTypeName = p32
		v34.variationName = p33
		p31:updateTreeSaplingVisuals()
	end
end
function TreeSaplingPallet.updateTreeSaplingVisuals(p35)
	local v36 = p35.spec_treeSaplingPallet
	if v36.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(v36.sharedLoadRequestId)
		v36.sharedLoadRequestId = nil
	end
	if v36.treeTypeFilename ~= nil then
		if p35.finishedLoading then
			v36.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(v36.treeTypeFilename, false, false, p35.onTreeSaplingLoaded, p35)
			return
		end
		v36.sharedLoadRequestId = p35:loadSubSharedI3DFile(v36.treeTypeFilename, false, false, p35.onTreeSaplingLoaded, p35)
	end
end
function TreeSaplingPallet.onTreeSaplingLoaded(p37, p38, _, _)
	if p38 ~= 0 then
		local v39 = getChildAt(p38, 0)
		local v40 = p37.spec_treeSaplingPallet
		for _, v41 in ipairs(v40.saplingNodes) do
			if v41.saplingShape ~= nil then
				delete(v41.saplingShape)
			end
			v41.saplingShape = clone(v39, false, false, false)
			link(v41.node, v41.saplingShape)
		end
		delete(p38)
		p37:updateTreeSaplingPalletNodes()
	end
end
function TreeSaplingPallet.updateTreeSaplingPalletNodes(p42)
	local v43 = p42.spec_treeSaplingPallet
	local v44 = p42:getFillUnitFillLevel(v43.fillUnitIndex)
	local v45 = p42:getFillUnitCapacity(v43.fillUnitIndex)
	for v46 = 1, #v43.saplingNodes do
		local v47 = v43.saplingNodes[v46]
		setVisibility(v47.node, v46 <= MathUtil.round(v44))
		I3DUtil.setShaderParameterRec(v47.node, "hideByIndex", v45 - v44, 0, 0, 0)
	end
end
function TreeSaplingPallet.onFillUnitFillLevelChanged(p48, _, _, _, _, _, _)
	p48:updateTreeSaplingPalletNodes()
end
function TreeSaplingPallet.showInfo(p49, p50, p51)
	local v52 = p49.spec_treeSaplingPallet
	if v52.infoBoxLineTitle ~= nil then
		p51:addLine(v52.infoBoxLineTitle, v52.infoBoxLineValue)
	end
	p50(p49, p51)
end

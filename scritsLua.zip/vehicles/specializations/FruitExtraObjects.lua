FruitExtraObjects = {}
function FruitExtraObjects.prerequisitesPresent(_)
	return true
end
function FruitExtraObjects.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("FruitExtraObjects")
	FruitExtraObjects.registerXMLPaths(v1, "vehicle.cutter.fruitExtraObjects")
	FruitExtraObjects.registerXMLPaths(v1, "vehicle.mower.fruitExtraObjects")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).fruitExtraObjects#lastFruitType", "Name of last fruit type")
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).fruitExtraObjects#lastFillType", "Name of last fill type")
end
function FruitExtraObjects.registerXMLPaths(p3, p4)
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".fruitExtraObject(?)#node", "Name of fruit type converter")
	p3:register(XMLValueType.STRING, p4 .. ".fruitExtraObject(?)#animationName", "Change animation name")
	p3:register(XMLValueType.FLOAT, p4 .. ".fruitExtraObject(?)#animationSpeed", "Speed of the animation", 1)
	p3:register(XMLValueType.BOOL, p4 .. ".fruitExtraObject(?)#isDefault", "Is default active", false)
	p3:register(XMLValueType.STRING, p4 .. ".fruitExtraObject(?)#fruitType", "Name of fruit type")
	p3:register(XMLValueType.STRING, p4 .. ".fruitExtraObject(?)#fillType", "Name of fill type")
	p3:register(XMLValueType.BOOL, p4 .. "#hideOnDetach", "Hide extra objects on detach", false)
	p3:register(XMLValueType.BOOL, p4 .. "#hideOnMount", "Hide extra objects when mounted to a header trailer", false)
end
function FruitExtraObjects.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "loadFruitExtraObjectFromXML", FruitExtraObjects.loadFruitExtraObjectFromXML)
	SpecializationUtil.registerFunction(p5, "getFruitExtraObjectTypeData", FruitExtraObjects.getFruitExtraObjectTypeData)
	SpecializationUtil.registerFunction(p5, "updateFruitExtraObjects", FruitExtraObjects.updateFruitExtraObjects)
end
function FruitExtraObjects.registerOverwrittenFunctions(_) end
function FruitExtraObjects.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", FruitExtraObjects)
	SpecializationUtil.registerEventListener(p6, "onDynamicMountTypeChanged", FruitExtraObjects)
	SpecializationUtil.registerEventListener(p6, "onPreAttach", FruitExtraObjects)
	SpecializationUtil.registerEventListener(p6, "onPostDetach", FruitExtraObjects)
end
function FruitExtraObjects.onPostLoad(p7, p8)
	local v9 = p7.spec_fruitExtraObjects
	if p7.isClient then
		v9.defaultExtraObject = nil
		v9.extraObjects = {}
		for _, v10 in p7.xmlFile:iterator("vehicle.cutter.fruitExtraObjects.fruitExtraObject") do
			local v11 = {}
			if p7:loadFruitExtraObjectFromXML(p7.xmlFile, v10, v11) then
				if v11.isDefault then
					v9.defaultExtraObject = v11
					v11.index = 0
				else
					local v12 = v9.extraObjects
					table.insert(v12, v11)
					v11.index = #v9.extraObjects
				end
			end
		end
		for _, v13 in p7.xmlFile:iterator("vehicle.mower.fruitExtraObjects.fruitExtraObject") do
			local v14 = {}
			if p7:loadFruitExtraObjectFromXML(p7.xmlFile, v13, v14) then
				if v14.isDefault then
					v9.defaultExtraObject = v14
					v14.index = 0
				else
					local v15 = v9.extraObjects
					table.insert(v15, v14)
					v14.index = #v9.extraObjects
				end
			end
		end
		v9.hideExtraObjectsOnDetach = p7.xmlFile:getValue("vehicle.cutter.fruitExtraObjects#hideOnDetach", p7.xmlFile:getValue("vehicle.mower.fruitExtraObjects#hideOnDetach", false))
		v9.hideExtraObjectsOnMount = p7.xmlFile:getValue("vehicle.cutter.fruitExtraObjects#hideOnMount", p7.xmlFile:getValue("vehicle.mower.fruitExtraObjects#hideOnMount", false))
		v9.currentExtraObject = nil
		v9.lastFruitType = nil
		v9.lastFillType = nil
		if p8 ~= nil and not p8.resetVehicles then
			local v16 = p8.xmlFile:getValue(p8.key .. ".fruitExtraObjects#lastFruitType")
			if v16 ~= nil then
				v9.lastFruitType = g_fruitTypeManager:getFruitTypeIndexByName(v16)
			end
			local v17 = p8.xmlFile:getValue(p8.key .. ".fruitExtraObjects#lastFillType")
			if v17 ~= nil then
				v9.lastFillType = g_fillTypeManager:getFillTypeIndexByName(v17)
			end
		end
		p7:updateFruitExtraObjects()
	end
	if not p7.isClient or #v9.extraObjects == 0 and v9.defaultExtraObject == nil then
		SpecializationUtil.removeEventListener(p7, "onLoadFinished", FruitExtraObjects)
		SpecializationUtil.removeEventListener(p7, "onDynamicMountTypeChanged", FruitExtraObjects)
		SpecializationUtil.removeEventListener(p7, "onPreAttach", FruitExtraObjects)
		SpecializationUtil.removeEventListener(p7, "onPostDetach", FruitExtraObjects)
	end
end
function FruitExtraObjects.saveToXMLFile(p18, p19, p20, _)
	local v21 = p18.spec_fruitExtraObjects
	if v21.lastFruitType ~= nil then
		p19:setValue(p20 .. "#lastFruitType", g_fruitTypeManager:getFruitTypeNameByIndex(v21.lastFruitType))
	end
	if v21.lastFillType ~= nil then
		p19:setValue(p20 .. "#lastFillType", g_fillTypeManager:getFillTypeNameByIndex(v21.lastFillType))
	end
end
function FruitExtraObjects.onDynamicMountTypeChanged(p22, _, _)
	p22:updateFruitExtraObjects()
end
function FruitExtraObjects.onPreAttach(p23, _, _, _)
	p23:updateFruitExtraObjects()
end
function FruitExtraObjects.onPostDetach(p24, _, _)
	p24:updateFruitExtraObjects()
end
function FruitExtraObjects.loadFruitExtraObjectFromXML(p25, p26, p27, p28)
	XMLUtil.checkDeprecatedXMLElements(p26, p27 .. "#anim", p27 .. "#animationName")
	p28.node = p26:getValue(p27 .. "#node", nil, p25.components, p25.i3dMappings)
	if p28.node ~= nil then
		setVisibility(p28.node, false)
	end
	p28.animationName = p26:getValue(p27 .. "#animationName")
	if p28.node ~= nil or p28.animationName ~= nil then
		p28.isDefault = p26:getValue(p27 .. "#isDefault", false)
		p28.animationSpeed = p26:getValue(p27 .. "#animationSpeed", 1)
		local v29 = p25.xmlFile:getValue(p27 .. "#fruitType")
		if v29 ~= nil then
			local v30 = g_fruitTypeManager:getFruitTypeIndexByName(string.upper(v29))
			if v30 ~= nil then
				p28.fruitType = v30
			end
		end
		local v31 = p25.xmlFile:getValue(p27 .. "#fillType")
		if v31 ~= nil then
			local v32 = g_fillTypeManager:getFillTypeIndexByName(string.upper(v31))
			if v32 ~= nil then
				p28.fillType = v32
			end
		end
		if p28.fruitType == nil and (p28.fillType == nil and not p28.isDefault) then
			Logging.xmlWarning(p26, "Missing fruitType/fillType or isDefault attribute for \'%s\'", p27)
			return false
		end
		if (p28.fruitType ~= nil or p28.fillType ~= nil) and p28.isDefault then
			Logging.xmlWarning(p26, "FruitType/fillType and isDefault attribute are defined for \'%s\'. Only one is allowed!", p27)
			return false
		end
	end
	return true
end
function FruitExtraObjects.getFruitExtraObjectTypeData(_)
	return nil, nil
end
function FruitExtraObjects.updateFruitExtraObjects(p33)
	local v34 = p33.spec_fruitExtraObjects
	local _ = v34.currentExtraObject
	local v35, v36 = p33:getFruitExtraObjectTypeData()
	if (v35 == nil or v35 == FruitType.UNKNOWN) and v34.lastFruitType ~= nil then
		v35 = v34.lastFruitType
	end
	v34.lastFruitType = v35
	if (v36 == nil or v36 == FillType.UNKNOWN) and v34.lastFillType ~= nil then
		v36 = v34.lastFillType
	end
	v34.lastFillType = v36
	local v37 = v34.defaultExtraObject
	for _, v38 in ipairs(v34.extraObjects) do
		if v35 ~= nil and v38.fruitType == v35 or v36 ~= nil and v38.fillType == v36 then
			v37 = v38
			break
		end
	end
	if v34.hideExtraObjectsOnDetach and (p33.getAttacherVehicle == nil or p33:getAttacherVehicle() == nil) then
		v37 = nil
	end
	if v34.hideExtraObjectsOnMount and p33.dynamicMountType ~= MountableObject.MOUNT_TYPE_NONE then
		v37 = nil
	end
	if v37 ~= v34.currentExtraObject then
		if v34.currentExtraObject ~= nil then
			if v34.currentExtraObject.node ~= nil then
				setVisibility(v34.currentExtraObject.node, false)
			end
			if v34.currentExtraObject.animationName ~= nil and p33.playAnimation ~= nil then
				p33:playAnimation(v34.currentExtraObject.animationName, -v34.currentExtraObject.animationSpeed, p33:getAnimationTime(v34.currentExtraObject.animationName), true)
			end
			v34.currentExtraObject = nil
		end
		if v37 ~= nil then
			if v37.node ~= nil then
				setVisibility(v37.node, true)
			end
			if v37.animationName ~= nil and p33.playAnimation ~= nil then
				p33:playAnimation(v37.animationName, v37.animationSpeed, p33:getAnimationTime(v37.animationName), true)
				if not p33.finishedLoading then
					AnimatedVehicle.updateAnimationByName(p33, v37.animationName, 9999999, true)
				end
			end
			v34.currentExtraObject = v37
		end
	end
end

Washable = {}
Washable.SEND_NUM_BITS = 6
Washable.SEND_MAX_VALUE = 2 ^ Washable.SEND_NUM_BITS - 1
Washable.SEND_THRESHOLD = 1 / Washable.SEND_MAX_VALUE
Washable.SEND_NUM_BITS_WETNESS = 4
Washable.SEND_MAX_VALUE_WETNESS = 2 ^ Washable.SEND_NUM_BITS_WETNESS - 1
Washable.SEND_THRESHOLD_WETNESS = 1 / Washable.SEND_MAX_VALUE_WETNESS
Washable.WASHTYPE_HIGH_PRESSURE_WASHER = 1
Washable.WASHTYPE_RAIN = 2
Washable.WASHTYPE_TRIGGER = 3
Washable.SHADER_PARAMETERS = { "scratches_dirt_snow_wetness", "mudAmount" }
function Washable.prerequisitesPresent(_)
	return true
end
function Washable.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Washable")
	v1:register(XMLValueType.FLOAT, "vehicle.washable#dirtDuration", "Duration until fully dirty (minutes)", 90)
	v1:register(XMLValueType.FLOAT, "vehicle.washable#washDuration", "Duration until fully clean (minutes)", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.washable#rainWashDuration", "Duration until fully clean when it rains (minutes)", 10)
	v1:register(XMLValueType.FLOAT, "vehicle.washable#wetDuration", "Duration until fully wet (minutes)", 2)
	v1:register(XMLValueType.FLOAT, "vehicle.washable#dryDuration", "Duration until the vehicle is fully dry again (minutes)", 10)
	v1:register(XMLValueType.FLOAT, "vehicle.washable#workMultiplier", "Multiplier while working", 4)
	v1:register(XMLValueType.FLOAT, "vehicle.washable#fieldMultiplier", "Multiplier while on field", 2)
	v1:register(XMLValueType.FLOAT, "vehicle.washable#wetMultiplier", "Multiplier while on it\'s wet", 5)
	v1:register(XMLValueType.STRING, "vehicle.washable#blockedWashTypes", "Block specific ways to clean vehicle (HIGH_PRESSURE_WASHER, RAIN, TRIGGER)")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.washable.wetnessIgnoreNode(?)#node", "Node, including it\'s children will never get wet")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).washable.dirtNode(?)#amount", "Dirt amount")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).washable.dirtNode(?)#snowScale", "Snow scale")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).washable.dirtNode(?)#wetness", "Wetness")
end
function Washable.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "cleanVehicle", Washable.cleanVehicle)
	SpecializationUtil.registerFunction(p3, "updateDirtAmount", Washable.updateDirtAmount)
	SpecializationUtil.registerFunction(p3, "addDirtAmount", Washable.addDirtAmount)
	SpecializationUtil.registerFunction(p3, "getDirtAmount", Washable.getDirtAmount)
	SpecializationUtil.registerFunction(p3, "setNodeDirtAmount", Washable.setNodeDirtAmount)
	SpecializationUtil.registerFunction(p3, "getNodeDirtAmount", Washable.getNodeDirtAmount)
	SpecializationUtil.registerFunction(p3, "setNodeDirtColor", Washable.setNodeDirtColor)
	SpecializationUtil.registerFunction(p3, "updateWetness", Washable.updateWetness)
	SpecializationUtil.registerFunction(p3, "getIsWet", Washable.getIsWet)
	SpecializationUtil.registerFunction(p3, "addWetnessAmount", Washable.addWetnessAmount)
	SpecializationUtil.registerFunction(p3, "setNodeWetness", Washable.setNodeWetness)
	SpecializationUtil.registerFunction(p3, "addAllSubWashableNodes", Washable.addAllSubWashableNodes)
	SpecializationUtil.registerFunction(p3, "addWashableNodes", Washable.addWashableNodes)
	SpecializationUtil.registerFunction(p3, "addWashableNode", Washable.addWashableNode)
	SpecializationUtil.registerFunction(p3, "validateWashableNode", Washable.validateWashableNode)
	SpecializationUtil.registerFunction(p3, "addToGlobalWashableNode", Washable.addToGlobalWashableNode)
	SpecializationUtil.registerFunction(p3, "getWashableNodeByCustomIndex", Washable.getWashableNodeByCustomIndex)
	SpecializationUtil.registerFunction(p3, "addToLocalWashableNode", Washable.addToLocalWashableNode)
	SpecializationUtil.registerFunction(p3, "removeAllSubWashableNodes", Washable.removeAllSubWashableNodes)
	SpecializationUtil.registerFunction(p3, "removeWashableNode", Washable.removeWashableNode)
	SpecializationUtil.registerFunction(p3, "getDirtMultiplier", Washable.getDirtMultiplier)
	SpecializationUtil.registerFunction(p3, "getWorkDirtMultiplier", Washable.getWorkDirtMultiplier)
	SpecializationUtil.registerFunction(p3, "getWashDuration", Washable.getWashDuration)
	SpecializationUtil.registerFunction(p3, "getAllowsWashingByType", Washable.getAllowsWashingByType)
end
function Washable.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", Washable)
	SpecializationUtil.registerEventListener(p4, "onLoadFinished", Washable)
	SpecializationUtil.registerEventListener(p4, "onReadStream", Washable)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", Washable)
	SpecializationUtil.registerEventListener(p4, "onReadUpdateStream", Washable)
	SpecializationUtil.registerEventListener(p4, "onWriteUpdateStream", Washable)
	SpecializationUtil.registerEventListener(p4, "onUpdateTick", Washable)
end
function Washable.onLoad(p5, _)
	local v6 = p5.spec_washable
	v6.wetnessIgnoreNodes = {}
	for _, v7 in p5.xmlFile:iterator("vehicle.washable.wetnessIgnoreNode") do
		local v8 = p5.xmlFile:getValue(v7 .. "#node", nil, p5.components, p5.i3dMappings)
		if v8 == nil then
			Logging.xmlWarning(p5.xmlFile, "Invalid node for wetnessIgnoreNode \'%s\'", v7)
		else
			v6.wetnessIgnoreNodes[v8] = true
		end
	end
	v6.washableNodes = {}
	v6.washableNodesByIndex = {}
	p5:addToLocalWashableNode(nil, Washable.updateDirtAmount, nil, nil)
	v6.globalWashableNode = v6.washableNodes[1]
	v6.dirtDuration = p5.xmlFile:getValue("vehicle.washable#dirtDuration", 90) * 60 * 1000
	if v6.dirtDuration ~= 0 then
		v6.dirtDuration = 1 / v6.dirtDuration
	end
	local v9 = p5.xmlFile:getValue("vehicle.washable#washDuration", 1) * 60 * 1000
	v6.washDuration = math.max(v9, 0.00001)
	local v10 = p5.xmlFile:getValue("vehicle.washable#rainWashDuration", 1) * 60 * 1000
	v6.rainWashDuration = math.max(v10, 0.00001)
	v6.wetDuration = p5.xmlFile:getValue("vehicle.washable#wetDuration", 2) / 60 / 1000
	local v11 = p5.xmlFile:getValue("vehicle.washable#dryDuration", 10) * 60 * 1000
	v6.dryDuration = 1 / math.max(v11, 0.0001)
	v6.workMultiplier = p5.xmlFile:getValue("vehicle.washable#workMultiplier", 4)
	v6.fieldMultiplier = p5.xmlFile:getValue("vehicle.washable#fieldMultiplier", 2)
	v6.wetMultiplier = p5.xmlFile:getValue("vehicle.washable#wetMultiplier", 5)
	v6.blockedWashTypes = {}
	local v12 = p5.xmlFile:getValue("vehicle.washable#blockedWashTypes")
	if v12 ~= nil then
		local v13 = v12:split(" ")
		for _, v14 in pairs(v13) do
			local v15 = "WASHTYPE_" .. v14
			if Washable[v15] == nil then
				Logging.xmlWarning(p5.xmlFile, "Unknown wash type \'%s\' in \'%s\'", v15, "vehicle.washable#blockedWashTypes")
			else
				v6.blockedWashTypes[Washable[v15]] = true
			end
		end
	end
	v6.lastDirtMultiplier = 0
	v6.dirtyFlag = p5:getNextDirtyFlag()
	if p5.propertyState == VehiclePropertyState.SHOP_CONFIG then
		SpecializationUtil.removeEventListener(p5, "onLoadFinished", Washable)
		SpecializationUtil.removeEventListener(p5, "onUpdateTick", Washable)
	end
end
function Washable.onLoadFinished(p16, p17)
	local v18 = p16.spec_washable
	for _, v19 in pairs(p16.components) do
		p16:addAllSubWashableNodes(v19.node)
	end
	if p17 == nil or Washable.getIntervalMultiplier() == 0 then
		for v20 = 1, #v18.washableNodes do
			p16:setNodeDirtAmount(v18.washableNodes[v20], 0, true)
		end
	else
		for v21 = 1, #v18.washableNodes do
			local v22 = v18.washableNodes[v21]
			local v23 = string.format("%s.washable.dirtNode(%d)", p17.key, v21 - 1)
			p16:setNodeDirtAmount(v22, p17.xmlFile:getValue(v23 .. "#amount", 0), true)
			p16:setNodeWetness(v22, p17.xmlFile:getValue(v23 .. "#wetness", 0), true)
			if v22.loadFromSavegameFunc ~= nil then
				v22.loadFromSavegameFunc(p17.xmlFile, v23)
			end
		end
	end
end
function Washable.saveToXMLFile(p24, p25, p26, _)
	local v27 = p24.spec_washable
	for v28 = 1, #v27.washableNodes do
		local v29 = v27.washableNodes[v28]
		local v30 = string.format("%s.dirtNode(%d)", p26, v28 - 1)
		p25:setValue(v30 .. "#amount", v29.dirtAmount)
		p25:setValue(v30 .. "#wetness", v29.wetness)
		if v29.saveToSavegameFunc ~= nil then
			v29.saveToSavegameFunc(p25, v30)
		end
	end
end
function Washable.onReadStream(p31, p32, p33)
	Washable.readWashableNodeData(p31, p32, p33)
end
function Washable.onWriteStream(p34, p35, p36)
	Washable.writeWashableNodeData(p34, p35, p36)
end
function Washable.onReadUpdateStream(p37, p38, _, p39)
	if p39:getIsServer() and (p37.spec_washable.washableNodes ~= nil and streamReadBool(p38)) then
		Washable.readWashableNodeData(p37, p38, p39)
	end
end
function Washable.onWriteUpdateStream(p40, p41, p42, p43)
	if not p42:getIsServer() then
		local v44 = p40.spec_washable
		if streamWriteBool(p41, bitAND(p43, v44.dirtyFlag) ~= 0) then
			Washable.writeWashableNodeData(p40, p41, p42)
		end
	end
end
function Washable.readWashableNodeData(p45, p46, _)
	local v47 = p45.spec_washable
	for v48 = 1, #v47.washableNodes do
		local v49 = v47.washableNodes[v48]
		p45:setNodeDirtAmount(v49, streamReadUIntN(p46, Washable.SEND_NUM_BITS) / Washable.SEND_MAX_VALUE, true)
		p45:setNodeWetness(v49, streamReadUIntN(p46, Washable.SEND_NUM_BITS_WETNESS) / Washable.SEND_MAX_VALUE_WETNESS, true)
		if streamReadBool(p46) then
			p45:setNodeDirtColor(v49, streamReadUIntN(p46, Washable.SEND_NUM_BITS) / Washable.SEND_MAX_VALUE, streamReadUIntN(p46, Washable.SEND_NUM_BITS) / Washable.SEND_MAX_VALUE, streamReadUIntN(p46, Washable.SEND_NUM_BITS) / Washable.SEND_MAX_VALUE, true)
		end
	end
end
function Washable.writeWashableNodeData(p50, p51, _)
	local v52 = p50.spec_washable
	for v53 = 1, #v52.washableNodes do
		local v54 = v52.washableNodes[v53]
		local v55 = streamWriteUIntN
		local v56 = v54.dirtAmount * Washable.SEND_MAX_VALUE + 0.5
		v55(p51, math.floor(v56), Washable.SEND_NUM_BITS)
		local v57 = streamWriteUIntN
		local v58 = v54.wetness * Washable.SEND_MAX_VALUE_WETNESS + 0.5
		v57(p51, math.floor(v58), Washable.SEND_NUM_BITS_WETNESS)
		streamWriteBool(p51, v54.colorChanged)
		if v54.colorChanged then
			local v59 = streamWriteUIntN
			local v60 = v54.color[1] * Washable.SEND_MAX_VALUE + 0.5
			v59(p51, math.floor(v60), Washable.SEND_NUM_BITS)
			local v61 = streamWriteUIntN
			local v62 = v54.color[2] * Washable.SEND_MAX_VALUE + 0.5
			v61(p51, math.floor(v62), Washable.SEND_NUM_BITS)
			local v63 = streamWriteUIntN
			local v64 = v54.color[3] * Washable.SEND_MAX_VALUE + 0.5
			v63(p51, math.floor(v64), Washable.SEND_NUM_BITS)
			v54.colorChanged = false
		end
	end
end
function Washable.onUpdateTick(p65, p66, _, _, _)
	if p65.isServer then
		local v67 = p65.spec_washable
		v67.lastDirtMultiplier = p65:getDirtMultiplier() * Washable.getIntervalMultiplier() * Platform.gameplay.dirtDurationScale
		local v68 = p65:getAllowsWashingByType(Washable.WASHTYPE_RAIN)
		local v69, v70, v71
		if v68 then
			local v72 = g_currentMission.environment.weather
			v69 = v72:getRainFallScale()
			v70 = v72:getTimeSinceLastRain()
			v71 = v72:getCurrentTemperature()
		else
			v70 = 0
			v71 = 0
			v69 = 0
		end
		for v73 = 1, #v67.washableNodes do
			local v74 = v67.washableNodes[v73]
			local v75, v76 = v74.updateFunc(p65, v74, p66, v68, v69, v70, v71)
			if v75 ~= 0 then
				p65:setNodeDirtAmount(v74, v74.dirtAmount + v75)
			end
			if v76 ~= 0 then
				p65:setNodeWetness(v74, v74.wetness + v76)
			end
		end
	end
end
function Washable.cleanVehicle(p77, p78)
	local v79 = p77.spec_washable
	for v80 = 1, #v79.washableNodes do
		local v81 = v79.washableNodes[v80]
		local v82 = p78 * (v81.cleaningMultiplier or 1)
		p77:setNodeDirtAmount(v81, v81.dirtAmount - v82, true)
		p77:setNodeWetness(v81, v81.wetness + v82 * 5, true)
	end
end
function Washable.updateDirtAmount(p83, p84, p85, p86, p87, p88, p89)
	local v90 = p83.spec_washable
	local v91 = 0
	local v92 = v90.lastDirtMultiplier
	local v93 = (not p86 or (p87 <= 0.1 or (p88 >= 30 or (p89 <= 0 or (p84.dirtAmount <= 0.5 or p83:getIsOnField() and p83:getLastSpeed() >= 1))))) and 0 or -(p85 / v90.rainWashDuration)
	if p89 > 0 and (p87 > 0.1 and p88 < 30) then
		v92 = v92 * 2.5
	end
	if v92 ~= 0 then
		v93 = p85 * v90.dirtDuration * v92
	end
	return v93, v91
end
function Washable.addDirtAmount(p94, p95, p96)
	local v97 = p94.spec_washable
	for v98 = 1, #v97.washableNodes do
		local v99 = v97.washableNodes[v98]
		p94:setNodeDirtAmount(v99, v99.dirtAmount + p95, p96)
	end
end
function Washable.getDirtAmount(p100)
	local v101 = p100.spec_washable
	local v102 = 0
	for v103 = 1, #v101.washableNodes do
		v102 = v102 + v101.washableNodes[v103].dirtAmount
	end
	return v102 / #v101.washableNodes
end
function Washable.setNodeDirtAmount(p104, p105, p106, p107)
	local v108 = p104.spec_washable
	p105.dirtAmount = math.clamp(p106, 0, 1)
	local v109 = p105.dirtAmountSent - p105.dirtAmount
	if math.abs(v109) > Washable.SEND_THRESHOLD or p107 then
		for v110, _ in pairs(p105.nodes) do
			setShaderParameter(v110, "scratches_dirt_snow_wetness", nil, p105.dirtAmount, nil, nil, false)
		end
		for v111, _ in pairs(p105.mudNodes) do
			g_animationManager:setPrevShaderParameter(v111, "mudAmount", p105.dirtAmount, 0, 0, 0, false, "prevMudAmount")
		end
		if p104.isServer then
			p104:raiseDirtyFlags(v108.dirtyFlag)
			p105.dirtAmountSent = p105.dirtAmount
		end
	end
end
function Washable.getNodeDirtAmount(_, p112)
	return p112.dirtAmount
end
function Washable.setNodeDirtColor(p113, p114, p115, p116, p117, p118)
	local v119 = p113.spec_washable
	local v120 = p114.color[1]
	local v121 = p114.color[2]
	local v122 = p114.color[3]
	local v123 = p115 - v120
	if math.abs(v123) <= Washable.SEND_THRESHOLD then
		local v124 = p116 - v121
		if math.abs(v124) <= Washable.SEND_THRESHOLD then
			local v125 = p117 - v122
			if math.abs(v125) <= Washable.SEND_THRESHOLD and not p118 then
				::l5::
				return
			end
		end
	end
	for v126, _ in pairs(p114.nodes) do
		setShaderParameter(v126, "dirtColor", p115, p116, p117, nil, false)
	end
	for v127, _ in pairs(p114.mudNodes) do
		setShaderParameter(v127, "dirtColor", p115, p116, p117, nil, false)
	end
	local v128 = p114.color
	local v129 = p114.color
	local v130 = p114.color
	v128[1] = p115
	v129[2] = p116
	v130[3] = p117
	if p113.isServer then
		p113:raiseDirtyFlags(v119.dirtyFlag)
		p114.colorChanged = true
	end
	goto l5
end
function Washable.updateWetness(p131, p132, p133)
	local v134 = p131.spec_washable
	local v135
	if p132 then
		local v136 = p133 * v134.wetDuration
		local v137 = p131.lastSpeed * 3600 / 10
		v135 = v136 * (1 + math.min(v137, 1))
	else
		v135 = nil
	end
	for v138 = 1, #v134.washableNodes do
		local v139 = v134.washableNodes[v138]
		if not p132 then
			local v140 = (1 - v139.dirtAmount) * 0.5 + 0.5
			local v141 = -p133 * v134.dryDuration * v140
			local v142 = p131.lastSpeed * 3600 / 10
			v135 = v141 * (1 + math.min(v142, 1))
		end
		p131:setNodeWetness(v139, v139.wetness + v135)
	end
end
function Washable.getIsWet(p143)
	for _, v144 in pairs(p143.spec_washable.washableNodes) do
		if v144.wetness > 0 then
			return true
		end
	end
	return false
end
function Washable.addWetnessAmount(p145, p146)
	local v147 = p145.spec_washable
	for v148 = 1, #v147.washableNodes do
		local v149 = v147.washableNodes[v148]
		p145:setNodeWetness(v149, v149.wetness + p146)
	end
end
function Washable.setNodeWetness(p150, p151, p152, p153)
	local v154 = p150.spec_washable
	p151.wetness = math.clamp(p152, 0, 1)
	local v155 = p151.wetnessSent - p151.wetness
	if math.abs(v155) > Washable.SEND_THRESHOLD_WETNESS or p153 then
		for v156, v157 in pairs(p151.nodes) do
			if v157 then
				setShaderParameter(v156, "scratches_dirt_snow_wetness", nil, nil, nil, p151.wetness, false)
			end
		end
		for v158, v159 in pairs(p151.mudNodes) do
			if v159 then
				setShaderParameter(v158, "wetness", p151.wetness, nil, nil, nil, false)
			end
		end
		if p150.isServer then
			p150:raiseDirtyFlags(v154.dirtyFlag)
			p151.wetnessSent = p151.wetness
		end
	end
end
function Washable.addAllSubWashableNodes(p160, p161)
	if p161 ~= nil then
		I3DUtil.iterateShaderParametersNodesRecursively(p161, Washable.SHADER_PARAMETERS, p160.addWashableNode, p160)
	end
	p160:addDirtAmount(0, true)
end
function Washable.addWashableNodes(p162, p163)
	for _, v164 in ipairs(p163) do
		p162:addWashableNode(v164)
	end
end
function Washable.addWashableNode(p165, p166)
	local v167, v168, v169, v170 = p165:validateWashableNode(p166)
	if v167 then
		p165:addToGlobalWashableNode(p166)
	elseif v168 ~= nil then
		p165:addToLocalWashableNode(p166, v168, v169, v170)
	end
end
function Washable.validateWashableNode(_, _)
	return true, nil
end
function Washable.addToGlobalWashableNode(p171, p172)
	local v173 = p171.spec_washable
	if v173.washableNodes[1] ~= nil then
		local v174 = true
		if next(v173.wetnessIgnoreNodes) ~= nil then
			local v175 = p172
			while true do
				if p172 == 0 then
					p172 = v175
					break
				end
				if v173.wetnessIgnoreNodes[p172] == true then
					p172 = v175
					v174 = false
					break
				end
				p172 = getParent(p172)
			end
		end
		v173.washableNodes[1].nodes[p172] = v174
	end
end
function Washable.getWashableNodeByCustomIndex(p176, p177)
	return p176.spec_washable.washableNodesByIndex[p177]
end
function Washable.addToLocalWashableNode(p178, p179, p180, p181, p182)
	local v183 = p178.spec_washable
	local v184 = true
	if p179 ~= nil and next(v183.wetnessIgnoreNodes) ~= nil then
		local v185 = p179
		while true do
			if p179 == 0 then
				p179 = v185
				break
			end
			if v183.wetnessIgnoreNodes[p179] == true then
				p179 = v185
				v184 = false
				break
			end
			p179 = getParent(p179)
		end
	end
	local v186 = {}
	if p181 ~= nil then
		if v183.washableNodesByIndex[p181] ~= nil then
			if getHasShaderParameter(p179, "scratches_dirt_snow_wetness") then
				v183.washableNodesByIndex[p181].nodes[p179] = v184
			else
				v183.washableNodesByIndex[p181].mudNodes[p179] = v184
			end
		end
		v183.washableNodesByIndex[p181] = v186
	end
	v186.nodes = {}
	v186.mudNodes = {}
	if p179 ~= nil then
		if getHasShaderParameter(p179, "scratches_dirt_snow_wetness") then
			v186.nodes[p179] = v184
		else
			v186.mudNodes[p179] = v184
		end
	end
	v186.updateFunc = p180
	v186.dirtAmount = 0
	v186.dirtAmountSent = 0
	v186.wetness = 0
	v186.wetnessSent = 0
	v186.colorChanged = false
	local v187, _ = g_currentMission.environment:getDirtColors()
	v186.color = { v187[1], v187[2], v187[3] }
	v186.defaultColor = { v187[1], v187[2], v187[3] }
	if p182 ~= nil then
		for v188, v189 in pairs(p182) do
			v186[v188] = v189
		end
	end
	local v190 = v183.washableNodes
	table.insert(v190, v186)
end
function Washable.removeAllSubWashableNodes(p191, p192)
	if p192 ~= nil then
		I3DUtil.iterateShaderParametersNodesRecursively(p192, Washable.SHADER_PARAMETERS, p191.removeWashableNode, p191)
	end
end
function Washable.removeWashableNode(p193, p194)
	local v195 = p193.spec_washable
	if p194 ~= nil then
		for v196 = 1, #v195.washableNodes do
			v195.washableNodes[v196].nodes[p194] = nil
			v195.washableNodes[v196].mudNodes[p194] = nil
		end
	end
end
function Washable.getDirtMultiplier(p197)
	local v198 = p197.spec_washable
	local v199 = p197:getLastSpeed() < 1 and 0 or 1
	if p197:getIsOnField() then
		v199 = v199 * v198.fieldMultiplier
		local v200 = g_currentMission.environment.weather:getGroundWetness()
		if v200 > 0 then
			v199 = v199 * (1 + v200 * v198.wetMultiplier)
		end
	end
	return v199
end
function Washable.getWorkDirtMultiplier(p201)
	return p201.spec_washable.workMultiplier
end
function Washable.getWashDuration(p202)
	return p202.spec_washable.washDuration
end
function Washable.getIntervalMultiplier()
	return g_currentMission.missionInfo.dirtInterval == 1 and 0 or (g_currentMission.missionInfo.dirtInterval == 2 and 0.25 or (g_currentMission.missionInfo.dirtInterval == 3 and 0.5 or (g_currentMission.missionInfo.dirtInterval == 4 and 1 or 1)))
end
function Washable.getAllowsWashingByType(p203, p204)
	return p203.spec_washable.blockedWashTypes[p204] == nil
end
function Washable.updateDebugValues(p205, p206)
	local v207 = p205.spec_washable
	if v207.washableNodes ~= nil then
		local v208 = p205:getAllowsWashingByType(Washable.WASHTYPE_RAIN)
		local v209, v210, v211
		if v208 then
			local v212 = g_currentMission.environment.weather
			v209 = v212:getRainFallScale()
			v210 = v212:getTimeSinceLastRain()
			v211 = v212:getCurrentTemperature()
		else
			v209 = 0
			v210 = 0
			v211 = 0
		end
		local v213
		if v209 > 0.1 and v210 < 30 then
			v213 = v211 > 0
		else
			v213 = false
		end
		local v214
		if v213 then
			local v215 = 3600000 * v207.wetDuration
			local v216 = p205.lastSpeed * 3600 / 10
			v214 = v215 * (1 + math.min(v216, 1))
		else
			v214 = 0
		end
		local v217 = {
			["name"] = "Dirt Multiplier",
			["value"] = string.format("%.3f", p205:getDirtMultiplier())
		}
		table.insert(p206, v217)
		for v218, v219 in ipairs(v207.washableNodes) do
			local v220, v221 = v219.updateFunc(p205, v219, 3600000, v208, v209, v210, v211)
			local v222
			if v213 then
				v222 = v221 + v214
			else
				local v223 = (1 - v219.dirtAmount) * 0.5 + 0.5
				local v224 = 3600000 * v207.dryDuration * v223
				local v225 = p205.lastSpeed * 3600 / 10
				v222 = v221 - v224 * (1 + math.min(v225, 1))
			end
			local v226 = {
				["name"] = "WashableNode" .. v218,
				["value"] = string.format("%.4f a/h (%.2f) (color %.2f %.2f %.2f) (wetness: %.2f , %.4f a/min)", v220, v207.washableNodes[v218].dirtAmount, v219.color[1], v219.color[2], v219.color[3], v219.wetness, v222 / 60)
			}
			table.insert(p206, v226)
		end
	end
end

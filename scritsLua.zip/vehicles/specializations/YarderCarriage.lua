YarderCarriage = {}
YarderCarriage.TREE_RAYCAST_DISTANCE = 5
YarderCarriage.ROPE_MAX_LIMIT_OFFSET = 2.5
source("dataS/scripts/vehicles/specializations/events/TreeAttachEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TreeAttachRequestEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TreeAttachResponseEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TreeDetachEvent.lua")
function YarderCarriage.prerequisitesPresent(_)
	return true
end
function YarderCarriage.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("YarderCarriage")
	v1:register(XMLValueType.INT, "vehicle.yarderCarriage#maxNumTrees", "Max. number of trees that can be attached", 4)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage#maxTreeMass", "Max. total tree mass that can be attached (to)", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage#length", "Total length off carriage to calculate the offset to start and end correctly", 2)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage#rollSpacing", "Spacing between the rolls to calculate the rotation correctly", 0.75)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage#liftSpeed", "Lifting speed [m/sec]", 2)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage#liftAcceleration", "Lifting acceleration (time in seconds until full speed is reached)", 0.75)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage#pullRopeTargetNode", "Target connection node for pull rope")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage#pushRopeTargetNode", "Target connection node for push rope")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.ropeAlignmentNode(?)#node", "Node is aligned to the rope in x and y axis")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.joint#node", "Attach joint node")
	v1:register(XMLValueType.TIME, "vehicle.yarderCarriage.joint#attachTime", "Time until the tree is fully attached", 0.5)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage.joint#minDistance", "Min. distance of the rope", 0.5)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage.joint#maxDistance", "Max. distance of the rope", 10)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.rope#originNode", "Rope origin node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.rope#rootHook", "Root hook node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.rope#rootHookReferenceNode", "Root hook reference node placed at the end of the hook")
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage.rope#treeRopeLength", "Length of the rope from the root hook to the tree", 1)
	ForestryRope.registerXMLPaths(v1, "vehicle.yarderCarriage.rope.mainRope")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.rope.attach#mainNode", "Outgoing node for main tree attach rope (used for dummy rope display)")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.rope.attach#additionalNode", "Outgoing node for additional tree attach rope (used for dummy rope display)")
	ForestryRope.registerXMLPaths(v1, "vehicle.yarderCarriage.rope.attach.mainRope")
	ForestryRope.registerXMLPaths(v1, "vehicle.yarderCarriage.rope.attach.additionalRope")
	TargetTreeMarker.registerXMLPaths(v1, "vehicle.yarderCarriage.rope.attach.marker")
	v1:register(XMLValueType.INT, "vehicle.yarderCarriage.rope.componentJoint#index", "Component joint index")
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.yarderCarriage.rope.componentJoint#rotLimitInactive", "Component joint rot limit while tree(s) not attached")
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.yarderCarriage.rope.componentJoint#rotLimitActive", "Component joint rot limit while tree(s) attached")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.additionalRopes.additionalRope(?)#referenceNode", "Node at the end of the hook for placement of the rope")
	ForestryRope.registerXMLPaths(v1, "vehicle.yarderCarriage.additionalRopes.additionalRope(?).rope")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderCarriage.additionalRopes.additionalRope(?).hookNode(?)#node", "Node to align to target point")
	v1:register(XMLValueType.BOOL, "vehicle.yarderCarriage.additionalRopes.additionalRope(?).hookNode(?)#alignYRot", "Node is only aligned on y axis", false)
	v1:register(XMLValueType.BOOL, "vehicle.yarderCarriage.additionalRopes.additionalRope(?).hookNode(?)#alignXRot", "Node is only aligned on x axis", false)
	v1:register(XMLValueType.ANGLE, "vehicle.yarderCarriage.additionalRopes.additionalRope(?).hookNode(?)#minRot", "Min. rotation value for only y or x alignment", -180)
	v1:register(XMLValueType.ANGLE, "vehicle.yarderCarriage.additionalRopes.additionalRope(?).hookNode(?)#maxRot", "Max. rotation value for only y or x alignment", 180)
	v1:register(XMLValueType.BOOL, "vehicle.yarderCarriage.additionalRopes.additionalRope(?).hookNode(?)#alignToTarget", "Node is only aligned on all axis", true)
	ObjectChangeUtil.registerObjectChangeXMLPaths(v1, "vehicle.yarderCarriage.rope")
	v1:register(XMLValueType.FLOAT, "vehicle.yarderCarriage.treeHook#offset", "Hook offset from tree", 0.01)
	v1:register(XMLValueType.STRING, "vehicle.yarderCarriage.treeHook#tensionBeltType", "Name of tension belt type used for tree hook", "forestryTreeBelt")
	ForestryHook.registerXMLPaths(v1, "vehicle.yarderCarriage.treeHook")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderCarriage.sounds", "attachTree")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderCarriage.sounds", "detachTree")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderCarriage.sounds", "lift")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderCarriage.sounds", "lower")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderCarriage.sounds", "liftLimit")
	v1:setXMLSpecializationType()
end
function YarderCarriage.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "getCarriageDimensions", YarderCarriage.getCarriageDimensions)
	SpecializationUtil.registerFunction(p2, "getCarriagePullRopeTargetNode", YarderCarriage.getCarriagePullRopeTargetNode)
	SpecializationUtil.registerFunction(p2, "getCarriagePushRopeTargetNode", YarderCarriage.getCarriagePushRopeTargetNode)
	SpecializationUtil.registerFunction(p2, "setYarderTowerVehicle", YarderCarriage.setYarderTowerVehicle)
	SpecializationUtil.registerFunction(p2, "updateRopeAlignmentNodes", YarderCarriage.updateRopeAlignmentNodes)
	SpecializationUtil.registerFunction(p2, "updateCarriageInRange", YarderCarriage.updateCarriageInRange)
	SpecializationUtil.registerFunction(p2, "onYarderCarriageUpdateEnd", YarderCarriage.onYarderCarriageUpdateEnd)
	SpecializationUtil.registerFunction(p2, "updateTreeAttachRopes", YarderCarriage.updateTreeAttachRopes)
	SpecializationUtil.registerFunction(p2, "onCarriageTreeRaycastCallback", YarderCarriage.onCarriageTreeRaycastCallback)
	SpecializationUtil.registerFunction(p2, "onAttachTreeAction", YarderCarriage.onAttachTreeAction)
	SpecializationUtil.registerFunction(p2, "attachTreeToCarriage", YarderCarriage.attachTreeToCarriage)
	SpecializationUtil.registerFunction(p2, "createJoint", YarderCarriage.createJoint)
	SpecializationUtil.registerFunction(p2, "onDetachTreeAction", YarderCarriage.onDetachTreeAction)
	SpecializationUtil.registerFunction(p2, "detachTreeFromCarriage", YarderCarriage.detachTreeFromCarriage)
	SpecializationUtil.registerFunction(p2, "getNumAttachedTrees", YarderCarriage.getNumAttachedTrees)
	SpecializationUtil.registerFunction(p2, "getMaxNumAttachedTrees", YarderCarriage.getMaxNumAttachedTrees)
	SpecializationUtil.registerFunction(p2, "getAttachedTreeMass", YarderCarriage.getAttachedTreeMass)
	SpecializationUtil.registerFunction(p2, "getIsCarriageTreeAttachAllowed", YarderCarriage.getIsCarriageTreeAttachAllowed)
	SpecializationUtil.registerFunction(p2, "getIsTreeInMountRange", YarderCarriage.getIsTreeInMountRange)
	SpecializationUtil.registerFunction(p2, "showCarriageTreeMountFailedWarning", YarderCarriage.showCarriageTreeMountFailedWarning)
	SpecializationUtil.registerFunction(p2, "setCarriageLiftInput", YarderCarriage.setCarriageLiftInput)
	SpecializationUtil.registerFunction(p2, "saveAttachedTreesToXML", YarderCarriage.saveAttachedTreesToXML)
	SpecializationUtil.registerFunction(p2, "resolveLoadedAttachedTrees", YarderCarriage.resolveLoadedAttachedTrees)
	SpecializationUtil.registerFunction(p2, "onYarderCarriageTreeShapeCut", YarderCarriage.onYarderCarriageTreeShapeCut)
	SpecializationUtil.registerFunction(p2, "onYarderCarriageTreeShapeMounted", YarderCarriage.onYarderCarriageTreeShapeMounted)
end
function YarderCarriage.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "getDirtMultiplier", YarderCarriage.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p3, "getWearMultiplier", YarderCarriage.getWearMultiplier)
end
function YarderCarriage.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", YarderCarriage)
	SpecializationUtil.registerEventListener(p4, "onLoadFinished", YarderCarriage)
	SpecializationUtil.registerEventListener(p4, "onDelete", YarderCarriage)
	SpecializationUtil.registerEventListener(p4, "onReadStream", YarderCarriage)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", YarderCarriage)
	SpecializationUtil.registerEventListener(p4, "onReadUpdateStream", YarderCarriage)
	SpecializationUtil.registerEventListener(p4, "onWriteUpdateStream", YarderCarriage)
	SpecializationUtil.registerEventListener(p4, "onPostUpdate", YarderCarriage)
end
function YarderCarriage.onLoad(p_u_5, _)
	local v_u_6 = p_u_5.spec_yarderCarriage
	v_u_6.maxNumTrees = p_u_5.xmlFile:getValue("vehicle.yarderCarriage#maxNumTrees", 4)
	local v7 = v_u_6.maxNumTrees
	local v8 = math.sqrt(v7)
	v_u_6.maxTreeBits = math.ceil(v8)
	v_u_6.maxTreeMass = p_u_5.xmlFile:getValue("vehicle.yarderCarriage#maxTreeMass", 1)
	v_u_6.length = p_u_5.xmlFile:getValue("vehicle.yarderCarriage#length", 2)
	v_u_6.rollSpacing = p_u_5.xmlFile:getValue("vehicle.yarderCarriage#rollSpacing", 0.75)
	v_u_6.liftSpeed = p_u_5.xmlFile:getValue("vehicle.yarderCarriage#liftSpeed", 2) * 0.001
	v_u_6.liftAcceleration = 1 / p_u_5.xmlFile:getValue("vehicle.yarderCarriage#liftAcceleration", 0.75) * 0.001
	v_u_6.curLiftSpeedAlpha = 0
	v_u_6.curLiftSpeedLastDirection = 0
	v_u_6.pullRopeTargetNode = p_u_5.xmlFile:getValue("vehicle.yarderCarriage#pullRopeTargetNode", nil, p_u_5.components, p_u_5.i3dMappings)
	v_u_6.pushRopeTargetNode = p_u_5.xmlFile:getValue("vehicle.yarderCarriage#pushRopeTargetNode", nil, p_u_5.components, p_u_5.i3dMappings)
	v_u_6.ropeAlignmentNodes = {}
	p_u_5.xmlFile:iterate("vehicle.yarderCarriage.ropeAlignmentNode", function(_, p9)
		-- upvalues: (copy) p_u_5, (copy) v_u_6
		local v10 = {
			["node"] = p_u_5.xmlFile:getValue(p9 .. "#node", nil, p_u_5.components, p_u_5.i3dMappings)
		}
		if v10.node ~= nil then
			local v11 = v_u_6.ropeAlignmentNodes
			table.insert(v11, v10)
		end
	end)
	v_u_6.joint = {}
	v_u_6.joint.node = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.joint#node", nil, p_u_5.components, p_u_5.i3dMappings)
	v_u_6.joint.attachTime = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.joint#attachTime", 0.5)
	v_u_6.joint.minDistance = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.joint#minDistance", 0.5)
	v_u_6.joint.maxDistance = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.joint#maxDistance", 20)
	v_u_6.joint.component = p_u_5:getParentComponent(v_u_6.joint.node)
	v_u_6.rope = {}
	v_u_6.rope.originNode = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope#originNode", nil, p_u_5.components, p_u_5.i3dMappings)
	v_u_6.rope.rootHook = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope#rootHook", nil, p_u_5.components, p_u_5.i3dMappings)
	v_u_6.rope.rootHookReferenceNode = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope#rootHookReferenceNode", nil, p_u_5.components, p_u_5.i3dMappings)
	v_u_6.rope.treeRopeLength = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope#treeRopeLength", 1)
	v_u_6.rope.rootHookLength = 1
	if v_u_6.rope.rootHook ~= nil and v_u_6.rope.rootHookReferenceNode ~= nil then
		v_u_6.rope.rootHookLength = calcDistanceFrom(v_u_6.rope.rootHook, v_u_6.rope.rootHookReferenceNode)
	end
	v_u_6.rope.mainRope = ForestryRope.new(p_u_5, v_u_6.rope.rootHook)
	v_u_6.rope.mainRope:loadFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.rope.mainRope", p_u_5.baseDirectory)
	v_u_6.rope.attachMainNode = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope.attach#mainNode", nil, p_u_5.components, p_u_5.i3dMappings)
	v_u_6.rope.attachMainRope = ForestryRope.new(p_u_5, v_u_6.rope.attachMainNode)
	v_u_6.rope.attachMainRope:loadFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.rope.attach.mainRope", p_u_5.baseDirectory)
	v_u_6.rope.attachMainRope:setVisibility(false)
	v_u_6.rope.attachAdditionalNode = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope.attach#additionalNode", nil, p_u_5.components, p_u_5.i3dMappings)
	v_u_6.rope.attachAdditionalRope = ForestryRope.new(p_u_5, v_u_6.rope.attachAdditionalNode)
	v_u_6.rope.attachAdditionalRope:loadFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.rope.attach.additionalRope", p_u_5.baseDirectory)
	v_u_6.rope.attachAdditionalRope:setVisibility(false)
	v_u_6.rope.attachMarker = TargetTreeMarker.new(p_u_5, p_u_5.rootNode)
	v_u_6.rope.attachMarker:loadFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.rope.attach.marker")
	v_u_6.rope.componentJointIndex = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope.componentJoint#index")
	v_u_6.rope.componentJointLimitInactive = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope.componentJoint#rotLimitInactive", "0 0 0", true)
	v_u_6.rope.componentJointLimitActive = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.rope.componentJoint#rotLimitActive", nil, true)
	v_u_6.rope.changeObjects = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.rope", v_u_6.rope.changeObjects, p_u_5.components, p_u_5)
	ObjectChangeUtil.setObjectChanges(v_u_6.rope.changeObjects, false, p_u_5, p_u_5.setMovingToolDirty)
	v_u_6.additionalRopes = {}
	p_u_5.xmlFile:iterate("vehicle.yarderCarriage.additionalRopes.additionalRope", function(_, p12)
		-- upvalues: (copy) p_u_5, (copy) v_u_6
		local v_u_13 = {
			["referenceNode"] = p_u_5.xmlFile:getValue(p12 .. "#referenceNode", nil, p_u_5.components, p_u_5.i3dMappings)
		}
		v_u_13.rope = ForestryRope.new(p_u_5, v_u_13.referenceNode)
		v_u_13.rope:loadFromXML(p_u_5.xmlFile, p12 .. ".rope", p_u_5.baseDirectory)
		v_u_13.hookNodes = {}
		p_u_5.xmlFile:iterate(p12 .. ".hookNode", function(_, p14)
			-- upvalues: (ref) p_u_5, (copy) v_u_13
			local v15 = {
				["node"] = p_u_5.xmlFile:getValue(p14 .. "#node", nil, p_u_5.components, p_u_5.i3dMappings),
				["alignYRot"] = p_u_5.xmlFile:getValue(p14 .. "#alignYRot", false),
				["alignXRot"] = p_u_5.xmlFile:getValue(p14 .. "#alignXRot", false),
				["minRot"] = p_u_5.xmlFile:getValue(p14 .. "#minRot", -180),
				["maxRot"] = p_u_5.xmlFile:getValue(p14 .. "#maxRot", 180),
				["alignToTarget"] = p_u_5.xmlFile:getValue(p14 .. "#alignToTarget", true),
				["referenceFrame"] = createTransformGroup("hookNodeReferenceFrame")
			}
			link(getParent(v15.node), v15.referenceFrame)
			setTranslation(v15.referenceFrame, getTranslation(v15.node))
			setRotation(v15.referenceFrame, getRotation(v15.node))
			setVisibility(v15.node, false)
			local v16 = v_u_13.hookNodes
			table.insert(v16, v15)
		end)
		setVisibility(v_u_13.referenceNode, false)
		local v17 = v_u_6.additionalRopes
		table.insert(v17, v_u_13)
	end)
	v_u_6.treeHook = {}
	v_u_6.treeHook.offset = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.treeHook#offset", 0.01)
	v_u_6.treeHook.tensionBeltType = p_u_5.xmlFile:getValue("vehicle.yarderCarriage.treeHook#tensionBeltType", "forestryTreeBelt")
	v_u_6.treeHook.beltData = g_tensionBeltManager:getBeltData(v_u_6.treeHook.tensionBeltType)
	v_u_6.treeHook.hookData = ForestryHook.new(p_u_5, p_u_5.rootNode)
	v_u_6.treeHook.hookData:loadFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.treeHook", p_u_5.baseDirectory)
	v_u_6.treeHook.hookData:setVisibility(false)
	v_u_6.yarderTowerVehicle = nil
	v_u_6.treeRaycast = {}
	v_u_6.treeRaycast.hasStarted = false
	v_u_6.treeRaycast.foundTree = false
	v_u_6.treeRaycast.treeTargetPos = { 0, 0, 0 }
	v_u_6.treeRaycast.treeCenterPos = { 0, 0, 0 }
	v_u_6.treeRaycast.treeUp = { 0, 1, 0 }
	v_u_6.treeRaycast.treeRadius = 1
	v_u_6.attachedTrees = {}
	v_u_6.splitShapesToAttach = {}
	v_u_6.lastTransLimitY = 0
	v_u_6.lastTransLimitYTimeOffset = 0
	v_u_6.sampleLiftPlayedSent = false
	v_u_6.sampleLiftLimitPlayedSent = false
	v_u_6.sampleLowerPlayedSent = false
	v_u_6.samples = {}
	if p_u_5.isClient then
		v_u_6.samples.attachTree = g_soundManager:loadSampleFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.sounds", "attachTree", p_u_5.baseDirectory, p_u_5.components, 1, AudioGroup.VEHICLE, p_u_5.i3dMappings, p_u_5)
		v_u_6.samples.detachTree = g_soundManager:loadSampleFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.sounds", "detachTree", p_u_5.baseDirectory, p_u_5.components, 1, AudioGroup.VEHICLE, p_u_5.i3dMappings, p_u_5)
		v_u_6.samples.lift = g_soundManager:loadSampleFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.sounds", "lift", p_u_5.baseDirectory, p_u_5.components, 0, AudioGroup.VEHICLE, p_u_5.i3dMappings, p_u_5)
		v_u_6.samples.lower = g_soundManager:loadSampleFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.sounds", "lower", p_u_5.baseDirectory, p_u_5.components, 0, AudioGroup.VEHICLE, p_u_5.i3dMappings, p_u_5)
		v_u_6.samples.liftLimit = g_soundManager:loadSampleFromXML(p_u_5.xmlFile, "vehicle.yarderCarriage.sounds", "liftLimit", p_u_5.baseDirectory, p_u_5.components, 1, AudioGroup.VEHICLE, p_u_5.i3dMappings, p_u_5)
	end
	v_u_6.texts = {}
	v_u_6.texts.warningTooHeavy = g_i18n:getText("yarder_treeToHeavy")
	p_u_5.isVehicleSaved = false
	v_u_6.dirtyFlag = p_u_5:getNextDirtyFlag()
	g_messageCenter:subscribe(MessageType.TREE_SHAPE_CUT, p_u_5.onYarderCarriageTreeShapeCut, p_u_5)
	g_messageCenter:subscribe(MessageType.TREE_SHAPE_MOUNTED, p_u_5.onYarderCarriageTreeShapeMounted, p_u_5)
end
function YarderCarriage.onLoadFinished(p18, _)
	local v19 = p18.spec_yarderCarriage
	v19.rope.mainRope:setTargetNode(v19.rope.originNode)
	v19.rope.treeRope = v19.rope.mainRope:clone(v19.rope.rootHookReferenceNode)
	v19.rope.treeRope:setLength(v19.rope.treeRopeLength)
end
function YarderCarriage.onDelete(p20)
	local v21 = p20.spec_yarderCarriage
	if v21.yarderTowerVehicle ~= nil then
		v21.yarderTowerVehicle.spec_yarderTower.carriage.vehicle = nil
	end
	if #v21.attachedTrees > 0 then
		p20:detachTreeFromCarriage(nil, true)
	end
	if p20.isClient then
		g_soundManager:deleteSamples(v21.samples)
	end
	if v21.treeHook.hookData ~= nil then
		v21.treeHook.hookData:delete()
	end
	if v21.rope.attachMarker ~= nil then
		v21.rope.attachMarker:delete()
	end
	if v21.rope.mainRope ~= nil then
		v21.rope.mainRope:delete()
	end
	if v21.rope.treeRope ~= nil then
		v21.rope.treeRope:delete()
	end
	if v21.rope.attachMainRope ~= nil then
		v21.rope.attachMainRope:delete()
	end
	if v21.rope.attachAdditionalRope ~= nil then
		v21.rope.attachAdditionalRope:delete()
	end
	if v21.additionalRopes ~= nil then
		for v22 = 1, #v21.additionalRopes do
			local v23 = v21.additionalRopes[v22]
			if v23.rope ~= nil then
				v23.rope:delete()
			end
		end
	end
end
function YarderCarriage.onReadStream(p24, p25, _)
	local v26 = p24.spec_yarderCarriage
	if streamReadBool(p25) then
		v26.yarderTowerVehicle = NetworkUtil.readNodeObject(p25)
		v26.yarderTowerVehicle.spec_yarderTower.carriage.vehicle = p24
	end
	for _ = 1, streamReadUIntN(p25, v26.maxTreeBits) do
		local v27 = streamReadFloat32(p25)
		local v28 = streamReadFloat32(p25)
		local v29 = streamReadFloat32(p25)
		local v30, v31, v32 = readSplitShapeIdFromStream(p25)
		if v30 == 0 then
			if v31 ~= 0 then
				local v33 = v26.splitShapesToAttach
				table.insert(v33, {
					["splitShapeId1"] = v31,
					["splitShapeId2"] = v32,
					["x"] = v27,
					["y"] = v28,
					["z"] = v29
				})
			end
		else
			local v34, v35, v36 = localToWorld(v30, v27, v28, v29)
			p24:attachTreeToCarriage(v30, v34, v35, v36, nil, true)
		end
	end
end
function YarderCarriage.onWriteStream(p37, p38, _)
	local v39 = p37.spec_yarderCarriage
	streamWriteBool(p38, v39.yarderTowerVehicle ~= nil)
	if v39.yarderTowerVehicle ~= nil then
		NetworkUtil.writeNodeObject(p38, v39.yarderTowerVehicle)
	end
	streamWriteUIntN(p38, #v39.attachedTrees, v39.maxTreeBits)
	for v40 = 1, #v39.attachedTrees do
		local v41 = v39.attachedTrees[v40]
		local v42, v43, v44 = worldToLocal(v41.treeId, getWorldTranslation(v41.hookData.hookId))
		streamWriteFloat32(p38, v42)
		streamWriteFloat32(p38, v43)
		streamWriteFloat32(p38, v44)
		writeSplitShapeIdToStream(p38, v41.treeId)
	end
end
function YarderCarriage.onReadUpdateStream(p45, p46, _, p47)
	if p47:getIsServer() and streamReadBool(p46) then
		local v48 = p45.spec_yarderCarriage
		if streamReadBool(p46) and not g_soundManager:getIsSamplePlaying(v48.samples.lift) then
			g_soundManager:playSample(v48.samples.lift)
			g_soundManager:stopSample(v48.samples.lower)
			v48.lastTransLimitYTimeOffset = 250
		end
		if streamReadBool(p46) then
			g_soundManager:playSample(v48.samples.liftLimit)
		end
		if streamReadBool(p46) and not g_soundManager:getIsSamplePlaying(v48.samples.lower) then
			g_soundManager:playSample(v48.samples.lower)
			g_soundManager:stopSample(v48.samples.lift)
			v48.lastTransLimitYTimeOffset = 250
		end
	end
end
function YarderCarriage.onWriteUpdateStream(p49, p50, p51, p52)
	local v53 = p49.spec_yarderCarriage
	if not p51:getIsServer() and streamWriteBool(p50, bitAND(p52, v53.dirtyFlag) ~= 0) then
		streamWriteBool(p50, v53.sampleLiftPlayedSent)
		streamWriteBool(p50, v53.sampleLiftLimitPlayedSent)
		streamWriteBool(p50, v53.sampleLowerPlayedSent)
		v53.sampleLiftPlayedSent = false
		v53.sampleLiftLimitPlayedSent = false
		v53.sampleLowerPlayedSent = false
	end
end
function YarderCarriage.onPostUpdate(p54, p55, _, _, _)
	local v56 = p54.spec_yarderCarriage
	if p54.isServer then
		for v57 = 1, #v56.attachedTrees do
			local v58 = v56.attachedTrees[v57]
			if v58.limitDirty then
				local v59 = v58.limitValue - v58.speedScale * g_currentDt
				v58.limitValue = math.max(v59, 0)
				setJointTranslationLimit(v58.jointIndex, 0, true, -v58.limitValue, v58.limitValue)
				setJointTranslationLimit(v58.jointIndex, 1, true, -v58.transLimitY, v58.limitValue)
				setJointTranslationLimit(v58.jointIndex, 2, true, -v58.limitValue, v58.limitValue)
				if v58.limitValue == 0 then
					v58.limitDirty = false
				end
			else
				if v58.treeId == nil or not entityExists(v58.treeId) then
					p54:detachTreeFromCarriage()
					break
				end
				if calcDistanceFrom(v56.joint.node, v58.hookData.hookId) > v58.transLimitY + YarderCarriage.ROPE_MAX_LIMIT_OFFSET then
					p54:detachTreeFromCarriage()
					break
				end
			end
		end
	else
		for v60 = #v56.splitShapesToAttach, 1, -1 do
			local v61 = v56.splitShapesToAttach[v60]
			local v62 = resolveStreamSplitShapeId(v61.splitShapeId1, v61.splitShapeId2)
			if v62 ~= 0 then
				local v63, v64, v65 = localToWorld(v62, v61.x, v61.y, v61.z)
				p54:attachTreeToCarriage(v62, v63, v64, v65, nil, true)
				table.remove(v56.splitShapesToAttach, v60)
			end
		end
	end
	p54:updateTreeAttachRopes(p55)
	if v56.treeRaycast.validTree ~= nil and not entityExists(v56.treeRaycast.validTree) then
		v56.treeRaycast.validTree = nil
	end
	if v56.treeRaycast.validTree ~= v56.treeRaycast.lastValidTree then
		v56.rope.attachMarker:setIsActive(v56.treeRaycast.validTree ~= nil)
		local v66 = v56.rope.attachMainRope
		local v67
		if v56.treeRaycast.validTree == nil then
			v67 = false
		else
			v67 = #v56.attachedTrees == 0
		end
		v66:setVisibility(v67)
		local v68 = v56.rope.attachAdditionalRope
		local v69
		if v56.treeRaycast.validTree == nil then
			v69 = false
		else
			v69 = #v56.attachedTrees > 0
		end
		v68:setVisibility(v69)
		v56.treeRaycast.lastValidTree = v56.treeRaycast.validTree
	end
	local v70 = #v56.attachedTrees == 0 and v56.rope.attachMainRope or v56.rope.attachAdditionalRope
	if v56.treeRaycast.validTree ~= nil and v70 ~= nil then
		v70:setTargetPosition(v56.treeRaycast.treeTargetPos[1], v56.treeRaycast.treeTargetPos[2], v56.treeRaycast.treeTargetPos[3])
		v56.rope.attachMarker:setIsActive(true)
		v56.rope.attachMarker:setPosition(v56.treeRaycast.treeCenterPos[1], v56.treeRaycast.treeCenterPos[2], v56.treeRaycast.treeCenterPos[3], v56.treeRaycast.treeUp[1], v56.treeRaycast.treeUp[2], v56.treeRaycast.treeUp[3], v56.treeRaycast.treeRadius)
	end
	if v56.lastTransLimitYTimeOffset > 0 then
		v56.lastTransLimitYTimeOffset = v56.lastTransLimitYTimeOffset - p55
		if v56.lastTransLimitYTimeOffset <= 0 then
			v56.curLiftSpeedAlpha = 0
			v56.curLiftSpeedLastDirection = 0
			g_soundManager:stopSample(v56.samples.lower)
			g_soundManager:stopSample(v56.samples.lift)
		end
	end
	if #v56.attachedTrees > 0 or v56.treeRaycast.validTree ~= nil then
		p54:raiseActive()
	end
end
function YarderCarriage.getCarriageDimensions(p71)
	local v72 = p71.spec_yarderCarriage
	return v72.length, v72.rollSpacing
end
function YarderCarriage.getCarriagePullRopeTargetNode(p73)
	return p73.spec_yarderCarriage.pullRopeTargetNode
end
function YarderCarriage.getCarriagePushRopeTargetNode(p74)
	return p74.spec_yarderCarriage.pushRopeTargetNode
end
function YarderCarriage.setYarderTowerVehicle(p75, p76)
	p75.spec_yarderCarriage.yarderTowerVehicle = p76
end
function YarderCarriage.updateRopeAlignmentNodes(p77, p78, p79, p80, p81, p82)
	local _, _, v83 = worldToLocal(p78, p79, p80, p81)
	local v84 = p77.spec_yarderCarriage
	for v85 = 1, #v84.ropeAlignmentNodes do
		local v86 = v84.ropeAlignmentNodes[v85]
		local _, _, v87 = worldToLocal(p78, getWorldTranslation(v86.node))
		local v88 = v87 / v83
		local v89 = math.clamp(v88, 0, 1) * 3.141592653589793
		local v90 = math.sin(v89) * p82
		local v91, v92, v93 = localToWorld(p78, 0, -v90, v87)
		local v94, v95, _ = worldToLocal(v86.node, v91, v92, v93)
		translate(v86.node, v94, v95, 0)
	end
end
function YarderCarriage.updateCarriageInRange(p96)
	if g_localPlayer ~= nil then
		local v97 = p96.spec_yarderCarriage
		local v98 = g_localPlayer
		local v99, _, v100 = getWorldTranslation(v98.rootNode)
		local v101, _, v102 = getWorldTranslation(v97.rope.originNode)
		if MathUtil.vector2Length(v99 - v101, v100 - v102) < v97.joint.maxDistance then
			if v98:getIsHoldingHandTool() then
				v97.treeRaycast.validTree = nil
				return
			end
			if #v97.attachedTrees >= v97.maxNumTrees then
				v97.treeRaycast.validTree = nil
				return
			end
			if not v97.treeRaycast.hasStarted then
				v97.treeRaycast.hasStarted = true
				v97.treeRaycast.foundTree = nil
				local v103 = v98:getCurrentCameraNode()
				local v104, v105, v106 = localToWorld(v103, 0, 0, 1)
				local v107, v108, v109 = localDirectionToWorld(v103, 0, 0, -1)
				raycastClosestAsync(v104, v105, v106, v107, v108, v109, YarderCarriage.TREE_RAYCAST_DISTANCE, "onCarriageTreeRaycastCallback", p96, CollisionFlag.TREE)
				return
			end
		else
			v97.treeRaycast.validTree = nil
		end
	end
end
function YarderCarriage.onYarderCarriageUpdateEnd(p110)
	local v111 = p110.spec_yarderCarriage
	v111.treeRaycast.validTree = nil
	v111.treeRaycast.hasStarted = false
	p110:raiseActive()
end
function YarderCarriage.updateTreeAttachRopes(p112, _)
	local v113 = p112.spec_yarderCarriage
	local v114 = v113.attachedTrees[1]
	if v114 ~= nil and entityExists(v114.treeId) then
		local v115, v116, v117 = getWorldTranslation(v113.rope.originNode)
		local v118, v119, v120 = v114.hookData:getRopeTargetPosition()
		local v121 = MathUtil.vector3Length(v118 - v115, v119 - v116, v120 - v117)
		local v122, v123, v124 = MathUtil.vector3Normalize(v118 - v115, v119 - v116, v120 - v117)
		local v125, v126, v127 = localDirectionToWorld(getParent(v113.rope.originNode), 0, 1, 0)
		I3DUtil.setWorldDirection(v113.rope.originNode, v122, v123, v124, v125, v126, v127)
		local v128 = v121 - v113.rope.treeRopeLength - v113.rope.rootHookLength
		setTranslation(v113.rope.rootHook, 0, 0, v128)
		v113.rope.mainRope:setLength(v128)
	end
	for v129 = 1, #v113.additionalRopes do
		local v130 = v113.additionalRopes[v129]
		local v131 = v113.attachedTrees[v129 + 1]
		if v131 ~= nil and entityExists(v131.treeId) then
			local v132, v133, v134 = v131.hookData:getRopeTargetPosition()
			for v135 = 1, #v130.hookNodes do
				local v136 = v130.hookNodes[v135]
				if v136.alignYRot then
					local v137, _, v138 = worldToLocal(v136.referenceFrame, v132, v133, v134)
					local v139, v140 = MathUtil.vector2Normalize(v137, v138)
					local v141 = math.atan2(v139, v140)
					local v142 = v136.minRot
					local v143 = v136.maxRot
					local v144 = math.clamp(v141, v142, v143)
					setRotation(v136.node, 0, v144, 0)
				elseif v136.alignXRot then
					local _, v145, v146 = worldToLocal(v136.referenceFrame, v132, v133, v134)
					local v147, v148 = MathUtil.vector2Normalize(v145, v146)
					local v149 = -math.atan2(v147, v148)
					local v150 = v136.minRot
					local v151 = v136.maxRot
					local v152 = math.clamp(v149, v150, v151)
					setRotation(v136.node, v152, 0, 0)
				elseif v136.alignToTarget then
					local v153, v154, v155 = worldToLocal(v136.referenceFrame, v132, v133, v134)
					local v156, v157, v158 = MathUtil.vector3Normalize(v153, v154, v155)
					setDirection(v136.node, v156, v157, v158, 0, 1, 0)
				end
			end
			v130.rope:setTargetNode(v131.hookData:getRopeTarget(), false)
		end
	end
end
function YarderCarriage.onCarriageTreeRaycastCallback(p159, p160, p161, p162, p163, _, _, _, _, _, _, p164)
	if not (p159.isDeleted or p159.isDeleting) then
		local v165 = p159.spec_yarderCarriage
		if not v165.treeRaycast.hasStarted then
			v165.treeRaycast.validTree = nil
			return false
		end
		if p160 ~= 0 and (getHasClassId(p160, ClassIds.SHAPE) and (getSplitType(p160) ~= 0 and getIsSplitShapeSplit(p160))) then
			if p164 then
				v165.treeRaycast.hasStarted = false
				local v166, _, v167 = getWorldTranslation(v165.rope.originNode)
				if MathUtil.vector2Length(p161 - v166, p163 - v167) > v165.joint.maxDistance then
					v165.treeRaycast.validTree = nil
					return false
				end
				if #v165.attachedTrees > 0 then
					for v168 = 1, #v165.attachedTrees do
						if p160 == v165.attachedTrees[v168].treeId then
							v165.treeRaycast.validTree = nil
							return false
						end
					end
					local v169 = v165.attachedTrees[1]
					local v170, v171, v172 = getWorldTranslation(v169.hookData.hookId)
					if MathUtil.vector3Length(p161 - v170, p162 - v171, p163 - v172) > 2 then
						v165.treeRaycast.validTree = nil
						return false
					end
				end
				local v173, v174, v175, v176, v177, v178, v179 = SplitShapeUtil.getTreeOffsetPosition(p160, p161, p162, p163, 4, 0.15)
				if v173 == nil then
					v165.treeRaycast.validTree = nil
				else
					v165.treeRaycast.validTree = p160
					v165.treeRaycast.treeTargetPos[1] = p161
					v165.treeRaycast.treeTargetPos[2] = p162
					v165.treeRaycast.treeTargetPos[3] = p163
					v165.treeRaycast.treeCenterPos[1] = v173
					v165.treeRaycast.treeCenterPos[2] = v174
					v165.treeRaycast.treeCenterPos[3] = v175
					v165.treeRaycast.treeUp[1] = v176
					v165.treeRaycast.treeUp[2] = v177
					v165.treeRaycast.treeUp[3] = v178
					v165.treeRaycast.treeRadius = v179
					p159:raiseActive()
				end
			end
			return false
		end
		if p164 then
			v165.treeRaycast.hasStarted = false
			v165.treeRaycast.validTree = nil
		end
	end
end
function YarderCarriage.onAttachTreeAction(p180)
	local v181 = p180.spec_yarderCarriage
	if v181.treeRaycast.validTree ~= nil then
		if g_server == nil then
			g_client:getServerConnection():sendEvent(TreeAttachRequestEvent.new(p180, v181.treeRaycast.validTree, v181.treeRaycast.treeTargetPos[1], v181.treeRaycast.treeTargetPos[2], v181.treeRaycast.treeTargetPos[3]))
		else
			local v182, v183 = p180:getIsCarriageTreeAttachAllowed(v181.treeRaycast.validTree)
			if v182 then
				p180:attachTreeToCarriage(v181.treeRaycast.validTree, v181.treeRaycast.treeTargetPos[1], v181.treeRaycast.treeTargetPos[2], v181.treeRaycast.treeTargetPos[3])
			else
				p180:showCarriageTreeMountFailedWarning(nil, v183)
			end
		end
		v181.treeRaycast.validTree = nil
	end
end
function YarderCarriage.attachTreeToCarriage(p184, p185, p186, p187, p188, _, p189)
	local v190 = p184.spec_yarderCarriage
	v190.rope.attachMainRope:setVisibility(false)
	v190.rope.attachAdditionalRope:setVisibility(false)
	local v191 = {
		["treeId"] = p185,
		["hookData"] = v190.treeHook.hookData:clone()
	}
	local v192, _, _ = v191.hookData:mountToTree(p185, p186, p187, p188, 4)
	if v192 == nil then
		v191.hookData:delete()
	else
		v191.hookData:setTargetNode(v190.rope.originNode, true)
		if p184.isServer then
			local v193, v194 = p184:createJoint(v191.treeId, v191.hookData.hookId)
			v191.jointIndex = v193
			v191.transLimitY = v194
			v191.limitValue = v191.transLimitY
			v191.speedScale = v191.transLimitY * (1 / v190.joint.attachTime)
			v191.limitDirty = true
			if #v190.attachedTrees == 0 then
				v190.lastTransLimitY = v191.transLimitY
			end
		end
		local v195 = v190.attachedTrees
		table.insert(v195, v191)
		ObjectChangeUtil.setObjectChanges(v190.rope.changeObjects, true, p184, p184.setMovingToolDirty)
		local v196 = #v190.attachedTrees
		if v196 > 1 and v190.additionalRopes[v196 - 1] ~= nil then
			local v197 = v190.additionalRopes[v196 - 1]
			setVisibility(v197.referenceNode, true)
			for v198 = 1, #v197.hookNodes do
				local v199 = v197.hookNodes[v198]
				setVisibility(v199.node, true)
			end
			v191.hookData:setTargetNode(v197.referenceNode, true)
		end
		p184:updateTreeAttachRopes(9999)
		if v190.samples.attachTree ~= nil then
			setWorldTranslation(v190.samples.attachTree.soundNode, p186, p187, p188)
			g_soundManager:playSample(v190.samples.attachTree)
		end
		if v196 == 1 and v190.rope.componentJointIndex ~= nil then
			local v200 = p184.componentJoints[v190.rope.componentJointIndex]
			local v201 = v190.rope.componentJointLimitActive
			p184:setComponentJointRotLimit(v200, 1, -v201[1], v201[1])
			p184:setComponentJointRotLimit(v200, 2, -v201[2], v201[2])
			p184:setComponentJointRotLimit(v200, 3, -v201[3], v201[3])
		end
		if v190.yarderTowerVehicle ~= nil then
			SpecializationUtil.raiseEvent(v190.yarderTowerVehicle, "onYarderCarriageTreeAttached", p185)
		end
		g_messageCenter:publish(MessageType.TREE_SHAPE_MOUNTED, p185, p184)
		p184:raiseActive()
		TreeAttachEvent.sendEvent(p184, p185, p186, p187, p188, nil, p189)
	end
end
function YarderCarriage.createJoint(p202, p203, p204)
	local v205 = p202.spec_yarderCarriage
	local v206 = JointConstructor.new()
	v206:setActors(v205.joint.component, p203)
	v206:setJointTransforms(v205.joint.node, p204)
	v206:setRotationLimit(0, -3.141592653589793, 3.141592653589793)
	v206:setRotationLimit(1, -3.141592653589793, 3.141592653589793)
	v206:setRotationLimit(2, -3.141592653589793, 3.141592653589793)
	v206:setEnableCollision(true)
	v206:setRotationLimitSpring(7500, 1500, 7500, 1500, 7500, 1500)
	v206:setTranslationLimitSpring(7500, 1500, 7500, 1500, 7500, 1500)
	local v207 = calcDistanceFrom(v205.joint.node, p204)
	v206:setTranslationLimit(0, true, -v207, v207)
	v206:setTranslationLimit(1, true, -v207, v207)
	v206:setTranslationLimit(2, true, -v207, v207)
	return v206:finalize(), v207
end
function YarderCarriage.onDetachTreeAction(p208)
	p208:detachTreeFromCarriage()
end
function YarderCarriage.detachTreeFromCarriage(p209, _, p210)
	local v211 = p209.spec_yarderCarriage
	if v211.samples.detachTree ~= nil and (v211.attachedTrees[1] ~= nil and entityExists(v211.attachedTrees[1].hookData.hookId)) then
		setWorldTranslation(v211.samples.detachTree.soundNode, getWorldTranslation(v211.attachedTrees[1].hookData.hookId))
		g_soundManager:playSample(v211.samples.detachTree)
	end
	for v212 = #v211.attachedTrees, 1, -1 do
		local v213 = v211.attachedTrees[v212]
		if p209.isServer then
			removeJoint(v213.jointIndex)
		end
		v213.hookData:delete()
		table.remove(v211.attachedTrees, v212)
	end
	for v214 = 1, #v211.additionalRopes do
		local v215 = v211.additionalRopes[v214]
		setVisibility(v215.referenceNode, false)
		for v216 = 1, #v215.hookNodes do
			local v217 = v215.hookNodes[v216]
			setVisibility(v217.node, false)
		end
	end
	ObjectChangeUtil.setObjectChanges(v211.rope.changeObjects, false, p209, p209.setMovingToolDirty)
	if v211.rope.componentJointIndex ~= nil then
		local v218 = p209.componentJoints[v211.rope.componentJointIndex]
		local v219 = v211.rope.componentJointLimitInactive
		p209:setComponentJointRotLimit(v218, 1, -v219[1], v219[1])
		p209:setComponentJointRotLimit(v218, 2, -v219[2], v219[2])
		p209:setComponentJointRotLimit(v218, 3, -v219[3], v219[3])
	end
	TreeDetachEvent.sendEvent(p209, nil, p210)
end
function YarderCarriage.getNumAttachedTrees(p220)
	return #p220.spec_yarderCarriage.attachedTrees
end
function YarderCarriage.getMaxNumAttachedTrees(p221)
	return p221.spec_yarderCarriage.maxNumTrees
end
function YarderCarriage.getAttachedTreeMass(p222)
	local v223 = p222.spec_yarderCarriage
	local v224 = 0
	for v225 = 1, #v223.attachedTrees do
		v224 = v224 + getMass(v223.attachedTrees[v225].treeId)
	end
	return v224
end
function YarderCarriage.getIsCarriageTreeAttachAllowed(p226, p227)
	local v228 = p226.spec_yarderCarriage
	if p227 == nil or not entityExists(p227) then
		return false, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_DEFAULT
	elseif #v228.attachedTrees >= v228.maxNumTrees then
		return false, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_DEFAULT
	elseif getMass(p227) + p226:getAttachedTreeMass() > v228.maxTreeMass then
		return false, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_TOO_HEAVY
	elseif getUserAttribute(p227, "isTensionBeltMounted") == true then
		return false, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_DEFAULT
	else
		return true, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_DEFAULT
	end
end
function YarderCarriage.getIsTreeInMountRange(p229)
	local v230 = p229.spec_yarderCarriage
	if v230.treeRaycast.validTree == nil then
		return false
	elseif entityExists(v230.treeRaycast.validTree) then
		return #v230.attachedTrees < v230.maxNumTrees
	else
		return false
	end
end
function YarderCarriage.showCarriageTreeMountFailedWarning(p231, _, p232)
	local v233 = p231.spec_yarderCarriage
	if p232 == TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_TOO_HEAVY then
		g_currentMission:showBlinkingWarning(string.format(v233.texts.warningTooHeavy, v233.maxTreeMass), 2500)
	end
end
function YarderCarriage.setCarriageLiftInput(p234, p235)
	if p234.isServer then
		local v236 = p234.spec_yarderCarriage
		for v237 = 1, #v236.attachedTrees do
			local v238 = v236.attachedTrees[v237]
			local v239 = v236.joint.minDistance
			if v237 > 1 then
				local v240 = v236.attachedTrees[1].transLimitY
				v239 = math.max(v240, v239)
			end
			if entityExists(v238.treeId) then
				local v241 = calcDistanceFrom(v236.joint.node, v238.hookData.hookId)
				if p235 ~= v236.curLiftSpeedLastDirection then
					v236.curLiftSpeedAlpha = 0
					v236.curLiftSpeedLastDirection = p235
				end
				local v242 = v236.curLiftSpeedAlpha + g_currentDt * v236.liftAcceleration
				v236.curLiftSpeedAlpha = math.min(v242, 1)
				local v243 = -(v236.liftSpeed * v236.curLiftSpeedAlpha) * g_currentDt * p235
				local v244 = v238.transLimitY + v243
				local v245 = v241 + 0.3
				local v246 = math.max(v239, v245)
				v238.transLimitY = math.clamp(v244, v239, v246)
				setJointTranslationLimit(v238.jointIndex, 1, true, -v238.transLimitY, 0)
				if v237 == 1 and v238.transLimitY ~= v236.lastTransLimitY then
					if v243 < 0 then
						if not g_soundManager:getIsSamplePlaying(v236.samples.lift) then
							g_soundManager:playSample(v236.samples.lift)
							g_soundManager:stopSample(v236.samples.lower)
							v236.sampleLiftPlayedSent = true
							v236.sampleLowerPlayedSent = false
						end
					elseif not g_soundManager:getIsSamplePlaying(v236.samples.lower) then
						g_soundManager:playSample(v236.samples.lower)
						g_soundManager:stopSample(v236.samples.lift)
						v236.sampleLowerPlayedSent = true
						v236.sampleLiftPlayedSent = false
					end
					if v238.transLimitY == v236.joint.minDistance then
						g_soundManager:playSample(v236.samples.liftLimit)
						v236.sampleLiftLimitPlayedSent = true
					end
					v236.lastTransLimitY = v238.transLimitY
					v236.lastTransLimitYTimeOffset = 250
					p234:raiseDirtyFlags(v236.dirtyFlag)
				end
			end
		end
	end
end
function YarderCarriage.registerSavegameXMLPaths(p247, p248)
	p247:register(XMLValueType.VECTOR_TRANS, p248 .. ".attachedTree(?)#translation", "Main rope is active")
	p247:register(XMLValueType.INT, p248 .. ".attachedTree(?)#splitShapePart1", "Split shape data part 1")
	p247:register(XMLValueType.INT, p248 .. ".attachedTree(?)#splitShapePart2", "Split shape data part 2")
	p247:register(XMLValueType.INT, p248 .. ".attachedTree(?)#splitShapePart3", "Split shape data part 3")
end
function YarderCarriage.saveAttachedTreesToXML(p249, p250, p251, _)
	local v252 = p249.spec_yarderCarriage
	for v253 = 1, #v252.attachedTrees do
		local v254 = v252.attachedTrees[v253]
		local v255 = string.format("%s.attachedTree(%d)", p251, v253 - 1)
		p250:setValue(v255 .. "#translation", getWorldTranslation(v254.hookData.hookId))
		local v256, v257, v258 = getSaveableSplitShapeId(v254.treeId)
		if v256 ~= 0 and v256 ~= nil then
			p250:setValue(v255 .. "#splitShapePart1", v256)
			p250:setValue(v255 .. "#splitShapePart2", v257)
			p250:setValue(v255 .. "#splitShapePart3", v258)
		end
	end
end
function YarderCarriage.loadAttachedTreesFromXML(p_u_259, p260)
	local v_u_261 = {}
	p_u_259:iterate(p260 .. ".attachedTree", function(_, p262)
		-- upvalues: (copy) p_u_259, (copy) v_u_261
		local v263 = p_u_259:getValue(p262 .. "#translation", nil, true)
		if v263 ~= nil then
			local v264 = p_u_259:getValue(p262 .. "#splitShapePart1")
			if v264 ~= nil then
				local v265 = v_u_261
				local v266 = {
					["translation"] = v263,
					["splitShapePart1"] = v264,
					["splitShapePart2"] = p_u_259:getValue(p262 .. "#splitShapePart2"),
					["splitShapePart3"] = p_u_259:getValue(p262 .. "#splitShapePart3")
				}
				table.insert(v265, v266)
			end
		end
	end)
	return v_u_261
end
function YarderCarriage.resolveLoadedAttachedTrees(p267, p268)
	for v269 = 1, #p268 do
		local v270 = p268[v269]
		local v271 = getShapeFromSaveableSplitShapeId(v270.splitShapePart1, v270.splitShapePart2, v270.splitShapePart3)
		if v271 == nil or v271 == 0 then
			return false
		end
	end
	for v272 = 1, #p268 do
		local v273 = p268[v272]
		p267:attachTreeToCarriage(getShapeFromSaveableSplitShapeId(v273.splitShapePart1, v273.splitShapePart2, v273.splitShapePart3), v273.translation[1], v273.translation[2], v273.translation[3], nil, true)
	end
	return true
end
function YarderCarriage.onYarderCarriageTreeShapeCut(p274, p275, _)
	if p274.isServer then
		local v276 = p274.spec_yarderCarriage
		for v277 = 1, #v276.attachedTrees do
			if v276.attachedTrees[v277].treeId == p275 then
				p274:detachTreeFromCarriage()
				return
			end
		end
	end
end
function YarderCarriage.onYarderCarriageTreeShapeMounted(p278, p279, p280)
	if p280 ~= p278 and p278.isServer then
		local v281 = p278.spec_yarderCarriage
		for v282 = 1, #v281.attachedTrees do
			if v281.attachedTrees[v282].treeId == p279 then
				p278:detachTreeFromCarriage()
				return
			end
		end
	end
end
function YarderCarriage.getDirtMultiplier(p283, p284)
	local v285 = p284(p283)
	local v286 = p283.spec_yarderCarriage
	if v286.yarderTowerVehicle == nil then
		return v285
	else
		return v286.yarderTowerVehicle:getDirtMultiplier()
	end
end
function YarderCarriage.getWearMultiplier(p287, p288)
	local v289 = p288(p287)
	local v290 = p287.spec_yarderCarriage
	if v290.yarderTowerVehicle == nil then
		return v289
	else
		return v290.yarderTowerVehicle:getDirtMultiplier()
	end
end

source("dataS/scripts/vehicles/specializations/events/ReceivingHopperSetCreateBoxesEvent.lua")
ReceivingHopper = {}
ReceivingHopper.BOX_SPAWN_OVERLAP_MASK = CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.VEHICLE + CollisionFlag.PLAYER
function ReceivingHopper.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(FillUnit, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Dischargeable, p1)
	end
	return v2
end
function ReceivingHopper.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("ReceivingHopper")
	v3:register(XMLValueType.INT, "vehicle.receivingHopper#fillUnitIndex", "Fill unit index", 1)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.receivingHopper.boxes#spawnPlaceNode", "Spawn place node")
	v3:register(XMLValueType.STRING, "vehicle.receivingHopper.boxes.box(?)#fillType", "Fill type name")
	v3:register(XMLValueType.STRING, "vehicle.receivingHopper.boxes.box(?)#filename", "Box filename")
	v3:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.BOOL, "vehicles.vehicle(?).receivingHopper#createBoxes", "Create boxes")
end
function ReceivingHopper.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "setCreateBoxes", ReceivingHopper.setCreateBoxes)
	SpecializationUtil.registerFunction(p4, "getCanSpawnNextBox", ReceivingHopper.getCanSpawnNextBox)
	SpecializationUtil.registerFunction(p4, "collisionTestCallback", ReceivingHopper.collisionTestCallback)
	SpecializationUtil.registerFunction(p4, "createBox", ReceivingHopper.createBox)
	SpecializationUtil.registerFunction(p4, "onCreateBoxFinished", ReceivingHopper.onCreateBoxFinished)
end
function ReceivingHopper.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "handleDischargeRaycast", ReceivingHopper.handleDischargeRaycast)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanBeSelected", ReceivingHopper.getCanBeSelected)
end
function ReceivingHopper.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", ReceivingHopper)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", ReceivingHopper)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", ReceivingHopper)
	SpecializationUtil.registerEventListener(p6, "onFillUnitFillLevelChanged", ReceivingHopper)
end
function ReceivingHopper.onLoad(p7, p8)
	local v9 = p7.spec_receivingHopper
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper#unloadingDelay", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper#unloadInfoIndex", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper#dischargeInfoIndex", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.tipTrigger#index", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.boxTrigger#index", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.fillScrollerNodes.fillScrollerNode", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.fillEffect", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.fillEffect", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.boxTrigger#litersPerMinute", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.raycastNode#index", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.raycastNode#raycastLength", "Dischargeable functionalities")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.boxTrigger#boxSpawnPlaceIndex", "vehicle.receivingHopper.boxes#spawnPlaceNode")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.receivingHopper.boxTrigger.box(0)", "vehicle.receivingHopper.boxes.box(0)")
	v9.fillUnitIndex = p7.xmlFile:getValue("vehicle.receivingHopper#fillUnitIndex", 1)
	v9.spawnPlace = p7.xmlFile:getValue("vehicle.receivingHopper.boxes#spawnPlaceNode", nil, p7.components, p7.i3dMappings)
	v9.boxes = {}
	local v10 = 0
	while true do
		local v11 = string.format("vehicle.receivingHopper.boxes.box(%d)", v10)
		if not p7.xmlFile:hasProperty(v11) then
			break
		end
		local v12 = p7.xmlFile:getValue(v11 .. "#fillType")
		local v13 = p7.xmlFile:getValue(v11 .. "#filename")
		local v14 = g_fillTypeManager:getFillTypeIndexByName(v12)
		if v14 == nil then
			Logging.xmlWarning(p7.xmlFile, "Invalid fillType \'%s\'", v12)
		else
			v9.boxes[v14] = v13
		end
		v10 = v10 + 1
	end
	v9.createBoxes = false
	v9.lastBox = nil
	v9.creatingBox = false
	if p8 ~= nil then
		v9.createBoxes = p8.xmlFile:getValue(p8.key .. ".receivingHopper#createBoxes", v9.createBoxes)
	end
	if not p7.isServer then
		SpecializationUtil.removeEventListener(p7, "onUpdateTick", ReceivingHopper)
	end
end
function ReceivingHopper.saveToXMLFile(p15, p16, p17, _)
	local v18 = p15.spec_receivingHopper
	p16:setValue(p17 .. "#createBoxes", v18.createBoxes)
end
function ReceivingHopper.onUpdateTick(p19, _, _, _, _)
	if p19.spec_receivingHopper.createBoxes and (p19:getDischargeState() == Dischargeable.DISCHARGE_STATE_OFF and p19:getCanSpawnNextBox()) then
		p19:createBox()
	end
end
function ReceivingHopper.setCreateBoxes(p20, p21, p22)
	local v23 = p20.spec_receivingHopper
	if p21 ~= v23.createBoxes then
		ReceivingHopperSetCreateBoxesEvent.sendEvent(p20, p21, p22)
		v23.createBoxes = p21
		ReceivingHopper.updateActionEvents(p20)
		v23.lastBox = nil
	end
end
function ReceivingHopper.getCanSpawnNextBox(p24)
	local v25 = p24.spec_receivingHopper
	if v25.creatingBox then
		return false
	end
	local v26 = p24:getFillUnitFillType(v25.fillUnitIndex)
	if v25.boxes[v26] == nil then
		return false
	end
	if v25.lastBox ~= nil and v25.lastBox:getFillUnitFreeCapacity(1) > 0 then
		return false
	end
	local v27 = Utils.getFilename(v25.boxes[v26], p24.baseDirectory)
	local v28 = StoreItemUtil.getSizeValues(v27, "vehicle", 0)
	local v29, v30, v31 = getWorldTranslation(v25.spawnPlace)
	local v32, v33, v34 = getWorldRotation(v25.spawnPlace)
	v25.foundObjectAtSpawnPlace = false
	overlapBox(v29, v30, v31, v32, v33, v34, v28.width * 0.5, 2, v28.length * 0.5, "collisionTestCallback", p24, ReceivingHopper.BOX_SPAWN_OVERLAP_MASK)
	return not v25.foundObjectAtSpawnPlace
end
function ReceivingHopper.collisionTestCallback(p35, p36)
	if (g_currentMission.nodeToObject[p36] ~= nil or g_currentMission.players[p36] ~= nil) and g_currentMission.nodeToObject[p36] ~= p35 then
		p35.spec_receivingHopper.foundObjectAtSpawnPlace = true
	end
end
function ReceivingHopper.createBox(p37)
	local v38 = p37.spec_receivingHopper
	if p37.isServer and v38.createBoxes then
		local v39 = p37:getFillUnitFillType(v38.fillUnitIndex)
		if v38.boxes[v39] ~= nil then
			local v40, v41, v42 = getWorldTranslation(v38.spawnPlace)
			local v43, v44, v45 = getWorldRotation(v38.spawnPlace)
			local v46 = Utils.getFilename(v38.boxes[v39], p37.baseDirectory)
			v38.creatingBox = true
			local v47 = VehicleLoadingData.new()
			v47:setFilename(v46)
			v47:setPosition(v40, v41, v42)
			v47:setRotation(v43, v44, v45)
			v47:setPropertyState(VehiclePropertyState.OWNED)
			v47:setOwnerFarmId(p37:getOwnerFarmId())
			v47:load(p37.onCreateBoxFinished, p37, nil)
		end
	end
end
function ReceivingHopper.onCreateBoxFinished(p48, p49, p50, _)
	local v51 = p48.spec_receivingHopper
	v51.creatingBox = false
	if p50 == VehicleLoadingState.OK then
		v51.lastBox = p49[1]
	end
end
function ReceivingHopper.handleDischargeRaycast(p52, _, p53, p54, _, _, p55, _)
	local v56 = false
	if p54 == nil or (not p54:getFillUnitAllowsFillType(p55, (p52:getDischargeFillType(p53))) or p54:getFillUnitFreeCapacity(p55) <= 0) then
		v56 = true
	else
		p52:setDischargeState(Dischargeable.DISCHARGE_STATE_OBJECT, true)
	end
	if v56 and p52:getDischargeState() == Dischargeable.DISCHARGE_STATE_OBJECT then
		p52:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF, true)
	end
end
function ReceivingHopper.getCanBeSelected(_, _)
	return true
end
function ReceivingHopper.onRegisterActionEvents(p57, _, p58)
	if p57.isClient then
		local v59 = p57.spec_receivingHopper
		p57:clearActionEventsTable(v59.actionEvents)
		if p58 then
			local _, v60 = p57:addActionEvent(v59.actionEvents, InputAction.IMPLEMENT_EXTRA, p57, ReceivingHopper.actionEventToggleBoxCreation, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v60, GS_PRIO_NORMAL)
			ReceivingHopper.updateActionEvents(p57)
		end
	end
end
function ReceivingHopper.onFillUnitFillLevelChanged(p61, p62, _, _, _, _, _)
	if p61:getFillUnitFillLevel(p62) > 0 then
		p61:raiseActive()
	end
end
function ReceivingHopper.actionEventToggleBoxCreation(p63, _, _, _, _)
	p63:setCreateBoxes(not p63.spec_receivingHopper.createBoxes)
end
function ReceivingHopper.updateActionEvents(p64)
	local v65 = p64.spec_receivingHopper
	local v66 = v65.actionEvents[InputAction.IMPLEMENT_EXTRA]
	if v66 ~= nil then
		if v65.createBoxes then
			g_inputBinding:setActionEventText(v66.actionEventId, g_i18n:getText("action_disablePalletSpawning"))
			return
		end
		g_inputBinding:setActionEventText(v66.actionEventId, g_i18n:getText("action_enablePalletSpawning"))
	end
end

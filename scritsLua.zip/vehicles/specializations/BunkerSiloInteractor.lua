BunkerSiloInteractor = {}
function BunkerSiloInteractor.prerequisitesPresent(_)
	return true
end
function BunkerSiloInteractor.registerFunctions(p1)
	SpecializationUtil.registerFunction(p1, "setBunkerSiloInteractorCallback", BunkerSiloInteractor.setBunkerSiloInteractorCallback)
	SpecializationUtil.registerFunction(p1, "notifiyBunkerSilo", BunkerSiloInteractor.notifiyBunkerSilo)
end
function BunkerSiloInteractor.registerEventListeners(p2)
	SpecializationUtil.registerEventListener(p2, "onLoad", BunkerSiloInteractor)
end
function BunkerSiloInteractor.onLoad(p3, _)
	local v4 = p3.spec_bunkerSiloInteractor
	v4.callback = nil
	v4.callbackTarget = nil
end
function BunkerSiloInteractor.setBunkerSiloInteractorCallback(p5, p6, p7)
	local v8 = p5.spec_bunkerSiloInteractor
	v8.callback = p6
	v8.callbackTarget = p7
end
function BunkerSiloInteractor.notifiyBunkerSilo(p9, p10, p11, p12, p13, p14)
	local v15 = p9.spec_bunkerSiloInteractor
	if v15.callback ~= nil then
		v15.callback(v15.callbackTarget, p9, p10, p11, p12, p13, p14)
	end
end

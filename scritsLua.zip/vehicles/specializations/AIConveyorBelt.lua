source("dataS/scripts/vehicles/specializations/events/AIConveyorBeltSetAngleEvent.lua")
AIConveyorBelt = {}
function AIConveyorBelt.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AIFieldWorker, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Motorized, p1)
	end
	return v2
end
function AIConveyorBelt.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("AIConveyorBelt")
	v3:register(XMLValueType.FLOAT, "vehicle.ai.conveyorBelt#minAngle", "Min angle", 5)
	v3:register(XMLValueType.FLOAT, "vehicle.ai.conveyorBelt#maxAngle", "Max angle", 45)
	v3:register(XMLValueType.FLOAT, "vehicle.ai.conveyorBelt#stepSize", "Step size", 5)
	v3:register(XMLValueType.FLOAT, "vehicle.ai.conveyorBelt#speed", "Speed", 1)
	v3:register(XMLValueType.INT, "vehicle.ai.conveyorBelt#direction", "Direction", -1)
	v3:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.FLOAT, "vehicles.vehicle(?).aiConveyorBelt#currentAngle", "Current angle", 45)
end
function AIConveyorBelt.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "setAIConveyorBeltAngle", AIConveyorBelt.setAIConveyorBeltAngle)
	SpecializationUtil.registerFunction(p4, "getDirectionAndSpeedToTargetAngle", AIConveyorBelt.getDirectionAndSpeedToTargetAngle)
end
function AIConveyorBelt.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getStartableAIJob", AIConveyorBelt.getStartableAIJob)
	SpecializationUtil.registerOverwrittenFunction(p5, "getHasStartableAIJob", AIConveyorBelt.getHasStartableAIJob)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanStartFieldWork", AIConveyorBelt.getCanStartFieldWork)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanStartAIVehicle", AIConveyorBelt.getCanStartAIVehicle)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanBeSelected", AIConveyorBelt.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAINeedsTrafficCollisionBox", AIConveyorBelt.getAINeedsTrafficCollisionBox)
end
function AIConveyorBelt.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", AIConveyorBelt)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", AIConveyorBelt)
	SpecializationUtil.registerEventListener(p6, "onReadStream", AIConveyorBelt)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", AIConveyorBelt)
	SpecializationUtil.registerEventListener(p6, "onUpdate", AIConveyorBelt)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", AIConveyorBelt)
	SpecializationUtil.registerEventListener(p6, "onAIFieldWorkerStart", AIConveyorBelt)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", AIConveyorBelt)
end
function AIConveyorBelt.onLoad(p7, _)
	local v8 = p7.spec_aiConveyorBelt
	v8.isAllowed = p7.xmlFile:hasProperty("vehicle.ai.conveyorBelt")
	v8.minAngle = p7.xmlFile:getValue("vehicle.ai.conveyorBelt#minAngle", 5)
	v8.maxAngle = p7.xmlFile:getValue("vehicle.ai.conveyorBelt#maxAngle", 45)
	v8.stepSize = p7.xmlFile:getValue("vehicle.ai.conveyorBelt#stepSize", 5)
	v8.currentAngle = v8.maxAngle
	v8.minTargetWorldYRot = 0
	v8.maxTargetWorldYRot = 0
	v8.currentDirection = 0
	v8.currentSpeed = 0
	v8.conveyorJob = g_currentMission.aiJobTypeManager:createJob(AIJobType.CONVEYOR)
	v8.speed = p7.xmlFile:getValue("vehicle.ai.conveyorBelt#speed", 1)
	v8.direction = p7.xmlFile:getValue("vehicle.ai.conveyorBelt#direction", -1)
	if not p7.isServer then
		SpecializationUtil.removeEventListener(p7, "onUpdate", AIConveyorBelt)
	end
	if not p7.isClient then
		SpecializationUtil.removeEventListener(p7, "onUpdateTick", AIConveyorBelt)
	end
end
function AIConveyorBelt.onPostLoad(p9, p10)
	local v11 = p9.spec_aiConveyorBelt
	if p10 ~= nil and not p10.resetVehicles then
		v11.currentAngle = p10.xmlFile:getValue(p10.key .. ".aiConveyorBelt#currentAngle", v11.currentAngle)
	end
end
function AIConveyorBelt.saveToXMLFile(p12, p13, p14, _)
	local v15 = p12.spec_aiConveyorBelt
	p13:setValue(p14 .. "#currentAngle", v15.currentAngle)
end
function AIConveyorBelt.onReadStream(p16, p17, _)
	p16:setAIConveyorBeltAngle(streamReadInt8(p17), true)
end
function AIConveyorBelt.onWriteStream(p18, p19, _)
	streamWriteInt8(p19, p18.spec_aiConveyorBelt.currentAngle)
end
function AIConveyorBelt.onUpdate(p20, p21, _, _, _)
	if p20:getIsAIActive() then
		local v22 = p20.spec_aiConveyorBelt
		local v23, v24 = p20:getDirectionAndSpeedToTargetAngle(v22.currentDirection, v22.minTargetWorldYRot, v22.maxTargetWorldYRot)
		v22.currentDirection = v23
		v22.currentSpeed = v24
		local v25 = p20:getMotor()
		local v26 = v22.currentSpeed * v22.speed
		v25:setSpeedLimit((math.abs(v26)))
		WheelsUtil.updateWheelsPhysics(p20, p21, v22.currentSpeed * v22.speed * v22.direction, v22.currentDirection * v22.direction, false, true)
	end
end
function AIConveyorBelt.onUpdateTick(p27, _, _, p28, _)
	local v29 = p27.spec_aiConveyorBelt
	local v30 = v29.actionEvents[InputAction.IMPLEMENT_EXTRA3]
	if v30 ~= nil then
		g_inputBinding:setActionEventActive(v30.actionEventId, p28)
		if p28 then
			g_inputBinding:setActionEventText(v30.actionEventId, string.format(g_i18n:getText("action_conveyorBeltChangeAngle"), string.format("%.0f", v29.currentAngle)))
		end
	end
end
function AIConveyorBelt.setAIConveyorBeltAngle(p31, p32, p33)
	if p33 == nil or p33 == false then
		if g_server == nil then
			g_client:getServerConnection():sendEvent(AIConveyorBeltSetAngleEvent.new(p31, p32))
		else
			g_server:broadcastEvent(AIConveyorBeltSetAngleEvent.new(p31, p32), nil, nil, p31)
		end
	end
	p31.spec_aiConveyorBelt.currentAngle = p32
end
function AIConveyorBelt.getDirectionAndSpeedToTargetAngle(p34, p35, p36, p37)
	local v38, _, v39 = localDirectionToWorld(p34.components[1].node, 0, 0, 1)
	local v40 = MathUtil.getYRotationFromDirection(v38, v39)
	local v41
	if p35 > 0 then
		if p37 < v40 then
			return -1, 0
		end
		v41 = p37 - v40
	elseif p35 < 0 then
		if v40 < p36 then
			return 1, 0
		end
		v41 = v40 - p36
	else
		v41 = 0
	end
	local v42 = math.deg(v41) / 2.5
	return p35, math.clamp(v42, 0.1, 1) * p35
end
function AIConveyorBelt.getCanStartAIVehicle(p43, p44)
	if p44(p43) then
		return p43.spec_aiConveyorBelt.isAllowed
	else
		return false
	end
end
function AIConveyorBelt.getCanStartFieldWork(p45)
	return p45:getCanStartAIVehicle()
end
function AIConveyorBelt.getStartableAIJob(p46, _)
	if p46:getCanStartFieldWork() then
		local v47 = p46.spec_aiConveyorBelt.conveyorJob
		v47:applyCurrentState(p46, g_currentMission, g_localPlayer.farmId, false)
		v47:setValues()
		if v47:validate(false) then
			return v47
		end
	end
	return nil
end
function AIConveyorBelt.getHasStartableAIJob(_, _)
	return true
end
function AIConveyorBelt.getCanBeSelected(_, _)
	return true
end
function AIConveyorBelt.getAINeedsTrafficCollisionBox(_, _)
	return false
end
function AIConveyorBelt.onAIFieldWorkerStart(p48)
	local v49 = p48.spec_aiConveyorBelt
	local v50, _, v51 = localDirectionToWorld(p48.components[1].node, 0, 0, 1)
	local v52 = MathUtil.getYRotationFromDirection(v50, v51)
	local v53 = v49.currentAngle
	v49.minTargetWorldYRot = v52 - math.rad(v53) / 2
	local v54 = v49.currentAngle
	v49.maxTargetWorldYRot = v52 + math.rad(v54) / 2
	v49.currentDirection = 1
end
function AIConveyorBelt.onRegisterActionEvents(p55, _, p56)
	if p55.isClient then
		local v57 = p55.spec_aiConveyorBelt
		p55:clearActionEventsTable(v57.actionEvents)
		if p56 and v57.isAllowed then
			local _, v58 = p55:addActionEvent(v57.actionEvents, InputAction.IMPLEMENT_EXTRA3, p55, AIConveyorBelt.actionEventChangeAngle, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v58, GS_PRIO_NORMAL)
		end
	end
end
function AIConveyorBelt.actionEventChangeAngle(p59, _, _, _, _)
	local v60 = p59.spec_aiConveyorBelt
	local v61 = v60.currentAngle + v60.stepSize
	if v60.maxAngle < v61 then
		v61 = v60.minAngle
	end
	p59:setAIConveyorBeltAngle(v61)
end

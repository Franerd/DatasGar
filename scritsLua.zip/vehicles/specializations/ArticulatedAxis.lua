ArticulatedAxis = {}
function ArticulatedAxis.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Drivable, p1)
end
function ArticulatedAxis.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("ArticulatedAxis")
	v2:register(XMLValueType.INT, "vehicle.articulatedAxis#componentJointIndex", "Index of component joint")
	v2:register(XMLValueType.ANGLE, "vehicle.articulatedAxis#rotSpeed", "Rotation speed")
	v2:register(XMLValueType.ANGLE, "vehicle.articulatedAxis#rotMax", "Max rotation")
	v2:register(XMLValueType.ANGLE, "vehicle.articulatedAxis#rotMin", "Min rotation")
	v2:register(XMLValueType.INT, "vehicle.articulatedAxis#anchorActor", "Anchor actor index", 0)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.articulatedAxis#rotNode", "Rotation node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.articulatedAxis#aiReverserNode", "AI reverser node")
	v2:register(XMLValueType.FLOAT, "vehicle.articulatedAxis#maxTurningRadius", "Fixed turning radius to overwrite automatic calculations")
	v2:register(XMLValueType.VECTOR_N, "vehicle.articulatedAxis#customWheelIndices1", "Component 1 wheel indices. Needed if wheels are not linked to component 1 directly. E.g. dolly axis")
	v2:register(XMLValueType.VECTOR_N, "vehicle.articulatedAxis#customWheelIndices2", "Component 2 wheel indices. Needed if wheels are not linked to component 2 directly. E.g. dolly axis")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.articulatedAxis.rotatingPart(?)#node", "Rotation part node")
	v2:register(XMLValueType.VECTOR_ROT, "vehicle.articulatedAxis.rotatingPart(?)#posRot", "Positive rotation")
	v2:register(XMLValueType.VECTOR_ROT, "vehicle.articulatedAxis.rotatingPart(?)#negRot", "Negative rotation")
	v2:register(XMLValueType.FLOAT, "vehicle.articulatedAxis.rotatingPart(?)#posRotFactor", "Positive rotation factor", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.articulatedAxis.rotatingPart(?)#negRotFactor", "Negative rotation factor", 1)
	v2:register(XMLValueType.BOOL, "vehicle.articulatedAxis.rotatingPart(?)#invertSteeringAngle", "Invert steering angle", false)
	SoundManager.registerSampleXMLPaths(v2, "vehicle.articulatedAxis.sounds", "steering")
	v2:setXMLSpecializationType()
end
function ArticulatedAxis.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "getSteeringRotTimeByCurvature", ArticulatedAxis.getSteeringRotTimeByCurvature)
	SpecializationUtil.registerOverwrittenFunction(p3, "getTurningRadiusByRotTime", ArticulatedAxis.getTurningRadiusByRotTime)
	SpecializationUtil.registerOverwrittenFunction(p3, "getAIReverserNode", ArticulatedAxis.getAIReverserNode)
end
function ArticulatedAxis.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", ArticulatedAxis)
	SpecializationUtil.registerEventListener(p4, "onPostLoad", ArticulatedAxis)
	SpecializationUtil.registerEventListener(p4, "onDelete", ArticulatedAxis)
	SpecializationUtil.registerEventListener(p4, "onDeactivate", ArticulatedAxis)
	SpecializationUtil.registerEventListener(p4, "onUpdate", ArticulatedAxis)
end
function ArticulatedAxis.onLoad(p5, _)
	local v6 = p5.xmlFile
	local v7 = p5.spec_articulatedAxis
	XMLUtil.checkDeprecatedXMLElements(p5.xmlFile, "vehicle.articulatedAxis.rotatingPart(0)#index", "vehicle.articulatedAxis.rotatingPart(0)#node")
	local v8 = v6:getValue("vehicle.articulatedAxis#componentJointIndex")
	if v8 ~= nil then
		if v8 == 0 then
			Logging.xmlWarning(p5.xmlFile, "Invalid component joint index \'0\' for articulatedAxis. Indices start with 1!")
		else
			local v9 = p5.componentJoints[v8]
			local v10 = v6:getValue("vehicle.articulatedAxis#rotSpeed")
			local v11 = v6:getValue("vehicle.articulatedAxis#rotMax")
			local v12 = v6:getValue("vehicle.articulatedAxis#rotMin")
			if v9 ~= nil and (v10 ~= nil and (v11 ~= nil and v12 ~= nil)) then
				v7.rotSpeed = v10
				v7.rotMax = v11
				v7.rotMin = v12
				v7.componentJoint = v9
				v7.anchorActor = v6:getValue("vehicle.articulatedAxis#anchorActor", 0)
				v7.rotationNode = v6:getValue("vehicle.articulatedAxis#rotNode", nil, p5.components, p5.i3dMappings)
				if v7.rotationNode == nil then
					v7.rotationNode = v7.componentJoint.jointNode
				end
				v7.curRot = 0
				v7.rotatingParts = {}
				for _, v13 in v6:iterator("vehicle.articulatedAxis.rotatingPart") do
					local v14 = v6:getValue(v13 .. "#node", nil, p5.components, p5.i3dMappings)
					if v14 == nil then
						Logging.xmlWarning(p5.xmlFile, "Failed to load rotation part \'%s\'", v13)
					else
						local v15 = {
							["node"] = v14,
							["defRot"] = { getRotation(v14) },
							["posRot"] = v6:getValue(v13 .. "#posRot", nil, true)
						}
						if v15.posRot == nil then
							Logging.xmlError(v6, "Missing values for \'%s\'", v13 .. "#posRot")
						else
							v15.negRot = v6:getValue(v13 .. "#negRot", nil, true)
							if v15.negRot == nil then
								Logging.xmlError(v6, "Missing values for \'%s\'", v13 .. "#negRot")
							else
								v15.negRotFactor = v6:getValue(v13 .. "#negRotFactor", 1)
								v15.posRotFactor = v6:getValue(v13 .. "#posRotFactor", 1)
								v15.invertSteeringAngle = v6:getValue(v13 .. "#invertSteeringAngle", false)
								local v16 = v7.rotatingParts
								table.insert(v16, v15)
							end
						end
					end
				end
				local v17 = {
					{},
					{}
				}
				local v18 = v6:getValue("vehicle.articulatedAxis#customWheelIndices1", nil, true)
				if v18 ~= nil then
					for _, v19 in ipairs(v18) do
						v17[1][v19] = true
					end
				end
				local v20 = v6:getValue("vehicle.articulatedAxis#customWheelIndices2", nil, true)
				if v20 ~= nil then
					for _, v21 in ipairs(v20) do
						v17[2][v21] = true
					end
				end
				local v22 = v11 / v10
				local v23 = v12 / v10
				if v22 >= v23 then
					local v24 = v22
					v22 = v23
					v23 = v24
				end
				if p5.maxRotTime < v23 then
					p5.maxRotTime = v23
				end
				if v22 < p5.minRotTime then
					p5.minRotTime = v22
				end
				p5.maxRotation = v11
				p5.wheelSteeringDuration = math.sign(v10) * v11 / v10
				v7.aiReverserNode = v6:getValue("vehicle.articulatedAxis#aiReverserNode", nil, p5.components, p5.i3dMappings)
				local v25 = p5.spec_wheels
				local v26 = 0
				for v27 = 1, 2 do
					local v28 = p5.components[v9.componentIndices[v27]].node
					local v29 = 0
					for v30, v31 in ipairs(v25.wheels) do
						if p5:getParentComponent(v31.repr) == v28 or v17[v27][v30] ~= nil then
							v29 = v29 + 1
							local v32, _, v33 = localToLocal(v31.driveNode, v28, 0, 0, 0)
							local v34 = v32 < 0 and -1 or 1
							local v35 = v31.physics.rotMin
							local v36 = v31.physics.rotMax
							local v37 = math.max(v35, v36)
							local v38 = math.tan(v37)
							if v33 > 0 then
								v38 = -v38
							end
							local v39 = v32 < 0 and -1 or 1
							local v40 = math.max(v12, v11)
							local v41 = math.tan(v40)
							if v33 < 0 then
								v41 = -v41
							end
							local v42 = MathUtil.vector2Length(v34, v38)
							local v43 = v34 / v42
							local v44 = v38 / v42
							local v45 = MathUtil.vector2Length(v39, v41)
							local v46 = v39 / v45
							local v47 = v41 / v45
							local v48, _, v49 = MathUtil.getLineLineIntersection2D(v32, v33, v43, v44, 0, 0, v46, v47)
							if v48 then
								local v50 = math.abs(v49)
								v26 = math.max(v26, v50)
							end
						end
					end
					if v29 < 2 then
						Logging.warning("Could not find articulated axis wheels for component %d. Requires at least two wheels. Need to be added via \'customWheelIndices%d\' attribute if not directly inside the component.", v27, v27)
					end
				end
				if v26 ~= 0 then
					p5.maxTurningRadius = v26
				end
				p5.maxTurningRadius = v6:getValue("vehicle.articulatedAxis#maxTurningRadius", p5.maxTurningRadius)
			end
		end
	end
	if p5.isClient then
		v7.samples = {}
		v7.samples.steering = g_soundManager:loadSampleFromXML(p5.xmlFile, "vehicle.articulatedAxis.sounds", "steering", p5.baseDirectory, p5.components, 0, AudioGroup.VEHICLE, p5.i3dMappings, p5)
		v7.isSteeringSoundPlaying = false
	end
	v7.interpolatedRotatedTime = 0
end
function ArticulatedAxis.onPostLoad(p51)
	if p51.spec_articulatedAxis.componentJoint == nil then
		SpecializationUtil.removeEventListener(p51, "onUpdate", ArticulatedAxis)
	elseif p51.updateArticulatedAxisRotation ~= nil then
		p51:updateArticulatedAxisRotation(0, 99999)
		return
	end
end
function ArticulatedAxis.onDelete(p52)
	if p52.isClient then
		local v53 = p52.spec_articulatedAxis
		g_soundManager:deleteSamples(v53.samples)
	end
end
function ArticulatedAxis.onDeactivate(p54)
	if p54.isClient then
		local v55 = p54.spec_articulatedAxis
		g_soundManager:stopSamples(v55.samples)
		v55.isSteeringSoundPlaying = false
	end
end
function ArticulatedAxis.onUpdate(p56, p57, _, _, _)
	local v58 = p56.spec_articulatedAxis
	if v58.interpolatedRotatedTime < p56.rotatedTime then
		local v59 = p56.rotatedTime
		local v60 = v58.interpolatedRotatedTime
		local v61 = v58.rotSpeed
		local v62 = v60 + math.abs(v61) * p57 / 500
		v58.interpolatedRotatedTime = math.min(v59, v62)
	elseif v58.interpolatedRotatedTime > p56.rotatedTime then
		local v63 = p56.rotatedTime
		local v64 = v58.interpolatedRotatedTime
		local v65 = v58.rotSpeed
		local v66 = v64 - math.abs(v65) * p57 / 500
		v58.interpolatedRotatedTime = math.max(v63, v66)
	end
	local v67 = p56.rotatedTime * v58.rotSpeed
	local v68 = v58.rotMin
	local v69 = v58.rotMax
	local v70 = math.clamp(v67, v68, v69)
	if p56.updateArticulatedAxisRotation ~= nil then
		v70 = p56:updateArticulatedAxisRotation(v70, p57)
	end
	if p56.isClient then
		local v71 = v70 - v58.curRot
		local v72 = math.abs(v71) > 0.0001
		if v72 ~= v58.isSteeringSoundPlaying then
			if v72 then
				g_soundManager:playSample(v58.samples.steering)
			else
				g_soundManager:stopSample(v58.samples.steering)
			end
			v58.isSteeringSoundPlaying = v72
		end
	end
	local v73 = v70 - v58.curRot
	if math.abs(v73) > 1e-6 then
		if p56.isServer then
			setRotation(v58.rotationNode, 0, v70, 0)
			p56:setComponentJointFrame(v58.componentJoint, v58.anchorActor)
		end
		v58.curRot = v70
		if p56.isClient then
			local v74 = 0
			if v70 > 0 then
				v74 = v70 / v58.rotMax
			elseif v70 < 0 then
				v74 = v70 / v58.rotMin
			end
			for _, v75 in pairs(v58.rotatingParts) do
				local v76, v77, v78
				if v70 > 0 and not v75.invertSteeringAngle or v70 < 0 and v75.invertSteeringAngle then
					local v79 = MathUtil.vector3ArrayLerp
					local v80 = v75.defRot
					local v81 = v75.posRot
					local v82 = v74 * v75.posRotFactor
					v76, v77, v78 = v79(v80, v81, (math.min(1, v82)))
				else
					local v83 = MathUtil.vector3ArrayLerp
					local v84 = v75.defRot
					local v85 = v75.negRot
					local v86 = v74 * v75.negRotFactor
					v76, v77, v78 = v83(v84, v85, (math.min(1, v86)))
				end
				setRotation(v75.node, v76, v77, v78)
				if p56.setMovingToolDirty ~= nil then
					p56:setMovingToolDirty(v75.node)
				end
			end
		end
	end
end
function ArticulatedAxis.getSteeringRotTimeByCurvature(p87, _, p88)
	local v89 = p87.wheelSteeringDuration
	local v90 = math.atan(p88)
	local v91 = 1 / p87.maxTurningRadius
	return v89 * (v90 / math.atan(v91))
end
function ArticulatedAxis.getTurningRadiusByRotTime(p92, p93, p94)
	local v95 = p92.spec_articulatedAxis
	if v95.componentJoint == nil or v95.rotSpeed == 0 then
		return p93(p92, p94)
	end
	local v96 = v95.rotSpeed
	local v97 = p92.maxRotation
	local v98 = p94 / (math.sign(v96) * v97 / v96)
	local v99 = 1 / p92.maxTurningRadius
	local v100 = v98 * math.atan(v99)
	local v101 = -math.tan(v100)
	return v101 == 0 and (1 / 0) or 1 / v101
end
function ArticulatedAxis.getAIReverserNode(p102, p103)
	return p102.spec_articulatedAxis.aiReverserNode or p103(p102)
end

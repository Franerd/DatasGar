WindBending = {}
function WindBending.prerequisitesPresent(_)
	return true
end
function WindBending.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("WindBending")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.windBending.windBendingNodes.windBendingNode(?)#node", "Shader node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.windBending.windBendingNodes.windBendingNode(?)#decalNode", "Extra node that gets the exact same shader parameters")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.windBending.windBendingNodes.windBendingNode(?)#speedReferenceNode", "Reference node to calculate speed of wind")
	v1:register(XMLValueType.FLOAT, "vehicle.windBending.windBendingNodes.windBendingNode(?)#maxBending", "Bending in meters", 0.15)
	v1:register(XMLValueType.FLOAT, "vehicle.windBending.windBendingNodes.windBendingNode(?)#maxBendingNeg", "Negative bending in meters (used if the vehicle drives in reverse)", "same as #maxBending")
	v1:register(XMLValueType.FLOAT, "vehicle.windBending.windBendingNodes.windBendingNode(?)#maxBendingSpeed", "Speed at which max bending state is reached in kmph", 20)
	v1:setXMLSpecializationType()
end
function WindBending.registerFunctions(_) end
function WindBending.registerEventListeners(p2)
	SpecializationUtil.registerEventListener(p2, "onLoad", WindBending)
	SpecializationUtil.registerEventListener(p2, "onUpdate", WindBending)
end
function WindBending.onLoad(p_u_3, _)
	local v_u_4 = p_u_3.spec_windBending
	if p_u_3.isClient then
		v_u_4.windBending = {}
		p_u_3.xmlFile:iterate("vehicle.windBending.windBendingNodes.windBendingNode", function(_, p5)
			-- upvalues: (copy) p_u_3, (copy) v_u_4
			local v6 = {
				["node"] = p_u_3.xmlFile:getValue(p5 .. "#node", nil, p_u_3.components, p_u_3.i3dMappings)
			}
			if v6.node == nil then
				Logging.xmlError(p_u_3.xmlFile, "Unable to load wind bending node from xml. Node not found. \'%s\'", p5)
				return
			elseif getHasClassId(v6.node, ClassIds.SHAPE) and getHasShaderParameter(v6.node, "directionBend") then
				v6.speedReferenceNode = p_u_3.xmlFile:getValue(p5 .. "#speedReferenceNode", v6.node, p_u_3.components, p_u_3.i3dMappings)
				v6.parentComponent = p_u_3:getParentComponent(v6.speedReferenceNode)
				v6.maxBending = p_u_3.xmlFile:getValue(p5 .. "#maxBending", 0.15)
				v6.maxBendingNeg = p_u_3.xmlFile:getValue(p5 .. "#maxBendingNeg", v6.maxBending)
				v6.maxBendingSpeed = p_u_3.xmlFile:getValue(p5 .. "#maxBendingSpeed", 20)
				v6.decalNode = p_u_3.xmlFile:getValue(p5 .. "#decalNode", nil, p_u_3.components, p_u_3.i3dMappings)
				v6.lastPosition = nil
				local v7 = v_u_4.windBending
				table.insert(v7, v6)
			else
				Logging.xmlError(p_u_3.xmlFile, "Unable to load wind bending node from xml. Node has not shader parameter \'directionBend\'. \'%s\'", p5)
			end
		end)
	end
	if not p_u_3.isClient or #v_u_4.windBending == 0 then
		SpecializationUtil.removeEventListener(p_u_3, "onUpdate", WindBending)
	end
end
function WindBending.onUpdate(p8, _, _, _, _)
	local v9 = p8.spec_windBending
	local v10 = p8:getLastSpeed()
	for v11 = 1, #v9.windBending do
		local v12 = v9.windBending[v11]
		local v13, v14, v15 = localToWorld(v12.speedReferenceNode, 0, 0, 0)
		if v12.lastPosition == nil then
			v12.lastPosition = { v13, v14, v15 }
		end
		local v16 = (v13 - v12.lastPosition[1]) * 10
		local v17 = (v14 - v12.lastPosition[2]) * 10
		local v18 = (v15 - v12.lastPosition[3]) * 10
		if v16 ~= 0 or (v17 ~= 0 or v18 ~= 0) then
			local v19, v20, v21 = worldDirectionToLocal(getParent(v12.node), v16, v17, v18)
			local v22, v23, v24 = MathUtil.vector3Normalize(v19, v20, v21)
			local v25 = (p8.movingDirection >= 0 and v12.maxBending or v12.maxBendingNeg) * (v10 / v12.maxBendingSpeed)
			g_animationManager:setPrevShaderParameter(v12.node, "directionBend", v22, v23, v24, v25, false, "prevDirectionBend")
			if v12.decalNode ~= nil then
				g_animationManager:setPrevShaderParameter(v12.decalNode, "directionBend", v22, v23, v24, v25, false, "prevDirectionBend")
			end
		end
		v12.lastPosition[1] = v13
		v12.lastPosition[2] = v14
		v12.lastPosition[3] = v15
	end
end

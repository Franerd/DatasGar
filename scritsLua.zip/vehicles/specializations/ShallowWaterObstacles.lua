ShallowWaterObstacles = {}
ShallowWaterObstacles.OBSTACLE_NODE_XML_KEY = "vehicle.shallowWaterObstacle.obstacleNode(?)"
function ShallowWaterObstacles.prerequisitesPresent(_)
	return true
end
function ShallowWaterObstacles.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("ShallowWaterObstacles")
	local v2 = ShallowWaterObstacles.OBSTACLE_NODE_XML_KEY
	v1:register(XMLValueType.NODE_INDEX, v2 .. "#node", "Obstacle node")
	v1:register(XMLValueType.NODE_INDEX, v2 .. "#directionNode", "Node that is used as reference for the moving direction", "Same as #node")
	v1:register(XMLValueType.VECTOR_3, v2 .. "#size", "Size of the obstacle in m", "1 1 1")
	v1:register(XMLValueType.VECTOR_TRANS, v2 .. "#offset", "Offset of the obstacle in local space", "0 0 0")
	v1:setXMLSpecializationType()
end
function ShallowWaterObstacles.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "loadObstacleNodeFromXML", ShallowWaterObstacles.loadObstacleNodeFromXML)
end
function ShallowWaterObstacles.registerEventListeners(p4)
	if Platform.hasShallowWaterSimulation then
		SpecializationUtil.registerEventListener(p4, "onPostLoad", ShallowWaterObstacles)
		SpecializationUtil.registerEventListener(p4, "onLoadFinished", ShallowWaterObstacles)
		SpecializationUtil.registerEventListener(p4, "onDelete", ShallowWaterObstacles)
	end
end
function ShallowWaterObstacles.onPostLoad(p5, _)
	local v6 = p5.spec_shallowWaterObstacles
	v6.obstacleNodes = {}
	for _, v7 in p5.xmlFile:iterator("vehicle.shallowWaterObstacle.obstacleNode") do
		local v8 = {}
		if p5:loadObstacleNodeFromXML(p5.xmlFile, v7, v8) then
			local v9 = v6.obstacleNodes
			table.insert(v9, v8)
			v8.vehicle = p5
			v8.index = #v6.obstacleNodes
		end
	end
	if #v6.obstacleNodes == 0 then
		SpecializationUtil.removeEventListener(p5, "onLoadFinished", ShallowWaterObstacles)
		SpecializationUtil.removeEventListener(p5, "onDelete", ShallowWaterObstacles)
		v6.obstacleNodes = nil
	end
end
function ShallowWaterObstacles.onLoadFinished(p10, _)
	if p10.propertyState ~= VehiclePropertyState.SHOP_CONFIG then
		local v11 = p10.spec_shallowWaterObstacles
		for _, v12 in ipairs(v11.obstacleNodes) do
			v12.shallowWaterObstacle = g_currentMission.shallowWaterSimulation:addObstacle(v12.node, v12.size[1], v12.size[2], v12.size[3], ShallowWaterObstacles.getShallowWaterParameters, v12, v12.offset)
		end
	end
end
function ShallowWaterObstacles.onDelete(p13)
	local v14 = p13.spec_shallowWaterObstacles
	if v14.obstacleNodes ~= nil then
		for _, v15 in ipairs(v14.obstacleNodes) do
			if v15.shallowWaterObstacle ~= nil then
				g_currentMission.shallowWaterSimulation:removeObstacle(v15.shallowWaterObstacle)
				v15.shallowWaterObstacle = nil
			end
		end
	end
end
function ShallowWaterObstacles.loadObstacleNodeFromXML(p16, p17, p18, p19)
	local v20 = p17:getValue(p18 .. "#node", nil, p16.components, p16.i3dMappings)
	if v20 == nil then
		Logging.xmlWarning(p17, "Missing node for obstacle node \'%s\'", p18)
		return false
	end
	p19.node = v20
	p19.directionNode = p17:getValue(p18 .. "#directionNode", v20, p16.components, p16.i3dMappings)
	p19.size = p17:getValue(p18 .. "#size", "1 1 1", true)
	p19.offset = p17:getValue(p18 .. "#offset", nil, true)
	return true
end
function ShallowWaterObstacles.getShallowWaterParameters(p21)
	local v22 = p21.vehicle.lastSignedSpeed * 1000
	local v23, _, v24 = localDirectionToWorld(p21.directionNode, 0, 0, 1)
	return v23 * v22, v24 * v22, MathUtil.getYRotationFromDirection(v23, v24)
end

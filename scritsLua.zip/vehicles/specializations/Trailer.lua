source("dataS/scripts/vehicles/specializations/events/TrailerToggleTipSideEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TrailerToggleManualTipEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TrailerToggleManualDoorEvent.lua")
Trailer = {}
Trailer.TIPSTATE_CLOSED = 0
Trailer.TIPSTATE_OPENING = 1
Trailer.TIPSTATE_OPEN = 2
Trailer.TIPSTATE_CLOSING = 3
Trailer.TIP_SIDE_NUM_BITS = 3
Trailer.TIP_STATE_NUM_BITS = 2
function Trailer.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(FillUnit, p1) and SpecializationUtil.hasSpecialization(Dischargeable, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	end
	return v2
end
function Trailer.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("trailer", g_i18n:getText("configuration_trailer"), "trailer", VehicleConfigurationItem)
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Trailer")
	v3:register(XMLValueType.L10N_STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer#infoText", "Info text", "action_toggleTipSide")
	v3:register(XMLValueType.STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?)#name", "Tip side name")
	v3:register(XMLValueType.INT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?)#dischargeNodeIndex", "Discharge node index")
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?)#canTipIfEmpty", "Can tip if empty", true)
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?)#canTip", "Can tip (if false, only back door control is allowed)", true)
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualTipToggle#enabled", "Tip animation can be toggled manually without dischargeable", false)
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualTipToggle#stopOnDeactivate", "Stop manual tipping while vehicle is deactivated (detached, exited etc)", true)
	v3:register(XMLValueType.STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualTipToggle#inputAction", "Input action to toggle tipping", "IMPLEMENT_EXTRA4")
	v3:register(XMLValueType.L10N_STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualTipToggle#inputActionTextPos", "Positive input text to display", "action_startTipping")
	v3:register(XMLValueType.L10N_STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualTipToggle#inputActionTextNeg", "Negative input text to display", "action_stopTipping")
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualDoorToggle#enabled", "Door animation can be toggled manually without dischargeable", false)
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualDoorToggle#openWhileTipping", "Still automatically open the door while tipping", false)
	v3:register(XMLValueType.STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualDoorToggle#inputAction", "Input action to toggle tipping", "IMPLEMENT_EXTRA3")
	v3:register(XMLValueType.L10N_STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualDoorToggle#inputActionTextPos", "Positive input text to display", "action_openBackDoor")
	v3:register(XMLValueType.L10N_STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualDoorToggle#inputActionTextNeg", "Negative input text to display", "action_closeBackDoor")
	v3:register(XMLValueType.INT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualDoorToggle.fillUnit#index", "Reference fill unit index for fill level detection")
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).manualDoorToggle.fillUnit#allowWhileFilled", "Allow manual door opening when fill unit is filled", true)
	v3:register(XMLValueType.STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).animation#name", "Tip animation name")
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).animation#speedScale", "Tip animation speed scale", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).animation#closeSpeedScale", "Tip animation speed scale while stopping to tip", "inversed speed scale")
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).animation#startTipTime", "Tip animation start tip time", 0)
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).animation#resetTipSideChange", "Reset tip animation to zero while tip side is activated", false)
	v3:register(XMLValueType.STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).doorAnimation#name", "Door animation name")
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).doorAnimation#speedScale", "Door animation speed scale", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).doorAnimation#closeSpeedScale", "Door animation speed scale while stopping to tip", "inversed speed scale")
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).doorAnimation#startTipTime", "Door animation start tip time", 0)
	v3:register(XMLValueType.BOOL, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).doorAnimation#delayedClosing", "Play door animation after tip animation while closing", false)
	v3:register(XMLValueType.STRING, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).tippingAnimation#name", "Tipping animation name (continuously played while tipping)")
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).tippingAnimation#speedScale", "Tipping animation speed scale", 1)
	v3:register(XMLValueType.INT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).fillLevel#fillUnitIndex", "Fill unit index to check")
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).fillLevel#minFillLevelPct", "Min. trailer fill level pct to select tip side", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).fillLevel#maxFillLevelPct", "Max. trailer fill level pct to select tip side", 1)
	AnimationManager.registerAnimationNodesXMLPaths(v3, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?).animationNodes")
	ObjectChangeUtil.registerObjectChangeXMLPaths(v3, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?)")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.trailer.trailerConfigurations.trailerConfiguration(?).trailer.tipSide(?)", "unloadSound")
	v3:addDelayedRegistrationFunc("AnimatedVehicle:part", function(p4, p5)
		p4:register(XMLValueType.FLOAT, p5 .. "#startTipSideEmptyFactor", "Start tip side empty factor")
		p4:register(XMLValueType.FLOAT, p5 .. "#endTipSideEmptyFactor", "End tip side empty factor")
	end)
	v3:register(XMLValueType.BOOL, Pickup.PICKUP_XML_KEY .. "#allowWhileTipping", "Allow pickup movement while tipping", true)
	v3:register(XMLValueType.BOOL, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#playWhileTipping", "Animation is active while tipping", false)
	v3:setXMLSpecializationType()
	local v6 = Vehicle.xmlSchemaSavegame
	v6:register(XMLValueType.INT, "vehicles.vehicle(?).trailer#tipSideIndex", "Current tip side index")
	v6:register(XMLValueType.BOOL, "vehicles.vehicle(?).trailer#doorState", "Current back door state")
	v6:register(XMLValueType.INT, "vehicles.vehicle(?).trailer#tipState", "Current tip state")
	v6:register(XMLValueType.FLOAT, "vehicles.vehicle(?).trailer#tipAnimationTime", "Current tip animation time")
end
function Trailer.registerEvents(p7)
	SpecializationUtil.registerEvent(p7, "onStartTipping")
	SpecializationUtil.registerEvent(p7, "onOpenBackDoor")
	SpecializationUtil.registerEvent(p7, "onStopTipping")
	SpecializationUtil.registerEvent(p7, "onCloseBackDoor")
	SpecializationUtil.registerEvent(p7, "onEndTipping")
end
function Trailer.registerFunctions(p8)
	SpecializationUtil.registerFunction(p8, "loadTipSide", Trailer.loadTipSide)
	SpecializationUtil.registerFunction(p8, "getCanTogglePreferdTipSide", Trailer.getCanTogglePreferdTipSide)
	SpecializationUtil.registerFunction(p8, "getIsTipSideAvailable", Trailer.getIsTipSideAvailable)
	SpecializationUtil.registerFunction(p8, "getNextAvailableTipSide", Trailer.getNextAvailableTipSide)
	SpecializationUtil.registerFunction(p8, "setPreferedTipSide", Trailer.setPreferedTipSide)
	SpecializationUtil.registerFunction(p8, "startTipping", Trailer.startTipping)
	SpecializationUtil.registerFunction(p8, "stopTipping", Trailer.stopTipping)
	SpecializationUtil.registerFunction(p8, "endTipping", Trailer.endTipping)
	SpecializationUtil.registerFunction(p8, "setTrailerDoorState", Trailer.setTrailerDoorState)
	SpecializationUtil.registerFunction(p8, "getAllowTrailerDoorToggle", Trailer.getAllowTrailerDoorToggle)
	SpecializationUtil.registerFunction(p8, "getTipState", Trailer.getTipState)
	SpecializationUtil.registerFunction(p8, "setTipState", Trailer.setTipState)
	SpecializationUtil.registerFunction(p8, "updateTrailerAutomaticRedischarge", Trailer.updateTrailerAutomaticRedischarge)
end
function Trailer.registerOverwrittenFunctions(p9)
	SpecializationUtil.registerOverwrittenFunction(p9, "getDischargeNodeEmptyFactor", Trailer.getDischargeNodeEmptyFactor)
	SpecializationUtil.registerOverwrittenFunction(p9, "getCanDischargeToGround", Trailer.getCanDischargeToGround)
	SpecializationUtil.registerOverwrittenFunction(p9, "getCanDischargeToObject", Trailer.getCanDischargeToObject)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsNextCoverStateAllowed", Trailer.getIsNextCoverStateAllowed)
	SpecializationUtil.registerOverwrittenFunction(p9, "getCanBeSelected", Trailer.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p9, "getAIHasFinishedDischarge", Trailer.getAIHasFinishedDischarge)
	SpecializationUtil.registerOverwrittenFunction(p9, "startAIDischarge", Trailer.startAIDischarge)
	SpecializationUtil.registerOverwrittenFunction(p9, "loadPickupFromXML", Trailer.loadPickupFromXML)
	SpecializationUtil.registerOverwrittenFunction(p9, "getCanChangePickupState", Trailer.getCanChangePickupState)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsTurnedOnAnimationActive", Trailer.getIsTurnedOnAnimationActive)
	SpecializationUtil.registerOverwrittenFunction(p9, "loadTurnedOnAnimationFromXML", Trailer.loadTurnedOnAnimationFromXML)
	SpecializationUtil.registerOverwrittenFunction(p9, "getRequiresPower", Trailer.getRequiresPower)
	SpecializationUtil.registerOverwrittenFunction(p9, "setManualDischargeState", Trailer.setManualDischargeState)
end
function Trailer.registerEventListeners(p10)
	SpecializationUtil.registerEventListener(p10, "onLoad", Trailer)
	SpecializationUtil.registerEventListener(p10, "onPostLoad", Trailer)
	SpecializationUtil.registerEventListener(p10, "onLoadFinished", Trailer)
	SpecializationUtil.registerEventListener(p10, "onDelete", Trailer)
	SpecializationUtil.registerEventListener(p10, "onReadStream", Trailer)
	SpecializationUtil.registerEventListener(p10, "onWriteStream", Trailer)
	SpecializationUtil.registerEventListener(p10, "onUpdate", Trailer)
	SpecializationUtil.registerEventListener(p10, "onRegisterActionEvents", Trailer)
	SpecializationUtil.registerEventListener(p10, "onDischargeStateChanged", Trailer)
	SpecializationUtil.registerEventListener(p10, "onDeactivate", Trailer)
	SpecializationUtil.registerEventListener(p10, "onRegisterAnimationValueTypes", Trailer)
	SpecializationUtil.registerEventListener(p10, "onFillUnitFillLevelChanged", Trailer)
end
function Trailer.onLoad(p11, _)
	local v12 = p11.spec_trailer
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.tipScrollerNodes.tipScrollerNode", "vehicle.trailer.trailerConfigurations.trailerConfiguration.trailer.tipSide.animationNodes.animationNode")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.tipRotationNodes.tipRotationNode", "vehicle.trailer.trailerConfigurations.trailerConfiguration.trailer.tipSide.animationNodes.animationNode")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.tipAnimations.tipAnimation", "vehicle.trailer.trailerConfigurations.trailerConfiguration.trailer.tipSide")
	local v13 = Utils.getNoNil(p11.configurations.trailer, 1)
	local v14 = string.format("vehicle.trailer.trailerConfigurations.trailerConfiguration(%d).trailer", v13 - 1)
	v12.fillLevelDependentTipSides = false
	v12.tipSideUpdateDirty = false
	v12.tipSides = {}
	v12.dischargeNodeIndexToTipSide = {}
	local v15 = 0
	while true do
		local v16 = string.format("%s.tipSide(%d)", v14, v15)
		if not p11.xmlFile:hasProperty(v16) then
			break
		end
		local v17 = {}
		if p11:loadTipSide(p11.xmlFile, v16, v17) then
			local v18 = v12.tipSides
			table.insert(v18, v17)
			v17.index = #v12.tipSides
			if v17.dischargeNodeIndex ~= nil then
				v12.dischargeNodeIndexToTipSide[v17.dischargeNodeIndex] = v17
			end
		end
		v15 = v15 + 1
	end
	v12.infoText = p11.xmlFile:getValue(v14 .. "#infoText", "action_toggleTipSide", p11.customEnvironment, false)
	v12.tipSideCount = #v12.tipSides
	v12.preferedTipSideIndex = 1
	v12.currentTipSideIndex = nil
	v12.tipState = Trailer.TIPSTATE_CLOSED
	v12.remainingFillDelta = 0
	v12.redischarge = {}
	v12.redischarge.isDisabled = false
	v12.redischarge.dischargeObject = nil
	v12.redischarge.dischargeNodeLastPos = { 0, 0, 0 }
	v12.dirtyFlag = p11:getNextDirtyFlag()
end
function Trailer.onPostLoad(p19, p20)
	local v21 = p19.spec_trailer
	for v22, v23 in ipairs(v21.tipSides) do
		if v23.dischargeNodeIndex ~= nil and p19:getDischargeNodeByIndex(v23.dischargeNodeIndex) == nil then
			Logging.xmlWarning(p19.xmlFile, "Unknown dischargeNodeIndex \'%s\' for tipSide index \'%s\'", v23.dischargeNodeIndex, v22)
		end
	end
	if p20 ~= nil and v21.tipSideCount > 0 then
		if v21.tipSideCount > 1 then
			local v24 = p20.xmlFile:getValue(p20.key .. ".trailer#tipSideIndex")
			if v24 ~= nil then
				p19:setPreferedTipSide(v24, true)
			end
		end
		local v25 = p20.xmlFile:getValue(p20.key .. ".trailer#doorState")
		if v25 ~= nil then
			p19:setTrailerDoorState(v21.preferedTipSideIndex, v25, true, true)
		end
		v21.tipState = p20.xmlFile:getValue(p20.key .. ".trailer#tipState", v21.tipState)
		if v21.tipState == Trailer.TIPSTATE_OPENING or v21.tipState == Trailer.TIPSTATE_OPEN then
			v21.currentTipSideIndex = v21.preferedTipSideIndex
			p19:setTipState(true)
		end
		local v26 = p20.xmlFile:getValue(p20.key .. ".trailer#tipAnimationTime")
		if v26 ~= nil then
			p19:setAnimationTime(v21.tipSides[v21.preferedTipSideIndex].animation.name, v26, true, false)
		end
	end
end
function Trailer.onLoadFinished(p27, _)
	local v28 = p27.spec_trailer
	if v28.tipSideCount > 1 and not p27:getIsTipSideAvailable(v28.preferedTipSideIndex) then
		v28.tipSideUpdateDirty = true
	end
end
function Trailer.onDelete(p29)
	local v30 = p29.spec_trailer
	if v30.tipSides ~= nil then
		for _, v31 in ipairs(v30.tipSides) do
			g_animationManager:deleteAnimations(v31.animationNodes)
			g_soundManager:deleteSample(v31.unloadSound)
		end
	end
end
function Trailer.onReadStream(p32, p33, _)
	local v34 = p32.spec_trailer
	if v34.tipSideCount > 1 then
		p32:setPreferedTipSide(streamReadUIntN(p33, Trailer.TIP_SIDE_NUM_BITS), true)
	end
	v34.tipState = streamReadUIntN(p33, Trailer.TIP_STATE_NUM_BITS)
	if streamReadBool(p33) then
		v34.currentTipSideIndex = streamReadUIntN(p33, Trailer.TIP_SIDE_NUM_BITS)
	end
	if streamReadBool(p33) then
		local v35 = streamReadBool(p33)
		p32:setTrailerDoorState(v34.preferedTipSideIndex, v35, true, true)
	end
	if streamReadBool(p33) then
		local v36 = v34.tipSides[v34.preferedTipSideIndex]
		local v37 = streamReadFloat32(p33)
		if v37 ~= nil then
			p32:setAnimationTime(v36.animation.name, v37, true, false)
		end
		if streamReadBool(p33) then
			if streamReadBool(p33) then
				p32:playAnimation(v36.animation.name, v36.animation.speedScale, v37, true)
			else
				p32:playAnimation(v36.animation.name, v36.animation.closeSpeedScale, v37, true)
			end
		end
	end
	if streamReadBool(p33) then
		local v38 = v34.tipSides[v34.preferedTipSideIndex]
		local v39 = streamReadFloat32(p33)
		if v39 ~= nil then
			p32:setAnimationTime(v38.doorAnimation.name, v39, true, false)
		end
		if streamReadBool(p33) then
			if streamReadBool(p33) then
				p32:playAnimation(v38.doorAnimation.name, v38.doorAnimation.speedScale, v39, true)
				return
			end
			p32:playAnimation(v38.doorAnimation.name, v38.doorAnimation.closeSpeedScale, v39, true)
		end
	end
end
function Trailer.onWriteStream(p40, p41, _)
	local v42 = p40.spec_trailer
	if v42.tipSideCount > 1 then
		streamWriteUIntN(p41, v42.preferedTipSideIndex, Trailer.TIP_SIDE_NUM_BITS)
	end
	streamWriteUIntN(p41, v42.tipState, Trailer.TIP_STATE_NUM_BITS)
	if streamWriteBool(p41, v42.currentTipSideIndex ~= nil) then
		streamWriteUIntN(p41, v42.currentTipSideIndex, Trailer.TIP_SIDE_NUM_BITS)
	end
	local v43 = v42.tipSides[v42.preferedTipSideIndex]
	local v44 = streamWriteBool
	local v45
	if v43 == nil then
		v45 = false
	else
		v45 = v43.manualDoorToggle
	end
	if v44(p41, v45) then
		streamWriteBool(p41, v43.doorAnimation.state)
	end
	local v46 = streamWriteBool
	local v47
	if v43 == nil then
		v47 = false
	else
		v47 = v43.animation.name ~= nil
	end
	if v46(p41, v47) then
		streamWriteFloat32(p41, p40:getAnimationTime(v43.animation.name))
		if streamWriteBool(p41, p40:getIsAnimationPlaying(v43.animation.name)) then
			streamWriteBool(p41, p40:getAnimationSpeed(v43.animation.name) > 0)
		end
	end
	local v48 = streamWriteBool
	local v49 = v43 ~= nil and not v43.manualDoorToggle
	if v49 then
		v49 = v43.doorAnimation.name ~= nil
	end
	if v48(p41, v49) then
		streamWriteFloat32(p41, p40:getAnimationTime(v43.doorAnimation.name))
		if streamWriteBool(p41, p40:getIsAnimationPlaying(v43.doorAnimation.name)) then
			streamWriteBool(p41, p40:getAnimationSpeed(v43.doorAnimation.name) > 0)
		end
	end
end
function Trailer.onUpdate(p50, _, _, p51, _)
	local v52 = p50.spec_trailer
	if v52.tipSideCount > 1 then
		local v53 = v52.actionEvents[InputAction.TOGGLE_TIPSIDE]
		if v53 ~= nil then
			local v54 = p50:getCanTogglePreferdTipSide()
			g_inputBinding:setActionEventActive(v53.actionEventId, v54)
			if v54 then
				local v55 = string.format(v52.infoText, v52.tipSides[v52.preferedTipSideIndex].name)
				g_inputBinding:setActionEventText(v53.actionEventId, v55)
			end
		end
	end
	if v52.tipSideUpdateDirty and p50:getTipState() == Trailer.TIPSTATE_CLOSED then
		p50:setPreferedTipSide(p50:getNextAvailableTipSide(v52.preferedTipSideIndex))
		v52.tipSideUpdateDirty = false
	end
	local v56 = v52.tipSides[v52.preferedTipSideIndex]
	if v56 ~= nil then
		if v56.manualTipToggle then
			local v57 = v52.actionEvents[v56.manualTipToggleAction]
			if v57 ~= nil then
				local v58 = p50:getTipState()
				local v59
				if v58 == Trailer.TIPSTATE_CLOSED or v58 == Trailer.TIPSTATE_CLOSING then
					v59 = v56.manualTipToggleActionTextPos
				else
					v59 = v56.manualTipToggleActionTextNeg
				end
				g_inputBinding:setActionEventText(v57.actionEventId, v59)
			end
		end
		if v56.manualDoorToggle then
			local v60 = v52.actionEvents[v56.manualDoorToggleAction]
			if v60 ~= nil then
				local v61
				if p50:getIsAnimationPlaying(v56.doorAnimation.name) then
					if p50:getAnimationSpeed(v56.doorAnimation.name) > 0 then
						v61 = v56.manualDoorToggleActionTextNeg
					else
						v61 = v56.manualDoorToggleActionTextPos
					end
				elseif p50:getAnimationTime(v56.doorAnimation.name) <= 0 then
					v61 = v56.manualDoorToggleActionTextPos
				else
					v61 = v56.manualDoorToggleActionTextNeg
				end
				g_inputBinding:setActionEventText(v60.actionEventId, v61)
			end
		end
	end
	if v52.tipState == Trailer.TIPSTATE_OPENING then
		local v62 = v52.tipSides[v52.currentTipSideIndex]
		if v62 ~= nil and (p50:getAnimationTime(v62.animation.name) >= 1 or p50:getAnimationDuration(v62.animation.name) == 0) then
			v52.tipState = Trailer.TIPSTATE_OPEN
		end
	elseif v52.tipState == Trailer.TIPSTATE_CLOSING then
		local v63 = v52.tipSides[v52.currentTipSideIndex]
		if v63 ~= nil and (p50:getAnimationTime(v63.animation.name) <= 0 or (p50:getAnimationDuration(v63.animation.name) == 0 or v63.animation.closeSpeedScale == 0)) then
			v52.tipState = Trailer.TIPSTATE_CLOSED
			p50:endTipping()
		end
	end
	if not p51 and v52.redischarge.dischargeObject ~= nil then
		if p50:getDischargeState() == Dischargeable.DISCHARGE_STATE_OFF then
			p50:updateTrailerAutomaticRedischarge()
		end
		p50:raiseActive()
	end
end
function Trailer.loadTipSide(p64, p65, p66, p67)
	local v68 = p65:getValue(p66 .. "#name")
	p67.name = g_i18n:convertText(v68, p64.customEnvironment)
	if p67.name == nil then
		Logging.xmlWarning(p64.xmlFile, "Given tipSide name \'%s\' not found for \'%s\'!", tostring(v68), p66)
		return false
	end
	p67.dischargeNodeIndex = p65:getValue(p66 .. "#dischargeNodeIndex")
	p67.canTipIfEmpty = p65:getValue(p66 .. "#canTipIfEmpty", true)
	p67.canTip = p65:getValue(p66 .. "#canTip", true)
	p67.manualTipToggle = p65:getValue(p66 .. ".manualTipToggle#enabled", false)
	if p67.manualTipToggle then
		local v69 = p65:getValue(p66 .. ".manualTipToggle#inputAction")
		p67.manualTipToggleAction = InputAction[v69] or InputAction.IMPLEMENT_EXTRA4
		p67.manualTipToggleStopOnDeactivate = p65:getValue(p66 .. ".manualTipToggle#stopOnDeactivate", true)
		p67.manualTipToggleActionTextPos = p65:getValue(p66 .. ".manualTipToggle#inputActionTextPos", "action_startTipping", p64.customEnvironment, false)
		p67.manualTipToggleActionTextNeg = p65:getValue(p66 .. ".manualTipToggle#inputActionTextNeg", "action_stopTipping", p64.customEnvironment, false)
	end
	p67.manualDoorToggle = p65:getValue(p66 .. ".manualDoorToggle#enabled", false)
	if p67.manualDoorToggle then
		p67.manualDoorToggleWhileTipping = p65:getValue(p66 .. ".manualDoorToggle#openWhileTipping", false)
		local v70 = p65:getValue(p66 .. ".manualDoorToggle#inputAction")
		p67.manualDoorToggleAction = InputAction[v70] or InputAction.IMPLEMENT_EXTRA3
		p67.manualDoorToggleActionTextPos = p65:getValue(p66 .. ".manualDoorToggle#inputActionTextPos", "action_openBackDoor", p64.customEnvironment, false)
		p67.manualDoorToggleActionTextNeg = p65:getValue(p66 .. ".manualDoorToggle#inputActionTextNeg", "action_closeBackDoor", p64.customEnvironment, false)
		p67.manualDoorToggleFillUnitIndex = p65:getValue(p66 .. ".manualDoorToggle.fillUnit#index")
		p67.manualDoorToggleFillUnitAllowWhileFilled = p65:getValue(p66 .. ".manualDoorToggle.fillUnit#allowWhileFilled", true)
	end
	p67.animation = {}
	p67.animation.name = p65:getValue(p66 .. ".animation#name")
	if p67.animation.name == nil or not p64:getAnimationExists(p67.animation.name) then
		Logging.xmlWarning(p64.xmlFile, "Missing animation name for \'%s\'!", p66)
		return false
	end
	p67.animation.speedScale = p65:getValue(p66 .. ".animation#speedScale", 1) * Platform.gameplay.dischargeSpeedFactor
	p67.animation.closeSpeedScale = -p65:getValue(p66 .. ".animation#closeSpeedScale", p67.animation.speedScale)
	p67.animation.startTipTime = p65:getValue(p66 .. ".animation#startTipTime", 0)
	p67.animation.resetTipSideChange = p65:getValue(p66 .. ".animation#resetTipSideChange", false)
	p67.doorAnimation = {}
	p67.doorAnimation.name = p65:getValue(p66 .. ".doorAnimation#name")
	p67.doorAnimation.speedScale = p65:getValue(p66 .. ".doorAnimation#speedScale", 1)
	p67.doorAnimation.closeSpeedScale = -p65:getValue(p66 .. ".doorAnimation#closeSpeedScale", p67.doorAnimation.speedScale)
	p67.doorAnimation.startTipTime = p65:getValue(p66 .. ".doorAnimation#startTipTime", 0)
	p67.doorAnimation.delayedClosing = p65:getValue(p66 .. ".doorAnimation#delayedClosing", false)
	p67.doorAnimation.state = false
	if p67.doorAnimation.name ~= nil and not p64:getAnimationExists(p67.doorAnimation.name) then
		Logging.xmlWarning(p64.xmlFile, "Unknown door animation name for \'%s\'!", p66)
		return false
	end
	p67.tippingAnimation = {}
	p67.tippingAnimation.name = p65:getValue(p66 .. ".tippingAnimation#name")
	p67.tippingAnimation.speedScale = p65:getValue(p66 .. ".tippingAnimation#speedScale", 1)
	p67.fillLevel = {}
	p67.fillLevel.fillUnitIndex = p65:getValue(p66 .. ".fillLevel#fillUnitIndex")
	p67.fillLevel.minFillLevelPct = p65:getValue(p66 .. ".fillLevel#minFillLevelPct", 0)
	p67.fillLevel.maxFillLevelPct = p65:getValue(p66 .. ".fillLevel#maxFillLevelPct", 1)
	if p67.fillLevel.fillUnitIndex ~= nil then
		p64.spec_trailer.fillLevelDependentTipSides = true
	end
	if p64.isClient then
		p67.animationNodes = g_animationManager:loadAnimations(p64.xmlFile, p66 .. ".animationNodes", p64.components, p64, p64.i3dMappings)
		p67.unloadSound = g_soundManager:loadSampleFromXML(p64.xmlFile, p66, "unloadSound", p64.baseDirectory, p64.components, 0, AudioGroup.VEHICLE, p64.i3dMappings, p64)
	end
	p67.objectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p65, p66, p67.objectChanges, p64.components, p64)
	ObjectChangeUtil.setObjectChanges(p67.objectChanges, false, p64, p64.setMovingToolDirty)
	p67.currentEmptyFactor = 1
	return true
end
function Trailer.saveToXMLFile(p71, p72, p73, _)
	local v74 = p71.spec_trailer
	if v74.tipSideCount > 1 then
		p72:setValue(p73 .. "#tipSideIndex", v74.preferedTipSideIndex)
	end
	local v75 = v74.tipSides[v74.preferedTipSideIndex]
	if v75 ~= nil then
		p72:setValue(p73 .. "#doorState", p71:getAnimationTime(v75.doorAnimation.name) > 0)
		p72:setValue(p73 .. "#tipAnimationTime", p71:getAnimationTime(v75.animation.name))
	end
	p72:setValue(p73 .. "#tipState", v74.tipState)
end
function Trailer.getCanTogglePreferdTipSide(p76)
	local v77 = p76.spec_trailer
	local v78
	if v77.tipState == Trailer.TIPSTATE_CLOSED then
		v78 = v77.tipSideCount > 0
	else
		v78 = false
	end
	return v78
end
function Trailer.getIsTipSideAvailable(p79, p80)
	local v81 = p79.spec_trailer.tipSides[p80]
	if v81 == nil then
		return false
	end
	if v81.fillLevel.fillUnitIndex ~= nil then
		local v82 = p79:getFillUnitFillLevelPercentage(v81.fillLevel.fillUnitIndex)
		if v82 < v81.fillLevel.minFillLevelPct or v81.fillLevel.maxFillLevelPct < v82 then
			return false
		end
	end
	return true
end
function Trailer.getNextAvailableTipSide(p83, p84)
	local v85 = p83.spec_trailer
	local v86 = v85.tipSideCount
	local v87 = p84
	while v86 > 0 do
		local v88 = p84 + 1
		p84 = v85.tipSideCount < v88 and 1 or v88
		if p83:getIsTipSideAvailable(p84) then
			return p84
		end
		v86 = v86 - 1
	end
	return v87
end
function Trailer.setPreferedTipSide(p89, p90, p91)
	local v92 = p89.spec_trailer
	local v93 = v92.tipSideCount
	local v94 = math.min(v93, p90)
	local v95 = math.max(1, v94)
	local v96 = p89:getTipState()
	if v96 ~= Trailer.TIPSTATE_CLOSED and v96 ~= Trailer.TIPSTATE_CLOSING then
		p89:stopTipping(true)
	end
	if v95 ~= v92.preferedTipSideIndex and (v92.tipSideCount > 1 and (p91 == nil or p91 == false)) then
		if g_server == nil then
			g_client:getServerConnection():sendEvent(TrailerToggleTipSideEvent.new(p89, v95))
		else
			g_server:broadcastEvent(TrailerToggleTipSideEvent.new(p89, v95), nil, nil, p89)
		end
	end
	for v97 = 1, #v92.tipSides do
		ObjectChangeUtil.setObjectChanges(v92.tipSides[v97].objectChanges, v97 == v95, p89, p89.setMovingToolDirty)
	end
	local v98 = v92.tipSides[v92.preferedTipSideIndex]
	v92.preferedTipSideIndex = v95
	local v99 = v92.tipSides[v95]
	if v98 ~= nil and (v99.doorAnimation.name ~= v98.doorAnimation.name and (v98.doorAnimation.name ~= nil and p89:getAnimationTime(v98.doorAnimation.name) > 0)) then
		p89:setTrailerDoorState(v98.index, false, true)
	end
	if v99.animation.resetTipSideChange then
		p89:setAnimationTime(v99.animation.name, 0, true, false)
	end
	if v99.dischargeNodeIndex ~= nil then
		p89:setCurrentDischargeNodeIndex(v99.dischargeNodeIndex)
	end
	p89:requestActionEventUpdate()
end
function Trailer.startTipping(p100, p101, _)
	local v102 = p100.spec_trailer
	local v103 = p101 or v102.preferedTipSideIndex
	local v104 = v102.tipSides[v103]
	if v104 ~= nil then
		local v105 = p100:getAnimationTime(v104.animation.name)
		p100:playAnimation(v104.animation.name, v104.animation.speedScale, v105, true)
		if (not v104.manualDoorToggle or v104.manualDoorToggleWhileTipping) and v104.doorAnimation.name ~= nil then
			p100:setTrailerDoorState(v102.preferedTipSideIndex, true, true)
		end
		if v104.tippingAnimation.name ~= nil then
			p100:playAnimation(v104.tippingAnimation.name, v104.tippingAnimation.speedScale, p100:getAnimationTime(v104.tippingAnimation.name), true)
		end
		if p100.isClient then
			g_animationManager:startAnimations(v104.animationNodes)
			g_soundManager:playSample(v104.unloadSound)
		end
		v102.tipState = Trailer.TIPSTATE_OPENING
		v102.currentTipSideIndex = v103
		if v104.dischargeNodeIndex ~= nil then
			p100:setCurrentDischargeNodeIndex(v104.dischargeNodeIndex)
		end
		v102.remainingFillDelta = 0
		SpecializationUtil.raiseEvent(p100, "onStartTipping", v103)
		p100:raiseActive()
	end
end
function Trailer.stopTipping(p106, _)
	local v107 = p106.spec_trailer
	local v108 = v107.tipSides[v107.currentTipSideIndex]
	if v108 ~= nil then
		if v108.animation.closeSpeedScale == 0 then
			if p106:getIsAnimationPlaying(v108.animation.name) then
				p106:stopAnimation(v108.animation.name, true)
			end
		else
			local v109 = p106:getAnimationTime(v108.animation.name)
			p106:playAnimation(v108.animation.name, v108.animation.closeSpeedScale, v109, true)
		end
		if (not v108.manualDoorToggle or v108.manualDoorToggleWhileTipping) and (v108.doorAnimation.name ~= nil and not v108.doorAnimation.delayedClosing) then
			p106:setTrailerDoorState(v107.currentTipSideIndex, false, true)
		end
		if v108.tippingAnimation.name ~= nil then
			p106:setAnimationStopTime(v108.tippingAnimation.name, 1)
		end
		if p106.isClient then
			g_animationManager:stopAnimations(v108.animationNodes)
			g_soundManager:stopSample(v108.unloadSound)
		end
		v107.tipState = Trailer.TIPSTATE_CLOSING
		v107.remainingFillDelta = 0
		SpecializationUtil.raiseEvent(p106, "onStopTipping")
		p106:raiseActive()
	end
end
function Trailer.endTipping(p110, _)
	local v111 = p110.spec_trailer
	local v112 = v111.tipSides[v111.currentTipSideIndex]
	if v112 ~= nil and (not v112.manualDoorToggle and (v112.doorAnimation.name ~= nil and v112.doorAnimation.delayedClosing)) then
		p110:setTrailerDoorState(v111.currentTipSideIndex, false, true)
	end
	v111.tipState = Trailer.TIPSTATE_CLOSED
	v111.currentTipSideIndex = nil
	SpecializationUtil.raiseEvent(p110, "onEndTipping")
end
function Trailer.setTrailerDoorState(p113, p114, p115, p116, p117)
	local v118 = p113.spec_trailer.tipSides[p114]
	if v118 ~= nil then
		if p115 == nil then
			p115 = not v118.doorAnimation.state
		end
		v118.doorAnimation.state = p115
		p113:playAnimation(v118.doorAnimation.name, p115 and v118.doorAnimation.speedScale or v118.doorAnimation.closeSpeedScale, p113:getAnimationTime(v118.doorAnimation.name), true)
		if p117 then
			AnimatedVehicle.updateAnimationByName(p113, v118.doorAnimation.name, 999999, true)
		end
		if v118.manualDoorToggle and v118.doorAnimation.name ~= nil then
			if p115 then
				SpecializationUtil.raiseEvent(p113, "onOpenBackDoor", p114)
			else
				SpecializationUtil.raiseEvent(p113, "onCloseBackDoor", p114)
			end
		end
		TrailerToggleManualDoorEvent.sendEvent(p113, p114, p115, p116)
	end
end
function Trailer.getAllowTrailerDoorToggle(p119, p120)
	local v121 = p119.spec_trailer.tipSides[p120]
	return (v121 == nil or (v121.manualDoorToggleFillUnitIndex == nil or (v121.manualDoorToggleFillUnitAllowWhileFilled or p119:getFillUnitFillLevel(v121.manualDoorToggleFillUnitIndex) <= 0))) and true or false
end
function Trailer.getTipState(p122)
	return p122.spec_trailer.tipState
end
function Trailer.setTipState(p123, p124)
	local v125 = p123.spec_trailer
	local v126 = v125.tipSides[v125.currentTipSideIndex]
	if v126 ~= nil then
		if p124 then
			p123:playAnimation(v126.animation.name, v126.animation.speedScale, p123:getAnimationTime(v126.animation.name), true)
			if not v126.manualDoorToggle and v126.doorAnimation.name ~= nil then
				p123:playAnimation(v126.doorAnimation.name, v126.doorAnimation.speedScale, p123:getAnimationTime(v126.doorAnimation.name), true)
			end
		else
			p123:playAnimation(v126.animation.name, v126.animation.closeSpeedScale, p123:getAnimationTime(v126.animation.name), true)
			if not v126.manualDoorToggle and v126.doorAnimation.name ~= nil then
				p123:playAnimation(v126.doorAnimation.name, v126.doorAnimation.closeSpeedScale, p123:getAnimationTime(v126.doorAnimation.name), true)
			end
		end
		AnimatedVehicle.updateAnimationByName(p123, v126.animation.name, 999999, true)
		AnimatedVehicle.updateAnimationByName(p123, v126.doorAnimation.name, 999999, true)
	end
end
function Trailer.updateTrailerAutomaticRedischarge(p127)
	local v128 = p127.spec_trailer
	local v129 = p127:getCurrentDischargeNode()
	if v129 ~= nil then
		local v130 = false
		local v131, v132, v133 = getWorldTranslation(v129.node)
		local v134 = v128.redischarge.dischargeNodeLastPos
		if MathUtil.vector3Length(v134[1] - v131, v134[2] - v132, v134[3] - v133) < 1.5 then
			local v135, v136 = p127:getDischargeTargetObject(v129)
			if v135 ~= nil and v135 == v128.redischarge.dischargeObject then
				local v137 = p127:getFillUnitFillLevel(v129.fillUnitIndex)
				if v137 > 0 then
					local v138 = true
					local v139 = 0.5
					if v135.getTrailerAutomaticRedischargeThreshold ~= nil then
						v139 = v135:getTrailerAutomaticRedischargeThreshold() or v139
					end
					if v135.getFillUnitCapacity ~= nil and v135.getFillUnitFreeCapacity ~= nil then
						local v140 = v135:getFillUnitCapacity(v136)
						local v141 = v135:getFillUnitFreeCapacity(v136, p127:getDischargeFillType(v129), p127:getActiveFarm())
						v138 = v140 * v139 < v141 and true or v137 < v141
					end
					if v138 then
						v128.redischarge.isDisabled = true
						p127:setDischargeState(Dischargeable.DISCHARGE_STATE_OBJECT)
						v128.redischarge.isDisabled = false
					end
				else
					v130 = true
				end
			end
		else
			v130 = true
		end
		if v130 then
			v128.redischarge.dischargeObject = nil
			local v142 = v128.redischarge.dischargeNodeLastPos
			local v143 = v128.redischarge.dischargeNodeLastPos
			local v144 = v128.redischarge.dischargeNodeLastPos
			v142[1] = 0
			v143[2] = 0
			v144[3] = 0
		end
	end
end
function Trailer.getDischargeNodeEmptyFactor(p145, p146, p147)
	local v148 = p145.spec_trailer.dischargeNodeIndexToTipSide[p147.index]
	if v148 == nil then
		return p146(p145, p147)
	else
		return v148.animation.name ~= nil and (v148.animation.startTipTime ~= 0 and (p145:getAnimationDuration(v148.animation.name) > 0 and p145:getAnimationTime(v148.animation.name) < v148.animation.startTipTime)) and 0 or (v148.doorAnimation.name ~= nil and (v148.doorAnimation.startTipTime ~= 0 and (p145:getAnimationDuration(v148.doorAnimation.name) > 0 and p145:getAnimationTime(v148.doorAnimation.name) < v148.doorAnimation.startTipTime)) and 0 or v148.currentEmptyFactor)
	end
end
function Trailer.getCanDischargeToGround(p149, p150, p151)
	local v152 = p150(p149, p151)
	if p151 ~= nil then
		local v153 = p149.spec_trailer
		local v154 = v153.tipSides[v153.currentTipSideIndex or v153.preferedTipSideIndex]
		if v154 ~= nil then
			if not v154.canTip then
				return false
			end
			local v155 = p151.fillUnitIndex
			if not v154.canTipIfEmpty and p149:getFillUnitFillLevel(v155) == 0 then
				v152 = false
			end
		end
	end
	return v152
end
function Trailer.getCanDischargeToObject(p156, p157, p158)
	local v159 = p157(p156, p158)
	if p158 ~= nil then
		local v160 = p156.spec_trailer
		local v161 = v160.tipSides[v160.currentTipSideIndex or v160.preferedTipSideIndex]
		if v161 ~= nil and not v161.canTip then
			v159 = false
		end
	end
	return v159
end
function Trailer.getIsNextCoverStateAllowed(p162, p163, p164)
	local v165 = p162.spec_trailer
	local v166
	if v165.currentTipSideIndex == nil then
		v166 = nil
	else
		v166 = v165.tipSides[v165.currentTipSideIndex]
	end
	local v167
	if v165.preferedTipSideIndex == nil then
		v167 = v166
	else
		v167 = v165.tipSides[v165.preferedTipSideIndex]
		if v167 == nil or not v167.manualDoorToggle then
			v167 = v166
		elseif not v167.doorAnimation.state then
			v167 = v166
		end
	end
	if v167 ~= nil and v167.dischargeNodeIndex ~= nil then
		local v168 = p162:getCoverByFillUnitIndex(p162:getDischargeNodeByIndex(v167.dischargeNodeIndex).fillUnitIndex)
		if v168 ~= nil and p164 ~= v168.index then
			return false
		end
	end
	return p163(p162, p164)
end
function Trailer.getCanBeSelected(_, _)
	return true
end
function Trailer.onRegisterActionEvents(p169, _, p170)
	if p169.isClient then
		local v171 = p169.spec_trailer
		if v171.tipSideCount < 2 then
			return
		end
		p169:clearActionEventsTable(v171.actionEvents)
		if p170 then
			local _, v172 = p169:addActionEvent(v171.actionEvents, InputAction.TOGGLE_TIPSIDE, p169, Trailer.actionEventToggleTipSide, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v172, GS_PRIO_NORMAL)
			local v173 = v171.tipSides[v171.preferedTipSideIndex]
			if v173 ~= nil then
				if v173.manualTipToggle then
					local _, v174 = p169:addPoweredActionEvent(v171.actionEvents, v173.manualTipToggleAction, p169, Trailer.actionEventManualToggleTip, false, true, false, true, nil)
					g_inputBinding:setActionEventTextPriority(v174, GS_PRIO_NORMAL)
				end
				if v173.manualDoorToggle then
					local _, v175 = p169:addPoweredActionEvent(v171.actionEvents, v173.manualDoorToggleAction, p169, Trailer.actionEventManualToggleDoor, false, true, false, true, nil)
					g_inputBinding:setActionEventTextPriority(v175, GS_PRIO_NORMAL)
				end
			end
		end
	end
end
function Trailer.onDischargeStateChanged(p176, p177)
	local v178 = p176.spec_trailer
	if p177 == Dischargeable.DISCHARGE_STATE_OFF then
		p176:stopTipping(true)
	elseif p177 == Dischargeable.DISCHARGE_STATE_GROUND or p177 == Dischargeable.DISCHARGE_STATE_OBJECT then
		p176:startTipping(nil, true)
	end
	if not v178.redischarge.isDisabled and p177 == Dischargeable.DISCHARGE_STATE_OBJECT then
		local v179 = p176:getCurrentDischargeNode()
		if v179 ~= nil then
			local v180, _ = p176:getDischargeTargetObject(v179)
			v178.redischarge.dischargeObject = v180
			local v181 = v178.redischarge.dischargeNodeLastPos
			local v182 = v178.redischarge.dischargeNodeLastPos
			local v183 = v178.redischarge.dischargeNodeLastPos
			local v184, v185, v186 = getWorldTranslation(v179.node)
			v181[1] = v184
			v182[2] = v185
			v183[3] = v186
		end
	end
end
function Trailer.onDeactivate(p187)
	local v188 = p187.spec_trailer
	local v189 = v188.tipSides[v188.preferedTipSideIndex]
	if v189 ~= nil and (v189.manualTipToggle and v189.manualTipToggleStopOnDeactivate) then
		local v190 = p187:getTipState()
		if v190 == Trailer.TIPSTATE_OPEN or v190 == Trailer.TIPSTATE_OPENING then
			p187:stopTipping(true)
		end
	end
end
function Trailer.getAIHasFinishedDischarge(p191, p192, p193)
	if p191:getTipState() == Trailer.TIPSTATE_CLOSED then
		return p192(p191, p193)
	else
		return false
	end
end
function Trailer.startAIDischarge(p194, p195, p196, p197)
	local v198 = p194.spec_trailer.dischargeNodeIndexToTipSide[p196.index]
	if v198 ~= nil then
		p194:setPreferedTipSide(v198.index)
	end
	p195(p194, p196, p197)
end
function Trailer.loadPickupFromXML(p199, p200, p201, p202, p203)
	p203.allowWhileTipping = p201:getValue(p202 .. "#allowWhileTipping", true)
	return p200(p199, p201, p202, p203)
end
function Trailer.getCanChangePickupState(p204, p205, p206, p207)
	if p205(p204, p206, p207) then
		return p206.allowWhileTipping and true or p204:getTipState() == Trailer.TIPSTATE_CLOSED
	else
		return false
	end
end
function Trailer.loadTurnedOnAnimationFromXML(p208, p209, p210, p211, p212)
	p212.playWhileTipping = p210:getValue(p211 .. "#playWhileTipping", false)
	return p209(p208, p210, p211, p212)
end
function Trailer.getRequiresPower(p213, p214)
	local v215 = p213:getTipState()
	return (v215 == Trailer.TIPSTATE_OPENING or v215 == Trailer.TIPSTATE_CLOSING) and true or p214(p213)
end
function Trailer.setManualDischargeState(p216, p217, p218, p219)
	if p218 == Dischargeable.DISCHARGE_STATE_OFF then
		local v220 = p216.spec_trailer
		v220.redischarge.dischargeObject = nil
		local v221 = v220.redischarge.dischargeNodeLastPos
		local v222 = v220.redischarge.dischargeNodeLastPos
		local v223 = v220.redischarge.dischargeNodeLastPos
		v221[1] = 0
		v222[2] = 0
		v223[3] = 0
	end
	return p217(p216, p218, p219)
end
function Trailer.getIsTurnedOnAnimationActive(p224, p225, p226)
	if not p226.playWhileTipping then
		return p225(p224, p226)
	end
	local v227 = p225(p224, p226)
	if not v227 then
		if p224:getTipState() == Trailer.TIPSTATE_CLOSED then
			v227 = false
		else
			v227 = p224:getDischargeNodeEmptyFactor(p224:getCurrentDischargeNode()) > 0
		end
	end
	return v227
end
function Trailer.onRegisterAnimationValueTypes(p228)
	p228:registerAnimationValueType("tipSideEmptyFactor", "startTipSideEmptyFactor", "endTipSideEmptyFactor", false, AnimationValueFloat, function(p229, p230, p231)
		p229.node = p230:getValue(p231 .. "#node", nil, p229.part.components, p229.part.i3dMappings)
		if p229.node == nil then
			return false
		end
		p229:setWarningInformation("node: " .. getName(p229.node))
		p229:addCompareParameters("node")
		return true
	end, function(p232)
		if p232.tipSide == nil then
			local v233 = p232.vehicle:getDischargeNodeByNode(p232.node)
			local v234
			if v233 == nil then
				v234 = nil
			else
				v234 = p232.vehicle.spec_trailer.dischargeNodeIndexToTipSide[v233.index]
			end
			if v233 == nil or v234 == nil then
				Logging.xmlWarning(p232.xmlFile, "Could not update discharge emptyFactor. No tipSide or dischargeNode defined for node \'%s\'!", getName(p232.node))
				p232.startValue = nil
				return 0
			end
			p232.tipSide = v234
		end
		return p232.tipSide.currentEmptyFactor
	end, function(p235, p236)
		if p235.tipSide ~= nil then
			p235.tipSide.currentEmptyFactor = p236
		end
	end)
end
function Trailer.onFillUnitFillLevelChanged(p237, p238, p239, _, _, _, _)
	local v240 = p237.spec_trailer
	if v240.fillLevelDependentTipSides and (p239 ~= 0 and not p237:getIsTipSideAvailable(v240.preferedTipSideIndex)) then
		if p237:getTipState() == Trailer.TIPSTATE_CLOSED then
			p237:setPreferedTipSide(p237:getNextAvailableTipSide(v240.preferedTipSideIndex))
		else
			v240.tipSideUpdateDirty = true
		end
	end
	if p237.isServer then
		for v241, v242 in ipairs(v240.tipSides) do
			if v242.manualDoorToggle and (not v242.manualDoorToggleFillUnitAllowWhileFilled and (v242.manualDoorToggleFillUnitIndex == p238 and p237:getFillUnitFillLevel(p238) > 0)) then
				p237:setTrailerDoorState(v241, false)
			end
		end
	end
end
function Trailer.actionEventToggleTipSide(p243, _, _, _, _)
	local v244 = p243.spec_trailer
	if p243:getCanTogglePreferdTipSide() then
		p243:setPreferedTipSide(p243:getNextAvailableTipSide(v244.preferedTipSideIndex))
	end
end
function Trailer.actionEventManualToggleTip(p245, _, _, _, _)
	local v246 = p245:getTipState()
	if v246 == Trailer.TIPSTATE_CLOSED or v246 == Trailer.TIPSTATE_CLOSING then
		p245:startTipping(nil, false)
		TrailerToggleManualTipEvent.sendEvent(p245, true)
	else
		p245:stopTipping()
		TrailerToggleManualTipEvent.sendEvent(p245, false)
	end
end
function Trailer.actionEventManualToggleDoor(p247, _, _, _, _)
	local v248 = p247.spec_trailer
	if p247:getAllowTrailerDoorToggle(v248.preferedTipSideIndex) then
		p247:setTrailerDoorState(v248.preferedTipSideIndex)
	end
end

LivestockTrailer = {}
source("dataS/scripts/vehicles/specializations/activatables/LivestockTrailerActivatable.lua")
function LivestockTrailer.initSpecialization()
	g_storeManager:addSpecType("numAnimalsCow", "shopListAttributeIconCow", LivestockTrailer.loadSpecValueNumberAnimalsCow, LivestockTrailer.getSpecValueNumberAnimalsCow, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("numAnimalsPig", "shopListAttributeIconPig", LivestockTrailer.loadSpecValueNumberAnimalsPig, LivestockTrailer.getSpecValueNumberAnimalsPig, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("numAnimalsSheep", "shopListAttributeIconSheep", LivestockTrailer.loadSpecValueNumberAnimalsSheep, LivestockTrailer.getSpecValueNumberAnimalsSheep, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("numAnimalsHorse", "shopListAttributeIconHorse", LivestockTrailer.loadSpecValueNumberAnimalsHorse, LivestockTrailer.getSpecValueNumberAnimalsHorse, StoreSpecies.VEHICLE)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("LivestockTrailer")
	v1:register(XMLValueType.STRING, "vehicle.livestockTrailer.animal(?)#type", "Animal type name")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.livestockTrailer.animal(?)#node", "Animal node")
	v1:register(XMLValueType.INT, "vehicle.livestockTrailer.animal(?)#numSlots", "Number of slots")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.livestockTrailer.loadTrigger#node", "Load trigger node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.livestockTrailer.spawnPlaces.spawnPlace(?)#node", "Unload spawn places")
	v1:register(XMLValueType.FLOAT, "vehicle.livestockTrailer.spawnPlaces.spawnPlace(?)#width", "Unloading width", 15)
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).livestockTrailer#animalType", "Animal type name")
	AnimalClusterSystem.registerSavegameXMLPaths(v2, "vehicles.vehicle(?).livestockTrailer")
end
function LivestockTrailer.prerequisitesPresent(_)
	return true
end
function LivestockTrailer.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getCurrentAnimalType", LivestockTrailer.getCurrentAnimalType)
	SpecializationUtil.registerFunction(p3, "getSupportsAnimalType", LivestockTrailer.getSupportsAnimalType)
	SpecializationUtil.registerFunction(p3, "getSupportsAnimalSubType", LivestockTrailer.getSupportsAnimalSubType)
	SpecializationUtil.registerFunction(p3, "setLoadingTrigger", LivestockTrailer.setLoadingTrigger)
	SpecializationUtil.registerFunction(p3, "getLoadingTrigger", LivestockTrailer.getLoadingTrigger)
	SpecializationUtil.registerFunction(p3, "updateAnimals", LivestockTrailer.updateAnimals)
	SpecializationUtil.registerFunction(p3, "updatedClusters", LivestockTrailer.updatedClusters)
	SpecializationUtil.registerFunction(p3, "clearAnimals", LivestockTrailer.clearAnimals)
	SpecializationUtil.registerFunction(p3, "addAnimals", LivestockTrailer.addAnimals)
	SpecializationUtil.registerFunction(p3, "addCluster", LivestockTrailer.addCluster)
	SpecializationUtil.registerFunction(p3, "getClusters", LivestockTrailer.getClusters)
	SpecializationUtil.registerFunction(p3, "getRideablesInTrigger", LivestockTrailer.getRideablesInTrigger)
	SpecializationUtil.registerFunction(p3, "getClusterById", LivestockTrailer.getClusterById)
	SpecializationUtil.registerFunction(p3, "getClusterSystem", LivestockTrailer.getClusterSystem)
	SpecializationUtil.registerFunction(p3, "getNumOfAnimals", LivestockTrailer.getNumOfAnimals)
	SpecializationUtil.registerFunction(p3, "getMaxNumOfAnimals", LivestockTrailer.getMaxNumOfAnimals)
	SpecializationUtil.registerFunction(p3, "getNumOfFreeAnimalSlots", LivestockTrailer.getNumOfFreeAnimalSlots)
	SpecializationUtil.registerFunction(p3, "onAnimalLoaded", LivestockTrailer.onAnimalLoaded)
	SpecializationUtil.registerFunction(p3, "onAnimalLoadTriggerCallback", LivestockTrailer.onAnimalLoadTriggerCallback)
	SpecializationUtil.registerFunction(p3, "getAnimalUnloadPlaces", LivestockTrailer.getAnimalUnloadPlaces)
	SpecializationUtil.registerFunction(p3, "setAnimalScreenController", LivestockTrailer.setAnimalScreenController)
	SpecializationUtil.registerFunction(p3, "onAnimalRideableDeleted", LivestockTrailer.onAnimalRideableDeleted)
end
function LivestockTrailer.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAdditionalComponentMass", LivestockTrailer.getAdditionalComponentMass)
	SpecializationUtil.registerOverwrittenFunction(p4, "getSellPrice", LivestockTrailer.getSellPrice)
	SpecializationUtil.registerOverwrittenFunction(p4, "dayChanged", LivestockTrailer.dayChanged)
	SpecializationUtil.registerOverwrittenFunction(p4, "periodChanged", LivestockTrailer.periodChanged)
end
function LivestockTrailer.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", LivestockTrailer)
	SpecializationUtil.registerEventListener(p5, "onLoadFinished", LivestockTrailer)
	SpecializationUtil.registerEventListener(p5, "onDelete", LivestockTrailer)
	SpecializationUtil.registerEventListener(p5, "onReadStream", LivestockTrailer)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", LivestockTrailer)
end
function LivestockTrailer.onLoad(p_u_6, _)
	local v_u_7 = p_u_6.spec_livestockTrailer
	v_u_7.animalPlaces = {}
	v_u_7.animalTypeIndexToPlaces = {}
	local v8 = 0
	while true do
		local v9 = string.format("vehicle.livestockTrailer.animal(%d)", v8)
		if not p_u_6.xmlFile:hasProperty(v9) then
			break
		end
		local v10 = {
			["numUsed"] = 0
		}
		local v11 = p_u_6.xmlFile:getValue(v9 .. "#type")
		local v12 = g_currentMission.animalSystem:getTypeIndexByName(v11)
		if v12 == nil then
			Logging.xmlWarning(p_u_6.xmlFile, "Animal type \'%s\' could not be found!", v11)
			break
		end
		v10.animalTypeIndex = v12
		v10.slots = {}
		local v13 = p_u_6.xmlFile:getValue(v9 .. "#node", nil, p_u_6.components, p_u_6.i3dMappings)
		local v14 = p_u_6.xmlFile:getValue(v9 .. "#numSlots", 0)
		local v15 = math.abs(v14)
		if getNumOfChildren(v13) < v15 then
			Logging.xmlWarning(p_u_6.xmlFile, "numSlots is greater than available children for \'%s\'", v9)
			v15 = getNumOfChildren(v13)
		end
		for v16 = 0, v15 - 1 do
			local v17 = getChildAt(v13, v16)
			local v18 = v10.slots
			table.insert(v18, {
				["linkNode"] = v17,
				["loadedMesh"] = nil,
				["place"] = v10
			})
		end
		local v19 = v_u_7.animalPlaces
		table.insert(v19, v10)
		v_u_7.animalTypeIndexToPlaces[v10.animalTypeIndex] = v10
		v8 = v8 + 1
	end
	local v20 = p_u_6.xmlFile:getValue("vehicle.livestockTrailer.loadTrigger#node", nil, p_u_6.components, p_u_6.i3dMappings)
	if v20 ~= nil then
		addTrigger(v20, "onAnimalLoadTriggerCallback", p_u_6)
		v_u_7.triggerNode = v20
	end
	v_u_7.rideablesInTrigger = {}
	v_u_7.spawnPlaces = {}
	p_u_6.xmlFile:iterate("vehicle.livestockTrailer.spawnPlaces.spawnPlace", function(_, p21)
		-- upvalues: (copy) p_u_6, (copy) v_u_7
		local v22 = p_u_6.xmlFile:getValue(p21 .. "#node", nil, p_u_6.components, p_u_6.i3dMappings)
		local v23 = p_u_6.xmlFile:getValue(p21 .. "#width", 5)
		if v22 ~= nil then
			local v24 = v_u_7.spawnPlaces
			table.insert(v24, {
				["node"] = v22,
				["width"] = v23
			})
		end
	end)
	if #v_u_7.spawnPlaces > 0 or v_u_7.triggerNode ~= nil then
		v_u_7.activatable = LivestockTrailerActivatable.new(p_u_6)
		if g_currentMission ~= nil then
			g_currentMission.activatableObjectsSystem:addActivatable(v_u_7.activatable)
		end
	end
	v_u_7.clusterSystem = AnimalClusterSystem.new(p_u_6.isServer, p_u_6)
	g_messageCenter:subscribe(AnimalClusterUpdateEvent, p_u_6.updatedClusters, p_u_6)
	v_u_7.loadingTrigger = nil
	v_u_7.animalScreenController = nil
	if g_currentMission ~= nil then
		g_currentMission.husbandrySystem:addLivestockTrailer(p_u_6)
	end
end
function LivestockTrailer.onLoadFinished(p25, p26)
	if p26 ~= nil and not p26.resetVehicles then
		local v27 = p25.spec_livestockTrailer
		local v28 = p26.xmlFile
		local v29 = p26.key
		v27.clusterSystem:loadFromXMLFile(v28, v29 .. ".livestockTrailer")
		v27.clusterSystem:updateNow()
	end
end
function LivestockTrailer.onDelete(p30)
	p30:clearAnimals()
	g_messageCenter:unsubscribe(AnimalClusterUpdateEvent, p30)
	if g_currentMission ~= nil then
		g_currentMission.husbandrySystem:removeLivestockTrailer(p30)
	end
	local v31 = p30.spec_livestockTrailer
	if v31.triggerNode ~= nil then
		removeTrigger(v31.triggerNode)
	end
	if v31.activatable ~= nil then
		g_currentMission.activatableObjectsSystem:removeActivatable(v31.activatable)
	end
	if v31.loadingTrigger ~= nil then
		v31.loadingTrigger:setLoadingTrailer(nil)
	end
end
function LivestockTrailer.saveToXMLFile(p32, p33, p34, p35)
	p32.spec_livestockTrailer.clusterSystem:saveToXMLFile(p33, p34, p35)
end
function LivestockTrailer.onReadStream(p36, p37, p38)
	p36.spec_livestockTrailer.clusterSystem:readStream(p37, p38)
end
function LivestockTrailer.onWriteStream(p39, p40, p41)
	p39.spec_livestockTrailer.clusterSystem:writeStream(p40, p41)
end
function LivestockTrailer.getSupportsAnimalType(p42, p43)
	return p42.spec_livestockTrailer.animalTypeIndexToPlaces[p43] ~= nil
end
function LivestockTrailer.getSupportsAnimalSubType(p44, p45)
	local v46 = g_currentMission.animalSystem
	return p44:getSupportsAnimalType(v46:getTypeByIndex(v46:getSubTypeByIndex(p45).typeIndex).typeIndex)
end
function LivestockTrailer.getCurrentAnimalType(p47)
	local v48 = p47.spec_livestockTrailer.clusterSystem:getClusters()
	if #v48 == 0 then
		return nil
	end
	local v49 = g_currentMission.animalSystem
	return v49:getTypeByIndex(v49:getSubTypeByIndex((v48[1]:getSubTypeIndex())).typeIndex)
end
function LivestockTrailer.setLoadingTrigger(p50, p51)
	p50.spec_livestockTrailer.loadingTrigger = p51
end
function LivestockTrailer.getLoadingTrigger(p52)
	return p52.spec_livestockTrailer.loadingTrigger
end
function LivestockTrailer.setAnimalScreenController(p53, p54)
	p53.spec_livestockTrailer.animalScreenController = p54
end
function LivestockTrailer.addAnimals(p55, p56, p57, p58)
	local v59 = g_currentMission.animalSystem:createClusterFromSubTypeIndex(p56)
	if v59:getSupportsMerging() then
		v59.numAnimals = p57
		v59.age = p58
		p55:addCluster(v59)
	else
		for v60 = 1, p57 do
			if v60 > 1 then
				v59 = g_currentMission.animalSystem:createClusterFromSubTypeIndex(p56)
			end
			v59.numAnimals = 1
			v59.age = p58
			p55:addCluster(v59)
		end
	end
end
function LivestockTrailer.addCluster(p61, p62)
	local v63 = p61.spec_livestockTrailer
	v63.clusterSystem:addPendingAddCluster(p62)
	v63.clusterSystem:updateNow()
end
function LivestockTrailer.getClusters(p64)
	return p64.spec_livestockTrailer.clusterSystem:getClusters()
end
function LivestockTrailer.getRideablesInTrigger(p65)
	return p65.spec_livestockTrailer.rideablesInTrigger
end
function LivestockTrailer.getClusterById(p66, p67)
	return p66.spec_livestockTrailer.clusterSystem:getClusterById(p67)
end
function LivestockTrailer.getClusterSystem(p68)
	return p68.spec_livestockTrailer.clusterSystem
end
function LivestockTrailer.getNumOfAnimals(p69)
	local v70 = p69.spec_livestockTrailer
	local v71 = v70.clusterSystem:getClusters()
	if #v71 == 0 then
		return 0
	end
	local v72 = v71[1]:getSubTypeIndex()
	local v73 = g_currentMission.animalSystem:getSubTypeByIndex(v72)
	return v70.animalTypeIndexToPlaces[v73.typeIndex].usedSlots or 0
end
function LivestockTrailer.getMaxNumOfAnimals(p74, p75)
	local v76 = p74.spec_livestockTrailer
	local v77 = p74:getCurrentAnimalType()
	if p75 == nil and v77 == nil then
		return 0
	end
	if v77 ~= nil and p75 ~= v77 then
		return 0
	end
	local v78 = p75 or v77
	return p74:getSupportsAnimalType(v78.typeIndex) and #v76.animalTypeIndexToPlaces[v78.typeIndex].slots or 0
end
function LivestockTrailer.getNumOfFreeAnimalSlots(p79, p80)
	local v81 = g_currentMission.animalSystem
	local v82 = v81:getTypeByIndex(v81:getSubTypeByIndex(p80).typeIndex)
	local v83 = p79:getNumOfAnimals()
	return p79:getMaxNumOfAnimals(v82) - v83
end
function LivestockTrailer.updatedClusters(p84, p85)
	if p85 == p84 then
		p84:updateAnimals()
		p84:setMassDirty()
	end
end
function LivestockTrailer.updateAnimals(p86)
	local v87 = p86.spec_livestockTrailer
	p86:clearAnimals()
	local v88 = 1
	local v89 = v87.clusterSystem:getClusters()
	local v90 = p86:getCurrentAnimalType()
	if v90 ~= nil then
		local v91 = v87.animalTypeIndexToPlaces[v90.typeIndex]
		v91.usedSlots = 0
		for _, v92 in ipairs(v89) do
			for _ = 1, v92:getNumAnimals() do
				local v93 = v91.slots[v88]
				v93.meshLoadingInProgress = true
				local v94 = g_currentMission.animalSystem:getVisualByAge(v92:getSubTypeIndex(), v92:getAge())
				local v95 = v94.visualAnimal.filenamePosed
				v93.filename = v95
				v93.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(v95, false, false, p86.onAnimalLoaded, p86, {
					["slot"] = v93,
					["visual"] = v94
				})
				v88 = v88 + 1
				v91.usedSlots = v91.usedSlots + 1
			end
		end
	end
end
function LivestockTrailer.clearAnimals(p96)
	local v97 = p96.spec_livestockTrailer
	if v97.animalTypeIndexToPlaces ~= nil then
		for _, v98 in pairs(v97.animalTypeIndexToPlaces) do
			for _, v99 in ipairs(v98.slots) do
				if v99.sharedLoadRequestId ~= nil then
					g_i3DManager:releaseSharedI3DFile(v99.sharedLoadRequestId)
					v99.sharedLoadRequestId = nil
				end
				if v99.loadedMesh ~= nil then
					delete(v99.loadedMesh)
					v99.loadedMesh = nil
				end
			end
		end
	end
end
function LivestockTrailer.onAnimalLoaded(_, p100, _, p101)
	if p100 ~= 0 then
		local v102 = p101.slot
		local v103 = p101.visual
		link(v102.linkNode, p100)
		v102.loadedMesh = p100
		v102.meshLoadingInProgress = false
		local v104 = v103.visualAnimal.variations[1]
		local v105 = v104.tileUIndex / v104.numTilesU
		local v106 = v104.tileVIndex / v104.numTilesV
		I3DUtil.setShaderParameterRec(p100, "atlasInvSizeAndOffsetUV", 1 / v104.numTilesU, 1 / v104.numTilesV, v105, v106)
		I3DUtil.setShaderParameterRec(p100, "dirt", 0, nil, nil, nil)
	end
end
function LivestockTrailer.getAdditionalComponentMass(p107, p108, p109)
	local v110 = p108(p107, p109)
	local v111 = p107.spec_livestockTrailer.clusterSystem:getClusters()
	for _, v112 in ipairs(v111) do
		local v113 = v112:getSubTypeIndex()
		local v114 = g_currentMission.animalSystem:getSubTypeByIndex(v113).fillTypeIndex
		v110 = v110 + g_fillTypeManager:getFillTypeByIndex(v114).massPerLiter * v112:getNumAnimals()
	end
	return v110
end
function LivestockTrailer.getSellPrice(p115, p116)
	local v117 = p116(p115)
	local v118 = p115.spec_livestockTrailer.clusterSystem:getClusters()
	for _, v119 in ipairs(v118) do
		v117 = v117 + v119:getSellPrice() * v119:getNumAnimals() * 0.75
	end
	return v117
end
function LivestockTrailer.dayChanged(p120, p121)
	p121(p120)
	local v122 = p120.spec_livestockTrailer.clusterSystem:getClusters()
	for _, v123 in ipairs(v122) do
		v123:onDayChanged()
	end
end
function LivestockTrailer.periodChanged(p124, p125)
	p125(p124)
	local v126 = p124.spec_livestockTrailer.clusterSystem:getClusters()
	for _, v127 in ipairs(v126) do
		v127:onPeriodChanged()
	end
end
function LivestockTrailer.onAnimalLoadTriggerCallback(p128, _, p129, p130, p131, _)
	if p130 or p131 then
		local v132 = p128.spec_livestockTrailer
		local v133 = g_currentMission.nodeToObject[p129]
		if v133 ~= nil and v133.spec_rideable ~= nil then
			local v134 = v133:getCluster()
			if v134 ~= nil and p128:getSupportsAnimalSubType((v134:getSubTypeIndex())) then
				if p130 then
					table.addElement(v132.rideablesInTrigger, v133)
					v133:addDeleteListener(p128, "onAnimalRideableDeleted")
				else
					table.removeElement(v132.rideablesInTrigger, v133)
					v133:removeDeleteListener(p128, "onAnimalRideableDeleted")
				end
				if v132.animalScreenController ~= nil then
					v132.animalScreenController:onAnimalsChanged(p128, nil)
				end
			end
		end
	end
end
function LivestockTrailer.onAnimalRideableDeleted(p135, p136)
	local v137 = p135.spec_livestockTrailer
	table.removeElement(v137.rideablesInTrigger, p136)
	if v137.animalScreenController ~= nil then
		v137.animalScreenController:onAnimalsChanged(p135, nil)
	end
end
function LivestockTrailer.getAnimalUnloadPlaces(p138)
	local v139 = p138.spec_livestockTrailer
	local v140 = {}
	for _, v141 in ipairs(v139.spawnPlaces) do
		local v142 = v141.node
		local v143, v144, v145 = getWorldTranslation(v142)
		local v146 = {
			["startX"] = v143,
			["startY"] = v144,
			["startZ"] = v145
		}
		local v147, v148, v149 = getWorldRotation(v142)
		v146.rotX = v147
		v146.rotY = v148
		v146.rotZ = v149
		local v150, v151, v152 = localDirectionToWorld(v142, 1, 0, 0)
		v146.dirX = v150
		v146.dirY = v151
		v146.dirZ = v152
		local v153, v154, v155 = localDirectionToWorld(v142, 0, 0, 1)
		v146.dirPerpX = v153
		v146.dirPerpY = v154
		v146.dirPerpZ = v155
		v146.yOffset = 1
		v146.maxWidth = (1 / 0)
		v146.maxLength = (1 / 0)
		v146.maxHeight = (1 / 0)
		v146.width = v141.width
		table.insert(v140, v146)
	end
	return v140
end
function LivestockTrailer.loadSpecValueNumberAnimals(p156, _, _, p157)
	local v158 = p156:getRootName()
	local v159 = 0
	local v160 = nil
	while true do
		local v161 = string.format("%s.livestockTrailer.animal(%d)", v158, v159)
		if not p156:hasProperty(v161) then
			break
		end
		local v162 = p156:getValue(v161 .. "#type")
		if v162 ~= nil and string.lower(v162) == string.lower(p157) then
			return p156:getValue(v161 .. "#numSlots", 0)
		end
		v159 = v159 + 1
	end
	return v160
end
function LivestockTrailer.loadSpecValueNumberAnimalsCow(p163, p164, p165)
	return LivestockTrailer.loadSpecValueNumberAnimals(p163, p164, p165, "cow")
end
function LivestockTrailer.loadSpecValueNumberAnimalsPig(p166, p167, p168)
	return LivestockTrailer.loadSpecValueNumberAnimals(p166, p167, p168, "pig")
end
function LivestockTrailer.loadSpecValueNumberAnimalsSheep(p169, p170, p171)
	return LivestockTrailer.loadSpecValueNumberAnimals(p169, p170, p171, "sheep")
end
function LivestockTrailer.loadSpecValueNumberAnimalsHorse(p172, p173, p174)
	return LivestockTrailer.loadSpecValueNumberAnimals(p172, p173, p174, "horse")
end
function LivestockTrailer.getSpecValueNumberAnimals(p175, _, p176)
	if p175.specs[p176] == nil then
		return nil
	else
		return string.format("%d %s", p175.specs[p176], g_i18n:getText("unit_pieces"))
	end
end
function LivestockTrailer.getSpecValueNumberAnimalsCow(p177, p178)
	return LivestockTrailer.getSpecValueNumberAnimals(p177, p178, "numAnimalsCow")
end
function LivestockTrailer.getSpecValueNumberAnimalsPig(p179, p180)
	return LivestockTrailer.getSpecValueNumberAnimals(p179, p180, "numAnimalsPig")
end
function LivestockTrailer.getSpecValueNumberAnimalsSheep(p181, p182)
	return LivestockTrailer.getSpecValueNumberAnimals(p181, p182, "numAnimalsSheep")
end
function LivestockTrailer.getSpecValueNumberAnimalsHorse(p183, p184)
	return LivestockTrailer.getSpecValueNumberAnimals(p183, p184, "numAnimalsHorse")
end

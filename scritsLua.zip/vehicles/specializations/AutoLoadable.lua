AutoLoadable = {}
function AutoLoadable.prerequisitesPresent(_)
	return true
end
function AutoLoadable.registerFunctions(p1)
	SpecializationUtil.registerFunction(p1, "getAutoLoadIsSupported", AutoLoadable.getAutoLoadIsSupported)
	SpecializationUtil.registerFunction(p1, "getAutoLoadIsAllowed", AutoLoadable.getAutoLoadIsAllowed)
	SpecializationUtil.registerFunction(p1, "getAutoLoadBoundingBox", AutoLoadable.getAutoLoadBoundingBox)
	SpecializationUtil.registerFunction(p1, "getAutoLoadSize", AutoLoadable.getAutoLoadSize)
	SpecializationUtil.registerFunction(p1, "autoLoad", AutoLoadable.autoLoad)
end
function AutoLoadable.registerEventListeners(p2)
	SpecializationUtil.registerEventListener(p2, "onLoad", AutoLoadable)
end
function AutoLoadable.onLoad(p3, _)
	if p3.isServer then
		p3.spec_autoLoadable.isSupported = true
	end
end
function AutoLoadable.getAutoLoadIsSupported(p4)
	return p4.spec_autoLoadable.isSupported
end
function AutoLoadable.getAutoLoadIsAllowed(_)
	return true
end
function AutoLoadable.getAutoLoadSize(p5)
	local v6 = p5.size
	return v6.width, v6.height, v6.length
end
function AutoLoadable.getAutoLoadBoundingBox(p7)
	local v8 = p7.size
	local v9, v10, v11 = localToWorld(p7.rootNode, v8.widthOffset, v8.heightOffset, v8.lengthOffset)
	local v12, v13, v14 = localDirectionToWorld(p7.rootNode, 0, 0, 1)
	local v15, v16, v17 = localDirectionToWorld(p7.rootNode, 0, 1, 0)
	return v9, v10, v11, v12, v13, v14, v15, v16, v17, v8.width * 0.5, v8.height * 0.5, v8.length * 0.5
end
function AutoLoadable.autoLoad(p18, p19, p20, p21, p22, _, _)
	local v23 = p18.size
	p18:mountKinematic(p19, p20, p21 + v23.widthOffset + v23.width * 0.5, v23.heightOffset, p22 + v23.lengthOffset + v23.height * 0.5, 0, 0, 0)
	return true
end

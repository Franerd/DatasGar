AutoLoadForwarder = {}
function AutoLoadForwarder.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AutomaticArmControlForwarder, p1)
end
function AutoLoadForwarder.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("AutoLoadForwarder")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.autoLoadForwarder#idlePositionNode", "Crane will move to this position after the tree has been loaded")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.autoLoadForwarder#dropPositionNode", "Crane will move to this position before the tree is dropped on the loading bay")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.autoLoadForwarder#craneTreeJointNode", "Tree will be mounted to this node while mounted to the crane")
	v2:register(XMLValueType.INT, "vehicle.autoLoadForwarder.loadPlaces#fillUnitIndex", "Fill unit index")
	v2:register(XMLValueType.FLOAT, "vehicle.autoLoadForwarder.loadPlaces#dropOffset", "Y offset of crane to the load place before dropping the tree", 0)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.autoLoadForwarder.loadPlaces.loadPlace(?)#node", "Load place node")
	v2:register(XMLValueType.STRING, "vehicle.autoLoadForwarder.grabAnimation#name", "Grab animation name")
	v2:register(XMLValueType.FLOAT, "vehicle.autoLoadForwarder.grabAnimation#speedScale", "Animation speed scale")
	v2:register(XMLValueType.FLOAT, "vehicle.autoLoadForwarder.grabAnimation#filledTime", "Target animation time when a tree is grabbed")
	v2:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.STRING, "vehicles.vehicle(?).autoLoadForwarder#treeI3DFilename", "Path to i3d file of the tree")
end
function AutoLoadForwarder.registerEvents(p3)
	SpecializationUtil.registerEvent(p3, "onAutoLoadForwaderMountedTree")
end
function AutoLoadForwarder.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "mountTreeToCrane", AutoLoadForwarder.mountTreeToCrane)
	SpecializationUtil.registerFunction(p4, "addTreeToLoadPlaces", AutoLoadForwarder.addTreeToLoadPlaces)
	SpecializationUtil.registerFunction(p4, "removeMountedObject", AutoLoadForwarder.removeMountedObject)
	SpecializationUtil.registerFunction(p4, "sortLoadedTreeObjects", AutoLoadForwarder.sortLoadedTreeObjects)
end
function AutoLoadForwarder.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAreControlledActionsAllowed", AutoLoadForwarder.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p5, "addToPhysics", AutoLoadForwarder.addToPhysics)
end
function AutoLoadForwarder.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", AutoLoadForwarder)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", AutoLoadForwarder)
	SpecializationUtil.registerEventListener(p6, "onDelete", AutoLoadForwarder)
	SpecializationUtil.registerEventListener(p6, "onUpdate", AutoLoadForwarder)
	SpecializationUtil.registerEventListener(p6, "onRootVehicleChanged", AutoLoadForwarder)
end
function AutoLoadForwarder.onLoad(p_u_7, _)
	local v_u_8 = p_u_7.spec_autoLoadForwarder
	v_u_8.idlePositionNode = p_u_7.xmlFile:getValue("vehicle.autoLoadForwarder#idlePositionNode", nil, p_u_7.components, p_u_7.i3dMappings)
	v_u_8.dropPositionNode = p_u_7.xmlFile:getValue("vehicle.autoLoadForwarder#dropPositionNode", nil, p_u_7.components, p_u_7.i3dMappings)
	v_u_8.craneTreeJointNode = p_u_7.xmlFile:getValue("vehicle.autoLoadForwarder#craneTreeJointNode", nil, p_u_7.components, p_u_7.i3dMappings)
	v_u_8.loadPlaces = {}
	v_u_8.loadPlaceFillUnitIndex = p_u_7.xmlFile:getValue("vehicle.autoLoadForwarder.loadPlaces#fillUnitIndex", 1)
	v_u_8.loadPlaceDropOffset = p_u_7.xmlFile:getValue("vehicle.autoLoadForwarder.loadPlaces#dropOffset", 0)
	p_u_7.xmlFile:iterate("vehicle.autoLoadForwarder.loadPlaces.loadPlace", function(_, p9)
		-- upvalues: (copy) p_u_7, (copy) v_u_8
		local v10 = {
			["node"] = p_u_7.xmlFile:getValue(p9 .. "#node", nil, p_u_7.components, p_u_7.i3dMappings)
		}
		if v10.node ~= nil then
			v10.treeObject = nil
			local v11 = v_u_8.loadPlaces
			table.insert(v11, v10)
		end
	end)
	v_u_8.grabAnimation = {}
	v_u_8.grabAnimation.name = p_u_7.xmlFile:getValue("vehicle.autoLoadForwarder.grabAnimation#name")
	v_u_8.grabAnimation.speedScale = p_u_7.xmlFile:getValue("vehicle.autoLoadForwarder.grabAnimation#speedScale", 1)
	v_u_8.grabAnimation.filledTime = p_u_7.xmlFile:getValue("vehicle.autoLoadForwarder.grabAnimation#filledTime", 0.5)
	v_u_8.grappleTreeId = nil
	v_u_8.pendingIdleReturn = false
	v_u_8.texts = {}
	v_u_8.texts.warning_forwarderNoTreeInRange = g_i18n:getText("warning_forwarderNoTreeInRange")
end
function AutoLoadForwarder.onPostLoad(p_u_12, p13)
	local v14 = p_u_12.spec_autoLoadForwarder
	if v14.grabAnimation.name ~= nil then
		p_u_12:setAnimationTime(v14.grabAnimation.name, 1, true)
	end
	local v15 = MathUtil.round(p_u_12:getFillUnitFillLevel(v14.loadPlaceFillUnitIndex))
	if v15 > 0 and not p13.resetVehicles then
		p_u_12:addFillUnitFillLevel(p_u_12:getOwnerFarmId(), v14.loadPlaceFillUnitIndex, (-1 / 0), p_u_12:getFillUnitFillType(v14.loadPlaceFillUnitIndex), ToolType.UNDEFINED, nil)
		local v16 = p13.xmlFile:getValue(p13.key .. ".autoLoadForwarder#treeI3DFilename")
		if v16 ~= nil then
			local v17 = NetworkUtil.convertFromNetworkFilename(v16)
			local function v20(_, p18, p19, _)
				-- upvalues: (copy) p_u_12
				if p19 then
					p_u_12:addTreeToLoadPlaces(p18)
				end
			end
			for _ = 1, v15 do
				local v21 = ForestryLog.new(p_u_12.isServer, p_u_12.isClient)
				v21:loadFromFilename(v17, 0, 0, 0, 0, 0, 0, v20, p_u_12, v21)
			end
		end
	end
end
function AutoLoadForwarder.onDelete(p22)
	local v23 = p22.spec_autoLoadForwarder
	for v24 = #v23.loadPlaces, 1, -1 do
		local v25 = v23.loadPlaces[v24]
		if v25.treeObject ~= nil then
			v25.treeObject:delete()
			v25.treeObject = nil
		end
	end
end
function AutoLoadForwarder.saveToXMLFile(p26, p27, p28, _)
	local v29 = p26.spec_autoLoadForwarder
	if MathUtil.round(p26:getFillUnitFillLevel(v29.loadPlaceFillUnitIndex)) > 0 then
		for v30 = 1, #v29.loadPlaces do
			local v31 = v29.loadPlaces[v30]
			if v31.treeObject ~= nil then
				p27:setValue(p28 .. "#treeI3DFilename", HTMLUtil.encodeToHTML(NetworkUtil.convertToNetworkFilename(v31.treeObject.i3dFilename)))
				return
			end
		end
	end
end
function AutoLoadForwarder.onUpdate(p32, _, _, _, _)
	local v33 = p32.spec_autoLoadForwarder
	if Platform.gameplay.automaticVehicleControl then
		if p32:getActionControllerDirection() == -1 then
			if v33.grappleTreeId == nil then
				local v34, v35, v36, v37, v38, v39 = p32:getAutomaticAlignmentCurrentTarget()
				if v34 == nil then
					p32:playControlledActions()
					return
				elseif p32:getIsAutomaticAlignmentFinished() then
					local v40 = v33.craneTargetTreeId
					if v40 == nil or not (entityExists(v40) and p32:mountTreeToCrane(v40)) then
						v33.grappleTreeId = nil
						p32:playControlledActions()
						if v33.grabAnimation.name ~= nil then
							p32:playAnimation(v33.grabAnimation.name, v33.grabAnimation.speedScale, p32:getAnimationTime(v33.grabAnimation.name))
						end
					else
						v33.grappleTreeId = v40
						p32:resetAutomaticAlignment()
						if v33.grabAnimation.name ~= nil then
							p32:setAnimationTime(v33.grabAnimation.name, v33.grabAnimation.filledTime, true)
						end
					end
					v33.craneTargetTreeId = nil
				else
					p32:doTreeArmAlignment(v34, v35, v36, v37, v38, v39, 1)
					if v33.grabAnimation.name ~= nil and (not p32:getIsAnimationPlaying(v33.grabAnimation.name) and p32:getAnimationTime(v33.grabAnimation.name) > 0) then
						p32:playAnimation(v33.grabAnimation.name, -v33.grabAnimation.speedScale, p32:getAnimationTime(v33.grabAnimation.name))
					end
					v33.craneTargetTreeId = p32:getAutomaticAlignmentTargetTree()
				end
			end
			local v41 = nil
			for v42 = 1, #v33.loadPlaces do
				local v43 = v33.loadPlaces[v42]
				if v43.treeObject == nil then
					v41 = v43
					break
				end
			end
			if v41 ~= nil then
				local v44, v45, v46 = getWorldTranslation(v41.node)
				local v47, v48, v49 = localDirectionToWorld(v41.node, 0, 0, 1)
				p32:doTreeArmAlignment(v44, v45 + v33.loadPlaceDropOffset, v46, v47, v48, v49, -1)
				if p32:getIsAutomaticAlignmentFinished() then
					if v33.grappleTreeId ~= nil and entityExists(v33.grappleTreeId) then
						local v50 = g_currentMission:getNodeObject(v33.grappleTreeId)
						if v50 ~= nil then
							p32:addTreeToLoadPlaces(v50)
						end
					end
					v33.grappleTreeId = nil
					p32:resetAutomaticAlignment()
					if p32:getAutomaticAlignmentAvailableTargetTree() == nil or p32:getFillUnitFreeCapacity(v33.loadPlaceFillUnitIndex) < 1 then
						p32:playControlledActions()
						if v33.grabAnimation.name ~= nil then
							p32:playAnimation(v33.grabAnimation.name, v33.grabAnimation.speedScale, p32:getAnimationTime(v33.grabAnimation.name))
							return
						end
					end
				end
			end
		elseif v33.pendingIdleReturn then
			if v33.idlePositionNode == nil then
				v33.pendingIdleReturn = false
			else
				p32:setEasyControlForcedTransMove(-1)
				local v51, v52, v53 = getWorldTranslation(v33.idlePositionNode)
				local v54, v55, v56 = localDirectionToWorld(v33.idlePositionNode, 0, 0, 1)
				p32:doTreeArmAlignment(v51, v52, v53, v54, v55, v56, -1, true)
				if p32:getIsAutomaticAlignmentFinished() then
					v33.pendingIdleReturn = false
					return
				end
			end
		end
	end
end
function AutoLoadForwarder.onRootVehicleChanged(p_u_57, p58)
	local v_u_59 = p_u_57.spec_autoLoadForwarder
	local v60 = p58.actionController
	if v60 == nil then
		if v_u_59.controlledAction ~= nil then
			v_u_59.controlledAction:remove()
			v_u_59.controlledAction = nil
		end
		return
	elseif v_u_59.controlledAction == nil then
		v_u_59.controlledAction = v60:registerAction("forwarderLoading", nil, 4)
		v_u_59.controlledAction:setCallback(p_u_57, AutoLoadForwarder.actionControllerEvent)
		v_u_59.controlledAction:setIsAvailableFunction(function()
			-- upvalues: (copy) v_u_59, (copy) p_u_57
			local v61
			if v_u_59.grappleTreeId == nil then
				v61 = p_u_57:getFillUnitFreeCapacity(v_u_59.loadPlaceFillUnitIndex) > 0
			else
				v61 = false
			end
			return v61
		end)
		v_u_59.controlledAction:setActionIcons("LOAD_LOG", "LOAD_LOG", true)
	else
		v_u_59.controlledAction:updateParent(v60)
	end
end
function AutoLoadForwarder.actionControllerEvent(p62, p63)
	local v64 = p62.spec_autoLoadForwarder
	if p63 < 0 then
		v64.pendingIdleReturn = true
		p62:resetAutomaticAlignment()
		if v64.grabAnimation.name ~= nil then
			p62:playAnimation(v64.grabAnimation.name, v64.grabAnimation.speedScale, p62:getAnimationTime(v64.grabAnimation.name))
		end
	else
		v64.pendingIdleReturn = false
		p62:resetAutomaticAlignment()
	end
	return true
end
function AutoLoadForwarder.getAreControlledActionsAllowed(p65, p66)
	if p65:getActionControllerDirection() == 1 and p65:getAutomaticAlignmentTargetTree() == nil then
		return false, p65.spec_autoLoadForwarder.texts.warning_forwarderNoTreeInRange
	else
		return p66(p65)
	end
end
function AutoLoadForwarder.addToPhysics(p67, p68)
	if not p68(p67) then
		return false
	end
	local v69 = p67.spec_autoLoadForwarder
	for v70 = 1, #v69.loadPlaces do
		local v71 = v69.loadPlaces[v70]
		if v71.treeObject ~= nil then
			local v72, v73, v74 = getRotation(v71.treeObject.nodeId)
			v71.treeObject:mountKinematic(p67, v71.node, 0, 0, 0, v72, v73, v74)
			SpecializationUtil.raiseEvent(p67, "onAutoLoadForwaderMountedTree", v71.treeObject.nodeId)
		end
	end
	return true
end
function AutoLoadForwarder.mountTreeToCrane(p75, p76)
	local v77 = g_currentMission:getNodeObject(p76)
	if v77 == nil then
		return false
	end
	local v78 = p75.spec_autoLoadForwarder
	local v79 = getUserAttribute(p76, "logRadius") or 0.5
	local v80, _, v81 = localRotationToLocal(p76, v78.craneTreeJointNode, 0, 0, 0)
	local v82 = math.abs(v80) < 1.5707963267948966 and 0 or v80
	v77:mountKinematic(p75, v78.craneTreeJointNode, 0, -v79, 0, v82, 0, v81)
	SpecializationUtil.raiseEvent(p75, "onAutoLoadForwaderMountedTree", v77.nodeId)
	return true
end
function AutoLoadForwarder.addTreeToLoadPlaces(p83, p84)
	local v85 = p83.spec_autoLoadForwarder
	p83:addFillUnitFillLevel(p83:getOwnerFarmId(), v85.loadPlaceFillUnitIndex, 1, p83:getFillUnitFirstSupportedFillType(v85.loadPlaceFillUnitIndex), ToolType.UNDEFINED, nil)
	for v86 = 1, #v85.loadPlaces do
		local v87 = v85.loadPlaces[v86]
		if v87.treeObject == nil then
			local v88, _, v89 = localRotationToLocal(p84.nodeId, v87.node, 0, 0, 0)
			local v90 = math.abs(v88) < 1.5707963267948966 and 0 or 3.141592653589793
			p84:mountKinematic(p83, v87.node, 0, 0, 0, v90, 0, v89)
			v87.treeObject = p84
			SpecializationUtil.raiseEvent(p83, "onAutoLoadForwaderMountedTree", p84.nodeId)
			return
		end
	end
	p84:delete()
end
function AutoLoadForwarder.removeMountedObject(p91, p92, _)
	local v93 = p91.spec_autoLoadForwarder
	for v94 = 1, #v93.loadPlaces do
		local v95 = v93.loadPlaces[v94]
		if v95.treeObject == p92 then
			v95.treeObject = nil
			p91:addFillUnitFillLevel(p91:getOwnerFarmId(), v93.loadPlaceFillUnitIndex, -1, p91:getFillUnitFirstSupportedFillType(v93.loadPlaceFillUnitIndex), ToolType.UNDEFINED, nil)
		end
	end
	p91:sortLoadedTreeObjects()
end
function AutoLoadForwarder.sortLoadedTreeObjects(p96)
	local v97 = p96.spec_autoLoadForwarder
	for v98 = 1, #v97.loadPlaces do
		local v99 = v97.loadPlaces[v98]
		if v99.treeObject == nil then
			local v100 = false
			for v101 = v98 + 1, #v97.loadPlaces do
				local v102 = v97.loadPlaces[v101]
				if v102.treeObject ~= nil then
					local v103, v104, v105 = getRotation(v102.treeObject.nodeId)
					v102.treeObject:mountKinematic(p96, v99.node, 0, 0, 0, v103, v104, v105)
					v99.treeObject = v102.treeObject
					v102.treeObject = nil
					v100 = true
					break
				end
			end
			if not v100 then
				break
			end
		end
	end
end

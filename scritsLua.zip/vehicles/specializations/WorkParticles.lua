WorkParticles = {}
WorkParticles.PARTICLE_MAPPING_XML_PATH = "vehicle.workParticles.particle(?).node(?)"
function WorkParticles.prerequisitesPresent(_)
	return true
end
function WorkParticles.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("WorkParticles")
	v1:register(XMLValueType.STRING, "vehicle.workParticles.particleAnimation(?)#file", "External effect i3d file")
	v1:register(XMLValueType.FLOAT, "vehicle.workParticles.particleAnimation(?)#speedThreshold", "Speed threshold", 0)
	WorkParticles.registerGroundAnimationMappingXMLPaths(v1, "vehicle.workParticles.particleAnimation(?).node(?)")
	v1:register(XMLValueType.STRING, "vehicle.workParticles.particle(?)#file", "External effect i3d file")
	WorkParticles.registerGroundParticleMappingXMLPaths(v1, "vehicle.workParticles.particle(?).node(?)")
	v1:register(XMLValueType.BOOL, "vehicle.workParticles#requireField", "The effects require the vehicle to be on a field to work", true)
	EffectManager.registerEffectXMLPaths(v1, "vehicle.workParticles.effect(?)")
	v1:register(XMLValueType.FLOAT, "vehicle.workParticles.effect(?)#speedThreshold", "Speed threshold", 0.5)
	v1:register(XMLValueType.INT, "vehicle.workParticles.effect(?)#activeDirection", "Active Direction (effect will be turned off wen in opposite direction)", 1)
	v1:register(XMLValueType.INT, "vehicle.workParticles.effect(?)#workAreaIndex", "Work area index")
	v1:register(XMLValueType.INT, "vehicle.workParticles.effect(?)#groundReferenceNodeIndex", "Index of ground reference node")
	v1:register(XMLValueType.BOOL, "vehicle.workParticles.effect(?)#needsSetIsTurnedOn", "Needs set is turned on", false)
	v1:register(XMLValueType.NODE_INDEX, GroundReference.GROUND_REFERENCE_XML_KEY .. "#depthNode", "Depth node")
	v1:setXMLSpecializationType()
end
function WorkParticles.registerGroundAnimationMappingXMLPaths(p2, p3)
	p2:register(XMLValueType.NODE_INDEX, p3 .. "#node", "Link node in vehicle")
	p2:register(XMLValueType.INT, p3 .. "#refNodeIndex", "Ground reference node index")
	p2:register(XMLValueType.STRING, p3 .. "#animMeshNode", "Animation mesh node in external file")
	p2:register(XMLValueType.STRING, p3 .. "#materialType", "Material type name (If external file is not given)")
	p2:register(XMLValueType.INT, p3 .. "#materialId", "Material index (If external file is not given)", 1)
	p2:register(XMLValueType.FLOAT, p3 .. "#maxDepth", "Max. depth", -0.1)
end
function WorkParticles.registerGroundParticleMappingXMLPaths(p4, p5)
	p4:register(XMLValueType.NODE_INDEX, p5 .. "#node", "Link node in vehicle")
	p4:register(XMLValueType.INT, p5 .. "#refNodeIndex", "Ground reference node index")
	p4:register(XMLValueType.STRING, p5 .. "#particleNode", "Particle node in external file")
	p4:register(XMLValueType.STRING, p5 .. "#particleType", "Particle type name (If external file is not given)")
	p4:register(XMLValueType.STRING, p5 .. "#fillType", "Fill type for particles (If external file is not given)", "UNKNOWN")
	p4:register(XMLValueType.FLOAT, p5 .. "#speedThreshold", "Speed threshold", 0.5)
	p4:register(XMLValueType.INT, p5 .. "#movingDirection", "Moving direction")
	ParticleUtil.registerParticleCopyXMLPaths(p4, p5)
end
function WorkParticles.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "getDoGroundManipulation", WorkParticles.getDoGroundManipulation)
	SpecializationUtil.registerFunction(p6, "loadGroundAnimations", WorkParticles.loadGroundAnimations)
	SpecializationUtil.registerFunction(p6, "onGroundAnimationI3DLoaded", WorkParticles.onGroundAnimationI3DLoaded)
	SpecializationUtil.registerFunction(p6, "loadGroundAnimationMapping", WorkParticles.loadGroundAnimationMapping)
	SpecializationUtil.registerFunction(p6, "loadGroundParticles", WorkParticles.loadGroundParticles)
	SpecializationUtil.registerFunction(p6, "groundParticleI3DLoaded", WorkParticles.groundParticleI3DLoaded)
	SpecializationUtil.registerFunction(p6, "loadGroundParticleMapping", WorkParticles.loadGroundParticleMapping)
	SpecializationUtil.registerFunction(p6, "loadGroundEffects", WorkParticles.loadGroundEffects)
	SpecializationUtil.registerFunction(p6, "getFillTypeFromWorkAreaIndex", WorkParticles.getFillTypeFromWorkAreaIndex)
end
function WorkParticles.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadGroundReferenceNode", WorkParticles.loadGroundReferenceNode)
	SpecializationUtil.registerOverwrittenFunction(p7, "updateGroundReferenceNode", WorkParticles.updateGroundReferenceNode)
end
function WorkParticles.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", WorkParticles)
	SpecializationUtil.registerEventListener(p8, "onDelete", WorkParticles)
	SpecializationUtil.registerEventListener(p8, "onUpdateTick", WorkParticles)
	SpecializationUtil.registerEventListener(p8, "onDeactivate", WorkParticles)
end
function WorkParticles.onLoad(p9, _)
	local v10 = p9.spec_workParticles
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.groundParticleAnimations.groundParticleAnimation", "vehicle.workParticles.particleAnimation")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.groundParticleAnimations.groundParticle", "vehicle.workParticles.particle")
	if p9.isClient then
		v10.requireField = p9.xmlFile:getValue("vehicle.workParticles#requireField", true)
		v10.particleAnimations = {}
		local v11 = 0
		while true do
			local v12 = string.format("vehicle.workParticles.particleAnimation(%d)", v11)
			if not p9.xmlFile:hasProperty(v12) then
				break
			end
			local v13 = {}
			if p9:loadGroundAnimations(p9.xmlFile, v12, v13, v11) then
				local v14 = v10.particleAnimations
				table.insert(v14, v13)
			end
			v11 = v11 + 1
		end
		v10.particles = {}
		local v15 = 0
		while true do
			local v16 = string.format("vehicle.workParticles.particle(%d)", v15)
			if not p9.xmlFile:hasProperty(v16) then
				break
			end
			local v17 = {}
			if p9:loadGroundParticles(p9.xmlFile, v16, v17, v15) then
				local v18 = v10.particles
				table.insert(v18, v17)
			end
			v15 = v15 + 1
		end
		v10.effects = {}
		local v19 = 0
		while true do
			local v20 = string.format("vehicle.workParticles.effect(%d)", v19)
			if not p9.xmlFile:hasProperty(v20) then
				break
			end
			local v21 = {}
			if p9:loadGroundEffects(p9.xmlFile, v20, v21, v19) then
				local v22 = v10.effects
				table.insert(v22, v21)
			end
			v19 = v19 + 1
		end
	end
	if not p9.isClient then
		SpecializationUtil.removeEventListener(p9, "onDelete", WorkParticles)
		SpecializationUtil.removeEventListener(p9, "onUpdateTick", WorkParticles)
		SpecializationUtil.removeEventListener(p9, "onDeactivate", WorkParticles)
	end
end
function WorkParticles.onDelete(p23)
	local v24 = p23.spec_workParticles
	if v24.particleAnimations ~= nil then
		for _, v25 in ipairs(v24.particleAnimations) do
			if v25.sharedLoadRequestId ~= nil then
				g_i3DManager:releaseSharedI3DFile(v25.sharedLoadRequestId)
				v25.sharedLoadRequestId = nil
			end
		end
	end
	if v24.particles ~= nil then
		for _, v26 in pairs(v24.particles) do
			for _, v27 in ipairs(v26.mappings) do
				ParticleUtil.deleteParticleSystem(v27.particleSystem)
			end
			if v26.sharedLoadRequestId ~= nil then
				g_i3DManager:releaseSharedI3DFile(v26.sharedLoadRequestId)
				v26.sharedLoadRequestId = nil
			end
		end
	end
	if v24.effects ~= nil then
		for _, v28 in pairs(v24.effects) do
			g_effectManager:deleteEffects(v28.effect)
		end
	end
end
function WorkParticles.onUpdateTick(p29, _, _, _, _)
	local v30 = p29.spec_workParticles
	local v31 = p29:getIsOnField() or not v30.requireField
	for _, v32 in ipairs(v30.particleAnimations) do
		for _, v33 in ipairs(v32.mappings) do
			local v34 = v33.groundRefNode
			if v34 ~= nil and v34.depthNode ~= nil then
				local v35 = v34.depth / v33.maxWorkDepth
				local v36 = not v31 and 0 or math.clamp(v35, 0, 1)
				local v37 = v33.lastDepth + v34.movingDirection * (v34.movedDistance / 0.5)
				local v38 = math.min(v36, v37)
				local v39 = math.clamp(v38, 0, 1)
				v33.lastDepth = v39
				v33.speed = v33.speed - v34.movedDistance * v34.movingDirection
				setVisibility(v33.animNode, v39 > 0)
				setShaderParameter(v33.animNode, "VertxoffsetVertexdeformMotionUVscale", -6, v39, v33.speed, 1.5, false)
			end
		end
	end
	local v40 = p29:getLastSpeed(true)
	local v41 = p29:getDoGroundManipulation() and v31
	for _, v42 in pairs(v30.particles) do
		for _, v43 in ipairs(v42.mappings) do
			local v44
			if v41 then
				v44 = v43.groundRefNode.isActive
				if v44 then
					v44 = v43.speedThreshold < v40
				end
			else
				v44 = v41
			end
			if v43.movingDirection ~= nil then
				if v44 then
					v44 = v43.movingDirection == p29.movingDirection
				end
			end
			ParticleUtil.setEmittingState(v43.particleSystem, v44)
		end
	end
	for _, v45 in pairs(v30.effects) do
		local v46
		if v41 then
			v46 = v45.speedThreshold < v40
		else
			v46 = v41
		end
		if v45.needsSetIsTurnedOn and p29.getIsTurnedOn ~= nil then
			local v47 = p29:getIsTurnedOn()
			if p29.getAttacherVehicle ~= nil then
				local v48 = p29:getAttacherVehicle()
				if v48 ~= nil and v48.getIsTurnedOn ~= nil then
					v47 = v47 or v48:getIsTurnedOn()
				end
			end
			v46 = v46 and v47
		end
		local v49 = p29:getWorkAreaByIndex(v45.workAreaIndex)
		if v49 ~= nil and v49.requiresGroundContact then
			if v46 then
				if v49.groundReferenceNode == nil then
					v46 = false
				else
					v46 = v49.groundReferenceNode.isActive
				end
			end
		end
		if v45.groundReferenceNodeIndex ~= nil and v45.groundReferenceNode == nil then
			v45.groundReferenceNode = p29:getGroundReferenceNodeFromIndex(v45.groundReferenceNodeIndex)
			if v45.groundReferenceNode == nil then
				Logging.warning("Unknown ground reference node \'%s\' for WorkParticle effect!", v45.groundReferenceNodeIndex)
				v45.groundReferenceNodeIndex = nil
			end
		end
		if v45.groundReferenceNode ~= nil then
			if v46 then
				v46 = v45.groundReferenceNode.isActive
			end
		end
		if v46 then
			v46 = p29.movingDirection ~= -v45.activeDirection and true or p29:getLastSpeed() < 0.5
		end
		if v46 then
			local v50 = p29:getFillTypeFromWorkAreaIndex(v45.workAreaIndex)
			g_effectManager:setEffectTypeInfo(v45.effect, v50)
			g_effectManager:startEffects(v45.effect)
		else
			g_effectManager:stopEffects(v45.effect)
		end
	end
end
function WorkParticles.getDoGroundManipulation(_)
	return true
end
function WorkParticles.loadGroundAnimations(p51, p52, p53, p54, _)
	p54.speedThreshold = p52:getValue(p53 .. "#speedThreshold", 0)
	p54.mappings = {}
	local v55 = 0
	while true do
		local v56 = string.format(p53 .. ".node(%d)", v55)
		if not p51.xmlFile:hasProperty(v56) then
			break
		end
		local v57 = {}
		if p51:loadGroundAnimationMapping(p52, v56, v57, v55) then
			local v58 = p54.mappings
			table.insert(v58, v57)
		end
		v55 = v55 + 1
	end
	local v59 = p51.xmlFile:getValue(p53 .. "#file")
	if v59 ~= nil then
		local v60 = Utils.getFilename(v59, p51.baseDirectory)
		p54.sharedLoadRequestId = p51:loadSubSharedI3DFile(v60, false, false, p51.onGroundAnimationI3DLoaded, p51, {
			["filename"] = v60,
			["animation"] = p54
		})
	end
	return true
end
function WorkParticles.onGroundAnimationI3DLoaded(_, p61, p62)
	if p61 ~= 0 then
		local v63 = p62.animation
		for _, v64 in ipairs(v63.mappings) do
			link(v64.node, v64.animNode)
			setVisibility(v64.animNode, false)
		end
		v63.filename = p62.filename
		delete(p61)
	end
end
function WorkParticles.loadGroundAnimationMapping(p65, p66, p67, p68, _)
	XMLUtil.checkDeprecatedXMLElements(p65.xmlFile, p67 .. "#index", p67 .. "#node")
	XMLUtil.checkDeprecatedXMLElements(p65.xmlFile, p67 .. "#animMeshIndex", p67 .. "#animMeshNode")
	local v69 = p66:getValue(p67 .. "#node", nil, p65.components, p65.i3dMappings)
	if v69 == nil then
		Logging.xmlWarning(p65.xmlFile, "Invalid node \'%s\' for \'%s\'", getXMLString(p66.handle, p67 .. "#node"), p67)
		return false
	end
	local v70 = p66:getValue(p67 .. "#refNodeIndex")
	if v70 == nil or p65:getGroundReferenceNodeFromIndex(v70) == nil then
		Logging.xmlWarning(p65.xmlFile, "Invalid refNodeIndex \'%s\' for \'%s\'", p66:getValue(p67 .. "#refNodeIndex"), p67)
		return false
	end
	local v71 = p66:getValue(p67 .. "#animMeshNode")
	local v72
	if v71 == nil then
		local v73 = p66:getValue(p67 .. "#materialType")
		local v74 = p66:getValue(p67 .. "#materialId", 1)
		if v73 == nil then
			Logging.xmlWarning(p65.xmlFile, "Missing materialType in \'%s\'", p67)
			return false
		end
		local v75 = g_materialManager:getBaseMaterialByName(v73)
		if v75 == nil then
			Logging.xmlWarning(p65.xmlFile, "Invalid materialType \'%s\' or materialId \'%s\' in \'%s\'", v73, v74, p67)
		else
			setMaterial(v69, v75, 0)
		end
		setVisibility(v69, false)
		v72 = v69
	else
		v72 = I3DUtil.indexToObject(v69, v71, p65.i3dMappings)
		if v72 == nil then
			Logging.xmlWarning(p65.xmlFile, "Invalid animMesh node \'%s\' \'%s\'", p66:getValue(p67 .. "#animMeshNode"), p67)
			return false
		end
	end
	p68.node = v69
	p68.animNode = v72
	p68.groundRefNode = p65:getGroundReferenceNodeFromIndex(v70)
	p68.lastDepth = 0
	p68.speed = 0
	p68.maxWorkDepth = p66:getValue(p67 .. "#maxDepth", -0.1)
	return true
end
function WorkParticles.loadGroundParticles(p76, p77, p78, p79, _)
	p79.mappings = {}
	local v80 = p77:getValue(p78 .. "#file")
	if v80 == nil then
		local v81 = 0
		while true do
			local v82 = string.format(p78 .. ".node(%d)", v81)
			if not p77:hasProperty(v82) then
				break
			end
			local v83 = {}
			if p76:loadGroundParticleMapping(p77, v82, v83, v81) then
				local v84 = p79.mappings
				table.insert(v84, v83)
			end
			v81 = v81 + 1
		end
	else
		local v85 = Utils.getFilename(v80, p76.baseDirectory)
		p79.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(v85, false, false, p76.groundParticleI3DLoaded, p76, {
			["xmlFile"] = p77,
			["key"] = p78,
			["particle"] = p79,
			["filename"] = v85
		})
	end
	return true
end
function WorkParticles.groundParticleI3DLoaded(p86, p87, _, p88)
	local v89 = p88.xmlFile
	local v90 = p88.key
	local v91 = p88.particle
	local v92 = p88.filename
	local v93 = 0
	while true do
		local v94 = string.format(v90 .. ".node(%d)", v93)
		if not v89:hasProperty(v94) then
			break
		end
		local v95 = {}
		if p86:loadGroundParticleMapping(v89, v94, v95, v93, p87) then
			local v96 = v91.mappings
			table.insert(v96, v95)
		end
		v93 = v93 + 1
	end
	if p87 ~= 0 then
		for _, v97 in ipairs(v91.mappings) do
			link(v97.node, v97.particleNode)
			ParticleUtil.loadParticleSystemFromNode(v97.particleNode, v97.particleSystem, false, true)
		end
		v91.filename = v92
		delete(p87)
	end
end
function WorkParticles.loadGroundParticleMapping(p98, p99, p100, p101, _, p102)
	XMLUtil.checkDeprecatedXMLElements(p98.xmlFile, p100 .. "#index", p100 .. "#node")
	XMLUtil.checkDeprecatedXMLElements(p98.xmlFile, p100 .. "#particleIndex", p100 .. "#particleNode")
	p101.particleSystem = {}
	local v103 = p99:getValue(p100 .. "#node", nil, p98.components, p98.i3dMappings)
	if v103 == nil then
		Logging.xmlWarning(p98.xmlFile, "Invalid node \'%s\' for \'%s\'", p99:getValue(p100 .. "#node"), p100)
		return false
	end
	local v104 = p99:getValue(p100 .. "#refNodeIndex")
	if v104 == nil or p98:getGroundReferenceNodeFromIndex(v104) == nil then
		Logging.xmlWarning(p98.xmlFile, "Invalid refNodeIndex \'%s\' for \'%s\'", p99:getValue(p100 .. "#refNodeIndex"), p100)
		return false
	end
	local v105 = p99:getValue(p100 .. "#particleNode")
	local v106
	if v105 == nil then
		local v107 = p99:getValue(p100 .. "#particleType")
		if v107 == nil then
			Logging.xmlWarning(p98.xmlFile, "Missing particleType in \'%s\'", p100)
			return false
		end
		local v108 = p99:getValue(p100 .. "#fillType")
		local v109 = Utils.getNoNil(g_fillTypeManager:getFillTypeIndexByName(v108), FillType.UNKNOWN)
		local v110 = g_particleSystemManager:getParticleSystem(v107)
		if v110 == nil then
			return false
		end
		if v109 ~= FillType.UNKNOWN then
			local v111 = g_materialManager:getParticleMaterial(v109, v107, 1)
			if v111 ~= nil then
				ParticleUtil.setMaterial(v110, v111)
			end
		end
		p101.particleSystem = ParticleUtil.copyParticleSystem(p99, p100, v110, v103)
		v106 = v103
	else
		v106 = I3DUtil.indexToObject(p102, v105, p98.i3dMappings)
		if v106 == nil then
			Logging.xmlWarning(p98.xmlFile, "Invalid particle node \'%s\' \'%s\'", p99:getValue(p100 .. "#particleNode"), p100)
			return false
		end
	end
	p101.node = v103
	p101.particleNode = v106
	p101.groundRefNode = p98:getGroundReferenceNodeFromIndex(v104)
	p101.speedThreshold = p99:getValue(p100 .. "#speedThreshold", 0.5)
	p101.movingDirection = p99:getValue(p100 .. "#movingDirection")
	return true
end
function WorkParticles.loadGroundEffects(p112, p113, p114, p115, _)
	p115.speedThreshold = p113:getValue(p114 .. "#speedThreshold", 0.5)
	p115.activeDirection = p113:getValue(p114 .. "#activeDirection", 1)
	p115.workAreaIndex = p113:getValue(p114 .. "#workAreaIndex")
	p115.groundReferenceNodeIndex = p113:getValue(p114 .. "#groundReferenceNodeIndex")
	p115.needsSetIsTurnedOn = p113:getValue(p114 .. "#needsSetIsTurnedOn", false)
	p115.effect = g_effectManager:loadEffect(p113, p114, p112.components, p112, p112.i3dMappings)
	return true
end
function WorkParticles.getFillTypeFromWorkAreaIndex(p116, p117)
	local v118 = FillType.UNKNOWN
	local v119 = p116:getWorkAreaByIndex(p117)
	if v119 ~= nil then
		if v119.fillType ~= nil then
			return v119.fillType
		end
		if v119.fruitType ~= nil then
			v118 = g_fruitTypeManager:getFruitTypeIndexByFillTypeIndex(v119.fruitType)
		end
	end
	return v118
end
function WorkParticles.loadGroundReferenceNode(p120, p121, p122, p123, p124)
	local v125 = p121(p120, p122, p123, p124)
	if v125 then
		p124.depthNode = p122:getValue(p123 .. "#depthNode", nil, p120.components, p120.i3dMappings)
		p124.movedDistance = 0
		p124.depth = 0
		p124.movingDirection = 0
	end
	return v125
end
function WorkParticles.updateGroundReferenceNode(p126, p127, p128, p129, p130, p131, p132, p133)
	p127(p126, p128, p129, p130, p131, p132, p133)
	if p126.isClient and p128.depthNode ~= nil then
		local v134, v135, v136 = getWorldTranslation(p128.depthNode)
		if p128.lastPosition == nil then
			p128.lastPosition = { v134, v135, v136 }
		end
		local v137, v138, v139 = worldDirectionToLocal(p128.depthNode, v134 - p128.lastPosition[1], v135 - p128.lastPosition[2], v136 - p128.lastPosition[3])
		p128.movingDirection = 0
		if v139 > 0.0001 then
			p128.movingDirection = 1
		elseif v139 < -0.0001 then
			p128.movingDirection = -1
		end
		p128.movedDistance = MathUtil.vector3Length(v137, v138, v139)
		local v140 = p128.lastPosition
		local v141 = p128.lastPosition
		local v142 = p128.lastPosition
		v140[1] = v134
		v141[2] = v135
		v142[3] = v136
		p128.depth = v135 - getTerrainHeightAtWorldPos(g_terrainNode, v134, v135, v136)
	end
end
function WorkParticles.onDeactivate(p143)
	local v144 = p143.spec_workParticles
	for _, v145 in pairs(v144.particles) do
		for _, v146 in ipairs(v145.mappings) do
			ParticleUtil.setEmittingState(v146.particleSystem, false)
		end
	end
	for _, v147 in ipairs(v144.particleAnimations) do
		for _, v148 in ipairs(v147.mappings) do
			setVisibility(v148.animNode, false)
		end
	end
end

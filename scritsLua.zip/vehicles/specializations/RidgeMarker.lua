source("dataS/scripts/vehicles/specializations/events/RidgeMarkerSetStateEvent.lua")
RidgeMarker = {}
RidgeMarker.SEND_NUM_BITS = 3
RidgeMarker.MAX_NUM_RIDGEMARKERS = 2 ^ RidgeMarker.SEND_NUM_BITS
function RidgeMarker.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("ridgeMarker", g_i18n:getText("configuration_ridgeMarker"), "ridgeMarker", VehicleConfigurationItem)
	g_workAreaTypeManager:addWorkAreaType("ridgemarker", false, false, false)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("RidgeMarker")
	RidgeMarker.registerRidgeMarkerXMLPaths(v1, "vehicle.ridgeMarker")
	RidgeMarker.registerRidgeMarkerXMLPaths(v1, "vehicle.ridgeMarker.ridgeMarkerConfigurations.ridgeMarkerConfiguration(?)")
	RidgeMarker.registerRidgeMarkerAreaXMLPaths(v1, WorkArea.WORK_AREA_XML_KEY)
	RidgeMarker.registerRidgeMarkerAreaXMLPaths(v1, WorkArea.WORK_AREA_XML_CONFIG_KEY)
	v1:register(XMLValueType.STRING, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#ridgeMarkerAnim", "Ridge marker animation")
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#ridgeMarkerAnimTimeMax", "Animation max. time for activation", 0.99)
	v1:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.INT, "vehicles.vehicle(?).ridgeMarker#state", "Ridge marker state")
end
function RidgeMarker.registerRidgeMarkerXMLPaths(p2, p3)
	p2:register(XMLValueType.STRING, p3 .. "#inputButton", "Input action name", "IMPLEMENT_EXTRA4")
	p2:register(XMLValueType.STRING, p3 .. ".marker(?)#animName", "Animation name")
	p2:register(XMLValueType.FLOAT, p3 .. ".marker(?)#minWorkLimit", "Min. work limit", 0.99)
	p2:register(XMLValueType.FLOAT, p3 .. ".marker(?)#maxWorkLimit", "Max. work limit", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".marker(?)#liftedAnimTime", "Lifted animation time")
	p2:register(XMLValueType.INT, p3 .. ".marker(?)#workAreaIndex", "Work area index")
	p2:register(XMLValueType.FLOAT, p3 .. "#foldMinLimit", "Fold min. limit", 0)
	p2:register(XMLValueType.FLOAT, p3 .. "#foldMaxLimit", "Fold max. limit", 1)
	p2:register(XMLValueType.INT, p3 .. "#foldDisableDirection", "Fold disable direction")
	p2:register(XMLValueType.BOOL, p3 .. "#onlyActiveWhenLowered", "Only active while lowered", true)
	p2:register(XMLValueType.NODE_INDEX, p3 .. "#directionNode", "Direction node")
end
function RidgeMarker.registerRidgeMarkerAreaXMLPaths(p4, p5)
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".ridgeMarkerArea#node", "Around this node the ridge marker areas are generated")
	p4:register(XMLValueType.FLOAT, p5 .. ".ridgeMarkerArea#size", "Width and length of area and test area", 0.25)
	p4:register(XMLValueType.FLOAT, p5 .. ".ridgeMarkerArea#testAreaOffset", "Offset of test area in positive z direction", 0.2)
end
function RidgeMarker.prerequisitesPresent(p6)
	local v7 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p6)
	if v7 then
		v7 = SpecializationUtil.hasSpecialization(WorkArea, p6)
	end
	return v7
end
function RidgeMarker.registerFunctions(p8)
	SpecializationUtil.registerFunction(p8, "loadRidgeMarker", RidgeMarker.loadRidgeMarker)
	SpecializationUtil.registerFunction(p8, "setRidgeMarkerState", RidgeMarker.setRidgeMarkerState)
	SpecializationUtil.registerFunction(p8, "canFoldRidgeMarker", RidgeMarker.canFoldRidgeMarker)
	SpecializationUtil.registerFunction(p8, "processRidgeMarkerArea", RidgeMarker.processRidgeMarkerArea)
end
function RidgeMarker.registerOverwrittenFunctions(p9)
	SpecializationUtil.registerOverwrittenFunction(p9, "loadWorkAreaFromXML", RidgeMarker.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsWorkAreaActive", RidgeMarker.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p9, "loadSpeedRotatingPartFromXML", RidgeMarker.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsSpeedRotatingPartActive", RidgeMarker.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p9, "getCanBeSelected", RidgeMarker.getCanBeSelected)
end
function RidgeMarker.registerEventListeners(p10)
	SpecializationUtil.registerEventListener(p10, "onLoad", RidgeMarker)
	SpecializationUtil.registerEventListener(p10, "onPostLoad", RidgeMarker)
	SpecializationUtil.registerEventListener(p10, "onReadStream", RidgeMarker)
	SpecializationUtil.registerEventListener(p10, "onWriteStream", RidgeMarker)
	SpecializationUtil.registerEventListener(p10, "onUpdateTick", RidgeMarker)
	SpecializationUtil.registerEventListener(p10, "onRegisterActionEvents", RidgeMarker)
	SpecializationUtil.registerEventListener(p10, "onSetLowered", RidgeMarker)
	SpecializationUtil.registerEventListener(p10, "onFoldStateChanged", RidgeMarker)
	SpecializationUtil.registerEventListener(p10, "onAIImplementStart", RidgeMarker)
end
function RidgeMarker.onLoad(p11, _)
	local v12 = p11.spec_ridgeMarker
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.ridgeMarkers", "vehicle.ridgeMarker")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.ridgeMarkers.ridgeMarker", "vehicle.ridgeMarker.marker")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.ridgeMarker.ridgeMarker", "vehicle.ridgeMarker.marker")
	local v13 = Utils.getNoNil(p11.configurations.ridgeMarker, 1)
	local v14 = string.format("vehicle.ridgeMarker.ridgeMarkerConfigurations.ridgeMarkerConfiguration(%d)", v13 - 1)
	local v15 = not p11.xmlFile:hasProperty(v14) and "vehicle.ridgeMarker" or v14
	local v16 = p11.xmlFile:getValue(v15 .. "#inputButton")
	if v16 ~= nil then
		v12.ridgeMarkerInputButton = InputAction[v16]
	end
	v12.ridgeMarkerInputButton = Utils.getNoNil(v12.ridgeMarkerInputButton, InputAction.IMPLEMENT_EXTRA4)
	v12.ridgeMarkers = {}
	v12.workAreaToRidgeMarker = {}
	local v17 = 0
	while true do
		local v18 = string.format("%s.marker(%d)", v15, v17)
		if not p11.xmlFile:hasProperty(v18) then
			break
		end
		if #v12.ridgeMarkers >= RidgeMarker.MAX_NUM_RIDGEMARKERS - 1 then
			Logging.xmlError(p11.xmlFile, "Too many ridgeMarker states. Only %d states are supported!", RidgeMarker.MAX_NUM_RIDGEMARKERS - 1)
			break
		end
		local v19 = {}
		if p11:loadRidgeMarker(p11.xmlFile, v18, v19) then
			local v20 = v12.ridgeMarkers
			table.insert(v20, v19)
			v12.workAreaToRidgeMarker[v19.workAreaIndex] = v19
		end
		v17 = v17 + 1
	end
	v12.numRigdeMarkers = #v12.ridgeMarkers
	v12.ridgeMarkerMinFoldTime = p11.xmlFile:getValue(v15 .. "#foldMinLimit", 0)
	v12.ridgeMarkerMaxFoldTime = p11.xmlFile:getValue(v15 .. "#foldMaxLimit", 1)
	v12.foldDisableDirection = p11.xmlFile:getValue(v15 .. "#foldDisableDirection")
	v12.onlyActiveWhenLowered = p11.xmlFile:getValue(v15 .. "#onlyActiveWhenLowered", true)
	v12.ridgeMarkerState = 0
	v12.directionNode = p11.xmlFile:getValue(v15 .. "#directionNode", nil, p11.components, p11.i3dMappings)
	if not p11.isClient then
		SpecializationUtil.removeEventListener(p11, "onUpdateTick", RidgeMarker)
	end
end
function RidgeMarker.onPostLoad(p21, p22)
	local v23 = p21.spec_ridgeMarker
	if v23.numRigdeMarkers > 0 and p22 ~= nil then
		local v24 = p22.xmlFile:getValue(p22.key .. ".ridgeMarker#state")
		if v24 ~= nil then
			p21:setRidgeMarkerState(v24, true)
			if v24 ~= 0 then
				AnimatedVehicle.updateAnimationByName(p21, v23.ridgeMarkers[v24].animName, 9999999, true)
			end
		end
	end
end
function RidgeMarker.saveToXMLFile(p25, p26, p27, _)
	local v28 = p25.spec_ridgeMarker
	if v28.numRigdeMarkers > 0 then
		p26:setValue(p27 .. "#state", v28.ridgeMarkerState)
	end
end
function RidgeMarker.onReadStream(p29, p30, _)
	local v31 = p29.spec_ridgeMarker
	if v31.numRigdeMarkers > 0 then
		local v32 = streamReadUIntN(p30, RidgeMarker.SEND_NUM_BITS)
		p29:setRidgeMarkerState(v32, true)
		if v32 ~= 0 then
			AnimatedVehicle.updateAnimationByName(p29, v31.ridgeMarkers[v32].animName, 9999999, true)
		end
	end
end
function RidgeMarker.onWriteStream(p33, p34, _)
	local v35 = p33.spec_ridgeMarker
	if v35.numRigdeMarkers > 0 then
		streamWriteUIntN(p34, v35.ridgeMarkerState, RidgeMarker.SEND_NUM_BITS)
	end
end
function RidgeMarker.onUpdateTick(p36, _, _, _, _)
	RidgeMarker.updateActionEvents(p36)
end
function RidgeMarker.loadRidgeMarker(p37, p38, p39, p40)
	p40.animName = p38:getValue(p39 .. "#animName")
	p40.minWorkLimit = p38:getValue(p39 .. "#minWorkLimit", 0.99)
	p40.maxWorkLimit = p38:getValue(p39 .. "#maxWorkLimit", 1)
	p40.liftedAnimTime = p38:getValue(p39 .. "#liftedAnimTime")
	p40.workAreaIndex = p38:getValue(p39 .. "#workAreaIndex")
	if p40.workAreaIndex ~= nil then
		return true
	end
	Logging.xmlWarning(p37.xmlFile, "Missing \'workAreaIndex\' for ridgeMarker \'%s\'!", p39)
	return false
end
function RidgeMarker.setRidgeMarkerState(p41, p42, p43)
	local v44 = p41.spec_ridgeMarker
	if v44.ridgeMarkerState ~= p42 then
		RidgeMarkerSetStateEvent.sendEvent(p41, p42, p43)
		if v44.ridgeMarkerState ~= 0 then
			local v45 = p41:getAnimationTime(v44.ridgeMarkers[v44.ridgeMarkerState].animName)
			p41:playAnimation(v44.ridgeMarkers[v44.ridgeMarkerState].animName, -1, v45, true)
		end
		v44.ridgeMarkerState = p42
		if v44.ridgeMarkerState ~= 0 then
			if v44.ridgeMarkers[v44.ridgeMarkerState].liftedAnimTime ~= nil and not p41:getIsLowered(true) then
				p41:setAnimationStopTime(v44.ridgeMarkers[v44.ridgeMarkerState].animName, v44.ridgeMarkers[v44.ridgeMarkerState].liftedAnimTime)
			end
			local v46 = p41:getAnimationTime(v44.ridgeMarkers[v44.ridgeMarkerState].animName)
			p41:playAnimation(v44.ridgeMarkers[v44.ridgeMarkerState].animName, 1, v46, true)
		end
	end
end
function RidgeMarker.canFoldRidgeMarker(p47, p48)
	local v49 = p47.spec_ridgeMarker
	if p47.getFoldAnimTime ~= nil then
		local v50 = p47:getFoldAnimTime()
		if v50 < v49.ridgeMarkerMinFoldTime or v49.ridgeMarkerMaxFoldTime < v50 then
			return false
		end
	end
	local v51 = p47.spec_foldable
	return (p48 == 0 or (v51.moveToMiddle or (v49.foldDisableDirection == nil or v49.foldDisableDirection ~= v51.foldMoveDirection and v51.foldMoveDirection ~= 0))) and true or false
end
function RidgeMarker.processRidgeMarkerArea(p52, p53, _)
	local v54 = p52.spec_ridgeMarker
	local v55 = g_currentMission
	local v56, v57, v58 = v55.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
	local v59 = getDensityAtWorldPos(v56, getWorldTranslation(p53.testNode))
	local v60 = bitAND(bitShiftRight(v59, v57), 2 ^ v58 - 1)
	local v61 = FieldGroundType.getTypeByValue(v60)
	if v61 ~= FieldGroundType.NONE then
		local v62, _, v63 = getWorldTranslation(p53.start)
		local v64, _, v65 = getWorldTranslation(p53.width)
		local v66, _, v67 = getWorldTranslation(p53.height)
		local v68 = v64 - v62
		local v69 = v65 - v63
		local v70 = v66 - v62
		local v71 = v67 - v63
		local v72 = v55.terrainDetailMapSize / v55.terrainSize
		local v73 = v62 * v72 + 0.5
		local v74 = math.floor(v73) / v72
		local v75 = v63 * v72 + 0.5
		local v76 = math.floor(v75) / v72
		local v77 = v74 + v68
		local v78 = v76 + v69
		local v79 = v74 + v70
		local v80 = v76 + v71
		local v81, _, v82 = localDirectionToWorld(v54.directionNode or p52.rootNode, 0, 0, 1)
		local v83 = FSDensityMapUtil.convertToDensityMapAngle(MathUtil.getYRotationFromDirection(v81, v82), v55.fieldGroundSystem:getGroundAngleMaxValue())
		if v61 == FieldGroundType.PLOWED then
			FSDensityMapUtil.updateCultivatorArea(v74, v76, v77, v78, v79, v80, false, true, v83, nil, nil, true)
		else
			FSDensityMapUtil.updatePlowArea(v74, v76, v77, v78, v79, v80, false, true, v83, false, true)
		end
		FSDensityMapUtil.eraseTireTrack(v74, v76, v77, v78, v79, v80)
	end
	return 0, 0
end
function RidgeMarker.loadWorkAreaFromXML(p84, p85, p86, p87, p88)
	local v89 = p87:getValue(p88 .. ".ridgeMarkerArea#node", nil, p84.components, p84.i3dMappings)
	local v90 = p87:getValue(p88 .. ".ridgeMarkerArea#size", 0.25) * 0.5
	local v91 = p87:getValue(p88 .. ".ridgeMarkerArea#testAreaOffset", 0.2)
	if v89 ~= nil then
		p86.start = createTransformGroup("ridgeMarkerAreaStart")
		link(v89, p86.start)
		setTranslation(p86.start, v90, 0, v90)
		p86.width = createTransformGroup("ridgeMarkerAreaWidth")
		link(v89, p86.width)
		setTranslation(p86.width, -v90, 0, v90)
		p86.height = createTransformGroup("ridgeMarkerAreaHeight")
		link(v89, p86.height)
		setTranslation(p86.height, v90, 0, -v90)
		local v92 = v91 + 2 * v90
		p86.testNode = createTransformGroup("ridgeMarkerTestNode")
		link(v89, p86.testNode)
		setTranslation(p86.testNode, 0, 0, v90 + v92)
	end
	if not p85(p84, p86, p87, p88) then
		return false
	end
	if p86.type == WorkAreaType.RIDGEMARKER then
		XMLUtil.checkDeprecatedXMLElements(p84.xmlFile, p88 .. ".testArea#startNode", p88 .. ".ridgeMarkerArea#node")
		XMLUtil.checkDeprecatedXMLElements(p84.xmlFile, p88 .. ".testArea#widthNode", p88 .. ".ridgeMarkerArea#node")
		XMLUtil.checkDeprecatedXMLElements(p84.xmlFile, p88 .. ".testArea#heightNode", p88 .. ".ridgeMarkerArea#node")
	end
	if v89 == nil then
		if p86.type == WorkAreaType.RIDGEMARKER then
			Logging.xmlWarning(p84.xmlFile, "Missing ridge marker node for ridge marker area \'%s\'", p88)
		end
	elseif p86.type == WorkAreaType.DEFAULT then
		p86.type = WorkAreaType.RIDGEMARKER
	end
	return true
end
function RidgeMarker.loadSpeedRotatingPartFromXML(p93, p94, p95, p96, p97)
	if not p94(p93, p95, p96, p97) then
		return false
	end
	p95.ridgeMarkerAnim = p96:getValue(p97 .. "#ridgeMarkerAnim")
	p95.ridgeMarkerAnimTimeMax = p96:getValue(p97 .. "#ridgeMarkerAnimTimeMax", 0.99)
	return true
end
function RidgeMarker.getIsSpeedRotatingPartActive(p98, p99, p100)
	if p100.ridgeMarkerAnim == nil or p98:getAnimationTime(p100.ridgeMarkerAnim) >= p100.ridgeMarkerAnimTimeMax then
		return p99(p98, p100)
	else
		return false
	end
end
function RidgeMarker.getCanBeSelected(_, _)
	return true
end
function RidgeMarker.getIsWorkAreaActive(p101, p102, p103)
	if p103.type == WorkAreaType.RIDGEMARKER then
		local v104 = p101.spec_ridgeMarker
		if v104.numRigdeMarkers == 0 then
			return false
		end
		local v105 = v104.workAreaToRidgeMarker[p103.index]
		if v105 ~= nil then
			local v106 = p101:getAnimationTime(v105.animName)
			if v105.maxWorkLimit < v106 or v106 < v105.minWorkLimit then
				return false
			end
			if v104.onlyActiveWhenLowered and not p101:getIsLowered(false) then
				return false
			end
		end
	end
	return p102(p101, p103)
end
function RidgeMarker.onRegisterActionEvents(p107, _, p108)
	if p107.isClient then
		local v109 = p107.spec_ridgeMarker
		p107:clearActionEventsTable(v109.actionEvents)
		if p108 and v109.numRigdeMarkers > 0 then
			local _, v110 = p107:addPoweredActionEvent(v109.actionEvents, v109.ridgeMarkerInputButton, p107, RidgeMarker.actionEventToggleRidgeMarkers, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v110, GS_PRIO_NORMAL)
			g_inputBinding:setActionEventText(v110, g_i18n:getText("action_toggleRidgeMarker"))
		end
	end
end
function RidgeMarker.onSetLowered(p111, p112)
	local v113 = p111.spec_ridgeMarker
	if p112 then
		for _, v114 in pairs(v113.ridgeMarkers) do
			if v114.liftedAnimTime ~= nil then
				local v115 = p111:getAnimationTime(v114.animName)
				if v115 == v114.liftedAnimTime then
					p111:playAnimation(v114.animName, 1, v115, true)
				end
			end
		end
	else
		for _, v116 in pairs(v113.ridgeMarkers) do
			if v116.liftedAnimTime ~= nil then
				local v117 = p111:getAnimationTime(v116.animName)
				if v116.liftedAnimTime < v117 then
					p111:setAnimationStopTime(v116.animName, v116.liftedAnimTime)
					p111:playAnimation(v116.animName, -1, v117, true)
				end
			end
		end
	end
end
function RidgeMarker.onFoldStateChanged(p118, p119, p120)
	if not p120 and p119 > 0 then
		p118:setRidgeMarkerState(0, true)
	end
end
function RidgeMarker.onAIImplementStart(p121)
	p121:setRidgeMarkerState(0, true)
end
function RidgeMarker.actionEventToggleRidgeMarkers(p122, _, _, _, _)
	local v123 = p122.spec_ridgeMarker
	local v124 = (v123.ridgeMarkerState + 1) % (v123.numRigdeMarkers + 1)
	if p122:canFoldRidgeMarker(v124) then
		p122:setRidgeMarkerState(v124)
	end
end
function RidgeMarker.updateActionEvents(p125)
	local v126 = p125.spec_ridgeMarker
	local v127 = v126.actionEvents[v126.ridgeMarkerInputButton]
	if v127 ~= nil then
		local v128 = v126.numRigdeMarkers > 0 and p125:canFoldRidgeMarker((v126.ridgeMarkerState + 1) % (v126.numRigdeMarkers + 1)) and true or false
		g_inputBinding:setActionEventActive(v127.actionEventId, v128)
	end
end

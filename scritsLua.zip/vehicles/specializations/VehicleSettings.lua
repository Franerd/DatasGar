source("dataS/scripts/vehicles/specializations/events/VehicleSettingsChangeEvent.lua")
VehicleSettings = {}
function VehicleSettings.prerequisitesPresent(_)
	return true
end
function VehicleSettings.initSpecialization() end
function VehicleSettings.registerFunctions(p1)
	SpecializationUtil.registerFunction(p1, "registerVehicleSetting", VehicleSettings.registerVehicleSetting)
	SpecializationUtil.registerFunction(p1, "setVehicleSettingState", VehicleSettings.setVehicleSettingState)
	SpecializationUtil.registerFunction(p1, "forceVehicleSettingsUpdate", VehicleSettings.forceVehicleSettingsUpdate)
end
function VehicleSettings.registerEvents(p2)
	SpecializationUtil.registerEvent(p2, "onVehicleSettingChanged")
end
function VehicleSettings.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onPreLoad", VehicleSettings)
	SpecializationUtil.registerEventListener(p3, "onUpdateTick", VehicleSettings)
	SpecializationUtil.registerEventListener(p3, "onStateChange", VehicleSettings)
	SpecializationUtil.registerEventListener(p3, "onPreAttach", VehicleSettings)
end
function VehicleSettings.onPreLoad(p4, _)
	local v5 = p4.spec_vehicleSettings
	v5.isDirty = false
	v5.settings = {}
	if p4.isServer then
		SpecializationUtil.removeEventListener(p4, "onUpdateTick", VehicleSettings)
	end
end
function VehicleSettings.onUpdateTick(p6, _, _, _, _)
	local v7 = p6.spec_vehicleSettings
	if v7.isDirty then
		local v8 = false
		for v9 = 1, #v7.settings do
			if v7.settings[v9].isDirty then
				v8 = true
				break
			end
		end
		if v8 and (g_server == nil and g_client ~= nil) then
			g_client:getServerConnection():sendEvent(VehicleSettingsChangeEvent.new(p6, v7.settings))
		end
		v7.isDirty = false
	end
end
function VehicleSettings.registerVehicleSetting(p_u_10, p11, p12)
	local v13 = p_u_10.spec_vehicleSettings
	local v_u_15 = {
		["index"] = #v13.settings + 1,
		["gameSettingId"] = p11,
		["isBool"] = p12,
		["callback"] = function(_, p14)
			-- upvalues: (copy) p_u_10, (copy) v_u_15
			if p_u_10:getIsActiveForInput(true, true) then
				p_u_10:setVehicleSettingState(v_u_15.index, p14)
			end
		end
	}
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[p11], v_u_15.callback, p_u_10)
	local v16 = v13.settings
	table.insert(v16, v_u_15)
end
function VehicleSettings.forceVehicleSettingsUpdate(p17)
	local v18 = p17.spec_vehicleSettings
	for v19 = 1, #v18.settings do
		local v20 = v18.settings[v19]
		p17:setVehicleSettingState(v20.index, g_gameSettings:getValue(v20.gameSettingId), true)
	end
end
function VehicleSettings.setVehicleSettingState(p21, p22, p23, p24)
	local v25 = p21.spec_vehicleSettings
	local v26 = v25.settings[p22]
	if v26 ~= nil then
		if (p24 == nil or p24 == false) and (g_server == nil and g_client ~= nil) then
			g_client:getServerConnection():sendEvent(VehicleSettingsChangeEvent.new(p21, v25.settings))
		end
		v26.state = p23
		v26.isDirty = true
		v25.isDirty = true
		SpecializationUtil.raiseEvent(p21, "onVehicleSettingChanged", v26.gameSettingId, p23)
	end
end
function VehicleSettings.onStateChange(p27, p28, _, p29)
	if p29 and p28 == VehicleStateChange.ENTER_VEHICLE then
		p27:forceVehicleSettingsUpdate()
	end
end
function VehicleSettings.onPreAttach(p30, _, _, _)
	p30:forceVehicleSettingsUpdate()
end

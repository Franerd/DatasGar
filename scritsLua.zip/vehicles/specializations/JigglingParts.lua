JigglingParts = {}
JigglingParts.JIGGLING_PART_XML_KEY = "vehicle.jigglingParts.jigglingPart(?)"
function JigglingParts.prerequisitesPresent(_)
	return true
end
function JigglingParts.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("JigglingParts")
	local v2 = JigglingParts.JIGGLING_PART_XML_KEY
	v1:register(XMLValueType.NODE_INDEX, v2 .. "#node", "Jiggling node")
	v1:register(XMLValueType.FLOAT, v2 .. "#speedScale", "Speed scale", 1)
	v1:register(XMLValueType.STRING, v2 .. "#shaderParameter", "Shader parameter", "amplFreq")
	v1:register(XMLValueType.STRING, v2 .. "#shaderParameterPrev", "Shader parameter previous frame", "prevAmplFreq")
	v1:register(XMLValueType.INT, v2 .. "#shaderParameterComponentSpeed", "Shader component speed index", 4)
	v1:register(XMLValueType.INT, v2 .. "#shaderParameterComponentAmplitude", "Shader component amplitude index", 1)
	v1:register(XMLValueType.FLOAT, v2 .. "#amplitudeScale", "Amplitude scale", 4)
	v1:register(XMLValueType.INT, v2 .. "#refNodeIndex", "Ground reference node index")
	v1:setXMLSpecializationType()
end
function JigglingParts.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "loadJigglingPartsFromXML", JigglingParts.loadJigglingPartsFromXML)
	SpecializationUtil.registerFunction(p3, "isJigglingPartActive", JigglingParts.isJigglingPartActive)
	SpecializationUtil.registerFunction(p3, "updateJigglingPart", JigglingParts.updateJigglingPart)
end
function JigglingParts.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", JigglingParts)
	SpecializationUtil.registerEventListener(p4, "onUpdate", JigglingParts)
end
function JigglingParts.onLoad(p5, _)
	local v6 = p5.spec_jigglingParts
	v6.parts = {}
	local v7 = 0
	while true do
		local v8 = string.format("vehicle.jigglingParts.jigglingPart(%d)", v7)
		if not p5.xmlFile:hasProperty(v8) then
			break
		end
		local v9 = {}
		if p5:loadJigglingPartsFromXML(v9, p5.xmlFile, v8) then
			local v10 = v6.parts
			table.insert(v10, v9)
		end
		v7 = v7 + 1
	end
	if #v6.parts == 0 then
		SpecializationUtil.removeEventListener(p5, "onUpdate", JigglingParts)
	end
end
function JigglingParts.onUpdate(p11, p12, _, _, _)
	local v13 = p11.spec_jigglingParts
	for _, v14 in ipairs(v13.parts) do
		if p11:isJigglingPartActive(v14) then
			p11:updateJigglingPart(v14, p12, true)
		elseif v14.currentAmplitudeScale > 0 then
			p11:updateJigglingPart(v14, p12, false)
		end
	end
end
function JigglingParts.loadJigglingPartsFromXML(p15, p16, p17, p18)
	XMLUtil.checkDeprecatedXMLElements(p17, p18 .. "#index", p18 .. "#node")
	p16.currentTime = 0
	p16.currentAmplitudeScale = 0
	p16.node = p17:getValue(p18 .. "#node", nil, p15.components, p15.i3dMappings)
	if p16.node == nil then
		Logging.xmlWarning(p15.xmlFile, "Failed to load node for jiggling part \'%s\'", p18)
		return false
	end
	p16.speedScale = p17:getValue(p18 .. "#speedScale", 1)
	p16.shaderParameter = p17:getValue(p18 .. "#shaderParameter", "amplFreq")
	p16.shaderParameterPrev = p17:getValue(p18 .. "#shaderParameterPrev", "prevAmplFreq")
	p16.shaderParameterComponentSpeed = p17:getValue(p18 .. "#shaderParameterComponentSpeed", 4)
	p16.shaderParameterComponentAmplitude = p17:getValue(p18 .. "#shaderParameterComponentAmplitude", 1)
	p16.amplitudeScale = p17:getValue(p18 .. "#amplitudeScale", 4)
	p16.refNodeIndex = p17:getValue(p18 .. "#refNodeIndex")
	p16.values = {
		0,
		0,
		0,
		0
	}
	return true
end
function JigglingParts.isJigglingPartActive(p19, p20)
	if p20.refNodeIndex ~= nil and p20.refNode == nil then
		if p19.getGroundReferenceNodeFromIndex ~= nil then
			local v21 = p19:getGroundReferenceNodeFromIndex(p20.refNodeIndex)
			if v21 ~= nil then
				p20.refNode = v21
			end
		end
		if p20.refNode == nil then
			Logging.xmlWarning(p19.xmlFile, "Unable to find ground reference node \'%d\' for jiggling part \'%s\'", p20.refNodeIndex, getName(p20.node))
		end
		p20.refNodeIndex = nil
	end
	return (p20.refNode == nil or p19:getIsGroundReferenceNodeActive(p20.refNode)) and true or false
end
function JigglingParts.updateJigglingPart(p22, p23, p24, p25)
	local v26 = p23.values[1]
	local v27 = p23.values[2]
	local v28 = p23.values[3]
	local v29 = p23.values[4]
	local v30, v31, v32, v33 = getShaderParameter(p23.node, p23.shaderParameter)
	local v34 = p23.values
	local v35 = p23.values
	local v36 = p23.values
	local v37 = p23.values
	v34[1] = v30
	v35[2] = v31
	v36[3] = v32
	v37[4] = v33
	local v38 = p24 / 1000 * p23.speedScale * p22:getLastSpeed() / 20
	p23.currentTime = p23.currentTime + v38
	p23.values[p23.shaderParameterComponentSpeed] = p23.currentTime
	if p25 and p23.currentAmplitudeScale < 1 then
		local v39 = p23.currentAmplitudeScale + p24 / 100
		p23.currentAmplitudeScale = math.min(v39, 1)
	elseif not p25 and p23.currentAmplitudeScale > 0 then
		local v40 = p23.currentAmplitudeScale - p24 / 100
		p23.currentAmplitudeScale = math.max(v40, 0)
	end
	p23.values[p23.shaderParameterComponentAmplitude] = p23.currentAmplitudeScale * p23.amplitudeScale
	setShaderParameter(p23.node, p23.shaderParameter, p23.values[1], p23.values[2], p23.values[3], p23.values[4], false)
	setShaderParameter(p23.node, p23.shaderParameterPrev, v26, v27, v28, v29, false)
end

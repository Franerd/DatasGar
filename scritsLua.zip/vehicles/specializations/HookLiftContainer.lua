HookLiftContainer = {}
function HookLiftContainer.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Attachable, p1)
	end
	return v2
end
function HookLiftContainer.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("HookLiftContainer")
	v3:register(XMLValueType.BOOL, "vehicle.hookLiftContainer#tiltContainerOnDischarge", "Tilt container on discharge", true)
	v3:setXMLSpecializationType()
end
function HookLiftContainer.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanDischargeToObject", HookLiftContainer.getCanDischargeToObject)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanDischargeToGround", HookLiftContainer.getCanDischargeToGround)
	SpecializationUtil.registerOverwrittenFunction(p4, "isDetachAllowed", HookLiftContainer.isDetachAllowed)
end
function HookLiftContainer.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", HookLiftContainer)
	SpecializationUtil.registerEventListener(p5, "onStartTipping", HookLiftContainer)
	SpecializationUtil.registerEventListener(p5, "onStopTipping", HookLiftContainer)
end
function HookLiftContainer.onLoad(p6, _)
	p6.spec_hookLiftContainer.tiltContainerOnDischarge = p6.xmlFile:getValue("vehicle.hookLiftContainer#tiltContainerOnDischarge", true)
end
function HookLiftContainer.getCanDischargeToObject(p7, p8, p9)
	local v10 = p7:getAttacherVehicle()
	if v10 == nil or (v10.getIsTippingAllowed == nil or v10:getIsTippingAllowed()) then
		return p8(p7, p9)
	else
		return false
	end
end
function HookLiftContainer.getCanDischargeToGround(p11, p12, p13)
	local v14 = p11:getAttacherVehicle()
	if v14 == nil or (v14.getIsTippingAllowed == nil or v14:getIsTippingAllowed()) then
		return p12(p11, p13)
	else
		return false
	end
end
function HookLiftContainer.isDetachAllowed(p15, p16)
	local v17 = p15:getAttacherVehicle()
	if v17 == nil or (v17.getCanDetachContainer == nil or v17:getCanDetachContainer()) then
		return p16(p15)
	else
		return false, nil
	end
end
function HookLiftContainer.onStartTipping(p18, _)
	local v19 = p18.spec_hookLiftContainer
	local v20 = p18:getAttacherVehicle()
	if v20 ~= nil and (v20.startTipping ~= nil and v19.tiltContainerOnDischarge) then
		v20:startTipping()
	end
end
function HookLiftContainer.onStopTipping(p21)
	local v22 = p21.spec_hookLiftContainer
	local v23 = p21:getAttacherVehicle()
	if v23 ~= nil and (v23.stopTipping ~= nil and v22.tiltContainerOnDischarge) then
		v23:stopTipping()
	end
end

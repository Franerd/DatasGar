source("dataS/scripts/vehicles/specializations/events/ReverseDrivingSetStateEvent.lua")
ReverseDriving = {}
function ReverseDriving.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Drivable, p1) and SpecializationUtil.hasSpecialization(Enterable, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	end
	return v2
end
function ReverseDriving.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("ReverseDriving")
	IKUtil.registerIKChainTargetsXMLPaths(v3, "vehicle.reverseDriving")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.reverseDriving.steeringWheel#node", "Spawn place node")
	v3:register(XMLValueType.ANGLE, "vehicle.reverseDriving.steeringWheel#indoorRotation", "Indoor rotation", "vehicle.drivable.steeringWheel#indoorRotation")
	v3:register(XMLValueType.ANGLE, "vehicle.reverseDriving.steeringWheel#outdoorRotation", "Outdoor rotation", "vehicle.drivable.steeringWheel#outdoorRotation")
	v3:register(XMLValueType.STRING, "vehicle.reverseDriving#animationName", "Animation name", "reverseDriving")
	v3:register(XMLValueType.BOOL, "vehicle.reverseDriving#hideCharacterOnChange", "Hide the character while changing the direction", true)
	v3:register(XMLValueType.BOOL, "vehicle.reverseDriving#inverseTransmission", "Inverse the transmission gear ratio when direction has changed", false)
	v3:register(XMLValueType.BOOL, "vehicle.reverseDriving#initialInversed", "Vehicle is in reverse driving state directly after loading", false)
	v3:register(XMLValueType.VECTOR_N, "vehicle.reverseDriving#disablingAttacherJointIndices", "Attacher joint indices which are disabling the reverse driving")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.reverseDriving.ai#steeringNode", "Steering Node while in reverse driving mode")
	AIImplement.registerAICollisionTriggerXMLPaths(v3, "vehicle.reverseDriving.ai")
	v3:register(XMLValueType.BOOL, Dashboard.GROUP_XML_KEY .. "#isReverseDriving", "Is Reverse driving")
	for v4 = 1, #Lights.ADDITIONAL_LIGHT_ATTRIBUTES_KEYS do
		local v5 = Lights.ADDITIONAL_LIGHT_ATTRIBUTES_KEYS[v4]
		v3:register(XMLValueType.INT, v5 .. "#enableDirection", "Light is enabled when driving into this direction [-1, 1]")
	end
	v3:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.BOOL, "vehicles.vehicle(?).reverseDriving#isActive", "Reverse driving is active")
end
function ReverseDriving.postInitSpecialization()
	local v6 = Vehicle.xmlSchema
	for _, v7 in pairs(g_vehicleConfigurationManager:getConfigurations()) do
		local v8 = v7.configurationKey .. "(?)"
		v6:setXMLSharedRegistration("configReverseDriving", v8)
		v6:register(XMLValueType.BOOL, v8 .. ".reverseDriving#isAllowed", "Reverse driving is allowed while this configuration is equipped", true)
		v6:resetXMLSharedRegistration("configReverseDriving", v8)
	end
end
function ReverseDriving.registerEvents(p9)
	SpecializationUtil.registerEvent(p9, "onStartReverseDirectionChange")
	SpecializationUtil.registerEvent(p9, "onReverseDirectionChanged")
end
function ReverseDriving.registerFunctions(p10)
	SpecializationUtil.registerFunction(p10, "reverseDirectionChanged", ReverseDriving.reverseDirectionChanged)
	SpecializationUtil.registerFunction(p10, "setIsReverseDriving", ReverseDriving.setIsReverseDriving)
	SpecializationUtil.registerFunction(p10, "getIsReverseDrivingAllowed", ReverseDriving.getIsReverseDrivingAllowed)
end
function ReverseDriving.registerOverwrittenFunctions(p11)
	SpecializationUtil.registerOverwrittenFunction(p11, "updateSteeringWheel", ReverseDriving.updateSteeringWheel)
	SpecializationUtil.registerOverwrittenFunction(p11, "getSteeringDirection", ReverseDriving.getSteeringDirection)
	SpecializationUtil.registerOverwrittenFunction(p11, "getAllowCharacterVisibilityUpdate", ReverseDriving.getAllowCharacterVisibilityUpdate)
	SpecializationUtil.registerOverwrittenFunction(p11, "getCanStartAIVehicle", ReverseDriving.getCanStartAIVehicle)
	SpecializationUtil.registerOverwrittenFunction(p11, "loadDashboardGroupFromXML", ReverseDriving.loadDashboardGroupFromXML)
	SpecializationUtil.registerOverwrittenFunction(p11, "getIsDashboardGroupActive", ReverseDriving.getIsDashboardGroupActive)
	SpecializationUtil.registerOverwrittenFunction(p11, "getCanBeSelected", ReverseDriving.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p11, "loadAdditionalLightAttributesFromXML", ReverseDriving.loadAdditionalLightAttributesFromXML)
	SpecializationUtil.registerOverwrittenFunction(p11, "getIsLightActive", ReverseDriving.getIsLightActive)
	SpecializationUtil.registerOverwrittenFunction(p11, "getAIDirectionNode", ReverseDriving.getAIDirectionNode)
	SpecializationUtil.registerOverwrittenFunction(p11, "getAIRootNode", ReverseDriving.getAIRootNode)
	SpecializationUtil.registerOverwrittenFunction(p11, "getAIImplementCollisionTrigger", ReverseDriving.getAIImplementCollisionTrigger)
end
function ReverseDriving.registerEventListeners(p12)
	SpecializationUtil.registerEventListener(p12, "onLoad", ReverseDriving)
	SpecializationUtil.registerEventListener(p12, "onPostLoad", ReverseDriving)
	SpecializationUtil.registerEventListener(p12, "onReadStream", ReverseDriving)
	SpecializationUtil.registerEventListener(p12, "onWriteStream", ReverseDriving)
	SpecializationUtil.registerEventListener(p12, "onUpdate", ReverseDriving)
	SpecializationUtil.registerEventListener(p12, "onVehicleCharacterChanged", ReverseDriving)
	SpecializationUtil.registerEventListener(p12, "onRegisterActionEvents", ReverseDriving)
end
function ReverseDriving.onLoad(p13, _)
	local v14 = p13.spec_reverseDriving
	XMLUtil.checkDeprecatedXMLElements(p13.xmlFile, "vehicle.reverseDriving.steering#reversedIndex", "vehicle.reverseDriving.steeringWheel#node")
	XMLUtil.checkDeprecatedXMLElements(p13.xmlFile, "vehicle.reverseDriving.steering#reversedNode", "vehicle.reverseDriving.steeringWheel#node")
	v14.reversedCharacterTargets = {}
	IKUtil.loadIKChainTargets(p13.xmlFile, "vehicle.reverseDriving", p13.components, v14.reversedCharacterTargets, p13.i3dMappings)
	local v15 = p13.xmlFile:getValue("vehicle.reverseDriving.steeringWheel#node", nil, p13.components, p13.i3dMappings)
	if v15 ~= nil then
		v14.steeringWheel = {}
		v14.steeringWheel.node = v15
		local _, v16, _ = getRotation(v14.steeringWheel.node)
		v14.steeringWheel.lastRotation = v16
		v14.steeringWheel.indoorRotation = p13.xmlFile:getValue("vehicle.reverseDriving.steeringWheel#indoorRotation", p13.xmlFile:getValue("vehicle.drivable.steeringWheel#indoorRotation", 0))
		v14.steeringWheel.outdoorRotation = p13.xmlFile:getValue("vehicle.reverseDriving.steeringWheel#outdoorRotation", p13.xmlFile:getValue("vehicle.drivable.steeringWheel#outdoorRotation", 0))
	end
	v14.reverseDrivingAnimation = p13.xmlFile:getValue("vehicle.reverseDriving#animationName", "reverseDriving")
	v14.hideCharacterOnChange = p13.xmlFile:getValue("vehicle.reverseDriving#hideCharacterOnChange", true)
	v14.inverseTransmission = p13.xmlFile:getValue("vehicle.reverseDriving#inverseTransmission", false)
	v14.disablingAttacherJointIndices = p13.xmlFile:getValue("vehicle.reverseDriving#disablingAttacherJointIndices", nil, true)
	v14.aiSteeringNode = p13.xmlFile:getValue("vehicle.reverseDriving.ai#steeringNode", nil, p13.components, p13.i3dMappings)
	v14.supportsAI = v14.aiSteeringNode ~= nil
	if p13.loadAICollisionTriggerFromXML ~= nil then
		v14.aiCollisionTrigger = p13:loadAICollisionTriggerFromXML(p13.xmlFile, "vehicle.reverseDriving.ai")
	end
	v14.hasReverseDriving = p13:getAnimationExists(v14.reverseDrivingAnimation)
	for v17, v18 in pairs(p13.configurations) do
		local v19 = g_vehicleConfigurationManager:getConfigurationDescByName(v17)
		local v20 = string.format("%s(%d).reverseDriving", v19.configurationKey, v18 - 1)
		if not p13.xmlFile:getValue(v20 .. "#isAllowed", true) then
			v14.hasReverseDriving = false
		end
	end
	v14.isChangingDirection = false
	v14.isReverseDriving = p13.xmlFile:getValue("vehicle.reverseDriving#initialInversed", false)
	v14.smoothReverserDirection = 1
	if not v14.hasReverseDriving then
		SpecializationUtil.removeEventListener(p13, "onPostLoad", ReverseDriving)
		SpecializationUtil.removeEventListener(p13, "onReadStream", ReverseDriving)
		SpecializationUtil.removeEventListener(p13, "onWriteStream", ReverseDriving)
		SpecializationUtil.removeEventListener(p13, "onUpdate", ReverseDriving)
		SpecializationUtil.removeEventListener(p13, "onVehicleCharacterChanged", ReverseDriving)
		SpecializationUtil.removeEventListener(p13, "onRegisterActionEvents", ReverseDriving)
	end
end
function ReverseDriving.onPostLoad(p21, p22)
	local v23 = p21.spec_reverseDriving
	local v24 = p21:getVehicleCharacter()
	if v24 ~= nil then
		v23.defaultCharacterTargets = v24:getIKChainTargets()
	end
	local v25 = v23.isReverseDriving
	if p22 ~= nil then
		v25 = p22.xmlFile:getValue(p22.key .. ".reverseDriving#isActive", v25)
	end
	p21:setIsReverseDriving(v25, true, true)
	v23.updateAnimationOnEnter = v25
end
function ReverseDriving.saveToXMLFile(p26, p27, p28, _)
	local v29 = p26.spec_reverseDriving
	if v29.hasReverseDriving then
		p27:setValue(p28 .. "#isActive", v29.isReverseDriving)
	end
end
function ReverseDriving.onReadStream(p30, p31, _)
	p30:setIsReverseDriving(streamReadBool(p31), true, true)
	local v32 = p30.spec_reverseDriving
	v32.updateAnimationOnEnter = v32.isReverseDriving
end
function ReverseDriving.onWriteStream(p33, p34, _)
	streamWriteBool(p34, p33.spec_reverseDriving.isReverseDriving)
end
function ReverseDriving.onUpdate(p35, p36, _, _, _)
	local v37 = p35.spec_reverseDriving
	if v37.isChangingDirection then
		if v37.hideCharacterOnChange then
			local v38 = p35:getVehicleCharacter()
			if v38 ~= nil then
				v38:setCharacterVisibility(false)
			end
		end
		if not p35:getIsEntered() and v37.updateAnimationOnEnter then
			AnimatedVehicle.updateAnimations(p35, 99999999, true)
			v37.updateAnimationOnEnter = false
		end
		if not p35:getIsAnimationPlaying(v37.reverseDrivingAnimation) then
			p35:reverseDirectionChanged(v37.reverserDirection)
		end
		local v39 = v37.isReverseDriving and 1 or -1
		local v40 = v37.smoothReverserDirection - 0.001 * p36 * v39
		v37.smoothReverserDirection = math.clamp(v40, -1, 1)
	end
end
function ReverseDriving.reverseDirectionChanged(p41, p42)
	local v43 = p41.spec_reverseDriving
	v43.isChangingDirection = false
	if v43.isReverseDriving then
		p41:setReverserDirection(-1)
		v43.smoothReverserDirection = -1
	else
		p41:setReverserDirection(1)
		v43.smoothReverserDirection = 1
	end
	local v44 = p41:getVehicleCharacter()
	if v44 ~= nil then
		if v43.isReverseDriving and next(v43.reversedCharacterTargets) ~= nil then
			v44:setIKChainTargets(v43.reversedCharacterTargets)
		else
			v44:setIKChainTargets(v43.defaultCharacterTargets)
		end
		if v44.meshThirdPerson ~= nil and not p41:getIsEntered() then
			v44:updateVisibility()
		end
		v44:setAllowCharacterUpdate(true)
	end
	if p41.setLightsTypesMask ~= nil then
		p41:setLightsTypesMask(p41.spec_lights.lightsTypesMask, true, true)
	end
	SpecializationUtil.raiseEvent(p41, "onReverseDirectionChanged", p42)
end
function ReverseDriving.setIsReverseDriving(p45, p46, p47, p48)
	local v49 = p45.spec_reverseDriving
	if p46 ~= v49.isReverseDriving or p48 then
		v49.isChangingDirection = true
		v49.isReverseDriving = p46
		local v50 = p46 and 1 or -1
		p45:playAnimation(v49.reverseDrivingAnimation, v50, p45:getAnimationTime(v49.reverseDrivingAnimation), true)
		local v51 = p45:getVehicleCharacter()
		if v51 ~= nil then
			v51:setAllowCharacterUpdate(false)
		end
		if v49.inverseTransmission and p45.setTransmissionDirection ~= nil then
			p45:setTransmissionDirection(-v50)
		end
		p45:setReverserDirection(0)
		SpecializationUtil.raiseEvent(p45, "onStartReverseDirectionChange")
		ReverseDrivingSetStateEvent.sendEvent(p45, p46, p47)
		if p48 then
			AnimatedVehicle.updateAnimationByName(p45, v49.reverseDrivingAnimation, 9999999, true)
		end
	end
end
function ReverseDriving.getIsReverseDrivingAllowed(p52, p53)
	local v54 = p52.spec_reverseDriving
	if p53 and v54.disablingAttacherJointIndices ~= nil then
		for v55 = 1, #v54.disablingAttacherJointIndices do
			if p52:getImplementFromAttacherJointIndex(v54.disablingAttacherJointIndices[v55]) ~= nil then
				return false
			end
		end
	end
	return true
end
function ReverseDriving.updateSteeringWheel(p56, p57, p58, p59, p60)
	local v61 = p56.spec_reverseDriving
	if v61.isReverseDriving then
		if v61.steeringWheel ~= nil then
			p58 = v61.steeringWheel
		end
		p60 = -p60
	end
	p57(p56, p58, p59, p60)
end
function ReverseDriving.getSteeringDirection(p62, p63)
	local v64 = p62.spec_reverseDriving
	if v64.hasReverseDriving then
		return v64.smoothReverserDirection
	else
		return p63(p62)
	end
end
function ReverseDriving.getAllowCharacterVisibilityUpdate(p65, p66)
	local v67 = p65.spec_reverseDriving
	local v68 = p66(p65)
	if v68 then
		v68 = not (v67.hideCharacterOnChange and v67.isChangingDirection)
	end
	return v68
end
function ReverseDriving.getCanStartAIVehicle(p69, p70, p71)
	local v72 = p69.spec_reverseDriving
	if not v72.supportsAI and v72.hasReverseDriving then
		if v72.isReverseDriving then
			return false
		end
		if v72.isChangingDirection then
			return false
		end
	end
	return p70(p69, p71)
end
function ReverseDriving.loadDashboardGroupFromXML(p73, p74, p75, p76, p77)
	if not p74(p73, p75, p76, p77) then
		return false
	end
	p77.isReverseDriving = p75:getValue(p76 .. "#isReverseDriving")
	return true
end
function ReverseDriving.getIsDashboardGroupActive(p78, p79, p80)
	if p80.isReverseDriving == nil or p78.spec_reverseDriving.isReverseDriving == p80.isReverseDriving then
		return p79(p78, p80)
	else
		return false
	end
end
function ReverseDriving.getCanBeSelected(_, _)
	return true
end
function ReverseDriving.loadAdditionalLightAttributesFromXML(p81, p82, p83, p84, p85)
	if not p82(p81, p83, p84, p85) then
		return false
	end
	p85.enableDirection = p83:getValue(p84 .. "#enableDirection")
	return true
end
function ReverseDriving.getIsLightActive(p86, p87, p88)
	if p88.enableDirection == nil or p88.enableDirection == p86:getReverserDirection() then
		return p87(p86, p88)
	else
		return false
	end
end
function ReverseDriving.getAIDirectionNode(p89, p90)
	local v91 = p89.spec_reverseDriving
	if v91.isReverseDriving then
		return v91.aiSteeringNode or p90(p89)
	else
		return p90(p89)
	end
end
function ReverseDriving.getAIRootNode(p92, p93)
	local v94 = p92.spec_reverseDriving
	if v94.isReverseDriving then
		return v94.aiSteeringNode or p93(p92)
	else
		return p93(p92)
	end
end
function ReverseDriving.getAIImplementCollisionTrigger(p95, p96)
	local v97 = p95.spec_reverseDriving
	if v97.isReverseDriving then
		return v97.aiCollisionTrigger or p96(p95)
	else
		return p96(p95)
	end
end
function ReverseDriving.onVehicleCharacterChanged(p98, p99)
	local v100 = p98.spec_reverseDriving
	if p99 ~= nil then
		if v100.updateAnimationOnEnter then
			AnimatedVehicle.updateAnimations(p98, 99999999, true)
			v100.updateAnimationOnEnter = false
		end
		if v100.isReverseDriving and next(v100.reversedCharacterTargets) ~= nil then
			p99:setIKChainTargets(v100.reversedCharacterTargets, true)
			return
		end
		p99:setIKChainTargets(v100.defaultCharacterTargets, true)
	end
end
function ReverseDriving.onRegisterActionEvents(p101, _, p102)
	if p101.isClient then
		local v103 = p101.spec_reverseDriving
		p101:clearActionEventsTable(v103.actionEvents)
		if p102 then
			local _, v104 = p101:addPoweredActionEvent(v103.actionEvents, InputAction.CHANGE_DRIVING_DIRECTION, p101, ReverseDriving.actionEventToggleReverseDriving, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v104, GS_PRIO_NORMAL)
			g_inputBinding:setActionEventText(v104, g_i18n:getText("input_CHANGE_DRIVING_DIRECTION"))
		end
	end
end
function ReverseDriving.actionEventToggleReverseDriving(p105, _, _, _, _)
	local v106 = p105.spec_reverseDriving
	if p105:getIsReverseDrivingAllowed(not v106.isReverseDriving) then
		p105:setIsReverseDriving(not v106.isReverseDriving)
	end
end

ConveyorBelt = {}
function ConveyorBelt.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Dischargeable, p1)
end
function ConveyorBelt.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("ConveyorBelt")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.conveyorBelt.animationNodes")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.conveyorBelt.effects")
	v2:register(XMLValueType.INT, "vehicle.conveyorBelt#dischargeNodeIndex", "Discharge node index", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.conveyorBelt#startPercentage", "Start unloading percentage", 0.9)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.conveyorBelt.offset(?)#movingToolNode", "Moving tool node")
	v2:register(XMLValueType.INT, "vehicle.conveyorBelt.offset(?).effect(?)#index", "Index of effect", 0)
	v2:register(XMLValueType.FLOAT, "vehicle.conveyorBelt.offset(?).effect(?)#minOffset", "Min. offset", 0)
	v2:register(XMLValueType.FLOAT, "vehicle.conveyorBelt.offset(?).effect(?)#maxOffset", "Max. offset", 1)
	v2:register(XMLValueType.BOOL, "vehicle.conveyorBelt.offset(?).effect(?)#inverted", "Is inverted", false)
	SoundManager.registerSampleXMLPaths(v2, "vehicle.conveyorBelt.sounds", "belt")
	v2:setXMLSpecializationType()
end
function ConveyorBelt.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getConveyorBeltFillLevel", ConveyorBelt.getConveyorBeltFillLevel)
	SpecializationUtil.registerFunction(p3, "getConveyorBeltTargetObject", ConveyorBelt.getConveyorBeltTargetObject)
	SpecializationUtil.registerFunction(p3, "getLoadTriggerMaxFillSpeed", ConveyorBelt.getLoadTriggerMaxFillSpeed)
end
function ConveyorBelt.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getDischargeNodeEmptyFactor", ConveyorBelt.getDischargeNodeEmptyFactor)
	SpecializationUtil.registerOverwrittenFunction(p4, "handleDischargeOnEmpty", ConveyorBelt.handleDischargeOnEmpty)
	SpecializationUtil.registerOverwrittenFunction(p4, "handleDischarge", ConveyorBelt.handleDischarge)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsEnterable", ConveyorBelt.getIsEnterable)
	SpecializationUtil.registerOverwrittenFunction(p4, "getFillUnitAllowsFillType", ConveyorBelt.getFillUnitAllowsFillType)
	SpecializationUtil.registerOverwrittenFunction(p4, "getFillUnitFreeCapacity", ConveyorBelt.getFillUnitFreeCapacity)
end
function ConveyorBelt.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", ConveyorBelt)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", ConveyorBelt)
	SpecializationUtil.registerEventListener(p5, "onDelete", ConveyorBelt)
	SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", ConveyorBelt)
	SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", ConveyorBelt)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", ConveyorBelt)
	SpecializationUtil.registerEventListener(p5, "onFillUnitFillLevelChanged", ConveyorBelt)
	SpecializationUtil.registerEventListener(p5, "onMovingToolChanged", ConveyorBelt)
end
function ConveyorBelt.onLoad(p6, _)
	local v7 = p6.spec_conveyorBelt
	if p6.isClient then
		v7.animationNodes = g_animationManager:loadAnimations(p6.xmlFile, "vehicle.conveyorBelt.animationNodes", p6.components, p6, p6.i3dMappings)
		v7.samples = {}
		v7.samples.belt = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.conveyorBelt.sounds", "belt", p6.baseDirectory, p6.components, 0, AudioGroup.VEHICLE, p6.i3dMappings, p6)
	end
	v7.effects = g_effectManager:loadEffect(p6.xmlFile, "vehicle.conveyorBelt.effects", p6.components, p6, p6.i3dMappings)
	v7.currentDelay = 0
	table.sort(v7.effects, function(p8, p9)
		return p8.startDelay < p9.startDelay
	end)
	for _, v10 in pairs(v7.effects) do
		if v10.planeFadeTime ~= nil then
			v7.currentDelay = v7.currentDelay + v10.planeFadeTime
		end
		if v10.setScrollUpdate ~= nil then
			v10:setScrollUpdate(false)
		end
	end
	v7.maxDelay = v7.currentDelay
	v7.morphStartPos = 0
	v7.morphEndPos = 0
	v7.isEffectDirty = true
	v7.emptyFactor = 1
	v7.scrollUpdateTime = 0
	v7.lastScrollUpdate = false
	v7.fillUnitIndex = 1
	v7.startFillLevel = 0
	v7.dischargeNodeIndex = p6.xmlFile:getValue("vehicle.conveyorBelt#dischargeNodeIndex", 1)
	p6:setCurrentDischargeNodeIndex(v7.dischargeNodeIndex)
	local v11 = p6:getDischargeNodeByIndex(v7.dischargeNodeIndex)
	local v12
	if v11 == nil then
		v12 = 0
	else
		local v13 = p6:getFillUnitCapacity(v11.fillUnitIndex)
		v7.fillUnitIndex = v11.fillUnitIndex
		v7.startFillLevel = v13 * p6.xmlFile:getValue("vehicle.conveyorBelt#startPercentage", 0.9)
		v12 = 0
	end
	while true do
		local v14 = string.format("vehicle.conveyorBelt.offset(%d)", v12)
		if not p6.xmlFile:hasProperty(v14) then
			break
		end
		local v15 = p6.xmlFile:getValue(v14 .. "#movingToolNode", nil, p6.components, p6.i3dMappings)
		if v15 == nil then
			Logging.xmlWarning(p6.xmlFile, "Missing movingToolNode for conveyor offset \'%s\'!", v14)
		else
			local v16, v17
			if v7.offsets == nil then
				v7.offsets = {}
				v16 = 0
				v17 = {
					["lastState"] = nil,
					["movingToolNode"] = v15,
					["effects"] = {}
				}
			else
				v16 = 0
				v17 = {
					["lastState"] = nil,
					["movingToolNode"] = v15,
					["effects"] = {}
				}
			end
			while true do
				local v18 = string.format(v14 .. ".effect(%d)", v16)
				if not p6.xmlFile:hasProperty(v18) then
					break
				end
				local v19 = p6.xmlFile:getValue(v18 .. "#index", 0)
				local v20 = v7.effects[v19]
				if v20 == nil or v20.setOffset == nil then
					Logging.xmlWarning(p6.xmlFile, "Effect index \'%d\' not found at \'%s\'!", v19, v18)
				else
					local v21 = {
						["effect"] = v20,
						["minValue"] = p6.xmlFile:getValue(v18 .. "#minOffset", 0) * 1000,
						["maxValue"] = p6.xmlFile:getValue(v18 .. "#maxOffset", 1) * 1000,
						["inverted"] = p6.xmlFile:getValue(v18 .. "#inverted", false)
					}
					local v22 = v17.effects
					table.insert(v22, v21)
				end
				v16 = v16 + 1
			end
			local v23 = v7.offsets
			table.insert(v23, v17)
		end
		v12 = v12 + 1
	end
	v7.isFilling = false
	v7.isScrolling = false
	v7.dirtyFlag = p6:getNextDirtyFlag()
end
function ConveyorBelt.onPostLoad(p24, _)
	local v25 = p24.spec_conveyorBelt
	if v25.offsets ~= nil then
		if p24.getMovingToolByNode == nil then
			Logging.xmlError(p24.xmlFile, "\'Cylindered\' specialization is required to use conveyorBelt offsets!")
			v25.offsets = nil
		else
			v25.movingToolToOffset = {}
			for v26 = #v25.offsets, 1, -1 do
				local v27 = v25.offsets[v26]
				local v28 = p24:getMovingToolByNode(v27.movingToolNode)
				if v28 == nil then
					Logging.xmlWarning(p24.xmlFile, "No movingTool node \'%s\' defined for conveyor offset \'%d\'!", getName(v27.movingToolNode), v26)
					table.remove(v25.offsets, v26)
				else
					v27.movingTool = v28
					v25.movingToolToOffset[v28] = v27
					ConveyorBelt.onMovingToolChanged(p24, v28, 0, 0)
				end
			end
			if #v25.offsets == 0 then
				v25.offsets = nil
				v25.movingToolToOffset = nil
				return
			end
		end
	end
end
function ConveyorBelt.onDelete(p29)
	local v30 = p29.spec_conveyorBelt
	g_effectManager:deleteEffects(v30.effects)
	g_animationManager:deleteAnimations(v30.animationNodes)
	g_soundManager:deleteSamples(v30.samples)
end
function ConveyorBelt.onReadUpdateStream(p31, p32, _, p33)
	if p33:getIsServer() and streamReadBool(p32) then
		local v34 = p31.spec_conveyorBelt
		v34.isFilling = streamReadBool(p32)
		v34.isScrolling = streamReadBool(p32)
	end
end
function ConveyorBelt.onWriteUpdateStream(p35, p36, p37, p38)
	if not p37:getIsServer() then
		local v39 = p35.spec_conveyorBelt
		if streamWriteBool(p36, bitAND(p38, v39.dirtyFlag) ~= 0) then
			streamWriteBool(p36, v39.isFilling)
			streamWriteBool(p36, v39.isScrolling)
		end
	end
end
function ConveyorBelt.onUpdateTick(p40, p41, _, _, _)
	local v42 = p40.spec_conveyorBelt
	if not p40.isServer then
		if v42.isFilling then
			v42.morphStartPos = 0
			local v43 = v42.morphEndPos
			local v44 = v42.fillUnitIndex
			v42.morphEndPos = math.max(v43, p40:getFillUnitFillLevelPercentage(v44))
			v42.isEffectDirty = true
		end
		if v42.isScrolling then
			v42.scrollUpdateTime = 100
		end
	end
	local v45 = v42.scrollUpdateTime > 0
	if v45 ~= v42.lastScrollUpdate then
		if p40.isClient then
			if v45 then
				g_animationManager:startAnimations(v42.animationNodes)
				g_soundManager:playSample(v42.samples.belt)
			else
				g_animationManager:stopAnimations(v42.animationNodes)
				g_soundManager:stopSample(v42.samples.belt)
			end
			for _, v46 in pairs(v42.effects) do
				if v46.setScrollUpdate ~= nil then
					v46:setScrollUpdate(v45)
				end
			end
		end
		v42.lastScrollUpdate = v45
	end
	local v47 = v42.scrollUpdateTime - p41
	v42.scrollUpdateTime = math.max(v47, 0)
	if p40:getDischargeState() ~= Dischargeable.DISCHARGE_STATE_OFF then
		local v48 = p40:getFillUnitFillLevelPercentage(v42.fillUnitIndex)
		if v48 > 0.0001 then
			local v49 = p41 / v42.currentDelay
			local v50 = v42.morphStartPos + v49
			v42.morphStartPos = math.clamp(v50, 0, 1)
			local v51 = v42.morphEndPos + v49
			v42.morphEndPos = math.clamp(v51, 0, 1)
			local v52 = v42.morphEndPos - v42.morphStartPos
			v42.emptyFactor = 1
			if v48 < v52 then
				local v53 = v48 / math.max(v52, 0.001)
				v42.emptyFactor = math.clamp(v53, 0, 1)
			else
				local v54 = v48 - v52
				v42.offset = v54
				local v55 = v42.morphStartPos
				local v56 = (1 - v42.morphStartPos) * v42.currentDelay
				local v57 = v55 - v54 / math.max(v56, 0.001) * p41
				v42.morphStartPos = math.clamp(v57, 0, 1)
			end
			v42.isEffectDirty = true
			v42.scrollUpdateTime = p41 * 3
		end
	end
	if v45 then
		p40:raiseActive()
	end
	if p40.isClient and v42.isEffectDirty then
		for _, v58 in pairs(v42.effects) do
			if v58.setMorphPosition ~= nil then
				local v59 = v58.startDelay / v42.currentDelay
				local v60 = (v58.startDelay + v58.planeFadeTime - v58.offset) / v42.currentDelay
				local v61 = v58.offset / v58.planeFadeTime
				local v62 = v61 + (v42.morphStartPos - v59) / (v60 - v59) * (1 - v61)
				local v63 = math.clamp(v62, v61, 1)
				local v64 = v61 + (v42.morphEndPos - v59) / (v60 - v59) * (1 - v61)
				v58:setMorphPosition(v63, (math.clamp(v64, v61, 1)))
			end
		end
		v42.isEffectDirty = false
	end
end
function ConveyorBelt.getConveyorBeltFillLevel(p65)
	local v66 = p65:getFillUnitFillLevel(p65.spec_conveyorBelt.fillUnitIndex)
	if p65.getCurrentDischargeNode ~= nil then
		local v67 = p65:getCurrentDischargeNode().dischargeHitObject
		if v67 ~= nil and v67.getConveyorBeltFillLevel ~= nil then
			v66 = v66 + v67:getConveyorBeltFillLevel()
		end
	end
	return v66
end
function ConveyorBelt.getConveyorBeltTargetObject(p68)
	if p68.getCurrentDischargeNode ~= nil then
		local v69 = p68:getCurrentDischargeNode()
		local v70 = v69.dischargeHitObject
		local v71 = v69.dischargeHitObjectUnitIndex
		if v70 ~= nil then
			if v70.getConveyorBeltTargetObject == nil then
				return v70, v71
			else
				return v70:getConveyorBeltTargetObject()
			end
		end
	end
	return nil
end
function ConveyorBelt.getLoadTriggerMaxFillSpeed(p72)
	local v73
	if p72.getCurrentDischargeNode == nil then
		v73 = (1 / 0)
	else
		local v74 = p72:getCurrentDischargeNode()
		v73 = v74.emptySpeed
		local v75 = v74.dischargeHitObject
		if v75 ~= nil and v75.getLoadTriggerMaxFillSpeed ~= nil then
			local v76 = v75:getLoadTriggerMaxFillSpeed()
			v73 = math.min(v76, v73)
		end
	end
	return v73
end
function ConveyorBelt.getDischargeNodeEmptyFactor(p77, p78, p79)
	local v80 = p77.spec_conveyorBelt
	local v81 = p78(p77, p79)
	if v80.dischargeNodeIndex == p79.index then
		return v80.morphEndPos ~= 1 and 0 or v80.emptyFactor
	else
		return v81
	end
end
function ConveyorBelt.handleDischargeOnEmpty(p82, p83, p84)
	local v85 = p82.spec_conveyorBelt
	if p84.index ~= v85.dischargeNodeIndex then
		p83(p82, p84)
	end
end
function ConveyorBelt.handleDischarge(p86, p87, p88, p89, p90, p91)
	local v92 = p86.spec_conveyorBelt
	if p88.index ~= v92.dischargeNodeIndex then
		p87(p86, p88, p89, p90, p91)
	end
end
function ConveyorBelt.getIsEnterable(p93, p94)
	local v95
	if p93.getAttacherVehicle == nil or p93:getAttacherVehicle() == nil then
		v95 = p94(p93)
	else
		v95 = false
	end
	return v95
end
function ConveyorBelt.getHasConveyorBeltLoop(p96, p97, p98)
	if p97.getCurrentDischargeNode ~= nil then
		local v99 = p97:getCurrentDischargeNode()
		if v99.fillUnitIndex == p98 then
			local v100 = v99.dischargeHitObject
			local v101 = v99.dischargeHitObjectUnitIndex
			if v100 ~= nil and (v100.spec_conveyorBelt ~= nil and v101 ~= nil) then
				return v100 == p96 and true or ConveyorBelt.getHasConveyorBeltLoop(p96, v100, v101)
			end
		end
	end
	return false
end
function ConveyorBelt.getFillUnitAllowsFillType(p102, p103, p104, p105)
	if not p103(p102, p104, p105) then
		return false
	end
	if not ConveyorBelt.getHasConveyorBeltLoop(p102, p102, p104) and p102.getCurrentDischargeNode ~= nil then
		local v106 = p102:getCurrentDischargeNode()
		if v106.fillUnitIndex == p104 then
			local v107 = v106.dischargeHitObject
			local v108 = v106.dischargeHitObjectUnitIndex
			if v107 ~= nil and (v107.getFillUnitAllowsFillType ~= nil and v108 ~= nil) then
				if v106.fillTypeConverter ~= nil then
					local v109 = v106.fillTypeConverter[p105]
					if v109 ~= nil and v107:getFillUnitAllowsFillType(v108, v109.targetFillTypeIndex) then
						return true
					end
				end
				return v107:getFillUnitAllowsFillType(v108, p105)
			end
		end
	end
	return true
end
function ConveyorBelt.getFillUnitFreeCapacity(p110, p111, p112, p113, p114)
	local v115 = p111(p110, p112, p113, p114)
	if not ConveyorBelt.getHasConveyorBeltLoop(p110, p110, p112) and p110.getCurrentDischargeNode ~= nil then
		local v116 = p110:getCurrentDischargeNode()
		if v116.fillUnitIndex == p112 then
			local v117 = v116.dischargeHitObject
			local v118 = v116.dischargeHitObjectUnitIndex
			if v117 ~= nil and (v117.getFillUnitFreeCapacity ~= nil and v118 ~= nil) then
				return v115 + v117:getFillUnitFreeCapacity(v118, p113, p114)
			end
		end
	end
	return v115
end
function ConveyorBelt.onFillUnitFillLevelChanged(p119, p120, p121, p122, _, _, _)
	local v123 = p119.spec_conveyorBelt
	if v123.fillUnitIndex == p120 then
		local v124 = p119:getFillUnitFillLevel(p120)
		if p119.isServer then
			local v125 = false
			local v126
			if p121 > 0 then
				v123.morphStartPos = 0
				local v127 = v123.morphEndPos
				local v128 = v124 / p119:getFillUnitCapacity(p120)
				v123.morphEndPos = math.max(v127, v128)
				v123.isEffectDirty = true
				v126 = true
			else
				v126 = false
			end
			if p121 ~= 0 then
				v123.scrollUpdateTime = 100
				v125 = true
			end
			if v126 ~= v123.isFilling or v125 ~= v123.isScrolling then
				v123.isFilling = v126
				v123.isScrolling = v125
				p119:raiseDirtyFlags(v123.dirtyFlag)
			end
		end
		if v124 == 0 then
			g_effectManager:stopEffects(v123.effects)
			v123.morphStartPos = 0
			v123.morphEndPos = 0
			v123.isEffectDirty = true
			return
		end
		g_effectManager:setEffectTypeInfo(v123.effects, p122)
		for _, v129 in pairs(v123.effects) do
			g_effectManager:startEffect(v129, true)
		end
	end
end
function ConveyorBelt.onMovingToolChanged(p130, p131, _, _)
	local v132 = p130.spec_conveyorBelt
	if v132.offsets ~= nil and v132.movingToolToOffset ~= nil then
		local v133 = v132.movingToolToOffset[p131]
		if v133 ~= nil then
			local v134 = Cylindered.getMovingToolState(p130, p131)
			if v134 ~= v133.lastState then
				local v135 = false
				for _, v136 in pairs(v133.effects) do
					local v137
					if v136.inverted then
						v137 = 1 - v134
					else
						v137 = v134
					end
					v136.effect:setOffset(MathUtil.lerp(v136.minValue, v136.maxValue, v137))
					v132.isEffectDirty = true
					v135 = true
				end
				if v135 then
					v132.currentDelay = 0
					for _, v138 in pairs(v132.effects) do
						if v138.planeFadeTime ~= nil then
							v132.currentDelay = v132.currentDelay + v138.planeFadeTime - v138.offset
						end
					end
				end
				v133.lastState = v134
			end
		end
	end
end
function ConveyorBelt.updateDebugValues(p139, p140)
	local v141 = p139.spec_conveyorBelt
	local v142 = {
		["name"] = "fillFactor",
		["value"] = p139:getFillUnitFillLevelPercentage(v141.fillUnitIndex)
	}
	table.insert(p140, v142)
	local v143 = {
		["name"] = "visualFactor",
		["value"] = v141.morphEndPos - v141.morphStartPos
	}
	table.insert(p140, v143)
	local v144 = {
		["name"] = "currentDelay",
		["value"] = v141.currentDelay
	}
	table.insert(p140, v144)
	local v145 = {
		["name"] = "offset",
		["value"] = v141.offset
	}
	table.insert(p140, v145)
	local v146 = {
		["name"] = "morphStartPos",
		["value"] = v141.morphStartPos
	}
	table.insert(p140, v146)
	local v147 = {
		["name"] = "morphEndPos",
		["value"] = v141.morphEndPos
	}
	table.insert(p140, v147)
end

HookLiftTrailer = {}
function HookLiftTrailer.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Foldable, p1)
	end
	return v2
end
function HookLiftTrailer.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("HookLiftTrailer")
	v3:register(XMLValueType.FLOAT, "vehicle.hookLiftTrailer.jointLimits.key(?)#time", "Key time")
	v3:register(XMLValueType.VECTOR_ROT, "vehicle.hookLiftTrailer.jointLimits.key(?)#rotLimit", "Rotation limit", "0 0 0")
	v3:register(XMLValueType.VECTOR_TRANS, "vehicle.hookLiftTrailer.jointLimits.key(?)#transLimit", "Translation limit", "0 0 0")
	v3:register(XMLValueType.STRING, "vehicle.hookLiftTrailer.jointLimits#refAnimation", "Reference animation", "unfoldHand")
	v3:register(XMLValueType.STRING, "vehicle.hookLiftTrailer.unloadingAnimation#name", "Unload animation", "unloading")
	v3:register(XMLValueType.FLOAT, "vehicle.hookLiftTrailer.unloadingAnimation#speed", "Unload animation speed", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.hookLiftTrailer.unloadingAnimation#reverseSpeed", "Unload animation reverse speed", -1)
	v3:register(XMLValueType.STRING, "vehicle.hookLiftTrailer.texts#unloadContainer", "Unload container text", "unload_container")
	v3:register(XMLValueType.STRING, "vehicle.hookLiftTrailer.texts#loadContainer", "Load container text", "load_container")
	v3:register(XMLValueType.STRING, "vehicle.hookLiftTrailer.texts#unloadArm", "Unload arm text", "unload_arm")
	v3:register(XMLValueType.STRING, "vehicle.hookLiftTrailer.texts#loadArm", "Load arm text", "load_arm")
	v3:setXMLSpecializationType()
end
function HookLiftTrailer.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "startTipping", HookLiftTrailer.startTipping)
	SpecializationUtil.registerFunction(p4, "stopTipping", HookLiftTrailer.stopTipping)
	SpecializationUtil.registerFunction(p4, "getIsTippingAllowed", HookLiftTrailer.getIsTippingAllowed)
	SpecializationUtil.registerFunction(p4, "getCanDetachContainer", HookLiftTrailer.getCanDetachContainer)
end
function HookLiftTrailer.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsFoldAllowed", HookLiftTrailer.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p5, "isDetachAllowed", HookLiftTrailer.isDetachAllowed)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDoConsumePtoPower", HookLiftTrailer.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p5, "getPtoRpm", HookLiftTrailer.getPtoRpm)
end
function HookLiftTrailer.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", HookLiftTrailer)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", HookLiftTrailer)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", HookLiftTrailer)
	SpecializationUtil.registerEventListener(p6, "onPostAttachImplement", HookLiftTrailer)
	SpecializationUtil.registerEventListener(p6, "onPreDetachImplement", HookLiftTrailer)
end
function HookLiftTrailer.onLoad(p7, _)
	local v8 = p7.spec_hookLiftTrailer
	v8.jointLimits = AnimCurve.new(linearInterpolatorN)
	local v9 = 0
	while true do
		local v10 = string.format("vehicle.hookLiftTrailer.jointLimits.key(%d)", v9)
		if not p7.xmlFile:hasProperty(v10) then
			break
		end
		local v11 = p7.xmlFile:getValue(v10 .. "#time")
		local v12, v13, v14 = p7.xmlFile:getValue(v10 .. "#rotLimit", "0 0 0")
		local v15, v16, v17 = p7.xmlFile:getValue(v10 .. "#transLimit", "0 0 0")
		v8.jointLimits:addKeyframe({
			v12,
			v13,
			v14,
			v15,
			v16,
			v17,
			["time"] = v11
		})
		v9 = v9 + 1
	end
	if v9 == 0 then
		v8.jointLimits = nil
	end
	v8.refAnimation = p7.xmlFile:getValue("vehicle.hookLiftTrailer.jointLimits#refAnimation", "unfoldHand")
	v8.unloadingAnimation = p7.xmlFile:getValue("vehicle.hookLiftTrailer.unloadingAnimation#name", "unloading")
	v8.unloadingAnimationSpeed = p7.xmlFile:getValue("vehicle.hookLiftTrailer.unloadingAnimation#speed", 1)
	v8.unloadingAnimationReverseSpeed = p7.xmlFile:getValue("vehicle.hookLiftTrailer.unloadingAnimation#reverseSpeed", -1)
	v8.texts = {}
	v8.texts.unloadContainer = g_i18n:getText(p7.xmlFile:getValue("vehicle.hookLiftTrailer.texts#unloadContainer", "unload_container"), p7.customEnvironment)
	v8.texts.loadContainer = g_i18n:getText(p7.xmlFile:getValue("vehicle.hookLiftTrailer.texts#loadContainer", "load_container"), p7.customEnvironment)
	v8.texts.unloadArm = g_i18n:getText(p7.xmlFile:getValue("vehicle.hookLiftTrailer.texts#unloadArm", "unload_arm"), p7.customEnvironment)
	v8.texts.loadArm = g_i18n:getText(p7.xmlFile:getValue("vehicle.hookLiftTrailer.texts#loadArm", "load_arm"), p7.customEnvironment)
end
function HookLiftTrailer.onPostLoad(p18, _)
	local v19 = p18.spec_hookLiftTrailer
	local v20 = p18.spec_foldable
	v20.posDirectionText = v19.texts.unloadArm
	v20.negDirectionText = v19.texts.loadArm
end
function HookLiftTrailer.onUpdateTick(p21, _, _, _, _)
	local v22 = p21.spec_hookLiftTrailer
	if v22.attachedContainer ~= nil then
		local v23 = p21:getAnimationTime(v22.refAnimation)
		v22.attachedContainer.object.allowsDetaching = v23 > 0.95
		if (p21:getIsAnimationPlaying(v22.refAnimation) or not v22.attachedContainer.limitLocked) and (v22.jointLimits ~= nil and not v22.attachedContainer.implement.attachingIsInProgress) then
			local v24, v25, v26, v27, v28, v29 = v22.jointLimits:get(v23)
			setJointRotationLimit(v22.attachedContainer.jointIndex, 0, true, -v24, v24)
			setJointRotationLimit(v22.attachedContainer.jointIndex, 1, true, -v25, v25)
			setJointRotationLimit(v22.attachedContainer.jointIndex, 2, true, -v26, v26)
			setJointTranslationLimit(v22.attachedContainer.jointIndex, 0, true, -v27, v27)
			setJointTranslationLimit(v22.attachedContainer.jointIndex, 1, true, -v28, v28)
			setJointTranslationLimit(v22.attachedContainer.jointIndex, 2, true, -v29, v29)
			if v23 >= 0.99 then
				v22.attachedContainer.limitLocked = true
			end
		end
	end
end
function HookLiftTrailer.onPostAttachImplement(p30, p31, _, p32)
	local v33 = p30.spec_hookLiftTrailer
	local v34 = p31:getActiveInputAttacherJoint()
	if v34 ~= nil and v34.jointType == AttacherJoints.JOINTTYPE_HOOKLIFT then
		local v35 = p30:getAttacherJointByJointDescIndex(p32)
		v33.attachedContainer = {}
		v33.attachedContainer.jointIndex = v35.jointIndex
		v33.attachedContainer.implement = p30:getImplementByObject(p31)
		v33.attachedContainer.object = p31
		v33.attachedContainer.limitLocked = false
		local v36 = p30.spec_foldable
		v36.posDirectionText = v33.texts.unloadContainer
		v36.negDirectionText = v33.texts.loadContainer
	end
end
function HookLiftTrailer.onPreDetachImplement(p37, p38)
	local v39 = p37.spec_hookLiftTrailer
	if v39.attachedContainer ~= nil and p38 == v39.attachedContainer.implement then
		local v40 = p37.spec_foldable
		v40.posDirectionText = v39.texts.unloadArm
		v40.negDirectionText = v39.texts.loadArm
		v39.attachedContainer = nil
	end
end
function HookLiftTrailer.startTipping(p41)
	local v42 = p41.spec_hookLiftTrailer
	p41:playAnimation(v42.unloadingAnimation, v42.unloadingAnimationSpeed, p41:getAnimationTime(v42.unloadingAnimation), true)
end
function HookLiftTrailer.stopTipping(p43)
	local v44 = p43.spec_hookLiftTrailer
	p43:playAnimation(v44.unloadingAnimation, v44.unloadingAnimationReverseSpeed, p43:getAnimationTime(v44.unloadingAnimation), true)
end
function HookLiftTrailer.getIsTippingAllowed(p45)
	return p45:getAnimationTime(p45.spec_hookLiftTrailer.refAnimation) == 0
end
function HookLiftTrailer.getCanDetachContainer(p46)
	return p46:getAnimationTime(p46.spec_hookLiftTrailer.refAnimation) == 1
end
function HookLiftTrailer.getIsFoldAllowed(p47, p48, p49, p50)
	if p47:getAnimationTime(p47.spec_hookLiftTrailer.unloadingAnimation) > 0 then
		return false
	else
		return p48(p47, p49, p50)
	end
end
function HookLiftTrailer.isDetachAllowed(p51, p52)
	if p51:getAnimationTime(p51.spec_hookLiftTrailer.unloadingAnimation) == 0 then
		return p52(p51)
	else
		return false, nil
	end
end
function HookLiftTrailer.getDoConsumePtoPower(p53, p54)
	local v55 = p53.spec_hookLiftTrailer
	return p54(p53) or (p53:getIsAnimationPlaying(v55.refAnimation) or p53:getIsAnimationPlaying(v55.unloadingAnimation))
end
function HookLiftTrailer.getPtoRpm(p56, p57)
	local v58 = p56.spec_hookLiftTrailer
	local v59 = p57(p56)
	if p56:getIsAnimationPlaying(v58.refAnimation) or p56:getIsAnimationPlaying(v58.unloadingAnimation) then
		return p56.spec_powerConsumer.ptoRpm
	else
		return v59
	end
end

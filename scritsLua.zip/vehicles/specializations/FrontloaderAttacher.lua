FrontloaderAttacher = {}
function FrontloaderAttacher.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AttacherJoints, p1)
end
function FrontloaderAttacher.registerEventListeners(p2)
	SpecializationUtil.registerEventListener(p2, "onLoad", FrontloaderAttacher)
	SpecializationUtil.registerEventListener(p2, "onPreDetachImplement", FrontloaderAttacher)
	SpecializationUtil.registerEventListener(p2, "onPreAttachImplement", FrontloaderAttacher)
end
function FrontloaderAttacher.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("frontloader", g_i18n:getText("configuration_frontloaderAttacher"), nil, VehicleConfigurationItem)
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("FrontloaderAttacher")
	v3:register(XMLValueType.BOOL, "vehicle.frontloaderConfigurations.frontloaderConfiguration(?).attacherJoint#frontAxisLimitJoint", "Front axis joint will be limited while attached", true)
	v3:register(XMLValueType.INT, "vehicle.frontloaderConfigurations.frontloaderConfiguration(?).attacherJoint#frontAxisJoint", "Front axis joint index", 1)
	v3:setXMLSpecializationType()
end
function FrontloaderAttacher.onLoad(p4, _)
	if p4.configurations.frontloader ~= nil then
		local v5 = p4.spec_frontloaderAttacher
		local v6 = string.format("vehicle.frontloaderConfigurations.frontloaderConfiguration(%d)", p4.configurations.frontloader - 1)
		if p4.xmlFile:hasProperty(v6 .. ".attacherJoint") and p4.xmlFile:getValue(v6 .. ".attacherJoint#frontAxisLimitJoint", true) then
			local v7 = p4.xmlFile:getValue(v6 .. ".attacherJoint#frontAxisJoint", 1)
			if p4.componentJoints[v7] == nil then
				Logging.xmlWarning(p4.xmlFile, "Invalid front-axis joint \'%s\' for frontloader attacher.", v7)
			else
				v5.frontAxisJoint = v7
			end
		end
	end
	if not p4.isServer or p4.spec_frontloaderAttacher.frontAxisJoint == nil then
		SpecializationUtil.removeEventListener(p4, "onPreDetachImplement", FrontloaderAttacher)
		SpecializationUtil.removeEventListener(p4, "onPreAttachImplement", FrontloaderAttacher)
	end
end
function FrontloaderAttacher.onPreDetachImplement(p8, p9)
	local v10 = p8.spec_frontloaderAttacher
	if v10.frontAxisJoint ~= nil then
		local v11 = p9.jointDescIndex
		local v12 = p8:getAttacherJoints()
		local v13
		if v12 == nil then
			v13 = nil
		else
			v13 = v12[v11]
		end
		if v13 ~= nil and v13.jointType == AttacherJoints.JOINTTYPE_ATTACHABLEFRONTLOADER then
			for v14 = 1, 3 do
				p8:setComponentJointRotLimit(p8.componentJoints[v10.frontAxisJoint], v14, -v10.rotLimit[v14], v10.rotLimit[v14])
			end
		end
	end
end
function FrontloaderAttacher.onPreAttachImplement(p15, _, _, p16)
	local v17 = p15.spec_frontloaderAttacher
	if v17.frontAxisJoint ~= nil then
		local v18 = p15:getAttacherJoints()
		local v19
		if v18 == nil then
			v19 = nil
		else
			v19 = v18[p16]
		end
		if v19 ~= nil and v19.jointType == AttacherJoints.JOINTTYPE_ATTACHABLEFRONTLOADER then
			local v20 = {}
			local v21 = p15.componentJoints[v17.frontAxisJoint].rotLimit
			__set_list(v20, 1, {unpack(v21)})
			v17.rotLimit = v20
			for v22 = 1, 3 do
				p15:setComponentJointRotLimit(p15.componentJoints[v17.frontAxisJoint], v22, 0, 0)
			end
		end
	end
end

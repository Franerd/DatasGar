IKChains = {}
function IKChains.prerequisitesPresent(_)
	return true
end
function IKChains.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("IKChains")
	IKUtil.registerIKChainXMLPaths(v1, "vehicle.ikChains.ikChain(?)")
	v1:setXMLSpecializationType()
end
function IKChains.registerEventListeners(p2)
	SpecializationUtil.registerEventListener(p2, "onLoad", IKChains)
	SpecializationUtil.registerEventListener(p2, "onUpdate", IKChains)
end
function IKChains.onLoad(p3, _)
	local v4 = p3.spec_ikChains
	v4.chains = {}
	local v5 = 0
	while true do
		local v6 = string.format("vehicle.ikChains.ikChain(%d)", v5)
		if not p3.xmlFile:hasProperty(v6) then
			break
		end
		IKUtil.loadIKChain(p3.xmlFile, v6, p3.components, p3.components, v4.chains)
		v5 = v5 + 1
	end
	if next(v4.chains) == nil then
		SpecializationUtil.removeEventListener(p3, "onUpdate", IKChains)
	end
end
function IKChains.onUpdate(p7, _, _, _, _)
	IKUtil.updateIKChains(p7.spec_ikChains.chains)
end

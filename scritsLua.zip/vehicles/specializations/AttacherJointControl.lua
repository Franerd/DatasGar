AttacherJointControl = {}
AttacherJointControl.ALPHA_NUM_BITS = 8
AttacherJointControl.ALPHA_MAX_VALUE = 2 ^ AttacherJointControl.ALPHA_NUM_BITS - 1
function AttacherJointControl.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Attachable, p1)
end
function AttacherJointControl.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("AttacherJointControl")
	v2:register(XMLValueType.ANGLE, "vehicle.attacherJointControl#maxTiltAngle", "Max tilt angle", 25)
	v2:register(XMLValueType.BOOL, "vehicle.attacherJointControl#supportsDamping", "Supports damping of Y axis", false)
	v2:register(XMLValueType.FLOAT, "vehicle.attacherJointControl#dampingOffset", "Distance from attacher joint to damping reference point (m)", 2)
	v2:register(XMLValueType.STRING, "vehicle.attacherJointControl.control(?)#controlFunction", "Control script function (controlAttacherJointHeight or controlAttacherJointTilt)")
	v2:register(XMLValueType.STRING, "vehicle.attacherJointControl.control(?)#controlAxis", "Name of input action")
	v2:register(XMLValueType.STRING, "vehicle.attacherJointControl.control(?)#iconName", "Name of icon")
	v2:registerAutoCompletionDataSource("vehicle.attacherJointControl.control(?)#iconName", "$dataS/axisIcons.xml", "axisIcons.icon#name")
	v2:register(XMLValueType.BOOL, "vehicle.attacherJointControl.control(?)#invertControlAxis", "Invert control axis", false)
	v2:register(XMLValueType.FLOAT, "vehicle.attacherJointControl.control(?)#mouseSpeedFactor", "Mouse speed factor", 1)
	SoundManager.registerSampleXMLPaths(v2, "vehicle.attacherJointControl.sounds", "hydraulic")
	v2:register(XMLValueType.BOOL, Attachable.INPUT_ATTACHERJOINT_XML_KEY .. "#isControllable", "Is controllable", false)
	v2:register(XMLValueType.BOOL, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY .. "#isControllable", "Is controllable", false)
	v2:setXMLSpecializationType()
end
function AttacherJointControl.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "controlAttacherJoint", AttacherJointControl.controlAttacherJoint)
	SpecializationUtil.registerFunction(p3, "controlAttacherJointHeight", AttacherJointControl.controlAttacherJointHeight)
	SpecializationUtil.registerFunction(p3, "controlAttacherJointTilt", AttacherJointControl.controlAttacherJointTilt)
	SpecializationUtil.registerFunction(p3, "getControlAttacherJointDirection", AttacherJointControl.getControlAttacherJointDirection)
	SpecializationUtil.registerFunction(p3, "getIsAttacherJointControlDampingAllowed", AttacherJointControl.getIsAttacherJointControlDampingAllowed)
end
function AttacherJointControl.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadInputAttacherJoint", AttacherJointControl.loadInputAttacherJoint)
	SpecializationUtil.registerOverwrittenFunction(p4, "registerLoweringActionEvent", AttacherJointControl.registerLoweringActionEvent)
	SpecializationUtil.registerOverwrittenFunction(p4, "getLoweringActionEventState", AttacherJointControl.getLoweringActionEventState)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanBeSelected", AttacherJointControl.getCanBeSelected)
end
function AttacherJointControl.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onDelete", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onReadStream", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onUpdate", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onRegisterActionEvents", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onPostAttach", AttacherJointControl)
	SpecializationUtil.registerEventListener(p5, "onPreDetach", AttacherJointControl)
end
function AttacherJointControl.onLoad(p6, _)
	local v7 = p6.spec_attacherJointControl
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.attacherJointControl.control1", "vehicle.attacherJointControl.control with #controlFunction \'controlAttacherJointHeight\'")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.attacherJointControl.control2", "vehicle.attacherJointControl.control with #controlFunction \'controlAttacherJointTilt\'")
	v7.maxTiltAngle = p6.xmlFile:getValue("vehicle.attacherJointControl#maxTiltAngle", 25)
	v7.heightTargetAlpha = -1
	v7.supportsDamping = p6.xmlFile:getValue("vehicle.attacherJointControl#supportsDamping", false)
	v7.dampingOffset = p6.xmlFile:getValue("vehicle.attacherJointControl#dampingOffset", 2)
	v7.nextHeightDampingUpdateTime = 0
	v7.controls = {}
	v7.nameToControl = {}
	local v8 = 0
	while true do
		local v9 = string.format("%s.control(%d)", "vehicle.attacherJointControl", v8)
		if not p6.xmlFile:hasProperty(v9) then
			break
		end
		local v10 = {}
		local v11 = p6.xmlFile:getValue(v9 .. "#controlFunction")
		if v11 == nil or p6[v11] == nil then
			Logging.xmlWarning(p6.xmlFile, "Unknown control function \'%s\' for attacher joint control \'%s\'", tostring(v11), v9)
			break
		end
		v10.func = p6[v11]
		if v10.func == p6.controlAttacherJointHeight then
			v7.heightController = v10
		end
		if v10.func == p6.controlAttacherJointTilt then
			v7.tiltController = v10
		end
		local v12 = p6.xmlFile:getValue(v9 .. "#controlAxis")
		if v12 == nil or InputAction[v12] == nil then
			Logging.xmlWarning(p6.xmlFile, "Unknown control axis \'%s\' for attacher joint control \'%s\'", tostring(v12), v9)
			break
		end
		v10.controlAction = InputAction[v12]
		XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, v9 .. "#controlAxisIcon", v9 .. "#iconName")
		local v13 = p6.xmlFile:getValue(v9 .. "#iconName", "")
		if InputHelpElement.AXIS_ICON[v13] == nil then
			v13 = (p6.customEnvironment or "") .. v13
		end
		v10.axisActionIcon = v13
		v10.invertAxis = p6.xmlFile:getValue(v9 .. "#invertControlAxis", false)
		v10.mouseSpeedFactor = p6.xmlFile:getValue(v9 .. "#mouseSpeedFactor", 1)
		v10.moveAlpha = 0
		v10.moveAlphaSent = 0
		v10.moveAlphaLastManual = 0
		v7.nameToControl[v12] = v10
		local v14 = v7.controls
		table.insert(v14, v10)
		v8 = v8 + 1
	end
	if p6.isClient then
		v7.lastMoveTime = 0
		v7.samples = {}
		v7.samples.hydraulic = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.attacherJointControl.sounds", "hydraulic", p6.baseDirectory, p6.components, 0, AudioGroup.VEHICLE, p6.i3dMappings, p6)
	end
	v7.jointDesc = nil
	v7.dirtyFlagClient = p6:getNextDirtyFlag()
	v7.dirtyFlagServer = p6:getNextDirtyFlag()
	if #v7.controls == 0 then
		SpecializationUtil.removeEventListener(p6, "onReadStream", AttacherJointControl)
		SpecializationUtil.removeEventListener(p6, "onWriteStream", AttacherJointControl)
		SpecializationUtil.removeEventListener(p6, "onReadUpdateStream", AttacherJointControl)
		SpecializationUtil.removeEventListener(p6, "onWriteUpdateStream", AttacherJointControl)
		SpecializationUtil.removeEventListener(p6, "onUpdate", AttacherJointControl)
		SpecializationUtil.removeEventListener(p6, "onRegisterActionEvents", AttacherJointControl)
		SpecializationUtil.removeEventListener(p6, "onPostAttach", AttacherJointControl)
		SpecializationUtil.removeEventListener(p6, "onPreDetach", AttacherJointControl)
	end
end
function AttacherJointControl.onDelete(p15)
	local v16 = p15.spec_attacherJointControl
	if p15.isClient and v16.samples ~= nil then
		g_soundManager:deleteSample(v16.samples.hydraulic)
	end
end
function AttacherJointControl.onReadStream(p17, p18, p19)
	if p19:getIsServer() and streamReadBool(p18) then
		local v20 = p17.spec_attacherJointControl
		for _, v21 in ipairs(v20.controls) do
			p17:controlAttacherJoint(v21, streamReadUIntN(p18, AttacherJointControl.ALPHA_NUM_BITS) / AttacherJointControl.ALPHA_MAX_VALUE, false, true)
		end
	end
end
function AttacherJointControl.onWriteStream(p22, p23, p24)
	if not p24:getIsServer() then
		local v25 = p22.spec_attacherJointControl
		if streamWriteBool(p23, v25.jointDesc ~= nil) then
			for _, v26 in ipairs(v25.controls) do
				streamWriteUIntN(p23, v26.moveAlpha * AttacherJointControl.ALPHA_MAX_VALUE, AttacherJointControl.ALPHA_NUM_BITS)
			end
		end
	end
end
function AttacherJointControl.onReadUpdateStream(p27, p28, _, p29)
	local v30 = p27.spec_attacherJointControl
	if p29:getIsServer() then
		if streamReadBool(p28) then
			for _, v31 in ipairs(v30.controls) do
				p27:controlAttacherJoint(v31, streamReadUIntN(p28, AttacherJointControl.ALPHA_NUM_BITS) / AttacherJointControl.ALPHA_MAX_VALUE, false, true)
			end
		end
	elseif streamReadBool(p28) then
		for _, v32 in ipairs(v30.controls) do
			p27:controlAttacherJoint(v32, streamReadUIntN(p28, AttacherJointControl.ALPHA_NUM_BITS) / AttacherJointControl.ALPHA_MAX_VALUE, false, true)
		end
		return
	end
end
function AttacherJointControl.onWriteUpdateStream(p33, p34, p35, p36)
	local v37 = p33.spec_attacherJointControl
	if p35:getIsServer() then
		if streamWriteBool(p34, bitAND(p36, v37.dirtyFlagClient) ~= 0) then
			for _, v38 in ipairs(v37.controls) do
				streamWriteUIntN(p34, v38.moveAlpha * AttacherJointControl.ALPHA_MAX_VALUE, AttacherJointControl.ALPHA_NUM_BITS)
			end
			return
		end
	elseif streamWriteBool(p34, bitAND(p36, v37.dirtyFlagServer) ~= 0) then
		for _, v39 in ipairs(v37.controls) do
			streamWriteUIntN(p34, v39.moveAlpha * AttacherJointControl.ALPHA_MAX_VALUE, AttacherJointControl.ALPHA_NUM_BITS)
		end
	end
end
function AttacherJointControl.onUpdate(p40, p41, _, _, _)
	local v42 = p40.spec_attacherJointControl
	local v43 = v42.heightController
	if v43 ~= nil and v42.jointDesc ~= nil then
		if v42.heightTargetAlpha ~= -1 then
			local v44 = v42.heightTargetAlpha - v43.moveAlpha + 0.0001
			local v45 = p41 / (v44 / (v42.jointDesc.upperAlpha - v42.jointDesc.lowerAlpha) * v42.jointDesc.moveTime) * v44
			if v44 > 0 then
				v45 = -v45
			end
			local v46 = v43.moveAlpha + v45
			p40:controlAttacherJoint(v43, v46, v42.nextHeightDampingUpdateTime < g_time, true)
			local v47 = v42.heightTargetAlpha - v46
			if math.abs(v47) < 0.01 then
				v42.heightTargetAlpha = -1
			end
		end
		if p40.isServer and (v42.supportsDamping and v42.nextHeightDampingUpdateTime < g_time) then
			local v48 = p40:getActiveInputAttacherJoint()
			local v49 = 0
			if p40:getIsAttacherJointControlDampingAllowed() then
				local v50, v51, v52 = getWorldTranslation(v48.node)
				local v53, _, v54 = localDirectionToWorld(v48.node, v42.dampingOffset, 0, 0)
				local v55, v56, v57 = worldToLocal(p40.components[1].node, v50 + v53, v51, v52 + v54)
				local _, v58, _ = getVelocityAtLocalPos(p40.components[1].node, v55, v56, v57)
				if math.abs(v58) > 0.15 then
					v49 = v58 * 0.5
				end
			else
				v49 = v43.moveAlphaLastManual - v43.moveAlpha
			end
			local v59 = v49 + (v43.moveAlphaLastManual - v43.moveAlpha) * 0.001 * p41
			if math.abs(v59) > 0.0001 then
				local v60 = v43.moveAlpha + v59
				v42.heightTargetAlpha = math.clamp(v60, 0, 1)
				if v42.heightTargetAlpha <= 0 and v42.tiltController ~= nil then
					local v61 = v42.tiltController
					local v62 = v42.tiltController.moveAlpha - v59 * 0.1
					p40:controlAttacherJoint(v61, math.clamp(v62, 0, 1), true)
				end
			end
		end
	end
	if v42.lastMoveTime + 100 > g_time then
		if not g_soundManager:getIsSamplePlaying(v42.samples.hydraulic) then
			g_soundManager:playSample(v42.samples.hydraulic)
			return
		end
	elseif g_soundManager:getIsSamplePlaying(v42.samples.hydraulic) then
		g_soundManager:stopSample(v42.samples.hydraulic)
	end
end
function AttacherJointControl.controlAttacherJoint(p63, p64, p65, p66, p67)
	local v68 = p63.spec_attacherJointControl
	local v69 = v68.jointDesc
	if p63.isServer and v69 ~= nil then
		p65 = p64.func(p63, p65)
		p63:getAttacherVehicle():updateAttacherJointRotation(v69, p63)
		if v69.jointIndex ~= 0 then
			setJointFrame(v69.jointIndex, 0, v69.jointTransform)
		end
	end
	v68.lastMoveTime = g_time
	if not p66 then
		v68.nextHeightDampingUpdateTime = g_time + 100
		p64.moveAlphaLastManual = p64.moveAlpha
	end
	local v70 = math.max(p65, 0)
	p64.moveAlpha = math.min(v70, 1)
	if p67 == nil or not p67 then
		local v71 = p64.moveAlphaSent - p65
		if math.abs(v71) > 1 / AttacherJointControl.ALPHA_MAX_VALUE then
			p64.moveAlphaSent = p65
			if p63.isServer then
				p63:raiseDirtyFlags(v68.dirtyFlagServer)
			else
				p63:raiseDirtyFlags(v68.dirtyFlagClient)
			end
		end
	else
		p64.moveAlphaSent = p65
	end
end
function AttacherJointControl.controlAttacherJointHeight(p72, p73)
	local v74 = p72.spec_attacherJointControl
	local v75 = v74.jointDesc
	if p73 == nil then
		p73 = v75.moveAlpha
	end
	local v76 = v75.upperAlpha
	local v77 = v75.lowerAlpha
	local v78 = math.clamp(p73, v76, v77)
	p72:updateAttacherJointRotationNodes(v75, v78)
	v75.moveAlpha = v78
	p72:updateAttacherJointRotation(v75, p72)
	v74.lastHeightAlpha = v78
	return v78
end
function AttacherJointControl.controlAttacherJointTilt(p79, p80)
	local v81 = p79.spec_attacherJointControl
	local v82 = p80 == nil and 0.5 or p80
	local v83 = math.clamp(v82, 0, 1)
	local v84 = v81.maxTiltAngle * -(v83 - 0.5)
	v81.jointDesc.upperRotationOffset = v81.jointDesc.upperRotationOffsetBackup + v84
	v81.jointDesc.lowerRotationOffset = v81.jointDesc.lowerRotationOffsetBackup + v84
	return v83
end
function AttacherJointControl.getControlAttacherJointDirection(p85)
	local v86 = p85.spec_attacherJointControl
	if v86.heightTargetAlpha ~= -1 then
		return v86.heightTargetAlpha == v86.jointDesc.upperAlpha
	end
	local v87 = v86.heightController.moveAlpha
	local v88 = v87 - v86.jointDesc.lowerAlpha
	local v89 = math.abs(v88)
	local v90 = v87 - v86.jointDesc.upperAlpha
	return math.abs(v90) < v89
end
function AttacherJointControl.getIsAttacherJointControlDampingAllowed(p91)
	if p91:getAttacherVehicle():getLastSpeed() < 0.5 then
		return false
	else
		return p91.movingDirection > 0
	end
end
function AttacherJointControl.loadInputAttacherJoint(p92, p93, p94, p95, p96, p97)
	if not p93(p92, p94, p95, p96, p97) then
		return false
	end
	p96.isControllable = p94:getValue(p95 .. "#isControllable", false)
	return true
end
function AttacherJointControl.registerLoweringActionEvent(p98, p99, p100, p101, p102, p103, p104, p105, p106, p107, p108, p109)
	if p98.spec_attacherJointControl.heightController then
		local _, v110 = p98:addPoweredActionEvent(p100, InputAction.LOWER_IMPLEMENT, p98, AttacherJointControl.actionEventAttacherJointControlSetPoint, p104, p105, p106, p107, p108, p109)
		g_inputBinding:setActionEventTextPriority(v110, GS_PRIO_HIGH)
		if p101 == InputAction.LOWER_IMPLEMENT then
			return
		end
	end
	p99(p98, p100, p101, p102, p103, p104, p105, p106, p107, p108, p109)
end
function AttacherJointControl.getLoweringActionEventState(p111, p112)
	local v113 = p111.spec_attacherJointControl
	if not v113.heightController then
		return p112(p111)
	end
	local v114 = v113.jointDesc ~= nil
	local v115
	if v114 then
		if p111:getControlAttacherJointDirection() then
			return v114, string.format(g_i18n:getText("action_lowerOBJECT"), p111.typeDesc)
		end
		v115 = string.format(g_i18n:getText("action_liftOBJECT"), p111.typeDesc)
	else
		v115 = nil
	end
	return v114, v115
end
function AttacherJointControl.getCanBeSelected(_, _)
	return true
end
function AttacherJointControl.onRegisterActionEvents(p116, _, p117)
	if p116.isClient then
		local v118 = p116.spec_attacherJointControl
		p116:clearActionEventsTable(v118.actionEvents)
		if p117 and v118.jointDesc ~= nil then
			for _, v119 in ipairs(v118.controls) do
				local _, v120 = p116:addPoweredActionEvent(v118.actionEvents, v119.controlAction, p116, AttacherJointControl.actionEventAttacherJointControl, false, false, true, true, nil, v119.axisActionIcon)
				g_inputBinding:setActionEventTextPriority(v120, GS_PRIO_NORMAL)
			end
		end
	end
end
function AttacherJointControl.onPostAttach(p121, p122, p123, p124, p125)
	local v126 = p121.spec_attacherJointControl
	local v127 = p121:getInputAttacherJoints()
	if v127[p123] ~= nil and v127[p123].isControllable then
		local v128 = p122:getAttacherJoints()[p124]
		if v128.allowsLoweringBackup == nil then
			v128.allowsLoweringBackup = v128.allowsLowering
		end
		v128.allowsLowering = false
		v128.upperRotationOffsetBackup = v128.upperRotationOffset
		v128.lowerRotationOffsetBackup = v128.lowerRotationOffset
		v126.jointDesc = v128
		for _, v129 in ipairs(v126.controls) do
			v129.moveAlpha = v129.func(p121)
		end
		if p125 then
			if v126.heightController ~= nil then
				p121:controlAttacherJoint(v126.heightController, v126.jointDesc.upperAlpha, false)
			end
		else
			v126.heightTargetAlpha = v126.jointDesc.upperAlpha
		end
		p121:requestActionEventUpdate()
	end
end
function AttacherJointControl.onPreDetach(p130, _, _)
	local v131 = p130.spec_attacherJointControl
	if v131.jointDesc ~= nil then
		v131.jointDesc.allowsLowering = v131.jointDesc.allowsLoweringBackup
		v131.jointDesc.upperRotationOffset = v131.jointDesc.upperRotationOffsetBackup
		v131.jointDesc.lowerRotationOffset = v131.jointDesc.lowerRotationOffsetBackup
		v131.jointDesc = nil
	end
end
function AttacherJointControl.actionEventAttacherJointControl(p132, p133, p134, _, _)
	if math.abs(p134) > 0 then
		local v135 = p132.spec_attacherJointControl
		local v136 = v135.nameToControl[p133]
		local v137 = p134 * v136.mouseSpeedFactor * 0.025
		if v136.invertAxis then
			v137 = -v137
		end
		p132:controlAttacherJoint(v136, v136.moveAlpha + v137, false)
		v135.heightTargetAlpha = -1
	end
end
function AttacherJointControl.actionEventAttacherJointControlSetPoint(p138, _, _, _, _)
	local v139 = p138.spec_attacherJointControl
	if v139.jointDesc ~= nil then
		if p138:getControlAttacherJointDirection() then
			v139.heightTargetAlpha = v139.jointDesc.lowerAlpha
		else
			v139.heightTargetAlpha = v139.jointDesc.upperAlpha
		end
		v139.nextHeightDampingUpdateTime = g_time + v139.jointDesc.moveTime
	end
end

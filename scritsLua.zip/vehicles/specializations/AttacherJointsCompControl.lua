AttacherJointsCompControl = {}
function AttacherJointsCompControl.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AttacherJoints, p1)
end
function AttacherJointsCompControl.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("AttacherJointsCompControl")
	v2:addDelayedRegistrationFunc("AttacherJoint", function(p3, p4)
		p3:register(XMLValueType.INT, p4 .. ".dependentComponentJoint#index", "Index of component joint that will be adjusted while something is attached")
		p3:register(XMLValueType.FLOAT, p4 .. ".dependentComponentJoint#transSpringFactor", "Factor that will be applied to the spring values on attach", 1)
		p3:register(XMLValueType.FLOAT, p4 .. ".dependentComponentJoint#transDampingFactor", "Factor that will be applied to the damping values on attach", "#transSpringFactor")
		p3:register(XMLValueType.FLOAT, p4 .. ".dependentComponentJoint#referenceMass", "Reference mass for spring and damping adjustments. At the mass attached to the front, the full factor will be applied to the spring/damping. (to)", 1)
		p3:register(XMLValueType.TIME, p4 .. ".dependentComponentJoint#attachInterpolationTime", "Time for the interpolation between the damping values after attach", 1)
		p3:register(XMLValueType.TIME, p4 .. ".dependentComponentJoint#detachInterpolationTime", "Time for the interpolation between the damping values after detach", 0.5)
	end)
	v2:setXMLSpecializationType()
end
function AttacherJointsCompControl.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "setDependentComponentJointBaseFactors", AttacherJointsCompControl.setDependentComponentJointBaseFactors)
	SpecializationUtil.registerFunction(p5, "addDependentComponentJointData", AttacherJointsCompControl.addDependentComponentJointData)
	SpecializationUtil.registerFunction(p5, "updateDependentComponentJointValues", AttacherJointsCompControl.updateDependentComponentJointValues)
end
function AttacherJointsCompControl.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "addToPhysics", AttacherJointsCompControl.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p6, "loadAttacherJointFromXML", AttacherJointsCompControl.loadAttacherJointFromXML)
end
function AttacherJointsCompControl.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onPreLoad", AttacherJointsCompControl)
	SpecializationUtil.registerEventListener(p7, "onStateChange", AttacherJointsCompControl)
end
function AttacherJointsCompControl.onPreLoad(p8, _)
	p8.spec_attacherJointsCompControl.dependentComponentJointData = {}
	if not p8.isServer then
		SpecializationUtil.removeEventListener(p8, "onStateChange", AttacherJointsCompControl)
	end
end
function AttacherJointsCompControl.onStateChange(p9, p10, _)
	if p10 == VehicleStateChange.ATTACH or p10 == VehicleStateChange.DETACH then
		p9:updateDependentComponentJointValues()
	end
end
function AttacherJointsCompControl.setDependentComponentJointBaseFactors(p11, p12, p13, p14)
	local v15 = p11:addDependentComponentJointData(p12)
	if v15 ~= nil then
		v15.baseTransSpringFactor = v15.baseTransSpringFactor * p13 or 1
		v15.baseTransDampingFactor = v15.baseTransDampingFactor * p14 or 1
	end
end
function AttacherJointsCompControl.addDependentComponentJointData(p16, p17)
	if p17 == nil then
		return nil
	end
	local v_u_18 = p16.componentJoints[p17]
	if v_u_18 == nil then
		Logging.xmlWarning(p16.xmlFile, "Unknown component joint index \'%s\' in dependentComponentJoint", p17)
		return nil
	end
	local v19 = p16.spec_attacherJointsCompControl
	local v20 = "dependentComponentJoint_" .. getName(v_u_18.jointNode)
	if v19.dependentComponentJointData[v20] == nil then
		local v_u_24 = {
			["interpolatorKey"] = v20,
			["baseTransSpringFactor"] = 1,
			["baseTransDampingFactor"] = 1,
			["curTransSpringFactor"] = 1,
			["curTransDampingFactor"] = 1,
			["targetTransSpringFactor"] = 1,
			["targetTransDampingFactor"] = 1,
			["attachInterpolationTime"] = 1,
			["detachInterpolationTime"] = 0.5,
			["interpolatorGet"] = function()
				-- upvalues: (copy) v_u_24
				return v_u_24.curTransSpringFactor, v_u_24.curTransDampingFactor
			end,
			["interpolatorSet"] = function(p21, p22)
				-- upvalues: (copy) v_u_24, (copy) v_u_18
				v_u_24.curTransSpringFactor = p21
				v_u_24.curTransDampingFactor = p22
				for v23 = 1, 3 do
					setJointTranslationLimitSpring(v_u_18.jointIndex, v23 - 1, v_u_18.transLimitSpring[v23] * p21, v_u_18.transLimitDamping[v23] * p22)
				end
			end
		}
		v19.dependentComponentJointData[v20] = v_u_24
	end
	return v19.dependentComponentJointData[v20]
end
function AttacherJointsCompControl.updateDependentComponentJointValues(p25, p26, p27)
	local v28 = p25.spec_attacherJointsCompControl
	for _, v29 in pairs(v28.dependentComponentJointData) do
		v29.targetTransSpringFactor = v29.baseTransSpringFactor
		v29.targetTransDampingFactor = v29.baseTransDampingFactor
	end
	for v30, v31 in ipairs(p25:getAttacherJoints()) do
		local v32 = p25:getImplementByJointDescIndex(v30)
		local v33 = v32 == nil and 0 or v32.object:getTotalMass()
		if v31.dependentComponentJoint ~= nil then
			local v34 = v31.dependentComponentJoint.data
			local v35 = v33 / v31.dependentComponentJoint.referenceMass
			local v36 = math.min(v35, 1)
			local v37 = (v31.dependentComponentJoint.transSpringFactor - 1) * v36 + 1
			local v38 = (v31.dependentComponentJoint.transDampingFactor - 1) * v36 + 1
			v34.targetTransSpringFactor = v34.targetTransSpringFactor + (v37 - 1)
			v34.targetTransDampingFactor = v34.targetTransDampingFactor + (v38 - 1)
		end
	end
	for v39, v40 in pairs(v28.dependentComponentJointData) do
		if v40.targetTransSpringFactor ~= v40.curTransSpringFactor or (v40.targetTransDampingFactor ~= v40.curTransDampingFactor or p26) then
			local v41 = v40.attachInterpolationTime
			if v40.targetTransSpringFactor <= v40.baseTransSpringFactor + 0.001 and v40.targetTransDampingFactor <= v40.targetTransDampingFactor + 0.001 then
				v41 = v40.detachInterpolationTime
			end
			if p27 then
				v40.interpolatorSet(v40.targetTransSpringFactor, v40.targetTransDampingFactor)
			else
				local v42 = ValueInterpolator.new(v39, v40.interpolatorGet, v40.interpolatorSet, { v40.targetTransSpringFactor, v40.targetTransDampingFactor }, v41)
				if v42 ~= nil then
					v42:setDeleteListenerObject(p25)
				end
			end
		end
	end
end
function AttacherJointsCompControl.addToPhysics(p43, p44)
	if not p44(p43) then
		return false
	end
	p43:updateDependentComponentJointValues(true, true)
	return true
end
function AttacherJointsCompControl.loadAttacherJointFromXML(p45, p46, p47, p48, p49, p50)
	if not p46(p45, p47, p48, p49, p50) then
		return false
	end
	if p45.isServer then
		local v51 = p48:getValue(p49 .. ".dependentComponentJoint#index")
		if v51 ~= nil then
			local v52 = p45:addDependentComponentJointData(v51)
			if v52 ~= nil then
				v52.attachInterpolationTime = p48:getValue(p49 .. ".dependentComponentJoint#attachInterpolationTime", v52.attachInterpolationTime)
				v52.detachInterpolationTime = p48:getValue(p49 .. ".dependentComponentJoint#detachInterpolationTime", v52.detachInterpolationTime)
				p47.dependentComponentJoint = {}
				p47.dependentComponentJoint.data = v52
				p47.dependentComponentJoint.transSpringFactor = p48:getValue(p49 .. ".dependentComponentJoint#transSpringFactor", 1)
				p47.dependentComponentJoint.transDampingFactor = p48:getValue(p49 .. ".dependentComponentJoint#transDampingFactor", p47.dependentComponentJoint.transSpringFactor)
				p47.dependentComponentJoint.referenceMass = p48:getValue(p49 .. ".dependentComponentJoint#referenceMass", 1)
			end
		end
	end
	return true
end
function AttacherJointsCompControl.updateDebugValues(p53, p54)
	local v55 = p53.spec_attacherJointsCompControl
	for v56, v57 in ipairs(p53:getAttacherJoints()) do
		local v58 = p53:getImplementByJointDescIndex(v56)
		local v59 = v58 == nil and 0 or v58.object:getTotalMass()
		if v57.dependentComponentJoint ~= nil then
			local v60 = {
				["name"] = "Attacher Joint",
				["value"] = tostring(v56)
			}
			table.insert(p54, v60)
			local v61 = v59 / v57.dependentComponentJoint.referenceMass
			local v62 = math.min(v61, 1)
			local v63 = (v57.dependentComponentJoint.transSpringFactor - 1) * v62 + 1
			local v64 = (v57.dependentComponentJoint.transDampingFactor - 1) * v62 + 1
			local v65 = {
				["name"] = "Mass",
				["value"] = string.format("%.2f / %.2f to", v59, v57.dependentComponentJoint.referenceMass)
			}
			table.insert(p54, v65)
			local v66 = {
				["name"] = "Spring Factors",
				["value"] = string.format("spring %.2f damping %.2f", v63, v64)
			}
			table.insert(p54, v66)
		end
	end
	for v67, v68 in pairs(v55.dependentComponentJointData) do
		table.insert(p54, {
			["name"] = "Component Joint",
			["value"] = v67
		})
		local v69 = {
			["name"] = "Base Factors",
			["value"] = string.format("spring %.2f damping %.2f", v68.baseTransSpringFactor, v68.baseTransDampingFactor)
		}
		table.insert(p54, v69)
		local v70 = {
			["name"] = "Current Factors",
			["value"] = string.format("spring %.2f damping %.2f", v68.curTransSpringFactor, v68.curTransDampingFactor)
		}
		table.insert(p54, v70)
	end
end

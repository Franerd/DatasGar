SlopeCompensation = {}
SlopeCompensation.SLOPE_COLLISION_MASK = CollisionFlag.STATIC_OBJECT + CollisionFlag.TERRAIN + CollisionFlag.TERRAIN_DELTA
function SlopeCompensation.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Wheels, p1)
end
function SlopeCompensation.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("slopeCompensation", g_i18n:getText("shop_configuration"), "slopeCompensation", VehicleConfigurationItem)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("SlopeCompensation")
	SlopeCompensation.registerXMLPaths(v2, "vehicle.slopeCompensation")
	SlopeCompensation.registerXMLPaths(v2, "vehicle.slopeCompensation.slopeCompensationConfigurations.slopeCompensationConfiguration(?)")
	v2:addDelayedRegistrationFunc("AnimatedVehicle:part", function(p3, p4)
		p3:register(XMLValueType.INT, p4 .. "#slopeCompensationNodeIndex", "Index in the XML of the slope compensation node")
		p3:register(XMLValueType.FLOAT, p4 .. "#startSlopeCompensationLevel", "Start slope compensation level")
		p3:register(XMLValueType.FLOAT, p4 .. "#endSlopeCompensationLevel", "End slope compensation level")
	end)
	v2:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.ANGLE, "vehicles.vehicle(?).slopeCompensation.compensationNode(?)#lastAngle", "Last angle of compensation node")
end
function SlopeCompensation.registerXMLPaths(p5, p6)
	p5:register(XMLValueType.ANGLE, p6 .. "#threshold", "Update threshold for animation", 0.1)
	p5:register(XMLValueType.BOOL, p6 .. "#highUpdateFrequency", "Defines if the angle is updated every frame or every seconds frame", false)
	local v7 = p6 .. ".compensationNode(?)"
	p5:addDelayedRegistrationPath(v7, "SlopeCompensation:compensationNode")
	p5:register(XMLValueType.INT, v7 .. "#wheel1", "Wheel index 1")
	p5:register(XMLValueType.INT, v7 .. "#wheel2", "Wheel index 2")
	p5:register(XMLValueType.NODE_INDEX, v7 .. "#wheelNode1", "Wheel node 1")
	p5:register(XMLValueType.NODE_INDEX, v7 .. "#wheelNode2", "Wheel node 2")
	p5:register(XMLValueType.NODE_INDICES, v7 .. "#wheelNodes1", "List of wheel nodes 1 (center of all nodes will be used for detection)")
	p5:register(XMLValueType.NODE_INDICES, v7 .. "#wheelNodes2", "List of wheel nodes 2 (center of all nodes will be used for detection)")
	p5:register(XMLValueType.ANGLE, v7 .. "#maxAngle", "Max. angle", 5)
	p5:register(XMLValueType.ANGLE, v7 .. "#minAngle", "Min. angle", "Negative #maxAngle")
	p5:register(XMLValueType.ANGLE, v7 .. "#speed", "Move speed (degree/sec)", 5)
	p5:register(XMLValueType.BOOL, v7 .. "#inverted", "Inverted rotation", false)
	p5:register(XMLValueType.FLOAT, v7 .. "#inActiveHeight", "Height while the compensation node is not active", 0)
	p5:register(XMLValueType.FLOAT, v7 .. "#initialHeight", "Height while the componensation node is active and the vehicle is fully leveled", 1)
	p5:register(XMLValueType.STRING, v7 .. "#animationName", "Animation name")
	p5:register(XMLValueType.NODE_INDEX, v7 .. "#referenceNode", "Node that is used to detect the current angle")
	p5:register(XMLValueType.INT, v7 .. "#referenceAxis", "Reference angle detection axis", 1)
	p5:register(XMLValueType.NODE_INDEX, v7 .. "#rotationNode", "Node that is rotated based on the slope angle")
	p5:register(XMLValueType.INT, v7 .. "#rotationAxis", "Rotation axis on which the rotationNode is rotated", 1)
	p5:register(XMLValueType.NODE_INDEX, v7 .. ".animationPart(?)#node", "Node that is adjusted")
	p5:register(XMLValueType.BOOL, v7 .. ".animationPart(?)#isLeft", "Is left or right side node")
	p5:register(XMLValueType.VECTOR_ROT, v7 .. ".animationPart(?)#rotMin", "Min. rotation")
	p5:register(XMLValueType.VECTOR_ROT, v7 .. ".animationPart(?)#rotMax", "Max. rotation")
	p5:register(XMLValueType.VECTOR_TRANS, v7 .. ".animationPart(?)#transMin", "Min. translation")
	p5:register(XMLValueType.VECTOR_TRANS, v7 .. ".animationPart(?)#transMax", "Max. translation")
end
function SlopeCompensation.registerFunctions(p8)
	SpecializationUtil.registerFunction(p8, "loadSlopeCompensationWheels", SlopeCompensation.loadSlopeCompensationWheels)
	SpecializationUtil.registerFunction(p8, "loadSlopeCompensationNodeFromXML", SlopeCompensation.loadSlopeCompensationNodeFromXML)
	SpecializationUtil.registerFunction(p8, "getSlopeCompensationAngle", SlopeCompensation.getSlopeCompensationAngle)
	SpecializationUtil.registerFunction(p8, "getSlopeCompensationAngleScale", SlopeCompensation.getSlopeCompensationAngleScale)
	SpecializationUtil.registerFunction(p8, "getSlopeCompensationGroundPosition", SlopeCompensation.getSlopeCompensationGroundPosition)
	SpecializationUtil.registerFunction(p8, "slopeCompensationDetectionCallback", SlopeCompensation.slopeCompensationDetectionCallback)
	SpecializationUtil.registerFunction(p8, "setSlopeCompensationNodeAngle", SlopeCompensation.setSlopeCompensationNodeAngle)
end
function SlopeCompensation.registerEventListeners(p9)
	SpecializationUtil.registerEventListener(p9, "onLoad", SlopeCompensation)
	SpecializationUtil.registerEventListener(p9, "onLoadFinished", SlopeCompensation)
	SpecializationUtil.registerEventListener(p9, "onUpdate", SlopeCompensation)
	SpecializationUtil.registerEventListener(p9, "onUpdateTick", SlopeCompensation)
	SpecializationUtil.registerEventListener(p9, "onRegisterAnimationValueTypes", SlopeCompensation)
end
function SlopeCompensation.onLoad(p10, _)
	local v11 = p10.spec_slopeCompensation
	v11.threshold = p10.xmlFile:getValue("vehicle.slopeCompensation#threshold", 0.002)
	v11.highUpdateFrequency = p10.xmlFile:getValue("vehicle.slopeCompensation#highUpdateFrequency", false)
	v11.lastRaycastDistance = 0
	v11.compensationNodes = {}
	for _, v12 in p10.xmlFile:iterator("vehicle.slopeCompensation.compensationNode") do
		local v13 = {}
		if p10:loadSlopeCompensationNodeFromXML(v13, p10.xmlFile, v12) then
			local v14 = v11.compensationNodes
			table.insert(v14, v13)
		end
	end
	local v15 = p10.configurations.slopeCompensation or 1
	local v16 = string.format("vehicle.slopeCompensation.slopeCompensationConfigurations.slopeCompensationConfiguration(%d)", v15 - 1)
	if p10.xmlFile:hasProperty(v16) then
		for _, v17 in p10.xmlFile:iterator(v16 .. ".compensationNode") do
			local v18 = {}
			if p10:loadSlopeCompensationNodeFromXML(v18, p10.xmlFile, v17) then
				local v19 = v11.compensationNodes
				table.insert(v19, v18)
			end
		end
		v11.threshold = p10.xmlFile:getValue(v16 .. "#threshold", v11.threshold)
		v11.highUpdateFrequency = p10.xmlFile:getValue(v16 .. "#highUpdateFrequency", v11.highUpdateFrequency)
	end
	if #v11.compensationNodes == 0 then
		SpecializationUtil.removeEventListener(p10, "onLoadFinished", SlopeCompensation)
		SpecializationUtil.removeEventListener(p10, "onUpdate", SlopeCompensation)
		SpecializationUtil.removeEventListener(p10, "onUpdateTick", SlopeCompensation)
		return
	elseif v11.highUpdateFrequency then
		SpecializationUtil.removeEventListener(p10, "onUpdateTick", SlopeCompensation)
	else
		SpecializationUtil.removeEventListener(p10, "onUpdate", SlopeCompensation)
	end
end
function SlopeCompensation.onLoadFinished(p20, p21)
	local v22 = p20.spec_slopeCompensation
	for _, v23 in ipairs(v22.compensationNodes) do
		if v23.animationName ~= nil then
			local v24 = p20:getSlopeCompensationAngleScale(v23) > 0
			p20:setAnimationTime(v23.animationName, 0, v24)
			p20:setAnimationTime(v23.animationName, 1, v24)
			p20:setAnimationTime(v23.animationName, 0.5, v24)
		end
	end
	if p21 == nil then
		for _, v25 in ipairs(v22.compensationNodes) do
			p20:setSlopeCompensationNodeAngle(v25, 0)
		end
	else
		for v26, v27 in ipairs(v22.compensationNodes) do
			p20:setSlopeCompensationNodeAngle(v27, (p21.xmlFile:getValue(string.format("%s.slopeCompensation.compensationNode(%d)#lastAngle", p21.key, v26 - 1), 0)))
		end
	end
end
function SlopeCompensation.saveToXMLFile(p28, p29, p30, _)
	local v31 = p28.spec_slopeCompensation
	for v32, v33 in ipairs(v31.compensationNodes) do
		p29:setValue(string.format("%s.compensationNode(%d)#lastAngle", p30, v32 - 1), v33.lastAngle)
	end
end
function SlopeCompensation.onUpdate(p34, p35, _, _, _)
	local v36 = p34.spec_slopeCompensation
	for _, v37 in ipairs(v36.compensationNodes) do
		local v38 = p34:getSlopeCompensationAngle(v37)
		local v39 = v37.minAngle
		local v40 = v37.maxAngle
		local v41 = math.clamp(v38, v39, v40) * p34:getSlopeCompensationAngleScale(v37)
		if v37.inverted then
			v41 = -v41
		end
		local v42 = v37.targetAngle - v41
		if math.abs(v42) > v36.threshold then
			v37.targetAngle = v41
		end
		local v43 = v37.targetAngle - v37.lastAngle
		local v44 = math.sign(v43)
		local v45 = v44 > 0 and math.min or math.max
		local v46 = v37.lastAngle - v41
		local v47 = math.abs(v46) / (v37.speed * 1000)
		local v48 = math.max(v47, 0.2)
		local v49 = math.min(v48, 1)
		local v50 = v45(v37.lastAngle + v37.speed * p35 * v44 * v49, v37.targetAngle)
		if v50 ~= v37.lastAngle then
			p34:setSlopeCompensationNodeAngle(v37, v50)
		end
	end
end
function SlopeCompensation.onUpdateTick(p51, p52, p53, p54, p55)
	SlopeCompensation.onUpdate(p51, p52, p53, p54, p55)
end
function SlopeCompensation.onRegisterAnimationValueTypes(p_u_56)
	p_u_56:registerAnimationValueType("slopeCompensationLevel", "startSlopeCompensationLevel", "endSlopeCompensationLevel", false, AnimationValueFloat, function(p57, p58, p59)
		p57.slopeCompensationNodeIndex = p58:getValue(p59 .. "#slopeCompensationNodeIndex")
		if p57.slopeCompensationNodeIndex == nil then
			return false
		end
		local v60 = p57.slopeCompensationNodeIndex
		p57:setWarningInformation("index: " .. tostring(v60))
		p57:addCompareParameters("slopeCompensationNodeIndex")
		return true
	end, function(p61)
		if p61.slopeCompensationNode == nil then
			local v62 = p61.vehicle.spec_slopeCompensation.compensationNodes[p61.slopeCompensationNodeIndex]
			if v62 == nil then
				Logging.xmlWarning(p61.xmlFile, "Could not update slope compensation node level. No slope compensation node with index %d found!", p61.slopeCompensationNodeIndex)
				p61.startValue = nil
				return 0
			end
			p61.slopeCompensationNode = v62
		end
		return p61.slopeCompensationNode.compensationLevel
	end, function(p63, p64)
		-- upvalues: (copy) p_u_56
		if p63.slopeCompensationNode ~= nil then
			p63.slopeCompensationNode.compensationLevel = p64
			p_u_56:setSlopeCompensationNodeAngle(p63.slopeCompensationNode, p63.slopeCompensationNode.lastAngle)
		end
	end)
end
function SlopeCompensation.loadSlopeCompensationWheels(p65, _, p66, p67, p68, p69)
	local v70 = 0
	local v71 = {}
	local v72 = p65.xmlFile:getValue(p66 .. "#" .. p67)
	if v72 ~= nil then
		local v73 = p65:getWheelFromWheelIndex(v72)
		if v73 == nil then
			Logging.xmlWarning(p65.xmlFile, "Unable to find wheel index \'%d\' for compensation node \'%s\'", v72, p66)
			return false
		end
		local v74 = v73.physics.radius
		v70 = math.max(v70, v74)
		local v75 = v73.driveNode
		table.insert(v71, v75)
	end
	local v76 = p65.xmlFile:getValue(p66 .. "#" .. p68, nil, p65.components, p65.i3dMappings)
	if v76 ~= nil then
		local v77 = p65:getWheelByWheelNode(v76)
		if v77 == nil then
			Logging.xmlWarning(p65.xmlFile, "Unable to find wheel for node \'%s\' for compensation node \'%s\'", getName(v76), p66)
			return false
		end
		local v78 = v77.physics.radius
		v70 = math.max(v70, v78)
		local v79 = v77.driveNode
		table.insert(v71, v79)
	end
	local v80 = p65.xmlFile:getValue(p66 .. "#" .. p69, nil, p65.components, p65.i3dMappings, true)
	if v80 ~= nil then
		for _, v81 in ipairs(v80) do
			local v82 = p65:getWheelByWheelNode(v81)
			if v82 == nil then
				Logging.xmlWarning(p65.xmlFile, "Unable to find wheel for node \'%s\' for compensation node \'%s\'", getName(v81), p66)
				return false
			end
			local v83 = v82.physics.radius
			v70 = math.max(v70, v83)
			local v84 = v82.driveNode
			table.insert(v71, v84)
		end
	end
	if #v71 == 0 then
		return false
	else
		return true, v71, v70
	end
end
function SlopeCompensation.loadSlopeCompensationNodeFromXML(p85, p86, p87, p88)
	p86.useWheelReference = false
	p86.raycastDistance = 0
	p86.lastDistance1 = 0
	p86.lastDistance2 = 0
	local v89, v90, v91 = p85:loadSlopeCompensationWheels(p87, p88, "wheel1", "wheelNode1", "wheelNodes1")
	local v92, v93, v94 = p85:loadSlopeCompensationWheels(p87, p88, "wheel2", "wheelNode2", "wheelNodes2")
	if v89 and v92 then
		p86.wheelNodes1 = v90
		p86.wheelNodes2 = v93
		local v95 = v91 + 1
		local v96 = v94 + 1
		p86.raycastDistance = math.max(v95, v96)
		p86.useWheelReference = true
	end
	p86.referenceNode = p85.xmlFile:getValue(p88 .. "#referenceNode", nil, p85.components, p85.i3dMappings)
	p86.referenceAxis = p85.xmlFile:getValue(p88 .. "#referenceAxis", 1)
	p86.rotationNode = p85.xmlFile:getValue(p88 .. "#rotationNode", nil, p85.components, p85.i3dMappings)
	p86.rotationAxis = p85.xmlFile:getValue(p88 .. "#rotationAxis", 1)
	if p86.rotationNode ~= nil then
		p86.rotationNodeRotation = { getRotation(p86.rotationNode) }
	end
	p86.maxAngle = p85.xmlFile:getValue(p88 .. "#maxAngle", 5)
	local v97 = p85.xmlFile
	local v98 = p88 .. "#minAngle"
	local v99 = p86.maxAngle
	p86.minAngle = v97:getValue(v98, -math.deg(v99))
	p86.speed = p85.xmlFile:getValue(p88 .. "#speed", 5) / 1000
	p86.inverted = p85.xmlFile:getValue(p88 .. "#inverted", false)
	if p86.minAngle > p86.maxAngle then
		local v100 = p86.maxAngle
		local v101 = p86.minAngle
		p86.minAngle = v100
		p86.maxAngle = v101
		p86.inverted = true
	end
	p86.targetAngle = 0
	p86.lastAngle = 0
	p86.animationName = p85.xmlFile:getValue(p88 .. "#animationName")
	p86.inActiveHeight = p87:getValue(p88 .. "#inActiveHeight", 0)
	local v102 = p87:getValue(p88 .. "#initialHeight", 1)
	p86.initialHeightOffset = 1 - math.clamp(v102, 0, 1)
	p86.compensationLevel = 1
	p86.animationParts = {}
	for _, v103 in p87:iterator(p88 .. ".animationPart") do
		local v104 = {
			["node"] = p87:getValue(v103 .. "#node", nil, p85.components, p85.i3dMappings)
		}
		if v104.node == nil then
			Logging.xmlWarning(p87, "Failed to load slope compensation animation part \'%s\'. Missing node.", v103)
		else
			v104.isLeft = p87:getValue(v103 .. "#isLeft", false)
			v104.rotMin = p87:getValue(v103 .. "#rotMin", nil, true)
			v104.rotMax = p87:getValue(v103 .. "#rotMax", nil, true)
			v104.transMin = p87:getValue(v103 .. "#transMin", nil, true)
			v104.transMax = p87:getValue(v103 .. "#transMax", nil, true)
			if (v104.rotMin == nil or v104.rotMax == nil) and (v104.transMin == nil or v104.transMax == nil) then
				Logging.xmlWarning(p87, "Failed to load slope compensation animation part \'%s\'. Missing values.", v103)
			else
				v104.lastAlpha = -1
				local v105 = p86.animationParts
				table.insert(v105, v104)
			end
		end
	end
	return true
end
function SlopeCompensation.getSlopeCompensationAngle(p106, p107)
	if p107.useWheelReference then
		local v108, v109, v110, v111 = p106:getSlopeCompensationGroundPosition(p107, p107.wheelNodes1, "lastDistance1")
		local v112, v113, v114, v115 = p106:getSlopeCompensationGroundPosition(p107, p107.wheelNodes2, "lastDistance2")
		if v111 and v115 then
			local v116 = v109 - v113
			local v117 = MathUtil.vector2Length(v108 - v112, v110 - v114)
			if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
				drawDebugLine(v108, v109, v110, 1, 1, 0, v112, v113, v114, 1, 1, 0, false)
				local v118 = Utils.renderTextAtWorldPosition
				local v119 = (v108 + v112) * 0.5
				local v120 = (v109 + v113) * 0.5
				local v121 = (v110 + v114) * 0.5
				local v122 = string.format
				local v123 = v116 / v117
				local v124 = math.tan(v123)
				v118(v119, v120, v121, v122("Angle: %.2f\194\176", (math.deg(v124))), 0.01)
			end
			local v125 = v116 / v117
			return math.tan(v125)
		end
	elseif p107.referenceNode ~= nil then
		local v126, v127, v128 = worldDirectionToLocal(p107.referenceNode, 0, 1, 0)
		if p107.referenceAxis == 1 then
			return math.atan2(v126, v127)
		end
		if p107.referenceAxis == 2 then
			return math.atan2(v126, v128)
		end
		if p107.referenceAxis == 3 then
			return math.atan2(v127, v128)
		end
	end
	return 0
end
function SlopeCompensation.getSlopeCompensationAngleScale(_, _)
	return 1
end
function SlopeCompensation.getSlopeCompensationGroundPosition(p129, p130, p131, p132)
	local v133 = p129.spec_slopeCompensation
	local v134 = 0
	local v135 = 0
	local v136 = 0
	for _, v137 in ipairs(p131) do
		local v138, v139, v140 = getWorldTranslation(v137)
		v134 = v134 + v138
		v135 = v135 + v139
		v136 = v136 + v140
	end
	local v141 = #p131
	local v142 = v134 / v141
	local v143 = v135 / v141
	local v144 = v136 / v141
	v133.lastRaycastDistance = 0
	raycastAll(v142, v143, v144, 0, -1, 0, p130.raycastDistance, "slopeCompensationDetectionCallback", p129, SlopeCompensation.SLOPE_COLLISION_MASK)
	local v145 = v133.lastRaycastDistance
	if v145 == 0 then
		v145 = p130[p132]
	else
		p130[p132] = v133.lastRaycastDistance
	end
	return v142, v143 - v145, v144, v145 ~= 0
end
function SlopeCompensation.slopeCompensationDetectionCallback(p146, p147, _, _, _, p148)
	if getRigidBodyType(p147) ~= RigidBodyType.STATIC then
		return true
	end
	p146.spec_slopeCompensation.lastRaycastDistance = p148
	return false
end
function SlopeCompensation.setSlopeCompensationNodeAngle(p149, p150, p151)
	local v152 = (p151 - p150.minAngle) / (p150.maxAngle - p150.minAngle)
	if p150.animationName ~= nil and p149.setAnimationTime ~= nil then
		local v153 = p149:getAnimationTime(p150.animationName)
		p149:setAnimationStopTime(p150.animationName, v152)
		local v154 = p150.animationName
		local v155 = v152 - v153
		p149:playAnimation(v154, math.sign(v155), v153, true)
		AnimatedVehicle.updateAnimationByName(p149, p150.animationName, 9999999, true)
	end
	if p150.rotationNode ~= nil then
		local v156 = p150.rotationNodeRotation
		local v157 = p150.rotationNodeRotation
		local v158 = p150.rotationNodeRotation
		local v159, v160, v161 = getRotation(p150.rotationNode)
		v156[1] = v159
		v157[2] = v160
		v158[3] = v161
		p150.rotationNodeRotation[p150.rotationAxis] = p151
		setRotation(p150.rotationNode, p150.rotationNodeRotation[1], p150.rotationNodeRotation[2], p150.rotationNodeRotation[3])
		if p149.setMovingToolDirty ~= nil then
			p149:setMovingToolDirty(p150.rotationNode)
		end
	end
	for _, v162 in ipairs(p150.animationParts) do
		local v163
		if v162.isLeft then
			local v164 = (v152 - 0.5) / 0.5 + p150.initialHeightOffset
			v163 = 1 - math.clamp(v164, 0, 1)
		else
			local v165 = v152 / 0.5 - p150.initialHeightOffset
			v163 = math.clamp(v165, 0, 1)
		end
		local v166 = MathUtil.lerp(p150.inActiveHeight, v163, p150.compensationLevel)
		v162.lastAlpha = v166
		if v162.rotMin ~= nil then
			local v167, v168, v169 = MathUtil.vector3ArrayLerp(v162.rotMin, v162.rotMax, v166)
			setRotation(v162.node, v167, v168, v169)
			if p149.setMovingToolDirty ~= nil then
				p149:setMovingToolDirty(v162.node)
			end
		end
		if v162.transMin ~= nil then
			local v170, v171, v172 = MathUtil.vector3ArrayLerp(v162.transMin, v162.transMax, v166)
			setTranslation(v162.node, v170, v171, v172)
			if p149.setMovingToolDirty ~= nil then
				p149:setMovingToolDirty(v162.node)
			end
		end
	end
	p150.lastAngle = p151
end
function SlopeCompensation.updateDebugValues(p173, p174)
	local v175 = p173.spec_slopeCompensation
	for v176, v177 in ipairs(v175.compensationNodes) do
		local v178 = p173:getSlopeCompensationAngle(v177)
		local v179 = v177.minAngle
		local v180 = v177.maxAngle
		local v181 = math.clamp(v178, v179, v180)
		if v177.inverted then
			v181 = -v181
		end
		local v182 = {
			["name"] = string.format("compNode %d", v176),
			["value"] = string.format("%.2f\194\176", (math.deg(v181)))
		}
		table.insert(p174, v182)
	end
end

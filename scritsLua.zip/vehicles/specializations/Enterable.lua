Enterable = {}
Enterable.ADDITIONAL_CHARACTER_XML_KEY = "vehicle.enterable.additionalCharacter"
source("dataS/scripts/vehicles/specializations/events/VehiclePlayerStyleChangedEvent.lua")
function Enterable.prerequisitesPresent(_)
	return true
end
function Enterable.initSpecialization()
	Vehicle.INTERACTION_FLAG_ENTERABLE = Vehicle.registerInteractionFlag("ENTERABLE")
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Enterable")
	v1:register(XMLValueType.BOOL, "vehicle.enterable#isTabbable", "Vehicle is tabbable", true)
	v1:register(XMLValueType.BOOL, "vehicle.enterable#canBeEnteredFromMenu", "Vehicle can be entered from menu", "same as #isTabbable")
	v1:register(XMLValueType.BOOL, "vehicle.enterable.forceSelectionOnEnter", "Vehicle is selected on entering", false)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.enterReferenceNode#node", "Enter reference node")
	v1:register(XMLValueType.FLOAT, "vehicle.enterable.enterReferenceNode#interactionRadius", "Interaction radius", 6)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.exitPoint#node", "Exit point")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.nicknameRenderNode#node", "Nickname rendering node", "root node")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.enterable.nicknameRenderNode#offset", "Nickname rendering offset")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.reverb#referenceNode", "Reference node for reverb calculations", "center of vehicle +2m Y")
	v1:register(XMLValueType.STRING, "vehicle.enterable.enterAnimation#name", "Enter animation name")
	VehicleCharacter.registerCharacterXMLPaths(v1, "vehicle.enterable.characterNode")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.additionalCharacter#node", "Additional character node")
	VehicleCharacter.registerCharacterXMLPaths(v1, "vehicle.enterable.additionalCharacter")
	VehicleCamera.registerCameraXMLPaths(v1, "vehicle.enterable.cameras.camera(?)")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.characterTargetNodeModifier(?)#node", "Target node")
	v1:register(XMLValueType.STRING, "vehicle.enterable.characterTargetNodeModifier(?)#poseId", "Modifier pose id")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.characterTargetNodeModifier(?).state(?)#node", "State node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.characterTargetNodeModifier(?).state(?)#referenceNode", "State is activated if this node moves or rotates")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.characterTargetNodeModifier(?).state(?)#directionReferenceNode", "State node is align to this node")
	v1:register(XMLValueType.BOOL, "vehicle.enterable.characterTargetNodeModifier(?).state(?)#referenceNodeMovement", "The state is active as long as the reference node is moving/rotating. By default it\'s active while translation/rotation is different compared to the original state.", false)
	v1:register(XMLValueType.STRING, "vehicle.enterable.characterTargetNodeModifier(?).state(?)#poseId", "Pose id")
	v1:register(XMLValueType.FLOAT, "vehicle.enterable.characterTargetNodeModifier(?)#transitionTime", "Time between state changes", 0.1)
	v1:register(XMLValueType.FLOAT, "vehicle.enterable.characterTargetNodeModifier(?)#transitionIdleDelay", "State is changed after this delay", 0.5)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.enterable.mirrors.mirror(?)#node", "Mirror node")
	v1:register(XMLValueType.INT, "vehicle.enterable.mirrors.mirror(?)#prio", "Priority", 2)
	Dashboard.registerDashboardXMLPaths(v1, "vehicle.enterable.dashboards", {
		"time",
		"timeHours",
		"timeMinutes",
		"operatingTime",
		"outsideTemperature"
	})
	SoundManager.registerSampleXMLPaths(v1, "vehicle.enterable.sounds", "rain(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.enterable.sounds", "hail(?)")
	v1:register(XMLValueType.BOOL, Dashboard.GROUP_XML_KEY .. "#isEntered", "Is entered")
	v1:addDelayedRegistrationFunc("Cylindered:movingTool", function(p2, p3)
		p2:register(XMLValueType.BOOL, p3 .. "#updateCharacterTargetModifier", "Update character target modifier state", false)
	end)
	v1:addDelayedRegistrationFunc("Cylindered:movingPart", function(p4, p5)
		p4:register(XMLValueType.BOOL, p5 .. "#updateCharacterTargetModifier", "Update character target modifier state", false)
	end)
	v1:setXMLSpecializationType()
	local v6 = Vehicle.xmlSchemaSavegame
	VehicleCamera.registerCameraSavegameXMLPaths(v6, "vehicles.vehicle(?).enterable.camera(?)")
	v6:register(XMLValueType.INT, "vehicles.vehicle(?).enterable#activeCameraIndex", "Index of active camera", 1)
	v6:register(XMLValueType.BOOL, "vehicles.vehicle(?).enterable#isTabbable", "Is tabbable", true)
	v6:register(XMLValueType.BOOL, "vehicles.vehicle(?).enterable#isLeavingAllowed", "Is leaving allowed", true)
end
function Enterable.registerEvents(p7)
	SpecializationUtil.registerEvent(p7, "onEnterVehicle")
	SpecializationUtil.registerEvent(p7, "onLeaveVehicle")
	SpecializationUtil.registerEvent(p7, "onCameraChanged")
	SpecializationUtil.registerEvent(p7, "onVehicleCharacterChanged")
end
function Enterable.registerFunctions(p8)
	SpecializationUtil.registerFunction(p8, "onPlayerEnterVehicle", Enterable.onPlayerEnterVehicle)
	SpecializationUtil.registerFunction(p8, "doLeaveVehicle", Enterable.doLeaveVehicle)
	SpecializationUtil.registerFunction(p8, "onPlayerLeaveVehicle", Enterable.onPlayerLeaveVehicle)
	SpecializationUtil.registerFunction(p8, "setActiveCameraIndex", Enterable.setActiveCameraIndex)
	SpecializationUtil.registerFunction(p8, "addToolCameras", Enterable.addToolCameras)
	SpecializationUtil.registerFunction(p8, "removeToolCameras", Enterable.removeToolCameras)
	SpecializationUtil.registerFunction(p8, "getExitNode", Enterable.getExitNode)
	SpecializationUtil.registerFunction(p8, "getUserPlayerStyle", Enterable.getUserPlayerStyle)
	SpecializationUtil.registerFunction(p8, "getCurrentPlayerStyle", Enterable.getCurrentPlayerStyle)
	SpecializationUtil.registerFunction(p8, "setVehicleCharacter", Enterable.setVehicleCharacter)
	SpecializationUtil.registerFunction(p8, "vehicleCharacterLoaded", Enterable.vehicleCharacterLoaded)
	SpecializationUtil.registerFunction(p8, "onPlayerStyleChanged", Enterable.onPlayerStyleChanged)
	SpecializationUtil.registerFunction(p8, "setRandomVehicleCharacter", Enterable.setRandomVehicleCharacter)
	SpecializationUtil.registerFunction(p8, "restoreVehicleCharacter", Enterable.restoreVehicleCharacter)
	SpecializationUtil.registerFunction(p8, "deleteVehicleCharacter", Enterable.deleteVehicleCharacter)
	SpecializationUtil.registerFunction(p8, "getFormattedOperatingTime", Enterable.getFormattedOperatingTime)
	SpecializationUtil.registerFunction(p8, "loadCharacterTargetNodeModifier", Enterable.loadCharacterTargetNodeModifier)
	SpecializationUtil.registerFunction(p8, "updateCharacterTargetNodeModifier", Enterable.updateCharacterTargetNodeModifier)
	SpecializationUtil.registerFunction(p8, "setCharacterTargetNodeStateDirty", Enterable.setCharacterTargetNodeStateDirty)
	SpecializationUtil.registerFunction(p8, "resetCharacterTargetNodeStateDefaults", Enterable.resetCharacterTargetNodeStateDefaults)
	SpecializationUtil.registerFunction(p8, "setMirrorVisible", Enterable.setMirrorVisible)
	SpecializationUtil.registerFunction(p8, "getIsTabbable", Enterable.getIsTabbable)
	SpecializationUtil.registerFunction(p8, "setIsTabbable", Enterable.setIsTabbable)
	SpecializationUtil.registerFunction(p8, "getIsEnterable", Enterable.getIsEnterable)
	SpecializationUtil.registerFunction(p8, "getIsEnterableFromMenu", Enterable.getIsEnterableFromMenu)
	SpecializationUtil.registerFunction(p8, "getIsEntered", Enterable.getIsEntered)
	SpecializationUtil.registerFunction(p8, "getIsControlled", Enterable.getIsControlled)
	SpecializationUtil.registerFunction(p8, "getControllerName", Enterable.getControllerName)
	SpecializationUtil.registerFunction(p8, "getActiveCamera", Enterable.getActiveCamera)
	SpecializationUtil.registerFunction(p8, "getVehicleCharacter", Enterable.getVehicleCharacter)
	SpecializationUtil.registerFunction(p8, "getAllowCharacterVisibilityUpdate", Enterable.getAllowCharacterVisibilityUpdate)
	SpecializationUtil.registerFunction(p8, "getDisableVehicleCharacterOnLeave", Enterable.getDisableVehicleCharacterOnLeave)
	SpecializationUtil.registerFunction(p8, "loadCamerasFromXML", Enterable.loadCamerasFromXML)
	SpecializationUtil.registerFunction(p8, "loadAdditionalCharacterFromXML", Enterable.loadAdditionalCharacterFromXML)
	SpecializationUtil.registerFunction(p8, "getIsAdditionalCharacterActive", Enterable.getIsAdditionalCharacterActive)
	SpecializationUtil.registerFunction(p8, "getCanLeave", Enterable.getCanLeave)
	SpecializationUtil.registerFunction(p8, "getCanLeaveVehicle", Enterable.getCanLeaveVehicle)
	SpecializationUtil.registerFunction(p8, "getCanLeaveRideable", Enterable.getCanLeaveRideable)
	SpecializationUtil.registerFunction(p8, "getIsLeavingAllowed", Enterable.getIsLeavingAllowed)
	SpecializationUtil.registerFunction(p8, "setIsLeavingAllowed", Enterable.setIsLeavingAllowed)
end
function Enterable.registerOverwrittenFunctions(p9)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsActive", Enterable.getIsActive)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsActiveForInput", Enterable.getIsActiveForInput)
	SpecializationUtil.registerOverwrittenFunction(p9, "getDistanceToNode", Enterable.getDistanceToNode)
	SpecializationUtil.registerOverwrittenFunction(p9, "getInteractionHelp", Enterable.getInteractionHelp)
	SpecializationUtil.registerOverwrittenFunction(p9, "interact", Enterable.interact)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsInteractive", Enterable.getIsInteractive)
	SpecializationUtil.registerOverwrittenFunction(p9, "getCanToggleSelectable", Enterable.getCanToggleSelectable)
	SpecializationUtil.registerOverwrittenFunction(p9, "getCanToggleAttach", Enterable.getCanToggleAttach)
	SpecializationUtil.registerOverwrittenFunction(p9, "getActiveFarm", Enterable.getActiveFarm)
	SpecializationUtil.registerOverwrittenFunction(p9, "loadDashboardGroupFromXML", Enterable.loadDashboardGroupFromXML)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsDashboardGroupActive", Enterable.getIsDashboardGroupActive)
	SpecializationUtil.registerOverwrittenFunction(p9, "mountDynamic", Enterable.mountDynamic)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsInUse", Enterable.getIsInUse)
	SpecializationUtil.registerOverwrittenFunction(p9, "loadExtraDependentParts", Enterable.loadExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p9, "updateExtraDependentParts", Enterable.updateExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsMapHotspotVisible", Enterable.getIsMapHotspotVisible)
end
function Enterable.registerEventListeners(p10)
	SpecializationUtil.registerEventListener(p10, "onLoad", Enterable)
	SpecializationUtil.registerEventListener(p10, "onPostLoad", Enterable)
	SpecializationUtil.registerEventListener(p10, "onLoadFinished", Enterable)
	SpecializationUtil.registerEventListener(p10, "onRegisterDashboardValueTypes", Enterable)
	SpecializationUtil.registerEventListener(p10, "onDelete", Enterable)
	SpecializationUtil.registerEventListener(p10, "onReadStream", Enterable)
	SpecializationUtil.registerEventListener(p10, "onWriteStream", Enterable)
	SpecializationUtil.registerEventListener(p10, "onPreUpdate", Enterable)
	SpecializationUtil.registerEventListener(p10, "onUpdate", Enterable)
	SpecializationUtil.registerEventListener(p10, "onPostUpdate", Enterable)
	SpecializationUtil.registerEventListener(p10, "onDrawUIInfo", Enterable)
	SpecializationUtil.registerEventListener(p10, "onPreRegisterActionEvents", Enterable)
	SpecializationUtil.registerEventListener(p10, "onRegisterActionEvents", Enterable)
	SpecializationUtil.registerEventListener(p10, "onSetBroken", Enterable)
end
function Enterable.onLoad(p11, p12)
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.mirrors.mirror(0)#index", "vehicle.enterable.mirrors.mirror(0)#node")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.enterReferenceNode", "vehicle.enterable.enterReferenceNode")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.enterReferenceNode#index", "vehicle.enterable.enterReferenceNode#node")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.enterable.enterReferenceNode#index", "vehicle.enterable.enterReferenceNode#node")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.exitPoint", "vehicle.enterable.exitPoint")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.exitPoint#index", "vehicle.enterable.exitPoint#node")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.enterable.exitPoint#index", "vehicle.enterable.exitPoint#node")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.characterNode", "vehicle.enterable.characterNode")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.characterNode#index", "vehicle.enterable.characterNode#node")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.enterable.characterNode#index", "vehicle.enterable.characterNode#node")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.nicknameRenderNode", "vehicle.enterable.nicknameRenderNode")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.enterAnimation", "vehicle.enterable.enterAnimation")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.cameras.camera1", "vehicle.enterable.cameras.camera")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.enterable.cameras.camera1", "vehicle.enterable.cameras.camera")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.indoorHud.time", "vehicle.enterable.dashboards.dashboard with valueType \'time\'")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.indoorHud.operatingTime", "vehicle.enterable.dashboards.dashboard with valueType \'operatingTime\'")
	XMLUtil.checkDeprecatedXMLElements(p11.xmlFile, "vehicle.enterable.nicknameRenderNode#index", "vehicle.enterable.nicknameRenderNode#node")
	local v13 = p11.spec_enterable
	v13.isTabbable = p11.xmlFile:getValue("vehicle.enterable#isTabbable", true)
	v13.canBeEnteredFromMenu = p11.xmlFile:getValue("vehicle.enterable#canBeEnteredFromMenu", v13.isTabbable)
	v13.isEntered = false
	v13.isControlled = false
	v13.playerStyle = nil
	v13.canUseEnter = true
	v13.controllerFarmId = 0
	v13.controllerUserId = 0
	v13.isLeavingAllowed = true
	v13.lastCameraWasInside = false
	v13.disableCharacterOnLeave = true
	v13.enterText = string.format("%s (%s)", g_i18n:getText("button_enterVehicle"), g_i18n:getText("passengerSeat_driver"))
	v13.forceSelectionOnEnter = p11.xmlFile:getValue("vehicle.enterable.forceSelectionOnEnter", false)
	v13.enterReferenceNode = p11.xmlFile:getValue("vehicle.enterable.enterReferenceNode#node", nil, p11.components, p11.i3dMappings)
	v13.exitPoint = p11.xmlFile:getValue("vehicle.enterable.exitPoint#node", nil, p11.components, p11.i3dMappings)
	v13.interactionRadius = p11.xmlFile:getValue("vehicle.enterable.enterReferenceNode#interactionRadius", 6)
	v13.vehicleCharacter = VehicleCharacter.new(p11)
	if v13.vehicleCharacter ~= nil and not v13.vehicleCharacter:load(p11.xmlFile, "vehicle.enterable.characterNode", p11.i3dMappings) then
		v13.vehicleCharacter = nil
	end
	p11:loadAdditionalCharacterFromXML(p11.xmlFile)
	v13.nicknameRendering = {}
	v13.nicknameRendering.node = p11.xmlFile:getValue("vehicle.enterable.nicknameRenderNode#node", nil, p11.components, p11.i3dMappings)
	v13.nicknameRendering.offset = p11.xmlFile:getValue("vehicle.enterable.nicknameRenderNode#offset", nil, true)
	if v13.nicknameRendering.node == nil then
		if v13.vehicleCharacter == nil or v13.vehicleCharacter.characterDistanceRefNode == nil then
			v13.nicknameRendering.node = p11.components[1].node
		else
			v13.nicknameRendering.node = v13.vehicleCharacter.characterDistanceRefNode
			if v13.nicknameRendering.offset == nil then
				v13.nicknameRendering.offset = { 0, 1.5, 0 }
			end
		end
	end
	if v13.nicknameRendering.offset == nil then
		v13.nicknameRendering.offset = { 0, 4, 0 }
	end
	v13.enterAnimation = p11.xmlFile:getValue("vehicle.enterable.enterAnimation#name")
	if v13.enterAnimation ~= nil and not p11:getAnimationExists(v13.enterAnimation) then
		Logging.xmlWarning(p11.xmlFile, "Unable to find enter animation \'%s\'", v13.enterAnimation)
	end
	p11:loadCamerasFromXML(p11.xmlFile, p12)
	if v13.numCameras == 0 then
		Logging.xmlError(p11.xmlFile, "No cameras defined!")
		p11:setLoadingState(VehicleLoadingState.ERROR)
	else
		v13.characterTargetNodeReferenceToState = {}
		v13.characterTargetNodeStatesDirty = false
		v13.characterTargetNodeModifiers = {}
		local v14 = 0
		while true do
			local v15 = string.format("vehicle.enterable.characterTargetNodeModifier(%d)", v14)
			if not p11.xmlFile:hasProperty(v15) then
				break
			end
			local v16 = {}
			if p11:loadCharacterTargetNodeModifier(v16, p11.xmlFile, v15) then
				local v17 = v13.characterTargetNodeModifiers
				table.insert(v17, v16)
			end
			v14 = v14 + 1
		end
		local v18 = {}
		if g_isDevelopmentVersion then
			I3DUtil.getNodesByShaderParam(p11.rootNode, "reflectionScale", v18)
		end
		v13.mirrors = {}
		local v19 = g_gameSettings:getValue(GameSettings.SETTING.MAX_NUM_MIRRORS) > 0
		local v20 = 0
		while true do
			local v21 = string.format("vehicle.enterable.mirrors.mirror(%d)", v20)
			if not p11.xmlFile:hasProperty(v21) then
				break
			end
			local v22 = p11.xmlFile:getValue(v21 .. "#node", nil, p11.components, p11.i3dMappings)
			if v22 ~= nil then
				local v23 = p11.xmlFile:getValue(v21 .. "#prio", 2)
				local v24 = ObjectMask.SHAPE_VIS_MIRROR
				local v25 = ObjectMask.SHAPE_VIS_MIRROR_ONLY
				local v26 = bit32.bor(v24, v25)
				setReflectionMapObjectMasks(v22, v26, ObjectMask.LIGHT_VIS_MIRROR, true)
				if getObjectMask(v22) == 0 then
					setObjectMask(v22, 16711807)
				end
				if v19 then
					local v27 = v13.mirrors
					local v28 = {
						["node"] = v22,
						["prio"] = v23,
						["cosAngle"] = 1,
						["parentNode"] = getParent(v22)
					}
					table.insert(v27, v28)
				else
					setVisibility(v22, false)
				end
				v18[v22] = nil
			end
			v20 = v20 + 1
		end
		for v29, _ in pairs(v18) do
			Logging.xmlError(p11.xmlFile, "Found Mesh \'%s\' with mirrorShader that is not entered in the vehicle XML", getName(v29))
		end
		p11:setMirrorVisible(v13.cameras[v13.camIndex].useMirror)
		v13.lastIsRaining = false
		v13.lastIsHailing = false
		v13.weatherObject = g_currentMission.environment.weather
		if p11.isClient then
			v13.rainSamples = g_soundManager:loadSamplesFromXML(p11.xmlFile, "vehicle.enterable.sounds", "rain", p11.baseDirectory, p11.components, 0, AudioGroup.VEHICLE, p11.i3dMappings, p11)
			v13.hasRainSamples = #v13.rainSamples > 0
			v13.hailSamples = g_soundManager:loadSamplesFromXML(p11.xmlFile, "vehicle.enterable.sounds", "hail", p11.baseDirectory, p11.components, 0, AudioGroup.VEHICLE, p11.i3dMappings, p11)
			v13.hasHailSamples = #v13.hailSamples > 0
		end
		v13.reverbReferenceNode = p11.xmlFile:getValue("vehicle.enterable.reverb#referenceNode", nil, p11.components, p11.i3dMappings)
		if v13.reverbReferenceNode == nil then
			v13.reverbReferenceNode = createTransformGroup("ReverebRefNode")
			link(p11.rootNode, v13.reverbReferenceNode)
			setTranslation(v13.reverbReferenceNode, 0, 2, 0)
		end
		v13.dirtyFlag = p11:getNextDirtyFlag()
		v13.playerHotspot = PlayerHotspot.new()
		v13.playerHotspot:setVehicle(p11)
		p11.needWaterInfo = true
		g_currentMission.vehicleSystem:addInteractiveVehicle(p11)
		g_currentMission.vehicleSystem:addEnterableVehicle(p11)
	end
end
function Enterable.onPostLoad(p30, p31)
	local v32 = p30.spec_enterable
	for v33 = 1, #v32.cameras do
		v32.cameras[v33]:onPostLoad(p31)
	end
	if p31 ~= nil and not p31.resetVehicles then
		p30:setIsTabbable(p31.xmlFile:getValue(p31.key .. ".enterable#isTabbable", v32.isTabbable))
		v32.camIndex = p31.xmlFile:getValue(p31.key .. ".enterable#activeCameraIndex", 1)
		v32.isLeavingAllowed = p31.xmlFile:getValue(p31.key .. ".enterable#isLeavingAllowed", true)
	end
end
function Enterable.onLoadFinished(p34, _)
	local v35 = p34.spec_enterable
	if v35.isControlled then
		v35.playerHotspot:setOwnerFarmId(p34:getActiveFarm())
		g_currentMission:addMapHotspot(v35.playerHotspot)
	end
end
function Enterable.onRegisterDashboardValueTypes(p36)
	local v37 = DashboardValueType.new("enterable", "time")
	v37:setValue(g_currentMission.environment, "getEnvironmentTime")
	p36:registerDashboardValueType(v37)
	local v38 = DashboardValueType.new("enterable", "timeHours")
	v38:setValue(g_currentMission.environment, function(p39)
		local v40 = p39:getEnvironmentTime()
		return math.floor(v40) + v40 % 1 * 100 / 60
	end)
	p36:registerDashboardValueType(v38)
	local v41 = DashboardValueType.new("enterable", "timeMinutes")
	v41:setValue(g_currentMission.environment, function(p42)
		return p42:getEnvironmentTime() % 1 * 100
	end)
	p36:registerDashboardValueType(v41)
	local v43 = DashboardValueType.new("enterable", "operatingTime")
	v43:setValue(p36, p36.getFormattedOperatingTime)
	p36:registerDashboardValueType(v43)
	local v44 = DashboardValueType.new("enterable", "outsideTemperature")
	v44:setValue(g_currentMission.environment.weather, "getCurrentTemperature")
	p36:registerDashboardValueType(v44)
end
function Enterable.onDelete(p45)
	local v46 = p45.spec_enterable
	if v46.isControlled then
		local v47 = g_currentMission.playerSystem:getPlayerByUserId(p45.spec_enterable.controllerUserId)
		if v47 ~= nil then
			v47:leaveVehicle(p45, true)
		end
	end
	if v46.vehicleCharacter ~= nil then
		v46.vehicleCharacter:delete()
		v46.vehicleCharacter = nil
	end
	if v46.cameras ~= nil then
		for _, v48 in ipairs(v46.cameras) do
			v48:delete()
		end
	end
	if v46.playerHotspot ~= nil then
		g_currentMission:removeMapHotspot(v46.playerHotspot)
		v46.playerHotspot:delete()
		v46.playerHotspot = nil
	end
	g_soundManager:deleteSamples(v46.rainSamples)
	g_soundManager:deleteSamples(v46.hailSamples)
	v46.weatherObject = nil
	g_currentMission.vehicleSystem:removeEnterableVehicle(p45)
	g_currentMission.vehicleSystem:removeInteractiveVehicle(p45)
end
function Enterable.onReadStream(p49, p50, _)
	p49.spec_enterable.isTabbable = streamReadBool(p50)
	if streamReadBool(p50) then
		local v51 = User.streamReadUserId(p50)
		local v52 = g_playerSystem:getPlayerByUserId(v51)
		if v52 ~= nil then
			v52:onEnterVehicle(p49)
		end
	end
end
function Enterable.onWriteStream(p53, p54, _)
	local v55 = p53.spec_enterable
	streamWriteBool(p54, v55.isTabbable)
	if streamWriteBool(p54, v55.isControlled) then
		User.streamWriteUserId(p54, v55.controllerUserId)
	end
end
function Enterable.saveToXMLFile(p56, p57, p58, p59)
	local v60 = p56.spec_enterable
	for v61 = 1, #v60.cameras do
		v60.cameras[v61]:saveToXMLFile(p57, string.format("%s.camera(%d)", p58, v61 - 1), p59)
	end
	p57:setValue(p58 .. "#activeCameraIndex", v60.camIndex)
	p57:setValue(p58 .. "#isTabbable", v60.isTabbable)
	p57:setValue(p58 .. "#isLeavingAllowed", v60.isLeavingAllowed)
end
function Enterable.saveStatsToXMLFile(p62, p63, p64)
	if p62.spec_enterable.isControlled then
		local v65 = p62:getControllerName()
		if v65 ~= nil then
			setXMLString(p63, p64 .. "#controller", HTMLUtil.encodeToHTML(v65))
		end
	end
	return nil
end
function Enterable.onPreUpdate(p66, _, _, _, _)
	local v67 = p66.spec_enterable
	if v67.characterTargetNodeStatesDirty then
		local v68 = false
		for v69, v70 in pairs(v67.characterTargetNodeReferenceToState) do
			for _, v71 in ipairs(v70) do
				if v71.dirtyFrameOffset ~= nil and v71.dirtyFrameOffset > 0 then
					v71.dirtyFrameOffset = v71.dirtyFrameOffset - 1
					if v71.dirtyFrameOffset <= 0 then
						p66:setCharacterTargetNodeStateDirty(v69, false)
						v71.dirtyFrameOffset = nil
					end
					v68 = true
				end
			end
		end
		if not v68 then
			v67.characterTargetNodeStatesDirty = false
		end
	end
end
function Enterable.onUpdate(p72, p73, _, _, _)
	if p72:getIsControlled() then
		if p72.isClient then
			local v74 = p72.spec_enterable
			for _, v75 in ipairs(v74.characterTargetNodeModifiers) do
				p72:updateCharacterTargetNodeModifier(p73, v75)
			end
			if p72:getIsAdditionalCharacterActive() ~= v74.additionalCharacterActive then
				v74.additionalCharacterActive = not v74.additionalCharacterActive
				local v76 = p72:getVehicleCharacter()
				if v76 ~= nil then
					local v77 = v74.defaultCharacterNode
					local v78 = v74.defaultCharacterTargets
					if v74.additionalCharacterActive then
						v78 = v74.additionalCharacterTargets
						v77 = v74.additionalCharacterNode
					end
					v76:setIKChainTargets(v78)
					v76.characterNode = v77
					if v76.playerModel.rootNode ~= nil then
						link(v77, v76.playerModel.rootNode)
					end
				end
			end
			if v74.hasRainSamples then
				local v79 = v74.weatherObject:getRainFallScale() > 0
				if v79 ~= v74.lastIsRaining then
					if v79 then
						g_soundManager:playSamples(v74.rainSamples)
					else
						g_soundManager:stopSamples(v74.rainSamples)
					end
					v74.lastIsRaining = v79
				end
			end
			if v74.hasHailSamples then
				local v80 = v74.weatherObject:getIsHailing()
				if v80 ~= v74.lastIsHailing then
					if v80 then
						g_soundManager:playSamples(v74.hailSamples)
					else
						g_soundManager:stopSamples(v74.hailSamples)
					end
					v74.lastIsHailing = v80
				end
			end
			local v81, v82, v83 = getWorldTranslation(p72.rootNode)
			local v84, v85, v86 = localDirectionToWorld(p72.rootNode, 0, 0, 1)
			g_currentMission.activatableObjectsSystem:setPosition(v81, v82, v83)
			g_currentMission.activatableObjectsSystem:setDirection(v84, v85, v86)
		end
		p72.rootVehicle:raiseActive()
	end
end
function Enterable.onPostUpdate(p87, p88, _, _, _)
	local v89 = p87.spec_enterable
	if p87.isClient then
		if v89.isEntered and (v89.vehicleCharacter ~= nil and (v89.vehicleCharacter.characterSpineNode ~= nil and v89.vehicleCharacter.characterSpineSpeedDepended)) then
			v89.vehicleCharacter:setSpineDirty(p87.lastSpeedAcceleration)
		end
		if p87.finishedFirstUpdate then
			if p87:getIsEntered() then
				v89.activeCamera:update(p88)
			end
			if p87:getAllowCharacterVisibilityUpdate() and v89.vehicleCharacter ~= nil then
				v89.vehicleCharacter:updateVisibility()
			end
		end
		if p87:getIsControlled() then
			if v89.vehicleCharacter ~= nil then
				v89.vehicleCharacter:update(p88)
			end
			if v89.activeCamera ~= nil and v89.activeCamera.useMirror then
				p87:setMirrorVisible(true)
			end
		end
	end
end
function Enterable.onDrawUIInfo(p90)
	local v91 = p90.spec_enterable
	local v92 = not (g_gui:getIsGuiVisible() or g_noHudModeEnabled)
	if v92 then
		v92 = g_gameSettings:getValue(GameSettings.SETTING.SHOW_MULTIPLAYER_NAMES)
	end
	if not v91.isEntered and (p90.isClient and (p90:getIsActive() and (v91.isControlled and v92))) then
		local v93, v94, v95 = getWorldTranslation(v91.nicknameRendering.node)
		local v96, v97, v98 = getWorldTranslation(g_cameraManager:getActiveCamera())
		if MathUtil.vector3LengthSq(v93 - v96, v94 - v97, v95 - v98) <= 10000 then
			local v99 = v93 + v91.nicknameRendering.offset[1]
			local v100 = v94 + v91.nicknameRendering.offset[2]
			local v101 = v95 + v91.nicknameRendering.offset[3]
			Utils.renderTextAtWorldPosition(v99, v100, v101, p90:getControllerName(), getCorrectTextSize(0.02), 0)
		end
	end
end
function Enterable.loadCamerasFromXML(p102, p103, p104)
	local v105 = p102.spec_enterable
	XMLUtil.checkDeprecatedXMLElements(p103, "vehicle.cameras.camera(0)#index", "vehicle.enterable.cameras.camera(0)#node")
	XMLUtil.checkDeprecatedXMLElements(p103, "vehicle.cameras.camera(0).raycastNode(0)#index", "vehicle.enterable.cameras.camera(0).raycastNode(0)#node")
	v105.cameras = {}
	local v106 = 0
	while true do
		local v107 = string.format("vehicle.enterable.cameras.camera(%d)", v106)
		if not p103:hasProperty(v107) then
			break
		end
		local v108 = VehicleCamera.new(p102)
		if v108:loadFromXML(p103, v107, p104, v106) then
			local v109 = v105.cameras
			table.insert(v109, v108)
		end
		v106 = v106 + 1
	end
	v105.numCameras = #v105.cameras
	v105.camIndex = 1
end
function Enterable.loadAdditionalCharacterFromXML(p110, p111)
	local v112 = p110.spec_enterable
	v112.additionalCharacterNode = p111:getValue("vehicle.enterable.additionalCharacter#node", nil, p110.components, p110.i3dMappings)
	v112.additionalCharacterTargets = {}
	IKUtil.loadIKChainTargets(p111, "vehicle.enterable.additionalCharacter", p110.components, v112.additionalCharacterTargets, p110.i3dMappings)
	v112.additionalCharacterActive = false
	if v112.vehicleCharacter ~= nil then
		v112.defaultCharacterNode = v112.vehicleCharacter.characterNode
		v112.defaultCharacterTargets = v112.vehicleCharacter:getIKChainTargets()
	end
end
function Enterable.getIsAdditionalCharacterActive(_)
	return false
end
function Enterable.loadCharacterTargetNodeModifier(p113, p114, p115, p116)
	XMLUtil.checkDeprecatedXMLElements(p115, p116 .. "#index", p116 .. "#node")
	p114.node = p115:getValue(p116 .. "#node", nil, p113.components, p113.i3dMappings)
	if p114.node == nil then
		return false
	end
	p114.parent = getParent(p114.node)
	p114.translationOffset = { getTranslation(p114.node) }
	p114.rotationOffset = { getRotation(p114.node) }
	p114.poseId = p115:getValue(p116 .. "#poseId")
	p114.states = {}
	local v117 = 0
	while true do
		local v118 = string.format("%s.state(%d)", p116, v117)
		if not p115:hasProperty(v118) then
			break
		end
		XMLUtil.checkDeprecatedXMLElements(p115, v118 .. "#index", v118 .. "#node")
		local v119 = p115:getValue(v118 .. "#node", nil, p113.components, p113.i3dMappings)
		if v119 == nil then
			Logging.xmlWarning(p113.xmlFile, "Missing node for state \'%s\'", v118)
		else
			local v120 = {
				["node"] = v119,
				["referenceNode"] = p115:getValue(v118 .. "#referenceNode", nil, p113.components, p113.i3dMappings),
				["directionReferenceNode"] = p115:getValue(v118 .. "#directionReferenceNode", nil, p113.components, p113.i3dMappings),
				["referenceNodeMovement"] = p115:getValue(v118 .. "#referenceNodeMovement", false),
				["poseId"] = p113.xmlFile:getValue(v118 .. "#poseId")
			}
			if v120.referenceNode ~= nil then
				v120.defaultRotation = { getRotation(v120.referenceNode) }
				v120.defaultTranslation = { getTranslation(v120.referenceNode) }
				local v121 = p113.spec_enterable
				if v121.characterTargetNodeReferenceToState[v120.referenceNode] == nil then
					v121.characterTargetNodeReferenceToState[v120.referenceNode] = {}
				end
				local v122 = v121.characterTargetNodeReferenceToState[v120.referenceNode]
				table.insert(v122, v120)
				local v123 = p114.states
				table.insert(v123, v120)
			end
		end
		v117 = v117 + 1
	end
	p114.transitionTime = p113.xmlFile:getValue(p116 .. "#transitionTime", 0.1) * 1000
	p114.transitionAlpha = 1
	p114.transitionIdleDelay = p113.xmlFile:getValue(p116 .. "#transitionIdleDelay", 0.5) * 1000
	p114.transitionIdleTime = 0
	return true
end
function Enterable.updateCharacterTargetNodeModifier(p124, p125, p126)
	local v127 = p126.parent
	local v128 = p126.poseId
	for _, v129 in pairs(p126.states) do
		if v129.isActive then
			v127 = v129.node
			v128 = v129.poseId or v128
			if v129.directionReferenceNode ~= nil then
				local v130, v131, v132 = getWorldTranslation(v129.directionReferenceNode)
				local v133, v134, v135 = getTranslation(v129.node)
				local v136, v137, v138 = worldToLocal(getParent(v129.node), v130, v131, v132)
				setDirection(v129.node, v136 - v133, v137 - v134, v138 - v135, 0, 1, 0)
			end
		end
	end
	local v139 = p126.transitionAlpha < 1
	local v140 = v127 ~= p126.parent
	if not v140 then
		p126.transitionIdleTime = p126.transitionIdleTime + p125
		if p126.transitionIdleTime > p126.transitionIdleDelay then
			p126.transitionIdleTime = 0
			v140 = true
		end
	end
	if not v140 or getParent(p126.node) == v127 then
		::l16::
		if v139 then
			local v141 = p126.transitionAlpha + p125 / p126.transitionTime
			p126.transitionAlpha = math.min(1, v141)
			local v142, v143, v144 = MathUtil.vector3ArrayLerp(p126.transitionStartPos, p126.transitionEndPos, p126.transitionAlpha)
			setTranslation(p126.node, v142, v143, v144)
			local v145, v146, v147, v148 = MathUtil.slerpQuaternionShortestPath(p126.transitionStartQuat[1], p126.transitionStartQuat[2], p126.transitionStartQuat[3], p126.transitionStartQuat[4], p126.transitionEndQuat[1], p126.transitionEndQuat[2], p126.transitionEndQuat[3], p126.transitionEndQuat[4], p126.transitionAlpha)
			setQuaternion(p126.node, v145, v146, v147, v148)
		end
		return
	end
	local v149 = { localToLocal(p126.node, v127, 0, 0, 0) }
	local v150 = v127 ~= p126.parent and { 0, 0, 0 } or p126.translationOffset
	p126.transitionStartPos = v149
	p126.transitionEndPos = v150
	local v151 = v150[1] - v149[1]
	if math.abs(v151) < 0.001 then
		local v152 = v150[2] - v149[2]
		if math.abs(v152) < 0.001 then
			local v153 = v150[3] - v149[3]
			if math.abs(v153) < 0.001 then
				p126.transitionAlpha = 1
				::l24::
				v139 = true
				local v154, v155, v156 = localRotationToLocal(p126.node, v127, 0, 0, 0)
				p126.transitionStartQuat = { mathEulerToQuaternion(v154, v155, v156) }
				p126.transitionEndQuat = {
					0,
					0,
					0,
					1
				}
				if v127 == p126.parent then
					local v157 = {}
					local v158 = mathEulerToQuaternion
					local v159 = p126.rotationOffset
					__set_list(v157, 1, {v158(unpack(v159))})
					p126.transitionEndQuat = v157
				end
				link(v127, p126.node)
				if v128 ~= nil then
					local v160 = p124:getVehicleCharacter()
					if v160 ~= nil then
						v160:setIKChainPoseByTarget(p126.node, v128)
					end
				end
				goto l16
			end
		end
	end
	p126.transitionAlpha = 0
	goto l24
end
function Enterable.setCharacterTargetNodeStateDirty(p161, p162, p163)
	local v164 = p161.spec_enterable
	local v165 = v164.characterTargetNodeReferenceToState[p162]
	if v165 ~= nil then
		for v166 = 1, #v165 do
			local v167 = v165[v166]
			v167.isActive = p163 == true
			local v168, v169, v170 = getRotation(v167.referenceNode)
			local v171 = v167.defaultRotation
			local v172, v173, v174 = unpack(v171)
			local v175 = v168 - v172
			local v176 = math.abs(v175)
			local v177 = v169 - v173
			local v178 = v176 + math.abs(v177)
			local v179 = v170 - v174
			if v178 + math.abs(v179) > 0.00001 then
				v167.isActive = true
			end
			local v180, v181, v182 = getTranslation(v167.referenceNode)
			local v183 = v167.defaultTranslation
			local v184, v185, v186 = unpack(v183)
			local v187 = v180 - v184
			local v188 = math.abs(v187)
			local v189 = v181 - v185
			local v190 = v188 + math.abs(v189)
			local v191 = v182 - v186
			if v190 + math.abs(v191) > 0.00001 then
				v167.isActive = true
			end
			if v167.referenceNodeMovement then
				local v192 = v167.defaultRotation
				local v193 = v167.defaultRotation
				local v194 = v167.defaultRotation
				v192[1] = v168
				v193[2] = v169
				v194[3] = v170
				local v195 = v167.defaultTranslation
				local v196 = v167.defaultTranslation
				local v197 = v167.defaultTranslation
				v195[1] = v180
				v196[2] = v181
				v197[3] = v182
				if v167.isActive then
					v167.dirtyFrameOffset = 2
					v164.characterTargetNodeStatesDirty = true
				end
			end
		end
	end
end
function Enterable.resetCharacterTargetNodeStateDefaults(p198, p199)
	local v200 = p198.spec_enterable.characterTargetNodeReferenceToState[p199]
	if v200 ~= nil then
		for v201 = 1, #v200 do
			local v202 = v200[v201]
			local v203 = v202.defaultRotation
			local v204 = v202.defaultRotation
			local v205 = v202.defaultRotation
			local v206, v207, v208 = getRotation(v202.referenceNode)
			v203[1] = v206
			v204[2] = v207
			v205[3] = v208
			local v209 = v202.defaultTranslation
			local v210 = v202.defaultTranslation
			local v211 = v202.defaultTranslation
			local v212, v213, v214 = getTranslation(v202.referenceNode)
			v209[1] = v212
			v210[2] = v213
			v211[3] = v214
		end
	end
end
function Enterable.onPlayerEnterVehicle(p215, p216, p217, p218, p219)
	local v220 = p215.spec_enterable
	p215:raiseActive()
	v220.isControlled = true
	v220.isEntered = p216
	v220.playerStyle = p217
	v220.canUseEnter = false
	v220.controllerFarmId = p218
	v220.controllerUserId = p219
	if v220.forceSelectionOnEnter then
		local v221 = p215.rootVehicle
		if v221 ~= p215 then
			v221:setSelectedImplementByObject(p215)
		end
	end
	if v220.isEntered then
		if g_gameSettings:getValue(GameSettings.SETTING.IS_HEAD_TRACKING_ENABLED) and isHeadTrackingAvailable() then
			for v222, v223 in pairs(v220.cameras) do
				if v223.isInside then
					v220.camIndex = v222
					break
				end
			end
		end
		if g_gameSettings:getValue(GameSettings.SETTING.RESET_CAMERA) then
			v220.camIndex = 1
		end
		p215:setActiveCameraIndex(v220.camIndex)
		g_currentMission.vehicleSystem:setEnteredVehicle(p215)
	end
	if v220.playerHotspot ~= nil then
		v220.playerHotspot:setOwnerFarmId(p215:getActiveFarm())
		g_currentMission:addMapHotspot(v220.playerHotspot)
		v220.playerHotspot:setPlayer(g_playerSystem:getPlayerByIndex(p219))
	end
	if not p215:getIsAIActive() then
		p215:setVehicleCharacter(p217)
		if v220.enterAnimation ~= nil and p215.playAnimation ~= nil then
			p215:playAnimation(v220.enterAnimation, 1, nil, true)
		end
	end
	p215.isActiveForLocalSound = p215:getIsActiveForInput(true, true)
	SpecializationUtil.raiseEvent(p215, "onEnterVehicle", p216)
	p215.rootVehicle:raiseStateChange(VehicleStateChange.ENTER_VEHICLE, p215, p216)
	if v220.isEntered and p215.isClient then
		g_messageCenter:subscribe(MessageType.INPUT_BINDINGS_CHANGED, p215.requestActionEventUpdate, p215)
		p215:requestActionEventUpdate()
	end
	if p215.isServer and (not p216 and (g_currentMission.trafficSystem ~= nil and g_currentMission.trafficSystem.trafficSystemId ~= 0)) then
		addTrafficSystemPlayer(g_currentMission.trafficSystem.trafficSystemId, p215.components[1].node)
	end
	p215:activate()
end
function Enterable.getCanLeave(p224)
	return p224.spec_enterable.isEntered
end
function Enterable.getCanLeaveVehicle(p225)
	local v226 = p225.spec_rideable == nil
	if v226 then
		v226 = p225:getCanLeave()
	end
	return v226
end
function Enterable.getCanLeaveRideable(p227)
	local v228 = p227.spec_rideable ~= nil
	if v228 then
		v228 = p227:getCanLeave()
	end
	return v228
end
function Enterable.getIsLeavingAllowed(p229)
	return p229.spec_enterable.isLeavingAllowed
end
function Enterable.setIsLeavingAllowed(p230, p231)
	p230.spec_enterable.isLeavingAllowed = p231
end
function Enterable.doLeaveVehicle(p232)
	if p232:getCanLeave() and p232:getIsLeavingAllowed() then
		g_localPlayer:leaveVehicle()
	end
end
function Enterable.onPlayerLeaveVehicle(p233)
	local v234 = p233.spec_enterable
	g_currentMission:removePauseListeners(p233)
	local v235 = v234.isEntered
	if v234.activeCamera ~= nil and v234.isEntered then
		v234.lastCameraWasInside = v234.activeCamera.isInside
		v234.activeCamera:onDeactivate()
		g_soundManager:setIsIndoor(false)
		g_currentMission.ambientSoundSystem:setIsIndoor(false)
		g_currentMission.environment.environmentMaskSystem:setIsIndoor(false)
		g_currentMission.activatableObjectsSystem:deactivate(Vehicle.INPUT_CONTEXT_NAME)
		if p233.isClient then
			g_soundManager:stopSamples(v234.rainSamples)
			v234.lastIsRaining = false
			g_soundManager:stopSamples(v234.hailSamples)
			v234.lastIsHailing = false
		end
	end
	if v234.playerHotspot ~= nil then
		g_currentMission:removeMapHotspot(v234.playerHotspot)
		v234.playerHotspot:setPlayer(nil)
	end
	v234.isControlled = false
	v234.isEntered = false
	v234.playerIndex = 0
	v234.playerColorIndex = 0
	v234.canUseEnter = true
	v234.controllerFarmId = 0
	v234.controllerUserId = 0
	g_currentMission:setLastInteractionTime(200)
	if v234.vehicleCharacter ~= nil and p233:getDisableVehicleCharacterOnLeave() then
		p233:deleteVehicleCharacter()
	end
	if v234.enterAnimation ~= nil and p233.playAnimation ~= nil then
		p233:playAnimation(v234.enterAnimation, -1, nil, true)
	end
	p233:setMirrorVisible(false)
	SpecializationUtil.raiseEvent(p233, "onLeaveVehicle", v235)
	p233.rootVehicle:raiseStateChange(VehicleStateChange.LEAVE_VEHICLE, p233)
	if v235 and p233.isClient then
		g_messageCenter:unsubscribe(MessageType.INPUT_BINDINGS_CHANGED, p233)
		p233:requestActionEventUpdate()
		if g_touchHandler ~= nil then
			g_touchHandler:removeGestureListener(p233.touchListenerDoubleTab)
		end
	end
	if p233.isServer and (not v234.isEntered and (g_currentMission.trafficSystem ~= nil and g_currentMission.trafficSystem.trafficSystemId ~= 0)) then
		removeTrafficSystemPlayer(g_currentMission.trafficSystem.trafficSystemId, p233.components[1].node)
	end
	if p233:getDeactivateOnLeave() then
		p233:deactivate()
	end
end
function Enterable.getIsMapHotspotVisible(p236, p237)
	if p237(p236) then
		return not p236.spec_enterable.isControlled
	else
		return false
	end
end
function Enterable.setActiveCameraIndex(p238, p239)
	local v240 = p238.spec_enterable
	if v240.camIndex ~= p239 or (v240.activeCamera == nil or g_cameraManager.activeCameraNode ~= v240.activeCamera.cameraNode) then
		if v240.activeCamera ~= nil then
			v240.activeCamera:onDeactivate()
		end
		v240.camIndex = p239
		if v240.camIndex > v240.numCameras then
			v240.camIndex = 1
		end
		local v241 = v240.cameras[v240.camIndex]
		v240.activeCamera = v241
		v241:onActivate()
		g_soundManager:setIsIndoor(not v241.useOutdoorSounds)
		g_currentMission.ambientSoundSystem:setIsIndoor(not v241.useOutdoorSounds)
		g_currentMission.environment.environmentMaskSystem:setIsIndoor(not v241.useOutdoorSounds)
		p238:setMirrorVisible(v241.useMirror)
		g_currentMission.environmentAreaSystem:setReferenceNode(v241.cameraNode)
		SpecializationUtil.raiseEvent(p238, "onCameraChanged", v241, v240.camIndex)
	end
end
function Enterable.addToolCameras(p242, p243)
	local v244 = p242.spec_enterable
	for _, v245 in pairs(p243) do
		local v246 = v244.cameras
		table.insert(v246, v245)
	end
	v244.numCameras = #v244.cameras
end
function Enterable.removeToolCameras(p247, p248)
	local v249 = p247.spec_enterable
	local v250 = false
	for v251 = #v249.cameras, 1, -1 do
		local v252 = v249.cameras[v251]
		for _, v253 in pairs(p248) do
			if v253 == v252 then
				table.remove(v249.cameras, v251)
				if v251 == v249.camIndex then
					v250 = true
				end
				break
			end
		end
	end
	v249.numCameras = #v249.cameras
	if v250 then
		if v249.activeCamera ~= nil then
			v249.activeCamera:onDeactivate()
		end
		v249.camIndex = 1
		p247:setActiveCameraIndex(v249.camIndex)
	end
end
function Enterable.getExitNode(p254, _)
	return p254.spec_enterable.exitPoint
end
function Enterable.getUserPlayerStyle(p255)
	return p255.spec_enterable.playerStyle
end
function Enterable.getCurrentPlayerStyle(p256)
	local v257 = p256.spec_enterable
	if v257.vehicleCharacter == nil then
		return nil
	else
		return v257.vehicleCharacter:getPlayerStyle()
	end
end
function Enterable.setVehicleCharacter(p258, p259)
	local v260 = p258.spec_enterable
	p258:deleteVehicleCharacter()
	if v260.vehicleCharacter ~= nil then
		v260.vehicleCharacter:loadCharacter(p259, p258, p258.vehicleCharacterLoaded)
	end
end
function Enterable.vehicleCharacterLoaded(p261, p262, _)
	local v263 = p261.spec_enterable
	if p262 == HumanModelLoadingState.OK then
		v263.vehicleCharacter:updateVisibility()
		v263.vehicleCharacter:updateIKChains()
	end
	SpecializationUtil.raiseEvent(p261, "onVehicleCharacterChanged", v263.vehicleCharacter)
	g_messageCenter:subscribe(MessageType.PLAYER_STYLE_CHANGED, p261.onPlayerStyleChanged, p261)
end
function Enterable.onPlayerStyleChanged(p264, p265, p266)
	if p264.isServer then
		local v267 = p264:getOwnerConnection()
		if v267 ~= nil and g_currentMission.userManager:getUserIdByConnection(v267) == p266 then
			p264:setVehicleCharacter(p265)
			g_server:broadcastEvent(VehiclePlayerStyleChangedEvent.new(p264, p265))
		end
	end
end
function Enterable.setRandomVehicleCharacter(p268, p269)
	if p268.spec_enterable.vehicleCharacter ~= nil then
		local v270
		if p269 == nil then
			v270 = g_helperManager:getRandomHelperStyle()
		else
			v270 = p269.playerStyle
		end
		p268:setVehicleCharacter(v270)
	end
end
function Enterable.restoreVehicleCharacter(p271)
	if p271.spec_enterable.vehicleCharacter ~= nil then
		if p271:getIsControlled() then
			p271:setVehicleCharacter(p271:getUserPlayerStyle())
			return
		end
		p271:deleteVehicleCharacter()
	end
end
function Enterable.deleteVehicleCharacter(p272)
	local v273 = p272.spec_enterable
	SpecializationUtil.raiseEvent(p272, "onVehicleCharacterChanged", nil)
	if v273.vehicleCharacter ~= nil then
		v273.vehicleCharacter:unloadCharacter()
	end
	g_messageCenter:unsubscribe(MessageType.PLAYER_STYLE_CHANGED, p272)
end
function Enterable.getFormattedOperatingTime(p274)
	local v275 = p274.operatingTime / 60000
	local v276 = v275 / 60
	local v277 = math.floor(v276)
	local v278 = (v275 - v277 * 60) / 6
	local v279 = math.floor(v278)
	local v280 = v277 .. "." .. string.format("%02d", v279 * 10)
	return tonumber(v280)
end
function Enterable.getIsActive(p281, p282)
	local v283 = p281.spec_enterable
	return (v283.isEntered or v283.isControlled) and true or p282(p281)
end
function Enterable.getIsActiveForInput(p284, p285, p286, p287)
	if not p285(p284, p286, p287) then
		return false
	end
	if g_currentMission.isPlayerFrozen then
		return false
	end
	local v288 = p284.spec_enterable
	if not (v288.isEntered and v288.isControlled) then
		local v289 = p284.rootVehicle:getChildVehicles()
		local v290 = true
		for _, v291 in ipairs(v289) do
			local v292 = v291.spec_enterable
			if v292 ~= nil and (v291 ~= p284 and (v292.isEntered or v292.isControlled)) then
				v290 = false
			end
		end
		if v290 then
			return false
		end
	end
	return true
end
function Enterable.getDistanceToNode(p293, p294, p295)
	local v296 = p293.spec_enterable
	local v297 = p294(p293, p295)
	if v296 == nil or v296.enterReferenceNode == nil then
		return v297
	end
	if not p293:getIsControlled() then
		local v298, v299, v300 = getWorldTranslation(p295)
		local v301, v302, v303 = getWorldTranslation(v296.enterReferenceNode)
		local v304 = MathUtil.vector3Length(v298 - v301, v299 - v302, v300 - v303)
		if v304 < v296.interactionRadius and v304 < v297 then
			p293.interactionFlag = Vehicle.INTERACTION_FLAG_ENTERABLE
			return v304
		end
	end
	return v297
end
function Enterable.getInteractionHelp(p305, p306)
	if p305.interactionFlag == Vehicle.INTERACTION_FLAG_ENTERABLE then
		return p305.spec_enterable.enterText
	else
		return p306(p305)
	end
end
function Enterable.interact(p307, p308, p309)
	if p307.interactionFlag == Vehicle.INTERACTION_FLAG_ENTERABLE then
		p309:requestToEnterVehicle(p307)
	else
		p308(p307)
	end
end
function Enterable.getIsInteractive(p310, p311)
	if p310:getIsControlled() then
		return false
	else
		return p311(p310)
	end
end
function Enterable.setMirrorVisible(p312, p313)
	local v314 = p312.spec_enterable
	if v314.mirrors == nil or next(v314.mirrors) == nil then
		return
	elseif p313 then
		local v315 = 0
		for _, v316 in pairs(v314.mirrors) do
			if getEffectiveVisibility(v316.parentNode) and getIsInCameraFrustum(v316.node, v314.activeCamera.cameraNode, g_presentedScreenAspectRatio) then
				local v317, v318, v319 = localToLocal(v314.activeCamera.cameraNode, v316.node, 0, 0, 0)
				local v320 = v318 * g_screenAspectRatio
				local v321 = MathUtil.vector3Length(v317, v320, v319)
				v316.cosAngle = -v319 / v321
			else
				v316.cosAngle = (1 / 0)
			end
		end
		table.sort(v314.mirrors, function(p322, p323)
			if p322.prio == p323.prio then
				return p322.cosAngle > p323.cosAngle
			else
				return p322.prio < p323.prio
			end
		end)
		local v324 = g_gameSettings:getValue(GameSettings.SETTING.MAX_NUM_MIRRORS)
		for _, v325 in ipairs(v314.mirrors) do
			if getEffectiveVisibility(v325.parentNode) then
				if v325.cosAngle == (1 / 0) or v315 >= v324 then
					setVisibility(v325.node, false)
				else
					setVisibility(v325.node, true)
					v315 = v315 + 1
				end
			end
		end
	else
		for _, v326 in pairs(v314.mirrors) do
			setVisibility(v326.node, false)
		end
	end
end
function Enterable.getIsTabbable(p327)
	return p327.spec_enterable.isTabbable
end
function Enterable.setIsTabbable(p328, p329)
	if p329 == nil then
		p329 = false
	end
	p328.spec_enterable.isTabbable = p329
end
function Enterable.getIsEnterable(p330)
	local v331 = p330.spec_enterable
	local v332 = v331.enterReferenceNode ~= nil and v331.exitPoint ~= nil and not (v331.isBroken or v331.isControlled)
	if v332 then
		v332 = g_currentMission.accessHandler:canPlayerAccess(p330)
	end
	return v332
end
function Enterable.getIsEnterableFromMenu(p333)
	local v334 = p333:getIsEnterable()
	if v334 then
		v334 = p333.spec_enterable.canBeEnteredFromMenu
	end
	return v334
end
function Enterable.getIsEntered(p335)
	return p335.spec_enterable.isEntered
end
function Enterable.getIsControlled(p336)
	return p336.spec_enterable.isControlled
end
function Enterable.getControllerName(p337)
	local v338
	if p337.isServer then
		v338 = g_currentMission.userManager:getUserByConnection(p337:getOwnerConnection())
	else
		v338 = g_currentMission.userManager:getUserByUserId(p337.spec_enterable.controllerUserId)
	end
	return v338 == nil and "" or v338:getNickname()
end
function Enterable.getActiveCamera(p339)
	return p339.spec_enterable.activeCamera
end
function Enterable.getVehicleCharacter(p340)
	return p340.spec_enterable.vehicleCharacter
end
function Enterable.getAllowCharacterVisibilityUpdate(_)
	return true
end
function Enterable.getDisableVehicleCharacterOnLeave(p341)
	return p341.spec_enterable.disableCharacterOnLeave
end
function Enterable.getCanToggleSelectable(p342, p343)
	return p342:getIsEntered() and true or p343(p342)
end
function Enterable.getCanToggleAttach(p344, p345)
	if p344:getIsEntered() then
		return p345(p344)
	else
		return false
	end
end
function Enterable.getActiveFarm(p346, p347)
	local v348 = p346.spec_enterable.controllerFarmId
	if v348 == 0 then
		return p347(p346)
	else
		return v348
	end
end
function Enterable.loadDashboardGroupFromXML(p349, p350, p351, p352, p353)
	if not p350(p349, p351, p352, p353) then
		return false
	end
	p353.isEntered = p351:getValue(p352 .. "#isEntered")
	return true
end
function Enterable.getIsDashboardGroupActive(p354, p355, p356)
	if p356.isEntered == nil or p356.isEntered == p354:getIsEntered() then
		return p355(p354, p356)
	else
		return false
	end
end
function Enterable.mountDynamic(p357, p358, p359, p360, p361, p362, p363)
	if p357.spec_enterable.isControlled then
		return false
	else
		return p358(p357, p359, p360, p361, p362, p363)
	end
end
function Enterable.getIsInUse(p364, p365, p366)
	return p364.spec_enterable.isControlled and p364:getOwnerConnection() ~= p366 and true or p365(p364, p366)
end
function Enterable.loadExtraDependentParts(p367, p368, p369, p370, p371)
	if not p368(p367, p369, p370, p371) then
		return false
	end
	p371.updateCharacterTargetModifier = p369:getValue(p370 .. "#updateCharacterTargetModifier", false)
	return true
end
function Enterable.updateExtraDependentParts(p372, p373, p374, p375)
	p373(p372, p374, p375)
	if p374.updateCharacterTargetModifier then
		p372:setCharacterTargetNodeStateDirty(p374.node, false)
	end
end
function Enterable.onPreRegisterActionEvents(p376, _, _)
	p376:clearActionEventsTable(p376.spec_enterable.actionEvents)
end
function Enterable.onRegisterActionEvents(p377, _, _)
	if p377:getIsEntered() then
		local v378 = p377.spec_enterable
		if g_touchHandler ~= nil then
			g_touchHandler:removeGestureListener(p377.touchListenerDoubleTab)
		end
		if p377:getIsActiveForInput(true, true) then
			g_localPlayer.inputComponent:registerGlobalPlayerActionEvents(Vehicle.INPUT_CONTEXT_NAME)
			local _, v379 = p377:addActionEvent(v378.actionEvents, InputAction.ENTER, p377, Enterable.actionEventLeave, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v379, GS_PRIO_VERY_HIGH)
			g_inputBinding:setActionEventTextVisibility(v379, false)
			if v378.numCameras > 1 then
				local _, v380 = p377:addActionEvent(v378.actionEvents, InputAction.CAMERA_SWITCH, p377, Enterable.actionEventCameraSwitch, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v380, GS_PRIO_LOW)
				g_inputBinding:setActionEventTextVisibility(v380, true)
			end
			local _, v381 = p377:addActionEvent(v378.actionEvents, InputAction.CAMERA_ZOOM_IN_OUT, p377, Enterable.actionEventCameraZoomInOut, false, true, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v381, GS_PRIO_LOW)
			g_inputBinding:setActionEventTextVisibility(v381, false)
			local _, v382 = p377:addActionEvent(v378.actionEvents, InputAction.RESET_HEAD_TRACKING, p377, Enterable.actionEventResetHeadTracking, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v382, GS_PRIO_VERY_LOW)
			g_inputBinding:setActionEventTextVisibility(v382, false)
			if g_touchHandler ~= nil then
				p377.touchListenerDoubleTab = g_touchHandler:registerGestureListener(TouchHandler.GESTURE_DOUBLE_TAP, Enterable.actionEventCameraSwitch, p377)
			end
			g_inputBinding:endActionEventsModification()
			g_currentMission.activatableObjectsSystem:activate(Vehicle.INPUT_CONTEXT_NAME)
			g_inputBinding:beginActionEventsModification(Vehicle.INPUT_CONTEXT_NAME)
		end
	end
end
function Enterable.onSetBroken(p383)
	if p383.spec_enterable.isEntered then
		g_localPlayer:leaveVehicle()
	end
end
function Enterable.actionEventLeave(p384, _, _, _, _)
	p384:doLeaveVehicle()
end
function Enterable.actionEventCameraSwitch(p385, _, _, _, _)
	if not g_gui:getIsGuiVisible() and p385:getIsEntered() then
		p385:setActiveCameraIndex(p385.spec_enterable.camIndex + 1)
	end
end
function Enterable.actionEventCameraZoomInOut(p386, _, p387, _, _, p388, _, _)
	local v389 = p386.spec_enterable
	local v390 = -0.2
	if p388 then
		v390 = v390 * InputBinding.MOUSE_WHEEL_INPUT_FACTOR
	end
	local v391 = v390 * g_gameSettings:getValue(GameSettings.SETTING.CAMERA_ZOOM_SENSITIVITY)
	v389.activeCamera:zoomSmoothly(v391 * p387)
end
function Enterable.actionEventResetHeadTracking(_, _, _, _, _)
	centerHeadTracking()
end

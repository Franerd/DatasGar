Wipers = {}
Wipers.forcedState = -1
function Wipers.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Enterable, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	end
	return v2
end
function Wipers.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Wipers")
	v3:register(XMLValueType.STRING, "vehicle.wipers.wiper(?)#animName", "Animation name")
	v3:register(XMLValueType.FLOAT, "vehicle.wipers.wiper(?).state(?)#animSpeed", "Animation speed")
	v3:register(XMLValueType.FLOAT, "vehicle.wipers.wiper(?).state(?)#animPause", "Animation pause time (sec.)")
	Dashboard.registerDashboardXMLPaths(v3, "vehicle.wipers.dashboards", { "state" })
	v3:setXMLSpecializationType()
end
function Wipers.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "loadWiperFromXML", Wipers.loadWiperFromXML)
	SpecializationUtil.registerFunction(p4, "getIsActiveForWipers", Wipers.getIsActiveForWipers)
end
function Wipers.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", Wipers)
	SpecializationUtil.registerEventListener(p5, "onRegisterDashboardValueTypes", Wipers)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", Wipers)
	SpecializationUtil.registerEventListener(p5, "onFinishAnimation", Wipers)
end
function Wipers.onLoad(p6, _)
	local v7 = p6.spec_wipers
	v7.wipers = {}
	local v8 = 0
	while true do
		local v9 = string.format("vehicle.wipers.wiper(%d)", v8)
		if not p6.xmlFile:hasProperty(v9) then
			break
		end
		local v10 = {}
		if p6:loadWiperFromXML(p6.xmlFile, v9, v10) then
			v10.lastValidState = 1
			v10.lastState = 0
			local v11 = v7.wipers
			table.insert(v11, v10)
		end
		v8 = v8 + 1
	end
	v7.hasWipers = #v7.wipers > 0
	v7.lastRainScale = 0
	v7.maxStateWiper = nil
	local v12 = 0
	for _, v13 in ipairs(v7.wipers) do
		local v14 = #v13.states
		if v12 < v14 then
			v7.maxStateWiper = v13
			v12 = v14
		end
	end
	if not v7.hasWipers then
		SpecializationUtil.removeEventListener(p6, "onUpdateTick", Wipers)
	end
end
function Wipers.onRegisterDashboardValueTypes(p15)
	local v16 = p15.spec_wipers
	if v16.maxStateWiper ~= nil then
		local v17 = DashboardValueType.new("wipers", "state")
		v17:setValue(v16.maxStateWiper, "lastState")
		p15:registerDashboardValueType(v17)
	end
end
function Wipers.onUpdateTick(p18, _, _, _, _)
	local v19 = p18.spec_wipers
	if p18:getIsControlled() then
		v19.lastRainScale = g_currentMission.environment.weather:getRainFallScale()
		for _, v20 in pairs(v19.wipers) do
			local v21 = 0
			if p18:getIsActiveForWipers() and v19.lastRainScale > 0.01 then
				for v22, v23 in ipairs(v20.states) do
					if v19.lastRainScale <= v23.maxRainValue then
						v21 = v22
						break
					end
				end
			end
			if Wipers.forcedState ~= -1 then
				local v24 = Wipers.forcedState
				local v25 = #v20.states
				v21 = math.clamp(v24, 0, v25)
			end
			if v21 > 0 then
				local v26 = v20.states[v21]
				if (v20.nextStartTime == nil or v20.nextStartTime < g_currentMission.time) and not p18:getIsAnimationPlaying(v20.animName) then
					p18:playAnimation(v20.animName, v26.animSpeed, 0, true)
					v20.nextStartTime = nil
				end
				if v20.nextStartTime == nil then
					v20.nextStartTime = g_currentMission.time + v20.animDuration / v26.animSpeed * 2 + v26.animPause
				end
				v20.lastValidState = v21
			end
			v20.lastState = v21
		end
	end
end
function Wipers.onFinishAnimation(p27, p28)
	local v29 = p27.spec_wipers
	for _, v30 in pairs(v29.wipers) do
		if v30.animName == p28 and p27:getAnimationTime(v30.animName) == 1 then
			local v31 = v30.states[v30.lastValidState]
			p27:playAnimation(v30.animName, -v31.animSpeed, 1, true)
		end
	end
end
function Wipers.loadWiperFromXML(p32, p33, p34, p35)
	local v36 = p33:getValue(p34 .. "#animName")
	if v36 == nil then
		Logging.xmlWarning(p32.xmlFile, "Missing animation for wiper \'%s\'!", p34)
		return false
	end
	if not p32:getAnimationExists(v36) then
		Logging.xmlWarning(p32.xmlFile, "Animation \'%s\' not defined for wiper \'%s\'!", v36, p34)
		return false
	end
	p35.animName = v36
	p35.animDuration = p32:getAnimationDuration(v36)
	p35.states = {}
	local v37 = 0
	while true do
		local v38 = string.format("%s.state(%d)", p34, v37)
		if not p33:hasProperty(v38) then
			break
		end
		local v39 = {
			["animSpeed"] = p33:getValue(v38 .. "#animSpeed"),
			["animPause"] = p33:getValue(v38 .. "#animPause")
		}
		if v39.animSpeed ~= nil and v39.animPause ~= nil then
			v39.animPause = v39.animPause * 1000
			local v40 = p35.states
			table.insert(v40, v39)
		end
		v37 = v37 + 1
	end
	local v41 = #p35.states
	if v41 <= 0 then
		Logging.xmlWarning(p32.xmlFile, "No states defined for wiper \'%s\'!", p34)
		return false
	end
	local v42 = 1 / v41
	local v43 = v42
	for _, v44 in ipairs(p35.states) do
		v44.maxRainValue = v42
		v42 = v42 + v43
	end
	p35.nextStartTime = nil
	return true
end
function Wipers.getIsActiveForWipers(_)
	return true
end
function Wipers.consoleSetWiperState(_, p45)
	if p45 == nil then
		return "Error: No arguments given! Usage: gsWiperStateSet <state> (-1 = use state from weather; 0..n = force specific wiper state)"
	end
	local v46 = tonumber(p45)
	if v46 == nil then
		return "Error: Argument is not a number! Usage: gsWiperStateSet <state> (-1 = use state from weather; 0..n = force specific wiper state)"
	end
	Wipers.forcedState = math.clamp(v46, -1, 999)
	return Wipers.forcedState == -1 and " Reset global wiper state, now using weather state" or string.format("Set global wiper states to %d.", Wipers.forcedState)
end
addConsoleCommand("gsWiperStateSet", "Sets the given wiper state for all vehicles", "consoleSetWiperState", Wipers)

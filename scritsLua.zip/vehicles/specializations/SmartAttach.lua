SmartAttach = {}
SmartAttach.DISTANCE_THRESHOLD = 3.5
SmartAttach.ABS_ANGLE_THRESHOLD = 0.3490658503988659
function SmartAttach.prerequisitesPresent(_)
	return true
end
function SmartAttach.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("SmartAttach")
	v1:register(XMLValueType.STRING, "vehicle.smartAttach#jointType", "Joint type name")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.smartAttach#trigger", "Trigger node")
	v1:setXMLSpecializationType()
end
function SmartAttach.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "smartAttachCallback", SmartAttach.smartAttachCallback)
	SpecializationUtil.registerFunction(p2, "getCanBeSmartAttached", SmartAttach.getCanBeSmartAttached)
	SpecializationUtil.registerFunction(p2, "doSmartAttach", SmartAttach.doSmartAttach)
end
function SmartAttach.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", SmartAttach)
	SpecializationUtil.registerEventListener(p3, "onDelete", SmartAttach)
	SpecializationUtil.registerEventListener(p3, "onPreAttach", SmartAttach)
end
function SmartAttach.onLoad(p4, _)
	local v5 = p4.spec_smartAttach
	v5.inputJointDescIndex = nil
	local v6 = p4.xmlFile:getValue("vehicle.smartAttach#jointType")
	if v6 ~= nil then
		local v7 = AttacherJoints.jointTypeNameToInt[v6]
		if v7 == nil then
			printWarning("Warning: invalid jointType " .. v6)
		else
			for v8, v9 in pairs(p4:getInputAttacherJoints()) do
				if v9.jointType == v7 then
					v5.inputJointDescIndex = v8
					break
				end
			end
			v5.jointType = v7
			if v5.inputJointDescIndex == nil then
				printWarning("Warning: SmartAttach jointType not defined in \'" .. p4.configFileName .. "\'!")
			end
		end
	end
	local v10 = p4.xmlFile:getValue("vehicle.smartAttach#trigger", nil, p4.components, p4.i3dMappings)
	if v10 ~= nil then
		v5.trigger = v10
		addTrigger(v5.trigger, "smartAttachCallback", p4)
	end
	v5.targetVehicle = nil
	v5.targetVehicleCount = 0
	v5.jointDescIndex = nil
	v5.activatable = SmartAttachActivatable.new(p4)
end
function SmartAttach.onDelete(p11)
	local v12 = p11.spec_smartAttach
	if v12.activatable ~= nil then
		g_currentMission.activatableObjectsSystem:removeActivatable(v12.activatable)
		v12.activatable = nil
	end
	if v12.trigger ~= nil then
		removeTrigger(v12.trigger)
		v12.trigger = nil
	end
end
function SmartAttach.doSmartAttach(p13, p14, p15, p16, p17)
	SmartAttachEvent.sendEvent(p13, p14, p15, p16, p17)
	if p13.isServer then
		local v18 = p13:getAttacherVehicle()
		if v18 ~= nil then
			v18:detachImplementByObject(p13)
		end
		p14:attachImplement(p13, p15, p16, false)
	end
end
function SmartAttach.getCanBeSmartAttached(p19)
	local v20 = p19.spec_smartAttach
	local v21 = v20.targetVehicle
	if v21 == nil then
		return false
	end
	if not (p19:getIsActiveForInput(true) or v20.targetVehicle:getIsActiveForInput(true)) then
		return false
	end
	local v22 = v21:getAttacherJoints()[v20.jointDescIndex].jointTransform
	local v23 = p19:getInputAttacherJoints()[v20.inputJointDescIndex].node
	local v24, _, v25 = getWorldTranslation(v22)
	local v26, _, v27 = getWorldTranslation(v23)
	local v28 = MathUtil.vector2Length(v24 - v26, v25 - v27)
	local v29 = Utils.getYRotationBetweenNodes(v22, v23)
	local v30
	if v28 < SmartAttach.DISTANCE_THRESHOLD then
		v30 = math.abs(v29) < SmartAttach.ABS_ANGLE_THRESHOLD
	else
		v30 = false
	end
	return v30
end
function SmartAttach.onPreAttach(p31)
	local v32 = p31.spec_smartAttach
	v32.targetVehicle = nil
	v32.targetVehicleCount = 0
end
function SmartAttach.smartAttachCallback(p33, _, p34, p35, p36, _, _)
	local v37 = p33.spec_smartAttach
	if p35 then
		local v38 = g_currentMission.nodeToObject[p34]
		if v38 ~= nil then
			if v37.targetVehicle == nil and (v38 ~= nil and (v38 ~= p33 and v38.getAttacherJoints ~= nil)) then
				for v39, v40 in ipairs(v38:getAttacherJoints()) do
					if v40.jointIndex == 0 and v40.jointType == v37.jointType then
						v37.targetVehicle = v38
						v37.jointDescIndex = v39
						v37.targetVehicleCount = 0
						local v41 = Utils.getNoNil(p33.typeDesc, "")
						local v42 = g_storeManager:getItemByXMLFilename(p33.configFileName:lower())
						if v42 ~= nil then
							v41 = v42.name
						end
						if p33:getAttacherVehicle() == nil then
							v37.activatable.activateText = string.format(g_i18n:getText("action_doSmartAttachGround", p33.customEnvironment), v41)
						else
							v37.activatable.activateText = string.format(g_i18n:getText("action_doSmartAttachTransform", p33.customEnvironment), v41)
						end
						g_currentMission.activatableObjectsSystem:addActivatable(v37.activatable)
						break
					end
				end
			end
			if v38 == v37.targetVehicle then
				v37.targetVehicleCount = v37.targetVehicleCount + 1
				return
			end
		end
	elseif p36 and v37.targetVehicle ~= nil then
		local v43 = g_currentMission.nodeToObject[p34]
		if v43 ~= nil and v43 == v37.targetVehicle then
			v37.targetVehicleCount = v37.targetVehicleCount - 1
			if v37.targetVehicleCount <= 0 then
				v37.targetVehicle = nil
				g_currentMission.activatableObjectsSystem:removeActivatable(v37.activatable)
				v37.targetVehicleCount = 0
			end
		end
	end
end
SmartAttachActivatable = {}
local v_u_44 = Class(SmartAttachActivatable)
function SmartAttachActivatable.new(p45)
	-- upvalues: (copy) v_u_44
	local v46 = v_u_44
	local v47 = setmetatable({}, v46)
	v47.smartAttachVehicle = p45
	v47.activateText = ""
	return v47
end
function SmartAttachActivatable.getIsActivatable(p48)
	return p48.smartAttachVehicle:getCanBeSmartAttached()
end
function SmartAttachActivatable.run(p49)
	local v50 = p49.smartAttachVehicle
	local v51 = v50.spec_smartAttach
	v50:doSmartAttach(v51.targetVehicle, v51.inputJointDescIndex, v51.jointDescIndex)
end
SmartAttachEvent = {}
local v_u_52 = Class(SmartAttachEvent, Event)
InitStaticEventClass(SmartAttachEvent, "SmartAttachEvent")
function SmartAttachEvent.emptyNew()
	-- upvalues: (copy) v_u_52
	return Event.new(v_u_52)
end
function SmartAttachEvent.new(p53, p54, p55, p56)
	local v57 = SmartAttachEvent.emptyNew()
	v57.vehicle = p53
	v57.targetVehicle = p54
	v57.inputJointDescIndex = p55
	v57.jointDescIndex = p56
	return v57
end
function SmartAttachEvent.readStream(p58, p59, p60)
	p58.vehicle = NetworkUtil.readNodeObject(p59)
	p58.targetVehicle = NetworkUtil.readNodeObject(p59)
	p58.inputJointDescIndex = streamReadUIntN(p59, 7)
	p58.jointDescIndex = streamReadUIntN(p59, 7)
	p58:run(p60)
end
function SmartAttachEvent.writeStream(p61, p62, _)
	NetworkUtil.writeNodeObject(p62, p61.vehicle)
	NetworkUtil.writeNodeObject(p62, p61.targetVehicle)
	streamWriteUIntN(p62, p61.inputJointDescIndex, 7)
	streamWriteUIntN(p62, p61.jointDescIndex, 7)
end
function SmartAttachEvent.run(p63, p64)
	p63.vehicle:doSmartAttach(p63.targetVehicle, p63.inputJointDescIndex, p63.jointDescIndex, true)
	if not p64:getIsServer() then
		g_server:broadcastEvent(SmartAttachEvent.new(p63.vehicle, p63.targetVehicle, p63.inputJointDescIndex, p63.jointDescIndex), nil, p64, p63.vehicle)
	end
end
function SmartAttachEvent.sendEvent(p65, p66, p67, p68, p69)
	if p69 == nil or p69 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(SmartAttachEvent.new(p65, p66, p67, p68), nil, nil, p65)
			return
		end
		g_client:getServerConnection():sendEvent(SmartAttachEvent.new(p65, p66, p67, p68))
	end
end

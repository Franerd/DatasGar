PushHandTool = {}
PushHandTool.PLAYER_COLLISION_MASK = PlayerCCT.DEFAULT_MOVEMENT_COLLISION_MASK
source("dataS/scripts/vehicles/specializations/events/PushHandToolDriveModeEvent.lua")
function PushHandTool.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("PushHandTool")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pushHandTool.raycast#node1", "Front raycast node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pushHandTool.raycast#node2", "Back raycast node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pushHandTool.raycast#playerNode", "Player node to adjust")
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.raycast#positionSmoothnessFactor", "Defines how delayed the player position can be (lower value is a higher delay)", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.raycast#positionSmoothnessFactorReverse", "Smoothness factor while reversing", "same as #positionSmoothnessFactor")
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.raycast#positionSmoothnessFactorSteering", "Defines additional delay when the vehicle is fully steered (high value is a higher delay)", 0.15)
	v1:register(XMLValueType.VECTOR_N, "vehicle.pushHandTool.wheels#front", "Indices of front wheels")
	v1:register(XMLValueType.VECTOR_N, "vehicle.pushHandTool.wheels#back", "Indices of back wheels")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.pushHandTool.handle#node", "Handle node")
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.handle#upperLimit", "Max. upper distance between handle node and hand ik root node", 0.4)
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.handle#lowerLimit", "Max. lower distance between handle node and hand ik root node", 0.4)
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.handle#interpolateDistance", "Interpolation distance if limit is exceeded", 0.4)
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.handle#minRot", "Min. rotation of handle", -20)
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.handle#maxRot", "Max. rotation of handle", 20)
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.spine#rotationForward", "Spine rotation while moving forward")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.spine#rotationBackward", "Spine rotation while moving backward")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.spine#rotationIdle", "Spine rotation while in idle position")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.spine#speed", "Speed of adjustment (degree per second)", 10)
	v1:register(XMLValueType.VECTOR_3, "vehicle.pushHandTool.spine#ratio", "Ratio between the 3 spine nodes to apply the rotation", "0.33 0.33 0.33")
	IKUtil.registerIKChainTargetsXMLPaths(v1, "vehicle.pushHandTool.ikChains")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.pushHandTool.effect")
	v1:register(XMLValueType.STRING, "vehicle.pushHandTool.driveMode#animationName", "Name of toggle mode animation", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.driveMode#animationSpeed", "Animation speed scale", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.driveMode#maxSpeed", "Max. vehicle speed while drive mode is enabled")
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.driveMode#gearRatio", "Min. gear ratio while drive mode is enabled")
	VehicleCharacter.registerCharacterXMLPaths(v1, "vehicle.pushHandTool.driveMode.characterNode")
	v1:register(XMLValueType.STRING, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#chainId", "Chain identifier string", 20)
	v1:register(XMLValueType.INT, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#nodeIndex", "Index of node")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#minRx", "Min. X rotation")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#maxRx", "Max. X rotation")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#minRy", "Min. Y rotation")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#maxRy", "Max. Y rotation")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#minRz", "Min. Z rotation")
	v1:register(XMLValueType.ANGLE, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#maxRz", "Max. Z rotation")
	v1:register(XMLValueType.FLOAT, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#damping", "Damping")
	v1:register(XMLValueType.BOOL, "vehicle.pushHandTool.customChainLimits.customChainLimit(?)#localLimits", "Local limits")
	ConditionalAnimation.registerXMLPaths(v1, "vehicle.pushHandTool.playerConditionalAnimation")
	v1:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.BOOL, "vehicles.vehicle(?).pushHandTool#driveModeIsActive", "DriveMode is active")
end
function PushHandTool.prerequisitesPresent(p2)
	return SpecializationUtil.hasSpecialization(Enterable, p2)
end
function PushHandTool.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getRaycastPosition", PushHandTool.getRaycastPosition)
	SpecializationUtil.registerFunction(p3, "playerRaycastCallback", PushHandTool.playerRaycastCallback)
	SpecializationUtil.registerFunction(p3, "postAnimationUpdate", PushHandTool.postAnimationUpdate)
	SpecializationUtil.registerFunction(p3, "customVehicleCharacterLoaded", PushHandTool.customVehicleCharacterLoaded)
	SpecializationUtil.registerFunction(p3, "setPushHandToolDriveMode", PushHandTool.setPushHandToolDriveMode)
end
function PushHandTool.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "setVehicleCharacter", PushHandTool.setVehicleCharacter)
	SpecializationUtil.registerOverwrittenFunction(p4, "deleteVehicleCharacter", PushHandTool.deleteVehicleCharacter)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAllowCharacterVisibilityUpdate", PushHandTool.getAllowCharacterVisibilityUpdate)
	SpecializationUtil.registerOverwrittenFunction(p4, "setActiveCameraIndex", PushHandTool.setActiveCameraIndex)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsFoldAllowed", PushHandTool.getIsFoldAllowed)
end
function PushHandTool.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onDelete", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onReadStream", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onUpdate", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onRegisterActionEvents", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onEnterVehicle", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onCameraChanged", PushHandTool)
	SpecializationUtil.registerEventListener(p5, "onVehicleCharacterChanged", PushHandTool)
end
function PushHandTool.onLoad(p_u_6, _)
	local v_u_7 = p_u_6.spec_pushHandTool
	v_u_7.animationParameters = {}
	v_u_7.animationParameters.absSmoothedForwardVelocity = {
		["id"] = 1,
		["value"] = 0,
		["type"] = 1
	}
	v_u_7.animationParameters.smoothedForwardVelocity = {
		["id"] = 2,
		["value"] = 0,
		["type"] = 1
	}
	v_u_7.animationParameters.accelerate = {
		["id"] = 3,
		["value"] = false,
		["type"] = 0
	}
	v_u_7.animationParameters.leftRightWeight = {
		["id"] = 4,
		["value"] = 0,
		["type"] = 1
	}
	v_u_7.raycastNode1 = p_u_6.xmlFile:getValue("vehicle.pushHandTool.raycast#node1", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.raycastNode2 = p_u_6.xmlFile:getValue("vehicle.pushHandTool.raycast#node2", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.playerNode = p_u_6.xmlFile:getValue("vehicle.pushHandTool.raycast#playerNode", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.playerTargetNode = createTransformGroup("playerTargetNode")
	if v_u_7.playerNode ~= nil then
		link(getParent(v_u_7.playerNode), v_u_7.playerTargetNode)
		setTranslation(v_u_7.playerTargetNode, getTranslation(v_u_7.playerNode))
	end
	v_u_7.positionSmoothnessFactor = p_u_6.xmlFile:getValue("vehicle.pushHandTool.raycast#positionSmoothnessFactor", 1)
	v_u_7.positionSmoothnessFactorReverse = p_u_6.xmlFile:getValue("vehicle.pushHandTool.raycast#positionSmoothnessFactorReverse", v_u_7.positionSmoothnessFactor)
	v_u_7.positionSmoothnessFactorSteering = p_u_6.xmlFile:getValue("vehicle.pushHandTool.raycast#positionSmoothnessFactorSteering", 0.15)
	local v8 = p_u_6.xmlFile:getValue("vehicle.pushHandTool.wheels#front", nil, true)
	v_u_7.frontWheels = {}
	if v8 ~= nil then
		for v9 = 1, #v8 do
			local v10 = p_u_6:getWheelFromWheelIndex(v8[v9])
			if v10 ~= nil then
				local v11 = v_u_7.frontWheels
				table.insert(v11, v10)
			end
		end
	end
	local v12 = p_u_6.xmlFile:getValue("vehicle.pushHandTool.wheels#back", nil, true)
	v_u_7.backWheels = {}
	if v12 ~= nil then
		for v13 = 1, #v12 do
			local v14 = p_u_6:getWheelFromWheelIndex(v12[v13])
			if v14 ~= nil then
				local v15 = v_u_7.backWheels
				table.insert(v15, v14)
			end
		end
	end
	v_u_7.handle = {}
	v_u_7.handle.node = p_u_6.xmlFile:getValue("vehicle.pushHandTool.handle#node", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.handle.upperLimit = p_u_6.xmlFile:getValue("vehicle.pushHandTool.handle#upperLimit", 0.4)
	v_u_7.handle.lowerLimit = p_u_6.xmlFile:getValue("vehicle.pushHandTool.handle#lowerLimit", 0.4)
	v_u_7.handle.interpolateDistance = p_u_6.xmlFile:getValue("vehicle.pushHandTool.handle#interpolateDistance", 0.4)
	v_u_7.handle.minRot = p_u_6.xmlFile:getValue("vehicle.pushHandTool.handle#minRot", -20)
	v_u_7.handle.maxRot = p_u_6.xmlFile:getValue("vehicle.pushHandTool.handle#maxRot", 20)
	v_u_7.spine = {}
	v_u_7.spine.node = nil
	v_u_7.spine.rotationForward = p_u_6.xmlFile:getValue("vehicle.pushHandTool.spine#rotationForward")
	v_u_7.spine.rotationBackward = p_u_6.xmlFile:getValue("vehicle.pushHandTool.spine#rotationBackward")
	v_u_7.spine.rotationIdle = p_u_6.xmlFile:getValue("vehicle.pushHandTool.spine#rotationIdle")
	v_u_7.spine.speed = p_u_6.xmlFile:getValue("vehicle.pushHandTool.spine#speed", 10) * 0.001
	v_u_7.spine.ratio = p_u_6.xmlFile:getValue("vehicle.pushHandTool.spine#ratio", "0.33 0.33 0.33", true)
	v_u_7.spine.currentRotation = v_u_7.spine.rotationIdle
	local v16 = v_u_7.spine
	local v17
	if v_u_7.spine.rotationForward == nil or v_u_7.spine.rotationBackward == nil then
		v17 = false
	else
		v17 = v_u_7.spine.rotationIdle ~= nil
	end
	v16.doAdjustment = v17
	v_u_7.characterIKNodes = {}
	v_u_7.ikChainTargets = {}
	IKUtil.loadIKChainTargets(p_u_6.xmlFile, "vehicle.pushHandTool.ikChains", p_u_6.components, v_u_7.ikChainTargets, p_u_6.i3dMappings)
	v_u_7.lastRaycastPosition = {
		0,
		0,
		0,
		0
	}
	v_u_7.lastRaycastHit = false
	if p_u_6.isClient then
		v_u_7.cutterEffects = g_effectManager:loadEffect(p_u_6.xmlFile, "vehicle.pushHandTool.effect", p_u_6.components, p_u_6, p_u_6.i3dMappings)
	end
	v_u_7.customChainLimits = {}
	p_u_6.xmlFile:iterate("vehicle.pushHandTool.customChainLimits.customChainLimit", function(_, p18)
		-- upvalues: (copy) p_u_6, (copy) v_u_7
		local v19 = {
			["chainId"] = p_u_6.xmlFile:getValue(p18 .. "#chainId"),
			["nodeIndex"] = p_u_6.xmlFile:getValue(p18 .. "#nodeIndex")
		}
		if v19.chainId ~= nil and v19.nodeIndex ~= nil then
			v19.minRx = p_u_6.xmlFile:getValue(p18 .. "#minRx")
			v19.maxRx = p_u_6.xmlFile:getValue(p18 .. "#maxRx")
			v19.minRy = p_u_6.xmlFile:getValue(p18 .. "#minRy")
			v19.maxRy = p_u_6.xmlFile:getValue(p18 .. "#maxRy")
			v19.minRz = p_u_6.xmlFile:getValue(p18 .. "#minRz")
			v19.maxRz = p_u_6.xmlFile:getValue(p18 .. "#maxRz")
			v19.damping = p_u_6.xmlFile:getValue(p18 .. "#damping")
			v19.localLimits = p_u_6.xmlFile:getValue(p18 .. "#localLimits")
			local v20 = v_u_7.customChainLimits
			table.insert(v20, v19)
		end
	end)
	v_u_7.driveMode = {}
	v_u_7.driveMode.animationName = p_u_6.xmlFile:getValue("vehicle.pushHandTool.driveMode#animationName")
	v_u_7.driveMode.animationSpeed = p_u_6.xmlFile:getValue("vehicle.pushHandTool.driveMode#animationSpeed", 1)
	v_u_7.driveMode.baseSpeed = p_u_6.spec_motorized.motor.maxForwardSpeed
	v_u_7.driveMode.baseGearRatio = p_u_6.spec_motorized.motor.minForwardGearRatio
	v_u_7.driveMode.maxSpeed = p_u_6.xmlFile:getValue("vehicle.pushHandTool.driveMode#maxSpeed")
	if v_u_7.driveMode.maxSpeed ~= nil then
		v_u_7.driveMode.maxSpeed = v_u_7.driveMode.maxSpeed / 3.6
	end
	v_u_7.driveMode.gearRatio = p_u_6.xmlFile:getValue("vehicle.pushHandTool.driveMode#gearRatio")
	v_u_7.driveMode.vehicleCharacter = VehicleCharacter.new(p_u_6)
	if v_u_7.driveMode.vehicleCharacter ~= nil and not v_u_7.driveMode.vehicleCharacter:load(p_u_6.xmlFile, "vehicle.pushHandTool.driveMode.characterNode") then
		v_u_7.driveMode.vehicleCharacter = nil
	end
	v_u_7.driveMode.isActive = false
	v_u_7.effectDirtyFlag = p_u_6:getNextDirtyFlag()
	v_u_7.effectsAreRunning = false
	v_u_7.lastFruitTypeIndex = FruitType.UNKNOWN
	v_u_7.lastFruitGrowthState = 0
	v_u_7.raycastsValid = true
	v_u_7.lastSmoothSpeed = 0
	if p_u_6.setTestAreaRequirements ~= nil then
		p_u_6:setTestAreaRequirements(FruitType.GRASS, nil, false)
	end
	v_u_7.postAnimationCallback = addPostAnimationCallback(p_u_6.postAnimationUpdate, p_u_6)
end
function PushHandTool.onPostLoad(p21, p22)
	local v23 = p21.spec_pushHandTool
	if p22 ~= nil and p22.xmlFile:getValue(p22.key .. ".pushHandTool#driveModeIsActive", false) then
		p21:setPushHandToolDriveMode(true, true)
		AnimatedVehicle.updateAnimationByName(p21, v23.driveMode.animationName, 99999, true)
	end
end
function PushHandTool.onDelete(p24)
	local v25 = p24.spec_pushHandTool
	g_effectManager:deleteEffects(v25.cutterEffects)
	removePostAnimationCallback(v25.postAnimationCallback)
end
function PushHandTool.saveToXMLFile(p26, p27, p28, _)
	local v29 = p26.spec_pushHandTool
	if v29.driveMode.animationName ~= nil then
		p27:setValue(p28 .. "#driveModeIsActive", v29.driveMode.isActive)
	end
end
function PushHandTool.onReadStream(p30, p31, _)
	local v32 = p30.spec_pushHandTool
	p30:setPushHandToolDriveMode(streamReadBool(p31), true)
	AnimatedVehicle.updateAnimationByName(p30, v32.driveMode.animationName, 99999, true)
end
function PushHandTool.onWriteStream(p33, p34, _)
	local v35 = p33.spec_pushHandTool
	streamWriteBool(p34, v35.driveMode.isActive)
end
function PushHandTool.onReadUpdateStream(p36, p37, _, p38)
	if p38:getIsServer() then
		local v39 = p36.spec_pushHandTool
		local v40 = streamReadBool(p37)
		if v40 then
			v39.lastFruitGrowthState = streamReadUIntN(p37, 4)
			v39.lastFruitTypeIndex = streamReadUIntN(p37, FruitTypeManager.SEND_NUM_BITS)
		end
		if v40 ~= v39.effectsAreRunning then
			v39.effectsAreRunning = v40
			if not v40 then
				g_effectManager:stopEffects(v39.cutterEffects)
			end
		end
	end
end
function PushHandTool.onWriteUpdateStream(p41, p42, p43, _)
	if not p43:getIsServer() then
		local v44 = p41.spec_pushHandTool
		if streamWriteBool(p42, v44.effectsAreRunning) then
			streamWriteUIntN(p42, v44.lastFruitGrowthState, 4)
			streamWriteUIntN(p42, v44.lastFruitTypeIndex, FruitTypeManager.SEND_NUM_BITS)
		end
	end
end
function PushHandTool.onUpdate(p45, p46, _, _, _)
	local v47 = p45.spec_pushHandTool
	if p45.getTestAreaWidthByWorkAreaIndex ~= nil then
		if p45:getIsTurnedOn() and p45:getLastSpeed() > 0.5 then
			local v48, v49, v50, v51 = p45:getTestAreaWidthByWorkAreaIndex(1)
			local v52
			if v48 == (-1 / 0) and v49 == (1 / 0) then
				v48 = 0
				v49 = 0
				v52 = true
			else
				v52 = false
			end
			local v53
			if p45.movingDirection > 0 then
				v53 = v48 * -1
				v48 = v49 * -1
				if v48 >= v53 then
					local v54 = v53
					v53 = v48
					v48 = v54
				end
			else
				v53 = v49
			end
			local v55, v56, v57
			if p45.isServer then
				v55 = FruitType.UNKNOWN
				v56 = 3
				if p45.spec_mower ~= nil then
					local v58 = p45.spec_mower
					if g_time - v58.workAreaParameters.lastCutTime < 500 then
						v55 = v58.workAreaParameters.lastInputFruitType
						v56 = v58.workAreaParameters.lastInputGrowthState
					end
				end
				v57 = not v52
				if v57 then
					if v55 == nil then
						v57 = false
					else
						v57 = v55 ~= FruitType.UNKNOWN
					end
				end
				if v57 then
					if not v47.effectsAreRunning then
						v47.effectsAreRunning = true
						p45:raiseDirtyFlags(v47.effectDirtyFlag)
					end
				elseif v47.effectsAreRunning then
					g_effectManager:stopEffects(v47.cutterEffects)
					v47.effectsAreRunning = false
					p45:raiseDirtyFlags(v47.effectDirtyFlag)
				end
				v47.lastFruitTypeIndex = v55
				v47.lastFruitGrowthState = v56
			else
				v55 = v47.lastFruitTypeIndex
				v56 = v47.lastFruitGrowthState
				v57 = v47.effectsAreRunning
				if v57 then
					v57 = v47.lastFruitTypeIndex ~= FruitType.UNKNOWN
				end
			end
			if v57 then
				g_effectManager:setEffectTypeInfo(v47.cutterEffects, nil, v55, v56)
				g_effectManager:setMinMaxWidth(v47.cutterEffects, v48, v53, v48 / v50, v53 / v51, v52)
				g_effectManager:startEffects(v47.cutterEffects)
			end
		elseif v47.effectsAreRunning then
			g_effectManager:stopEffects(v47.cutterEffects)
			v47.effectsAreRunning = false
			p45:raiseDirtyFlags(v47.effectDirtyFlag)
		end
	end
	local v59 = p45.lastSignedSpeed * 1000
	local v60 = 0
	local v61 = 0
	for _, v62 in pairs(v47.backWheels) do
		if v62.physics.netInfo.xDriveSpeed ~= nil then
			v60 = v60 + MathUtil.rpmToMps(v62.physics.netInfo.xDriveSpeed / 6.283185307179586 * 60, v62.physics.radius) * 1000
			v61 = v61 + 1
		end
	end
	if v61 > 0 then
		v59 = v60 / v61
	end
	v47.lastSmoothSpeed = v47.lastSmoothSpeed * 0.9 + v59 * 0.1
	v47.animationParameters.smoothedForwardVelocity.value = v47.lastSmoothSpeed
	local v63 = v47.animationParameters.absSmoothedForwardVelocity
	local v64 = v47.lastSmoothSpeed
	v63.value = math.abs(v64)
	v47.animationParameters.leftRightWeight.value = p45.rotatedTime
	v47.animationParameters.accelerate.value = p45:getAccelerationAxis() > 0
	if p45:getIsEntered() or (p45:getIsControlled() or p45:getIsAIActive()) then
		local v65 = p45:getVehicleCharacter()
		if v65 ~= nil and (v65.animationCharsetId ~= nil and v65.animationPlayer ~= nil) then
			for _, v66 in pairs(v47.animationParameters) do
				if v66.type == 0 then
					setConditionalAnimationBoolValue(v65.animationPlayer, v66.id, v66.value)
				elseif v66.type == 1 then
					setConditionalAnimationFloatValue(v65.animationPlayer, v66.id, v66.value)
				end
			end
			setConditionalAnimationSpecificParameterIds(v65.animationPlayer, v47.animationParameters.absSmoothedForwardVelocity.id, 0)
			updateConditionalAnimation(v65.animationPlayer, p46)
		end
		if v47.driveMode.vehicleCharacter ~= nil and (v47.driveMode.isActive and not p45:getIsAnimationPlaying(v47.driveMode.animationName)) then
			v47.driveMode.vehicleCharacter:update(p46)
		end
	end
	if v47.spine.doAdjustment then
		local v67 = v47.spine.rotationIdle
		if p45:getLastSpeed() > 0.75 then
			if p45.movingDirection > 0 then
				v67 = v47.spine.rotationForward
			elseif p45.movingDirection < 0 then
				v67 = v47.spine.rotationBackward
			end
		end
		local v68 = v67 - v47.spine.currentRotation
		local v69 = math.sign(v68)
		local v70 = v69 > 0 and math.min or math.max
		v47.spine.currentRotation = v70(v47.spine.currentRotation + v69 * p46 * v47.spine.speed, v67)
	end
	if v47.raycastNode1 ~= nil and (v47.raycastNode2 ~= nil and (v47.playerNode ~= nil and (#v47.frontWheels >= 1 and #v47.backWheels >= 1))) then
		local v71, v72, v73 = p45:getRaycastPosition(v47.raycastNode1)
		local v74, v75, v76 = p45:getRaycastPosition(v47.raycastNode2)
		if v71 ~= nil and v74 ~= nil then
			local v77 = (v71 + v74) * 0.5
			local v78 = (v72 + v75) * 0.5
			local v79 = (v73 + v76) * 0.5
			setWorldTranslation(v47.playerTargetNode, v77, v78, v79)
			local v80 = v71 - v74
			local v81 = v72 - v75
			local v82 = v73 - v76
			local v83, v84, v85 = MathUtil.vector3Normalize(v80, v81, v82)
			if v47.lastYDirection == nil then
				v47.lastYDirection = v84
			else
				v84 = v47.lastYDirection * 0.9 + v84 * 0.1
				v47.lastYDirection = v84
			end
			I3DUtil.setWorldDirection(v47.playerTargetNode, v83, v84, v85, 0, 1, 0)
			if v47.lastWorldTrans == nil then
				v47.lastWorldTrans = { getWorldTranslation(v47.playerNode) }
			end
			local v86 = v47.lastWorldTrans[1]
			local v87 = v47.lastWorldTrans[2]
			local v88 = v47.lastWorldTrans[3]
			local v89 = p45.rotatedTime / 0.5
			local v90 = math.abs(v89)
			local v91 = (0.3 - math.min(v90, 1) * v47.positionSmoothnessFactorSteering) * (p45.movingDirection > 0 and v47.positionSmoothnessFactor or v47.positionSmoothnessFactorReverse)
			local v92 = (v86 - v77) * v91
			local v93 = (v87 - v78) * v91
			local v94 = (v88 - v79) * v91
			local v95 = v86 - v92
			local v96 = v87 - v93
			local v97 = v88 - v94
			setWorldTranslation(v47.playerNode, v95, v96, v97)
			local v98 = v47.lastWorldTrans
			local v99 = v47.lastWorldTrans
			local v100 = v47.lastWorldTrans
			v98[1] = v95
			v99[2] = v96
			v100[3] = v97
			local v101 = p45.movingDirection
			local v102 = v101 == 0 and 1 or v101
			local v103, v104, v105 = localToWorld(v47.playerTargetNode, 0, 0, 0.2 * v102)
			local v106 = v103 - v95
			local v107 = v104 - v96
			local v108 = v105 - v97
			local v109, _, v110 = MathUtil.vector3Normalize(v106, v107, v108)
			if v102 < 0 then
				v109 = -v109
				v110 = -v110
			end
			local v111 = #v47.frontWheels
			local v112 = 0
			local v113 = 0
			local v114 = 0
			for v115 = 1, v111 do
				local v116 = v47.frontWheels[v115]
				local v117 = v116.physics.netInfo.x
				local v118 = v116.physics.netInfo.y
				local v119 = v116.physics.netInfo.z
				local v120 = v118 - v116.physics.radius
				local v121, v122, v123 = localToWorld(v116.node, v117, v120, v119)
				v112 = v112 + v121
				v113 = v113 + v122
				v114 = v114 + v123
			end
			local v124 = v112 / v111
			local v125 = v113 / v111
			local v126 = v114 / v111
			local v127 = #v47.backWheels
			local v128 = 0
			local v129 = 0
			local v130 = 0
			for v131 = 1, v127 do
				local v132 = v47.backWheels[v131]
				local v133 = v132.physics.netInfo.x
				local v134 = v132.physics.netInfo.y
				local v135 = v132.physics.netInfo.z
				local v136 = v134 - v132.physics.radius
				local v137, v138, v139 = localToWorld(v132.node, v133, v136, v135)
				v128 = v128 + v137
				v129 = v129 + v138
				v130 = v130 + v139
			end
			local v140 = v128 / v127
			local v141 = v129 / v127
			local v142 = v130 / v127
			local v143 = v140 - v124
			local v144 = v141 - v125
			local v145 = v142 - v126
			local _, v146, _ = MathUtil.vector3Normalize(v143, v144, v145)
			local v147 = v146 < 0 and 1 or -1
			local v148 = math.abs(v146)
			local v149 = v146 + math.min(0.15, v148) * v147
			local v150, v151, v152 = localDirectionToWorld(p45.rootNode, 0, 1, 0)
			local v153 = v151 + 0.5
			local v154, v155, v156 = MathUtil.vector3Normalize(v150, v153, v152)
			I3DUtil.setWorldDirection(v47.playerNode, v109, v149, v110, v154, v155, v156)
			v47.raycastsValid = true
			return
		end
		if v47.raycastsValid and p45:getIsEntered() then
			v47.raycastsValid = false
			local v157 = p45:getVehicleCharacter()
			if v157 ~= nil then
				v157:setCharacterVisibility(false)
			end
			p45:setActiveCameraIndex(p45.spec_enterable.camIndex)
		end
	end
end
function PushHandTool.onRegisterActionEvents(p158, _, p159)
	if p158.isClient then
		local v160 = p158.spec_pushHandTool
		if v160.driveMode.vehicleCharacter ~= nil then
			p158:clearActionEventsTable(v160.actionEvents)
			if p159 then
				local _, v161 = p158:addPoweredActionEvent(v160.actionEvents, InputAction.IMPLEMENT_EXTRA4, p158, PushHandTool.actionEventToggleDriveMode, false, true, false, true, 1)
				g_inputBinding:setActionEventTextPriority(v161, GS_PRIO_NORMAL)
				g_inputBinding:setActionEventText(v161, g_i18n:getText("action_changeDriveMode"))
			end
		end
	end
end
function PushHandTool.actionEventToggleDriveMode(p162, _, _, _, _)
	p162:setPushHandToolDriveMode()
end
function PushHandTool.setVehicleCharacter(p163, _, p164)
	local v165 = p163.spec_enterable
	if v165.vehicleCharacter ~= nil then
		v165.vehicleCharacter:delete()
		v165.vehicleCharacter:loadCharacter(p164, p163, p163.customVehicleCharacterLoaded)
	end
	local v166 = p163.spec_pushHandTool
	if v166.driveMode.vehicleCharacter ~= nil and p164 ~= nil then
		v166.driveMode.vehicleCharacter:loadCharacter(p164, p163, PushHandTool.driveModeVehicleCharacterLoaded, {})
	end
end
function PushHandTool.deleteVehicleCharacter(p167, p168)
	p168(p167)
	local v169 = p167.spec_pushHandTool
	if v169.driveMode.vehicleCharacter ~= nil then
		v169.driveMode.vehicleCharacter:unloadCharacter()
	end
end
function PushHandTool.customVehicleCharacterLoaded(p170, p171, _)
	local v172 = p170.spec_enterable
	if p171 == HumanModelLoadingState.OK then
		local v173 = v172.vehicleCharacter
		if v173 ~= nil then
			v173:updateVisibility()
		end
		SpecializationUtil.raiseEvent(p170, "onVehicleCharacterChanged", v173)
		local v174 = p170.spec_pushHandTool
		v174.characterIKNodes = {}
		v174.spine.node = v173.playerModel.thirdPersonSpineNode
		for v175, v176 in pairs(v173.playerModel.ikChains) do
			if v174.ikChainTargets[v175] ~= nil then
				for _, v177 in pairs(v176.nodes) do
					if v174.characterIKNodes[v177.node] == nil then
						local v178 = createTransformGroup(getName(v177.node) .. "_ikChain")
						local v179 = getParent(v177.node)
						if v174.characterIKNodes[v179] ~= nil then
							v179 = v174.characterIKNodes[v179]
						end
						link(v179, v178)
						setTranslation(v178, getTranslation(v177.node))
						setRotation(v178, getRotation(v177.node))
						v174.characterIKNodes[v177.node] = v178
					end
				end
			end
			for _, v180 in pairs(v176.nodes) do
				if v174.characterIKNodes[v180.node] ~= nil then
					v180.node = v174.characterIKNodes[v180.node]
				end
			end
		end
		v173.ikChainTargets = v174.ikChainTargets
		for v181, v182 in pairs(v174.ikChainTargets) do
			IKUtil.setTarget(v173.playerModel.ikChains, v181, v182)
		end
		v174.ikChains = v173.playerModel.ikChains
		for v183, v184 in pairs(v173.playerModel.ikChains) do
			v184.ikChainSolver = IKChain.new(#v184.nodes)
			for v185, v186 in ipairs(v184.nodes) do
				local v187 = v186.minRx
				local v188 = v186.maxRx
				local v189 = v186.minRy
				local v190 = v186.maxRy
				local v191 = v186.minRz
				local v192 = v186.maxRz
				local v193 = v186.damping
				local v194 = v186.localLimits
				for v195 = 1, #v174.customChainLimits do
					local v196 = v174.customChainLimits[v195]
					if v196.chainId == v183 and v196.nodeIndex == v185 then
						v187 = v196.minRx or v187
						v188 = v196.maxRx or v188
						v189 = v196.minRy or v189
						v190 = v196.maxRy or v190
						v191 = v196.minRz or v191
						v192 = v196.maxRz or v192
						v193 = v196.damping or v193
						if v196.localLimits ~= nil then
							v194 = v196.localLimits
						end
					end
				end
				v184.ikChainSolver:setJointTransformGroup(v185 - 1, v186.node, v187, v188, v189, v190, v191, v192, v193, v194)
			end
			v184.numIterations = 40
			v184.positionThreshold = 0.0001
		end
		v173:setDirty()
		if v173 ~= nil and (v173.animationCharsetId ~= nil and v173.animationPlayer ~= nil) then
			for v197, v198 in pairs(v174.animationParameters) do
				conditionalAnimationRegisterParameter(v173.animationPlayer, v198.id, v198.type, v197)
			end
			initConditionalAnimation(v173.animationPlayer, v173.animationCharsetId, p170.configFileName, "vehicle.pushHandTool.playerConditionalAnimation")
			conditionalAnimationZeroiseTrackTimes(v173.animationPlayer)
		end
	end
end
function PushHandTool.driveModeVehicleCharacterLoaded(p199, p200, _)
	if p200 == HumanModelLoadingState.OK then
		local v201 = p199.spec_pushHandTool
		if v201.driveMode.vehicleCharacter ~= nil then
			local v202 = p199:getActiveCamera()
			if v202 ~= nil then
				v201.driveMode.vehicleCharacter:setCharacterVisibility(not v202.isInside)
			end
			v201.driveMode.vehicleCharacter:updateIKChains()
		end
	end
end
function PushHandTool.setPushHandToolDriveMode(p203, p204, p205)
	local v206 = p203.spec_pushHandTool
	if p204 == nil then
		p204 = not v206.driveMode.isActive
	end
	if v206.driveMode.isActive ~= p204 then
		v206.driveMode.isActive = p204
		p203.spec_motorized.motor.maxForwardSpeed = p204 and v206.driveMode.maxSpeed or v206.driveMode.baseSpeed
		p203.spec_motorized.motor.minForwardGearRatio = p204 and v206.driveMode.gearRatio or v206.driveMode.baseGearRatio
		p203.spec_drivable.cruiseControl.maxSpeed = p203.spec_motorized.motor.maxForwardSpeed * 3.6
		local v207 = p203.spec_drivable.cruiseControl.speed
		local v208 = p203.spec_drivable.cruiseControl.maxSpeed
		p203:setCruiseControlMaxSpeed(math.min(v207, v208), nil)
		p203:playAnimation(v206.driveMode.animationName, p204 and v206.driveMode.animationSpeed or -v206.driveMode.animationSpeed, p203:getAnimationTime(v206.driveMode.animationName), true)
		p203:setFoldState(p203.spec_foldable.turnOnFoldDirection, false, true)
		if v206.driveMode.vehicleCharacter ~= nil then
			local v209 = p203:getVehicleCharacter()
			if v209 ~= nil then
				v209:setCharacterVisibility(false)
			end
		end
	end
	PushHandToolDriveModeEvent.sendEvent(p203, p204, p205)
end
function PushHandTool.getAllowCharacterVisibilityUpdate(p210, p211)
	if p211(p210) then
		if p210:getIsEntered() then
			local v212 = p210:getActiveCamera()
			if v212 ~= nil and v212.isInside then
				return false
			end
		end
		local v213 = p210.spec_pushHandTool
		if v213.raycastsValid then
			if v213.driveMode.isActive and v213.driveMode.vehicleCharacter ~= nil then
				return false
			else
				return (v213.driveMode.vehicleCharacter == nil or not p210:getIsAnimationPlaying(v213.driveMode.animationName)) and true or false
			end
		else
			return false
		end
	else
		return false
	end
end
function PushHandTool.setActiveCameraIndex(p214, p215, p216)
	if not p214.spec_pushHandTool.raycastsValid then
		local v217 = p214.spec_enterable
		p216 = v217.numCameras < p216 and 1 or p216
		if v217.cameras[p216].isInside then
			for v218, v219 in pairs(v217.cameras) do
				if not v219.isInside then
					p216 = v218
					break
				end
			end
		end
	end
	return p215(p214, p216)
end
function PushHandTool.getIsFoldAllowed(p220, p221, p222, p223)
	if p220.spec_pushHandTool.driveMode.isActive then
		return false
	else
		return p221(p220, p222, p223)
	end
end
function PushHandTool.onEnterVehicle(p224, p225)
	local v226 = false
	if p225 then
		local v227 = p224:getActiveCamera()
		v226 = v227 ~= nil and v227.isInside and true or v226
	end
	if not p224.spec_pushHandTool.raycastsValid and true or v226 then
		local v228 = p224:getVehicleCharacter()
		if v228 ~= nil then
			v228:setCharacterVisibility(false)
		end
	end
end
function PushHandTool.onCameraChanged(p229, p230, _)
	if p229:getIsEntered() then
		local v231 = p229.spec_pushHandTool
		local v232 = p229:getVehicleCharacter()
		if v232 ~= nil and p230.isInside then
			v232:setCharacterVisibility(false)
		end
		if v231.driveMode.vehicleCharacter ~= nil then
			v231.driveMode.vehicleCharacter:setCharacterVisibility(not p230.isInside)
		end
	end
end
function PushHandTool.onVehicleCharacterChanged(p233, p234)
	if p233:getIsEntered() and p234 ~= nil then
		local v235 = p233:getActiveCamera()
		if v235 ~= nil and v235.isInside then
			p234:setCharacterVisibility(false)
		end
	end
	if p234 == nil then
		local v236 = p233.spec_pushHandTool
		v236.characterIKNodes = {}
		v236.spine.node = nil
	end
end
function PushHandTool.postAnimationUpdate(p237, _)
	if p237.isActive then
		local v238 = p237.spec_pushHandTool
		if v238.raycastsValid and (v238.handle.node ~= nil and v238.ikChains ~= nil) then
			local v239 = nil
			for v240, v241 in pairs(v238.ikChains) do
				local v242 = v241.nodes[1].node
				if v242 ~= nil and v238.ikChainTargets[v240] ~= nil then
					local v243 = v238.ikChainTargets[v240].targetNode
					if v243 ~= nil then
						local v244, v245, v246 = getRotation(v238.handle.node)
						setRotation(v238.handle.node, 0, 0, 0)
						if v239 == nil then
							v239 = calcDistanceFrom(v242, v243)
						else
							v239 = (v239 + calcDistanceFrom(v242, v243)) / 2
						end
						setRotation(v238.handle.node, v244, v245, v246)
					end
				end
			end
			if v239 ~= nil then
				if v239 < v238.handle.upperLimit then
					local v247 = (v238.handle.upperLimit - v239) / v238.handle.interpolateDistance
					setRotation(v238.handle.node, v238.handle.minRot * v247, 0, 0)
				elseif v238.handle.lowerLimit < v239 then
					local v248 = (v239 - v238.handle.lowerLimit) / v238.handle.interpolateDistance
					setRotation(v238.handle.node, v238.handle.maxRot * v248, 0, 0)
				end
			end
		end
		if v238.spine.node ~= nil and v238.spine.doAdjustment then
			setRotation(v238.spine.node, 0, 0, v238.spine.currentRotation * v238.spine.ratio[1])
			local v249 = getChildAt(v238.spine.node, 0)
			setRotation(v249, 0, 0, v238.spine.currentRotation * v238.spine.ratio[2])
			local v250 = getChildAt(v249, 0)
			setRotation(v250, 0, 0, v238.spine.currentRotation * v238.spine.ratio[3])
		end
		if (not (v238.driveMode.isActive or p237:getIsAnimationPlaying(v238.driveMode.animationName)) or v238.driveMode.vehicleCharacter == nil) and v238.ikChains ~= nil then
			for v251, _ in pairs(v238.ikChainTargets) do
				IKUtil.setIKChainDirty(v238.ikChains, v251)
			end
			IKUtil.updateIKChains(v238.ikChains)
			for v252, v253 in pairs(v238.characterIKNodes) do
				if entityExists(v252) and entityExists(v253) then
					setTranslation(v252, getTranslation(v253))
					setRotation(v252, getRotation(v253))
				end
			end
			for v254, v255 in pairs(v238.ikChainTargets) do
				IKUtil.setIKChainPose(v238.ikChains, v254, v255.poseId)
			end
		end
	end
end
function PushHandTool.getRaycastPosition(p256, p257)
	local v258 = p256.spec_pushHandTool
	local v259, v260, v261 = getWorldTranslation(p257)
	local v262, v263, v264 = localDirectionToWorld(p257, 0, -1, 0)
	local v265 = v263 * 1.5
	v258.lastRaycastHit = false
	raycastAll(v259, v260, v261, v262, v265, v264, 2, "playerRaycastCallback", p256, PushHandTool.PLAYER_COLLISION_MASK)
	if not v258.lastRaycastHit or (v258.lastRaycastPosition[4] <= 0.35 or v258.lastRaycastPosition[2] >= v260 - 0.25) then
		return nil
	end
	local v266 = v258.lastRaycastPosition
	return unpack(v266)
end
function PushHandTool.playerRaycastCallback(p267, p268, p269, p270, p271, p272)
	local v273 = p267.spec_pushHandTool
	local v274 = g_currentMission.nodeToObject[p268]
	if v274 ~= nil and v274 == p267 then
		return true
	end
	v273.lastRaycastPosition[1] = p269
	v273.lastRaycastPosition[2] = p270
	v273.lastRaycastPosition[3] = p271
	v273.lastRaycastPosition[4] = p272
	v273.lastRaycastHit = true
	return false
end

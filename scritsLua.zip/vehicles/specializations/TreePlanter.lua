source("dataS/scripts/vehicles/specializations/events/TreePlanterCreateTreeEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TreePlanterLoadPalletEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TreePlanterTreeTypeEvent.lua")
source("dataS/scripts/vehicles/specializations/events/PlantLimitToFieldEvent.lua")
TreePlanter = {}
TreePlanter.AI_REQUIRED_GROUND_TYPES = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.CULTIVATED,
	FieldGroundType.SEEDBED,
	FieldGroundType.PLOWED,
	FieldGroundType.ROLLED_SEEDBED,
	FieldGroundType.RIDGE,
	FieldGroundType.SOWN,
	FieldGroundType.DIRECT_SOWN,
	FieldGroundType.PLANTED,
	FieldGroundType.RIDGE_SOWN,
	FieldGroundType.ROLLER_LINES,
	FieldGroundType.HARVEST_READY,
	FieldGroundType.HARVEST_READY_OTHER,
	FieldGroundType.GRASS,
	FieldGroundType.GRASS_CUT
}
function TreePlanter.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p1) and SpecializationUtil.hasSpecialization(FillUnit, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(GroundReference, p1)
	end
	return v2
end
function TreePlanter.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("TreePlanter")
	v3:register(XMLValueType.STRING, "vehicle.treePlanter#inputAction", "Name of the input action to plant a tree manually (If set, the trees are planted manual only)")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.treePlanter#node", "Node index")
	v3:register(XMLValueType.FLOAT, "vehicle.treePlanter#minDistance", "Min. distance between trees", 20)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.treePlanter#palletTrigger", "Pallet trigger")
	v3:register(XMLValueType.INT, "vehicle.treePlanter#refNodeIndex", "Ground reference node index", 1)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.treePlanter#saplingPalletGrabNode", "Sapling pallet grab node")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.treePlanter#saplingPalletMountNode", "Sapling pallet mount node")
	v3:register(XMLValueType.INT, "vehicle.treePlanter#fillUnitIndex", "Fill unit index")
	v3:register(XMLValueType.FLOAT, "vehicle.treePlanter#palletMountingRange", "Min. distance from saplingPalletGrabNode to pallet to mount it", 6)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.treePlanter.saplingNodes.saplingNode(?)#node", "Link node for tree sapling (will be hidden based on fill level)")
	v3:register(XMLValueType.STRING, "vehicle.treePlanter.plantAnimation#name", "Name of plant animation")
	v3:register(XMLValueType.FLOAT, "vehicle.treePlanter.plantAnimation#speedScale", "Speed scale of animation", 1)
	v3:register(XMLValueType.STRING, "vehicle.treePlanter.magazineAnimation#name", "Name of magazine animation (updated based on fill level)")
	v3:register(XMLValueType.FLOAT, "vehicle.treePlanter.magazineAnimation#speedScale", "Speed scale of animation", 1)
	v3:register(XMLValueType.INT, "vehicle.treePlanter.magazineAnimation#numRows", "Number of rows on the magazine", 1)
	SoundManager.registerSampleXMLPaths(v3, "vehicle.treePlanter.sounds", "work")
	AnimationManager.registerAnimationNodesXMLPaths(v3, "vehicle.treePlanter.animationNodes")
	v3:setXMLSpecializationType()
	local v4 = Vehicle.xmlSchemaSavegame
	v4:register(XMLValueType.VECTOR_TRANS, "vehicles.vehicle(?).treePlanter#lastTreePos", "Position of last tree")
	v4:register(XMLValueType.BOOL, "vehicles.vehicle(?).treePlanter#palletHadBeenMounted", "Pallet is mounted")
	v4:register(XMLValueType.STRING, "vehicles.vehicle(?).treePlanter#currentTreeType", "Name of currently loaded tree type")
	v4:register(XMLValueType.STRING, "vehicles.vehicle(?).treePlanter#currentTreeVariation", "Name of currently loaded tree stage variation")
end
function TreePlanter.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "removeMountedObject", TreePlanter.removeMountedObject)
	SpecializationUtil.registerFunction(p5, "setPlantLimitToField", TreePlanter.setPlantLimitToField)
	SpecializationUtil.registerFunction(p5, "createTree", TreePlanter.createTree)
	SpecializationUtil.registerFunction(p5, "loadPallet", TreePlanter.loadPallet)
	SpecializationUtil.registerFunction(p5, "palletTriggerCallback", TreePlanter.palletTriggerCallback)
	SpecializationUtil.registerFunction(p5, "onDeleteTreePlanterObject", TreePlanter.onDeleteTreePlanterObject)
	SpecializationUtil.registerFunction(p5, "getCanPlantOutsideSeason", TreePlanter.getCanPlantOutsideSeason)
	SpecializationUtil.registerFunction(p5, "setTreePlanterTreeTypeIndex", TreePlanter.setTreePlanterTreeTypeIndex)
	SpecializationUtil.registerFunction(p5, "onTreePlanterSaplingLoaded", TreePlanter.onTreePlanterSaplingLoaded)
	SpecializationUtil.registerFunction(p5, "updateTreePlanterFillLevel", TreePlanter.updateTreePlanterFillLevel)
end
function TreePlanter.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDirtMultiplier", TreePlanter.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getWearMultiplier", TreePlanter.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsSpeedRotatingPartActive", TreePlanter.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsWorkAreaActive", TreePlanter.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p6, "doCheckSpeedLimit", TreePlanter.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanBeSelected", TreePlanter.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsOnField", TreePlanter.getIsOnField)
	SpecializationUtil.registerOverwrittenFunction(p6, "addFillUnitFillLevel", TreePlanter.addFillUnitFillLevel)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitFillLevel", TreePlanter.getFillUnitFillLevel)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitFillLevelPercentage", TreePlanter.getFillUnitFillLevelPercentage)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitFillType", TreePlanter.getFillUnitFillType)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitCapacity", TreePlanter.getFillUnitCapacity)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitAllowsFillType", TreePlanter.getFillUnitAllowsFillType)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitFreeCapacity", TreePlanter.getFillUnitFreeCapacity)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillLevelInformation", TreePlanter.getFillLevelInformation)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitHasMountedPalletsToUnload", TreePlanter.getFillUnitHasMountedPalletsToUnload)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitUnloadPalletFilename", TreePlanter.getFillUnitUnloadPalletFilename)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillUnitMountedPalletsToUnload", TreePlanter.getFillUnitMountedPalletsToUnload)
	SpecializationUtil.registerOverwrittenFunction(p6, "getImplementAllowAutomaticSteering", TreePlanter.getImplementAllowAutomaticSteering)
end
function TreePlanter.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onDelete", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onReadStream", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onWriteStream", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onReadUpdateStream", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onWriteUpdateStream", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onUpdate", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onUpdateTick", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onDraw", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onRegisterActionEvents", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onTurnedOn", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onTurnedOff", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onFillUnitIsFillingStateChanged", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onFillUnitFillLevelChanged", TreePlanter)
	SpecializationUtil.registerEventListener(p7, "onFillUnitUnloadPallet", TreePlanter)
end
function TreePlanter.onLoad(p_u_8, p9)
	local v_u_10 = p_u_8.spec_treePlanter
	XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.treePlanterSound", "vehicle.treePlanter.sounds.work")
	XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode(0)", "vehicle.treePlanter.animationNodes.animationNode")
	if p_u_8.isClient then
		v_u_10.samples = {}
		v_u_10.samples.work = g_soundManager:loadSampleFromXML(p_u_8.xmlFile, "vehicle.treePlanter.sounds", "work", p_u_8.baseDirectory, p_u_8.components, 0, AudioGroup.VEHICLE, p_u_8.i3dMappings, p_u_8)
		v_u_10.isWorkSamplePlaying = false
		v_u_10.animationNodes = g_animationManager:loadAnimations(p_u_8.xmlFile, "vehicle.treePlanter.animationNodes", p_u_8.components, p_u_8, p_u_8.i3dMappings)
	end
	v_u_10.inputAction = InputAction[p_u_8.xmlFile:getValue("vehicle.treePlanter#inputAction")]
	v_u_10.node = p_u_8.xmlFile:getValue("vehicle.treePlanter#node", nil, p_u_8.components, p_u_8.i3dMappings)
	v_u_10.minDistance = p_u_8.xmlFile:getValue("vehicle.treePlanter#minDistance", 20)
	v_u_10.palletTrigger = p_u_8.xmlFile:getValue("vehicle.treePlanter#palletTrigger", nil, p_u_8.components, p_u_8.i3dMappings)
	if v_u_10.palletTrigger == nil then
		Logging.xmlWarning(p_u_8.xmlFile, "TreePlanter requires a palletTrigger!")
	else
		addTrigger(v_u_10.palletTrigger, "palletTriggerCallback", p_u_8)
		g_currentMission:addNodeObject(v_u_10.palletTrigger, p_u_8)
	end
	v_u_10.palletsInTrigger = {}
	v_u_10.groundReferenceNode = p_u_8:getGroundReferenceNodeFromIndex((p_u_8.xmlFile:getValue("vehicle.treePlanter#refNodeIndex", 1)))
	if v_u_10.groundReferenceNode == nil then
		Logging.xmlWarning(p_u_8.xmlFile, "No groundReferenceNode specified or invalid groundReferenceNode index in \'%s\'", "vehicle.treePlanter#refNodeIndex")
	end
	v_u_10.currentTreeTypeIndex = nil
	v_u_10.currentTreeVariationIndex = nil
	v_u_10.saplingNodes = {}
	p_u_8.xmlFile:iterate("vehicle.treePlanter.saplingNodes.saplingNode", function(_, p11)
		-- upvalues: (copy) p_u_8, (copy) v_u_10
		local v12 = p_u_8.xmlFile:getValue(p11 .. "#node", nil, p_u_8.components, p_u_8.i3dMappings)
		if v12 ~= nil then
			local v13 = v_u_10.saplingNodes
			table.insert(v13, v12)
		end
	end)
	v_u_10.plantAnimation = {}
	v_u_10.plantAnimation.name = p_u_8.xmlFile:getValue("vehicle.treePlanter.plantAnimation#name")
	v_u_10.plantAnimation.speedScale = p_u_8.xmlFile:getValue("vehicle.treePlanter.plantAnimation#speedScale", 1)
	v_u_10.magazineAnimation = {}
	v_u_10.magazineAnimation.name = p_u_8.xmlFile:getValue("vehicle.treePlanter.magazineAnimation#name")
	v_u_10.magazineAnimation.speedScale = p_u_8.xmlFile:getValue("vehicle.treePlanter.magazineAnimation#speedScale", 1)
	v_u_10.magazineAnimation.numRows = p_u_8.xmlFile:getValue("vehicle.treePlanter.magazineAnimation#numRows", 1)
	v_u_10.activatable = TreePlanterActivatable.new(p_u_8)
	v_u_10.saplingPalletGrabNode = p_u_8.xmlFile:getValue("vehicle.treePlanter#saplingPalletGrabNode", p_u_8.rootNode, p_u_8.components, p_u_8.i3dMappings)
	v_u_10.saplingPalletMountNode = p_u_8.xmlFile:getValue("vehicle.treePlanter#saplingPalletMountNode", p_u_8.rootNode, p_u_8.components, p_u_8.i3dMappings)
	v_u_10.mountedSaplingPallet = nil
	v_u_10.fillUnitIndex = p_u_8.xmlFile:getValue("vehicle.treePlanter#fillUnitIndex", 1)
	v_u_10.nearestPalletDistance = p_u_8.xmlFile:getValue("vehicle.treePlanter#palletMountingRange", 6)
	v_u_10.currentTree = 1
	v_u_10.lastTreePos = nil
	v_u_10.showFieldNotOwnedWarning = false
	v_u_10.showRestrictedZoneWarning = false
	v_u_10.showTooManyTreesWarning = false
	v_u_10.hasGroundContact = false
	v_u_10.showWrongPlantingTimeWarning = false
	v_u_10.limitToField = true
	v_u_10.forceLimitToField = false
	if p_u_8.addAIGroundTypeRequirements ~= nil then
		p_u_8:addAIGroundTypeRequirements(TreePlanter.AI_REQUIRED_GROUND_TYPES)
		if p_u_8.setAIFruitProhibitions ~= nil then
			p_u_8:setAIFruitProhibitions(FruitType.POPLAR, 1, 5)
		end
	end
	v_u_10.dirtyFlag = p_u_8:getNextDirtyFlag()
	if p9 ~= nil and not p9.resetVehicles then
		v_u_10.lastTreePos = p9.xmlFile:getValue(p9.key .. ".treePlanter#lastTreePos", nil, true)
		v_u_10.palletHadBeenMounted = p9.xmlFile:getValue(p9.key .. ".treePlanter#palletHadBeenMounted")
		local v14 = p9.xmlFile:getValue(p9.key .. ".treePlanter#currentTreeType")
		local v15 = p9.xmlFile:getValue(p9.key .. ".treePlanter#currentTreeVariation")
		if v14 ~= nil then
			local v16, v17 = g_treePlantManager:getTreeTypeIndexAndVariationFromName(v14, 1, v15)
			p_u_8:setTreePlanterTreeTypeIndex(v16, v17, true)
		end
	end
end
function TreePlanter.onDelete(p18)
	local v19 = p18.spec_treePlanter
	g_soundManager:deleteSamples(v19.samples)
	g_animationManager:deleteAnimations(v19.animationNodes)
	if v19.activatable ~= nil then
		g_currentMission.activatableObjectsSystem:removeActivatable(v19.activatable)
	end
	if v19.mountedSaplingPallet ~= nil then
		v19.mountedSaplingPallet:unmount()
		v19.mountedSaplingPallet = nil
	end
	if v19.palletTrigger ~= nil then
		removeTrigger(v19.palletTrigger)
		g_currentMission:removeNodeObject(v19.palletTrigger)
	end
end
function TreePlanter.saveToXMLFile(p20, p21, p22, _)
	local v23 = p20.spec_treePlanter
	if v23.lastTreePos ~= nil then
		local v24 = p22 .. "#lastTreePos"
		local v25 = v23.lastTreePos
		p21:setValue(v24, unpack(v25))
	end
	if v23.mountedSaplingPallet ~= nil then
		p21:setValue(p22 .. "#palletHadBeenMounted", true)
	end
	if v23.currentTreeTypeIndex ~= nil then
		local v26, v27 = g_treePlantManager:getTreeTypeNameAndVariationByIndex(v23.currentTreeTypeIndex, 1, v23.currentTreeVariationIndex)
		if v26 ~= nil then
			p21:setValue(p22 .. "#currentTreeType", v26)
		end
		if v27 ~= nil then
			p21:setValue(p22 .. "#currentTreeVariation", v27)
		end
	end
end
function TreePlanter.removeMountedObject(p28, p29, _)
	local v30 = p28.spec_treePlanter
	if v30.mountedSaplingPallet == p29 then
		v30.mountedSaplingPallet:unmount()
		v30.mountedSaplingPallet = nil
	end
end
function TreePlanter.onReadStream(p31, p32, _)
	local v33 = p31.spec_treePlanter
	if streamReadBool(p32) then
		v33.palletIdToMount = NetworkUtil.readNodeObjectId(p32)
	end
	if streamReadBool(p32) then
		p31:setTreePlanterTreeTypeIndex(streamReadUInt32(p32), streamReadUIntN(p32, TreePlantManager.VARIATION_NUM_BITS), true)
	end
	if streamReadBool(p32) then
		local v34 = g_currentMission.vehicleXZPosCompressionParams
		local v35 = g_currentMission.vehicleYPosCompressionParams
		v33.lastTreePos = { NetworkUtil.readCompressedWorldPosition(p32, v34), NetworkUtil.readCompressedWorldPosition(p32, v35), (NetworkUtil.readCompressedWorldPosition(p32, v34)) }
	end
end
function TreePlanter.onWriteStream(p36, p37, _)
	local v38 = p36.spec_treePlanter
	streamWriteBool(p37, v38.mountedSaplingPallet ~= nil)
	if v38.mountedSaplingPallet ~= nil then
		local v39 = NetworkUtil.getObjectId(v38.mountedSaplingPallet)
		NetworkUtil.writeNodeObjectId(p37, v39)
	end
	if streamWriteBool(p37, v38.currentTreeTypeIndex ~= nil) then
		streamWriteUInt32(p37, v38.currentTreeTypeIndex)
		streamWriteUIntN(p37, v38.currentTreeVariationIndex or 1, TreePlantManager.VARIATION_NUM_BITS)
	end
	if streamWriteBool(p37, v38.lastTreePos ~= nil) then
		local v40 = g_currentMission.vehicleXZPosCompressionParams
		local v41 = g_currentMission.vehicleYPosCompressionParams
		NetworkUtil.writeCompressedWorldPosition(p37, v38.lastTreePos[1], v40)
		NetworkUtil.writeCompressedWorldPosition(p37, v38.lastTreePos[2], v41)
		NetworkUtil.writeCompressedWorldPosition(p37, v38.lastTreePos[3], v40)
	end
end
function TreePlanter.onReadUpdateStream(p42, p43, _, p44)
	if p44:getIsServer() then
		local v45 = p42.spec_treePlanter
		if streamReadBool(p43) then
			v45.hasGroundContact = streamReadBool(p43)
			v45.showFieldNotOwnedWarning = streamReadBool(p43)
			v45.showRestrictedZoneWarning = streamReadBool(p43)
		end
	end
end
function TreePlanter.onWriteUpdateStream(p46, p47, p48, p49)
	if not p48:getIsServer() then
		local v50 = p46.spec_treePlanter
		if streamWriteBool(p47, bitAND(p49, v50.dirtyFlag) ~= 0) then
			streamWriteBool(p47, v50.hasGroundContact)
			streamWriteBool(p47, v50.showFieldNotOwnedWarning)
			streamWriteBool(p47, v50.showRestrictedZoneWarning)
		end
	end
end
function TreePlanter.onUpdate(p51, _, _, _, _)
	local v52 = p51.spec_treePlanter
	if p51.finishedFirstUpdate then
		local v53 = nil
		if v52.palletIdToMount == nil then
			if v52.palletHadBeenMounted then
				v52.palletHadBeenMounted = nil
				v53 = TreePlanter.getSaplingPalletInRange(p51, v52.saplingPalletMountNode, v52.palletsInTrigger)
			end
		else
			v53 = NetworkUtil.getObject(v52.palletIdToMount)
		end
		if v53 ~= nil and v53:getIsSynchronized() then
			v53:mount(p51, v52.saplingPalletMountNode, 0, 0, 0, 0, 0, 0)
			v52.mountedSaplingPallet = v53
			g_currentMission.activatableObjectsSystem:removeActivatable(v52.activatable)
			v52.palletIdToMount = nil
			if p51.isServer and v53.getTreeSaplingPalletType ~= nil then
				local v54, v55 = v53:getTreeSaplingPalletType()
				local v56, v57 = g_treePlantManager:getTreeTypeIndexAndVariationFromName(v54, 1, v55)
				p51:setTreePlanterTreeTypeIndex(v56, v57)
			end
			FillUnit.updateUnloadActionDisplay(p51)
		end
	end
	if p51.isClient then
		local v58
		if v52.mountedSaplingPallet == nil then
			v58 = TreePlanter.getSaplingPalletInRange(p51, v52.saplingPalletGrabNode, v52.palletsInTrigger)
		else
			v58 = nil
		end
		if v52.nearestSaplingPallet ~= v58 then
			v52.nearestSaplingPallet = v58
			if v58 == nil then
				g_currentMission.activatableObjectsSystem:removeActivatable(v52.activatable)
			else
				g_currentMission.activatableObjectsSystem:addActivatable(v52.activatable)
			end
		end
	end
	if v52.mountedSaplingPallet ~= nil then
		if v52.mountedSaplingPallet.isDeleted then
			v52.palletsInTrigger[v52.mountedSaplingPallet] = nil
			v52.mountedSaplingPallet = nil
			return
		end
		v52.mountedSaplingPallet:raiseActive()
	end
end
function TreePlanter.onUpdateTick(p59, p60, _, p61, _)
	local v62 = p59.spec_treePlanter
	v62.showTooManyTreesWarning = false
	local v63 = false
	local v64 = false
	if p59.isServer then
		local v65
		if v62.groundReferenceNode == nil then
			v65 = false
		else
			v65 = p59:getIsGroundReferenceNodeActive(v62.groundReferenceNode)
		end
		if v62.hasGroundContact ~= v65 then
			p59:raiseDirtyFlags(v62.dirtyFlag)
			v62.hasGroundContact = v65
		end
	end
	if p59:getIsAIActive() and (not g_currentMission.missionInfo.helperBuySeeds and v62.mountedSaplingPallet == nil) then
		p59.rootVehicle:stopCurrentAIJob(AIMessageErrorOutOfFill.new())
	end
	v62.showWrongPlantingTimeWarning = false
	if v62.hasGroundContact and p59:getIsTurnedOn() then
		local v66
		if p59:getCanPlantOutsideSeason() then
			v66 = true
		else
			local v67 = p59:getFillUnitFillType(v62.fillUnitIndex)
			local v68 = g_fruitTypeManager:getFruitTypeByFillTypeIndex(v67)
			v66 = v68 == nil and true or v68:getIsPlantableInPeriod(g_currentMission.missionInfo.growthMode, g_currentMission.environment.currentPeriod)
		end
		v62.showWrongPlantingTimeWarning = not v66
		if p59.isServer and v66 then
			local v69 = p59:getFillUnitFillLevel(v62.fillUnitIndex)
			local v70 = p59:getFillUnitFillType(v62.fillUnitIndex)
			if g_currentMission.missionInfo.helperBuySeeds and p59:getIsAIActive() then
				if v62.mountedSaplingPallet == nil then
					v70 = FillType.POPLAR
				else
					v70 = v62.mountedSaplingPallet:getFillUnitFillType(1)
				end
			end
			if v69 == 0 and not (p59:getIsAIActive() and g_currentMission.missionInfo.helperBuySeeds) then
				v70 = FillType.UNKNOWN
			end
			if v70 == FillType.TREESAPLINGS then
				if p59:getLastSpeed() > 1 then
					local v71, v72, v73 = getWorldTranslation(v62.node)
					if g_currentMission.accessHandler:canFarmAccessLand(p59:getActiveFarm(), v71, v73) then
						if PlacementUtil.isInsideRestrictedZone(g_currentMission.restrictedZones, v71, v72, v73, true) then
							v64 = true
						elseif v62.lastTreePos == nil then
							p59:createTree()
						elseif MathUtil.vector3Length(v71 - v62.lastTreePos[1], v72 - v62.lastTreePos[2], v73 - v62.lastTreePos[3]) > v62.minDistance then
							p59:createTree()
						end
					else
						v63 = true
					end
				end
			elseif v70 ~= FillType.UNKNOWN then
				local v74, _, v75 = getWorldTranslation(v62.node)
				if g_currentMission.accessHandler:canFarmAccessLand(p59:getActiveFarm(), v74, v75) then
					local v76 = g_currentMission:getFruitPixelsToSqm()
					local v77 = math.sqrt(v76) * 0.5
					local v78, _, v79 = localToWorld(v62.node, -v77, 0, v77)
					local v80, _, v81 = localToWorld(v62.node, v77, 0, v77)
					local v82, _, v83 = localToWorld(v62.node, -v77, 0, 3 * v77)
					local v84 = g_fruitTypeManager:getFruitTypeIndexByFillTypeIndex(v70)
					local v85 = g_fruitTypeManager:getFruitTypeByIndex(v84)
					local v86, _, v87 = localDirectionToWorld(v62.node, 0, 0, 1)
					local v88 = MathUtil.getYRotationFromDirection(v86, v87)
					if v85 ~= nil and v85.directionSnapAngle ~= 0 then
						local v89 = v88 / v85.directionSnapAngle + 0.5
						v88 = math.floor(v89) * v85.directionSnapAngle
					end
					local v90 = FSDensityMapUtil.convertToDensityMapAngle(v88, g_currentMission.fieldGroundSystem:getGroundAngleMaxValue())
					local v91 = v62.limitToField or v62.forceLimitToField
					local v92 = v62.limitToField or v62.forceLimitToField
					FSDensityMapUtil.updateCultivatorArea(v78, v79, v80, v81, v82, v83, not v91, v92, v90, nil)
					FSDensityMapUtil.eraseTireTrack(v78, v79, v80, v81, v82, v83)
					local v93, _, v94 = localToWorld(v62.node, -v77, 0, -3 * v77)
					local v95, _, v96 = localToWorld(v62.node, v77, 0, -3 * v77)
					local v97, _, v98 = localToWorld(v62.node, -v77, 0, -v77)
					local v99 = FieldGroundType.getValueByType(FieldGroundType.SOWN)
					local v100, _ = FSDensityMapUtil.updateSowingArea(v84, v93, v94, v95, v96, v97, v98, v99, false, v90, 2)
					local v101 = v85.seedUsagePerSqm * v100
					local v102 = p59:getActiveFarm()
					if p59:getIsAIActive() and g_currentMission.missionInfo.helperBuySeeds then
						local v103 = v101 * g_currentMission.economyManager:getCostPerLiter(FillType.SEEDS, false) * 1.5
						g_farmManager:updateFarmStats(v102, "expenses", v103)
						g_currentMission:addMoney(-v103, p59:getActiveFarm(), MoneyType.PURCHASE_SEEDS)
					else
						p59:addFillUnitFillLevel(p59:getOwnerFarmId(), v62.fillUnitIndex, -v101, v70, ToolType.UNDEFINED)
					end
					local v104 = MathUtil.areaToHa(v100, g_currentMission:getFruitPixelsToSqm())
					g_farmManager:updateFarmStats(v102, "seedUsage", v101)
					g_farmManager:updateFarmStats(v102, "sownHectares", v104)
					g_farmManager:updateFarmStats(v102, "sownTime", p60 / 60000)
					p59:updateLastWorkedArea(v100)
				else
					v63 = true
				end
			end
		end
	end
	if p59.isServer and (v62.showFieldNotOwnedWarning ~= v63 or v62.showRestrictedZoneWarning ~= v64) then
		v62.showFieldNotOwnedWarning = v63
		v62.showRestrictedZoneWarning = v64
		p59:raiseDirtyFlags(v62.dirtyFlag)
	end
	if p59.isClient then
		if p59:getIsTurnedOn() and (v62.hasGroundContact and p59:getLastSpeed() > 1) then
			if not v62.isWorkSamplePlaying then
				g_soundManager:playSample(v62.samples.work)
				v62.isWorkSamplePlaying = true
			end
		elseif v62.isWorkSamplePlaying then
			g_soundManager:stopSample(v62.samples.work)
			v62.isWorkSamplePlaying = false
		end
		local v105 = v62.actionEvents[InputAction.IMPLEMENT_EXTRA3]
		if v105 ~= nil then
			local v106 = false
			if p61 then
				local v107 = p59:getFillUnitFillType(v62.fillUnitIndex)
				v106 = v107 ~= FillType.UNKNOWN and (v107 ~= FillType.TREESAPLINGS and (g_currentMission:getHasPlayerPermission("createFields", p59:getOwnerConnection()) and not v62.forceLimitToField)) and true or v106
				if v106 then
					if v62.limitToField then
						g_inputBinding:setActionEventText(v105.actionEventId, g_i18n:getText("action_allowCreateFields"))
					else
						g_inputBinding:setActionEventText(v105.actionEventId, g_i18n:getText("action_limitToFields"))
					end
				end
			end
			g_inputBinding:setActionEventActive(v105.actionEventId, v106)
		end
		if v62.inputAction ~= nil then
			local v108 = v62.actionEvents[v62.inputAction]
			if v108 ~= nil then
				local v109
				if v62.lastTreePos == nil then
					v109 = true
				else
					local v110, v111, v112 = getWorldTranslation(v62.node)
					v109 = MathUtil.vector3Length(v110 - v62.lastTreePos[1], v111 - v62.lastTreePos[2], v112 - v62.lastTreePos[3]) > v62.minDistance
				end
				local v113 = g_inputBinding
				local v114 = v108.actionEventId
				if v109 then
					v109 = p59:getFillUnitFillLevel(v62.fillUnitIndex) > 0
				end
				v113:setActionEventActive(v114, v109)
			end
		end
	end
end
function TreePlanter.onDraw(p115, _, p116, _)
	local v117 = p115.spec_treePlanter
	if p116 then
		if p115:getFillUnitFillLevel(v117.fillUnitIndex) <= 0 then
			g_currentMission:addExtraPrintText(g_i18n:getText("info_firstFillTheTool"))
		end
		if v117.currentTreeTypeIndex ~= nil and (p115:getFillUnitFillLevel(v117.fillUnitIndex) > 0 and v117.treeTypeExtraPrintText ~= nil) then
			g_currentMission:addExtraPrintText(v117.treeTypeExtraPrintText)
		end
	end
	if v117.showFieldNotOwnedWarning then
		g_currentMission:showBlinkingWarning(g_i18n:getText("warning_youDontHaveAccessToThisLand"))
	end
	if v117.showRestrictedZoneWarning then
		g_currentMission:showBlinkingWarning(g_i18n:getText("warning_actionNotAllowedHere"))
	end
	if v117.showTooManyTreesWarning then
		g_currentMission:showBlinkingWarning(g_i18n:getText("warning_tooManyTrees"))
	end
	if v117.showWrongPlantingTimeWarning then
		g_currentMission:showBlinkingWarning(string.format(g_i18n:getText("warning_theSelectedFruitTypeCantBePlantedInThisPeriod"), g_i18n:formatPeriod()), 100)
	end
end
function TreePlanter.onTurnedOn(p118)
	if p118.isClient then
		local v119 = p118.spec_treePlanter
		g_animationManager:startAnimations(v119.animationNodes)
	end
end
function TreePlanter.onTurnedOff(p120)
	if p120.isClient then
		local v121 = p120.spec_treePlanter
		g_animationManager:stopAnimations(v121.animationNodes)
		g_soundManager:stopSamples(v121.samples)
		v121.isWorkSamplePlaying = false
	end
end
function TreePlanter.onFillUnitIsFillingStateChanged(p122, p123)
	if p122.isServer and p123 then
		local v124 = p122.spec_fillUnit.fillTrigger.currentTrigger
		if v124 ~= nil and (v124.sourceObject ~= nil and v124.sourceObject.getTreeSaplingPalletType ~= nil) then
			local v125, v126 = v124.sourceObject:getTreeSaplingPalletType()
			local v127, v128 = g_treePlantManager:getTreeTypeIndexAndVariationFromName(v125, 1, v126)
			p122:setTreePlanterTreeTypeIndex(v127, v128)
		end
	end
end
function TreePlanter.onFillUnitFillLevelChanged(p129, p130, _, _, _, _, _)
	if p130 == p129.spec_treePlanter.fillUnitIndex then
		p129:updateTreePlanterFillLevel()
	end
end
function TreePlanter.onFillUnitUnloadPallet(p131, p132)
	local v133 = p131.spec_treePlanter
	if p132.setTreeSaplingPalletType ~= nil then
		local v134, v135 = g_treePlantManager:getTreeTypeNameAndVariationByIndex(v133.currentTreeTypeIndex, 1, v133.currentTreeVariationIndex)
		p132:setTreeSaplingPalletType(v134, v135)
	end
	if v133.mountedSaplingPallet == p132 then
		v133.mountedSaplingPallet = nil
	end
end
function TreePlanter.addFillUnitFillLevel(p136, p137, p138, p139, p140, p141, p142, p143)
	local v144 = p136.spec_treePlanter
	if p139 == v144.fillUnitIndex then
		local v145 = v144.mountedSaplingPallet
		if v145 ~= nil then
			local v146 = v145:getFillUnits()
			for v147, _ in pairs(v146) do
				if v145:getFillUnitFillType(p139) == p141 then
					return v145:addFillUnitFillLevel(p136:getOwnerFarmId(), v147, p140, p141, ToolType.UNDEFINED)
				end
			end
		end
	end
	return p137(p136, p138, p139, p140, p141, p142, p143)
end
function TreePlanter.getFillUnitFillLevel(p148, p149, p150)
	local v151 = p148.spec_treePlanter
	if p150 == v151.fillUnitIndex then
		local v152 = v151.mountedSaplingPallet
		if v152 ~= nil then
			local v153 = v152:getFillUnits()
			local v154 = 0
			for v155, _ in pairs(v153) do
				v154 = v154 + v152:getFillUnitFillLevel(v155)
			end
			return v154
		end
	end
	return p149(p148, p150)
end
function TreePlanter.getFillUnitFillLevelPercentage(p156, p157, p158)
	local v159 = p156.spec_treePlanter
	if p158 == v159.fillUnitIndex and v159.mountedSaplingPallet ~= nil then
		local v160 = p156:getFillUnitCapacity(p158)
		local v161 = p156:getFillUnitFillLevel(p158)
		if v160 > 0 then
			return v161 / v160
		end
	end
	return p157(p156, p158)
end
function TreePlanter.getFillUnitFillType(p162, p163, p164)
	local v165 = p162.spec_treePlanter
	if p164 == v165.fillUnitIndex then
		local v166 = v165.mountedSaplingPallet
		if v166 ~= nil then
			local v167 = v166:getFillUnits()
			for v168, _ in pairs(v167) do
				if v166:getFillUnitFillLevel(v168) > 0 then
					return v166:getFillUnitFillType(v168)
				end
			end
		end
	end
	return p163(p162, p164)
end
function TreePlanter.getFillUnitCapacity(p169, p170, p171)
	local v172 = p169.spec_treePlanter
	if p171 == v172.fillUnitIndex then
		local v173 = v172.mountedSaplingPallet
		if v173 ~= nil then
			local v174 = v173:getFillUnits()
			local v175 = 0
			for v176, _ in pairs(v174) do
				v175 = v175 + v173:getFillUnitCapacity(v176)
			end
			return v175
		end
	end
	return p170(p169, p171)
end
function TreePlanter.getFillUnitAllowsFillType(p177, p178, p179, p180)
	local v181 = p177.spec_treePlanter
	if p179 == v181.fillUnitIndex and v181.mountedSaplingPallet ~= nil then
		return false
	else
		return p178(p177, p179, p180)
	end
end
function TreePlanter.getFillUnitFreeCapacity(p182, p183, p184, p185, p186)
	local v187 = p182.spec_treePlanter
	return p184 == v187.fillUnitIndex and v187.mountedSaplingPallet ~= nil and 0 or p183(p182, p184, p185, p186)
end
function TreePlanter.getFillLevelInformation(p188, p189, p190)
	local v191 = p188.spec_treePlanter
	if v191.mountedSaplingPallet ~= nil then
		local v192 = p188:getFillUnitCapacity(v191.fillUnitIndex)
		local v193 = p188:getFillUnitFillLevel(v191.fillUnitIndex)
		p190:addFillLevel(p188:getFillUnitFillType(v191.fillUnitIndex), v193, v192)
	end
	p189(p188, p190)
end
function TreePlanter.getFillUnitUnloadPalletFilename(p194, _, _)
	local v195 = p194.spec_treePlanter
	if v195.mountedSaplingPallet == nil and v195.currentTreeTypeIndex ~= nil then
		return g_treePlantManager:getPalletStoreItemFilenameByIndex(v195.currentTreeTypeIndex, 1, v195.currentTreeVariationIndex)
	end
end
function TreePlanter.getFillUnitHasMountedPalletsToUnload(p196, _)
	return p196.spec_treePlanter.mountedSaplingPallet ~= nil
end
function TreePlanter.getFillUnitMountedPalletsToUnload(p197, _)
	return { p197.spec_treePlanter.mountedSaplingPallet }
end
function TreePlanter.getImplementAllowAutomaticSteering(_, _)
	return true
end
function TreePlanter.getCanPlantOutsideSeason(_)
	return false
end
function TreePlanter.setTreePlanterTreeTypeIndex(p198, p199, p200, p201)
	local v202 = p198.spec_treePlanter
	if p199 ~= v202.currentTreeTypeIndex or p200 ~= v202.currentTreeVariationIndex then
		v202.currentTreeTypeIndex = p199
		v202.currentTreeVariationIndex = p200
		local v203 = g_treePlantManager:getTreeTypeDescFromIndex(v202.currentTreeTypeIndex)
		if v203 ~= nil then
			v202.treeTypeExtraPrintText = string.format("%s: %s", g_i18n:getText("configuration_treeType"), v203.title)
		end
		if #v202.saplingNodes > 0 then
			if v202.saplingSharedLoadRequestId ~= nil then
				g_i3DManager:releaseSharedI3DFile(v202.saplingSharedLoadRequestId)
			end
			local v204 = nil
			if v203 ~= nil then
				local v205 = v203.stages[1]
				if v205 ~= nil then
					local v206 = v205[p200]
					if v206 ~= nil then
						v204 = v206.planterFilename or v206.filename
					end
				end
			end
			if v204 ~= nil then
				v202.saplingSharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(v204, false, false, p198.onTreePlanterSaplingLoaded, p198)
			end
		end
		TreePlanterTreeTypeEvent.sendEvent(p198, p199, p200, p201)
	end
end
function TreePlanter.onTreePlanterSaplingLoaded(p207, p208, _, _)
	if p208 ~= 0 then
		local v209 = getChildAt(p208, 0)
		local v210 = p207.spec_treePlanter
		for v211 = 1, #v210.saplingNodes do
			local v212 = clone(v209, false, false, false)
			link(v210.saplingNodes[v211], v212)
		end
		p207:updateTreePlanterFillLevel(true)
		delete(p208)
	end
end
function TreePlanter.updateTreePlanterFillLevel(p213, p214)
	local v215 = p213.spec_treePlanter
	local v216 = p213:getFillUnitFillLevel(v215.fillUnitIndex)
	local v217 = p213:getFillUnitCapacity(v215.fillUnitIndex)
	for v218 = 1, #v215.saplingNodes do
		local v219 = v215.saplingNodes[v218]
		setVisibility(v219, v218 <= MathUtil.round(v216))
		I3DUtil.setShaderParameterRec(v219, "hideByIndex", v217 - v216, 0, 0, 0)
	end
	if v215.magazineAnimation.name ~= nil then
		local v220 = (v216 - 1) / v217 * v215.magazineAnimation.numRows
		local v221 = math.ceil(v220) / v215.magazineAnimation.numRows
		local v222 = p213:getAnimationTime(v215.magazineAnimation.name)
		if v221 ~= v222 then
			p213:setAnimationStopTime(v215.magazineAnimation.name, v221)
			local v223 = v215.magazineAnimation.name
			local v224 = v215.magazineAnimation.speedScale
			local v225 = v221 - v222
			p213:playAnimation(v223, v224 * math.sign(v225), v222, true)
			if p214 then
				AnimatedVehicle.updateAnimationByName(p213, v215.magazineAnimation.name, 999999, true)
			end
		end
	end
	if v215.unloadActionEventId ~= nil then
		g_inputBinding:setActionEventActive(v215.unloadActionEventId, v216 > 0)
	end
end
function TreePlanter.setPlantLimitToField(p226, p227, p228)
	local v229 = p226.spec_treePlanter
	if v229.limitToField ~= p227 then
		v229.limitToField = p227
		PlantLimitToFieldEvent.sendEvent(p226, p227, p228)
	end
end
function TreePlanter.createTree(p230, p231)
	local v232 = p230.spec_treePlanter
	if g_treePlantManager:canPlantTree() then
		if p230.isServer then
			local v233, v234, v235 = getWorldTranslation(v232.node)
			local v236 = math.random() * 2 * 3.141592653589793
			local v237 = v232.currentTreeTypeIndex
			local v238 = v232.currentTreeVariationIndex
			if v237 == nil or v238 == nil then
				Logging.error("Failed to plant tree. Tree type not found. (treeType %s, variation %s)", v237, v238)
				return
			end
			g_treePlantManager:plantTree(v237, v233, v234, v235, 0, v236, 0, 1, v238)
			if v232.lastTreePos == nil then
				v232.lastTreePos = { v233, v234, v235 }
			else
				local v239 = v232.lastTreePos
				local v240 = v232.lastTreePos
				local v241 = v232.lastTreePos
				v239[1] = v233
				v240[2] = v234
				v241[3] = v235
			end
			local v242 = p230:getActiveFarm()
			if g_currentMission.missionInfo.helperBuySeeds and p230:getIsAIActive() then
				local v243 = v232.mountedSaplingPallet
				if v243 ~= nil then
					local v244 = 1.5 * (g_storeManager:getItemByXMLFilename(v243.configFileName).price / v243:getFillUnitCapacity(1))
					g_farmManager:updateFarmStats(v242, "expenses", v244)
					g_currentMission:addMoney(-v244, p230:getActiveFarm(), MoneyType.PURCHASE_SEEDS)
				end
			else
				local v245 = p230:getFillUnitFillLevel(v232.fillUnitIndex) < 1.5 and (-1 / 0) or -0.9999
				p230:addFillUnitFillLevel(p230:getOwnerFarmId(), v232.fillUnitIndex, v245, p230:getFillUnitFillType(v232.fillUnitIndex), ToolType.UNDEFINED)
			end
			g_farmManager:updateFarmStats(v242, "plantedTreeCount", 1)
		else
			local v246, v247, v248 = getWorldTranslation(v232.node)
			if v232.lastTreePos == nil then
				v232.lastTreePos = { v246, v247, v248 }
			else
				local v249 = v232.lastTreePos
				local v250 = v232.lastTreePos
				local v251 = v232.lastTreePos
				v249[1] = v246
				v250[2] = v247
				v251[3] = v248
			end
		end
		if p230.isClient and v232.plantAnimation.name ~= nil then
			p230:setAnimationTime(v232.plantAnimation.name, 0, true)
			p230:playAnimation(v232.plantAnimation.name, v232.plantAnimation.speedScale, 0, true)
		end
		TreePlanterCreateTreeEvent.sendEvent(p230, p231)
	else
		v232.showTooManyTreesWarning = true
	end
end
function TreePlanter.loadPallet(p252, p253, p254)
	local v255 = p252.spec_treePlanter
	TreePlanterLoadPalletEvent.sendEvent(p252, p253, p254)
	v255.palletIdToMount = p253
end
function TreePlanter.getDirtMultiplier(p256, p257)
	local v258 = p257(p256)
	if p256.spec_treePlanter.hasGroundContact then
		v258 = v258 + p256:getWorkDirtMultiplier() * p256:getLastSpeed() / p256.speedLimit
	end
	return v258
end
function TreePlanter.getWearMultiplier(p259, p260)
	local v261 = p260(p259)
	if p259.spec_treePlanter.hasGroundContact then
		v261 = v261 + p259:getWorkWearMultiplier() * p259:getLastSpeed() / p259.speedLimit
	end
	return v261
end
function TreePlanter.getIsSpeedRotatingPartActive(p262, p263, p264)
	if p262.spec_treePlanter.hasGroundContact then
		return p263(p262, p264)
	else
		return false
	end
end
function TreePlanter.getIsWorkAreaActive(p265, p266, p267)
	local v268 = p265.spec_treePlanter
	local v269 = p266(p265, p267)
	if p267.groundReferenceNode == v268.groundReferenceNode and not p265:getIsTurnedOn() then
		v269 = false
	end
	return v269
end
function TreePlanter.doCheckSpeedLimit(p270, p271)
	local v272 = not p271(p270) and p270:getIsTurnedOn()
	if v272 then
		v272 = p270:getIsImplementChainLowered()
	end
	return v272
end
function TreePlanter.getCanBeSelected(_, _)
	return true
end
function TreePlanter.onDeleteTreePlanterObject(p273, p274)
	local v275 = p273.spec_treePlanter
	if v275.mountedSaplingPallet == p274 then
		v275.mountedSaplingPallet = nil
	end
	v275.palletsInTrigger[p274] = nil
end
function TreePlanter.getIsOnField(p276, p277)
	return p277(p276) and true or (p276.spec_treePlanter.hasGroundContact and true or false)
end
function TreePlanter.palletTriggerCallback(p278, _, p279, p280, p281, _, _)
	local v282 = p278.spec_treePlanter
	if p279 ~= 0 then
		local v283 = g_currentMission:getNodeObject(p279)
		if v283 ~= nil and (v283.isa ~= nil and (v283:isa(Vehicle) and (v283.isPallet and g_currentMission.accessHandler:canFarmAccess(p278:getActiveFarm(), v283)))) then
			local v284 = Utils.getNoNil(v282.palletsInTrigger[v283], 0)
			if p280 then
				v282.palletsInTrigger[v283] = v284 + 1
				if v284 == 0 and v283.addDeleteListener ~= nil then
					v283:addDeleteListener(p278, "onDeleteTreePlanterObject")
				end
			elseif p281 then
				local v285 = v282.palletsInTrigger
				local v286 = v284 - 1
				v285[v283] = math.max(v286, 0)
			end
			if v282.palletsInTrigger[v283] == 0 then
				v282.palletsInTrigger[v283] = nil
			end
		end
	end
end
function TreePlanter.onRegisterActionEvents(p287, _, p288)
	if p287.isClient then
		local v289 = p287.spec_treePlanter
		p287:clearActionEventsTable(v289.actionEvents)
		if p288 then
			if not v289.forceLimitToField then
				local _, v290 = p287:addActionEvent(v289.actionEvents, InputAction.IMPLEMENT_EXTRA3, p287, TreePlanter.actionEventToggleTreePlanterFieldLimitation, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v290, GS_PRIO_NORMAL)
			end
			if v289.inputAction ~= nil then
				local _, v291 = p287:addPoweredActionEvent(v289.actionEvents, v289.inputAction, p287, TreePlanter.actionEventPlant, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v291, GS_PRIO_HIGH)
				g_inputBinding:setActionEventText(v291, g_i18n:getText("action_plantTree"))
			end
		end
	end
end
function TreePlanter.actionEventToggleTreePlanterFieldLimitation(p292, _, _, _, _)
	p292:setPlantLimitToField(not p292.spec_treePlanter.limitToField)
end
function TreePlanter.actionEventPlant(p293, _, _, _, _)
	local v294 = p293.spec_treePlanter
	if v294.hasGroundContact then
		if g_treePlantManager:canPlantTree() then
			local v295, v296, v297 = getWorldTranslation(v294.node)
			if g_currentMission.accessHandler:canFarmAccessLand(p293:getActiveFarm(), v295, v297) then
				if PlacementUtil.isInsideRestrictedZone(g_currentMission.restrictedZones, v295, v296, v297, true) then
					g_currentMission:showBlinkingWarning(g_i18n:getText("warning_actionNotAllowedHere"))
				else
					p293:createTree()
				end
			else
				g_currentMission:showBlinkingWarning(g_i18n:getText("warning_youDontHaveAccessToThisLand"))
				return
			end
		else
			g_currentMission:showBlinkingWarning(g_i18n:getText("warning_tooManyTrees"))
			return
		end
	else
		g_currentMission:showBlinkingWarning(g_i18n:getText("warning_treePlanterNoGroundContact"))
		return
	end
end
function TreePlanter.getDefaultSpeedLimit()
	return 5
end
function TreePlanter.getSaplingPalletInRange(p298, p299, p300)
	local v301 = p298.spec_treePlanter
	local v302 = v301.nearestPalletDistance
	local v303 = nil
	for v304, v305 in pairs(p300) do
		if v305 ~= nil and (v305 > 0 and (v304 ~= v301.mountedSaplingPallet and calcDistanceFrom(p299, v304.rootNode) < v302)) then
			local v306 = v304:getFillUnits()
			local v307 = false
			for v308, _ in pairs(v306) do
				local v309 = v304:getFillUnitFillType(v308)
				if v309 ~= FillType.UNKNOWN and (p298:getFillUnitSupportsFillType(v301.fillUnitIndex, v309) and v304:getFillUnitFillLevel(v308) > 0) then
					v307 = true
					break
				end
			end
			if v307 then
				v303 = v304
			end
		end
	end
	return v303
end
TreePlanterActivatable = {}
local v_u_310 = Class(TreePlanterActivatable)
function TreePlanterActivatable.new(p311)
	-- upvalues: (copy) v_u_310
	local v312 = v_u_310
	local v313 = setmetatable({}, v312)
	v313.treePlanterVehicle = p311
	v313.activateText = string.format(g_i18n:getText("action_refillOBJECT"), v313.treePlanterVehicle.typeDesc)
	return v313
end
function TreePlanterActivatable.getIsActivatable(p314)
	if p314.treePlanterVehicle.rootVehicle == g_localPlayer:getCurrentVehicle() then
		return p314.treePlanterVehicle.spec_treePlanter.mountedSaplingPallet == nil and p314.treePlanterVehicle.spec_treePlanter.nearestSaplingPallet ~= nil
	else
		return false
	end
end
function TreePlanterActivatable.run(p315)
	p315.treePlanterVehicle:loadPallet(NetworkUtil.getObjectId(p315.treePlanterVehicle.spec_treePlanter.nearestSaplingPallet))
end

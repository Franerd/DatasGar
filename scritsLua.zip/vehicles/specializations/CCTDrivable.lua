CCTDrivable = {}
function CCTDrivable.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Enterable, p1)
end
function CCTDrivable.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("CCTDrivable")
	v2:register(XMLValueType.FLOAT, "vehicle.cctDrivable#cctRadius", "CCT radius", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.cctDrivable#cctHeight", "CCT height", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.cctDrivable#cctSlopeLimit", "CCT slope limit", 25)
	v2:register(XMLValueType.FLOAT, "vehicle.cctDrivable#cctStepOffset", "CCT step offset", 0.35)
	v2:setXMLSpecializationType()
end
function CCTDrivable.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getTouchingNode", CCTDrivable.getTouchingNode)
	SpecializationUtil.registerFunction(p3, "moveCCTExternal", CCTDrivable.moveCCTExternal)
	SpecializationUtil.registerFunction(p3, "moveCCT", CCTDrivable.moveCCT)
	SpecializationUtil.registerFunction(p3, "getIsCCTOnGround", CCTDrivable.getIsCCTOnGround)
	SpecializationUtil.registerFunction(p3, "getCCTCollisionMask", CCTDrivable.getCCTCollisionMask)
	SpecializationUtil.registerFunction(p3, "getCCTWorldTranslation", CCTDrivable.getCCTWorldTranslation)
end
function CCTDrivable.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "addToPhysics", CCTDrivable.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p4, "setWorldPosition", CCTDrivable.setWorldPosition)
	SpecializationUtil.registerOverwrittenFunction(p4, "setWorldPositionQuaternion", CCTDrivable.setWorldPositionQuaternion)
end
function CCTDrivable.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", CCTDrivable)
	SpecializationUtil.registerEventListener(p5, "onDelete", CCTDrivable)
end
function CCTDrivable.onLoad(p6, _)
	local v7 = p6.spec_cctdrivable
	v7.cctRadius = p6.xmlFile:getValue("vehicle.cctDrivable#cctRadius", 1)
	v7.cctHeight = p6.xmlFile:getValue("vehicle.cctDrivable#cctHeight", 1)
	v7.cctSlopeLimit = p6.xmlFile:getValue("vehicle.cctDrivable#cctSlopeLimit", 25)
	v7.cctStepOffset = p6.xmlFile:getValue("vehicle.cctDrivable#cctStepOffset", 0.3)
	v7.cctCenterOffset = -v7.cctRadius
	v7.kinematicCollisionGroup = CollisionFlag.ANIMAL + CollisionFlag.CAMERA_BLOCKING
	local v8 = CollisionMask.ALL
	local v9 = CollisionFlag.VEHICLE
	local v10 = CollisionFlag.ANIMAL
	local v11 = CollisionFlag.PLAYER
	local v12 = CollisionFlag.WATER
	local v13 = CollisionFlag.AI_BLOCKING
	local v14 = CollisionFlag.GROUND_TIP_BLOCKING
	local v15 = CollisionFlag.PLACEMENT_BLOCKING
	local v16 = CollisionFlag.CAMERA_BLOCKING
	local v17 = CollisionFlag.PRECIPITATION_BLOCKING
	local v18 = CollisionFlag.ANIMAL_NAV_MESH_BLOCKING
	local v19 = CollisionFlag.TERRAIN_DISPLACEMENT
	v7.kinematicCollisionMask = v8 - bit32.bor(v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19)
	v7.movementCollisionGroup = v7.kinematicCollisionGroup
	local v20 = CollisionMask.ALL
	local v21 = CollisionFlag.TRIGGER
	local v22 = CollisionFlag.WATER
	local v23 = CollisionFlag.AI_BLOCKING
	local v24 = CollisionFlag.GROUND_TIP_BLOCKING
	local v25 = CollisionFlag.PLACEMENT_BLOCKING
	local v26 = CollisionFlag.CAMERA_BLOCKING
	local v27 = CollisionFlag.PRECIPITATION_BLOCKING
	local v28 = CollisionFlag.ANIMAL_NAV_MESH_BLOCKING
	local v29 = CollisionFlag.TERRAIN_DISPLACEMENT
	v7.movementCollisionMask = v20 - bit32.bor(v21, v22, v23, v24, v25, v26, v27, v28, v29)
	if p6.isServer then
		v7.cctNode = createTransformGroup("cctDrivable")
		link(getRootNode(), v7.cctNode)
	end
end
function CCTDrivable.onDelete(p30)
	local v31 = p30.spec_cctdrivable
	if v31.controllerIndex ~= nil then
		removeCCT(v31.controllerIndex)
		delete(v31.cctNode)
	end
end
function CCTDrivable.moveCCT(p32, p33, p34, p35)
	if p32.isServer then
		local v36 = p32.spec_cctdrivable
		moveCCT(v36.controllerIndex, p33, p34, p35, v36.movementCollisionGroup, v36.movementCollisionMask)
		p32:raiseActive()
	end
end
function CCTDrivable.moveCCTExternal(p37, p38, p39, p40)
	p37:moveCCT(p38, p39, p40)
end
function CCTDrivable.getTouchingNode(p41)
	local v42 = p41.spec_cctdrivable
	local v43 = v42.controllerIndex == nil and 0 or getCCTGroundObject(v42.controllerIndex)
	if v43 == 0 or not v43 then
		v43 = nil
	end
	return v43
end
function CCTDrivable.getIsCCTOnGround(p44)
	local v45 = p44.spec_cctdrivable
	if not p44.isServer then
		return false
	end
	local _, _, v46 = getCCTCollisionFlags(v45.controllerIndex)
	return v46
end
function CCTDrivable.getCCTCollisionMask(p47)
	return p47.spec_cctdrivable.kinematicCollisionMask
end
function CCTDrivable.getCCTWorldTranslation(p48)
	local v49 = p48.spec_cctdrivable
	local v50, v51, v52 = getTranslation(v49.cctNode)
	return v50, v51 + v49.cctCenterOffset, v52
end
function CCTDrivable.setWorldPosition(p53, p54, p55, p56, p57, p58, p59, p60, p61, p62)
	p54(p53, p55, p56, p57, p58, p59, p60, p61, p62)
	if p53.isServer and p61 == 1 then
		local v63 = p53.spec_cctdrivable
		setTranslation(v63.cctNode, p55, p56 - v63.cctCenterOffset, p57)
	end
end
function CCTDrivable.setWorldPositionQuaternion(p64, p65, p66, p67, p68, p69, p70, p71, p72, p73, p74)
	p65(p64, p66, p67, p68, p69, p70, p71, p72, p73, p74)
	if p64.isServer and p73 == 1 then
		local v75 = p64.spec_cctdrivable
		setTranslation(v75.cctNode, p66, p67 - v75.cctCenterOffset, p68)
	end
end
function CCTDrivable.addToPhysics(p76, p77)
	if not p77(p76) then
		return false
	end
	if p76.isServer then
		local v78 = p76.spec_cctdrivable
		local v79 = p76.components[1].defaultMass * 1000
		if v78.controllerIndex ~= nil then
			removeCCT(v78.controllerIndex)
		end
		v78.controllerIndex = createCCT(v78.cctNode, v78.cctRadius, v78.cctHeight, v78.cctStepOffset, v78.cctSlopeLimit, 0.2, v78.kinematicCollisionGroup, v78.kinematicCollisionMask, v79)
		setCCTPairCollision(v78.controllerIndex, p76.rootNode, false)
	end
	return true
end

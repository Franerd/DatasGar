Cultivator = {}
Cultivator.AI_REQUIRED_GROUND_TYPES_FLAT = {
	FieldGroundType.CULTIVATED,
	FieldGroundType.PLOWED,
	FieldGroundType.ROLLED_SEEDBED,
	FieldGroundType.SOWN,
	FieldGroundType.DIRECT_SOWN,
	FieldGroundType.PLANTED,
	FieldGroundType.RIDGE_SOWN,
	FieldGroundType.ROLLER_LINES,
	FieldGroundType.HARVEST_READY,
	FieldGroundType.HARVEST_READY_OTHER,
	FieldGroundType.GRASS,
	FieldGroundType.GRASS_CUT
}
Cultivator.AI_REQUIRED_GROUND_TYPES_DEEP = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.SEEDBED,
	FieldGroundType.PLOWED,
	FieldGroundType.ROLLED_SEEDBED,
	FieldGroundType.SOWN,
	FieldGroundType.DIRECT_SOWN,
	FieldGroundType.PLANTED,
	FieldGroundType.RIDGE_SOWN,
	FieldGroundType.ROLLER_LINES,
	FieldGroundType.HARVEST_READY,
	FieldGroundType.HARVEST_READY_OTHER,
	FieldGroundType.GRASS,
	FieldGroundType.GRASS_CUT
}
Cultivator.AI_OUTPUT_GROUND_TYPES = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.CULTIVATED,
	FieldGroundType.SEEDBED,
	FieldGroundType.RIDGE,
	FieldGroundType.ROLLED_SEEDBED
}
function Cultivator.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("cultivator", true, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Cultivator")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.cultivator.directionNode#node", "Direction node")
	v1:register(XMLValueType.BOOL, "vehicle.cultivator.onlyActiveWhenLowered#value", "Only active when lowered", true)
	v1:register(XMLValueType.BOOL, "vehicle.cultivator#isSubsoiler", "Is subsoiler", false)
	v1:register(XMLValueType.BOOL, "vehicle.cultivator#useDeepMode", "If true the implement acts like a cultivator. If false it\'s a discharrow or seedbed combination", true)
	v1:register(XMLValueType.BOOL, "vehicle.cultivator#isPowerHarrow", "If this is set the cultivator works standalone like a cultivator, but as soon as a sowing machine is attached to it, it\'s only using the sowing machine", false)
	SoundManager.registerSampleXMLPaths(v1, "vehicle.cultivator.sounds", "work(?)")
	v1:addDelayedRegistrationFunc("WorkMode:workMode", function(p2, p3)
		p2:register(XMLValueType.BOOL, p3 .. "#useDeepMode", "If true the implement acts like a cultivator. If false it\'s a discharrow or seedbed combination")
	end)
	v1:setXMLSpecializationType()
end
function Cultivator.prerequisitesPresent(p4)
	return SpecializationUtil.hasSpecialization(WorkArea, p4)
end
function Cultivator.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "processCultivatorArea", Cultivator.processCultivatorArea)
	SpecializationUtil.registerFunction(p5, "processVineCultivatorArea", Cultivator.processVineCultivatorArea)
	SpecializationUtil.registerFunction(p5, "getCultivatorLimitToField", Cultivator.getCultivatorLimitToField)
	SpecializationUtil.registerFunction(p5, "getUseCultivatorAIRequirements", Cultivator.getUseCultivatorAIRequirements)
	SpecializationUtil.registerFunction(p5, "updateCultivatorAIRequirements", Cultivator.updateCultivatorAIRequirements)
	SpecializationUtil.registerFunction(p5, "updateCultivatorEnabledState", Cultivator.updateCultivatorEnabledState)
	SpecializationUtil.registerFunction(p5, "getIsCultivationEnabled", Cultivator.getIsCultivationEnabled)
end
function Cultivator.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "doCheckSpeedLimit", Cultivator.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDirtMultiplier", Cultivator.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getWearMultiplier", Cultivator.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "loadWorkAreaFromXML", Cultivator.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsWorkAreaActive", Cultivator.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p6, "loadWorkModeFromXML", Cultivator.loadWorkModeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p6, "getAIImplementUseVineSegment", Cultivator.getAIImplementUseVineSegment)
end
function Cultivator.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", Cultivator)
	SpecializationUtil.registerEventListener(p7, "onDelete", Cultivator)
	SpecializationUtil.registerEventListener(p7, "onPostAttach", Cultivator)
	SpecializationUtil.registerEventListener(p7, "onDeactivate", Cultivator)
	SpecializationUtil.registerEventListener(p7, "onStartWorkAreaProcessing", Cultivator)
	SpecializationUtil.registerEventListener(p7, "onEndWorkAreaProcessing", Cultivator)
	SpecializationUtil.registerEventListener(p7, "onStateChange", Cultivator)
	SpecializationUtil.registerEventListener(p7, "onWorkModeChanged", Cultivator)
end
function Cultivator.onLoad(p8, _)
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.cultivator.directionNode#index", "vehicle.cultivator.directionNode#node")
	if p8:getGroundReferenceNodeFromIndex(1) == nil then
		printWarning("Warning: No ground reference nodes in  " .. p8.configFileName)
	end
	local v9 = p8.spec_cultivator
	if p8.isClient then
		v9.samples = {}
		v9.samples.work = g_soundManager:loadSamplesFromXML(p8.xmlFile, "vehicle.cultivator.sounds", "work", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v9.isWorkSamplePlaying = false
	end
	v9.directionNode = p8.xmlFile:getValue("vehicle.cultivator.directionNode#node", p8.components[1].node, p8.components, p8.i3dMappings)
	v9.onlyActiveWhenLowered = p8.xmlFile:getValue("vehicle.cultivator.onlyActiveWhenLowered#value", true)
	v9.isSubsoiler = p8.xmlFile:getValue("vehicle.cultivator#isSubsoiler", false)
	v9.isPowerHarrow = p8.xmlFile:getValue("vehicle.cultivator#isPowerHarrow", false)
	v9.useDeepMode = p8.xmlFile:getValue("vehicle.cultivator#useDeepMode", true)
	p8:updateCultivatorAIRequirements()
	v9.isEnabled = true
	v9.startActivationTimeout = 2000
	v9.startActivationTime = 0
	v9.hasGroundContact = false
	v9.isWorking = false
	v9.limitToField = true
	v9.workAreaParameters = {}
	v9.workAreaParameters.limitToField = p8:getCultivatorLimitToField()
	v9.workAreaParameters.angle = 0
	v9.workAreaParameters.lastChangedArea = 0
	v9.workAreaParameters.lastStatsArea = 0
	v9.workAreaParameters.lastTotalArea = 0
end
function Cultivator.onDelete(p10)
	local v11 = p10.spec_cultivator
	if v11.samples ~= nil then
		g_soundManager:deleteSamples(v11.samples.work)
	end
end
function Cultivator.processCultivatorArea(p12, p13, _)
	local v14 = p12.spec_cultivator
	local v15, _, v16 = getWorldTranslation(p13.start)
	local v17, _, v18 = getWorldTranslation(p13.width)
	local v19, _, v20 = getWorldTranslation(p13.height)
	local v21, v22
	if v14.isEnabled then
		local v23 = v14.workAreaParameters
		if v14.useDeepMode then
			local v24
			v24, v21 = FSDensityMapUtil.updateCultivatorArea(v15, v16, v17, v18, v19, v20, not v23.limitToField, v23.limitFruitDestructionToField, v23.angle, nil)
			v22 = v24 + FSDensityMapUtil.updateVineCultivatorArea(v15, v16, v17, v18, v19, v20, true)
		else
			local v25
			v25, v21 = FSDensityMapUtil.updateDiscHarrowArea(v15, v16, v17, v18, v19, v20, not v23.limitToField, v23.limitFruitDestructionToField, v23.angle, nil)
			v22 = v25 + FSDensityMapUtil.updateVineCultivatorArea(v15, v16, v17, v18, v19, v20, true)
		end
		v23.lastChangedArea = v23.lastChangedArea + v22
		v23.lastStatsArea = v23.lastStatsArea + v22
		v23.lastTotalArea = v23.lastTotalArea + v21
	else
		v22 = 0
		v21 = 0
	end
	if v14.isSubsoiler then
		FSDensityMapUtil.updateSubsoilerArea(v15, v16, v17, v18, v19, v20)
	end
	FSDensityMapUtil.eraseTireTrack(v15, v16, v17, v18, v19, v20)
	v14.isWorking = p12:getLastSpeed() > 0.5
	return v22, v21
end
function Cultivator.processVineCultivatorArea(p26, p27, _)
	if p26.spec_cultivator.isEnabled then
		local v28, _, v29 = getWorldTranslation(p27.start)
		local v30, _, v31 = getWorldTranslation(p27.width)
		local v32, _, v33 = getWorldTranslation(p27.height)
		FSDensityMapUtil.updateVineCultivatorArea(v28, v29, v30, v31, v32, v33, false)
	end
	return 0, 0
end
function Cultivator.getCultivatorLimitToField(p34)
	return p34.spec_cultivator.limitToField
end
function Cultivator.getUseCultivatorAIRequirements(_)
	return true
end
function Cultivator.updateCultivatorAIRequirements(p35)
	if p35:getUseCultivatorAIRequirements() and p35.addAITerrainDetailRequiredRange ~= nil then
		local v36 = p35:getChildVehicles()
		local v37 = false
		local v38 = nil
		local v39 = nil
		for v40 = 1, #v36 do
			if SpecializationUtil.hasSpecialization(SowingMachine, v36[v40].specializations) and (v36[v40]:getAIRequiresTurnOn() or v36[v40]:getUseSowingMachineAIRequirements()) then
				v37 = true
			end
		end
		local v41 = p35.rootVehicle:getChildVehicles()
		for v42 = 1, #v41 do
			if SpecializationUtil.hasSpecialization(Roller, v41[v42].specializations) then
				v38 = FieldGroundType.ROLLER_LINES
				v39 = FieldGroundType.ROLLED_SEEDBED
			end
		end
		if not v37 then
			if p35.spec_cultivator.useDeepMode then
				p35:addAIGroundTypeRequirements(Cultivator.AI_REQUIRED_GROUND_TYPES_DEEP, v38, v39)
			else
				p35:addAIGroundTypeRequirements(Cultivator.AI_REQUIRED_GROUND_TYPES_FLAT, v38, v39)
			end
		end
		p35:clearAITerrainDetailRequiredRange()
	end
end
function Cultivator.updateCultivatorEnabledState(p43)
	local v44 = p43.spec_cultivator
	if v44.isPowerHarrow then
		local v45 = p43:getChildVehicles()
		for v46 = 1, #v45 do
			if SpecializationUtil.hasSpecialization(SowingMachine, v45[v46].specializations) then
				v44.isEnabled = false
				return
			end
		end
	elseif SpecializationUtil.hasSpecialization(SowingMachine, p43.specializations) and (p43:getUseSowingMachineAIRequirements() and p43.spec_sowingMachine.useDirectPlanting) then
		if p43.spec_sowingMachine.workAreaParameters.seedsVehicle ~= nil then
			v44.isEnabled = false
			return
		end
		if p43:getIsAIActive() and g_currentMission.missionInfo.helperBuySeeds then
			v44.isEnabled = false
			return
		end
	end
	v44.isEnabled = true
end
function Cultivator.getIsCultivationEnabled(p47)
	return p47.spec_cultivator.isEnabled
end
function Cultivator.doCheckSpeedLimit(p48, p49)
	return p49(p48) or p48:getIsImplementChainLowered()
end
function Cultivator.getDirtMultiplier(p50, p51)
	local v52 = p50.spec_cultivator
	local v53 = p51(p50)
	if v52.isWorking then
		v53 = v53 + p50:getWorkDirtMultiplier() * p50:getLastSpeed() / v52.speedLimit
	end
	return v53
end
function Cultivator.getWearMultiplier(p54, p55)
	local v56 = p54.spec_cultivator
	local v57 = p55(p54)
	if v56.isWorking then
		v57 = v57 + p54:getWorkWearMultiplier() * p54:getLastSpeed() / v56.speedLimit
	end
	return v57
end
function Cultivator.loadWorkAreaFromXML(p58, p59, p60, p61, p62)
	local v63 = p59(p58, p60, p61, p62)
	if p60.type == WorkAreaType.DEFAULT then
		p60.type = WorkAreaType.CULTIVATOR
	end
	return v63
end
function Cultivator.getIsWorkAreaActive(p64, p65, p66)
	if p66.type == WorkAreaType.CULTIVATOR then
		local v67 = p64.spec_cultivator
		if v67.startActivationTime > g_currentMission.time then
			return false
		end
		if v67.onlyActiveWhenLowered and (p64.getIsLowered ~= nil and not p64:getIsLowered(false)) then
			return false
		end
	end
	return p65(p64, p66)
end
function Cultivator.loadWorkModeFromXML(p68, p69, p70, p71, p72)
	if not p69(p68, p70, p71, p72) then
		return false
	end
	p72.useDeepMode = p70:getValue(p71 .. "#useDeepMode")
	return true
end
function Cultivator.getAIImplementUseVineSegment(p73, _, p74, p75, p76)
	local v77, v78, v79, v80, v81, v82 = p74:getSegmentSideArea(p75, p76)
	local v83, v84 = AIVehicleUtil.getAIAreaOfVehicle(p73, v77, v78, v79, v80, v81, v82)
	if v84 > 0 then
		return v83 / v84 > 0.01
	else
		return false
	end
end
function Cultivator.onPostAttach(p85, _, _, _)
	local v86 = p85.spec_cultivator
	v86.startActivationTime = g_currentMission.time + v86.startActivationTimeout
end
function Cultivator.onDeactivate(p87)
	if p87.isClient then
		local v88 = p87.spec_cultivator
		g_soundManager:stopSamples(v88.samples.work)
		v88.isWorkSamplePlaying = false
	end
end
function Cultivator.onStartWorkAreaProcessing(p89, _)
	local v90 = p89.spec_cultivator
	v90.isWorking = false
	local v91 = p89:getCultivatorLimitToField()
	local v92
	if g_currentMission:getHasPlayerPermission("createFields", p89:getOwnerConnection()) then
		v92 = v91
	else
		v91 = true
		v92 = true
	end
	local v93, _, v94 = localDirectionToWorld(v90.directionNode, 0, 0, 1)
	local v95 = FSDensityMapUtil.convertToDensityMapAngle(MathUtil.getYRotationFromDirection(v93, v94), g_currentMission.fieldGroundSystem:getGroundAngleMaxValue())
	v90.workAreaParameters.limitToField = v91
	v90.workAreaParameters.limitFruitDestructionToField = v92
	v90.workAreaParameters.angle = v95
	v90.workAreaParameters.lastChangedArea = 0
	v90.workAreaParameters.lastStatsArea = 0
	v90.workAreaParameters.lastTotalArea = 0
end
function Cultivator.onEndWorkAreaProcessing(p96, p97)
	local v98 = p96.spec_cultivator
	if p96.isServer then
		local v99 = p96:getLastTouchedFarmlandFarmId()
		local v100 = v98.workAreaParameters.lastStatsArea
		if v100 > 0 then
			local v101 = MathUtil.areaToHa(v100, g_currentMission:getFruitPixelsToSqm())
			g_farmManager:updateFarmStats(v99, "cultivatedHectares", v101)
			p96:updateLastWorkedArea(v100)
		end
		if v98.isWorking then
			g_farmManager:updateFarmStats(v99, "cultivatedTime", p97 / 60000)
		end
	end
	if p96.isClient then
		if v98.isWorking then
			if not v98.isWorkSamplePlaying then
				g_soundManager:playSamples(v98.samples.work)
				v98.isWorkSamplePlaying = true
				return
			end
		elseif v98.isWorkSamplePlaying then
			g_soundManager:stopSamples(v98.samples.work)
			v98.isWorkSamplePlaying = false
		end
	end
end
function Cultivator.onStateChange(p102, p103, p104)
	if p103 == VehicleStateChange.ATTACH or (p103 == VehicleStateChange.DETACH or p103 == VehicleStateChange.AI_START_LINE) then
		p102:updateCultivatorAIRequirements()
		p102:updateCultivatorEnabledState()
	end
	if p102.isServer and (p103 == VehicleStateChange.TURN_ON or p103 == VehicleStateChange.TURN_OFF) and p102.spec_cultivator.isPowerHarrow then
		if p104 == p102 and p102.getAttachedImplements ~= nil then
			for _, v105 in pairs(p102:getAttachedImplements()) do
				local v106 = v105.object
				if v106 ~= nil then
					if p103 == VehicleStateChange.TURN_ON then
						v106:setIsTurnedOn(true)
					elseif v106:getIsTurnedOn() then
						v106:setIsTurnedOn(false)
					end
				end
			end
			return
		end
		if p104.getAttacherVehicle ~= nil then
			local v107 = p104:getAttacherVehicle()
			if v107 ~= nil and v107 == p102 then
				if p103 == VehicleStateChange.TURN_ON then
					p102:setIsTurnedOn(true)
					return
				end
				if p102:getIsTurnedOn() then
					p102:setIsTurnedOn(false)
				end
			end
		end
	end
end
function Cultivator.onWorkModeChanged(p108, p109, _)
	if p109.useDeepMode ~= nil then
		p108.spec_cultivator.useDeepMode = p109.useDeepMode
		p108:updateCultivatorAIRequirements()
	end
end
function Cultivator.getDefaultSpeedLimit()
	return 15
end

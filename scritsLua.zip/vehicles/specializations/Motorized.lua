source("dataS/scripts/vehicles/specializations/events/MotorSetTurnedOnEvent.lua")
source("dataS/scripts/vehicles/specializations/events/MotorGearShiftEvent.lua")
source("dataS/scripts/vehicles/specializations/events/MotorStateEvent.lua")
source("dataS/scripts/vehicles/specializations/enums/MotorState.lua")
Motorized = {}
Motorized.DAMAGED_USAGE_INCREASE = 0.3
function Motorized.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("motor", g_i18n:getText("configuration_motorSetup"), "motorized", VehicleConfigurationItemMotor, nil, nil, nil, 1)
	g_storeManager:addSpecType("fuel", "shopListAttributeIconFuel", Motorized.loadSpecValueFuel, Motorized.getSpecValueFuelDiesel, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("electricCharge", "shopListAttributeIconElectricCharge", Motorized.loadSpecValueFuel, Motorized.getSpecValueFuelElectricCharge, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("methane", "shopListAttributeIconMethane", Motorized.loadSpecValueFuel, Motorized.getSpecValueFuelMethane, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("maxSpeed", "shopListAttributeIconMaxSpeed", Motorized.loadSpecValueMaxSpeed, Motorized.getSpecValueMaxSpeed, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("power", "shopListAttributeIconPower", Motorized.loadSpecValuePower, Motorized.getSpecValuePower, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("powerConfig", "shopListAttributeIconPower", Motorized.loadSpecValuePowerConfig, Motorized.getSpecValuePowerConfig, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("transmission", "shopListAttributeIconTransmission", Motorized.loadSpecValueTransmission, Motorized.getSpecValueTransmission, StoreSpecies.VEHICLE)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Motorized")
	Motorized.registerDifferentialXMLPaths(v1, "vehicle.motorized.differentialConfigurations.differentialConfiguration(?)")
	Motorized.registerDifferentialXMLPaths(v1, "vehicle.motorized.differentials")
	Motorized.registerMotorXMLPaths(v1, "vehicle.motorized.motorConfigurations.motorConfiguration(?)")
	Motorized.registerConsumerXMLPaths(v1, "vehicle.motorized.consumerConfigurations.consumerConfiguration(?)")
	Motorized.registerConsumerXMLPaths(v1, "vehicle.motorized.consumers")
	Motorized.registerSoundXMLPaths(v1, "vehicle.motorized.sounds")
	Motorized.registerSoundXMLPaths(v1, "vehicle.motorized.motorConfigurations.motorConfiguration(?).sounds")
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.reverseDriveSound#threshold", "Reverse drive sound turn on speed threshold", 4)
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.brakeCompressor#capacity", "Brake compressor capacity", 6)
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.brakeCompressor#refillFillLevel", "Brake compressor refill threshold", "half of capacity")
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.brakeCompressor#fillSpeed", "Brake compressor fill speed", 0.6)
	ParticleUtil.registerParticleXMLPaths(v1, "vehicle.motorized.exhaustParticleSystems", "exhaustParticleSystem(?)")
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.exhaustParticleSystems#minScale", "Min. scale", 0.5)
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.exhaustParticleSystems#maxScale", "Max. scale", 1)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.motorized.exhaustFlap(?)#node", "Exhaust Flap Node")
	v1:register(XMLValueType.ANGLE, "vehicle.motorized.exhaustFlap(?)#maxRot", "Max. rotation", 0)
	v1:register(XMLValueType.INT, "vehicle.motorized.exhaustFlap(?)#rotationAxis", "Rotation Axis", 1)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.motorized.exhaustEffects.exhaustEffect(?)#node", "Effect link node")
	v1:register(XMLValueType.STRING, "vehicle.motorized.exhaustEffects.exhaustEffect(?)#filename", "Effect i3d filename")
	v1:register(XMLValueType.VECTOR_4, "vehicle.motorized.exhaustEffects.exhaustEffect(?)#minRpmColor", "Min. rpm color", "0 0 0 1")
	v1:register(XMLValueType.VECTOR_4, "vehicle.motorized.exhaustEffects.exhaustEffect(?)#maxRpmColor", "Max. rpm color", "0.0384 0.0359 0.0627 2.0")
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.exhaustEffects.exhaustEffect(?)#minRpmScale", "Min. rpm scale", 0.25)
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.exhaustEffects.exhaustEffect(?)#maxRpmScale", "Max. rpm scale", 0.95)
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.exhaustEffects.exhaustEffect(?)#upFactor", "Defines how far the effect goes up in the air in meter", 0.75)
	v1:register(XMLValueType.FLOAT, "vehicle.motorized.motorStartDuration", "Motor start duration", "Duration motor takes to start. After this time player can start to drive")
	v1:register(XMLValueType.L10N_STRING, "vehicle.motorized#clutchNoEngagedWarning", "Warning to be displayed if try to start the engine but clutch not engaged", "warning_motorClutchNoEngaged")
	v1:register(XMLValueType.L10N_STRING, "vehicle.motorized#clutchCrackingGearWarning", "Warning to be display if user tries to select a gear without pressing clutch pedal", "action_clutchCrackingGear")
	v1:register(XMLValueType.L10N_STRING, "vehicle.motorized#clutchCrackingGroupWarning", "Warning to be display if user tries to select a gear without pressing clutch pedal", "action_clutchCrackingGroup")
	v1:register(XMLValueType.L10N_STRING, "vehicle.motorized#turnOnText", "Motor start text", "action_startMotor")
	v1:register(XMLValueType.L10N_STRING, "vehicle.motorized#turnOffText", "Motor stop text", "action_stopMotor")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.motorized.gearLevers.gearLever(?)#node", "Gear lever node")
	v1:register(XMLValueType.INT, "vehicle.motorized.gearLevers.gearLever(?)#centerAxis", "Axis of center bay")
	v1:register(XMLValueType.TIME, "vehicle.motorized.gearLevers.gearLever(?)#changeTime", "Time to move lever from one state to another", 0.5)
	v1:register(XMLValueType.TIME, "vehicle.motorized.gearLevers.gearLever(?)#handsOnDelay", "The animation is delayed by this time to have time to put the hand on the lever", 0)
	v1:register(XMLValueType.INT, "vehicle.motorized.gearLevers.gearLever(?).state(?)#gear", "Gear index")
	v1:register(XMLValueType.INT, "vehicle.motorized.gearLevers.gearLever(?).state(?)#group", "Group index")
	v1:register(XMLValueType.ANGLE, "vehicle.motorized.gearLevers.gearLever(?).state(?)#xRot", "X rotation")
	v1:register(XMLValueType.ANGLE, "vehicle.motorized.gearLevers.gearLever(?).state(?)#yRot", "Y rotation")
	v1:register(XMLValueType.ANGLE, "vehicle.motorized.gearLevers.gearLever(?).state(?)#zRot", "Z rotation")
	v1:register(XMLValueType.FLOAT, "vehicle.storeData.specs.power", "Power")
	v1:register(XMLValueType.FLOAT, "vehicle.storeData.specs.maxSpeed", "Max speed")
	v1:register(XMLValueType.STRING, "vehicle.motorized#statsType", "Statistic type", "tractor")
	v1:register(XMLValueType.BOOL, "vehicle.motorized#forceSpeedHudDisplay", "Force usage of vehicle speed display in hud independent of setting", false)
	v1:register(XMLValueType.BOOL, "vehicle.motorized#forceRpmHudDisplay", "Force usage of motor speed display in hud independent of setting", false)
	Dashboard.registerDashboardXMLPaths(v1, "vehicle.motorized.dashboards", {
		"rpm",
		"load",
		"speed",
		"speedDir",
		"fuelUsage",
		"motorTemperature",
		"motorTemperatureWarning",
		"clutchPedal",
		"gear",
		"gearGroup",
		"gearShiftUp",
		"gearShiftDown",
		"movingDirection",
		"directionForward",
		"directionForwardExclusive",
		"directionBackward",
		"directionNeutral",
		"movingDirectionLetter",
		"ignitionState",
		"battery"
	})
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.motorized.animationNodes")
	v1:register(XMLValueType.BOOL, Dashboard.GROUP_XML_KEY .. "#isMotorStarting", "Is motor starting")
	v1:register(XMLValueType.BOOL, Dashboard.GROUP_XML_KEY .. "#isMotorRunning", "Is motor running")
	v1:setXMLSpecializationType()
end
function Motorized.registerMotorXMLPaths(p2, p3)
	p2:register(XMLValueType.STRING, p3 .. ".motor#type", "Motor type", "vehicle")
	p2:register(XMLValueType.STRING, p3 .. ".motor#startAnimationName", "Motor start animation", "vehicle")
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#minRpm", "Min. RPM", 1000)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#maxRpm", "Max. RPM", 1800)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#minSpeed", "Min. driving speed", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#maxForwardSpeed", "Max. forward speed")
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#maxBackwardSpeed", "Max. backward speed")
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#accelerationLimit", "Acceleration limit", 2)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#brakeForce", "Brake force", 10)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#lowBrakeForceScale", "Low brake force scale", 0.5)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#lowBrakeForceSpeedLimit", "Low brake force speed limit (below this speed the lowBrakeForceScale is activated)", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#torqueScale", "Scale factor for torque curve", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#ptoMotorRpmRatio", "PTO to motor rpm ratio", 4)
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission#minForwardGearRatio", "Min. forward gear ratio")
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission#maxForwardGearRatio", "Max. forward gear ratio")
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission#minBackwardGearRatio", "Min. backward gear ratio")
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission#maxBackwardGearRatio", "Max. backward gear ratio")
	p2:register(XMLValueType.TIME, p3 .. ".transmission#gearChangeTime", "Gear change time")
	p2:register(XMLValueType.TIME, p3 .. ".transmission#autoGearChangeTime", "Auto gear change time")
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission#axleRatio", "Axle ratio", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission#startGearThreshold", "Adjusts which gear is used as start gear", VehicleMotor.GEAR_START_THRESHOLD)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor.torque(?)#normRpm", "Norm RPM (0-1)")
	p2:register(XMLValueType.FLOAT, p3 .. ".motor.torque(?)#rpm", "RPM")
	p2:register(XMLValueType.FLOAT, p3 .. ".motor.torque(?)#torque", "Torque")
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#rotInertia", "Rotation inertia", "Peak. motor torque / 600")
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#dampingRateScale", "Scales motor damping rate", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".motor#rpmSpeedLimit", "Motor rotation acceleration limit")
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission.forwardGear(?)#gearRatio", "Gear ratio")
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission.forwardGear(?)#maxSpeed", "Gear ratio")
	p2:register(XMLValueType.BOOL, p3 .. ".transmission.forwardGear(?)#defaultGear", "Gear ratio")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.forwardGear(?)#name", "Gear name to display")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.forwardGear(?)#reverseName", "Gear name to display (if reverse direction is active)")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.forwardGear(?)#dashboardName", "Gear name to display in dashboard")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.forwardGear(?)#dashboardReverseName", "Gear name to display in dashboard (if reverse direction is active)")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.forwardGear(?)#actionName", "Input Action to select this gear", "SHIFT_GEAR_SELECT_X")
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission.backwardGear(?)#gearRatio", "Gear ratio")
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission.backwardGear(?)#maxSpeed", "Gear ratio")
	p2:register(XMLValueType.BOOL, p3 .. ".transmission.backwardGear(?)#defaultGear", "Gear ratio")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.backwardGear(?)#name", "Gear name to display")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.backwardGear(?)#reverseName", "Gear name to display (if reverse direction is active)")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.backwardGear(?)#dashboardName", "Gear name to display in dashboard")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.backwardGear(?)#dashboardReverseName", "Gear name to display in dashboard (if reverse direction is active)")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.backwardGear(?)#actionName", "Input Action to select this gear", "SHIFT_GEAR_SELECT_X")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.groups#type", "Type of groups (powershift/default)", "default")
	p2:register(XMLValueType.TIME, p3 .. ".transmission.groups#changeTime", "Change time if default type", 0.5)
	p2:register(XMLValueType.FLOAT, p3 .. ".transmission.groups.group(?)#ratio", "Ratio while stage active")
	p2:register(XMLValueType.BOOL, p3 .. ".transmission.groups.group(?)#isDefault", "Is default stage", false)
	p2:register(XMLValueType.STRING, p3 .. ".transmission.groups.group(?)#name", "Gear name to display")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.groups.group(?)#dashboardName", "Gear name to display in dashboard")
	p2:register(XMLValueType.STRING, p3 .. ".transmission.groups.group(?)#actionName", "Input Action to select this group", "SHIFT_GROUP_SELECT_X")
	p2:register(XMLValueType.BOOL, p3 .. ".transmission.directionChange#useGroup", "Use group as reverse change", false)
	p2:register(XMLValueType.INT, p3 .. ".transmission.directionChange#reverseGroupIndex", "Group will be activated while direction is changed", 1)
	p2:register(XMLValueType.BOOL, p3 .. ".transmission.directionChange#useGear", "Use gear as reverse change", false)
	p2:register(XMLValueType.INT, p3 .. ".transmission.directionChange#reverseGearIndex", "Gear will be activated while direction is changed", 1)
	p2:register(XMLValueType.TIME, p3 .. ".transmission.directionChange#changeTime", "Direction change time", 0.5)
	p2:register(XMLValueType.BOOL, p3 .. ".transmission.manualShift#gears", "Defines if gears can be shifted manually", true)
	p2:register(XMLValueType.BOOL, p3 .. ".transmission.manualShift#groups", "Defines if groups can be shifted manually", true)
	p2:register(XMLValueType.L10N_STRING, p3 .. ".transmission#name", "Name of transmission to display in the shop")
	p2:register(XMLValueType.STRING, p3 .. ".transmission#param", "Parameter to insert in transmission name")
	p2:register(XMLValueType.FLOAT, p3 .. ".motorStartDuration", "Motor start duration", "Duration motor takes to start. After this time player can start to drive")
end
function Motorized.registerDifferentialXMLPaths(p4, p5)
	p4:register(XMLValueType.FLOAT, p5 .. ".differentials.differential(?)#torqueRatio", "Torque ratio", 0.5)
	p4:register(XMLValueType.FLOAT, p5 .. ".differentials.differential(?)#maxSpeedRatio", "Max. speed ratio", 1.3)
	p4:register(XMLValueType.INT, p5 .. ".differentials.differential(?)#wheelIndex1", "Wheel index 1")
	p4:register(XMLValueType.INT, p5 .. ".differentials.differential(?)#wheelIndex2", "Wheel index 2")
	p4:register(XMLValueType.INT, p5 .. ".differentials.differential(?)#differentialIndex1", "Differential index 1")
	p4:register(XMLValueType.INT, p5 .. ".differentials.differential(?)#differentialIndex2", "Differential index 2")
end
function Motorized.registerConsumerXMLPaths(p6, p7)
	p6:register(XMLValueType.L10N_STRING, p7 .. "#consumersEmptyWarning", "Consumers empty warning", "warning_motorFuelEmpty")
	p6:register(XMLValueType.INT, p7 .. ".consumer(?)#fillUnitIndex", "Fill unit index", 1)
	p6:register(XMLValueType.STRING, p7 .. ".consumer(?)#fillType", "Fill type name")
	p6:register(XMLValueType.FLOAT, p7 .. ".consumer(?)#usage", "Usage in l/h", 1)
	p6:register(XMLValueType.BOOL, p7 .. ".consumer(?)#permanentConsumption", "Do permanent consumption", 1)
	p6:register(XMLValueType.FLOAT, p7 .. ".consumer(?)#refillLitersPerSecond", "Refill liters per second", 0)
	p6:register(XMLValueType.FLOAT, p7 .. ".consumer(?)#refillCapacityPercentage", "Refill capacity percentage", 0)
	p6:register(XMLValueType.FLOAT, p7 .. ".consumer(?)#capacity", "If defined the capacity of the fillUnit fill be overwritten with this value")
end
function Motorized.registerSoundXMLPaths(p8, p9)
	SoundManager.registerSampleXMLPaths(p8, p9, "motorStart")
	SoundManager.registerSampleXMLPaths(p8, p9, "motorStop")
	SoundManager.registerSampleXMLPaths(p8, p9, "gearbox(?)")
	SoundManager.registerSampleXMLPaths(p8, p9, "clutchCracking")
	SoundManager.registerSampleXMLPaths(p8, p9, "gearEngaged")
	SoundManager.registerSampleXMLPaths(p8, p9, "gearDisengaged")
	SoundManager.registerSampleXMLPaths(p8, p9, "gearLeverStart")
	SoundManager.registerSampleXMLPaths(p8, p9, "gearLeverEnd")
	SoundManager.registerSampleXMLPaths(p8, p9, "gearGroupLeverStart")
	SoundManager.registerSampleXMLPaths(p8, p9, "gearGroupLeverEnd")
	SoundManager.registerSampleXMLPaths(p8, p9, "gearGroupChange")
	SoundManager.registerSampleXMLPaths(p8, p9, "blowOffValve")
	SoundManager.registerSampleXMLPaths(p8, p9, "retarder")
	SoundManager.registerSampleXMLPaths(p8, p9, "motor(?)")
	SoundManager.registerSampleXMLPaths(p8, p9, "airCompressorStart")
	SoundManager.registerSampleXMLPaths(p8, p9, "airCompressorStop")
	SoundManager.registerSampleXMLPaths(p8, p9, "airCompressorRun")
	SoundManager.registerSampleXMLPaths(p8, p9, "compressedAir")
	SoundManager.registerSampleXMLPaths(p8, p9, "airRelease")
	SoundManager.registerSampleXMLPaths(p8, p9, "reverseDrive")
	SoundManager.registerSampleXMLPaths(p8, p9, "brake")
end
function Motorized.prerequisitesPresent(p10)
	local v11 = SpecializationUtil.hasSpecialization(FillUnit, p10)
	if v11 then
		v11 = SpecializationUtil.hasSpecialization(VehicleSettings, p10)
	end
	return v11
end
function Motorized.registerEvents(p12)
	SpecializationUtil.registerEvent(p12, "onStartMotor")
	SpecializationUtil.registerEvent(p12, "onStopMotor")
	SpecializationUtil.registerEvent(p12, "onGearDirectionChanged")
	SpecializationUtil.registerEvent(p12, "onGearChanged")
	SpecializationUtil.registerEvent(p12, "onGearGroupChanged")
	SpecializationUtil.registerEvent(p12, "onClutchCreaking")
end
function Motorized.registerFunctions(p13)
	SpecializationUtil.registerFunction(p13, "loadDifferentials", Motorized.loadDifferentials)
	SpecializationUtil.registerFunction(p13, "loadMotor", Motorized.loadMotor)
	SpecializationUtil.registerFunction(p13, "loadGears", Motorized.loadGears)
	SpecializationUtil.registerFunction(p13, "loadGearGroups", Motorized.loadGearGroups)
	SpecializationUtil.registerFunction(p13, "loadExhaustEffects", Motorized.loadExhaustEffects)
	SpecializationUtil.registerFunction(p13, "onExhaustEffectI3DLoaded", Motorized.onExhaustEffectI3DLoaded)
	SpecializationUtil.registerFunction(p13, "loadSounds", Motorized.loadSounds)
	SpecializationUtil.registerFunction(p13, "loadConsumerConfiguration", Motorized.loadConsumerConfiguration)
	SpecializationUtil.registerFunction(p13, "setMotorState", Motorized.setMotorState)
	SpecializationUtil.registerFunction(p13, "getMotorState", Motorized.getMotorState)
	SpecializationUtil.registerFunction(p13, "getIsMotorStarted", Motorized.getIsMotorStarted)
	SpecializationUtil.registerFunction(p13, "getIsMotorInNeutral", Motorized.getIsMotorInNeutral)
	SpecializationUtil.registerFunction(p13, "getCanMotorRun", Motorized.getCanMotorRun)
	SpecializationUtil.registerFunction(p13, "getStopMotorOnLeave", Motorized.getStopMotorOnLeave)
	SpecializationUtil.registerFunction(p13, "getMotorNotAllowedWarning", Motorized.getMotorNotAllowedWarning)
	SpecializationUtil.registerFunction(p13, "startMotor", Motorized.startMotor)
	SpecializationUtil.registerFunction(p13, "stopMotor", Motorized.stopMotor)
	SpecializationUtil.registerFunction(p13, "updateMotorProperties", Motorized.updateMotorProperties)
	SpecializationUtil.registerFunction(p13, "controlVehicle", Motorized.controlVehicle)
	SpecializationUtil.registerFunction(p13, "updateConsumers", Motorized.updateConsumers)
	SpecializationUtil.registerFunction(p13, "updateMotorTemperature", Motorized.updateMotorTemperature)
	SpecializationUtil.registerFunction(p13, "getMotor", Motorized.getMotor)
	SpecializationUtil.registerFunction(p13, "getMotorStartTime", Motorized.getMotorStartTime)
	SpecializationUtil.registerFunction(p13, "getMotorType", Motorized.getMotorType)
	SpecializationUtil.registerFunction(p13, "getMotorRpmPercentage", Motorized.getMotorRpmPercentage)
	SpecializationUtil.registerFunction(p13, "getMotorRpmReal", Motorized.getMotorRpmReal)
	SpecializationUtil.registerFunction(p13, "getMotorLoadPercentage", Motorized.getMotorLoadPercentage)
	SpecializationUtil.registerFunction(p13, "getMotorBlowOffValveState", Motorized.getMotorBlowOffValveState)
	SpecializationUtil.registerFunction(p13, "getMotorDifferentialSpeed", Motorized.getMotorDifferentialSpeed)
	SpecializationUtil.registerFunction(p13, "getConsumerFillUnitIndex", Motorized.getConsumerFillUnitIndex)
	SpecializationUtil.registerFunction(p13, "getAirConsumerUsage", Motorized.getAirConsumerUsage)
	SpecializationUtil.registerFunction(p13, "getTraveledDistanceStatsActive", Motorized.getTraveledDistanceStatsActive)
	SpecializationUtil.registerFunction(p13, "setGearLeversState", Motorized.setGearLeversState)
	SpecializationUtil.registerFunction(p13, "generateShiftAnimation", Motorized.generateShiftAnimation)
	SpecializationUtil.registerFunction(p13, "getGearInfoToDisplay", Motorized.getGearInfoToDisplay)
	SpecializationUtil.registerFunction(p13, "setTransmissionDirection", Motorized.setTransmissionDirection)
	SpecializationUtil.registerFunction(p13, "getDirectionChangeMode", Motorized.getDirectionChangeMode)
	SpecializationUtil.registerFunction(p13, "getIsManualDirectionChangeAllowed", Motorized.getIsManualDirectionChangeAllowed)
	SpecializationUtil.registerFunction(p13, "getGearShiftMode", Motorized.getGearShiftMode)
	SpecializationUtil.registerFunction(p13, "stopVehicle", Motorized.stopVehicle)
end
function Motorized.registerOverwrittenFunctions(p14)
	SpecializationUtil.registerOverwrittenFunction(p14, "getBrakeForce", Motorized.getBrakeForce)
	SpecializationUtil.registerOverwrittenFunction(p14, "addToPhysics", Motorized.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p14, "removeFromPhysics", Motorized.removeFromPhysics)
	SpecializationUtil.registerOverwrittenFunction(p14, "getIsOperating", Motorized.getIsOperating)
	SpecializationUtil.registerOverwrittenFunction(p14, "getDeactivateOnLeave", Motorized.getDeactivateOnLeave)
	SpecializationUtil.registerOverwrittenFunction(p14, "getDeactivateLightsOnLeave", Motorized.getDeactivateLightsOnLeave)
	SpecializationUtil.registerOverwrittenFunction(p14, "loadDashboardGroupFromXML", Motorized.loadDashboardGroupFromXML)
	SpecializationUtil.registerOverwrittenFunction(p14, "getIsDashboardGroupActive", Motorized.getIsDashboardGroupActive)
	SpecializationUtil.registerOverwrittenFunction(p14, "getIsActiveForInteriorLights", Motorized.getIsActiveForInteriorLights)
	SpecializationUtil.registerOverwrittenFunction(p14, "getIsActiveForWipers", Motorized.getIsActiveForWipers)
	SpecializationUtil.registerOverwrittenFunction(p14, "getUsageCausesDamage", Motorized.getUsageCausesDamage)
	SpecializationUtil.registerOverwrittenFunction(p14, "getName", Motorized.getName)
	SpecializationUtil.registerOverwrittenFunction(p14, "getCanBeSelected", Motorized.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p14, "getIsPowered", Motorized.getIsPowered)
end
function Motorized.registerEventListeners(p15)
	SpecializationUtil.registerEventListener(p15, "onLoad", Motorized)
	SpecializationUtil.registerEventListener(p15, "onPostLoad", Motorized)
	SpecializationUtil.registerEventListener(p15, "onRegisterDashboardValueTypes", Motorized)
	SpecializationUtil.registerEventListener(p15, "onDelete", Motorized)
	SpecializationUtil.registerEventListener(p15, "onReadStream", Motorized)
	SpecializationUtil.registerEventListener(p15, "onWriteStream", Motorized)
	SpecializationUtil.registerEventListener(p15, "onReadUpdateStream", Motorized)
	SpecializationUtil.registerEventListener(p15, "onWriteUpdateStream", Motorized)
	SpecializationUtil.registerEventListener(p15, "onUpdate", Motorized)
	SpecializationUtil.registerEventListener(p15, "onUpdateTick", Motorized)
	SpecializationUtil.registerEventListener(p15, "onRegisterActionEvents", Motorized)
	SpecializationUtil.registerEventListener(p15, "onStateChange", Motorized)
	SpecializationUtil.registerEventListener(p15, "onFillUnitFillLevelChanged", Motorized)
	SpecializationUtil.registerEventListener(p15, "onSetBroken", Motorized)
	SpecializationUtil.registerEventListener(p15, "onGearDirectionChanged", Motorized)
	SpecializationUtil.registerEventListener(p15, "onGearChanged", Motorized)
	SpecializationUtil.registerEventListener(p15, "onGearGroupChanged", Motorized)
	SpecializationUtil.registerEventListener(p15, "onClutchCreaking", Motorized)
	SpecializationUtil.registerEventListener(p15, "onReverseDirectionChanged", Motorized)
	SpecializationUtil.registerEventListener(p15, "onVehicleSettingChanged", Motorized)
	SpecializationUtil.registerEventListener(p15, "onAIJobStarted", Motorized)
	SpecializationUtil.registerEventListener(p15, "onAIJobFinished", Motorized)
end
function Motorized.onLoad(p_u_16, _)
	local v_u_17 = p_u_16.spec_motorized
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.motor.animationNodes.animationNode", "motor")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.differentialConfigurations", "vehicle.motorized.differentialConfigurations")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.motorConfigurations", "vehicle.motorized.motorConfigurations")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.maximalAirConsumptionPerFullStop", "vehicle.motorized.consumerConfigurations.consumerConfiguration.consumer(with fill type \'air\')#usage (is now in usage per second at full brake power)")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.indoorHud.rpm", "vehicle.motorized.dashboards.dashboard with valueType \'rpm\'")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.indoorHud.speed", "vehicle.motorized.dashboards.dashboard with valueType \'speed\'")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.indoorHud.fuelUsage", "vehicle.motorized.dashboards.dashboard with valueType \'fuelUsage\'")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.indoorHud.fuel", "fillUnit.dashboard with valueType \'fillLevel\'")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.motor", "vehicle.motorized.motorConfigurations.motorConfiguration(?).motor")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.transmission", "vehicle.motorized.motorConfigurations.motorConfiguration(?).transmission")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.fuelCapacity", "vehicle.motorized.consumerConfigurations.consumerConfiguration.consumer#capacity")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.motorized.motorConfigurations.motorConfiguration(?).fuelCapacity", "vehicle.motorized.consumerConfigurations.consumerConfiguration.consumer#capacity")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle#consumerConfigurationIndex", "vehicle.motorized.motorConfigurations.motorConfiguration(?)#consumerConfigurationIndex\'")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.motorized.exhaustParticleSystems#count")
	XMLUtil.checkDeprecatedXMLElements(p_u_16.xmlFile, "vehicle.motorized.exhaustParticleSystems.exhaustParticleSystem1", "vehicle.motorized.exhaustParticleSystems.exhaustParticleSystem")
	v_u_17.motorizedNode = nil
	for _, v18 in pairs(p_u_16.components) do
		if v18.motorized then
			v_u_17.motorizedNode = v18.node
			break
		end
	end
	v_u_17.directionChangeMode = VehicleMotor.DIRECTION_CHANGE_MODE_AUTOMATIC
	v_u_17.gearShiftMode = VehicleMotor.SHIFT_MODE_AUTOMATIC
	local v19 = string.format("vehicle.motorized.motorConfigurations.motorConfiguration(%d)", p_u_16.configurations.motor - 1)
	p_u_16:loadDifferentials(p_u_16.xmlFile, p_u_16.differentialIndex)
	p_u_16:loadMotor(p_u_16.xmlFile, p_u_16.configurations.motor)
	p_u_16:loadSounds(p_u_16.xmlFile, "vehicle.motorized.sounds")
	if p_u_16.xmlFile:hasProperty(v19) then
		p_u_16:loadSounds(p_u_16.xmlFile, v19 .. ".sounds")
	end
	p_u_16:loadConsumerConfiguration(p_u_16.xmlFile, v_u_17.consumerConfigurationIndex)
	if p_u_16.isClient then
		p_u_16:loadExhaustEffects(p_u_16.xmlFile)
	end
	v_u_17.gearLevers = {}
	v_u_17.activeGearLeverInterpolators = {}
	p_u_16.xmlFile:iterate("vehicle.motorized.gearLevers.gearLever", function(_, p20)
		-- upvalues: (copy) p_u_16, (copy) v_u_17
		local v_u_21 = {
			["node"] = p_u_16.xmlFile:getValue(p20 .. "#node", nil, p_u_16.components, p_u_16.i3dMappings)
		}
		if v_u_21.node == nil then
			Logging.xmlWarning(p_u_16.xmlFile, "Unable to load gear lever. Missing node! \'%s\'", p20)
		else
			v_u_21.centerAxis = p_u_16.xmlFile:getValue(p20 .. "#centerAxis")
			v_u_21.changeTime = p_u_16.xmlFile:getValue(p20 .. "#changeTime", 500)
			v_u_21.handsOnDelay = p_u_16.xmlFile:getValue(p20 .. "#handsOnDelay", 0)
			v_u_21.curTarget = { getRotation(v_u_21.node) }
			v_u_21.states = {}
			p_u_16.xmlFile:iterate(p20 .. ".state", function(_, p22)
				-- upvalues: (ref) p_u_16, (copy) v_u_21
				local v23 = {
					["gear"] = p_u_16.xmlFile:getValue(p22 .. "#gear"),
					["group"] = p_u_16.xmlFile:getValue(p22 .. "#group")
				}
				if v23.gear == nil and v23.group == nil then
					Logging.xmlWarning(p_u_16.xmlFile, "Unable to load gear lever state. Missing gear or group! \'%s\'", p22)
				else
					v23.node = v_u_21.node
					v23.gearLever = v_u_21
					local v24, v25, v26 = getRotation(v_u_21.node)
					local v27 = p_u_16.xmlFile:getValue(p22 .. "#xRot", v24)
					local v28 = p_u_16.xmlFile:getValue(p22 .. "#yRot", v25)
					local v29 = p_u_16.xmlFile:getValue(p22 .. "#zRot", v26)
					v23.rotation = { v27, v28, v29 }
					v23.useRotation = { p_u_16.xmlFile:getValue(p22 .. "#xRot") ~= nil, p_u_16.xmlFile:getValue(p22 .. "#yRot") ~= nil, p_u_16.xmlFile:getValue(p22 .. "#zRot") ~= nil }
					v23.curRotation = { v27, v28, v29 }
					local v30 = v_u_21.states
					table.insert(v30, v23)
				end
			end)
			local v31 = v_u_17.gearLevers
			table.insert(v31, v_u_21)
		end
	end)
	v_u_17.stopMotorOnLeave = true
	v_u_17.motorStartDuration = 0
	if v_u_17.samples ~= nil and v_u_17.samples.motorStart ~= nil then
		v_u_17.motorStartDuration = v_u_17.samples.motorStart.duration
	end
	if v_u_17.motorSamples ~= nil then
		local v32 = 0
		for _, v33 in ipairs(v_u_17.motorSamples) do
			local v34 = g_soundManager
			v32 = math.max(v32, v34:getSampleLoopSynthesisStartDuration(v33))
		end
		if v32 ~= 0 then
			v_u_17.motorStartDuration = v32
		end
	end
	v_u_17.motorStartDuration = p_u_16.xmlFile:getValue("vehicle.motorized.motorStartDuration", v_u_17.motorStartDuration) or 0
	if p_u_16.xmlFile:hasProperty(v19) then
		v_u_17.motorStartDuration = p_u_16.xmlFile:getValue(v19 .. ".motorStartDuration", v_u_17.motorStartDuration)
	end
	v_u_17.clutchNoEngagedWarning = p_u_16.xmlFile:getValue("vehicle.motorized#clutchNoEngagedWarning", "warning_motorClutchNoEngaged", p_u_16.customEnvironment)
	v_u_17.clutchCrackingGearWarning = p_u_16.xmlFile:getValue("vehicle.motorized#clutchCrackingGearWarning", "action_clutchCrackingGear", p_u_16.customEnvironment)
	v_u_17.clutchCrackingGroupWarning = p_u_16.xmlFile:getValue("vehicle.motorized#clutchCrackingGroupWarning", "action_clutchCrackingGroup", p_u_16.customEnvironment)
	v_u_17.turnOnText = p_u_16.xmlFile:getValue("vehicle.motorized#turnOnText", "action_startMotor", p_u_16.customEnvironment)
	v_u_17.turnOffText = p_u_16.xmlFile:getValue("vehicle.motorized#turnOffText", "action_stopMotor", p_u_16.customEnvironment)
	v_u_17.speedDisplayScale = 1
	v_u_17.motorStartTime = 0
	v_u_17.actualLoadPercentage = 0
	v_u_17.smoothedLoadPercentage = 0
	v_u_17.maxDecelerationDuringBrake = 0
	v_u_17.lastControlParameters = {
		["acceleratorPedal"] = nil,
		["maxSpeed"] = nil,
		["maxAcceleration"] = nil,
		["minMotorRotSpeed"] = nil,
		["maxMotorRotSpeed"] = nil,
		["maxMotorRotAcceleration"] = nil,
		["minGearRatio"] = nil,
		["maxGearRatio"] = nil,
		["maxClutchTorque"] = nil,
		["neededPtoTorque"] = nil
	}
	v_u_17.clutchCrackingTimeOut = (1 / 0)
	v_u_17.clutchState = 0
	v_u_17.clutchStateSent = 0
	v_u_17.motorState = MotorState.OFF
	v_u_17.motorStopTimerDuration = g_gameSettings:getValue(GameSettings.SETTING.MOTOR_STOP_TIMER_DURATION)
	v_u_17.motorStopTimer = v_u_17.motorStopTimerDuration
	v_u_17.motorNotRequiredTimer = 0
	v_u_17.motorTemperature = {}
	v_u_17.motorTemperature.value = 20
	v_u_17.motorTemperature.valueSend = 20
	v_u_17.motorTemperature.valueMax = 120
	v_u_17.motorTemperature.valueMin = 20
	v_u_17.motorTemperature.heatingPerMS = 0.0015
	v_u_17.motorTemperature.coolingByWindPerMS = 0.001
	v_u_17.motorFan = {}
	v_u_17.motorFan.enabled = false
	v_u_17.motorFan.enableTemperature = 95
	v_u_17.motorFan.disableTemperature = 85
	v_u_17.motorFan.coolingPerMS = 0.003
	v_u_17.lastFuelUsage = 0
	v_u_17.lastFuelUsageDisplay = 0
	v_u_17.lastFuelUsageDisplayTime = 0
	v_u_17.fuelUsageBuffer = ValueBuffer.new(250)
	v_u_17.lastDefUsage = 0
	v_u_17.lastAirUsage = 0
	v_u_17.lastVehicleDamage = 0
	v_u_17.forceSpeedHudDisplay = p_u_16.xmlFile:getValue("vehicle.motorized#forceSpeedHudDisplay", false)
	v_u_17.forceRpmHudDisplay = p_u_16.xmlFile:getValue("vehicle.motorized#forceRpmHudDisplay", false)
	v_u_17.statsType = string.lower(p_u_16.xmlFile:getValue("vehicle.motorized#statsType", "tractor"))
	if v_u_17.statsType ~= "tractor" and (v_u_17.statsType ~= "car" and v_u_17.statsType ~= "truck") then
		v_u_17.statsType = "tractor"
	end
	v_u_17.statsTypeDistance = v_u_17.statsType .. "Distance"
	v_u_17.animationNodes = g_animationManager:loadAnimations(p_u_16.xmlFile, "vehicle.motorized.animationNodes", p_u_16.components, p_u_16, p_u_16.i3dMappings)
	v_u_17.traveledDistanceBuffer = 0
	v_u_17.dirtyFlag = p_u_16:getNextDirtyFlag()
	v_u_17.inputDirtyFlag = p_u_16:getNextDirtyFlag()
	p_u_16:registerVehicleSetting(GameSettings.SETTING.DIRECTION_CHANGE_MODE, false)
	p_u_16:registerVehicleSetting(GameSettings.SETTING.GEAR_SHIFT_MODE, false)
end
function Motorized.onPostLoad(p35, p36)
	local v37 = p35.spec_motorized
	if p35.isServer then
		local v38 = 0
		for _, v39 in pairs(v37.consumersByFillTypeName) do
			local v40 = p35:getFillUnitFillLevel(v39.fillUnitIndex)
			local v41 = p35:getFillUnitCapacity(v39.fillUnitIndex) * 0.1
			if v40 < v41 then
				local v42 = v41 - v40
				p35:addFillUnitFillLevel(p35:getOwnerFarmId(), v39.fillUnitIndex, v42, v39.fillType, ToolType.UNDEFINED)
				local v43 = v42 * g_currentMission.economyManager:getCostPerLiter(v39.fillType) * 2
				g_farmManager:updateFarmStats(p35:getOwnerFarmId(), "expenses", v43)
				g_currentMission:addMoney(-v43, p35:getOwnerFarmId(), MoneyType.PURCHASE_FUEL, false, false)
				v38 = v38 + v43
			end
		end
		if v38 > 0 then
			g_currentMission:addMoneyChange(-v38, p35:getOwnerFarmId(), MoneyType.PURCHASE_FUEL, true)
		end
	end
	v37.propellantFillUnitIndices = {}
	for _, v44 in pairs({
		FillType.DIESEL,
		FillType.DEF,
		FillType.ELECTRICCHARGE,
		FillType.METHANE
	}) do
		local v45 = g_fillTypeManager:getFillTypeNameByIndex(v44)
		if v37.consumersByFillTypeName[v45] ~= nil then
			local v46 = v37.propellantFillUnitIndices
			local v47 = v37.consumersByFillTypeName[v45].fillUnitIndex
			table.insert(v46, v47)
		end
	end
	if v37.motor ~= nil then
		v37.motor:postLoad(p36)
	end
end
function Motorized.onRegisterDashboardValueTypes(p_u_48)
	local v_u_49 = p_u_48.spec_motorized
	local v50 = DashboardValueType.new("motorized", "rpm")
	v50:setValue(v_u_49.motor, "getLastModulatedMotorRpm")
	v50:setRange(0, "getMaxRpm")
	v50:setInterpolationSpeed(function(p51, _)
		return p51:getMaxRpm() * 0.001
	end)
	p_u_48:registerDashboardValueType(v50)
	local v52 = DashboardValueType.new("motorized", "load")
	v52:setValue(v_u_49.motor, "getSmoothLoadPercentage")
	v52:setRange(0, 100)
	v52:setInterpolationSpeed(0.1)
	v52:setValueFactor(100)
	p_u_48:registerDashboardValueType(v52)
	local v53 = DashboardValueType.new("motorized", "speed")
	v53:setValue(p_u_48, "getLastSpeed")
	v53:setRange(0, p_u_48:getMotor():getMaximumForwardSpeed() * 3.6)
	v53:setInterpolationSpeed(function(_, _)
		-- upvalues: (copy) p_u_48
		return p_u_48:getLastSpeed() * 0.001
	end)
	p_u_48:registerDashboardValueType(v53)
	local v54 = DashboardValueType.new("motorized", "speedDir")
	v54:setValue(p_u_48, function()
		-- upvalues: (copy) p_u_48, (copy) v_u_49
		return p_u_48:getLastSpeed() * v_u_49.motor:getDrivingDirection()
	end)
	v54:setRange(-p_u_48:getMotor():getMaximumBackwardSpeed() * 3.6, p_u_48:getMotor():getMaximumForwardSpeed() * 3.6)
	v54:setInterpolationSpeed(function(_, _)
		-- upvalues: (copy) p_u_48
		return p_u_48:getMotor():getMaximumForwardSpeed() * 3.6 * 0.001
	end)
	v54:setCenter(0)
	p_u_48:registerDashboardValueType(v54)
	local v55 = DashboardValueType.new("motorized", "fuelUsage")
	v55:setValue(v_u_49, "lastFuelUsageDisplay")
	p_u_48:registerDashboardValueType(v55)
	local v56 = DashboardValueType.new("motorized", "motorTemperature")
	v56:setValue(v_u_49.motorTemperature, "value")
	v56:setRange("valueMin", "valueMax")
	v56:setInterpolationSpeed(function(p57, _)
		return (p57.valueMax - p57.valueMin) * 0.001
	end)
	p_u_48:registerDashboardValueType(v56)
	local v58 = DashboardValueType.new("motorized", "motorTemperatureWarning")
	v58:setValue(v_u_49.motorTemperature, function(_, p59)
		-- upvalues: (copy) v_u_49
		local v60 = v_u_49.motorTemperature.value
		local v61
		if p59.warningThresholdMin < v60 then
			v61 = v60 < p59.warningThresholdMax
		else
			v61 = false
		end
		return v61
	end)
	v58:setAdditionalFunctions(Dashboard.warningAttributes)
	p_u_48:registerDashboardValueType(v58)
	local v62 = DashboardValueType.new("motorized", "clutchPedal")
	v62:setValue(v_u_49.motor, "getSmoothedClutchPedal")
	v62:setRange(0, 1)
	p_u_48:registerDashboardValueType(v62)
	local v63 = DashboardValueType.new("motorized", "gear")
	v63:setValue(v_u_49.motor, function()
		-- upvalues: (copy) v_u_49
		return v_u_49.motor:getGearToDisplay(true)
	end)
	v63:setRange(0, (1 / 0))
	p_u_48:registerDashboardValueType(v63)
	local v64 = DashboardValueType.new("motorized", "gearGroup")
	v64:setValue(v_u_49.motor, function()
		-- upvalues: (copy) v_u_49
		return v_u_49.motor:getGearGroupToDisplay(true)
	end)
	v64:setRange(0, (1 / 0))
	p_u_48:registerDashboardValueType(v64)
	local v65 = DashboardValueType.new("motorized", "gearShiftUp")
	v65:setValue(v_u_49.motor, function(p66)
		local v67
		if g_time - p66.lastGearChangeTime < 200 then
			v67 = p66.targetGear > p66.previousGear
		else
			v67 = false
		end
		return v67
	end)
	p_u_48:registerDashboardValueType(v65)
	local v68 = DashboardValueType.new("motorized", "gearShiftDown")
	v68:setValue(v_u_49.motor, function(p69)
		local v70
		if g_time - p69.lastGearChangeTime < 200 then
			v70 = p69.targetGear < p69.previousGear
		else
			v70 = false
		end
		return v70
	end)
	p_u_48:registerDashboardValueType(v68)
	local v71 = DashboardValueType.new("motorized", "movingDirection")
	v71:setValue(v_u_49.motor, "getDrivingDirection")
	v71:setRange(-1, 1)
	p_u_48:registerDashboardValueType(v71)
	local v72 = DashboardValueType.new("motorized", "directionForward")
	v72:setValue(v_u_49.motor, function(p73)
		return p73:getDrivingDirection() >= 0
	end)
	p_u_48:registerDashboardValueType(v72)
	local v74 = DashboardValueType.new("motorized", "directionForwardExclusive")
	v74:setValue(v_u_49.motor, function(p75)
		return p75:getDrivingDirection() > 0
	end)
	p_u_48:registerDashboardValueType(v74)
	local v76 = DashboardValueType.new("motorized", "directionBackward")
	v76:setValue(v_u_49.motor, function(p77)
		return p77:getDrivingDirection() < 0
	end)
	p_u_48:registerDashboardValueType(v76)
	local v78 = DashboardValueType.new("motorized", "directionNeutral")
	v78:setValue(v_u_49.motor, function(p79)
		return p79:getDrivingDirection() == 0
	end)
	p_u_48:registerDashboardValueType(v78)
	local v80 = DashboardValueType.new("motorized", "movingDirectionLetter")
	v80:setValue(v_u_49.motor, function(p81)
		return p81:getDrivingDirection() == 1 and "F" or (p81:getDrivingDirection() == -1 and "R" or "N")
	end)
	p_u_48:registerDashboardValueType(v80)
	local v82 = DashboardValueType.new("motorized", "ignitionState")
	v82:setValue(p_u_48, function()
		-- upvalues: (copy) p_u_48
		local v83 = p_u_48:getMotorState()
		return v83 == MotorState.ON and 2 or (v83 == MotorState.STARTING and 1 or 0)
	end)
	v82:setRange(0, 2)
	p_u_48:registerDashboardValueType(v82)
	local v84 = DashboardValueType.new("motorized", "battery")
	v84:setValue(p_u_48, 12 + (math.random() * 0.5 - 0.15))
	v84:setRange(0, 15)
	v84:setInterpolationSpeed(0.015)
	p_u_48:registerDashboardValueType(v84)
end
function Motorized.onDelete(p85)
	local v86 = p85.spec_motorized
	if v86.motor ~= nil then
		v86.motor:delete()
	end
	if v86.sharedLoadRequestIds ~= nil then
		for _, v87 in ipairs(v86.sharedLoadRequestIds) do
			g_i3DManager:releaseSharedI3DFile(v87)
		end
		v86.sharedLoadRequestIds = nil
	end
	ParticleUtil.deleteParticleSystems(v86.exhaustParticleSystems)
	g_soundManager:deleteSamples(v86.samples)
	g_soundManager:deleteSamples(v86.motorSamples)
	g_soundManager:deleteSamples(v86.gearboxSamples)
	g_animationManager:deleteAnimations(v86.animationNodes)
end
function Motorized.onReadStream(p88, p89, _)
	p88:setMotorState(MotorState.readStream(p89), true)
end
function Motorized.onWriteStream(p90, p91, _)
	MotorState.writeStream(p91, p90.spec_motorized.motorState)
end
function Motorized.onReadUpdateStream(p92, p93, _, p94)
	local v95 = p92.spec_motorized
	if p94.isServer then
		if streamReadBool(p93) then
			local v96 = streamReadUIntN(p93, 11) / 2047
			local v97 = v95.motor:getMaxRpm() - v95.motor:getMinRpm()
			v95.motor:setEqualizedMotorRpm(v96 * v97 + v95.motor:getMinRpm())
			local v98 = streamReadUIntN(p93, 7)
			v95.motor.rawLoadPercentage = v98 / 127
			v95.brakeCompressor.doFill = streamReadBool(p93)
			local v99 = streamReadUIntN(p93, 5)
			v95.motor:onManualClutchChanged(v99 / 31)
		end
		if streamReadBool(p93) then
			v95.motor:readGearDataFromStream(p93)
			return
		end
	elseif streamReadBool(p93) and streamReadBool(p93) then
		v95.clutchState = streamReadUIntN(p93, 7) / 127
		v95.motor:onManualClutchChanged(v95.clutchState)
		if v95.clutchState > 0 then
			p92:raiseActive()
		end
	end
end
function Motorized.onWriteUpdateStream(p100, p101, p102, p103)
	local v104 = p100.spec_motorized
	if p102.isServer then
		if streamWriteBool(p101, bitAND(p103, v104.inputDirtyFlag) ~= 0) and streamWriteBool(p101, v104.clutchState ~= v104.clutchStateSent) then
			streamWriteUIntN(p101, 127 * v104.clutchState, 7)
			v104.clutchStateSent = v104.clutchState
		end
	else
		local v105 = p100:getMotorState()
		if streamWriteBool(p101, v105 == MotorState.STARTING and true or v105 == MotorState.ON) then
			local v106 = v104.motor:getMaxRpm() - v104.motor:getMinRpm()
			local v107 = (v104.motor:getEqualizedMotorRpm() - v104.motor:getMinRpm()) / v106
			local v108 = math.clamp(v107, 0, 1) * 2047
			local v109 = math.floor(v108)
			streamWriteUIntN(p101, v109, 11)
			streamWriteUIntN(p101, 127 * v104.actualLoadPercentage, 7)
			streamWriteBool(p101, v104.brakeCompressor.doFill)
			streamWriteUIntN(p101, 31 * v104.motor:getClutchPedal(), 5)
		end
		if streamWriteBool(p101, bitAND(p103, v104.dirtyFlag) ~= 0) then
			v104.motor:writeGearDataToStream(p101)
			return
		end
	end
end
function Motorized.onUpdate(p110, p111, _, _, _)
	local v112 = p110.spec_motorized
	local v113 = p110.getAxisForward == nil and 0 or p110:getAxisForward()
	local v114 = p110:getMotorState()
	if v114 == MotorState.STARTING or v114 == MotorState.ON then
		if p110.isServer and (v114 == MotorState.STARTING and v112.motorStartTime < g_currentMission.time) then
			p110:setMotorState(MotorState.ON)
		end
		v112.motor:update(p111)
		if p110.isServer then
			local v115 = v112.motor.rawLoadPercentage
			v112.actualLoadPercentage = math.clamp(v115, 0, 1)
		end
		v112.smoothedLoadPercentage = v112.motor:getSmoothLoadPercentage()
		local v116 = p110.getCruiseControlState ~= nil and p110:getCruiseControlState() ~= Drivable.CRUISECONTROL_STATE_OFF and 1 or v113
		if p110.isServer then
			p110:updateConsumers(p111, v116)
			local v117 = p110:getVehicleDamage() - v112.lastVehicleDamage
			if math.abs(v117) > 0.05 then
				p110:updateMotorProperties()
				v112.lastVehicleDamage = p110:getVehicleDamage()
			end
		end
		if p110.isClient then
			local v118 = v112.samples
			local v119 = v112.motor:getLastModulatedMotorRpm()
			local v120 = v112.motor.minRpm
			local v121 = v112.motor.maxRpm
			local v122 = (v119 - v120) / (v121 - v120)
			local v123 = math.min(v122, 1)
			local v124 = math.max(v123, 0)
			local v125 = v112.smoothedLoadPercentage
			local v126 = math.min(v125, 1)
			local v127 = math.max(v126, -1)
			g_soundManager:setSamplesLoopSynthesisParameters(v112.motorSamples, v124, v127)
			if g_soundManager:getIsSamplePlaying(v112.motorSamples[1]) then
				if v118.airCompressorRun ~= nil and (v112.consumersByFillTypeName ~= nil and v112.consumersByFillTypeName.AIR ~= nil) then
					if v112.consumersByFillTypeName.AIR.doRefill then
						if not g_soundManager:getIsSamplePlaying(v118.airCompressorRun) then
							if v118.airCompressorStart == nil then
								g_soundManager:playSample(v118.airCompressorRun)
							else
								if not g_soundManager:getIsSamplePlaying(v118.airCompressorStart) and v112.brakeCompressor.playSampleRunTime == nil then
									g_soundManager:playSample(v118.airCompressorStart)
									v112.brakeCompressor.playSampleRunTime = g_currentMission.time + v118.airCompressorStart.duration
								end
								if not g_soundManager:getIsSamplePlaying(v118.airCompressorStart) then
									v112.brakeCompressor.playSampleRunTime = nil
									g_soundManager:stopSample(v118.airCompressorStart)
									g_soundManager:playSample(v118.airCompressorRun)
								end
							end
						end
					elseif g_soundManager:getIsSamplePlaying(v118.airCompressorRun) then
						g_soundManager:stopSample(v118.airCompressorRun)
						g_soundManager:playSample(v118.airCompressorStop)
					end
				end
				if v112.compressionSoundTime <= g_currentMission.time then
					g_soundManager:playSample(v118.airRelease)
					v112.compressionSoundTime = g_currentMission.time + math.random(10000, 40000)
				end
				local v128
				if p110:getDecelerationAxis() > 0 then
					v128 = p110:getLastSpeed() > 1
				else
					v128 = false
				end
				if v118.compressedAir ~= nil then
					if v128 then
						v118.compressedAir.brakeTime = v118.compressedAir.brakeTime + p111
					elseif v118.compressedAir.brakeTime > 0 then
						v118.compressedAir.lastBrakeTime = v118.compressedAir.brakeTime
						v118.compressedAir.brakeTime = 0
						g_soundManager:playSample(v118.compressedAir)
					end
				end
				if v112.motor.blowOffValveState > 0 then
					if not g_soundManager:getIsSamplePlaying(v118.blowOffValve) then
						g_soundManager:playSample(v118.blowOffValve)
					end
				elseif g_soundManager:getIsSamplePlaying(v118.blowOffValve) then
					g_soundManager:stopSample(v118.blowOffValve)
				end
				if v118.brake ~= nil then
					if v128 then
						if not v112.isBrakeSamplePlaying then
							g_soundManager:playSample(v118.brake)
							v112.isBrakeSamplePlaying = true
						end
					elseif v112.isBrakeSamplePlaying then
						g_soundManager:stopSample(v118.brake)
						v112.isBrakeSamplePlaying = false
					end
				end
				if v118.reverseDrive ~= nil then
					local v129 = p110.getReverserDirection == nil and 1 or p110:getReverserDirection()
					local v130
					if p110:getLastSpeed() > v112.reverseDriveThreshold then
						v130 = p110.movingDirection ~= v129
					else
						v130 = false
					end
					if g_soundManager:getIsSamplePlaying(v118.reverseDrive) or not v130 then
						if not v130 then
							g_soundManager:stopSample(v118.reverseDrive)
						end
					else
						g_soundManager:playSample(v118.reverseDrive)
					end
				end
			end
			for v131, v132 in pairs(v112.activeGearLeverInterpolators) do
				local v133 = v132.interpolations[v132.currentInterpolation]
				if v133 == nil then
					v112.activeGearLeverInterpolators[v131] = nil
				elseif v132.handsOnDelay > 0 then
					v132.handsOnDelay = v132.handsOnDelay - p111
					if v132.handsOnDelay <= 0 then
						local v134 = v132.isGear and v112.samples.gearLeverStart or v112.samples.gearGroupLeverStart
						if not g_soundManager:getIsSamplePlaying(v134) then
							g_soundManager:playSample(v134)
						end
					end
					if p110.setCharacterTargetNodeStateDirty ~= nil then
						p110:setCharacterTargetNodeStateDirty(v131.node, true)
					end
				else
					local v135 = v131.curRotation
					local v136 = v131.curRotation
					local v137 = v131.curRotation
					local v138, v139, v140 = getRotation(v131.node)
					v135[1] = v138
					v136[2] = v139
					v137[3] = v140
					local v141 = math.min
					if v133.speed < 0 then
						v141 = math.max
					end
					v131.curRotation[v133.axis] = v141(v131.curRotation[v133.axis] + v133.speed * p111, v133.tar)
					setRotation(v131.node, v131.curRotation[1], v131.curRotation[2], v131.curRotation[3])
					if v131.curRotation[v133.axis] == v133.tar then
						v132.currentInterpolation = v132.currentInterpolation + 1
						if v132.currentInterpolation > #v132.interpolations then
							v112.activeGearLeverInterpolators[v131] = nil
							if v132.isResetPosition and p110.resetCharacterTargetNodeStateDefaults ~= nil then
								p110:resetCharacterTargetNodeStateDefaults(v131.node)
							end
							local v142 = v132.isGear and v112.samples.gearLeverEnd or v112.samples.gearGroupLeverEnd
							if not g_soundManager:getIsSamplePlaying(v142) then
								g_soundManager:playSample(v142)
							end
						end
					end
					if p110.setCharacterTargetNodeStateDirty ~= nil then
						p110:setCharacterTargetNodeStateDirty(v131.node)
					end
				end
			end
		end
		if p110.isServer and (not p110:getIsAIActive() and (p110:getTraveledDistanceStatsActive() and p110.lastMovedDistance > 0.001)) then
			v112.traveledDistanceBuffer = v112.traveledDistanceBuffer + p110.lastMovedDistance
			if v112.traveledDistanceBuffer > 10 then
				local v143 = p110:getOwnerFarmId()
				local v144 = v112.traveledDistanceBuffer * 0.001
				g_farmManager:updateFarmStats(v143, "traveledDistance", v144)
				g_farmManager:updateFarmStats(v143, v112.statsTypeDistance, v144)
				v112.traveledDistanceBuffer = 0
			end
		end
	end
end
function Motorized.onUpdateTick(p145, p146, _, p147, _)
	local v148 = p145.spec_motorized
	local v149 = g_currentMission.missionInfo.automaticMotorStartEnabled
	if p145.isServer then
		if not v149 then
			local v150 = p145:getMotorState()
			if (v150 == MotorState.STARTING or v150 == MotorState.ON) and not p145:getIsAIActive() then
				local v151
				if p145.getIsEntered == nil then
					v151 = false
				else
					v151 = p145:getIsEntered()
				end
				local v152
				if p145.getIsControlled == nil then
					v152 = false
				else
					v152 = p145:getIsControlled()
				end
				if not (v151 or v152) then
					local v153 = false
					for _, v154 in pairs(g_currentMission.playerSystem.players) do
						if v154.isControlled and calcDistanceFrom(p145.rootNode, v154.rootNode) < 250 then
							v153 = true
							break
						end
					end
					if not v153 then
						for _, v155 in pairs(g_currentMission.vehicleSystem.enterables) do
							if v155.spec_enterable ~= nil and (v155.spec_enterable.isControlled and calcDistanceFrom(p145.rootNode, v155.rootNode) < 250) then
								v153 = true
								break
							end
						end
					end
					if v153 then
						v148.motorStopTimer = v148.motorStopTimerDuration
					else
						v148.motorStopTimer = v148.motorStopTimer - p146
						if v148.motorStopTimer <= 0 then
							p145:stopMotor()
						end
					end
				end
			end
		end
		local v156 = p145:getMotorState()
		if v156 == MotorState.STARTING or v156 == MotorState.ON then
			p145:updateMotorTemperature(p146)
		end
		if v149 then
			if v156 == MotorState.OFF or v156 == MotorState.IGNITION then
				if p145.getIsControlled ~= nil and (p145:getIsControlled() and p145:getCanMotorRun()) then
					p145:startMotor(true)
				end
				if p145:getRequiresPower() and p145:getCanMotorRun() then
					p145:startMotor(true)
				end
			elseif p145.getIsControlled ~= nil and not p145:getIsControlled() then
				if p145:getStopMotorOnLeave() then
					v148.motorNotRequiredTimer = v148.motorNotRequiredTimer + p146
					if v148.motorNotRequiredTimer > 250 then
						p145:stopMotor(true)
					end
				end
				p145:raiseActive()
			end
		end
	end
	if p145.isClient then
		local v157 = p145:getMotorState()
		if v157 == MotorState.STARTING or v157 == MotorState.ON then
			local v158 = v148.motor:getEqualizedMotorRpm() / v148.motor:getMaxRpm()
			if v148.exhaustParticleSystems ~= nil then
				for _, v159 in pairs(v148.exhaustParticleSystems) do
					local v160 = MathUtil.lerp(v148.exhaustParticleSystems.minScale, v148.exhaustParticleSystems.maxScale, v158)
					ParticleUtil.setEmitCountScale(v148.exhaustParticleSystems, v160)
					ParticleUtil.setParticleLifespan(v159, v159.originalLifespan * v160)
				end
			end
			for _, v161 in ipairs(v148.exhaustFlaps) do
				local v162 = MathUtil.lerp(-0.1, 0.1, math.random()) + v158
				local v163 = math.clamp(v162, 0, 1) * v161.maxRot
				if v161.rotationAxis == 1 then
					setRotation(v161.node, v163, 0, 0)
				elseif v161.rotationAxis == 2 then
					setRotation(v161.node, 0, v163, 0)
				else
					setRotation(v161.node, 0, 0, v163)
				end
			end
			if v148.exhaustEffects ~= nil then
				for _, v164 in pairs(v148.exhaustEffects) do
					local v165, v166, v167 = localToWorld(v164.effectNode, 0, 0.5, 0)
					if v164.lastPosition == nil then
						v164.lastPosition = { v165, v166, v167 }
					end
					local v168 = (v165 - v164.lastPosition[1]) * 10
					local v169 = (v166 - v164.lastPosition[2]) * 10
					local v170 = (v167 - v164.lastPosition[3]) * 10
					local v171, v172, v173 = localToWorld(v164.effectNode, 0, 1, 0)
					local v174 = v171 - v168
					local v175 = v172 - v169 + v164.upFactor
					local v176 = v173 - v170
					local v177, v178, v179 = worldToLocal(v164.effectNode, v174, v175, v176)
					local v180 = MathUtil.vector2Length(v177, v179)
					if v180 > 0 then
						v177, v179 = MathUtil.vector2Normalize(v177, v179)
					end
					local v181 = math.max(v178, 0.01)
					local v182 = math.abs(v181)
					local v183 = v180 / v182
					local v184 = math.atan(v183) * (1.2 + 2 * v182)
					local v185 = v180 / v182
					local v186 = math.atan(v185) * (1.2 + 2 * v182)
					local v187 = v179 / v182
					local v188 = math.atan(v187) * v184
					local v189 = v177 / v182
					local v190 = -math.atan(v189) * v186
					v164.xRot = v164.xRot * 0.95 + v188 * 0.05
					v164.zRot = v164.zRot * 0.95 + v190 * 0.05
					local v191 = MathUtil.lerp(v164.minRpmScale, v164.maxRpmScale, v158)
					setShaderParameter(v164.effectNode, "param", v164.xRot, v164.zRot, 0, v191, false)
					local v192 = MathUtil.lerp(v164.minRpmColor[1], v164.maxRpmColor[1], v158)
					local v193 = MathUtil.lerp(v164.minRpmColor[2], v164.maxRpmColor[2], v158)
					local v194 = MathUtil.lerp(v164.minRpmColor[3], v164.maxRpmColor[3], v158)
					local v195 = MathUtil.lerp(v164.minRpmColor[4], v164.maxRpmColor[4], v158)
					setShaderParameter(v164.effectNode, "exhaustColor", v192, v193, v194, v195, false)
					v164.lastPosition[1] = v165
					v164.lastPosition[2] = v166
					v164.lastPosition[3] = v167
				end
			end
			v148.lastFuelUsageDisplayTime = v148.lastFuelUsageDisplayTime + p146
			if v148.lastFuelUsageDisplayTime > 250 then
				v148.lastFuelUsageDisplayTime = 0
				v148.lastFuelUsageDisplay = v148.fuelUsageBuffer:getAverage()
			end
			v148.fuelUsageBuffer:add(v148.lastFuelUsage)
		end
		if v148.clutchCrackingTimeOut < g_time then
			if g_soundManager:getIsSamplePlaying(v148.samples.clutchCracking) then
				g_soundManager:stopSample(v148.samples.clutchCracking)
			end
			if v148.clutchCrackingGearIndex ~= nil then
				p145:setGearLeversState(0, nil, 500)
			end
			if v148.clutchCrackingGroupIndex ~= nil then
				p145:setGearLeversState(nil, 0, 500)
			end
			v148.clutchCrackingTimeOut = (1 / 0)
		end
		if p147 then
			if v149 then
				if not p145:getCanMotorRun() then
					local v196 = p145:getMotorNotAllowedWarning()
					if v196 ~= nil then
						g_currentMission:showBlinkingWarning(v196, 2000)
					end
				end
			elseif g_ignitionLockManager:getIsAvailable() and not p145:getIsAIActive() then
				local v197 = g_ignitionLockManager:getState()
				local v198 = p145:getMotorState()
				if v197 == IgnitionLockState.OFF then
					if v198 ~= MotorState.OFF then
						p145:setMotorState(MotorState.OFF)
					end
				elseif v197 == IgnitionLockState.IGNITION then
					if v198 == MotorState.OFF then
						p145:setMotorState(MotorState.IGNITION)
					end
				elseif v197 == IgnitionLockState.START and (v198 ~= MotorState.STARTING and v198 ~= MotorState.ON) then
					if p145:getCanMotorRun() then
						p145:setMotorState(MotorState.STARTING)
					else
						local v199 = p145:getMotorNotAllowedWarning()
						if v199 ~= nil then
							g_currentMission:showBlinkingWarning(v199, 2000)
						end
					end
				end
			end
			Motorized.updateActionEvents(p145)
		end
	end
end
function Motorized.loadDifferentials(p_u_200, p_u_201, p202)
	local v203, _ = ConfigurationUtil.getXMLConfigurationKey(p_u_201, p202, "vehicle.motorized.differentialConfigurations.differentialConfiguration", "vehicle.motorized.differentials", "differentials")
	local v_u_204 = p_u_200.spec_motorized
	v_u_204.differentials = {}
	if p_u_200.isServer and v_u_204.motorizedNode ~= nil then
		p_u_201:iterate(v203 .. ".differentials.differential", function(_, p205)
			-- upvalues: (copy) p_u_201, (copy) p_u_200, (copy) v_u_204
			local v206 = p_u_201:getValue(p205 .. "#torqueRatio", 0.5)
			local v207 = p_u_201:getValue(p205 .. "#maxSpeedRatio", 1.3)
			local v208 = { -1, -1 }
			local v209 = { false, false }
			for v210 = 1, 2 do
				local v211 = p_u_201:getValue(p205 .. string.format("#wheelIndex%d", v210))
				if v211 == nil then
					local v212 = p_u_201:getValue(p205 .. string.format("#differentialIndex%d", v210))
					if v212 ~= nil then
						v208[v210] = v212 - 1
						v209[v210] = false
						if v212 == 0 then
							Logging.xmlWarning(p_u_200.xmlFile, "Unable to find differentialIndex \'0\' for differential \'%s\' (Indices start at 1)", p205)
						end
					end
				elseif p_u_200:getWheelFromWheelIndex(v211) == nil then
					Logging.xmlWarning(p_u_200.xmlFile, "Unable to find wheelIndex \'%d\' for differential \'%s\' (Indices start at 1)", v211, p205)
				else
					v208[v210] = v211
					v209[v210] = true
				end
			end
			if v208[1] ~= -1 and v208[2] ~= -1 then
				local v213 = v_u_204.differentials
				local v214 = {
					["torqueRatio"] = v206,
					["maxSpeedRatio"] = v207,
					["diffIndex1"] = v208[1],
					["diffIndex1IsWheel"] = v209[1],
					["diffIndex2"] = v208[2],
					["diffIndex2IsWheel"] = v209[2]
				}
				table.insert(v213, v214)
			end
		end)
		if #v_u_204.differentials == 0 then
			Logging.xmlWarning(p_u_200.xmlFile, "No differentials defined")
		end
	end
end
function Motorized.loadMotor(p215, p216, p217)
	local v218, _ = ConfigurationUtil.getXMLConfigurationKey(p216, p217, "vehicle.motorized.motorConfigurations.motorConfiguration", "vehicle.motorized", "motor")
	local v219 = p215.spec_motorized
	v219.motorType = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#type", "vehicle", "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	v219.motorStartAnimation = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#startAnimationName", "vehicle", "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	v219.consumerConfigurationIndex = ConfigurationUtil.getConfigurationValue(p216, v218, "#consumerConfigurationIndex", "", 1, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v220 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#minRpm", 1000, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v221 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#maxRpm", 1800, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v222 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#minSpeed", 1, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v223 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#maxForwardSpeed", nil, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v224 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#maxBackwardSpeed", nil, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	if v223 ~= nil then
		v223 = v223 / 3.6
	end
	if v224 ~= nil then
		v224 = v224 / 3.6
	end
	local v225 = p215.spec_wheels
	if v225 ~= nil and (v225.configItem ~= nil and v225.configItem.maxForwardSpeed ~= nil) then
		v223 = v225.configItem.maxForwardSpeed / 3.6
	end
	local v226 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#accelerationLimit", 2, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v227 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#brakeForce", 10, "vehicle.motorized.motorConfigurations.motorConfiguration(0)") * 2
	local v228 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#lowBrakeForceScale", 0.5, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v229 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#lowBrakeForceSpeedLimit", 1, "vehicle.motorized.motorConfigurations.motorConfiguration(0)") / 3600
	local v230 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#torqueScale", 1, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v231 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#ptoMotorRpmRatio", 4, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
	local v232 = v218 .. ".transmission"
	local v233 = not p216:hasProperty(v232) and "vehicle.motorized.motorConfigurations.motorConfiguration(0).transmission" or v232
	local v234 = p216:getValue(v233 .. "#minForwardGearRatio")
	local v235 = p216:getValue(v233 .. "#maxForwardGearRatio")
	local v236 = p216:getValue(v233 .. "#minBackwardGearRatio")
	local v237 = p216:getValue(v233 .. "#maxBackwardGearRatio")
	local v238 = p216:getValue(v233 .. "#gearChangeTime")
	local v239 = p216:getValue(v233 .. "#autoGearChangeTime")
	local v240 = p216:getValue(v233 .. "#axleRatio", 1)
	local v241 = p216:getValue(v233 .. "#startGearThreshold", VehicleMotor.GEAR_START_THRESHOLD)
	local v242, v243
	if v235 == nil or v234 == nil then
		v242 = nil
		v243 = nil
	else
		v242 = v234 * v240
		v243 = v235 * v240
	end
	local v244, v245
	if v236 == nil or v237 == nil then
		v244 = nil
		v245 = nil
	else
		v245 = v236 * v240
		v244 = v237 * v240
	end
	local v246
	if v242 == nil then
		v246 = p215:loadGears(p216, "forwardGear", v233, v221, v240, 1)
		if v246 == nil then
			printWarning("Warning: Missing forward gear ratios for motor in \'" .. p215.configFileName .. "\'!")
			v246 = {
				{
					["ratio"] = 1,
					["default"] = false
				}
			}
		end
	else
		v246 = nil
	end
	local v247
	if v245 == nil then
		v247 = p215:loadGears(p216, "backwardGear", v233, v221, v240, -1)
	else
		v247 = nil
	end
	local v248 = p215:loadGearGroups(p216, v233 .. ".groups", v221, v240)
	local v249 = p216:getValue(v233 .. ".groups#type", "default")
	local v250 = p216:getValue(v233 .. ".groups#changeTime", 0.5)
	local v251 = p216:getValue(v233 .. ".directionChange#useGear", false)
	local v252 = p216:getValue(v233 .. ".directionChange#reverseGearIndex", 1)
	local v253 = p216:getValue(v233 .. ".directionChange#useGroup", false)
	local v254 = p216:getValue(v233 .. ".directionChange#reverseGroupIndex", 1)
	local v255 = p216:getValue(v233 .. ".directionChange#changeTime", 0.5)
	local v256 = p216:getValue(v233 .. ".manualShift#gears", true)
	local v257 = p216:getValue(v233 .. ".manualShift#groups", true)
	local v258 = AnimCurve.new(linearInterpolator1)
	local v259 = 0
	local v260
	if v218 == nil or not p216:hasProperty(v218 .. ".motor.torque(0)") then
		v260 = "vehicle.motorized.motorConfigurations.motorConfiguration(0).motor.torque"
	else
		v260 = v218 .. ".motor.torque"
	end
	while true do
		local v261 = string.format(v260 .. "(%d)", v259)
		local v262 = p216:getValue(v261 .. "#normRpm")
		local v263
		if v262 == nil then
			v263 = p216:getValue(v261 .. "#rpm")
		else
			v263 = v262 * v221
		end
		local v264 = p216:getValue(v261 .. "#torque")
		if v264 == nil or v263 == nil then
			v219.motor = VehicleMotor.new(p215, v220, v221, v223, v224, v258, v227, v246, v247, v242, v243, v245, v244, v231, v222)
			v219.motor:setGearGroups(v248, v249, v250)
			v219.motor:setDirectionChange(v251, v252, v253, v254, v255)
			v219.motor:setManualShift(v256, v257)
			v219.motor:setStartGearThreshold(v241)
			local v265 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#rotInertia", v219.motor:getRotInertia(), "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
			local v266 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#dampingRateScale", 1, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
			v219.motor:setRotInertia(v265)
			v219.motor:setDampingRateScale(v266)
			v219.motor:setLowBrakeForce(v228, v229)
			v219.motor:setAccelerationLimit(v226)
			local v267 = ConfigurationUtil.getConfigurationValue(p216, v218, ".motor", "#rpmSpeedLimit", nil, "vehicle.motorized.motorConfigurations.motorConfiguration(0)")
			if v267 ~= nil then
				local v268 = v267 * 3.141592653589793 / 30
				v219.motor:setMotorRotationAccelerationLimit(v268)
			end
			if v238 ~= nil then
				v219.motor:setGearChangeTime(v238)
			end
			if v239 ~= nil then
				v219.motor:setAutoGearChangeTime(v239)
			end
			return
		end
		v258:addKeyframe({
			v264 * v230,
			["time"] = v263
		})
		v259 = v259 + 1
	end
end
function Motorized.loadGears(_, p269, p270, p271, p272, p273, p274)
	local v275 = 0
	local v276 = {}
	while true do
		local v277 = string.format(p271 .. ".%s(%d)", p270, v275)
		if not p269:hasProperty(v277) then
			break
		end
		local v278 = p269:getValue(v277 .. "#gearRatio")
		local v279 = p269:getValue(v277 .. "#maxSpeed")
		if v279 ~= nil then
			v278 = p272 * 3.141592653589793 / (v279 / 3.6 * 30)
		end
		if v278 ~= nil then
			local v280 = {
				["ratio"] = v278 * p273,
				["default"] = p269:getValue(v277 .. "#defaultGear", false)
			}
			local v281 = v277 .. "#name"
			local v282 = (v275 + 1) * p274
			v280.name = p269:getValue(v281, (tostring(v282)))
			local v283 = v277 .. "#reverseName"
			local v284 = (v275 + 1) * p274 * -1
			v280.reverseName = p269:getValue(v283, (tostring(v284)))
			v280.dashboardName = p269:getValue(v277 .. "#dashboardName")
			v280.dashboardReverseName = p269:getValue(v277 .. "#dashboardReverseName")
			v280.actionName = p269:getValue(v277 .. "#actionName")
			if (v275 < 8 or v280.actionName ~= nil) and v280.actionName ~= "-" then
				v280.actionName = v280.actionName or string.format("SHIFT_GEAR_SELECT_%d", v275 + 1)
				v280.inputAction = InputAction[v280.actionName]
				if v280.inputAction == nil then
					Logging.xmlWarning(p269, "Invalid actionName \'%s\' found for gear \'%s\'", v280.actionName, v277)
					v280.inputAction = InputAction[string.format("SHIFT_GEAR_SELECT_%d", v275 + 1)]
				end
			end
			table.insert(v276, v280)
		end
		v275 = v275 + 1
	end
	if #v276 > 0 then
		return v276
	else
		return nil
	end
end
function Motorized.loadGearGroups(_, p285, p286, _, _)
	local v287 = 0
	local v288 = {}
	while true do
		local v289 = string.format(p286 .. ".group(%d)", v287)
		if not p285:hasProperty(v289) then
			break
		end
		local v290 = p285:getValue(v289 .. "#ratio")
		if v290 ~= nil then
			local v291 = {
				["ratio"] = 1 / v290,
				["isDefault"] = p285:getValue(v289 .. "#isDefault", false)
			}
			local v292 = v289 .. "#name"
			local v293 = v287 + 1
			v291.name = p285:getValue(v292, (tostring(v293)))
			v291.dashboardName = p285:getValue(v289 .. "#dashboardName")
			v291.actionName = p285:getValue(v289 .. "#actionName")
			if (v287 < 4 or v291.actionName ~= nil) and v291.actionName ~= "-" then
				v291.actionName = v291.actionName or string.format("SHIFT_GROUP_SELECT_%d", v287 + 1)
				v291.inputAction = InputAction[v291.actionName]
				if v291.inputAction == nil then
					Logging.xmlWarning(p285, "Invalid actionName \'%s\' found for gear group \'%s\'", v291.actionName, v289)
					v291.inputAction = InputAction[string.format("SHIFT_GROUP_SELECT_%d", v287 + 1)]
				end
			end
			table.insert(v288, v291)
		end
		v287 = v287 + 1
	end
	if #v288 > 0 then
		return v288
	else
		return nil
	end
end
function Motorized.loadExhaustEffects(p_u_294, p_u_295)
	local v_u_296 = p_u_294.spec_motorized
	local v297 = p_u_295:getValue("vehicle.motorized.exhaustParticleSystems#minScale", 0.5)
	local v298 = p_u_295:getValue("vehicle.motorized.exhaustParticleSystems#maxScale", 1)
	v_u_296.exhaustParticleSystems = {}
	local v299 = 0
	while true do
		local v300 = string.format("vehicle.motorized.exhaustParticleSystems.exhaustParticleSystem(%d)", v299)
		if not p_u_295:hasProperty(v300) then
			break
		end
		local v301 = {}
		ParticleUtil.loadParticleSystem(p_u_295, v301, v300, p_u_294.components, false, nil, p_u_294.baseDirectory)
		v301.minScale = v297
		v301.maxScale = v298
		local v302 = v_u_296.exhaustParticleSystems
		table.insert(v302, v301)
		v299 = v299 + 1
	end
	if #v_u_296.exhaustParticleSystems == 0 then
		v_u_296.exhaustParticleSystems = nil
	end
	XMLUtil.checkDeprecatedXMLElements(p_u_295, "vehicle.motorized.exhaustFlap#index", "vehicle.motorized.exhaustFlap#node")
	v_u_296.exhaustFlaps = {}
	for _, v303 in p_u_294.xmlFile:iterator("vehicle.motorized.exhaustFlap") do
		local v304 = {
			["node"] = p_u_295:getValue(v303 .. "#node", nil, p_u_294.components, p_u_294.i3dMappings)
		}
		if v304.node ~= nil then
			v304.maxRot = p_u_295:getValue(v303 .. "#maxRot", 0)
			v304.rotationAxis = p_u_295:getValue(v303 .. "#rotationAxis", 1)
			local v305 = v_u_296.exhaustFlaps
			table.insert(v305, v304)
		end
	end
	v_u_296.exhaustEffects = {}
	v_u_296.sharedLoadRequestIds = {}
	p_u_295:iterate("vehicle.motorized.exhaustEffects.exhaustEffect", function(_, p306)
		-- upvalues: (copy) p_u_295, (copy) p_u_294, (copy) v_u_296
		XMLUtil.checkDeprecatedXMLElements(p_u_295, p306 .. "#index", p306 .. "#node")
		local v307 = p_u_295:getValue(p306 .. "#node", nil, p_u_294.components, p_u_294.i3dMappings)
		local v308 = p_u_295:getValue(p306 .. "#filename")
		if v308 ~= nil and v307 ~= nil then
			local v309 = Utils.getFilename(v308, p_u_294.baseDirectory)
			local v310 = {
				["xmlFile"] = p_u_295,
				["key"] = p306,
				["linkNode"] = v307,
				["filename"] = v309
			}
			local v311 = p_u_294:loadSubSharedI3DFile(v309, false, false, p_u_294.onExhaustEffectI3DLoaded, p_u_294, v310)
			local v312 = v_u_296.sharedLoadRequestIds
			table.insert(v312, v311)
		end
	end)
	v_u_296.exhaustEffectMaxSteeringSpeed = 0.001
end
function Motorized.onExhaustEffectI3DLoaded(p313, p314, _, p315)
	local v316 = p313.spec_motorized
	if p314 ~= 0 then
		local v317 = getChildAt(p314, 0)
		if getHasShaderParameter(v317, "param") then
			local v318 = p315.xmlFile
			local v319 = p315.key
			local v320 = {
				["effectNode"] = v317,
				["node"] = p315.linkNode,
				["filename"] = p315.filename
			}
			link(v320.node, v320.effectNode)
			setVisibility(v320.effectNode, false)
			delete(p314)
			v320.minRpmColor = v318:getValue(v319 .. "#minRpmColor", "0 0 0 1", true)
			v320.maxRpmColor = v318:getValue(v319 .. "#maxRpmColor", "0.0384 0.0359 0.0627 2.0", true)
			v320.minRpmScale = v318:getValue(v319 .. "#minRpmScale", 0.25)
			v320.maxRpmScale = v318:getValue(v319 .. "#maxRpmScale", 0.95)
			v320.upFactor = v318:getValue(v319 .. "#upFactor", 0.75)
			v320.lastPosition = nil
			v320.xRot = 0
			v320.zRot = 0
			local v321 = v316.exhaustEffects
			table.insert(v321, v320)
		end
	end
end
function Motorized.loadSounds(p322, p323, p324)
	if p322.isClient then
		local v325 = p322.spec_motorized
		v325.samples = v325.samples or {}
		v325.samples.motorStart = g_soundManager:loadSampleFromXML(p323, p324, "motorStart", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.motorStart
		v325.samples.motorStop = g_soundManager:loadSampleFromXML(p323, p324, "motorStop", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.motorStop
		v325.samples.clutchCracking = g_soundManager:loadSampleFromXML(p323, p324, "clutchCracking", p322.baseDirectory, p322.components, 0, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.clutchCracking
		v325.samples.gearEngaged = g_soundManager:loadSampleFromXML(p323, p324, "gearEngaged", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.gearEngaged
		v325.samples.gearDisengaged = g_soundManager:loadSampleFromXML(p323, p324, "gearDisengaged", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.gearDisengaged
		v325.samples.gearGroupChange = g_soundManager:loadSampleFromXML(p323, p324, "gearGroupChange", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.gearGroupChange
		v325.samples.gearLeverStart = g_soundManager:loadSampleFromXML(p323, p324, "gearLeverStart", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.gearLeverStart
		v325.samples.gearLeverEnd = g_soundManager:loadSampleFromXML(p323, p324, "gearLeverEnd", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.gearLeverEnd
		v325.samples.gearGroupLeverStart = g_soundManager:loadSampleFromXML(p323, p324, "gearGroupLeverStart", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.gearGroupLeverStart
		v325.samples.gearGroupLeverEnd = g_soundManager:loadSampleFromXML(p323, p324, "gearGroupLeverEnd", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.gearGroupLeverEnd
		v325.samples.blowOffValve = g_soundManager:loadSampleFromXML(p323, p324, "blowOffValve", p322.baseDirectory, p322.components, 0, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.blowOffValve
		v325.samples.retarder = g_soundManager:loadSampleFromXML(p323, p324, "retarder", p322.baseDirectory, p322.components, 0, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.retarder
		v325.gearboxSamples = g_soundManager:loadSamplesFromXML(p323, p324, "gearbox", p322.baseDirectory, p322.components, 0, AudioGroup.VEHICLE, p322.i3dMappings, p322, v325.gearboxSamples)
		v325.motorSamples = g_soundManager:loadSamplesFromXML(p323, p324, "motor", p322.baseDirectory, p322.components, 0, AudioGroup.VEHICLE, p322.i3dMappings, p322, v325.motorSamples)
		v325.samples.airCompressorStart = g_soundManager:loadSampleFromXML(p323, p324, "airCompressorStart", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.airCompressorStart
		v325.samples.airCompressorStop = g_soundManager:loadSampleFromXML(p323, p324, "airCompressorStop", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.airCompressorStop
		v325.samples.airCompressorRun = g_soundManager:loadSampleFromXML(p323, p324, "airCompressorRun", p322.baseDirectory, p322.components, 0, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.airCompressorRun
		v325.samples.compressedAir = g_soundManager:loadSampleFromXML(p323, p324, "compressedAir", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.compressedAir
		if v325.samples.compressedAir ~= nil then
			v325.samples.compressedAir.brakeTime = 0
			v325.samples.compressedAir.lastBrakeTime = 0
		end
		v325.samples.airRelease = g_soundManager:loadSampleFromXML(p323, p324, "airRelease", p322.baseDirectory, p322.components, 1, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.airRelease
		v325.samples.reverseDrive = g_soundManager:loadSampleFromXML(p323, p324, "reverseDrive", p322.baseDirectory, p322.components, 0, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.reverseDrive
		v325.reverseDriveThreshold = p323:getValue("vehicle.motorized.reverseDriveSound#threshold", 4)
		v325.brakeCompressor = {}
		v325.brakeCompressor.capacity = p323:getValue("vehicle.motorized.brakeCompressor#capacity", 6)
		local v326 = v325.brakeCompressor
		local v327 = v325.brakeCompressor.capacity
		local v328 = v325.brakeCompressor.capacity / 2
		v326.refillFilllevel = math.min(v327, p323:getValue("vehicle.motorized.brakeCompressor#refillFillLevel", v328))
		v325.brakeCompressor.fillSpeed = p323:getValue("vehicle.motorized.brakeCompressor#fillSpeed", 0.6) / 1000
		v325.brakeCompressor.fillLevel = 0
		v325.brakeCompressor.doFill = true
		v325.isBrakeSamplePlaying = false
		v325.samples.brake = g_soundManager:loadSampleFromXML(p323, p324, "brake", p322.baseDirectory, p322.components, 0, AudioGroup.VEHICLE, p322.i3dMappings, p322) or v325.samples.brake
		v325.compressionSoundTime = 0
	end
end
function Motorized.loadConsumerConfiguration(p329, p330, p331)
	local v332 = string.format("vehicle.motorized.consumerConfigurations.consumerConfiguration(%d)", p331 - 1)
	local v333 = p329.spec_motorized
	v333.consumersEmptyWarning = p329.xmlFile:getValue(v332 .. "#consumersEmptyWarning", "warning_motorFuelEmpty", p329.customEnvironment)
	v333.consumers = {}
	v333.consumersByFillTypeName = {}
	v333.consumersByFillType = {}
	if p330:hasProperty(v332) then
		local v334 = 0
		while true do
			local v335 = string.format(".consumer(%d)", v334)
			if not p330:hasProperty(v332 .. v335) then
				break
			end
			local v336 = {
				["fillUnitIndex"] = ConfigurationUtil.getConfigurationValue(p330, v332, v335, "#fillUnitIndex", 1, "vehicle.motorized.consumers")
			}
			local v337 = ConfigurationUtil.getConfigurationValue(p330, v332, v335, "#fillType", "consumer", "vehicle.motorized.consumers")
			v336.fillType = g_fillTypeManager:getFillTypeIndexByName(v337)
			v336.capacity = ConfigurationUtil.getConfigurationValue(p330, v332, v335, "#capacity", nil, "vehicle.motorized.consumers")
			local v338 = p329:getFillUnitByIndex(v336.fillUnitIndex)
			if v338 == nil then
				Logging.xmlWarning(p329.xmlFile, "Unknown fillUnit \'%d\' for consumer \'%s\'", v336.fillUnitIndex, v332 .. v335)
			else
				if v338.supportedFillTypes[v336.fillType] == nil then
					v338.supportedFillTypes = {}
					v338.supportedFillTypes[v336.fillType] = true
				end
				v338.capacity = v336.capacity or v338.capacity
				if (v336.fillType == FillType.DIESEL or (v336.fillType == FillType.ELECTRICCHARGE or v336.fillType == FillType.METHANE)) and v338.exactFillRootNode == nil then
					Logging.xmlWarning(p329.xmlFile, "Missing exactFillRootNode for fuel fill unit (%d).", v336.fillUnitIndex)
				end
				v338.startFillLevel = v338.capacity
				v338.startFillTypeIndex = v336.fillType
				v338.ignoreFillLimit = true
				local v339 = ConfigurationUtil.getConfigurationValue(p330, v332, v335, "#usage", 1, "vehicle.motorized.consumers")
				v336.permanentConsumption = ConfigurationUtil.getConfigurationValue(p330, v332, v335, "#permanentConsumption", true, "vehicle.motorized.consumers")
				if v336.permanentConsumption then
					v336.usage = v339 / 3600000
				else
					v336.usage = v339
				end
				v336.refillLitersPerSecond = ConfigurationUtil.getConfigurationValue(p330, v332, v335, "#refillLitersPerSecond", 0, "vehicle.motorized.consumers")
				v336.refillCapacityPercentage = ConfigurationUtil.getConfigurationValue(p330, v332, v335, "#refillCapacityPercentage", 0, "vehicle.motorized.consumers")
				v336.fillLevelToChange = 0
				local v340 = v333.consumers
				table.insert(v340, v336)
				v333.consumersByFillTypeName[v337:upper()] = v336
				v333.consumersByFillType[v336.fillType] = v336
			end
			v334 = v334 + 1
		end
	end
end
function Motorized.getIsMotorStarted(p341)
	return p341.spec_motorized.motorState == MotorState.ON
end
function Motorized.getIsMotorInNeutral(p342)
	return p342.spec_motorized.motor:getIsInNeutral()
end
function Motorized.getMotorState(p343)
	return p343.spec_motorized.motorState
end
function Motorized.getCanMotorRun(p344)
	local v345 = p344.spec_motorized
	for _, v346 in ipairs(v345.propellantFillUnitIndices) do
		if p344:getFillUnitFillLevel(v346) == 0 then
			return false
		end
	end
	return v345.motor:getCanMotorRun() and true or false
end
function Motorized.getStopMotorOnLeave(p347)
	local v348 = p347.spec_motorized.stopMotorOnLeave
	if v348 then
		v348 = not p347:getRequiresPower()
	end
	return v348
end
function Motorized.getMotorNotAllowedWarning(p349)
	local v350 = p349.spec_motorized
	for _, v351 in pairs(v350.propellantFillUnitIndices) do
		if p349:getFillUnitFillLevel(v351) == 0 then
			return v350.consumersEmptyWarning
		end
	end
	local v352, v353 = v350.motor:getCanMotorRun()
	if v352 or v353 ~= VehicleMotor.REASON_CLUTCH_NOT_ENGAGED then
		return nil
	else
		return v350.clutchNoEngagedWarning
	end
end
function Motorized.setMotorState(p354, p355, p356)
	local v357 = p354.spec_motorized
	if v357.motorState ~= p355 then
		MotorStateEvent.sendEvent(p354, p355, p356)
		local v358 = v357.motorState
		v357.motorState = p355
		local v359 = false
		local v360 = false
		if v358 == MotorState.OFF or v358 == MotorState.IGNITION then
			if p355 == MotorState.STARTING or p355 == MotorState.ON then
				v359 = true
			end
		elseif v358 == MotorState.STARTING or v358 == MotorState.ON then
			if p355 == MotorState.OFF or p355 == MotorState.IGNITION then
				v360 = true
			end
		end
		if v359 then
			if p354.isClient then
				if v357.exhaustParticleSystems ~= nil then
					for _, v361 in pairs(v357.exhaustParticleSystems) do
						ParticleUtil.setEmittingState(v361, true)
					end
				end
				if v357.exhaustEffects ~= nil then
					for _, v362 in pairs(v357.exhaustEffects) do
						setVisibility(v362.effectNode, true)
						setShaderParameter(v362.effectNode, "param", v362.xRot, v362.zRot, 0, 0, false)
						local v363 = v362.minRpmColor
						setShaderParameter(v362.effectNode, "exhaustColor", v363[1], v363[2], v363[3], v363[4], false)
					end
				end
				if v357.samples == nil then
					Logging.error("Motor samples not found (%s, %d)", p354.configFileName, p354.loadingState)
					printCallstack()
				end
				g_soundManager:stopSample(v357.samples.motorStop)
				g_soundManager:playSample(v357.samples.motorStart)
				g_soundManager:playSamples(v357.motorSamples, 0, v357.samples.motorStart)
				g_soundManager:playSamples(v357.gearboxSamples, 0, v357.samples.motorStart)
				g_soundManager:playSample(v357.samples.retarder, 0, v357.samples.motorStart)
				g_animationManager:startAnimations(v357.animationNodes)
				if v357.motorStartAnimation ~= nil then
					p354:playAnimation(v357.motorStartAnimation, 1, nil, true)
				end
			end
			v357.motorStartTime = g_currentMission.time + v357.motorStartDuration
			v357.motorNotRequiredTimer = 0
			v357.compressionSoundTime = g_currentMission.time + math.random(5000, 20000)
			v357.motor.lastMotorRpm = 0
			SpecializationUtil.raiseEvent(p354, "onStartMotor")
			p354.rootVehicle:raiseStateChange(VehicleStateChange.MOTOR_TURN_ON)
		elseif v360 then
			if p354.isClient then
				if v357.exhaustParticleSystems ~= nil then
					for _, v364 in pairs(v357.exhaustParticleSystems) do
						ParticleUtil.setEmittingState(v364, false)
					end
				end
				if v357.exhaustEffects ~= nil then
					for _, v365 in pairs(v357.exhaustEffects) do
						setVisibility(v365.effectNode, false)
					end
				end
				for _, v366 in ipairs(v357.exhaustFlaps) do
					setRotation(v366.node, 0, 0, 0)
				end
				g_soundManager:stopSamples(v357.samples)
				g_soundManager:playSample(v357.samples.motorStop)
				g_soundManager:stopSamples(v357.motorSamples)
				g_soundManager:stopSamples(v357.gearboxSamples)
				v357.isBrakeSamplePlaying = false
				g_animationManager:stopAnimations(v357.animationNodes)
				if v357.motorStartAnimation ~= nil then
					p354:playAnimation(v357.motorStartAnimation, -1, nil, true)
				end
			end
			SpecializationUtil.raiseEvent(p354, "onStopMotor")
			p354.rootVehicle:raiseStateChange(VehicleStateChange.MOTOR_TURN_OFF)
		end
	end
	if p355 == MotorState.ON or p355 == MotorState.STARTING then
		if p354.isServer then
			p354:wakeUp()
		end
	else
		v357.motor.lastMotorRpm = 0
	end
	if p354.setDashboardsDirty ~= nil then
		p354:setDashboardsDirty()
	end
end
function Motorized.startMotor(p367, p368)
	local v369 = p367:getMotorState()
	if v369 == MotorState.OFF or v369 == MotorState.IGNITION then
		MotorSetTurnedOnEvent.sendEvent(p367, true, p368)
		p367:setMotorState(MotorState.STARTING, true)
	end
end
function Motorized.stopMotor(p370, p371)
	local v372 = p370:getMotorState()
	if v372 == MotorState.ON or v372 == MotorState.STARTING then
		MotorSetTurnedOnEvent.sendEvent(p370, false, p371)
		p370:setMotorState(MotorState.OFF, true)
	end
end
function Motorized.updateConsumers(p373, p374, p375)
	local v376 = p373.spec_motorized
	local v377 = (v376.motor.lastMotorRpm - v376.motor.minRpm) / (v376.motor.maxRpm - v376.motor.minRpm)
	local v378 = 0.5 + v377 * 0.5
	local v379 = v376.smoothedLoadPercentage * v377
	local v380 = math.max(v379, 0)
	local v381 = 0.5 * (0.2 * v378 + 1.8 * v380)
	local v382 = g_currentMission.missionInfo
	local v383 = v382.fuelUsage
	local v384 = v383 == 1 and 1 or (v383 == 3 and 2.5 or 1.5)
	local v385 = p373:getVehicleDamage()
	if v385 > 0 then
		v384 = v384 * (1 + v385 * Motorized.DAMAGED_USAGE_INCREASE)
	end
	for _, v386 in pairs(v376.consumers) do
		if v386.permanentConsumption and v386.usage > 0 then
			local v387 = v384 * v381 * v386.usage * p374
			if v387 ~= 0 then
				v386.fillLevelToChange = v386.fillLevelToChange + v387
				local v388 = v386.fillLevelToChange
				if math.abs(v388) > 1 then
					v387 = v386.fillLevelToChange
					v386.fillLevelToChange = 0
					local v389 = p373:getFillUnitLastValidFillType(v386.fillUnitIndex)
					g_farmManager:updateFarmStats(p373:getOwnerFarmId(), "fuelUsage", v387)
					if p373:getIsAIActive() and (v389 == FillType.DIESEL or v389 == FillType.DEF) and v382.helperBuyFuel then
						if v389 == FillType.DIESEL then
							local v390 = v387 * g_currentMission.economyManager:getCostPerLiter(v389) * 1.5
							g_farmManager:updateFarmStats(p373:getOwnerFarmId(), "expenses", v390)
							g_currentMission:addMoney(-v390, p373:getOwnerFarmId(), MoneyType.PURCHASE_FUEL, true)
							v387 = 0
						else
							v387 = 0
						end
					end
					if v389 == v386.fillType then
						p373:addFillUnitFillLevel(p373:getOwnerFarmId(), v386.fillUnitIndex, -v387, v389, ToolType.UNDEFINED)
					end
				end
				if v386.fillType == FillType.DIESEL or (v386.fillType == FillType.ELECTRICCHARGE or v386.fillType == FillType.METHANE) then
					v376.lastFuelUsage = v387 / p374 * 1000 * 60 * 60
				elseif v386.fillType == FillType.DEF then
					v376.lastDefUsage = v387 / p374 * 1000 * 60 * 60
				end
			end
		end
	end
	if v376.consumersByFillTypeName.AIR ~= nil then
		local v391 = v376.consumersByFillTypeName.AIR
		if p373:getFillUnitLastValidFillType(v391.fillUnitIndex) == v391.fillType then
			local v392 = 0
			local v393 = p373.movingDirection * p373:getReverserDirection()
			local v394
			if v393 > 0 then
				v394 = p375 < 0
			else
				v394 = false
			end
			local v395
			if v393 < 0 then
				v395 = p375 > 0
			else
				v395 = false
			end
			local v396
			if p373:getLastSpeed() > 1 then
				v396 = v394 or v395
			else
				v396 = false
			end
			if v396 then
				local v397 = math.abs(p375) * p374 * p373:getAirConsumerUsage() / 1000
				p373:addFillUnitFillLevel(p373:getOwnerFarmId(), v391.fillUnitIndex, -v397, v391.fillType, ToolType.UNDEFINED)
				v392 = v397 / p374 * 1000
			end
			local v398 = p373:getFillUnitFillLevelPercentage(v391.fillUnitIndex)
			if v398 < v391.refillCapacityPercentage then
				v391.doRefill = true
			elseif v398 == 1 then
				v391.doRefill = false
			end
			if v391.doRefill then
				local v399 = v391.refillLitersPerSecond / 1000 * p374
				p373:addFillUnitFillLevel(p373:getOwnerFarmId(), v391.fillUnitIndex, v399, v391.fillType, ToolType.UNDEFINED)
				v392 = -v399 / p374 * 1000
			end
			v376.lastAirUsage = v392
		end
	end
end
function Motorized.updateMotorTemperature(p400, p401)
	local v402 = p400.spec_motorized
	local v403 = v402.motorTemperature.heatingPerMS * p401 * ((1 + 4 * v402.actualLoadPercentage) / 5 + p400:getMotorRpmPercentage())
	local v404 = v402.motorTemperature
	local v405 = v402.motorTemperature.valueMax
	local v406 = v402.motorTemperature.value + v403
	v404.value = math.min(v405, v406)
	local v407 = v402.motorTemperature.coolingByWindPerMS * p401
	local v408 = p400:getLastSpeed() / 30
	local v409 = math.min(1, v408)
	local v410 = math.pow(v409, 2)
	local v411 = v402.motorTemperature
	local v412 = v402.motorTemperature.valueMin
	local v413 = v402.motorTemperature.value - v410 * v407
	v411.value = math.max(v412, v413)
	if v402.motorTemperature.value > v402.motorFan.enableTemperature then
		v402.motorFan.enabled = true
	end
	if v402.motorFan.enabled and v402.motorTemperature.value < v402.motorFan.disableTemperature then
		v402.motorFan.enabled = false
	end
	if v402.motorFan.enabled then
		local v414 = v402.motorFan.coolingPerMS * p401
		local v415 = v402.motorTemperature
		local v416 = v402.motorTemperature.valueMin
		local v417 = v402.motorTemperature.value - v414
		v415.value = math.max(v416, v417)
	end
end
function Motorized.onGearDirectionChanged(p418, _)
	if p418.isServer then
		p418:raiseDirtyFlags(p418.spec_motorized.dirtyFlag)
	end
end
function Motorized.onGearChanged(p419, p420, p421, p422)
	p419:setGearLeversState(p421, nil, p422)
	local v423 = p419.spec_motorized
	if p419.isClient then
		if p420 == 0 then
			if not g_soundManager:getIsSamplePlaying(v423.samples.gearDisengaged) then
				g_soundManager:playSample(v423.samples.gearDisengaged)
			end
		elseif not g_soundManager:getIsSamplePlaying(v423.samples.gearEngaged) then
			g_soundManager:playSample(v423.samples.gearEngaged)
		end
	end
	if p419.isServer then
		p419:raiseDirtyFlags(v423.dirtyFlag)
	end
end
function Motorized.onGearGroupChanged(p424, p425, p426)
	p424:setGearLeversState(nil, p425, p426)
	local v427 = p424.spec_motorized
	if p424.isClient and not g_soundManager:getIsSamplePlaying(v427.samples.gearGroupChange) then
		g_soundManager:playSample(v427.samples.gearGroupChange)
	end
	if p424.isServer then
		p424:raiseDirtyFlags(v427.dirtyFlag)
	end
end
function Motorized.onClutchCreaking(p428, p429, p430, p431, p432)
	local v433 = p428.spec_motorized
	if p430 then
		g_currentMission:showBlinkingWarning(v433.clutchCrackingGroupWarning, 2000)
	else
		g_currentMission:showBlinkingWarning(v433.clutchCrackingGearWarning, 2000)
	end
	if not g_soundManager:getIsSamplePlaying(v433.samples.clutchCracking) then
		g_soundManager:playSample(v433.samples.clutchCracking)
	end
	if p431 ~= nil then
		p428:setGearLeversState(p431, nil, 500, false)
		v433.clutchCrackingGearIndex = p431
	end
	if p432 ~= nil then
		p428:setGearLeversState(nil, p432, 500, false)
		v433.clutchCrackingGroupIndex = p432
	end
	v433.clutchCrackingTimeOut = g_time + (p429 and 750 or 100)
end
function Motorized.onReverseDirectionChanged(p434)
	if p434:getDirectionChangeMode() == VehicleMotor.DIRECTION_CHANGE_MODE_MANUAL then
		MotorGearShiftEvent.sendToServer(p434, MotorGearShiftEvent.TYPE_DIRECTION_CHANGE)
	end
end
function Motorized.onVehicleSettingChanged(p435, p436, p437)
	local v438 = p435.spec_motorized
	local v439 = v438.motor
	if p436 == GameSettings.SETTING.DIRECTION_CHANGE_MODE then
		v438.directionChangeMode = p437
		if v439 ~= nil then
			v439:setDirectionChangeMode(p437)
			p435:requestActionEventUpdate()
		end
	end
	if p436 == GameSettings.SETTING.GEAR_SHIFT_MODE then
		v438.gearShiftMode = p437
		if not p435:getIsAIActive() and v439 ~= nil then
			v439:setGearShiftMode(p437)
			p435:requestActionEventUpdate()
		end
	end
end
function Motorized.onAIJobStarted(p440, _)
	local v441 = p440.spec_motorized
	p440:startMotor(true)
	if v441.motor ~= nil then
		v441.motor:setGearShiftMode(VehicleMotor.SHIFT_MODE_AUTOMATIC)
	end
end
function Motorized.onAIJobFinished(p442, _)
	if p442.getIsControlled == nil or not p442:getIsControlled() then
		p442:stopMotor(true)
	end
	local v443 = p442.spec_motorized
	if v443.motor ~= nil then
		v443.motor:setGearShiftMode(v443.gearShiftMode)
	end
end
function Motorized.getMotor(p444)
	return p444.spec_motorized.motor
end
function Motorized.getMotorStartTime(p445)
	return p445.spec_motorized.motorStartTime
end
function Motorized.getMotorType(p446)
	return p446.spec_motorized.motorType
end
function Motorized.getMotorRpmPercentage(p447)
	local v448 = p447.spec_motorized.motor
	return (v448:getLastModulatedMotorRpm() - v448:getMinRpm()) / (v448:getMaxRpm() - v448:getMinRpm())
end
g_soundManager:registerModifierType("MOTOR_RPM", Motorized.getMotorRpmPercentage)
function Motorized.getMotorRpmReal(p449)
	return p449.spec_motorized.motor:getLastModulatedMotorRpm()
end
g_soundManager:registerModifierType("MOTOR_RPM_REAL", Motorized.getMotorRpmReal)
function Motorized.getMotorLoadPercentage(p450)
	return p450.spec_motorized.smoothedLoadPercentage
end
g_soundManager:registerModifierType("MOTOR_LOAD", Motorized.getMotorLoadPercentage)
function Motorized.getMotorBrakeTime(p451)
	local v452 = p451.spec_motorized.samples.compressedAir
	return v452 == nil and 0 or v452.lastBrakeTime / 1000
end
g_soundManager:registerModifierType("BRAKE_TIME", Motorized.getMotorBrakeTime)
function Motorized.getMotorBlowOffValveState(p453)
	return p453.spec_motorized.motor.blowOffValveState
end
g_soundManager:registerModifierType("BLOW_OFF_VALVE_STATE", Motorized.getMotorBlowOffValveState)
function Motorized.getMotorDifferentialSpeed(p454)
	if p454.spec_motorized == nil then
		Logging.error("Sound modifier \'DIFFERENTIAL_SPEED\' used on non motorized vehicle \'%s\'", p454.configFileName)
		return 0
	else
		local v455 = p454.spec_motorized.motor.differentialRotSpeed * 3.6
		return math.abs(v455)
	end
end
g_soundManager:registerModifierType("DIFFERENTIAL_SPEED", Motorized.getMotorDifferentialSpeed)
function Motorized.getConsumerFillUnitIndex(p456, p457)
	local v458 = p456.spec_motorized.consumersByFillType[p457]
	if v458 == nil then
		return nil
	else
		return v458.fillUnitIndex
	end
end
function Motorized.getAirConsumerUsage(p459)
	local v460 = p459.spec_motorized.consumersByFillTypeName.AIR
	return v460 and v460.usage or 0
end
function Motorized.getBrakeForce(p461, p462)
	local v463 = p462(p461)
	local v464 = p461.spec_motorized.motor
	return math.max(v463, v464:getBrakeForce())
end
function Motorized.loadDashboardGroupFromXML(p465, p466, p467, p468, p469)
	if not p466(p465, p467, p468, p469) then
		return false
	end
	p469.isMotorStarting = p467:getValue(p468 .. "#isMotorStarting")
	p469.isMotorRunning = p467:getValue(p468 .. "#isMotorRunning")
	return true
end
function Motorized.getIsDashboardGroupActive(p470, p471, p472)
	local v473 = p470:getMotorState()
	if p472.isMotorRunning and (p472.isMotorStarting and (v473 ~= MotorState.STARTING and v473 ~= MotorState.ON)) then
		return false
	elseif p472.isMotorStarting and (not p472.isMotorRunning and v473 ~= MotorState.STARTING) then
		return false
	elseif p472.isMotorRunning and (not p472.isMotorStarting and v473 ~= MotorState.ON) then
		return false
	else
		return p471(p470, p472)
	end
end
function Motorized.getIsActiveForInteriorLights(p474, p475)
	local v476 = p474:getMotorState()
	return (v476 == MotorState.IGNITION or (v476 == MotorState.STARTING or v476 == MotorState.ON)) and true or p475(p474)
end
function Motorized.getIsActiveForWipers(p477, p478)
	if p477:getMotorState() == MotorState.OFF then
		return false
	else
		return p478(p477)
	end
end
function Motorized.getUsageCausesDamage(p479, p480)
	local v481 = p479:getMotorState()
	if v481 == MotorState.STARTING or v481 == MotorState.ON then
		return p480(p479)
	else
		return false
	end
end
function Motorized.addToPhysics(p482, p483)
	if not p483(p482) then
		return false
	end
	if p482.isServer then
		local v484 = p482.spec_motorized
		if v484.motorizedNode ~= nil and next(v484.differentials) ~= nil then
			for _, v485 in pairs(v484.differentials) do
				local v486 = v485.diffIndex1
				local v487 = v485.diffIndex2
				if v485.diffIndex1IsWheel then
					v486 = p482:getWheelFromWheelIndex(v486).physics.wheelShape
				end
				if v485.diffIndex2IsWheel then
					v487 = p482:getWheelFromWheelIndex(v487).physics.wheelShape
				end
				addDifferential(v484.motorizedNode, v486, v485.diffIndex1IsWheel, v487, v485.diffIndex2IsWheel, v485.torqueRatio, v485.maxSpeedRatio)
			end
			p482:updateMotorProperties()
			p482:controlVehicle(0, 0, 0, 0, (1 / 0), 0, 0, 0, 0, 0)
		end
	end
	return true
end
function Motorized.removeFromPhysics(p488, p489)
	if p488.isServer then
		local v490 = p488.spec_motorized
		if v490.motorizedNode ~= nil and next(v490.differentials) ~= nil then
			removeAllDifferentials(v490.motorizedNode)
		end
	end
	return p489(p488) and true or false
end
function Motorized.updateMotorProperties(p491)
	local v492 = p491.spec_motorized
	local v493 = v492.motor
	local v494, v495 = v493:getTorqueAndSpeedValues()
	setMotorProperties(v492.motorizedNode, v493:getMinRpm() * 3.141592653589793 / 30, v493:getMaxRpm() * 3.141592653589793 / 30, v493:getRotInertia(), v493:getDampingRateFullThrottle(), v493:getDampingRateZeroThrottleClutchEngaged(), v493:getDampingRateZeroThrottleClutchDisengaged(), v495, v494)
end
function Motorized.controlVehicle(p496, p497, p498, p499, p500, p501, p502, p503, p504, p505, p506)
	local v507 = p496.spec_motorized
	controlVehicle(v507.motorizedNode, p497, p498, p499, p500, p501, p502, p503, p504, p505, p506)
	local v508 = v507.lastControlParameters
	if getIsSleeping(v507.motorizedNode) and (p497 ~= v508.acceleratorPedal or (p498 ~= v508.maxSpeed or (p499 ~= v508.maxAcceleration or (p500 ~= v508.minMotorRotSpeed or (p501 ~= v508.maxMotorRotSpeed or (p502 ~= v508.maxMotorRotAcceleration or (p503 ~= v508.minGearRatio or (p504 ~= v508.maxGearRatio or (p505 ~= v508.maxClutchTorque or p506 ~= v508.neededPtoTorque))))))))) then
		I3DUtil.wakeUpObject(v507.motorizedNode)
	end
	v508.acceleratorPedal = p497
	v508.maxSpeed = p498
	v508.maxAcceleration = p499
	v508.minMotorRotSpeed = p500
	v508.maxMotorRotSpeed = p501
	v508.maxMotorRotAcceleration = p502
	v508.minGearRatio = p503
	v508.maxGearRatio = p504
	v508.maxClutchTorque = p505
	v508.neededPtoTorque = p506
end
function Motorized.getIsOperating(p509, p510)
	local v511 = p509:getMotorState()
	return p510(p509) or v511 == MotorState.ON
end
function Motorized.getDeactivateOnLeave(p512, p513)
	local v514 = g_currentMission.missionInfo
	local v515 = p513(p512)
	if v515 then
		v515 = v514.automaticMotorStartEnabled
	end
	return v515
end
function Motorized.getDeactivateLightsOnLeave(p516, p517)
	local v518 = g_currentMission.missionInfo
	local v519 = p517(p516) and v518.automaticMotorStartEnabled
	if v519 then
		v519 = not p516:getRequiresPower()
	end
	return v519
end
function Motorized.onRegisterActionEvents(p520, _, p521)
	if p520.isClient then
		local v522 = p520.spec_motorized
		p520:clearActionEventsTable(v522.actionEvents)
		if p521 then
			local _, v523 = p520:addActionEvent(v522.actionEvents, InputAction.TOGGLE_MOTOR_STATE, p520, Motorized.actionEventToggleMotorState, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v523, GS_PRIO_VERY_HIGH)
			g_inputBinding:setActionEventText(v523, v522.turnOnText)
			local _, v524 = p520:addActionEvent(v522.actionEvents, InputAction.MOTOR_STATE_IGNITION, p520, Motorized.actionEventSetMotorStateIgnition, false, true, false, true, nil)
			g_inputBinding:setActionEventTextVisibility(v524, false)
			local _, v525 = p520:addActionEvent(v522.actionEvents, InputAction.MOTOR_STATE_ON, p520, Motorized.actionEventSetMotorStateOn, false, true, false, true, nil)
			g_inputBinding:setActionEventTextVisibility(v525, false)
			local _, v526 = p520:addActionEvent(v522.actionEvents, InputAction.MOTOR_STATE_OFF, p520, Motorized.actionEventSetMotorStateOff, false, true, false, true, nil)
			g_inputBinding:setActionEventTextVisibility(v526, false)
			if (v522.motor.minForwardGearRatio == nil or v522.motor.minBackwardGearRatio == nil) and (p520:getGearShiftMode() ~= VehicleMotor.SHIFT_MODE_AUTOMATIC or not GS_IS_CONSOLE_VERSION) then
				if v522.motor.manualShiftGears then
					local _, v527 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_UP, p520, Motorized.actionEventShiftGear, false, true, false, true, nil)
					g_inputBinding:setActionEventTextVisibility(v527, false)
					local _, v528 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_DOWN, p520, Motorized.actionEventShiftGear, false, true, false, true, nil)
					g_inputBinding:setActionEventTextVisibility(v528, false)
					local _, v529 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_SELECT_1, p520, Motorized.actionEventSelectGear, true, true, false, true, 1)
					g_inputBinding:setActionEventTextVisibility(v529, false)
					local _, v530 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_SELECT_2, p520, Motorized.actionEventSelectGear, true, true, false, true, 2)
					g_inputBinding:setActionEventTextVisibility(v530, false)
					local _, v531 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_SELECT_3, p520, Motorized.actionEventSelectGear, true, true, false, true, 3)
					g_inputBinding:setActionEventTextVisibility(v531, false)
					local _, v532 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_SELECT_4, p520, Motorized.actionEventSelectGear, true, true, false, true, 4)
					g_inputBinding:setActionEventTextVisibility(v532, false)
					local _, v533 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_SELECT_5, p520, Motorized.actionEventSelectGear, true, true, false, true, 5)
					g_inputBinding:setActionEventTextVisibility(v533, false)
					local _, v534 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_SELECT_6, p520, Motorized.actionEventSelectGear, true, true, false, true, 6)
					g_inputBinding:setActionEventTextVisibility(v534, false)
					local _, v535 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_SELECT_7, p520, Motorized.actionEventSelectGear, true, true, false, true, 7)
					g_inputBinding:setActionEventTextVisibility(v535, false)
					local _, v536 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GEAR_SELECT_8, p520, Motorized.actionEventSelectGear, true, true, false, true, 8)
					g_inputBinding:setActionEventTextVisibility(v536, false)
				end
				if v522.motor.manualShiftGroups and v522.motor.gearGroups ~= nil then
					local _, v537 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GROUP_UP, p520, Motorized.actionEventShiftGroup, false, true, false, true, nil)
					g_inputBinding:setActionEventTextVisibility(v537, false)
					local _, v538 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GROUP_DOWN, p520, Motorized.actionEventShiftGroup, false, true, false, true, nil)
					g_inputBinding:setActionEventTextVisibility(v538, false)
					local _, v539 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GROUP_SELECT_1, p520, Motorized.actionEventSelectGroup, true, true, false, true, 1)
					g_inputBinding:setActionEventTextVisibility(v539, false)
					local _, v540 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GROUP_SELECT_2, p520, Motorized.actionEventSelectGroup, true, true, false, true, 2)
					g_inputBinding:setActionEventTextVisibility(v540, false)
					local _, v541 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GROUP_SELECT_3, p520, Motorized.actionEventSelectGroup, true, true, false, true, 3)
					g_inputBinding:setActionEventTextVisibility(v541, false)
					local _, v542 = p520:addActionEvent(v522.actionEvents, InputAction.SHIFT_GROUP_SELECT_4, p520, Motorized.actionEventSelectGroup, true, true, false, true, 4)
					g_inputBinding:setActionEventTextVisibility(v542, false)
				end
				local _, v543 = p520:addActionEvent(v522.actionEvents, InputAction.AXIS_CLUTCH_VEHICLE, p520, Motorized.actionEventClutch, false, false, true, true, nil)
				g_inputBinding:setActionEventTextVisibility(v543, false)
			end
			if p520:getDirectionChangeMode() == VehicleMotor.DIRECTION_CHANGE_MODE_MANUAL or p520:getGearShiftMode() ~= VehicleMotor.SHIFT_MODE_AUTOMATIC then
				local _, v544 = p520:addActionEvent(v522.actionEvents, InputAction.DIRECTION_CHANGE, p520, Motorized.actionEventDirectionChange, false, true, false, true, nil, nil, true)
				g_inputBinding:setActionEventTextVisibility(v544, false)
				local _, v545 = p520:addActionEvent(v522.actionEvents, InputAction.DIRECTION_CHANGE_POS, p520, Motorized.actionEventDirectionChange, false, true, false, true, nil, nil, true)
				g_inputBinding:setActionEventTextVisibility(v545, false)
				local _, v546 = p520:addActionEvent(v522.actionEvents, InputAction.DIRECTION_CHANGE_NEG, p520, Motorized.actionEventDirectionChange, false, true, false, true, nil, nil, true)
				g_inputBinding:setActionEventTextVisibility(v546, false)
			end
			Motorized.updateActionEvents(p520)
		end
	end
end
function Motorized.actionEventShiftGear(p547, p548, _, _, _)
	if p548 == InputAction.SHIFT_GEAR_UP then
		MotorGearShiftEvent.sendToServer(p547, MotorGearShiftEvent.TYPE_SHIFT_UP)
	else
		MotorGearShiftEvent.sendToServer(p547, MotorGearShiftEvent.TYPE_SHIFT_DOWN)
	end
end
function Motorized.actionEventSelectGear(p549, p550, p551, p552, _)
	local v553 = p549.spec_motorized.motor.currentGears
	if v553 ~= nil then
		for v554 = 1, #v553 do
			if v553[v554].inputAction == InputAction[p550] then
				MotorGearShiftEvent.sendToServer(p549, MotorGearShiftEvent.TYPE_SELECT_GEAR, p551 == 1 and v554 and v554 or 0)
				return
			end
		end
	end
	return MotorGearShiftEvent.sendToServer(p549, MotorGearShiftEvent.TYPE_SELECT_GEAR, p551 == 1 and p552 and p552 or 0)
end
function Motorized.actionEventShiftGroup(p555, p556, _, _, _)
	if p556 == InputAction.SHIFT_GROUP_UP then
		MotorGearShiftEvent.sendToServer(p555, MotorGearShiftEvent.TYPE_SHIFT_GROUP_UP)
	else
		MotorGearShiftEvent.sendToServer(p555, MotorGearShiftEvent.TYPE_SHIFT_GROUP_DOWN)
	end
end
function Motorized.actionEventSelectGroup(p557, p558, p559, p560, _)
	local v561 = p557.spec_motorized.motor.gearGroups
	if v561 ~= nil then
		for v562 = 1, #v561 do
			if v561[v562].inputAction == InputAction[p558] then
				MotorGearShiftEvent.sendToServer(p557, MotorGearShiftEvent.TYPE_SELECT_GROUP, p559 == 1 and v562 and v562 or 0)
				return
			end
		end
	end
	return MotorGearShiftEvent.sendToServer(p557, MotorGearShiftEvent.TYPE_SELECT_GROUP, p559 == 1 and p560 and p560 or 0)
end
function Motorized.actionEventDirectionChange(p563, p564, _, _, _)
	if p564 == InputAction.DIRECTION_CHANGE_POS then
		MotorGearShiftEvent.sendToServer(p563, MotorGearShiftEvent.TYPE_DIRECTION_CHANGE_POS)
		return
	elseif p564 == InputAction.DIRECTION_CHANGE_NEG then
		MotorGearShiftEvent.sendToServer(p563, MotorGearShiftEvent.TYPE_DIRECTION_CHANGE_NEG)
	else
		MotorGearShiftEvent.sendToServer(p563, MotorGearShiftEvent.TYPE_DIRECTION_CHANGE)
	end
end
function Motorized.actionEventClutch(p565, _, p566, _, _)
	local v567 = p565.spec_motorized
	v567.clutchState = p566
	if p565.isServer then
		v567.motor:onManualClutchChanged(v567.clutchState)
		if p566 > 0 then
			p565:raiseActive()
			return
		end
	else
		p565:raiseDirtyFlags(v567.inputDirtyFlag)
	end
end
function Motorized.updateActionEvents(p568)
	local v569 = g_currentMission.missionInfo.automaticMotorStartEnabled
	local v570 = p568.spec_motorized
	local v571 = v570.actionEvents[InputAction.TOGGLE_MOTOR_STATE]
	if v571 ~= nil then
		if v569 then
			g_inputBinding:setActionEventActive(v571.actionEventId, false)
		else
			g_inputBinding:setActionEventActive(v571.actionEventId, true)
			local v572 = p568:getMotorState()
			local v573
			if v572 == MotorState.STARTING or v572 == MotorState.ON then
				g_inputBinding:setActionEventTextPriority(v571.actionEventId, GS_PRIO_VERY_LOW)
				v573 = v570.turnOffText
			else
				g_inputBinding:setActionEventTextPriority(v571.actionEventId, GS_PRIO_VERY_HIGH)
				v573 = v570.turnOnText
			end
			g_inputBinding:setActionEventText(v571.actionEventId, v573)
		end
	end
	local v574 = v570.actionEvents[InputAction.MOTOR_STATE_IGNITION]
	if v574 ~= nil then
		g_inputBinding:setActionEventActive(v574.actionEventId, not v569)
	end
	local v575 = v570.actionEvents[InputAction.MOTOR_STATE_ON]
	if v575 ~= nil then
		g_inputBinding:setActionEventActive(v575.actionEventId, not v569)
	end
	local v576 = v570.actionEvents[InputAction.MOTOR_STATE_OFF]
	if v576 ~= nil then
		g_inputBinding:setActionEventActive(v576.actionEventId, not v569)
	end
end
function Motorized.getTraveledDistanceStatsActive(_)
	return true
end
function Motorized.setGearLeversState(p577, p578, p579, p580, p581)
	local v582 = p577.spec_motorized
	for v583 = 1, #v582.gearLevers do
		local v584 = v582.gearLevers[v583]
		for v585 = 1, #v584.states do
			local v586 = v584.states[v585]
			if v586.gear ~= nil and v586.gear == p578 or v586.group ~= nil and v586.group == p579 then
				p577:generateShiftAnimation(v584, v586, p580, p581)
			end
		end
	end
end
function Motorized.generateShiftAnimation(p587, p588, p589, _, p590)
	local v591 = p589.curRotation
	local v592 = p589.curRotation
	local v593 = p589.curRotation
	local v594, v595, v596 = getRotation(p588.node)
	v591[1] = v594
	v592[2] = v595
	v593[3] = v596
	local v597 = false
	local v598 = {
		["interpolations"] = {}
	}
	for v599 = 1, 3 do
		local v600 = p589.curRotation[v599] - p589.rotation[v599]
		if math.abs(v600) > 0.00001 then
			v597 = true
			break
		end
	end
	local v601 = true
	for v602 = 1, 3 do
		local v603 = p588.curTarget[v602] - p589.rotation[v602]
		if math.abs(v603) > 0.00001 then
			v601 = false
			break
		end
	end
	if not v597 or v601 then
		return false
	end
	local v604 = p588.curTarget
	local v605 = p588.curTarget
	local v606 = p588.curTarget
	local v607 = p589.curRotation[1]
	local v608 = p589.curRotation[2]
	local v609 = p589.curRotation[3]
	v604[1] = v607
	v605[2] = v608
	v606[3] = v609
	local v610
	if p588.centerAxis == nil then
		v610 = false
	else
		local v611 = p589.curRotation[p588.centerAxis] - p589.rotation[p588.centerAxis]
		v610 = math.abs(v611) > 0.00001
	end
	if v610 then
		for v612 = 1, 3 do
			if v612 ~= p588.centerAxis then
				local v613 = p589.curRotation[v612]
				local v614 = p589.rotation[v612]
				local v615 = p588.centerAxis ~= nil and 0 or v614
				local v616 = v613 - v615
				local v617 = math.abs(v616) > 0.00001
				local v618
				if p588.centerAxis == nil or v617 then
					v618 = false
				else
					v617 = p589.useRotation[v612]
					if v617 then
						local v619 = p589.curRotation[p588.centerAxis] - p589.rotation[p588.centerAxis]
						v617 = math.abs(v619) > 0.00001
					end
					v618 = v617
				end
				if v617 then
					local v620 = v598.interpolations
					table.insert(v620, {
						["axis"] = v612,
						["cur"] = v613,
						["tar"] = v618 and 0 or v615
					})
					p588.curTarget[v612] = v615
				end
			end
		end
	end
	if p588.centerAxis ~= nil then
		if v610 then
			local v621 = p589.curRotation[p588.centerAxis]
			local v622 = p589.rotation[p588.centerAxis]
			local v623 = v598.interpolations
			local v624 = {
				["axis"] = p588.centerAxis,
				["cur"] = v621,
				["tar"] = v622
			}
			table.insert(v623, v624)
			p588.curTarget[p588.centerAxis] = v622
		end
		for v625 = 1, 3 do
			if v625 ~= p588.centerAxis then
				local v626 = p589.curRotation[v625]
				local v627 = p589.rotation[v625]
				local v628 = v626 - v627
				local v629 = math.abs(v628) > 0.00001
				if p588.centerAxis ~= nil and not v629 then
					v629 = p589.useRotation[v625]
					if v629 then
						local v630 = p589.curRotation[p588.centerAxis] - p589.rotation[p588.centerAxis]
						v629 = math.abs(v630) > 0.00001
					end
				end
				if v629 then
					local v631 = v598.interpolations
					table.insert(v631, {
						["axis"] = v625,
						["cur"] = v610 and 0 or v626,
						["tar"] = v627
					})
					p588.curTarget[v625] = v627
				end
			end
		end
	end
	for v632, _ in pairs(p587.spec_motorized.activeGearLeverInterpolators) do
		if v632.gearLever == p589.gearLever then
			p587.spec_motorized.activeGearLeverInterpolators[v632] = nil
		end
	end
	if p587.spec_motorized.activeGearLeverInterpolators[p589] == nil then
		local v633 = #v598.interpolations
		if v633 > 0 then
			local v634 = p588.changeTime
			local v635 = math.max(v634, 0.001) / v633
			for v636 = 1, v633 do
				local v637 = v598.interpolations[v636]
				v637.speed = (v637.tar - v637.cur) / v635
			end
			v598.currentInterpolation = 1
			v598.isResetPosition = p590 == nil and true or p590 == true
			v598.handsOnDelay = p588.handsOnDelay
			v598.isGear = p589.gear ~= nil
			p587.spec_motorized.activeGearLeverInterpolators[p589] = v598
		end
	end
	return true
end
function Motorized.getGearInfoToDisplay(p638)
	local v639 = false
	local v640 = p638.spec_motorized.motor
	local v641, v642, v643, v644, v645, v646, v647, v648, v649
	if v640 == nil then
		v641 = nil
		v642 = nil
		v643 = nil
		v644 = nil
		v645 = nil
		v646 = nil
		v647 = nil
		v648 = nil
		v649 = nil
	else
		v642, v644, v645, v646, v647, v648, v649, v641 = v640:getGearInfoToDisplay()
		local v650
		v643, v650 = v640:getGearGroupToDisplay()
		if not v650 then
			v643 = nil
		end
		if p638.getAcDecelerationAxis ~= nil then
			local v651 = p638:getAcDecelerationAxis()
			if math.abs(v651) > 0 then
				v639 = p638:getIsMotorInNeutral()
			end
		end
	end
	return v642, v643, v644, v645, v646, v647, v648, v649, v641, v639
end
function Motorized.setTransmissionDirection(p652, p653)
	local v654 = p652.spec_motorized.motor
	if v654 ~= nil then
		v654:setTransmissionDirection(p653)
	end
end
function Motorized.getDirectionChangeMode(p655)
	return p655.spec_motorized.directionChangeMode
end
function Motorized.getIsManualDirectionChangeAllowed(p656)
	return not p656:getIsAIActive()
end
function Motorized.getGearShiftMode(p657)
	return p657.spec_motorized.gearShiftMode
end
function Motorized.onStateChange(p658, p659, _, _)
	local v660 = g_currentMission.missionInfo
	if p659 == VehicleStateChange.ENTER_VEHICLE then
		if v660.automaticMotorStartEnabled and p658:getCanMotorRun() then
			p658:startMotor(true)
			return
		end
	elseif p659 == VehicleStateChange.LEAVE_VEHICLE then
		if p658:getStopMotorOnLeave() and v660.automaticMotorStartEnabled then
			p658:stopMotor(true)
		end
		p658:stopVehicle()
	end
end
function Motorized.stopVehicle(p661)
	if p661.isServer and p661.spec_motorized.motorizedNode ~= nil then
		p661:controlVehicle(0, 0, 0, 0, (1 / 0), 0, 0, 0, 0, 0)
	end
end
function Motorized.onFillUnitFillLevelChanged(p662, p663, p664, p665, _, _, _)
	if p664 > 0 and p665 == FillType.DIESEL then
		local v666 = p662:getFillUnitFillLevel(p663) / p662:getFillUnitCapacity(p663)
		local v667 = p662:getConsumerFillUnitIndex(FillType.DEF)
		if v667 ~= nil then
			local v668 = p662:getFillUnitCapacity(v667) * v666 - p662:getFillUnitFillLevel(v667)
			p662:addFillUnitFillLevel(p662:getOwnerFarmId(), v667, v668, FillType.DEF, ToolType.UNDEFINED, nil)
		end
	end
end
function Motorized.onSetBroken(p669)
	p669:stopMotor(true)
end
function Motorized.getName(p670, p671)
	local v672 = p671(p670)
	local v673 = ConfigurationUtil.getConfigItemByConfigId(p670.configFileName, "motor", p670.configurations.motor)
	if v673 ~= nil and not v673.hasDefaultName then
		v672 = v673.name
	end
	return v672
end
function Motorized.getCanBeSelected(p674, p675)
	if not g_currentMission.missionInfo.automaticMotorStartEnabled then
		local v676 = p674.rootVehicle:getChildVehicles()
		for _, v677 in pairs(v676) do
			if v677.spec_motorized ~= nil then
				return true
			end
		end
	end
	return p675(p674)
end
function Motorized.getIsPowered(p678, p679)
	local v680 = p679(p678)
	if v680 then
		local v681 = p678:getMotorState()
		if v681 ~= MotorState.STARTING and v681 ~= MotorState.ON then
			local v682 = p678.rootVehicle:getChildVehicles()
			for _, v683 in pairs(v682) do
				if v683 ~= p678 and v683.getMotorState ~= nil then
					local v684 = v683:getMotorState()
					if v684 == MotorState.STARTING or v684 == MotorState.ON then
						return true
					end
				end
			end
			if p678:getCanMotorRun() then
				return false, g_i18n:getText("warning_motorNotStarted")
			else
				return false, p678:getMotorNotAllowedWarning()
			end
		end
	end
	return v680
end
function Motorized.tryStartMotor(p685)
	for v686 = 1, #p685.rootVehicle.childVehicles do
		local v687 = p685.rootVehicle.childVehicles[v686]
		if v687.getCanMotorRun ~= nil and v687:getCanMotorRun() then
			v687:startMotor()
		end
	end
end
function Motorized.actionEventToggleMotorState(p688, _, _, _, _)
	if not p688:getIsAIActive() then
		local v689 = p688:getMotorState()
		if v689 == MotorState.STARTING or v689 == MotorState.ON then
			p688:stopMotor()
			return
		end
		if p688:getCanMotorRun() then
			p688:startMotor()
			return
		end
		local v690 = p688:getMotorNotAllowedWarning()
		if v690 ~= nil then
			g_currentMission:showBlinkingWarning(v690, 2000)
		end
	end
end
function Motorized.actionEventSetMotorStateIgnition(p691, _, _, _, _)
	if not p691:getIsAIActive() and p691:getMotorState() == MotorState.OFF then
		p691:setMotorState(MotorState.IGNITION)
	end
end
function Motorized.actionEventSetMotorStateOn(p692, _, _, _, _)
	if not p692:getIsAIActive() then
		local v693 = p692:getMotorState()
		if v693 == MotorState.OFF or v693 == MotorState.IGNITION then
			if p692:getCanMotorRun() then
				p692:startMotor()
				return
			end
			local v694 = p692:getMotorNotAllowedWarning()
			if v694 ~= nil then
				g_currentMission:showBlinkingWarning(v694, 2000)
			end
		end
	end
end
function Motorized.actionEventSetMotorStateOff(p695, _, _, _, _)
	if not p695:getIsAIActive() and p695:getMotorState() ~= MotorState.OFF then
		p695:stopMotor()
	end
end
function Motorized.loadSpecValueFuel(p696, _, _)
	local v697 = p696:getRootName()
	local v698 = 0
	local v699 = {}
	while true do
		local v700 = string.format(v697 .. ".fillUnit.fillUnitConfigurations.fillUnitConfiguration(%d)", v698)
		if not p696:hasProperty(v700) then
			break
		end
		local v701 = 0
		local v702 = {}
		while true do
			local v703 = string.format(v700 .. ".fillUnits.fillUnit(%d)", v701)
			if not p696:hasProperty(v703) then
				break
			end
			local v704 = {
				["fillTypes"] = p696:getValue(v703 .. "#fillTypes"),
				["capacity"] = p696:getValue(v703 .. "#capacity")
			}
			table.insert(v702, v704)
			v701 = v701 + 1
		end
		table.insert(v699, v702)
		v698 = v698 + 1
	end
	local v705 = 0
	local v706 = {}
	while true do
		local v707 = string.format(v697 .. ".motorized.consumerConfigurations.consumerConfiguration(%d)", v705)
		if not p696:hasProperty(v707) then
			break
		end
		local v708 = 0
		local v709 = {}
		while true do
			local v710 = string.format(v707 .. ".consumer(%d)", v708)
			if not p696:hasProperty(v710) then
				break
			end
			local v711 = {
				["fillType"] = p696:getValue(v710 .. "#fillType"),
				["fillUnitIndex"] = p696:getValue(v710 .. "#fillUnitIndex"),
				["capacity"] = p696:getValue(v710 .. "#capacity")
			}
			table.insert(v709, v711)
			v708 = v708 + 1
		end
		table.insert(v706, v709)
		v705 = v705 + 1
	end
	return {
		["fillUnits"] = v699,
		["consumers"] = v706
	}
end
function Motorized.getSpecValueFuelDiesel(p712, p713, p714)
	return Motorized.getSpecValueFuel(p712, p713, p714, FillType.DIESEL)
end
function Motorized.getSpecValueFuelElectricCharge(p715, p716, p717)
	return Motorized.getSpecValueFuel(p715, p716, p717, FillType.ELECTRICCHARGE)
end
function Motorized.getSpecValueFuelMethane(p718, p719, p720)
	return Motorized.getSpecValueFuel(p718, p719, p720, FillType.METHANE)
end
function Motorized.getSpecValueFuel(p721, p722, p723, p724)
	local v725 = 1
	if p722 == nil or (p721.configurations == nil or (p722.configurations.motor == nil or p721.configurations.motor == nil)) then
		if p723 ~= nil then
			local v726 = p723.motor
			if v726 ~= nil then
				v725 = Utils.getNoNil(p721.configurations.motor[v726].consumerConfigurationIndex, v725)
			end
		end
	else
		local v727 = p722.configurations.motor
		v725 = Utils.getNoNil(p721.configurations.motor[v727].consumerConfigurationIndex, v725)
	end
	local v728 = nil
	local v729 = nil
	local v730 = nil
	local v731 = nil
	local v732 = 0
	local v733 = 0
	local v734 = 0
	local v735 = 0
	local v736 = p721.specs.fuel
	if v736 then
		v736 = p721.specs.fuel.consumers[v725]
	end
	if v736 ~= nil then
		for _, v737 in ipairs(v736) do
			local v738 = g_fillTypeManager:getFillTypeIndexByName(v737.fillType)
			if p724 == nil or v738 == p724 then
				if v738 == FillType.DIESEL then
					v732 = v737.fillUnitIndex
					v728 = v737.capacity
					if v738 == FillType.DEF then
						v733 = v737.fillUnitIndex
						v729 = v737.capacity
					end
				elseif v738 == FillType.ELECTRICCHARGE then
					v734 = v737.fillUnitIndex
					v730 = v737.capacity
				elseif v738 == FillType.METHANE then
					v735 = v737.fillUnitIndex
					v731 = v737.capacity
				end
			end
		end
	end
	local v739 = (p722 == nil or (p721.configurations == nil or (p722.configurations.fillUnit == nil or p721.configurations.fillUnit == nil))) and 1 or p722.configurations.fillUnit
	if p721.specs.fuel and p721.specs.fuel.fillUnits[v739] ~= nil then
		local v740 = p721.specs.fuel.fillUnits[v739][v732]
		if v740 ~= nil and v728 == nil then
			local v741 = v740.capacity
			v728 = math.max(v741, v728 or 0)
		end
		local v742 = p721.specs.fuel.fillUnits[v739][v733]
		if v742 ~= nil and v729 == nil then
			local v743 = v742.capacity
			v729 = math.max(v743, v729 or 0)
		end
		local v744 = p721.specs.fuel.fillUnits[v739][v734]
		if v744 ~= nil and v730 == nil then
			local v745 = v744.capacity
			v730 = math.max(v745, v730 or 0)
		end
		local v746 = p721.specs.fuel.fillUnits[v739][v735]
		if v746 ~= nil and v731 == nil then
			local v747 = v746.capacity
			v731 = math.max(v747, v731 or 0)
		end
	end
	if v728 == nil then
		if v730 == nil then
			if v731 == nil then
				return nil
			else
				return string.format(g_i18n:getText("shop_fuelValue"), v731, g_i18n:getText("unit_kg"))
			end
		else
			return string.format(g_i18n:getText("shop_fuelValue"), v730, g_i18n:getText("unit_kw"))
		end
	elseif v729 == nil or v729 <= 0 then
		return string.format(g_i18n:getText("shop_fuelValue"), v728, g_i18n:getText("unit_literShort"))
	else
		return string.format(g_i18n:getText("shop_fuelDefValue"), v728, g_i18n:getText("unit_literShort"), v729, g_i18n:getText("unit_literShort"), g_i18n:getText("fillType_def_short"))
	end
end
function Motorized.loadSpecValueMaxSpeed(p748, _, _)
	local v749 = p748:hasProperty("vehicle.motorized.motorConfigurations.motorConfiguration(0)") and "vehicle.motorized.motorConfigurations.motorConfiguration(0)" or (p748:hasProperty("vehicle.motor") and "vehicle" or nil)
	if v749 == nil then
		return nil
	else
		local v750 = p748:getValue(v749 .. ".motor#maxRpm", 1800)
		local v751 = p748:getValue(v749 .. ".transmission#minForwardGearRatio", nil)
		local v752 = p748:getValue(v749 .. ".transmission#axleRatio", 1)
		local v753 = Motorized.loadGears(nil, p748, "forwardGear", v749 .. ".transmission", v750, v752, 1)
		if v751 == nil and v753 == nil then
			Logging.xmlWarning(p748, "No gear ratios defined for transmission")
		end
		local v754 = VehicleMotor.calculatePhysicalMaximumSpeed(v751, v753, v750) * 3.6
		local v755 = math.ceil(v754)
		local v756 = p748:getValue("vehicle.storeData.specs.maxSpeed")
		local v757 = p748:getValue("vehicle.motorized.motorConfigurations.motorConfiguration(0)#maxSpeed")
		local v758 = p748:getValue(v749 .. ".motor#maxForwardSpeed")
		if v756 == nil then
			if v757 == nil then
				if v758 == nil then
					return v755
				else
					return math.min(v758, v755)
				end
			else
				return v757
			end
		else
			return v756
		end
	end
end
function Motorized.getSpecValueMaxSpeed(p759, p760, _, _, p761, _)
	local v762 = nil
	if p760 ~= nil and p759.configurations ~= nil then
		if p760.configurations.motor ~= nil and p759.configurations.motor ~= nil then
			local v763 = p760.configurations.motor
			v762 = Utils.getNoNil(p759.configurations.motor[v763].maxSpeed, v762)
		end
		if p760.configurations.wheel ~= nil and p759.configurations.wheel ~= nil then
			local v764 = p760.configurations.wheel
			v762 = Utils.getNoNil(p759.configurations.wheel[v764].maxForwardSpeedShop, v762)
		end
	end
	if v762 == nil then
		v762 = p759.specs.maxSpeed
	end
	if v762 == nil then
		return nil
	elseif p761 then
		return MathUtil.round(v762)
	else
		return string.format(g_i18n:getText("shop_maxSpeed"), string.format("%1d", g_i18n:getSpeed(v762)), g_i18n:getSpeedMeasuringUnit())
	end
end
function Motorized.loadSpecValuePower(p765, _, _)
	return p765:getValue("vehicle.storeData.specs.power")
end
function Motorized.getSpecValuePower(p766, p767, _, _, p768, _)
	local v769 = nil
	local v770 = nil
	if p767 == nil or (p766.configurations == nil or (p767.configurations.motor == nil or p766.configurations.motor == nil)) then
		if p767 == nil and (p766.configurations ~= nil and p766.configurations.motor ~= nil) then
			for _, v771 in ipairs(p766.configurations.motor) do
				if v771.isSelectable and v771.power ~= nil then
					local v772 = v771.power
					v769 = math.min(v769 or (1 / 0), v772)
					local v773 = v771.power
					v770 = math.max(v770 or 0, v773)
				end
			end
		end
	else
		local v774 = p767.configurations.motor
		v769 = p766.configurations.motor[v774].power
		v770 = v769
	end
	if v769 == nil then
		v769 = p766.specs.power
		v770 = v769
	end
	if v769 == nil then
		return nil
	elseif p768 == nil or p768 == false then
		if v769 == v770 then
			return string.format(g_i18n:getText("shop_maxPowerValueSingle"), MathUtil.round(v769))
		else
			return string.format(g_i18n:getText("shop_maxPowerValueRange"), MathUtil.round(v769), MathUtil.round(v770))
		end
	else
		return MathUtil.round(v769), MathUtil.round(v770)
	end
end
function Motorized.loadSpecValuePowerConfig(p775, _, _)
	local v776 = {}
	local v777 = false
	for v778, v779 in pairs(g_vehicleConfigurationManager:getConfigurations()) do
		v776[v778] = {}
		for v780, v781 in p775:iterator(v779.configurationKey) do
			if p775:getValue(v781 .. "#isSelectable", true) then
				local v782 = p775:getFloat(v781 .. "#hp")
				if v782 ~= nil then
					v776[v778][v780] = MathUtil.round(v782)
					v777 = true
				end
			end
		end
	end
	if v777 then
		return v776
	else
		return nil
	end
end
function Motorized.getSpecValuePowerConfig(p783, _, p784, _, p785, _)
	if p783.specs.powerConfig ~= nil then
		local v786 = nil
		local v787 = nil
		if p784 == nil then
			v786 = (1 / 0)
			v787 = 0
			local v788 = 0
			for _, v789 in pairs(p783.specs.powerConfig) do
				for _, v790 in pairs(v789) do
					v786 = math.min(v786, v790)
					v787 = math.max(v787, v790)
					v788 = v788 + 1
				end
			end
		else
			for v791, v792 in pairs(p784) do
				local v793 = p783.specs.powerConfig[v791][v792]
				if v793 ~= nil then
					v787 = v793
					v786 = v787
					local v794 = v787
					v787 = v786
					v794 = v786
				end
			end
		end
		if v786 ~= nil then
			if p785 then
				return MathUtil.round(v786), MathUtil.round(v787)
			elseif v786 == v787 then
				return string.format(g_i18n:getText("shop_maxPowerValueSingle"), MathUtil.round(v786))
			else
				return string.format(g_i18n:getText("shop_maxPowerValueRange"), MathUtil.round(v786), MathUtil.round(v787))
			end
		end
	end
	return nil
end
function Motorized.loadSpecValueTransmission(p_u_795, p_u_796, _)
	local v_u_797 = {}
	p_u_795:iterate("vehicle.motorized.motorConfigurations.motorConfiguration", function(p798, p799)
		-- upvalues: (copy) v_u_797, (copy) p_u_795, (copy) p_u_796
		v_u_797[p798] = p_u_795:getValue(p799 .. ".transmission#name", nil, p_u_796, false)
		local v800 = p_u_795:getValue(p799 .. ".transmission#param")
		if v800 ~= nil then
			local v801 = g_i18n:convertText(v800, p_u_796)
			v_u_797[p798] = string.format(v_u_797[p798], v801)
		end
	end)
	return v_u_797
end
function Motorized.getSpecValueTransmission(p802, p803, _, _, _, _)
	local v804
	if p803 == nil or (p802.configurations == nil or (p803.configurations.motor == nil or p802.configurations.motor == nil)) then
		v804 = p802.specs.transmission[1]
	else
		v804 = p802.specs.transmission[p803.configurations.motor]
		if v804 == nil then
			return p802.specs.transmission[1]
		end
	end
	return v804
end

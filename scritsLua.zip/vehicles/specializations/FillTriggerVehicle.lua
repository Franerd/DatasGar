FillTriggerVehicle = {}
function FillTriggerVehicle.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(FillUnit, p1)
end
function FillTriggerVehicle.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("FillTriggerVehicle")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.fillTriggerVehicle#triggerNode", "Fill trigger node")
	v2:register(XMLValueType.INT, "vehicle.fillTriggerVehicle#fillUnitIndex", "Fill unit index", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.fillTriggerVehicle#litersPerSecond", "Liter per second", 200)
	v2:setXMLSpecializationType()
end
function FillTriggerVehicle.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "getDrawFirstFillText", FillTriggerVehicle.getDrawFirstFillText)
end
function FillTriggerVehicle.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", FillTriggerVehicle)
	SpecializationUtil.registerEventListener(p4, "onDelete", FillTriggerVehicle)
	SpecializationUtil.registerEventListener(p4, "onReadStream", FillTriggerVehicle)
	SpecializationUtil.registerEventListener(p4, "onWriteStream", FillTriggerVehicle)
end
function FillTriggerVehicle.onLoad(p5, _)
	local v6 = p5.spec_fillTriggerVehicle
	local v7 = p5.xmlFile:getValue("vehicle.fillTriggerVehicle#triggerNode", nil, p5.components, p5.i3dMappings)
	if v7 ~= nil then
		v6.fillUnitIndex = p5.xmlFile:getValue("vehicle.fillTriggerVehicle#fillUnitIndex", 1)
		v6.litersPerSecond = p5.xmlFile:getValue("vehicle.fillTriggerVehicle#litersPerSecond", 200)
		v6.fillTrigger = FillTrigger.new(v7, p5, v6.fillUnitIndex, v6.litersPerSecond)
		if p5:getPropertyState() ~= VehiclePropertyState.SHOP_CONFIG and p5.isServer then
			local v8 = MoneyType.register("other", "finance_purchaseFuel")
			v6.fillTrigger:setMoneyChangeType(v8)
		end
	end
end
function FillTriggerVehicle.onDelete(p9)
	local v10 = p9.spec_fillTriggerVehicle
	if v10.fillTrigger ~= nil then
		v10.fillTrigger:delete()
		v10.fillTrigger = nil
	end
end
function FillTriggerVehicle.onReadStream(p11, p12, p13)
	if p13:getIsServer() then
		local v14 = p11.spec_fillTriggerVehicle
		if v14.fillTrigger ~= nil then
			local v15 = streamReadUInt16(p12)
			local v16 = MoneyType.registerWithId(v15, "other", "finance_purchaseFuel")
			v14.fillTrigger:setMoneyChangeType(v16)
		end
	end
end
function FillTriggerVehicle.onWriteStream(p17, p18, p19)
	if not p19:getIsServer() then
		local v20 = p17.spec_fillTriggerVehicle
		if v20.fillTrigger ~= nil then
			streamWriteUInt16(p18, v20.fillTrigger.moneyChangeType.id)
		end
	end
end
function FillTriggerVehicle.getDrawFirstFillText(p21, p22)
	local v23 = p21.spec_fillTriggerVehicle
	return p21.isClient and (v23.fillUnitIndex ~= nil and (p21:getFillUnitFillLevel(v23.fillUnitIndex) <= 0 and p21:getFillUnitCapacity(v23.fillUnitIndex) ~= 0)) and true or p22(p21)
end

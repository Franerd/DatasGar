AIAutomaticSteering = {}
AIAutomaticSteering.LINE_END_SOUND_DISTANCE = 5
AIAutomaticSteering.RESET_COURSE_TIME = 20000
AIAutomaticSteering.HEADING_LETTERS = {}
AIAutomaticSteering.HEADING_LETTERS[1] = "N"
AIAutomaticSteering.HEADING_LETTERS[2] = "NE"
AIAutomaticSteering.HEADING_LETTERS[3] = "E"
AIAutomaticSteering.HEADING_LETTERS[4] = "SE"
AIAutomaticSteering.HEADING_LETTERS[5] = "S"
AIAutomaticSteering.HEADING_LETTERS[6] = "SW"
AIAutomaticSteering.HEADING_LETTERS[7] = "W"
AIAutomaticSteering.HEADING_LETTERS[8] = "NW"
AIAutomaticSteering.STATE = {}
AIAutomaticSteering.STATE.DISABLED = 1
AIAutomaticSteering.STATE.AVAILABLE = 2
AIAutomaticSteering.STATE.ACTIVE = 3
Enum(AIAutomaticSteering.STATE)
source("dataS/scripts/vehicles/specializations/events/AIAutomaticSteeringCourseEvent.lua")
source("dataS/scripts/vehicles/specializations/events/AIAutomaticSteeringRequestEvent.lua")
source("dataS/scripts/vehicles/specializations/events/AIAutomaticSteeringStateEvent.lua")
function AIAutomaticSteering.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Drivable, p1)
end
function AIAutomaticSteering.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("AIAutomaticSteering")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.ai.automaticSteering.sounds", "engage")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.ai.automaticSteering.sounds", "disengage")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.ai.automaticSteering.sounds", "lineEnd")
	Dashboard.registerDashboardXMLPaths(v2, "vehicle.ai.automaticSteering.dashboards", {
		"steeringEngaged",
		"steeringState",
		"heading",
		"headingLetter"
	})
	v2:register(XMLValueType.FLOAT, "vehicle.ai.automaticSteering#lookAheadDistance", "Distance for aiming onto the wayline", "half of the vehicle length")
	v2:setXMLSpecializationType()
	local v3 = Vehicle.xmlSchemaSavegame
	SteeringFieldCourse.registerXMLPaths(v3, "vehicles.vehicle(?).aiAutomaticSteering.steeringFieldCourse")
	v3:register(XMLValueType.BOOL, "vehicles.vehicle(?).aiAutomaticSteering#isOnField", "Is on field")
end
function AIAutomaticSteering.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "getAttacherToolWorkingWidth", AIAutomaticSteering.getAttacherToolWorkingWidth)
	SpecializationUtil.registerFunction(p4, "getIsAutomaticSteeringAllowed", AIAutomaticSteering.getIsAutomaticSteeringAllowed)
	SpecializationUtil.registerFunction(p4, "setAIAutomaticSteeringEnabled", AIAutomaticSteering.setAIAutomaticSteeringEnabled)
	SpecializationUtil.registerFunction(p4, "setAIAutomaticSteeringCourse", AIAutomaticSteering.setAIAutomaticSteeringCourse)
	SpecializationUtil.registerFunction(p4, "getIsAIAutomaticSteeringAllowed", AIAutomaticSteering.getIsAIAutomaticSteeringAllowed)
	SpecializationUtil.registerFunction(p4, "getAIAutomaticSteeringState", AIAutomaticSteering.getAIAutomaticSteeringState)
	SpecializationUtil.registerFunction(p4, "getIsSideOffsetReversed", AIAutomaticSteering.getIsSideOffsetReversed)
end
function AIAutomaticSteering.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "setSteeringInput", AIAutomaticSteering.setSteeringInput)
	SpecializationUtil.registerOverwrittenFunction(p5, "updateVehiclePhysics", AIAutomaticSteering.updateVehiclePhysics)
end
function AIAutomaticSteering.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onRegisterDashboardValueTypes", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onDelete", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onReadStream", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onUpdate", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onStateChange", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onAIModeChanged", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onAIModeSettingsChanged", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onActivate", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onDeactivate", AIAutomaticSteering)
	SpecializationUtil.registerEventListener(p6, "onRegisterActionEvents", AIAutomaticSteering)
end
function AIAutomaticSteering.onLoad(p7, _)
	local v8 = p7.spec_aiAutomaticSteering
	v8.lastIsOnField = false
	v8.forceFieldCourseUpdate = false
	v8.resetCourseTimer = 0
	v8.steeringFieldCourse = nil
	v8.lastDistanceToEnd = 0
	v8.steeringEnabled = false
	v8.steeringLastEnableTime = (-1 / 0)
	v8.steeringValue = 0
	v8.lookAheadDistance = p7.xmlFile:getValue("vehicle.ai.automaticSteering#lookAheadDistance")
	v8.lastSteeringInputValue = 0
	if p7.isClient then
		v8.samples = {}
		v8.samples.engage = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.ai.automaticSteering.sounds", "engage", p7.baseDirectory, p7.components, 1, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.samples.disengage = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.ai.automaticSteering.sounds", "disengage", p7.baseDirectory, p7.components, 1, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.samples.lineEnd = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.ai.automaticSteering.sounds", "lineEnd", p7.baseDirectory, p7.components, 1, AudioGroup.VEHICLE, p7.i3dMappings, p7)
	end
	v8.dirtyFlag = p7:getNextDirtyFlag()
end
function AIAutomaticSteering.onPostLoad(p_u_9, p10)
	if p10 ~= nil and not p10.resetVehicles then
		local v_u_11 = p_u_9.spec_aiAutomaticSteering
		v_u_11.lastIsOnField = p10.xmlFile:getValue(p10.key .. ".aiAutomaticSteering#isOnField", v_u_11.lastIsOnField)
		SteeringFieldCourse.loadFromXML(p10.xmlFile, p10.key .. ".aiAutomaticSteering.steeringFieldCourse", function(p12)
			-- upvalues: (copy) p_u_9, (copy) v_u_11
			if p12 ~= nil then
				p_u_9:setAIAutomaticSteeringCourse(p12, true)
				v_u_11.forceFieldCourseUpdate = false
			end
		end)
	end
end
function AIAutomaticSteering.onRegisterDashboardValueTypes(p_u_13)
	local v14 = p_u_13.spec_aiAutomaticSteering
	local v15 = DashboardValueType.new("ai.automaticSteering", "steeringEngaged")
	v15:setValue(v14, "steeringEnabled")
	p_u_13:registerDashboardValueType(v15)
	local v16 = DashboardValueType.new("ai.automaticSteering", "steeringState")
	v16:setValue(v14, function()
		-- upvalues: (copy) p_u_13
		return p_u_13:getAIAutomaticSteeringState() - 1
	end)
	p_u_13:registerDashboardValueType(v16)
	local v17 = DashboardValueType.new("ai.automaticSteering", "heading")
	v17:setValue(v14, function()
		-- upvalues: (copy) p_u_13
		local v18, _, v19 = localDirectionToWorld(p_u_13.rootNode, 0, 0, 1)
		local v20 = MathUtil.getYRotationFromDirection(v18, v19)
		if v20 < 0 then
			v20 = v20 + 6.283185307179586
		end
		return 360 - math.deg(v20)
	end)
	p_u_13:registerDashboardValueType(v17)
	local v21 = DashboardValueType.new("ai.automaticSteering", "headingLetter")
	v21:setValue(v14, function()
		-- upvalues: (copy) p_u_13
		local v22, _, v23 = localDirectionToWorld(p_u_13.rootNode, 0, 0, -1)
		local v24 = MathUtil.getYRotationFromDirection(v22, v23)
		if v24 < 0 then
			v24 = v24 + 6.283185307179586
		end
		local v25 = 360 - math.deg(v24)
		if v25 >= 337.5 or v25 < 22.5 then
			return AIAutomaticSteering.HEADING_LETTERS[1]
		end
		if v25 >= 22.5 and v25 < 67.5 then
			return AIAutomaticSteering.HEADING_LETTERS[2]
		end
		if v25 >= 67.5 and v25 < 112.5 then
			return AIAutomaticSteering.HEADING_LETTERS[3]
		end
		if v25 >= 112.5 and v25 < 157.5 then
			return AIAutomaticSteering.HEADING_LETTERS[4]
		end
		if v25 >= 157.5 and v25 < 202.5 then
			return AIAutomaticSteering.HEADING_LETTERS[5]
		end
		if v25 >= 202.5 and v25 < 247.5 then
			return AIAutomaticSteering.HEADING_LETTERS[6]
		end
		if v25 >= 247.5 and v25 < 292.5 then
			return AIAutomaticSteering.HEADING_LETTERS[7]
		end
		if v25 >= 292.5 and v25 < 337.5 then
			return AIAutomaticSteering.HEADING_LETTERS[8]
		end
	end)
	p_u_13:registerDashboardValueType(v21)
end
function AIAutomaticSteering.onDelete(p26)
	local v27 = p26.spec_aiAutomaticSteering
	if v27.samples ~= nil then
		g_soundManager:deleteSamples(v27.samples)
	end
end
function AIAutomaticSteering.saveToXMLFile(p28, p29, p30, _)
	local v31 = p28.spec_aiAutomaticSteering
	if v31.steeringFieldCourse ~= nil then
		v31.steeringFieldCourse:saveToXML(p29, p30 .. ".steeringFieldCourse")
	end
	p29:setValue(p30 .. "#isOnField", v31.lastIsOnField)
end
function AIAutomaticSteering.onReadStream(p_u_32, p33, p34)
	if streamReadBool(p33) then
		SteeringFieldCourse.readStream(p33, p34, function(p35)
			-- upvalues: (copy) p_u_32
			p_u_32:setAIAutomaticSteeringCourse(p35, true)
			p_u_32.spec_aiAutomaticSteering.lastIsOnField = true
			p_u_32.spec_aiAutomaticSteering.forceFieldCourseUpdate = false
		end)
	end
end
function AIAutomaticSteering.onWriteStream(p36, p37, p38)
	local v39 = p36.spec_aiAutomaticSteering
	if streamWriteBool(p37, v39.steeringFieldCourse ~= nil) then
		v39.steeringFieldCourse:writeStream(p37, p38)
	end
end
function AIAutomaticSteering.onReadUpdateStream(p40, p41, _, p42)
	if p42:getIsServer() and streamReadBool(p41) then
		SteeringFieldCourse.readSegmentStatesFromStream(p40.spec_aiAutomaticSteering.steeringFieldCourse, p41, p42)
	end
end
function AIAutomaticSteering.onWriteUpdateStream(p43, p44, p45, p46)
	local v47 = p43.spec_aiAutomaticSteering
	if not p45:getIsServer() and streamWriteBool(p44, bitAND(p46, v47.dirtyFlag) ~= 0) then
		v47.steeringFieldCourse:writeSegmentStatesToStream(p44, p45)
	end
end
function AIAutomaticSteering.onUpdate(p48, p49, _, p50, _)
	local v51 = p48.spec_aiAutomaticSteering
	if p48:getAIModeSelection() == AIModeSelection.MODE.STEERING_ASSIST and v51.steeringFieldCourse ~= nil then
		if p50 and VehicleDebug.state == VehicleDebug.DEBUG_AI then
			v51.steeringFieldCourse:draw()
		end
		local v52 = p48:getAIRootNode()
		local v53 = p48:getReverserDirection()
		local v54 = p48:getIsSideOffsetReversed()
		local v55 = v51.lookAheadDistance or p48.size.length * 0.5
		local v56
		if v53 < 0 then
			v56 = -v55 + p48.size.lengthOffset
		else
			v56 = v55 + p48.size.lengthOffset
		end
		local _, _, v57 = localToLocal(p48.rootNode, v52, 0, 0, v56)
		local v58 = math.max(v57, 4)
		local v59 = math.sign(v58)
		local v60 = p48:getLastSpeed() / 30
		local v61 = math.min(v60, 1)
		local v62 = v58 + v59 * math.pow(v61, 2) * 5
		if p48:getLastSpeed() > 1 and p48.movingDirection * v53 < 0 then
			if v51.steeringFieldCourse:resetCurrentSegment() then
				AIAutomaticSteering.updateActionEvents(p48)
			end
		else
			local v63, _, v64 = localToWorld(v52, 0, 0, v62)
			local v65, _, v66 = localDirectionToWorld(p48.rootNode, 0, 0, 1)
			local v67, v68 = MathUtil.vector2Normalize(v65, v66)
			if v51.steeringFieldCourse:updateVehicleData(p49, v51.steeringEnabled, v63, v64, v67, v68, v54) then
				AIAutomaticSteering.updateActionEvents(p48)
			end
		end
		if p48.isServer then
			if v51.steeringFieldCourse.currentSegment ~= nil and v51.steeringEnabled then
				local v69, v70, v71 = v51.steeringFieldCourse:getSteeringTarget(v52, v62, v54)
				if v69 ~= 0 and v70 ~= 0 then
					local v72 = v69 * 0.5
					local v73 = v70 * 0.5
					local v74 = -v72
					local v75
					if v69 > 0 then
						v75 = -v73
						v74 = v72
					else
						v75 = v73
					end
					local v76, _, v77 = MathUtil.getLineLineIntersection2D(v72, v73, v75, v74, 0, 0, v69, 0)
					local v78
					if v76 and math.abs(v77) < 100000 then
						v78 = p48:getSteeringRotTimeByCurvature(1 / (v69 * v77))
						if v53 < 0 then
							v78 = -v78
						end
					else
						v78 = 0
					end
					local v79
					if v78 >= 0 then
						local v80 = p48.maxRotTime
						v79 = math.min(v78, v80)
					else
						local v81 = p48.minRotTime
						v79 = math.max(v78, v81)
					end
					if v51.steeringValue < v79 then
						local v82 = v51.steeringValue + p49 * p48:getAISteeringSpeed()
						v51.steeringValue = math.min(v82, v79)
					else
						local v83 = v51.steeringValue - p49 * p48:getAISteeringSpeed()
						v51.steeringValue = math.max(v83, v79)
					end
					if v71 ~= v51.lastDistanceToEnd then
						if v51.lastDistanceToEnd > AIAutomaticSteering.LINE_END_SOUND_DISTANCE and v71 <= AIAutomaticSteering.LINE_END_SOUND_DISTANCE then
							g_soundManager:playSample(v51.samples.lineEnd)
						end
						v51.lastDistanceToEnd = v71
					end
				end
			end
			if v51.steeringFieldCourse.segmentStatesDirty then
				p48:raiseDirtyFlags(v51.dirtyFlag)
				v51.steeringFieldCourse.segmentStatesDirty = false
			end
		end
	end
end
function AIAutomaticSteering.onUpdateTick(p84, p85, _, p86, _)
	local v87 = p84.spec_aiAutomaticSteering
	if p86 and p84:getAIModeSelection() == AIModeSelection.MODE.STEERING_ASSIST then
		local v88, _, v89 = localToWorld(p84.rootNode, 0, 0, p84.size.length * 0.5 + p84.size.lengthOffset)
		local v90, v91 = g_fieldCourseManager:roundToTerrainDetailPixel(v88, v89)
		local v92 = getDensityAtWorldPos(g_currentMission.terrainDetailId, v90, 0, v91) ~= 0
		if not v92 then
			local v93, _, v94 = localToWorld(p84.rootNode, 0, 0, -p84.size.length * 0.5 + p84.size.lengthOffset)
			v90, v91 = g_fieldCourseManager:roundToTerrainDetailPixel(v93, v94)
			if getDensityAtWorldPos(g_currentMission.terrainDetailId, v90, 0, v91) == 0 then
				v92 = false
			else
				v92 = true
			end
		end
		local v95 = p84:getActiveFarm()
		if not (g_currentMission.accessHandler:canFarmAccessLand(v95, v90, v91) or g_missionManager:getIsMissionWorkAllowed(v95, v90, v91, nil, p84)) then
			v92 = false
		end
		if v92 ~= v87.lastIsOnField or v87.forceFieldCourseUpdate then
			v87.lastIsOnField = v92
			if v92 then
				v87.resetCourseTimer = 0
				local v96 = p84:getAttacherToolWorkingWidth()
				local v97 = true
				if v87.steeringFieldCourse ~= nil and (not v87.forceFieldCourseUpdate and v87.steeringFieldCourse:getIsPointInsideBoundary(v90, v91)) then
					local v98 = v96 - v87.steeringFieldCourse.fieldCourseSettings.implementWidth
					if math.abs(v98) < 0.05 then
						v97 = false
					end
				end
				if v97 then
					p84:initializeLoadedAIModeUserSettings()
					local v99 = p84:getAIModeFieldCourseSettings()
					if v99 == nil then
						local v100
						v99, v100 = FieldCourseSettings.generate(p84.rootVehicle)
					end
					if VehicleDebug.state == VehicleDebug.DEBUG_AI then
						v99:print()
					end
					g_client:getServerConnection():sendEvent(AIAutomaticSteeringRequestEvent.new(p84, v90, v91, v99))
				end
			else
				v87.resetCourseTimer = AIAutomaticSteering.RESET_COURSE_TIME
			end
			v87.forceFieldCourseUpdate = false
		end
		if not v92 and v87.resetCourseTimer > 0 then
			v87.resetCourseTimer = v87.resetCourseTimer - p85
			if v87.resetCourseTimer <= 0 then
				p84:setAIAutomaticSteeringCourse(nil)
			end
		end
	end
	if p84.isServer and (p84:getAIModeSelection() == AIModeSelection.MODE.STEERING_ASSIST and (v87.steeringFieldCourse ~= nil and (v87.steeringEnabled and (p84:getLastSpeed() > 1 and p84.movingDirection * p84:getReverserDirection() < 0)))) then
		p84:setAIAutomaticSteeringEnabled(false)
	end
end
function AIAutomaticSteering.onStateChange(p101, p102, _)
	if p102 == VehicleStateChange.ATTACH or p102 == VehicleStateChange.DETACH then
		p101.spec_aiAutomaticSteering.forceFieldCourseUpdate = true
		if p101.isServer and (p101:getAIModeSelection() == AIModeSelection.MODE.STEERING_ASSIST and not p101:getIsAutomaticSteeringAllowed()) then
			p101:setAIModeSelection(AIModeSelection.MODE.WORKER)
		end
	end
end
function AIAutomaticSteering.onAIModeChanged(p103, p104)
	if p104 == AIModeSelection.MODE.STEERING_ASSIST then
		if p103.isClient then
			p103.spec_aiAutomaticSteering.forceFieldCourseUpdate = true
		end
	else
		p103:setAIAutomaticSteeringCourse(nil, false)
	end
end
function AIAutomaticSteering.onAIModeSettingsChanged(p105, p106)
	if p105.isClient and p106 == AIModeSelection.MODE.STEERING_ASSIST then
		p105:setAIAutomaticSteeringCourse(nil, false)
		p105.spec_aiAutomaticSteering.forceFieldCourseUpdate = true
	end
end
function AIAutomaticSteering.onActivate(p107)
	if p107:getIsActiveForInput(true, true) then
		local v108 = p107.spec_aiAutomaticSteering
		if v108.steeringFieldCourse ~= nil then
			g_fieldCourseManager:setActiveSteeringFieldCourse(v108.steeringFieldCourse, p107)
		end
	end
end
function AIAutomaticSteering.onDeactivate(p109)
	if p109.isActiveForInputIgnoreSelectionIgnoreAI then
		if p109.spec_aiAutomaticSteering.steeringFieldCourse ~= nil then
			g_fieldCourseManager:setActiveSteeringFieldCourse(nil, p109)
		end
		p109:setAIAutomaticSteeringEnabled(false)
	end
end
function AIAutomaticSteering.getAttacherToolWorkingWidth(p110)
	local v111 = 0
	for _, v112 in pairs(p110.rootVehicle.childVehicles) do
		if v112.getAIMarkers ~= nil then
			v112:updateAIMarkerWidth()
			local _, _, _, _, v113 = v112:getAIMarkers()
			if v113 ~= nil then
				v111 = math.max(v111, v113)
			end
		end
		if v112.getAIWorkAreaWidth ~= nil then
			v111 = math.max(v111, v112:getAIWorkAreaWidth())
		end
	end
	return v111
end
function AIAutomaticSteering.getIsAutomaticSteeringAllowed(p114)
	if p114.rootVehicle.getImplementAllowAutomaticSteering ~= nil and p114.rootVehicle:getImplementAllowAutomaticSteering() then
		return true
	end
	for _, v115 in pairs(p114.rootVehicle.childVehicles) do
		if v115.getImplementAllowAutomaticSteering ~= nil and v115:getImplementAllowAutomaticSteering() then
			return true
		end
	end
	return false
end
function AIAutomaticSteering.setAIAutomaticSteeringEnabled(p116, p117, p118, p119, p120)
	local v121 = p116.spec_aiAutomaticSteering
	if p117 == nil then
		p117 = not v121.steeringEnabled
	end
	if p117 ~= v121.steeringEnabled then
		v121.steeringEnabled = p117
		if p117 then
			v121.steeringValue = p116.rotatedTime
			v121.steeringLastEnableTime = g_time
		end
		if p116.isClient then
			if p117 then
				g_soundManager:playSample(v121.samples.engage)
			else
				g_soundManager:playSample(v121.samples.disengage)
			end
			AIAutomaticSteering.updateActionEvents(p116)
		end
	end
	if v121.steeringFieldCourse ~= nil then
		if p116.isServer then
			p118 = v121.steeringFieldCourse.currentSegmentIndex
			p119 = v121.steeringFieldCourse.currentSegmentIsLeft
		elseif p118 ~= nil then
			v121.steeringFieldCourse:setCurrentSegmentIndex(p118, p119)
		end
	end
	AIAutomaticSteeringStateEvent.sendEvent(p116, p117, p118, p119, p120)
	return p118, p119
end
function AIAutomaticSteering.setAIAutomaticSteeringCourse(p122, p123, p124)
	local v125 = p122.spec_aiAutomaticSteering
	v125.steeringFieldCourse = p123
	if p123 == nil and v125.steeringEnabled then
		p122:setAIAutomaticSteeringEnabled(false, nil, nil, true)
	end
	if p122.isActiveForInputIgnoreSelectionIgnoreAI then
		g_fieldCourseManager:setActiveSteeringFieldCourse(p123, p122)
	end
	if p122.isClient then
		AIAutomaticSteering.updateActionEvents(p122)
	end
	if p124 ~= true then
		if g_server ~= nil then
			g_server:broadcastEvent(AIAutomaticSteeringCourseEvent.new(p122, p123), nil, nil, p122)
			return
		end
		g_client:getServerConnection():sendEvent(AIAutomaticSteeringCourseEvent.new(p122, p123))
	end
end
function AIAutomaticSteering.getIsAIAutomaticSteeringAllowed(p126)
	local v127 = p126.spec_aiAutomaticSteering
	if v127.steeringFieldCourse == nil then
		return false, g_i18n:getText("ai_automaticSteeringWarningNoCourse")
	elseif v127.steeringFieldCourse.currentSegment == nil then
		return false, g_i18n:getText("ai_automaticSteeringWarningNoSegment")
	else
		return true
	end
end
function AIAutomaticSteering.getAIAutomaticSteeringState(p128)
	local v129 = p128.spec_aiAutomaticSteering
	if v129.steeringFieldCourse == nil then
		return AIAutomaticSteering.STATE.DISABLED
	elseif v129.steeringEnabled then
		return AIAutomaticSteering.STATE.ACTIVE
	else
		return AIAutomaticSteering.STATE.AVAILABLE
	end
end
function AIAutomaticSteering.getIsSideOffsetReversed(p130)
	for _, v131 in pairs(p130.rootVehicle.childVehicles) do
		if v131.spec_plow ~= nil then
			return v131.spec_plow.rotationMax
		end
	end
	return false
end
function AIAutomaticSteering.setSteeringInput(p132, p133, p134, p135, p136)
	local v137 = p132.spec_aiAutomaticSteering
	if v137.steeringEnabled then
		if p136 == InputDevice.CATEGORY.KEYBOARD_MOUSE then
			p132:setAIAutomaticSteeringEnabled(false)
		elseif g_time - v137.steeringLastEnableTime > 2500 then
			local v138 = p134 - v137.lastSteeringInputValue
			if math.abs(v138) > 0.1 then
				p132:setAIAutomaticSteeringEnabled(false)
			end
		else
			v137.lastSteeringInputValue = p134
		end
	else
		v137.lastSteeringInputValue = p134
	end
	return p133(p132, p134, p135, p136)
end
function AIAutomaticSteering.updateVehiclePhysics(p139, p140, p141, p142, p143, p144)
	local v145 = p139.spec_aiAutomaticSteering
	if not v145.steeringEnabled then
		return p140(p139, p141, p142, p143, p144)
	end
	local v146
	if v145.steeringValue < 0 then
		v146 = -v145.steeringValue / p139.maxRotTime
	else
		v146 = v145.steeringValue / p139.minRotTime
	end
	local v147 = p140(p139, p141, v146, p143, p144)
	p139.rotatedTime = v145.steeringValue
	p139.spec_drivable.axisSide = v146
	return v147
end
function AIAutomaticSteering.onRegisterActionEvents(p148, _, p149)
	if p148.isClient then
		local v150 = p148.spec_aiAutomaticSteering
		p148:clearActionEventsTable(v150.actionEvents)
		if p149 then
			local _, v151 = p148:addPoweredActionEvent(v150.actionEvents, InputAction.TOGGLE_AI_STEERING, p148, AIAutomaticSteering.actionEventSteering, false, true, false, true, nil)
			if v151 ~= nil then
				g_inputBinding:setActionEventTextPriority(v151, GS_PRIO_HIGH)
				g_inputBinding:setActionEventText(v151, string.format(g_i18n:getText("ai_modeSelect"), g_i18n:getText("ai_modeSteeringAssist")))
				AIAutomaticSteering.updateActionEvents(p148)
			end
		end
	end
end
function AIAutomaticSteering.actionEventSteering(p152, _, _, _, _)
	p152:setAIAutomaticSteeringEnabled()
end
function AIAutomaticSteering.updateActionEvents(p153)
	local v154 = p153.spec_aiAutomaticSteering
	local v155 = v154.actionEvents[InputAction.TOGGLE_AI_STEERING]
	if v155 ~= nil then
		local v156
		if v154.steeringFieldCourse == nil then
			v156 = false
		else
			v156 = v154.steeringFieldCourse.currentSegment ~= nil
		end
		g_inputBinding:setActionEventActive(v155.actionEventId, v156)
	end
end

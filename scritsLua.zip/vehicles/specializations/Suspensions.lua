Suspensions = {}
Suspensions.DEFAULT_MAX_UPDATE_DISTANCE = 40
Suspensions.SUSPENSION_NODE_XML_KEY = "vehicle.suspensions.suspension(?)"
function Suspensions.prerequisitesPresent(_)
	return true
end
function Suspensions.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Suspensions")
	local v2 = Suspensions.SUSPENSION_NODE_XML_KEY
	v1:register(XMLValueType.NODE_INDEX, v2 .. "#node", "Suspension node")
	v1:register(XMLValueType.BOOL, v2 .. "#useCharacterTorso", "Use character torso instead of node")
	v1:register(XMLValueType.FLOAT, v2 .. "#weight", "Weight in kg", 500)
	v1:register(XMLValueType.VECTOR_ROT, v2 .. "#minRotation", "Min. rotation")
	v1:register(XMLValueType.VECTOR_ROT, v2 .. "#maxRotation", "Max. rotation")
	v1:register(XMLValueType.VECTOR_TRANS, v2 .. "#startTranslationOffset", "Custom translation offset")
	v1:register(XMLValueType.VECTOR_TRANS, v2 .. "#minTranslation", "Min. translation")
	v1:register(XMLValueType.VECTOR_TRANS, v2 .. "#maxTranslation", "Max. translation")
	v1:register(XMLValueType.FLOAT, v2 .. "#maxVelocityDifference", "Max. velocity difference", 0.1)
	v1:register(XMLValueType.VECTOR_2, v2 .. "#suspensionParametersX", "Suspension parameters X", "0 0")
	v1:register(XMLValueType.VECTOR_2, v2 .. "#suspensionParametersY", "Suspension parameters Y", "0 0")
	v1:register(XMLValueType.VECTOR_2, v2 .. "#suspensionParametersZ", "Suspension parameters Z", "0 0")
	v1:register(XMLValueType.BOOL, v2 .. "#inverseMovement", "Invert movement", false)
	v1:register(XMLValueType.BOOL, v2 .. "#serverOnly", "Suspension is only calculated on server side", false)
	v1:register(XMLValueType.FLOAT, "vehicle.suspensions#maxUpdateDistance", "Max. distance to vehicle root to update suspension nodes", Suspensions.DEFAULT_MAX_UPDATE_DISTANCE)
	v1:setXMLSpecializationType()
end
function Suspensions.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "loadSuspensionNodeFromXML", Suspensions.loadSuspensionNodeFromXML)
	SpecializationUtil.registerFunction(p3, "getSuspensionNodeFromIndex", Suspensions.getSuspensionNodeFromIndex)
	SpecializationUtil.registerFunction(p3, "getIsSuspensionNodeActive", Suspensions.getIsSuspensionNodeActive)
	SpecializationUtil.registerFunction(p3, "setSuspensionNodeCharacter", Suspensions.setSuspensionNodeCharacter)
end
function Suspensions.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", Suspensions)
	SpecializationUtil.registerEventListener(p4, "onUpdate", Suspensions)
	SpecializationUtil.registerEventListener(p4, "onEnterVehicle", Suspensions)
	SpecializationUtil.registerEventListener(p4, "onVehicleCharacterChanged", Suspensions)
end
function Suspensions.onLoad(p5, _)
	if p5.isClient then
		local v6 = p5.spec_suspensions
		v6.suspensionNodes = {}
		for _, v7 in p5.xmlFile:iterator("vehicle.suspensions.suspension") do
			local v8 = {}
			if p5:loadSuspensionNodeFromXML(p5.xmlFile, v7, v8) and (not v8.serverOnly or p5.isServer) then
				local v9 = v6.suspensionNodes
				table.insert(v9, v8)
			end
		end
		v6.maxUpdateDistance = p5.xmlFile:getValue("vehicle.suspensions#maxUpdateDistance", Suspensions.DEFAULT_MAX_UPDATE_DISTANCE)
		if #v6.suspensionNodes > 0 then
			v6.suspensionAvailable = true
		end
		if not Platform.gameplay.allowSuspensionNodes and p5.xmlFile:hasProperty("vehicle.suspensions") then
			Logging.xmlWarning(p5.xmlFile, "Suspension nodes are not allowed on this platform")
			v6.suspensionAvailable = false
			v6.suspensionNodes = {}
		end
	end
	if not p5.spec_suspensions.suspensionAvailable then
		SpecializationUtil.removeEventListener(p5, "onUpdate", Suspensions)
		SpecializationUtil.removeEventListener(p5, "onEnterVehicle", Suspensions)
		SpecializationUtil.removeEventListener(p5, "onVehicleCharacterChanged", Suspensions)
	end
end
function Suspensions.onUpdate(p10, _, _, _, _)
	local v11 = p10.spec_suspensions
	if p10.currentUpdateDistance < v11.maxUpdateDistance then
		local v12 = 0.001 * g_physicsDt
		for _, v13 in ipairs(v11.suspensionNodes) do
			if v13.node == nil or not entityExists(v13.node) then
				if v13.node ~= nil then
					Logging.xmlError(p10.xmlFile, "Failed to update suspension node %d. Node does not exist anymore!", v13.node)
					v13.node = nil
				end
			else
				local v14 = v13.curAcc
				local v15 = v13.curAcc
				local v16 = v13.curAcc
				v14[1] = 0
				v15[2] = 0
				v16[3] = 0
				if p10:getIsSuspensionNodeActive(v13) then
					local v17 = localToWorld
					local v18 = v13.component
					local v19 = v13.refNodeOffset
					local v20, v21, v22 = v17(v18, unpack(v19))
					if v13.lastRefNodePosition == nil then
						v13.lastRefNodePosition = { v20, v21, v22 }
						v13.lastRefNodeVelocity = { 0, 0, 0 }
					end
					local v23 = v13.inverseMovement and -1 or 1
					local v24 = (v20 - v13.lastRefNodePosition[1]) / v12 * v23
					local v25 = (v21 - v13.lastRefNodePosition[2]) / v12 * v23
					local v26 = (v22 - v13.lastRefNodePosition[3]) / v12 * v23
					local v27 = v13.lastRefNodeVelocity
					local v28, v29, v30 = unpack(v27)
					local v31, v32, v33 = worldDirectionToLocal(getParent(v13.node), v24 - v28, v25 - v29, v26 - v30)
					local v34 = -v13.maxVelocityDifference
					local v35 = v13.maxVelocityDifference
					local v36 = math.clamp(v31, v34, v35)
					local v37 = -v13.maxVelocityDifference
					local v38 = v13.maxVelocityDifference
					local v39 = math.clamp(v32, v37, v38)
					local v40 = -v13.maxVelocityDifference
					local v41 = v13.maxVelocityDifference
					local v42 = math.clamp(v33, v40, v41)
					if v13.isRotational then
						if v13.useCharacterTorso then
							local v43 = v13.curAcc
							local v44 = v13.curAcc
							local v45 = v13.curAcc
							local v46, v47, v48 = MathUtil.crossProduct(v36 / v12, v39 / v12, v42 / v12, 1, 0, 0)
							v43[1] = v46
							v44[2] = v47
							v45[3] = v48
						else
							local v49 = v13.curAcc
							local v50 = v13.curAcc
							local v51 = v13.curAcc
							local v52, v53, v54 = MathUtil.crossProduct(v36 / v12, v39 / v12, v42 / v12, 0, 1, 0)
							v49[1] = v52
							v50[2] = v53
							v51[3] = v54
						end
					else
						local v55 = v13.curAcc
						local v56 = v13.curAcc
						local v57 = v13.curAcc
						local v58 = -v36 / v12
						local v59 = -v39 / v12
						local v60 = -v42 / v12
						v55[1] = v58
						v56[2] = v59
						v57[3] = v60
					end
					v13.lastRefNodePosition[1] = v20
					v13.lastRefNodePosition[2] = v21
					v13.lastRefNodePosition[3] = v22
					v13.lastRefNodeVelocity[1] = v24
					v13.lastRefNodeVelocity[2] = v25
					v13.lastRefNodeVelocity[3] = v26
				end
				for v61 = 1, 3 do
					local v62 = v13.suspensionParameters[v61]
					if v62[1] > 0 and v62[2] > 0 then
						local v63 = v13.weight * v13.curAcc[v61]
						local v64 = v62[1]
						local v65 = v62[2]
						if v13.isRotational then
							local v66 = v13.curRotation[v61]
							local v67 = v13.curRotationSpeed[v61]
							local v68 = v63 - v64 * v66 - v65 * v67
							local v69 = v13.weight
							local v70 = v66 + (v67 + v12 * (v68 + v12 * -v64 * v67) / v69 / (1 - (-v65 + v12 * -v64) * v12 / v69)) * v12
							local v71 = v13.minRotation[v61]
							local v72 = v13.maxRotation[v61]
							local v73 = math.clamp(v70, v71, v72)
							v13.curRotationSpeed[v61] = (v73 - v66) / v12
							v13.curRotation[v61] = v73
						else
							local v74 = v13.curTranslation[v61]
							local v75 = v13.curTranslationSpeed[v61]
							local v76 = v63 - v64 * v74 - v65 * v75
							local v77 = v13.weight
							local v78 = v74 + (v75 + v12 * (v76 + v12 * -v64 * v75) / v77 / (1 - (-v65 + v12 * -v64) * v12 / v77)) * v12
							local v79 = v13.minTranslation[v61]
							local v80 = v13.maxTranslation[v61]
							local v81 = math.clamp(v78, v79, v80)
							v13.curTranslationSpeed[v61] = (v81 - v74) / v12
							v13.curTranslation[v61] = v81
						end
					end
				end
				if v13.isRotational then
					setRotation(v13.node, v13.curRotation[1], v13.curRotation[2], v13.curRotation[3])
				elseif v13.minTranslation ~= nil then
					setTranslation(v13.node, v13.baseTranslation[1] + v13.curTranslation[1], v13.baseTranslation[2] + v13.curTranslation[2], v13.baseTranslation[3] + v13.curTranslation[3])
				end
				if p10.setMovingToolDirty ~= nil then
					p10:setMovingToolDirty(v13.node)
				end
			end
		end
	end
end
function Suspensions.loadSuspensionNodeFromXML(p82, p83, p84, p85)
	p85.node = p83:getValue(p84 .. "#node", nil, p82.components, p82.i3dMappings)
	if p85.node ~= nil then
		local v86 = p82:getParentComponent(p85.node)
		if v86 ~= nil then
			p85.component = v86
			p85.refNodeOffset = { localToLocal(p85.node, v86, 0, 0, 0) }
		end
	end
	p85.refNodeOffset = p85.refNodeOffset or { 0, 0, 0 }
	p85.useCharacterTorso = p83:getValue(p84 .. "#useCharacterTorso", false)
	if (p85.node == nil or p85.component == nil) and not p85.useCharacterTorso then
		return false
	end
	p85.weight = p83:getValue(p84 .. "#weight", 500)
	p85.minRotation = p83:getValue(p84 .. "#minRotation", nil, true)
	p85.maxRotation = p83:getValue(p84 .. "#maxRotation", nil, true)
	local v87
	if p85.minRotation == nil then
		v87 = false
	else
		v87 = p85.maxRotation ~= nil
	end
	p85.isRotational = v87
	if not (p85.isRotational or p85.useCharacterTorso) then
		p85.baseTranslation = { getTranslation(p85.node) }
		p85.startTranslationOffset = p83:getValue(p84 .. "#startTranslationOffset", "0 0 0", true)
		p85.baseTranslation[1] = p85.baseTranslation[1] + p85.startTranslationOffset[1]
		p85.baseTranslation[2] = p85.baseTranslation[2] + p85.startTranslationOffset[2]
		p85.baseTranslation[3] = p85.baseTranslation[3] + p85.startTranslationOffset[3]
		p85.minTranslation = p83:getValue(p84 .. "#minTranslation", nil, true)
		p85.maxTranslation = p83:getValue(p84 .. "#maxTranslation", nil, true)
		if p85.minTranslation == nil or p85.maxTranslation == nil then
			Logging.xmlWarning(p83, "suspension \'%s\' has neither rotational nor translational limits, ignoring", p84)
			return false
		end
	end
	p85.maxVelocityDifference = p83:getValue(p84 .. "#maxVelocityDifference", 0.1)
	local v88 = p83:getValue(p84 .. "#suspensionParametersX", "0 0", true)
	local v89 = p83:getValue(p84 .. "#suspensionParametersY", "0 0", true)
	local v90 = p83:getValue(p84 .. "#suspensionParametersZ", "0 0", true)
	p85.suspensionParameters = {}
	p85.suspensionParameters[1] = {}
	p85.suspensionParameters[2] = {}
	p85.suspensionParameters[3] = {}
	for v91 = 1, 2 do
		p85.suspensionParameters[1][v91] = v88[v91] * 1000
		p85.suspensionParameters[2][v91] = v89[v91] * 1000
		p85.suspensionParameters[3][v91] = v90[v91] * 1000
	end
	p85.inverseMovement = p83:getValue(p84 .. "#inverseMovement", false)
	p85.serverOnly = p83:getValue(p84 .. "#serverOnly", false)
	p85.lastRefNodePosition = nil
	p85.lastRefNodeVelocity = nil
	p85.curRotation = { 0, 0, 0 }
	p85.curRotationSpeed = { 0, 0, 0 }
	p85.curTranslation = { 0, 0, 0 }
	p85.curTranslationSpeed = { 0, 0, 0 }
	p85.curAcc = { 0, 0, 0 }
	return true
end
function Suspensions.getSuspensionNodeFromIndex(p92, p93)
	if p92.spec_suspensions.suspensionAvailable then
		return p92.spec_suspensions.suspensionNodes[p93]
	else
		return nil
	end
end
function Suspensions.getIsSuspensionNodeActive(_, p94)
	local v95
	if p94.node == nil then
		v95 = false
	else
		v95 = p94.component ~= nil
	end
	return v95
end
function Suspensions.setSuspensionNodeCharacter(p96, p97, p98)
	if p97.useCharacterTorso and p98.playerModel ~= nil then
		p97.node = p98.playerModel.thirdPersonSuspensionNode
		if p97.node ~= nil then
			local v99 = p96:getParentComponent(p97.node)
			if v99 ~= nil then
				p97.refNodeOffset = { localToLocal(p98.characterNode, v99, 0, 0, 0) }
				p97.component = v99
			end
		end
	end
end
function Suspensions.onEnterVehicle(p100, _)
	if p100.getVehicleCharacter ~= nil then
		local v101 = p100:getVehicleCharacter()
		if v101 ~= nil then
			local v102 = p100.spec_suspensions
			for _, v103 in ipairs(v102.suspensionNodes) do
				p100:setSuspensionNodeCharacter(v103, v101)
			end
		end
	end
end
function Suspensions.onVehicleCharacterChanged(p104, p105)
	local v106 = p104.spec_suspensions
	for _, v107 in ipairs(v106.suspensionNodes) do
		if v107.useCharacterTorso then
			if p105 == nil then
				v107.node = nil
			else
				p104:setSuspensionNodeCharacter(v107, p105)
			end
		end
	end
end
function Suspensions.subCollisionErrorFunction(p108, p109, p110)
	if getHasClassId(p108, ClassIds.SHAPE) then
		Logging.xmlError(p109, "Found collision \'%s\' as child of suspension node \'%s\'. This can cause the vehicle to never sleep!", getName(p108), p110)
	end
end
function Suspensions.getSuspensionModfier(p111)
	local v112 = p111.spec_suspensions
	local v113 = #v112.suspensionNodes >= 2 and not (v112.suspensionNodes[2].useCharacterTorso or v112.suspensionNodes[2].isRotational) and 2 or 1
	local v114 = v112.suspensionNodes[v113]
	return (v114 == nil or v114.isRotational) and 0 or v114.curTranslation[2]
end
g_soundManager:registerModifierType("SUSPENSION", Suspensions.getSuspensionModfier)

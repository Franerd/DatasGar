source("dataS/scripts/vehicles/specializations/events/SprayerDoubledAmountEvent.lua")
Sprayer = {}
Sprayer.SPRAY_TYPE_XML_KEY = "vehicle.sprayer.sprayTypes.sprayType(?)"
Sprayer.AI_REQUIRED_GROUND_TYPES = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.CULTIVATED,
	FieldGroundType.SEEDBED,
	FieldGroundType.PLOWED,
	FieldGroundType.ROLLED_SEEDBED,
	FieldGroundType.RIDGE,
	FieldGroundType.SOWN,
	FieldGroundType.DIRECT_SOWN,
	FieldGroundType.PLANTED,
	FieldGroundType.RIDGE_SOWN,
	FieldGroundType.ROLLER_LINES,
	FieldGroundType.HARVEST_READY,
	FieldGroundType.HARVEST_READY_OTHER,
	FieldGroundType.GRASS,
	FieldGroundType.GRASS_CUT
}
function Sprayer.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("sprayer", false, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Sprayer")
	v1:register(XMLValueType.BOOL, "vehicle.sprayer#allowsSpraying", "Allows spraying", true)
	v1:register(XMLValueType.BOOL, "vehicle.sprayer#activateTankOnLowering", "Activate tank on lowering", false)
	v1:register(XMLValueType.BOOL, "vehicle.sprayer#activateOnLowering", "Activate on lowering", false)
	v1:register(XMLValueType.FLOAT, "vehicle.sprayer.usageScales#scale", "Usage scale", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.sprayer.usageScales#workingWidth", "Working width", 12)
	v1:register(XMLValueType.INT, "vehicle.sprayer.usageScales#workAreaIndex", "Work area that is used for working width reference instead of #workingWidth")
	v1:register(XMLValueType.STRING, "vehicle.sprayer.usageScales.sprayUsageScale(?)#fillType", "Fill type name")
	v1:register(XMLValueType.FLOAT, "vehicle.sprayer.usageScales.sprayUsageScale(?)#scale", "Scale")
	v1:register(XMLValueType.INT, Sprayer.SPRAY_TYPE_XML_KEY .. "#fillUnitIndex", "Fill unit index")
	v1:register(XMLValueType.INT, Sprayer.SPRAY_TYPE_XML_KEY .. "#unloadInfoIndex", "Unload info index")
	v1:register(XMLValueType.INT, Sprayer.SPRAY_TYPE_XML_KEY .. "#fillVolumeIndex", "Fill volume index")
	SoundManager.registerSampleXMLPaths(v1, Sprayer.SPRAY_TYPE_XML_KEY .. ".sounds", "work")
	SoundManager.registerSampleXMLPaths(v1, Sprayer.SPRAY_TYPE_XML_KEY .. ".sounds", "spray")
	AnimationManager.registerAnimationNodesXMLPaths(v1, Sprayer.SPRAY_TYPE_XML_KEY .. ".animationNodes")
	EffectManager.registerEffectXMLPaths(v1, Sprayer.SPRAY_TYPE_XML_KEY .. ".effects")
	v1:register(XMLValueType.STRING, Sprayer.SPRAY_TYPE_XML_KEY .. ".turnedAnimation#name", "Turned animation name")
	v1:register(XMLValueType.FLOAT, Sprayer.SPRAY_TYPE_XML_KEY .. ".turnedAnimation#turnOnSpeedScale", "Speed Scale while turned on", 1)
	v1:register(XMLValueType.FLOAT, Sprayer.SPRAY_TYPE_XML_KEY .. ".turnedAnimation#turnOffSpeedScale", "Speed Scale while turned off", "Inversed #turnOnSpeedScale")
	v1:register(XMLValueType.BOOL, Sprayer.SPRAY_TYPE_XML_KEY .. ".turnedAnimation#externalFill", "Animation is played while sprayer is externally filled", true)
	AIImplement.registerAIImplementBaseXMLPaths(v1, Sprayer.SPRAY_TYPE_XML_KEY .. ".ai")
	v1:register(XMLValueType.STRING, Sprayer.SPRAY_TYPE_XML_KEY .. "#fillTypes", "Fill types")
	v1:register(XMLValueType.FLOAT, Sprayer.SPRAY_TYPE_XML_KEY .. ".usageScales#workingWidth", "Work width", 12)
	v1:register(XMLValueType.INT, Sprayer.SPRAY_TYPE_XML_KEY .. ".usageScales#workAreaIndex", "Work area that is used for working width reference instead of #workingWidth")
	ObjectChangeUtil.registerObjectChangeXMLPaths(v1, Sprayer.SPRAY_TYPE_XML_KEY)
	EffectManager.registerEffectXMLPaths(v1, "vehicle.sprayer.effects")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.sprayer.sounds", "work")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.sprayer.sounds", "spray")
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.sprayer.animationNodes")
	v1:register(XMLValueType.STRING, "vehicle.sprayer.animation#name", "Spray animation name")
	v1:register(XMLValueType.INT, "vehicle.sprayer#fillUnitIndex", "Fill unit index", 1)
	v1:register(XMLValueType.INT, "vehicle.sprayer#unloadInfoIndex", "Unload info index", 1)
	v1:register(XMLValueType.INT, "vehicle.sprayer#fillVolumeIndex", "Fill volume index")
	v1:register(XMLValueType.VECTOR_3, "vehicle.sprayer#fillVolumeDischargeScrollSpeed", "Fill volume discharge scroll speed", "0 0 0")
	v1:register(XMLValueType.FLOAT, "vehicle.sprayer.doubledAmount#decreasedSpeed", "Speed while doubled amount is sprayed", "automatically calculated")
	v1:register(XMLValueType.FLOAT, "vehicle.sprayer.doubledAmount#decreaseFactor", "Decrease factor that is applied on speedLimit while doubled amount is sprayed", 0.5)
	v1:register(XMLValueType.STRING, "vehicle.sprayer.doubledAmount#toggleButton", "Name of input action to toggle doubled amount", "IMPLEMENT_EXTRA4")
	v1:register(XMLValueType.L10N_STRING, "vehicle.sprayer.doubledAmount#deactivateText", "Deactivated text", "action_deactivateDoubledSprayAmount")
	v1:register(XMLValueType.L10N_STRING, "vehicle.sprayer.doubledAmount#activateText", "Activate text", "action_activateDoubledSprayAmount")
	v1:register(XMLValueType.STRING, "vehicle.sprayer.turnedAnimation#name", "Turned animation name")
	v1:register(XMLValueType.FLOAT, "vehicle.sprayer.turnedAnimation#turnOnSpeedScale", "Speed Scale while turned on", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.sprayer.turnedAnimation#turnOffSpeedScale", "Speed Scale while turned off", "Inversed #turnOnSpeedScale")
	v1:register(XMLValueType.BOOL, "vehicle.sprayer.turnedAnimation#externalFill", "Animation is played while sprayer is externally filled", true)
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. "#sprayType", "Spray type index")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. "#sprayType", "Spray type index")
	v1:setXMLSpecializationType()
end
function Sprayer.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(FillUnit, p2) and SpecializationUtil.hasSpecialization(WorkArea, p2)
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p2)
	end
	return v3
end
function Sprayer.registerEvents(p4)
	SpecializationUtil.registerEvent(p4, "onSprayTypeChange")
end
function Sprayer.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "processSprayerArea", Sprayer.processSprayerArea)
	SpecializationUtil.registerFunction(p5, "getIsSprayerExternallyFilled", Sprayer.getIsSprayerExternallyFilled)
	SpecializationUtil.registerFunction(p5, "getExternalFill", Sprayer.getExternalFill)
	SpecializationUtil.registerFunction(p5, "getAreEffectsVisible", Sprayer.getAreEffectsVisible)
	SpecializationUtil.registerFunction(p5, "updateSprayerEffects", Sprayer.updateSprayerEffects)
	SpecializationUtil.registerFunction(p5, "getSprayerUsage", Sprayer.getSprayerUsage)
	SpecializationUtil.registerFunction(p5, "getUseSprayerAIRequirements", Sprayer.getUseSprayerAIRequirements)
	SpecializationUtil.registerFunction(p5, "setSprayerAITerrainDetailProhibitedRange", Sprayer.setSprayerAITerrainDetailProhibitedRange)
	SpecializationUtil.registerFunction(p5, "getSprayerFillUnitIndex", Sprayer.getSprayerFillUnitIndex)
	SpecializationUtil.registerFunction(p5, "loadSprayTypeFromXML", Sprayer.loadSprayTypeFromXML)
	SpecializationUtil.registerFunction(p5, "getActiveSprayType", Sprayer.getActiveSprayType)
	SpecializationUtil.registerFunction(p5, "getIsSprayTypeActive", Sprayer.getIsSprayTypeActive)
	SpecializationUtil.registerFunction(p5, "setSprayerDoubledAmountActive", Sprayer.setSprayerDoubledAmountActive)
	SpecializationUtil.registerFunction(p5, "getSprayerDoubledAmountActive", Sprayer.getSprayerDoubledAmountActive)
end
function Sprayer.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDrawFirstFillText", Sprayer.getDrawFirstFillText)
	SpecializationUtil.registerOverwrittenFunction(p6, "getAreControlledActionsAllowed", Sprayer.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanToggleTurnedOn", Sprayer.getCanToggleTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanBeTurnedOn", Sprayer.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p6, "loadWorkAreaFromXML", Sprayer.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsWorkAreaActive", Sprayer.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p6, "doCheckSpeedLimit", Sprayer.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p6, "getRawSpeedLimit", Sprayer.getRawSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFillVolumeUVScrollSpeed", Sprayer.getFillVolumeUVScrollSpeed)
	SpecializationUtil.registerOverwrittenFunction(p6, "getAIRequiresTurnOffOnHeadland", Sprayer.getAIRequiresTurnOffOnHeadland)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDirtMultiplier", Sprayer.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getWearMultiplier", Sprayer.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getEffectByNode", Sprayer.getEffectByNode)
	SpecializationUtil.registerOverwrittenFunction(p6, "getVariableWorkWidthUsage", Sprayer.getVariableWorkWidthUsage)
	SpecializationUtil.registerOverwrittenFunction(p6, "getAIImplementUseVineSegment", Sprayer.getAIImplementUseVineSegment)
end
function Sprayer.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onDelete", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onUpdateTick", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onRegisterActionEvents", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onTurnedOn", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onTurnedOff", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onPreDetach", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onStartWorkAreaProcessing", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onEndWorkAreaProcessing", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onStateChange", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onSetLowered", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onFillUnitFillLevelChanged", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onSprayTypeChange", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onAIImplementEnd", Sprayer)
	SpecializationUtil.registerEventListener(p7, "onVariableWorkWidthSectionChanged", Sprayer)
end
function Sprayer.onLoad(p8, _)
	local v9 = p8.spec_sprayer
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.sprayParticles.emitterShape", "vehicle.sprayer.effects.effectNode#effectClass=\'ParticleEffect\'")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.sprayer#needsTankActivation")
	v9.allowsSpraying = p8.xmlFile:getValue("vehicle.sprayer#allowsSpraying", true)
	v9.activateTankOnLowering = p8.xmlFile:getValue("vehicle.sprayer#activateTankOnLowering", false)
	v9.activateOnLowering = p8.xmlFile:getValue("vehicle.sprayer#activateOnLowering", false)
	v9.usageScale = {}
	v9.usageScale.default = p8.xmlFile:getValue("vehicle.sprayer.usageScales#scale", 1)
	v9.usageScale.workingWidth = p8.xmlFile:getValue("vehicle.sprayer.usageScales#workingWidth", 12)
	v9.usageScale.workAreaIndex = p8.xmlFile:getValue("vehicle.sprayer.usageScales#workAreaIndex")
	v9.usageScale.fillTypeScales = {}
	local v10 = 0
	while true do
		local v11 = string.format("vehicle.sprayer.usageScales.sprayUsageScale(%d)", v10)
		if not p8.xmlFile:hasProperty(v11) then
			break
		end
		local v12 = p8.xmlFile:getValue(v11 .. "#fillType")
		local v13 = p8.xmlFile:getValue(v11 .. "#scale")
		if v12 ~= nil and v13 ~= nil then
			local v14 = g_fillTypeManager:getFillTypeIndexByName(v12)
			if v14 == nil then
				printWarning("Warning: Invalid spray usage scale fill type \'" .. v12 .. "\' in \'" .. p8.configFileName .. "\'")
			else
				v9.usageScale.fillTypeScales[v14] = v13
			end
		end
		v10 = v10 + 1
	end
	v9.sprayTypes = {}
	local v15 = 0
	while true do
		local v16 = string.format("vehicle.sprayer.sprayTypes.sprayType(%d)", v15)
		if not p8.xmlFile:hasProperty(v16) then
			break
		end
		local v17 = {}
		if p8:loadSprayTypeFromXML(p8.xmlFile, v16, v17) then
			local v18 = v9.sprayTypes
			table.insert(v18, v17)
			v17.index = #v9.sprayTypes
		end
		v15 = v15 + 1
	end
	v9.lastActiveSprayType = nil
	if p8.isClient then
		v9.effects = g_effectManager:loadEffect(p8.xmlFile, "vehicle.sprayer.effects", p8.components, p8, p8.i3dMappings)
		v9.animationName = p8.xmlFile:getValue("vehicle.sprayer.animation#name", "")
		v9.samples = {}
		v9.samples.work = g_soundManager:loadSampleFromXML(p8.xmlFile, "vehicle.sprayer.sounds", "work", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v9.samples.spray = g_soundManager:loadSampleFromXML(p8.xmlFile, "vehicle.sprayer.sounds", "spray", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v9.sampleFillEnabled = false
		v9.sampleFillStopTime = -1
		v9.lastFillLevel = -1
		v9.animationNodes = g_animationManager:loadAnimations(p8.xmlFile, "vehicle.sprayer.animationNodes", p8.components, p8, p8.i3dMappings)
	end
	if p8.addAIGroundTypeRequirements ~= nil then
		p8:addAIGroundTypeRequirements(Sprayer.AI_REQUIRED_GROUND_TYPES)
	end
	v9.supportedSprayTypes = {}
	v9.fillUnitIndex = p8.xmlFile:getValue("vehicle.sprayer#fillUnitIndex", 1)
	v9.unloadInfoIndex = p8.xmlFile:getValue("vehicle.sprayer#unloadInfoIndex", 1)
	v9.fillVolumeIndex = p8.xmlFile:getValue("vehicle.sprayer#fillVolumeIndex")
	v9.dischargeUVScrollSpeed = p8.xmlFile:getValue("vehicle.sprayer#fillVolumeDischargeScrollSpeed", "0 0 0", true)
	if p8:getFillUnitByIndex(v9.fillUnitIndex) == nil then
		Logging.xmlError(p8.xmlFile, "FillUnit \'%d\' not defined!", v9.fillUnitIndex)
		p8:setLoadingState(VehicleLoadingState.ERROR)
	else
		local v19 = p8.xmlFile:getValue("vehicle.sprayer.doubledAmount#decreasedSpeed")
		if v19 == nil then
			local v20 = p8.xmlFile:getValue("vehicle.sprayer.doubledAmount#decreaseFactor", 0.5)
			v19 = p8:getSpeedLimit() * v20
		end
		v9.doubledAmountSpeed = v19
		v9.doubledAmountIsActive = false
		local v21 = p8.xmlFile:getValue("vehicle.sprayer.doubledAmount#toggleButton")
		if v21 ~= nil then
			v9.toggleDoubledAmountInputBinding = InputAction[v21]
		end
		v9.toggleDoubledAmountInputBinding = v9.toggleDoubledAmountInputBinding or InputAction.DOUBLED_SPRAY_AMOUNT
		v9.doubledAmountDeactivateText = p8.xmlFile:getValue("vehicle.sprayer.doubledAmount#deactivateText", "action_deactivateDoubledSprayAmount", p8.customEnvironment)
		v9.doubledAmountActivateText = p8.xmlFile:getValue("vehicle.sprayer.doubledAmount#activateText", "action_activateDoubledSprayAmount", p8.customEnvironment)
		v9.turnedAnimation = p8.xmlFile:getValue("vehicle.sprayer.turnedAnimation#name", "")
		v9.turnedAnimationTurnOnSpeedScale = p8.xmlFile:getValue("vehicle.sprayer.turnedAnimation#turnOnSpeedScale", 1)
		v9.turnedAnimationTurnOffSpeedScale = p8.xmlFile:getValue("vehicle.sprayer.turnedAnimation#turnOffSpeedScale", -v9.turnedAnimationTurnOnSpeedScale)
		v9.turnedAnimationExternalFill = p8.xmlFile:getValue("vehicle.sprayer.turnedAnimation#externalFill", true)
		v9.needsToBeFilledToTurnOn = true
		v9.useSpeedLimit = true
		v9.isWorking = false
		v9.lastEffectsState = false
		v9.isSlurryTanker = p8:getFillUnitAllowsFillType(p8:getSprayerFillUnitIndex(), FillType.LIQUIDMANURE) or p8:getFillUnitAllowsFillType(p8:getSprayerFillUnitIndex(), FillType.DIGESTATE)
		v9.isManureSpreader = p8:getFillUnitAllowsFillType(p8:getSprayerFillUnitIndex(), FillType.MANURE)
		local v22 = not v9.isSlurryTanker
		if v22 then
			v22 = not v9.isManureSpreader
		end
		v9.isFertilizerSprayer = v22
		v9.workAreaParameters = {}
		v9.workAreaParameters.sprayVehicle = nil
		v9.workAreaParameters.sprayVehicleFillUnitIndex = nil
		v9.workAreaParameters.lastChangedArea = 0
		v9.workAreaParameters.lastTotalArea = 0
		v9.workAreaParameters.lastIsExternallyFilled = false
		v9.workAreaParameters.lastSprayTime = (-1 / 0)
		v9.workAreaParameters.usage = 0
		v9.workAreaParameters.usagePerMin = 0
	end
end
function Sprayer.onDelete(p23)
	local v24 = p23.spec_sprayer
	g_effectManager:deleteEffects(v24.effects)
	g_soundManager:deleteSamples(v24.samples)
	g_animationManager:deleteAnimations(v24.animationNodes)
	if v24.sprayTypes ~= nil then
		for _, v25 in ipairs(v24.sprayTypes) do
			g_effectManager:deleteEffects(v25.effects)
			g_soundManager:deleteSamples(v25.samples)
			g_animationManager:deleteAnimations(v25.animationNodes)
		end
	end
end
function Sprayer.onUpdateTick(p26, _, _, _, _)
	local v27 = p26:getActiveSprayType()
	if v27 ~= nil then
		local v28 = p26.spec_sprayer
		if v27 ~= v28.lastActiveSprayType then
			for _, v29 in ipairs(v28.sprayTypes) do
				if v29 == v28.lastActiveSprayType then
					g_effectManager:stopEffects(v29.effects)
					g_animationManager:stopAnimations(v29.animationNodes)
				end
			end
			SpecializationUtil.raiseEvent(p26, "onSprayTypeChange", v27)
			v28.lastActiveSprayType = v27
			p26:updateSprayerEffects(true)
		end
	end
	if p26.isClient then
		local v30 = p26.spec_sprayer
		local v31 = v30.actionEvents[v30.toggleDoubledAmountInputBinding]
		if v31 ~= nil then
			local v32
			if v30.doubledAmountIsActive then
				v32 = v30.doubledAmountDeactivateText
			else
				v32 = v30.doubledAmountActivateText
			end
			g_inputBinding:setActionEventText(v31.actionEventId, v32)
			local _, v33 = p26:getSprayerDoubledAmountActive(v30.workAreaParameters.sprayType)
			g_inputBinding:setActionEventActive(v31.actionEventId, v33)
		end
	end
	if p26.isServer then
		local v34 = p26.spec_sprayer
		if v34.pendingActivationAfterLowering and p26:getCanBeTurnedOn() then
			p26:setIsTurnedOn(true)
			v34.pendingActivationAfterLowering = false
		end
	end
end
function Sprayer.onRegisterActionEvents(p35, _, p36)
	if p35.isClient then
		local v37 = p35.spec_sprayer
		p35:clearActionEventsTable(v37.actionEvents)
		if p36 then
			local _, v38 = p35:addActionEvent(v37.actionEvents, v37.toggleDoubledAmountInputBinding, p35, Sprayer.actionEventDoubledAmount, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v38, GS_PRIO_HIGH)
		end
	end
end
function Sprayer.actionEventDoubledAmount(p39, _, _, _, _)
	p39:setSprayerDoubledAmountActive(not p39.spec_sprayer.doubledAmountIsActive)
end
function Sprayer.processSprayerArea(p40, p41, _)
	local v42 = p40.spec_sprayer
	if p40:getIsAIActive() and (p40.isServer and (v42.workAreaParameters.sprayFillType == nil or v42.workAreaParameters.sprayFillType == FillType.UNKNOWN)) then
		p40.rootVehicle:stopCurrentAIJob(AIMessageErrorOutOfFill.new())
		return 0, 0
	end
	if v42.workAreaParameters.sprayFillLevel <= 0 then
		return 0, 0
	end
	local v43, _, v44 = getWorldTranslation(p41.start)
	local v45, _, v46 = getWorldTranslation(p41.width)
	local v47, _, v48 = getWorldTranslation(p41.height)
	local v49 = p40:getSprayerDoubledAmountActive(v42.workAreaParameters.sprayType) and 2 or 1
	local v50, v51 = FSDensityMapUtil.updateSprayArea(v43, v44, v45, v46, v47, v48, v42.workAreaParameters.sprayType, v49)
	v42.workAreaParameters.isActive = true
	v42.workAreaParameters.lastChangedArea = v42.workAreaParameters.lastChangedArea + v50
	v42.workAreaParameters.lastStatsArea = v42.workAreaParameters.lastStatsArea + v50
	v42.workAreaParameters.lastTotalArea = v42.workAreaParameters.lastTotalArea + v51
	v42.workAreaParameters.lastSprayTime = g_time
	if p40:getLastSpeed() > 1 then
		v42.isWorking = true
	end
	return v50, v51
end
function Sprayer.getIsSprayerExternallyFilled(p52)
	if not p52:getIsAIActive() then
		return false
	end
	if p52:getFillUnitCapacity(p52:getSprayerFillUnitIndex()) == 0 then
		local v53 = p52.spec_sprayer
		local v54 = false
		for _, v55 in ipairs(v53.supportedSprayTypes) do
			if #v53.fillTypeSources[v55] > 0 then
				v54 = true
				break
			end
		end
		if not v54 then
			return false
		end
	end
	if p52.rootVehicle.getIsFieldWorkActive == nil or not p52.rootVehicle:getIsFieldWorkActive() then
		return false
	end
	local v56 = p52.spec_sprayer
	local v57 = ((not v56.isSlurryTanker or g_currentMission.missionInfo.helperSlurrySource <= 1) and true or false) and (((not v56.isManureSpreader or g_currentMission.missionInfo.helperManureSource <= 1) and true or false) and v56.isFertilizerSprayer)
	if v57 then
		v57 = g_currentMission.missionInfo.helperBuyFertilizer
	end
	return v57
end
function Sprayer.getExternalFill(p58, p59, p60)
	local v61 = false
	local v62 = p59 == FillType.UNKNOWN
	local v63 = p58:getFillUnitAllowsFillType(p58:getSprayerFillUnitIndex(), FillType.LIQUIDMANURE)
	local v64 = p58:getFillUnitAllowsFillType(p58:getSprayerFillUnitIndex(), FillType.DIGESTATE)
	local v65 = p58:getFillUnitAllowsFillType(p58:getSprayerFillUnitIndex(), FillType.MANURE)
	local v66 = p58:getFillUnitAllowsFillType(p58:getSprayerFillUnitIndex(), FillType.LIQUIDFERTILIZER)
	local v67 = p58:getFillUnitAllowsFillType(p58:getSprayerFillUnitIndex(), FillType.FERTILIZER)
	local v68 = p58:getFillUnitAllowsFillType(p58:getSprayerFillUnitIndex(), FillType.HERBICIDE)
	local v69 = 0
	local v70 = p58:getActiveFarm()
	local v71 = p58:getLastTouchedFarmlandFarmId()
	if p59 == FillType.LIQUIDMANURE or (p59 == FillType.DIGESTATE or v62 and (v63 or v64)) then
		if g_currentMission.missionInfo.helperSlurrySource == 2 then
			v61 = true
			if g_currentMission.economyManager:getCostPerLiter(FillType.LIQUIDMANURE, false) then
				p59 = FillType.LIQUIDMANURE
			else
				p59 = FillType.DIGESTATE
			end
			v69 = p58:getSprayerUsage(p59, p60)
			if p58.isServer then
				local v72 = v69 * g_currentMission.economyManager:getCostPerLiter(p59, false) * 1.5
				g_farmManager:updateFarmStats(v71, "expenses", v72)
				g_currentMission:addMoney(-v72, v70, MoneyType.PURCHASE_FERTILIZER)
			end
		elseif g_currentMission.missionInfo.helperSlurrySource > 2 then
			local v73 = g_currentMission.liquidManureLoadingStations[g_currentMission.missionInfo.helperSlurrySource - 2]
			if p58.isServer and v73 ~= nil then
				v69 = p58:getSprayerUsage(FillType.LIQUIDMANURE, p60)
				if v69 - v73:removeFillLevel(FillType.LIQUIDMANURE, v69, v70 or p58:getOwnerFarmId()) > 1e-6 then
					p59 = FillType.LIQUIDMANURE
					v61 = true
				elseif v69 - v73:removeFillLevel(FillType.DIGESTATE, v69, v70 or p58:getOwnerFarmId()) > 1e-6 then
					p59 = FillType.DIGESTATE
					v61 = true
				end
			end
		end
	elseif p59 == FillType.MANURE or p59 == FillType.UNKNOWN and v65 then
		if g_currentMission.missionInfo.helperManureSource == 2 then
			v61 = true
			p59 = FillType.MANURE
			v69 = p58:getSprayerUsage(p59, p60)
			if p58.isServer then
				local v74 = v69 * g_currentMission.economyManager:getCostPerLiter(p59, false) * 1.5
				g_farmManager:updateFarmStats(v71, "expenses", v74)
				g_currentMission:addMoney(-v74, v70, MoneyType.PURCHASE_FERTILIZER)
			end
		elseif g_currentMission.missionInfo.helperManureSource > 2 then
			local v75 = g_currentMission.manureLoadingStations[g_currentMission.missionInfo.helperManureSource - 2]
			if p58.isServer and v75 ~= nil then
				v69 = p58:getSprayerUsage(FillType.MANURE, p60)
				if v69 - v75:removeFillLevel(FillType.MANURE, v69, v70 or p58:getOwnerFarmId()) > 1e-6 then
					p59 = FillType.MANURE
					v61 = true
				end
			end
		end
	elseif (p59 == FillType.FERTILIZER or (p59 == FillType.LIQUIDFERTILIZER or (p59 == FillType.HERBICIDE or (p59 == FillType.LIME or p59 == FillType.UNKNOWN and (v66 or (v67 or v68)))))) and g_currentMission.missionInfo.helperBuyFertilizer then
		v61 = true
		if p59 == FillType.UNKNOWN then
			if v66 then
				p59 = FillType.LIQUIDFERTILIZER
			elseif v67 then
				p59 = FillType.FERTILIZER
			elseif v68 then
				p59 = FillType.HERBICIDE
			end
		end
		v69 = p58:getSprayerUsage(p59, p60)
		if p58.isServer then
			local v76 = v69 * g_currentMission.economyManager:getCostPerLiter(p59, false) * 1.5
			g_farmManager:updateFarmStats(v71, "expenses", v76)
			g_currentMission:addMoney(-v76, v70, MoneyType.PURCHASE_FERTILIZER)
		end
	end
	if v61 then
		return p59, v69
	else
		return FillType.UNKNOWN, 0
	end
end
function Sprayer.getAreEffectsVisible(p77)
	return p77.spec_sprayer.workAreaParameters.lastSprayTime + 100 > g_time
end
function Sprayer.updateSprayerEffects(p78, p79)
	local v80 = p78.spec_sprayer
	local v81 = p78:getAreEffectsVisible()
	if v81 ~= v80.lastEffectsState or p79 then
		if v81 then
			local v82 = p78:getFillUnitLastValidFillType(p78:getSprayerFillUnitIndex())
			if v82 == FillType.UNKNOWN then
				v82 = p78:getFillUnitFirstSupportedFillType(p78:getSprayerFillUnitIndex())
			end
			g_effectManager:setEffectTypeInfo(v80.effects, v82)
			g_effectManager:startEffects(v80.effects)
			g_soundManager:playSample(v80.samples.spray)
			local v83 = p78:getActiveSprayType()
			if v83 ~= nil then
				g_effectManager:setEffectTypeInfo(v83.effects, v82)
				g_effectManager:startEffects(v83.effects)
				g_animationManager:startAnimations(v83.animationNodes)
				g_soundManager:playSample(v83.samples.spray)
			end
			g_animationManager:startAnimations(v80.animationNodes)
		else
			g_effectManager:stopEffects(v80.effects)
			g_animationManager:stopAnimations(v80.animationNodes)
			g_soundManager:stopSample(v80.samples.spray)
			for _, v84 in ipairs(v80.sprayTypes) do
				g_effectManager:stopEffects(v84.effects)
				g_animationManager:stopAnimations(v84.animationNodes)
				g_soundManager:stopSample(v84.samples.spray)
			end
		end
		v80.lastEffectsState = v81
	end
end
function Sprayer.getSprayerUsage(p85, p86, p87)
	if p86 == FillType.UNKNOWN then
		return 0
	end
	local v88 = p85.spec_sprayer
	local v89 = Utils.getNoNil(v88.usageScale.fillTypeScales[p86], v88.usageScale.default)
	local v90 = g_sprayTypeManager:getSprayTypeByFillTypeIndex(p86)
	local v91 = v90 == nil and 1 or v90.litersPerSecond
	local v92 = v88.usageScale
	local v93 = p85:getActiveSprayType()
	if v93 ~= nil then
		v92 = v93.usageScale
	end
	local v94
	if v92.workAreaIndex == nil then
		v94 = v92.workingWidth
	else
		v94 = p85:getWorkAreaWidth(v92.workAreaIndex)
	end
	return v89 * v91 * p85.speedLimit * v94 * p87 * 0.001
end
function Sprayer.getUseSprayerAIRequirements(_)
	return true
end
function Sprayer.setSprayerAITerrainDetailProhibitedRange(p95, p96)
	if p95:getUseSprayerAIRequirements() and p95.addAITerrainDetailProhibitedRange ~= nil then
		p95:clearAITerrainDetailProhibitedRange()
		p95:clearAIFruitRequirements()
		p95:clearAIFruitProhibitions()
		p95:addAIGroundTypeRequirements(Sprayer.AI_REQUIRED_GROUND_TYPES)
		local v97 = g_sprayTypeManager:getSprayTypeByFillTypeIndex(p96)
		if v97 ~= nil then
			if v97.isHerbicide then
				local v98 = g_currentMission.weedSystem
				if v98 ~= nil then
					local v99, v100, v101 = v98:getDensityMapData()
					local v102 = v98:getHerbicideReplacements()
					if v102.weed ~= nil then
						local v103 = -1
						local v104 = -1
						for v105, _ in pairs(v102.weed.replacements) do
							if v103 == -1 then
								v103 = v105
							elseif v105 ~= v104 + 1 then
								p95:addAIFruitRequirement(nil, v103, v104, v99, v100, v101)
								v103 = v105
							end
							v104 = v105
						end
						if v103 ~= -1 then
							p95:addAIFruitRequirement(nil, v103, v104, v99, v100, v101)
						end
					end
				end
			else
				local v106 = g_currentMission
				local v107, v108, v109 = v106.fieldGroundSystem:getDensityMapData(FieldDensityMap.SPRAY_TYPE)
				local v110, v111, v112 = v106.fieldGroundSystem:getDensityMapData(FieldDensityMap.SPRAY_LEVEL)
				local v113 = v106.fieldGroundSystem:getMaxValue(FieldDensityMap.SPRAY_LEVEL)
				p95:addAIFruitProhibitions(0, v97.sprayGroundType, v97.sprayGroundType, v107, v108, v109)
				p95:addAIFruitProhibitions(0, v113, v113, v110, v111, v112)
			end
			if v97.isHerbicide or v97.isFertilizer then
				for _, v114 in pairs(g_fruitTypeManager:getFruitTypes()) do
					if v114.terrainDataPlaneId ~= nil and (v114.name:lower() ~= "grass" and (v114.minHarvestingGrowthState ~= nil and v114.maxHarvestingGrowthState ~= nil)) then
						p95:addAIFruitProhibitions(v114.index, v114.minHarvestingGrowthState, v114.maxHarvestingGrowthState)
					end
				end
			end
		end
	end
end
function Sprayer.getSprayerFillUnitIndex(p115)
	local v116 = p115:getActiveSprayType()
	if v116 == nil then
		return p115.spec_sprayer.fillUnitIndex
	else
		return v116.fillUnitIndex
	end
end
function Sprayer.loadSprayTypeFromXML(p_u_117, p118, p119, p_u_120)
	p_u_120.fillUnitIndex = p118:getValue(p119 .. "#fillUnitIndex", 1)
	p_u_120.unloadInfoIndex = p118:getValue(p119 .. "#unloadInfoIndex", 1)
	p_u_120.fillVolumeIndex = p118:getValue(p119 .. "#fillVolumeIndex")
	p_u_120.samples = {}
	p_u_120.samples.work = g_soundManager:loadSampleFromXML(p118, p119 .. ".sounds", "work", p_u_117.baseDirectory, p_u_117.components, 0, AudioGroup.VEHICLE, p_u_117.i3dMappings, p_u_117)
	p_u_120.samples.spray = g_soundManager:loadSampleFromXML(p118, p119 .. ".sounds", "spray", p_u_117.baseDirectory, p_u_117.components, 0, AudioGroup.VEHICLE, p_u_117.i3dMappings, p_u_117)
	p_u_120.effects = g_effectManager:loadEffect(p118, p119 .. ".effects", p_u_117.components, p_u_117, p_u_117.i3dMappings)
	p_u_120.animationNodes = g_animationManager:loadAnimations(p118, p119 .. ".animationNodes", p_u_117.components, p_u_117, p_u_117.i3dMappings)
	p_u_120.turnedAnimation = p118:getValue(p119 .. ".turnedAnimation#name", "")
	p_u_120.turnedAnimationTurnOnSpeedScale = p118:getValue(p119 .. ".turnedAnimation#turnOnSpeedScale", 1)
	p_u_120.turnedAnimationTurnOffSpeedScale = p118:getValue(p119 .. ".turnedAnimation#turnOffSpeedScale", -p_u_120.turnedAnimationTurnOnSpeedScale)
	p_u_120.turnedAnimationExternalFill = p118:getValue(p119 .. ".turnedAnimation#externalFill", true)
	if p_u_117.loadAIImplementBaseSetupFromXML ~= nil then
		p_u_117:loadAIImplementBaseSetupFromXML(p118, p119 .. ".ai", function(_)
			-- upvalues: (copy) p_u_117, (copy) p_u_120
			return p_u_117:getIsSprayTypeActive(p_u_120)
		end)
	end
	local v121 = p118:getValue(p119 .. "#fillTypes")
	if v121 ~= nil then
		p_u_120.fillTypes = v121:split(" ")
	end
	p_u_120.objectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p118, p119, p_u_120.objectChanges, p_u_117.components, p_u_117)
	ObjectChangeUtil.setObjectChanges(p_u_120.objectChanges, false, p_u_117, p_u_117.setMovingToolDirty)
	p_u_120.usageScale = {}
	p_u_120.usageScale.workingWidth = p118:getValue(p119 .. ".usageScales#workingWidth", 12)
	p_u_120.usageScale.workAreaIndex = p118:getValue(p119 .. ".usageScales#workAreaIndex")
	return true
end
function Sprayer.getActiveSprayType(p122)
	local v123 = p122.spec_sprayer
	for _, v124 in ipairs(v123.sprayTypes) do
		if p122:getIsSprayTypeActive(v124) then
			return v124
		end
	end
	return nil
end
function Sprayer.getIsSprayTypeActive(p125, p126)
	if p126.fillTypes ~= nil then
		local v127 = p125:getFillUnitFillType(p126.fillUnitIndex or p125.spec_sprayer.fillUnitIndex)
		local v128 = false
		for _, v129 in ipairs(p126.fillTypes) do
			if v127 == g_fillTypeManager:getFillTypeIndexByName(v129) then
				v128 = true
			end
		end
		if not v128 then
			return false
		end
	end
	return true
end
function Sprayer.setSprayerDoubledAmountActive(p130, p131, p132)
	local v133 = p130.spec_sprayer
	if p131 ~= v133.doubledAmountIsActive then
		v133.doubledAmountIsActive = p131
		SprayerDoubledAmountEvent.sendEvent(p130, p131, p132)
	end
end
function Sprayer.getSprayerDoubledAmountActive(p134, p135)
	local v136 = p134.spec_sprayer
	if not v136.isFertilizerSprayer then
		if p135 == nil then
			return v136.doubledAmountIsActive, true
		end
		local v137 = g_sprayTypeManager:getSprayTypeByIndex(p135)
		if v137 == nil then
			return v136.doubledAmountIsActive, true
		end
		if v137.isFertilizer then
			return v136.doubledAmountIsActive, true
		end
	end
	return false, false
end
function Sprayer.getDrawFirstFillText(p138, p139)
	return p138.isClient and (p138.spec_sprayer.needsToBeFilledToTurnOn and (p138:getIsActiveForInput() and (p138:getIsSelected() and (not p138.isAlwaysTurnedOn and (not p138:getCanBeTurnedOn() and (p138:getFillUnitFillLevel(p138:getSprayerFillUnitIndex()) <= 0 and p138:getFillUnitCapacity(p138:getSprayerFillUnitIndex()) > 0)))))) and true or p139(p138)
end
function Sprayer.getAreControlledActionsAllowed(p140, p141)
	local v142 = p140.spec_sprayer
	if v142.needsToBeFilledToTurnOn and (p140:getFillUnitFillLevel(v142.fillUnitIndex) <= 0 and p140:getFillUnitCapacity(v142.fillUnitIndex) ~= 0) then
		return false, g_i18n:getText("info_firstFillTheTool")
	else
		return p141(p140)
	end
end
function Sprayer.getCanToggleTurnedOn(p143, p144)
	if p143.isClient and (p143.spec_sprayer.needsToBeFilledToTurnOn and (not p143:getCanBeTurnedOn() and p143:getFillUnitCapacity(p143:getSprayerFillUnitIndex()) <= 0)) then
		return false
	else
		return p144(p143)
	end
end
function Sprayer.getCanBeTurnedOn(p145, p146)
	local v147 = p145.spec_sprayer
	if not v147.allowsSpraying then
		return false
	end
	if p145:getFillUnitFillLevel(p145:getSprayerFillUnitIndex()) <= 0 and (v147.needsToBeFilledToTurnOn and not p145:getIsAIActive()) then
		local v148 = nil
		for _, v149 in ipairs(v147.supportedSprayTypes) do
			for _, v150 in ipairs(v147.fillTypeSources[v149]) do
				local v151 = v150.vehicle
				if v151:getFillUnitFillType(v150.fillUnitIndex) == v149 and v151:getFillUnitFillLevel(v150.fillUnitIndex) > 0 then
					v148 = v151
					break
				end
			end
		end
		if v148 == nil then
			return false
		end
	end
	return p146(p145)
end
function Sprayer.loadWorkAreaFromXML(p152, p153, p154, p155, p156)
	local v157 = p153(p152, p154, p155, p156)
	if p154.type == WorkAreaType.DEFAULT then
		p154.type = WorkAreaType.SPRAYER
	end
	p154.sprayType = p155:getValue(p156 .. "#sprayType")
	return v157
end
function Sprayer.getIsWorkAreaActive(p158, p159, p160)
	if p160.sprayType ~= nil then
		local v161 = p158:getActiveSprayType()
		if v161 ~= nil and v161.index ~= p160.sprayType then
			return false
		end
	end
	return p159(p158, p160)
end
function Sprayer.doCheckSpeedLimit(p162, p163)
	local v164 = not p163(p162) and p162:getIsTurnedOn()
	if v164 then
		v164 = p162.spec_sprayer.useSpeedLimit
	end
	return v164
end
function Sprayer.getRawSpeedLimit(p165, p166)
	local v167 = p165.spec_sprayer
	local v168
	if v167.workAreaParameters == nil then
		v168 = nil
	else
		v168 = v167.workAreaParameters.sprayType
	end
	if p165:getSprayerDoubledAmountActive(v168) and p165:getIsTurnedOn() then
		return v167.doubledAmountSpeed
	else
		return p166(p165)
	end
end
function Sprayer.getFillVolumeUVScrollSpeed(p169, p170, p171)
	local v172 = p169.spec_sprayer
	local v173 = v172.fillVolumeIndex
	local v174 = p169:getActiveSprayType()
	if v174 ~= nil then
		v173 = v174.fillVolumeIndex or v173
	end
	if p171 == v173 and (p169:getIsTurnedOn() and not p169:getIsSprayerExternallyFilled()) then
		return v172.dischargeUVScrollSpeed[1], v172.dischargeUVScrollSpeed[2], v172.dischargeUVScrollSpeed[3]
	else
		return p170(p169, p171)
	end
end
function Sprayer.getAIRequiresTurnOffOnHeadland(_, _)
	return true
end
function Sprayer.getDirtMultiplier(p175, p176)
	if p175.spec_sprayer.isWorking then
		return p176(p175) + p175:getWorkDirtMultiplier() * p175:getLastSpeed() / p175.speedLimit
	else
		return p176(p175)
	end
end
function Sprayer.getWearMultiplier(p177, p178)
	if p177.spec_sprayer.isWorking then
		return p178(p177) + p177:getWorkWearMultiplier() * p177:getLastSpeed() / p177.speedLimit
	else
		return p178(p177)
	end
end
function Sprayer.getEffectByNode(p179, p180, p181)
	local v182 = p179.spec_sprayer
	for v183 = 1, #v182.effects do
		local v184 = v182.effects[v183]
		if p181 == v184.node then
			return v184
		end
	end
	for v185 = 1, #v182.sprayTypes do
		local v186 = v182.sprayTypes[v185]
		for v187 = 1, #v186.effects do
			local v188 = v186.effects[v187]
			if p181 == v188.node then
				return v188
			end
		end
	end
	return p180(p179, p181)
end
function Sprayer.getVariableWorkWidthUsage(p189, p190)
	local v191 = p190(p189)
	if v191 == nil then
		return not p189:getIsTurnedOn() and 0 or p189.spec_sprayer.workAreaParameters.usagePerMin
	else
		return v191
	end
end
function Sprayer.getAIImplementUseVineSegment(p192, _, p193, p194, p195)
	local v196, v197, v198, v199, v200, v201 = p193:getSegmentSideArea(p194, p195)
	local v202, v203 = AIVehicleUtil.getAIAreaOfVehicle(p192, v196, v197, v198, v199, v200, v201)
	if v203 > 0 then
		return v202 / v203 > 0.1
	else
		return false
	end
end
function Sprayer.onTurnedOn(p204)
	local v205 = p204.spec_sprayer
	if p204.isClient then
		p204:updateSprayerEffects()
		if v205.animationName ~= "" and p204.playAnimation ~= nil then
			p204:playAnimation(v205.animationName, 1, p204:getAnimationTime(v205.animationName), true)
		end
		g_soundManager:playSample(v205.samples.work)
		local v206 = p204:getActiveSprayType()
		if v206 ~= nil then
			g_soundManager:playSample(v206.samples.work)
			if v206.turnedAnimationExternalFill or not p204:getIsSprayerExternallyFilled() then
				p204:playAnimation(v206.turnedAnimation, v206.turnedAnimationTurnOnSpeedScale, p204:getAnimationTime(v206.turnedAnimation), true)
			end
		end
		if v205.turnedAnimationExternalFill or not p204:getIsSprayerExternallyFilled() then
			p204:playAnimation(v205.turnedAnimation, v205.turnedAnimationTurnOnSpeedScale, p204:getAnimationTime(v205.turnedAnimation), true)
		end
	end
end
function Sprayer.onTurnedOff(p207)
	local v208 = p207.spec_sprayer
	if p207.isClient then
		p207:updateSprayerEffects()
		if v208.animationName ~= "" and p207.stopAnimation ~= nil then
			p207:stopAnimation(v208.animationName, true)
		end
		g_soundManager:stopSample(v208.samples.work)
		for _, v209 in ipairs(v208.sprayTypes) do
			g_soundManager:stopSample(v209.samples.work)
			p207:playAnimation(v209.turnedAnimation, v209.turnedAnimationTurnOffSpeedScale, p207:getAnimationTime(v209.turnedAnimation), true)
		end
		p207:playAnimation(v208.turnedAnimation, v208.turnedAnimationTurnOffSpeedScale, p207:getAnimationTime(v208.turnedAnimation), true)
	end
end
function Sprayer.onPreDetach(_, p210, _)
	if p210.setIsTurnedOn ~= nil and p210:getIsTurnedOn() then
		p210:setIsTurnedOn(false)
	end
end
function Sprayer.onStartWorkAreaProcessing(p211, p212)
	local v213 = p211.spec_sprayer
	local v214 = nil
	local v215 = nil
	local v216 = p211:getFillUnitFillType(p211:getSprayerFillUnitIndex())
	local v217 = p211:getSprayerUsage(v216, p212)
	local v218 = p211:getFillUnitFillLevel(p211:getSprayerFillUnitIndex())
	if v218 > 0 then
		v215 = p211:getSprayerFillUnitIndex()
		v214 = p211
	else
		for _, v219 in ipairs(v213.supportedSprayTypes) do
			for _, v220 in ipairs(v213.fillTypeSources[v219]) do
				local v221 = v220.vehicle
				if v221:getIsFillUnitActive(v220.fillUnitIndex) then
					local v222 = v221:getFillUnitFillType(v220.fillUnitIndex)
					local v223 = v221:getFillUnitFillLevel(v220.fillUnitIndex)
					if v223 > 0 and v222 == v219 then
						v215 = v220.fillUnitIndex
						v216 = v221:getFillUnitFillType(v215)
						v217 = p211:getSprayerUsage(v216, p212)
						v214 = v221
						v218 = v223
						break
					end
				elseif p211:getIsAIActive() and (v221.setIsTurnedOn ~= nil and not v221:getIsTurnedOn()) then
					v221:setIsTurnedOn(true)
				end
			end
		end
	end
	local v224 = p211:getIsSprayerExternallyFilled()
	local v225, v226
	if v224 and (p211.rootVehicle.getAIFieldWorkerIsTurning == nil or not (p211.rootVehicle:getAIFieldWorkerIsTurning() or p211.rootVehicle:getAIFieldWorkerIsBlocked())) then
		v225, v226 = p211:getExternalFill(v216, p212)
		if v225 == FillType.UNKNOWN then
			v226 = v218
			v225 = v216
		else
			v217 = v226
			v215 = nil
			v214 = nil
		end
	else
		v226 = v218
		v225 = v216
	end
	if v224 ~= v213.workAreaParameters.lastIsExternallyFilled then
		local v227 = p211:getActiveSprayType()
		if v227 ~= nil then
			if v224 then
				if not v227.turnedAnimationExternalFill and p211:getIsAnimationPlaying(v227.turnedAnimation) then
					p211:stopAnimation(v227.turnedAnimation)
				end
			elseif not p211:getIsAnimationPlaying(v227.turnedAnimation) then
				p211:playAnimation(v227.turnedAnimation, v227.turnedAnimationTurnOnSpeedScale, p211:getAnimationTime(v227.turnedAnimation), true)
			end
		end
		if v224 then
			if not v213.turnedAnimationExternalFill and p211:getIsAnimationPlaying(v213.turnedAnimation) then
				p211:stopAnimation(v213.turnedAnimation)
			end
		elseif not p211:getIsAnimationPlaying(v213.turnedAnimation) then
			p211:playAnimation(v213.turnedAnimation, v213.turnedAnimationTurnOnSpeedScale, p211:getAnimationTime(v213.turnedAnimation), true)
		end
		v213.workAreaParameters.lastIsExternallyFilled = v224
	end
	if p211.isServer and (v225 ~= FillType.UNKNOWN and v225 ~= v213.workAreaParameters.sprayFillType) then
		p211:setSprayerAITerrainDetailProhibitedRange(v225)
	end
	v213.workAreaParameters.sprayType = g_sprayTypeManager:getSprayTypeIndexByFillTypeIndex(v225)
	v213.workAreaParameters.sprayFillType = v225
	v213.workAreaParameters.sprayFillLevel = v226
	v213.workAreaParameters.usage = v217
	v213.workAreaParameters.usagePerMin = v217 / p212 * 1000 * 60
	v213.workAreaParameters.sprayVehicle = v214
	v213.workAreaParameters.sprayVehicleFillUnitIndex = v215
	v213.workAreaParameters.lastChangedArea = 0
	v213.workAreaParameters.lastTotalArea = 0
	v213.workAreaParameters.lastStatsArea = 0
	v213.workAreaParameters.isActive = false
	v213.isWorking = false
end
function Sprayer.onEndWorkAreaProcessing(p228, p229, _)
	local v230 = p228.spec_sprayer
	if p228.isServer and v230.workAreaParameters.isActive then
		local v231 = v230.workAreaParameters.sprayVehicle
		local v232 = v230.workAreaParameters.usage
		if v231 ~= nil then
			local v233 = v230.workAreaParameters.sprayVehicleFillUnitIndex
			local v234 = v230.workAreaParameters.sprayFillType
			local v235 = v230.unloadInfoIndex
			local v236 = p228:getActiveSprayType()
			if v236 ~= nil then
				v235 = v236.unloadInfoIndex
			end
			local v237 = p228:getFillVolumeUnloadInfo(v235)
			v231:addFillUnitFillLevel(p228:getOwnerFarmId(), v233, -v232, v234, ToolType.UNDEFINED, v237)
		end
		local v238 = MathUtil.areaToHa(v230.workAreaParameters.lastStatsArea, g_currentMission:getFruitPixelsToSqm())
		local v239 = p228:getLastTouchedFarmlandFarmId()
		g_farmManager:updateFarmStats(v239, "sprayedHectares", v238)
		g_farmManager:updateFarmStats(v239, "sprayedTime", p229 / 60000)
		g_farmManager:updateFarmStats(v239, "sprayUsage", v232)
		p228:updateLastWorkedArea(v230.workAreaParameters.lastStatsArea)
	end
	p228:updateSprayerEffects()
end
function Sprayer.onStateChange(p240, p241, _)
	if p241 == VehicleStateChange.ATTACH or (p241 == VehicleStateChange.DETACH or p241 == VehicleStateChange.FILLTYPE_CHANGE) then
		local v242 = p240.spec_sprayer
		v242.fillTypeSources = {}
		local v243 = p240:getFillUnitSupportedFillTypes(p240:getSprayerFillUnitIndex())
		v242.supportedSprayTypes = {}
		if v243 ~= nil then
			for v244, v245 in pairs(v243) do
				if v245 then
					v242.fillTypeSources[v244] = {}
					local v246 = v242.supportedSprayTypes
					table.insert(v246, v244)
				end
			end
		end
		local v247 = p240.rootVehicle
		FillUnit.addFillTypeSources(v242.fillTypeSources, v247, p240, v242.supportedSprayTypes)
	end
end
function Sprayer.onSetLowered(p248, p249)
	local v250 = p248.spec_sprayer
	if p248.isServer then
		if v250.activateOnLowering then
			if p248:getCanBeTurnedOn() then
				p248:setIsTurnedOn(p249)
			else
				v250.pendingActivationAfterLowering = true
			end
		end
		if not p249 then
			v250.pendingActivationAfterLowering = false
		end
	end
	if v250.activateTankOnLowering then
		for _, v251 in ipairs(v250.supportedSprayTypes) do
			for _, v252 in ipairs(v250.fillTypeSources[v251]) do
				local v253 = v252.vehicle
				if v253.getIsTurnedOn ~= nil then
					v253:setIsTurnedOn(p249, true)
				end
			end
		end
	end
end
function Sprayer.onFillUnitFillLevelChanged(p254, p255, _, p256, _, _, _)
	local v257 = p254.spec_sprayer
	if p255 == v257.fillUnitIndex and (p254:getFillUnitFillLevel(p255) == 0 and (p254:getIsTurnedOn() and not p254:getIsAIActive())) then
		local v258 = false
		if v257.fillTypeSources[p256] ~= nil then
			for _, v259 in ipairs(v257.fillTypeSources[p256]) do
				local v260 = v259.vehicle
				if v260:getIsFillUnitActive(v259.fillUnitIndex) then
					local v261 = v260:getFillUnitFillType(v259.fillUnitIndex)
					if v260:getFillUnitFillLevel(v259.fillUnitIndex) > 0 and v261 == p256 then
						v258 = true
					end
				end
			end
		end
		if not v258 then
			p254:setIsTurnedOn(false)
			if Platform.gameplay.automaticVehicleControl then
				p254.rootVehicle:playControlledActions()
			end
		end
	end
end
function Sprayer.onSprayTypeChange(p262, p263)
	local v264 = p262.spec_sprayer
	for _, v265 in ipairs(v264.sprayTypes) do
		ObjectChangeUtil.setObjectChanges(v265.objectChanges, v265 == p263, p262, p262.setMovingToolDirty)
	end
end
function Sprayer.onAIImplementEnd(p266)
	local v267 = p266.spec_sprayer
	for _, v268 in ipairs(v267.supportedSprayTypes) do
		for _, v269 in ipairs(v267.fillTypeSources[v268]) do
			local v270 = v269.vehicle
			if v270.getIsTurnedOn ~= nil and v270:getIsTurnedOn() then
				v270:setIsTurnedOn(false, true)
			end
		end
	end
end
function Sprayer.onVariableWorkWidthSectionChanged(p271)
	p271:updateSprayerEffects(true)
end
function Sprayer.getDefaultSpeedLimit()
	return 15
end

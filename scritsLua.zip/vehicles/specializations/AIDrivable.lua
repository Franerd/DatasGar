AIDrivable = {}
AIDrivable.STATES = {}
AIDrivable.STATES[AgentState.DRIVING] = "driving"
AIDrivable.STATES[AgentState.BLOCKED] = "blocked"
AIDrivable.STATES[AgentState.PLANNING] = "planning"
AIDrivable.STATES[AgentState.NOT_REACHABLE] = "not_reachable"
AIDrivable.STATES[AgentState.TARGET_REACHED] = "target_reached"
AIDrivable.TRAILER_LIMIT = 4
function AIDrivable.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AIVehicle, p1) and SpecializationUtil.hasSpecialization(AIJobVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Drivable, p1)
	end
	return v2
end
function AIDrivable.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("AI")
	AIDrivable.registerAgentXMLPaths(v3, "vehicle.ai.agent")
	v3:setXMLSpecializationType()
end
function AIDrivable.postInitSpecialization()
	local v4 = Vehicle.xmlSchema
	for _, v5 in pairs(g_vehicleConfigurationManager:getConfigurations()) do
		local v6 = v5.configurationKey .. "(?)"
		v4:setXMLSharedRegistration("configAIAgent", v6)
		AIDrivable.registerAgentXMLPaths(v4, v6 .. ".aiAgent")
		v4:resetXMLSharedRegistration("configAIAgent", v6)
	end
end
function AIDrivable.registerAgentXMLPaths(p7, p8)
	p7:register(XMLValueType.FLOAT, p8 .. "#width", "AI vehicle width")
	p7:register(XMLValueType.FLOAT, p8 .. "#length", "AI vehicle length")
	p7:register(XMLValueType.FLOAT, p8 .. "#lengthOffset", "AI vehicle length offset")
	p7:register(XMLValueType.FLOAT, p8 .. "#height", "AI vehicle height")
	p7:register(XMLValueType.FLOAT, p8 .. "#frontOffset", "AI vehicle front offset")
	p7:register(XMLValueType.VECTOR_N, p8 .. "#frontWheelIndices", "List of wheels (indices) that are used for steering")
	p7:register(XMLValueType.NODE_INDICES, p8 .. "#frontWheelNodes", "List of wheels (nodes) that are used for steering")
	p7:register(XMLValueType.FLOAT, p8 .. "#maxBrakeAcceleration", "AI vehicle max brake acceleration")
	p7:register(XMLValueType.FLOAT, p8 .. "#maxCentripetalAcceleration", "AI vehicle max centripetal acceleration")
	p7:register(XMLValueType.FLOAT, p8 .. "#maxTurningRadius", "Max. turning radius (overwrites value detected from ackermann steering)")
end
function AIDrivable.registerEvents(p9)
	SpecializationUtil.registerEvent(p9, "onAIDrivablePrepare")
	SpecializationUtil.registerEvent(p9, "onAIDriveableStart")
	SpecializationUtil.registerEvent(p9, "onAIDriveableActive")
	SpecializationUtil.registerEvent(p9, "onAIDriveableEnd")
end
function AIDrivable.registerFunctions(p10)
	SpecializationUtil.registerFunction(p10, "consoleCommandSetTurnRadius", AIDrivable.consoleCommandSetTurnRadius)
	SpecializationUtil.registerFunction(p10, "consoleCommandMove", AIDrivable.consoleCommandMove)
	SpecializationUtil.registerFunction(p10, "consoleCommandClearPath", AIDrivable.consoleCommandClearPath)
	SpecializationUtil.registerFunction(p10, "createAgent", AIDrivable.createAgent)
	SpecializationUtil.registerFunction(p10, "deleteAgent", AIDrivable.deleteAgent)
	SpecializationUtil.registerFunction(p10, "setAITarget", AIDrivable.setAITarget)
	SpecializationUtil.registerFunction(p10, "unsetAITarget", AIDrivable.unsetAITarget)
	SpecializationUtil.registerFunction(p10, "stopAIDriving", AIDrivable.stopAIDriving)
	SpecializationUtil.registerFunction(p10, "reachedAITarget", AIDrivable.reachedAITarget)
	SpecializationUtil.registerFunction(p10, "getAIRootNode", AIDrivable.getAIRootNode)
	SpecializationUtil.registerFunction(p10, "getAIAllowsBackwards", AIDrivable.getAIAllowsBackwards)
	SpecializationUtil.registerFunction(p10, "drawDebugAIAgent", AIDrivable.drawDebugAIAgent)
	SpecializationUtil.registerFunction(p10, "debugGetAgentHasSpaceAt", AIDrivable.debugGetAgentHasSpaceAt)
	SpecializationUtil.registerFunction(p10, "loadAgentInfoFromXML", AIDrivable.loadAgentInfoFromXML)
	SpecializationUtil.registerFunction(p10, "getAIAgentSize", AIDrivable.getAIAgentSize)
	SpecializationUtil.registerFunction(p10, "getAIAgentMaxBrakeAcceleration", AIDrivable.getAIAgentMaxBrakeAcceleration)
	SpecializationUtil.registerFunction(p10, "updateAIAgentAttachments", AIDrivable.updateAIAgentAttachments)
	SpecializationUtil.registerFunction(p10, "addAIAgentAttachment", AIDrivable.addAIAgentAttachment)
	SpecializationUtil.registerFunction(p10, "startNewAIAgentAttachmentChain", AIDrivable.startNewAIAgentAttachmentChain)
	SpecializationUtil.registerFunction(p10, "updateAIAgentAttachmentOffsetData", AIDrivable.updateAIAgentAttachmentOffsetData)
	SpecializationUtil.registerFunction(p10, "updateAIAgentPoseData", AIDrivable.updateAIAgentPoseData)
	SpecializationUtil.registerFunction(p10, "prepareForAIDriving", AIDrivable.prepareForAIDriving)
	SpecializationUtil.registerFunction(p10, "getAITurningRadius", AIDrivable.getAITurningRadius)
end
function AIDrivable.registerOverwrittenFunctions(p11)
	SpecializationUtil.registerOverwrittenFunction(p11, "getCanStartAIVehicle", AIDrivable.getCanStartAIVehicle)
	SpecializationUtil.registerOverwrittenFunction(p11, "getCanHaveAIVehicleObstacle", AIDrivable.getCanHaveAIVehicleObstacle)
	SpecializationUtil.registerOverwrittenFunction(p11, "getIsAIReadyToDrive", AIDrivable.getIsAIReadyToDrive)
	SpecializationUtil.registerOverwrittenFunction(p11, "getIsAIPreparingToDrive", AIDrivable.getIsAIPreparingToDrive)
end
function AIDrivable.registerEventListeners(p12)
	SpecializationUtil.registerEventListener(p12, "onLoad", AIDrivable)
	SpecializationUtil.registerEventListener(p12, "onPostLoad", AIDrivable)
	SpecializationUtil.registerEventListener(p12, "onUpdate", AIDrivable)
	SpecializationUtil.registerEventListener(p12, "onEnterVehicle", AIDrivable)
	SpecializationUtil.registerEventListener(p12, "onLeaveVehicle", AIDrivable)
end
function AIDrivable.onLoad(p13, _)
	local v14 = p13.spec_aiDrivable
	v14.agentInfo = {}
	v14.agentInfo.isValid = false
	p13:loadAgentInfoFromXML(p13.xmlFile, v14.agentInfo)
	v14.maxSpeed = (1 / 0)
	v14.isRunning = false
	v14.useManualDriving = false
	v14.lastState = nil
	v14.lastIsBlocked = false
	v14.lastMaxSpeed = 0
	v14.stuckTime = 0
	v14.agentId = nil
	v14.targetX = nil
	v14.targetY = nil
	v14.targetZ = nil
	v14.targetDirX = nil
	v14.targetDirY = nil
	v14.targetDirZ = nil
	v14.attachments = {}
	v14.attachmentChains = {}
	v14.attachmentChainIndex = 1
	v14.attachmentsTrailerOffsetData = {}
	v14.attachmentsMaxWidth = 0
	v14.attachmentsMaxHeight = 0
	v14.attachmentsMaxLengthOffsetPos = 0
	v14.attachmentsMaxLengthOffsetNeg = 0
	v14.poseData = {}
	v14.debugVehicle = nil
	v14.debugSizeBox = DebugBox.new()
	v14.debugSizeBox:setColorRGBA(0, 1, 1)
	v14.debugSizeBox:setText("agentSize")
	v14.debugFrontMarker = DebugGizmo.new()
	v14.debugDump = nil
end
function AIDrivable.onPostLoad(p15)
	local v16 = p15.spec_aiDrivable
	local v17 = p15:getAIRootNode()
	v16.attacherJointOffsets = {}
	if p15.getAttacherJoints ~= nil then
		for _, v18 in ipairs(p15:getAttacherJoints()) do
			local v19 = v18.jointTransform
			local v20, v21, v22 = localDirectionToLocal(v19, v17, 0, 0, 1)
			local v23, v24, v25 = localDirectionToLocal(v19, v17, 0, 1, 0)
			local v26, v27, v28 = localToLocal(v19, v17, 0, 0, 0)
			local v29 = v16.attacherJointOffsets
			table.insert(v29, {
				["x"] = v26,
				["y"] = v27,
				["z"] = v28,
				["xDir"] = v20,
				["yDir"] = v21,
				["zDir"] = v22,
				["xUp"] = v23,
				["yUp"] = v24,
				["zUp"] = v25
			})
		end
	end
	if p15.xmlFile:hasProperty("vehicle.ai.agent") then
		if v16.agentInfo.width == nil or (v16.agentInfo.length == nil or v16.agentInfo.height == nil) then
			v16.agentInfo.width = v16.agentInfo.width or p15.size.width
			v16.agentInfo.height = v16.agentInfo.height or p15.size.height
			if v16.agentInfo.length == nil then
				v16.agentInfo.length = p15.size.length
				local _, _, v30 = localToLocal(v17, p15.rootNode, 0, 0, 0)
				v16.agentInfo.lengthOffset = -v30 + p15.size.lengthOffset
			end
		end
		if v16.agentInfo.frontWheelIndices ~= nil or v16.agentInfo.frontWheelNodes ~= nil then
			local v31 = 0
			local v32 = 0
			if v16.agentInfo.frontWheelNodes == nil or #v16.agentInfo.frontWheelNodes <= 0 then
				if v16.agentInfo.frontWheelIndices ~= nil and #v16.agentInfo.frontWheelIndices > 0 then
					for _, v33 in ipairs(v16.agentInfo.frontWheelIndices) do
						local v34 = p15:getWheelFromWheelIndex(v33)
						if v34 == nil then
							Logging.xmlWarning(p15.xmlFile, "Unknown wheel index \'%d\' found for ai agent definition.", v33)
						else
							local _, _, v35 = localToLocal(v34.repr, v17, 0, 0, 0)
							v31 = v31 + v35
							v32 = v32 + 1
						end
					end
				end
			else
				for _, v36 in ipairs(v16.agentInfo.frontWheelNodes) do
					local v37 = p15:getWheelByWheelNode(v36)
					if v37 == nil then
						Logging.xmlWarning(p15.xmlFile, "Node wheel for node \'%s\' found for ai agent definition.", getName(v36))
					else
						local _, _, v38 = localToLocal(v37.repr, v17, 0, 0, 0)
						v31 = v31 + v38
						v32 = v32 + 1
					end
				end
			end
			if v32 > 0 then
				v16.agentInfo.frontOffset = v31 / v32
			end
		end
	end
	v16.agentInfo.isValid = (v16.agentInfo.width ~= nil or v16.agentInfo.length ~= nil) and true or v16.agentInfo.height ~= nil
end
function AIDrivable.onUpdate(p39, p40, _, _, _)
	local v41 = p39.spec_aiDrivable
	if p39.isServer and v41.isRunning then
		local v42 = v41.lastIsBlocked
		if v42 then
			v42 = p39:getLastSpeed() < 5
		end
		local v43 = v41.lastMaxSpeed
		local v44
		if math.abs(v43) > 0 then
			v44 = p39:getLastSpeed() < 1
		else
			v44 = false
		end
		if v44 or v42 then
			v41.stuckTime = v41.stuckTime + p40
		else
			v41.stuckTime = 0
		end
		local v45 = v41.stuckTime > 5000
		local v46 = p39:getAIRootNode()
		local v47, v48, v49 = getWorldTranslation(v46)
		v41.distanceToTarget = MathUtil.vector2Length(v47 - v41.targetX, v49 - v41.targetZ)
		local v50 = p39.lastSpeedReal * p39.movingDirection * 1000
		local v51 = v41.maxSpeed
		local v52 = math.min(v51, p39:getCruiseControlSpeed())
		if v41.useManualDriving then
			local v53, _, v54 = worldToLocal(v46, v41.targetX, v41.targetY, v41.targetZ)
			AIVehicleUtil.driveToPoint(p39, p40, 1, true, true, v53, v54, v52, false)
			v41.lastMaxSpeed = v52
			if v41.distanceToTarget < 0.5 then
				p39:reachedAITarget()
			end
		else
			local v55, v56, v57 = localDirectionToWorld(v46, 0, 0, 1)
			p39:updateAIAgentPoseData()
			local v58, v59, v60 = getVehicleNavigationAgentNextCurvature(v41.agentId, v41.poseData, (math.abs(v50)))
			if v41.debugDump ~= nil then
				v41.debugDump:addData(p40, v47, v48, v49, v55, v56, v57, v50, v58, v52, v60)
			end
			if v60 == AgentState.DRIVING then
				local v61 = v59 * 3.6
				v52 = math.min(v61, v52)
				AIVehicleUtil.driveAlongCurvature(p39, p40, v58, v52, 1)
				if v52 == 0 then
					v45 = false
				end
			elseif v60 == AgentState.PLANNING then
				p39:stopAIDriving()
				p39:brake(1)
				v45 = false
			elseif v60 == AgentState.BLOCKED then
				p39:stopAIDriving()
				v45 = true
			elseif v60 == AgentState.TARGET_REACHED then
				p39:reachedAITarget()
				v45 = false
			elseif v60 == AgentState.NOT_REACHABLE then
				p39:stopCurrentAIJob(AIMessageErrorNotReachable.new())
				v45 = false
			end
			v41.lastState = v60
			v41.lastMaxSpeed = v52
		end
		if v41.debugVehicle ~= nil then
			v41.debugVehicle:update(p40)
		end
		if v45 and not v41.lastIsBlocked then
			g_server:broadcastEvent(AIVehicleIsBlockedEvent.new(p39, true), true, nil, p39)
		elseif not v45 and v41.lastIsBlocked then
			g_server:broadcastEvent(AIVehicleIsBlockedEvent.new(p39, false), true, nil, p39)
		end
		v41.lastIsBlocked = v45
		SpecializationUtil.raiseEvent(p39, "onAIDriveableActive")
	end
end
function AIDrivable.createAgent(p62, _)
	if p62.isServer then
		local v63 = p62.spec_aiDrivable
		p62:updateAIAgentAttachments()
		local v64 = v63.attachmentsTrailerOffsetData
		local v65 = g_currentMission.aiSystem:getNavigationMap()
		local v66 = v63.agentInfo
		local v67, v68, v69, v70 = p62:getAIAgentSize()
		local v71 = p62:getAIAgentMaxBrakeAcceleration()
		local v72 = v66.maxCentripetalAcceleration
		local v73 = p62:getAITurningRadius(v66.maxTurningRadius or p62.maxTurningRadius)
		local v74 = p62:getAIAllowsBackwards()
		v63.agentId = createVehicleNavigationAgent(v65, v73, v73, v74, v67, v68, v69, v70, v71, v72, v64)
		p62:setAIVehicleObstacleStateDirty()
		if g_currentMission.aiSystem.debugEnabled then
			if v63.debugVehicle ~= nil then
				v63.debugVehicle:delete()
			end
			v63.debugVehicle = AIDebugVehicle.new(p62, { math.random(), math.random(), math.random() })
			if v63.debugDump ~= nil then
				v63.debugDump:delete()
			end
			v63.debugDump = AIDebugDump.new(p62, v63.agentId)
			v63.debugDump:startRecording(v73, v74, v67, v68, v69, v70, v71, v72)
		end
		if VehicleDebug.state == VehicleDebug.DEBUG_AI then
			enableVehicleNavigationAgentDebugRendering(v63.agentId, true)
		end
	end
end
function AIDrivable.deleteAgent(p75)
	local v76 = p75.spec_aiDrivable
	v76.isRunning = false
	p75:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF, true)
	if v76.debugDump ~= nil then
		v76.debugDump:delete()
		v76.debugDump = nil
	end
	if v76.agentId ~= nil then
		delete(v76.agentId)
		v76.agentId = nil
	end
	p75:setAIVehicleObstacleStateDirty()
end
function AIDrivable.setAITarget(p77, p78, p79, p80, p81, p82, p83, p84, p85, p86)
	local v87 = p77.spec_aiDrivable
	local v88 = p77:getAIRootNode()
	local v89, v90, v91 = getWorldTranslation(v88)
	local v92, v93, v94 = localDirectionToWorld(v88, 0, 0, 1)
	v87.useManualDriving = Utils.getNoNil(p86, false)
	v87.isRunning = true
	v87.task = p78
	v87.maxSpeed = p85 or (1 / 0)
	v87.targetX = p79
	v87.targetY = p80
	v87.targetZ = p81
	v87.targetDirX = p82 or 0
	v87.targetDirY = p83
	v87.targetDirZ = p84 or 0
	v87.distanceToTarget = MathUtil.vector2Length(v89 - p79, v91 - p81)
	if not v87.useManualDriving and p77.isServer then
		setVehicleNavigationAgentTarget(v87.agentId, p79, p80, p81, p82, p83, p84)
	end
	if v87.debugVehicle ~= nil then
		v87.debugVehicle:setTarget(p79, p80, p81, p82, p83, p84)
	end
	if v87.debugDump ~= nil then
		v87.debugDump:setTarget(p79, p80, p81, p82, p83, p84, v89, v90, v91, v92, v93, v94, v87.maxSpeed)
	end
	SpecializationUtil.raiseEvent(p77, "onAIDriveableStart")
end
function AIDrivable.reachedAITarget(p95)
	local v96 = p95.spec_aiDrivable
	if p95.isServer then
		local v97 = v96.task
		if v97 ~= nil then
			v97:onTargetReached()
		end
	end
end
function AIDrivable.unsetAITarget(p98)
	local v99 = p98.spec_aiDrivable
	v99.isRunning = false
	v99.task = nil
	v99.useManualDriving = false
	p98:stopAIDriving()
	SpecializationUtil.raiseEvent(p98, "onAIDriveableEnd")
end
function AIDrivable.stopAIDriving(p100)
	p100:brake(1)
	p100:stopVehicle()
	p100:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF, true)
end
function AIDrivable.getAIRootNode(p101)
	return p101.components[1].node
end
function AIDrivable.getAIAllowsBackwards(_)
	return false
end
function AIDrivable.onEnterVehicle(p102, p103)
	if p103 then
		addConsoleCommand("gsAISetTurnRadius", "Set Turn radius", "consoleCommandSetTurnRadius", p102)
		addConsoleCommand("gsAIMoveVehicle", "Moves vehicles", "consoleCommandMove", p102)
		addConsoleCommand("gsAIClearPath", "Clears debug path", "consoleCommandClearPath", p102)
	end
end
function AIDrivable.onLeaveVehicle(_, p104)
	if p104 then
		removeConsoleCommand("gsAISetTurnRadius")
		removeConsoleCommand("gsAIMoveVehicle")
		removeConsoleCommand("gsAIClearPath")
	end
end
function AIDrivable.getIsAIReadyToDrive(p105, p106)
	for _, v107 in ipairs(p105.rootVehicle.childVehicles) do
		if v107 ~= p105 and (v107.getIsAIReadyToDrive ~= nil and not v107:getIsAIReadyToDrive()) then
			return false, v107
		end
	end
	return p106(p105)
end
function AIDrivable.getIsAIPreparingToDrive(p108, p109)
	for _, v110 in ipairs(p108.rootVehicle.childVehicles) do
		if v110 ~= p108 and (v110.getIsAIPreparingToDrive ~= nil and v110:getIsAIPreparingToDrive()) then
			return true
		end
	end
	return p109(p108)
end
function AIDrivable.drawDebugAIAgent(p111)
	local v112 = p111.spec_aiDrivable
	if v112.agentInfo.isValid then
		local v113 = p111:getAIRootNode()
		local v114, v115, v116, v117, v118 = p111:getAIAgentSize()
		v112.debugSizeBox:createWithNode(v113, v114, v118, v115, 0, v118 * 0.5, v116)
		v112.debugSizeBox:draw()
		local v119, v120, v121 = localToWorld(v113, 0, 0, v117)
		local v122, v123, v124 = localDirectionToWorld(v113, 0, 0, 1)
		local v125, v126, v127 = localDirectionToWorld(v113, 0, 1, 0)
		if v120 > 0 then
			v120 = getTerrainHeightAtWorldPos(g_terrainNode, v119, 0, v121) + 0.15
		end
		v112.debugFrontMarker:createWithWorldPosAndDir(v119, v120, v121, v122, v123, v124, v125, v126, v127, "FrontMarker", false, nil, 3)
		v112.debugFrontMarker:draw()
		local v128, v129, v130 = getWorldTranslation(v113)
		if v112.isRunning then
			local v131
			if v112.useManualDriving then
				v131 = string.format("Distance: %.2f", v112.distanceToTarget)
			else
				v131 = AIDrivable.STATES[v112.lastState]
			end
			Utils.renderTextAtWorldPosition(v128, v129 + 4, v130, v131, 0.015, 0, 1, 1, 1, 1)
		end
		if v112.debugVehicle ~= nil then
			v112.debugVehicle:setForcedY(v129 + 0.1)
			v112.debugVehicle:draw()
		end
		local v132, _, v133 = localToWorld(v113, 0, 0.5, 0)
		local v134 = getTerrainHeightAtWorldPos(g_terrainNode, v132, 0, v133) + 0.15
		local v135, _, v136 = localToWorld(v113, 10, 0.5, 0)
		local v137, _, v138 = localToWorld(v113, -10, 0.5, 0)
		drawDebugLine(v132, v134, v133, 1, 0, 0, v135, v134, v136, 1, 0, 0)
		drawDebugLine(v132, v134, v133, 0, 1, 0, v137, v134, v138, 0, 1, 0)
		local v139, v140 = MathUtil.vector2Normalize(v135 - v132, v136 - v133)
		local v141 = p111.maxTurningRadius
		local v142 = p111:getTurningRadiusByRotTime(p111.rotatedTime)
		local v143 = p111:getAITurningRadius(p111.maxTurningRadius)
		local v144 = p111:getSteeringRotTimeByCurvature(1 / (v142 * (p111.rotatedTime >= 0 and 1 or -1)))
		local v145 = string.format("ReferenceRadius: %.3fm\nMinRadius: %.3fm\nCalc Radius: %.3f\nRotatedTime: %.3f\nRevTime: %.3f", v142, v141, v143, p111.rotatedTime, v144)
		Utils.renderTextAtWorldPosition(v132, v134 + 5, v133, v145, getCorrectTextSize(0.012), 0)
		local v146 = p111.spec_wheels
		for _, v147 in ipairs(v146.wheels) do
			if v147.physics.rotSpeed ~= 0 or p111.spec_articulatedAxis ~= nil and p111.spec_articulatedAxis.componentJoint ~= nil then
				local v148, v149, v150 = localToWorld(v147.repr, 0, 0, 0)
				local v151, v152, v153 = localDirectionToWorld(v147.driveNode, 1, 0, 0)
				local v154 = v148 + v151 * 10
				local _ = v149 + v152 * 10
				local v155 = v150 + v153 * 10
				local v156 = v148 + v151 * -10
				local _ = v149 + v152 * -10
				local v157 = v150 + v153 * -10
				drawDebugLine(v148, v134, v150, 1, 0, 0, v154, v134, v155, 1, 0, 0)
				drawDebugLine(v148, v134, v150, 0, 1, 0, v156, v134, v157, 0, 1, 0)
			end
		end
		if v146.steeringCenterNode ~= nil then
			DebugGizmo.renderAtNode(v146.steeringCenterNode, "SCN")
		end
		local v158 = p111.rotatedTime
		local v159 = math.sign(v158)
		local v160 = v132 + v159 * v139 * v142
		local v161 = v133 + v159 * v140 * v142
		DebugGizmo.renderAtPosition(v160, v134, v161, v139, 0, v140, 0, 1, 0, "X")
		local v162 = p111.rotatedTime
		local v163 = math.sign(v162)
		local v164 = v132 + v163 * v139 * v143
		local v165 = v133 + v163 * v140 * v143
		DebugGizmo.renderAtPosition(v164, v134, v165, v139, 0, v140, 0, 1, 0, "M")
	end
end
function AIDrivable.debugGetAgentHasSpaceAt(p166, p167, p168, p169, p170, p171, p172, p173)
	local v174 = p166.spec_aiDrivable
	local v175 = v174.agentInfo
	local v176 = VehicleDebug.state ~= VehicleDebug.DEBUG_AI and g_currentMission.aiSystem
	if v176 then
		v176 = g_currentMission.aiSystem.splinesVisible or g_currentMission.aiSystem.debug.isCostRenderingActive
	end
	v174.debugElementsGroups = v174.debugElementsGroups or {}
	if v174.debugElementsGroups[p173] ~= nil then
		for _, v177 in ipairs(v174.debugElementsGroups[p173]) do
			g_debugManager:removeElement(v177)
		end
	end
	v174.debugElementsGroups[p173] = {}
	local v178 = v175.width / 2 + 0.3
	local v179 = v175.length / 2 + 0.3
	local v180 = {
		{ MathUtil.transform(p167, p168, p169, p170, p171, p172, 0, 1, 0, -v178, 0, -v179 - v175.lengthOffset) },
		{ MathUtil.transform(p167, p168, p169, p170, p171, p172, 0, 1, 0, -v178, 0, v179 - v175.lengthOffset) },
		{ MathUtil.transform(p167, p168, p169, p170, p171, p172, 0, 1, 0, v178, 0, -v179 - v175.lengthOffset) },
		{ MathUtil.transform(p167, p168, p169, p170, p171, p172, 0, 1, 0, v178, 0, v179 - v175.lengthOffset) }
	}
	local v181 = false
	for _, v182 in ipairs(v180) do
		local v183 = v182[1]
		local v184 = v182[2]
		local v185 = v182[3]
		local _, v186 = getVehicleNavigationMapCostAtWorldPos(g_currentMission.aiSystem.navigationMap, v183, v184, v185)
		v181 = v186 and true or v181
		if v176 then
			local v187 = DebugPoint.new():createWithWorldPos(v183, v184, v185, true, false):setColorRGBA(0, 1, 0, 0.8)
			if v186 then
				v187:setColorRGBA(1, 0, 0, 1)
			end
			g_debugManager:addElement(v187)
			local v188 = v174.debugElementsGroups[p173]
			table.insert(v188, v187)
		end
	end
	if v176 then
		local v189 = string.format("%s\n%s\nagentId %d\nagentWidth %.3f\nagentLength %.3f\nagentLengthOffset %.3f", p173, p166.configFileName, v174.agentId, v175.width, v175.length, v175.lengthOffset)
		local v190 = DebugText.new():createWithWorldPos(p167, p168, p169, v189, 0.015):setColorRGBA(0, 1, 0, 1)
		if v181 then
			v190:setColorRGBA(1, 0, 0, 1)
		end
		g_debugManager:addElement(v190)
		local v191 = v174.debugElementsGroups[p173]
		table.insert(v191, v190)
	end
	return not v181
end
function AIDrivable.loadAgentInfoFromXML(p192, p193, p194)
	p194.width = p193:getValue("vehicle.ai.agent#width")
	p194.length = p193:getValue("vehicle.ai.agent#length")
	p194.height = p193:getValue("vehicle.ai.agent#height")
	p194.lengthOffset = p193:getValue("vehicle.ai.agent#lengthOffset", 0)
	p194.frontOffset = p193:getValue("vehicle.ai.agent#frontOffset", 3)
	p194.frontWheelIndices = p193:getValue("vehicle.ai.agent#frontWheelIndices", nil, true)
	p194.frontWheelNodes = p193:getValue("vehicle.ai.agent#frontWheelNodes", nil, p192.components, p192.i3dMappings, true)
	p194.maxBrakeAcceleration = p193:getValue("vehicle.ai.agent#maxBrakeAcceleration", 5)
	p194.maxCentripetalAcceleration = p193:getValue("vehicle.ai.agent#maxCentripetalAcceleration", 1)
	p194.maxTurningRadius = p193:getValue("vehicle.ai.agent#maxTurningRadius")
	for v195, v196 in pairs(p192.configurations) do
		local v197 = g_vehicleConfigurationManager:getConfigurationDescByName(v195)
		local v198 = string.format("%s(%d).aiAgent", v197.configurationKey, v196 - 1)
		p194.width = p193:getValue(v198 .. "#width", p194.width)
		p194.length = p193:getValue(v198 .. "#length", p194.length)
		p194.height = p193:getValue(v198 .. "#height", p194.height)
		p194.lengthOffset = p193:getValue(v198 .. "#lengthOffset", p194.lengthOffset)
		p194.frontOffset = p193:getValue(v198 .. "#frontOffset", p194.frontOffset)
		p194.frontWheelIndices = p193:getValue("vehicle.ai.agent#frontWheelIndices", p194.frontWheelIndices, true)
		p194.frontWheelNodes = p193:getValue("vehicle.ai.agent#frontWheelNodes", p194.frontWheelNodes, p192.components, p192.i3dMappings, true)
		local v199 = v198 .. "#maxBrakeAcceleration"
		local v200 = p194.maxBrakeAcceleration
		p194.maxBrakeAcceleration = math.min(p193:getValue(v199, v200))
		local v201 = v198 .. "#maxCentripetalAcceleration"
		local v202 = p194.maxCentripetalAcceleration
		p194.maxCentripetalAcceleration = math.min(p193:getValue(v201, v202))
		p194.maxTurningRadius = p193:getValue(v198 .. "#maxTurningRadius", p194.maxTurningRadius)
	end
end
function AIDrivable.getAIAgentSize(p203)
	local v204 = p203.spec_aiDrivable
	local v205 = v204.agentInfo
	local v206 = v205.width
	local v207 = v204.attachmentsMaxWidth
	local v208 = math.max(v206, v207)
	local v209 = v205.height
	local v210 = v204.attachmentsMaxHeight
	local v211 = math.max(v209, v210)
	local v212 = v205.length
	local v213 = v205.lengthOffset
	return v208, v212 + v204.attachmentsMaxLengthOffsetPos - v204.attachmentsMaxLengthOffsetNeg, v213 + v204.attachmentsMaxLengthOffsetPos * 0.5 + v204.attachmentsMaxLengthOffsetNeg * 0.5, v205.frontOffset, v211
end
function AIDrivable.getAIAgentMaxBrakeAcceleration(p214)
	return p214.spec_aiDrivable.agentInfo.maxBrakeAcceleration
end
function AIDrivable.updateAIAgentAttachments(p215)
	local v216 = p215.spec_aiDrivable
	v216.attachments = {}
	v216.attachmentChains = {}
	v216.attachmentChainIndex = 1
	v216.attachmentsTrailerOffsetData = {}
	v216.attachmentsMaxWidth = 0
	v216.attachmentsMaxHeight = 0
	v216.attachmentsMaxLengthOffsetPos = 0
	v216.attachmentsMaxLengthOffsetNeg = 0
	p215:collectAIAgentAttachments(p215)
	p215:updateAIAgentAttachmentOffsetData()
	p215:updateAIAgentPoseData()
end
function AIDrivable.addAIAgentAttachment(p217, p218, p219)
	local v220 = p217.spec_aiDrivable
	local v221 = v220.attachmentsMaxWidth
	local v222 = p218.width
	v220.attachmentsMaxWidth = math.max(v221, v222)
	local v223 = v220.attachmentsMaxHeight
	local v224 = p218.height
	v220.attachmentsMaxHeight = math.max(v223, v224)
	p218.level = p219
	if v220.attachmentChains[v220.attachmentChainIndex] == nil then
		v220.attachmentChains[v220.attachmentChainIndex] = {}
	end
	local v225 = v220.attachments
	table.insert(v225, p218)
	local v226 = v220.attachmentChains[v220.attachmentChainIndex]
	table.insert(v226, p218)
end
function AIDrivable.startNewAIAgentAttachmentChain(p227)
	local v228 = p227.spec_aiDrivable
	if v228.attachmentChains[v228.attachmentChainIndex] ~= nil then
		v228.attachmentChainIndex = v228.attachmentChainIndex + 1
	end
end
function AIDrivable.updateAIAgentAttachmentOffsetData(p229)
	local v230 = p229.spec_aiDrivable
	local _, v231, _, _ = p229:getAIAgentSize()
	local v232 = 0
	for v233 = 1, #v230.attachmentChains do
		local v234 = v230.attachmentChains[v233]
		local v235 = p229:getAIRootNode()
		local v236 = true
		local v237 = true
		for v238 = 1, #v234 do
			local v239 = v234[v238]
			if v239.rotCenterNode == nil or not v237 then
				if v236 then
					if v232 > 0 then
						v237 = false
					end
					if v239.rotCenterNode == nil then
						local v240 = p229:getAIRootNode()
						local _, _, v241 = localToLocal(v239.rootNode, v240, 0, 0, v239.length * 0.5)
						local _, _, v242 = localToLocal(v239.rootNode, v240, 0, 0, -v239.length * 0.5)
						local v243 = -v230.agentInfo.length * 0.5 + v230.agentInfo.lengthOffset
						local v244 = v230.agentInfo.length * 0.5 + v230.agentInfo.lengthOffset
						local v245 = v241 - v243
						local v246 = v242 - v243
						local v247 = math.min(0, v245, v246)
						local v248 = v241 - v244
						local v249 = v242 - v244
						local v250 = math.max(0, v248, v249)
						local v251 = v230.attachmentsMaxLengthOffsetPos
						v230.attachmentsMaxLengthOffsetPos = math.max(v251, v250)
						local v252 = v230.attachmentsMaxLengthOffsetNeg
						v230.attachmentsMaxLengthOffsetNeg = math.min(v252, v247)
					end
				end
			elseif v232 < AIDrivable.TRAILER_LIMIT then
				local v253 = v239.jointNode or v239.jointNodeDynamic
				local v254 = v239.attacherVehicleJointNode or v253
				if v254 ~= nil and v253 ~= nil then
					local _, _, v255 = localToLocal(v254, v235, 0, 0, 0)
					local v256
					if v239.jointNodeToHitchOffset == nil then
						v256 = v239.trailerHitchOffset
					else
						v256 = v239.jointNodeToHitchOffset[v253]
					end
					if v256 ~= nil then
						local v257 = v239.lengthOffset + v231 * 0.5 - v239.length * 0.5
						local v258 = v239.hasCollision and 1 or 0
						local v259 = v230.attachmentsTrailerOffsetData
						table.insert(v259, v255)
						local v260 = v230.attachmentsTrailerOffsetData
						table.insert(v260, v256)
						local v261 = v230.attachmentsTrailerOffsetData
						table.insert(v261, v257)
						local v262 = v230.attachmentsTrailerOffsetData
						table.insert(v262, v258)
						v235 = v239.rotCenterNode
						v232 = v232 + 1
					end
				end
				v236 = false
			end
		end
	end
end
function AIDrivable.updateAIAgentPoseData(p263)
	local v264 = p263.spec_aiDrivable
	local v265 = p263:getAIRootNode()
	local v266 = v264.poseData
	local v267 = v264.poseData
	local v268 = v264.poseData
	local v269, v270, v271 = getWorldTranslation(v265)
	v266[1] = v269
	v267[2] = v270
	v268[3] = v271
	local v272 = v264.poseData
	local v273 = v264.poseData
	local v274 = v264.poseData
	local v275, v276, v277 = localDirectionToWorld(v265, 0, 0, 1)
	v272[4] = v275
	v273[5] = v276
	v274[6] = v277
	local v278 = 0
	local v279 = 6
	for v280 = 1, #v264.attachmentChains do
		local v281 = v264.attachmentChains[v280]
		local v282 = true
		for v283 = 1, #v281 do
			local v284 = v281[v283]
			if v284.rotCenterNode == nil or not v282 then
				if v278 > 0 then
					v282 = false
				end
			elseif v278 < AIDrivable.TRAILER_LIMIT then
				local v285 = v264.poseData
				local v286 = v279 + 1
				local v287 = v264.poseData
				local v288 = v279 + 2
				local v289 = v264.poseData
				local v290 = v279 + 3
				local v291, v292, v293 = getWorldTranslation(v284.rotCenterNode)
				v285[v286] = v291
				v287[v288] = v292
				v289[v290] = v293
				local v294 = v264.poseData
				local v295 = v279 + 4
				local v296 = v264.poseData
				local v297 = v279 + 5
				local v298 = v264.poseData
				local v299 = v279 + 6
				local v300, v301, v302 = localDirectionToWorld(v284.rotCenterNode, 0, 0, 1)
				v294[v295] = v300
				v296[v297] = v301
				v298[v299] = v302
				v278 = v278 + 1
				v279 = v279 + 6
			end
		end
	end
	while v279 < #v264.poseData do
		table.remove(v264.poseData, #v264.poseData)
	end
end
function AIDrivable.prepareForAIDriving(p303)
	p303:raiseAIEvent("onAIDrivablePrepare", "onAIImplementPrepareForTransport")
end
function AIDrivable.getAITurningRadius(_, p304)
	return p304
end
function AIDrivable.getCanStartAIVehicle(p305, p306)
	if p305.spec_aiDrivable.agentInfo.isValid then
		return p306(p305)
	else
		return false
	end
end
function AIDrivable.getCanHaveAIVehicleObstacle(p307, p308)
	if p307.spec_aiDrivable.agentId == nil then
		return p308(p307)
	else
		return false
	end
end
function AIDrivable.consoleCommandClearPath(p309)
	local v310 = p309.spec_aiDrivable
	if v310.debugVehicle ~= nil then
		v310.debugVehicle:clear()
	end
	return string.format("Cleared AI paths of %s", p309:getName())
end
function AIDrivable.consoleCommandSetTurnRadius(p311, p312)
	local v313 = p311:getSteeringRotTimeByCurvature(1 / (tonumber(p312) or 10))
	local v314
	if v313 > 0 then
		v314 = v313 / -p311.maxRotTime
	else
		v314 = v313 / p311.minRotTime
	end
	local v315 = p311:getSteeringDirection() * v314
	p311.spec_drivable.axisSide = v315
end
function AIDrivable.consoleCommandMove(p316, p317)
	local v318 = p316:getChildVehicles()
	local v319 = {}
	for _, v320 in ipairs(v318) do
		v320:removeFromPhysics()
		table.insert(v319, v320)
	end
	local v321 = p316:getAIRootNode()
	local v322, v323, v324 = localDirectionToWorld(v321, 1, 0, 0)
	local v325 = v322 * p317
	local v326 = v323 * p317
	local v327 = v324 * p317
	local v328 = p316:getTurningRadiusByRotTime(p316.rotatedTime)
	local v329 = DebugGizmo.new()
	local v330, v331, v332 = localToWorld(v321, v328, 0.05, 0)
	v329:createWithWorldPosAndDir(v330, v331, v332, 0, 0, 1, 0, 1, 0, "", false, nil)
	g_debugManager:addElement(v329)
	p316.rotatedTime = p316:getSteeringRotTimeByCurvature(1 / (-v328 + p317))
	if p316.rotatedTime < 0 then
		p316.spec_wheels.axisSide = p316.rotatedTime / -p316.maxRotTime / p316:getSteeringDirection()
	else
		p316.spec_wheels.axisSide = p316.rotatedTime / p316.minRotTime / p316:getSteeringDirection()
	end
	for _, v333 in ipairs(v319) do
		for _, v334 in ipairs(v333.components) do
			local v335, v336, v337 = getWorldTranslation(v334.node)
			setWorldTranslation(v334.node, v335 + v325, v336 + v326, v337 + v327)
		end
	end
	for _, v338 in ipairs(v319) do
		v338:addToPhysics()
	end
end

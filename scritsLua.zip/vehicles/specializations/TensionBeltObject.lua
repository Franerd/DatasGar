TensionBeltObject = {}
function TensionBeltObject.prerequisitesPresent(_)
	return true
end
function TensionBeltObject.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("TensionBeltObject")
	v1:register(XMLValueType.BOOL, "vehicle.tensionBeltObject#supportsTensionBelts", "Supports tension belts", true)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.tensionBeltObject.meshNodes.meshNode(?)#node", "Mesh node for tension belt calculation")
	v1:setXMLSpecializationType()
end
function TensionBeltObject.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "getSupportsTensionBelts", TensionBeltObject.getSupportsTensionBelts)
	SpecializationUtil.registerFunction(p2, "getMeshNodes", TensionBeltObject.getMeshNodes)
	SpecializationUtil.registerFunction(p2, "getTensionBeltNodeId", TensionBeltObject.getTensionBeltNodeId)
end
function TensionBeltObject.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", TensionBeltObject)
end
function TensionBeltObject.onLoad(p4, _)
	local v5 = p4.spec_tensionBeltObject
	v5.supportsTensionBelts = p4.xmlFile:getValue("vehicle.tensionBeltObject#supportsTensionBelts", true)
	v5.meshNodes = {}
	local v6 = 0
	while true do
		local v7 = string.format("vehicle.tensionBeltObject.meshNodes.meshNode(%d)", v6)
		if not p4.xmlFile:hasProperty(v7) then
			break
		end
		local v8 = p4.xmlFile:getValue(v7 .. "#node", nil, p4.components, p4.i3dMappings)
		if v8 ~= nil then
			if not getShapeIsCPUMesh(v8) then
				Logging.xmlWarning(p4.xmlFile, "Mesh node %s (%s) does not have the CPU-Mesh flag set required for tension belts", p4.xmlFile:getString(v7 .. "#node"), I3DUtil.getNodePath(v8))
			end
			local v9 = v5.meshNodes
			table.insert(v9, v8)
		end
		v6 = v6 + 1
	end
end
function TensionBeltObject.getSupportsTensionBelts(p10)
	return p10.spec_tensionBeltObject.supportsTensionBelts
end
function TensionBeltObject.getMeshNodes(p11)
	return p11.spec_tensionBeltObject.meshNodes
end
function TensionBeltObject.getTensionBeltNodeId(p12)
	return p12.components[1].node
end

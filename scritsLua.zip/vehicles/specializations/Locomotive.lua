source("dataS/scripts/vehicles/specializations/events/LocomotiveStateEvent.lua")
Locomotive = {}
Locomotive.STATE_NONE = 0
Locomotive.STATE_MANUAL_TRAVEL_ACTIVE = 1
Locomotive.STATE_MANUAL_TRAVEL_INACTIVE = 2
Locomotive.STATE_AUTOMATIC_TRAVEL_ACTIVE = 3
Locomotive.STATE_REQUESTED_POSITION = 4
Locomotive.STATE_REQUESTED_POSITION_BRAKING = 5
Locomotive.NUM_BITS_STATE = 3
Locomotive.AUTOMATIC_DRIVE_DELAY = 1500000
function Locomotive.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(SplineVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Drivable, p1)
	end
	return v2
end
function Locomotive.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Locomotive")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.locomotive.powerArm#node", "Power arm node")
	v3:setXMLSpecializationType()
end
function Locomotive.registerEvents(p4)
	SpecializationUtil.registerEvent(p4, "onAutomatedTrainTravelActive")
end
function Locomotive.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "getDownhillForce", Locomotive.getDownhillForce)
	SpecializationUtil.registerFunction(p5, "setRequestedSplinePosition", Locomotive.setRequestedSplinePosition)
	SpecializationUtil.registerFunction(p5, "getDistanceToRequestedPosition", Locomotive.getDistanceToRequestedPosition)
	SpecializationUtil.registerFunction(p5, "setLocomotiveState", Locomotive.setLocomotiveState)
	SpecializationUtil.registerFunction(p5, "startAutomatedTrainTravel", Locomotive.startAutomatedTrainTravel)
	SpecializationUtil.registerFunction(p5, "notifyPlayerFarmChanged", Locomotive.notifyPlayerFarmChanged)
end
function Locomotive.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsMotorStarted", Locomotive.getIsMotorStarted)
	SpecializationUtil.registerOverwrittenFunction(p6, "updateVehiclePhysics", Locomotive.updateVehiclePhysics)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsReadyForAutomatedTrainTravel", Locomotive.getIsReadyForAutomatedTrainTravel)
	SpecializationUtil.registerOverwrittenFunction(p6, "alignToSplineTime", Locomotive.alignToSplineTime)
	SpecializationUtil.registerOverwrittenFunction(p6, "setTrainSystem", Locomotive.setTrainSystem)
	SpecializationUtil.registerOverwrittenFunction(p6, "getFullName", Locomotive.getFullName)
	SpecializationUtil.registerOverwrittenFunction(p6, "getAreSurfaceSoundsActive", Locomotive.getAreSurfaceSoundsActive)
	SpecializationUtil.registerOverwrittenFunction(p6, "getTraveledDistanceStatsActive", Locomotive.getTraveledDistanceStatsActive)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsEnterable", Locomotive.getIsEnterable)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsMapHotspotVisible", Locomotive.getIsMapHotspotVisible)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanBeReset", Locomotive.getCanBeReset)
	SpecializationUtil.registerOverwrittenFunction(p6, "getStopMotorOnLeave", Locomotive.getStopMotorOnLeave)
end
function Locomotive.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", Locomotive)
	SpecializationUtil.registerEventListener(p7, "onDelete", Locomotive)
	SpecializationUtil.registerEventListener(p7, "onReadStream", Locomotive)
	SpecializationUtil.registerEventListener(p7, "onWriteStream", Locomotive)
	SpecializationUtil.registerEventListener(p7, "onUpdate", Locomotive)
	SpecializationUtil.registerEventListener(p7, "onLeaveVehicle", Locomotive)
	SpecializationUtil.registerEventListener(p7, "onEnterVehicle", Locomotive)
end
function Locomotive.onLoad(p8, _)
	local v9 = p8.spec_locomotive
	p8.serverMass = 1
	v9.powerArm = p8.xmlFile:getValue("vehicle.locomotive.powerArm#node", nil, p8.components, p8.i3dMappings)
	v9.electricitySpline = nil
	v9.lastVirtualRpm = p8:getMotor():getMinRpm()
	v9.speed = 0
	v9.lastAcceleration = 0
	v9.nextMovingDirection = 0
	v9.sellingDirection = 1
	v9.startBrakeDistance = 0
	v9.startBrakeSpeed = 0
	p8:setLocomotiveState(Locomotive.STATE_NONE)
	v9.motor = p8:getMotor()
	v9.doStartCheck = true
	g_messageCenter:subscribe(MessageType.PLAYER_FARM_CHANGED, p8.notifyPlayerFarmChanged, p8)
	g_messageCenter:subscribe(MessageType.PLAYER_CREATED, p8.notifyPlayerFarmChanged, p8)
end
function Locomotive.onDelete(p10)
	g_messageCenter:unsubscribeAll(p10)
end
function Locomotive.onReadStream(p11, p12, _)
	p11.spec_locomotive.state = streamReadUIntN(p12, Locomotive.NUM_BITS_STATE)
end
function Locomotive.onWriteStream(p13, p14, _)
	streamWriteUIntN(p14, p13.spec_locomotive.state, Locomotive.NUM_BITS_STATE)
end
function Locomotive.onUpdate(p15, p16, _, _, _)
	local v17 = p15.spec_locomotive
	if v17.doStartCheck and p15.trainSystem ~= nil then
		if p15.trainSystem:getIsRented() then
			p15:setLocomotiveState(Locomotive.STATE_MANUAL_TRAVEL_ACTIVE)
		else
			p15:startAutomatedTrainTravel()
		end
		p15:raiseActive()
		v17.doStartCheck = false
	end
	if p15.isServer then
		if v17.state == Locomotive.STATE_AUTOMATIC_TRAVEL_ACTIVE then
			p15:raiseActive()
			p15:updateVehiclePhysics(1, 0, 0, p16)
			SpecializationUtil.raiseEvent(p15, "onAutomatedTrainTravelActive", p16)
			return
		end
		if v17.state == Locomotive.STATE_REQUESTED_POSITION then
			if v17.requestedSplinePosition ~= nil then
				local v18 = p15.trainSystem:getSplineLength()
				local v19 = p15:getCurrentSplinePosition()
				local v20 = v17.requestedSplinePosition
				local v21 = v20 - v19
				local v22 = math.sign(v21)
				local v23 = Locomotive.getBrakeAcceleration(p15)
				local v24 = v17.speed ^ 2 / (2 * v23)
				local v25 = math.abs(v24)
				local v26 = (v20 - v25 / v18 * v22) % 1
				if (v22 == p15.movingDirection and true or p15.movingDirection == 0) and (v22 >= 0 and (v26 < v19 and v19 < v26 + 0.5) or v22 < 0 and (v19 < v26 and v26 - 0.5 < v19)) then
					p15:setLocomotiveState(Locomotive.STATE_REQUESTED_POSITION_BRAKING)
					v17.startBrakeDistance = v25
					v17.startBrakeSpeed = v17.speed
				else
					p15:updateVehiclePhysics(v22, 0, 0, p16)
				end
				p15:raiseActive()
				return
			end
		elseif v17.state == Locomotive.STATE_REQUESTED_POSITION_BRAKING then
			local v27 = Locomotive.getBrakeAcceleration(p15)
			local v28 = v17.startBrakeSpeed ^ 2 / (2 * v27)
			if math.abs(v28) < v17.startBrakeDistance - 10 then
				p15:setLocomotiveState(Locomotive.STATE_REQUESTED_POSITION)
			end
			if p15.movingDirection > 0 then
				p15:updateVehiclePhysics(-1, 0, 0, p16)
			else
				p15:updateVehiclePhysics(1, 0, 0, p16)
			end
			p15:raiseActive()
			if v17.speed == 0 then
				p15:setLocomotiveState(Locomotive.STATE_MANUAL_TRAVEL_ACTIVE)
				p15:stopMotor()
				return
			end
		elseif v17.state == Locomotive.STATE_MANUAL_TRAVEL_INACTIVE then
			if p15.movingDirection > 0 then
				p15:updateVehiclePhysics(-1, 0, 0, p16)
			elseif p15.movingDirection < 0 then
				p15:updateVehiclePhysics(1, 0, 0, p16)
			end
			p15:raiseActive()
		end
	end
end
function Locomotive.setTrainSystem(p29, p30, p31)
	p30(p29, p31)
	local v32 = p29.spec_locomotive
	if v32.powerArm ~= nil then
		local v33 = p31:getElectricitySpline()
		if v33 ~= nil then
			local v34 = p31:getElectricitySplineLength()
			local v35 = v34 - p31:getSplineLength()
			v32.splineDiff = math.abs(v35)
			v32.electricitySplineSearchTime = v32.splineDiff * 5 / v34
			v32.electricitySpline = v33
		end
	end
end
function Locomotive.getFullName(p36, _)
	return g_storeManager:getItemByXMLFilename(p36.configFileName).name
end
function Locomotive.getAreSurfaceSoundsActive(p37, _)
	return p37:getLastSpeed() > 0.1
end
function Locomotive.getTraveledDistanceStatsActive(p38, _)
	return p38.spec_locomotive.state == Locomotive.STATE_MANUAL_TRAVEL_ACTIVE
end
function Locomotive.getIsEnterable(p39, p40)
	if not p40(p39) then
		return false
	end
	if p39.trainSystem ~= nil and not p39.trainSystem:getIsTrainInDriveableRange() then
		return false
	end
	local v41 = p39.spec_locomotive
	return v41.state == Locomotive.STATE_MANUAL_TRAVEL_ACTIVE and true or v41.state == Locomotive.STATE_MANUAL_TRAVEL_INACTIVE
end
function Locomotive.getIsMapHotspotVisible(p42, p43)
	if not p43(p42) then
		return false
	end
	if p42.trainSystem ~= nil and not p42.trainSystem:getIsTrainInDriveableRange() then
		return false
	end
	local v44, _, v45 = getWorldTranslation(p42.rootNode)
	return math.abs(v44) <= g_currentMission.terrainSize * 0.5 and math.abs(v45) <= g_currentMission.terrainSize * 0.5
end
function Locomotive.setRequestedSplinePosition(p46, p47, _)
	local v48 = p46.spec_locomotive
	v48.requestedSplinePosition = p47
	p46:setLocomotiveState(Locomotive.STATE_REQUESTED_POSITION, true)
	local v49 = p46:getCurrentSplinePosition()
	local v50 = v48.requestedSplinePosition
	if v48.requestedSplinePosition < v49 then
		local v51 = v49 - (v50 + 1)
		local v52 = math.abs(v51)
		local v53 = v49 - v50
		if v52 < math.abs(v53) then
			v48.requestedSplinePosition = v50 + 1
		end
	end
	if p46.isServer then
		p46:startMotor()
	end
end
function Locomotive.getDistanceToRequestedPosition(p54)
	local v55 = p54.spec_locomotive
	if v55.state ~= Locomotive.STATE_REQUESTED_POSITION_BRAKING and v55.state ~= Locomotive.STATE_REQUESTED_POSITION then
		return 0
	end
	local v56 = p54:getCurrentSplinePosition()
	local v57 = v55.requestedSplinePosition - v56
	local v58 = math.abs(v57)
	return v55.state == Locomotive.STATE_REQUESTED_POSITION_BRAKING and v58 > 0.5 and 0 or v58 * p54.trainSystem:getSplineLength()
end
function Locomotive.setLocomotiveState(p59, p60, p61)
	p59.spec_locomotive.state = p60
	if p60 == Locomotive.STATE_AUTOMATIC_TRAVEL_ACTIVE then
		if p59.setRandomVehicleCharacter ~= nil then
			p59:setRandomVehicleCharacter()
		end
	elseif p60 == Locomotive.STATE_MANUAL_TRAVEL_ACTIVE then
		p59:restoreVehicleCharacter()
	end
	if g_server ~= nil and not p61 then
		g_server:broadcastEvent(LocomotiveStateEvent.new(p59, p60), nil, nil, p59)
	end
end
function Locomotive.startAutomatedTrainTravel(p62)
	p62:setLocomotiveState(Locomotive.STATE_AUTOMATIC_TRAVEL_ACTIVE)
	p62:startMotor()
end
function Locomotive.notifyPlayerFarmChanged(p63)
	if p63.trainSystem ~= nil then
		local v64 = p63.trainSystem.isRented
		if v64 then
			v64 = g_localPlayer.farmId == p63.trainSystem.rentFarmId
		end
		p63:setIsTabbable(v64)
	end
end
function Locomotive.onLeaveVehicle(p65)
	local v66 = p65.spec_locomotive
	if v66.state ~= Locomotive.STATE_AUTOMATIC_TRAVEL_ACTIVE then
		if p65:getIsReadyForAutomatedTrainTravel() then
			v66.automaticTravelStartTime = g_time + Locomotive.AUTOMATIC_DRIVE_DELAY
		end
		p65:setLocomotiveState(Locomotive.STATE_MANUAL_TRAVEL_INACTIVE)
		p65:raiseActive()
		v66.requestedSplinePosition = nil
	end
end
function Locomotive.onEnterVehicle(p67)
	local v68 = p67.spec_locomotive
	v68.requestedSplinePosition = nil
	v68.automaticTravelStartTime = nil
	if not g_currentMission.missionInfo.automaticMotorStartEnabled and (v68.state == Locomotive.STATE_AUTOMATIC_TRAVEL_ACTIVE or (v68.state == Locomotive.STATE_REQUESTED_POSITION or v68.state == Locomotive.STATE_REQUESTED_POSITION_BRAKING)) then
		p67:startMotor(true)
	end
	p67:setLocomotiveState(Locomotive.STATE_MANUAL_TRAVEL_ACTIVE)
end
function Locomotive.getIsReadyForAutomatedTrainTravel(p69, p70)
	if p69:getIsControlled() then
		return false
	else
		return p70(p69)
	end
end
function Locomotive.getIsMotorStarted(p71, p72)
	local v73 = p71.spec_locomotive
	return p72(p71) or ((v73.state == Locomotive.STATE_AUTOMATIC_TRAVEL_ACTIVE or v73.state == Locomotive.STATE_REQUESTED_POSITION) and true or v73.state == Locomotive.STATE_REQUESTED_POSITION_BRAKING)
end
function Locomotive.getDownhillForce(p74)
	local v75, v76, v77 = localDirectionToWorld(p74.rootNode, 0, 0, 1)
	local v78 = v76 / MathUtil.vector3Length(v75, v76, v77)
	local v79 = math.acos(v78) - 1.5707963267948966
	local v80 = p74.serverMass * 9.81
	local v81 = -v79
	return v80 * math.sin(v81)
end
function Locomotive.getBrakeAcceleration(p82)
	local v83 = p82.spec_locomotive
	local v84 = p82:getDownhillForce()
	local v85 = p82.serverMass * 9.81 * 0.18
	local v86 = v83.speed
	if math.abs(v86) >= 0.3 and p82:getIsControlled() then
		v85 = v85 * 0.05
	end
	local v87 = v83.speed
	local v88 = v85 * math.sign(v87)
	return 1 / p82.serverMass * (-v88 - v84)
end
function Locomotive.updateVehiclePhysics(p89, p90, p91, p92, p93, p94)
	local v95 = p89.spec_locomotive
	local v96 = p89.spec_drivable
	local v97 = p90(p89, p91 * v95.sellingDirection, p92, p93, p94)
	local v98 = g_physicsDt
	if g_server == nil then
		v98 = g_physicsDtUnclamped
	end
	local v99 = p89.serverMass * 9.81 * 0.18
	local v100 = p89:getDownhillForce()
	local v101 = math.min(300000, v99)
	if p89:getIsMotorStarted() then
		local v102 = v96 == nil and 1 or v96.reverserDirection
		if p89:getCruiseControlState() ~= Drivable.CRUISECONTROL_STATE_OFF then
			local v103 = p89:getCruiseControlSpeed() / 3.6
			if v95.speed < v102 * v103 then
				v97 = 1
			elseif v95.speed > v102 * v103 then
				v97 = -1
			end
		end
	else
		v101 = v99
	end
	if math.abs(v97) < 0.001 then
		local v104 = Locomotive.getBrakeAcceleration(p89)
		if v95.speed > 0 then
			local v105 = v95.speed + v104 * p94 / 1000
			v95.speed = math.max(0, v105)
		elseif v95.speed < 0 then
			local v106 = v95.speed + v104 * p94 / 1000
			v95.speed = math.min(0, v106)
		elseif v99 < math.abs(v100) then
			v95.speed = v95.speed + v104 * p94 / 1000
		end
		if v95.speed == 0 then
			v95.hasStopped = true
		else
			v95.hasStopped = false
		end
	else
		local v107 = v95.speed
		if math.abs(v107) > 0.1 then
			v95.hasStopped = false
		else
			local v108 = v95.speed
			if math.abs(v108) == 0 then
				v95.hasStopped = true
			end
		end
		if v95.hasStopped == nil or v95.hasStopped and math.abs(v97) > 0.01 then
			v95.nextMovingDirection = math.sign(v97)
		end
		local v109 = 0
		if v95.nextMovingDirection == nil or v95.nextMovingDirection * v97 > 0 then
			local v110 = v97 * v101
			v109 = 1 / p89.serverMass * (v110 - 0 - v100)
		else
			local v111 = 0
			local v112 = v95.speed
			local v113 = math.sign(v112) * math.abs(v97) * v99
			local v114 = v95.speed
			if math.abs(v114) < 0.1 then
				v95.speed = 0
			else
				v109 = 1 / p89.serverMass * (v111 - v113 - v100)
			end
		end
		v95.speed = v95.speed + v109 * v98 / 1000
	end
	local v115 = v95.motor
	if v95.speed > 0 then
		local v116 = v95.speed
		local v117 = v115.maxForwardSpeed
		v95.speed = math.min(v116, v117)
	elseif v95.speed < 0 then
		local v118 = v95.speed
		local v119 = -v115.maxBackwardSpeed
		v95.speed = math.max(v118, v119)
	end
	if v95.speed ~= 0 then
		p89.trainSystem:updateTrainPositionByLocomotiveSpeed(v98, v95.speed)
	end
	local v120 = v115.minRpm
	local v121 = v115.maxRpm
	if v95.lastAcceleration * v95.nextMovingDirection > 0 then
		local v122 = v95.lastVirtualRpm + 0.0005 * p94 * (v121 - v120)
		v95.lastVirtualRpm = math.min(v121, v122)
	else
		local v123 = v95.lastVirtualRpm - 0.001 * p94 * (v121 - v120)
		v95.lastVirtualRpm = math.max(v120, v123)
	end
	v115:setEqualizedMotorRpm(v95.lastVirtualRpm)
	v95.lastAcceleration = v97
end
function Locomotive.alignToSplineTime(p124, p125, p126, p127, p128)
	local v129 = p125(p124, p126, p127, p128)
	if v129 ~= nil then
		local v130 = p124.spec_locomotive
		if v130.powerArm ~= nil and v130.electricitySpline ~= nil then
			v129 = SplineUtil.getValidSplineTime(v129)
			local v131, v132, v133 = getWorldTranslation(v130.powerArm)
			local v134, v135, v136, _ = getLocalClosestSplinePosition(v130.electricitySpline, v129, v130.electricitySplineSearchTime, v131, v132, v133, 0.01)
			local _, v137, _ = worldToLocal(getParent(v130.powerArm), v134, v135, v136)
			local v138, _, v139 = getTranslation(v130.powerArm)
			setTranslation(v130.powerArm, v138, v137, v139)
			if v130.powerArm ~= nil then
				p124:setMovingToolDirty(v130.powerArm)
			end
		end
	end
	if not p124.isServer then
		p124:updateMapHotspot()
	end
	return v129
end
function Locomotive.getCanBeReset(_, _)
	return false
end
function Locomotive.getStopMotorOnLeave(p140, _)
	return p140.spec_locomotive.state == Locomotive.STATE_MANUAL_TRAVEL_ACTIVE and true or p140.spec_locomotive.state == Locomotive.STATE_MANUAL_TRAVEL_INACTIVE
end

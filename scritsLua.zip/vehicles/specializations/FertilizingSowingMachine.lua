FertilizingSowingMachine = {}
function FertilizingSowingMachine.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(SowingMachine, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Sprayer, p1)
	end
	return v2
end
function FertilizingSowingMachine.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("FertilizingSowingMachine")
	v3:register(XMLValueType.BOOL, "vehicle.fertilizingSowingMachine#needsSetIsTurnedOn", "Needs to be turned on to spray", false)
	v3:setXMLSpecializationType()
end
function FertilizingSowingMachine.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "processSowingMachineArea", FertilizingSowingMachine.processSowingMachineArea)
	SpecializationUtil.registerOverwrittenFunction(p4, "getUseSprayerAIRequirements", FertilizingSowingMachine.getUseSprayerAIRequirements)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAreEffectsVisible", FertilizingSowingMachine.getAreEffectsVisible)
end
function FertilizingSowingMachine.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", FertilizingSowingMachine)
end
function FertilizingSowingMachine.onLoad(p6, _)
	p6.spec_fertilizingSowingMachine.needsSetIsTurnedOn = p6.xmlFile:getValue("vehicle.fertilizingSowingMachine#needsSetIsTurnedOn", false)
	p6.spec_sprayer.needsToBeFilledToTurnOn = false
	p6.spec_sprayer.useSpeedLimit = false
	p6.needWaterInfo = true
end
function FertilizingSowingMachine.processSowingMachineArea(p7, _, p8, p9)
	local v10 = p7.spec_fertilizingSowingMachine
	local v11 = p7.spec_sowingMachine
	local v12 = p7.spec_sprayer
	local v13 = v12.workAreaParameters
	local v14 = v11.workAreaParameters
	p7.spec_sowingMachine.isWorking = p7:getLastSpeed() > 0.5
	if v11.waterSeeding and not p7.isInWater then
		v11.showWaterPlantingRequiredWarning = true
		if p7:getIsAIActive() then
			p7.rootVehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
		end
		return 0, 0
	end
	if not v11.waterSeeding and p7.isInWater then
		v11.showWaterPlantingProhibitedWarning = true
		if p7:getIsAIActive() then
			p7.rootVehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
		end
		return 0, 0
	end
	if not v14.isActive then
		return 0, 0
	end
	if not (p7:getIsAIActive() and g_currentMission.missionInfo.helperBuySeeds) and v14.seedsVehicle == nil then
		if p7:getIsAIActive() then
			p7.rootVehicle:stopCurrentAIJob(AIMessageErrorOutOfFill.new())
		end
		return 0, 0
	end
	if (v12.isSlurryTanker and g_currentMission.missionInfo.helperSlurrySource == 1 or (v12.isManureSpreader and g_currentMission.missionInfo.helperManureSource == 1 or v12.isFertilizerSprayer and not g_currentMission.missionInfo.helperBuyFertilizer)) and p7:getIsAIActive() then
		if v13.sprayFillType == nil or v13.sprayFillType == FillType.UNKNOWN then
			if v13.lastAIHasSprayed ~= nil then
				p7.rootVehicle:stopCurrentAIJob(AIMessageErrorOutOfFill.new())
				v13.lastAIHasSprayed = nil
			end
		else
			v13.lastAIHasSprayed = true
		end
	end
	if not v14.canFruitBePlanted then
		return 0, 0
	end
	local v15 = SprayType.FERTILIZER
	if v13.sprayFillLevel <= 0 or v10.needsSetIsTurnedOn and not p7:getIsTurnedOn() then
		v15 = nil
	end
	local v16, _, v17 = getWorldTranslation(p8.start)
	local v18, _, v19 = getWorldTranslation(p8.width)
	local v20, _, v21 = getWorldTranslation(p8.height)
	local v22 = g_fruitTypeManager:getFruitTypeByIndex(v11.workAreaParameters.seedsFruitType)
	if v22.seedRequiredFieldType ~= nil then
		local v23 = (v16 + v18 + v20) / 3
		local v24 = (v17 + v19 + v21) / 3
		if FSDensityMapUtil.getFieldTypeAtWorldPos(v23, v24) ~= v22.seedRequiredFieldType then
			if v22.seedRequiredFieldType == FieldType.RICE then
				v11.showFieldTypeWarningRiceRequired = true
			else
				v11.showFieldTypeWarningRegularRequired = true
			end
			if p7:getIsAIActive() then
				p7.rootVehicle:stopCurrentAIJob(AIMessageErrorNoFieldFound.new())
			end
		end
	end
	local v25, v26
	if v11.useDirectPlanting then
		v25, v26 = FSDensityMapUtil.updateDirectSowingArea(v14.seedsFruitType, v16, v17, v18, v19, v20, v21, v14.fieldGroundType, v14.ridgeSeeding, v14.angle, nil, v15)
	else
		v25, v26 = FSDensityMapUtil.updateSowingArea(v14.seedsFruitType, v16, v17, v18, v19, v20, v21, v14.fieldGroundType, v14.ridgeSeeding, v14.angle, nil, v15)
	end
	p7.spec_sowingMachine.isProcessing = p7.spec_sowingMachine.isWorking
	if v15 ~= nil then
		local v27 = v12.doubledAmountIsActive and 2 or 1
		local v28, v29 = FSDensityMapUtil.updateSprayArea(v16, v17, v18, v19, v20, v21, v15, v27)
		v13.lastChangedArea = v13.lastChangedArea + v28
		v13.lastTotalArea = v13.lastTotalArea + v29
		v13.lastStatsArea = 0
		v13.isActive = true
		v13.lastSprayTime = g_time
		local v30 = p7:getLastTouchedFarmlandFarmId()
		local v31 = MathUtil.areaToHa(v13.lastChangedArea, g_currentMission:getFruitPixelsToSqm())
		g_farmManager:updateFarmStats(v30, "sprayedHectares", v31)
		g_farmManager:updateFarmStats(v30, "sprayedTime", p9 / 60000)
		g_farmManager:updateFarmStats(v30, "sprayUsage", v13.usage)
	end
	v14.lastChangedArea = v14.lastChangedArea + v25
	v14.lastStatsArea = v14.lastStatsArea + v25
	v14.lastTotalArea = v14.lastTotalArea + v26
	FSDensityMapUtil.eraseTireTrack(v16, v17, v18, v19, v20, v21)
	p7:updateMissionSowingWarning(v16, v17)
	return v25, v26
end
function FertilizingSowingMachine.getUseSprayerAIRequirements(_, _)
	return false
end
function FertilizingSowingMachine.getAreEffectsVisible(p32, p33)
	local v34 = p33(p32)
	if v34 then
		v34 = p32:getFillUnitFillType(p32:getSprayerFillUnitIndex()) ~= FillType.UNKNOWN
	end
	return v34
end

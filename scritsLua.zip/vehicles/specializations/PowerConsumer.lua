PowerConsumer = {}
function PowerConsumer.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("powerConsumer", g_i18n:getText("configuration_powerConsumer"), "powerConsumer", VehicleConfigurationItem)
	g_storeManager:addSpecType("neededPower", "shopListAttributeIconPowerReq", PowerConsumer.loadSpecValueNeededPower, PowerConsumer.getSpecValueNeededPower, StoreSpecies.VEHICLE)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("PowerConsumer")
	PowerConsumer.registerPowerConsumerXMLPaths(v1, "vehicle.powerConsumer")
	PowerConsumer.registerPowerConsumerXMLPaths(v1, "vehicle.powerConsumer.powerConsumerConfigurations.powerConsumerConfiguration(?)")
	v1:register(XMLValueType.INT, "vehicle.storeData.specs.neededPower", "Needed power")
	v1:register(XMLValueType.INT, "vehicle.storeData.specs.neededPower#maxPower", "Max. recommended power")
	v1:register(XMLValueType.INT, "vehicle.powerConsumer.powerConsumerConfigurations.powerConsumerConfiguration(?)#neededPower", "Needed power")
	v1:addDelayedRegistrationFunc("WorkMode:workMode", function(p2, p3)
		p2:register(XMLValueType.FLOAT, p3 .. "#forceScale", "Scale the powerConsumer force up or down", 1)
		p2:register(XMLValueType.FLOAT, p3 .. "#ptoPowerScale", "Scale the powerConsumer pto power up or down", 1)
	end)
	v1:setXMLSpecializationType()
end
function PowerConsumer.registerPowerConsumerXMLPaths(p4, p5)
	p4:register(XMLValueType.NODE_INDEX, p5 .. "#forceNode", "Force node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. "#forceDirNode", "Force node", "Force node")
	p4:register(XMLValueType.FLOAT, p5 .. "#forceFactor", "Force factor", 1)
	p4:register(XMLValueType.FLOAT, p5 .. "#maxForce", "Max. force (kN)", 0)
	p4:register(XMLValueType.FLOAT, p5 .. "#forceDir", "Force direction", 1)
	p4:register(XMLValueType.BOOL, p5 .. "#useTurnOnState", "While vehicle is turned on the vehicle consumes the pto power", true)
	p4:register(XMLValueType.FLOAT, p5 .. "#turnOnPeakPowerMultiplier", "While turning the tool on a short peak power with this multiplier is consumed", 3)
	p4:register(XMLValueType.TIME, p5 .. "#turnOnPeakPowerDuration", "Duration for peak power while turning on (sec)", 2)
	p4:register(XMLValueType.L10N_STRING, p5 .. "#turnOnNotAllowedWarning", "Turn on not allowed text", "warning_insufficientPowerOutput")
	p4:register(XMLValueType.FLOAT, p5 .. "#neededMaxPtoPower", "Needed max. pto power", 0)
	p4:register(XMLValueType.FLOAT, p5 .. "#neededMinPtoPower", "Needed min. pto power", "neededMaxPtoPower")
	p4:register(XMLValueType.FLOAT, p5 .. "#ptoRpm", "Pto rpm", 0)
	p4:register(XMLValueType.FLOAT, p5 .. "#virtualPowerMultiplicator", "Virtual multiplicator for pto power to increased the motor load without reducing the available power for driving", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".speedLimitModifier(?)#offset", "Speed limit offset to apply")
	p4:register(XMLValueType.FLOAT, p5 .. ".speedLimitModifier(?)#minPowerHp", "Min. power in HP of root motor", 0)
	p4:register(XMLValueType.FLOAT, p5 .. ".speedLimitModifier(?)#maxPowerHp", "Max. power in HP of root motor", 0)
end
function PowerConsumer.prerequisitesPresent(_)
	return true
end
function PowerConsumer.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "loadPowerSetup", PowerConsumer.loadPowerSetup)
	SpecializationUtil.registerFunction(p6, "getPtoRpm", PowerConsumer.getPtoRpm)
	SpecializationUtil.registerFunction(p6, "getDoConsumePtoPower", PowerConsumer.getDoConsumePtoPower)
	SpecializationUtil.registerFunction(p6, "getPowerMultiplier", PowerConsumer.getPowerMultiplier)
	SpecializationUtil.registerFunction(p6, "getConsumedPtoTorque", PowerConsumer.getConsumedPtoTorque)
	SpecializationUtil.registerFunction(p6, "getConsumingLoad", PowerConsumer.getConsumingLoad)
end
function PowerConsumer.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "getCanBeTurnedOn", PowerConsumer.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p7, "getCanBeTurnedOnAll", PowerConsumer.getCanBeTurnedOnAll)
	SpecializationUtil.registerOverwrittenFunction(p7, "getTurnedOnNotAllowedWarning", PowerConsumer.getTurnedOnNotAllowedWarning)
	SpecializationUtil.registerOverwrittenFunction(p7, "getRawSpeedLimit", PowerConsumer.getRawSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadWorkModeFromXML", PowerConsumer.loadWorkModeFromXML)
end
function PowerConsumer.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", PowerConsumer)
	SpecializationUtil.registerEventListener(p8, "onUpdate", PowerConsumer)
	SpecializationUtil.registerEventListener(p8, "onStateChange", PowerConsumer)
	SpecializationUtil.registerEventListener(p8, "onWorkModeChanged", PowerConsumer)
	SpecializationUtil.registerEventListener(p8, "onTurnedOn", PowerConsumer)
end
function PowerConsumer.onLoad(p_u_9, _)
	local v_u_10 = p_u_9.spec_powerConsumer
	local v11 = Utils.getNoNil(p_u_9.configurations.powerConsumer, 1)
	local v12 = string.format("vehicle.powerConsumer.powerConsumerConfigurations.powerConsumerConfiguration(%d)", v11 - 1)
	local v13 = not p_u_9.xmlFile:hasProperty(v12) and "vehicle.powerConsumer" or v12
	v_u_10.forceNode = p_u_9.xmlFile:getValue(v13 .. "#forceNode", nil, p_u_9.components, p_u_9.i3dMappings)
	v_u_10.forceDirNode = p_u_9.xmlFile:getValue(v13 .. "#forceDirNode", v_u_10.forceNode, p_u_9.components, p_u_9.i3dMappings)
	v_u_10.forceFactor = p_u_9.xmlFile:getValue(v13 .. "#forceFactor", 1)
	v_u_10.maxForce = p_u_9.xmlFile:getValue(v13 .. "#maxForce", 0)
	v_u_10.forceDir = p_u_9.xmlFile:getValue(v13 .. "#forceDir", 1)
	v_u_10.useTurnOnState = p_u_9.xmlFile:getValue(v13 .. "#useTurnOnState", true)
	v_u_10.turnOnNotAllowedWarning = string.format(p_u_9.xmlFile:getValue(v13 .. "#turnOnNotAllowedWarning", "warning_insufficientPowerOutput", p_u_9.customEnvironment), p_u_9.typeDesc)
	p_u_9:loadPowerSetup(p_u_9.xmlFile, v13)
	v_u_10.speedLimitModifier = {}
	v_u_10.sourceMotorPeakPower = (1 / 0)
	v_u_10.turnOnPeakPowerMultiplier = p_u_9.xmlFile:getValue(v13 .. "#turnOnPeakPowerMultiplier", 3)
	v_u_10.turnOnPeakPowerDuration = p_u_9.xmlFile:getValue(v13 .. "#turnOnPeakPowerDuration", 2.5)
	v_u_10.turnOnPeakPowerTimer = -1
	p_u_9.xmlFile:iterate(v13 .. ".speedLimitModifier", function(_, p14)
		-- upvalues: (copy) p_u_9, (copy) v_u_10
		local v15 = {
			["offset"] = p_u_9.xmlFile:getValue(p14 .. "#offset")
		}
		if v15.offset == nil then
			Logging.xmlWarning(p_u_9.xmlFile, "Invalid offset found for \'%s\'", p14)
		else
			v15.minPowerKw = p_u_9.xmlFile:getValue(p14 .. "#minPowerHp", 0) * 0.735499
			v15.maxPowerKw = p_u_9.xmlFile:getValue(p14 .. "#maxPowerHp", 0) * 0.735499
			local v16 = v_u_10.speedLimitModifier
			table.insert(v16, v15)
		end
	end)
	if #v_u_10.speedLimitModifier == 0 then
		SpecializationUtil.removeEventListener(p_u_9, "onPostDetach", PowerConsumer)
	end
end
function PowerConsumer.onUpdate(p17, p18, _, _, _)
	if p17.isActive then
		local v19 = p17.spec_powerConsumer
		if v19.forceNode ~= nil and (p17.movingDirection == v19.forceDir and p17.lastSpeedReal > 0.0001) then
			local v20 = p17:getPowerMultiplier()
			if v20 ~= 0 then
				local v21 = v19.forceFactor * p17.lastSpeedReal * 1000 * p17:getTotalMass(false) / (p18 / 1000)
				local v22 = v19.maxForce
				local v23 = -math.min(v21, v22) * p17.movingDirection * v20
				local v24, v25, v26 = localDirectionToWorld(v19.forceDirNode, 0, 0, v23)
				local v27, v28, v29 = getCenterOfMass(v19.forceNode)
				addForce(v19.forceNode, v24, v25, v26, v27, v28, v29, true)
				if (VehicleDebug.state == VehicleDebug.DEBUG_PHYSICS or VehicleDebug.state == VehicleDebug.DEBUG_TUNING) and p17.isActiveForInputIgnoreSelectionIgnoreAI then
					local v30 = string.format("frictionForce=%.2f maxForce=%.2f -> force=%.2f", v21, v19.maxForce, v23)
					renderText(0.7, 0.85, getCorrectTextSize(0.02), v30)
				end
			end
		end
		if v19.turnOnPeakPowerTimer > 0 then
			v19.turnOnPeakPowerTimer = v19.turnOnPeakPowerTimer - p18
		end
	end
end
function PowerConsumer.loadPowerSetup(p31, p32, p33)
	local v34 = p31.spec_powerConsumer
	XMLUtil.checkDeprecatedXMLElements(p32, p33 .. "#neededPtoPower", string.format("%s#neededMinPtoPower and %s#neededMaxPtoPower", p33, p33))
	v34.neededMaxPtoPower = p32:getValue(p33 .. "#neededMaxPtoPower", 0)
	v34.neededMinPtoPower = p32:getValue(p33 .. "#neededMinPtoPower", v34.neededMaxPtoPower)
	if v34.neededMaxPtoPower < v34.neededMinPtoPower then
		Logging.xmlWarning(p31.xmlFile, "\'%s#neededMaxPtoPower\' is smaller than \'%s#neededMinPtoPower\'", p33, p33)
	end
	v34.ptoRpm = p32:getValue(p33 .. "#ptoRpm", 0)
	v34.virtualPowerMultiplicator = p32:getValue(p33 .. "#virtualPowerMultiplicator", 1)
end
function PowerConsumer.getPtoRpm(p35)
	return not p35:getDoConsumePtoPower() and 0 or p35.spec_powerConsumer.ptoRpm
end
function PowerConsumer.getDoConsumePtoPower(p36)
	local v37 = p36.spec_powerConsumer.useTurnOnState
	if v37 then
		if p36.getIsTurnedOn == nil then
			v37 = false
		else
			v37 = p36:getIsTurnedOn()
		end
	end
	return v37
end
function PowerConsumer.getPowerMultiplier(_)
	return 1
end
function PowerConsumer.getConsumedPtoTorque(p38, p39, p40)
	if p38:getDoConsumePtoPower() or p39 ~= nil and p39 then
		local v41 = p38.spec_powerConsumer
		local v42 = v41.ptoRpm
		if v42 > 0.001 then
			local v43, v44 = p38:getConsumingLoad()
			local v45 = v44 <= 0 and 1 or v43 / v44
			local v46 = v41.turnOnPeakPowerTimer / v41.turnOnPeakPowerDuration
			local v47 = math.min(v46, 1)
			local v48 = math.max(v47, 0) * v41.turnOnPeakPowerMultiplier
			local v49 = math.max(v48, 1)
			local v50 = p40 == true and 1 or v49
			return (v41.neededMinPtoPower + v45 * (v41.neededMaxPtoPower - v41.neededMinPtoPower)) / (v42 * 3.141592653589793 / 30), v41.virtualPowerMultiplicator * v50
		end
	end
	return 0, 1
end
function PowerConsumer.getConsumingLoad(_)
	return 0, 0
end
function PowerConsumer.getCanBeTurnedOn(p51, p52)
	local v53 = p51.rootVehicle
	if v53 ~= nil and v53.getMotor ~= nil then
		local v54 = v53:getMotor()
		local v55, _ = p51:getConsumedPtoTorque(true)
		local v56, _ = PowerConsumer.getTotalConsumedPtoTorque(v53, p51)
		local v57 = (v55 + v56) / v54:getPtoMotorRpmRatio()
		if v57 > 0 and (0.9 * v54:getPeakTorque() < v57 and not p51:getIsTurnedOn()) then
			return false, true
		end
	end
	if p52 == nil then
		return true, false
	else
		return p52(p51)
	end
end
function PowerConsumer.getCanBeTurnedOnAll(p58, p59)
	if not p59(p58) then
		return false
	end
	local v60 = p58.rootVehicle
	if v60 ~= nil and v60.getMotor ~= nil then
		local v61 = v60:getMotor()
		local v62, _ = PowerConsumer.getTotalConsumedPtoTorque(v60, nil, true)
		local v63 = v62 / v61:getPtoMotorRpmRatio()
		if v63 > 0 and (0.9 * v61:getPeakTorque() < v63 and not p58:getIsTurnedOn()) then
			return false, p58.spec_powerConsumer.turnOnNotAllowedWarning
		end
	end
	return true, false
end
function PowerConsumer.getTurnedOnNotAllowedWarning(p64, p65)
	local v66 = p64.spec_powerConsumer
	local _, v67 = PowerConsumer.getCanBeTurnedOn(p64)
	if v67 then
		return v66.turnOnNotAllowedWarning
	else
		return p65(p64)
	end
end
function PowerConsumer.getRawSpeedLimit(p68, p69)
	local v70 = p69(p68)
	local v71 = p68.spec_powerConsumer
	for v72 = #v71.speedLimitModifier, 1, -1 do
		local v73 = v71.speedLimitModifier[v72]
		if v71.sourceMotorPeakPower >= v73.minPowerKw and v71.sourceMotorPeakPower <= v73.maxPowerKw then
			return v70 + v73.offset
		end
	end
	return v70
end
function PowerConsumer.loadWorkModeFromXML(p74, p75, p76, p77, p78)
	if not p75(p74, p76, p77, p78) then
		return false
	end
	p78.forceScale = p76:getValue(p77 .. "#forceScale", 1)
	p78.ptoPowerScale = p76:getValue(p77 .. "#ptoPowerScale", 1)
	return true
end
function PowerConsumer.onStateChange(p79, p80, _)
	if p80 == VehicleStateChange.ATTACH or p80 == VehicleStateChange.DETACH then
		local v81 = p79.spec_powerConsumer
		local v82 = p79.rootVehicle
		if v82 ~= nil and v82.getMotor ~= nil then
			v81.sourceMotorPeakPower = v82:getMotor().peakMotorPower
			return
		end
		v81.sourceMotorPeakPower = (1 / 0)
	end
end
function PowerConsumer.onWorkModeChanged(p83, p84, _)
	if p84.forceScale ~= nil then
		local v85 = p83.spec_powerConsumer
		if v85.maxForceOrig == nil then
			v85.maxForceOrig = v85.maxForce
			v85.neededMinPtoPowerOrig = v85.neededMinPtoPower
			v85.neededMaxPtoPowerOrig = v85.neededMaxPtoPower
		end
		v85.maxForce = v85.maxForceOrig * p84.forceScale
		v85.neededMinPtoPower = v85.neededMinPtoPowerOrig * p84.forceScale
		v85.neededMaxPtoPower = v85.neededMaxPtoPowerOrig * p84.forceScale
	end
end
function PowerConsumer.onTurnedOn(p86)
	p86.spec_powerConsumer.turnOnPeakPowerTimer = p86.spec_powerConsumer.turnOnPeakPowerDuration * 1.5
end
function PowerConsumer.getTotalConsumedPtoTorque(p87, p88, p89, p90)
	local v91, v92
	if p87 == p88 or p87.getConsumedPtoTorque == nil then
		v91 = 0
		v92 = 1
	else
		v91, v92 = p87:getConsumedPtoTorque(p89, p90)
	end
	if p87.getAttachedImplements ~= nil then
		local v93 = p87:getAttachedImplements()
		for _, v94 in pairs(v93) do
			local v95, v96 = PowerConsumer.getTotalConsumedPtoTorque(v94.object, p88, p89, p90)
			v91 = v91 + v95
			if v91 == 0 then
				v92 = v96
			else
				local v97 = v95 / v91
				v92 = v92 * (1 - v97) + v96 * v97
			end
		end
	end
	return v91, v92
end
function PowerConsumer.getMaxPtoRpm(p98)
	local v99 = p98.getPtoRpm == nil and 0 or p98:getPtoRpm()
	if p98.getAttachedImplements ~= nil then
		local v100 = p98:getAttachedImplements()
		for _, v101 in pairs(v100) do
			local v102 = PowerConsumer.getMaxPtoRpm
			local v103 = v101.object
			v99 = math.max(v99, v102(v103))
		end
	end
	return v99
end
function PowerConsumer.consoleSetPowerConsumer(_, p104, p105, p106, p107, p108, p109)
	if p104 == nil then
		return "No arguments given! Usage: gsPowerConsumerSet <neededMinPtoPower> <neededMaxPtoPower> <forceFactor> <maxForce> <forceDir> <ptoRpm>"
	end
	local v110
	if g_currentMission == nil or (g_localPlayer:getCurrentVehicle() == nil or (g_localPlayer:getCurrentVehicle():getSelectedImplement() == nil or g_localPlayer:getCurrentVehicle():getSelectedImplement().object.spec_powerConsumer == nil)) then
		v110 = nil
	else
		v110 = g_localPlayer:getCurrentVehicle():getSelectedImplement().object
	end
	if v110 == nil then
		return "No vehicle with powerConsumer specialization selected"
	end
	v110.spec_powerConsumer.neededMinPtoPower = Utils.getNoNil(p104, v110.spec_powerConsumer.neededMinPtoPower)
	v110.spec_powerConsumer.neededMaxPtoPower = Utils.getNoNil(p105, v110.spec_powerConsumer.neededMaxPtoPower)
	v110.spec_powerConsumer.forceFactor = Utils.getNoNil(p106, v110.spec_powerConsumer.forceFactor)
	v110.spec_powerConsumer.maxForce = Utils.getNoNil(p107, v110.spec_powerConsumer.maxForce)
	v110.spec_powerConsumer.forceDir = Utils.getNoNil(p108, v110.spec_powerConsumer.forceDir)
	v110.spec_powerConsumer.ptoRpm = Utils.getNoNil(p109, v110.spec_powerConsumer.ptoRpm)
	for _, v111 in pairs(g_currentMission.vehicleSystem.vehicles) do
		if v111.configFileName == v110.configFileName then
			v111.spec_powerConsumer.neededMinPtoPower = v110.spec_powerConsumer.neededMinPtoPower
			v111.spec_powerConsumer.neededMaxPtoPower = v110.spec_powerConsumer.neededMaxPtoPower
			v111.spec_powerConsumer.forceFactor = v110.spec_powerConsumer.forceFactor
			v111.spec_powerConsumer.maxForce = v110.spec_powerConsumer.maxForce
			v111.spec_powerConsumer.forceDir = v110.spec_powerConsumer.forceDir
			v111.spec_powerConsumer.ptoRpm = v110.spec_powerConsumer.ptoRpm
		end
	end
	return string.format("Updated power consumer for \'%s\'", v110.configFileName)
end
addConsoleCommand("gsPowerConsumerSet", "Sets properties of the powerConsumer specialization", "consoleSetPowerConsumer", PowerConsumer)
function PowerConsumer.loadSpecValueNeededPower(p112, _, _)
	local v113 = {
		["base"] = p112:getValue("vehicle.storeData.specs.neededPower"),
		["maxPower"] = p112:getValue("vehicle.storeData.specs.neededPower#maxPower"),
		["config"] = {}
	}
	local v114 = 0
	while true do
		local v115 = string.format("vehicle.powerConsumer.powerConsumerConfigurations.powerConsumerConfiguration(%d)", v114)
		if not p112:hasProperty(v115) then
			break
		end
		v113.config[v114 + 1] = p112:getValue(v115 .. "#neededPower")
		v114 = v114 + 1
	end
	return v113
end
function PowerConsumer.getSpecValueNeededPower(p116, _, _, _, _, _)
	if p116.specs.neededPower == nil then
		return nil
	end
	local v117 = (1 / 0)
	local v118 = (-1 / 0)
	for _, v119 in pairs(p116.specs.neededPower.config) do
		v117 = math.min(v117, v119)
		v118 = math.max(v118, v119)
	end
	if v117 == (1 / 0) then
		v117 = p116.specs.neededPower.base or 0
		v118 = p116.specs.neededPower.maxPower
	end
	if v117 == 0 then
		return nil
	end
	if v118 == nil or v117 == v118 then
		local v120, v121 = g_i18n:getPower(v117)
		return string.format(g_i18n:getText("shop_neededPowerValue"), MathUtil.round(v121), MathUtil.round(v120))
	end
	local v122, _ = g_i18n:getPower(v117)
	local v123, _ = g_i18n:getPower(v118)
	return string.format(g_i18n:getText("shop_neededPowerValueMinMax"), MathUtil.round(v122), MathUtil.round(v123))
end

ConnectedAttributes = {}
ConnectedAttributes.COMBINE_OPERATION = {}
ConnectedAttributes.COMBINE_OPERATION.AVERAGE = 0
ConnectedAttributes.COMBINE_OPERATION.SUM = 1
ConnectedAttributes.COMBINE_OPERATION.SUBTRACT = 2
ConnectedAttributes.COMBINE_OPERATION.MULTIPLY = 3
ConnectedAttributes.COMBINE_OPERATION.DIVIDE = 4
function ConnectedAttributes.prerequisitesPresent(_)
	return true
end
function ConnectedAttributes.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("ConnectedAttributes")
	v1:register(XMLValueType.BOOL, "vehicle.connectedAttributes.attribute(?)#isActiveDirty", "Attribute is permanently updated", false)
	v1:register(XMLValueType.FLOAT, "vehicle.connectedAttributes.attribute(?)#maxUpdateDistance", "If the player is within this distance to the vehicle, the attribute is updated", "always")
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).updateByAnimation(?)#name", "Name of animation that triggers a update of the connected value")
	v1:register(XMLValueType.BOOL, "vehicle.connectedAttributes.attribute(?).updateByAnimation(?)#onStart", "Update is triggered on start of the animation", false)
	v1:register(XMLValueType.BOOL, "vehicle.connectedAttributes.attribute(?).updateByAnimation(?)#onRun", "Update is triggered while the animation is running", false)
	v1:register(XMLValueType.BOOL, "vehicle.connectedAttributes.attribute(?).updateByAnimation(?)#onStop", "Update is triggered while the animation is stopped", false)
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).prerequisites.animation(?)#name", "Name of animation that needs to be in the defined target range")
	v1:register(XMLValueType.FLOAT, "vehicle.connectedAttributes.attribute(?).prerequisites.animation(?)#minTime", "Min. time of animation", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.connectedAttributes.attribute(?).prerequisites.animation(?)#maxTime", "Max. time of animation", 1)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.connectedAttributes.attribute(?).source(?)#node", "Source reference node")
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).source(?)#type", "Source type (" .. ConnectedAttributes.TYPES_STRING .. ")")
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).source(?)#values", "Value definition from the source")
	for v2 = 1, #ConnectedAttributes.TYPES do
		ConnectedAttributes.TYPES[v2].registerSourceXMLPaths(v1, "vehicle.connectedAttributes.attribute(?).source(?)")
	end
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).combine(?)#value", "New value id of the combined value")
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).combine(?)#operation", "Operation to be executed on the values (AVERAGE, SUM, SUBTRACT, MULTIPLY, DIVIDE)")
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).combine(?)#values", "Values to combine")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.connectedAttributes.attribute(?).target(?)#node", "Target reference node")
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).target(?)#type", "Target type (" .. ConnectedAttributes.TYPES_STRING .. ")")
	v1:register(XMLValueType.STRING, "vehicle.connectedAttributes.attribute(?).target(?)#values", "Value definition how the source values are applied to the target")
	for v3 = 1, #ConnectedAttributes.TYPES do
		ConnectedAttributes.TYPES[v3].registerTargetXMLPaths(v1, "vehicle.connectedAttributes.attribute(?).target(?)")
	end
	v1:addDelayedRegistrationFunc("Cylindered:movingTool", function(p4, p5)
		p4:register(XMLValueType.VECTOR_N, p5 .. "#connectedAttributeIndices", "Connected attributes to update")
	end)
	v1:addDelayedRegistrationFunc("Cylindered:movingPart", function(p6, p7)
		p6:register(XMLValueType.VECTOR_N, p7 .. "#connectedAttributeIndices", "Connected attributes to update")
	end)
	v1:setXMLSpecializationType()
end
function ConnectedAttributes.registerFunctions(_) end
function ConnectedAttributes.registerOverwrittenFunctions(p8)
	SpecializationUtil.registerOverwrittenFunction(p8, "loadExtraDependentParts", ConnectedAttributes.loadExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p8, "updateExtraDependentParts", ConnectedAttributes.updateExtraDependentParts)
end
function ConnectedAttributes.registerEventListeners(p9)
	SpecializationUtil.registerEventListener(p9, "onLoad", ConnectedAttributes)
	SpecializationUtil.registerEventListener(p9, "onLoadFinished", ConnectedAttributes)
	SpecializationUtil.registerEventListener(p9, "onUpdate", ConnectedAttributes)
	SpecializationUtil.registerEventListener(p9, "onUpdateEnd", ConnectedAttributes)
	SpecializationUtil.registerEventListener(p9, "onPlayAnimation", ConnectedAttributes)
	SpecializationUtil.registerEventListener(p9, "onUpdateAnimation", ConnectedAttributes)
	SpecializationUtil.registerEventListener(p9, "onFinishAnimation", ConnectedAttributes)
end
function ConnectedAttributes.onLoad(p_u_10, _)
	local v_u_11 = p_u_10.spec_connectedAttributes
	v_u_11.attributes = {}
	v_u_11.dirtyAttributes = {}
	local v_u_12 = false
	local v_u_13 = false
	local v_u_14 = false
	p_u_10.xmlFile:iterate("vehicle.connectedAttributes.attribute", function(_, p15)
		-- upvalues: (copy) p_u_10, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (copy) v_u_11
		local v_u_16 = {
			["isActive"] = false,
			["isActiveDirty"] = p_u_10.xmlFile:getValue(p15 .. "#isActiveDirty", false),
			["maxUpdateDistance"] = p_u_10.xmlFile:getValue(p15 .. "#maxUpdateDistance"),
			["values"] = {},
			["updateByAnimations"] = {}
		}
		p_u_10.xmlFile:iterate(p15 .. ".updateByAnimation", function(_, p17)
			-- upvalues: (ref) p_u_10, (copy) v_u_16, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14
			local v18 = {
				["animationName"] = p_u_10.xmlFile:getValue(p17 .. "#name")
			}
			if v18.animationName ~= nil then
				v18.onStart = p_u_10.xmlFile:getValue(p17 .. "#onStart", false)
				v18.onRun = p_u_10.xmlFile:getValue(p17 .. "#onRun", false)
				v18.onStop = p_u_10.xmlFile:getValue(p17 .. "#onStop", false)
				if v18.onStart or (v18.onRun or v18.onStop) then
					local v19 = v_u_16.updateByAnimations
					table.insert(v19, v18)
					v_u_12 = v_u_12 or v18.onStart
					v_u_13 = v_u_13 or v18.onRun
					v_u_14 = v_u_14 or v18.onStop
				end
			end
		end)
		v_u_16.prerequisites = {}
		p_u_10.xmlFile:iterate(p15 .. ".prerequisites.animation", function(_, p20)
			-- upvalues: (ref) p_u_10, (copy) v_u_16
			local v_u_21 = p_u_10.xmlFile:getValue(p20 .. "#name")
			local v_u_22 = p_u_10.xmlFile:getValue(p20 .. "#minTime", 0)
			local v_u_23 = p_u_10.xmlFile:getValue(p20 .. "#maxTime", 1)
			if v_u_21 ~= nil and (v_u_22 > 0 or v_u_23 < 1) then
				local v24 = v_u_16.prerequisites
				local function v27()
					-- upvalues: (ref) p_u_10, (copy) v_u_21, (copy) v_u_22, (copy) v_u_23
					local v25 = p_u_10:getAnimationTime(v_u_21)
					local v26
					if v_u_22 <= v25 then
						v26 = v25 <= v_u_23
					else
						v26 = false
					end
					return v26
				end
				table.insert(v24, v27)
			end
		end)
		v_u_16.sources = {}
		p_u_10.xmlFile:iterate(p15 .. ".source", function(_, p28)
			-- upvalues: (ref) p_u_10, (copy) v_u_16
			local v29 = {
				["node"] = p_u_10.xmlFile:getValue(p28 .. "#node", nil, p_u_10.components, p_u_10.i3dMappings)
			}
			if v29.node == nil then
				Logging.xmlWarning(p_u_10.xmlFile, "Missing node in \'%s\'", p28)
				return
			else
				local v30 = p_u_10.xmlFile:getValue(p28 .. "#type")
				if v30 == nil then
					Logging.xmlWarning(p_u_10.xmlFile, "Missing type in \'%s\'", p28)
					return
				else
					v29.typeClass = ConnectedAttributes.TYPES_BY_NAME[v30:upper()]
					if v29.typeClass == nil then
						Logging.xmlWarning(p_u_10.xmlFile, "Invalid type \'%s\' in \'%s\'", v30, p28)
						return
					elseif v29.typeClass.isAvailable == nil or v29.typeClass.isAvailable(p_u_10) then
						v29.object = v29.typeClass.new(p_u_10, v29.node, p_u_10.xmlFile, p28, p_u_10.components, p_u_10.i3dMappings)
						if v29.object == nil then
							Logging.xmlWarning(p_u_10.xmlFile, "Failed to load source \'%s\'", p28)
						else
							v29.values = {}
							local v31 = p_u_10.xmlFile:getValue(p28 .. "#values")
							if v31 ~= nil then
								local v32 = v31:split(" ")
								local v33 = #v32
								local v34 = v29.typeClass.NUM_VALUES
								for v35 = 1, math.min(v33, v34) do
									if v32[v35] ~= "-" then
										v29.values[v35] = v32[v35]
										v_u_16.values[v32[v35]] = 0
									end
								end
							end
							local v36 = v_u_16.sources
							table.insert(v36, v29)
						end
					else
						return
					end
				end
			end
		end)
		v_u_16.combinations = {}
		p_u_10.xmlFile:iterate(p15 .. ".combine", function(_, p37)
			-- upvalues: (ref) p_u_10, (copy) v_u_16
			local v38 = {
				["value"] = p_u_10.xmlFile:getValue(p37 .. "#value")
			}
			if v38.value == nil then
				Logging.xmlWarning(p_u_10.xmlFile, "Missing value for \'%s\'", p37)
				return
			else
				local v39 = p_u_10.xmlFile:getValue(p37 .. "#operation")
				if v39 ~= nil then
					v38.operation = ConnectedAttributes.COMBINE_OPERATION[v39:upper()]
				end
				if v38.operation == nil then
					Logging.xmlWarning(p_u_10.xmlFile, "Invalid operation for \'%s\'", p37)
					return
				else
					v38.values = {}
					local v40 = p_u_10.xmlFile:getValue(p37 .. "#values")
					if v40 ~= nil then
						local v41 = v40:split(" ")
						for v42 = 1, #v41 do
							local v43 = v41[v42]
							if v43 ~= "" and v_u_16.values[v43] ~= nil then
								local v44 = v38.values
								table.insert(v44, v43)
							end
						end
					end
					v38.numValues = #v38.values
					if v38.numValues == 0 then
						Logging.xmlWarning(p_u_10.xmlFile, "Missing values for \'%s\'", p37)
					else
						v_u_16.values[v38.value] = 0
						local v45 = v_u_16.combinations
						table.insert(v45, v38)
					end
				end
			end
		end)
		v_u_16.targets = {}
		p_u_10.xmlFile:iterate(p15 .. ".target", function(_, p46)
			-- upvalues: (ref) p_u_10, (copy) v_u_16
			local v47 = {
				["node"] = p_u_10.xmlFile:getValue(p46 .. "#node", nil, p_u_10.components, p_u_10.i3dMappings)
			}
			if v47.node == nil then
				Logging.xmlWarning(p_u_10.xmlFile, "Missing node in \'%s\'", p46)
				return
			else
				local v48 = p_u_10.xmlFile:getValue(p46 .. "#type")
				if v48 == nil then
					Logging.xmlWarning(p_u_10.xmlFile, "Missing type in \'%s\'", p46)
					return
				else
					v47.typeClass = ConnectedAttributes.TYPES_BY_NAME[v48:upper()]
					if v47.typeClass == nil then
						Logging.xmlWarning(p_u_10.xmlFile, "Invalid type \'%s\' in \'%s\'", v48, p46)
						return
					elseif v47.typeClass.isAvailable == nil or v47.typeClass.isAvailable(p_u_10) then
						v47.object = v47.typeClass.new(p_u_10, v47.node, p_u_10.xmlFile, p46, p_u_10.components, p_u_10.i3dMappings)
						if v47.object == nil then
							Logging.xmlWarning(p_u_10.xmlFile, "Failed to load target \'%s\'", p46)
						else
							v47.object:get()
							v47.values = {}
							v47.factors = {}
							v47.additionals = {}
							v47.toSourceValue = {}
							local v49 = p_u_10.xmlFile:getValue(p46 .. "#values")
							if v49 ~= nil then
								local v50 = v49:split(" ")
								local v51 = #v50
								local v52 = v47.typeClass.NUM_VALUES
								for v53 = 1, math.min(v51, v52) do
									if v50[v53] ~= "-" then
										if v50[v53]:contains("*") then
											local v54 = v50[v53]:split("*")
											v47.values[v53] = v54[1]
											local v55 = v47.factors
											local v56 = v54[2]
											v55[v53] = tonumber(v56) or 1
											v47.additionals[v53] = 0
										elseif v50[v53]:contains("/") then
											local v57 = v50[v53]:split("/")
											v47.values[v53] = v57[1]
											local v58 = v47.factors
											local v59 = v57[2]
											v58[v53] = 1 / (tonumber(v59) or 1)
											v47.additionals[v53] = 0
										elseif v50[v53]:contains("+") then
											local v60 = v50[v53]:split("+")
											v47.values[v53] = v60[1]
											v47.factors[v53] = 1
											local v61 = v47.additionals
											local v62 = v60[2]
											v61[v53] = tonumber(v62) or 0
										elseif v50[v53]:contains("-") then
											local v63 = v50[v53]:split("-")
											if v63[1] == "" then
												if v_u_16.values[v63[2]] == nil then
													v47.values[v53] = next(v_u_16.values)
													v47.factors[v53] = 0
													local v64 = v47.additionals
													local v65 = v50[v53]
													v64[v53] = tonumber(v65)
												else
													v47.values[v53] = v63[2]
													v47.factors[v53] = -1
													v47.additionals[v53] = 0
												end
											else
												v47.values[v53] = v63[1]
												v47.factors[v53] = 1
												local v66 = v47.additionals
												local v67 = v63[2]
												v66[v53] = -(tonumber(v67) or 0)
											end
										elseif v_u_16.values[v50[v53]] == nil then
											local v68 = v50[v53]
											if tonumber(v68) ~= nil then
												v47.values[v53] = next(v_u_16.values)
												v47.factors[v53] = 0
												local v69 = v47.additionals
												local v70 = v50[v53]
												v69[v53] = tonumber(v70)
											end
										else
											v47.values[v53] = v50[v53]
											v47.factors[v53] = 1
											v47.additionals[v53] = 0
										end
										if v47.values[v53] == nil or (v47.values[v53] == "" or v_u_16.values[v47.values[v53]] == nil) then
											v47.values[v53] = nil
											v47.factors[v53] = nil
											v47.additionals[v53] = nil
											Logging.xmlWarning(p_u_10.xmlFile, "Failed to validate target value \'%s\' of \'%s\' in \'%s\'", v50[v53], v49, p46)
										else
											v47.toSourceValue[v53] = v_u_16.values[v47.values[v53]]
										end
									end
								end
							end
							local v71 = v_u_16.targets
							table.insert(v71, v47)
						end
					else
						return
					end
				end
			end
		end)
		if #v_u_16.sources >= 1 and #v_u_16.targets >= 1 then
			local v72 = v_u_11.attributes
			table.insert(v72, v_u_16)
			if v_u_16.isActiveDirty then
				local v73 = v_u_11.dirtyAttributes
				table.insert(v73, v_u_16)
			end
		end
	end)
	if #v_u_11.attributes == 0 then
		SpecializationUtil.removeEventListener(p_u_10, "onLoadFinished", ConnectedAttributes)
		SpecializationUtil.removeEventListener(p_u_10, "onUpdate", ConnectedAttributes)
	elseif #v_u_11.dirtyAttributes == 0 then
		SpecializationUtil.removeEventListener(p_u_10, "onUpdate", ConnectedAttributes)
	end
	if not v_u_12 then
		SpecializationUtil.removeEventListener(p_u_10, "onPlayAnimation", ConnectedAttributes)
	end
	if not v_u_13 then
		SpecializationUtil.removeEventListener(p_u_10, "onUpdateAnimation", ConnectedAttributes)
	end
	if not v_u_14 then
		SpecializationUtil.removeEventListener(p_u_10, "onFinishAnimation", ConnectedAttributes)
	end
end
function ConnectedAttributes.onLoadFinished(p74, _)
	local v75 = p74.spec_connectedAttributes
	for _, v76 in ipairs(v75.attributes) do
		ConnectedAttributes.updateAttribute(v76, true)
	end
end
function ConnectedAttributes.onUpdate(p77, _, _, _, _)
	local v78 = p77.spec_connectedAttributes
	for v79 = 1, #v78.dirtyAttributes do
		local v80 = v78.dirtyAttributes[v79]
		if v80.maxUpdateDistance == nil or p77.currentUpdateDistance < v80.maxUpdateDistance then
			ConnectedAttributes.updateAttribute(v80)
		end
	end
end
function ConnectedAttributes.onUpdateEnd(p81, _, p82, p83, p84)
	ConnectedAttributes.onUpdate(p81, 99999, p82, p83, p84)
end
function ConnectedAttributes.onPlayAnimation(p85, p86)
	local v87 = p85.spec_connectedAttributes
	for _, v88 in ipairs(v87.attributes) do
		for _, v89 in ipairs(v88.updateByAnimations) do
			if v89.onStart and v89.animationName == p86 then
				ConnectedAttributes.updateAttribute(v88, true)
				break
			end
		end
	end
end
function ConnectedAttributes.onUpdateAnimation(p90, p91)
	local v92 = p90.spec_connectedAttributes
	for _, v93 in ipairs(v92.attributes) do
		for _, v94 in ipairs(v93.updateByAnimations) do
			if v94.onRun and v94.animationName == p91 then
				ConnectedAttributes.updateAttribute(v93, true)
				break
			end
		end
	end
end
function ConnectedAttributes.onFinishAnimation(p95, p96)
	local v97 = p95.spec_connectedAttributes
	for _, v98 in ipairs(v97.attributes) do
		for _, v99 in ipairs(v98.updateByAnimations) do
			if v99.onStop and v99.animationName == p96 then
				ConnectedAttributes.updateAttribute(v98, true)
				break
			end
		end
	end
end
function ConnectedAttributes.updateAttribute(p100, p101)
	local v102 = true
	for v103 = 1, #p100.prerequisites do
		if not p100.prerequisites[v103]() then
			v102 = false
			break
		end
	end
	if v102 then
		local v104 = p100.values
		local v105 = p100.isActive ~= v102 and true or p101
		for v106 = 1, #p100.sources do
			local v107 = p100.sources[v106]
			local v108 = v107.object
			v108:get()
			for v109, v110 in pairs(v107.values) do
				local v111 = v108.data[v109]
				if v111 ~= v104[v110] then
					v104[v110] = v111
					v105 = true
				end
			end
		end
		for v112 = 1, #p100.combinations do
			local v113 = p100.combinations[v112]
			if v113.operation == ConnectedAttributes.COMBINE_OPERATION.AVERAGE then
				local v114 = 0
				for v115 = 1, v113.numValues do
					v114 = v114 + v104[v113.values[v115]]
				end
				v104[v113.value] = v114 / v113.numValues
			elseif v113.operation == ConnectedAttributes.COMBINE_OPERATION.SUM then
				local v116 = 0
				for v117 = 1, v113.numValues do
					v116 = v116 + v104[v113.values[v117]]
				end
				v104[v113.value] = v116
			elseif v113.operation == ConnectedAttributes.COMBINE_OPERATION.SUBTRACT then
				local v118 = v104[v113.values[1]]
				for v119 = 2, v113.numValues do
					v118 = v118 - v104[v113.values[v119]]
				end
				v104[v113.value] = v118
			elseif v113.operation == ConnectedAttributes.COMBINE_OPERATION.MULTIPLY then
				local v120 = v104[v113.values[1]]
				for v121 = 2, v113.numValues do
					v120 = v120 * v104[v113.values[v121]]
				end
				v104[v113.value] = v120
			elseif v113.operation == ConnectedAttributes.COMBINE_OPERATION.DIVIDE then
				local v122 = v104[v113.values[1]]
				for v123 = 2, v113.numValues do
					v122 = v122 / v104[v113.values[v123]]
				end
				v104[v113.value] = v122
			end
		end
		if v105 then
			for v124 = 1, #p100.targets do
				local v125 = p100.targets[v124]
				local v126 = v125.object
				local v127 = v126.data
				local v128 = v125.factors
				local v129 = v125.additionals
				for v130, v131 in pairs(v125.values) do
					v127[v130] = v104[v131] * v128[v130] + v129[v130]
				end
				v126:set()
			end
		end
	end
	p100.isActive = v102
end
function ConnectedAttributes.loadExtraDependentParts(p132, p133, p134, p135, p136)
	if not p133(p132, p134, p135, p136) then
		return false
	end
	local v137 = p134:getValue(p135 .. "#connectedAttributeIndices", nil, true)
	if v137 ~= nil and #v137 > 0 then
		p136.connectedAttributeIndices = v137
	end
	return true
end
function ConnectedAttributes.updateExtraDependentParts(p138, p139, p140, p141)
	p139(p138, p140, p141)
	if p140.connectedAttributeIndices ~= nil then
		local v142 = p138.spec_connectedAttributes
		for v143 = 1, #p140.connectedAttributeIndices do
			local v144 = p140.connectedAttributeIndices[v143]
			if v142.attributes[v144] ~= nil then
				ConnectedAttributes.updateAttribute(v142.attributes[v144])
			end
		end
	end
end
function ConnectedAttributes.updateDebugValues(p145, p146)
	local v147 = p145.spec_connectedAttributes
	for v148 = 1, #v147.attributes do
		local v149 = v147.attributes[v148]
		if v148 > 1 then
			table.insert(p146, {
				["name"] = "-",
				["value"] = "-"
			})
		end
		for v150 = 1, #v149.prerequisites do
			local v151 = {
				["name"] = string.format("prerequisite %d", v150),
				["value"] = string.format("%s", v149.prerequisites[v150]())
			}
			table.insert(p146, v151)
		end
		for v152 = 1, #v149.sources do
			local v153 = v149.sources[v152].object
			local v154 = ""
			for _, v155 in pairs(v153.data) do
				v154 = string.format("%s %.2f", v154, MathUtil.round(v155, 2))
			end
			local v156 = {
				["name"] = string.format("source %d (%s)", v152, v153.NAME),
				["value"] = v154
			}
			table.insert(p146, v156)
		end
		local v157 = ""
		for v158, v159 in pairs(v149.values) do
			v157 = string.format("%s (%s: %.2f)", v157, v158, MathUtil.round(v159, 2))
		end
		table.insert(p146, {
			["name"] = "current values",
			["value"] = v157
		})
		for v160 = 1, #v149.targets do
			local v161 = v149.targets[v160].object
			local v162 = ""
			for _, v163 in pairs(v161.data) do
				v162 = string.format("%s %.2f", v162, MathUtil.round(v163, 2))
			end
			local v164 = {
				["name"] = string.format("target %d (%s)", v160, v161.NAME),
				["value"] = v162
			}
			table.insert(p146, v164)
		end
	end
end
ConnectedAttributes.TYPES = {}
ConnectedAttributes.TYPES_BY_NAME = {}
ConnectedAttributes.TYPES_STRING = ""
function ConnectedAttributes.addType(p165)
	ConnectedAttributes.TYPES_BY_NAME[p165.NAME] = p165
	ConnectedAttributes.TYPES_STRING = ConnectedAttributes.TYPES_STRING .. " or " .. p165.NAME
	local v166 = ConnectedAttributes.TYPES
	table.insert(v166, p165)
end
local v167 = {}
local v_u_168 = Class(v167)
v167.NAME = "LOCAL_OFFSET"
v167.NUM_VALUES = 3
function v167.registerSourceXMLPaths(p169, p170)
	p169:register(XMLValueType.NODE_INDEX, p170 .. ".localOffset#node", "Reference node to measure the offset to the defined source node")
end
function v167.registerTargetXMLPaths(p171, p172)
	p171:register(XMLValueType.NODE_INDEX, p172 .. ".localOffset#node", "Node to set to the offset position that is calculated from the defined target node")
end
function v167.new(_, p173, p174, p175, p176, p177)
	-- upvalues: (copy) v_u_168
	local v178 = {}
	local v179 = v_u_168
	setmetatable(v178, v179)
	v178.parentNode = p173
	v178.node = p174:getValue(p175 .. ".localOffset#node", nil, p176, p177)
	if v178.node == nil then
		Logging.xmlWarning(p174, "Invalid shaderParameter \'%s\' for node \'%s\'", v178.name, getName(p173))
		return nil
	else
		v178.data = { 0, 0, 0 }
		return v178
	end
end
function v167.get(p180)
	local v181 = p180.data
	local v182 = p180.data
	local v183 = p180.data
	local v184, v185, v186 = localToLocal(p180.node, p180.parentNode, 0, 0, 0)
	v181[1] = v184
	v182[2] = v185
	v183[3] = v186
end
function v167.set(p187)
	local v188, v189, v190 = localToLocal(p187.parentNode, getParent(p187.node), p187.data[1], p187.data[2], p187.data[3])
	setTranslation(p187.node, v188, v189, v190)
end
ConnectedAttributes.addType(v167)
local v_u_191 = {}
local v_u_192 = Class(v_u_191)
v_u_191.NAME = "SHADER_PARAMETER"
v_u_191.NUM_VALUES = 4
function v_u_191.registerSourceXMLPaths(p193, p194)
	p193:register(XMLValueType.STRING, p194 .. ".shaderParameter#name", "Name of shader parameter of the source node that is used")
	p193:register(XMLValueType.STRING, p194 .. "#shaderParameterName", "Name of shader parameter of the source node that is used")
end
function v_u_191.registerTargetXMLPaths(p195, p196)
	p195:register(XMLValueType.STRING, p196 .. ".shaderParameter#name", "Name of shader parameter of the target node that is used")
	p195:register(XMLValueType.STRING, p196 .. "#shaderParameterName", "Name of shader parameter of the target node that is used")
end
function v_u_191.new(_, p197, p198, p199, _, _)
	-- upvalues: (copy) v_u_192, (copy) v_u_191
	local v200 = {}
	local v201 = v_u_192
	setmetatable(v200, v201)
	v200.parentNode = p197
	v200.name = p198:getValue(p199 .. ".shaderParameter#name") or p198:getValue(p199 .. "#shaderParameterName")
	if v200.name == nil or not getHasShaderParameter(p197, v200.name) then
		Logging.xmlWarning(p198, "Invalid shaderParameter \'%s\' for node \'%s\'", v200.name, getName(p197))
		return nil
	end
	v200.data = {
		0,
		0,
		0,
		0
	}
	local v202 = "prev" .. v200.name:sub(1, 1):upper() .. v200.name:sub(2)
	if getHasShaderParameter(p197, v202) then
		v200.prevName = v202
		v200.set = v_u_191.prev_set
	end
	v200.numMaterials = getNumOfMaterials(v200.parentNode)
	return v200
end
function v_u_191.get(p203)
	local v204 = p203.data
	local v205 = p203.data
	local v206 = p203.data
	local v207 = p203.data
	local v208, v209, v210, v211 = getShaderParameter(p203.parentNode, p203.name)
	v204[1] = v208
	v205[2] = v209
	v206[3] = v210
	v207[4] = v211
end
function v_u_191.set(p212)
	setShaderParameter(p212.parentNode, p212.name, p212.data[1], p212.data[2], p212.data[3], p212.data[4], false)
end
function v_u_191.prev_set(p213)
	g_animationManager:setPrevShaderParameter(p213.parentNode, p213.name, p213.data[1], p213.data[2], p213.data[3], p213.data[4], false, p213.prevName)
end
ConnectedAttributes.addType(v_u_191)
local v214 = {}
local v_u_215 = Class(v214)
v214.NAME = "SHADER_PARAMETER_PREV"
v214.NUM_VALUES = 8
function v214.registerSourceXMLPaths(p216, p217)
	p216:register(XMLValueType.STRING, p217 .. ".shaderParameter#name", "Name of shader parameter of the source node that is used")
	p216:register(XMLValueType.STRING, p217 .. "#shaderParameterName", "Name of shader parameter of the source node that is used")
end
function v214.registerTargetXMLPaths(p218, p219)
	p218:register(XMLValueType.STRING, p219 .. ".shaderParameter#name", "Name of shader parameter of the target node that is used")
	p218:register(XMLValueType.STRING, p219 .. "#shaderParameterName", "Name of shader parameter of the target node that is used")
end
function v214.new(_, p220, p221, p222, _, _)
	-- upvalues: (copy) v_u_215
	local v223 = {}
	local v224 = v_u_215
	setmetatable(v223, v224)
	v223.parentNode = p220
	v223.name = p221:getValue(p222 .. ".shaderParameter#name") or p221:getValue(p222 .. "#shaderParameterName")
	if v223.name == nil or not getHasShaderParameter(p220, v223.name) then
		Logging.xmlWarning(p221, "Invalid shaderParameter \'%s\' for node \'%s\'", v223.name, getName(p220))
		return nil
	end
	v223.data = {
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	}
	local v225 = "prev" .. v223.name:sub(1, 1):upper() .. v223.name:sub(2)
	if not getHasShaderParameter(p220, v225) then
		return nil
	end
	v223.prevName = v225
	return v223
end
function v214.get(p226)
	local v227 = p226.data
	local v228 = p226.data
	local v229 = p226.data
	local v230 = p226.data
	local v231, v232, v233, v234 = getShaderParameter(p226.parentNode, p226.name)
	v227[1] = v231
	v228[2] = v232
	v229[3] = v233
	v230[4] = v234
	local v235 = p226.data
	local v236 = p226.data
	local v237 = p226.data
	local v238 = p226.data
	local v239, v240, v241, v242 = getShaderParameter(p226.parentNode, p226.prevName)
	v235[5] = v239
	v236[6] = v240
	v237[7] = v241
	v238[8] = v242
end
function v214.set(p243)
	setShaderParameter(p243.parentNode, p243.name, p243.data[1], p243.data[2], p243.data[3], p243.data[4], false)
	setShaderParameter(p243.parentNode, p243.prevName, p243.data[5], p243.data[6], p243.data[7], p243.data[8], false)
end
ConnectedAttributes.addType(v214)
local v_u_244 = {}
local v_u_245 = Class(v_u_244)
v_u_244.NAME = "TRANSLATION"
v_u_244.NUM_VALUES = 3
function v_u_244.registerSourceXMLPaths(_, _) end
function v_u_244.registerTargetXMLPaths(_, _) end
function v_u_244.new(p_u_246, p_u_247, _, _, _, _)
	-- upvalues: (copy) v_u_245, (copy) v_u_244
	local v_u_248 = {}
	local v249 = v_u_245
	setmetatable(v_u_248, v249)
	v_u_248.parentNode = p_u_247
	v_u_248.data = { 0, 0, 0 }
	if p_u_246.setMovingToolDirty ~= nil then
		function v_u_248.set()
			-- upvalues: (ref) v_u_244, (copy) v_u_248, (copy) p_u_246, (copy) p_u_247
			v_u_244.set(v_u_248)
			p_u_246:setMovingToolDirty(p_u_247)
		end
	end
	return v_u_248
end
function v_u_244.get(p250)
	local v251 = p250.data
	local v252 = p250.data
	local v253 = p250.data
	local v254, v255, v256 = getTranslation(p250.parentNode)
	v251[1] = v254
	v252[2] = v255
	v253[3] = v256
end
function v_u_244.set(p257)
	setTranslation(p257.parentNode, p257.data[1], p257.data[2], p257.data[3])
end
ConnectedAttributes.addType(v_u_244)
local v_u_258 = {}
local v_u_259 = Class(v_u_258)
v_u_258.NAME = "ROTATION"
v_u_258.NUM_VALUES = 3
function v_u_258.registerSourceXMLPaths(_, _) end
function v_u_258.registerTargetXMLPaths(_, _) end
function v_u_258.new(p_u_260, p_u_261, _, _, _, _)
	-- upvalues: (copy) v_u_259, (copy) v_u_258
	local v_u_262 = {}
	local v263 = v_u_259
	setmetatable(v_u_262, v263)
	v_u_262.parentNode = p_u_261
	v_u_262.data = { 0, 0, 0 }
	if p_u_260.setMovingToolDirty ~= nil then
		function v_u_262.set()
			-- upvalues: (ref) v_u_258, (copy) v_u_262, (copy) p_u_260, (copy) p_u_261
			v_u_258.set(v_u_262)
			p_u_260:setMovingToolDirty(p_u_261)
		end
	end
	return v_u_262
end
function v_u_258.get(p264)
	local v265, v266, v267 = getRotation(p264.parentNode)
	local v268 = p264.data
	local v269 = p264.data
	local v270 = p264.data
	local v271 = math.deg(v265)
	local v272 = math.deg(v266)
	local v273 = math.deg(v267)
	v268[1] = v271
	v269[2] = v272
	v270[3] = v273
end
function v_u_258.set(p274)
	local v275 = setRotation
	local v276 = p274.parentNode
	local v277 = p274.data[1]
	local v278 = math.rad(v277)
	local v279 = p274.data[2]
	local v280 = math.rad(v279)
	local v281 = p274.data[3]
	v275(v276, v278, v280, (math.rad(v281)))
end
ConnectedAttributes.addType(v_u_258)
local v282 = {}
local v_u_283 = Class(v282)
v282.NAME = "JOINT_LIMIT_ROT"
v282.NUM_VALUES = 6
function v282.registerSourceXMLPaths(_, _) end
function v282.registerTargetXMLPaths(_, _) end
function v282.isAvailable(p284)
	return p284.isServer
end
function v282.new(p285, p286, p287, p288, _, _)
	-- upvalues: (copy) v_u_283
	local v289 = {}
	local v290 = v_u_283
	setmetatable(v289, v290)
	v289.parentNode = p286
	for v291 = 1, #p285.componentJoints do
		local v292 = p285.componentJoints[v291]
		if v292.jointNode == p286 then
			v289.componentJoint = v292
			if v289.componentJoint ~= nil then
				v289.data = {
					0,
					0,
					0,
					0,
					0,
					0
				}
				v289.vehicle = p285
				return v289
			end
		end
	end
	Logging.xmlWarning(p287, "Unable to find component joint in \'%s\' for node \'%s\'", p288, getName(p286))
	return nil
end
function v282.get(p293)
	local v294 = p293.componentJoint
	local v295 = p293.data
	local v296 = p293.data
	local v297 = p293.data
	local v298 = v294.rotMinLimit[1]
	local v299 = math.deg(v298)
	local v300 = v294.rotMinLimit[2]
	local v301 = math.deg(v300)
	local v302 = v294.rotMinLimit[3]
	local v303 = math.deg(v302)
	v295[1] = v299
	v296[2] = v301
	v297[3] = v303
	local v304 = p293.data
	local v305 = p293.data
	local v306 = p293.data
	local v307 = v294.rotLimit[1]
	local v308 = math.deg(v307)
	local v309 = v294.rotLimit[2]
	local v310 = math.deg(v309)
	local v311 = v294.rotLimit[3]
	local v312 = math.deg(v311)
	v304[4] = v308
	v305[5] = v310
	v306[6] = v312
end
function v282.set(p313)
	local v314 = p313.vehicle
	local v315 = p313.componentJoint
	local v316 = p313.data[1]
	local v317 = math.rad(v316)
	local v318 = p313.data[4]
	v314:setComponentJointRotLimit(v315, 1, v317, (math.rad(v318)))
	local v319 = p313.vehicle
	local v320 = p313.componentJoint
	local v321 = p313.data[2]
	local v322 = math.rad(v321)
	local v323 = p313.data[5]
	v319:setComponentJointRotLimit(v320, 2, v322, (math.rad(v323)))
	local v324 = p313.vehicle
	local v325 = p313.componentJoint
	local v326 = p313.data[3]
	local v327 = math.rad(v326)
	local v328 = p313.data[6]
	v324:setComponentJointRotLimit(v325, 3, v327, (math.rad(v328)))
end
ConnectedAttributes.addType(v282)
local v329 = {}
local v_u_330 = Class(v329)
v329.NAME = "JOINT_LIMIT_TRANS"
v329.NUM_VALUES = 6
function v329.registerSourceXMLPaths(_, _) end
function v329.registerTargetXMLPaths(_, _) end
function v282.isAvailable(p331)
	return p331.isServer
end
function v329.new(p332, p333, p334, p335, _, _)
	-- upvalues: (copy) v_u_330
	local v336 = {}
	local v337 = v_u_330
	setmetatable(v336, v337)
	v336.parentNode = p333
	for v338 = 1, #p332.componentJoints do
		local v339 = p332.componentJoints[v338]
		if v339.jointNode == p333 then
			v336.componentJoint = v339
			if v336.componentJoint ~= nil then
				v336.data = {
					0,
					0,
					0,
					0,
					0,
					0
				}
				v336.vehicle = p332
				return v336
			end
		end
	end
	Logging.xmlWarning(p334, "Unable to find component joint in \'%s\' for node \'%s\'", p335, getName(p333))
	return nil
end
function v329.get(p340)
	local v341 = p340.componentJoint
	local v342 = p340.data
	local v343 = p340.data
	local v344 = p340.data
	local v345 = v341.transMinLimit[1]
	local v346 = v341.transMinLimit[2]
	local v347 = v341.transMinLimit[3]
	v342[1] = v345
	v343[2] = v346
	v344[3] = v347
	local v348 = p340.data
	local v349 = p340.data
	local v350 = p340.data
	local v351 = v341.transLimit[1]
	local v352 = v341.transLimit[2]
	local v353 = v341.transLimit[3]
	v348[4] = v351
	v349[5] = v352
	v350[6] = v353
end
function v329.set(p354)
	p354.vehicle:setComponentJointTransLimit(p354.componentJoint, 1, p354.data[1], p354.data[4])
	p354.vehicle:setComponentJointTransLimit(p354.componentJoint, 2, p354.data[2], p354.data[5])
	p354.vehicle:setComponentJointTransLimit(p354.componentJoint, 3, p354.data[3], p354.data[6])
end
ConnectedAttributes.addType(v329)
local v_u_355 = {}
local v_u_356 = Class(v_u_355)
v_u_355.NAME = "ANIMATION_TIME"
v_u_355.NUM_VALUES = 1
function v_u_355.registerSourceXMLPaths(p357, p358)
	p357:register(XMLValueType.STRING, p358 .. ".animation#name", "Name of animation from which the time is used")
end
function v_u_355.registerTargetXMLPaths(p359, p360)
	p359:register(XMLValueType.STRING, p360 .. ".animation#name", "Name of animation onto which the value is applied as time")
	p359:register(XMLValueType.STRING, p360 .. ".animation#minValue", "Min. reference value (when input value is at this point, animation time \'0\' is used)")
	p359:register(XMLValueType.STRING, p360 .. ".animation#maxValue", "Max. reference value (when input value is at this point, animation time \'1\' is used)")
end
function v_u_355.new(p361, p362, p363, p364, _, _)
	-- upvalues: (copy) v_u_356, (copy) v_u_355
	local v365 = {}
	local v366 = v_u_356
	setmetatable(v365, v366)
	v365.parentNode = p362
	if p361.getAnimationExists == nil then
		Logging.xmlWarning(p363, "Vehicle does not have animations for \'%s\'", p364)
		return nil
	end
	v365.name = p363:getValue(p364 .. ".animation#name")
	if v365.name == nil or not p361:getAnimationExists(v365.name) then
		Logging.xmlWarning(p363, "Invalid animation \'%s\' in \'%s\'", v365.name, p364)
		return nil
	end
	v365.minValue = p363:getValue(p364 .. ".animation#minValue")
	v365.maxValue = p363:getValue(p364 .. ".animation#maxValue")
	if v365.minValue ~= nil ~= (v365.maxValue ~= nil) then
		Logging.xmlWarning(p363, "Invalid animation values for \'%s\' in \'%s\' (minValue and maxValue need to be defined, or non of them)", v365.name, p364)
		return nil
	end
	if v365.minValue ~= nil and v365.maxValue ~= nil then
		v365.set = v_u_355.range_set
	end
	v365.data = { 0 }
	v365.vehicle = p361
	return v365
end
function v_u_355.get(p367)
	p367.data[1] = p367.vehicle:getAnimationTime(p367.name)
end
function v_u_355.set(p368)
	p368.vehicle:setAnimationTime(p368.name, p368.data[1], true)
end
function v_u_355.range_set(p369)
	local v370 = (p369.data[1] - p369.minValue) / (p369.maxValue - p369.minValue)
	p369.vehicle:setAnimationTime(p369.name, v370, true)
end
ConnectedAttributes.addType(v_u_355)

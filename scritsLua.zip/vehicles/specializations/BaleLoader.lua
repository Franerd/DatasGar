source("dataS/scripts/vehicles/specializations/events/BaleLoaderStateEvent.lua")
BaleLoader = {}
function BaleLoader.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(FillUnit, p1)
end
function BaleLoader.initSpecialization()
	g_storeManager:addSpecType("baleLoaderBaleSizeRound", "shopListAttributeIconBaleSizeRound", BaleLoader.loadSpecValueBaleSizeRound, BaleLoader.getSpecValueBaleSizeRound, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("baleLoaderBaleSizeSquare", "shopListAttributeIconBaleSizeSquare", BaleLoader.loadSpecValueBaleSizeSquare, BaleLoader.getSpecValueBaleSizeSquare, StoreSpecies.VEHICLE)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("BaleLoader")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#transportPosition", "Transport position text", "action_baleloaderTransportPosition")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#operatingPosition", "Operating position text", "action_baleloaderOperatingPosition")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#unload", "Unload text", "action_baleloaderUnload")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#tilting", "Tilting text", "info_baleloaderTiltingTable")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#lowering", "Lowering text", "info_baleloaderLoweringTable")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#lowerPlattform", "Lower platform text", "action_baleloaderLowerPlatform")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#abortUnloading", "Abort unloading text", "action_baleloaderAbortUnloading")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#unloadHere", "Unload here text", "action_baleloaderUnloadHere")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#baleNotSupported", "Bale not supported warning", "warning_baleNotSupported")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#baleDoNotAllowFillTypeMixing", "Warning to be shown if the fill type is different from loaded fill types", "warning_baleDoNotAllowFillTypeMixing")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#onlyOneBaleTypeWarning", "Warning to be shown if user tries to collect a different bale type as already loaded", "warning_baleLoaderOnlyAllowOnceSize")
	v2:register(XMLValueType.L10N_STRING, "vehicle.baleLoader.texts#minUnloadingFillLevelWarning", "Warning to be displayed if min fill level is not reached", "warning_baleLoaderNotFullyLoaded")
	BaleLoader.registerAnimationXMLPaths(v2, "vehicle.baleLoader")
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader#transportPositionAfterUnloading", "Activate transport mode after unloading", true)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader#useFoldingState", "Use folding state for activation and deactivation", false)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader#useBalePlaceAsLoadPosition", "Use bale place position as load position", false)
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader#balePlaceOffset", "Bale place offset", 0)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader#keepBaleRotationDuringLoad", "Keep the same bale rotation while loading bale", false)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader#automaticUnloading", "Automatically unload the bale loader if platform lifted", false)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader#fullAutomaticUnloading", "Automatically unload the bale loader when getting full", false)
	v2:register(XMLValueType.INT, "vehicle.baleLoader#minUnloadingFillLevel", "Min. fill level until unloading is allowed", 1)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader#allowKinematicMounting", "Kinematic mounting of bale is allow (= bales still have collision while loaded)", true)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader#consumePtoPower", "Defines if the bale loader consumes pto power while in work mode", true)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader.dynamicMount#enabled", "Bales are dynamically mounted", false)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader.dynamicMount#doInterpolation", "Bale position is interpolated from bale origin position to grabber position", false)
	v2:register(XMLValueType.TIME, "vehicle.baleLoader.dynamicMount#interpolationTimeRot", "Time for bale rotation interpolation", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.dynamicMount#interpolationSpeedTrans", "Speed of translation interpolation (m/sec)", 0.1)
	v2:register(XMLValueType.VECTOR_TRANS, "vehicle.baleLoader.dynamicMount#minTransLimits", "Min translation limit")
	v2:register(XMLValueType.VECTOR_TRANS, "vehicle.baleLoader.dynamicMount#maxTransLimits", "Max translation limit")
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader.dynamicBaleUnloading#enabled", "Bales are joint together during unloading")
	v2:register(XMLValueType.VECTOR_N, "vehicle.baleLoader.dynamicBaleUnloading#connectedRows", "Indices of rows that are connected together")
	v2:register(XMLValueType.STRING, "vehicle.baleLoader.dynamicBaleUnloading#interConnectedRowStarts", "Interconnections at row start between rows (e.g. \'1-2 3-4\')")
	v2:register(XMLValueType.STRING, "vehicle.baleLoader.dynamicBaleUnloading#interConnectedRowEnds", "Interconnections at row ends between rows (e.g. \'1-2 3-4\')")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.dynamicBaleUnloading#widthOffset", "Width offset")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.dynamicBaleUnloading#heightOffset", "Height offset")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.dynamicBaleUnloading#diameterOffset", "Diameter offset")
	v2:register(XMLValueType.ANGLE, "vehicle.baleLoader.dynamicBaleUnloading#rowConnectionRotLimit", "Rotation limit for row joints")
	v2:register(XMLValueType.ANGLE, "vehicle.baleLoader.dynamicBaleUnloading#rowInterConnectionRotLimit", "Rotation limit for inter row joints")
	v2:register(XMLValueType.STRING, "vehicle.baleLoader.dynamicBaleUnloading.releaseAnimation#name", "Reference animation to remove joints")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.dynamicBaleUnloading.releaseAnimation#time", "If animation time is higher than this time the joints will be removed", 1)
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader.dynamicBaleUnloading.releaseAnimation#useUnloadingMoverTrigger", "Bale joints will be removed as soon all bales hast left the unloading mover trigger", false)
	v2:register(XMLValueType.INT, "vehicle.baleLoader#fillUnitIndex", "Fill unit index", 1)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.grabber#grabNode", "Grab node")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.grabber#pickupRange", "Pickup range", 3)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.grabber#triggerNode", "Trigger node")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.baleLoader.grabber")
	v2:register(XMLValueType.TIME, "vehicle.baleLoader.grabber#effectDisableDuration", "Disable duration", 0.6)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.balePlaces#startBalePlace", "Start bale place node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.balePlaces.balePlace(?)#node", "Bale place node")
	v2:register(XMLValueType.STRING, "vehicle.baleLoader.foldingAnimations#baseAnimation", "Base animation name", "baleGrabberTransportToWork")
	v2:register(XMLValueType.STRING, "vehicle.baleLoader.foldingAnimations.foldingAnimation(?)#name", "Animation name")
	v2:register(XMLValueType.INT, "vehicle.baleLoader.foldingAnimations.foldingAnimation(?)#baleTypeIndex", "Index of current bale type", "\'0\' - any bale type")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.foldingAnimations.foldingAnimation(?)#minFillLevel", "Min. fill level to use this animation", "-inf")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.foldingAnimations.foldingAnimation(?)#maxFillLevel", "Max. fill level to use this animation", "inf")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.foldingAnimations.foldingAnimation(?)#minBalePlace", "Min. bales on platform to use this animation", "-inf")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.foldingAnimations.foldingAnimation(?)#maxBalePlace", "Max. bales on platform to use this animation", "inf")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.unloadingMoverNodes#trigger", "As long as bales are in this trigger the mover nodes are active and the player can not lower the platform")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.unloadingMoverNodes.unloadingMoverNode(?)#node", "Node that moves bales")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.unloadingMoverNodes.unloadingMoverNode(?)#speed", "Defines direction and speed of moving in X direction", -1)
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.baleLoader.unloadingMoverNodes.animationNodes")
	v2:register(XMLValueType.INT, "vehicle.baleLoader.synchronization#numBitsPosition", "Number of bits to synchronize bale positions", 10)
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.synchronization#maxPosition", "Max. position offset of bales from bale place in meter", 3)
	SoundManager.registerSampleXMLPaths(v2, "vehicle.baleLoader.sounds", "grab")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.baleLoader.sounds", "emptyRotate")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.baleLoader.sounds", "work")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.baleLoader.sounds", "unload")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#diameter", "Bale diameter")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#width", "Bale width")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#height", "Bale height")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#length", "Bale length")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#minDiameter", "Bale min diameter", "diameter value")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#maxDiameter", "Bale max diameter", "diameter value")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#minWidth", "Bale min width", "width value")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#maxWidth", "Bale max width", "width value")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#minHeight", "Bale min height", "height value")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#maxHeight", "Bale max height", "height value")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#minLength", "Bale min length", "length value")
	v2:register(XMLValueType.FLOAT, "vehicle.baleLoader.baleTypes.baleType(?)#maxLength", "Bale max length", "length value")
	v2:register(XMLValueType.INT, "vehicle.baleLoader.baleTypes.baleType(?)#fillUnitIndex", "Fill unit index", "baleLoader#fillUnitIndex")
	v2:register(XMLValueType.BOOL, "vehicle.baleLoader.baleTypes.baleType(?)#mixedFillTypes", "Allow loading of mixed fill types", true)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.baleTypes.baleType(?).balePlaces#startBalePlace", "Start bale place node")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.baleTypes.baleType(?).balePlaces.balePlace(?)#node", "Bale place node")
	ObjectChangeUtil.registerObjectChangeXMLPaths(v2, "vehicle.baleLoader.baleTypes.baleType(?)")
	BaleLoader.registerAnimationXMLPaths(v2, "vehicle.baleLoader.baleTypes.baleType(?)")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.baleLoader.animationNodes")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.baleLoader.balePacker#node", "Node where to create the packed bale")
	v2:register(XMLValueType.STRING, "vehicle.baleLoader.balePacker#packedFilename", "Filename to packed bale")
	v2:addDelayedRegistrationFunc("AnimatedVehicle:part", function(p3, p4)
		p3:register(XMLValueType.BOOL, p4 .. "#baleLoaderAnimationNodes", "Bale Loader animation nodes turn on/off")
	end)
	v2:setXMLSpecializationType()
	local v5 = Vehicle.xmlSchemaSavegame
	v5:register(XMLValueType.STRING, "vehicles.vehicle(?).baleLoader#lastFoldingAnimation", "Last folding animation name")
	v5:register(XMLValueType.INT, "vehicles.vehicle(?).baleLoader#baleTypeIndex", "Last bale type index")
	v5:register(XMLValueType.BOOL, "vehicles.vehicle(?).baleLoader#isInWorkPosition", "Is in working Position")
	v5:register(XMLValueType.STRING, "vehicles.vehicle(?).baleLoader.bale(?)#filename", "Filename")
	v5:register(XMLValueType.VECTOR_TRANS, "vehicles.vehicle(?).baleLoader.bale(?)#position", "Position")
	v5:register(XMLValueType.VECTOR_ROT, "vehicles.vehicle(?).baleLoader.bale(?)#rotation", "Rotation")
	v5:register(XMLValueType.FLOAT, "vehicles.vehicle(?).baleLoader.bale(?)#fillLevel", "Filllevel")
	v5:register(XMLValueType.INT, "vehicles.vehicle(?).baleLoader.bale(?)#balePlace", "Bale place index")
	v5:register(XMLValueType.INT, "vehicles.vehicle(?).baleLoader.bale(?)#helper", "Helper index")
	v5:register(XMLValueType.INT, "vehicles.vehicle(?).baleLoader.bale(?)#farmId", "Farm index")
	Bale.registerSavegameXMLPaths(v5, "vehicles.vehicle(?).baleLoader.bale(?)")
end
function BaleLoader.registerAnimationXMLPaths(p6, p7)
	p6:register(XMLValueType.STRING, p7 .. ".animations.platform#rotate", "Rotate platform animation name", "rotatePlatform")
	p6:register(XMLValueType.STRING, p7 .. ".animations.platform#rotateBack", "Rotate platform back animation name", "rotatePlatform")
	p6:register(XMLValueType.STRING, p7 .. ".animations.platform#rotateEmpty", "Rotate platform empty animation name", "rotatePlatform")
	p6:register(XMLValueType.BOOL, p7 .. ".animations.platform#allowPickupWhileMoving", "Allow pickup of next bale while platform is rotating", false)
	p6:register(XMLValueType.FLOAT, p7 .. ".animations.baleGrabber#dropBaleReverseSpeed", "Speed of grabber in reverse", 5)
	p6:register(XMLValueType.STRING, p7 .. ".animations.baleGrabber#dropToWork", "Custom grabber animation when moving from drop to work")
	p6:register(XMLValueType.STRING, p7 .. ".animations.baleGrabber#workToDrop", "Bale grabber work to drop animation", "baleGrabberWorkToDrop")
	p6:register(XMLValueType.STRING, p7 .. ".animations.baleGrabber#dropBale", "Bale grabber drop bale animation", "baleGrabberDropBale")
	p6:register(XMLValueType.STRING, p7 .. ".animations.baleGrabber#transportToWork", "Transport to work animation", "baleGrabberTransportToWork")
	p6:register(XMLValueType.STRING, p7 .. ".animations.pusher#emptyHide", "Empty hide animation", "emptyHidePusher1")
	p6:register(XMLValueType.STRING, p7 .. ".animations.pusher#moveToEmpty", "Move to empty position", "moveBalePusherToEmpty")
	p6:register(XMLValueType.BOOL, p7 .. ".animations.pusher#hidePusherOnEmpty", "Reverse move to empty animation after execution", true)
	p6:register(XMLValueType.BOOL, p7 .. ".animations.pusher#pushBalesOnEmpty", "Defines if bale are pushed or pulled on empty", false)
	p6:register(XMLValueType.STRING, p7 .. ".animations.releaseFrontPlatform#name", "Release front platform animation name", "releaseFrontplattform")
	p6:register(XMLValueType.BOOL, p7 .. ".animations.releaseFrontPlatform#fillLevelSpeed", "Front platform speed is dependent on fill level", false)
	p6:register(XMLValueType.STRING, p7 .. ".animations.moveBalePlaces#name", "Move bale places animation", "moveBalePlaces")
	p6:register(XMLValueType.STRING, p7 .. ".animations.moveBalePlaces#extrasOnce", "Move bale places extra once animation", "moveBalePlaces")
	p6:register(XMLValueType.STRING, p7 .. ".animations.moveBalePlaces#empty", "Move bale places empty animation", "moveBalePlaces")
	p6:register(XMLValueType.FLOAT, p7 .. ".animations.moveBalePlaces#emptySpeed", "Speed of move bale places to empty", 1.5)
	p6:register(XMLValueType.FLOAT, p7 .. ".animations.moveBalePlaces#emptyReverseSpeed", "Reverse speed of move bale places to empty", -1)
	p6:register(XMLValueType.FLOAT, p7 .. ".animations.moveBalePlaces#pushOffset", "Delay of empty animation to give pusher time to move to the last bale", 0)
	p6:register(XMLValueType.BOOL, p7 .. ".animations.moveBalePlaces#moveAfterRotatePlatform", "Move bale places after rotate platform", false)
	p6:register(XMLValueType.BOOL, p7 .. ".animations.moveBalePlaces#resetOnSink", "Reset move bale places on platform sink", false)
	p6:register(XMLValueType.FLOAT, p7 .. ".animations.moveBalePlaces#maxGrabberTime", "Max. grabber time to move bale places", "inf")
	p6:register(XMLValueType.BOOL, p7 .. ".animations.moveBalePlaces#alwaysMove", "Always move bale places", false)
	p6:register(XMLValueType.STRING, p7 .. ".animations.emptyRotate#name", "Empty rotate", "emptyRotate")
	p6:register(XMLValueType.BOOL, p7 .. ".animations.emptyRotate#reset", "Reset empty rotate animation", true)
	p6:register(XMLValueType.STRING, p7 .. ".animations#frontBalePusher", "Front bale pusher animation", "frontBalePusher")
	p6:register(XMLValueType.STRING, p7 .. ".animations#balesToOtherRow", "Bales to othe row animation", "balesToOtherRow")
	p6:register(XMLValueType.STRING, p7 .. ".animations#closeGrippers", "Close grippers animation", "closeGrippers")
end
BaleLoader.GRAB_MOVE_UP = 1
BaleLoader.GRAB_MOVE_DOWN = 2
BaleLoader.GRAB_DROP_BALE = 3
BaleLoader.EMPTY_NONE = 1
BaleLoader.EMPTY_TO_WORK = 2
BaleLoader.EMPTY_ROTATE_PLATFORM = 3
BaleLoader.EMPTY_ROTATE1 = 4
BaleLoader.EMPTY_CLOSE_GRIPPERS = 5
BaleLoader.EMPTY_HIDE_PUSHER1 = 6
BaleLoader.EMPTY_HIDE_PUSHER2 = 7
BaleLoader.EMPTY_ROTATE2 = 8
BaleLoader.EMPTY_WAIT_TO_DROP = 9
BaleLoader.EMPTY_WAIT_TO_SINK = 10
BaleLoader.EMPTY_SINK = 11
BaleLoader.EMPTY_CANCEL = 12
BaleLoader.EMPTY_WAIT_TO_REDO = 13
BaleLoader.CHANGE_DROP_BALES = 1
BaleLoader.CHANGE_SINK = 2
BaleLoader.CHANGE_EMPTY_REDO = 3
BaleLoader.CHANGE_EMPTY_START = 4
BaleLoader.CHANGE_EMPTY_CANCEL = 5
BaleLoader.CHANGE_MOVE_TO_WORK = 6
BaleLoader.CHANGE_MOVE_TO_TRANSPORT = 7
BaleLoader.CHANGE_GRAB_BALE = 8
BaleLoader.CHANGE_GRAB_MOVE_UP = 9
BaleLoader.CHANGE_GRAB_DROP_BALE = 10
BaleLoader.CHANGE_GRAB_MOVE_DOWN = 11
BaleLoader.CHANGE_FRONT_PUSHER = 12
BaleLoader.CHANGE_ROTATE_PLATFORM = 13
BaleLoader.CHANGE_EMPTY_ROTATE_PLATFORM = 14
BaleLoader.CHANGE_EMPTY_ROTATE1 = 15
BaleLoader.CHANGE_EMPTY_CLOSE_GRIPPERS = 16
BaleLoader.CHANGE_EMPTY_HIDE_PUSHER1 = 17
BaleLoader.CHANGE_EMPTY_HIDE_PUSHER2 = 18
BaleLoader.CHANGE_EMPTY_ROTATE2 = 19
BaleLoader.CHANGE_EMPTY_WAIT_TO_DROP = 20
BaleLoader.CHANGE_EMPTY_STATE_NIL = 21
BaleLoader.CHANGE_EMPTY_WAIT_TO_REDO = 22
BaleLoader.CHANGE_BUTTON_EMPTY = 23
BaleLoader.CHANGE_BUTTON_EMPTY_ABORT = 24
BaleLoader.CHANGE_BUTTON_WORK_TRANSPORT = 25
function BaleLoader.registerFunctions(p8)
	SpecializationUtil.registerFunction(p8, "loadBaleTypeFromXML", BaleLoader.loadBaleTypeFromXML)
	SpecializationUtil.registerFunction(p8, "loadBalePlacesFromXML", BaleLoader.loadBalePlacesFromXML)
	SpecializationUtil.registerFunction(p8, "loadBaleLoaderAnimationsFromXML", BaleLoader.loadBaleLoaderAnimationsFromXML)
	SpecializationUtil.registerFunction(p8, "createBaleToBaleJoints", BaleLoader.createBaleToBaleJoints)
	SpecializationUtil.registerFunction(p8, "createBaleToBaleJoint", BaleLoader.createBaleToBaleJoint)
	SpecializationUtil.registerFunction(p8, "doStateChange", BaleLoader.doStateChange)
	SpecializationUtil.registerFunction(p8, "getBaleGrabberDropBaleAnimName", BaleLoader.getBaleGrabberDropBaleAnimName)
	SpecializationUtil.registerFunction(p8, "getIsBaleGrabbingAllowed", BaleLoader.getIsBaleGrabbingAllowed)
	SpecializationUtil.registerFunction(p8, "pickupBale", BaleLoader.pickupBale)
	SpecializationUtil.registerFunction(p8, "setBaleLoaderBaleType", BaleLoader.setBaleLoaderBaleType)
	SpecializationUtil.registerFunction(p8, "getBaleTypeByBale", BaleLoader.getBaleTypeByBale)
	SpecializationUtil.registerFunction(p8, "baleGrabberTriggerCallback", BaleLoader.baleGrabberTriggerCallback)
	SpecializationUtil.registerFunction(p8, "baleLoaderMoveTriggerCallback", BaleLoader.baleLoaderMoveTriggerCallback)
	SpecializationUtil.registerFunction(p8, "mountDynamicBale", BaleLoader.mountDynamicBale)
	SpecializationUtil.registerFunction(p8, "unmountDynamicBale", BaleLoader.unmountDynamicBale)
	SpecializationUtil.registerFunction(p8, "mountBale", BaleLoader.mountBale)
	SpecializationUtil.registerFunction(p8, "unmountBale", BaleLoader.unmountBale)
	SpecializationUtil.registerFunction(p8, "setBalePairCollision", BaleLoader.setBalePairCollision)
	SpecializationUtil.registerFunction(p8, "getLoadedBales", BaleLoader.getLoadedBales)
	SpecializationUtil.registerFunction(p8, "startAutomaticBaleUnloading", BaleLoader.startAutomaticBaleUnloading)
	SpecializationUtil.registerFunction(p8, "getIsAutomaticBaleUnloadingInProgress", BaleLoader.getIsAutomaticBaleUnloadingInProgress)
	SpecializationUtil.registerFunction(p8, "getIsAutomaticBaleUnloadingAllowed", BaleLoader.getIsAutomaticBaleUnloadingAllowed)
	SpecializationUtil.registerFunction(p8, "playBaleLoaderFoldingAnimation", BaleLoader.playBaleLoaderFoldingAnimation)
	SpecializationUtil.registerFunction(p8, "getIsBaleLoaderFoldingPlaying", BaleLoader.getIsBaleLoaderFoldingPlaying)
	SpecializationUtil.registerFunction(p8, "getCurrentFoldingAnimation", BaleLoader.getCurrentFoldingAnimation)
	SpecializationUtil.registerFunction(p8, "updateFoldingAnimation", BaleLoader.updateFoldingAnimation)
	SpecializationUtil.registerFunction(p8, "onBaleMoverBaleRemoved", BaleLoader.onBaleMoverBaleRemoved)
	SpecializationUtil.registerFunction(p8, "addBaleUnloadTrigger", BaleLoader.addBaleUnloadTrigger)
	SpecializationUtil.registerFunction(p8, "removeBaleUnloadTrigger", BaleLoader.removeBaleUnloadTrigger)
end
function BaleLoader.registerOverwrittenFunctions(p9)
	SpecializationUtil.registerOverwrittenFunction(p9, "getCanBeSelected", BaleLoader.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p9, "getAllowDynamicMountFillLevelInfo", BaleLoader.getAllowDynamicMountFillLevelInfo)
	SpecializationUtil.registerOverwrittenFunction(p9, "getAreControlledActionsAllowed", BaleLoader.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsAIReadyToDrive", BaleLoader.getIsAIReadyToDrive)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsAIPreparingToDrive", BaleLoader.getIsAIPreparingToDrive)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsFoldAllowed", BaleLoader.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p9, "getDoConsumePtoPower", BaleLoader.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p9, "getConsumingLoad", BaleLoader.getConsumingLoad)
	SpecializationUtil.registerOverwrittenFunction(p9, "getIsPowerTakeOffActive", BaleLoader.getIsPowerTakeOffActive)
	SpecializationUtil.registerOverwrittenFunction(p9, "addToPhysics", BaleLoader.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p9, "removeFromPhysics", BaleLoader.removeFromPhysics)
end
function BaleLoader.registerEventListeners(p10)
	SpecializationUtil.registerEventListener(p10, "onLoad", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onPostLoad", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onLoadFinished", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onDelete", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onReadUpdateStream", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onWriteUpdateStream", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onReadStream", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onWriteStream", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onUpdate", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onUpdateTick", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onDraw", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onRegisterActionEvents", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onActivate", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onDeactivate", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onRootVehicleChanged", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onFillUnitFillLevelChanged", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onFoldStateChanged", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onBalerUnloadingStarted", BaleLoader)
	SpecializationUtil.registerEventListener(p10, "onRegisterAnimationValueTypes", BaleLoader)
end
function BaleLoader.onLoad(p_u_11, _)
	local v12 = p_u_11.spec_baleLoader
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleloaderTurnedOnScrollers.baleloaderTurnedOnScroller", "vehicle.baleLoader.animationNodes.animationNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleGrabber", "vehicle.baleLoader.grabber")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.balePlaces", "vehicle.baleLoader.balePlaces")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.grabParticleSystem", "vehicle.baleLoader.grabber.grabParticleSystem")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader.grabber.grabParticleSystem", "vehicle.baleLoader.grabber.effectNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#pickupRange", "vehicle.baleLoader.grabber#pickupRange")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleTypes", "vehicle.baleLoader.baleTypes")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#textTransportPosition", "vehicle.baleLoader.texts#transportPosition")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#textOperatingPosition", "vehicle.baleLoader.texts#operatingPosition")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#textUnload", "vehicle.baleLoader.texts#unload")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#textTilting", "vehicle.baleLoader.texts#tilting")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#textLowering", "vehicle.baleLoader.texts#lowering")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#textLowerPlattform", "vehicle.baleLoader.texts#lowerPlattform")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#textAbortUnloading", "vehicle.baleLoader.texts#abortUnloading")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#textUnloadHere", "vehicle.baleLoader.texts#unloadHere")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#rotatePlatformAnimName", "vehicle.baleLoader.animations#rotatePlatform")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#rotatePlatformBackAnimName", "vehicle.baleLoader.animations#rotatePlatformBack")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#rotatePlatformEmptyAnimName", "vehicle.baleLoader.animations#rotatePlatformEmpty")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader.animations#grabberDropBaleReverseSpeed", "vehicle.baleLoader.animations.baleGrabber#dropBaleReverseSpeed")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader.animations#grabberDropToWork", "vehicle.baleLoader.animations.baleGrabber#dropToWork")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader.animations#rotatePlatform", "vehicle.baleLoader.animations.platform#rotate")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader.animations#rotatePlatformBack", "vehicle.baleLoader.animations.platform#rotateBack")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader.animations#rotatePlatformEmpty", "vehicle.baleLoader.animations.platform#rotateEmpty")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#moveBalePlacesAfterRotatePlatform", "vehicle.baleLoader.animations.moveBalePlaces#moveAfterRotatePlatform")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#moveBalePlacesMaxGrabberTime", "vehicle.baleLoader.animations.moveBalePlaces#maxGrabberTime")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#alwaysMoveBalePlaces", "vehicle.baleLoader.animations.moveBalePlaces#alwaysMove")
	XMLUtil.checkDeprecatedXMLElements(p_u_11.xmlFile, "vehicle.baleLoader#resetEmptyRotateAnimation", "vehicle.baleLoader.animations.emptyRotate#reset")
	v12.balesToLoad = {}
	v12.balesToMount = {}
	v12.isInWorkPosition = false
	v12.grabberIsMoving = false
	v12.rotatePlatformDirection = 0
	v12.frontBalePusherDirection = 0
	v12.emptyState = BaleLoader.EMPTY_NONE
	v12.texts = {}
	v12.texts.transportPosition = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#transportPosition", "action_baleloaderTransportPosition", nil, p_u_11.customEnvironment)
	v12.texts.operatingPosition = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#operatingPosition", "action_baleloaderOperatingPosition", nil, p_u_11.customEnvironment)
	v12.texts.unload = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#unload", "action_baleloaderUnload", nil, p_u_11.customEnvironment)
	v12.texts.tilting = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#tilting", "info_baleloaderTiltingTable", nil, p_u_11.customEnvironment)
	v12.texts.lowering = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#lowering", "info_baleloaderLoweringTable", nil, p_u_11.customEnvironment)
	v12.texts.lowerPlattform = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#lowerPlattform", "action_baleloaderLowerPlatform", nil, p_u_11.customEnvironment)
	v12.texts.abortUnloading = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#abortUnloading", "action_baleloaderAbortUnloading", nil, p_u_11.customEnvironment)
	v12.texts.unloadHere = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#unloadHere", "action_baleloaderUnloadHere", nil, p_u_11.customEnvironment)
	v12.texts.baleNotSupported = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#baleNotSupported", "warning_baleNotSupported", nil, p_u_11.customEnvironment)
	v12.texts.baleDoNotAllowFillTypeMixing = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#baleDoNotAllowFillTypeMixing", "warning_baleDoNotAllowFillTypeMixing", nil, p_u_11.customEnvironment)
	v12.texts.onlyOneBaleTypeWarning = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#onlyOneBaleTypeWarning", "warning_baleLoaderOnlyAllowOnceSize", nil, p_u_11.customEnvironment)
	v12.texts.minUnloadingFillLevelWarning = p_u_11.xmlFile:getValue("vehicle.baleLoader.texts#minUnloadingFillLevelWarning", "warning_baleLoaderNotFullyLoaded", nil, p_u_11.customEnvironment)
	v12.texts.youDoNotOwnBale = g_i18n:getText("warning_youDontOwnThisItem")
	v12.transportPositionAfterUnloading = p_u_11.xmlFile:getValue("vehicle.baleLoader#transportPositionAfterUnloading", true)
	v12.useFoldingState = p_u_11.xmlFile:getValue("vehicle.baleLoader#useFoldingState", false)
	v12.useBalePlaceAsLoadPosition = p_u_11.xmlFile:getValue("vehicle.baleLoader#useBalePlaceAsLoadPosition", false)
	v12.balePlaceOffset = p_u_11.xmlFile:getValue("vehicle.baleLoader#balePlaceOffset", 0)
	v12.keepBaleRotationDuringLoad = p_u_11.xmlFile:getValue("vehicle.baleLoader#keepBaleRotationDuringLoad", false)
	v12.fullAutomaticUnloading = p_u_11.xmlFile:getValue("vehicle.baleLoader#fullAutomaticUnloading", false)
	v12.automaticUnloading = p_u_11.xmlFile:getValue("vehicle.baleLoader#automaticUnloading", v12.fullAutomaticUnloading)
	v12.minUnloadingFillLevel = p_u_11.xmlFile:getValue("vehicle.baleLoader#minUnloadingFillLevel", 1)
	v12.fillUnitIndex = p_u_11.xmlFile:getValue("vehicle.baleLoader#fillUnitIndex", 1)
	v12.allowKinematicMounting = p_u_11.xmlFile:getValue("vehicle.baleLoader#allowKinematicMounting", true)
	v12.consumePtoPower = p_u_11.xmlFile:getValue("vehicle.baleLoader#consumePtoPower", true)
	v12.dynamicMount = {}
	v12.dynamicMount.enabled = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicMount#enabled", false)
	v12.dynamicMount.jointInterpolation = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicMount#doInterpolation", false)
	v12.dynamicMount.jointInterpolationTimeRot = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicMount#interpolationTimeRot", 1)
	v12.dynamicMount.jointInterpolationSpeedTrans = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicMount#interpolationSpeedTrans", 0.1) / 1000
	v12.dynamicMount.baleJointsToUpdate = {}
	v12.dynamicMount.minTransLimits = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicMount#minTransLimits", nil, true)
	v12.dynamicMount.maxTransLimits = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicMount#maxTransLimits", nil, true)
	v12.dynamicMount.baleMassDirty = false
	v12.dynamicBaleUnloading = {}
	v12.dynamicBaleUnloading.enabled = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading#enabled", false)
	v12.dynamicBaleUnloading.connectedRows = {}
	local v13 = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading#connectedRows", nil, true)
	if v13 ~= nil then
		for v14 = 1, #v13 do
			v12.dynamicBaleUnloading.connectedRows[v13[v14]] = true
		end
	end
	local function v25(p15)
		-- upvalues: (copy) p_u_11
		local v16 = {}
		local v17 = p_u_11.xmlFile:getValue(p15)
		if v17 ~= nil then
			local v18 = string.split(v17, " ")
			for v19 = 1, #v18 do
				local v20 = string.split(v18[v19], "-")
				if #v20 == 2 then
					local v21 = {}
					local v22 = v20[1]
					local v23 = tonumber(v22)
					local v24 = v20[2]
					__set_list(v21, 1, {v23, (tonumber(v24))})
					table.insert(v16, v21)
				else
					Logging.xmlWarning(p_u_11.xmlFile, "Unknown row connection \'%s\' in \'%s\' (should look like \'1-2 3-4\')", v18[v19], p15)
				end
			end
		end
		return v16
	end
	v12.dynamicBaleUnloading.interConnectedRowStarts = v25("vehicle.baleLoader.dynamicBaleUnloading#interConnectedRowStarts")
	v12.dynamicBaleUnloading.interConnectedRowEnds = v25("vehicle.baleLoader.dynamicBaleUnloading#interConnectedRowEnds")
	v12.dynamicBaleUnloading.widthOffset = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading#widthOffset", 0.05)
	v12.dynamicBaleUnloading.heightOffset = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading#heightOffset", 0.05)
	v12.dynamicBaleUnloading.diameterOffset = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading#diameterOffset", 0.05)
	v12.dynamicBaleUnloading.rowConnectionRotLimit = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading#rowConnectionRotLimit", 4)
	v12.dynamicBaleUnloading.rowInterConnectionRotLimit = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading#rowInterConnectionRotLimit", 1)
	v12.dynamicBaleUnloading.releaseAnimation = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading.releaseAnimation#name")
	v12.dynamicBaleUnloading.releaseAnimationTime = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading.releaseAnimation#time", 1)
	v12.dynamicBaleUnloading.useUnloadingMoverTrigger = p_u_11.xmlFile:getValue("vehicle.baleLoader.dynamicBaleUnloading.releaseAnimation#useUnloadingMoverTrigger", false)
	v12.baleGrabber = {}
	v12.baleGrabber.grabNode = p_u_11.xmlFile:getValue("vehicle.baleLoader.grabber#grabNode", nil, p_u_11.components, p_u_11.i3dMappings)
	v12.baleGrabber.pickupRange = p_u_11.xmlFile:getValue("vehicle.baleLoader.grabber#pickupRange", 3)
	v12.baleGrabber.balesInTrigger = {}
	v12.baleGrabber.trigger = p_u_11.xmlFile:getValue("vehicle.baleLoader.grabber#triggerNode", nil, p_u_11.components, p_u_11.i3dMappings)
	if v12.baleGrabber.trigger == nil then
		Logging.xmlError(p_u_11.xmlFile, "Bale grabber needs a valid trigger!")
	else
		addTrigger(v12.baleGrabber.trigger, "baleGrabberTriggerCallback", p_u_11)
		g_currentMission:addNodeObject(v12.baleGrabber.trigger, p_u_11)
	end
	if p_u_11.isClient then
		local v26 = {}
		if ParticleUtil.loadParticleSystem(p_u_11.xmlFile, v26, "vehicle.baleLoader.grabber.grabParticleSystem", p_u_11.components, false, nil, p_u_11.baseDirectory) then
			v12.grabParticleSystem = v26
			v12.grabParticleSystemDisableTime = 0
		end
		v12.grabberEffects = g_effectManager:loadEffect(p_u_11.xmlFile, "vehicle.baleLoader.grabber", p_u_11.components, p_u_11, p_u_11.i3dMappings)
		v12.grabberEffectDisableDuration = p_u_11.xmlFile:getValue("vehicle.baleLoader.grabber#effectDisableDuration", 0.6)
		v12.grabberEffectDisableTime = 0
		v12.samples = {}
		v12.samples.grab = g_soundManager:loadSampleFromXML(p_u_11.xmlFile, "vehicle.baleLoader.sounds", "grab", p_u_11.baseDirectory, p_u_11.components, 1, AudioGroup.VEHICLE, p_u_11.i3dMappings, p_u_11)
		v12.samples.emptyRotate = g_soundManager:loadSampleFromXML(p_u_11.xmlFile, "vehicle.baleLoader.sounds", "emptyRotate", p_u_11.baseDirectory, p_u_11.components, 1, AudioGroup.VEHICLE, p_u_11.i3dMappings, p_u_11)
		v12.samples.work = g_soundManager:loadSampleFromXML(p_u_11.xmlFile, "vehicle.baleLoader.sounds", "work", p_u_11.baseDirectory, p_u_11.components, 0, AudioGroup.VEHICLE, p_u_11.i3dMappings, p_u_11)
		v12.samples.unload = g_soundManager:loadSampleFromXML(p_u_11.xmlFile, "vehicle.baleLoader.sounds", "unload", p_u_11.baseDirectory, p_u_11.components, 0, AudioGroup.VEHICLE, p_u_11.i3dMappings, p_u_11)
	end
	v12.defaultAnimations = {}
	p_u_11:loadBaleLoaderAnimationsFromXML(p_u_11.xmlFile, "vehicle.baleLoader", v12.defaultAnimations)
	v12.animations = v12.defaultAnimations.animations
	v12.defaultBalePlace = {}
	v12.useSharedBalePlaces = false
	if p_u_11:loadBalePlacesFromXML(p_u_11.xmlFile, "vehicle.baleLoader", v12.defaultBalePlace) then
		v12.useSharedBalePlaces = true
	end
	v12.startBalePlace = v12.defaultBalePlace.startBalePlace
	v12.balePlaces = v12.defaultBalePlace.balePlaces
	v12.baleTypes = {}
	local v27 = 0
	while true do
		local v28 = string.format("%s.baleTypes.baleType(%d)", "vehicle.baleLoader", v27)
		if not p_u_11.xmlFile:hasProperty(v28) then
			break
		end
		local v29 = {}
		if p_u_11:loadBaleTypeFromXML(p_u_11.xmlFile, v28, v29) then
			v29.index = v27 + 1
			local v30 = v12.baleTypes
			table.insert(v30, v29)
		end
		v27 = v27 + 1
	end
	if #v12.baleTypes == 0 then
		Logging.xmlError(p_u_11.xmlFile, "No bale types defined for baleLoader!")
	else
		if v12.startBalePlace == nil then
			v12.startBalePlace = v12.baleTypes[1].startBalePlace
		end
		if v12.balePlaces == nil then
			v12.balePlaces = v12.baleTypes[1].balePlaces
		end
		if v12.startBalePlace == nil then
			Logging.xmlError(p_u_11.xmlFile, "Could not find startBalePlace for baleLoader!")
		end
		if v12.balePlaces == nil then
			Logging.xmlError(p_u_11.xmlFile, "Could not find bale places for baleLoader!")
		end
	end
	p_u_11:setBaleLoaderBaleType(1)
	v12.foldingAnimations = {}
	local v31 = 0
	while true do
		local v32 = string.format("%s.foldingAnimations.foldingAnimation(%d)", "vehicle.baleLoader", v31)
		if not p_u_11.xmlFile:hasProperty(v32) then
			break
		end
		local v33 = {
			["name"] = p_u_11.xmlFile:getValue(v32 .. "#name"),
			["baleTypeIndex"] = p_u_11.xmlFile:getValue(v32 .. "#baleTypeIndex", 0),
			["minFillLevel"] = p_u_11.xmlFile:getValue(v32 .. "#minFillLevel", (-1 / 0)),
			["maxFillLevel"] = p_u_11.xmlFile:getValue(v32 .. "#maxFillLevel", (1 / 0)),
			["minBalePlace"] = p_u_11.xmlFile:getValue(v32 .. "#minBalePlace", (-1 / 0)),
			["maxBalePlace"] = p_u_11.xmlFile:getValue(v32 .. "#maxBalePlace", (1 / 0))
		}
		if p_u_11:getAnimationExists(v33.name) then
			local v34 = v12.foldingAnimations
			table.insert(v34, v33)
		else
			Logging.xmlWarning(p_u_11.xmlFile, "Unknown folding animation \'%s\' in \'%s\'", v33.name, v32)
		end
		v31 = v31 + 1
	end
	v12.hasMultipleFoldingAnimations = #v12.foldingAnimations > 0
	v12.lastFoldingAnimation = v12.animations.baleGrabberTransportToWork
	p_u_11:updateFoldingAnimation()
	v12.unloadingMover = {}
	v12.unloadingMover.trigger = p_u_11.xmlFile:getValue("vehicle.baleLoader.unloadingMoverNodes#trigger", nil, p_u_11.components, p_u_11.i3dMappings)
	if v12.unloadingMover.trigger ~= nil then
		addTrigger(v12.unloadingMover.trigger, "baleLoaderMoveTriggerCallback", p_u_11)
		g_currentMission:addNodeObject(v12.unloadingMover.trigger, p_u_11)
	end
	v12.unloadingMover.isActive = false
	v12.unloadingMover.dirtyFlag = p_u_11:getNextDirtyFlag()
	v12.unloadingMover.frameDelay = 0
	v12.unloadingMover.balesInTrigger = {}
	v12.unloadingMover.nodes = {}
	v12.unloadingMover.animationNodes = g_animationManager:loadAnimations(p_u_11.xmlFile, "vehicle.baleLoader.unloadingMoverNodes.animationNodes", p_u_11.components, p_u_11, p_u_11.i3dMappings)
	local v35 = 0
	while true do
		local v36 = string.format("%s.unloadingMoverNodes.unloadingMoverNode(%d)", "vehicle.baleLoader", v35)
		if not p_u_11.xmlFile:hasProperty(v36) then
			break
		end
		local v37 = {
			["node"] = p_u_11.xmlFile:getValue(v36 .. "#node", nil, p_u_11.components, p_u_11.i3dMappings),
			["speed"] = p_u_11.xmlFile:getValue(v36 .. "#speed", -1)
		}
		if v37.node == nil then
			Logging.xmlWarning(p_u_11.xmlFile, "Unknown node in \'%s\'", v36)
		else
			local v38 = v12.unloadingMover.nodes
			table.insert(v38, v37)
		end
		v35 = v35 + 1
	end
	v12.balePacker = {}
	v12.balePacker.node = p_u_11.xmlFile:getValue("vehicle.baleLoader.balePacker#node", nil, p_u_11.components, p_u_11.i3dMappings)
	v12.balePacker.filename = p_u_11.xmlFile:getValue("vehicle.baleLoader.balePacker#packedFilename")
	if v12.balePacker.filename ~= nil then
		v12.balePacker.filename = Utils.getFilename(v12.balePacker.filename, p_u_11.baseDirectory)
		if v12.balePacker.filename ~= nil and not fileExists(v12.balePacker.filename) then
			Logging.xmlError(p_u_11.xmlFile, "Unable to find packed bale \'%s\'", v12.balePacker.filename)
		end
	end
	v12.synchronizationNumBitsPosition = p_u_11.xmlFile:getValue("vehicle.baleLoader.synchronization#numBitsPosition", 10)
	v12.synchronizationMaxPosition = p_u_11.xmlFile:getValue("vehicle.baleLoader.synchronization#maxPosition", 3)
	v12.animationNodes = g_animationManager:loadAnimations(p_u_11.xmlFile, "vehicle.baleLoader.animationNodes", p_u_11.components, p_u_11, p_u_11.i3dMappings)
	v12.animationNodesBlocked = false
	v12.showBaleNotSupportedWarning = false
	v12.baleNotSupportedWarning = nil
	v12.automaticUnloadingInProgress = false
	v12.automaticUnloadingAdditionalBalesToLoad = -1
	v12.lastPickupAutomatedUnloadingDelayTime = 15000
	v12.lastPickupTime = -v12.lastPickupAutomatedUnloadingDelayTime
	v12.kinematicMountedBales = {}
	v12.baleUnloadTriggers = {}
	v12.baleJoints = {}
end
function BaleLoader.onPostLoad(p39, p40)
	if p40 ~= nil then
		local v41 = p39.spec_baleLoader
		local v42 = p40.xmlFile:getValue(p40.key .. ".baleLoader#baleTypeIndex")
		if v42 ~= nil then
			p39:setBaleLoaderBaleType(v42, true)
		end
		if v41.hasMultipleFoldingAnimations and not p40.resetVehicles then
			v41.lastFoldingAnimation = p40.xmlFile:getValue(p40.key .. ".baleLoader#lastFoldingAnimation", v41.lastFoldingAnimation)
		end
		if p40.xmlFile:getValue(p40.key .. ".baleLoader#isInWorkPosition", false) then
			if not v41.isInWorkPosition then
				v41.grabberIsMoving = true
				v41.isInWorkPosition = true
				BaleLoader.moveToWorkPosition(p39, true)
			end
		else
			BaleLoader.moveToTransportPosition(p39)
		end
		v41.startBalePlace.current = 1
		v41.startBalePlace.count = 0
		if not p40.resetVehicles then
			local v43 = 0
			local v44 = 0
			while true do
				local v45 = p40.key .. string.format(".baleLoader.bale(%d)", v43)
				if not p40.xmlFile:hasProperty(v45) then
					break
				end
				local v46 = p40.xmlFile:getValue(v45 .. "#filename")
				if v46 ~= nil then
					local v47 = NetworkUtil.convertFromNetworkFilename(v46)
					local v48 = p40.xmlFile:getValue(v45 .. "#position", nil, true)
					local v49 = p40.xmlFile:getValue(v45 .. "#rotation", nil, true)
					local v50 = p40.xmlFile:getValue(v45 .. "#balePlace")
					local v51 = p40.xmlFile:getValue(v45 .. "#helper")
					if v50 == nil or v50 > 0 and (v48 == nil or v49 == nil) or v50 < 1 and v51 == nil then
						printWarning("Warning: Corrupt savegame, bale " .. v47 .. " could not be loaded")
					else
						if v50 <= 0 then
							v48 = { 0, 0, 0 }
							v49 = { 0, 0, 0 }
						end
						local v52 = nil
						local v53 = nil
						if v50 < 1 then
							if v41.startBalePlace.node ~= nil and v51 <= v41.startBalePlace.numOfPlaces then
								v52 = getChildAt(v41.startBalePlace.node, v51 - 1)
								if v41.startBalePlace.bales == nil then
									v41.startBalePlace.bales = {}
								end
								v53 = v41.startBalePlace.bales
								v41.startBalePlace.count = v41.startBalePlace.count + 1
							end
						elseif v50 <= #v41.balePlaces then
							local v54 = v41.startBalePlace
							local v55 = v41.startBalePlace.current
							local v56 = v50 + 1
							v54.current = math.max(v55, v56)
							v52 = v41.balePlaces[v50].node
							if v41.balePlaces[v50].bales == nil then
								v41.balePlaces[v50].bales = {}
							end
							v53 = v41.balePlaces[v50].bales
						end
						if v52 ~= nil then
							local v57 = {}
							Bale.loadBaleAttributesFromXMLFile(v57, p40.xmlFile, v45, p40.resetVehicles)
							v44 = v44 + 1
							local v58 = v41.balesToLoad
							table.insert(v58, {
								["parentNode"] = v52,
								["filename"] = v47,
								["bales"] = v53,
								["translation"] = v48,
								["rotation"] = v49,
								["attributes"] = v57
							})
						end
					end
				end
				v43 = v43 + 1
			end
		end
		p39:updateFoldingAnimation()
		BaleLoader.updateBalePlacesAnimations(p39)
	end
end
function BaleLoader.onLoadFinished(p59, _)
	local v60 = p59.spec_baleLoader
	for v61, v62 in pairs(v60.balesToLoad) do
		local v63 = Bale.new(p59.isServer, p59.isClient)
		local v64 = v62.translation
		local v65, v66, v67 = unpack(v64)
		local v68 = v62.rotation
		local v69, v70, v71 = unpack(v68)
		if v63:loadFromConfigXML(v62.filename, v65, v66, v67, v69, v70, v71, v62.attributes.uniqueId) then
			v63:applyBaleAttributes(v62.attributes)
			v63:register()
			if v60.dynamicMount.enabled then
				p59:mountDynamicBale(v63, v62.parentNode)
			else
				p59:mountBale(v63, p59, v62.parentNode, v65, v66, v67, v69, v70, v71)
			end
			v63:setCanBeSold(false)
			local v72 = v62.bales
			local v73 = NetworkUtil.getObjectId
			table.insert(v72, v73(v63))
		end
		v60.balesToLoad[v61] = nil
	end
end
function BaleLoader.onDelete(p74)
	local v75 = p74.spec_baleLoader
	if v75.balePlaces ~= nil then
		for _, v76 in pairs(v75.balePlaces) do
			if v76.bales ~= nil then
				for _, v77 in pairs(v76.bales) do
					local v78 = NetworkUtil.getObject(v77)
					if v78 ~= nil then
						if v75.dynamicMount.enabled then
							p74:unmountDynamicBale(v78)
						else
							p74:unmountBale(v78)
						end
						v78:setCanBeSold(true)
						if p74.isReconfigurating ~= nil and p74.isReconfigurating then
							v78:delete()
						end
					end
				end
			end
		end
	end
	if v75.startBalePlace ~= nil then
		for _, v79 in ipairs(v75.startBalePlace.bales) do
			local v80 = NetworkUtil.getObject(v79)
			if v80 ~= nil then
				if v75.dynamicMount.enabled then
					p74:unmountDynamicBale(v80)
				else
					p74:unmountBale(v80)
				end
				v80:setCanBeSold(true)
				if p74.isReconfigurating ~= nil and p74.isReconfigurating then
					v80:delete()
				end
			end
		end
	end
	if v75.baleGrabber ~= nil then
		if v75.baleGrabber.currentBale ~= nil then
			local v81 = NetworkUtil.getObject(v75.baleGrabber.currentBale)
			if v81 ~= nil then
				if v75.dynamicMount.enabled then
					p74:unmountDynamicBale(v81)
				else
					p74:unmountBale(v81)
				end
				v81:setCanBeSold(true)
			end
		end
		if v75.baleGrabber.trigger ~= nil then
			removeTrigger(v75.baleGrabber.trigger)
			g_currentMission:removeNodeObject(v75.baleGrabber.trigger)
		end
	end
	if v75.unloadingMover ~= nil then
		if v75.unloadingMover.trigger ~= nil then
			removeTrigger(v75.unloadingMover.trigger)
			g_currentMission:removeNodeObject(v75.unloadingMover.trigger)
		end
		g_animationManager:deleteAnimations(v75.unloadingMover.animationNodes)
	end
	if v75.baleUnloadTriggers ~= nil then
		for v82, _ in pairs(v75.baleUnloadTriggers) do
			v82:removeDeleteListener(p74, BaleLoader.onBaleUnloadTriggerDeleted)
			v75.baleUnloadTriggers[v82] = nil
		end
	end
	g_effectManager:deleteEffects(v75.grabberEffects)
	g_soundManager:deleteSamples(v75.samples)
	g_animationManager:deleteAnimations(v75.animationNodes)
end
function BaleLoader.saveToXMLFile(p83, p84, p85, _)
	local v86 = p83.spec_baleLoader
	p84:setValue(p85 .. "#isInWorkPosition", v86.isInWorkPosition)
	if v86.currentBaleType ~= nil then
		p84:setValue(p85 .. "#baleTypeIndex", v86.currentBaleType.index)
	end
	local v87 = 0
	for v88, v89 in pairs(v86.balePlaces) do
		if v89.bales ~= nil then
			for _, v90 in pairs(v89.bales) do
				local v91 = NetworkUtil.getObject(v90)
				if v91 ~= nil then
					local v92 = string.format("%s.bale(%d)", p85, v87)
					v91:saveToXMLFile(p84, v92)
					local v93 = #v86.startBalePlace.bales == 0
					local v94 = p83:getFillUnitFillLevel(v86.fillUnitIndex) % v86.startBalePlace.numOfPlaces ~= 0
					local v95 = p83:getFillUnitFillLevel(v86.fillUnitIndex) / v86.startBalePlace.numOfPlaces
					if v93 and (v94 and (math.floor(v95) + 1 == v88 and p83:getFillUnitCapacity(v86.fillUnitIndex) % 2 == 0)) then
						p84:setValue(v92 .. "#balePlace", 0)
						p84:setValue(v92 .. "#helper", 1)
					else
						p84:setValue(v92 .. "#balePlace", v88)
					end
					v87 = v87 + 1
				end
			end
		end
	end
	for v96, v97 in ipairs(v86.startBalePlace.bales) do
		local v98 = NetworkUtil.getObject(v97)
		if v98 ~= nil then
			local v99 = string.format("%s.bale(%d)", p85, v87)
			v98:saveToXMLFile(p84, v99)
			p84:setValue(v99 .. "#balePlace", 0)
			p84:setValue(v99 .. "#helper", v96)
			v87 = v87 + 1
		end
	end
	if v86.hasMultipleFoldingAnimations and v86.lastFoldingAnimation ~= nil then
		p84:setValue(p85 .. "#lastFoldingAnimation", v86.lastFoldingAnimation)
	end
	if v86.baleGrabber.currentBale ~= nil then
		local v100 = NetworkUtil.getObject(v86.baleGrabber.currentBale)
		if v100 ~= nil then
			p83:unmountBale(v100)
			v86.baleGrabber.currentBaleIsUnmounted = true
		end
	end
end
function BaleLoader.onReadStream(p101, p102, _)
	local v103 = p101.spec_baleLoader
	v103.isInWorkPosition = streamReadBool(p102)
	v103.frontBalePusherDirection = streamReadIntN(p102, 3)
	v103.rotatePlatformDirection = streamReadIntN(p102, 3)
	if streamReadBool(p102) then
		p101:setBaleLoaderBaleType((streamReadIntN(p102, 6)))
	end
	if v103.isInWorkPosition then
		BaleLoader.moveToWorkPosition(p101)
	end
	local v104 = streamReadUIntN(p102, 4)
	v103.startBalePlace.current = streamReadInt8(p102)
	if streamReadBool(p102) then
		v103.baleGrabber.currentBale = NetworkUtil.readNodeObjectId(p102)
		v103.balesToMount[v103.baleGrabber.currentBale] = {
			["serverId"] = v103.baleGrabber.currentBale,
			["linkNode"] = v103.baleGrabber.grabNode,
			["trans"] = { 0, 0, 0 },
			["rot"] = { 0, 0, 0 }
		}
	end
	v103.startBalePlace.count = streamReadUInt8(p102)
	for v105 = 1, v103.startBalePlace.count do
		local v106 = NetworkUtil.readNodeObjectId(p102)
		local v107 = {
			["serverId"] = v106,
			["linkNode"] = getChildAt(v103.startBalePlace.node, v105 - 1),
			["trans"] = { 0, 0, 0 },
			["rot"] = { 0, 0, 0 }
		}
		v103.balesToMount[v106] = v107
		local v108 = v103.startBalePlace.bales
		table.insert(v108, v106)
		p101:updateFoldingAnimation()
	end
	for v109 = 1, #v103.balePlaces do
		local v110 = v103.balePlaces[v109]
		local v111 = streamReadUInt8(p102)
		if v111 > 0 then
			v110.bales = {}
			for _ = 1, v111 do
				local v112 = NetworkUtil.readNodeObjectId(p102)
				local v113, v114, v115
				if v103.dynamicMount.enabled then
					v113 = 0
					v114 = 0
					v115 = 0
				else
					local v116 = 2 ^ v103.synchronizationNumBitsPosition - 1
					v113 = streamReadUIntN(p102, v103.synchronizationNumBitsPosition) / v116 * (v103.synchronizationMaxPosition * 2) - v103.synchronizationMaxPosition
					v114 = streamReadUIntN(p102, v103.synchronizationNumBitsPosition) / v116 * (v103.synchronizationMaxPosition * 2) - v103.synchronizationMaxPosition
					v115 = streamReadUIntN(p102, v103.synchronizationNumBitsPosition) / v116 * (v103.synchronizationMaxPosition * 2) - v103.synchronizationMaxPosition
				end
				local v117 = v110.bales
				table.insert(v117, v112)
				v103.balesToMount[v112] = {
					["serverId"] = v112,
					["linkNode"] = v110.node,
					["trans"] = { v113, v114, v115 },
					["rot"] = { 0, 0, 0 }
				}
			end
		end
	end
	BaleLoader.updateBalePlacesAnimations(p101)
	if BaleLoader.EMPTY_TO_WORK <= v104 then
		p101:doStateChange(BaleLoader.CHANGE_EMPTY_START)
		AnimatedVehicle.updateAnimations(p101, 99999999, true)
		if BaleLoader.EMPTY_ROTATE_PLATFORM <= v104 then
			p101:doStateChange(BaleLoader.CHANGE_EMPTY_ROTATE_PLATFORM)
			AnimatedVehicle.updateAnimations(p101, 99999999, true)
			if BaleLoader.EMPTY_ROTATE1 <= v104 then
				p101:doStateChange(BaleLoader.CHANGE_EMPTY_ROTATE1)
				AnimatedVehicle.updateAnimations(p101, 99999999, true)
				if BaleLoader.EMPTY_CLOSE_GRIPPERS <= v104 then
					p101:doStateChange(BaleLoader.CHANGE_EMPTY_CLOSE_GRIPPERS)
					AnimatedVehicle.updateAnimations(p101, 99999999, true)
					if BaleLoader.EMPTY_HIDE_PUSHER1 <= v104 then
						p101:doStateChange(BaleLoader.CHANGE_EMPTY_HIDE_PUSHER1)
						AnimatedVehicle.updateAnimations(p101, 99999999, true)
						if BaleLoader.EMPTY_HIDE_PUSHER2 <= v104 then
							p101:doStateChange(BaleLoader.CHANGE_EMPTY_HIDE_PUSHER2)
							AnimatedVehicle.updateAnimations(p101, 99999999, true)
							if BaleLoader.EMPTY_ROTATE2 <= v104 then
								p101:doStateChange(BaleLoader.CHANGE_EMPTY_ROTATE2)
								AnimatedVehicle.updateAnimations(p101, 99999999, true)
								if BaleLoader.EMPTY_WAIT_TO_DROP <= v104 then
									p101:doStateChange(BaleLoader.CHANGE_EMPTY_WAIT_TO_DROP)
									AnimatedVehicle.updateAnimations(p101, 99999999, true)
									if v104 == BaleLoader.EMPTY_CANCEL or v104 == BaleLoader.EMPTY_WAIT_TO_REDO then
										p101:doStateChange(BaleLoader.CHANGE_EMPTY_CANCEL)
										AnimatedVehicle.updateAnimations(p101, 99999999, true)
										if v104 == BaleLoader.EMPTY_WAIT_TO_REDO then
											p101:doStateChange(BaleLoader.CHANGE_EMPTY_WAIT_TO_REDO)
											AnimatedVehicle.updateAnimations(p101, 99999999, true)
										end
									elseif v104 == BaleLoader.EMPTY_WAIT_TO_SINK or v104 == BaleLoader.EMPTY_SINK then
										p101:doStateChange(BaleLoader.CHANGE_DROP_BALES)
										AnimatedVehicle.updateAnimations(p101, 99999999, true)
										if v104 == BaleLoader.EMPTY_SINK then
											p101:doStateChange(BaleLoader.CHANGE_SINK)
											AnimatedVehicle.updateAnimations(p101, 99999999, true)
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
	v103.emptyState = v104
end
function BaleLoader.onWriteStream(p118, p119, _)
	local v120 = p118.spec_baleLoader
	streamWriteBool(p119, v120.isInWorkPosition)
	streamWriteIntN(p119, v120.frontBalePusherDirection, 3)
	streamWriteIntN(p119, v120.rotatePlatformDirection, 3)
	if streamWriteBool(p119, v120.currentBaleType ~= nil) then
		streamWriteIntN(p119, v120.currentBaleType.index or 1, 6)
	end
	streamWriteUIntN(p119, v120.emptyState, 4)
	streamWriteInt8(p119, v120.startBalePlace.current)
	if streamWriteBool(p119, v120.baleGrabber.currentBale ~= nil) then
		NetworkUtil.writeNodeObjectId(p119, v120.baleGrabber.currentBale)
	end
	streamWriteUInt8(p119, v120.startBalePlace.count)
	for v121 = 1, v120.startBalePlace.count do
		local v122 = v120.startBalePlace.bales[v121]
		NetworkUtil.writeNodeObjectId(p119, v122)
	end
	for v123 = 1, #v120.balePlaces do
		local v124 = v120.balePlaces[v123]
		local v125 = v124.bales == nil and 0 or #v124.bales
		streamWriteUInt8(p119, v125)
		if v124.bales ~= nil then
			for v126 = 1, v125 do
				local v127 = v124.bales[v126]
				local v128 = NetworkUtil.getObject(v127).nodeId
				local v129, v130, v131 = getTranslation(v128)
				NetworkUtil.writeNodeObjectId(p119, v127)
				if not v120.dynamicMount.enabled then
					if math.abs(v129) > v120.synchronizationMaxPosition or (math.abs(v130) > v120.synchronizationMaxPosition or math.abs(v131) > v120.synchronizationMaxPosition) then
						Logging.xmlWarning(p118.xmlFile, "Position of bale \'%d\' could not be synchronized correctly. Position out of range (%.2f, %.2f, %.2f) > %.2f. Increase \'vehicle.baleLoader.synchronization#maxPosition\'", v126, v129, v130, v131, v120.synchronizationMaxPosition)
					end
					local v132 = 2 ^ v120.synchronizationNumBitsPosition - 1
					streamWriteUIntN(p119, (v120.synchronizationMaxPosition + v129) / (v120.synchronizationMaxPosition * 2) * v132, v120.synchronizationNumBitsPosition)
					streamWriteUIntN(p119, (v120.synchronizationMaxPosition + v130) / (v120.synchronizationMaxPosition * 2) * v132, v120.synchronizationNumBitsPosition)
					streamWriteUIntN(p119, (v120.synchronizationMaxPosition + v131) / (v120.synchronizationMaxPosition * 2) * v132, v120.synchronizationNumBitsPosition)
				end
			end
		end
	end
end
function BaleLoader.onReadUpdateStream(p133, p134, _, p135)
	local v136 = p133.spec_baleLoader
	if p135:getIsServer() and streamReadBool(p134) then
		local v137 = streamReadBool(p134)
		if v137 ~= v136.unloadingMover.isActive then
			if v137 then
				g_animationManager:startAnimations(v136.unloadingMover.animationNodes)
				g_soundManager:playSample(v136.samples.unload)
			else
				g_animationManager:stopAnimations(v136.unloadingMover.animationNodes)
				g_soundManager:stopSample(v136.samples.unload)
			end
			v136.unloadingMover.isActive = v137
		end
	end
end
function BaleLoader.onWriteUpdateStream(p138, p139, p140, p141)
	local v142 = p138.spec_baleLoader
	if not p140:getIsServer() and streamWriteBool(p139, bitAND(p141, v142.unloadingMover.dirtyFlag) ~= 0) then
		streamWriteBool(p139, v142.unloadingMover.isActive)
	end
end
function BaleLoader.updateBalePlacesAnimations(p143)
	local v144 = p143.spec_baleLoader
	if v144.startBalePlace ~= nil and v144.startBalePlace.current > v144.startBalePlace.numOfPlaces or v144.animations.moveBalePlacesAfterRotatePlatform and v144.startBalePlace.current > 1 then
		local v145 = #v144.balePlaces
		local v146 = v144.animations.moveBalePlacesAfterRotatePlatform and not (v144.animations.moveBalePlacesAlways or v144.useBalePlaceAsLoadPosition) and 0 or 1
		if v144.useBalePlaceAsLoadPosition then
			v145 = v145 - 1
			v146 = v146 + v144.balePlaceOffset
		end
		p143:playAnimation(v144.animations.moveBalePlaces, 1, 0, true)
		local v147 = v144.animations.moveBalePlaces
		local v148 = (v144.startBalePlace.current - v146) / v145
		p143:setAnimationStopTime(v147, (math.min(v148, 1)))
		AnimatedVehicle.updateAnimations(p143, 99999999, true)
	end
	if v144.startBalePlace ~= nil and v144.startBalePlace.count >= 1 then
		p143:playAnimation(v144.animations.balesToOtherRow, 20, nil, true)
		AnimatedVehicle.updateAnimations(p143, 99999999, true)
		if v144.startBalePlace.count >= v144.startBalePlace.numOfPlaces then
			BaleLoader.rotatePlatform(p143)
		end
	end
end
function BaleLoader.onUpdate(p149, _, _, _, _)
	local v150 = p149.spec_baleLoader
	if p149.finishedFirstUpdate then
		for v151, v152 in pairs(v150.balesToMount) do
			local v153 = NetworkUtil.getObject(v152.serverId)
			if v153 ~= nil then
				local v154 = v152.trans
				local v155, v156, v157 = unpack(v154)
				local v158 = v152.rot
				local v159, v160, v161 = unpack(v158)
				if v150.dynamicMount.enabled then
					p149:mountDynamicBale(v153, v152.linkNode)
				else
					p149:mountBale(v153, p149, v152.linkNode, v155, v156, v157, v159, v160, v161)
				end
				local v162 = p149:getBaleTypeByBale(v153)
				if v162 ~= nil then
					p149:setBaleLoaderBaleType(v162.index)
				end
				v150.balesToMount[v151] = nil
			end
		end
	end
	if p149.isClient and (v150.grabberEffectDisableTime ~= 0 and v150.grabberEffectDisableTime < g_currentMission.time) then
		g_effectManager:stopEffects(v150.grabberEffects)
		v150.grabberEffectDisableTime = 0
	end
	if v150.grabberIsMoving and not p149:getIsBaleLoaderFoldingPlaying() then
		v150.grabberIsMoving = false
	end
	v150.showBaleNotSupportedWarning = false
	if p149:getIsBaleGrabbingAllowed() and (v150.baleGrabber.grabNode ~= nil and v150.baleGrabber.currentBale == nil) then
		local v163, v164, v165 = BaleLoader.getBaleInRange(p149, v150.baleGrabber.grabNode, v150.baleGrabber.balesInTrigger)
		if v163 ~= nil then
			if v164 == nil then
				v150.showBaleNotSupportedWarning = true
				v150.baleNotSupportedWarning = v165
			elseif p149.isServer then
				p149:pickupBale(v163, v164)
			end
		end
	end
	if p149.isServer then
		if v150.grabberMoveState ~= nil then
			if v150.grabberMoveState == BaleLoader.GRAB_MOVE_UP then
				if not p149:getIsAnimationPlaying(v150.animations.baleGrabberWorkToDrop) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_GRAB_MOVE_UP), true, nil, p149)
				end
			elseif v150.grabberMoveState == BaleLoader.GRAB_DROP_BALE then
				if not p149:getIsAnimationPlaying(v150.currentBaleGrabberDropBaleAnimName) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_GRAB_DROP_BALE), true, nil, p149)
				end
			elseif v150.grabberMoveState == BaleLoader.GRAB_MOVE_DOWN and not p149:getIsAnimationPlaying(v150.animations.baleGrabberDropToWork or v150.animations.baleGrabberWorkToDrop) then
				g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_GRAB_MOVE_DOWN), true, nil, p149)
				p149:setAnimationTime(v150.currentBaleGrabberDropBaleAnimName, 0, false)
				p149:setAnimationTime(v150.animations.baleGrabberWorkToDrop, 0, false)
			end
		end
		if v150.frontBalePusherDirection ~= 0 and not p149:getIsAnimationPlaying(v150.animations.frontBalePusher) then
			g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_FRONT_PUSHER), true, nil, p149)
		end
		if v150.rotatePlatformDirection ~= 0 then
			local v166 = v150.animations.rotatePlatform
			if v150.rotatePlatformDirection < 0 then
				v166 = v150.animations.rotatePlatformBack
			end
			if not (p149:getIsAnimationPlaying(v166) or (p149:getIsAnimationPlaying(v150.animations.moveBalePlacesExtrasOnce) or v150.moveBalePlacesDelayedMovement)) then
				g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_ROTATE_PLATFORM), true, nil, p149)
			end
		end
		if v150.emptyState ~= BaleLoader.EMPTY_NONE then
			if v150.emptyState == BaleLoader.EMPTY_TO_WORK then
				if not p149:getIsBaleLoaderFoldingPlaying() then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_ROTATE_PLATFORM), true, nil, p149)
				end
			elseif v150.emptyState == BaleLoader.EMPTY_ROTATE_PLATFORM then
				if not p149:getIsAnimationPlaying(v150.animations.rotatePlatformEmpty) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_ROTATE1), true, nil, p149)
				end
			elseif v150.emptyState == BaleLoader.EMPTY_ROTATE1 then
				if not (p149:getIsAnimationPlaying(v150.animations.emptyRotate) or p149:getIsAnimationPlaying(v150.animations.moveBalePlacesToEmpty)) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_CLOSE_GRIPPERS), true, nil, p149)
				end
			elseif v150.emptyState == BaleLoader.EMPTY_CLOSE_GRIPPERS then
				if not p149:getIsAnimationPlaying(v150.animations.closeGrippers) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_HIDE_PUSHER1), true, nil, p149)
				end
			elseif v150.emptyState == BaleLoader.EMPTY_HIDE_PUSHER1 then
				if not p149:getIsAnimationPlaying(v150.animations.pusherEmptyHide1) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_HIDE_PUSHER2), true, nil, p149)
				end
			elseif v150.emptyState == BaleLoader.EMPTY_HIDE_PUSHER2 then
				if p149:getAnimationTime(v150.animations.pusherMoveToEmpty) < 0.7 or not p149:getIsAnimationPlaying(v150.animations.pusherMoveToEmpty) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_ROTATE2), true, nil, p149)
				end
			elseif v150.emptyState == BaleLoader.EMPTY_ROTATE2 then
				if not p149:getIsAnimationPlaying(v150.animations.emptyRotate) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_WAIT_TO_DROP), true, nil, p149)
				end
			elseif v150.emptyState == BaleLoader.EMPTY_SINK then
				if not (p149:getIsAnimationPlaying(v150.animations.emptyRotate) or (p149:getIsAnimationPlaying(v150.animations.moveBalePlacesToEmpty) or (p149:getIsAnimationPlaying(v150.animations.pusherEmptyHide1) or p149:getIsAnimationPlaying(v150.animations.rotatePlatformEmpty)))) then
					g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_STATE_NIL), true, nil, p149)
				end
			elseif v150.emptyState == BaleLoader.EMPTY_CANCEL and not p149:getIsAnimationPlaying(v150.animations.emptyRotate) then
				g_server:broadcastEvent(BaleLoaderStateEvent.new(p149, BaleLoader.CHANGE_EMPTY_WAIT_TO_REDO), true, nil, p149)
			end
		end
	end
	if v150.baleGrabber.currentBaleIsUnmounted then
		v150.baleGrabber.currentBaleIsUnmounted = false
		local v167 = NetworkUtil.getObject(v150.baleGrabber.currentBale)
		if v167 ~= nil then
			if v150.dynamicMount.enabled then
				p149:mountDynamicBale(v167, v150.baleGrabber.grabNode)
			else
				p149:mountBale(v167, p149, v150.baleGrabber.grabNode, 0, 0, 0, 0, 0, 0)
			end
			v167:setCanBeSold(false)
		end
	end
end
function BaleLoader.onUpdateTick(p168, p169, _, _, _)
	local v170 = p168.spec_baleLoader
	if p168.isClient then
		local v171 = v170.actionEvents[InputAction.IMPLEMENT_EXTRA]
		if v171 ~= nil then
			local v172
			if v170.emptyState == BaleLoader.EMPTY_NONE and v170.grabberMoveState == nil then
				if v170.isInWorkPosition then
					g_inputBinding:setActionEventText(v171.actionEventId, v170.texts.transportPosition)
					v172 = true
				else
					g_inputBinding:setActionEventText(v171.actionEventId, v170.texts.operatingPosition)
					v172 = true
				end
			else
				v172 = false
			end
			g_inputBinding:setActionEventActive(v171.actionEventId, v172)
		end
		local v173 = v170.actionEvents[InputAction.IMPLEMENT_EXTRA2]
		if v173 ~= nil then
			g_inputBinding:setActionEventActive(v173.actionEventId, v170.emptyState == BaleLoader.EMPTY_WAIT_TO_DROP)
		end
		local v174 = v170.actionEvents[InputAction.IMPLEMENT_EXTRA3]
		if v174 ~= nil then
			local v175 = false
			if v170.emptyState == BaleLoader.EMPTY_NONE then
				if BaleLoader.getAllowsStartUnloading(p168) then
					g_inputBinding:setActionEventText(v174.actionEventId, v170.texts.unload)
					v175 = true
				end
			elseif v170.emptyState == BaleLoader.EMPTY_WAIT_TO_DROP then
				g_inputBinding:setActionEventText(v174.actionEventId, v170.texts.unloadHere)
				v175 = true
			elseif v170.emptyState == BaleLoader.EMPTY_WAIT_TO_SINK then
				if not v170.unloadingMover.isActive then
					g_inputBinding:setActionEventText(v174.actionEventId, v170.texts.lowerPlattform)
					v175 = true
				end
			elseif v170.emptyState == BaleLoader.EMPTY_WAIT_TO_REDO then
				g_inputBinding:setActionEventText(v174.actionEventId, v170.texts.unload)
				v175 = true
			end
			g_inputBinding:setActionEventActive(v174.actionEventId, v175)
		end
	end
	if p168.isServer then
		if Platform.gameplay.automaticBaleDrop then
			local v176, _ = next(v170.baleUnloadTriggers)
			if v176 ~= nil and p168:getIsAutomaticBaleUnloadingAllowed() then
				local v177 = p168:getLoadedBales()
				local v178 = false
				for _, v179 in ipairs(v177) do
					if v176:getIsBaleSupportedByUnloadTrigger(v179) then
						v178 = true
						break
					end
				end
				if v178 and BaleLoader.getAllowsStartUnloading(p168) then
					p168:startAutomaticBaleUnloading()
				end
			end
		end
		if v170.fullAutomaticUnloading and (p168:getFillUnitFillLevelPercentage(v170.fillUnitIndex) == 1 or v170.automaticUnloadingAdditionalBalesToLoad == 0) and BaleLoader.getAllowsStartUnloading(p168) then
			p168:startAutomaticBaleUnloading()
		end
		if v170.automaticUnloading or v170.automaticUnloadingInProgress then
			if v170.emptyState == BaleLoader.EMPTY_WAIT_TO_DROP then
				p168:doStateChange(BaleLoader.CHANGE_BUTTON_EMPTY)
			end
			local v180 = p168:getIsAnimationPlaying(v170.animations.releaseFrontPlatform)
			if v170.emptyState == BaleLoader.EMPTY_WAIT_TO_SINK and not (v180 or v170.unloadingMover.isActive) then
				p168:doStateChange(BaleLoader.CHANGE_SINK)
			end
		end
		if #v170.baleJoints > 0 then
			local v181 = v170.dynamicBaleUnloading.useUnloadingMoverTrigger and (v170.unloadingMover.frameDelay == 0 and next(v170.unloadingMover.balesInTrigger) == nil) and true or false
			if v170.dynamicBaleUnloading.useUnloadingMoverTrigger == nil or v181 then
				v181 = false
				if v170.dynamicBaleUnloading.releaseAnimation ~= nil then
					local v182 = v170.dynamicBaleUnloading.releaseAnimation
					v181 = (p168:getAnimationTime(v182) >= v170.dynamicBaleUnloading.releaseAnimationTime or not p168:getIsAnimationPlaying(v182)) and true or v181
				end
			end
			if v181 then
				for v183 = #v170.baleJoints, 1, -1 do
					removeJoint(v170.baleJoints[v183])
					v170.baleJoints[v183] = nil
				end
			end
		end
		if v170.unloadingMover.isActive then
			local v184 = v170.unloadingMover
			local v185 = v170.unloadingMover.frameDelay - 1
			v184.frameDelay = math.max(v185, 0)
			if v170.unloadingMover.frameDelay == 0 and next(v170.unloadingMover.balesInTrigger) == nil then
				v170.unloadingMover.isActive = false
				for v186 = 1, #v170.unloadingMover.nodes do
					setFrictionVelocity(v170.unloadingMover.nodes[v186].node, 0)
				end
				if p168.isClient then
					g_animationManager:stopAnimations(v170.unloadingMover.animationNodes)
					g_soundManager:stopSample(v170.samples.unload)
				end
				p168:raiseDirtyFlags(v170.unloadingMover.dirtyFlag)
			end
		end
		if v170.dynamicMount.enabled then
			local v187 = false
			for v188, v189 in ipairs(v170.dynamicMount.baleJointsToUpdate) do
				if v189.quaternion == nil then
					local v190, v191, v192, v193 = getQuaternion(v189.node)
					v189.quaternion = {
						v190,
						v191,
						v192,
						v193
					}
				end
				if v189.time < v170.dynamicMount.jointInterpolationTimeRot then
					v189.time = v189.time + p169
					local v194 = 0
					local v195 = 0
					local v196 = 0
					local v197 = 1
					local v198 = v189.quaternion[2]
					if math.abs(v198) > 0.5 then
						v194, v195, v196, v197 = MathUtil.slerpQuaternionShortestPath(v189.quaternion[1], v189.quaternion[2], v189.quaternion[3], v189.quaternion[4], 0, 1, 0, 0, v189.time / v170.dynamicMount.jointInterpolationTimeRot)
					else
						local v199 = v189.quaternion[2]
						if math.abs(v199) < 0.5 then
							v194, v195, v196, v197 = MathUtil.slerpQuaternionShortestPath(v189.quaternion[1], v189.quaternion[2], v189.quaternion[3], v189.quaternion[4], 0, 0, 0, 1, v189.time / v170.dynamicMount.jointInterpolationTimeRot)
						end
					end
					setQuaternion(v189.node, v194, v195, v196, v197)
					v187 = true
				end
				local v200, v201, v202 = getTranslation(v189.node)
				if math.abs(v200) + math.abs(v201) + math.abs(v202) > 0.001 then
					local v_u_203 = v170.dynamicMount.jointInterpolationSpeedTrans * p169
					setTranslation(v189.node, (math.sign(v200) > 0 and math.max or math.min)(v200 - math.sign(v200) * v_u_203, 0), (math.sign(v201) > 0 and math.max or math.min)(v201 - math.sign(v201) * v_u_203, 0), (function(p204)
						-- upvalues: (copy) v_u_203
						return (math.sign(p204) > 0 and math.max or math.min)(p204 - math.sign(p204) * v_u_203, 0)
					end)(v202))
					v187 = true
				elseif v189.time > v170.dynamicMount.jointInterpolationTimeRot then
					table.remove(v170.dynamicMount.baleJointsToUpdate, v188)
				end
			end
			local v205 = false
			for v206, _ in pairs(p168.spec_animatedVehicle.animations) do
				if p168:getIsAnimationPlaying(v206) then
					v205 = true
				end
			end
			if v205 or (v187 or v170.dynamicMount.baleMassDirty) then
				for _, v207 in pairs(v170.balePlaces) do
					if v207.bales ~= nil then
						for _, v208 in pairs(v207.bales) do
							local v209 = NetworkUtil.getObject(v208)
							if v209 ~= nil then
								if v209.dynamicMountJointIndex ~= nil then
									setJointFrame(v209.dynamicMountJointIndex, 0, v209.baleLoaderDynamicJointNode)
								end
								if v209.backupMass == nil then
									local v210 = getMass(v209.nodeId)
									if v210 ~= 1 then
										v209.backupMass = v210
										setMass(v209.nodeId, 0.1)
										v170.dynamicMount.baleMassDirty = false
									end
								end
							end
						end
					end
				end
				if v170.startBalePlace ~= nil then
					for _, v211 in ipairs(v170.startBalePlace.bales) do
						local v212 = NetworkUtil.getObject(v211)
						if v212 ~= nil then
							if v212.dynamicMountJointIndex ~= nil then
								setJointFrame(v212.dynamicMountJointIndex, 0, v212.baleLoaderDynamicJointNode)
							end
							if v212.backupMass == nil then
								local v213 = getMass(v212.nodeId)
								if v213 ~= 1 then
									v212.backupMass = v213
									setMass(v212.nodeId, 0.1)
									v170.dynamicMount.baleMassDirty = false
								end
							end
						end
					end
				end
				if v170.baleGrabber.currentBale ~= nil then
					local v214 = NetworkUtil.getObject(v170.baleGrabber.currentBale)
					if v214 ~= nil and v214.dynamicMountJointIndex ~= nil then
						setJointFrame(v214.dynamicMountJointIndex, 0, v214.baleLoaderDynamicJointNode)
					end
				end
			end
		end
	end
	if v170.moveBalePlacesDelayedMovement and p168:getAnimationTime(v170.animations.baleGrabberWorkToDrop) < v170.animations.moveBalePlacesMaxGrabberTime then
		v170.rotatePlatformDirection = -1
		p168:playAnimation(v170.animations.rotatePlatformBack, -1, nil, true)
		if v170.animations.moveBalePlacesAfterRotatePlatform and (v170.startBalePlace ~= nil and v170.startBalePlace.current <= #v170.balePlaces or v170.animations.moveBalePlacesAlways) then
			p168:playAnimation(v170.animations.moveBalePlaces, 1, (v170.startBalePlace.current - 1) / #v170.balePlaces, true)
			p168:setAnimationStopTime(v170.animations.moveBalePlaces, v170.startBalePlace.current / #v170.balePlaces)
			p168:playAnimation(v170.animations.moveBalePlacesExtrasOnce, 1, nil, true)
		end
		v170.moveBalePlacesDelayedMovement = nil
	end
	if v170.animations.moveBalePlacesToEmptyPushOffsetTime > 0 then
		v170.animations.moveBalePlacesToEmptyPushOffsetTime = v170.animations.moveBalePlacesToEmptyPushOffsetTime - p169
		if v170.animations.moveBalePlacesToEmptyPushOffsetTime <= 0 then
			local v215 = p168:getRealAnimationTime(v170.animations.moveBalePlaces)
			local v216 = p168:getAnimationDuration(v170.animations.moveBalePlacesToEmpty)
			local v217 = v215 / v216
			local v218 = (v216 - v215) / (v216 - v215 - v170.animations.moveBalePlacesToEmptyPushOffsetDelay * v170.animations.moveBalePlacesToEmptySpeed)
			local v219 = v170.animations.moveBalePlacesToEmptySpeed * v218
			p168:playAnimation(v170.animations.moveBalePlacesToEmpty, v219, v217, true)
			v170.animations.moveBalePlacesToEmptyPushOffsetTime = 0
		end
	end
end
function BaleLoader.onDraw(p220, _, _, _)
	local v221 = p220.spec_baleLoader
	if v221.showBaleNotSupportedWarning and v221.baleNotSupportedWarning ~= nil then
		g_currentMission:showBlinkingWarning(v221.baleNotSupportedWarning, 2000)
	end
end
function BaleLoader.getBaleInRange(p222, p223, p224)
	local v225 = p222.spec_baleLoader
	local v226 = v225.baleGrabber.pickupRange
	local v227 = v225.texts.baleNotSupported
	local v228 = nil
	local v229 = nil
	for v230, v231 in pairs(p224) do
		if v231 ~= nil and v231 > 0 then
			local v232 = true
			local v233 = nil
			for _, v234 in pairs(v225.balePlaces) do
				if v234.bales ~= nil then
					for _, v235 in pairs(v234.bales) do
						v233 = NetworkUtil.getObject(v235)
						if v233 ~= nil and v233 == v230 then
							v232 = false
						end
					end
				end
			end
			if v225.startBalePlace ~= nil then
				for _, v236 in ipairs(v225.startBalePlace.bales) do
					v233 = NetworkUtil.getObject(v236)
					if v233 ~= nil and v233 == v230 then
						v232 = false
					end
				end
			end
			if v230 == nil or not entityExists(v230.nodeId) then
				v232 = false
			end
			if v232 then
				local v237 = calcDistanceFrom(p223, v230.nodeId)
				if v237 < v226 then
					local v238 = p222:getBaleTypeByBale(v230)
					if v238 ~= v225.currentBaleType and p222:getFillUnitFillLevel(v225.currentBaleType.fillUnitIndex) ~= 0 then
						v227 = v225.texts.onlyOneBaleTypeWarning
						v238 = nil
					end
					if v238 ~= nil and (not v238.mixedFillTypes and (v233 ~= nil and v230:getFillType() ~= v233:getFillType())) then
						v227 = v225.texts.baleDoNotAllowFillTypeMixing
						v238 = nil
					end
					if v230:getIsMounted() or v230.baleJointIndex ~= nil then
						v238 = nil
						v227 = nil
					end
					if not v230:getBaleSupportsBaleLoader() then
						v238 = nil
					end
					local v239 = p222:getActiveFarm()
					if v239 ~= v230.ownerFarmId and (not g_currentMission.accessHandler:canFarmAccessOtherId(v239, v230.ownerFarmId) and p222.spec_baler == nil) then
						v227 = v225.texts.youDoNotOwnBale
						v238 = nil
					end
					if v238 ~= nil or v228 == nil then
						if v238 == nil then
							v237 = v226
						end
						v229 = v230
						v226 = v237
						v228 = v238
					end
				end
			end
		end
	end
	return v229, v228, v227
end
function BaleLoader.onActivate(p240)
	local v241 = p240.spec_baleLoader
	if v241.isInWorkPosition and not v241.animationNodesBlocked then
		g_animationManager:startAnimations(v241.animationNodes)
		g_soundManager:playSample(v241.samples.work)
	end
end
function BaleLoader.onDeactivate(p242)
	local v243 = p242.spec_baleLoader
	g_effectManager:stopEffects(v243.grabberEffects)
	g_animationManager:stopAnimations(v243.animationNodes)
	g_soundManager:stopSample(v243.samples.work)
end
function BaleLoader.onRootVehicleChanged(p244, p245)
	local v246 = p244.spec_baleLoader
	local v247 = p245.actionController
	if v247 == nil then
		if v246.controlledAction ~= nil then
			v246.controlledAction:remove()
		end
		return
	elseif v246.controlledAction == nil then
		v246.controlledAction = v247:registerAction("baleLoaderWorkstate", nil, 4)
		v246.controlledAction:setCallback(p244, BaleLoader.actionControllerEvent)
		v246.controlledAction:setFinishedFunctions(p244, function(p248)
			return p248.spec_baleLoader.isInWorkPosition
		end, true, false)
		v246.controlledAction:addAIEventListener(p244, "onAIImplementPrepareForTransport", -1)
	else
		v246.controlledAction:updateParent(v247)
	end
end
function BaleLoader.actionControllerEvent(p249, p250)
	local v251 = p249.spec_baleLoader
	if v251.grabberIsMoving or v251.grabberMoveState ~= nil or (p250 <= 0 or v251.isInWorkPosition) and (p250 >= 0 or not v251.isInWorkPosition) then
		return false
	end
	BaleLoader.actionEventWorkTransport(p249)
	return true
end
function BaleLoader.onFillUnitFillLevelChanged(p252, p253, _, _, _, _, _)
	if p253 == p252.spec_baleLoader.fillUnitIndex then
		p252:updateFoldingAnimation()
	end
end
function BaleLoader.onFoldStateChanged(p254, p255)
	if p254.spec_baleLoader.useFoldingState and p254.isServer then
		if p255 == p254.spec_foldable.turnOnFoldDirection then
			g_server:broadcastEvent(BaleLoaderStateEvent.new(p254, BaleLoader.CHANGE_MOVE_TO_WORK), true, nil, p254)
			return
		end
		g_server:broadcastEvent(BaleLoaderStateEvent.new(p254, BaleLoader.CHANGE_MOVE_TO_TRANSPORT), true, nil, p254)
	end
end
function BaleLoader.onBalerUnloadingStarted(p256, p257)
	local v258 = p256.spec_baleLoader
	if v258.fullAutomaticUnloading then
		v258.automaticUnloadingAdditionalBalesToLoad = p257
	end
end
function BaleLoader.onRegisterAnimationValueTypes(p259)
	local v_u_260 = p259.spec_baleLoader
	p259:registerAnimationValueType("baleLoaderAnimationNodes", "baleLoaderAnimationNodes", "", false, AnimationValueBool, function(_, _, _)
		return true
	end, function(_)
		-- upvalues: (copy) v_u_260
		return not v_u_260.animationNodesBlocked
	end, function(_, p261)
		-- upvalues: (copy) v_u_260
		v_u_260.animationNodesBlocked = not p261
		if not v_u_260.animationNodesBlocked and v_u_260.isInWorkPosition then
			g_animationManager:startAnimations(v_u_260.animationNodes)
			g_soundManager:playSample(v_u_260.samples.work)
		end
		if v_u_260.animationNodesBlocked and v_u_260.isInWorkPosition then
			g_animationManager:stopAnimations(v_u_260.animationNodes)
			g_soundManager:stopSample(v_u_260.samples.work)
		end
	end)
end
function BaleLoader.loadBaleTypeFromXML(p262, p_u_263, p264, p265)
	local v266 = p262.spec_baleLoader
	local function v277(p267, p268, p269, p270, p271)
		-- upvalues: (copy) p_u_263
		local v272 = p267:getValue(p268 .. "#" .. p269)
		local v273 = p267:getValue(p268 .. "#" .. p270)
		local v274 = p267:getValue(p268 .. "#" .. p271)
		local v275 = v273 or (v274 or v272)
		local v276 = v274 or v275
		if v275 ~= nil and v276 ~= nil then
			return MathUtil.round(v275, 2), MathUtil.round(v276, 2)
		end
		Logging.xmlError(p_u_263, "Unable to load bale dimension. \'%s\' is not available in \'%s\'", p269, p268)
		return 0, 0
	end
	p265.dimensions = {}
	local v278 = p265.dimensions
	v278.isRoundbale = (p262.xmlFile:getString(p264 .. "#diameter") ~= nil or p262.xmlFile:getString(p264 .. "#minDiameter") ~= nil) and true or p262.xmlFile:getString(p264 .. "#maxDiameter") ~= nil
	if v278.isRoundbale then
		local v279, v280 = v277(p262.xmlFile, p264, "width", "minWidth", "maxWidth")
		v278.minWidth = v279
		v278.maxWidth = v280
		local v281, v282 = v277(p262.xmlFile, p264, "diameter", "minDiameter", "maxDiameter")
		v278.minDiameter = v281
		v278.maxDiameter = v282
	else
		local v283, v284 = v277(p262.xmlFile, p264, "width", "minWidth", "maxWidth")
		v278.minWidth = v283
		v278.maxWidth = v284
		local v285, v286 = v277(p262.xmlFile, p264, "height", "minHeight", "maxHeight")
		v278.minHeight = v285
		v278.maxHeight = v286
		local v287, v288 = v277(p262.xmlFile, p264, "length", "minLength", "maxLength")
		v278.minLength = v287
		v278.maxLength = v288
	end
	p265.mixedFillTypes = p262.xmlFile:getValue(p264 .. "#mixedFillTypes", true)
	p265.fillUnitIndex = p262.xmlFile:getValue(p264 .. "#fillUnitIndex", v266.fillUnitIndex)
	p265.changeObjects = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p262.xmlFile, p264, p265.changeObjects, p262.components, p262)
	p262:loadBalePlacesFromXML(p_u_263, p264, p265)
	return p262:loadBaleLoaderAnimationsFromXML(p_u_263, p264, p265, v266.defaultAnimations) and true or false
end
function BaleLoader.loadBaleLoaderAnimationsFromXML(_, p289, p290, p291, p292)
	p291.animations = {}
	local v293 = p291.animations
	if p292 ~= nil then
		v293 = p292.animations or p291.animations
	end
	p291.animations.rotatePlatform = p289:getValue(p290 .. ".animations.platform#rotate", v293.rotatePlatform or "rotatePlatform")
	p291.animations.rotatePlatformBack = p289:getValue(p290 .. ".animations.platform#rotateBack", v293.rotatePlatformBack or "rotatePlatform")
	p291.animations.rotatePlatformEmpty = p289:getValue(p290 .. ".animations.platform#rotateEmpty", v293.rotatePlatformEmpty or "rotatePlatform")
	p291.animations.rotatePlatformAllowPickup = p289:getValue(p290 .. ".animations.platform#allowPickupWhileMoving", Utils.getNoNil(v293.rotatePlatformAllowPickup, false))
	p291.animations.baleGrabberDropBaleReverseSpeed = p289:getValue(p290 .. ".animations.baleGrabber#dropBaleReverseSpeed", v293.baleGrabberDropBaleReverseSpeed or 5)
	p291.animations.baleGrabberDropToWork = p289:getValue(p290 .. ".animations.baleGrabber#dropToWork", v293.baleGrabberDropToWork)
	p291.animations.baleGrabberWorkToDrop = p289:getValue(p290 .. ".animations.baleGrabber#workToDrop", v293.baleGrabberWorkToDrop or "baleGrabberWorkToDrop")
	p291.animations.baleGrabberDropBale = p289:getValue(p290 .. ".animations.baleGrabber#dropBale", v293.baleGrabberDropBale or "baleGrabberDropBale")
	p291.animations.baleGrabberTransportToWork = p289:getValue(p290 .. ".animations.baleGrabber#transportToWork", v293.baleGrabberTransportToWork or "baleGrabberTransportToWork")
	p291.animations.pusherEmptyHide1 = p289:getValue(p290 .. ".animations.pusher#emptyHide", v293.pusherEmptyHide1 or "emptyHidePusher1")
	p291.animations.pusherMoveToEmpty = p289:getValue(p290 .. ".animations.pusher#moveToEmpty", v293.pusherMoveToEmpty or "moveBalePusherToEmpty")
	p291.animations.pusherHideOnEmpty = p289:getValue(p290 .. ".animations.pusher#hidePusherOnEmpty", Utils.getNoNil(v293.pusherHideOnEmpty, true))
	p291.animations.pusherPushBalesOnEmpty = p289:getValue(p290 .. ".animations.pusher#pushBalesOnEmpty", Utils.getNoNil(v293.pusherPushBalesOnEmpty, false))
	p291.animations.releaseFrontPlatform = p289:getValue(p290 .. ".animations.releaseFrontPlatform#name", v293.releaseFrontPlatform or "releaseFrontplattform")
	p291.animations.releaseFrontPlatformFillLevelSpeed = p289:getValue(p290 .. ".animations.releaseFrontPlatform#fillLevelSpeed", Utils.getNoNil(v293.releaseFrontPlatformFillLevelSpeed, false))
	p291.animations.moveBalePlaces = p289:getValue(p290 .. ".animations.moveBalePlaces#name", v293.moveBalePlaces or "moveBalePlaces")
	p291.animations.moveBalePlacesExtrasOnce = p289:getValue(p290 .. ".animations.moveBalePlaces#extrasOnce", v293.moveBalePlacesExtrasOnce or "moveBalePlacesExtrasOnce")
	p291.animations.moveBalePlacesToEmpty = p289:getValue(p290 .. ".animations.moveBalePlaces#empty", v293.moveBalePlacesToEmpty or "moveBalePlacesToEmpty")
	p291.animations.moveBalePlacesToEmptySpeed = p289:getValue(p290 .. ".animations.moveBalePlaces#emptySpeed", v293.moveBalePlacesToEmptySpeed or 1.5)
	p291.animations.moveBalePlacesToEmptyReverseSpeed = p289:getValue(p290 .. ".animations.moveBalePlaces#emptyReverseSpeed", v293.moveBalePlacesToEmptyReverseSpeed or -1)
	p291.animations.moveBalePlacesToEmptyPushOffset = p289:getValue(p290 .. ".animations.moveBalePlaces#pushOffset", v293.moveBalePlacesToEmptyPushOffset or 0)
	p291.animations.moveBalePlacesToEmptyPushOffsetDelay = 0
	p291.animations.moveBalePlacesToEmptyPushOffsetTime = 0
	p291.animations.moveBalePlacesAfterRotatePlatform = p289:getValue(p290 .. ".animations.moveBalePlaces#moveAfterRotatePlatform", Utils.getNoNil(v293.moveBalePlacesAfterRotatePlatform, false))
	p291.animations.moveBalePlacesResetOnSink = p289:getValue(p290 .. ".animations.moveBalePlaces#resetOnSink", Utils.getNoNil(v293.moveBalePlacesResetOnSink, false))
	p291.animations.moveBalePlacesMaxGrabberTime = p289:getValue(p290 .. ".animations.moveBalePlaces#maxGrabberTime", v293.moveBalePlacesMaxGrabberTime or (1 / 0))
	p291.animations.moveBalePlacesAlways = p289:getValue(p290 .. ".animations.moveBalePlaces#alwaysMove", Utils.getNoNil(v293.moveBalePlacesAlways, false))
	p291.animations.emptyRotate = p289:getValue(p290 .. ".animations.emptyRotate#name", v293.emptyRotate or "emptyRotate")
	p291.animations.emptyRotateReset = p289:getValue(p290 .. ".animations.emptyRotate#reset", Utils.getNoNil(v293.emptyRotateReset, true))
	p291.animations.frontBalePusher = p289:getValue(p290 .. ".animations#frontBalePusher", v293.frontBalePusher or "frontBalePusher")
	p291.animations.balesToOtherRow = p289:getValue(p290 .. ".animations#balesToOtherRow", v293.balesToOtherRow or "balesToOtherRow")
	p291.animations.closeGrippers = p289:getValue(p290 .. ".animations#closeGrippers", v293.closeGrippers or "closeGrippers")
	return true
end
function BaleLoader.loadBalePlacesFromXML(p294, _, p295, p296)
	local v297 = true
	p296.startBalePlace = {}
	p296.startBalePlace.bales = {}
	p296.startBalePlace.node = p294.xmlFile:getValue(p295 .. ".balePlaces#startBalePlace", nil, p294.components, p294.i3dMappings)
	if p296.startBalePlace.node == nil then
		p296.startBalePlace.numOfPlaces = 0
		v297 = false
	else
		p296.startBalePlace.numOfPlaces = getNumOfChildren(p296.startBalePlace.node)
		if p296.startBalePlace.numOfPlaces == 0 then
			p296.startBalePlace.node = nil
		else
			p296.startBalePlace.origRot = {}
			p296.startBalePlace.origTrans = {}
			for v298 = 1, p296.startBalePlace.numOfPlaces do
				local v299 = getChildAt(p296.startBalePlace.node, v298 - 1)
				p296.startBalePlace.origRot[v298] = { getRotation(v299) }
				p296.startBalePlace.origTrans[v298] = { getTranslation(v299) }
			end
		end
	end
	p296.startBalePlace.count = 0
	p296.startBalePlace.current = 1
	p296.balePlaces = {}
	local v300 = 0
	while true do
		local v301 = string.format("%s.balePlaces.balePlace(%d)", p295, v300)
		if not p294.xmlFile:hasProperty(v301) then
			break
		end
		local v302 = p294.xmlFile:getValue(v301 .. "#node", nil, p294.components, p294.i3dMappings)
		if v302 ~= nil then
			local v303 = p296.balePlaces
			table.insert(v303, {
				["node"] = v302
			})
		end
		v300 = v300 + 1
	end
	if #p296.balePlaces == 0 then
		v297 = false
	end
	return v297
end
function BaleLoader.createBaleToBaleJoints(p304, p305)
	if #p305 > 1 then
		local v306 = p304.spec_baleLoader.dynamicBaleUnloading
		local v307 = v306.rowConnectionRotLimit
		local v308 = v306.rowInterConnectionRotLimit
		for v309, v310 in ipairs(p305) do
			local v311 = v310[1].isRoundbale
			if v306.connectedRows[v309] then
				for v312 = 1, #v310 - 1 do
					if v311 then
						p304:createBaleToBaleJoint(v310[v312], v310[v312 + 1], 0, v306.heightOffset, v310[v312].width + v306.widthOffset, v307, 0, 0, v312)
					else
						p304:createBaleToBaleJoint(v310[v312], v310[v312 + 1], v310[v312].width + v306.widthOffset, v306.heightOffset, 0, 0, 0, v307 * 5, v312)
					end
				end
			end
			for _, v313 in ipairs(v306.interConnectedRowStarts) do
				if v313[1] == v309 then
					local v314 = p305[v313[2]]
					if v314 ~= nil then
						if v311 then
							p304:createBaleToBaleJoint(v310[1], v314[1], v310[1].diameter + v306.diameterOffset, v306.heightOffset, 0, v308, v308, v308, 1)
						else
							p304:createBaleToBaleJoint(v310[1], v314[1], 0, v310[1].height + 0.05, 0, v307, 0, 0, 1)
						end
					end
				end
			end
			for _, v315 in ipairs(v306.interConnectedRowEnds) do
				if v315[1] == v309 then
					local v316 = p305[v315[2]]
					if v316 ~= nil and #v310 == #v316 then
						if v311 then
							p304:createBaleToBaleJoint(v310[#v310], v316[#v316], v310[#v310].diameter + v306.diameterOffset, v306.heightOffset, 0, v308, v308, v308, #v310)
						else
							p304:createBaleToBaleJoint(v310[#v310], v316[#v316], 0, v310[#v310].height + 0.05, 0, v307, 0, 0, #v310)
						end
					end
				end
			end
		end
	end
end
function BaleLoader.createBaleToBaleJoint(p317, p318, p319, p320, p321, p322, p323, p324, p325, p326)
	local v327 = p317.spec_baleLoader
	local v328 = v327.balePlaces[p326].node
	local v329 = JointConstructor.new()
	v329:setActors(p318.nodeId, p319.nodeId)
	local v330 = createTransformGroup("jointTransform1")
	link(p318.nodeId, v330)
	setRotation(v330, localRotationToLocal(v328, p318.nodeId, 0, 0, 0))
	local v331 = createTransformGroup("jointTransform2")
	link(p319.nodeId, v331)
	setRotation(v331, localRotationToLocal(v328, p319.nodeId, 0, 0, 0))
	v329:setJointTransforms(v330, v331)
	v329:setEnableCollision(true)
	v329:setRotationLimit(0, -p323, p323)
	v329:setRotationLimit(1, -p324, p324)
	v329:setRotationLimit(2, -p325, p325)
	v329:setTranslationLimit(0, true, -p320, p320)
	v329:setTranslationLimit(1, true, -p321, p321)
	v329:setTranslationLimit(2, true, -p322, p322)
	local v332 = v329:finalize()
	local v333 = v327.baleJoints
	table.insert(v333, v332)
end
function BaleLoader.doStateChange(p334, p335, p336)
	local v337 = p334.spec_baleLoader
	if p335 == BaleLoader.CHANGE_DROP_BALES then
		local v338 = {}
		if v337.startBalePlace ~= nil then
			v337.startBalePlace.current = 1
		end
		local v339
		if v337.balePacker.node == nil then
			v339 = false
		else
			v339 = v337.balePacker.filename ~= nil
		end
		local v340 = FarmManager.SPECTATOR_FARM_ID
		local v341 = FillType.UNKNOWN
		local v342 = 0
		for _, v343 in pairs(v337.balePlaces) do
			if v343.bales ~= nil then
				for v344, v345 in pairs(v343.bales) do
					local v346 = NetworkUtil.getObject(v345)
					if v346 ~= nil then
						if v337.dynamicMount.enabled then
							p334:unmountDynamicBale(v346)
						else
							p334:unmountBale(v346)
						end
						v346:setCanBeSold(true)
						if v337.baleGrabber.balesInTrigger[v346] ~= nil then
							v337.baleGrabber.balesInTrigger[v346] = nil
						end
						if v337.dynamicBaleUnloading.enabled then
							if v338[v344] == nil then
								table.insert(v338, { v346 })
							else
								local v347 = v338[v344]
								table.insert(v347, v346)
							end
						end
						if v339 then
							v340 = v346.ownerFarmId
							v341 = v346.fillType
							v342 = v342 + v346.fillLevel
							v346:delete()
						end
					end
					v337.balesToMount[v345] = nil
				end
				v343.bales = nil
			end
		end
		if p334.isServer and v339 then
			local v348 = PackedBale.new(p334.isServer, p334.isClient)
			local v349, v350, v351 = getWorldTranslation(v337.balePacker.node)
			local v352, v353, v354 = getWorldRotation(v337.balePacker.node)
			if v348:loadFromConfigXML(v337.balePacker.filename, v349, v350, v351, v352, v353, v354) then
				v348:setFillType(v341)
				v348:setFillLevel(v342)
				v348:setOwnerFarmId(v340, true)
				v348:register()
				removeFromPhysics(v348.nodeId)
				addToPhysics(v348.nodeId)
			end
		end
		if v337.dynamicBaleUnloading.enabled then
			p334:createBaleToBaleJoints(v338)
		end
		local v355 = not v337.animations.releaseFrontPlatformFillLevelSpeed and 1 or 1 / (p334:getFillUnitFillLevel(v337.fillUnitIndex) / p334:getFillUnitCapacity(v337.fillUnitIndex))
		p334:addFillUnitFillLevel(p334:getOwnerFarmId(), v337.fillUnitIndex, (-1 / 0), p334:getFillUnitFirstSupportedFillType(v337.fillUnitIndex), ToolType.UNDEFINED, nil)
		if p334.isServer and v337.unloadingMover.trigger ~= nil then
			v337.unloadingMover.isActive = true
			v337.unloadingMover.frameDelay = 3
			for v356 = 1, #v337.unloadingMover.nodes do
				local v357 = v337.unloadingMover.nodes[v356]
				setFrictionVelocity(v357.node, v357.speed)
			end
			if p334.isClient then
				g_animationManager:startAnimations(v337.unloadingMover.animationNodes)
				g_soundManager:playSample(v337.samples.unload)
			end
			p334:raiseDirtyFlags(v337.unloadingMover.dirtyFlag)
		end
		p334:playAnimation(v337.animations.releaseFrontPlatform, v355, nil, true)
		p334:playAnimation(v337.animations.closeGrippers, -1, nil, true)
		v337.emptyState = BaleLoader.EMPTY_WAIT_TO_SINK
		return
	elseif p335 == BaleLoader.CHANGE_SINK then
		if v337.animations.emptyRotateReset then
			p334:playAnimation(v337.animations.emptyRotate, -1, nil, true)
		end
		p334:playAnimation(v337.animations.moveBalePlacesToEmpty, v337.animations.moveBalePlacesToEmptyReverseSpeed, nil, true)
		if v337.animations.moveBalePlacesResetOnSink then
			p334:playAnimation(v337.animations.moveBalePlaces, -999999, nil, true)
		end
		p334:playAnimation(v337.animations.pusherEmptyHide1, -1, nil, true)
		p334:playAnimation(v337.animations.rotatePlatformEmpty, -1, nil, true)
		if not v337.isInWorkPosition then
			p334:playAnimation(v337.animations.closeGrippers, 1, p334:getAnimationTime(v337.animations.closeGrippers), true)
		end
		v337.emptyState = BaleLoader.EMPTY_SINK
		return
	elseif p335 == BaleLoader.CHANGE_EMPTY_REDO then
		p334:playAnimation(v337.animations.emptyRotate, 1, nil, true)
		v337.emptyState = BaleLoader.EMPTY_ROTATE2
		return
	elseif p335 == BaleLoader.CHANGE_EMPTY_START then
		if GS_IS_MOBILE_VERSION then
			if p334.rootVehicle:getActionControllerDirection() > 0 then
				v337.controlledAction.parent:startActionSequence()
			end
			v337.emptyState = BaleLoader.EMPTY_TO_WORK
		else
			BaleLoader.moveToWorkPosition(p334)
			v337.emptyState = BaleLoader.EMPTY_TO_WORK
		end
	elseif p335 == BaleLoader.CHANGE_EMPTY_CANCEL then
		p334:playAnimation(v337.animations.emptyRotate, -1, nil, true)
		v337.emptyState = BaleLoader.EMPTY_CANCEL
	elseif p335 == BaleLoader.CHANGE_MOVE_TO_TRANSPORT then
		if v337.isInWorkPosition then
			v337.grabberIsMoving = true
			v337.isInWorkPosition = false
			g_animationManager:stopAnimations(v337.animationNodes)
			g_soundManager:stopSample(v337.samples.work)
			BaleLoader.moveToTransportPosition(p334)
			return
		end
	elseif p335 == BaleLoader.CHANGE_MOVE_TO_WORK then
		if not v337.isInWorkPosition then
			v337.grabberIsMoving = true
			v337.isInWorkPosition = true
			if not v337.animationNodesBlocked then
				g_animationManager:startAnimations(v337.animationNodes)
				g_soundManager:playSample(v337.samples.work)
			end
			BaleLoader.moveToWorkPosition(p334)
			return
		end
	elseif p335 == BaleLoader.CHANGE_GRAB_BALE then
		local v358 = NetworkUtil.getObject(p336)
		v337.baleGrabber.currentBale = p336
		if v358 == nil then
			v337.balesToMount[p336] = {
				["serverId"] = p336,
				["linkNode"] = v337.baleGrabber.grabNode,
				["trans"] = { 0, 0, 0 },
				["rot"] = { 0, 0, 0 }
			}
		else
			if v337.dynamicMount.enabled then
				p334:mountDynamicBale(v358, v337.baleGrabber.grabNode)
			else
				p334:mountBale(v358, p334, v337.baleGrabber.grabNode, 0, 0, 0, 0, 0, 0, true)
			end
			v358:setCanBeSold(false)
			local v359 = p334:getBaleTypeByBale(v358)
			if v359 ~= nil then
				p334:setBaleLoaderBaleType(v359.index)
			end
			v337.balesToMount[p336] = nil
		end
		v337.grabberMoveState = BaleLoader.GRAB_MOVE_UP
		p334:playAnimation(v337.animations.baleGrabberWorkToDrop, 1, nil, true)
		p334:addFillUnitFillLevel(p334:getOwnerFarmId(), v337.fillUnitIndex, 1, p334:getFillUnitFirstSupportedFillType(v337.fillUnitIndex), ToolType.UNDEFINED, nil)
		if p334.isClient then
			g_soundManager:playSample(v337.samples.grab)
			if v358 ~= nil then
				g_effectManager:setEffectTypeInfo(v337.grabberEffects, v358:getFillType())
				g_effectManager:startEffects(v337.grabberEffects)
				v337.grabberEffectDisableTime = g_currentMission.time + v337.grabberEffectDisableDuration
				return
			end
		end
	else
		if p335 == BaleLoader.CHANGE_GRAB_MOVE_UP then
			v337.currentBaleGrabberDropBaleAnimName = p334:getBaleGrabberDropBaleAnimName()
			p334:playAnimation(v337.currentBaleGrabberDropBaleAnimName, 1, nil, true)
			v337.grabberMoveState = BaleLoader.GRAB_DROP_BALE
			return
		end
		if p335 == BaleLoader.CHANGE_GRAB_DROP_BALE then
			if v337.startBalePlace ~= nil and (v337.startBalePlace.count < v337.startBalePlace.numOfPlaces and v337.startBalePlace.node ~= nil) then
				local v360 = getChildAt(v337.startBalePlace.node, v337.startBalePlace.count)
				local v361 = NetworkUtil.getObject(v337.baleGrabber.currentBale)
				if v361 == nil then
					v337.balesToMount[v337.baleGrabber.currentBale] = {
						["serverId"] = v337.baleGrabber.currentBale,
						["linkNode"] = v360,
						["trans"] = { 0, 0, 0 },
						["rot"] = { 0, 0, 0 }
					}
				else
					if v337.dynamicMount.enabled then
						p334:mountDynamicBale(v361, v360)
					else
						local v362, v363, v364
						if v337.keepBaleRotationDuringLoad then
							v362, v363, v364 = localRotationToLocal(v361.nodeId, v360, 0, 0, 0)
						else
							v362 = 0
							v363 = 0
							v364 = 0
						end
						p334:mountBale(v361, p334, v360, 0, 0, 0, v362, v363, v364)
					end
					v337.balesToMount[v337.baleGrabber.currentBale] = nil
				end
				v337.startBalePlace.count = v337.startBalePlace.count + 1
				local v365 = v337.startBalePlace.bales
				local v366 = v337.baleGrabber.currentBale
				table.insert(v365, v366)
				v337.baleGrabber.currentBale = nil
				p334:updateFoldingAnimation()
				if v337.startBalePlace.count < v337.startBalePlace.numOfPlaces then
					v337.frontBalePusherDirection = 1
					p334:playAnimation(v337.animations.balesToOtherRow, 1, nil, true)
					p334:playAnimation(v337.animations.frontBalePusher, 1, nil, true)
				elseif v337.startBalePlace.count == v337.startBalePlace.numOfPlaces then
					BaleLoader.rotatePlatform(p334)
				end
				if v337.animations.baleGrabberDropToWork == nil then
					p334:playAnimation(v337.currentBaleGrabberDropBaleAnimName, -v337.animations.baleGrabberDropBaleReverseSpeed, nil, true)
					p334:playAnimation(v337.animations.baleGrabberWorkToDrop, -1, nil, true)
				else
					p334:playAnimation(v337.animations.baleGrabberDropToWork, 1, 0, true)
				end
				v337.grabberMoveState = BaleLoader.GRAB_MOVE_DOWN
				return
			end
		else
			if p335 == BaleLoader.CHANGE_GRAB_MOVE_DOWN then
				v337.grabberMoveState = nil
				v337.automaticUnloadingAdditionalBalesToLoad = v337.automaticUnloadingAdditionalBalesToLoad - 1
				return
			end
			if p335 == BaleLoader.CHANGE_FRONT_PUSHER then
				if v337.frontBalePusherDirection > 0 then
					p334:playAnimation(v337.animations.frontBalePusher, -1, nil, true)
					v337.frontBalePusherDirection = -1
				else
					v337.frontBalePusherDirection = 0
				end
			end
			if p335 == BaleLoader.CHANGE_ROTATE_PLATFORM then
				if v337.startBalePlace == nil or v337.rotatePlatformDirection <= 0 then
					v337.rotatePlatformDirection = 0
					return
				end
				local v367 = v337.balePlaces[v337.startBalePlace.current]
				v337.startBalePlace.current = v337.startBalePlace.current + 1
				for v368 = 1, #v337.startBalePlace.bales do
					local v369 = getChildAt(v337.startBalePlace.node, v368 - 1)
					local v370, v371, v372 = getTranslation(v369)
					local v373, v374, v375 = getRotation(v369)
					local v376 = v337.startBalePlace.bales[v368]
					local v377 = NetworkUtil.getObject(v376)
					if v377 == nil then
						v337.balesToMount[v376] = {
							["serverId"] = v376,
							["linkNode"] = v367.node,
							["trans"] = { v370, v371, v372 },
							["rot"] = { v373, v374, v375 }
						}
					else
						if v337.keepBaleRotationDuringLoad then
							v370, v371, v372 = localToLocal(v377.nodeId, v367.node, 0, 0, 0)
							v373, v374, v375 = localRotationToLocal(v377.nodeId, v367.node, 0, 0, 0)
						end
						if v337.dynamicMount.enabled then
							p334:mountDynamicBale(v377, v367.node)
						else
							p334:mountBale(v377, p334, v367.node, v370, v371, v372, v373, v374, v375)
						end
						v337.balesToMount[v376] = nil
					end
				end
				v367.bales = v337.startBalePlace.bales
				v337.startBalePlace.bales = {}
				v337.startBalePlace.count = 0
				p334:updateFoldingAnimation()
				for v378 = 1, v337.startBalePlace.numOfPlaces do
					local v379 = getChildAt(v337.startBalePlace.node, v378 - 1)
					local v380 = setRotation
					local v381 = v337.startBalePlace.origRot[v378]
					v380(v379, unpack(v381))
					local v382 = setTranslation
					local v383 = v337.startBalePlace.origTrans[v378]
					v382(v379, unpack(v383))
				end
				if v337.emptyState ~= BaleLoader.EMPTY_NONE then
					v337.rotatePlatformDirection = 0
					return
				end
				if p334:getAnimationTime(v337.animations.baleGrabberWorkToDrop) >= v337.animations.moveBalePlacesMaxGrabberTime and v337.animations.moveBalePlacesMaxGrabberTime ~= (1 / 0) then
					v337.rotatePlatformDirection = -1
					v337.moveBalePlacesDelayedMovement = true
					return
				end
				v337.rotatePlatformDirection = -1
				p334:playAnimation(v337.animations.rotatePlatformBack, -1, nil, true)
				if v337.animations.moveBalePlacesAfterRotatePlatform and (v337.startBalePlace.current <= #v337.balePlaces or v337.animations.moveBalePlacesAlways) then
					p334:playAnimation(v337.animations.moveBalePlaces, 1, (v337.startBalePlace.current - 1) / #v337.balePlaces, true)
					p334:setAnimationStopTime(v337.animations.moveBalePlaces, v337.startBalePlace.current / #v337.balePlaces)
					p334:playAnimation(v337.animations.moveBalePlacesExtrasOnce, 1, nil, true)
					return
				end
			else
				if p335 == BaleLoader.CHANGE_EMPTY_ROTATE_PLATFORM then
					v337.emptyState = BaleLoader.EMPTY_ROTATE_PLATFORM
					if v337.startBalePlace == nil or v337.startBalePlace.count ~= 0 then
						BaleLoader.rotatePlatform(p334)
					else
						p334:playAnimation(v337.animations.rotatePlatformEmpty, 1, nil, true)
					end
				end
				if p335 == BaleLoader.CHANGE_EMPTY_ROTATE1 then
					p334:playAnimation(v337.animations.emptyRotate, 1, nil, true)
					p334:setAnimationStopTime(v337.animations.emptyRotate, 0.2)
					local v384 = p334:getRealAnimationTime(v337.animations.moveBalePlaces)
					local v385 = v337.animations.moveBalePlacesToEmptySpeed
					if v337.animations.pusherPushBalesOnEmpty and v337.startBalePlace ~= nil then
						local v386 = v337.startBalePlace.current
						if #v337.startBalePlace.bales == 0 then
							v386 = v386 - 1
						end
						local v387 = p334:getAnimationDuration(v337.animations.moveBalePlacesToEmpty)
						local v388 = v387 <= 0 and 1 or 1 - v384 / v387
						local v389 = 1 - v386 / #v337.balePlaces
						v385 = v337.animations.moveBalePlacesToEmptySpeed * (v389 / math.max(v388, 0.0001))
						if v385 > 0 then
							p334:playAnimation(v337.animations.pusherMoveToEmpty, v385, 0, true)
							p334:setAnimationStopTime(v337.animations.pusherMoveToEmpty, v389)
						end
					else
						local v390 = p334:getAnimationDuration(v337.animations.pusherMoveToEmpty)
						local v391 = v390 <= 0 and 0 or v384 / v390
						p334:playAnimation(v337.animations.pusherMoveToEmpty, v337.animations.moveBalePlacesToEmptySpeed, v391, true)
					end
					local v392 = v337.balePlaces[v337.startBalePlace.current - 1]
					local v393 = v392 == nil or #v392.bales >= v337.startBalePlace.numOfPlaces
					if v337.animations.moveBalePlacesToEmptyPushOffset > 0 and v393 then
						if v385 > 0 then
							v337.animations.moveBalePlacesToEmptyPushOffsetDelay = v337.animations.moveBalePlacesToEmptyPushOffset * p334:getAnimationDuration(v337.animations.pusherMoveToEmpty) / v385
							v337.animations.moveBalePlacesToEmptyPushOffsetTime = v337.animations.moveBalePlacesToEmptyPushOffsetDelay
						end
					else
						local v394 = p334:getAnimationDuration(v337.animations.moveBalePlacesToEmpty)
						local v395 = v394 <= 0 and 0 or v384 / v394
						p334:playAnimation(v337.animations.moveBalePlacesToEmpty, v337.animations.moveBalePlacesToEmptySpeed, v395, true)
					end
					v337.emptyState = BaleLoader.EMPTY_ROTATE1
					if p334.isClient then
						g_soundManager:playSample(v337.samples.emptyRotate)
						return
					end
				else
					if p335 == BaleLoader.CHANGE_EMPTY_CLOSE_GRIPPERS then
						p334:playAnimation(v337.animations.closeGrippers, 1, nil, true)
						v337.emptyState = BaleLoader.EMPTY_CLOSE_GRIPPERS
						return
					end
					if p335 == BaleLoader.CHANGE_EMPTY_HIDE_PUSHER1 then
						p334:playAnimation(v337.animations.pusherEmptyHide1, 1, nil, true)
						v337.emptyState = BaleLoader.EMPTY_HIDE_PUSHER1
						return
					end
					if p335 == BaleLoader.CHANGE_EMPTY_HIDE_PUSHER2 then
						if v337.animations.pusherHideOnEmpty then
							p334:playAnimation(v337.animations.pusherMoveToEmpty, -2, nil, true)
							v337.emptyState = BaleLoader.EMPTY_HIDE_PUSHER2
							return
						end
						if p334.isServer then
							g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_EMPTY_ROTATE2), true, nil, p334)
							return
						end
					else
						if p335 == BaleLoader.CHANGE_EMPTY_ROTATE2 then
							p334:playAnimation(v337.animations.emptyRotate, 1, p334:getAnimationTime(v337.animations.emptyRotate), true)
							v337.emptyState = BaleLoader.EMPTY_ROTATE2
							return
						end
						if p335 == BaleLoader.CHANGE_EMPTY_WAIT_TO_DROP then
							v337.emptyState = BaleLoader.EMPTY_WAIT_TO_DROP
							return
						end
						if p335 == BaleLoader.CHANGE_EMPTY_STATE_NIL then
							v337.emptyState = BaleLoader.EMPTY_NONE
							if GS_IS_MOBILE_VERSION then
								if p334.rootVehicle:getActionControllerDirection() < 0 then
									v337.controlledAction.parent:startActionSequence()
								end
							elseif v337.transportPositionAfterUnloading then
								BaleLoader.moveToTransportPosition(p334)
								if p334.isServer then
									g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_MOVE_TO_TRANSPORT), true, nil, p334)
								end
							end
							v337.automaticUnloadingInProgress = false
							return
						end
						if p335 == BaleLoader.CHANGE_EMPTY_WAIT_TO_REDO then
							v337.emptyState = BaleLoader.EMPTY_WAIT_TO_REDO
							return
						end
						if p335 == BaleLoader.CHANGE_BUTTON_EMPTY then
							local v396 = p334.isServer
							assert(v396)
							if v337.emptyState == BaleLoader.EMPTY_NONE then
								if BaleLoader.getAllowsStartUnloading(p334) then
									g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_EMPTY_START), true, nil, p334)
									return
								end
							else
								if v337.emptyState == BaleLoader.EMPTY_WAIT_TO_DROP then
									g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_DROP_BALES), true, nil, p334)
									return
								end
								if v337.emptyState == BaleLoader.EMPTY_WAIT_TO_SINK then
									if not v337.unloadingMover.isActive then
										g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_SINK), true, nil, p334)
										return
									end
								elseif v337.emptyState == BaleLoader.EMPTY_WAIT_TO_REDO then
									g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_EMPTY_REDO), true, nil, p334)
									return
								end
							end
						elseif p335 == BaleLoader.CHANGE_BUTTON_EMPTY_ABORT then
							local v397 = p334.isServer
							assert(v397)
							if v337.emptyState ~= BaleLoader.EMPTY_NONE and v337.emptyState == BaleLoader.EMPTY_WAIT_TO_DROP then
								g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_EMPTY_CANCEL), true, nil, p334)
								return
							end
						elseif p335 == BaleLoader.CHANGE_BUTTON_WORK_TRANSPORT then
							local v398 = p334.isServer
							assert(v398)
							if v337.emptyState == BaleLoader.EMPTY_NONE and v337.grabberMoveState == nil then
								if v337.isInWorkPosition then
									g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_MOVE_TO_TRANSPORT), true, nil, p334)
									return
								end
								g_server:broadcastEvent(BaleLoaderStateEvent.new(p334, BaleLoader.CHANGE_MOVE_TO_WORK), true, nil, p334)
							end
						end
					end
				end
			end
		end
	end
end
function BaleLoader.getAllowsStartUnloading(p399)
	local v400 = p399.spec_baleLoader
	if p399:getFillUnitFillLevel(v400.fillUnitIndex) == 0 then
		return false
	elseif v400.rotatePlatformDirection == 0 then
		if v400.frontBalePusherDirection == 0 then
			if v400.grabberIsMoving or v400.grabberMoveState ~= nil then
				return false
			else
				return v400.emptyState == BaleLoader.EMPTY_NONE
			end
		else
			return false
		end
	else
		return false
	end
end
function BaleLoader.rotatePlatform(p401)
	local v402 = p401.spec_baleLoader
	v402.rotatePlatformDirection = 1
	p401:playAnimation(v402.animations.rotatePlatform, 1, nil, true)
	if v402.startBalePlace.current > 1 and not v402.animations.moveBalePlacesAfterRotatePlatform or v402.animations.moveBalePlacesAlways then
		p401:playAnimation(v402.animations.moveBalePlaces, 1, (v402.startBalePlace.current - 1) / #v402.balePlaces, true)
		p401:setAnimationStopTime(v402.animations.moveBalePlaces, v402.startBalePlace.current / #v402.balePlaces)
		p401:playAnimation(v402.animations.moveBalePlacesExtrasOnce, 1, nil, true)
	end
end
function BaleLoader.moveToWorkPosition(p403, p404)
	local v405 = p403.spec_baleLoader
	p403:playBaleLoaderFoldingAnimation(p404 and 9999 or 1)
	local v406
	if p403:getAnimationTime(v405.animations.closeGrippers) == 0 then
		v406 = nil
	else
		v406 = p403:getAnimationTime(v405.animations.closeGrippers)
	end
	p403:playAnimation(v405.animations.closeGrippers, -1, v406, true)
end
function BaleLoader.moveToTransportPosition(p407)
	p407:playBaleLoaderFoldingAnimation(-1)
	local v408 = p407.spec_baleLoader
	local v409 = v408.animations.closeGrippers
	local v410 = p407:getAnimationTime(v408.animations.closeGrippers)
	p407:playAnimation(v409, 1, math.clamp(v410, 0, 1), true)
end
function BaleLoader.getBaleGrabberDropBaleAnimName(p411)
	local v412 = p411.spec_baleLoader
	local v413 = string.format("%s%d", v412.animations.baleGrabberDropBale, v412.startBalePlace.count)
	if p411:getAnimationExists(v413) then
		return v413
	else
		return v412.animations.baleGrabberDropBale
	end
end
function BaleLoader.getIsBaleGrabbingAllowed(p414)
	local v415 = p414.spec_baleLoader
	if v415.isInWorkPosition then
		if v415.grabberIsMoving or v415.grabberMoveState ~= nil then
			return false
		elseif v415.startBalePlace.count >= v415.startBalePlace.numOfPlaces then
			return false
		elseif v415.frontBalePusherDirection == 0 then
			if v415.animations.rotatePlatformAllowPickup or v415.rotatePlatformDirection == 0 then
				if v415.animations.moveBalePlacesAlways and p414:getIsAnimationPlaying(v415.animations.moveBalePlaces) then
					return false
				elseif v415.emptyState == BaleLoader.EMPTY_NONE then
					return p414:getFillUnitFreeCapacity(v415.fillUnitIndex) ~= 0
				else
					return false
				end
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end
end
function BaleLoader.pickupBale(p416, p417, p418)
	p416.spec_baleLoader.lastPickupTime = g_time
	p416:setBaleLoaderBaleType(p418.index)
	g_server:broadcastEvent(BaleLoaderStateEvent.new(p416, BaleLoader.CHANGE_GRAB_BALE, NetworkUtil.getObjectId(p417)), true, nil, p416)
end
function BaleLoader.setBaleLoaderBaleType(p419, p420, p421)
	local v422 = p419.spec_baleLoader
	local v423 = v422.baleTypes[p420] or v422.baleTypes[1]
	if v423 ~= v422.currentBaleType then
		v422.currentBaleType = v423
		v422.animations = v423.animations
		if not v422.useSharedBalePlaces then
			if v423.startBalePlace.node == nil then
				v422.startBalePlace = v422.defaultBalePlace.startBalePlace
			else
				v422.startBalePlace = v423.startBalePlace
			end
			if #v423.balePlaces > 0 then
				v422.balePlaces = v423.balePlaces
			else
				v422.balePlaces = v422.defaultBalePlace.balePlaces
			end
		end
		v422.fillUnitIndex = v423.fillUnitIndex
		for v424 = 1, #v422.baleTypes do
			local v425 = v422.baleTypes[v424]
			local v426 = p419:getFillUnitByIndex(v425.fillUnitIndex)
			if v426.showOnHudOrig == nil then
				v426.showOnHudOrig = v426.showOnHud
			end
			if v426.showOnHudOrig then
				v426.showOnHud = v425.fillUnitIndex == v422.fillUnitIndex
			end
		end
		ObjectChangeUtil.setObjectChanges(v423.changeObjects, true, p419, p419.setMovingToolDirty, p421)
	end
end
function BaleLoader.getBaleTypeByBale(p427, p428)
	local v429 = p427.spec_baleLoader
	local v430 = nil
	for _, v431 in pairs(v429.baleTypes) do
		local v432 = v431.dimensions
		if v432.isRoundbale then
			if v432.isRoundbale and (p428.width >= v432.minWidth and (p428.width <= v432.maxWidth and (p428.diameter >= v432.minDiameter and p428.diameter <= v432.maxDiameter))) then
				return v431
			end
		elseif not v432.isRoundbale and (p428.width >= v432.minWidth and (p428.width <= v432.maxWidth and (p428.height >= v432.minHeight and (p428.height <= v432.maxHeight and (p428.length >= v432.minLength and p428.length <= v432.maxLength))))) then
			return v431
		end
	end
	return v430
end
function BaleLoader.baleGrabberTriggerCallback(p433, _, p434, p435, p436, _, _)
	if p434 ~= 0 then
		local v437 = getRigidBodyType(p434)
		if p433.isServer and v437 == RigidBodyType.DYNAMIC or not p433.isServer and v437 == RigidBodyType.KINEMATIC then
			local v438 = g_currentMission:getNodeObject(p434)
			if v438 ~= nil and v438:isa(Bale) then
				local v439 = p433.spec_baleLoader
				if p435 then
					v439.baleGrabber.balesInTrigger[v438] = Utils.getNoNil(v439.baleGrabber.balesInTrigger[v438], 0) + 1
					return
				end
				if p436 and v439.baleGrabber.balesInTrigger[v438] ~= nil then
					local v440 = v439.baleGrabber.balesInTrigger
					local v441 = v439.baleGrabber.balesInTrigger[v438] - 1
					v440[v438] = math.max(0, v441)
					if v439.baleGrabber.balesInTrigger[v438] == 0 then
						v439.baleGrabber.balesInTrigger[v438] = nil
					end
				end
			end
		end
	end
end
function BaleLoader.baleLoaderMoveTriggerCallback(p442, _, p443, p444, p445, _, _)
	if p443 ~= 0 and getRigidBodyType(p443) == RigidBodyType.DYNAMIC then
		local v446 = g_currentMission:getNodeObject(p443)
		if v446 ~= nil and v446:isa(Bale) then
			local v447 = p442.spec_baleLoader
			if p444 then
				v447.unloadingMover.balesInTrigger[v446] = Utils.getNoNil(v447.unloadingMover.balesInTrigger[v446], 0) + 1
				if v447.unloadingMover.balesInTrigger[v446] == 1 then
					v446:addDeleteListener(p442, "onBaleMoverBaleRemoved")
					return
				end
			elseif p445 and v447.unloadingMover.balesInTrigger[v446] ~= nil then
				local v448 = v447.unloadingMover.balesInTrigger
				local v449 = v447.unloadingMover.balesInTrigger[v446] - 1
				v448[v446] = math.max(0, v449)
				if v447.unloadingMover.balesInTrigger[v446] == 0 then
					v447.unloadingMover.balesInTrigger[v446] = nil
					v446:removeDeleteListener(p442, "onBaleMoverBaleRemoved")
				end
			end
		end
	end
end
function BaleLoader.mountDynamicBale(p450, p451, p452)
	local v453 = p450.spec_baleLoader
	if p450.isServer then
		if p451.dynamicMountJointIndex == nil or p451.baleLoaderDynamicJointNode == nil then
			local v454 = createTransformGroup("baleJoint")
			link(p452, v454)
			p451.baleLoaderDynamicJointNode = v454
			if v453.dynamicMount.jointInterpolation then
				setWorldTranslation(v454, getWorldTranslation(p451.nodeId))
				setWorldRotation(v454, getWorldRotation(p451.nodeId))
			else
				local v455, v456, v457 = getWorldTranslation(v454)
				local v458, v459, v460, v461 = getWorldQuaternion(v454)
				removeFromPhysics(p451.nodeId)
				p451:setWorldPositionQuaternion(v455, v456, v457, v458, v459, v460, v461, true)
				addToPhysics(p451.nodeId)
				link(v454, p451.meshNode)
			end
			p451:mountDynamic(p450, p450:getParentComponent(p452), v454, DynamicMountUtil.TYPE_FIX_ATTACH, 0, false)
			p451:setNeedsSaving(false)
			if v453.dynamicMount.minTransLimits ~= nil and v453.dynamicMount.maxTransLimits ~= nil then
				for v462 = 1, 3 do
					local v463 = v453.dynamicMount.minTransLimits[v462] ~= 0 and true or v453.dynamicMount.maxTransLimits[v462] ~= 0
					if v463 then
						setJointTranslationLimit(p451.dynamicMountJointIndex, v462 - 1, v463, v453.dynamicMount.minTransLimits[v462], v453.dynamicMount.maxTransLimits[v462])
					end
				end
			end
			if v453.dynamicMount.jointInterpolation then
				local v464 = v453.dynamicMount.baleJointsToUpdate
				local v465 = {
					["node"] = p451.baleLoaderDynamicJointNode,
					["time"] = 0
				}
				table.insert(v464, v465)
			end
			v453.dynamicMount.baleMassDirty = true
		else
			local v466, v467, v468 = getWorldTranslation(p451.baleLoaderDynamicJointNode)
			local v469, v470, v471 = getWorldRotation(p451.baleLoaderDynamicJointNode)
			link(p452, p451.baleLoaderDynamicJointNode)
			setWorldTranslation(p451.baleLoaderDynamicJointNode, v466, v467, v468)
			setWorldRotation(p451.baleLoaderDynamicJointNode, v469, v470, v471)
			setJointFrame(p451.dynamicMountJointIndex, 0, p451.baleLoaderDynamicJointNode)
			if v453.dynamicMount.jointInterpolation then
				local v472 = v453.dynamicMount.baleJointsToUpdate
				local v473 = {
					["node"] = p451.baleLoaderDynamicJointNode,
					["time"] = 0
				}
				table.insert(v472, v473)
				return
			end
		end
	end
end
function BaleLoader.unmountDynamicBale(p474, p475)
	if p474.isServer then
		local v476 = p474.spec_baleLoader
		p475:unmountDynamic()
		p475:setNeedsSaving(true)
		if p475.baleLoaderDynamicJointNode ~= nil then
			delete(p475.baleLoaderDynamicJointNode)
			p475.baleLoaderDynamicJointNode = nil
		end
		v476.dynamicMount.baleJointsToUpdate = {}
		if p475.backupMass ~= nil then
			setMass(p475.nodeId, p475.backupMass)
			p475.backupMass = nil
		end
	end
end
function BaleLoader.mountBale(p477, p478, p479, p480, p481, p482, p483, p484, p485, p486, p487)
	local v488 = p477.spec_baleLoader
	if v488.unloadingMover.balesInTrigger[p478] ~= nil then
		v488.unloadingMover.balesInTrigger[p478] = nil
	end
	if p487 == true or not v488.allowKinematicMounting then
		p478:mount(p479, p480, p481, p482, p483, p484, p485, p486)
		p478:setNeedsSaving(false)
	else
		p478:mountKinematic(p479, p480, p481, p482, p483, p484, p485, p486)
		p478:setNeedsSaving(false)
		if not table.hasElement(v488.kinematicMountedBales, p478) then
			p477:setBalePairCollision(p478, false)
			table.addElement(v488.kinematicMountedBales, p478)
		end
	end
end
function BaleLoader.unmountBale(p489, p490)
	local v491 = p489.spec_baleLoader
	if p490.dynamicMountType == MountableObject.MOUNT_TYPE_DEFAULT then
		p490:unmount()
		p490:setNeedsSaving(true)
	elseif p490.dynamicMountType == MountableObject.MOUNT_TYPE_KINEMATIC then
		p490:unmountKinematic()
		p490:setNeedsSaving(true)
		table.removeElement(v491.kinematicMountedBales, p490)
		p489:setBalePairCollision(p490, true)
	end
end
function BaleLoader.setBalePairCollision(p492, p493, p494)
	local v495 = p492.spec_baleLoader
	for v496 = 1, #p492.components do
		setPairCollision(p492.components[v496].node, p493.nodeId, p494)
	end
	for v497 = 1, #v495.kinematicMountedBales do
		local v498 = v495.kinematicMountedBales[v497]
		setPairCollision(v498.nodeId, p493.nodeId, p494)
	end
end
function BaleLoader.getLoadedBales(p499)
	local v500 = p499.spec_baleLoader
	local v501 = {}
	for _, v502 in pairs(v500.balePlaces) do
		if v502.bales ~= nil then
			for _, v503 in pairs(v502.bales) do
				local v504 = NetworkUtil.getObject(v503)
				if v504 ~= nil then
					table.insert(v501, v504)
				end
			end
		end
	end
	for _, v505 in ipairs(v500.startBalePlace.bales) do
		local v506 = NetworkUtil.getObject(v505)
		if v506 ~= nil then
			table.insert(v501, v506)
		end
	end
	return v501
end
function BaleLoader.startAutomaticBaleUnloading(p507)
	local v508 = p507.spec_baleLoader
	v508.automaticUnloadingInProgress = true
	if v508.automaticUnloadingAdditionalBalesToLoad == 0 then
		v508.automaticUnloadingAdditionalBalesToLoad = -1
	end
	g_client:getServerConnection():sendEvent(BaleLoaderStateEvent.new(p507, BaleLoader.CHANGE_BUTTON_EMPTY))
end
function BaleLoader.getIsAutomaticBaleUnloadingInProgress(p509)
	return p509.spec_baleLoader.automaticUnloadingInProgress
end
function BaleLoader.getIsAutomaticBaleUnloadingAllowed(p510)
	if p510:getIsAutomaticBaleUnloadingInProgress() then
		return false
	elseif p510.spec_baleLoader.lastPickupTime + p510.spec_baleLoader.lastPickupAutomatedUnloadingDelayTime > g_time then
		return false
	else
		return BaleLoader.getAllowsStartUnloading(p510) and true or false
	end
end
function BaleLoader.playBaleLoaderFoldingAnimation(p511, p512)
	local v513 = p511:getCurrentFoldingAnimation()
	local v514 = p511:getAnimationTime(v513)
	p511:playAnimation(v513, p512, math.clamp(v514, 0, 1), true)
end
function BaleLoader.getIsBaleLoaderFoldingPlaying(p515)
	return p515:getIsAnimationPlaying(p515:getCurrentFoldingAnimation())
end
function BaleLoader.getCurrentFoldingAnimation(p516)
	local v517 = p516.spec_baleLoader
	if v517.hasMultipleFoldingAnimations then
		return v517.lastFoldingAnimation
	else
		return v517.animations.baleGrabberTransportToWork
	end
end
function BaleLoader.updateFoldingAnimation(p518)
	local v519 = p518.spec_baleLoader
	local v520 = v519.animations.baleGrabberTransportToWork
	local v521 = MathUtil.round(p518:getFillUnitFillLevel(v519.fillUnitIndex))
	local v522 = #v519.startBalePlace.bales
	local v523 = v519.currentBaleType == nil and 1 or v519.currentBaleType.index
	for _, v524 in ipairs(v519.foldingAnimations) do
		if (v524.baleTypeIndex == 0 or v524.baleTypeIndex == v523) and (v524.minFillLevel <= v521 and (v521 <= v524.maxFillLevel and (v524.minBalePlace <= v522 and v522 <= v524.maxBalePlace))) then
			v520 = v524.name
			break
		end
	end
	if v520 ~= v519.lastFoldingAnimation then
		if v519.lastFoldingAnimation ~= nil then
			p518:setAnimationTime(v520, p518:getAnimationTime(v519.lastFoldingAnimation), false)
		end
		v519.lastFoldingAnimation = v520
	end
end
function BaleLoader.onBaleMoverBaleRemoved(p525, p526)
	p525.spec_baleLoader.unloadingMover.balesInTrigger[p526] = nil
end
function BaleLoader.onBaleUnloadTriggerDeleted(p527, p528)
	local v529 = p527.spec_baleLoader
	if v529.baleUnloadTriggers[p528] ~= nil then
		v529.baleUnloadTriggers[p528] = nil
	end
end
function BaleLoader.addBaleUnloadTrigger(p530, p531)
	local v532 = p530.spec_baleLoader
	v532.baleUnloadTriggers[p531] = (v532.baleUnloadTriggers[p531] or 0) + 1
	p531:addDeleteListener(p530, BaleLoader.onBaleUnloadTriggerDeleted)
	p530:raiseActive()
end
function BaleLoader.removeBaleUnloadTrigger(p533, p534)
	local v535 = p533.spec_baleLoader
	v535.baleUnloadTriggers[p534] = (v535.baleUnloadTriggers[p534] or 0) - 1
	if v535.baleUnloadTriggers[p534] <= 0 then
		v535.baleUnloadTriggers[p534] = nil
		p534:removeDeleteListener(p533, BaleLoader.onBaleUnloadTriggerDeleted)
	end
end
function BaleLoader.getCanBeSelected(_, _)
	return true
end
function BaleLoader.getAllowDynamicMountFillLevelInfo(p536, p537)
	if p536.spec_baleLoader.dynamicMount.enabled then
		return false
	else
		return p537(p536)
	end
end
function BaleLoader.getAreControlledActionsAllowed(p538, p539)
	if p538:getIsAutomaticBaleUnloadingInProgress() then
		return false
	else
		return p539(p538)
	end
end
function BaleLoader.getIsAIReadyToDrive(p540, p541)
	local v542 = p540.spec_baleLoader
	if v542.isInWorkPosition or v542.grabberIsMoving then
		return false
	else
		return p541(p540)
	end
end
function BaleLoader.getIsAIPreparingToDrive(p543, p544)
	return p543.spec_baleLoader.grabberIsMoving and true or p544(p543)
end
function BaleLoader.getIsFoldAllowed(p545, p546, p547, p548)
	if p545:getFillUnitFillLevel(p545.spec_baleLoader.fillUnitIndex) > 0 then
		return false
	else
		return p546(p545, p547, p548)
	end
end
function BaleLoader.getDoConsumePtoPower(p549, p550)
	local v551 = p549.spec_baleLoader
	return v551.consumePtoPower and (v551.isInWorkPosition or v551.grabberIsMoving) and true or p550(p549)
end
function BaleLoader.getConsumingLoad(p552, p553)
	local v554, v555 = p553(p552)
	local v556 = p552.spec_baleLoader
	return v554 + (v556.consumePtoPower and (v556.isInWorkPosition or v556.grabberIsMoving) and 1 or 0), v555 + 1
end
function BaleLoader.getIsPowerTakeOffActive(p557, p558)
	local v559 = p557.spec_baleLoader
	return v559.consumePtoPower and (v559.isInWorkPosition or v559.grabberIsMoving) and true or p558(p557)
end
function BaleLoader.addToPhysics(p560, p561)
	if not p561(p560) then
		return false
	end
	local v562 = p560.spec_baleLoader
	for _, v563 in pairs(v562.balePlaces) do
		if v563.bales ~= nil then
			for _, v564 in pairs(v563.bales) do
				local v565 = NetworkUtil.getObject(v564)
				if v565 ~= nil then
					v565:addToPhysics()
					if v562.dynamicMount.enabled then
						p560:mountDynamicBale(v565, v563.node)
					else
						local v566, v567, v568 = localToLocal(v565.nodeId, v563.node, 0, 0, 0)
						local v569, v570, v571 = localRotationToLocal(v565.nodeId, v563.node, 0, 0, 0)
						p560:mountBale(v565, p560, v563.node, v566, v567, v568, v569, v570, v571)
					end
				end
			end
		end
	end
	for _, v572 in ipairs(v562.startBalePlace.bales) do
		local v573 = NetworkUtil.getObject(v572)
		if v573 ~= nil then
			v573:addToPhysics()
			local v574 = getChildAt(v562.startBalePlace.node, v562.startBalePlace.count)
			if v562.dynamicMount.enabled then
				p560:mountDynamicBale(v573, v574)
			else
				local v575, v576, v577 = localToLocal(v573.nodeId, v574, 0, 0, 0)
				local v578, v579, v580 = localRotationToLocal(v573.nodeId, v574, 0, 0, 0)
				p560:mountBale(v573, p560, v574, v575, v576, v577, v578, v579, v580)
			end
		end
	end
	return true
end
function BaleLoader.removeFromPhysics(p581, p582)
	if not p582(p581) then
		return false
	end
	local v583 = p581.spec_baleLoader
	for _, v584 in pairs(v583.balePlaces) do
		if v584.bales ~= nil then
			for _, v585 in pairs(v584.bales) do
				local v586 = NetworkUtil.getObject(v585)
				if v586 ~= nil then
					if v583.dynamicMount.enabled then
						p581:unmountDynamicBale(v586)
					else
						p581:unmountBale(v586)
					end
					v586:removeFromPhysics()
				end
			end
		end
	end
	for _, v587 in ipairs(v583.startBalePlace.bales) do
		local v588 = NetworkUtil.getObject(v587)
		if v588 ~= nil then
			if v583.dynamicMount.enabled then
				p581:unmountDynamicBale(v588)
			else
				p581:unmountBale(v588)
			end
			v588:removeFromPhysics()
		end
	end
	return true
end
function BaleLoader.onRegisterActionEvents(p589, _, p590)
	if p589.isClient then
		local v591 = p589.spec_baleLoader
		p589:clearActionEventsTable(v591.actionEvents)
		if p590 then
			if not v591.useFoldingState then
				local _, v592 = p589:addPoweredActionEvent(v591.actionEvents, InputAction.IMPLEMENT_EXTRA, p589, BaleLoader.actionEventWorkTransport, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v592, GS_PRIO_NORMAL)
			end
			if not v591.fullAutomaticUnloading then
				local _, v593 = p589:addPoweredActionEvent(v591.actionEvents, InputAction.IMPLEMENT_EXTRA3, p589, BaleLoader.actionEventEmpty, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v593, GS_PRIO_NORMAL)
				local _, v594 = p589:addPoweredActionEvent(v591.actionEvents, InputAction.IMPLEMENT_EXTRA2, p589, BaleLoader.actionEventAbortEmpty, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v594, GS_PRIO_NORMAL)
				g_inputBinding:setActionEventText(v594, v591.texts.abortUnloading)
			end
		end
	end
end
function BaleLoader.actionEventEmpty(p595, _, _, _, _)
	local v596 = p595.spec_baleLoader
	if p595:getFillUnitFillLevel(v596.fillUnitIndex) >= v596.minUnloadingFillLevel or v596.emptyState ~= BaleLoader.EMPTY_NONE then
		g_client:getServerConnection():sendEvent(BaleLoaderStateEvent.new(p595, BaleLoader.CHANGE_BUTTON_EMPTY))
	else
		g_currentMission:showBlinkingWarning(v596.texts.minUnloadingFillLevelWarning, 2500)
	end
end
function BaleLoader.actionEventAbortEmpty(p597, _, _, _, _)
	g_client:getServerConnection():sendEvent(BaleLoaderStateEvent.new(p597, BaleLoader.CHANGE_BUTTON_EMPTY_ABORT))
end
function BaleLoader.actionEventWorkTransport(p598, _, _, _, _)
	g_client:getServerConnection():sendEvent(BaleLoaderStateEvent.new(p598, BaleLoader.CHANGE_BUTTON_WORK_TRANSPORT))
end
function BaleLoader.loadSpecValueBaleSize(p_u_599, _, _, p_u_600)
	local v_u_601 = {
		["minDiameter"] = (1 / 0),
		["maxDiameter"] = (-1 / 0),
		["minLength"] = (1 / 0),
		["maxLength"] = (-1 / 0)
	}
	p_u_599:iterate(p_u_599:getRootName() .. ".baleLoader.baleTypes.baleType", function(_, p602)
		-- upvalues: (copy) p_u_599, (copy) p_u_600, (copy) v_u_601
		if ((p_u_599:getValue(p602 .. "#diameter") ~= nil or p_u_599:getValue(p602 .. "#minDiameter") ~= nil) and true or p_u_599:getValue(p602 .. "#maxDiameter") ~= nil) == p_u_600 then
			local v603 = MathUtil.round(p_u_599:getValue(p602 .. "#diameter"), 2)
			local v604 = MathUtil.round(p_u_599:getValue(p602 .. "#minDiameter"), 2)
			local v605 = MathUtil.round(p_u_599:getValue(p602 .. "#maxDiameter"), 2)
			local v606 = v_u_601
			local v607 = v_u_601.minDiameter
			local v608 = v603 or v_u_601.minDiameter
			local v609 = v604 or v_u_601.minDiameter
			local v610 = v605 or v_u_601.minDiameter
			v606.minDiameter = math.min(v607, v608, v609, v610)
			local v611 = v_u_601
			local v612 = v_u_601.maxDiameter
			local v613 = v603 or v_u_601.maxDiameter
			local v614 = v604 or v_u_601.maxDiameter
			local v615 = v605 or v_u_601.maxDiameter
			v611.maxDiameter = math.max(v612, v613, v614, v615)
			local v616 = MathUtil.round(p_u_599:getValue(p602 .. "#length"), 2)
			local v617 = MathUtil.round(p_u_599:getValue(p602 .. "#minLength"), 2)
			local v618 = MathUtil.round(p_u_599:getValue(p602 .. "#maxLength"), 2)
			local v619 = v_u_601
			local v620 = v_u_601.minLength
			local v621 = v616 or v_u_601.minLength
			local v622 = v617 or v_u_601.minLength
			local v623 = v618 or v_u_601.minLength
			v619.minLength = math.min(v620, v621, v622, v623)
			local v624 = v_u_601
			local v625 = v_u_601.maxLength
			local v626 = v616 or v_u_601.maxLength
			local v627 = v617 or v_u_601.maxLength
			local v628 = v618 or v_u_601.maxLength
			v624.maxLength = math.max(v625, v626, v627, v628)
		end
	end)
	if v_u_601.minDiameter == (1 / 0) and v_u_601.minLength == (1 / 0) then
		return nil
	else
		return v_u_601
	end
end
function BaleLoader.getSpecValueBaleSize(p629, _, _, _, p630, p631, p632)
	local v633 = p632 and p629.specs.baleLoaderBaleSizeRound or p629.specs.baleLoaderBaleSizeSquare
	if v633 == nil then
		if p630 and p631 then
			return 0, 0, ""
		elseif p630 then
			return 0, ""
		else
			return ""
		end
	else
		local v634 = p632 and v633.minDiameter or v633.minLength
		local v635 = p632 and v633.maxDiameter or v633.maxLength
		if p630 == nil or not p630 then
			local v636 = g_i18n:getText("unit_cmShort")
			if v635 == v634 then
				return string.format("%d%s", v634 * 100, v636)
			else
				return string.format("%d%s-%d%s", v634 * 100, v636, v635 * 100, v636)
			end
		elseif p631 == true and v635 ~= v634 then
			return v634 * 100, v635 * 100, g_i18n:getText("unit_cmShort")
		else
			return v634 * 100, g_i18n:getText("unit_cmShort")
		end
	end
end
function BaleLoader.loadSpecValueBaleSizeRound(p637, p638, p639)
	return BaleLoader.loadSpecValueBaleSize(p637, p638, p639, true)
end
function BaleLoader.loadSpecValueBaleSizeSquare(p640, p641, p642)
	return BaleLoader.loadSpecValueBaleSize(p640, p641, p642, false)
end
function BaleLoader.getSpecValueBaleSizeRound(p643, p644, p645, p646, p647, p648)
	if p643.specs.baleLoaderBaleSizeRound == nil then
		return nil
	else
		return BaleLoader.getSpecValueBaleSize(p643, p644, p645, p646, p647, p648, true)
	end
end
function BaleLoader.getSpecValueBaleSizeSquare(p649, p650, p651, p652, p653, p654)
	if p649.specs.baleLoaderBaleSizeSquare == nil then
		return nil
	else
		return BaleLoader.getSpecValueBaleSize(p649, p650, p651, p652, p653, p654, false)
	end
end

Mountable = {}
Mountable.FORCE_LIMIT_UPDATE_TIME = 1000
Mountable.FORCE_LIMIT_RAYCAST_DISTANCE = 20
source("dataS/scripts/vehicles/specializations/events/MountableSetMountTypeEvent.lua")
function Mountable.prerequisitesPresent(_)
	return true
end
function Mountable.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Mountable")
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMount#forceLimitScale", "Force limit scale", 1)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicMount#triggerNode", "Trigger node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicMount#jointNode", "Joint node")
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMount#triggerForceAcceleration", "Trigger force acceleration", 4)
	v1:register(XMLValueType.BOOL, "vehicle.dynamicMount#singleAxisFreeY", "Single axis free Y")
	v1:register(XMLValueType.BOOL, "vehicle.dynamicMount#singleAxisFreeX", "Single axis free X")
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMount#jointTransY", "Fixed Y translation of local placed joint", "not defined")
	v1:register(XMLValueType.BOOL, "vehicle.dynamicMount#jointLimitToRotY", "Local placed joint will only be adjusted on Y axis to the target mounter object. X and Z will be 0.", false)
	v1:register(XMLValueType.FLOAT, "vehicle.dynamicMount#additionalMountDistance", "Distance from root node to the object laying on top (normally height of object). If defined the mass of this object has influence in mounting.", 0)
	v1:register(XMLValueType.BOOL, "vehicle.dynamicMount#allowMassReduction", "Defines if mass can be reduced by the mount vehicle", true)
	v1:register(XMLValueType.STRING, "vehicle.dynamicMount.lockPosition(?)#xmlFilename", "XML filename of vehicle to lock on (needs to match only the end of the filename)")
	v1:register(XMLValueType.STRING, "vehicle.dynamicMount.lockPosition(?)#jointNode", "Joint node of other vehicle (path or i3dMapping name)", "vehicle root node")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.dynamicMount.lockPosition(?)#transOffset", "Translation offset from joint node", "0 0 0")
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.dynamicMount.lockPosition(?)#rotOffset", "Rotation offset from joint node", "0 0 0")
	v1:setXMLSpecializationType()
end
function Mountable.registerEvents(p2)
	SpecializationUtil.registerEvent(p2, "onDynamicMountTypeChanged")
end
function Mountable.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getSupportsMountDynamic", Mountable.getSupportsMountDynamic)
	SpecializationUtil.registerFunction(p3, "getSupportsMountKinematic", Mountable.getSupportsMountKinematic)
	SpecializationUtil.registerFunction(p3, "onDynamicMountJointBreak", Mountable.onDynamicMountJointBreak)
	SpecializationUtil.registerFunction(p3, "mountableTriggerCallback", Mountable.mountableTriggerCallback)
	SpecializationUtil.registerFunction(p3, "mount", Mountable.mount)
	SpecializationUtil.registerFunction(p3, "unmount", Mountable.unmount)
	SpecializationUtil.registerFunction(p3, "mountKinematic", Mountable.mountKinematic)
	SpecializationUtil.registerFunction(p3, "unmountKinematic", Mountable.unmountKinematic)
	SpecializationUtil.registerFunction(p3, "mountDynamic", Mountable.mountDynamic)
	SpecializationUtil.registerFunction(p3, "unmountDynamic", Mountable.unmountDynamic)
	SpecializationUtil.registerFunction(p3, "getAdditionalMountingDistance", Mountable.getAdditionalMountingDistance)
	SpecializationUtil.registerFunction(p3, "getAdditionalMountingMass", Mountable.getAdditionalMountingMass)
	SpecializationUtil.registerFunction(p3, "updateDynamicMountJointForceLimit", Mountable.updateDynamicMountJointForceLimit)
	SpecializationUtil.registerFunction(p3, "additionalMountingMassRaycastCallback", Mountable.additionalMountingMassRaycastCallback)
	SpecializationUtil.registerFunction(p3, "getMountObject", Mountable.getMountObject)
	SpecializationUtil.registerFunction(p3, "getDynamicMountObject", Mountable.getDynamicMountObject)
	SpecializationUtil.registerFunction(p3, "setReducedComponentMass", Mountable.setReducedComponentMass)
	SpecializationUtil.registerFunction(p3, "getAllowComponentMassReduction", Mountable.getAllowComponentMassReduction)
	SpecializationUtil.registerFunction(p3, "getDefaultAllowComponentMassReduction", Mountable.getDefaultAllowComponentMassReduction)
	SpecializationUtil.registerFunction(p3, "getMountableLockPositions", Mountable.getMountableLockPositions)
	SpecializationUtil.registerFunction(p3, "setDynamicMountType", Mountable.setDynamicMountType)
	SpecializationUtil.registerFunction(p3, "addMountStateChangeListener", Mountable.addMountStateChangeListener)
	SpecializationUtil.registerFunction(p3, "removeMountStateChangeListener", Mountable.removeMountStateChangeListener)
end
function Mountable.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsActive", Mountable.getIsActive)
	SpecializationUtil.registerOverwrittenFunction(p4, "getOwnerConnection", Mountable.getOwnerConnection)
	SpecializationUtil.registerOverwrittenFunction(p4, "findRootVehicle", Mountable.findRootVehicle)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsMapHotspotVisible", Mountable.getIsMapHotspotVisible)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAdditionalComponentMass", Mountable.getAdditionalComponentMass)
	SpecializationUtil.registerOverwrittenFunction(p4, "setWorldPositionQuaternion", Mountable.setWorldPositionQuaternion)
	SpecializationUtil.registerOverwrittenFunction(p4, "addToPhysics", Mountable.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p4, "removeFromPhysics", Mountable.removeFromPhysics)
end
function Mountable.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", Mountable)
	SpecializationUtil.registerEventListener(p5, "onDelete", Mountable)
	SpecializationUtil.registerEventListener(p5, "onReadStream", Mountable)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", Mountable)
	SpecializationUtil.registerEventListener(p5, "onUpdate", Mountable)
	SpecializationUtil.registerEventListener(p5, "onEnterVehicle", Mountable)
	SpecializationUtil.registerEventListener(p5, "onPreAttach", Mountable)
end
function Mountable.onLoad(p_u_6, _)
	local v_u_7 = p_u_6.spec_mountable
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.dynamicMount#triggerIndex", "vehicle.dynamicMount#triggerNode")
	v_u_7.dynamicMountJointIndex = nil
	v_u_7.dynamicMountObject = nil
	p_u_6.dynamicMountObjectActorId = nil
	v_u_7.dynamicMountForceLimitScale = p_u_6.xmlFile:getValue("vehicle.dynamicMount#forceLimitScale", 1)
	v_u_7.mountObject = nil
	v_u_7.componentNode = p_u_6.rootNode
	v_u_7.dynamicMountTriggerId = p_u_6.xmlFile:getValue("vehicle.dynamicMount#triggerNode", nil, p_u_6.components, p_u_6.i3dMappings)
	if v_u_7.dynamicMountTriggerId ~= nil then
		if p_u_6.isServer then
			addTrigger(v_u_7.dynamicMountTriggerId, "mountableTriggerCallback", p_u_6)
		end
		v_u_7.componentNode = p_u_6:getParentComponent(v_u_7.dynamicMountTriggerId)
		if v_u_7.dynamicMountJointNodeDynamic == nil then
			v_u_7.dynamicMountJointNodeDynamic = createTransformGroup("dynamicMountJointNodeDynamic")
			link(v_u_7.componentNode, v_u_7.dynamicMountJointNodeDynamic)
		end
		v_u_7.dynamicMountJointTransY = p_u_6.xmlFile:getValue("vehicle.dynamicMount#jointTransY")
		v_u_7.dynamicMountJointLimitToRotY = p_u_6.xmlFile:getValue("vehicle.dynamicMount#jointLimitToRotY", false)
	end
	v_u_7.jointNode = p_u_6.xmlFile:getValue("vehicle.dynamicMount#jointNode", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.dynamicMountTriggerForceAcceleration = p_u_6.xmlFile:getValue("vehicle.dynamicMount#triggerForceAcceleration", 4)
	v_u_7.dynamicMountSingleAxisFreeY = p_u_6.xmlFile:getValue("vehicle.dynamicMount#singleAxisFreeY")
	v_u_7.dynamicMountSingleAxisFreeX = p_u_6.xmlFile:getValue("vehicle.dynamicMount#singleAxisFreeX")
	v_u_7.additionalMountDistance = p_u_6.xmlFile:getValue("vehicle.dynamicMount#additionalMountDistance", 0)
	v_u_7.forceLimitUpdate = {}
	v_u_7.forceLimitUpdate.raycastActive = false
	v_u_7.forceLimitUpdate.timer = 0
	v_u_7.forceLimitUpdate.lastDistance = 0
	v_u_7.forceLimitUpdate.nextMountingDistance = 0
	v_u_7.forceLimitUpdate.additionalMass = 0
	v_u_7.allowMassReduction = p_u_6.xmlFile:getValue("vehicle.dynamicMount#allowMassReduction", p_u_6:getDefaultAllowComponentMassReduction())
	v_u_7.reducedComponentMass = false
	v_u_7.lockPositions = {}
	p_u_6.xmlFile:iterate("vehicle.dynamicMount.lockPosition", function(_, p8)
		-- upvalues: (copy) p_u_6, (copy) v_u_7
		local v9 = {
			["xmlFilename"] = p_u_6.xmlFile:getValue(p8 .. "#xmlFilename"),
			["jointNode"] = p_u_6.xmlFile:getValue(p8 .. "#jointNode", "0>")
		}
		if v9.xmlFilename == nil or v9.jointNode == nil then
			Logging.xmlWarning(p_u_6.xmlFile, "Invalid lock position \'%s\'. Missing xmlFilename or jointNode!", p8)
		else
			v9.xmlFilename = v9.xmlFilename:gsub("$data", "data")
			v9.transOffset = p_u_6.xmlFile:getValue(p8 .. "#transOffset", "0 0 0", true)
			v9.rotOffset = p_u_6.xmlFile:getValue(p8 .. "#rotOffset", "0 0 0", true)
			local v10 = v_u_7.lockPositions
			table.insert(v10, v9)
		end
	end)
	p_u_6.dynamicMountType = MountableObject.MOUNT_TYPE_NONE
	v_u_7.mountStateChangeListeners = {}
end
function Mountable.onDelete(p11)
	local v12 = p11.spec_mountable
	if v12.mountObject ~= nil and v12.mountObject.onUnmountObject ~= nil then
		v12.mountObject:onUnmountObject(p11)
	end
	if v12.dynamicMountJointIndex ~= nil then
		removeJointBreakReport(v12.dynamicMountJointIndex)
		removeJoint(v12.dynamicMountJointIndex)
	end
	if v12.dynamicMountObject ~= nil then
		v12.dynamicMountObject:removeDynamicMountedObject(p11, true)
	end
	if v12.dynamicMountTriggerId ~= nil then
		removeTrigger(v12.dynamicMountTriggerId)
	end
end
function Mountable.onReadStream(p13, p14, _)
	p13:setDynamicMountType(streamReadUIntN(p14, MountableObject.MOUNT_TYPE_SEND_NUM_BITS))
end
function Mountable.onWriteStream(p15, p16, _)
	streamWriteUIntN(p16, p15.spec_mountable.dynamicMountType, MountableObject.MOUNT_TYPE_SEND_NUM_BITS)
end
function Mountable.onUpdate(p17, p18, _, _, _)
	if p17.isServer then
		local v19 = p17.spec_mountable
		if v19.dynamicMountObjectTriggerCount ~= nil and v19.dynamicMountObjectTriggerCount <= 0 then
			if v19.dynamicMountJointNodeDynamicRefNode == nil then
				p17:unmountDynamic()
				v19.dynamicMountObjectTriggerCount = nil
			else
				local _, _, v20 = localToLocal(v19.dynamicMountJointNodeDynamic, v19.dynamicMountJointNodeDynamicRefNode, 0, 0, 0)
				if v19.dynamicMountJointNodeDynamicMountOffset < v20 then
					v19.dynamicMountJointNodeDynamicMountOffset = nil
					v19.dynamicMountJointNodeDynamicRefNode = nil
					p17:unmountDynamic()
					v19.dynamicMountObjectTriggerCount = nil
				else
					p17:raiseActive()
				end
			end
		end
		if p17.dynamicMountJointIndex ~= nil then
			p17:updateDynamicMountJointForceLimit(p18)
		end
	end
end
function Mountable.getSupportsMountDynamic(p21)
	return p21.spec_mountable.dynamicMountForceLimitScale ~= nil
end
function Mountable.getSupportsMountKinematic(p22)
	return #p22.components == 1
end
function Mountable.onDynamicMountJointBreak(p23, p24, _)
	if p24 == p23.spec_mountable.dynamicMountJointIndex then
		p23:unmountDynamic()
	end
	return false
end
function Mountable.mountableTriggerCallback(p25, _, p26, p27, p28, _, _)
	local v29 = p25.spec_mountable
	if p27 then
		if v29.mountObject == nil then
			local v30 = g_currentMission.nodeToObject[p26]
			if v30 ~= nil and v30.spec_dynamicMountAttacher ~= nil then
				local v31 = v30.spec_dynamicMountAttacher
				if v31 ~= nil and v31.dynamicMountAttacherNode ~= nil then
					if p25.dynamicMountObjectActorId == nil then
						p25:mountDynamic(v30, p26, v31.dynamicMountAttacherNode, DynamicMountUtil.TYPE_FORK, v29.dynamicMountTriggerForceAcceleration * v31.dynamicMountAttacherForceLimitScale)
						v29.dynamicMountObjectTriggerCount = 1
						return
					end
					if p26 ~= p25.dynamicMountObjectActorId and v29.dynamicMountObjectTriggerCount == nil then
						p25:unmountDynamic()
						p25:mountDynamic(v30, p26, v31.dynamicMountAttacherNode, DynamicMountUtil.TYPE_FORK, v29.dynamicMountTriggerForceAcceleration * v31.dynamicMountAttacherForceLimitScale)
						v29.dynamicMountObjectTriggerCount = 1
						return
					end
					if p26 == p25.dynamicMountObjectActorId and v29.dynamicMountObjectTriggerCount ~= nil then
						v29.dynamicMountObjectTriggerCount = v29.dynamicMountObjectTriggerCount + 1
						return
					end
				end
			end
		end
	elseif p28 and (p26 == p25.dynamicMountObjectActorId and v29.dynamicMountObjectTriggerCount ~= nil) then
		v29.dynamicMountObjectTriggerCount = v29.dynamicMountObjectTriggerCount - 1
		if v29.dynamicMountJointNodeDynamic == nil and v29.dynamicMountObjectTriggerCount == 0 then
			p25:unmountDynamic()
			v29.dynamicMountObjectTriggerCount = nil
		end
	end
end
function Mountable.mount(p32, p33, p34, p35, p36, p37, p38, p39, p40)
	local v41 = p32.spec_mountable
	p32:unmountDynamic(true)
	if v41.mountObject == nil then
		removeFromPhysics(v41.componentNode)
	end
	link(p34, v41.componentNode)
	local v42, v43, v44 = localToWorld(p34, p35, p36, p37)
	local v45, v46, v47, v48 = mathEulerToQuaternion(localRotationToWorld(p34, p38, p39, p40))
	p32:setWorldPositionQuaternion(v42, v43, v44, v45, v46, v47, v48, 1, true)
	v41.mountObject = p33
	p32:setDynamicMountType(MountableObject.MOUNT_TYPE_DEFAULT, p33)
end
function Mountable.unmount(p49)
	local v50 = p49.spec_mountable
	p49:setDynamicMountType(MountableObject.MOUNT_TYPE_NONE)
	if v50.mountObject == nil then
		return false
	end
	if v50.mountObject.onUnmountObject ~= nil then
		v50.mountObject:onUnmountObject(p49)
	end
	v50.mountObject = nil
	local v51, v52, v53 = getWorldTranslation(v50.componentNode)
	local v54, v55, v56, v57 = getWorldQuaternion(v50.componentNode)
	link(getRootNode(), v50.componentNode)
	p49:setWorldPositionQuaternion(v51, v52, v53, v54, v55, v56, v57, 1, true)
	addToPhysics(v50.componentNode)
	return true
end
function Mountable.mountKinematic(p58, p59, p60, p61, p62, p63, p64, p65, p66)
	local v67 = p58.spec_mountable
	p58:unmountDynamic(true)
	removeFromPhysics(v67.componentNode)
	if p58.isServer then
		setRigidBodyType(v67.componentNode, RigidBodyType.KINEMATIC)
		p58.components[1].isKinematic = true
		p58.components[1].isDynamic = false
	end
	link(p60, v67.componentNode)
	local v68, v69, v70 = localToWorld(p60, p61, p62, p63)
	local v71, v72, v73, v74 = mathEulerToQuaternion(localRotationToWorld(p60, p64, p65, p66))
	p58:setWorldPositionQuaternion(v68, v69, v70, v71, v72, v73, v74, 1, true)
	addToPhysics(v67.componentNode)
	if p59.getParentComponent ~= nil then
		local v75 = p59:getParentComponent(p60)
		if getRigidBodyType(v75) == RigidBodyType.DYNAMIC then
			setPairCollision(v75, v67.componentNode, false)
		end
	end
	v67.mountObject = p59
	v67.mountJointNode = p60
	p58:setDynamicMountType(MountableObject.MOUNT_TYPE_KINEMATIC, p59)
end
function Mountable.unmountKinematic(p76)
	local v77 = p76.spec_mountable
	p76:setDynamicMountType(MountableObject.MOUNT_TYPE_NONE)
	if v77.mountObject == nil then
		return false
	end
	if v77.mountObject.getParentComponent ~= nil then
		local v78 = v77.mountObject:getParentComponent(v77.mountJointNode)
		if getRigidBodyType(v78) == RigidBodyType.DYNAMIC then
			setPairCollision(v78, v77.componentNode, true)
		end
	end
	if v77.mountObject.onUnmountObject ~= nil then
		v77.mountObject:onUnmountObject(p76)
	end
	v77.mountObject = nil
	v77.mountJointNode = nil
	local v79, v80, v81 = getWorldTranslation(v77.componentNode)
	local v82, v83, v84, v85 = getWorldQuaternion(v77.componentNode)
	removeFromPhysics(v77.componentNode)
	link(getRootNode(), v77.componentNode)
	p76:setWorldPositionQuaternion(v79, v80, v81, v82, v83, v84, v85, 1, true)
	addToPhysics(v77.componentNode)
	if p76.isServer then
		setRigidBodyType(v77.componentNode, RigidBodyType.DYNAMIC)
		p76.components[1].isKinematic = false
		p76.components[1].isDynamic = true
	end
	return true
end
function Mountable.mountDynamic(p86, p87, p88, p89, p90, p91)
	local v92 = p86.spec_mountable
	if not p86:getSupportsMountDynamic() or (v92.mountObject ~= nil or p86.dynamicMountType ~= MountableObject.MOUNT_TYPE_NONE) then
		return false
	end
	local v93 = p86.spec_dynamicMountAttacher
	if v93 ~= nil then
		for _, v94 in pairs(v93.dynamicMountedObjects) do
			if v94:isa(Vehicle) and v94.rootVehicle == p87.rootVehicle then
				return false
			end
		end
	end
	if p87.rootVehicle == p86.rootVehicle then
		return false
	end
	local v95 = v92.jointNode or p89
	if v92.dynamicMountTriggerId ~= nil then
		local v96, v97, v98
		if p90 == DynamicMountUtil.TYPE_FORK then
			local _, _, v99 = worldToLocal(v95, localToWorld(v92.componentNode, getCenterOfMass(v92.componentNode)))
			v96, v97, v98 = localToLocal(v95, getParent(v92.dynamicMountJointNodeDynamic), 0, 0, v99)
		else
			v96, v97, v98 = localToLocal(v95, getParent(v92.dynamicMountJointNodeDynamic), 0, 0, 0)
		end
		local v100 = v92.dynamicMountJointTransY or v97
		setTranslation(v92.dynamicMountJointNodeDynamic, v96, v100, v98)
		if v92.dynamicMountJointLimitToRotY then
			local v101, v102, v103 = localDirectionToLocal(v95, getParent(v92.dynamicMountJointNodeDynamic), 0, 0, 1)
			if math.abs(v102) > 0.2 then
				return false
			end
			local v104, v105 = MathUtil.vector2Normalize(v101, v103)
			local v106 = MathUtil.getYRotationFromDirection(v104, v105)
			setRotation(v92.dynamicMountJointNodeDynamic, 0, v106, 0)
			local _, v107, _ = localDirectionToLocal(v95, getParent(v92.dynamicMountJointNodeDynamic), 0, 1, 0)
			if v107 < 0 then
				rotateAboutLocalAxis(v92.dynamicMountJointNodeDynamic, 3.141592653589793, 0, 0, 1)
			end
		else
			local v108, v109, v110 = localRotationToLocal(v95, getParent(v92.dynamicMountJointNodeDynamic), 0, 0, 0)
			setRotation(v92.dynamicMountJointNodeDynamic, v108, v109, v110)
		end
		local _, _, v111 = localToLocal(v92.dynamicMountJointNodeDynamic, v95, 0, 0, 0)
		v92.dynamicMountJointNodeDynamicMountOffset = v111
		v92.dynamicMountJointNodeDynamicRefNode = v95
	end
	v92.mountBaseForceAcceleration = p91
	v92.mountBaseMass = p86:getTotalMass()
	if not DynamicMountUtil.mountDynamic(p86, v92.componentNode, p87, p88, v95, p90, p91 * v92.dynamicMountForceLimitScale, v92.dynamicMountJointNodeDynamic) then
		return false
	end
	p86:setDynamicMountType(MountableObject.MOUNT_TYPE_DYNAMIC, p87)
	v92.mountObject = p87
	return true
end
function Mountable.unmountDynamic(p112, p113)
	local v114 = p112.spec_mountable
	p112:setDynamicMountType(MountableObject.MOUNT_TYPE_NONE)
	if v114.mountObject ~= nil then
		if v114.mountObject.onUnmountObject ~= nil then
			v114.mountObject:onUnmountObject(p112)
		end
		v114.mountObject = nil
	end
	DynamicMountUtil.unmountDynamic(p112, p113)
end
function Mountable.addToPhysics(p115, p116)
	if not p116(p115) then
		return false
	end
	local v117 = p115.spec_mountable
	if p115.dynamicMountType == MountableObject.MOUNT_TYPE_KINEMATIC then
		local v118 = v117.mountObject
		if v118 ~= nil and v118.getParentComponent ~= nil then
			local v119 = v118:getParentComponent(v117.mountJointNode)
			if getRigidBodyType(v119) == RigidBodyType.DYNAMIC then
				setPairCollision(v119, v117.componentNode, false)
			end
		end
	end
	return true
end
function Mountable.removeFromPhysics(p120, p121)
	return p121(p120)
end
function Mountable.getAdditionalMountingDistance(p122)
	return p122.spec_mountable.additionalMountDistance
end
function Mountable.getAdditionalMountingMass(_)
	return 0
end
function Mountable.updateDynamicMountJointForceLimit(p123, p124)
	local v125 = p123.spec_mountable
	if not v125.forceLimitUpdate.raycastActive then
		v125.forceLimitUpdate.timer = v125.forceLimitUpdate.timer - p124
		if v125.forceLimitUpdate.timer <= 0 then
			v125.forceLimitUpdate.raycastActive = true
			v125.forceLimitUpdate.timer = Mountable.FORCE_LIMIT_UPDATE_TIME
			v125.forceLimitUpdate.lastDistance = 0
			v125.forceLimitUpdate.lastObject = nil
			v125.forceLimitUpdate.nextMountingDistance = p123:getAdditionalMountingDistance()
			v125.forceLimitUpdate.additionalMass = 0
			local v126, v127, v128 = getWorldTranslation(p123.rootNode)
			raycastAllAsync(v126, v127, v128, 0, 1, 0, Mountable.FORCE_LIMIT_RAYCAST_DISTANCE, "additionalMountingMassRaycastCallback", p123, CollisionFlag.DYNAMIC_OBJECT)
		end
	end
end
function Mountable.additionalMountingMassRaycastCallback(p129, p130, _, _, _, p131, _, _, _, _, _, p132)
	local v133 = p129.spec_mountable
	v133.forceLimitUpdate.raycastActive = false
	local v134 = g_currentMission.nodeToObject[p130]
	if v134 ~= p129 and (v134 ~= nil and (v134:isa(Vehicle) and (p129.getAdditionalMountingDistance ~= nil and v134 ~= v133.forceLimitUpdate.lastObject))) then
		local v135 = p131 - v133.forceLimitUpdate.lastDistance - v133.forceLimitUpdate.nextMountingDistance
		if math.abs(v135) < 0.25 then
			v133.forceLimitUpdate.lastDistance = p131
			v133.forceLimitUpdate.nextMountingDistance = p129:getAdditionalMountingDistance()
			v133.forceLimitUpdate.additionalMass = v133.forceLimitUpdate.additionalMass + v134:getTotalMass()
			v133.forceLimitUpdate.lastObject = v134
		end
	end
	if p132 and p129.dynamicMountJointIndex ~= nil then
		local v136 = (v133.forceLimitUpdate.additionalMass + v133.mountBaseMass) / v133.mountBaseMass
		local v137 = v133.mountBaseForceAcceleration * v136
		local v138 = v133.mountBaseMass * v137
		setJointLinearDrive(p129.dynamicMountJointIndex, 2, false, true, 0, 0, v138, 0, 0)
	end
	return true
end
function Mountable.getIsActive(p139, p140)
	local v141 = p139.spec_mountable
	local v142
	if v141.dynamicMountObject == nil or v141.dynamicMountObject.getIsActive == nil then
		v142 = false
	else
		v142 = v141.dynamicMountObject:getIsActive()
	end
	return p140(p139) or v142
end
function Mountable.getMountObject(p143)
	return p143.spec_mountable.mountObject
end
function Mountable.getDynamicMountObject(p144)
	return p144.spec_mountable.dynamicMountObject
end
function Mountable.setReducedComponentMass(p145, p146)
	local v147 = p145.spec_mountable
	if not p145:getAllowComponentMassReduction() then
		return false
	end
	if v147.reducedComponentMass ~= p146 then
		v147.reducedComponentMass = p146
		p145:setMassDirty()
	end
	return true
end
function Mountable.getAllowComponentMassReduction(p148)
	return p148.spec_mountable.allowMassReduction
end
function Mountable.getDefaultAllowComponentMassReduction(_)
	return false
end
function Mountable.getMountableLockPositions(p149)
	return p149.spec_mountable.lockPositions
end
function Mountable.setDynamicMountType(p150, p151, p152, p153)
	local v154 = p150.spec_mountable
	if p151 ~= p150.dynamicMountType then
		p150.dynamicMountType = p151
		if p151 == MountableObject.MOUNT_TYPE_NONE then
			p150:setReducedComponentMass(false)
		end
		for _, v155 in ipairs(v154.mountStateChangeListeners) do
			local v156 = v155.callbackFunc
			if type(v156) == "string" then
				v155.object[v155.callbackFunc](v155.object, p150, p151, p152)
			else
				local v157 = v155.callbackFunc
				if type(v157) == "function" then
					v155.callbackFunc(v155.object, p150, p151, p152)
				end
			end
		end
		SpecializationUtil.raiseEvent(p150, "onDynamicMountTypeChanged", p150.dynamicMountType, p152)
		MountableSetMountTypeEvent.sendEvent(p150, p150.dynamicMountType, p153)
	end
end
function Mountable.addMountStateChangeListener(p158, p159, p160)
	local v161 = p158.spec_mountable
	local v162 = p160 == nil and "onObjectMountStateChanged" or p160
	for _, v163 in ipairs(v161.mountStateChangeListeners) do
		if v163.object == p159 and v163.callbackFunc == v162 then
			return
		end
	end
	local v164 = v161.mountStateChangeListeners
	table.insert(v164, {
		["object"] = p159,
		["callbackFunc"] = v162
	})
end
function Mountable.removeMountStateChangeListener(p165, p166, p167)
	local v168 = p165.spec_mountable
	local v169 = p167 == nil and "onObjectMountStateChanged" or p167
	local v170 = -1
	for v171, v172 in ipairs(v168.mountStateChangeListeners) do
		if v172.object == p166 and v172.callbackFunc == v169 then
			v170 = v171
		end
	end
	if v170 > 0 then
		table.remove(v168.mountStateChangeListeners, v170)
	end
end
function Mountable.getOwnerConnection(p173, p174)
	local v175 = p173.spec_mountable
	if v175.dynamicMountObject == nil or v175.dynamicMountObject.getOwnerConnection == nil then
		return p174(p173)
	else
		return v175.dynamicMountObject:getOwnerConnection()
	end
end
function Mountable.findRootVehicle(p176, p177)
	local v178 = p176.spec_mountable
	local v179 = p177(p176)
	if (v179 == nil or v179 == p176) and (v178.dynamicMountObject ~= nil and v178.dynamicMountObject.findRootVehicle ~= nil) then
		v179 = v178.dynamicMountObject:findRootVehicle()
	end
	if v179 ~= nil then
		p176 = v179
	end
	return p176
end
function Mountable.getIsMapHotspotVisible(p180, p181)
	if p181(p180) then
		if p180:getMountObject() == nil then
			return p180:getDynamicMountObject() == nil
		else
			return false
		end
	else
		return false
	end
end
function Mountable.getAdditionalComponentMass(p182, p183, p184)
	local v185 = p183(p182, p184)
	if p182.spec_mountable.reducedComponentMass then
		v185 = -p184.defaultMass + 0.1
	end
	return v185
end
function Mountable.setWorldPositionQuaternion(p186, p187, p188, p189, p190, p191, p192, p193, p194, p195, p196)
	if p186.isServer then
		return p187(p186, p188, p189, p190, p191, p192, p193, p194, p195, p196)
	end
	if p186:getMountObject() == nil or p195 > 1 then
		return p187(p186, p188, p189, p190, p191, p192, p193, p194, p195, p196)
	end
end
function Mountable.onEnterVehicle(p197, _)
	p197:unmountDynamic()
end
function Mountable.onPreAttach(p198, _, _, _)
	p198:unmountDynamic()
end

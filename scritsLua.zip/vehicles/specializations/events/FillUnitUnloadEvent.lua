FillUnitUnloadEvent = {}
local v_u_1 = Class(FillUnitUnloadEvent, Event)
InitStaticEventClass(FillUnitUnloadEvent, "FillUnitUnloadEvent")
function FillUnitUnloadEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function FillUnitUnloadEvent.new(p2)
	local v3 = FillUnitUnloadEvent.emptyNew()
	v3.object = p2
	return v3
end
function FillUnitUnloadEvent.newServerToClient()
	return FillUnitUnloadEvent.emptyNew()
end
function FillUnitUnloadEvent.readStream(p4, p5, p6)
	if not p6:getIsServer() then
		p4.object = NetworkUtil.readNodeObject(p5)
	end
	p4:run(p6)
end
function FillUnitUnloadEvent.writeStream(p7, p8, p9)
	if p9:getIsServer() then
		NetworkUtil.writeNodeObject(p8, p7.object)
	end
end
function FillUnitUnloadEvent.run(p10, p11)
	if not p11:getIsServer() and (p10.object ~= nil and p10.object:getIsSynchronized()) then
		p10.object:unloadFillUnits(true)
	end
end

PalletFillerBuyPalletEvent = {}
local v_u_1 = Class(PalletFillerBuyPalletEvent, Event)
InitStaticEventClass(PalletFillerBuyPalletEvent, "PalletFillerBuyPalletEvent")
function PalletFillerBuyPalletEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function PalletFillerBuyPalletEvent.new(p2)
	local v3 = PalletFillerBuyPalletEvent.emptyNew()
	v3.object = p2
	return v3
end
function PalletFillerBuyPalletEvent.readStream(p4, p5, p6)
	p4.object = NetworkUtil.readNodeObject(p5)
	p4:run(p6)
end
function PalletFillerBuyPalletEvent.writeStream(p7, p8, _)
	NetworkUtil.writeNodeObject(p8, p7.object)
end
function PalletFillerBuyPalletEvent.run(p9, p10)
	if p10:getIsServer() then
		if p9.object ~= nil and p9.object:getIsSynchronized() then
			p9.object:buyPalletFillerPallets(true)
		end
	else
		g_server:broadcastEvent(p9, false, p10, p9.object)
		if p9.object ~= nil and p9.object:getIsSynchronized() then
			if g_currentMission.slotSystem:getCanAddLimitedObjects(SlotSystem.LIMITED_OBJECT_PALLET, 1) then
				p9.object:buyPalletFillerPallets(true)
			else
				local v11 = BuyVehicleData.new()
				v11:setStoreItem(p9.object.spec_palletFiller.pallet.storeItem)
				p10:sendEvent(BuyVehicleEvent.newServerToClient(BuyVehicleEvent.STATE_TOO_MANY_PALLETS, v11))
			end
		end
	end
end

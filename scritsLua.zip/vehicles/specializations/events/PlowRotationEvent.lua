PlowRotationEvent = {}
local v_u_1 = Class(PlowRotationEvent, Event)
InitStaticEventClass(PlowRotationEvent, "PlowRotationEvent")
function PlowRotationEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function PlowRotationEvent.new(p2, p3)
	local v4 = PlowRotationEvent.emptyNew()
	v4.object = p2
	v4.rotationMax = p3
	return v4
end
function PlowRotationEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.rotationMax = streamReadBool(p6)
	p5:run(p7)
end
function PlowRotationEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteBool(p9, p8.rotationMax)
end
function PlowRotationEvent.run(p10, p11)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setRotationMax(p10.rotationMax, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(PlowRotationEvent.new(p10.object, p10.rotationMax), nil, p11, p10.object)
	end
end

AIVehicleIsBlockedEvent = {}
local v_u_1 = Class(AIVehicleIsBlockedEvent, Event)
InitStaticEventClass(AIVehicleIsBlockedEvent, "AIVehicleIsBlockedEvent")
function AIVehicleIsBlockedEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AIVehicleIsBlockedEvent.new(p2, p3)
	local v4 = AIVehicleIsBlockedEvent.emptyNew()
	v4.object = p2
	v4.isBlocked = p3
	return v4
end
function AIVehicleIsBlockedEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.isBlocked = streamReadBool(p6)
	p5:run(p7)
end
function AIVehicleIsBlockedEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteBool(p9, p8.isBlocked)
end
function AIVehicleIsBlockedEvent.run(p10, _)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		if p10.isBlocked then
			p10.object:aiBlock()
			return
		end
		p10.object:aiContinue()
	end
end

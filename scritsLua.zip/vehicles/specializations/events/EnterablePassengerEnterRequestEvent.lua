EnterablePassengerEnterRequestEvent = {}
local v_u_1 = Class(EnterablePassengerEnterRequestEvent, Event)
InitStaticEventClass(EnterablePassengerEnterRequestEvent, "EnterablePassengerEnterRequestEvent")
function EnterablePassengerEnterRequestEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function EnterablePassengerEnterRequestEvent.new(p2, p3)
	local v4 = EnterablePassengerEnterRequestEvent.emptyNew()
	v4.object = p2
	v4.objectId = NetworkUtil.getObjectId(v4.object)
	v4.seatIndex = p3
	return v4
end
function EnterablePassengerEnterRequestEvent.readStream(p5, p6, p7)
	p5.objectId = NetworkUtil.readNodeObjectId(p6)
	p5.seatIndex = streamReadUIntN(p6, EnterablePassenger.SEAT_INDEX_SEND_NUM_BITS) + 1
	p5.object = NetworkUtil.getObject(p5.objectId)
	p5:run(p7)
end
function EnterablePassengerEnterRequestEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObjectId(p9, p8.objectId)
	local v10 = streamWriteUIntN
	local v11 = p8.seatIndex - 1
	local v12 = 2 ^ EnterablePassenger.SEAT_INDEX_SEND_NUM_BITS - 1
	v10(p9, math.clamp(v11, 0, v12), EnterablePassenger.SEAT_INDEX_SEND_NUM_BITS)
end
function EnterablePassengerEnterRequestEvent.run(p13, p14)
	if p13.object ~= nil and (p13.object:getIsSynchronized() and p13.object:getIsPassengerSeatIndexAvailable(p13.seatIndex)) then
		local v15 = g_currentMission.userManager:getUserIdByConnection(p14)
		g_server:broadcastEvent(EnterablePassengerEnterResponseEvent.new(p13.objectId, false, p13.seatIndex, v15), true, p14)
		p14:sendEvent(EnterablePassengerEnterResponseEvent.new(p13.objectId, true, p13.seatIndex, v15))
	end
end

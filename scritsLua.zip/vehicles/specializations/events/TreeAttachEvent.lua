TreeAttachEvent = {}
local v_u_1 = Class(TreeAttachEvent, Event)
InitStaticEventClass(TreeAttachEvent, "TreeAttachEvent")
function TreeAttachEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TreeAttachEvent.new(p2, p3, p4, p5, p6, p7)
	local v8 = TreeAttachEvent.emptyNew()
	v8.object = p2
	v8.splitShapeId = p3
	v8.x = p4
	v8.y = p5
	v8.z = p6
	v8.ropeIndex = p7
	return v8
end
function TreeAttachEvent.readStream(p9, p10, p11)
	p9.object = NetworkUtil.readNodeObject(p10)
	p9.splitShapeId = readSplitShapeIdFromStream(p10)
	p9.x = streamReadFloat32(p10)
	p9.y = streamReadFloat32(p10)
	p9.z = streamReadFloat32(p10)
	if streamReadBool(p10) then
		p9.ropeIndex = streamReadUIntN(p10, 4)
	end
	p9:run(p11)
end
function TreeAttachEvent.writeStream(p12, p13, _)
	NetworkUtil.writeNodeObject(p13, p12.object)
	writeSplitShapeIdToStream(p13, p12.splitShapeId)
	streamWriteFloat32(p13, p12.x)
	streamWriteFloat32(p13, p12.y)
	streamWriteFloat32(p13, p12.z)
	if streamWriteBool(p13, p12.ropeIndex ~= nil) then
		streamWriteUIntN(p13, p12.ropeIndex, 4)
	end
end
function TreeAttachEvent.run(p14, _)
	if p14.object ~= nil and p14.object:getIsSynchronized() then
		if p14.object.attachTreeToCarriage ~= nil then
			p14.object:attachTreeToCarriage(p14.splitShapeId, p14.x, p14.y, p14.z, p14.ropeIndex, true)
			return
		end
		if p14.object.attachTreeToWinch ~= nil then
			p14.object:attachTreeToWinch(p14.splitShapeId, p14.x, p14.y, p14.z, p14.ropeIndex, nil, true)
		end
	end
end
function TreeAttachEvent.sendEvent(p15, p16, p17, p18, p19, p20, p21)
	if p21 == nil or p21 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(TreeAttachEvent.new(p15, p16, p17, p18, p19, p20), nil, nil, p15)
			return
		end
		g_client:getServerConnection():sendEvent(TreeAttachEvent.new(p15, p16, p17, p18, p19, p20))
	end
end

WearableRepaintEvent = {}
local v_u_1 = Class(WearableRepaintEvent, Event)
InitStaticEventClass(WearableRepaintEvent, "WearableRepaintEvent")
function WearableRepaintEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function WearableRepaintEvent.new(p2)
	local v3 = WearableRepaintEvent.emptyNew()
	v3.vehicle = p2
	return v3
end
function WearableRepaintEvent.readStream(p4, p5, p6)
	p4.vehicle = NetworkUtil.readNodeObject(p5)
	p4:run(p6)
end
function WearableRepaintEvent.writeStream(p7, p8, _)
	NetworkUtil.writeNodeObject(p8, p7.vehicle)
end
function WearableRepaintEvent.run(p9, p10)
	if p10:getIsServer() then
		g_messageCenter:publish(MessageType.VEHICLE_REPAINTED, p9.vehicle)
	elseif p9.vehicle ~= nil and (p9.vehicle:getIsSynchronized() and p9.vehicle.repaintVehicle ~= nil) then
		p9.vehicle:repaintVehicle()
		g_server:broadcastEvent(p9)
		g_messageCenter:publish(MessageType.VEHICLE_REPAINTED, p9.vehicle)
		return
	end
end

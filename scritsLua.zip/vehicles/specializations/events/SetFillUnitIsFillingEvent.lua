SetFillUnitIsFillingEvent = {}
local v_u_1 = Class(SetFillUnitIsFillingEvent, Event)
InitStaticEventClass(SetFillUnitIsFillingEvent, "SetFillUnitIsFillingEvent")
function SetFillUnitIsFillingEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function SetFillUnitIsFillingEvent.new(p2, p3)
	local v4 = SetFillUnitIsFillingEvent.emptyNew()
	v4.vehicle = p2
	v4.isFilling = p3
	return v4
end
function SetFillUnitIsFillingEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.isFilling = streamReadBool(p6)
	p5:run(p7)
end
function SetFillUnitIsFillingEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	streamWriteBool(p9, p8.isFilling)
end
function SetFillUnitIsFillingEvent.run(p10, p11)
	if p10.vehicle ~= nil and p10.vehicle:getIsSynchronized() then
		p10.vehicle:setFillUnitIsFilling(p10.isFilling, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(SetFillUnitIsFillingEvent.new(p10.vehicle, p10.isFilling), nil, p11, p10.vehicle)
	end
end

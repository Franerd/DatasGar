FoldableSetFoldDirectionEvent = {}
local v_u_1 = Class(FoldableSetFoldDirectionEvent, Event)
InitStaticEventClass(FoldableSetFoldDirectionEvent, "FoldableSetFoldDirectionEvent")
function FoldableSetFoldDirectionEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function FoldableSetFoldDirectionEvent.new(p2, p3, p4)
	local v5 = FoldableSetFoldDirectionEvent.emptyNew()
	v5.object = p2
	v5.direction = math.sign(p3)
	v5.moveToMiddle = p4
	return v5
end
function FoldableSetFoldDirectionEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.direction = streamReadUIntN(p7, 2) - 1
	p6.moveToMiddle = streamReadBool(p7)
	p6:run(p8)
end
function FoldableSetFoldDirectionEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteUIntN(p10, p9.direction + 1, 2)
	streamWriteBool(p10, p9.moveToMiddle)
end
function FoldableSetFoldDirectionEvent.run(p11, p12)
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setFoldState(p11.direction, p11.moveToMiddle, true)
	end
	if not p12:getIsServer() then
		g_server:broadcastEvent(FoldableSetFoldDirectionEvent.new(p11.object, p11.direction, p11.moveToMiddle), nil, p12, p11.object)
	end
end

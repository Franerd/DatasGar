WoodHarvesterCutLengthEvent = {}
local v_u_1 = Class(WoodHarvesterCutLengthEvent, Event)
InitStaticEventClass(WoodHarvesterCutLengthEvent, "WoodHarvesterCutLengthEvent")
function WoodHarvesterCutLengthEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function WoodHarvesterCutLengthEvent.new(p2, p3)
	local v4 = WoodHarvesterCutLengthEvent.emptyNew()
	v4.object = p2
	v4.index = p3
	return v4
end
function WoodHarvesterCutLengthEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.index = streamReadUIntN(p6, WoodHarvester.NUM_BITS_CUT_LENGTH)
	p5:run(p7)
end
function WoodHarvesterCutLengthEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteUIntN(p9, p8.index, WoodHarvester.NUM_BITS_CUT_LENGTH)
end
function WoodHarvesterCutLengthEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(p10, false, p11, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setWoodHarvesterCutLengthIndex(p10.index, true)
	end
end
function WoodHarvesterCutLengthEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(WoodHarvesterCutLengthEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(WoodHarvesterCutLengthEvent.new(p12, p13))
	end
end

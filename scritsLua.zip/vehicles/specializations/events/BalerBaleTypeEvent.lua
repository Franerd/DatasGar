BalerBaleTypeEvent = {}
BalerBaleTypeEvent.BALE_TYPE_SEND_NUM_BITS = 4
BalerBaleTypeEvent.MAX_NUM_BALE_TYPES = 2 ^ BalerBaleTypeEvent.BALE_TYPE_SEND_NUM_BITS - 1
local v_u_1 = Class(BalerBaleTypeEvent, Event)
InitStaticEventClass(BalerBaleTypeEvent, "BalerBaleTypeEvent")
function BalerBaleTypeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function BalerBaleTypeEvent.new(p2, p3, p4)
	local v5 = BalerBaleTypeEvent.emptyNew()
	v5.object = p2
	v5.baleTypeIndex = p3
	v5.force = p4
	return v5
end
function BalerBaleTypeEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.baleTypeIndex = streamReadUIntN(p7, BalerBaleTypeEvent.BALE_TYPE_SEND_NUM_BITS)
	p6.force = streamReadBool(p7)
	p6:run(p8)
end
function BalerBaleTypeEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteUIntN(p10, p9.baleTypeIndex, BalerBaleTypeEvent.BALE_TYPE_SEND_NUM_BITS)
	streamWriteBool(p10, Utils.getNoNil(p9.force, false))
end
function BalerBaleTypeEvent.run(p11, p12)
	if not p12:getIsServer() then
		g_server:broadcastEvent(p11, false, p12, p11.object)
	end
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setBaleTypeIndex(p11.baleTypeIndex, p11.force, true)
	end
end
function BalerBaleTypeEvent.sendEvent(p13, p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(BalerBaleTypeEvent.new(p13, p14, p15), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(BalerBaleTypeEvent.new(p13, p14, p15))
	end
end

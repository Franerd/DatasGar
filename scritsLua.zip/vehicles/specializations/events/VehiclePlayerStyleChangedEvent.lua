VehiclePlayerStyleChangedEvent = {}
local v_u_1 = Class(VehiclePlayerStyleChangedEvent, Event)
InitStaticEventClass(VehiclePlayerStyleChangedEvent, "VehiclePlayerStyleChangedEvent")
function VehiclePlayerStyleChangedEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehiclePlayerStyleChangedEvent.new(p2, p3)
	local v4 = VehiclePlayerStyleChangedEvent.emptyNew()
	v4.vehicle = p2
	v4.playerStyle = p3
	return v4
end
function VehiclePlayerStyleChangedEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.playerStyle = PlayerStyle.new()
	p5.playerStyle:readStream(p6, p7)
	if p5.vehicle ~= nil and p5.vehicle:getIsSynchronized() then
		p5.vehicle:setVehicleCharacter(p5.playerStyle)
	end
end
function VehiclePlayerStyleChangedEvent.writeStream(p8, p9, p10)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	p8.playerStyle:writeStream(p9, p10)
end
function VehiclePlayerStyleChangedEvent.run(_, _) end

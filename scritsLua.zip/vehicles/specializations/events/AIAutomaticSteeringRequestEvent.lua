AIAutomaticSteeringRequestEvent = {}
local v_u_1 = Class(AIAutomaticSteeringRequestEvent, Event)
InitStaticEventClass(AIAutomaticSteeringRequestEvent, "AIAutomaticSteeringRequestEvent")
function AIAutomaticSteeringRequestEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AIAutomaticSteeringRequestEvent.new(p2, p3, p4, p5)
	local v6 = AIAutomaticSteeringRequestEvent.emptyNew()
	v6.vehicle = p2
	v6.x = p3
	v6.z = p4
	v6.fieldCourseSettings = p5
	return v6
end
function AIAutomaticSteeringRequestEvent.readStream(p7, p8, p9)
	p7.vehicle = NetworkUtil.readNodeObject(p8)
	local v10, v11 = g_fieldCourseManager:readTerrainDetailPixel(p8)
	p7.x = v10
	p7.z = v11
	local v12 = FieldCourseSettings.readStream(p8, p9)
	p7.fieldCourseSettings = FieldCourseSettings.new(p7.vehicle)
	p7.fieldCourseSettings:applyAttributes(v12)
	p7:run(p9)
end
function AIAutomaticSteeringRequestEvent.writeStream(p13, p14, p15)
	NetworkUtil.writeNodeObject(p14, p13.vehicle)
	g_fieldCourseManager:writeTerrainDetailPixel(p14, p13.x, p13.z)
	p13.fieldCourseSettings:writeStream(p14, p15)
end
function AIAutomaticSteeringRequestEvent.run(p_u_16, _)
	g_fieldCourseManager:generateFieldCourseAtWorldPos(p_u_16.x, p_u_16.z, p_u_16.fieldCourseSettings, function(_, p17)
		-- upvalues: (copy) p_u_16
		if p17 == nil then
			Logging.devInfo("Failed to generate field course for AISteering")
			p_u_16.vehicle:setAIAutomaticSteeringCourse(nil)
		else
			local v18 = SteeringFieldCourse.new(p17)
			p_u_16.vehicle:setAIAutomaticSteeringCourse(v18)
		end
	end)
end

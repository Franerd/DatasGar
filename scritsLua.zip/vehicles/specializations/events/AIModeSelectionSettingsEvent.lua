AIModeSelectionSettingsEvent = {}
local v_u_1 = Class(AIModeSelectionSettingsEvent, Event)
InitStaticEventClass(AIModeSelectionSettingsEvent, "AIModeSelectionSettingsEvent")
function AIModeSelectionSettingsEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AIModeSelectionSettingsEvent.new(p2, p3)
	local v4 = AIModeSelectionSettingsEvent.emptyNew()
	v4.vehicle = p2
	v4.fieldCourseSettings = p3
	return v4
end
function AIModeSelectionSettingsEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	local v8 = FieldCourseSettings.readStream(p6, p7)
	p5.fieldCourseSettings = FieldCourseSettings.new(p5.vehicle)
	p5.fieldCourseSettings:applyAttributes(v8)
	p5:run(p7)
end
function AIModeSelectionSettingsEvent.writeStream(p9, p10, p11)
	NetworkUtil.writeNodeObject(p10, p9.vehicle)
	p9.fieldCourseSettings:writeStream(p10, p11)
end
function AIModeSelectionSettingsEvent.run(p12, p13)
	if p12.vehicle ~= nil and p12.vehicle:getIsSynchronized() then
		p12.vehicle:setAIModeFieldCourseSettings(p12.fieldCourseSettings)
	end
	if not p13:getIsServer() then
		g_server:broadcastEvent(AIModeSelectionSettingsEvent.new(p12.vehicle, p12.fieldCourseSettings), nil, p13, p12.vehicle)
	end
end
function AIModeSelectionSettingsEvent.sendEvent(p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(AIModeSelectionSettingsEvent.new(p14, p15), nil, nil, p14)
			return
		end
		g_client:getServerConnection():sendEvent(AIModeSelectionSettingsEvent.new(p14, p15))
	end
end

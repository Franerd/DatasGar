SetCruiseControlSpeedEvent = {}
local v_u_1 = Class(SetCruiseControlSpeedEvent, Event)
InitStaticEventClass(SetCruiseControlSpeedEvent, "SetCruiseControlSpeedEvent")
function SetCruiseControlSpeedEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function SetCruiseControlSpeedEvent.new(p2, p3, p4)
	local v5 = SetCruiseControlSpeedEvent.emptyNew()
	v5.speed = p3
	v5.speedReverse = p4
	v5.vehicle = p2
	return v5
end
function SetCruiseControlSpeedEvent.readStream(p6, p7, p8)
	p6.vehicle = NetworkUtil.readNodeObject(p7)
	p6.speed = streamReadUInt8(p7)
	p6.speedReverse = streamReadUInt8(p7)
	p6:run(p8)
end
function SetCruiseControlSpeedEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.vehicle)
	streamWriteUInt8(p10, p9.speed)
	streamWriteUInt8(p10, p9.speedReverse)
end
function SetCruiseControlSpeedEvent.run(p11, p12)
	if not p12:getIsServer() then
		g_server:broadcastEvent(p11, false, p12, p11.vehicle)
	end
	if p11.vehicle ~= nil and p11.vehicle:getIsSynchronized() then
		p11.vehicle:setCruiseControlMaxSpeed(p11.speed, p11.speedReverse)
	end
end

BaleWrapperStateEvent = {}
local v_u_1 = Class(BaleWrapperStateEvent, Event)
InitStaticEventClass(BaleWrapperStateEvent, "BaleWrapperStateEvent")
function BaleWrapperStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function BaleWrapperStateEvent.new(p2, p3, p4)
	local v5 = BaleWrapperStateEvent.emptyNew()
	v5.object = p2
	v5.stateId = p3
	local v6 = p4 ~= nil and true or v5.stateId ~= BaleWrapper.CHANGE_GRAB_BALE
	assert(v6)
	v5.nearestBaleServerId = p4
	return v5
end
function BaleWrapperStateEvent.readStream(p7, p8, p9)
	p7.object = NetworkUtil.readNodeObject(p8)
	p7.stateId = streamReadInt8(p8)
	if p7.stateId == BaleWrapper.CHANGE_GRAB_BALE then
		p7.nearestBaleServerId = NetworkUtil.readNodeObjectId(p8)
	end
	p7:run(p9)
end
function BaleWrapperStateEvent.writeStream(p10, p11, _)
	NetworkUtil.writeNodeObject(p11, p10.object)
	streamWriteInt8(p11, p10.stateId)
	if p10.stateId == BaleWrapper.CHANGE_GRAB_BALE then
		NetworkUtil.writeNodeObjectId(p11, p10.nearestBaleServerId)
	end
end
function BaleWrapperStateEvent.run(p12, _)
	if p12.object ~= nil and p12.object:getIsSynchronized() then
		p12.object:doStateChange(p12.stateId, p12.nearestBaleServerId)
	end
end

TreeAttachResponseEvent = {}
TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_DEFAULT = 0
TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_TOO_HEAVY = 1
TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_TOO_MANY = 2
TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_NUM_BITS = 3
local v_u_1 = Class(TreeAttachResponseEvent, Event)
InitStaticEventClass(TreeAttachResponseEvent, "TreeAttachResponseEvent")
function TreeAttachResponseEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TreeAttachResponseEvent.new(p2, p3, p4)
	local v5 = TreeAttachResponseEvent.emptyNew()
	v5.object = p2
	v5.failedReason = p3
	v5.ropeIndex = p4
	return v5
end
function TreeAttachResponseEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.failedReason = streamReadUIntN(p7, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_NUM_BITS)
	if streamReadBool(p7) then
		p6.ropeIndex = streamReadUIntN(p7, 3)
	end
	p6:run(p8)
end
function TreeAttachResponseEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteUIntN(p10, p9.failedReason, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_NUM_BITS)
	if streamWriteBool(p10, p9.ropeIndex ~= nil) then
		streamWriteUIntN(p10, p9.ropeIndex, 3)
	end
end
function TreeAttachResponseEvent.run(p11, _)
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		if p11.object.showCarriageTreeMountFailedWarning ~= nil then
			p11.object:showCarriageTreeMountFailedWarning(p11.ropeIndex, p11.failedReason)
			return
		end
		if p11.object.showWinchTreeMountFailedWarning ~= nil then
			p11.object:showWinchTreeMountFailedWarning(p11.ropeIndex, p11.failedReason)
		end
	end
end

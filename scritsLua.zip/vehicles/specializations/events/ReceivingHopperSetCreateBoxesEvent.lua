ReceivingHopperSetCreateBoxesEvent = {}
local v_u_1 = Class(ReceivingHopperSetCreateBoxesEvent, Event)
InitStaticEventClass(ReceivingHopperSetCreateBoxesEvent, "ReceivingHopperSetCreateBoxesEvent")
function ReceivingHopperSetCreateBoxesEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function ReceivingHopperSetCreateBoxesEvent.new(p2, p3)
	local v4 = ReceivingHopperSetCreateBoxesEvent.emptyNew()
	v4.object = p2
	v4.state = p3
	return v4
end
function ReceivingHopperSetCreateBoxesEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.state = streamReadBool(p6)
	p5:run(p7)
end
function ReceivingHopperSetCreateBoxesEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteBool(p9, p8.state)
end
function ReceivingHopperSetCreateBoxesEvent.run(p10, p11)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setCreateBoxes(p10.state, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(ReceivingHopperSetCreateBoxesEvent.new(p10.object, p10.state), nil, p11, p10.object)
	end
end
function ReceivingHopperSetCreateBoxesEvent.sendEvent(p12, p13, p14)
	if p13 ~= p12.state and (p14 == nil or p14 == false) then
		if g_server ~= nil then
			g_server:broadcastEvent(ReceivingHopperSetCreateBoxesEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(ReceivingHopperSetCreateBoxesEvent.new(p12, p13))
	end
end

MotorStateEvent = {}
local v_u_1 = Class(MotorStateEvent, Event)
InitStaticEventClass(MotorStateEvent, "MotorStateEvent")
function MotorStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function MotorStateEvent.new(p2, p3)
	local v4 = MotorStateEvent.emptyNew()
	v4.vehicle = p2
	v4.motorState = p3
	return v4
end
function MotorStateEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.motorState = MotorState.readStream(p6)
	p5:run(p7)
end
function MotorStateEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	MotorState.writeStream(p9, p8.motorState)
end
function MotorStateEvent.run(p10, p11)
	local v12 = p10.vehicle
	if v12 ~= nil and v12:getIsSynchronized() then
		v12:setMotorState(p10.motorState, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(MotorStateEvent.new(p10.vehicle, p10.motorState), nil, p11, p10.vehicle)
	end
end
function MotorStateEvent.sendEvent(p13, p14, p15)
	if p15 == nil or p15 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(MotorStateEvent.new(p13, p14), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(MotorStateEvent.new(p13, p14))
	end
end

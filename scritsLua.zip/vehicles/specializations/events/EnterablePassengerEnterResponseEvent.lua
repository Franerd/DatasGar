EnterablePassengerEnterResponseEvent = {}
local v_u_1 = Class(EnterablePassengerEnterResponseEvent, Event)
InitStaticEventClass(EnterablePassengerEnterResponseEvent, "EnterablePassengerEnterResponseEvent")
function EnterablePassengerEnterResponseEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function EnterablePassengerEnterResponseEvent.new(p2, p3, p4, p5)
	local v6 = EnterablePassengerEnterResponseEvent.emptyNew()
	v6.id = p2
	v6.isOwner = p3
	v6.seatIndex = p4
	v6.userId = p5
	return v6
end
function EnterablePassengerEnterResponseEvent.readStream(p7, p8, p9)
	p7.id = NetworkUtil.readNodeObjectId(p8)
	p7.isOwner = streamReadBool(p8)
	p7.seatIndex = streamReadUIntN(p8, EnterablePassenger.SEAT_INDEX_SEND_NUM_BITS) + 1
	p7.userId = User.streamReadUserId(p8)
	p7:run(p9)
end
function EnterablePassengerEnterResponseEvent.writeStream(p10, p11, _)
	NetworkUtil.writeNodeObjectId(p11, p10.id)
	streamWriteBool(p11, p10.isOwner)
	local v12 = streamWriteUIntN
	local v13 = p10.seatIndex - 1
	local v14 = 2 ^ EnterablePassenger.SEAT_INDEX_SEND_NUM_BITS - 1
	v12(p11, math.clamp(v13, 0, v14), EnterablePassenger.SEAT_INDEX_SEND_NUM_BITS)
	User.streamWriteUserId(p11, p10.userId)
end
function EnterablePassengerEnterResponseEvent.run(p15, _)
	local v16 = NetworkUtil.getObject(p15.id)
	if v16 ~= nil and v16:getIsSynchronized() then
		local v17 = g_currentMission.userManager:getUniqueUserIdByUserId(p15.userId)
		local v18 = nil
		for _, v19 in pairs(g_currentMission.playerSystem.players) do
			if v19.uniqueUserId == v17 then
				v18 = v19
				break
			end
		end
		v18:onEnterVehicleAsPassenger(v16, p15.seatIndex)
	end
end

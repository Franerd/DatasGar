SetSeedIndexEvent = {}
local v_u_1 = Class(SetSeedIndexEvent, Event)
InitStaticEventClass(SetSeedIndexEvent, "SetSeedIndexEvent")
function SetSeedIndexEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function SetSeedIndexEvent.new(p2, p3)
	local v4 = SetSeedIndexEvent.emptyNew()
	v4.object = p2
	v4.seedIndex = p3
	return v4
end
function SetSeedIndexEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.seedIndex = streamReadUInt8(p6)
	p5:run(p7)
end
function SetSeedIndexEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteUInt8(p9, p8.seedIndex)
end
function SetSeedIndexEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(p10, false, p11, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setSeedIndex(p10.seedIndex, true)
	end
end
function SetSeedIndexEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(SetSeedIndexEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(SetSeedIndexEvent.new(p12, p13))
	end
end

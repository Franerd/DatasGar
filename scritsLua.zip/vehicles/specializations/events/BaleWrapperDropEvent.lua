BaleWrapperDropEvent = {}
local v_u_1 = Class(BaleWrapperDropEvent, Event)
InitStaticEventClass(BaleWrapperDropEvent, "BaleWrapperDropEvent")
function BaleWrapperDropEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function BaleWrapperDropEvent.new(p2, p3, _)
	local v4 = BaleWrapperDropEvent.emptyNew()
	v4.object = p2
	v4.dropAnimationIndex = p3
	return v4
end
function BaleWrapperDropEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.dropAnimationIndex = streamReadUIntN(p6, 4)
	p5:run(p7)
end
function BaleWrapperDropEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteUIntN(p9, p8.dropAnimationIndex, 4)
end
function BaleWrapperDropEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(p10, false, nil, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setBaleWrapperDropAnimation(p10.dropAnimationIndex)
		p10.object:doStateChange(BaleWrapper.CHANGE_WRAPPER_START_DROP_BALE, nil)
	end
end

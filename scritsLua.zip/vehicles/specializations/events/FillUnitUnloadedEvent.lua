FillUnitUnloadedEvent = {}
local v_u_1 = Class(FillUnitUnloadedEvent, Event)
InitStaticEventClass(FillUnitUnloadedEvent, "FillUnitUnloadedEvent")
function FillUnitUnloadedEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function FillUnitUnloadedEvent.new(p2, p3)
	local v4 = FillUnitUnloadedEvent.emptyNew()
	v4.object = p2
	v4.pallet = p3
	return v4
end
function FillUnitUnloadedEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	if streamReadBool(p6) then
		p5.pallet = NetworkUtil.readNodeObject(p6)
		local v8 = g_currentMission.vehicleXZPosHighPrecisionCompressionParams
		local v9 = g_currentMission.vehicleYPosHighPrecisionCompressionParams
		p5.x = NetworkUtil.readCompressedWorldPosition(p6, v8)
		p5.y = NetworkUtil.readCompressedWorldPosition(p6, v9)
		p5.z = NetworkUtil.readCompressedWorldPosition(p6, v8)
		local v10 = NetworkUtil.readCompressedAngle(p6)
		local v11 = NetworkUtil.readCompressedAngle(p6)
		local v12 = NetworkUtil.readCompressedAngle(p6)
		local v13, v14, v15, v16 = mathEulerToQuaternion(v10, v11, v12)
		p5.qx = v13
		p5.qy = v14
		p5.qz = v15
		p5.qw = v16
	else
		p5.showWarning = true
	end
	p5:run(p7)
end
function FillUnitUnloadedEvent.writeStream(p17, p18, _)
	NetworkUtil.writeNodeObject(p18, p17.object)
	if streamWriteBool(p18, p17.pallet ~= nil) then
		NetworkUtil.writeNodeObject(p18, p17.pallet)
		local v19 = g_currentMission.vehicleXZPosHighPrecisionCompressionParams
		local v20 = g_currentMission.vehicleYPosHighPrecisionCompressionParams
		local v21 = p17.pallet.components[1]
		local v22, v23, v24 = getWorldTranslation(v21.node)
		local v25, v26, v27 = getWorldRotation(v21.node)
		NetworkUtil.writeCompressedWorldPosition(p18, v22, v19)
		NetworkUtil.writeCompressedWorldPosition(p18, v23, v20)
		NetworkUtil.writeCompressedWorldPosition(p18, v24, v19)
		NetworkUtil.writeCompressedAngle(p18, v25)
		NetworkUtil.writeCompressedAngle(p18, v26)
		NetworkUtil.writeCompressedAngle(p18, v27)
	end
end
function FillUnitUnloadedEvent.run(p28, _)
	if p28.object ~= nil and p28.object:getIsSynchronized() then
		if p28.pallet ~= nil and p28.pallet:getIsSynchronized() then
			if p28.pallet.unmount ~= nil then
				p28.pallet:unmount()
			end
			p28.pallet:setWorldPositionQuaternion(p28.x, p28.y, p28.z, p28.qx, p28.qy, p28.qz, p28.qw, 1, true)
			SpecializationUtil.raiseEvent(p28.object, "onFillUnitUnloadPallet", p28.pallet)
			return
		end
		if p28.showWarning then
			g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, g_i18n:getText("fillUnit_unload_nospace"))
		end
	end
end

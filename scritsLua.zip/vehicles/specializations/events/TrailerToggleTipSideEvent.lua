TrailerToggleTipSideEvent = {}
local v_u_1 = Class(TrailerToggleTipSideEvent, Event)
InitStaticEventClass(TrailerToggleTipSideEvent, "TrailerToggleTipSideEvent")
function TrailerToggleTipSideEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TrailerToggleTipSideEvent.new(p2, p3)
	local v4 = TrailerToggleTipSideEvent.emptyNew()
	v4.object = p2
	v4.tipSideIndex = p3
	return v4
end
function TrailerToggleTipSideEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.tipSideIndex = streamReadUIntN(p6, Trailer.TIP_SIDE_NUM_BITS)
	p5:run(p7)
end
function TrailerToggleTipSideEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteUIntN(p9, p8.tipSideIndex, Trailer.TIP_SIDE_NUM_BITS)
end
function TrailerToggleTipSideEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(p10, false, p11, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setPreferedTipSide(p10.tipSideIndex, true)
	end
end

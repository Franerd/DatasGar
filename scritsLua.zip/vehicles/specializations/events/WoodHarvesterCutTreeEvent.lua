WoodHarvesterCutTreeEvent = {}
local v_u_1 = Class(WoodHarvesterCutTreeEvent, Event)
InitStaticEventClass(WoodHarvesterCutTreeEvent, "WoodHarvesterCutTreeEvent")
function WoodHarvesterCutTreeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function WoodHarvesterCutTreeEvent.new(p2, p3)
	local v4 = WoodHarvesterCutTreeEvent.emptyNew()
	v4.object = p2
	v4.length = p3
	return v4
end
function WoodHarvesterCutTreeEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.length = streamReadFloat32(p6)
	p5:run(p7)
end
function WoodHarvesterCutTreeEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteFloat32(p9, p8.length)
end
function WoodHarvesterCutTreeEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(WoodHarvesterCutTreeEvent.new(p10.object, p10.length), nil, p11, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:cutTree(p10.length, true)
	end
end
function WoodHarvesterCutTreeEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(WoodHarvesterCutTreeEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(WoodHarvesterCutTreeEvent.new(p12, p13))
	end
end

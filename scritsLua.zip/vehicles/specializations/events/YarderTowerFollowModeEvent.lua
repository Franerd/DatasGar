YarderTowerFollowModeEvent = {}
local v_u_1 = Class(YarderTowerFollowModeEvent, Event)
InitStaticEventClass(YarderTowerFollowModeEvent, "YarderTowerFollowModeEvent")
function YarderTowerFollowModeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function YarderTowerFollowModeEvent.new(p2, p3)
	local v4 = YarderTowerFollowModeEvent.emptyNew()
	v4.object = p2
	v4.state = p3
	return v4
end
function YarderTowerFollowModeEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.state = streamReadUIntN(p6, 2)
	p5:run(p7)
end
function YarderTowerFollowModeEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteUIntN(p9, p8.state, 2)
end
function YarderTowerFollowModeEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(p10, false, p11, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setYarderCarriageFollowMode(p10.state, p11, true)
	end
end
function YarderTowerFollowModeEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(YarderTowerFollowModeEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(YarderTowerFollowModeEvent.new(p12, p13))
	end
end

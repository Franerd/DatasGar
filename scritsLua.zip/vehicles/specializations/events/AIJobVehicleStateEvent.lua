AIJobVehicleStateEvent = {}
local v_u_1 = Class(AIJobVehicleStateEvent, Event)
InitStaticEventClass(AIJobVehicleStateEvent, "AIJobVehicleStateEvent")
function AIJobVehicleStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AIJobVehicleStateEvent.new(p2, p3, p4, p5)
	local v6 = AIJobVehicleStateEvent.emptyNew()
	v6.vehicle = p2
	v6.job = p3
	v6.helperIndex = p4
	v6.startedFarmId = p5
	return v6
end
function AIJobVehicleStateEvent.readStream(p7, p8, p9)
	p7.vehicle = NetworkUtil.readNodeObject(p8)
	if streamReadBool(p8) then
		local v10 = streamReadInt32(p8)
		p7.job = g_currentMission.aiSystem:getJobById(v10)
		p7.startedFarmId = streamReadUIntN(p8, FarmManager.FARM_ID_SEND_NUM_BITS)
		p7.helperIndex = streamReadUInt8(p8)
	end
	p7:run(p9)
end
function AIJobVehicleStateEvent.writeStream(p11, p12, p13)
	local v14 = not p13:getIsServer()
	assert(v14, "AIJobVehicleStateEvent is a server to client event only")
	NetworkUtil.writeNodeObject(p12, p11.vehicle)
	if streamWriteBool(p12, p11.job ~= nil) then
		streamWriteInt32(p12, p11.job.jobId)
		streamWriteUIntN(p12, p11.startedFarmId, FarmManager.FARM_ID_SEND_NUM_BITS)
		streamWriteUInt8(p12, p11.helperIndex)
	end
end
function AIJobVehicleStateEvent.run(p15, _)
	if p15.vehicle ~= nil and (p15.vehicle ~= nil and p15.vehicle:getIsSynchronized()) then
		if p15.job ~= nil then
			p15.vehicle:aiJobStarted(p15.job, p15.helperIndex, p15.startedFarmId)
			return
		end
		p15.vehicle:aiJobFinished()
	end
end

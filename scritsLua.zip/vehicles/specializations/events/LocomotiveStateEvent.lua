LocomotiveStateEvent = {}
local v_u_1 = Class(LocomotiveStateEvent, Event)
InitStaticEventClass(LocomotiveStateEvent, "LocomotiveStateEvent")
function LocomotiveStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function LocomotiveStateEvent.new(p2, p3)
	local v4 = LocomotiveStateEvent.emptyNew()
	v4.object = p2
	v4.state = p3
	return v4
end
function LocomotiveStateEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.state = streamReadUIntN(p6, Locomotive.NUM_BITS_STATE)
	p5:run(p7)
end
function LocomotiveStateEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteUIntN(p9, p8.state, Locomotive.NUM_BITS_STATE)
end
function LocomotiveStateEvent.run(p10, _)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setLocomotiveState(p10.state, true)
	end
end

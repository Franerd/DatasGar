InlineWrapperPushOffEvent = {}
local v_u_1 = Class(InlineWrapperPushOffEvent, Event)
InitStaticEventClass(InlineWrapperPushOffEvent, "InlineWrapperPushOffEvent")
function InlineWrapperPushOffEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function InlineWrapperPushOffEvent.new(p2)
	local v3 = InlineWrapperPushOffEvent.emptyNew()
	v3.inlineWrapper = p2
	return v3
end
function InlineWrapperPushOffEvent.readStream(p4, p5, p6)
	if not p6:getIsServer() then
		p4.inlineWrapper = NetworkUtil.readNodeObject(p5)
	end
	p4:run(p6)
end
function InlineWrapperPushOffEvent.writeStream(p7, p8, p9)
	if p9:getIsServer() then
		NetworkUtil.writeNodeObject(p8, p7.inlineWrapper)
	end
end
function InlineWrapperPushOffEvent.run(p10, p11)
	if not p11:getIsServer() and (p10.inlineWrapper ~= nil and p10.inlineWrapper:getIsSynchronized()) then
		p10.inlineWrapper:pushOffInlineBale()
	end
end

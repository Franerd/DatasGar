TreePlanterTreeTypeEvent = {}
local v_u_1 = Class(TreePlanterTreeTypeEvent, Event)
InitStaticEventClass(TreePlanterTreeTypeEvent, "TreePlanterTreeTypeEvent")
function TreePlanterTreeTypeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TreePlanterTreeTypeEvent.new(p2, p3, p4)
	local v5 = TreePlanterTreeTypeEvent.emptyNew()
	v5.object = p2
	v5.treeTypeIndex = p3
	v5.treeVariationIndex = p4
	return v5
end
function TreePlanterTreeTypeEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.treeTypeIndex = streamReadUInt32(p7)
	p6.treeVariationIndex = streamReadUIntN(p7, TreePlantManager.VARIATION_NUM_BITS)
	p6:run(p8)
end
function TreePlanterTreeTypeEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteUInt32(p10, p9.treeTypeIndex)
	streamWriteUIntN(p10, p9.treeVariationIndex or 1, TreePlantManager.VARIATION_NUM_BITS)
end
function TreePlanterTreeTypeEvent.run(p11, p12)
	if not p12:getIsServer() then
		g_server:broadcastEvent(p11, false, p12, p11.object)
	end
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setTreePlanterTreeTypeIndex(p11.treeTypeIndex, p11.treeVariationIndex, true)
	end
end
function TreePlanterTreeTypeEvent.sendEvent(p13, p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(TreePlanterTreeTypeEvent.new(p13, p14, p15), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(TreePlanterTreeTypeEvent.new(p13, p14, p15))
	end
end

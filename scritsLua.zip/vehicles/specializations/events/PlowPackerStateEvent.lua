PlowPackerStateEvent = {}
local v_u_1 = Class(PlowPackerStateEvent, Event)
InitStaticEventClass(PlowPackerStateEvent, "PlowPackerStateEvent")
function PlowPackerStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function PlowPackerStateEvent.new(p2, p3, p4)
	local v5 = PlowPackerStateEvent.emptyNew()
	v5.object = p2
	v5.state = p3
	v5.updateAnimations = p4
	return v5
end
function PlowPackerStateEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.state = streamReadBool(p7)
	p6.updateAnimations = streamReadBool(p7)
	p6:run(p8)
end
function PlowPackerStateEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteBool(p10, p9.state)
	streamWriteBool(p10, p9.updateAnimations)
end
function PlowPackerStateEvent.run(p11, p12)
	if not p12:getIsServer() then
		g_server:broadcastEvent(p11, false, p12, p11.object)
	end
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setPackerState(p11.state, p11.updateAnimations, true)
	end
end
function PlowPackerStateEvent.sendEvent(p13, p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(PlowPackerStateEvent.new(p13, p14, p15), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(PlowPackerStateEvent.new(p13, p14, p15))
	end
end

AISetModeEvent = {}
local v_u_1 = Class(AISetModeEvent, Event)
InitStaticEventClass(AISetModeEvent, "AISetModeEvent")
function AISetModeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AISetModeEvent.new(p2, p3)
	local v4 = AISetModeEvent.emptyNew()
	v4.vehicle = p2
	v4.aiMode = p3
	return v4
end
function AISetModeEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.aiMode = streamReadUIntN(p6, AIModeSelection.NUM_BITS) + 1
	p5:run(p7)
end
function AISetModeEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	streamWriteUIntN(p9, p8.aiMode - 1, AIModeSelection.NUM_BITS)
end
function AISetModeEvent.run(p10, p11)
	if p10.vehicle ~= nil and p10.vehicle:getIsSynchronized() then
		p10.vehicle:setAIModeSelection(p10.aiMode, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(AISetModeEvent.new(p10.vehicle, p10.aiMode), nil, p11, p10.vehicle)
	end
end
function AISetModeEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(AISetModeEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(AISetModeEvent.new(p12, p13))
	end
end

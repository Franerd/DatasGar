VehicleSetLightEvent = {}
local v_u_1 = Class(VehicleSetLightEvent, Event)
InitStaticEventClass(VehicleSetLightEvent, "VehicleSetLightEvent")
function VehicleSetLightEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleSetLightEvent.new(p2, p3, p4)
	local v5 = VehicleSetLightEvent.emptyNew()
	v5.object = p2
	v5.lightsTypesMask = p3
	v5.numBits = p4
	return v5
end
function VehicleSetLightEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.numBits = streamReadUIntN(p7, 5)
	p6.lightsTypesMask = streamReadUIntN(p7, p6.numBits)
	p6:run(p8)
end
function VehicleSetLightEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteUIntN(p10, p9.numBits, 5)
	streamWriteUIntN(p10, p9.lightsTypesMask, p9.numBits)
end
function VehicleSetLightEvent.run(p11, p12)
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setLightsTypesMask(p11.lightsTypesMask, true, true)
	end
	if not p12:getIsServer() then
		g_server:broadcastEvent(VehicleSetLightEvent.new(p11.object, p11.lightsTypesMask, p11.numBits), nil, p12, p11.object)
	end
end

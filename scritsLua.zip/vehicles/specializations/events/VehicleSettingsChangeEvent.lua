VehicleSettingsChangeEvent = {}
local v_u_1 = Class(VehicleSettingsChangeEvent, Event)
InitStaticEventClass(VehicleSettingsChangeEvent, "VehicleSettingsChangeEvent")
function VehicleSettingsChangeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleSettingsChangeEvent.new(p2, p3, _)
	local v4 = VehicleSettingsChangeEvent.emptyNew()
	v4.vehicle = p2
	v4.settings = p3
	return v4
end
function VehicleSettingsChangeEvent.readStream(_, p5, _)
	local v6 = NetworkUtil.readNodeObject(p5)
	local v7 = streamReadUInt8(p5)
	local v8
	if v6 == nil then
		v8 = false
	else
		v8 = v6:getIsSynchronized()
	end
	for _ = 1, v7 do
		local v9 = streamReadUInt8(p5)
		local v10
		if streamReadBool(p5) then
			v10 = streamReadBool(p5)
		else
			v10 = streamReadUInt8(p5)
		end
		if v8 then
			v6:setVehicleSettingState(v9, v10, true)
		end
	end
end
function VehicleSettingsChangeEvent.writeStream(p11, p12, _)
	NetworkUtil.writeNodeObject(p12, p11.vehicle)
	local v13 = 0
	for v14 = 1, #p11.settings do
		if p11.settings[v14].isDirty then
			v13 = v13 + 1
		end
	end
	streamWriteUInt8(p12, v13)
	for v15 = 1, #p11.settings do
		local v16 = p11.settings[v15]
		if v16.isDirty then
			streamWriteUInt8(p12, v16.index)
			if streamWriteBool(p12, v16.isBool) then
				streamWriteBool(p12, v16.state)
			else
				streamWriteUInt8(p12, v16.state)
			end
			v16.isDirty = false
		end
	end
end
function VehicleSettingsChangeEvent.run(_, _) end

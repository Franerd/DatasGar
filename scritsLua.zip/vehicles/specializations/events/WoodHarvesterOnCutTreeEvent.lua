WoodHarvesterOnCutTreeEvent = {}
local v_u_1 = Class(WoodHarvesterOnCutTreeEvent, Event)
InitStaticEventClass(WoodHarvesterOnCutTreeEvent, "WoodHarvesterOnCutTreeEvent")
function WoodHarvesterOnCutTreeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function WoodHarvesterOnCutTreeEvent.new(p2, p3)
	local v4 = WoodHarvesterOnCutTreeEvent.emptyNew()
	v4.object = p2
	v4.radius = p3
	return v4
end
function WoodHarvesterOnCutTreeEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.radius = streamReadFloat32(p6)
	p5:run(p7)
end
function WoodHarvesterOnCutTreeEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteFloat32(p9, p8.radius)
end
function WoodHarvesterOnCutTreeEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(WoodHarvesterOnCutTreeEvent.new(p10.object, p10.radius), nil, p11, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		SpecializationUtil.raiseEvent(p10.object, "onCutTree", p10.radius)
	end
end

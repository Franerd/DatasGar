SetCoverStateEvent = {}
local v_u_1 = Class(SetCoverStateEvent, Event)
InitStaticEventClass(SetCoverStateEvent, "SetCoverStateEvent")
function SetCoverStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function SetCoverStateEvent.new(p2, p3)
	local v4 = SetCoverStateEvent.emptyNew()
	v4.vehicle = p2
	v4.state = p3
	return v4
end
function SetCoverStateEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.state = streamReadUIntN(p6, Cover.SEND_NUM_BITS)
	p5:run(p7)
end
function SetCoverStateEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	streamWriteUIntN(p9, p8.state, Cover.SEND_NUM_BITS)
end
function SetCoverStateEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(p10, false, p11, p10.vehicle)
	end
	if p10.vehicle ~= nil and (p10.vehicle ~= nil and p10.vehicle:getIsSynchronized()) then
		p10.vehicle:setCoverState(p10.state, true)
	end
end
function SetCoverStateEvent.sendEvent(p12, p13, p14)
	if p12.spec_cover.state ~= p13 and (p14 == nil or p14 == false) then
		if g_server ~= nil then
			g_server:broadcastEvent(SetCoverStateEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(SetCoverStateEvent.new(p12, p13))
	end
end

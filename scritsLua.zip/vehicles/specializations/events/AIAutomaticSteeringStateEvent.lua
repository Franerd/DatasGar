AIAutomaticSteeringStateEvent = {}
local v_u_1 = Class(AIAutomaticSteeringStateEvent, Event)
InitStaticEventClass(AIAutomaticSteeringStateEvent, "AIAutomaticSteeringStateEvent")
function AIAutomaticSteeringStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AIAutomaticSteeringStateEvent.new(p2, p3, p4, p5)
	local v6 = AIAutomaticSteeringStateEvent.emptyNew()
	v6.vehicle = p2
	v6.state = p3
	v6.segmentIndex = p4
	v6.segmentIsLeft = p5
	return v6
end
function AIAutomaticSteeringStateEvent.readStream(p7, p8, p9)
	p7.vehicle = NetworkUtil.readNodeObject(p8)
	p7.state = streamReadBool(p8)
	if streamReadBool(p8) then
		p7.segmentIndex = streamReadUInt16(p8)
		p7.segmentIsLeft = streamReadBool(p8)
	end
	p7:run(p9)
end
function AIAutomaticSteeringStateEvent.writeStream(p10, p11, _)
	NetworkUtil.writeNodeObject(p11, p10.vehicle)
	streamWriteBool(p11, p10.state)
	local v12 = streamWriteBool
	local v13
	if p10.segmentIndex == nil then
		v13 = false
	else
		v13 = p10.segmentIndex > 0
	end
	if v12(p11, v13) then
		streamWriteUInt16(p11, p10.segmentIndex)
		streamWriteBool(p11, Utils.getNoNil(p10.segmentIsLeft, false))
	end
end
function AIAutomaticSteeringStateEvent.run(p14, p15)
	if p14.vehicle ~= nil and p14.vehicle:getIsSynchronized() then
		local v16, v17 = p14.vehicle:setAIAutomaticSteeringEnabled(p14.state, p14.segmentIndex, p14.segmentIsLeft, true)
		p14.segmentIndex = v16
		p14.segmentIsLeft = v17
	end
	if not p15:getIsServer() then
		g_server:broadcastEvent(AIAutomaticSteeringStateEvent.new(p14.vehicle, p14.state, p14.segmentIndex, p14.segmentIsLeft), nil, nil, p14.vehicle)
	end
end
function AIAutomaticSteeringStateEvent.sendEvent(p18, p19, p20, p21, p22)
	if p22 == nil or p22 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(AIAutomaticSteeringStateEvent.new(p18, p19, p20, p21), nil, nil, p18)
			return
		end
		g_client:getServerConnection():sendEvent(AIAutomaticSteeringStateEvent.new(p18, p19, p20, p21))
	end
end

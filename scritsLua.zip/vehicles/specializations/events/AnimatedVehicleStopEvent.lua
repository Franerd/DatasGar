AnimatedVehicleStopEvent = {}
local v_u_1 = Class(AnimatedVehicleStopEvent, Event)
InitStaticEventClass(AnimatedVehicleStopEvent, "AnimatedVehicleStopEvent")
function AnimatedVehicleStopEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AnimatedVehicleStopEvent.new(p2, p3)
	local v4 = AnimatedVehicleStopEvent.emptyNew()
	v4.name = p3
	v4.object = p2
	return v4
end
function AnimatedVehicleStopEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.name = streamReadString(p6)
	p5:run(p7)
end
function AnimatedVehicleStopEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteString(p9, p8.name)
end
function AnimatedVehicleStopEvent.run(p10, p11)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:stopAnimation(p10.name, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(AnimatedVehicleStopEvent.new(p10.object, p10.name), nil, p11, p10.object)
	end
end

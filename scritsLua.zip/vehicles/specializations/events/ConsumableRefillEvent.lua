ConsumableRefillEvent = {}
local v_u_1 = Class(ConsumableRefillEvent, Event)
InitStaticEventClass(ConsumableRefillEvent, "ConsumableRefillEvent")
function ConsumableRefillEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function ConsumableRefillEvent.new(p2, p3, p4)
	local v5 = ConsumableRefillEvent.emptyNew()
	v5.object = p2
	v5.typeIndex = p3
	v5.variationIndex = p4
	return v5
end
function ConsumableRefillEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.typeIndex = streamReadUInt8(p7)
	p6.variationIndex = streamReadUIntN(p7, ConsumableManager.NUM_VARIATION_BITS)
	if not p8:getIsServer() then
		p6:run(p8)
	end
end
function ConsumableRefillEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteUInt8(p10, p9.typeIndex)
	streamWriteUIntN(p10, p9.variationIndex, ConsumableManager.NUM_VARIATION_BITS)
end
function ConsumableRefillEvent.run(p11, _)
	if p11.object ~= nil then
		local v12 = p11.object.spec_consumable.types[p11.typeIndex]
		v12.consumingVariationIndex = p11.variationIndex
		local v13 = p11.object:addFillUnitFillLevel(p11.object:getOwnerFarmId(), v12.fillUnitIndex, v12.numStorageSlots, p11.object:getFillUnitFirstSupportedFillType(v12.fillUnitIndex), ToolType.UNDEFINED, nil)
		p11.object:updateConsumable(v12.typeName, 0)
		local v14 = v13 + p11.object:addFillUnitFillLevel(p11.object:getOwnerFarmId(), v12.fillUnitIndex, v12.numConsumingSlots, p11.object:getFillUnitFirstSupportedFillType(v12.fillUnitIndex), ToolType.UNDEFINED, nil)
		p11.object:updateConsumable(v12.typeName, 0)
		local v15 = g_consumableManager:getConsumableVariationPriceByIndex(p11.variationIndex) * v14
		if v15 > 0 then
			g_farmManager:updateFarmStats(p11.object:getActiveFarm(), "expenses", v15)
			g_currentMission:addMoney(-v15, p11.object:getActiveFarm(), MoneyType.PURCHASE_CONSUMABLES, true)
			g_currentMission:showMoneyChange(MoneyType.PURCHASE_CONSUMABLES, nil, false, p11.object:getActiveFarm())
		end
	end
end
function ConsumableRefillEvent.sendEvent(p16, p17, p18)
	if g_server == nil then
		g_client:getServerConnection():sendEvent(ConsumableRefillEvent.new(p16, p17, p18))
	else
		g_server:broadcastEvent(ConsumableRefillEvent.new(p16, p17, p18), true, nil, p16)
	end
end

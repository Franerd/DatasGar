LogGrabClawStateEvent = {}
local v_u_1 = Class(LogGrabClawStateEvent, Event)
InitStaticEventClass(LogGrabClawStateEvent, "LogGrabClawStateEvent")
function LogGrabClawStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function LogGrabClawStateEvent.new(p2, p3, p4)
	local v5 = LogGrabClawStateEvent.emptyNew()
	v5.object = p2
	v5.state = p3
	v5.grabIndex = p4
	return v5
end
function LogGrabClawStateEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.state = streamReadBool(p7)
	p6.grabIndex = streamReadUIntN(p7, LogGrab.GRAB_INDEX_NUM_BITS)
	p6:run(p8)
end
function LogGrabClawStateEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteBool(p10, p9.state)
	streamWriteUIntN(p10, p9.grabIndex, LogGrab.GRAB_INDEX_NUM_BITS)
end
function LogGrabClawStateEvent.run(p11, p12)
	if not p12:getIsServer() then
		g_server:broadcastEvent(p11, false, p12, p11.object)
	end
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setLogGrabClawState(p11.grabIndex, p11.state, true)
	end
end
function LogGrabClawStateEvent.sendEvent(p13, p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(LogGrabClawStateEvent.new(p13, p14, p15), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(LogGrabClawStateEvent.new(p13, p14, p15))
	end
end

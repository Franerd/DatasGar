AnimatedVehicleStartEvent = {}
local v_u_1 = Class(AnimatedVehicleStartEvent, Event)
InitStaticEventClass(AnimatedVehicleStartEvent, "AnimatedVehicleStartEvent")
function AnimatedVehicleStartEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AnimatedVehicleStartEvent.new(p2, p3, p4, p5)
	local v6 = AnimatedVehicleStartEvent.emptyNew()
	v6.name = p3
	v6.speed = p4
	v6.animTime = p5
	v6.object = p2
	return v6
end
function AnimatedVehicleStartEvent.readStream(p7, p8, p9)
	p7.object = NetworkUtil.readNodeObject(p8)
	p7.name = streamReadString(p8)
	p7.speed = streamReadFloat32(p8)
	p7.animTime = streamReadFloat32(p8)
	p7:run(p9)
end
function AnimatedVehicleStartEvent.writeStream(p10, p11, _)
	NetworkUtil.writeNodeObject(p11, p10.object)
	streamWriteString(p11, p10.name)
	streamWriteFloat32(p11, p10.speed)
	streamWriteFloat32(p11, p10.animTime)
end
function AnimatedVehicleStartEvent.run(p12, p13)
	if p12.object ~= nil and p12.object:getIsSynchronized() then
		p12.object:playAnimation(p12.name, p12.speed, p12.animTime, true)
	end
	if not p13:getIsServer() then
		g_server:broadcastEvent(AnimatedVehicleStartEvent.new(p12.object, p12.name, p12.speed, p12.animTime), nil, p13, p12.object)
	end
end

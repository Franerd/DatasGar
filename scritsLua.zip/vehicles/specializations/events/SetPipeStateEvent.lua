SetPipeStateEvent = {}
local v_u_1 = Class(SetPipeStateEvent, Event)
InitStaticEventClass(SetPipeStateEvent, "SetPipeStateEvent")
function SetPipeStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function SetPipeStateEvent.new(p2, p3)
	local v4 = SetPipeStateEvent.emptyNew()
	v4.object = p2
	v4.pipeState = p3
	local v5
	if v4.pipeState >= 0 then
		v5 = v4.pipeState < 8
	else
		v5 = false
	end
	assert(v5)
	return v4
end
function SetPipeStateEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.pipeState = streamReadUIntN(p7, 3)
	p6:run(p8)
end
function SetPipeStateEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteUIntN(p10, p9.pipeState, 3)
end
function SetPipeStateEvent.run(p11, p12)
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setPipeState(p11.pipeState, true)
	end
	if not p12:getIsServer() then
		g_server:broadcastEvent(SetPipeStateEvent.new(p11.object, p11.pipeState), nil, p12, p11.object)
	end
end

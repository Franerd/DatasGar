SetDischargeStateEvent = {}
local v_u_1 = Class(SetDischargeStateEvent, Event)
InitStaticEventClass(SetDischargeStateEvent, "SetDischargeStateEvent")
function SetDischargeStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function SetDischargeStateEvent.new(p2, p3)
	local v4 = SetDischargeStateEvent.emptyNew()
	v4.vehicle = p2
	v4.state = p3
	return v4
end
function SetDischargeStateEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.state = streamReadUIntN(p6, 2)
	p5:run(p7)
end
function SetDischargeStateEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	streamWriteUIntN(p9, p8.state, 2)
end
function SetDischargeStateEvent.run(p10, p11)
	if p10.vehicle ~= nil and (p10.vehicle ~= nil and p10.vehicle:getIsSynchronized()) then
		p10.vehicle:setDischargeState(p10.state, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(SetDischargeStateEvent.new(p10.vehicle, p10.state), nil, p11, p10.vehicle)
	end
end
function SetDischargeStateEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(SetDischargeStateEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(SetDischargeStateEvent.new(p12, p13))
	end
end

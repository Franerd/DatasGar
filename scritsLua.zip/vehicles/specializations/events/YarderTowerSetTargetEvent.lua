YarderTowerSetTargetEvent = {}
local v_u_1 = Class(YarderTowerSetTargetEvent, Event)
InitStaticEventClass(YarderTowerSetTargetEvent, "YarderTowerSetTargetEvent")
function YarderTowerSetTargetEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function YarderTowerSetTargetEvent.new(p2, p3, p4, p5, p6)
	local v7 = YarderTowerSetTargetEvent.emptyNew()
	v7.object = p2
	v7.state = p3
	v7.x = p4
	v7.y = p5
	v7.z = p6
	return v7
end
function YarderTowerSetTargetEvent.readStream(p8, p9, p10)
	p8.object = NetworkUtil.readNodeObject(p9)
	p8.state = streamReadBool(p9)
	if p8.state then
		p8.x = streamReadFloat32(p9)
		p8.y = streamReadFloat32(p9)
		p8.z = streamReadFloat32(p9)
	end
	p8:run(p10)
end
function YarderTowerSetTargetEvent.writeStream(p11, p12, _)
	NetworkUtil.writeNodeObject(p12, p11.object)
	if streamWriteBool(p12, p11.state) then
		streamWriteFloat32(p12, p11.x)
		streamWriteFloat32(p12, p11.y)
		streamWriteFloat32(p12, p11.z)
	end
end
function YarderTowerSetTargetEvent.run(p13, p14)
	if not p14:getIsServer() then
		g_server:broadcastEvent(p13, false, p14, p13.object)
	end
	if p13.object ~= nil and p13.object:getIsSynchronized() then
		local v15 = p13.object.spec_yarderTower
		if p13.x ~= nil then
			v15.mainRope.isValid = true
			local v16 = v15.mainRope.target
			local v17 = v15.mainRope.target
			local v18 = v15.mainRope.target
			local v19 = p13.x
			local v20 = p13.y
			local v21 = p13.z
			v16[1] = v19
			v17[2] = v20
			v18[3] = v21
		end
		p13.object:setYarderTargetActive(p13.state, true)
	end
end
function YarderTowerSetTargetEvent.sendEvent(p22, p23, p24, p25, p26, p27)
	if p27 == nil or p27 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(YarderTowerSetTargetEvent.new(p22, p23, p24, p25, p26), nil, nil, p22)
			return
		end
		g_client:getServerConnection():sendEvent(YarderTowerSetTargetEvent.new(p22, p23, p24, p25, p26))
	end
end

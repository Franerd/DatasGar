RidgeMarkerSetStateEvent = {}
local v_u_1 = Class(RidgeMarkerSetStateEvent, Event)
InitStaticEventClass(RidgeMarkerSetStateEvent, "RidgeMarkerSetStateEvent")
function RidgeMarkerSetStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function RidgeMarkerSetStateEvent.new(p2, p3)
	local v4 = RidgeMarkerSetStateEvent.emptyNew()
	v4.vehicle = p2
	v4.state = p3
	local v5
	if p3 >= 0 then
		v5 = p3 < RidgeMarker.MAX_NUM_RIDGEMARKERS
	else
		v5 = false
	end
	assert(v5)
	return v4
end
function RidgeMarkerSetStateEvent.readStream(p6, p7, p8)
	p6.vehicle = NetworkUtil.readNodeObject(p7)
	p6.state = streamReadUIntN(p7, RidgeMarker.SEND_NUM_BITS)
	p6:run(p8)
end
function RidgeMarkerSetStateEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.vehicle)
	streamWriteUIntN(p10, p9.state, RidgeMarker.SEND_NUM_BITS)
end
function RidgeMarkerSetStateEvent.run(p11, p12)
	if p11.vehicle ~= nil and p11.vehicle:getIsSynchronized() then
		p11.vehicle:setRidgeMarkerState(p11.state, true)
	end
	if not p12:getIsServer() then
		g_server:broadcastEvent(RidgeMarkerSetStateEvent.new(p11.vehicle, p11.state), nil, p12, p11.vehicle)
	end
end
function RidgeMarkerSetStateEvent.sendEvent(p13, p14, p15)
	if p15 == nil or p15 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(RidgeMarkerSetStateEvent.new(p13, p14), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(RidgeMarkerSetStateEvent.new(p13, p14))
	end
end

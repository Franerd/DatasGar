TensionBeltsRefreshEvent = {}
local v_u_1 = Class(TensionBeltsRefreshEvent, Event)
InitStaticEventClass(TensionBeltsRefreshEvent, "TensionBeltsRefreshEvent")
function TensionBeltsRefreshEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TensionBeltsRefreshEvent.new(p2)
	local v3 = TensionBeltsRefreshEvent.emptyNew()
	v3.object = p2
	return v3
end
function TensionBeltsRefreshEvent.readStream(p4, p5, p6)
	p4.object = NetworkUtil.readNodeObject(p5)
	p4:run(p6)
end
function TensionBeltsRefreshEvent.writeStream(p7, p8, _)
	NetworkUtil.writeNodeObject(p8, p7.object)
end
function TensionBeltsRefreshEvent.run(p9, p10)
	if not p10:getIsServer() then
		g_server:broadcastEvent(p9, false, p10, p9.object)
	end
	if p9.object ~= nil and p9.object:getIsSynchronized() then
		p9.object:refreshTensionBelts()
	end
end

MotorGearShiftEvent = {}
MotorGearShiftEvent.TYPE_SHIFT_UP = 1
MotorGearShiftEvent.TYPE_SHIFT_DOWN = 2
MotorGearShiftEvent.TYPE_SELECT_GEAR = 3
MotorGearShiftEvent.TYPE_SHIFT_GROUP_UP = 4
MotorGearShiftEvent.TYPE_SHIFT_GROUP_DOWN = 5
MotorGearShiftEvent.TYPE_SELECT_GROUP = 6
MotorGearShiftEvent.TYPE_DIRECTION_CHANGE = 7
MotorGearShiftEvent.TYPE_DIRECTION_CHANGE_POS = 8
MotorGearShiftEvent.TYPE_DIRECTION_CHANGE_NEG = 9
local v_u_1 = Class(MotorGearShiftEvent, Event)
InitStaticEventClass(MotorGearShiftEvent, "MotorGearShiftEvent")
function MotorGearShiftEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function MotorGearShiftEvent.new(p2, p3, p4)
	local v5 = MotorGearShiftEvent.emptyNew()
	v5.vehicle = p2
	v5.shiftType = p3
	v5.shiftValue = p4
	return v5
end
function MotorGearShiftEvent.readStream(p6, p7, p8)
	p6.vehicle = NetworkUtil.readNodeObject(p7)
	p6.shiftType = streamReadUIntN(p7, 4)
	if p6.shiftType == MotorGearShiftEvent.TYPE_SELECT_GEAR or p6.shiftType == MotorGearShiftEvent.TYPE_SELECT_GROUP then
		p6.shiftValue = streamReadUIntN(p7, 3)
	end
	p6:run(p8)
end
function MotorGearShiftEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.vehicle)
	streamWriteUIntN(p10, p9.shiftType, 4)
	if p9.shiftType == MotorGearShiftEvent.TYPE_SELECT_GEAR or p9.shiftType == MotorGearShiftEvent.TYPE_SELECT_GROUP then
		streamWriteUIntN(p10, p9.shiftValue, 3)
	end
end
function MotorGearShiftEvent.run(p11, _)
	local v12 = p11.vehicle
	if v12 ~= nil and v12:getIsSynchronized() then
		local v13 = v12.spec_motorized
		if v13 ~= nil then
			local v14 = v12:getMotorState()
			if v14 == MotorState.STARTING or v14 == MotorState.ON then
				if p11.shiftType == MotorGearShiftEvent.TYPE_SHIFT_UP then
					v13.motor:shiftGear(true)
					return
				end
				if p11.shiftType == MotorGearShiftEvent.TYPE_SHIFT_DOWN then
					v13.motor:shiftGear(false)
					return
				end
				if p11.shiftType == MotorGearShiftEvent.TYPE_SELECT_GEAR then
					v13.motor:selectGear(p11.shiftValue, p11.shiftValue ~= 0)
					return
				end
				if p11.shiftType == MotorGearShiftEvent.TYPE_SHIFT_GROUP_UP then
					v13.motor:shiftGroup(true)
					return
				end
				if p11.shiftType == MotorGearShiftEvent.TYPE_SHIFT_GROUP_DOWN then
					v13.motor:shiftGroup(false)
					return
				end
				if p11.shiftType == MotorGearShiftEvent.TYPE_SELECT_GROUP then
					v13.motor:selectGroup(p11.shiftValue, p11.shiftValue ~= 0)
					return
				end
				if p11.shiftType == MotorGearShiftEvent.TYPE_DIRECTION_CHANGE then
					v13.motor:changeDirection()
					return
				end
				if p11.shiftType == MotorGearShiftEvent.TYPE_DIRECTION_CHANGE_POS then
					v13.motor:changeDirection(1)
					return
				end
				if p11.shiftType == MotorGearShiftEvent.TYPE_DIRECTION_CHANGE_NEG then
					v13.motor:changeDirection(-1)
				end
			end
		end
	end
end
function MotorGearShiftEvent.sendToServer(p15, p16, p17)
	if g_client ~= nil then
		g_client:getServerConnection():sendEvent(MotorGearShiftEvent.new(p15, p16, p17))
	end
end

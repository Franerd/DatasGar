TensionBeltsEvent = {}
local v_u_1 = Class(TensionBeltsEvent, Event)
InitStaticEventClass(TensionBeltsEvent, "TensionBeltsEvent")
function TensionBeltsEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TensionBeltsEvent.new(p2, p3, p4)
	local v5 = TensionBeltsEvent.emptyNew()
	v5.object = p2
	v5.isActive = p3
	v5.beltId = p4
	return v5
end
function TensionBeltsEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	if not streamReadBool(p7) then
		p6.beltId = streamReadUIntN(p7, TensionBelts.NUM_SEND_BITS) + 1
	end
	p6.isActive = streamReadBool(p7)
	p6:run(p8)
end
function TensionBeltsEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteBool(p10, p9.beltId == nil)
	if p9.beltId ~= nil then
		streamWriteUIntN(p10, p9.beltId - 1, TensionBelts.NUM_SEND_BITS)
	end
	streamWriteBool(p10, p9.isActive)
end
function TensionBeltsEvent.run(p11, p12)
	if not p12:getIsServer() then
		g_server:broadcastEvent(p11, false, p12, p11.object)
	end
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setTensionBeltsActive(p11.isActive, p11.beltId, true)
	end
end
function TensionBeltsEvent.sendEvent(p13, p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(TensionBeltsEvent.new(p13, p14, p15), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(TensionBeltsEvent.new(p13, p14, p15))
	end
end

TreePlanterCreateTreeEvent = {}
local v_u_1 = Class(TreePlanterCreateTreeEvent, Event)
InitStaticEventClass(TreePlanterCreateTreeEvent, "TreePlanterCreateTreeEvent")
function TreePlanterCreateTreeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TreePlanterCreateTreeEvent.new(p2, _, _)
	local v3 = TreePlanterCreateTreeEvent.emptyNew()
	v3.object = p2
	return v3
end
function TreePlanterCreateTreeEvent.readStream(p4, p5, p6)
	p4.object = NetworkUtil.readNodeObject(p5)
	p4:run(p6)
end
function TreePlanterCreateTreeEvent.writeStream(p7, p8, _)
	NetworkUtil.writeNodeObject(p8, p7.object)
end
function TreePlanterCreateTreeEvent.run(p9, p10)
	if not p10:getIsServer() then
		g_server:broadcastEvent(p9, false, p10, p9.object)
	end
	if p9.object ~= nil and p9.object:getIsSynchronized() then
		p9.object:createTree(true)
	end
end
function TreePlanterCreateTreeEvent.sendEvent(p11, p12)
	if p12 == nil or p12 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(TreePlanterCreateTreeEvent.new(p11), nil, nil, p11)
			return
		end
		g_client:getServerConnection():sendEvent(TreePlanterCreateTreeEvent.new(p11))
	end
end

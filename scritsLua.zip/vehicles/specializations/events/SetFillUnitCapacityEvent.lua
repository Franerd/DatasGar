SetFillUnitCapacityEvent = {}
local v_u_1 = Class(SetFillUnitCapacityEvent, Event)
InitStaticEventClass(SetFillUnitCapacityEvent, "SetFillUnitCapacityEvent")
function SetFillUnitCapacityEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function SetFillUnitCapacityEvent.new(p2, p3, p4)
	local v5 = SetFillUnitCapacityEvent.emptyNew()
	v5.vehicle = p2
	v5.fillUnitIndex = p3
	v5.capacity = p4
	return v5
end
function SetFillUnitCapacityEvent.readStream(p6, p7, p8)
	p6.vehicle = NetworkUtil.readNodeObject(p7)
	p6.fillUnitIndex = streamReadUIntN(p7, 8)
	p6.capacity = streamReadFloat32(p7)
	p6:run(p8)
end
function SetFillUnitCapacityEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.vehicle)
	streamWriteUIntN(p10, p9.fillUnitIndex, 8)
	streamWriteFloat32(p10, p9.capacity)
end
function SetFillUnitCapacityEvent.run(p11, p12)
	if p11.vehicle ~= nil and p11.vehicle:getIsSynchronized() then
		p11.vehicle:setFillUnitCapacity(p11.fillUnitIndex, p11.capacity, true)
	end
	if not p12:getIsServer() then
		g_server:broadcastEvent(SetFillUnitCapacityEvent.new(p11.vehicle, p11.fillUnitIndex, p11.capacity), nil, p12, p11.vehicle)
	end
end
function SetFillUnitCapacityEvent.sendEvent(p13, p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(SetFillUnitCapacityEvent.new(p13, p14, p15), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(SetFillUnitCapacityEvent.new(p13, p14, p15))
	end
end

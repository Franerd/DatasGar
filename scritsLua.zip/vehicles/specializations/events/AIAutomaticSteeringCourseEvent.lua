AIAutomaticSteeringCourseEvent = {}
local v_u_1 = Class(AIAutomaticSteeringCourseEvent, Event)
InitStaticEventClass(AIAutomaticSteeringCourseEvent, "AIAutomaticSteeringCourseEvent")
function AIAutomaticSteeringCourseEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AIAutomaticSteeringCourseEvent.new(p2, p3)
	local v4 = AIAutomaticSteeringCourseEvent.emptyNew()
	v4.vehicle = p2
	v4.steeringFieldCourse = p3
	return v4
end
function AIAutomaticSteeringCourseEvent.readStream(p_u_5, p6, p7)
	p_u_5.vehicle = NetworkUtil.readNodeObject(p6)
	if p_u_5.vehicle ~= nil and p_u_5.vehicle:getIsSynchronized() then
		p_u_5.vehicle:setAIAutomaticSteeringCourse(nil, true)
	end
	if streamReadBool(p6) then
		SteeringFieldCourse.readStream(p6, p7, function(p8)
			-- upvalues: (copy) p_u_5
			if p8 ~= nil and (p_u_5.vehicle ~= nil and p_u_5.vehicle:getIsSynchronized()) then
				p_u_5.vehicle:setAIAutomaticSteeringCourse(p8, true)
			end
		end)
	end
end
function AIAutomaticSteeringCourseEvent.writeStream(p9, p10, p11)
	NetworkUtil.writeNodeObject(p10, p9.vehicle)
	if streamWriteBool(p10, p9.steeringFieldCourse ~= nil) then
		p9.steeringFieldCourse:writeStream(p10, p11)
	end
end
function AIAutomaticSteeringCourseEvent.run(_, _) end

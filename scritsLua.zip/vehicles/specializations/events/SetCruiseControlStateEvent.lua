SetCruiseControlStateEvent = {}
local v_u_1 = Class(SetCruiseControlStateEvent, Event)
InitStaticEventClass(SetCruiseControlStateEvent, "SetCruiseControlStateEvent")
function SetCruiseControlStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function SetCruiseControlStateEvent.new(p2, p3)
	local v4 = SetCruiseControlStateEvent.emptyNew()
	v4.state = p3
	v4.vehicle = p2
	return v4
end
function SetCruiseControlStateEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.state = streamReadUIntN(p6, 2)
	p5:run(p7)
end
function SetCruiseControlStateEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	streamWriteUIntN(p9, p8.state, 2)
end
function SetCruiseControlStateEvent.run(p10, _)
	if p10.vehicle ~= nil and p10.vehicle:getIsSynchronized() then
		p10.vehicle:setCruiseControlState(p10.state, true)
	end
end

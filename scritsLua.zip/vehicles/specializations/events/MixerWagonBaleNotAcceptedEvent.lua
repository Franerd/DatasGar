MixerWagonBaleNotAcceptedEvent = {}
local v_u_1 = Class(MixerWagonBaleNotAcceptedEvent, Event)
InitStaticEventClass(MixerWagonBaleNotAcceptedEvent, "MixerWagonBaleNotAcceptedEvent")
function MixerWagonBaleNotAcceptedEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function MixerWagonBaleNotAcceptedEvent.new()
	return MixerWagonBaleNotAcceptedEvent.emptyNew()
end
function MixerWagonBaleNotAcceptedEvent.readStream(p2, _, p3)
	p2:run(p3)
end
function MixerWagonBaleNotAcceptedEvent.writeStream(_, _, _) end
function MixerWagonBaleNotAcceptedEvent.run(_, _)
	g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, g_i18n:getText("warning_baleNotSupported"))
end

WoodHarvesterHeaderTiltEvent = {}
local v_u_1 = Class(WoodHarvesterHeaderTiltEvent, Event)
InitStaticEventClass(WoodHarvesterHeaderTiltEvent, "WoodHarvesterHeaderTiltEvent")
function WoodHarvesterHeaderTiltEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function WoodHarvesterHeaderTiltEvent.new(p2, p3)
	local v4 = WoodHarvesterHeaderTiltEvent.emptyNew()
	v4.object = p2
	v4.state = p3
	return v4
end
function WoodHarvesterHeaderTiltEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.state = streamReadBool(p6)
	p5:run(p7)
end
function WoodHarvesterHeaderTiltEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteBool(p9, p8.state)
end
function WoodHarvesterHeaderTiltEvent.run(p10, _)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setWoodHarvesterTiltState(p10.state, true)
	end
end
function WoodHarvesterHeaderTiltEvent.sendEvent(p11, p12, p13)
	if p13 == nil or p13 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(WoodHarvesterHeaderTiltEvent.new(p11, p12), nil, nil, p11)
			return
		end
		g_client:getServerConnection():sendEvent(WoodHarvesterHeaderTiltEvent.new(p11, p12))
	end
end

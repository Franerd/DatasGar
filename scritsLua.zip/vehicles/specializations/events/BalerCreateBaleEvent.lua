BalerCreateBaleEvent = {}
local v_u_1 = Class(BalerCreateBaleEvent, Event)
InitStaticEventClass(BalerCreateBaleEvent, "BalerCreateBaleEvent")
function BalerCreateBaleEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function BalerCreateBaleEvent.new(p2, p3, p4, p5)
	local v6 = BalerCreateBaleEvent.emptyNew()
	v6.object = p2
	v6.baleFillType = p3
	v6.baleTime = p4
	v6.baleServerId = p5
	return v6
end
function BalerCreateBaleEvent.readStream(p7, p8, p9)
	p7.object = NetworkUtil.readNodeObject(p8)
	p7.baleTime = streamReadFloat32(p8)
	p7.baleFillType = streamReadUIntN(p8, FillTypeManager.SEND_NUM_BITS)
	if streamReadBool(p8) then
		p7.baleServerId = NetworkUtil.readNodeObjectId(p8)
	end
	p7:run(p9)
end
function BalerCreateBaleEvent.writeStream(p10, p11, _)
	NetworkUtil.writeNodeObject(p11, p10.object)
	streamWriteFloat32(p11, p10.baleTime)
	streamWriteUIntN(p11, p10.baleFillType, FillTypeManager.SEND_NUM_BITS)
	if streamWriteBool(p11, p10.baleServerId ~= nil) then
		NetworkUtil.writeNodeObjectId(p11, p10.baleServerId)
	end
end
function BalerCreateBaleEvent.run(p12, _)
	if p12.object ~= nil and p12.object:getIsSynchronized() then
		p12.object:createBale(p12.baleFillType, nil, p12.baleServerId)
		p12.object:setBaleTime(#p12.object.spec_baler.bales, p12.baleTime)
	end
end

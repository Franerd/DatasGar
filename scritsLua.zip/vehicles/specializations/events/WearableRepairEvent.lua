WearableRepairEvent = {}
local v_u_1 = Class(WearableRepairEvent, Event)
InitStaticEventClass(WearableRepairEvent, "WearableRepairEvent")
function WearableRepairEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function WearableRepairEvent.new(p2, p3)
	local v4 = WearableRepairEvent.emptyNew()
	v4.vehicle = p2
	v4.atSellingPoint = p3
	return v4
end
function WearableRepairEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.atSellingPoint = streamReadBool(p6)
	p5:run(p7)
end
function WearableRepairEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	streamWriteBool(p9, p8.atSellingPoint)
end
function WearableRepairEvent.run(p10, p11)
	if p11:getIsServer() then
		g_messageCenter:publish(MessageType.VEHICLE_REPAIRED, p10.vehicle, p10.atSellingPoint)
	elseif p10.vehicle ~= nil and (p10.vehicle:getIsSynchronized() and p10.vehicle.repairVehicle ~= nil) then
		p10.vehicle:repairVehicle(p10.atSellingPoint)
		g_server:broadcastEvent(p10)
		g_messageCenter:publish(MessageType.VEHICLE_REPAIRED, p10.vehicle, p10.atSellingPoint)
		return
	end
end

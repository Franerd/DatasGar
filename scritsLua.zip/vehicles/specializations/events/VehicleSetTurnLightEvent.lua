VehicleSetTurnLightEvent = {}
local v_u_1 = Class(VehicleSetTurnLightEvent, Event)
InitStaticEventClass(VehicleSetTurnLightEvent, "VehicleSetTurnLightEvent")
function VehicleSetTurnLightEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleSetTurnLightEvent.new(p2, p3)
	local v4 = VehicleSetTurnLightEvent.emptyNew()
	v4.object = p2
	v4.state = p3
	local v5
	if p3 >= 0 then
		v5 = p3 <= Lights.TURNLIGHT_HAZARD
	else
		v5 = false
	end
	assert(v5)
	return v4
end
function VehicleSetTurnLightEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.state = streamReadUIntN(p7, Lights.turnLightSendNumBits)
	p6:run(p8)
end
function VehicleSetTurnLightEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteUIntN(p10, p9.state, Lights.turnLightSendNumBits)
end
function VehicleSetTurnLightEvent.run(p11, p12)
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setTurnLightState(p11.state, true, true)
	end
	if not p12:getIsServer() then
		g_server:broadcastEvent(VehicleSetTurnLightEvent.new(p11.object, p11.state), nil, p12, p11.object)
	end
end

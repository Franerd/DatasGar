JumpEvent = {}
local v_u_1 = Class(JumpEvent, Event)
InitStaticEventClass(JumpEvent, "JumpEvent")
function JumpEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function JumpEvent.new(p2)
	local v3 = JumpEvent.emptyNew()
	v3.object = p2
	return v3
end
function JumpEvent.readStream(p4, p5, p6)
	if not p6:getIsServer() then
		p4.object = NetworkUtil.readNodeObject(p5)
		p4:run(p6)
	end
end
function JumpEvent.writeStream(p7, p8, p9)
	if p9:getIsServer() then
		NetworkUtil.writeNodeObject(p8, p7.object)
	end
end
function JumpEvent.run(p10, _)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:jump(true)
	end
end

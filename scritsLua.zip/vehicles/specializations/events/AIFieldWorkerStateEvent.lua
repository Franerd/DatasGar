AIFieldWorkerStateEvent = {}
local v_u_1 = Class(AIFieldWorkerStateEvent, Event)
InitStaticEventClass(AIFieldWorkerStateEvent, "AIFieldWorkerStateEvent")
function AIFieldWorkerStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AIFieldWorkerStateEvent.new(p2, p3)
	local v4 = AIFieldWorkerStateEvent.emptyNew()
	v4.vehicle = p2
	v4.isActive = p3
	return v4
end
function AIFieldWorkerStateEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.isActive = streamReadBool(p6)
	p5:run(p7)
end
function AIFieldWorkerStateEvent.writeStream(p8, p9, p10)
	local v11 = not p10:getIsServer()
	assert(v11, "AIFieldWorkerStateEvent is a server to client event only")
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	streamWriteBool(p9, p8.isActive)
end
function AIFieldWorkerStateEvent.run(p12, _)
	if p12.vehicle ~= nil and (p12.vehicle ~= nil and p12.vehicle:getIsSynchronized()) then
		if p12.isActive then
			p12.vehicle:startFieldWorker()
			return
		end
		p12.vehicle:stopFieldWorker()
	end
end

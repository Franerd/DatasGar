BaleWrapperAutomaticDropEvent = {}
local v_u_1 = Class(BaleWrapperAutomaticDropEvent, Event)
InitStaticEventClass(BaleWrapperAutomaticDropEvent, "BaleWrapperAutomaticDropEvent")
function BaleWrapperAutomaticDropEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function BaleWrapperAutomaticDropEvent.new(p2, p3)
	local v4 = BaleWrapperAutomaticDropEvent.emptyNew()
	v4.object = p2
	v4.automaticDrop = p3
	return v4
end
function BaleWrapperAutomaticDropEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.automaticDrop = streamReadBool(p6)
	p5:run(p7)
end
function BaleWrapperAutomaticDropEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteBool(p9, p8.automaticDrop)
end
function BaleWrapperAutomaticDropEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(p10, false, p11, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setBaleWrapperAutomaticDrop(p10.automaticDrop, true)
	end
end
function BaleWrapperAutomaticDropEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(BaleWrapperAutomaticDropEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(BaleWrapperAutomaticDropEvent.new(p12, p13))
	end
end

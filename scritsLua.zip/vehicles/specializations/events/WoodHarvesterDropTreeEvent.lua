WoodHarvesterDropTreeEvent = {}
local v_u_1 = Class(WoodHarvesterDropTreeEvent, Event)
InitStaticEventClass(WoodHarvesterDropTreeEvent, "WoodHarvesterDropTreeEvent")
function WoodHarvesterDropTreeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function WoodHarvesterDropTreeEvent.new(p2)
	local v3 = WoodHarvesterDropTreeEvent.emptyNew()
	v3.object = p2
	return v3
end
function WoodHarvesterDropTreeEvent.readStream(p4, p5, p6)
	p4.object = NetworkUtil.readNodeObject(p5)
	p4:run(p6)
end
function WoodHarvesterDropTreeEvent.writeStream(p7, p8, _)
	NetworkUtil.writeNodeObject(p8, p7.object)
end
function WoodHarvesterDropTreeEvent.run(p9, p10)
	if not p10:getIsServer() then
		g_server:broadcastEvent(WoodHarvesterDropTreeEvent.new(p9.object), nil, p10, p9.object)
	end
	if p9.object ~= nil and p9.object:getIsSynchronized() then
		p9.object:dropWoodHarvesterTree(true)
	end
end
function WoodHarvesterDropTreeEvent.sendEvent(p11, p12)
	if p12 == nil or p12 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(WoodHarvesterDropTreeEvent.new(p11), nil, nil, p11)
			return
		end
		g_client:getServerConnection():sendEvent(WoodHarvesterDropTreeEvent.new(p11))
	end
end

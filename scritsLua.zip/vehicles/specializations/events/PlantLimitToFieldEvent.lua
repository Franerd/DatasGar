PlantLimitToFieldEvent = {}
local v_u_1 = Class(PlantLimitToFieldEvent, Event)
InitStaticEventClass(PlantLimitToFieldEvent, "PlantLimitToFieldEvent")
function PlantLimitToFieldEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function PlantLimitToFieldEvent.new(p2, p3)
	local v4 = PlantLimitToFieldEvent.emptyNew()
	v4.object = p2
	v4.plantLimitToField = p3
	return v4
end
function PlantLimitToFieldEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.plantLimitToField = streamReadBool(p6)
	p5:run(p7)
end
function PlantLimitToFieldEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteBool(p9, p8.plantLimitToField)
end
function PlantLimitToFieldEvent.run(p10, p11)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setPlantLimitToField(p10.plantLimitToField, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(PlantLimitToFieldEvent.new(p10.object, p10.plantLimitToField), nil, p11, p10.object)
	end
end
function PlantLimitToFieldEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(PlantLimitToFieldEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(PlantLimitToFieldEvent.new(p12, p13))
	end
end

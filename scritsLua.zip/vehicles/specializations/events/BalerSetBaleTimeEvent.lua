BalerSetBaleTimeEvent = {}
local v_u_1 = Class(BalerSetBaleTimeEvent, Event)
InitStaticEventClass(BalerSetBaleTimeEvent, "BalerSetBaleTimeEvent")
function BalerSetBaleTimeEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function BalerSetBaleTimeEvent.new(p2, p3, p4)
	local v5 = BalerSetBaleTimeEvent.emptyNew()
	v5.object = p2
	v5.bale = p3
	v5.baleTime = p4
	return v5
end
function BalerSetBaleTimeEvent.readStream(p6, p7, p8)
	p6.object = NetworkUtil.readNodeObject(p7)
	p6.bale = streamReadInt32(p7)
	p6.baleTime = streamReadFloat32(p7)
	p6:run(p8)
end
function BalerSetBaleTimeEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.object)
	streamWriteInt32(p10, p9.bale)
	streamWriteFloat32(p10, p9.baleTime)
end
function BalerSetBaleTimeEvent.run(p11, _)
	if p11.object ~= nil and p11.object:getIsSynchronized() then
		p11.object:setBaleTime(p11.bale, p11.baleTime)
	end
end

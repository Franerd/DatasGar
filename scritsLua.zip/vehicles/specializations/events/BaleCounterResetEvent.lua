BaleCounterResetEvent = {}
local v_u_1 = Class(BaleCounterResetEvent, Event)
InitStaticEventClass(BaleCounterResetEvent, "BaleCounterResetEvent")
function BaleCounterResetEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function BaleCounterResetEvent.new(p2)
	local v3 = BaleCounterResetEvent.emptyNew()
	v3.object = p2
	return v3
end
function BaleCounterResetEvent.readStream(p4, p5, p6)
	p4.object = NetworkUtil.readNodeObject(p5)
	p4:run(p6)
end
function BaleCounterResetEvent.writeStream(p7, p8, _)
	NetworkUtil.writeNodeObject(p8, p7.object)
end
function BaleCounterResetEvent.run(p9, p10)
	if not p10:getIsServer() then
		g_server:broadcastEvent(p9, false, p10, p9.object)
	end
	if p9.object ~= nil and p9.object:getIsSynchronized() then
		p9.object:doBaleCounterReset(true)
	end
end
function BaleCounterResetEvent.sendEvent(p11, p12)
	if p12 == nil or p12 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(BaleCounterResetEvent.new(p11), nil, nil, p11)
			return
		end
		g_client:getServerConnection():sendEvent(BaleCounterResetEvent.new(p11))
	end
end

RideableStableNotificationEvent = {}
local v_u_1 = Class(RideableStableNotificationEvent, Event)
InitStaticEventClass(RideableStableNotificationEvent, "RideableStableNotificationEvent")
function RideableStableNotificationEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function RideableStableNotificationEvent.new(p2, p3)
	local v4 = RideableStableNotificationEvent.emptyNew()
	v4.isInStable = p2
	v4.name = p3
	return v4
end
function RideableStableNotificationEvent.readStream(p5, p6, p7)
	p5.isInStable = streamReadBool(p6)
	p5.name = streamReadString(p6)
	p5:run(p7)
end
function RideableStableNotificationEvent.writeStream(p8, p9, _)
	streamWriteBool(p9, p8.isInStable)
	streamWriteString(p9, p8.name)
end
function RideableStableNotificationEvent.run(p10, _)
	if p10.isInStable then
		g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, string.format(g_i18n:getText("ingameNotification_horseInStable"), p10.name))
	else
		g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_CRITICAL, string.format(g_i18n:getText("ingameNotification_horseNotInStable"), p10.name))
	end
end

PalletFillerStateEvent = {}
local v_u_1 = Class(PalletFillerStateEvent, Event)
InitStaticEventClass(PalletFillerStateEvent, "PalletFillerStateEvent")
function PalletFillerStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function PalletFillerStateEvent.new(p2, p3)
	local v4 = PalletFillerStateEvent.emptyNew()
	v4.object = p2
	v4.state = p3
	return v4
end
function PalletFillerStateEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.state = streamReadUIntN(p6, PalletFiller.getNumBits())
	p5:run(p7)
end
function PalletFillerStateEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteUIntN(p9, p8.state, PalletFiller.getNumBits())
end
function PalletFillerStateEvent.run(p10, p11)
	if not p11:getIsServer() then
		g_server:broadcastEvent(p10, false, p11, p10.object)
	end
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setPalletFillerState(p10.state, false, true)
	end
end
function PalletFillerStateEvent.sendEvent(p12, p13, p14)
	if p14 == nil or p14 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(PalletFillerStateEvent.new(p12, p13), nil, nil, p12)
			return
		end
		g_client:getServerConnection():sendEvent(PalletFillerStateEvent.new(p12, p13))
	end
end

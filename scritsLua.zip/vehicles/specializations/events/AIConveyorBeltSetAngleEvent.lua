AIConveyorBeltSetAngleEvent = {}
local v_u_1 = Class(AIConveyorBeltSetAngleEvent, Event)
InitStaticEventClass(AIConveyorBeltSetAngleEvent, "AIConveyorBeltSetAngleEvent")
function AIConveyorBeltSetAngleEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function AIConveyorBeltSetAngleEvent.new(p2, p3)
	local v4 = AIConveyorBeltSetAngleEvent.emptyNew()
	v4.currentAngle = p3
	v4.vehicle = p2
	return v4
end
function AIConveyorBeltSetAngleEvent.readStream(p5, p6, p7)
	p5.vehicle = NetworkUtil.readNodeObject(p6)
	p5.currentAngle = streamReadInt8(p6)
	p5:run(p7)
end
function AIConveyorBeltSetAngleEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.vehicle)
	streamWriteInt8(p9, p8.currentAngle)
end
function AIConveyorBeltSetAngleEvent.run(p10, p11)
	if p10.vehicle ~= nil and p10.vehicle:getIsSynchronized() then
		p10.vehicle:setAIConveyorBeltAngle(p10.currentAngle, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(AIConveyorBeltSetAngleEvent.new(p10.vehicle, p10.currentAngle), nil, p11, p10.vehicle)
	end
end

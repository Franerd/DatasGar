VariableWorkWidthStateEvent = {}
local v_u_1 = Class(VariableWorkWidthStateEvent, Event)
InitStaticEventClass(VariableWorkWidthStateEvent, "VariableWorkWidthStateEvent")
function VariableWorkWidthStateEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VariableWorkWidthStateEvent.new(p2, p3, p4)
	local v5 = VariableWorkWidthStateEvent.emptyNew()
	v5.vehicle = p2
	v5.leftSide = p3
	v5.rightSide = p4
	return v5
end
function VariableWorkWidthStateEvent.readStream(p6, p7, p8)
	p6.vehicle = NetworkUtil.readNodeObject(p7)
	p6.leftSide = streamReadUIntN(p7, VariableWorkWidth.SEND_NUM_BITS)
	p6.rightSide = streamReadUIntN(p7, VariableWorkWidth.SEND_NUM_BITS)
	p6:run(p8)
end
function VariableWorkWidthStateEvent.writeStream(p9, p10, _)
	NetworkUtil.writeNodeObject(p10, p9.vehicle)
	streamWriteUIntN(p10, p9.leftSide, VariableWorkWidth.SEND_NUM_BITS)
	streamWriteUIntN(p10, p9.rightSide, VariableWorkWidth.SEND_NUM_BITS)
end
function VariableWorkWidthStateEvent.run(p11, p12)
	if p11.vehicle ~= nil and p11.vehicle:getIsSynchronized() then
		p11.vehicle:setSectionsActive(p11.leftSide, p11.rightSide, true)
	end
	if not p12:getIsServer() then
		g_server:broadcastEvent(VariableWorkWidthStateEvent.new(p11.vehicle, p11.leftSide, p11.rightSide), nil, p12, p11.object)
	end
end
function VariableWorkWidthStateEvent.sendEvent(p13, p14, p15, p16)
	if p16 == nil or p16 == false then
		if g_server ~= nil then
			g_server:broadcastEvent(VariableWorkWidthStateEvent.new(p13, p14, p15), nil, nil, p13)
			return
		end
		g_client:getServerConnection():sendEvent(VariableWorkWidthStateEvent.new(p13, p14, p15))
	end
end

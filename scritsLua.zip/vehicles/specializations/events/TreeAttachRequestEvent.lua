TreeAttachRequestEvent = {}
local v_u_1 = Class(TreeAttachRequestEvent, Event)
InitStaticEventClass(TreeAttachRequestEvent, "TreeAttachRequestEvent")
function TreeAttachRequestEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function TreeAttachRequestEvent.new(p2, p3, p4, p5, p6, p7, p8)
	local v9 = TreeAttachRequestEvent.emptyNew()
	v9.object = p2
	v9.splitShapeId = p3
	v9.x = p4
	v9.y = p5
	v9.z = p6
	v9.ropeIndex = p7
	v9.setupRope = p8
	return v9
end
function TreeAttachRequestEvent.readStream(p10, p11, p12)
	p10.object = NetworkUtil.readNodeObject(p11)
	p10.splitShapeId = readSplitShapeIdFromStream(p11)
	p10.x = streamReadFloat32(p11)
	p10.y = streamReadFloat32(p11)
	p10.z = streamReadFloat32(p11)
	if streamReadBool(p11) then
		p10.ropeIndex = streamReadUIntN(p11, 3)
	end
	if streamReadBool(p11) then
		p10.setupRopeData = ForestryPhysicsRope.readStream(p11, true)
	end
	p10:run(p12)
end
function TreeAttachRequestEvent.writeStream(p13, p14, _)
	NetworkUtil.writeNodeObject(p14, p13.object)
	writeSplitShapeIdToStream(p14, p13.splitShapeId)
	streamWriteFloat32(p14, p13.x)
	streamWriteFloat32(p14, p13.y)
	streamWriteFloat32(p14, p13.z)
	if streamWriteBool(p14, p13.ropeIndex ~= nil) then
		streamWriteUIntN(p14, p13.ropeIndex, 3)
	end
	if streamWriteBool(p14, p13.setupRope ~= nil) then
		p13.setupRope:writeStream(p14)
	end
end
function TreeAttachRequestEvent.run(p15, p16)
	if p15.object ~= nil and p15.object:getIsSynchronized() then
		if p15.object.getIsCarriageTreeAttachAllowed ~= nil then
			local v17, v18 = p15.object:getIsCarriageTreeAttachAllowed(p15.splitShapeId)
			if v17 then
				p15.object:attachTreeToCarriage(p15.splitShapeId, p15.x, p15.y, p15.z, p15.ropeIndex)
			else
				g_server:broadcastEvent(TreeAttachResponseEvent.new(p15.object, v18, p15.ropeIndex), nil, nil, p15.object, nil, { p16 })
			end
		end
		if p15.object.getIsWinchTreeAttachAllowed ~= nil then
			local v19, v20 = p15.object:getIsWinchTreeAttachAllowed(p15.ropeIndex, p15.splitShapeId)
			if v19 then
				p15.object:attachTreeToWinch(p15.splitShapeId, p15.x, p15.y, p15.z, p15.ropeIndex, p15.setupRopeData)
				return
			end
			g_server:broadcastEvent(TreeAttachResponseEvent.new(p15.object, v20, p15.ropeIndex), nil, nil, p15.object, nil, { p16 })
		end
	end
end

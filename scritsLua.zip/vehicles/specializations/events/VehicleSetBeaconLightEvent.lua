VehicleSetBeaconLightEvent = {}
local v_u_1 = Class(VehicleSetBeaconLightEvent, Event)
InitStaticEventClass(VehicleSetBeaconLightEvent, "VehicleSetBeaconLightEvent")
function VehicleSetBeaconLightEvent.emptyNew()
	-- upvalues: (copy) v_u_1
	return Event.new(v_u_1)
end
function VehicleSetBeaconLightEvent.new(p2, p3)
	local v4 = VehicleSetBeaconLightEvent.emptyNew()
	v4.active = p3
	v4.object = p2
	return v4
end
function VehicleSetBeaconLightEvent.readStream(p5, p6, p7)
	p5.object = NetworkUtil.readNodeObject(p6)
	p5.active = streamReadBool(p6)
	p5:run(p7)
end
function VehicleSetBeaconLightEvent.writeStream(p8, p9, _)
	NetworkUtil.writeNodeObject(p9, p8.object)
	streamWriteBool(p9, p8.active)
end
function VehicleSetBeaconLightEvent.run(p10, p11)
	if p10.object ~= nil and p10.object:getIsSynchronized() then
		p10.object:setBeaconLightsVisibility(p10.active, true, true)
	end
	if not p11:getIsServer() then
		g_server:broadcastEvent(VehicleSetBeaconLightEvent.new(p10.object, p10.active), nil, p11, p10.object)
	end
end

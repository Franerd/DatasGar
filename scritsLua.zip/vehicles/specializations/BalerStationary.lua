BalerStationary = {}
source("dataS/scripts/gui/hud/extensions/BalerStationaryHUDExtension.lua")
function BalerStationary.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Baler, p1) and SpecializationUtil.hasSpecialization(BaleWrapper, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(FoldableSteps, p1)
	end
	return v2
end
function BalerStationary.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", BalerStationary)
	SpecializationUtil.registerEventListener(p3, "onDelete", BalerStationary)
	SpecializationUtil.registerEventListener(p3, "onDraw", BalerStationary)
end
function BalerStationary.onLoad(p4)
	p4.spec_balerStationary.hudExtension = BalerStationaryHUDExtension.new(p4)
end
function BalerStationary.onDelete(p5)
	local v6 = p5.spec_balerStationary
	if v6.hudExtension ~= nil then
		g_currentMission.hud:removeInfoExtension(v6.hudExtension)
		v6.hudExtension:delete()
	end
end
function BalerStationary.onDraw(p7)
	local v8 = p7.spec_balerStationary
	if v8.hudExtension ~= nil then
		g_currentMission.hud:addInfoExtension(v8.hudExtension)
	end
end

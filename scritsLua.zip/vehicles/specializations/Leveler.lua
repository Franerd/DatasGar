Leveler = {}
Leveler.LEVELER_NODE_XML_KEY = "vehicle.leveler.levelerNode(?)"
Leveler.LEVEL_NUM_BITS = 8
Leveler.LEVEL_MAX_VALUE = 2 ^ Leveler.LEVEL_NUM_BITS - 1
function Leveler.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(FillUnit, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(BunkerSiloInteractor, p1)
	end
	return v2
end
function Leveler.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Leveler")
	local v4 = Leveler.LEVELER_NODE_XML_KEY
	v3:register(XMLValueType.NODE_INDEX, v4 .. "#node", "Leveler node")
	v3:register(XMLValueType.FLOAT, v4 .. "#width", "Width")
	v3:register(XMLValueType.FLOAT, v4 .. "#zOffset", "Z axis offset", 0)
	v3:register(XMLValueType.FLOAT, v4 .. "#yOffset", "Y axis offset", 0)
	v3:register(XMLValueType.FLOAT, v4 .. "#minDropWidth", "Min. drop width", "half of width")
	v3:register(XMLValueType.FLOAT, v4 .. "#maxDropWidth", "Max. drop width", "width value")
	v3:register(XMLValueType.FLOAT, v4 .. "#minDropDirOffset", "Min. drop direction offset", 0.7)
	v3:register(XMLValueType.FLOAT, v4 .. "#maxDropDirOffset", "Max. drop direction offset", 0.7)
	v3:register(XMLValueType.INT, v4 .. "#numHeightLimitChecks", "Number of height limit checks", 6)
	v3:register(XMLValueType.BOOL, v4 .. "#alignToWorldY", "Defines if the leveler node is aligned to worlds Y axis", true)
	v3:register(XMLValueType.BOOL, v4 .. ".smoothing#allowed", "Leveler smoothes while driving backward", true)
	v3:register(XMLValueType.FLOAT, v4 .. ".smoothing#radius", "Smooth ground radius", 0.5)
	v3:register(XMLValueType.FLOAT, v4 .. ".smoothing#overlap", "Radius overlap", 1.7)
	v3:register(XMLValueType.INT, v4 .. ".smoothing#direction", "Smooth direction (if set to \'0\' it smooths in both directions)", -1)
	v3:register(XMLValueType.INT, v4 .. "#fillUnitIndex", "Fill unit index", "Value of vehicle.leveler#fillUnitIndex")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".occlusionAreas.occlusionArea(?)#startNode", "Start node")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".occlusionAreas.occlusionArea(?)#widthNode", "Width node")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".occlusionAreas.occlusionArea(?)#heightNode", "Height node")
	v3:register(XMLValueType.INT, "vehicle.leveler.pickUpDirection", "Pick up direction", 1)
	v3:register(XMLValueType.INT, "vehicle.leveler#fillUnitIndex", "Fill unit index")
	v3:register(XMLValueType.FLOAT, "vehicle.leveler#maxFillLevelPerMS", "Max. fill level change rate as reference for effect and force", 20)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.leveler.force#node", "Force node")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.leveler.force#directionNode", "Force direction node")
	v3:register(XMLValueType.FLOAT, "vehicle.leveler.force#maxForce", "Max. force in kN", 0)
	v3:register(XMLValueType.INT, "vehicle.leveler.force#direction", "Driving direction for applying force", 1)
	v3:register(XMLValueType.BOOL, "vehicle.leveler#ignoreFarmlandState", "If set to true the farmland underneath the leveler does not need to be bought to actually work", false)
	EffectManager.registerEffectXMLPaths(v3, "vehicle.leveler.effects")
	v3:setXMLSpecializationType()
end
function Leveler.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "getIsLevelerPickupNodeActive", Leveler.getIsLevelerPickupNodeActive)
	SpecializationUtil.registerFunction(p5, "loadLevelerNodeFromXML", Leveler.loadLevelerNodeFromXML)
	SpecializationUtil.registerFunction(p5, "onLevelerRaycastCallback", Leveler.onLevelerRaycastCallback)
end
function Leveler.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsAttacherJointControlDampingAllowed", Leveler.getIsAttacherJointControlDampingAllowed)
end
function Leveler.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", Leveler)
	SpecializationUtil.registerEventListener(p7, "onDelete", Leveler)
	SpecializationUtil.registerEventListener(p7, "onReadUpdateStream", Leveler)
	SpecializationUtil.registerEventListener(p7, "onWriteUpdateStream", Leveler)
	SpecializationUtil.registerEventListener(p7, "onUpdate", Leveler)
end
function Leveler.onLoad(p8, _)
	local v9 = p8.spec_leveler
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.leveler.levelerNode#index", "vehicle.leveler.levelerNode#node")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.levelerEffects", "vehicle.leveler.effects")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.leveler.levelerNode(0)#minDropHeight")
	XMLUtil.checkDeprecatedXMLElements(p8.xmlFile, "vehicle.leveler.levelerNode(0)#maxDropHeight")
	v9.pickUpDirection = p8.xmlFile:getValue("vehicle.leveler.pickUpDirection", 1)
	v9.maxFillLevelPerMS = p8.xmlFile:getValue("vehicle.leveler#maxFillLevelPerMS", 35)
	v9.fillUnitIndex = p8.xmlFile:getValue("vehicle.leveler#fillUnitIndex")
	v9.nodes = {}
	local v10 = 0
	while true do
		local v11 = string.format("vehicle.leveler.levelerNode(%d)", v10)
		if not p8.xmlFile:hasProperty(v11) then
			break
		end
		local v12 = {}
		if p8:loadLevelerNodeFromXML(v12, p8.xmlFile, v11) then
			v12.vehicle = p8
			v12.onLevelerRaycastCallback = p8.onLevelerRaycastCallback
			local v13 = v9.nodes
			table.insert(v13, v12)
		end
		v10 = v10 + 1
	end
	v9.litersToPickup = 0
	v9.smoothAccumulation = 0
	v9.lastFillLevelMoved = 0
	v9.lastFillLevelMovedPct = 0
	v9.lastFillLevelMovedTarget = 0
	v9.lastFillLevelMovedBuffer = 0
	v9.lastFillLevelMovedBufferTime = 300
	v9.lastFillLevelMovedBufferTimer = 0
	v9.forceNode = p8.xmlFile:getValue("vehicle.leveler.force#node", nil, p8.components, p8.i3dMappings)
	v9.forceDirNode = p8.xmlFile:getValue("vehicle.leveler.force#directionNode", v9.forceNode, p8.components, p8.i3dMappings)
	v9.maxForce = p8.xmlFile:getValue("vehicle.leveler.force#maxForce", 0)
	v9.lastForce = 0
	v9.forceDir = p8.xmlFile:getValue("vehicle.leveler.force#direction", 1)
	v9.ignoreFarmlandState = p8.xmlFile:getValue("vehicle.leveler#ignoreFarmlandState", false)
	if p8.isClient then
		v9.effects = g_effectManager:loadEffect(p8.xmlFile, "vehicle.leveler.effects", p8.components, p8, p8.i3dMappings)
	end
	if #v9.nodes == 0 then
		SpecializationUtil.removeEventListener(p8, "onUpdate", Leveler)
	end
	v9.dirtyFlag = p8:getNextDirtyFlag()
end
function Leveler.onDelete(p14)
	local v15 = p14.spec_leveler
	g_effectManager:deleteEffects(v15.effects)
end
function Leveler.onReadUpdateStream(p16, p17, _, p18)
	if p18:getIsServer() and streamReadBool(p17) then
		p16.spec_leveler.lastFillLevelMovedPct = streamReadUIntN(p17, Leveler.LEVEL_NUM_BITS) / Leveler.LEVEL_MAX_VALUE
	end
end
function Leveler.onWriteUpdateStream(p19, p20, p21, p22)
	if not p21:getIsServer() then
		local v23 = p19.spec_leveler
		if streamWriteBool(p20, bitAND(p22, v23.dirtyFlag) ~= 0) then
			streamWriteUIntN(p20, v23.lastFillLevelMovedPct * Leveler.LEVEL_MAX_VALUE, Leveler.LEVEL_NUM_BITS)
		end
	end
end
function Leveler.onUpdate(p24, p25, _, _, _)
	local v26 = p24.spec_leveler
	if p24.isClient then
		local v27 = FillType.UNKNOWN
		for _, v28 in pairs(v26.nodes) do
			v27 = p24:getFillUnitLastValidFillType(v28.fillUnitIndex)
			if v27 ~= FillType.UNKNOWN then
				break
			end
		end
		if v27 == FillType.UNKNOWN or v26.lastFillLevelMovedPct <= 0 then
			g_effectManager:stopEffects(v26.effects)
		else
			g_effectManager:setEffectTypeInfo(v26.effects, v27)
			g_effectManager:startEffects(v26.effects)
			for _, v29 in pairs(v26.effects) do
				if v29:isa(LevelerEffect) or v29:isa(SnowPlowMotionPathEffect) then
					v29:setFillLevel(v26.lastFillLevelMovedPct)
					v29:setLastVehicleSpeed(p24.movingDirection * p24:getLastSpeed())
				end
			end
		end
	end
	if p24.isServer then
		for _, v30 in pairs(v26.nodes) do
			local v31, v32, v33 = localToWorld(v30.node, -v30.halfWidth, v30.yOffset, v30.maxDropDirOffset)
			local v34, v35, v36 = localToWorld(v30.node, v30.halfWidth, v30.yOffset, v30.maxDropDirOffset)
			if not v26.ignoreFarmlandState then
				local v37 = p24:getOwnerFarmId()
				if not (g_farmlandManager:getCanAccessLandAtWorldPosition(v37, v31, v33) and g_farmlandManager:getCanAccessLandAtWorldPosition(v37, v34, v36)) then
					break
				end
			end
			local v38 = 0
			local v39 = p24:getFillUnitFillType(v30.fillUnitIndex)
			local v40 = p24:getFillUnitFillLevel(v30.fillUnitIndex)
			local v41
			if v39 == FillType.UNKNOWN or v40 < g_densityMapHeightManager:getMinValidLiterValue(v39) + 0.001 then
				v41 = DensityMapHeightUtil.getFillTypeAtLine(v31, v32, v33, v34, v35, v36, 0.5 * v30.maxDropDirOffset)
				if v41 == FillType.UNKNOWN or (v41 == v39 or not p24:getFillUnitSupportsFillType(v30.fillUnitIndex, v41)) then
					v41 = v39
				else
					p24:addFillUnitFillLevel(p24:getOwnerFarmId(), v30.fillUnitIndex, (-1 / 0))
				end
			else
				v41 = v39
			end
			local v42 = g_densityMapHeightManager:getDensityMapHeightTypeByFillTypeIndex(v41)
			if v41 == FillType.UNKNOWN or v42 == nil then
				v26.lastFillLevelMovedBuffer = 0
				v26.lastFillLevelMovedTarget = 0
			else
				local v43 = 2
				local v44 = p24:getFillUnitCapacity(v30.fillUnitIndex)
				local v45
				if v30.alignToWorldY then
					local v46, v47
					v46, v45, v47 = localDirectionToWorld(v30.referenceFrame, 0, 0, 1)
					I3DUtil.setWorldDirection(v30.node, v46, math.max(v45, 0), v47, 0, 1, 0)
				else
					v45 = 0
				end
				if p24:getIsLevelerPickupNodeActive(v30) and (v26.pickUpDirection == p24.movingDirection and p24.lastSpeed > 0.0001) then
					local v48, v49, v50 = localToWorld(v30.node, -v30.halfWidth, v30.yOffset, v30.zOffset)
					local v51, v52, v53 = localToWorld(v30.node, v30.halfWidth, v30.yOffset, v30.zOffset)
					if v45 >= 0 then
						local _, v54, _ = localToWorld(v30.node, -v30.halfWidth, v30.yOffset, v30.zOffset + 0.5)
						local _, v55, _ = localToWorld(v30.node, v30.halfWidth, v30.yOffset, v30.zOffset + 0.5)
						v49 = math.max(v49, v54)
						v52 = math.max(v52, v55)
					end
					local v56 = -(v44 - p24:getFillUnitFillLevel(v30.fillUnitIndex))
					local v57 = v30.numHeightLimitChecks
					if v57 > 0 then
						local v58 = 0
						for v59 = 0, v57 do
							local v60 = v59 / v57
							local v61 = v48 + (v51 - v48) * v60
							local v62 = v49 + (v52 - v49) * v60
							local v63 = v50 + (v53 - v50) * v60
							local v64 = DensityMapHeightUtil.getHeightAtWorldPos(v61, v62, v63) - 0.05 - v62
							v58 = math.max(v58, v64)
						end
						if v58 > 0 then
							v49 = v49 + v58
							v52 = v52 + v58
						end
					end
					local v65, v66 = DensityMapHeightUtil.tipToGroundAroundLine(p24, v56, v41, v48, v49, v50, v51, v52, v53, 0.5, 2, v30.lineOffsetPickUp, true, nil)
					v30.lastPickUp = v65
					v30.lineOffsetPickUp = v66
					if v30.lastPickUp < 0 then
						if p24.notifiyBunkerSilo ~= nil then
							p24:notifiyBunkerSilo(v30.lastPickUp, v41, (v48 + v51) * 0.5, (v49 + v52) * 0.5, (v50 + v53) * 0.5)
						end
						v30.lastPickUp = v30.lastPickUp + v26.litersToPickup
						v26.litersToPickup = 0
						p24:addFillUnitFillLevel(p24:getOwnerFarmId(), v30.fillUnitIndex, -v30.lastPickUp, v41, ToolType.UNDEFINED, nil)
						v38 = v30.lastPickUp
					end
				end
				local v67 = -v38
				v26.lastFillLevelMovedBuffer = v26.lastFillLevelMovedBuffer + v67
				v26.lastFillLevelMovedBufferTimer = v26.lastFillLevelMovedBufferTimer + p25
				if v26.lastFillLevelMovedBufferTimer > v26.lastFillLevelMovedBufferTime then
					v26.lastFillLevelMovedTarget = v26.lastFillLevelMovedBuffer / v26.lastFillLevelMovedBufferTimer
					v26.lastFillLevelMovedBufferTimer = 0
					v26.lastFillLevelMovedBuffer = 0
				end
				if p24.movingDirection < 0 and p24.lastSpeed * 3600 > 0.5 then
					v26.lastFillLevelMovedBuffer = 0
				end
				local v68 = p24:getFillUnitFillLevel(v30.fillUnitIndex)
				if v68 > 0 then
					local v69 = v68 / v44
					local v70 = MathUtil.lerp(v30.halfMinDropWidth, v30.halfMaxDropWidth, v69)
					local v71, v72, v73 = localToWorld(v30.node, -v70, v30.yOffset, v30.zOffset)
					local v74, v75, v76 = localToWorld(v30.node, v70, v30.yOffset, v30.zOffset)
					local v77, v78 = DensityMapHeightUtil.tipToGroundAroundLine(p24, v68, v41, v71, v72 + -0.15, v73, v74, v75 + -0.15, v76, 0.5, 2, v30.lineOffsetDrop1, true, nil)
					v30.lastDrop1 = v77
					v30.lineOffsetDrop1 = v78
					if v30.lastDrop1 > 0 then
						local v79 = v68 - v30.lastDrop1
						if v79 <= g_densityMapHeightManager:getMinValidLiterValue(v41) then
							v30.lastDrop1 = v68
							v26.litersToPickup = v26.litersToPickup + v79
						end
						p24:addFillUnitFillLevel(p24:getOwnerFarmId(), v30.fillUnitIndex, -v30.lastDrop1, v41, ToolType.UNDEFINED, nil)
					end
				end
				if p24:getFillUnitFillLevel(v30.fillUnitIndex) > 0 then
					local v80 = MathUtil.lerp(v30.minDropDirOffset, v30.maxDropDirOffset, v26.lastFillLevelMovedPct)
					local v81, v82, v83 = localToWorld(v30.node, 0, v30.yOffset, 0)
					local v84, v85, v86 = localToWorld(v30.node, 0, v30.yOffset, v30.zOffset + v80)
					v30.raycastLastFillType = v41
					v30.raycastLastRadius = v43
					v30.raycastHitObject = false
					local v87 = v84 - v81
					local v88 = v85 - v82
					local v89 = v86 - v83
					local v90 = MathUtil.vector3Length(v87, v88, v89)
					local v91, v92, v93 = MathUtil.vector3Normalize(v87, v88, v89)
					raycastAllAsync(v81, v82, v83, v91, v92, v93, v90, "onLevelerRaycastCallback", v30, CollisionFlag.STATIC_OBJECT)
				end
			end
			if v38 < 0 and v41 ~= FillType.UNKNOWN then
				p24:notifiyBunkerSilo(v38, v41)
			end
			if v30.allowsSmoothing and (v30.smoothDirection == 0 or p24.movingDirection == v30.smoothDirection) then
				local v94 = 0
				if p24.lastSpeedReal > 0.0002 then
					local v95 = v26.smoothAccumulation
					local v96 = p24.lastMovedDistance * 0.5
					local v97 = 0.0003 * p25
					v94 = v95 + math.max(v96, v97)
					v26.smoothAccumulation = v94 - DensityMapHeightUtil.getRoundedHeightValue(v94)
				else
					v26.smoothAccumulation = 0
				end
				if v94 > 0 then
					DensityMapHeightUtil.smoothAroundLine(v30.node, v30.width, v30.smoothGroundRadius, v30.smoothOverlap, v94, true)
				end
			end
		end
		local v98 = v26.lastFillLevelMovedTarget == 0 and 0.2 or 0.05
		v26.lastFillLevelMoved = v26.lastFillLevelMoved * (1 - v98) + v26.lastFillLevelMovedTarget * v98
		if v26.lastFillLevelMoved < 0.005 then
			v26.lastFillLevelMoved = 0
		end
		local v99 = v26.lastFillLevelMovedPct
		local v100 = v26.lastFillLevelMoved / v26.maxFillLevelPerMS
		local v101 = math.min(v100, 1)
		v26.lastFillLevelMovedPct = math.max(v101, 0)
		if v26.lastFillLevelMovedPct ~= v99 then
			p24:raiseDirtyFlags(v26.dirtyFlag)
		end
		if v26.forceNode ~= nil and (p24.movingDirection == v26.forceDir and v26.lastFillLevelMoved > 0) then
			v26.lastForce = -v26.maxForce * v26.lastFillLevelMovedPct
			local v102, v103, v104 = localDirectionToWorld(v26.forceDirNode, 0, 0, v26.lastForce)
			local v105, v106, v107 = getCenterOfMass(v26.forceNode)
			addForce(v26.forceNode, v102, v103, v104, v105, v106, v107, true)
		end
	end
end
function Leveler.loadLevelerNodeFromXML(p108, p109, p110, p111)
	p109.node = p110:getValue(p111 .. "#node", nil, p108.components, p108.i3dMappings)
	if p109.node == nil then
		return false
	end
	local v112 = createTransformGroup("referenceFrame")
	link(getParent(p109.node), v112)
	setTranslation(v112, getTranslation(p109.node))
	setRotation(v112, getRotation(p109.node))
	p109.referenceFrame = v112
	p109.zOffset = p110:getValue(p111 .. "#zOffset", 0)
	p109.yOffset = p110:getValue(p111 .. "#yOffset", 0)
	p109.width = p110:getValue(p111 .. "#width")
	p109.halfWidth = p109.width * 0.5
	p109.minDropWidth = p110:getValue(p111 .. "#minDropWidth", p109.width * 0.5)
	p109.halfMinDropWidth = p109.minDropWidth * 0.5
	p109.maxDropWidth = p110:getValue(p111 .. "#maxDropWidth", p109.width)
	p109.halfMaxDropWidth = p109.maxDropWidth * 0.5
	p109.minDropDirOffset = p110:getValue(p111 .. "#minDropDirOffset", 0.7)
	p109.maxDropDirOffset = p110:getValue(p111 .. "#maxDropDirOffset", 0.7)
	p109.numHeightLimitChecks = p110:getValue(p111 .. "#numHeightLimitChecks", 6)
	p109.alignToWorldY = p110:getValue(p111 .. "#alignToWorldY", true)
	p109.occlusionAreas = {}
	local v113 = 0
	while true do
		local v114 = string.format("%s.occlusionAreas.occlusionArea(%d)", p111, v113)
		if not p110:hasProperty(v114) then
			break
		end
		local v115 = {
			["startNode"] = p110:getValue(v114 .. "#startNode", nil, p108.components, p108.i3dMappings),
			["widthNode"] = p110:getValue(v114 .. "#widthNode", nil, p108.components, p108.i3dMappings),
			["heightNode"] = p110:getValue(v114 .. "#heightNode", nil, p108.components, p108.i3dMappings)
		}
		if v115.startNode == nil or (v115.widthNode == nil or v115.heightNode == nil) then
			Logging.xmlWarning(p110, "Failed to load occlustion area \'%s\'. One or more nodes missing.", v114)
		else
			local v116 = p109.occlusionAreas
			table.insert(v116, v115)
		end
		v113 = v113 + 1
	end
	p109.allowsSmoothing = p110:getValue(p111 .. ".smoothing#allowed", true)
	p109.smoothGroundRadius = p110:getValue(p111 .. ".smoothing#radius", 0.5)
	p109.smoothOverlap = p110:getValue(p111 .. ".smoothing#overlap", 1.7)
	p109.smoothDirection = p110:getValue(p111 .. ".smoothing#direction", -1)
	p109.lineOffsetPickUp = nil
	p109.lineOffsetDrop = nil
	p109.lastPickUp = 0
	p109.lastDrop = 0
	p109.fillUnitIndex = p110:getValue(p111 .. "#fillUnitIndex", p108.spec_leveler.fillUnitIndex)
	if p108:getFillUnitExists(p109.fillUnitIndex) then
		return true
	end
	local v117 = Logging.xmlWarning
	local v118 = p108.xmlFile
	local v119 = p109.fillUnitIndex
	v117(v118, "Unknown fillUnitIndex \'%s\' for leveler", (tostring(v119)))
	return false
end
function Leveler.getIsLevelerPickupNodeActive(p120, _)
	return p120.getAttacherVehicle == nil and true or p120:getAttacherVehicle() ~= nil
end
function Leveler.getIsAttacherJointControlDampingAllowed(p121, p122)
	if not p122(p121) then
		return false
	end
	for _, v123 in pairs(p121.spec_leveler.nodes) do
		local v124, v125, v126 = getWorldTranslation(v123.node)
		local _, v127 = DensityMapHeightUtil.getHeightAtWorldPos(v124, v125, v126)
		if v127 == 0 then
			return false
		end
	end
	return true
end
function Leveler.onLevelerRaycastCallback(p128, p129, _, _, _, _, _, _, _, _, _, p130)
	local v131 = p128.vehicle
	if not (v131.isDeleted or v131.isDeleting) then
		local v132 = v131.spec_leveler
		if p129 ~= 0 and p129 ~= g_terrainNode then
			p128.raycastHitObject = true
		end
		if p130 and not p128.raycastHitObject then
			local v133 = v131:getFillUnitFillLevel(p128.fillUnitIndex)
			if v133 > 0 then
				local v134 = p128.raycastLastFillType
				local v135 = p128.raycastLastRadius
				local v136 = v132.lastFillLevelMovedPct
				local v137 = MathUtil.lerp(p128.halfMinDropWidth, p128.halfMaxDropWidth, v136)
				local v138 = MathUtil.lerp(p128.minDropDirOffset, p128.maxDropDirOffset, v136)
				local v139 = g_densityMapHeightManager:getTerrainDetailHeightUpdater()
				if v139 ~= nil then
					for v140 = 1, #p128.occlusionAreas do
						local v141 = p128.occlusionAreas[v140]
						local v142, v143, v144 = getWorldTranslation(v141.startNode)
						local v145, _, v146 = getWorldTranslation(v141.widthNode)
						local v147, _, v148 = getWorldTranslation(v141.heightNode)
						local v149, v150, v151, v152, v153, v154 = MathUtil.getXZWidthAndHeight(v142, v144, v145, v146, v147, v148)
						addDensityMapHeightOcclusionArea(v139, v149, v143, v150, v151, v143, v152, v153, v143, v154, true)
					end
				end
				local v155, v156, v157 = localToWorld(p128.node, -v137, p128.yOffset, p128.zOffset + v138)
				local v158, v159, v160 = localToWorld(p128.node, v137, p128.yOffset, p128.zOffset + v138)
				local v161, v162 = DensityMapHeightUtil.tipToGroundAroundLine(v131, v133, v134, v155, v156, v157, v158, v159, v160, 0, v135, p128.lineOffsetDrop2, false, nil)
				p128.lastDrop2 = v161
				p128.lineOffsetDrop2 = v162
				if p128.lastDrop2 > 0 then
					local v163 = v133 - p128.lastDrop2
					if v163 <= g_densityMapHeightManager:getMinValidLiterValue(v134) then
						p128.lastDrop2 = v133
						v132.litersToPickup = v132.litersToPickup + v163
					end
					v131:addFillUnitFillLevel(v131:getOwnerFarmId(), p128.fillUnitIndex, -p128.lastDrop2, v134, ToolType.UNDEFINED, nil)
				end
			end
		end
	end
end

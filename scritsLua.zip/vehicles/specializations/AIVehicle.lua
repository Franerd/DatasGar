AIVehicle = {}
function AIVehicle.prerequisitesPresent(_)
	return true
end
function AIVehicle.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("AIVehicle")
	AIVehicle.registerAgentAttachmentPaths(v1, "vehicle.ai", true)
	v1:setXMLSpecializationType()
end
function AIVehicle.registerAgentAttachmentPaths(p2, p3, p4)
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".agentAttachment(?)#jointNode", "Custom joint node (if not defined the current attacher joint is used)")
	p2:register(XMLValueType.VECTOR_N, p3 .. ".agentAttachment(?)#rotCenterWheelIndices", "The center of these wheel indices define the steering center")
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".agentAttachment(?)#rotCenterNode", "Custom node to define the steering center")
	p2:register(XMLValueType.VECTOR_2, p3 .. ".agentAttachment(?)#rotCenterPosition", "Offset from root component that defines the steering center")
	p2:register(XMLValueType.FLOAT, p3 .. ".agentAttachment(?)#width", "Agent attachable width", 3)
	p2:register(XMLValueType.FLOAT, p3 .. ".agentAttachment(?)#height", "Agent attachable height", 3)
	p2:register(XMLValueType.FLOAT, p3 .. ".agentAttachment(?)#heightOffset", "Agent attachable height offset (only for visual debug)", 0)
	p2:register(XMLValueType.FLOAT, p3 .. ".agentAttachment(?)#length", "Agent attachable length", 3)
	p2:register(XMLValueType.FLOAT, p3 .. ".agentAttachment(?)#lengthOffset", "Agent attachable length offset from rot center", 0)
	p2:register(XMLValueType.BOOL, p3 .. ".agentAttachment(?)#hasCollision", "Agent attachable is doing collision checks", true)
	p2:register(XMLValueType.BOOL, p3 .. ".agentAttachment(?)#useSize", "Use the vehicle size definition for the agentAttachment size as well (for static tools)", false)
	if p4 then
		AIVehicle.registerAgentAttachmentPaths(p2, p3 .. ".agentAttachment(?)", false)
	end
end
function AIVehicle.registerEvents(p5)
	SpecializationUtil.registerEvent(p5, "onAIFieldCourseSettingsInitialized")
end
function AIVehicle.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "collectAIAgentAttachments", AIVehicle.collectAIAgentAttachments)
	SpecializationUtil.registerFunction(p6, "registerAIAgentAttachment", AIVehicle.registerAIAgentAttachment)
	SpecializationUtil.registerFunction(p6, "loadAIAgentAttachmentsFromXML", AIVehicle.loadAIAgentAttachmentsFromXML)
	SpecializationUtil.registerFunction(p6, "validateAIAgentAttachments", AIVehicle.validateAIAgentAttachments)
	SpecializationUtil.registerFunction(p6, "drawAIAgentAttachments", AIVehicle.drawAIAgentAttachments)
	SpecializationUtil.registerFunction(p6, "raiseAIEvent", AIVehicle.raiseAIEvent)
	SpecializationUtil.registerFunction(p6, "safeRaiseAIEvent", AIVehicle.safeRaiseAIEvent)
	SpecializationUtil.registerFunction(p6, "getIsAIReadyToDrive", AIVehicle.getIsAIReadyToDrive)
	SpecializationUtil.registerFunction(p6, "getIsAIPreparingToDrive", AIVehicle.getIsAIPreparingToDrive)
end
function AIVehicle.registerOverwrittenFunctions(_) end
function AIVehicle.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", AIVehicle)
	SpecializationUtil.registerEventListener(p7, "onPostLoad", AIVehicle)
end
function AIVehicle.onLoad(p8, _)
	local v9 = p8.spec_aiVehicle
	v9.agentAttachments = {}
	if p8.getInputAttacherJoints ~= nil then
		p8:loadAIAgentAttachmentsFromXML(p8.xmlFile, "vehicle.ai.agentAttachment", v9.agentAttachments)
	end
	v9.debugSizeBox = DebugBox.new()
	v9.debugSizeBox:setColorRGBA(0, 1, 1)
	v9.debugSizeBox:setText("aiAgentAttachment")
end
function AIVehicle.onPostLoad(p10, _)
	local v11 = p10.spec_aiVehicle
	if #v11.agentAttachments > 0 then
		local v12 = p10:getInputAttacherJoints()
		p10:validateAIAgentAttachments(v11.agentAttachments, v12)
	end
end
function AIVehicle.collectAIAgentAttachments(p13, p14)
	local v15 = p13.spec_aiVehicle
	if #v15.agentAttachments > 0 then
		local v16 = p13:getActiveInputAttacherJoint()
		if v16 ~= nil then
			local v17 = p13:getAttacherVehicle():getAttacherJointDescFromObject(p13)
			local v18 = false
			for v19 = 1, #v15.agentAttachments do
				local v20 = v15.agentAttachments[v19]
				if v20.jointNode == v16.node then
					v20.attacherVehicleJointNode = v17.jointTransform
					p13:registerAIAgentAttachment(p14, v20)
					v18 = true
				end
			end
			if not v18 then
				for v21 = 1, #v15.agentAttachments do
					local v22 = v15.agentAttachments[v21]
					if v22.isDirectAttachment then
						v22.attacherVehicleJointNode = v17.jointTransform
						v22.jointNodeDynamic = v16.node
						p13:registerAIAgentAttachment(p14, v22)
						break
					end
				end
			end
			for v23 = 1, #v15.agentAttachments do
				local v24 = v15.agentAttachments[v23]
				if not v24.isDirectAttachment then
					p13:registerAIAgentAttachment(p14, v24)
				end
			end
		end
	end
end
function AIVehicle.registerAIAgentAttachment(_, p25, p26)
	p25:addAIAgentAttachment(p26)
	for v27 = 1, #p26.agentAttachments do
		p25:addAIAgentAttachment(p26.agentAttachments[v27])
	end
end
function AIVehicle.loadAIAgentAttachmentsFromXML(p_u_28, p_u_29, p30, p_u_31, p_u_32, p_u_33)
	p_u_29:iterate(p30, function(_, p34)
		-- upvalues: (copy) p_u_29, (copy) p_u_28, (copy) p_u_32, (copy) p_u_33, (copy) p_u_31
		local v35 = {
			["jointNode"] = p_u_29:getValue(p34 .. "#jointNode", nil, p_u_28.components, p_u_28.i3dMappings),
			["jointNodeDynamic"] = nil,
			["rotCenterNode"] = p_u_29:getValue(p34 .. "#rotCenterNode", nil, p_u_28.components, p_u_28.i3dMappings),
			["rotCenterWheelIndices"] = p_u_29:getValue(p34 .. "#rotCenterWheelIndices", nil, true),
			["rotCenterPosition"] = p_u_29:getValue(p34 .. "#rotCenterPosition", nil, true),
			["useSize"] = p_u_29:getValue(p34 .. "#useSize", false)
		}
		if v35.useSize then
			v35.width = p_u_28.size.width
			v35.height = p_u_28.size.height
			v35.heightOffset = p_u_28.size.heightOffset
			v35.length = p_u_28.size.length
			v35.lengthOffset = p_u_28.size.lengthOffset
		else
			v35.width = 3
			v35.height = 3
			v35.heightOffset = 0
			v35.length = 3
			v35.lengthOffset = 0
		end
		v35.width = p_u_29:getValue(p34 .. "#width", v35.width)
		v35.height = p_u_29:getValue(p34 .. "#height", v35.height)
		v35.heightOffset = p_u_29:getValue(p34 .. "#heightOffset", v35.heightOffset)
		v35.length = p_u_29:getValue(p34 .. "#length", v35.length)
		v35.lengthOffset = p_u_29:getValue(p34 .. "#lengthOffset", v35.lengthOffset)
		v35.hasCollision = p_u_29:getValue(p34 .. "#hasCollision", true)
		v35.isDirectAttachment = false
		v35.agentAttachments = {}
		if p_u_32 ~= false then
			p_u_28:loadAIAgentAttachmentsFromXML(p_u_29, p34 .. ".agentAttachment", v35.agentAttachments, false, true)
		end
		if p_u_33 == true and v35.jointNode == nil then
			Logging.xmlWarning(p_u_29, "No joint node defined for ai agent sub attachable \'%s\'!", p34)
		else
			local v36 = p_u_31
			table.insert(v36, v35)
		end
	end)
	if p_u_32 == nil and #p_u_31 == 0 then
		Logging.xmlWarning(p_u_29, "Missing ai agent attachment definition for attachable vehicle")
	end
end
function AIVehicle.validateAIAgentAttachments(p37, p38, p39)
	for v40 = 1, #p38 do
		local v41 = p38[v40]
		for v42 = 1, #p39 do
			if v41.jointNode == nil or v41.jointNode == p39[v42].node then
				v41.isDirectAttachment = true
			end
		end
		if v41.rotCenterNode == nil then
			if v41.rotCenterPosition == nil or #v41.rotCenterPosition ~= 2 then
				if v41.rotCenterWheelIndices ~= nil and (#v41.rotCenterWheelIndices > 0 and p37.getWheels ~= nil) then
					local v43 = p37:getWheels()
					local v44 = nil
					local v45 = 0
					local v46 = 0
					local v47 = 0
					local v48 = 0
					local v49 = 0
					local v50 = 0
					local v51 = 0
					for v52 = 1, #v41.rotCenterWheelIndices do
						local v53 = v41.rotCenterWheelIndices[v52]
						local v54 = v43[v53]
						if v54 == nil then
							Logging.xmlWarning(p37.xmlFile, "Unknown wheel index \'%d\' ground in ai agent attachment entry \'vehicle.ai.agentAttachment(%d)\'!", v53, v40 - 1)
						else
							v44 = v44 or v54.node
							local v55, v56, v57 = localToLocal(v54.repr, v44, 0, -v54.physics.radius, 0)
							local v58, v59, v60 = localDirectionToLocal(v54.driveNode, v44, 0, 0, 1)
							v48 = v48 + v55
							v49 = v49 + v56
							v46 = v46 + v57
							v50 = v50 + v58
							v51 = v51 + v59
							v47 = v47 + v60
							v45 = v45 + 1
						end
					end
					if v45 > 0 then
						v48 = v48 / v45
						v49 = v49 / v45
						v46 = v46 / v45
						v50 = v50 / v45
						v51 = v51 / v45
						v47 = v47 / v45
					end
					local v61, v62, v63 = MathUtil.vector3Normalize(v50, v51, v47)
					if v41.useSize then
						v41.lengthOffset = p37.size.lengthOffset - v46
					end
					local v64 = createTransformGroup("aiAgentAttachmentRotCenter" .. v40)
					link(v44, v64)
					setTranslation(v64, v48, v49, v46)
					v41.rotCenterNode = v64
					if v45 > 0 and MathUtil.vector3Length(v61, v62, v63) > 0 then
						setDirection(v64, v61, v62, v63, 0, 1, 0)
					end
				end
			else
				local v65 = createTransformGroup("aiAgentAttachmentRotCenter" .. v40)
				link(p37.components[1].node, v65)
				setTranslation(v65, v41.rotCenterPosition[1], 0, v41.rotCenterPosition[2])
				v41.rotCenterNode = v65
			end
		end
		if v41.rotCenterNode == nil then
			v41.rootNode = p37.rootNode
		end
		if v41.rotCenterNode ~= nil then
			if v41.jointNode == nil then
				v41.jointNodeToHitchOffset = {}
				for v66 = 1, #p39 do
					local _, _, v67 = localToLocal(p39[v66].node, v41.rotCenterNode, 0, 0, 0)
					v41.jointNodeToHitchOffset[p39[v66].node] = v67
				end
			else
				local _, _, v68 = localToLocal(v41.jointNode, v41.rotCenterNode, 0, 0, 0)
				v41.trailerHitchOffset = v68
			end
		end
		p37:validateAIAgentAttachments(v41.agentAttachments, p39)
	end
end
function AIVehicle.drawAIAgentAttachments(p69, p70)
	local v71 = p69.spec_aiVehicle
	local v72 = p70 or v71.agentAttachments
	for v73 = 1, #v72 do
		local v74 = v72[v73]
		if v74.rotCenterNode == nil then
			v71.debugSizeBox:setColorRGBA(0, 0.15, 1)
			v71.debugSizeBox:createWithNode(v74.rootNode, v74.width, v74.height, v74.length, 0, v74.height * 0.5 + v74.heightOffset, v74.lengthOffset)
			v71.debugSizeBox:draw()
		else
			v71.debugSizeBox:setColorRGBA(0, 1, 0.25)
			v71.debugSizeBox:createWithNode(v74.rotCenterNode, v74.width, v74.height, v74.length, 0, v74.height * 0.5 + v74.heightOffset, v74.lengthOffset)
			v71.debugSizeBox:draw()
		end
		p69:drawAIAgentAttachments(v74.agentAttachments)
	end
end
function AIVehicle.raiseAIEvent(p75, p76, p77, ...)
	local v78 = p75.rootVehicle.actionController
	for _, v79 in ipairs(p75.rootVehicle.childVehicles) do
		if v79 ~= p75 then
			p75:safeRaiseAIEvent(v79, p77, ...)
			if v78 ~= nil then
				v78:onAIEvent(v79, p77)
			end
		end
	end
	p75:safeRaiseAIEvent(p75, p77, ...)
	if v78 ~= nil then
		v78:onAIEvent(p75, p77)
	end
	p75:safeRaiseAIEvent(p75, p76, ...)
	if v78 ~= nil then
		v78:onAIEvent(p75, p76)
	end
end
function AIVehicle.safeRaiseAIEvent(_, p80, p81, ...)
	if p80.eventListeners[p81] ~= nil then
		SpecializationUtil.raiseEvent(p80, p81, ...)
	end
end
function AIVehicle.getIsAIReadyToDrive(_)
	return true
end
function AIVehicle.getIsAIPreparingToDrive(_)
	return false
end

source("dataS/scripts/vehicles/specializations/events/WearableRepairEvent.lua")
source("dataS/scripts/vehicles/specializations/events/WearableRepaintEvent.lua")
Wearable = {}
Wearable.SEND_NUM_BITS = 6
Wearable.SEND_MAX_VALUE = 2 ^ Wearable.SEND_NUM_BITS - 1
Wearable.SEND_THRESHOLD = 1 / Wearable.SEND_MAX_VALUE
function Wearable.prerequisitesPresent(_)
	return true
end
function Wearable.initSpecialization()
	if Platform.gameplay.hasVehicleDamage then
		g_storeManager:addSpecType("wearable", "shopListAttributeIconCondition", Wearable.loadSpecValueCondition, Wearable.getSpecValueCondition, StoreSpecies.VEHICLE)
	end
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Wearable")
	v1:register(XMLValueType.FLOAT, "vehicle.wearable#wearDuration", "Duration until fully worn (minutes)", 600)
	v1:register(XMLValueType.FLOAT, "vehicle.wearable#workMultiplier", "Multiplier while working", 20)
	v1:register(XMLValueType.FLOAT, "vehicle.wearable#fieldMultiplier", "Multiplier while on field", 2)
	v1:register(XMLValueType.BOOL, "vehicle.wearable#showOnHud", "Show the damage on the hud", true)
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).wearable.wearNode(?)#amount", "Wear amount")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).wearable#damage", "Damage amount")
end
function Wearable.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "addAllSubWearableNodes", Wearable.addAllSubWearableNodes)
	SpecializationUtil.registerFunction(p3, "addDamageAmount", Wearable.addDamageAmount)
	SpecializationUtil.registerFunction(p3, "addToGlobalWearableNode", Wearable.addToGlobalWearableNode)
	SpecializationUtil.registerFunction(p3, "addToLocalWearableNode", Wearable.addToLocalWearableNode)
	SpecializationUtil.registerFunction(p3, "addWearableNode", Wearable.addWearableNode)
	SpecializationUtil.registerFunction(p3, "addWearAmount", Wearable.addWearAmount)
	SpecializationUtil.registerFunction(p3, "getDamageAmount", Wearable.getDamageAmount)
	SpecializationUtil.registerFunction(p3, "getDamageShowOnHud", Wearable.getDamageShowOnHud)
	SpecializationUtil.registerFunction(p3, "getNodeWearAmount", Wearable.getNodeWearAmount)
	SpecializationUtil.registerFunction(p3, "getUsageCausesDamage", Wearable.getUsageCausesDamage)
	SpecializationUtil.registerFunction(p3, "getUsageCausesWear", Wearable.getUsageCausesWear)
	SpecializationUtil.registerFunction(p3, "getWearMultiplier", Wearable.getWearMultiplier)
	SpecializationUtil.registerFunction(p3, "getWearTotalAmount", Wearable.getWearTotalAmount)
	SpecializationUtil.registerFunction(p3, "getWorkWearMultiplier", Wearable.getWorkWearMultiplier)
	SpecializationUtil.registerFunction(p3, "removeAllSubWearableNodes", Wearable.removeAllSubWearableNodes)
	SpecializationUtil.registerFunction(p3, "removeWearableNode", Wearable.removeWearableNode)
	SpecializationUtil.registerFunction(p3, "repaintVehicle", Wearable.repaintVehicle)
	SpecializationUtil.registerFunction(p3, "repairVehicle", Wearable.repairVehicle)
	SpecializationUtil.registerFunction(p3, "setDamageAmount", Wearable.setDamageAmount)
	SpecializationUtil.registerFunction(p3, "setNodeWearAmount", Wearable.setNodeWearAmount)
	SpecializationUtil.registerFunction(p3, "updateDamageAmount", Wearable.updateDamageAmount)
	SpecializationUtil.registerFunction(p3, "updateWearAmount", Wearable.updateWearAmount)
	SpecializationUtil.registerFunction(p3, "validateWearableNode", Wearable.validateWearableNode)
end
function Wearable.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getVehicleDamage", Wearable.getVehicleDamage)
	SpecializationUtil.registerOverwrittenFunction(p4, "getRepairPrice", Wearable.getRepairPrice)
	SpecializationUtil.registerOverwrittenFunction(p4, "getRepaintPrice", Wearable.getRepaintPrice)
	SpecializationUtil.registerOverwrittenFunction(p4, "showInfo", Wearable.showInfo)
end
function Wearable.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", Wearable)
	SpecializationUtil.registerEventListener(p5, "onLoadFinished", Wearable)
	if not GS_IS_MOBILE_VERSION then
		SpecializationUtil.registerEventListener(p5, "onSaleItemSet", Wearable)
		SpecializationUtil.registerEventListener(p5, "onReadStream", Wearable)
		SpecializationUtil.registerEventListener(p5, "onWriteStream", Wearable)
		SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", Wearable)
		SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", Wearable)
		SpecializationUtil.registerEventListener(p5, "onUpdateTick", Wearable)
	end
end
function Wearable.onLoad(p6, _)
	local v7 = p6.spec_wearable
	v7.wearableNodes = {}
	v7.wearableNodesByIndex = {}
	p6:addToLocalWearableNode(nil, Wearable.updateWearAmount, nil, nil)
	v7.wearDuration = p6.xmlFile:getValue("vehicle.wearable#wearDuration", 600) * 60 * 1000
	if v7.wearDuration ~= 0 then
		v7.wearDuration = 1 / v7.wearDuration
	end
	v7.totalAmount = 0
	v7.damage = 0
	v7.damageByCurve = 0
	v7.damageSent = 0
	v7.workMultiplier = p6.xmlFile:getValue("vehicle.wearable#workMultiplier", 20)
	v7.fieldMultiplier = p6.xmlFile:getValue("vehicle.wearable#fieldMultiplier", 2)
	v7.showOnHud = p6.xmlFile:getValue("vehicle.wearable#showOnHud", true)
	v7.dirtyFlag = p6:getNextDirtyFlag()
end
function Wearable.onLoadFinished(p8, p9)
	local v10 = p8.spec_wearable
	if p9 ~= nil then
		v10.damage = p9.xmlFile:getValue(p9.key .. ".wearable#damage", 0)
		local v11 = v10.damage - 0.3
		v10.damageByCurve = math.max(v11, 0) / 0.7
	end
	if v10.wearableNodes ~= nil then
		for _, v12 in pairs(p8.components) do
			p8:addAllSubWearableNodes(v12.node)
		end
		if p9 ~= nil then
			for v13, v14 in ipairs(v10.wearableNodes) do
				local v15 = string.format("%s.wearable.wearNode(%d)", p9.key, v13 - 1)
				p8:setNodeWearAmount(v14, p9.xmlFile:getValue(v15 .. "#amount", 0), true)
			end
			return
		end
		for _, v16 in ipairs(v10.wearableNodes) do
			p8:setNodeWearAmount(v16, 0, true)
		end
	end
end
function Wearable.onSaleItemSet(p17, p18)
	p17:addDamageAmount(p18.damage or 0, true)
	p17:addWearAmount(p18.wear or 0, true)
end
function Wearable.saveToXMLFile(p19, p20, p21, _)
	local v22 = p19.spec_wearable
	p20:setValue(p21 .. "#damage", v22.damage)
	if v22.wearableNodes ~= nil then
		for v23, v24 in ipairs(v22.wearableNodes) do
			p20:setValue(string.format("%s.wearNode(%d)", p21, v23 - 1) .. "#amount", p19:getNodeWearAmount(v24))
		end
	end
end
function Wearable.onReadStream(p25, p26, _)
	local v27 = p25.spec_wearable
	p25:setDamageAmount(streamReadUIntN(p26, Wearable.SEND_NUM_BITS) / Wearable.SEND_MAX_VALUE, true)
	if v27.wearableNodes ~= nil then
		for _, v28 in ipairs(v27.wearableNodes) do
			p25:setNodeWearAmount(v28, streamReadUIntN(p26, Wearable.SEND_NUM_BITS) / Wearable.SEND_MAX_VALUE, true)
		end
	end
end
function Wearable.onWriteStream(p29, p30, _)
	local v31 = p29.spec_wearable
	local v32 = streamWriteUIntN
	local v33 = v31.damage * Wearable.SEND_MAX_VALUE + 0.5
	v32(p30, math.floor(v33), Wearable.SEND_NUM_BITS)
	if v31.wearableNodes ~= nil then
		for _, v34 in ipairs(v31.wearableNodes) do
			local v35 = streamWriteUIntN
			local v36 = p29:getNodeWearAmount(v34) * Wearable.SEND_MAX_VALUE + 0.5
			v35(p30, math.floor(v36), Wearable.SEND_NUM_BITS)
		end
	end
end
function Wearable.onReadUpdateStream(p37, p38, _, p39)
	local v40 = p37.spec_wearable
	if p39:getIsServer() and streamReadBool(p38) then
		p37:setDamageAmount(streamReadUIntN(p38, Wearable.SEND_NUM_BITS) / Wearable.SEND_MAX_VALUE, true)
		if v40.wearableNodes ~= nil then
			for _, v41 in ipairs(v40.wearableNodes) do
				p37:setNodeWearAmount(v41, streamReadUIntN(p38, Wearable.SEND_NUM_BITS) / Wearable.SEND_MAX_VALUE, true)
			end
		end
	end
end
function Wearable.onWriteUpdateStream(p42, p43, p44, p45)
	local v46 = p42.spec_wearable
	if not p44:getIsServer() and streamWriteBool(p43, bitAND(p45, v46.dirtyFlag) ~= 0) then
		local v47 = streamWriteUIntN
		local v48 = v46.damage * Wearable.SEND_MAX_VALUE + 0.5
		v47(p43, math.floor(v48), Wearable.SEND_NUM_BITS)
		if v46.wearableNodes ~= nil then
			for _, v49 in ipairs(v46.wearableNodes) do
				local v50 = streamWriteUIntN
				local v51 = p42:getNodeWearAmount(v49) * Wearable.SEND_MAX_VALUE + 0.5
				v50(p43, math.floor(v51), Wearable.SEND_NUM_BITS)
			end
		end
	end
end
function Wearable.onUpdateTick(p52, p53, _, _, _)
	local v54 = p52.spec_wearable
	if v54.wearableNodes ~= nil and p52.isServer then
		local v55 = p52:updateDamageAmount(p53)
		if v55 ~= 0 then
			p52:setDamageAmount(v54.damage + v55)
		end
		for _, v56 in ipairs(v54.wearableNodes) do
			local v57 = v56.updateFunc(p52, v56, p53)
			if v57 ~= 0 then
				p52:setNodeWearAmount(v56, p52:getNodeWearAmount(v56) + v57)
			end
		end
	end
end
function Wearable.setDamageAmount(p58, p59, p60)
	local v61 = p58.spec_wearable
	local v62 = math.max(p59, 0)
	v61.damage = math.min(v62, 1)
	local v63 = v61.damage - 0.3
	v61.damageByCurve = math.max(v63, 0) / 0.7
	local v64 = v61.damageSent - v61.damage
	if (math.abs(v64) > Wearable.SEND_THRESHOLD or p60) and p58.isServer then
		p58:raiseDirtyFlags(v61.dirtyFlag)
		v61.damageSent = v61.damage
	end
end
function Wearable.updateWearAmount(p65, p66, p67)
	local v68 = p65.spec_wearable
	return not p65:getUsageCausesWear() and 0 or p67 * v68.wearDuration * p65:getWearMultiplier(p66) * 0.5
end
function Wearable.updateDamageAmount(p69, p70)
	local v71 = p69.spec_wearable
	if not p69:getUsageCausesDamage() then
		return 0
	end
	local v72
	if p69.lifetime == nil or p69.lifetime == 0 then
		v72 = 1
	else
		local v73 = p69.age / p69.lifetime
		local v74 = 0.15 * math.min(v73, 1)
		local v75 = p69.operatingTime / 3600000 / (p69.lifetime * EconomyManager.LIFETIME_OPERATINGTIME_RATIO)
		local v76 = 0.85 * math.min(v75, 1)
		v72 = 1 + EconomyManager.MAX_DAILYUPKEEP_MULTIPLIER * (v74 + v76)
	end
	return p70 * v71.wearDuration * 0.35 * v72
end
function Wearable.getUsageCausesWear(_)
	return true
end
function Wearable.getUsageCausesDamage(p77)
	if p77.spec_motorized == nil and getIsSleeping(p77.rootNode) then
		return false
	end
	local v78 = p77.isActive
	if v78 then
		v78 = p77.propertyState ~= VehiclePropertyState.MISSION
	end
	return v78
end
function Wearable.addWearAmount(p79, p80, p81)
	local v82 = p79.spec_wearable
	if v82.wearableNodes ~= nil then
		for _, v83 in ipairs(v82.wearableNodes) do
			p79:setNodeWearAmount(v83, p79:getNodeWearAmount(v83) + p80, p81)
		end
	end
end
function Wearable.addDamageAmount(p84, p85, p86)
	p84:setDamageAmount(p84.spec_wearable.damage + p85, p86)
end
function Wearable.setNodeWearAmount(p87, p88, p89, p90)
	local v91 = p87.spec_wearable
	p88.wearAmount = math.clamp(p89, 0, 1)
	local v92 = p88.wearAmountSent - p88.wearAmount
	if math.abs(v92) > Wearable.SEND_THRESHOLD or p90 then
		for _, v93 in pairs(p88.nodes) do
			setShaderParameter(v93, "scratches_dirt_snow_wetness", p88.wearAmount, nil, nil, nil, false)
		end
		if p87.isServer then
			p87:raiseDirtyFlags(v91.dirtyFlag)
			p88.wearAmountSent = p88.wearAmount
		end
		v91.totalAmount = 0
		for v94 = 1, #v91.wearableNodes do
			v91.totalAmount = v91.totalAmount + v91.wearableNodes[v94].wearAmount
		end
		v91.totalAmount = v91.totalAmount / #v91.wearableNodes
	end
end
function Wearable.getNodeWearAmount(_, p95)
	return p95.wearAmount
end
function Wearable.getWearTotalAmount(p96)
	return p96.spec_wearable.totalAmount
end
function Wearable.getDamageAmount(p97)
	return p97.spec_wearable.damage
end
function Wearable.getDamageShowOnHud(p98)
	return p98.spec_wearable.showOnHud
end
function Wearable.repairVehicle(p99)
	if p99.isServer then
		g_currentMission:addMoney(-p99:getRepairPrice(), p99:getOwnerFarmId(), MoneyType.VEHICLE_REPAIR, true, true)
		p99:setDamageAmount(0)
		p99:raiseDirtyFlags(p99.spec_wearable.dirtyFlag)
		local v100, _ = g_farmManager:updateFarmStats(p99:getOwnerFarmId(), "repairVehicleCount", 1)
		if v100 ~= nil then
			g_achievementManager:tryUnlock("VehicleRepairFirst", v100)
			g_achievementManager:tryUnlock("VehicleRepair", v100)
		end
	end
end
function Wearable.repaintVehicle(p101)
	if p101.isServer then
		g_currentMission:addMoney(-p101:getRepaintPrice(), p101:getOwnerFarmId(), MoneyType.VEHICLE_REPAIR, true, true)
		local v102 = p101.spec_wearable
		for _, v103 in ipairs(v102.wearableNodes) do
			p101:setNodeWearAmount(v103, 0, true)
		end
		p101:raiseDirtyFlags(v102.dirtyFlag)
		local v104, _ = g_farmManager:updateFarmStats(p101:getOwnerFarmId(), "repaintVehicleCount", 1)
		if v104 ~= nil then
			g_achievementManager:tryUnlock("VehicleRepaint", v104)
		end
	end
end
function Wearable.getRepairPrice(p105, p106)
	return p106(p105) + Wearable.calculateRepairPrice(p105:getPrice(), p105.spec_wearable.damage)
end
function Wearable.calculateRepairPrice(p107, p108)
	return p107 * math.pow(p108, 1.5) * 0.09
end
function Wearable.getRepaintPrice(p109, p110)
	return p110(p109) + Wearable.calculateRepaintPrice(p109:getPrice(), p109:getWearTotalAmount())
end
function Wearable.showInfo(p111, p112, p113)
	local v114 = p111.spec_wearable.damage
	if v114 > 0.01 then
		p113:addLine(g_i18n:getText("infohud_damage"), string.format("%d %%", v114 * 100))
	end
	p112(p111, p113)
end
function Wearable.calculateRepaintPrice(p115, p116)
	local v117 = p116 / 100
	return p115 * math.sqrt(v117) * 2
end
function Wearable.getVehicleDamage(p118, p119)
	local v120 = p119(p118) + p118.spec_wearable.damageByCurve
	return math.min(v120, 1)
end
function Wearable.addAllSubWearableNodes(p121, p122)
	if p122 ~= nil then
		I3DUtil.iterateShaderParameterNodesRecursively(p122, "scratches_dirt_snow_wetness", p121.addWearableNode, p121)
	end
end
function Wearable.addWearableNode(p123, p124)
	local v125, v126, v127, v128 = p123:validateWearableNode(p124)
	if v125 then
		p123:addToGlobalWearableNode(p124)
	elseif v126 ~= nil then
		p123:addToLocalWearableNode(p124, v126, v127, v128)
	end
end
function Wearable.validateWearableNode(_, _)
	return true, nil
end
function Wearable.addToGlobalWearableNode(p129, p130)
	local v131 = p129.spec_wearable
	if v131.wearableNodes[1] ~= nil then
		v131.wearableNodes[1].nodes[p130] = p130
	end
end
function Wearable.addToLocalWearableNode(p132, p133, p134, p135, p136)
	local v137 = p132.spec_wearable
	local v138 = {}
	if p135 ~= nil then
		if v137.wearableNodesByIndex[p135] ~= nil then
			v137.wearableNodesByIndex[p135].nodes[p133] = p133
			return
		end
		v137.wearableNodesByIndex[p135] = v138
	end
	v138.nodes = {}
	if p133 ~= nil then
		v138.nodes[p133] = p133
	end
	v138.updateFunc = p134
	v138.wearAmount = 0
	v138.wearAmountSent = 0
	if p136 ~= nil then
		for v139, v140 in pairs(p136) do
			v138[v139] = v140
		end
	end
	local v141 = v137.wearableNodes
	table.insert(v141, v138)
end
function Wearable.removeAllSubWearableNodes(p142, p143)
	if p143 ~= nil then
		I3DUtil.iterateShaderParameterNodesRecursively(p143, "scratches_dirt_snow_wetness", p142.removeWearableNode, p142)
	end
end
function Wearable.removeWearableNode(p144, p145)
	local v146 = p144.spec_wearable
	if v146.wearableNodes ~= nil and p145 ~= nil then
		for _, v147 in ipairs(v146.wearableNodes) do
			v147.nodes[p145] = nil
		end
	end
end
function Wearable.getWearMultiplier(p148)
	local v149 = p148.spec_wearable
	local v150 = p148:getLastSpeed() < 1 and 0 or 1
	if p148:getIsOnField() then
		v150 = v150 * v149.fieldMultiplier
	end
	return v150
end
function Wearable.getWorkWearMultiplier(p151)
	return p151.spec_wearable.workMultiplier
end
function Wearable.updateDebugValues(p152, p153)
	local v154 = p152.spec_wearable
	local v155 = p152:updateDamageAmount(3600000)
	local v156 = {
		["name"] = "Damage",
		["value"] = string.format("%.4f a/h (%.2f)", v155, p152:getDamageAmount())
	}
	table.insert(p153, v156)
	if v154.wearableNodes ~= nil and p152.isServer then
		for v157, v158 in ipairs(v154.wearableNodes) do
			local v159 = v158.updateFunc(p152, v158, 3600000)
			local v160 = {
				["name"] = "WearableNode" .. v157,
				["value"] = string.format("%.4f a/h (%.6f)", v159, p152:getNodeWearAmount(v158))
			}
			table.insert(p153, v160)
		end
	end
end
function Wearable.loadSpecValueCondition(_, _, _)
	return nil
end
function Wearable.getSpecValueCondition(_, p161)
	if p161 == nil then
		return nil
	else
		return string.format("%d%%", p161:getDamageAmount() * 100)
	end
end

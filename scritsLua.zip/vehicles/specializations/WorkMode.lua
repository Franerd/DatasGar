source("dataS/scripts/vehicles/specializations/events/SetWorkModeEvent.lua")
WorkMode = {}
source("dataS/scripts/gui/hud/extensions/WorkModeHUDExtension.lua")
WorkMode.WORKMODE_SEND_NUM_BITS = 4
function WorkMode.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(WorkArea, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	end
	return v2
end
function WorkMode.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("workMode", g_i18n:getText("configuration_workMode"), "workModes", VehicleConfigurationItem)
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("WorkMode")
	WorkMode.registerWorkModeXMLPaths(v3, "vehicle.workModes")
	WorkMode.registerWorkModeXMLPaths(v3, "vehicle.workModes.workModeConfigurations.workModeConfiguration(?)")
	v3:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.INT, "vehicles.vehicle(?).workMode#state", "Current work mode", 1)
end
function WorkMode.registerWorkModeXMLPaths(p4, p5)
	p4:register(XMLValueType.FLOAT, p5 .. "#foldMaxLimit", "Fold max. limit to change mode", 1)
	p4:register(XMLValueType.FLOAT, p5 .. "#foldMinLimit", "Fold min. limit to change mode", 0)
	p4:register(XMLValueType.BOOL, p5 .. "#allowChangeOnLowered", "Allow change while lowered", true)
	p4:register(XMLValueType.BOOL, p5 .. "#allowChangeWhileTurnedOn", "Allow change while turned on", true)
	p4:addDelayedRegistrationPath(p5 .. ".workMode(?)", "WorkMode:workMode")
	p4:register(XMLValueType.L10N_STRING, p5 .. ".workMode(?)#name", "Work mode name")
	p4:register(XMLValueType.STRING, p5 .. ".workMode(?)#inputBindingName", "Input action name for quick access")
	p4:register(XMLValueType.STRING, p5 .. ".workMode(?).turnedOnAnimations.turnedOnAnimation(?)#name", "Turned on animation name")
	p4:register(XMLValueType.FLOAT, p5 .. ".workMode(?).turnedOnAnimations.turnedOnAnimation(?)#turnOnFadeTime", "Turn on fade time (sec.)", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".workMode(?).turnedOnAnimations.turnedOnAnimation(?)#turnOffFadeTime", "Turn off fade time (sec.)", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".workMode(?).turnedOnAnimations.turnedOnAnimation(?)#speedScale", "Speed scale", 1)
	p4:register(XMLValueType.STRING, p5 .. ".workMode(?).loweringAnimations.loweringAnimation(?)#name", "Lowering animation name")
	p4:register(XMLValueType.FLOAT, p5 .. ".workMode(?).loweringAnimations.loweringAnimation(?)#speed", "Speed scale", 1)
	p4:register(XMLValueType.INT, p5 .. ".workMode(?).workAreas.workArea(?)#workAreaIndex", "Work area index")
	p4:register(XMLValueType.INT, p5 .. ".workMode(?).workAreas.workArea(?)#dropAreaIndex", "Drop area index")
	p4:register(XMLValueType.STRING, p5 .. ".workMode(?).animation(?)#name", "Mode change animation name")
	p4:register(XMLValueType.FLOAT, p5 .. ".workMode(?).animation(?)#speed", "Mode change animation speed", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".workMode(?).animation(?)#stopTime", "Mode change animation stop time")
	p4:register(XMLValueType.BOOL, p5 .. ".workMode(?).animation(?)#repeatAfterUnfolding", "Repeat animation after unfolding", false)
	p4:register(XMLValueType.FLOAT, p5 .. ".workMode(?).animation(?)#repeatStartTime", "Repeat start time")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".workMode(?).movingToolLimit#node", "Target moving tool node")
	p4:register(XMLValueType.ANGLE, p5 .. ".workMode(?).movingToolLimit#minRot", "Min. rotation", 0)
	p4:register(XMLValueType.ANGLE, p5 .. ".workMode(?).movingToolLimit#maxRot", "Max. rotation", 0)
	EffectManager.registerEffectXMLPaths(p4, p5 .. ".workMode(?).windrowerEffect")
	AnimationManager.registerAnimationNodesXMLPaths(p4, p5 .. ".workMode(?).animationNodes")
	AIImplement.registerAIImplementBaseXMLPaths(p4, p5 .. ".workMode(?).ai")
	p4:register(XMLValueType.INT, Sprayer.SPRAY_TYPE_XML_KEY .. "#workModeIndex", "Index of work mode to activate spray type")
	p4:addDelayedRegistrationFunc("Cylindered:movingTool", function(p6, p7)
		p6:register(XMLValueType.BOOL, p7 .. "#allowWhileChangingWorkMode", "Allow movement while changing work mode", true)
	end)
end
function WorkMode.registerEvents(p8)
	SpecializationUtil.registerEvent(p8, "onWorkModeChanged")
end
function WorkMode.registerFunctions(p9)
	SpecializationUtil.registerFunction(p9, "loadWorkModeFromXML", WorkMode.loadWorkModeFromXML)
	SpecializationUtil.registerFunction(p9, "setWorkMode", WorkMode.setWorkMode)
	SpecializationUtil.registerFunction(p9, "getWorkMode", WorkMode.getWorkMode)
	SpecializationUtil.registerFunction(p9, "getIsWorkModeChangeAllowed", WorkMode.getIsWorkModeChangeAllowed)
	SpecializationUtil.registerFunction(p9, "deactivateWindrowerEffects", WorkMode.deactivateWindrowerEffects)
end
function WorkMode.registerOverwrittenFunctions(p10)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsWorkAreaActive", WorkMode.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "getCanBeSelected", WorkMode.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p10, "getAllowsLowering", WorkMode.getAllowsLowering)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadSprayTypeFromXML", WorkMode.loadSprayTypeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsSprayTypeActive", WorkMode.getIsSprayTypeActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadMovingToolFromXML", WorkMode.loadMovingToolFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsMovingToolActive", WorkMode.getIsMovingToolActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "getAreEffectsVisible", WorkMode.getAreEffectsVisible)
end
function WorkMode.registerEventListeners(p11)
	SpecializationUtil.registerEventListener(p11, "onLoad", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onPostLoad", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onDelete", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onReadStream", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onWriteStream", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onReadUpdateStream", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onWriteUpdateStream", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onUpdate", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onUpdateTick", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onDraw", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onTurnedOn", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onTurnedOff", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onDeactivate", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onSetLowered", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onFoldStateChanged", WorkMode)
	SpecializationUtil.registerEventListener(p11, "onRegisterActionEvents", WorkMode)
end
function WorkMode.onLoad(p12, _)
	local v13 = p12.spec_workMode
	local v14 = p12.configurations.workMode or 1
	local v15 = string.format("vehicle.workModes.workModeConfigurations.workModeConfiguration(%d)", v14 - 1)
	local v16 = not p12.xmlFile:hasProperty(v15) and "vehicle.workModes" or v15
	if p12.xmlFile:hasProperty(v16) then
		v13.state = 1
		v13.stateMax = 0
		v13.foldMaxLimit = p12.xmlFile:getValue(v16 .. "#foldMaxLimit", 1)
		v13.foldMinLimit = p12.xmlFile:getValue(v16 .. "#foldMinLimit", 0)
		v13.allowChangeOnLowered = p12.xmlFile:getValue(v16 .. "#allowChangeOnLowered", true)
		v13.allowChangeWhileTurnedOn = p12.xmlFile:getValue(v16 .. "#allowChangeWhileTurnedOn", true)
		v13.workModes = {}
		for _, v17 in p12.xmlFile:iterator(v16 .. ".workMode") do
			local v18 = {}
			if p12:loadWorkModeFromXML(p12.xmlFile, v17, v18) then
				local v19 = v13.workModes
				table.insert(v19, v18)
			end
		end
		v13.stateMax = #v13.workModes
		if v13.stateMax > 2 ^ WorkMode.WORKMODE_SEND_NUM_BITS - 1 then
			printError("Error: WorkMode only supports " .. 2 ^ WorkMode.WORKMODE_SEND_NUM_BITS - 1 .. " modes!")
		end
		if v13.stateMax > 0 then
			p12:setWorkMode(1, true)
		end
		v13.hudExtension = WorkModeHUDExtension.new(p12)
		v13.accumulatedFruitType = FruitType.UNKNOWN
		v13.dirtyFlag = p12:getNextDirtyFlag()
	end
	if v13.stateMax == nil or v13.stateMax == 0 then
		SpecializationUtil.removeEventListener(p12, "onPostLoad", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onDelete", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onReadStream", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onWriteStream", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onReadUpdateStream", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onWriteUpdateStream", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onUpdate", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onUpdateTick", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onDraw", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onTurnedOn", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onTurnedOff", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onDeactivate", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onSetLowered", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onFoldStateChanged", WorkMode)
		SpecializationUtil.removeEventListener(p12, "onRegisterActionEvents", WorkMode)
	end
end
function WorkMode.onPostLoad(p20, p21)
	if p21 ~= nil and not p21.resetVehicles then
		local v22 = p20.spec_workMode
		if v22.stateMax > 0 and p21.xmlFile:hasProperty(p21.key .. ".workMode#state") then
			local v23 = p21.xmlFile:getValue(p21.key .. ".workMode#state", 1)
			local v24 = v22.stateMax
			p20:setWorkMode(math.clamp(v23, 1, v24), true)
			AnimatedVehicle.updateAnimations(p20, 99999999, true)
			if p20.spec_foldable ~= nil and (p20.spec_foldable.hasFoldingParts and p20.spec_foldable.foldMoveDirection == 0) then
				local v25 = p20:getFoldAnimTime()
				if v25 <= 0 then
					p20.spec_foldable.foldMoveDirection = -1
					return
				end
				if p20.spec_foldable.foldMiddleAnimTime == v25 then
					p20.spec_foldable.moveToMiddle = true
				end
				p20.spec_foldable.foldMoveDirection = 1
			end
		end
	end
end
function WorkMode.saveToXMLFile(p26, p27, p28, _)
	local v29 = p26.spec_workMode
	if v29.state ~= nil then
		p27:setValue(p28 .. "#state", v29.state)
	end
end
function WorkMode.onDelete(p30)
	local v31 = p30.spec_workMode
	if v31.workModes ~= nil then
		for _, v32 in ipairs(v31.workModes) do
			g_effectManager:deleteEffects(v32.windrowerEffects)
			g_animationManager:deleteAnimations(v32.animationNodes)
		end
	end
	if v31.hudExtension ~= nil then
		v31.hudExtension:delete()
	end
end
function WorkMode.onReadStream(p33, p34, _)
	p33:setWorkMode(streamReadUIntN(p34, WorkMode.WORKMODE_SEND_NUM_BITS), true)
end
function WorkMode.onWriteStream(p35, p36, _)
	local v37 = p35.spec_workMode
	streamWriteUIntN(p36, v37.state, WorkMode.WORKMODE_SEND_NUM_BITS)
end
function WorkMode.onReadUpdateStream(p38, p39, _, p40)
	if p40:getIsServer() and streamReadBool(p39) then
		local v41 = p38.spec_workMode
		local v42 = v41.workModes[v41.state]
		for _, v43 in ipairs(v42.windrowerEffects) do
			if streamReadBool(p39) then
				v43.lastChargeTime = g_currentMission.time
			end
		end
		v41.accumulatedFruitType = streamReadUIntN(p39, FruitTypeManager.SEND_NUM_BITS)
	end
end
function WorkMode.onWriteUpdateStream(p44, p45, p46, p47)
	if not p46:getIsServer() then
		local v48 = p44.spec_workMode
		if streamWriteBool(p45, bitAND(p47, v48.dirtyFlag) ~= 0) then
			local v49 = v48.workModes[v48.state]
			for _, v50 in ipairs(v49.windrowerEffects) do
				streamWriteBool(p45, v50.lastChargeTime + 500 > g_currentMission.time)
			end
			streamWriteUIntN(p45, v48.accumulatedFruitType, FruitTypeManager.SEND_NUM_BITS)
		end
	end
end
function WorkMode.onUpdate(p51, p52, _, _, _)
	local v53 = p51.spec_workMode
	if p51.isClient then
		local v54 = v53.workModes[v53.state]
		for v55 = 1, #v53.workModes do
			for _, v56 in pairs(v53.workModes[v55].turnedOnAnimations) do
				if v56.speedDirection ~= 0 then
					local v57 = v56.turnOnFadeTime
					if v56.speedDirection == -1 then
						v57 = v56.turnOffFadeTime
					end
					local v58, v59
					if v56.speedDirection == 1 then
						v58 = -1
						v59 = 1
					else
						v58 = 0
						v59 = 1
					end
					local v60 = v56.currentSpeed + v56.speedDirection * p52 / v57
					v56.currentSpeed = math.clamp(v60, v58, v59)
					if p51:getIsAnimationPlaying(v56.name) then
						p51:setAnimationSpeed(v56.name, v56.currentSpeed * v56.speedScale)
					else
						p51:playAnimation(v56.name, v56.currentSpeed * v56.speedScale, p51:getAnimationTime(v56.name), true)
					end
					if v56.speedDirection == -1 and v56.currentSpeed == 0 then
						p51:stopAnimation(v56.name, true)
					end
					if v56.currentSpeed == 1 or v56.currentSpeed == 0 then
						v56.speedDirection = 0
					end
				end
			end
		end
		for _, v61 in pairs(v54.windrowerEffects) do
			if v61.lastChargeTime + 500 > g_currentMission.time then
				local v62 = g_fruitTypeManager:getWindrowFillTypeIndexByFruitTypeIndex(v53.accumulatedFruitType)
				if v62 ~= nil then
					v61:setFillType(v62)
					if not v61:isRunning() then
						g_effectManager:startEffect(v61)
					end
				end
			elseif v61.turnOffRequiredEffect == 0 or v61.turnOffRequiredEffect ~= 0 and not v54.windrowerEffects[v61.turnOffRequiredEffect]:isRunning() then
				g_effectManager:stopEffect(v61)
			end
		end
		local v63 = p51:getIsWorkModeChangeAllowed()
		local v64 = v53.actionEvents[InputAction.TOGGLE_WORKMODE]
		if v64 ~= nil then
			g_inputBinding:setActionEventActive(v64.actionEventId, v63)
		end
		for _, v65 in ipairs(v53.workModes) do
			if v65.inputAction ~= nil then
				local v66 = v53.actionEvents[v65.inputAction]
				if v66 ~= nil then
					g_inputBinding:setActionEventActive(v66.actionEventId, v63)
				end
			end
		end
	end
	if p51.isServer then
		local v67 = v53.workModes[v53.state]
		local v68 = nil
		local v69 = nil
		for _, v70 in ipairs(v67.workAreas) do
			local v71 = p51.spec_workArea.workAreas[v70.workAreaIndex]
			if v71 ~= nil then
				if v71.lastValidPickupFruitType ~= FruitType.UNKNOWN then
					v69 = v71.lastValidPickupFruitType
				end
				v68 = v68 or v71.lastPickupLiters ~= 0
			end
		end
		if v69 ~= nil and v69 ~= v53.accumulatedFruitType then
			v53.accumulatedFruitType = v69
			p51:raiseDirtyFlags(v53.dirtyFlag)
		end
		for _, v72 in pairs(v67.windrowerEffects) do
			if v68 then
				v72.lastChargeTime = g_currentMission.time
				p51:raiseDirtyFlags(v53.dirtyFlag)
			end
		end
	end
end
function WorkMode.onUpdateTick(p73, _, _, _, _)
	local v74 = p73.spec_workMode
	if p73.getFoldAnimTime ~= nil then
		local v75 = p73:getFoldAnimTime()
		if v75 == 0 or v75 == p73.spec_foldable.foldMiddleAnimTime then
			local v76 = v74.workModes[v74.state]
			for _, v77 in pairs(v76.animations) do
				if v77.repeatAfterUnfolding and not v77.repeated then
					local v78 = p73:getAnimationTime(v77.animName)
					if v77.stopTime == nil then
						p73:playAnimation(v77.animName, v77.animSpeed, Utils.getNoNil(v77.repeatStartTime, v78), true)
					else
						p73:setAnimationStopTime(v77.animName, v77.stopTime)
						local v79 = v77.animSpeed
						local v80 = math.abs(v79)
						if v77.stopTime < v78 then
							local v81 = v77.animSpeed
							v80 = -math.abs(v81)
						end
						p73:playAnimation(v77.animName, v80, Utils.getNoNil(v77.repeatStartTime, v78), true)
					end
					v77.repeated = true
				end
			end
		end
		if v74.playDelayedLoweringAnimation ~= nil and (v75 == 1 or (v75 == 0 or v75 == p73.spec_foldable.foldMiddleAnimTime)) then
			WorkMode.onSetLowered(p73, v74.playDelayedLoweringAnimation)
			v74.playDelayedLoweringAnimation = nil
		end
	end
end
function WorkMode.onDraw(p82, _, _, _)
	local v83 = p82.spec_workMode
	if v83.hudExtension ~= nil then
		g_currentMission.hud:addHelpExtension(v83.hudExtension)
	end
end
function WorkMode.onDeactivate(p84)
	WorkMode.deactivateWindrowerEffects(p84)
end
function WorkMode.deactivateWindrowerEffects(p85)
	if p85.isClient then
		local v86 = p85.spec_workMode
		for _, v87 in pairs(v86.workModes) do
			if v87.windrowerEffects ~= nil then
				g_effectManager:stopEffects(v87.windrowerEffects)
			end
		end
	end
end
function WorkMode.loadWorkModeFromXML(p_u_88, p89, p90, p_u_91)
	p_u_91.name = p89:getValue(p90 .. "#name", nil, p_u_88.customEnvironment)
	local v92 = p89:getValue(p90 .. "#inputBindingName")
	if v92 ~= nil and InputAction[v92] ~= nil then
		p_u_91.inputAction = InputAction[v92]
	end
	p_u_91.turnedOnAnimations = {}
	for _, v93 in p89:iterator(p90 .. ".turnedOnAnimations.turnedOnAnimation") do
		local v94 = {
			["name"] = p89:getValue(v93 .. "#name"),
			["turnOnFadeTime"] = p89:getValue(v93 .. "#turnOnFadeTime", 1) * 1000,
			["turnOffFadeTime"] = p89:getValue(v93 .. "#turnOffFadeTime", 1) * 1000,
			["speedScale"] = p89:getValue(v93 .. "#speedScale", 1),
			["speedDirection"] = 0,
			["currentSpeed"] = 0
		}
		if p_u_88:getAnimationExists(v94.name) then
			local v95 = p_u_91.turnedOnAnimations
			table.insert(v95, v94)
		end
	end
	p_u_91.loweringAnimations = {}
	for _, v96 in p89:iterator(p90 .. ".loweringAnimations.loweringAnimation") do
		local v97 = {
			["name"] = p89:getValue(v96 .. "#name"),
			["speed"] = p89:getValue(v96 .. "#speed", 1)
		}
		if p_u_88:getAnimationExists(v97.name) then
			local v98 = p_u_91.loweringAnimations
			table.insert(v98, v97)
		end
	end
	p_u_91.workAreas = {}
	for v99, v100 in p89:iterator(p90 .. ".workAreas.workArea") do
		local v101 = {
			["workAreaIndex"] = p89:getValue(v100 .. "#workAreaIndex", v99),
			["dropAreaIndex"] = p89:getValue(v100 .. "#dropAreaIndex", v99)
		}
		local v102 = p_u_91.workAreas
		table.insert(v102, v101)
	end
	p_u_91.animations = {}
	for _, v103 in p89:iterator(p90 .. ".animation") do
		local v104 = {
			["animName"] = p89:getValue(v103 .. "#name"),
			["animSpeed"] = p89:getValue(v103 .. "#speed", 1),
			["stopTime"] = p89:getValue(v103 .. "#stopTime"),
			["repeatAfterUnfolding"] = p89:getValue(v103 .. "#repeatAfterUnfolding", false),
			["repeatStartTime"] = p89:getValue(v103 .. "#repeatStartTime"),
			["repeated"] = false
		}
		if p_u_88:getAnimationExists(v104.animName) then
			local v105 = p_u_91.animations
			table.insert(v105, v104)
		end
	end
	local v106 = p89:getValue(p90 .. ".movingToolLimit#node", nil, p_u_88.components, p_u_88.i3dMappings)
	if v106 ~= nil then
		p_u_91.movingTool = p_u_88:getMovingToolByNode(v106)
		p_u_91.movingToolMinRot = p89:getValue(p90 .. ".movingToolLimit#minRot", 0)
		p_u_91.movingToolMaxRot = p89:getValue(p90 .. ".movingToolLimit#maxRot", 0)
	end
	p_u_91.windrowerEffects = g_effectManager:loadEffect(p89, string.format("%s.windrowerEffect", p90), p_u_88.components, p_u_88, p_u_88.i3dMappings)
	p_u_91.animationNodes = g_animationManager:loadAnimations(p89, p90 .. ".animationNodes", p_u_88.components, p_u_88, p_u_88.i3dMappings)
	if p_u_88.loadAIImplementBaseSetupFromXML ~= nil then
		p_u_88:loadAIImplementBaseSetupFromXML(p89, p90 .. ".ai", function(_)
			-- upvalues: (copy) p_u_88, (copy) p_u_91
			local v107 = p_u_88.spec_workMode
			return v107.workModes[v107.state] == p_u_91
		end)
	end
	return true
end
function WorkMode.setWorkMode(p108, p109, p110)
	local v111 = p108.spec_workMode
	if p110 == nil or p110 == false then
		if g_server == nil then
			g_client:getServerConnection():sendEvent(SetWorkModeEvent.new(p108, p109))
		else
			g_server:broadcastEvent(SetWorkModeEvent.new(p108, p109), nil, nil, p108)
		end
	end
	if p109 ~= v111.state then
		local v112 = v111.workModes[v111.state]
		if v112.animations ~= nil then
			for _, v113 in pairs(v112.animations) do
				local v114 = p108:getAnimationTime(v113.animName)
				if v113.stopTime == nil then
					p108:playAnimation(v113.animName, -v113.animSpeed, v114, p110)
				end
			end
			g_animationManager:stopAnimations(v112.animationNodes)
		end
		local v115 = v111.workModes[p109]
		if v115.animations ~= nil then
			for _, v116 in pairs(v115.animations) do
				local v117 = p108:getAnimationTime(v116.animName)
				if v116.stopTime == nil then
					p108:playAnimation(v116.animName, v116.animSpeed, v117, p110)
				else
					p108:setAnimationStopTime(v116.animName, v116.stopTime)
					local v118 = v116.animSpeed
					local v119 = math.abs(v118)
					if v116.stopTime < v117 then
						local v120 = v116.animSpeed
						v119 = -math.abs(v120)
					end
					p108:playAnimation(v116.animName, v119, v117, p110)
				end
			end
		end
		if p108.getIsTurnedOn ~= nil then
			local v121 = p108:getIsTurnedOn()
			if v115.animations ~= nil and v121 then
				g_animationManager:startAnimations(v115.animationNodes)
			end
			if v121 then
				for _, v122 in pairs(v115.turnedOnAnimations) do
					if p108:getIsAnimationPlaying(v122.name) then
						for v123 = 1, #v111.workModes do
							local v124 = v111.workModes[v123]
							if v124 ~= v115 then
								for v125 = 1, #v124.turnedOnAnimations do
									local v126 = v124.turnedOnAnimations[v125]
									if v126.name == v122.name then
										local v127 = p108.spec_animatedVehicle.animations[v122.name].currentSpeed
										if v127 ~= 0 then
											v122.currentSpeed = v127 / v122.speedScale
											v126.currentSpeed = 0
											v126.speedDirection = 0
										end
									end
								end
							end
						end
					end
					v122.speedDirection = 1
				end
			end
		end
		for _, v128 in pairs(v112.windrowerEffects) do
			g_effectManager:stopEffect(v128)
		end
		if v115.movingTool ~= nil then
			local v129 = v115.movingTool
			if v115.movingToolMinRot ~= nil then
				v129.rotMin = v115.movingToolMinRot
			end
			if v115.movingToolMaxRot ~= nil then
				v129.rotMax = v115.movingToolMaxRot
			end
			if p108.isClient then
				v129.networkInterpolators.rotation:setMinMax(v129.rotMin, v129.rotMax)
			end
		end
		SpecializationUtil.raiseEvent(p108, "onWorkModeChanged", v115, v112)
	end
	local v130 = p108.spec_workArea
	if v130 ~= nil then
		local v131 = v130.workAreas
		for _, v132 in pairs(v111.workModes[p109].workAreas) do
			local v133 = v131[v132.workAreaIndex]
			if v133 ~= nil then
				v133.dropWindrowWorkAreaIndex = v132.dropAreaIndex
				v133.dropAreaIndex = v132.dropAreaIndex
			end
		end
	end
	v111.state = p109
end
function WorkMode.getWorkMode(p134)
	local v135 = p134.spec_workMode
	if v135.workModes == nil then
		return nil
	else
		return v135.workModes[v135.state]
	end
end
function WorkMode.getIsWorkAreaActive(p136, p137, p138)
	local v139 = p136.spec_workMode
	if v139.stateMax ~= nil and v139.stateMax > 0 then
		for _, v140 in pairs(v139.workModes[v139.state].workAreas) do
			if p138.index == v140.workAreaIndex and v140.dropAreaIndex == 0 then
				return false
			end
		end
	end
	return p137(p136, p138)
end
function WorkMode.getCanBeSelected(_, _)
	return true
end
function WorkMode.getAllowsLowering(p141, p142)
	local v143, v144 = p142(p141)
	local v145 = p141.spec_workMode
	local v146
	if v145.workModes == nil or #v145.workModes <= 0 then
		v146 = false
	else
		v146 = #v145.workModes[v145.state].loweringAnimations > 0
	end
	return v143 or v146, v144
end
function WorkMode.loadSprayTypeFromXML(p147, p148, p149, p150, p151)
	p151.workModeIndex = p149:getValue(p150 .. "#workModeIndex")
	return p148(p147, p149, p150, p151)
end
function WorkMode.getIsSprayTypeActive(p152, p153, p154)
	if p154.workModeIndex == nil or p152.spec_workMode.state == p154.workModeIndex then
		return p153(p152, p154)
	else
		return false
	end
end
function WorkMode.loadMovingToolFromXML(p155, p156, p157, p158, p159)
	if not p156(p155, p157, p158, p159) then
		return false
	end
	p159.allowWhileChangingWorkMode = p157:getValue(p158 .. "#allowWhileChangingWorkMode", true)
	return true
end
function WorkMode.getIsMovingToolActive(p160, p161, p162)
	if not p162.allowWhileChangingWorkMode then
		local v163 = p160.spec_workMode
		if v163.stateMax ~= nil then
			for v164 = 1, #v163.workModes do
				local v165 = v163.workModes[v164]
				for v166 = 1, #v165.animations do
					if p160:getIsAnimationPlaying(v165.animations[v166].animName) then
						return false
					end
				end
			end
		end
	end
	return p161(p160, p162)
end
function WorkMode.getAreEffectsVisible(p167, p168)
	if not p168(p167) then
		return false
	end
	local v169 = p167.spec_workMode
	if v169.stateMax ~= nil and v169.stateMax > 0 then
		for v170 = 1, #v169.workModes do
			local v171 = v169.workModes[v170]
			for v172 = 1, #v171.animations do
				if p167:getIsAnimationPlaying(v171.animations[v172].animName) then
					return false
				end
			end
		end
	end
	return true
end
function WorkMode.getIsWorkModeChangeAllowed(p173)
	local v174 = p173.spec_workMode
	if p173.getFoldAnimTime ~= nil and (p173:getFoldAnimTime() > v174.foldMaxLimit or p173:getFoldAnimTime() < v174.foldMinLimit) then
		return false
	end
	if not v174.allowChangeOnLowered then
		local v175 = p173:getAttacherVehicle()
		if v175 ~= nil and v175:getAttacherJointByJointDescIndex((v175:getAttacherJointIndexFromObject(p173))).moveDown then
			return false
		end
	end
	return true
end
function WorkMode.onTurnedOff(p176)
	local v177 = p176.spec_workMode
	if p176.isClient then
		WorkMode.deactivateWindrowerEffects(p176)
		local v178 = v177.workModes[v177.state]
		for _, v179 in pairs(v178.turnedOnAnimations) do
			v179.speedDirection = -1
		end
		g_animationManager:stopAnimations(v178.animationNodes)
	end
end
function WorkMode.onTurnedOn(p180)
	local v181 = p180.spec_workMode
	if p180.isClient then
		local v182 = v181.workModes[v181.state]
		for _, v183 in pairs(v182.turnedOnAnimations) do
			v183.speedDirection = 1
		end
		g_animationManager:startAnimations(v182.animationNodes)
	end
end
function WorkMode.onSetLowered(p184, p185)
	local v186 = p184.spec_workMode
	if p184.getFoldAnimTime ~= nil then
		local v187 = p184:getFoldAnimTime()
		if v187 ~= 1 and (v187 ~= 0 and v187 ~= p184.foldMiddleAnimTime) then
			v186.playDelayedLoweringAnimation = p185
			return
		end
	end
	local v188 = v186.workModes[v186.state]
	for _, v189 in pairs(v188.loweringAnimations) do
		if p185 then
			if p184:getAnimationTime(v189.name) < 1 then
				p184:playAnimation(v189.name, v189.speed, nil, true)
			end
		elseif p184:getAnimationTime(v189.name) > 0 then
			p184:playAnimation(v189.name, -v189.speed, nil, true)
		end
	end
end
function WorkMode.onFoldStateChanged(p190, p191, _)
	local v192 = p190.spec_workMode
	if p191 > 0 then
		local v193 = v192.workModes[v192.state]
		for _, v194 in pairs(v193.animations) do
			if v194.repeatAfterUnfolding then
				v194.repeated = false
			end
		end
		if p190:getIsLowered() and p190.getAttacherVehicle ~= nil then
			local v195 = p190:getAttacherVehicle()
			if v195 ~= nil then
				v195:handleLowerImplementEvent()
			end
		end
	end
end
function WorkMode.onRegisterActionEvents(p196, _, p197)
	if p196.isClient then
		local v198 = p196.spec_workMode
		if v198.stateMax > 0 then
			p196:clearActionEventsTable(v198.actionEvents)
			if p197 then
				local _, v199 = p196:addPoweredActionEvent(v198.actionEvents, InputAction.TOGGLE_WORKMODE, p196, WorkMode.actionEventWorkModeChange, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v199, GS_PRIO_NORMAL)
				g_inputBinding:setActionEventActive(v199, false)
				for _, v200 in ipairs(v198.workModes) do
					if v200.inputAction ~= nil then
						local _, v201 = p196:addPoweredActionEvent(v198.actionEvents, v200.inputAction, p196, WorkMode.actionEventWorkModeChangeDirect, false, true, false, true, nil)
						g_inputBinding:setActionEventTextVisibility(v201, false)
						g_inputBinding:setActionEventActive(v201, false)
					end
				end
			end
		end
	end
end
function WorkMode.actionEventWorkModeChange(p202, _, _, _, _)
	local v203 = p202.spec_workMode
	local v204 = v203.state + 1
	local v205 = v203.stateMax < v204 and 1 or v204
	if v205 ~= v203.state then
		p202:setWorkMode(v205)
	end
end
function WorkMode.actionEventWorkModeChangeDirect(p206, p207, _, _, _)
	local v208 = p206.spec_workMode
	for v209, v210 in ipairs(v208.workModes) do
		if v210.inputAction == InputAction[p207] and v209 ~= v208.state then
			p206:setWorkMode(v209)
		end
	end
end

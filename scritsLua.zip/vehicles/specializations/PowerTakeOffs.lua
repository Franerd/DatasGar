PowerTakeOffs = {}
PowerTakeOffs.DEFAULT_MAX_UPDATE_DISTANCE = 40
PowerTakeOffs.xmlSchema = nil
function PowerTakeOffs.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AttacherJoints, p1) or SpecializationUtil.hasSpecialization(Attachable, p1)
end
function PowerTakeOffs.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("PowerTakeOffs")
	PowerTakeOffs.registerXMLPaths(v2, "vehicle.powerTakeOffs.powerTakeOffConfigurations.powerTakeOffConfiguration(?)")
	PowerTakeOffs.registerXMLPaths(v2, "vehicle.powerTakeOffs")
	v2:addDelayedRegistrationFunc("Cylindered:movingTool", function(p3, p4)
		p3:register(XMLValueType.VECTOR_N, p4 .. ".powerTakeOffs#indices", "PTOs to update")
		p3:register(XMLValueType.VECTOR_N, p4 .. ".powerTakeOffs#localIndices", "Local PTOs to update")
	end)
	v2:addDelayedRegistrationFunc("Cylindered:movingPart", function(p5, p6)
		p5:register(XMLValueType.VECTOR_N, p6 .. ".powerTakeOffs#indices", "PTOs to update")
		p5:register(XMLValueType.VECTOR_N, p6 .. ".powerTakeOffs#localIndices", "Local PTOs to update")
	end)
	v2:register(XMLValueType.BOOL, "vehicle.powerTakeOffs#ignoreInvalidJointIndices", "Do not display warning if attacher joint index could not be found. Can be useful if attacher joints change due to configurations", false)
	v2:register(XMLValueType.FLOAT, "vehicle.powerTakeOffs#maxUpdateDistance", "Max. distance to vehicle root to update power take offs", PowerTakeOffs.DEFAULT_MAX_UPDATE_DISTANCE)
	Dashboard.addDelayedRegistrationFunc(v2, function(p7, p8)
		p7:register(XMLValueType.INT, p8 .. "#powerTakeOffIndex", "Index of power take off in xml to use")
	end)
	SoundManager.registerSampleXMLPaths(v2, "vehicle.powerTakeOffs.sounds", "turnedOn(?)")
	v2:setXMLSpecializationType()
	local v9 = XMLSchema.new("powerTakeOff")
	PowerTakeOffs.xmlSchema = v9
	v9:register(XMLValueType.STRING, "powerTakeOff#filename", "Path to i3d file")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.startNode#node", "Start node")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.linkNode#node", "Link node")
	v9:register(XMLValueType.FLOAT, "powerTakeOff#size", "Height of pto", 0.19)
	v9:register(XMLValueType.FLOAT, "powerTakeOff#minLength", "Minimum length of pto", 0.6)
	v9:register(XMLValueType.ANGLE, "powerTakeOff#maxAngle", "Max. angle between start and end", 45)
	v9:register(XMLValueType.FLOAT, "powerTakeOff#zOffset", "Z axis offset of end node", 0)
	v9:register(XMLValueType.STRING, "powerTakeOff#colorMaterialName", "Color material name", "powerTakeOff_main_mat")
	v9:register(XMLValueType.STRING, "powerTakeOff#decalColorMaterialName", "Decal color material name", "powerTakeOff_decal_mat")
	AnimationManager.registerAnimationNodesXMLPaths(v9, "powerTakeOff.animationNodes")
	v9:register(XMLValueType.BOOL, "powerTakeOff#isSingleJoint", "Is single joint PTO", false)
	v9:register(XMLValueType.BOOL, "powerTakeOff#isDoubleJoint", "Is double joint PTO", false)
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.startJoint#node", "(Single Joint) Start joint node")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.endJoint#node", "(Single Joint) End joint node")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.scalePart#node", "(Single|Double Joint) Scale part node")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.scalePart#referenceNode", "(Single|Double Joint) Scale part reference node")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.translationPart#node", "(Single|Double Joint) translation part node")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.translationPart#referenceNode", "(Single|Double Joint) translation part reference node")
	v9:register(XMLValueType.FLOAT, "powerTakeOff.translationPart#length", "(Single|Double Joint) translation part length", 0.4)
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.translationPart.decal#node", "(Single|Double Joint) translation part decal node")
	v9:register(XMLValueType.FLOAT, "powerTakeOff.translationPart.decal#size", "(Single|Double Joint) translation part decal size", 0.1)
	v9:register(XMLValueType.FLOAT, "powerTakeOff.translationPart.decal#offset", "(Single|Double Joint) translation part decal offset", 0.05)
	v9:register(XMLValueType.FLOAT, "powerTakeOff.translationPart.decal#minOffset", "(Single|Double Joint) translation part decal minOffset", 0.01)
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.startJoint1#node", "(Double Joint) Start joint 1")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.startJoint2#node", "(Double Joint) Start joint 2")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.endJoint1#node", "(Double Joint) End joint 1")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.endJoint1#referenceNode", "(Double Joint) End joint 1 reference node")
	v9:register(XMLValueType.NODE_INDEX, "powerTakeOff.endJoint2#node", "(Double Joint) End joint 2")
	I3DUtil.registerI3dMappingXMLPaths(v9, "powerTakeOff")
end
function PowerTakeOffs.registerXMLPaths(p10, p11)
	PowerTakeOffs.registerOutputXMLPaths(p10, p11 .. ".output(?)")
	PowerTakeOffs.registerInputXMLPaths(p10, p11 .. ".input(?)")
	PowerTakeOffs.registerLocalXMLPaths(p10, p11 .. ".local(?)")
end
function PowerTakeOffs.registerOutputXMLPaths(p12, p13)
	p12:register(XMLValueType.INT, p13 .. "#skipToInputAttacherIndex", "Skip to input attacher joint index")
	p12:register(XMLValueType.NODE_INDEX, p13 .. "#outputNode", "Output node")
	p12:register(XMLValueType.VECTOR_N, p13 .. "#attacherJointIndices", "Corresponding attacher joint(s) (List of indices)")
	p12:register(XMLValueType.NODE_INDICES, p13 .. "#attacherJointNodes", "Corresponding attacher joint(s) (List of attacherJoint nodes)")
	p12:register(XMLValueType.STRING, p13 .. "#ptoName", "Output name", "DEFAULT_PTO")
	AnimationManager.registerAnimationNodesXMLPaths(p12, p13 .. ".animationNodes")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p12, p13)
	Dashboard.registerDashboardXMLPaths(p12, p13, { "state" })
end
function PowerTakeOffs.registerInputXMLPaths(p14, p15)
	p14:register(XMLValueType.NODE_INDEX, p15 .. "#inputNode", "Input node")
	p14:register(XMLValueType.VECTOR_N, p15 .. "#inputAttacherJointIndices", "Corresponding Input attacher joint(s) (List of indices)")
	p14:register(XMLValueType.NODE_INDICES, p15 .. "#inputAttacherJointNodes", "Corresponding Input attacher joint(s) (List of attacherJoint nodes)")
	p14:register(XMLValueType.NODE_INDEX, p15 .. "#detachNode", "Detach node")
	p14:register(XMLValueType.BOOL, p15 .. "#aboveAttacher", "Above attacher", true)
	p14:register(XMLValueType.VEHICLE_MATERIAL, p15 .. "#materialTemplateName", "Name of shared material to apply to the main pto")
	p14:registerAutoCompletionDataSource(p15 .. "#materialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p14:register(XMLValueType.VEHICLE_MATERIAL, p15 .. "#decalMaterialTemplateName", "Name of shared material to apply to the decals")
	p14:registerAutoCompletionDataSource(p15 .. "#decalMaterialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p14:register(XMLValueType.FLOAT, p15 .. "#length", "Predefined length of the PTO (Otherwise calculated from the distance between startNode and endNode, while loading. Can be useful if the tool is loaded in different states to always get the same length.)")
	p14:register(XMLValueType.STRING, p15 .. "#filename", "Path to pto xml file", "$data/shared/assets/powerTakeOffs/walterscheidW.xml")
	p14:register(XMLValueType.STRING, p15 .. "#ptoName", "Pto name", "DEFAULT_PTO")
	AnimationManager.registerAnimationNodesXMLPaths(p14, p15 .. ".animationNodes")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p14, p15)
end
function PowerTakeOffs.registerLocalXMLPaths(p16, p17)
	p16:register(XMLValueType.NODE_INDEX, p17 .. "#startNode", "Start node")
	p16:register(XMLValueType.NODE_INDEX, p17 .. "#endNode", "End node")
	p16:register(XMLValueType.VEHICLE_MATERIAL, p17 .. "#materialTemplateName", "Name of shared material to apply to the main pto")
	p16:registerAutoCompletionDataSource(p17 .. "#materialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p16:register(XMLValueType.VEHICLE_MATERIAL, p17 .. "#decalMaterialTemplateName", "Name of shared material to apply to the decals")
	p16:registerAutoCompletionDataSource(p17 .. "#decalMaterialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p16:register(XMLValueType.FLOAT, p17 .. "#length", "Predefined length of the PTO (Otherwise calculated from the distance between startNode and endNode, while loading. Can be useful if the tool is loaded in different states to always get the same length.)")
	p16:register(XMLValueType.STRING, p17 .. "#filename", "Path to pto xml file", "$data/shared/assets/powerTakeOffs/walterscheidW.xml")
end
function PowerTakeOffs.registerFunctions(p18)
	SpecializationUtil.registerFunction(p18, "getPowerTakeOffConfigIndex", PowerTakeOffs.getPowerTakeOffConfigIndex)
	SpecializationUtil.registerFunction(p18, "loadPowerTakeOffsFromXML", PowerTakeOffs.loadPowerTakeOffsFromXML)
	SpecializationUtil.registerFunction(p18, "loadOutputPowerTakeOff", PowerTakeOffs.loadOutputPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "loadInputPowerTakeOff", PowerTakeOffs.loadInputPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "loadLocalPowerTakeOff", PowerTakeOffs.loadLocalPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "placeLocalPowerTakeOff", PowerTakeOffs.placeLocalPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "updatePowerTakeOff", PowerTakeOffs.updatePowerTakeOff)
	SpecializationUtil.registerFunction(p18, "updateAttachedPowerTakeOffs", PowerTakeOffs.updateAttachedPowerTakeOffs)
	SpecializationUtil.registerFunction(p18, "updatePowerTakeOffLength", PowerTakeOffs.updatePowerTakeOffLength)
	SpecializationUtil.registerFunction(p18, "getOutputPowerTakeOffsByJointDescIndex", PowerTakeOffs.getOutputPowerTakeOffsByJointDescIndex)
	SpecializationUtil.registerFunction(p18, "getOutputPowerTakeOffs", PowerTakeOffs.getOutputPowerTakeOffs)
	SpecializationUtil.registerFunction(p18, "getInputPowerTakeOffs", PowerTakeOffs.getInputPowerTakeOffs)
	SpecializationUtil.registerFunction(p18, "getInputPowerTakeOffsByJointDescIndexAndName", PowerTakeOffs.getInputPowerTakeOffsByJointDescIndexAndName)
	SpecializationUtil.registerFunction(p18, "getIsPowerTakeOffActive", PowerTakeOffs.getIsPowerTakeOffActive)
	SpecializationUtil.registerFunction(p18, "attachPowerTakeOff", PowerTakeOffs.attachPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "detachPowerTakeOff", PowerTakeOffs.detachPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "checkPowerTakeOffCollision", PowerTakeOffs.checkPowerTakeOffCollision)
	SpecializationUtil.registerFunction(p18, "parkPowerTakeOff", PowerTakeOffs.parkPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "loadPowerTakeOffFromConfigFile", PowerTakeOffs.loadPowerTakeOffFromConfigFile)
	SpecializationUtil.registerFunction(p18, "onPowerTakeOffI3DLoaded", PowerTakeOffs.onPowerTakeOffI3DLoaded)
	SpecializationUtil.registerFunction(p18, "loadSingleJointPowerTakeOff", PowerTakeOffs.loadSingleJointPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "updateSingleJointPowerTakeOff", PowerTakeOffs.updateSingleJointPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "loadDoubleJointPowerTakeOff", PowerTakeOffs.loadDoubleJointPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "updateDoubleJointPowerTakeOff", PowerTakeOffs.updateDoubleJointPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "loadBasicPowerTakeOff", PowerTakeOffs.loadBasicPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "attachTypedPowerTakeOff", PowerTakeOffs.attachTypedPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "detachTypedPowerTakeOff", PowerTakeOffs.detachTypedPowerTakeOff)
	SpecializationUtil.registerFunction(p18, "validatePowerTakeOffAttachment", PowerTakeOffs.validatePowerTakeOffAttachment)
end
function PowerTakeOffs.registerOverwrittenFunctions(p19)
	SpecializationUtil.registerOverwrittenFunction(p19, "loadExtraDependentParts", PowerTakeOffs.loadExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p19, "updateExtraDependentParts", PowerTakeOffs.updateExtraDependentParts)
end
function PowerTakeOffs.registerEventListeners(p20)
	SpecializationUtil.registerEventListener(p20, "onPreLoad", PowerTakeOffs)
	SpecializationUtil.registerEventListener(p20, "onLoad", PowerTakeOffs)
	SpecializationUtil.registerEventListener(p20, "onPostLoad", PowerTakeOffs)
	SpecializationUtil.registerEventListener(p20, "onDelete", PowerTakeOffs)
	SpecializationUtil.registerEventListener(p20, "onPostUpdate", PowerTakeOffs)
	SpecializationUtil.registerEventListener(p20, "onUpdateEnd", PowerTakeOffs)
	SpecializationUtil.registerEventListener(p20, "onPreAttachImplement", PowerTakeOffs)
	SpecializationUtil.registerEventListener(p20, "onPostAttachImplement", PowerTakeOffs)
	SpecializationUtil.registerEventListener(p20, "onPreDetachImplement", PowerTakeOffs)
end
function PowerTakeOffs.onPreLoad(p21, _)
	p21.spec_powerTakeOffs.configIndex = p21:getPowerTakeOffConfigIndex()
end
function PowerTakeOffs.onLoad(p22, _)
	local v23 = p22.spec_powerTakeOffs
	v23.outputPowerTakeOffs = {}
	v23.inputPowerTakeOffs = {}
	v23.localPowerTakeOffs = {}
	v23.ignoreInvalidJointIndices = p22.xmlFile:getValue("vehicle.powerTakeOffs#ignoreInvalidJointIndices", false)
	v23.maxUpdateDistance = p22.xmlFile:getValue("vehicle.powerTakeOffs#maxUpdateDistance", PowerTakeOffs.DEFAULT_MAX_UPDATE_DISTANCE)
	v23.delayedPowerTakeOffsMountings = {}
	if p22.isClient then
		v23.samples = {}
		v23.samples.turnedOn = g_soundManager:loadSamplesFromXML(p22.xmlFile, "vehicle.powerTakeOffs.sounds", "turnedOn", p22.baseDirectory, p22.components, 0, AudioGroup.VEHICLE, p22.i3dMappings, p22)
	else
		SpecializationUtil.removeEventListener(p22, "onPostUpdate", PowerTakeOffs)
	end
end
function PowerTakeOffs.onPostLoad(p24, _)
	local v25 = p24.spec_powerTakeOffs
	p24:loadPowerTakeOffsFromXML(p24.xmlFile, "vehicle.powerTakeOffs")
	local v26 = string.format("vehicle.powerTakeOffs.powerTakeOffConfigurations.powerTakeOffConfiguration(%d)", v25.configIndex - 1)
	if p24.xmlFile:hasProperty(v26) then
		p24:loadPowerTakeOffsFromXML(p24.xmlFile, v26)
	end
end
function PowerTakeOffs.onDelete(p27)
	local v28 = p27.spec_powerTakeOffs
	if v28.outputPowerTakeOffs ~= nil then
		for _, v29 in pairs(v28.outputPowerTakeOffs) do
			if v29.xmlFile ~= nil then
				v29.xmlFile:delete()
				v29.xmlFile = nil
			end
			if v29.sharedLoadRequestId ~= nil then
				g_i3DManager:releaseSharedI3DFile(v29.sharedLoadRequestId)
				v29.sharedLoadRequestId = nil
			end
			g_animationManager:deleteAnimations(v29.localAnimationNodes)
			if v29.rootNode ~= nil then
				delete(v29.rootNode)
				delete(v29.attachNode)
			end
		end
	end
	if v28.inputPowerTakeOffs ~= nil then
		for _, v30 in pairs(v28.inputPowerTakeOffs) do
			if v30.xmlFile ~= nil then
				v30.xmlFile:delete()
				v30.xmlFile = nil
			end
			if v30.sharedLoadRequestId ~= nil then
				g_i3DManager:releaseSharedI3DFile(v30.sharedLoadRequestId)
				v30.sharedLoadRequestId = nil
			end
			g_animationManager:deleteAnimations(v30.animationNodes)
			g_animationManager:deleteAnimations(v30.localAnimationNodes)
			if v30.rootNode ~= nil then
				delete(v30.rootNode)
				delete(v30.attachNode)
			end
		end
	end
	if v28.localPowerTakeOffs ~= nil then
		for _, v31 in pairs(v28.localPowerTakeOffs) do
			if v31.xmlFile ~= nil then
				v31.xmlFile:delete()
				v31.xmlFile = nil
			end
			if v31.sharedLoadRequestId ~= nil then
				g_i3DManager:releaseSharedI3DFile(v31.sharedLoadRequestId)
				v31.sharedLoadRequestId = nil
			end
			g_animationManager:deleteAnimations(v31.animationNodes)
		end
	end
	if v28.samples ~= nil then
		g_soundManager:deleteSamples(v28.samples.turnedOn)
	end
end
function PowerTakeOffs.onPostUpdate(p32, p33, _, _, _)
	if p32.isClient then
		local v34 = p32.spec_powerTakeOffs
		if p32.currentUpdateDistance < v34.maxUpdateDistance then
			for v35 = 1, #v34.inputPowerTakeOffs do
				local v36 = v34.inputPowerTakeOffs[v35]
				if v36.connectedVehicle ~= nil and p32.updateLoopIndex == v36.connectedVehicle.updateLoopIndex then
					p32:updatePowerTakeOff(v36, p33)
				end
			end
			if p32.getAttachedImplements ~= nil then
				local v37 = p32:getAttachedImplements()
				for v38 = 1, #v37 do
					local v39 = v37[v38].object
					if v39.updateAttachedPowerTakeOffs ~= nil then
						v39:updateAttachedPowerTakeOffs(p33, p32)
					end
				end
			end
			local v40 = p32.isActive
			if v40 then
				v40 = p32:getIsPowerTakeOffActive()
			end
			if v34.lastIsPowerTakeOffActive ~= v40 then
				for v41 = 1, #v34.inputPowerTakeOffs do
					local v42 = v34.inputPowerTakeOffs[v41]
					if v40 and v42.connectedVehicle ~= nil then
						g_animationManager:startAnimations(v42.animationNodes)
						g_animationManager:startAnimations(v42.localAnimationNodes)
						g_animationManager:startAnimations(v42.connectedOutput.localAnimationNodes)
						v42.connectedOutput.isActive = true
					else
						g_animationManager:stopAnimations(v42.animationNodes)
						g_animationManager:stopAnimations(v42.localAnimationNodes)
						if v42.connectedOutput ~= nil then
							g_animationManager:stopAnimations(v42.connectedOutput.localAnimationNodes)
							v42.connectedOutput.isActive = false
						end
					end
				end
				for v43 = 1, #v34.localPowerTakeOffs do
					local v44 = v34.localPowerTakeOffs[v43]
					if v40 then
						g_animationManager:startAnimations(v44.animationNodes)
					else
						g_animationManager:stopAnimations(v44.animationNodes)
					end
				end
				if v40 then
					g_soundManager:playSamples(v34.samples.turnedOn)
				else
					g_soundManager:stopSamples(v34.samples.turnedOn)
				end
				v34.lastIsPowerTakeOffActive = v40
			end
		end
	end
end
function PowerTakeOffs.onUpdateEnd(p45, p46, p47, p48, p49)
	PowerTakeOffs.onPostUpdate(p45, p46, p47, p48, p49)
end
function PowerTakeOffs.getPowerTakeOffConfigIndex(_)
	return 1
end
function PowerTakeOffs.loadPowerTakeOffsFromXML(p_u_50, p_u_51, p52)
	local v_u_53 = p_u_50.spec_powerTakeOffs
	if SpecializationUtil.hasSpecialization(AttacherJoints, p_u_50.specializations) then
		p_u_51:iterate(p52 .. ".output", function(_, p54)
			-- upvalues: (copy) p_u_50, (copy) p_u_51, (copy) v_u_53
			local v55 = {}
			if p_u_50:loadOutputPowerTakeOff(p_u_51, p54, v55) then
				local v56 = v_u_53.outputPowerTakeOffs
				table.insert(v56, v55)
			end
		end)
	end
	if SpecializationUtil.hasSpecialization(Attachable, p_u_50.specializations) then
		p_u_51:iterate(p52 .. ".input", function(_, p57)
			-- upvalues: (copy) p_u_50, (copy) p_u_51, (copy) v_u_53
			local v58 = {}
			if p_u_50:loadInputPowerTakeOff(p_u_51, p57, v58) then
				local v59 = v_u_53.inputPowerTakeOffs
				table.insert(v59, v58)
			end
		end)
	end
	p_u_51:iterate(p52 .. ".local", function(_, p60)
		-- upvalues: (copy) p_u_50, (copy) p_u_51, (copy) v_u_53
		local v61 = {}
		if p_u_50:loadLocalPowerTakeOff(p_u_51, p60, v61) then
			local v62 = v_u_53.localPowerTakeOffs
			table.insert(v62, v61)
		end
	end)
end
function PowerTakeOffs.loadOutputPowerTakeOff(p63, p64, p65, p66)
	XMLUtil.checkDeprecatedXMLElements(p64, p65 .. "#linkNode", p65 .. "#outputNode")
	XMLUtil.checkDeprecatedXMLElements(p64, p65 .. "#filename", "pto file is now defined in the pto input node")
	p66.skipToInputAttacherIndex = p64:getValue(p65 .. "#skipToInputAttacherIndex")
	local v67 = p64:getValue(p65 .. "#outputNode", nil, p63.components, p63.i3dMappings)
	if v67 == nil and p66.skipToInputAttacherIndex == nil then
		Logging.xmlWarning(p64, "Pto output needs to have either a valid \'outputNode\' or a \'skipToInputAttacherIndex\' in \'%s\'", p65)
		return false
	end
	local v68 = {}
	local v69 = p64:getValue(p65 .. "#attacherJointIndices", nil, true)
	if v69 ~= nil then
		for _, v70 in ipairs(v69) do
			if p63:getAttacherJointByJointDescIndex(v70) == nil then
				if not p63.spec_powerTakeOffs.ignoreInvalidJointIndices then
					Logging.xmlWarning(p63.xmlFile, "The given attacherJointIndex \'%d\' for powerTakeOff can\'t be resolved into a valid attacherJoint in %s", v70, p65)
				end
			else
				v68[v70] = true
			end
		end
	end
	local v71 = p64:getValue(p65 .. "#attacherJointNodes", nil, p63.components, p63.i3dMappings, true)
	if v71 ~= nil then
		for _, v72 in ipairs(v71) do
			local v73 = p63:getAttacherJointIndexByNode(v72)
			if v73 ~= nil then
				v68[v73] = true
			end
		end
	end
	if next(v68) == nil then
		Logging.xmlWarning(p64, "Pto output needs to have valid \'attacherJointIndices\' or \'attacherJointNodes\' in \'%s\'", p65)
		return false
	end
	p66.outputNode = v67
	p66.attacherJointIndices = v68
	p66.connectedInput = nil
	p66.ptoName = p64:getValue(p65 .. "#ptoName", "DEFAULT_PTO")
	p66.localAnimationNodes = g_animationManager:loadAnimations(p64, p65 .. ".animationNodes", p63.components, p63, p63.i3dMappings)
	p66.objectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p64, p65, p66.objectChanges, p63.components, p63)
	ObjectChangeUtil.setObjectChanges(p66.objectChanges, false, p63, p63.setMovingToolDirty)
	p66.isActive = false
	if p63.registerDashboardValueType ~= nil then
		local v74 = DashboardValueType.new("powerTakeOffs", "state")
		v74:setXMLKey(p65)
		v74:setValue(p66, function(p75, p76)
			return (p76.powerTakeOffOutput or p75).isActive
		end)
		v74:setAdditionalFunctions(function(p77, p78, p79, p80, _)
			local v81 = p78:getValue(p79 .. "#powerTakeOffIndex")
			if v81 ~= nil then
				p80.powerTakeOffOutput = p77.spec_powerTakeOffs.outputPowerTakeOffs[v81]
			end
			return true
		end, nil)
		p63:registerDashboardValueType(v74)
	end
	return true
end
function PowerTakeOffs.loadInputPowerTakeOff(p82, p83, p84, p85)
	XMLUtil.checkDeprecatedXMLElements(p83, p84 .. "#color", p84 .. "#materialTemplateName")
	XMLUtil.checkDeprecatedXMLElements(p83, p84 .. "#decalColor", p84 .. "#decalMaterialTemplateName")
	local v86 = p83:getValue(p84 .. "#inputNode", nil, p82.components, p82.i3dMappings)
	if v86 == nil then
		Logging.xmlWarning(p83, "Pto input needs to have a valid \'inputNode\' in \'%s\'", p84)
		return false
	end
	local v87 = {}
	local v88 = p83:getValue(p84 .. "#inputAttacherJointIndices", nil, true)
	if v88 ~= nil then
		for _, v89 in ipairs(v88) do
			if p82:getInputAttacherJointByJointDescIndex(v89) == nil then
				if not p82.spec_powerTakeOffs.ignoreInvalidJointIndices then
					Logging.xmlWarning(p82.xmlFile, "The given inputAttacherJointIndex \'%d\' for powerTakeOff can\'t be resolved into a valid attacherJoint in %s", v89, p84)
				end
			else
				v87[v89] = true
			end
		end
	end
	local v90 = p83:getValue(p84 .. "#inputAttacherJointNodes", nil, p82.components, p82.i3dMappings, true)
	if v90 ~= nil then
		for _, v91 in ipairs(v90) do
			local v92 = p82:getInputAttacherJointIndexByNode(v91)
			if v92 ~= nil then
				v87[v92] = true
			end
		end
	end
	if next(v87) == nil then
		Logging.xmlWarning(p83, "Pto output needs to have valid \'inputAttacherJointIndices\' or \'inputAttacherJointNodes\' in \'%s\'", p84)
		return false
	end
	p85.inputNode = v86
	if Platform.gameplay.hasDetachedPowerTakeOffs then
		p85.detachNode = p83:getValue(p84 .. "#detachNode", nil, p82.components, p82.i3dMappings)
	end
	p85.inputAttacherJointIndices = v87
	p85.aboveAttacher = p83:getValue(p84 .. "#aboveAttacher", true)
	p85.material = p83:getValue(p84 .. "#materialTemplateName")
	p85.decalMaterial = p83:getValue(p84 .. "#decalMaterialTemplateName")
	p85.ptoName = p83:getValue(p84 .. "#ptoName", "DEFAULT_PTO")
	p85.localAnimationNodes = g_animationManager:loadAnimations(p83, p84 .. ".animationNodes", p82.components, p82, p82.i3dMappings)
	p85.objectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p83, p84, p85.objectChanges, p82.components, p82)
	ObjectChangeUtil.setObjectChanges(p85.objectChanges, false, p82, p82.setMovingToolDirty)
	local v93 = p83:getValue(p84 .. "#filename", "$data/shared/assets/powerTakeOffs/walterscheidW.xml")
	if v93 ~= nil then
		p82:loadPowerTakeOffFromConfigFile(p85, v93)
	end
	return true
end
function PowerTakeOffs.loadLocalPowerTakeOff(p94, p95, p96, p97)
	p97.isLocal = true
	p97.inputNode = p95:getValue(p96 .. "#startNode", nil, p94.components, p94.i3dMappings)
	if p97.inputNode == nil then
		Logging.xmlWarning(p95, "Missing startNode for local power take off \'%s\'", p96)
		return false
	end
	p97.endNode = p95:getValue(p96 .. "#endNode", nil, p94.components, p94.i3dMappings)
	if p97.endNode == nil then
		Logging.xmlWarning(p95, "Missing endNode for local power take off \'%s\'", p96)
		return false
	end
	p97.material = p95:getValue(p96 .. "#materialTemplateName")
	p97.decalMaterial = p95:getValue(p96 .. "#decalMaterialTemplateName")
	p97.predefinedLength = p95:getValue(p96 .. "#length")
	local v98 = p95:getValue(p96 .. "#filename", "$data/shared/assets/powerTakeOffs/walterscheidW.xml")
	if v98 ~= nil then
		p94:loadPowerTakeOffFromConfigFile(p97, v98)
	end
	return true
end
function PowerTakeOffs.placeLocalPowerTakeOff(p99, p100)
	if p100.i3dLoaded then
		if not p100.isPlaced then
			link(p100.endNode, p100.linkNode)
			setTranslation(p100.linkNode, 0, 0, p100.zOffset)
			setTranslation(p100.startNode, 0, 0, -p100.zOffset)
			p99:updatePowerTakeOffLength(p100)
			p100.isPlaced = true
		end
		p99:updatePowerTakeOff(p100, 0)
	end
end
function PowerTakeOffs.updatePowerTakeOff(p101, p102, p103)
	if p102.i3dLoaded and (p102.isLinked or p102.isPlaced) and p102.updateFunc ~= nil then
		p102.updateFunc(p101, p102, p103)
	end
end
function PowerTakeOffs.updateAttachedPowerTakeOffs(p104, p105, p106)
	local v107 = p104.spec_powerTakeOffs
	for _, v108 in pairs(v107.inputPowerTakeOffs) do
		if v108.connectedVehicle ~= nil and (v108.connectedVehicle == p106 and p104.updateLoopIndex == v108.connectedVehicle.updateLoopIndex) then
			p104:updatePowerTakeOff(v108, p105)
		end
	end
end
function PowerTakeOffs.updatePowerTakeOffLength(p109, p110)
	if p110.i3dLoaded and p110.updateDistanceFunc ~= nil then
		p110.updateDistanceFunc(p109, p110)
	end
end
function PowerTakeOffs.getOutputPowerTakeOffsByJointDescIndex(p111, p112)
	local v113 = p111.spec_powerTakeOffs
	local v114 = {}
	for _, v115 in pairs(v113.outputPowerTakeOffs) do
		if v115.attacherJointIndices[p112] ~= nil then
			table.insert(v114, v115)
		end
	end
	if #v114 > 0 then
		for _, v116 in ipairs(v114) do
			if v116.skipToInputAttacherIndex ~= nil then
				local v117 = p111:getAttacherVehicle()
				if v117 ~= nil then
					return v117:getOutputPowerTakeOffsByJointDescIndex(v117:getImplementByObject(p111).jointDescIndex)
				end
			end
		end
	end
	return v114
end
function PowerTakeOffs.getOutputPowerTakeOffs(p118)
	return p118.spec_powerTakeOffs.outputPowerTakeOffs
end
function PowerTakeOffs.getInputPowerTakeOffsByJointDescIndexAndName(p119, p120, p121)
	local v122 = p119.spec_powerTakeOffs
	local v123 = {}
	for _, v124 in pairs(v122.inputPowerTakeOffs) do
		if v124.inputAttacherJointIndices[p120] ~= nil and v124.ptoName == p121 then
			table.insert(v123, v124)
		end
	end
	if #v123 == 0 then
		for _, v125 in pairs(v122.outputPowerTakeOffs) do
			if v125.skipToInputAttacherIndex == p120 then
				for v126, _ in pairs(v125.attacherJointIndices) do
					local v127 = p119:getImplementFromAttacherJointIndex(v126)
					if v127 ~= nil then
						v123 = v127.object:getInputPowerTakeOffsByJointDescIndexAndName(v127.inputJointDescIndex, p121)
					end
				end
			end
		end
	end
	return v123
end
function PowerTakeOffs.getInputPowerTakeOffs(p128)
	return p128.spec_powerTakeOffs.inputPowerTakeOffs
end
function PowerTakeOffs.getIsPowerTakeOffActive(_)
	return false
end
function PowerTakeOffs.attachPowerTakeOff(p129, p130, p131, p132)
	local v133 = p129.spec_powerTakeOffs
	local v134 = p129:getOutputPowerTakeOffsByJointDescIndex(p132)
	for _, v135 in ipairs(v134) do
		if p130.getInputPowerTakeOffsByJointDescIndexAndName ~= nil then
			local v136 = p130:getInputPowerTakeOffsByJointDescIndexAndName(p131, v135.ptoName)
			for _, v137 in ipairs(v136) do
				v135.connectedInput = v137
				v135.connectedVehicle = p130
				v137.connectedVehicle = p129
				v137.connectedOutput = v135
				local v138 = v133.delayedPowerTakeOffsMountings
				table.insert(v138, {
					["jointDescIndex"] = p132,
					["input"] = v137,
					["output"] = v135
				})
			end
		end
	end
	return true
end
function PowerTakeOffs.detachPowerTakeOff(p139, p140, p141, p142)
	p139.spec_powerTakeOffs.delayedPowerTakeOffsMountings = {}
	local v143 = p140:getOutputPowerTakeOffsByJointDescIndex(p142 or p141.jointDescIndex)
	for _, v144 in ipairs(v143) do
		if v144.connectedInput ~= nil then
			local v145 = v144.connectedInput
			if v145.detachFunc ~= nil then
				v145.detachFunc(p139, v145, v144)
			end
			if v145.connectedOutput ~= nil then
				g_animationManager:stopAnimations(v145.connectedOutput.localAnimationNodes)
				v145.connectedOutput.isActive = false
			end
			v145.connectedVehicle = nil
			v145.connectedOutput = nil
			v144.connectedVehicle = nil
			v144.connectedInput = nil
			ObjectChangeUtil.setObjectChanges(v145.objectChanges, false, p139, p139.setMovingToolDirty)
			ObjectChangeUtil.setObjectChanges(v144.objectChanges, false, p139, p139.setMovingToolDirty)
		end
	end
	return true
end
function PowerTakeOffs.checkPowerTakeOffCollision(p146, p147, p148, p149)
	if p149 then
		local v150 = p146:getOutputPowerTakeOffsByJointDescIndex(p148)
		if v150 ~= nil and #v150 > 0 then
			local v151 = v150[1]
			local v152 = v151.connectedInput
			if v152 ~= nil then
				local _, v153, _ = localToLocal(v151.outputNode, p147, 0, 0, 0)
				if v152.aboveAttacher and v153 < 0 or not v152.aboveAttacher and v153 > 0 then
					p146:detachPowerTakeOff(p146, nil, p148)
				end
			end
		end
	end
end
function PowerTakeOffs.parkPowerTakeOff(p154, p155)
	if p155.detachNode == nil then
		link(p155.inputNode, p155.linkNode)
		link(p155.inputNode, p155.startNode)
		setVisibility(p155.linkNode, false)
		setVisibility(p155.startNode, false)
		p155.isLinked = false
	else
		link(p155.detachNode, p155.linkNode)
		link(p155.inputNode, p155.startNode)
		p154:updatePowerTakeOff(p155, 0)
		p154:updatePowerTakeOffLength(p155)
		p155.isLinked = true
	end
	setTranslation(p155.linkNode, 0, 0, p155.zOffset)
	setTranslation(p155.startNode, 0, 0, -p155.zOffset)
end
function PowerTakeOffs.onPreAttachImplement(p156, p157, p158, p159)
	p156:attachPowerTakeOff(p157, p158, p159)
end
function PowerTakeOffs.onPostAttachImplement(p160, _, _, p161)
	local v162 = p160.spec_powerTakeOffs
	for v163 = #v162.delayedPowerTakeOffsMountings, 1, -1 do
		local v164 = v162.delayedPowerTakeOffsMountings[v163]
		if v164.jointDescIndex == p161 then
			local v165 = v164.input
			local v166 = v164.output
			if v165.attachFunc ~= nil then
				v165.attachFunc(p160, v165, v166)
			end
			ObjectChangeUtil.setObjectChanges(v165.objectChanges, true, p160, p160.setMovingToolDirty)
			ObjectChangeUtil.setObjectChanges(v166.objectChanges, true, p160, p160.setMovingToolDirty)
			table.remove(v162.delayedPowerTakeOffsMountings, v163)
		end
	end
end
function PowerTakeOffs.onPreDetachImplement(p167, p168)
	p167:detachPowerTakeOff(p167, p168)
	if p167.isClient then
		local v169 = p167.spec_powerTakeOffs
		g_soundManager:stopSamples(v169.samples.turnedOn)
	end
end
function PowerTakeOffs.loadPowerTakeOffFromConfigFile(p170, p171, p172)
	local v173 = Utils.getFilename(p172, p170.baseDirectory)
	local v174 = XMLFile.load("PtoConfig", v173, PowerTakeOffs.xmlSchema)
	if v174 == nil then
		Logging.warning("Failed to open powerTakeOff config file \'%s\'", v173)
		return
	else
		local v175 = v174:getValue("powerTakeOff#filename")
		if v175 == nil then
			Logging.xmlWarning(p170.xmlFile, "Failed to open powerTakeOff i3d file \'%s\' in \'%s\'", v175, v173)
			v174:delete()
		else
			local v176 = Utils.getFilename(v175, p170.baseDirectory)
			p171.xmlFile = v174
			p171.sharedLoadRequestId = p170:loadSubSharedI3DFile(v176, false, false, p170.onPowerTakeOffI3DLoaded, p170, {
				["xmlFile"] = v174,
				["powerTakeOff"] = p171
			})
		end
	end
end
function PowerTakeOffs.onPowerTakeOffI3DLoaded(p177, p178, _, p179)
	local v180 = p179.xmlFile
	local v181 = p179.powerTakeOff
	if p178 == 0 then
		if not (p177.isDeleted or p177.isDeleting) then
			Logging.xmlWarning(p177.xmlFile, "Failed to find powerTakeOff in file \'%s\'", v180.filename)
		end
	else
		v181.components = {}
		v181.i3dMappings = {}
		I3DUtil.loadI3DComponents(p178, v181.components)
		I3DUtil.loadI3DMapping(v180, "powerTakeOff", v181.components, v181.i3dMappings)
		v181.startNode = v180:getValue("powerTakeOff.startNode#node", nil, v181.components, v181.i3dMappings)
		if v181.startNode == nil then
			Logging.xmlWarning(v180, "Failed to find startNode in powerTakeOff file \'%s\'", v180.filename)
		else
			v181.size = v180:getValue("powerTakeOff#size", 0.19)
			v181.minLength = v180:getValue("powerTakeOff#minLength", 0.6)
			v181.maxAngle = v180:getValue("powerTakeOff#maxAngle", 45)
			v181.zOffset = v180:getValue("powerTakeOff#zOffset", 0)
			v181.animationNodes = g_animationManager:loadAnimations(v180, "powerTakeOff.animationNodes", v181.components, p177, v181.i3dMappings)
			if v181.material ~= nil then
				local v182 = v180:getValue("powerTakeOff#colorMaterialName", "powerTakeOff_main_mat")
				v181.material:apply(v181.startNode, v182, true)
			end
			if v181.decalMaterial ~= nil then
				local v183 = v180:getValue("powerTakeOff#decalColorMaterialName", "powerTakeOff_decal_mat")
				v181.decalMaterial:apply(v181.startNode, v183, true)
			end
			if v180:getValue("powerTakeOff#isSingleJoint") then
				p177:loadSingleJointPowerTakeOff(v181, v180, v181.components, v181.i3dMappings)
			elseif v180:getValue("powerTakeOff#isDoubleJoint") then
				p177:loadDoubleJointPowerTakeOff(v181, v180, v181.components, v181.i3dMappings)
			else
				p177:loadBasicPowerTakeOff(v181, v180, v181.components, v181.i3dMappings)
			end
			link(v181.inputNode, v181.startNode)
			v181.i3dLoaded = true
			if v181.isLocal then
				p177:placeLocalPowerTakeOff(v181)
			else
				p177:parkPowerTakeOff(v181)
			end
			p177:updatePowerTakeOff(v181, 0)
		end
		delete(p178)
	end
	v180:delete()
	v181.xmlFile = nil
end
function PowerTakeOffs.loadSingleJointPowerTakeOff(_, p184, p185, p186, p187)
	p184.startJoint = p185:getValue("powerTakeOff.startJoint#node", nil, p186, p187)
	p184.scalePart = p185:getValue("powerTakeOff.scalePart#node", nil, p186, p187)
	p184.scalePartRef = p185:getValue("powerTakeOff.scalePart#referenceNode", nil, p186, p187)
	local _, _, v188 = localToLocal(p184.scalePartRef, p184.scalePart, 0, 0, 0)
	p184.scalePartBaseDistance = v188
	p184.translationPart = p185:getValue("powerTakeOff.translationPart#node", nil, p186, p187)
	p184.translationPartRef = p185:getValue("powerTakeOff.translationPart#referenceNode", nil, p186, p187)
	p184.translationPartLength = p185:getValue("powerTakeOff.translationPart#length", 0.4)
	p184.decal = p185:getValue("powerTakeOff.translationPart.decal#node", nil, p186, p187)
	p184.decalSize = p185:getValue("powerTakeOff.translationPart.decal#size", 0.1)
	p184.decalOffset = p185:getValue("powerTakeOff.translationPart.decal#offset", 0.05)
	p184.decalMinOffset = p185:getValue("powerTakeOff.translationPart.decal#minOffset", 0.01)
	p184.endJoint = p185:getValue("powerTakeOff.endJoint#node", nil, p186, p187)
	p184.linkNode = p185:getValue("powerTakeOff.linkNode#node", nil, p186, p187)
	local _, _, v189 = localToLocal(p184.translationPart, p184.translationPartRef, 0, 0, 0)
	local _, _, v190 = localToLocal(p184.startNode, p184.linkNode, 0, 0, 0)
	p184.betweenLength = math.abs(v189)
	p184.connectorLength = math.abs(v190) - math.abs(v189)
	setTranslation(p184.linkNode, 0, 0, 0)
	setRotation(p184.linkNode, 0, 0, 0)
	p184.updateFunc = PowerTakeOffs.updateSingleJointPowerTakeOff
	p184.updateDistanceFunc = PowerTakeOffs.updateDistanceOfTypedPowerTakeOff
	p184.attachFunc = PowerTakeOffs.attachTypedPowerTakeOff
	p184.detachFunc = PowerTakeOffs.detachTypedPowerTakeOff
end
function PowerTakeOffs.updateSingleJointPowerTakeOff(_, p191, _)
	local v192, v193, v194 = getWorldTranslation(p191.linkNode)
	local v195, v196, v197 = worldToLocal(p191.startNode, v192, v193, v194)
	I3DUtil.setDirection(p191.startJoint, v195, v196, v197, 0, 1, 0)
	local v198, v199, v200 = worldToLocal(getParent(p191.endJoint), v192, v193, v194)
	setTranslation(p191.endJoint, 0, 0, MathUtil.vector3Length(v198, v199, v200))
	local v201 = calcDistanceFrom(p191.scalePart, p191.scalePartRef)
	setScale(p191.scalePart, 1, 1, v201 / p191.scalePartBaseDistance)
end
function PowerTakeOffs.loadDoubleJointPowerTakeOff(_, p202, p203, p204, p205)
	p202.startJoint1 = p203:getValue("powerTakeOff.startJoint1#node", nil, p204, p205)
	p202.startJoint2 = p203:getValue("powerTakeOff.startJoint2#node", nil, p204, p205)
	p202.scalePart = p203:getValue("powerTakeOff.scalePart#node", nil, p204, p205)
	p202.scalePartRef = p203:getValue("powerTakeOff.scalePart#referenceNode", nil, p204, p205)
	local _, _, v206 = localToLocal(p202.scalePartRef, p202.scalePart, 0, 0, 0)
	p202.scalePartBaseDistance = v206
	p202.translationPart = p203:getValue("powerTakeOff.translationPart#node", nil, p204, p205)
	p202.translationPartRef = p203:getValue("powerTakeOff.translationPart#referenceNode", nil, p204, p205)
	p202.translationPartLength = p203:getValue("powerTakeOff.translationPart#length", 0.4)
	p202.decal = p203:getValue("powerTakeOff.translationPart.decal#node", nil, p204, p205)
	p202.decalSize = p203:getValue("powerTakeOff.translationPart.decal#size", 0.1)
	p202.decalOffset = p203:getValue("powerTakeOff.translationPart.decal#offset", 0.05)
	p202.decalMinOffset = p203:getValue("powerTakeOff.translationPart.decal#minOffset", 0.01)
	p202.endJoint1 = p203:getValue("powerTakeOff.endJoint1#node", nil, p204, p205)
	p202.endJoint1Ref = p203:getValue("powerTakeOff.endJoint1#referenceNode", nil, p204, p205)
	p202.endJoint2 = p203:getValue("powerTakeOff.endJoint2#node", nil, p204, p205)
	p202.linkNode = p203:getValue("powerTakeOff.linkNode#node", nil, p204, p205)
	local _, _, v207 = localToLocal(p202.translationPart, p202.translationPartRef, 0, 0, 0)
	local _, _, v208 = localToLocal(p202.startNode, p202.linkNode, 0, 0, 0)
	p202.betweenLength = math.abs(v207)
	p202.connectorLength = math.abs(v208) - math.abs(v207)
	setTranslation(p202.linkNode, 0, 0, 0)
	setRotation(p202.linkNode, 0, 0, 0)
	p202.updateFunc = PowerTakeOffs.updateDoubleJointPowerTakeOff
	p202.updateDistanceFunc = PowerTakeOffs.updateDistanceOfTypedPowerTakeOff
	p202.attachFunc = PowerTakeOffs.attachTypedPowerTakeOff
	p202.detachFunc = PowerTakeOffs.detachTypedPowerTakeOff
end
function PowerTakeOffs.updateDoubleJointPowerTakeOff(_, p209, _)
	local v210, v211, v212 = getWorldTranslation(p209.startNode)
	local v213, v214, v215 = worldToLocal(getParent(p209.endJoint2), v210, v211, v212)
	local v216, v217, v218 = MathUtil.vector3Normalize(v213, v214, v215)
	I3DUtil.setDirection(p209.endJoint2, v216 * 0.5, v217 * 0.5, (v218 + 1) * 0.5, 0, 1, 0)
	local v219, v220, v221 = getWorldTranslation(p209.endJoint1Ref)
	local v222, v223, v224 = worldToLocal(getParent(p209.startJoint1), v219, v220, v221)
	local v225, v226, v227 = MathUtil.vector3Normalize(v222, v223, v224)
	I3DUtil.setDirection(p209.startJoint1, v225 * 0.5, v226 * 0.5, (v227 + 1) * 0.5, 0, 1, 0)
	local v228, v229, v230 = getWorldTranslation(p209.endJoint1Ref)
	local v231, v232, v233 = worldToLocal(getParent(p209.startJoint2), v228, v229, v230)
	local v234, v235, v236 = MathUtil.vector3Normalize(v231, v232, v233)
	I3DUtil.setDirection(p209.startJoint2, v234, v235, v236, 0, 1, 0)
	local v237, v238, v239 = worldToLocal(getParent(p209.endJoint1), v228, v229, v230)
	setTranslation(p209.endJoint1, 0, 0, MathUtil.vector3Length(v237, v238, v239))
	local v240 = calcDistanceFrom(p209.scalePart, p209.scalePartRef)
	setScale(p209.scalePart, 1, 1, v240 / p209.scalePartBaseDistance)
end
function PowerTakeOffs.loadBasicPowerTakeOff(_, p241, p242, p243, p244)
	p241.startNode = p242:getValue("powerTakeOff.startNode#node", nil, p243, p244)
	p241.linkNode = p242:getValue("powerTakeOff.linkNode#node", nil, p243, p244)
	p241.attachFunc = PowerTakeOffs.attachTypedPowerTakeOff
	p241.detachFunc = PowerTakeOffs.detachTypedPowerTakeOff
end
function PowerTakeOffs.updateDistanceOfTypedPowerTakeOff(_, p245)
	local v246 = (p245.predefinedLength or calcDistanceFrom(p245.linkNode, p245.startNode)) - p245.connectorLength
	local v247 = math.max(v246, 0) / p245.betweenLength
	setScale(p245.translationPart, 1, 1, v247)
	if p245.decal ~= nil then
		local v248 = v247 * p245.translationPartLength
		if p245.decalMinOffset * 2 + p245.decalSize < v248 then
			local v249 = (v248 - p245.decalSize) / 2
			local v250 = p245.decalOffset
			local v251 = math.min(v249, v250) + p245.decalSize * 0.5
			local v252, v253, _ = getTranslation(p245.decal)
			setTranslation(p245.decal, v252, v253, -v251 / v247)
			setScale(p245.decal, 1, 1, 1 / v247)
			return
		end
		setVisibility(p245.decal, false)
	end
end
function PowerTakeOffs.attachTypedPowerTakeOff(p254, p255, p256)
	if p254:validatePowerTakeOffAttachment(p255, p256) then
		link(p256.outputNode, p255.linkNode)
		link(p255.inputNode, p255.startNode)
		setTranslation(p255.linkNode, 0, 0, p255.zOffset)
		setTranslation(p255.startNode, 0, 0, -p255.zOffset)
		p254:updatePowerTakeOff(p255, 0)
		p254:updatePowerTakeOffLength(p255)
		setVisibility(p255.linkNode, true)
		setVisibility(p255.startNode, true)
		p255.isLinked = true
	end
end
function PowerTakeOffs.detachTypedPowerTakeOff(p257, p258, _)
	p257:parkPowerTakeOff(p258)
end
function PowerTakeOffs.validatePowerTakeOffAttachment(_, p259, p260)
	if p260.outputNode == nil or p259.inputNode == nil then
		return false
	end
	local v261, v262, v263 = getWorldTranslation(p260.outputNode)
	local v264, v265, v266 = getWorldTranslation(p259.inputNode)
	local v267 = MathUtil.vector3Length(v261 - v264, v262 - v265, v263 - v266)
	if v267 < p259.minLength then
		return false
	end
	local v268 = MathUtil.vector2Length(v261 - v264, v263 - v266) / v267
	return math.acos(v268) <= p259.maxAngle
end
function PowerTakeOffs.loadExtraDependentParts(p269, p270, p271, p272, p273)
	if not p270(p269, p271, p272, p273) then
		return false
	end
	local v274 = p271:getValue(p272 .. ".powerTakeOffs#indices", nil, true)
	if v274 ~= nil then
		p273.powerTakeOffs = {}
		for v275 = 1, #v274 do
			local v276 = p273.powerTakeOffs
			local v277 = v274[v275]
			table.insert(v276, v277)
		end
	end
	local v278 = p271:getValue(p272 .. ".powerTakeOffs#localIndices", nil, true)
	if v278 ~= nil then
		p273.localPowerTakeOffs = {}
		for v279 = 1, #v278 do
			local v280 = p273.localPowerTakeOffs
			local v281 = v278[v279]
			table.insert(v280, v281)
		end
	end
	return true
end
function PowerTakeOffs.updateExtraDependentParts(p282, p283, p284, p285)
	p283(p282, p284, p285)
	if p284.powerTakeOffs ~= nil then
		local v286 = p282.spec_powerTakeOffs
		for v287, v288 in ipairs(p284.powerTakeOffs) do
			if v286.inputPowerTakeOffs[v288] == nil then
				if p282.finishedLoading then
					p284.powerTakeOffs[v287] = nil
					Logging.xmlWarning(p282.xmlFile, "Unable to find powerTakeOff index \'%d\' for movingPart/movingTool \'%s\'", v288, getName(p284.node))
				end
			else
				p282:updatePowerTakeOff(v286.inputPowerTakeOffs[v288], p285)
			end
		end
	end
	if p284.localPowerTakeOffs ~= nil then
		local v289 = p282.spec_powerTakeOffs
		for v290, v291 in ipairs(p284.localPowerTakeOffs) do
			if v289.localPowerTakeOffs[v291] == nil then
				if p282.finishedLoading then
					p284.localPowerTakeOffs[v290] = nil
					Logging.xmlWarning(p282.xmlFile, "Unable to find local powerTakeOff index \'%d\' for movingPart/movingTool \'%s\'", v291, getName(p284.node))
				end
			else
				p282:placeLocalPowerTakeOff(v289.localPowerTakeOffs[v291], p285)
			end
		end
	end
end
function PowerTakeOffs.consoleCommandTestConnection(p292, p293)
	local v294 = p292.spec_powerTakeOffs
	if v294 ~= nil then
		local v295 = Color.new(0, 0.5, 1)
		for _, v296 in pairs(v294.outputPowerTakeOffs) do
			if v296.debugLine ~= nil then
				g_debugManager:removeElement(v296.debugLine)
				v296.debugLine = nil
			end
			if v296.debugText ~= nil then
				g_debugManager:removeElement(v296.debugText)
				v296.debugText = nil
			end
			for v297 = getNumOfChildren(v296.outputNode), 1, -1 do
				delete(getChildAt(v296.outputNode, v297 - 1))
			end
			if v296.attacherJointIndices[p293] == nil then
				ObjectChangeUtil.setObjectChanges(v296.objectChanges, false, p292, p292.setMovingToolDirty)
			else
				local v298 = g_i3DManager:loadI3DFile("data/shared/assets/powerTakeOffs/walterscheidW.i3d", false, false)
				if v298 ~= 0 then
					link(v296.outputNode, v298)
					setTranslation(v298, 0, 0, 0.045)
					setRotation(v298, 0, 3.141592653589793, 0)
					setVisibility(getChildAt(getChildAt(v298, 0), 0), false)
					local v299 = VehicleMaterial.new()
					v299.colorScale = {
						1,
						0,
						1,
						1
					}
					v299:apply(v298)
				end
				ObjectChangeUtil.setObjectChanges(v296.objectChanges, true, p292, p292.setMovingToolDirty)
				local v300 = p292:getAttacherJointByJointDescIndex(p293)
				if v300 ~= nil then
					v296.debugLine = DebugLine.new():createWithStartAndEndNode(v300.jointTransform, v296.outputNode, false, true, 100, true)
					v296.debugLine:setColors(v295, v295)
					g_debugManager:addElement(v296.debugLine, nil, nil, (1 / 0))
					v296.debugText = DebugText.new():createWithNode(v296.outputNode, getName(v296.outputNode), 0.01, true)
					g_debugManager:addElement(v296.debugText, nil, nil, (1 / 0))
				end
			end
		end
	end
end
function PowerTakeOffs.consoleCommandDebug(_)
	if PowerTakeOffs.debugRootNode == nil then
		PowerTakeOffs.debugRootNode = createTransformGroup("powerTakeOffsDebugRoot")
		link(getRootNode(), PowerTakeOffs.debugRootNode)
		local v301, v302, v303 = g_localPlayer:getPosition()
		local v304, v305 = g_localPlayer:getCurrentFacingDirection()
		local v306 = v301 + v304 * 4
		local v307 = v303 + v305 * 4
		local v308 = MathUtil.getYRotationFromDirection(v304, v305)
		setWorldTranslation(PowerTakeOffs.debugRootNode, v306, v302, v307)
		setWorldRotation(PowerTakeOffs.debugRootNode, 0, v308, 0)
	end
	if PowerTakeOffs.debugPowerTakeOffs ~= nil then
		for _, v309 in ipairs(PowerTakeOffs.debugPowerTakeOffs) do
			g_currentMission:removeUpdateable(v309)
			if v309.xmlFile ~= nil then
				v309.xmlFile:delete()
			end
			if v309.sharedLoadRequestId ~= nil then
				g_i3DManager:releaseSharedI3DFile(v309.sharedLoadRequestId)
				v309.sharedLoadRequestId = nil
			end
			g_animationManager:deleteAnimations(v309.animationNodes)
			g_animationManager:deleteAnimations(v309.localAnimationNodes)
			delete(v309.inputNode)
		end
	end
	PowerTakeOffs.debugPowerTakeOffs = {}
	local v310 = Files.getFilesRecursive(getAppBasePath() .. "data/shared/assets/powerTakeOffs")
	table.sort(v310, function(p311, p312)
		return p311.path < p312.path
	end)
	local v313 = nil
	local v314 = nil
	local v315 = 0
	local v316 = 0
	for _, v317 in ipairs(v310) do
		if not v317.isDirectory and v317.filename:contains(".xml") then
			local v318 = createTransformGroup("linkNode")
			link(PowerTakeOffs.debugRootNode, v318)
			local v319 = v317.filename
			local v320 = string.gsub(v319, ".xml", "")
			local v321 = v317.path:split(v317.filename)[1]
			local v322
			if v321 == v313 and v320 == v314 then
				v320 = v314
				v321 = v313
				v322 = v316
			else
				v315 = v315 + 1
				local v323, v324, v325 = localToWorld(PowerTakeOffs.debugRootNode, v315 * 2, 1, -1)
				local v326, v327, v328 = localRotationToWorld(PowerTakeOffs.debugRootNode, -1.5707963267948966, 3.141592653589793, 0)
				g_debugManager:addElement(DebugText3D.new():createWithWorldPos(v323, v324, v325, v326, v327, v328, v320, 0.15), nil, nil, (1 / 0))
				v322 = 0
			end
			local v329 = v315 * 2
			v316 = v322 + 1
			setTranslation(v318, v329, 1, v322)
			setRotation(v318, 0, 0, 0)
			v314 = v320
			v313 = v321
			for v_u_330 = 1, 3 do
				local v_u_331 = {
					["baseDirectory"] = ""
				}
				for v332, v333 in pairs(PowerTakeOffs) do
					v_u_331[v332] = v333
				end
				function v_u_331.onPowerTakeOffI3DLoaded(p334, p335, p336, p337)
					-- upvalues: (copy) v_u_330, (copy) v_u_331
					local v338 = p337.xmlFile:getValue("powerTakeOff#colorMaterialName", "powerTakeOff_main_mat")
					local v339 = p337.xmlFile:getValue("powerTakeOff#decalColorMaterialName", "powerTakeOff_decal_mat")
					PowerTakeOffs.onPowerTakeOffI3DLoaded(p334, p335, p336, p337)
					if p335 ~= 0 then
						local v340 = p337.powerTakeOff
						if v_u_330 == 2 then
							v340.material = VehicleMaterial.new()
							v340.material.colorScale = {
								0,
								1,
								1,
								1
							}
							v340.material:apply(v340.inputNode, v338)
							v340.decalMaterial = VehicleMaterial.new()
							v340.decalMaterial.colorScale = {
								1,
								0,
								1,
								1
							}
							v340.decalMaterial:apply(v340.inputNode, v339)
						elseif v_u_330 == 3 then
							g_animationManager:startAnimations(v340.animationNodes)
							v_u_331.dynamicPowerTakeOff = v340
							v_u_331.time = 0
							function v_u_331.update(p341, p342)
								p341.time = (p341.time + p342) % 2500
								local v343 = p341.time / 2500
								setTranslation(p341.dynamicPowerTakeOff.detachNode, v343 * 0.5, v343, -1.5)
								if p341.dynamicPowerTakeOff.updateFunc ~= nil then
									p341.dynamicPowerTakeOff.updateFunc(self, p341.dynamicPowerTakeOff, p342)
								end
							end
							g_currentMission:addUpdateable(v_u_331, v340)
						end
						local v344 = PowerTakeOffs.debugPowerTakeOffs
						table.insert(v344, v340)
					end
				end
				function v_u_331.loadSubSharedI3DFile(_, p345, p346, p347, p348, p349, p350)
					return g_i3DManager:loadSharedI3DFileAsync(p345, p346, p347, p348, p349, p350)
				end
				local v351 = {
					["inputNode"] = createTransformGroup("inputNode")
				}
				link(v318, v351.inputNode)
				setTranslation(v351.inputNode, 0, 0, v_u_330 * 3)
				setRotation(v351.inputNode, 0, 3.141592653589793, 0)
				v351.detachNode = createTransformGroup("detachNode")
				link(v351.inputNode, v351.detachNode)
				setTranslation(v351.detachNode, 0, 0, -1.5)
				setRotation(v351.detachNode, 0, 0, 0)
				local v352 = string.gsub(v317.path, getAppBasePath(), "")
				PowerTakeOffs.loadPowerTakeOffFromConfigFile(v_u_331, v351, v352)
				g_debugManager:addElement(DebugGizmo.new():createWithNode(v351.inputNode, "start", nil, nil, 0.25), nil, nil, (1 / 0))
				g_debugManager:addElement(DebugGizmo.new():createWithNode(v351.detachNode, "end", nil, nil, 0.25), nil, nil, (1 / 0))
				v320 = v314
				v321 = v313
				v314 = v320
				v313 = v321
			end
		end
	end
end
addConsoleCommand("gsVehicleDebugPowerTakeOffs", "Spawns all power take offs in front of the player", "PowerTakeOffs.consoleCommandDebug", nil)

source("dataS/scripts/vehicles/specializations/events/HonkEvent.lua")
Honk = {}
function Honk.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(Drivable, p1)
end
function Honk.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Honk")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.honk", "sound")
	v2:setXMLSpecializationType()
end
function Honk.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "getIsHonkAvailable", Honk.getIsHonkAvailable)
	SpecializationUtil.registerFunction(p3, "setHonkInput", Honk.setHonkInput)
	SpecializationUtil.registerFunction(p3, "playHonk", Honk.playHonk)
end
function Honk.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", Honk)
	SpecializationUtil.registerEventListener(p4, "onDelete", Honk)
	SpecializationUtil.registerEventListener(p4, "onUpdate", Honk)
	SpecializationUtil.registerEventListener(p4, "onLeaveVehicle", Honk)
	SpecializationUtil.registerEventListener(p4, "onRegisterActionEvents", Honk)
end
function Honk.onLoad(p5, _)
	local v6 = p5.spec_honk
	v6.inputPressed = false
	v6.isPlaying = false
	if p5.isClient then
		v6.sample = g_soundManager:loadSampleFromXML(p5.xmlFile, "vehicle.honk", "sound", p5.baseDirectory, p5.components, 0, AudioGroup.VEHICLE, p5.i3dMappings, p5)
	end
	if not p5.isClient then
		SpecializationUtil.removeEventListener(p5, "onUpdate", Honk)
	end
end
function Honk.onDelete(p7)
	local v8 = p7.spec_honk
	g_soundManager:deleteSample(v8.sample)
end
function Honk.onUpdate(p9, _, _, p10, _)
	if p9.isClient and p10 then
		local v11 = p9.spec_honk
		if v11.inputPressed then
			if not g_soundManager:getIsSamplePlaying(v11.sample) then
				p9:playHonk(true)
			end
		elseif v11.isPlaying then
			p9:playHonk(false)
		end
		v11.inputPressed = false
	end
end
function Honk.onLeaveVehicle(p12)
	p12:playHonk(false, true)
end
function Honk.getIsHonkAvailable(_)
	return true
end
function Honk.setHonkInput(p13)
	p13.spec_honk.inputPressed = true
end
function Honk.playHonk(p14, p15, p16)
	HonkEvent.sendEvent(p14, p15, p16)
	local v17 = p14.spec_honk
	v17.isPlaying = p15
	if v17.sample ~= nil then
		if p15 then
			if p14:getIsActive() and p14.isClient then
				g_soundManager:playSample(v17.sample)
				return
			end
		else
			g_soundManager:stopSample(v17.sample)
		end
	end
end
function Honk.onRegisterActionEvents(p18, _, p19)
	if p18.isClient then
		local v20 = p18.spec_honk
		p18:clearActionEventsTable(v20.actionEvents)
		if p19 and v20.sample ~= nil then
			local _, v21 = p18:addActionEvent(v20.actionEvents, InputAction.HONK, p18, Honk.actionEventHonk, false, true, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v21, GS_PRIO_VERY_LOW)
			g_inputBinding:setActionEventActive(v21, true)
			g_inputBinding:setActionEventText(v21, g_i18n:getText("action_honk"))
		end
	end
end
function Honk.actionEventHonk(p22, _, _, _, _)
	p22:setHonkInput()
end

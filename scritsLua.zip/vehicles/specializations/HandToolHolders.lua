HandToolHolders = {}
function HandToolHolders.prerequisitesPresent(_)
	return true
end
function HandToolHolders.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("handToolHolder", g_i18n:getText("shop_configuration"), "handToolHolders", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("HandToolHolders")
	HandToolHolder.registerXMLPaths(v1, "vehicle.handToolHolders")
	HandToolHolder.registerXMLPaths(v1, "vehicle.handToolHolders.handToolHolderConfigurations.handToolHolderConfiguration(?)")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	HandToolHolder.registerSavegameXMLPaths(Vehicle.xmlSchemaSavegame, "vehicles.vehicle(?).handToolHolders.handToolHolder(?)")
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).handToolHolders.handToolHolder(?)#index", "Index of the holder", nil, true)
end
function HandToolHolders.registerEvents(p3)
	SpecializationUtil.registerEvent(p3, "onHandToolStoredInHolder")
	SpecializationUtil.registerEvent(p3, "onHandToolTakenFromHolder")
end
function HandToolHolders.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "onHandToolHolderFinished", HandToolHolders.onHandToolHolderFinished)
end
function HandToolHolders.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "setOwnerFarmId", HandToolHolders.setOwnerFarmId)
end
function HandToolHolders.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", HandToolHolders)
	SpecializationUtil.registerEventListener(p6, "onDelete", HandToolHolders)
	SpecializationUtil.registerEventListener(p6, "saveToXMLFile", HandToolHolders)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", HandToolHolders)
	SpecializationUtil.registerEventListener(p6, "onReadStream", HandToolHolders)
	SpecializationUtil.registerEventListener(p6, "onRegistered", HandToolHolders)
end
function HandToolHolders.onLoad(p7, p8)
	local v9 = p7.spec_handToolHolders
	local v10 = p7.configurations.handToolHolder or 1
	local v11 = string.format("vehicle.handToolHolders.handToolHolderConfigurations.handToolHolderConfiguration(%d)", v10 - 1)
	local v12 = not p7.xmlFile:hasProperty(v11) and "vehicle.handToolHolders" or v11
	v9.handToolHolders = {}
	local v13 = p7:getName()
	local v14 = g_brandManager:getBrandByIndex(p7:getBrand())
	if v14 ~= nil then
		v13 = v14.title .. " " .. v13
	end
	local v15 = string.format(g_i18n:getText("ui_handToolHolderVehicle"), v13)
	for _, v16 in p7.xmlFile:iterator(v12 .. ".handToolHolder") do
		local v17 = HandToolHolder.new(p7, p7.isServer, p7.isClient)
		v17:setHolderName(v15)
		local v18 = {
			["loadingTask"] = p7:createLoadingTask(p7),
			["xmlFile"] = p7.xmlFile,
			["key"] = v16,
			["savegame"] = p8
		}
		v17:load(p7.xmlFile, v16, p7.onHandToolHolderFinished, p7, v18, p7.components, p7.i3dMappings, p7.baseDirectory, p7.customEnvironment)
	end
end
function HandToolHolders.onHandToolHolderFinished(p_u_19, p20, p21)
	if p20 ~= nil then
		local v22 = p_u_19.spec_handToolHolders
		p20:setOwnerFarmId(p_u_19:getOwnerFarmId())
		p20:setStoreCallback(function(p23)
			-- upvalues: (copy) p_u_19
			SpecializationUtil.raiseEvent(p_u_19, "onHandToolStoredInHolder", p23)
		end)
		p20:setPickupCallback(function(p24)
			-- upvalues: (copy) p_u_19
			SpecializationUtil.raiseEvent(p_u_19, "onHandToolTakenFromHolder", p24)
		end)
		local v25 = v22.handToolHolders
		table.insert(v25, p20)
		local v26 = #v22.handToolHolders
		local v27 = p21.savegame
		if v27 ~= nil and not v27.resetVehicles then
			for _, v28 in v27.xmlFile:iterator(v27.key .. ".handToolHolders.handToolHolder") do
				if v27.xmlFile:getValue(v28 .. "#index") == v26 then
					p20:loadFromXMLFile(v27.xmlFile, v28)
					break
				end
			end
		end
	end
	p_u_19:finishLoadingTask(p21.loadingTask)
end
function HandToolHolders.onDelete(p29)
	local v30 = p29.spec_handToolHolders
	if v30.handToolHolders ~= nil then
		for _, v31 in ipairs(v30.handToolHolders) do
			v31:delete()
		end
	end
end
function HandToolHolders.saveToXMLFile(p32, p33, p34, _)
	local v35 = p32.spec_handToolHolders
	if v35.handToolHolders ~= nil then
		for v36, v37 in ipairs(v35.handToolHolders) do
			local v38 = string.format("%s.handToolHolder(%d)", p34, v36 - 1)
			p33:setValue(v38 .. "#index", v36)
			v37:saveToXMLFile(p33, v38)
		end
	end
end
function HandToolHolders.onWriteStream(p39, p40, p41)
	if not p41:getIsServer() then
		local v42 = p39.spec_handToolHolders
		if v42.handToolHolders ~= nil then
			for _, v43 in ipairs(v42.handToolHolders) do
				NetworkUtil.writeNodeObjectId(p40, NetworkUtil.getObjectId(v43))
				v43:writeStream(p40, p41)
				g_server:registerObjectInStream(p41, v43)
			end
		end
	end
end
function HandToolHolders.onReadStream(p44, p45, p46)
	if p46:getIsServer() then
		local v47 = p44.spec_handToolHolders
		if v47.handToolHolders ~= nil then
			for _, v48 in ipairs(v47.handToolHolders) do
				local v49 = NetworkUtil.readNodeObjectId(p45)
				v48:readStream(p45, p46)
				g_client:finishRegisterObject(v48, v49)
			end
		end
	end
end
function HandToolHolders.setOwnerFarmId(p50, p51, p52, p53)
	p51(p50, p52, p53)
	local v54 = p50.spec_handToolHolders
	if v54.handToolHolders ~= nil then
		for _, v55 in ipairs(v54.handToolHolders) do
			v55:setOwnerFarmId(p52, true)
		end
	end
end
function HandToolHolders.onRegistered(p56, _)
	local v57 = p56.spec_handToolHolders
	if v57.handToolHolders ~= nil then
		for _, v58 in ipairs(v57.handToolHolders) do
			v58:register(true)
		end
	end
end

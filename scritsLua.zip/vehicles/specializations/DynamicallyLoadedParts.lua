DynamicallyLoadedParts = {}
function DynamicallyLoadedParts.prerequisitesPresent(_)
	return true
end
function DynamicallyLoadedParts.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("DynamicallyLoadedParts")
	v1:register(XMLValueType.STRING, "vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart(?)#filename", "Filename to i3d file")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart(?)#node", "Node in external i3d file", "0|0")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart(?)#linkNode", "Link node", "0>")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart(?)#position", "Position", "0 0 0")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart(?)#rotationNode", "Rotation node", "node")
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart(?)#rotation", "Rotation node rotation")
	v1:register(XMLValueType.STRING, "vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart(?)#shaderParameterName", "Shader parameter name")
	v1:register(XMLValueType.VECTOR_4, "vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart(?)#shaderParameter", "Shader parameter to apply")
	v1:setXMLSpecializationType()
end
function DynamicallyLoadedParts.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "onDynamicallyPartI3DLoaded", DynamicallyLoadedParts.onDynamicallyPartI3DLoaded)
end
function DynamicallyLoadedParts.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", DynamicallyLoadedParts)
	SpecializationUtil.registerEventListener(p3, "onDelete", DynamicallyLoadedParts)
end
function DynamicallyLoadedParts.onLoad(p_u_4, _)
	local v_u_5 = p_u_4.spec_dynamicallyLoadedParts
	v_u_5.sharedLoadRequestIds = {}
	v_u_5.parts = {}
	p_u_4.xmlFile:iterate("vehicle.dynamicallyLoadedParts.dynamicallyLoadedPart", function(_, p6)
		-- upvalues: (copy) p_u_4, (copy) v_u_5
		local v7 = p_u_4.xmlFile:getValue(p6 .. "#filename")
		if v7 == nil then
			Logging.xmlWarning(p_u_4.xmlFile, "Missing filename for dynamically loaded part \'%s\'", p6)
		else
			local v8 = {
				["filename"] = Utils.getFilename(v7, p_u_4.baseDirectory)
			}
			local v9 = {
				["xmlFile"] = p_u_4.xmlFile,
				["partKey"] = p6,
				["dynamicallyLoadedPart"] = v8
			}
			local v10 = p_u_4:loadSubSharedI3DFile(v8.filename, false, false, p_u_4.onDynamicallyPartI3DLoaded, p_u_4, v9)
			local v11 = v_u_5.sharedLoadRequestIds
			table.insert(v11, v10)
		end
	end)
end
function DynamicallyLoadedParts.onDelete(p12)
	local v13 = p12.spec_dynamicallyLoadedParts
	if v13.sharedLoadRequestIds ~= nil then
		for _, v14 in ipairs(v13.sharedLoadRequestIds) do
			g_i3DManager:releaseSharedI3DFile(v14)
		end
		v13.sharedLoadRequestIds = nil
	end
end
function DynamicallyLoadedParts.onDynamicallyPartI3DLoaded(p15, p16, _, p17)
	local v18 = p15.spec_dynamicallyLoadedParts
	local v19 = p17.xmlFile
	local v20 = p17.partKey
	local v21 = p17.dynamicallyLoadedPart
	if p16 == 0 then
		Logging.xmlWarning(v19, "Failed to load dynamicallyLoadedPart \'%s\'. Unable to load i3d", v20)
		return false
	end
	local v22 = v19:getValue(v20 .. "#node", "0|0", p16)
	if v22 == nil then
		Logging.xmlWarning(v19, "Failed to load dynamicallyLoadedPart \'%s\'. Unable to find node in loaded i3d", v20)
		delete(p16)
		return false
	end
	local v23 = v19:getValue(v20 .. "#linkNode", "0>", p15.components, p15.i3dMappings)
	if v23 == nil then
		Logging.xmlWarning(v19, "Failed to load dynamicallyLoadedPart \'%s\'. Unable to find linkNode", v20)
		delete(p16)
		return false
	end
	local v24, v25, v26 = getReferenceInfo(v23)
	if not (v24 and v26) then
		local v27, v28, v29 = v19:getValue(v20 .. "#position")
		if v27 == nil or (v28 == nil or v29 == nil) then
			setTranslation(v22, 0, 0, 0)
		else
			setTranslation(v22, v27, v28, v29)
		end
		setRotation(v22, 0, 0, 0)
		local v30 = v19:getValue(v20 .. "#rotationNode", v22, p16)
		local v31, v32, v33 = v19:getValue(v20 .. "#rotation")
		if v31 ~= nil and (v32 ~= nil and v33 ~= nil) then
			setRotation(v30, v31, v32, v33)
		end
		local v34 = v19:getValue(v20 .. "#shaderParameterName")
		local v35, v36, v37, v38 = v19:getValue(v20 .. "#shaderParameter")
		if v34 ~= nil and (v35 ~= nil and (v36 ~= nil and (v37 ~= nil and v38 ~= nil))) then
			setShaderParameter(v22, v34, v35, v36, v37, v38, false)
		end
		link(v23, v22)
		delete(p16)
		local v39 = v18.parts
		table.insert(v39, v21)
		return true
	end
	local v40 = Utils.getFilenameInfo(v21.filename, true)
	local v41 = Utils.getFilenameInfo(v25, true)
	if v40 ~= v41 then
		Logging.xmlWarning(v19, "DynamicallyLoadedPart \'%s\' loading different file from XML compared to i3D. (XML: %s vs i3D: %s)", getName(v23), v40, v41)
	end
	Logging.xmlWarning(v19, "DynamicallyLoadedPart link node \'%s\' is a runtime loaded reference. Please load it either via XML or the i3D reference, but not both!", getName(v23))
	delete(p16)
end

HeadlandAnimation = {}
function HeadlandAnimation.prerequisitesPresent(_)
	return true
end
function HeadlandAnimation.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("HeadlandAnimation")
	v1:register(XMLValueType.TIME, "vehicle.headlandAnimation#activationDelay", "Headland is activated after this time above activationAngle", 0.5)
	v1:register(XMLValueType.TIME, "vehicle.headlandAnimation#deactivationDelay", "Headland is deactivated after this time below deactivationAngle", 4)
	v1:register(XMLValueType.FLOAT, "vehicle.headlandAnimation#activationAngle", "Headland is activated above this steering percentage [0-1]", 0.2)
	v1:register(XMLValueType.FLOAT, "vehicle.headlandAnimation#deactivationAngle", "Headland is deactivated below this steering percentage [0-1]", 0.13)
	v1:register(XMLValueType.STRING, "vehicle.headlandAnimation#requiredGroundTypes", "Headland is only activated one of these ground types is below vehicle")
	v1:register(XMLValueType.STRING, "vehicle.headlandAnimation.animation(?)#name", "Animation name")
	v1:register(XMLValueType.FLOAT, "vehicle.headlandAnimation.animation(?)#speed", "Animation speed")
	v1:setXMLSpecializationType()
end
function HeadlandAnimation.registerFunctions(_) end
function HeadlandAnimation.registerOverwrittenFunctions(_) end
function HeadlandAnimation.registerEventListeners(p2)
	SpecializationUtil.registerEventListener(p2, "onLoad", HeadlandAnimation)
	SpecializationUtil.registerEventListener(p2, "onUpdate", HeadlandAnimation)
end
function HeadlandAnimation.onLoad(p3, _)
	local v4 = p3.spec_headlandAnimation
	v4.isAvailable = p3.xmlFile:hasProperty("vehicle.headlandAnimation")
	if v4.isAvailable then
		v4.headlandActivationDelay = p3.xmlFile:getValue("vehicle.headlandAnimation#activationDelay", 0.5)
		v4.headlandDeactivationDelay = p3.xmlFile:getValue("vehicle.headlandAnimation#deactivationDelay", 4)
		v4.headlandActivationAngle = p3.xmlFile:getValue("vehicle.headlandAnimation#activationAngle", 0.2)
		v4.headlandDeactivationAngle = p3.xmlFile:getValue("vehicle.headlandAnimation#deactivationAngle", 0.13)
		local v5 = p3.xmlFile:getValue("vehicle.headlandAnimation#requiredGroundTypes"):split(" ")
		v4.requiredGroundTypes = {}
		for v6 = 1, #v5 do
			local v7 = v5[v6]
			if v7 ~= nil and v7 ~= "" then
				local v8 = FieldGroundType[v7]
				if v8 == nil then
					Logging.xmlWarning(p3.xmlFile, "Unknown ground type \'%s\' defined for headland animation", v7)
				else
					v4.requiredGroundTypes[v8] = true
				end
			end
		end
		v4.headlandDeactivationTime = 0
		v4.headlandState = false
		v4.lastHeadlandState = false
		v4.animations = {}
		local v9 = 0
		while true do
			local v10 = string.format("vehicle.headlandAnimation.animation(%d)", v9)
			if not p3.xmlFile:hasProperty(v10) then
				break
			end
			local v11 = {
				["name"] = p3.xmlFile:getValue(v10 .. "#name"),
				["speed"] = p3.xmlFile:getValue(v10 .. "#speed")
			}
			if v11.name ~= nil then
				local v12 = v4.animations
				table.insert(v12, v11)
			end
			v9 = v9 + 1
		end
	else
		SpecializationUtil.removeEventListener(p3, "onUpdate", HeadlandAnimation)
	end
end
function HeadlandAnimation.onUpdate(p13, p14, _, _, _)
	local v15 = p13.spec_headlandAnimation
	local v16 = true
	if v15.headlandRequiredDensityBits ~= 0 then
		local v17, v18, v19 = getWorldTranslation(p13.components[1].node)
		local _, _, v20 = FSDensityMapUtil.getFieldDataAtWorldPosition(v17, v18, v19)
		if v15.requiredGroundTypes[v20] ~= true then
			v16 = false
		end
	end
	if v16 then
		local v21 = p13.rotatedTime
		if math.abs(v21) > v15.headlandActivationAngle then
			v15.headlandDeactivationTime = v15.headlandDeactivationTime + p14
			if v15.headlandDeactivationTime > v15.headlandActivationDelay then
				v15.headlandState = true
				v15.headlandDeactivationTime = v15.headlandDeactivationDelay
			end
			::l8::
			if v15.headlandDeactivationTime == 0 then
				v15.headlandState = false
			end
			if v15.headlandState ~= v15.lastHeadlandState then
				local v22 = v15.headlandState and 1 or -1
				for v23 = 1, #v15.animations do
					local v24 = v15.animations[v23]
					p13:playAnimation(v24.name, v24.speed * v22, p13:getAnimationTime(v24.name))
				end
				v15.lastHeadlandState = v15.headlandState
			end
			return
		end
	end
	local v25 = p13.rotatedTime
	if math.abs(v25) < v15.headlandDeactivationAngle then
		local v26 = v15.headlandDeactivationTime - p14
		v15.headlandDeactivationTime = math.max(v26, 0)
	end
	goto l8
end

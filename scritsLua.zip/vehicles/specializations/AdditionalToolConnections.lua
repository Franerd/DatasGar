AdditionalToolConnections = {}
function AdditionalToolConnections.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AttacherJoints, p1) or SpecializationUtil.hasSpecialization(Attachable, p1)
end
function AdditionalToolConnections.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("AdditionalToolConnections")
	v2:register(XMLValueType.STRING, "vehicle.additionalToolConnections.connection(?)#id", "Identifier of the tool connection")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.additionalToolConnections.connection(?)#movingPartNode", "Node of movingPart to set the reference node to the connection node")
	ObjectChangeUtil.registerObjectChangeXMLPaths(v2, "vehicle.additionalToolConnections.connection(?)")
	v2:addDelayedRegistrationFunc("AttacherJoint", function(p3, p4)
		p3:register(XMLValueType.STRING, p4 .. ".additionalToolConnection(?)#id", "Identifier of the tool connection")
		p3:register(XMLValueType.NODE_INDEX, p4 .. ".additionalToolConnection(?)#node", "Node to connect to")
	end)
	v2:setXMLSpecializationType()
end
function AdditionalToolConnections.registerFunctions(_) end
function AdditionalToolConnections.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadAttacherJointFromXML", AdditionalToolConnections.loadAttacherJointFromXML)
end
function AdditionalToolConnections.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onPostLoad", AdditionalToolConnections)
	SpecializationUtil.registerEventListener(p6, "onPostAttach", AdditionalToolConnections)
	SpecializationUtil.registerEventListener(p6, "onPreDetach", AdditionalToolConnections)
end
function AdditionalToolConnections.onPostLoad(p_u_7, _)
	local v_u_8 = p_u_7.spec_additionalToolConnections
	v_u_8.additionalToolConnections = {}
	p_u_7.xmlFile:iterate("vehicle.additionalToolConnections.connection", function(_, p9)
		-- upvalues: (copy) p_u_7, (copy) v_u_8
		local v10 = p_u_7.xmlFile:getValue(p9 .. "#id")
		local v11 = p_u_7.xmlFile:getValue(p9 .. "#movingPartNode", nil, p_u_7.components, p_u_7.i3dMappings)
		if v10 == nil or v11 == nil then
			Logging.xmlWarning(p_u_7.xmlFile, "Failed to load additionalToolConnection \'%s\'", p9)
			return
		elseif p_u_7:getMovingPartByNode(v11) == nil then
			Logging.xmlWarning(p_u_7.xmlFile, "Failed to find moving part for \'%s\' in \'%s\'", getName(v11), p9)
		else
			local v12 = {
				["id"] = v10,
				["movingPartNode"] = v11,
				["objectChanges"] = {}
			}
			ObjectChangeUtil.loadObjectChangeFromXML(p_u_7.xmlFile, p9, v12.objectChanges, p_u_7.components, p_u_7)
			ObjectChangeUtil.setObjectChanges(v12.objectChanges, false, p_u_7, p_u_7.setMovingToolDirty)
			local v13 = v_u_8.additionalToolConnections
			table.insert(v13, v12)
		end
	end)
end
function AdditionalToolConnections.loadAttacherJointFromXML(p_u_14, p15, p_u_16, p_u_17, p18, p19, ...)
	if not p15(p_u_14, p_u_16, p_u_17, p18, p19, ...) then
		return false
	end
	p_u_16.additionalToolConnections = p_u_16.additionalToolConnections or {}
	p_u_17:iterate(p18 .. ".additionalToolConnection", function(_, p20)
		-- upvalues: (copy) p_u_17, (copy) p_u_14, (copy) p_u_16
		local v21 = p_u_17:getValue(p20 .. "#id")
		local v22 = p_u_17:getValue(p20 .. "#node", nil, p_u_14.components, p_u_14.i3dMappings)
		if v21 == nil or v22 == nil then
			Logging.xmlWarning(p_u_17, "Failed to load additionalToolConnection \'%s\'", p20)
		else
			p_u_16.additionalToolConnections[v21] = v22
		end
	end)
	return true
end
function AdditionalToolConnections.onPostAttach(p23, p24, _, p25, _)
	local v26 = p23.spec_additionalToolConnections
	local v27 = p24:getAttacherJointByJointDescIndex(p25)
	if v27.additionalToolConnections ~= nil then
		for v28 = 1, #v26.additionalToolConnections do
			local v29 = v26.additionalToolConnections[v28]
			local v30 = v27.additionalToolConnections[v29.id]
			if v30 ~= nil then
				p23:setMovingPartReferenceNode(v29.movingPartNode, v30, true)
				ObjectChangeUtil.setObjectChanges(v29.objectChanges, true, p23, p23.setMovingToolDirty)
			end
		end
	end
end
function AdditionalToolConnections.onPreDetach(p31, _, _)
	local v32 = p31.spec_additionalToolConnections
	for v33 = 1, #v32.additionalToolConnections do
		local v34 = v32.additionalToolConnections[v33]
		p31:setMovingPartReferenceNode(v34.movingPartNode, nil, false)
		ObjectChangeUtil.setObjectChanges(v34.objectChanges, false, p31, p31.setMovingToolDirty)
	end
end

WinchAttachTreeActivatable = {}
local v_u_1 = Class(WinchAttachTreeActivatable)
function WinchAttachTreeActivatable.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = {}
	local v5 = v_u_1
	setmetatable(v4, v5)
	v4.vehicle = p2
	v4.texts = p2.spec_winch.texts
	v4.ropes = p2.spec_winch.ropes
	v4.rope = p3
	v4.activateText = ""
	return v4
end
function WinchAttachTreeActivatable.registerCustomInput(p6, _)
	local _, v7 = g_inputBinding:registerActionEvent(InputAction.WINCH_ATTACH_MODE, p6, p6.onToggleAttachTreeMode, false, true, false, true)
	p6.actionEventIdToggle = v7
	g_inputBinding:setActionEventTextPriority(p6.actionEventIdToggle, GS_PRIO_VERY_HIGH)
	local _, v8 = g_inputBinding:registerActionEvent(InputAction.WINCH_ATTACH, p6, p6.onAttachTree, false, true, false, true)
	p6.actionEventIdAttachTree = v8
	g_inputBinding:setActionEventTextPriority(p6.actionEventIdAttachTree, GS_PRIO_VERY_HIGH)
	g_inputBinding:setActionEventText(p6.actionEventIdAttachTree, p6.texts.attachTree)
	p6:update(9999)
end
function WinchAttachTreeActivatable.removeCustomInput(p9, _)
	g_inputBinding:removeActionEventsByTarget(p9)
end
function WinchAttachTreeActivatable.onToggleAttachTreeMode(p10)
	p10.vehicle:setWinchTreeAttachMode(p10.rope)
end
function WinchAttachTreeActivatable.onAttachTree(p11)
	if p11.vehicle:getCanAttachWinchTree(p11.rope) then
		p11.vehicle:onAttachTreeInputEvent(p11.rope)
	end
end
function WinchAttachTreeActivatable.update(p12, _)
	g_inputBinding:setActionEventText(p12.actionEventIdToggle, p12.vehicle:getIsWinchAttachModeActive(p12.rope) and p12.texts.stopAttachMode or p12.texts.startAttachMode)
	g_inputBinding:setActionEventActive(p12.actionEventIdAttachTree, p12.vehicle:getCanAttachWinchTree(p12.rope))
end
function WinchAttachTreeActivatable.getIsActivatable(p13)
	if p13.vehicle:getOwnerFarmId() ~= g_currentMission:getFarmId() then
		return false
	end
	if #p13.rope.attachedTrees >= p13.rope.maxNumTrees then
		return false
	end
	for v14 = 1, #p13.ropes do
		if p13.ropes[v14] ~= p13.rope and p13.ropes[v14].isAttachModeActive then
			return false
		end
	end
	return true
end
function WinchAttachTreeActivatable.activate(_) end
function WinchAttachTreeActivatable.deactivate(_) end
function WinchAttachTreeActivatable.getDistance(p15, p16, p17, p18)
	if p15.rope.isAttachModeActive then
		return 0
	end
	local v19, v20, v21 = getWorldTranslation(p15.rope.ropeNode)
	return MathUtil.vector3Length(p16 - v19, p17 - v20, p18 - v21)
end
function WinchAttachTreeActivatable.draw(_) end

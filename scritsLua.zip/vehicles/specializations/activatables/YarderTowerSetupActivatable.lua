YarderTowerSetupActivatable = {}
local v_u_1 = Class(YarderTowerSetupActivatable)
function YarderTowerSetupActivatable.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = {}
	local v4 = v_u_1
	setmetatable(v3, v4)
	v3.vehicle = p2
	v3.activateText = ""
	return v3
end
function YarderTowerSetupActivatable.registerCustomInput(p5, _)
	local _, v6 = g_inputBinding:registerActionEvent(InputAction.ACTIVATE_OBJECT, p5, p5.onToggleSetupMode, false, true, false, true)
	p5.actionEventIdToggle = v6
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdToggle, GS_PRIO_VERY_HIGH)
	local _, v7 = g_inputBinding:registerActionEvent(InputAction.YARDER_SETUP_ROPE, p5, p5.onSetTarget, false, true, false, true)
	p5.actionEventIdSetTarget = v7
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdSetTarget, GS_PRIO_VERY_HIGH)
	p5:updateActionEventTexts()
end
function YarderTowerSetupActivatable.removeCustomInput(p8, _)
	g_inputBinding:removeActionEventsByTarget(p8)
end
function YarderTowerSetupActivatable.onToggleSetupMode(p9)
	if p9.vehicle.spec_yarderTower.mainRope.isActive then
		p9.vehicle:setYarderTargetActive(false)
		return
	else
		local v10, v11 = p9.vehicle:getIsSetupModeChangeAllowed()
		if v10 then
			p9.vehicle:setYarderSetupModeState(nil, true)
		elseif v11 ~= nil then
			g_currentMission:showBlinkingWarning(v11, 2000)
		end
	end
end
function YarderTowerSetupActivatable.onSetTarget(p12)
	p12.vehicle:setYarderTargetActive(true)
end
function YarderTowerSetupActivatable.updateActionEventTexts(p13)
	local v14 = p13.vehicle.spec_yarderTower
	local v15
	if v14.setupModeState then
		v15 = v14.mainRope.isValid
		g_inputBinding:setActionEventText(p13.actionEventIdToggle, v14.texts.actionCancelSetup)
		g_inputBinding:setActionEventText(p13.actionEventIdSetTarget, v14.texts.actionSetTargetTree)
	else
		v15 = false
		if v14.mainRope.isActive then
			g_inputBinding:setActionEventText(p13.actionEventIdToggle, v14.texts.actionRemoveYarder)
		else
			g_inputBinding:setActionEventText(p13.actionEventIdToggle, v14.texts.actionStartSetup)
		end
	end
	g_inputBinding:setActionEventActive(p13.actionEventIdSetTarget, v15)
end
function YarderTowerSetupActivatable.getIsActivatable(p16)
	return p16.vehicle:getIsPlayerInYarderRange()
end
function YarderTowerSetupActivatable.activate(_) end
function YarderTowerSetupActivatable.deactivate(_) end
function YarderTowerSetupActivatable.getDistance(p17, p18, p19, p20)
	if p17.vehicle.spec_yarderTower.controlTriggerNode == nil then
		return (1 / 0)
	end
	local v21, v22, v23 = getWorldTranslation(p17.vehicle.spec_yarderTower.controlTriggerNode)
	return MathUtil.vector3Length(p18 - v21, p19 - v22, p20 - v23)
end
function YarderTowerSetupActivatable.draw(_) end

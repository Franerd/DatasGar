WinchControlRopeActivatable = {}
WinchControlRopeActivatable.SUB_ATTACH_ADDITIONAL_RANGE = 2
local v_u_1 = Class(WinchControlRopeActivatable)
function WinchControlRopeActivatable.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = {}
	local v5 = v_u_1
	setmetatable(v4, v5)
	v4.vehicle = p2
	v4.texts = p2.spec_winch.texts
	v4.ropes = p2.spec_winch.ropes
	v4.rope = p3
	v4.activateText = ""
	return v4
end
function WinchControlRopeActivatable.registerCustomInput(p6, _)
	local _, v7 = g_inputBinding:registerActionEvent(InputAction.WINCH_CONTROL, p6, p6.onControlWinch, false, true, true, true)
	p6.actionEventIdControl = v7
	g_inputBinding:setActionEventTextPriority(p6.actionEventIdControl, GS_PRIO_VERY_HIGH)
	g_inputBinding:setActionEventText(p6.actionEventIdControl, p6.texts.control)
	local _, v8 = g_inputBinding:registerActionEvent(InputAction.WINCH_DETACH, p6, p6.onDetachTree, false, true, false, true)
	p6.actionEventIdDetachTree = v8
	g_inputBinding:setActionEventTextPriority(p6.actionEventIdDetachTree, GS_PRIO_VERY_HIGH)
	g_inputBinding:setActionEventText(p6.actionEventIdDetachTree, p6.texts.detachTree)
	local _, v9 = g_inputBinding:registerActionEvent(InputAction.WINCH_ATTACH_MODE, p6, p6.onAttachMode, false, true, false, true)
	p6.actionEventIdAttachMode = v9
	g_inputBinding:setActionEventTextPriority(p6.actionEventIdAttachMode, GS_PRIO_VERY_HIGH)
	g_inputBinding:setActionEventText(p6.actionEventIdAttachMode, p6.texts.attachAnotherTree)
end
function WinchControlRopeActivatable.removeCustomInput(p10, _)
	g_inputBinding:removeActionEventsByTarget(p10)
end
function WinchControlRopeActivatable.onControlWinch(p11, _, p12, _, _)
	p11.vehicle:setWinchControlInput(p11.rope.index, p12)
end
function WinchControlRopeActivatable.onDetachTree(p13, _, _, _, _)
	p13.vehicle:detachTreeFromWinch(p13.rope.index)
end
function WinchControlRopeActivatable.onAttachMode(p14, _, _, _, _)
	if #p14.rope.attachedTrees < p14.rope.maxNumTrees then
		p14.vehicle:setWinchTreeAttachMode(p14.rope)
	else
		g_currentMission:showBlinkingWarning(p14.texts.warningMaxNumTreesReached, 2500)
	end
end
function WinchControlRopeActivatable.update(p15, _)
	if g_localPlayer ~= nil then
		local v16, _, v17 = getWorldTranslation(g_localPlayer.rootNode)
		local v18, _, v19 = getWorldTranslation(p15.rope.attachedTrees[1].activeHookData.hookId)
		local v20 = MathUtil.vector2Length(v16 - v18, v17 - v19)
		g_inputBinding:setActionEventActive(p15.actionEventIdAttachMode, v20 < p15.rope.maxSubLength + WinchControlRopeActivatable.SUB_ATTACH_ADDITIONAL_RANGE)
	end
end
function WinchControlRopeActivatable.getIsActivatable(p21)
	if p21.vehicle:getOwnerFarmId() ~= g_currentMission:getFarmId() then
		return false
	end
	for v22 = 1, #p21.ropes do
		if p21.rope ~= p21.ropes[v22] and p21.ropes[v22].isPlayerInRange then
			return false
		end
		if p21.ropes[v22].isAttachModeActive then
			return false
		end
	end
	local v23 = g_localPlayer
	return v23 ~= nil and (v23.currentHandtool == nil and (v23.isControlled and p21:getDistance(getWorldTranslation(v23.rootNode)) < Winch.CONTROL_RANGE)) and true or false
end
function WinchControlRopeActivatable.activate(_) end
function WinchControlRopeActivatable.deactivate(_) end
function WinchControlRopeActivatable.getDistance(p24, p25, _, p26)
	for v27 = 1, #p24.ropes do
		if p24.rope ~= p24.ropes[v27] and p24.ropes[v27].isPlayerInRange then
			return (1 / 0)
		end
		if p24.ropes[v27].isAttachModeActive then
			return (1 / 0)
		end
	end
	if #p24.rope.attachedTrees == 0 then
		return (1 / 0)
	end
	local v28, _, v29 = getWorldTranslation(p24.rope.ropeNode)
	local v30 = p24.rope.attachedTrees[1].activeHookData.hookId
	if not entityExists(v30) then
		return (1 / 0)
	end
	local v31, _, v32 = getWorldTranslation(v30)
	local v33, _, v34 = MathUtil.getClosestPointOnLineSegment(v28, 0, v29, v31, 0, v32, p25, 0, p26)
	return MathUtil.vector2Length(p25 - v33, p26 - v34)
end
function WinchControlRopeActivatable.draw(_) end

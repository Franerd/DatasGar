LivestockTrailerActivatable = {}
local v_u_1 = Class(LivestockTrailerActivatable)
function LivestockTrailerActivatable.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1
	local v4 = setmetatable({}, v3)
	v4.livestockTrailer = p2
	v4.activateText = g_i18n:getText("action_openLivestockTrailerMenu")
	return v4
end
function LivestockTrailerActivatable.getIsActivatable(p5)
	if p5.livestockTrailer:getLoadingTrigger() ~= nil then
		return false
	end
	local v6 = p5.livestockTrailer:getRideablesInTrigger()
	if #v6 > 0 or p5.livestockTrailer:getNumOfAnimals() > 0 then
		if p5.livestockTrailer:getIsActiveForInput(true) then
			return true
		end
		for _, v7 in ipairs(v6) do
			if v7:getIsActiveForInput(true) then
				return true
			end
		end
	end
	return false
end
function LivestockTrailerActivatable.run(p8)
	g_animalScreen:setController(nil, p8.livestockTrailer, false)
	g_gui:showGui("AnimalScreen")
end

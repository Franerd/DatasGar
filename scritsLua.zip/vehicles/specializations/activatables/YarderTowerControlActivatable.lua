YarderTowerControlActivatable = {}
local v_u_1 = Class(YarderTowerControlActivatable)
function YarderTowerControlActivatable.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = {}
	local v4 = v_u_1
	setmetatable(v3, v4)
	v3.vehicle = p2
	v3.activateText = ""
	return v3
end
function YarderTowerControlActivatable.registerCustomInput(p5, _)
	local _, v6 = g_inputBinding:registerActionEvent(InputAction.YARDER_FOLLOW_ME, p5, p5.onToggleFollowMeMode, false, true, false, true)
	p5.actionEventIdFollowMe = v6
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdFollowMe, GS_PRIO_VERY_HIGH)
	local _, v7 = g_inputBinding:registerActionEvent(InputAction.YARDER_FOLLOW_HOME, p5, p5.onToggleFollowHome, false, true, false, true)
	p5.actionEventIdFollowHome = v7
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdFollowHome, GS_PRIO_VERY_HIGH)
	local _, v8 = g_inputBinding:registerActionEvent(InputAction.YARDER_FOLLOW_PICKUP, p5, p5.onToggleFollowPickup, false, true, false, true)
	p5.actionEventIdFollowPickup = v8
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdFollowPickup, GS_PRIO_VERY_HIGH)
	local _, v9 = g_inputBinding:registerActionEvent(InputAction.YARDER_CONTROL_LEFTRIGHT, p5, p5.onManualControlLeftRight, false, false, true, true)
	p5.actionEventIdManualControl = v9
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdManualControl, GS_PRIO_VERY_HIGH)
	g_inputBinding:setActionEventText(p5.actionEventIdManualControl, p5.vehicle.spec_yarderTower.texts.actionCarriageManualControl)
	local _, v10 = g_inputBinding:registerActionEvent(InputAction.YARDER_CONTROL_UPDOWN, p5, p5.onManualControlUpDown, false, false, true, true)
	p5.actionEventIdLiftLower = v10
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdLiftLower, GS_PRIO_VERY_HIGH)
	g_inputBinding:setActionEventText(p5.actionEventIdLiftLower, p5.vehicle.spec_yarderTower.texts.actionCarriageLiftLower)
	local _, v11 = g_inputBinding:registerActionEvent(InputAction.YARDER_ATTACH, p5, p5.onTreeAttach, false, true, false, true)
	p5.actionEventIdAttach = v11
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdAttach, GS_PRIO_VERY_HIGH)
	g_inputBinding:setActionEventText(p5.actionEventIdAttach, p5.vehicle.spec_yarderTower.texts.actionCarriageAttachTree)
	local _, v12 = g_inputBinding:registerActionEvent(InputAction.YARDER_DETACH, p5, p5.onTreeDetach, false, true, false, true)
	p5.actionEventIdDetach = v12
	g_inputBinding:setActionEventTextPriority(p5.actionEventIdDetach, GS_PRIO_VERY_HIGH)
	g_inputBinding:setActionEventText(p5.actionEventIdDetach, p5.vehicle.spec_yarderTower.texts.actionCarriageDetachTree)
	p5:updateActionEventTexts()
end
function YarderTowerControlActivatable.removeCustomInput(p13, _)
	g_inputBinding:removeActionEventsByTarget(p13)
end
function YarderTowerControlActivatable.onToggleFollowMeMode(p14)
	if p14.vehicle.spec_yarderTower.carriage.followModeState == YarderTower.FOLLOW_MODE_ME then
		p14.vehicle:setYarderCarriageFollowMode(YarderTower.FOLLOW_MODE_NONE)
	else
		p14.vehicle:setYarderCarriageFollowMode(YarderTower.FOLLOW_MODE_ME)
	end
end
function YarderTowerControlActivatable.onToggleFollowHome(p15)
	p15.vehicle:setYarderCarriageFollowMode(YarderTower.FOLLOW_MODE_HOME)
end
function YarderTowerControlActivatable.onToggleFollowPickup(p16)
	p16.vehicle:setYarderCarriageFollowMode(YarderTower.FOLLOW_MODE_PICKUP)
end
function YarderTowerControlActivatable.onManualControlLeftRight(p17, _, p18, _, _, _)
	p17.vehicle:setYarderCarriageMoveInput(p18)
end
function YarderTowerControlActivatable.onManualControlUpDown(p19, _, p20, _, _, _)
	p19.vehicle:setYarderCarriageLiftInput(p20)
end
function YarderTowerControlActivatable.onTreeAttach(p21, _, _, _, _, _)
	p21.vehicle:onYarderCarriageAttach()
end
function YarderTowerControlActivatable.onTreeDetach(p22, _, p23, _, _, _)
	p22.vehicle:onYarderCarriageDetach(p23)
end
function YarderTowerControlActivatable.update(p24, _)
	local v25 = p24.vehicle.spec_yarderTower.carriage.vehicle
	if v25 ~= nil then
		g_inputBinding:setActionEventActive(p24.actionEventIdAttach, v25:getIsTreeInMountRange())
		local v26 = v25:getNumAttachedTrees() > 0
		g_inputBinding:setActionEventActive(p24.actionEventIdDetach, v26)
		g_inputBinding:setActionEventActive(p24.actionEventIdLiftLower, v26)
	end
end
function YarderTowerControlActivatable.updateActionEventTexts(p27)
	local v28 = p27.vehicle.spec_yarderTower
	local v29 = p27.vehicle:getYarderMainRopeLength()
	g_inputBinding:setActionEventText(p27.actionEventIdFollowMe, v28.carriage.followModeState == YarderTower.FOLLOW_MODE_ME and v28.texts.actionCarriageFollowModeDisable or v28.texts.actionCarriageFollowModeEnable)
	if v28.carriage.followModeState == YarderTower.FOLLOW_MODE_NONE then
		g_inputBinding:setActionEventActive(p27.actionEventIdFollowHome, v28.carriage.lastPosition * v29 > 5)
		if v28.carriage.followModePickupPosition == 0 then
			g_inputBinding:setActionEventActive(p27.actionEventIdFollowPickup, false)
		else
			local v30 = v28.carriage.lastPosition - v28.carriage.followModePickupPosition
			local v31 = math.abs(v30) * v29
			g_inputBinding:setActionEventActive(p27.actionEventIdFollowPickup, v31 > 5)
		end
	else
		g_inputBinding:setActionEventActive(p27.actionEventIdFollowHome, false)
		g_inputBinding:setActionEventActive(p27.actionEventIdFollowPickup, false)
		return
	end
end
function YarderTowerControlActivatable.getIsActivatable(p32)
	local v33, _ = p32.vehicle:getIsPlayerInYarderControlRange()
	return v33
end
function YarderTowerControlActivatable.activate(_) end
function YarderTowerControlActivatable.deactivate(_) end
function YarderTowerControlActivatable.getDistance(p34, _, _, _)
	local _, v35 = p34.vehicle:getIsPlayerInYarderControlRange()
	return v35
end
function YarderTowerControlActivatable.draw(_) end

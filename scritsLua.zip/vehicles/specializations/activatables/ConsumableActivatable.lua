ConsumableActivatable = {}
ConsumableActivatable.TYPE_TEXTS = {}
ConsumableActivatable.TYPE_TEXTS.BALE_WRAP = "action_refillBaleWrap"
ConsumableActivatable.TYPE_TEXTS.BALE_NET = "action_refillBaleNet"
ConsumableActivatable.TYPE_TEXTS.BALE_TWINE = "action_refillBaleTwine"
ConsumableActivatable.TYPE_TEXTS.RICE_SAPLINGS = "action_refillBaleTwine"
local v_u_1 = Class(ConsumableActivatable)
function ConsumableActivatable.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1
	local v4 = setmetatable({}, v3)
	v4.vehicle = p2
	v4.activateText = ""
	return v4
end
function ConsumableActivatable.getIsActivatable(p5)
	if p5.vehicle:getIsActiveForInput(true) then
		local v6 = p5.vehicle.spec_consumable
		for _, v7 in ipairs(v6.types) do
			if v7.consumingFillLevel == 0 then
				return true
			end
		end
	end
	return false
end
function ConsumableActivatable.run(p_u_8)
	local v9 = p_u_8.vehicle.spec_consumable
	for v_u_10, v11 in ipairs(v9.types) do
		if v11.consumingFillLevel == 0 then
			p_u_8.optionsTypeName = v11.typeName
			local v12, v13 = g_consumableManager:getConsumableVariationsByType(v11.typeName)
			p_u_8.options = v12
			p_u_8.optionToVariationIndex = v13
			OptionDialog.show(function(p14)
				-- upvalues: (copy) p_u_8, (copy) v_u_10
				if p14 ~= nil then
					local v15 = p_u_8.optionToVariationIndex[p14]
					if v15 ~= nil then
						ConsumableRefillEvent.sendEvent(p_u_8.vehicle, v_u_10, v15)
					end
				end
			end, g_i18n:getText("ui_consumableSelectType"), g_i18n:getText(ConsumableActivatable.TYPE_TEXTS[v11.typeName]), p_u_8.options)
		end
	end
end
function ConsumableActivatable.updateActivateText(p16)
	local v17 = p16.vehicle.spec_consumable
	for _, v18 in ipairs(v17.types) do
		if v18.consumingFillLevel == 0 then
			p16.activateText = g_i18n:getText(ConsumableActivatable.TYPE_TEXTS[v18.typeName])
		end
	end
end

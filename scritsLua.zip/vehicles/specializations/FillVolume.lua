FillVolume = {}
FillVolume.SEND_NUM_BITS = 6
FillVolume.SEND_MAX_SIZE = 15
local v1 = FillVolume
local v2 = FillVolume.SEND_NUM_BITS
v1.SEND_MAX_VALUE = math.pow(2, v2) - 1
FillVolume.SEND_PRECISION = FillVolume.SEND_MAX_SIZE / FillVolume.SEND_MAX_VALUE
function FillVolume.writeStreamCompressedPosition(p3, p4)
	local v5 = (p4 + FillVolume.SEND_MAX_SIZE * 0.5) / FillVolume.SEND_MAX_SIZE
	local v6 = math.clamp(v5, 0, 1) * FillVolume.SEND_MAX_VALUE
	streamWriteUIntN(p3, v6, FillVolume.SEND_NUM_BITS)
end
function FillVolume.readStreamCompressedPosition(p7)
	return streamReadUIntN(p7, FillVolume.SEND_NUM_BITS) / FillVolume.SEND_MAX_VALUE * FillVolume.SEND_MAX_SIZE - FillVolume.SEND_MAX_SIZE * 0.5
end
function FillVolume.prerequisitesPresent(p8)
	return SpecializationUtil.hasSpecialization(FillUnit, p8)
end
function FillVolume.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("fillVolume", g_i18n:getText("configuration_fillVolume"), "fillVolume", VehicleConfigurationItem)
	local v9 = Vehicle.xmlSchema
	v9:setXMLSpecializationType("FillVolume")
	v9:register(XMLValueType.NODE_INDEX, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#node", "Fill volume node")
	v9:register(XMLValueType.INT, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#fillUnitIndex", "Fill unit index")
	v9:register(XMLValueType.FLOAT, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#fillUnitFactor", "Fill unit factor", 1)
	v9:register(XMLValueType.BOOL, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#useFullCapacity", "Defines if the fill volume represents the full fill unit capacity when multiple fill volumes are given. If set to \'false\' (default), the fill level is split across the defined volumes. If set to \'true\' all fill up the same.", true)
	v9:register(XMLValueType.BOOL, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#allSidePlanes", "All side planes", true)
	v9:register(XMLValueType.BOOL, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#retessellateTop", "Retessellate top plane for better triangulation quality", false)
	v9:register(XMLValueType.STRING, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#defaultFillType", "Default fill type name")
	v9:register(XMLValueType.STRING, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#forcedVolumeFillType", "Forced fill type name")
	v9:register(XMLValueType.FLOAT, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#maxDelta", "Max. heap size above above input surface [m]", 1)
	v9:register(XMLValueType.ANGLE, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#maxAllowedHeapAngle", "Max. allowed heap surface slope angle [deg]", 35)
	v9:register(XMLValueType.FLOAT, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#maxSurfaceDistanceError", "Max. allowed distance from input mesh surface to created fill plane mesh [m]", 0.05)
	v9:register(XMLValueType.FLOAT, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#maxSubDivEdgeLength", "Max. length of sub division edges [m]", 0.9)
	v9:register(XMLValueType.FLOAT, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?)#syncMaxSubDivEdgeLength", "Max. length of sub division edges used to sync in multiplayer [m]", 1.35)
	v9:register(XMLValueType.NODE_INDEX, "vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(?).volumes.volume(?).deformNode(?)#node", "Deformer node")
	FillVolume.registerInfoNodeXMLPaths(v9, "vehicle.fillVolume.loadInfos.loadInfo(?)")
	FillVolume.registerInfoNodeXMLPaths(v9, "vehicle.fillVolume.unloadInfos.unloadInfo(?)")
	v9:register(XMLValueType.INT, "vehicle.fillVolume.heightNodes.heightNode(?)#fillVolumeIndex", "Fill volume index")
	v9:register(XMLValueType.NODE_INDEX, "vehicle.fillVolume.heightNodes.heightNode(?).refNode(?)#node", "Reference node")
	v9:register(XMLValueType.NODE_INDEX, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#node", "Height node")
	v9:register(XMLValueType.VECTOR_SCALE, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#baseScale", "Base scale", "1 1 1")
	v9:register(XMLValueType.VECTOR_3, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#scaleAxis", "Scale axis", "0 0 0")
	v9:register(XMLValueType.VECTOR_SCALE, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#scaleMax", "Max. scale", "0 0 0")
	v9:register(XMLValueType.VECTOR_3, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#transAxis", "Translation axis", "0 0 0")
	v9:register(XMLValueType.VECTOR_TRANS, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#transMax", "Max. translation", "0 0 0")
	v9:register(XMLValueType.FLOAT, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#minHeight", "Min. fill volume height used for height node", 0)
	v9:register(XMLValueType.FLOAT, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#heightOffset", "Fill plane height offset", 0)
	v9:register(XMLValueType.BOOL, "vehicle.fillVolume.heightNodes.heightNode(?).node(?)#orientateToWorldY", "Orientate to world Y", false)
	v9:addDelayedRegistrationFunc("Cylindered:movingTool", function(p10, p11)
		p10:register(XMLValueType.INT, p11 .. ".fillVolume#fillVolumeIndex", "Fill Unit index which includes the deformers", 1)
		p10:register(XMLValueType.VECTOR_N, p11 .. ".fillVolume#deformerNodeIndices", "Indices of deformer nodes to update")
	end)
	v9:addDelayedRegistrationFunc("Cylindered:movingPart", function(p12, p13)
		p12:register(XMLValueType.INT, p13 .. ".fillVolume#fillVolumeIndex", "Fill Unit index which includes the deformers", 1)
		p12:register(XMLValueType.VECTOR_N, p13 .. ".fillVolume#deformerNodeIndices", "Indices of deformer nodes to update")
	end)
	v9:setXMLSpecializationType()
end
function FillVolume.registerInfoNodeXMLPaths(p14, p15)
	p14:register(XMLValueType.NODE_INDEX, p15 .. ".node(?)#node", "Info node")
	p14:register(XMLValueType.FLOAT, p15 .. ".node(?)#width", "Info width", 1)
	p14:register(XMLValueType.FLOAT, p15 .. ".node(?)#length", "Info length", 1)
	p14:register(XMLValueType.INT, p15 .. ".node(?)#fillVolumeHeightIndex", "Fill volume height index")
	p14:register(XMLValueType.INT, p15 .. ".node(?)#priority", "Priority", 1)
	p14:register(XMLValueType.FLOAT, p15 .. ".node(?)#minHeight", "Min. height")
	p14:register(XMLValueType.FLOAT, p15 .. ".node(?)#maxHeight", "Max. height")
	p14:register(XMLValueType.FLOAT, p15 .. ".node(?)#minFillLevelPercentage", "Min. fill level percentage")
	p14:register(XMLValueType.FLOAT, p15 .. ".node(?)#maxFillLevelPercentage", "Min. fill level percentage")
	p14:register(XMLValueType.FLOAT, p15 .. ".node(?)#heightForTranslation", "Min. height for translation")
	p14:register(XMLValueType.VECTOR_TRANS, p15 .. ".node(?)#translationStart", "Translation start")
	p14:register(XMLValueType.VECTOR_TRANS, p15 .. ".node(?)#translationEnd", "Translation end")
end
function FillVolume.registerFunctions(p16)
	SpecializationUtil.registerFunction(p16, "loadFillVolume", FillVolume.loadFillVolume)
	SpecializationUtil.registerFunction(p16, "loadFillVolumeInfo", FillVolume.loadFillVolumeInfo)
	SpecializationUtil.registerFunction(p16, "loadFillVolumeHeightNode", FillVolume.loadFillVolumeHeightNode)
	SpecializationUtil.registerFunction(p16, "getFillVolumeLoadInfo", FillVolume.getFillVolumeLoadInfo)
	SpecializationUtil.registerFunction(p16, "getFillVolumeUnloadInfo", FillVolume.getFillVolumeUnloadInfo)
	SpecializationUtil.registerFunction(p16, "getFillVolumeIndicesByFillUnitIndex", FillVolume.getFillVolumeIndicesByFillUnitIndex)
	SpecializationUtil.registerFunction(p16, "setFillVolumeForcedFillTypeByFillUnitIndex", FillVolume.setFillVolumeForcedFillTypeByFillUnitIndex)
	SpecializationUtil.registerFunction(p16, "setFillVolumeForcedFillType", FillVolume.setFillVolumeForcedFillType)
	SpecializationUtil.registerFunction(p16, "getFillVolumeUVScrollSpeed", FillVolume.getFillVolumeUVScrollSpeed)
end
function FillVolume.registerOverwrittenFunctions(p17)
	SpecializationUtil.registerOverwrittenFunction(p17, "setMovingToolDirty", FillVolume.setMovingToolDirty)
	SpecializationUtil.registerOverwrittenFunction(p17, "loadExtraDependentParts", FillVolume.loadExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p17, "updateExtraDependentParts", FillVolume.updateExtraDependentParts)
end
function FillVolume.registerEventListeners(p18)
	SpecializationUtil.registerEventListener(p18, "onLoad", FillVolume)
	SpecializationUtil.registerEventListener(p18, "onDelete", FillVolume)
	SpecializationUtil.registerEventListener(p18, "onReadUpdateStream", FillVolume)
	SpecializationUtil.registerEventListener(p18, "onWriteUpdateStream", FillVolume)
	SpecializationUtil.registerEventListener(p18, "onUpdate", FillVolume)
	SpecializationUtil.registerEventListener(p18, "onFillUnitFillLevelChanged", FillVolume)
end
function FillVolume.onLoad(p_u_19, _)
	local v_u_20 = p_u_19.spec_fillVolume
	local v21 = Utils.getNoNil(p_u_19.configurations.fillVolume, 1)
	local v22 = string.format("vehicle.fillVolume.fillVolumeConfigurations.fillVolumeConfiguration(%d).volumes", v21 - 1)
	v_u_20.volumes = {}
	v_u_20.fillVolumeDeformersByNode = {}
	v_u_20.fillUnitFillVolumeMapping = {}
	p_u_19.xmlFile:iterate(v22 .. ".volume", function(_, p23)
		-- upvalues: (copy) p_u_19, (copy) v_u_20
		local v24 = {}
		if p_u_19:loadFillVolume(p_u_19.xmlFile, p23, v24) then
			local v25 = v_u_20.volumes
			table.insert(v25, v24)
			v24.index = #v_u_20.volumes
		end
	end)
	for _, v26 in ipairs(v_u_20.fillUnitFillVolumeMapping) do
		for _, v27 in ipairs(v26.fillVolumes) do
			if not v27.useFullCapacity then
				v27.fillUnitFactor = v27.fillUnitFactor / v26.sumFactors
			end
		end
	end
	for _, v28 in ipairs(v_u_20.volumes) do
		v28.capacity = p_u_19:getFillUnitCapacity(v28.fillUnitIndex) * v28.fillUnitFactor
		v28.fillLevel = 0
		v28.volume = createFillPlaneShape(v28.baseNode, "fillPlane", v28.capacity, v28.maxDelta, v28.maxSurfaceAngle, v28.maxPhysicalSurfaceAngle, v28.maxSurfaceDistanceError, v28.maxSubDivEdgeLength, v28.syncMaxSubDivEdgeLength, v28.allSidePlanes, v28.retessellateTop)
		if v28.volume == nil or v28.volume == 0 then
			local v29 = printWarning
			local v30 = getName
			local v31 = v28.baseNode
			v29("Warning: fillVolume \'" .. tostring(v30(v31)) .. "\' could not create actual fillVolume in \'" .. p_u_19.configFileName .. "\'! Simplifying the mesh could help")
			v28.volume = nil
		else
			setVisibility(v28.volume, false)
			for v32 = #v28.deformers, 1, -1 do
				local v33 = v28.deformers[v32]
				v33.polyline = findPolyline(v28.volume, v33.posX, v33.posZ)
				if v33.polyline == nil and v33.polyline ~= -1 then
					local v34 = printWarning
					local v35 = getName
					local v36 = v33.node
					v34("Warning: Could not find \'polyline\' for \'" .. tostring(v35(v36)) .. "\' in \'" .. p_u_19.configFileName .. "\'")
					table.remove(v28.deformers, v32)
				end
			end
			link(v28.baseNode, v28.volume)
			local v37 = g_materialManager:getBaseMaterialByName("fillPlane")
			if v37 == nil then
				Logging.error("Failed to assign material to fill volume. Base Material \'fillPlane\' not found!")
			else
				setMaterial(v28.volume, v37, 0)
				g_fillTypeManager:assignFillTypeTextureArraysFromTerrain(v28.volume, g_terrainNode, true, true, true)
			end
			fillPlaneAdd(v28.volume, 1, 0, 1, 0, 11, 0, 0, 0, 0, 11)
			v28.heightOffset = getFillPlaneHeightAtLocalPos(v28.volume, 0, 0)
			fillPlaneAdd(v28.volume, -1, 0, 1, 0, 11, 0, 0, 0, 0, 11)
		end
	end
	v_u_20.loadInfos = {}
	p_u_19.xmlFile:iterate("vehicle.fillVolume.loadInfos.loadInfo", function(_, p38)
		-- upvalues: (copy) p_u_19, (copy) v_u_20
		local v39 = {}
		if p_u_19:loadFillVolumeInfo(p_u_19.xmlFile, p38, v39) then
			local v40 = v_u_20.loadInfos
			table.insert(v40, v39)
		end
	end)
	v_u_20.unloadInfos = {}
	p_u_19.xmlFile:iterate("vehicle.fillVolume.unloadInfos.unloadInfo", function(_, p41)
		-- upvalues: (copy) p_u_19, (copy) v_u_20
		local v42 = {}
		if p_u_19:loadFillVolumeInfo(p_u_19.xmlFile, p41, v42) then
			local v43 = v_u_20.unloadInfos
			table.insert(v43, v42)
		end
	end)
	v_u_20.heightNodes = {}
	v_u_20.fillVolumeIndexToHeightNode = {}
	p_u_19.xmlFile:iterate("vehicle.fillVolume.heightNodes.heightNode", function(_, p44)
		-- upvalues: (copy) p_u_19, (copy) v_u_20
		local v45 = {}
		if p_u_19:loadFillVolumeHeightNode(p_u_19.xmlFile, p44, v45) then
			local v46 = v_u_20.heightNodes
			table.insert(v46, v45)
			if v_u_20.fillVolumeIndexToHeightNode[v45.fillVolumeIndex] == nil then
				v_u_20.fillVolumeIndexToHeightNode[v45.fillVolumeIndex] = {}
			end
			local v47 = v_u_20.fillVolumeIndexToHeightNode[v45.fillVolumeIndex]
			table.insert(v47, v45)
		end
	end)
	v_u_20.lastPositionInfo = { 0, 0 }
	v_u_20.lastPositionInfoSent = { 0, 0 }
	v_u_20.availableFillNodes = {}
	v_u_20.dirtyFlag = p_u_19:getNextDirtyFlag()
	if not p_u_19.isClient or #v_u_20.volumes == 0 and #v_u_20.heightNodes == 0 then
		SpecializationUtil.removeEventListener(p_u_19, "onUpdate", FillVolume)
	end
end
function FillVolume.onDelete(p48)
	local v49 = p48.spec_fillVolume
	if v49.volumes ~= nil then
		for _, v50 in ipairs(v49.volumes) do
			if v50.volume ~= nil then
				delete(v50.volume)
			end
			v50.volume = nil
		end
	end
end
function FillVolume.onReadUpdateStream(p51, p52, _, p53)
	if p53:getIsServer() then
		local v54 = p51.spec_fillVolume
		if streamReadBool(p52) then
			v54.lastPositionInfo[1] = FillVolume.readStreamCompressedPosition(p52)
			v54.lastPositionInfo[2] = FillVolume.readStreamCompressedPosition(p52)
		end
	end
end
function FillVolume.onWriteUpdateStream(p55, p56, p57, p58)
	if not p57:getIsServer() then
		local v59 = p55.spec_fillVolume
		if streamWriteBool(p56, bitAND(p58, v59.dirtyFlag) ~= 0) then
			FillVolume.writeStreamCompressedPosition(p56, v59.lastPositionInfoSent[1])
			FillVolume.writeStreamCompressedPosition(p56, v59.lastPositionInfoSent[2])
		end
	end
end
function FillVolume.onUpdate(p60, p61, _, _, _)
	if not p60.isClient then
		::l2::
		return
	end
	local v62 = p60.spec_fillVolume
	for _, v63 in pairs(v62.volumes) do
		for _, v64 in ipairs(v63.deformers) do
			if v64.isDirty and (v64.polyline ~= nil and v64.polyline ~= -1) then
				v64.isDirty = false
				local v65, _, v66 = localToLocal(v64.node, v64.baseNode, 0, 0, 0)
				local v67 = v65 - v64.posX
				if math.abs(v67) > 0.0001 then
					::l11::
					v64.lastPosX = v65
					v64.lastPosZ = v66
					local v68 = v65 - v64.initPos[1]
					local v69 = v66 - v64.initPos[3]
					setPolylineTranslation(v63.volume, v64.polyline, v68, v69)
				else
					local v70 = v66 - v64.posZ
					if math.abs(v70) > 0.0001 then
						goto l11
					end
				end
			end
		end
		local v71, v72, v73 = p60:getFillVolumeUVScrollSpeed(v63.index)
		if v71 ~= 0 or (v72 ~= 0 or v73 ~= 0) then
			v63.uvPosition[1] = v63.uvPosition[1] + v71 * (p61 / 1000)
			v63.uvPosition[2] = v63.uvPosition[2] + v72 * (p61 / 1000)
			v63.uvPosition[3] = v63.uvPosition[3] + v73 * (p61 / 1000)
			setShaderParameter(v63.volume, "uvOffset", v63.uvPosition[1], v63.uvPosition[2], v63.uvPosition[3], 0, false)
		end
	end
	for _, v74 in pairs(v62.heightNodes) do
		if v74.isDirty then
			v74.isDirty = false
			local v75 = v62.volumes[v74.fillVolumeIndex]
			local v76 = v75.baseNode
			local v77 = v75.volume
			if v76 ~= nil and v77 ~= nil then
				local v78 = (1 / 0)
				local v79 = (-1 / 0)
				local v80 = (-1 / 0)
				for _, v81 in pairs(v74.refNodes) do
					local v82, _, v83 = localToLocal(v81.refNode, v76, 0, 0, 0)
					local v84 = getFillPlaneHeightAtLocalPos(v77, v82, v83)
					if not MathUtil.isNan(v84) then
						local v85 = v84 - v75.heightOffset
						v78 = math.min(v78, v85)
						v79 = math.max(v79, v85)
						local _, v86, _ = localToWorld(v76, v82, v85, v83)
						v80 = math.max(v80, v86)
						if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
							local v87, v88, v89 = localToWorld(v76, v82, v75.heightOffset, v83)
							local v90, v91, v92 = localToWorld(v76, v82, v85, v83)
							drawDebugLine(v87, v88, v89, 0, 1, 0, v90, v91, v92, 0, 1, 0, false)
							Utils.renderTextAtWorldPosition(v90, v91, v92, string.format("Height: %.2fm", v85), 0.01)
						end
					end
				end
				v74.currentMinHeight = v78
				v74.currentMaxHeight = v79
				v74.currentMaxHeightWorld = v80
				for _, v93 in pairs(v74.nodes) do
					local v94 = v78 + v93.heightOffset
					local v95 = v93.minHeight
					local v96 = math.max(v94, v95)
					local v97 = v93.scaleAxis[1] * v96
					local v98 = v93.scaleAxis[2] * v96
					local v99 = v93.scaleAxis[3] * v96
					if v93.scaleMax[1] > 0 then
						local v100 = v93.scaleMax[1]
						v97 = math.min(v100, v97)
					end
					if v93.scaleMax[2] > 0 then
						local v101 = v93.scaleMax[2]
						v98 = math.min(v101, v98)
					end
					if v93.scaleMax[3] > 0 then
						local v102 = v93.scaleMax[3]
						v99 = math.min(v102, v99)
					end
					local v103 = v93.transAxis[1] * v96
					local v104 = v93.transAxis[2] * v96
					local v105 = v93.transAxis[3] * v96
					if v93.transMax[1] > 0 then
						local v106 = v93.transMax[1]
						v103 = math.min(v106, v103)
					end
					if v93.transMax[2] > 0 then
						local v107 = v93.transMax[2]
						v104 = math.min(v107, v104)
					end
					if v93.transMax[3] > 0 then
						local v108 = v93.transMax[3]
						v105 = math.min(v108, v105)
					end
					setScale(v93.node, v93.baseScale[1] + v97, v93.baseScale[2] + v98, v93.baseScale[3] + v99)
					setTranslation(v93.node, v93.basePosition[1] + v103, v93.basePosition[2] + v104, v93.basePosition[3] + v105)
					if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES and getEffectiveVisibility(v93.node) then
						renderShapeOutline(v93.node, false)
						if v98 ~= 0 then
							setScale(v93.node, 1, 1, 1)
							local v109, v110, v111 = localToWorld(v93.node, 0, 0, 0)
							local v112, v113, v114 = localToWorld(v93.node, 0, v93.baseScale[2] + v98, 0)
							drawDebugLine(v109, v110, v111, 0, 1, 0, v112, v113, v114, 0, 1, 0, false)
							Utils.renderTextAtWorldPosition(v112, v113, v114, string.format("%s scaleY: %.2f", getName(v93.node), v93.baseScale[2] + v98), 0.01)
							setScale(v93.node, v93.baseScale[1] + v97, v93.baseScale[2] + v98, v93.baseScale[3] + v99)
						end
						if v104 ~= 0 then
							local v115, v116, v117 = localToWorld(getParent(v93.node), v93.basePosition[1] + v103, v93.basePosition[2], v93.basePosition[3] + v105)
							local v118, v119, v120 = localToWorld(getParent(v93.node), v93.basePosition[1] + v103, v93.basePosition[2] + v104, v93.basePosition[3] + v105)
							drawDebugLine(v115, v116, v117, 0, 1, 0, v118, v119, v120, 0, 1, 0, false)
							Utils.renderTextAtWorldPosition(v118, v119, v120, string.format("%s transY: %.2f", getName(v93.node), v93.basePosition[2] + v104), 0.01)
						end
					end
					if v93.orientateToWorldY then
						local _, v121, _ = localDirectionToWorld(getParent(v93.node), 0, 1, 0)
						local v122 = math.clamp(v121, -1, 1)
						local v123 = math.acos(v122)
						setRotation(v93.node, v123, 0, 0)
					end
				end
			end
		end
	end
	goto l2
end
function FillVolume.loadFillVolume(p124, p125, p126, p127)
	local v128 = p124.spec_fillVolume
	XMLUtil.checkDeprecatedXMLElements(p125, p126 .. "#index", p126 .. "#node")
	p127.baseNode = p125:getValue(p126 .. "#node", nil, p124.components, p124.i3dMappings)
	if p127.baseNode == nil then
		printWarning("Warning: fillVolume \'" .. tostring(p126) .. "\' has an invalid \'node\' in \'" .. p124.configFileName .. "\'!")
		return false
	end
	local v129 = p125:getValue(p126 .. "#fillUnitIndex")
	p127.fillUnitIndex = v129
	if v129 == nil then
		printWarning("Warning: fillVolume \'" .. tostring(p126) .. "\' has no \'fillUnitIndex\' given in \'" .. p124.configFileName .. "\'!")
		return false
	end
	if not p124:getFillUnitExists(v129) then
		printWarning("Warning: fillVolume \'" .. tostring(p126) .. "\' has an invalid \'fillUnitIndex\' in \'" .. p124.configFileName .. "\'!")
		return false
	end
	p127.fillUnitFactor = p125:getValue(p126 .. "#fillUnitFactor", 1)
	p127.useFullCapacity = p125:getValue(p126 .. "#useFullCapacity", true)
	if v128.fillUnitFillVolumeMapping[v129] == nil then
		v128.fillUnitFillVolumeMapping[v129] = {
			["fillVolumes"] = {},
			["sumFactors"] = 0
		}
	end
	local v130 = v128.fillUnitFillVolumeMapping[v129].fillVolumes
	table.insert(v130, p127)
	v128.fillUnitFillVolumeMapping[v129].sumFactors = v128.fillUnitFillVolumeMapping[v129].sumFactors + p127.fillUnitFactor
	p127.allSidePlanes = p125:getValue(p126 .. "#allSidePlanes", true)
	p127.retessellateTop = p125:getValue(p126 .. "#retessellateTop", false)
	local v131 = p125:getValue(p126 .. "#defaultFillType")
	if v131 == nil then
		p127.defaultFillType = p124:getFillUnitFirstSupportedFillType(v129)
	else
		local v132 = g_fillTypeManager:getFillTypeIndexByName(v131)
		if v132 == nil then
			printWarning("Warning: Invalid defaultFillType \'" .. tostring(v131) .. "\' for \'" .. tostring(p126) .. "\' in \'" .. p124.configFileName .. "\'")
			return false
		end
		p127.defaultFillType = v132
	end
	local v133 = p125:getValue(p126 .. "#forcedVolumeFillType")
	if v133 ~= nil then
		local v134 = g_fillTypeManager:getFillTypeIndexByName(v133)
		if v134 == nil then
			printWarning("Warning: Invalid forcedVolumeFillType \'" .. tostring(v133) .. "\' for \'" .. tostring(p126) .. "\' in \'" .. p124.configFileName .. "\'")
			return false
		end
		p127.forcedVolumeFillType = v134
	end
	p127.maxDelta = p125:getValue(p126 .. "#maxDelta", 1)
	p127.maxSurfaceAngle = p125:getValue(p126 .. "#maxAllowedHeapAngle", 35)
	p127.maxPhysicalSurfaceAngle = 0.6108652381980153
	p127.maxSurfaceDistanceError = p125:getValue(p126 .. "#maxSurfaceDistanceError", 0.05)
	p127.maxSubDivEdgeLength = p125:getValue(p126 .. "#maxSubDivEdgeLength", 0.9)
	p127.syncMaxSubDivEdgeLength = p125:getValue(p126 .. "#syncMaxSubDivEdgeLength", 1.35)
	p127.uvPosition = { 0, 0, 0 }
	p127.deformers = {}
	local v135 = 0
	while true do
		local v136 = string.format("%s.deformNode(%d)", p126, v135)
		if not p125:hasProperty(v136) then
			break
		end
		XMLUtil.checkDeprecatedXMLElements(p125, v136 .. "#index", v136 .. "#node")
		local v137 = p125:getValue(v136 .. "#node", nil, p124.components, p124.i3dMappings)
		if v137 ~= nil then
			local v138 = { localToLocal(v137, p127.baseNode, 0, 0, 0) }
			local v139 = {
				["node"] = v137,
				["initPos"] = v138,
				["posX"] = v138[1],
				["posZ"] = v138[3],
				["polyline"] = nil,
				["volume"] = p127.volume,
				["baseNode"] = p127.baseNode
			}
			local v140 = p127.deformers
			table.insert(v140, v139)
			v128.fillVolumeDeformersByNode[v137] = v139
		end
		v135 = v135 + 1
	end
	p127.lastFillType = FillType.UNKNOWN
	return true
end
function FillVolume.loadFillVolumeInfo(p141, p142, p143, p144)
	p144.nodes = {}
	local v145 = 0
	while true do
		local v146 = p143 .. string.format(".node(%d)", v145)
		if not p142:hasProperty(v146) then
			break
		end
		XMLUtil.checkDeprecatedXMLElements(p142, v146 .. "#index", v146 .. "#node")
		local v147 = p142:getValue(v146 .. "#node", nil, p141.components, p141.i3dMappings)
		if v147 == nil then
			Logging.xmlWarning(p141.xmlFile, "Missing node for \'%s\'", v146)
		else
			local v148 = {
				["node"] = v147,
				["width"] = p142:getValue(v146 .. "#width", 1),
				["length"] = p142:getValue(v146 .. "#length", 1),
				["fillVolumeHeightIndex"] = p142:getValue(v146 .. "#fillVolumeHeightIndex"),
				["priority"] = p142:getValue(v146 .. "#priority", 1),
				["minHeight"] = p142:getValue(v146 .. "#minHeight"),
				["maxHeight"] = p142:getValue(v146 .. "#maxHeight"),
				["minFillLevelPercentage"] = p142:getValue(v146 .. "#minFillLevelPercentage"),
				["maxFillLevelPercentage"] = p142:getValue(v146 .. "#maxFillLevelPercentage"),
				["heightForTranslation"] = p142:getValue(v146 .. "#heightForTranslation"),
				["translationStart"] = p142:getValue(v146 .. "#translationStart", nil, true),
				["translationEnd"] = p142:getValue(v146 .. "#translationEnd", nil, true),
				["translationAlpha"] = 0
			}
			local v149 = p144.nodes
			table.insert(v149, v148)
		end
		v145 = v145 + 1
	end
	table.sort(p144.nodes, function(p150, p151)
		return p150.priority > p151.priority
	end)
	return true
end
function FillVolume.loadFillVolumeHeightNode(p152, p153, p154, p155)
	p155.isDirty = false
	p155.fillVolumeIndex = p153:getValue(p154 .. "#fillVolumeIndex", 1)
	if p152.spec_fillVolume.volumes[p155.fillVolumeIndex] == nil then
		Logging.xmlWarning(p152.xmlFile, "Invalid fillVolumeIndex \'%d\' for heightNode \'%s\'. Igoring heightNode!", p155.fillVolumeIndex, p154)
		return false
	end
	p155.refNodes = {}
	local v156 = 0
	while true do
		local v157 = p154 .. string.format(".refNode(%d)", v156)
		if not p153:hasProperty(v157) then
			break
		end
		XMLUtil.checkDeprecatedXMLElements(p153, v157 .. "#index", v157 .. "#node")
		local v158 = p153:getValue(v157 .. "#node", nil, p152.components, p152.i3dMappings)
		if v158 == nil then
			Logging.xmlWarning(p152.xmlFile, "Missing node for \'%s\'", v157)
		else
			local v159 = p155.refNodes
			table.insert(v159, {
				["refNode"] = v158
			})
		end
		v156 = v156 + 1
	end
	p155.nodes = {}
	local v160 = 0
	while true do
		local v161 = p154 .. string.format(".node(%d)", v160)
		if not p153:hasProperty(v161) then
			break
		end
		XMLUtil.checkDeprecatedXMLElements(p153, v161 .. "#index", v161 .. "#node")
		local v162 = p153:getValue(v161 .. "#node", nil, p152.components, p152.i3dMappings)
		if v162 == nil then
			Logging.xmlWarning(p152.xmlFile, "Missing node for \'%s\'", v161)
		else
			local v163 = {
				["node"] = v162,
				["baseScale"] = p153:getValue(v161 .. "#baseScale", "1 1 1", true),
				["scaleAxis"] = p153:getValue(v161 .. "#scaleAxis", "0 0 0", true),
				["scaleMax"] = p153:getValue(v161 .. "#scaleMax", "0 0 0", true),
				["basePosition"] = { getTranslation(v162) },
				["transAxis"] = p153:getValue(v161 .. "#transAxis", "0 0 0", true),
				["transMax"] = p153:getValue(v161 .. "#transMax", "0 0 0", true),
				["minHeight"] = p153:getValue(v161 .. "#minHeight", 0),
				["heightOffset"] = p153:getValue(v161 .. "#heightOffset", 0),
				["orientateToWorldY"] = p153:getValue(v161 .. "#orientateToWorldY", false)
			}
			local v164 = p155.nodes
			table.insert(v164, v163)
		end
		v160 = v160 + 1
	end
	return true
end
function FillVolume.getFillVolumeLoadInfo(p165, p166)
	return p165.spec_fillVolume.loadInfos[p166]
end
function FillVolume.getFillVolumeUnloadInfo(p167, p168)
	return p167.spec_fillVolume.unloadInfos[p168]
end
function FillVolume.getFillVolumeIndicesByFillUnitIndex(p169, p170)
	local v171 = p169.spec_fillVolume
	local v172 = {}
	for v173, v174 in ipairs(v171.volumes) do
		if v174.fillUnitIndex == p170 then
			table.insert(v172, v173)
		end
	end
	return v172
end
function FillVolume.setFillVolumeForcedFillTypeByFillUnitIndex(p175, p176, p177)
	local v178 = p175.spec_fillVolume
	for v179, v180 in ipairs(v178.volumes) do
		if v180.fillUnitIndex == p176 then
			p175:setFillVolumeForcedFillType(v179, p177)
		end
	end
end
function FillVolume.setFillVolumeForcedFillType(p181, p182, p183)
	local v184 = p181.spec_fillVolume
	if v184.volumes[p182] ~= nil then
		v184.volumes[p182].forcedFillType = p183
	end
end
function FillVolume.getFillVolumeUVScrollSpeed(_)
	return 0, 0, 0
end
function FillVolume.setMovingToolDirty(p185, p186, p187, p188, p189)
	p186(p185, p187, p188, p189)
	local v190 = p185.spec_fillVolume
	if v190.fillVolumeDeformersByNode ~= nil then
		local v191 = v190.fillVolumeDeformersByNode[p187]
		if v191 ~= nil then
			v191.isDirty = true
		end
	end
end
function FillVolume.loadExtraDependentParts(p192, p193, p194, p195, p196)
	if not p193(p192, p194, p195, p196) then
		return false
	end
	local v197 = p194:getValue(p195 .. ".fillVolume#fillVolumeIndex", 1)
	local v198 = p194:getValue(p195 .. ".fillVolume#deformerNodeIndices", nil, true)
	if v198 ~= nil and #v198 > 0 then
		p196.fillVolumeIndex = v197
		p196.deformerNodes = {}
		for v199 = 1, #v198 do
			local v200 = p196.deformerNodes
			local v201 = v198[v199]
			table.insert(v200, v201)
		end
	end
	return true
end
function FillVolume.updateExtraDependentParts(p202, p203, p204, p205)
	p203(p202, p204, p205)
	if p204.deformerNodes ~= nil then
		if p204.fillVolumeIndex ~= nil then
			p204.fillVolume = p202.spec_fillVolume.volumes[p204.fillVolumeIndex]
			if p204.fillVolume == nil then
				Logging.xmlWarning(p202.xmlFile, "Unable to find fillVolume with index \'%d\' for movingPart/movingTool \'%s\'", p204.fillVolumeIndex, getName(p204.node))
				p204.deformerNodes = nil
			end
			p204.fillVolumeIndex = nil
		end
		if p204.fillVolume ~= nil then
			for v206, v207 in pairs(p204.deformerNodes) do
				local v208 = p204.fillVolume.deformers[v207]
				if v208 == nil then
					p204.deformerNodes[v206] = nil
				else
					v208.isDirty = true
				end
			end
		end
	end
end
function FillVolume.onFillUnitFillLevelChanged(p209, p210, _, _, _, p211, _)
	local v212 = p209.spec_fillVolume
	local v213 = v212.fillUnitFillVolumeMapping[p210]
	if v213 == nil then
		return
	end
	local v214 = p209:getFillUnitFillLevel(p210)
	local v215 = p209:getFillUnitFillType(p210)
	for _, v216 in ipairs(v213.fillVolumes) do
		local v217 = v216.baseNode
		local v218 = v216.volume
		if v217 == nil or v218 == nil then
			return
		end
		local v219 = v216.fillLevel
		local v220 = v216.capacity
		v216.fillLevel = math.clamp(v214, 0, v220)
		local v221 = v216.fillLevel - v219
		if v216.forcedFillType ~= nil then
			v215 = v216.forcedFillType
		end
		if v214 == 0 then
			v216.forcedFillType = nil
		end
		if v215 ~= v216.lastFillType then
			local v222 = g_fillTypeManager:getFillTypeByIndex(v215)
			local v223
			if v222 == nil then
				v223 = nil
			else
				v223 = v222.maxPhysicalSurfaceAngle
			end
			if v223 ~= nil and v216.volume ~= nil then
				setFillPlaneMaxPhysicalSurfaceAngle(v216.volume, v223)
				v216.maxPhysicalSurfaceAngle = v223
			end
		end
		setVisibility(v216.volume, v214 > 0)
		if v215 ~= FillType.UNKNOWN and v215 ~= v216.lastFillType then
			local v224 = g_fillTypeManager:getTextureArrayIndexByFillTypeIndex(v215)
			if v224 ~= nil then
				setShaderParameter(v216.volume, "fillTypeId", v224 - 1, 0, 0, 0, false)
			end
		end
		if p211 == nil then
			local v225 = (v216.maxPhysicalSurfaceAngle == 0 or v216.maxSurfaceAngle == 0) and 10 or 0.1
			local v226, v227, v228 = localToWorld(v216.volume, -v225 * 0.5, 0, -v225 * 0.5)
			local v229, v230, v231 = localDirectionToWorld(v216.volume, v225, 0, 0)
			local v232, v233, v234 = localDirectionToWorld(v216.volume, 0, 0, v225)
			if not p209.isServer and (v212.lastPositionInfo[1] ~= 0 and v212.lastPositionInfo[2] ~= 0) then
				v226, v227, v228 = localToWorld(v216.volume, v212.lastPositionInfo[1], 0, v212.lastPositionInfo[2])
			end
			local v235 = v221 / 400
			local v236 = math.floor(v235)
			local v237 = math.clamp(v236, 1, 25)
			for _ = 1, v237 do
				fillPlaneAdd(v216.volume, v221 / v237, v226, v227, v228, v229, v230, v231, v232, v233, v234)
			end
		else
			for v238 = #v212.availableFillNodes, 1, -1 do
				v212.availableFillNodes[v238] = nil
			end
			if p211.nodes == nil then
				local v239 = v212.availableFillNodes
				table.insert(v239, p211)
			else
				local v240 = p211.nodes[1].priority
				while #v212.availableFillNodes == 0 and v240 >= 1 do
					for _, v241 in pairs(p211.nodes) do
						if v240 <= v241.priority then
							local v242 = true
							if v241.minHeight ~= nil or v241.maxHeight ~= nil then
								local v243 = (-1 / 0)
								if v241.fillVolumeHeightIndex == nil or v212.heightNodes[v241.fillVolumeHeightIndex] == nil then
									local v244, _, v245 = localToLocal(v241.node, v217, 0, 0, 0)
									local v246 = getFillPlaneHeightAtLocalPos(v218, v244, v245) - v216.heightOffset
									v243 = math.max(v243, v246)
								else
									for _, v247 in pairs(v212.heightNodes[v241.fillVolumeHeightIndex].refNodes) do
										local v248, _, v249 = localToLocal(v247.refNode, v217, 0, 0, 0)
										local v250 = getFillPlaneHeightAtLocalPos(v218, v248, v249) - v216.heightOffset
										v243 = math.max(v243, v250)
									end
								end
								if v241.minHeight ~= nil and v243 < v241.minHeight then
									v242 = false
								end
								if v241.maxHeight ~= nil and v241.maxHeight < v243 then
									v242 = false
								end
								if v241.heightForTranslation ~= nil then
									if v241.heightForTranslation < v243 then
										v241.translationAlpha = v241.translationAlpha + 0.01
										local v251, v252, v253 = MathUtil.vector3ArrayLerp(v241.translationStart, v241.translationEnd, v241.translationAlpha)
										setTranslation(v241.node, v251, v252, v253)
									else
										v241.translationAlpha = v241.translationAlpha - 0.01
									end
									local v254 = v241.translationAlpha
									v241.translationAlpha = math.clamp(v254, 0, 1)
								end
							end
							if v241.minFillLevelPercentage ~= nil or v241.maxFillLevelPercentage ~= nil then
								local v255 = v214 / p209:getFillUnitCapacity(p210)
								if v241.minFillLevelPercentage ~= nil and v255 < v241.minFillLevelPercentage then
									v242 = false
								end
								if v241.maxFillLevelPercentage ~= nil and v241.maxFillLevelPercentage < v255 then
									v242 = false
								end
							end
							if v242 then
								local v256 = v212.availableFillNodes
								table.insert(v256, v241)
							end
						end
					end
					if #v212.availableFillNodes > 0 then
						break
					end
					v240 = v240 - 1
				end
			end
			local v257 = #v212.availableFillNodes
			local v258 = 0
			local v259 = 0
			for v260 = 1, v257 do
				local v261 = v212.availableFillNodes[v260]
				local v262, v263, v264 = getWorldTranslation(v261.node)
				local v265, v266, v267 = localDirectionToWorld(v261.node, v261.width, 0, 0)
				local v268, v269, v270 = localDirectionToWorld(v261.node, 0, 0, v261.length)
				if VehicleDebug.state == VehicleDebug.DEBUG then
					drawDebugLine(v262, v263, v264, 1, 0, 0, v262 + v265, v263 + v266, v264 + v267, 1, 0, 0)
					drawDebugLine(v262, v263, v264, 0, 0, 1, v262 + v268, v263 + v269, v264 + v270, 0, 0, 1)
					drawDebugPoint(v262, v263, v264, 1, 1, 1, 1)
					drawDebugPoint(v262 + v265, v263 + v266, v264 + v267, 1, 0, 0, 1)
					drawDebugPoint(v262 + v268, v263 + v269, v264 + v270, 0, 0, 1, 1)
				end
				local v271 = v262 - (v265 + v268) / 2
				local v272 = v263 - (v266 + v269) / 2
				local v273 = v264 - (v267 + v270) / 2
				fillPlaneAdd(v216.volume, v221 / v257, v271, v272, v273, v265, v266, v267, v268, v269, v270)
				local v274, _, v275 = localToLocal(v261.node, v216.volume, 0, 0, 0)
				v259 = v259 + v274
				v258 = v258 + v275
			end
			local v276 = v259 / v257
			local v277 = v258 / v257
			local v278 = v276 - v212.lastPositionInfoSent[1]
			if math.abs(v278) > FillVolume.SEND_PRECISION then
				::l77::
				v212.lastPositionInfoSent[1] = v276
				v212.lastPositionInfoSent[2] = v277
				p209:raiseDirtyFlags(v212.dirtyFlag)
				goto l78
			end
			local v279 = v277 - v212.lastPositionInfoSent[2]
			if math.abs(v279) > FillVolume.SEND_PRECISION then
				goto l77
			end
		end
		::l78::
		local v280 = v212.fillVolumeIndexToHeightNode[v216.index]
		if v280 ~= nil then
			for _, v281 in ipairs(v280) do
				v281.isDirty = true
			end
		end
		for _, v282 in pairs(v216.deformers) do
			v282.isDirty = true
		end
		v216.lastFillType = v215
	end
end

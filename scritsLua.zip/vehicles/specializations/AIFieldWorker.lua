source("dataS/scripts/vehicles/specializations/events/AIVehicleIsBlockedEvent.lua")
source("dataS/scripts/vehicles/specializations/events/AIFieldWorkerStateEvent.lua")
source("dataS/scripts/vehicles/ai/AIDriveStrategy.lua")
source("dataS/scripts/vehicles/ai/AIDriveStrategyBaler.lua")
source("dataS/scripts/vehicles/ai/AIDriveStrategyCombine.lua")
source("dataS/scripts/vehicles/ai/AIDriveStrategyConveyor.lua")
source("dataS/scripts/vehicles/ai/AIDriveStrategyStonePicker.lua")
source("dataS/scripts/vehicles/ai/AIDriveStrategyFieldCourse.lua")
AIFieldWorker = {}
AIFieldWorker.TRAFFIC_COLLISION_BOX_FILENAME = "data/shared/ai/trafficCollision.i3d"
AIFieldWorker.TRAFFIC_COLLISION = 0
AIFieldWorker.registeredDriveStrategies = {}
function AIFieldWorker.registerDriveStrategy(p1, p2, p3)
	local v4 = AIFieldWorker.registeredDriveStrategies
	local v5 = {
		["func"] = p1,
		["class"] = p2,
		["prio"] = p3 or #AIFieldWorker.registeredDriveStrategies + 1
	}
	table.insert(v4, v5)
end
AIFieldWorker.registerDriveStrategy(function()
	return true
end, AIDriveStrategyFieldCourse, 1000)
function AIFieldWorker.deleteCollisionBox()
	if AIFieldWorker.TRAFFIC_COLLISION ~= 0 then
		delete(AIFieldWorker.TRAFFIC_COLLISION)
		AIFieldWorker.TRAFFIC_COLLISION = 0
	end
end
function AIFieldWorker.prerequisitesPresent(p6)
	local v7 = SpecializationUtil.hasSpecialization(AIJobVehicle, p6)
	if v7 then
		v7 = SpecializationUtil.hasSpecialization(Drivable, p6)
	end
	return v7
end
function AIFieldWorker.initSpecialization()
	local v8 = Vehicle.xmlSchema
	v8:setXMLSpecializationType("AIFieldWorker")
	v8:register(XMLValueType.FLOAT, "vehicle.ai.didNotMoveTimeout#value", "Did not move time out time", 5000)
	v8:register(XMLValueType.BOOL, "vehicle.ai.didNotMoveTimeout#deactivated", "Did not move time out deactivated", false)
	v8:setXMLSpecializationType()
	g_i3DManager:loadI3DFileAsync(AIFieldWorker.TRAFFIC_COLLISION_BOX_FILENAME, true, false, AIFieldWorker.onTrafficCollisionLoaded, nil, nil)
end
function AIFieldWorker.terminateSpecialization()
	AIFieldWorker.deleteCollisionBox()
end
function AIFieldWorker.postInitSpecialization()
	table.sort(AIFieldWorker.registeredDriveStrategies, function(p9, p10)
		return p9.prio < p10.prio
	end)
	local v11 = Vehicle.xmlSchemaSavegame
	v11:register(XMLValueType.BOOL, "vehicles.vehicle(?).aiFieldWorker#isActive", "AI worker is currently active")
	for _, v12 in ipairs(AIFieldWorker.registeredDriveStrategies) do
		if v12.class.registerSavegameXMLPaths ~= nil then
			v12.class.registerSavegameXMLPaths(v11, "vehicles.vehicle(?).aiFieldWorker")
		end
	end
end
function AIFieldWorker.registerEvents(p13)
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerStart")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerActive")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerEnd")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerPrepareForWork")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerStartTurn")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerTurnProgress")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerEndTurn")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerSideOffsetChanged")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerBlock")
	SpecializationUtil.registerEvent(p13, "onAIFieldWorkerContinue")
end
function AIFieldWorker.registerFunctions(p14)
	SpecializationUtil.registerFunction(p14, "getIsFieldWorkActive", AIFieldWorker.getIsFieldWorkActive)
	SpecializationUtil.registerFunction(p14, "getAICollisionTriggers", AIFieldWorker.getAICollisionTriggers)
	SpecializationUtil.registerFunction(p14, "startFieldWorker", AIFieldWorker.startFieldWorker)
	SpecializationUtil.registerFunction(p14, "stopFieldWorker", AIFieldWorker.stopFieldWorker)
	SpecializationUtil.registerFunction(p14, "getDirectionSnapAngle", AIFieldWorker.getDirectionSnapAngle)
	SpecializationUtil.registerFunction(p14, "getAINeedsTrafficCollisionBox", AIFieldWorker.getAINeedsTrafficCollisionBox)
	SpecializationUtil.registerFunction(p14, "clearAIDebugTexts", AIFieldWorker.clearAIDebugTexts)
	SpecializationUtil.registerFunction(p14, "addAIDebugText", AIFieldWorker.addAIDebugText)
	SpecializationUtil.registerFunction(p14, "clearAIDebugLines", AIFieldWorker.clearAIDebugLines)
	SpecializationUtil.registerFunction(p14, "addAIDebugLine", AIFieldWorker.addAIDebugLine)
	SpecializationUtil.registerFunction(p14, "updateAIFieldWorker", AIFieldWorker.updateAIFieldWorker)
	SpecializationUtil.registerFunction(p14, "updateAIFieldWorkerImplementData", AIFieldWorker.updateAIFieldWorkerImplementData)
	SpecializationUtil.registerFunction(p14, "updateAIFieldWorkerDriveStrategies", AIFieldWorker.updateAIFieldWorkerDriveStrategies)
	SpecializationUtil.registerFunction(p14, "aiFieldWorkerStartTurn", AIFieldWorker.aiFieldWorkerStartTurn)
	SpecializationUtil.registerFunction(p14, "aiFieldWorkerTurnProgress", AIFieldWorker.aiFieldWorkerTurnProgress)
	SpecializationUtil.registerFunction(p14, "aiFieldWorkerEndTurn", AIFieldWorker.aiFieldWorkerEndTurn)
	SpecializationUtil.registerFunction(p14, "aiFieldWorkerSideOffsetChanged", AIFieldWorker.aiFieldWorkerSideOffsetChanged)
	SpecializationUtil.registerFunction(p14, "getCanAIFieldWorkerContinueWork", AIFieldWorker.getCanAIFieldWorkerContinueWork)
	SpecializationUtil.registerFunction(p14, "getAIFieldWorkerIsTurning", AIFieldWorker.getAIFieldWorkerIsTurning)
	SpecializationUtil.registerFunction(p14, "getAIFieldWorkerLastTurnDirection", AIFieldWorker.getAIFieldWorkerLastTurnDirection)
	SpecializationUtil.registerFunction(p14, "getAIFieldWorkerIsBlocked", AIFieldWorker.getAIFieldWorkerIsBlocked)
	SpecializationUtil.registerFunction(p14, "getAttachedAIImplements", AIFieldWorker.getAttachedAIImplements)
	SpecializationUtil.registerFunction(p14, "getCanStartFieldWork", AIFieldWorker.getCanStartFieldWork)
end
function AIFieldWorker.registerOverwrittenFunctions(p15)
	SpecializationUtil.registerOverwrittenFunction(p15, "aiBlock", AIFieldWorker.aiBlock)
	SpecializationUtil.registerOverwrittenFunction(p15, "aiContinue", AIFieldWorker.aiContinue)
	SpecializationUtil.registerOverwrittenFunction(p15, "getStartableAIJob", AIFieldWorker.getStartableAIJob)
	SpecializationUtil.registerOverwrittenFunction(p15, "getHasStartableAIJob", AIFieldWorker.getHasStartableAIJob)
end
function AIFieldWorker.registerEventListeners(p16)
	SpecializationUtil.registerEventListener(p16, "onLoad", AIFieldWorker)
	SpecializationUtil.registerEventListener(p16, "onDelete", AIFieldWorker)
	SpecializationUtil.registerEventListener(p16, "onStateChange", AIFieldWorker)
	SpecializationUtil.registerEventListener(p16, "onUpdate", AIFieldWorker)
	SpecializationUtil.registerEventListener(p16, "onReadStream", AIFieldWorker)
	SpecializationUtil.registerEventListener(p16, "onWriteStream", AIFieldWorker)
end
function AIFieldWorker.onLoad(p17, p18)
	local v19 = p17.spec_aiFieldWorker
	v19.aiImplementList = {}
	v19.aiImplementDataDirtyFlag = true
	v19.aiDriveParams = {
		["valid"] = false
	}
	v19.aiUpdateLowFrequencyDt = 0
	v19.aiUpdateDt = 0
	v19.driveStrategies = {}
	v19.reconstructionData = {}
	v19.aiTrafficCollision = nil
	v19.aiTrafficCollisionTranslation = { 0, 0, 10 }
	v19.debugTexts = {}
	v19.debugLines = {}
	v19.fieldJob = g_currentMission.aiJobTypeManager:createJob(AIJobType.FIELDWORK)
	v19.didNotMoveTimeout = p17.xmlFile:getValue("vehicle.ai.didNotMoveTimeout#value", 5000)
	if p17.xmlFile:getValue("vehicle.ai.didNotMoveTimeout#deactivated") then
		v19.didNotMoveTimeout = (1 / 0)
	end
	v19.didNotMoveTimer = v19.didNotMoveTimeout
	v19.isActive = false
	v19.isBlocked = false
	v19.lastTurnDirection = false
	if p18 ~= nil and (not p18.resetVehicles and p18.xmlFile:getValue(p18.key .. ".aiFieldWorker#isActive")) then
		v19.pendingAIFieldWorkerStart = true
		v19.strategyLoadingData = {}
		for v20, v21 in ipairs(AIFieldWorker.registeredDriveStrategies) do
			if v21.class.loadFromXML ~= nil then
				v19.strategyLoadingData[v20] = v21.class.loadFromXML(v19.reconstructionData, p18.xmlFile, p18.key .. ".aiFieldWorker")
			end
		end
	end
end
function AIFieldWorker.onDelete(p22)
	local v23 = p22.spec_aiFieldWorker
	if v23.aiTrafficCollision ~= nil and entityExists(v23.aiTrafficCollision) then
		delete(v23.aiTrafficCollision)
		v23.aiTrafficCollision = nil
	end
end
function AIFieldWorker.saveToXMLFile(p24, p25, p26, _)
	local v27 = p24.spec_aiFieldWorker
	if v27.isActive ~= nil then
		p25:setValue(p26 .. "#isActive", v27.isActive)
	end
	if v27.driveStrategies ~= nil and #v27.driveStrategies > 0 then
		v27.reconstructionData = {}
		for _, v28 in ipairs(v27.driveStrategies) do
			if v28.fillReconstructionData ~= nil then
				v28:fillReconstructionData(v27.reconstructionData)
			end
		end
	end
	for _, v29 in ipairs(AIFieldWorker.registeredDriveStrategies) do
		if v29.class.saveToXML ~= nil then
			v29.class.saveToXML(v27.reconstructionData, p25, p26)
		end
	end
end
function AIFieldWorker.onReadStream(p30, p31, _)
	if streamReadBool(p31) then
		p30:startFieldWorker()
	end
end
function AIFieldWorker.onWriteStream(p32, p33, _)
	local v34 = p32.spec_aiFieldWorker
	streamWriteBool(p33, v34.isActive)
end
function AIFieldWorker.onUpdate(p35, p36, _, _, _)
	local v37 = p35.spec_aiFieldWorker
	if p35.isServer and v37.pendingAIFieldWorkerStart then
		local v38 = g_currentMission.aiJobTypeManager:createJob(AIJobType.FIELDWORK)
		v38.vehicleParameter:setVehicle(p35)
		local v39, _, v40 = getWorldTranslation(p35.rootNode)
		local v41, _, v42 = localDirectionToWorld(p35.rootNode, 0, 0, 1)
		v38.positionAngleParameter:setPosition(v39, v40)
		v38.positionAngleParameter:setAngle(MathUtil.getYRotationFromDirection(v41, v42))
		v38:setValues()
		g_client:getServerConnection():sendEvent(AIJobStartRequestEvent.new(v38, p35:getOwnerFarmId()))
		v37.pendingAIFieldWorkerStart = false
	end
	if v37.checkImplementDirection then
		v37.checkImplementDirection = false
		for _, v43 in pairs(p35:getAttachedAIImplements()) do
			if v43.object:getAINeedsRootAlignment() then
				local v44 = Utils.getYRotationBetweenNodes(p35:getAIDirectionNode(), v43.object.components[1].node, p35.yRotationOffset, v43.object.yRotationOffset, false)
				if math.abs(v44) > 1.5707963267948966 then
					p35:stopCurrentAIJob(AIMessageErrorImplementWrongWay.new())
					return
				end
			end
		end
	end
	if VehicleDebug.state == VehicleDebug.DEBUG_AI and p35.isActiveForInputIgnoreSelectionIgnoreAI then
		if #v37.debugTexts > 0 then
			for v45, v46 in pairs(v37.debugTexts) do
				renderText(0.7, 0.87 - 0.02 * v45, 0.02, v46)
			end
		end
		if #v37.debugLines > 0 then
			for _, v47 in pairs(v37.debugLines) do
				drawDebugLine(v47.s[1], v47.s[2], v47.s[3], v47.c[1], v47.c[2], v47.c[3], v47.e[1], v47.e[2], v47.e[3], v47.c[1], v47.c[2], v47.c[3])
			end
		end
	end
	if v37.aiImplementDataDirtyFlag then
		v37.aiImplementDataDirtyFlag = false
		p35:updateAIFieldWorkerImplementData()
	end
	if p35:getIsFieldWorkActive() and p35.isServer then
		if v37.aiTrafficCollision ~= nil and not p35:getAIFieldWorkerIsTurning() then
			local v48 = localToWorld
			local v49 = p35.components[1].node
			local v50 = v37.aiTrafficCollisionTranslation
			local v51, v52, v53 = v48(v49, unpack(v50))
			setTranslation(v37.aiTrafficCollision, v51, v52, v53)
			setRotation(v37.aiTrafficCollision, localRotationToWorld(p35.components[1].node, 0, 0, 0))
		end
		for _, v54 in ipairs(v37.driveStrategies) do
			v54:update(p36)
		end
		p35:updateAIFieldWorker(p36)
	end
end
function AIFieldWorker.updateAIFieldWorker(p55, p56)
	local v57 = p55.spec_aiFieldWorker
	p55:clearAIDebugTexts()
	p55:clearAIDebugLines()
	if p55:getIsFieldWorkActive() then
		if #v57.driveStrategies > 0 then
			local v58, v59, v60 = getWorldTranslation(p55:getAISteeringNode())
			local v61 = nil
			local v62 = nil
			local v63 = nil
			local v64 = nil
			local v65 = nil
			for _, v66 in ipairs(v57.driveStrategies) do
				local v67
				v63, v62, v65, v67, v64 = v66:getDriveData(p56, v58, v59, v60)
				v61 = math.min(v67 or (1 / 0), v61 or (1 / 0))
				if v63 ~= nil or not p55:getIsFieldWorkActive() then
					break
				end
			end
			if v63 == nil and p55:getIsFieldWorkActive() then
				p55:stopCurrentAIJob(AIMessageSuccessFinishedJob.new())
			end
			if not p55:getIsFieldWorkActive() then
				return
			end
			local v68, v69
			if p55:getAIFieldWorkerIsTurning() then
				v68 = 2
				v69 = 1.5
			else
				v68 = 5
				v69 = 5
			end
			local v70 = v64 / v68
			local v71 = v61 * math.min(1, v70)
			local v72 = math.max(v69, v71)
			local v73, _ = p55:getSpeedLimit(true)
			local v74 = math.min(v61, v72, v73)
			local v75 = math.min(v74, p55:getCruiseControlMaxSpeed())
			if VehicleDebug.state == VehicleDebug.DEBUG_AI then
				p55:addAIDebugText(string.format("===> maxSpeed = %.2f", v75))
			end
			v57.aiDriveParams.moveForwards = v65
			v57.aiDriveParams.tX = v63
			v57.aiDriveParams.tY = v59
			v57.aiDriveParams.tZ = v62
			v57.aiDriveParams.maxSpeed = v75
			v57.aiDriveParams.valid = true
		end
		if v57.aiDriveParams.valid then
			local v76 = v57.aiDriveParams.moveForwards
			local v77 = v57.aiDriveParams.tX
			local v78 = v57.aiDriveParams.tY
			local v79 = v57.aiDriveParams.tZ
			local v80 = v57.aiDriveParams.maxSpeed
			local v81, v82
			if v76 then
				local v83
				v81, v83, v82 = worldToLocal(p55:getAISteeringNode(), v77, v78, v79)
			else
				local v84
				v81, v84, v82 = worldToLocal(p55:getAIReverserNode(), v77, v78, v79)
			end
			local v85 = v80 ~= 0
			AIVehicleUtil.driveToPoint(p55, p56, 1, v85, v76, v81, v82, v80)
		end
		p55:raiseAIEvent("onAIFieldWorkerActive", "onAIImplementActive")
	end
end
function AIFieldWorker.getIsFieldWorkActive(p86)
	return p86.spec_aiFieldWorker.isActive
end
function AIFieldWorker.getStartableAIJob(p87, p88)
	local v89 = p88(p87)
	local v90
	if v89 == nil then
		p87:updateAIFieldWorkerImplementData()
		if p87:getCanStartFieldWork() then
			v90 = p87.spec_aiFieldWorker.fieldJob
			v90:applyCurrentState(p87, g_currentMission, g_localPlayer.farmId, true)
			v90:setValues()
			if not v90:validate(false) then
				v90 = v89
			end
		else
			v90 = v89
		end
	else
		v90 = v89
	end
	return v90
end
function AIFieldWorker.getHasStartableAIJob(p91, _)
	return p91:getCanStartFieldWork()
end
function AIFieldWorker.getCanStartFieldWork(p92)
	local v93 = p92.spec_aiFieldWorker
	if v93.isActive then
		return false
	else
		return #v93.aiImplementList > 0
	end
end
function AIFieldWorker.startFieldWorker(p94)
	local v95 = p94.spec_aiFieldWorker
	v95.isActive = true
	if p94.isServer then
		p94:updateAIFieldWorkerImplementData()
		p94:updateAIFieldWorkerDriveStrategies()
		v95.checkImplementDirection = true
	end
	p94:raiseAIEvent("onAIFieldWorkerStart", "onAIImplementStart")
	if p94:getAINeedsTrafficCollisionBox() and (AIFieldWorker.TRAFFIC_COLLISION ~= nil and (AIFieldWorker.TRAFFIC_COLLISION ~= 0 and v95.aiTrafficCollision == nil)) then
		v95.aiTrafficCollision = clone(AIFieldWorker.TRAFFIC_COLLISION, true, false, true)
	end
end
function AIFieldWorker.stopFieldWorker(p96)
	local v97 = p96.spec_aiFieldWorker
	v97.aiDriveParams.valid = false
	p96:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF, true)
	if p96.isServer then
		WheelsUtil.updateWheelsPhysics(p96, 0, v97.lastSpeedReal * v97.movingDirection, 0, true, true)
		if v97.driveStrategies ~= nil and #v97.driveStrategies > 0 then
			v97.reconstructionData = {}
			for v98 = #v97.driveStrategies, 1, -1 do
				local v99 = v97.driveStrategies[v98]
				if v99.fillReconstructionData ~= nil then
					v99:fillReconstructionData(v97.reconstructionData)
				end
				v99:delete()
				table.remove(v97.driveStrategies, v98)
			end
			v97.driveStrategies = {}
		end
	end
	if p96:getAINeedsTrafficCollisionBox() and v97.aiTrafficCollision ~= nil then
		setTranslation(v97.aiTrafficCollision, 0, -1000, 0)
	end
	if p96.brake ~= nil then
		p96:brake(1)
	end
	local v100 = p96.rootVehicle.actionController
	if v100 ~= nil then
		v100:resetCurrentState()
	end
	p96:raiseAIEvent("onAIFieldWorkerEnd", "onAIImplementEnd")
	v97.isTurning = false
	v97.isBlocked = false
	v97.lastTurnStrategy = nil
	v97.isActive = false
end
function AIFieldWorker.getAICollisionTriggers(_, _) end
function AIFieldWorker.getDirectionSnapAngle(_)
	return 0
end
function AIFieldWorker.getAINeedsTrafficCollisionBox(p101)
	return p101.isServer
end
function AIFieldWorker.clearAIDebugTexts(p102)
	for v103 = #p102.spec_aiFieldWorker.debugTexts, 1, -1 do
		p102.spec_aiFieldWorker.debugTexts[v103] = nil
	end
end
function AIFieldWorker.addAIDebugText(p104, p105)
	local v106 = p104.spec_aiFieldWorker.debugTexts
	table.insert(v106, p105)
end
function AIFieldWorker.clearAIDebugLines(p107)
	for v108 = #p107.spec_aiFieldWorker.debugLines, 1, -1 do
		p107.spec_aiFieldWorker.debugLines[v108] = nil
	end
end
function AIFieldWorker.addAIDebugLine(p109, p110, p111, p112)
	local v113 = p109.spec_aiFieldWorker.debugLines
	table.insert(v113, {
		["s"] = p110,
		["e"] = p111,
		["c"] = p112
	})
end
function AIFieldWorker.onStateChange(p114, p115, _)
	if p115 == VehicleStateChange.ATTACH or p115 == VehicleStateChange.DETACH then
		p114.spec_aiFieldWorker.aiImplementDataDirtyFlag = true
	end
end
function AIFieldWorker.updateAIFieldWorkerImplementData(p116)
	local v117 = p116.spec_aiFieldWorker
	v117.aiImplementList = {}
	p116:addVehicleToAIImplementList(v117.aiImplementList)
end
function AIFieldWorker.updateAIFieldWorkerDriveStrategies(p118)
	local v119 = p118.spec_aiFieldWorker
	if #v119.aiImplementList > 0 then
		if v119.driveStrategies ~= nil and #v119.driveStrategies > 0 then
			for v120 = #v119.driveStrategies, 1, -1 do
				v119.driveStrategies[v120]:delete()
				table.remove(v119.driveStrategies, v120)
			end
			v119.driveStrategies = {}
		end
		for _, v121 in ipairs(AIFieldWorker.registeredDriveStrategies) do
			for _, v122 in pairs(p118.rootVehicle.childVehicles) do
				if v121.func(v122) then
					local v123 = v119.driveStrategies
					local v124 = v121.class.new
					local v125 = v119.reconstructionData
					table.insert(v123, v124(v125))
					break
				end
			end
		end
		for v126 = 1, #v119.driveStrategies do
			v119.driveStrategies[v126]:setAIVehicle(p118)
		end
	end
end
function AIFieldWorker.aiFieldWorkerStartTurn(p127, p128, p129)
	local v130 = p127.spec_aiFieldWorker
	v130.isTurning = true
	v130.lastTurnDirection = p128
	v130.lastTurnStrategy = p129
	for _, v131 in ipairs(v130.driveStrategies) do
		if v131.setTurnData ~= nil then
			v131:setTurnData(p128, p129)
		end
	end
	p127:raiseAIEvent("onAIFieldWorkerStartTurn", "onAIImplementStartTurn", p128, p129)
end
function AIFieldWorker.aiFieldWorkerTurnProgress(p132, p133, p134, p135)
	p132:raiseAIEvent("onAIFieldWorkerTurnProgress", "onAIImplementTurnProgress", p133, p134, p135)
end
function AIFieldWorker.aiFieldWorkerEndTurn(p136, p137)
	local v138 = p136.spec_aiFieldWorker
	v138.isTurning = false
	v138.lastTurnStrategy = nil
	for _, v139 in ipairs(v138.driveStrategies) do
		if v139.setTurnData ~= nil then
			v139:setTurnData()
		end
	end
	p136:raiseAIEvent("onAIFieldWorkerEndTurn", "onAIImplementEndTurn", p137)
end
function AIFieldWorker.aiFieldWorkerSideOffsetChanged(p140, p141, p142)
	p140:raiseAIEvent("onAIFieldWorkerSideOffsetChanged", "onAIImplementSideOffsetChanged", p141, p142)
end
function AIFieldWorker.aiBlock(p143, p144)
	p144(p143)
	local v145 = p143.spec_aiFieldWorker
	if v145.isActive and not v145.isTurning then
		p143:raiseAIEvent("onAIFieldWorkerBlock", "onAIImplementBlock")
	end
	v145.isBlocked = true
end
function AIFieldWorker.aiContinue(p146, p147)
	p147(p146)
	local v148 = p146.spec_aiFieldWorker
	if v148.isActive and not v148.isTurning then
		p146:raiseAIEvent("onAIFieldWorkerContinue", "onAIImplementContinue")
	end
	v148.isBlocked = false
end
function AIFieldWorker.getCanAIFieldWorkerContinueWork(p149, p150)
	for _, v151 in ipairs(p149:getAttachedAIImplements()) do
		local v152, v153, v154 = v151.object:getCanAIImplementContinueWork(p150)
		if not v152 then
			return false, v153, v154
		end
	end
	if SpecializationUtil.hasSpecialization(AIImplement, p149.specializations) then
		local v155, v156, v157 = p149:getCanAIImplementContinueWork(p150)
		if not v155 then
			return false, v156, v157
		end
	end
	return true, false
end
function AIFieldWorker.getAIFieldWorkerIsTurning(p158)
	return p158.spec_aiFieldWorker.isTurning
end
function AIFieldWorker.getAIFieldWorkerLastTurnDirection(p159)
	return p159.spec_aiFieldWorker.lastTurnDirection
end
function AIFieldWorker.getAIFieldWorkerIsBlocked(p160)
	return p160.spec_aiFieldWorker.isBlocked
end
function AIFieldWorker.getAttachedAIImplements(p161)
	return p161.spec_aiFieldWorker.aiImplementList
end
function AIFieldWorker.onTrafficCollisionLoaded(_, p162)
	if p162 ~= 0 then
		local v163 = getChildAt(p162, 0)
		link(getRootNode(), v163)
		AIFieldWorker.TRAFFIC_COLLISION = v163
		delete(p162)
	end
end

VineDetector = {}
function VineDetector.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("VineDetector")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.vineDetector.raycast#node", "Raycast node")
	v1:register(XMLValueType.FLOAT, "vehicle.vineDetector.raycast#maxDistance", "Max raycast distance", 1)
	v1:setXMLSpecializationType()
end
function VineDetector.prerequisitesPresent(_)
	return true
end
function VineDetector.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "raycastCallbackVineDetection", VineDetector.raycastCallbackVineDetection)
	SpecializationUtil.registerFunction(p2, "finishedVineDetection", VineDetector.finishedVineDetection)
	SpecializationUtil.registerFunction(p2, "clearCurrentVinePlaceable", VineDetector.clearCurrentVinePlaceable)
	SpecializationUtil.registerFunction(p2, "cancelVineDetection", VineDetector.cancelVineDetection)
	SpecializationUtil.registerFunction(p2, "getIsValidVinePlaceable", VineDetector.getIsValidVinePlaceable)
	SpecializationUtil.registerFunction(p2, "handleVinePlaceable", VineDetector.handleVinePlaceable)
	SpecializationUtil.registerFunction(p2, "getCanStartVineDetection", VineDetector.getCanStartVineDetection)
	SpecializationUtil.registerFunction(p2, "getFirstVineHitPosition", VineDetector.getFirstVineHitPosition)
	SpecializationUtil.registerFunction(p2, "getCurrentVineHitPosition", VineDetector.getCurrentVineHitPosition)
	SpecializationUtil.registerFunction(p2, "getCurrentVineHitDistance", VineDetector.getCurrentVineHitDistance)
end
function VineDetector.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", VineDetector)
	SpecializationUtil.registerEventListener(p3, "onUpdate", VineDetector)
end
function VineDetector.onLoad(p4, _)
	local v5 = p4.spec_vineDetector
	v5.raycast = {}
	v5.raycast.node = p4.xmlFile:getValue("vehicle.vineDetector.raycast#node", nil, p4.components, p4.i3dMappings)
	if v5.raycast.node == nil then
		Logging.xmlWarning(p4.xmlFile, "Missing vine detector raycast node")
	end
	v5.raycast.maxDistance = p4.xmlFile:getValue("vehicle.vineDetector.raycast#maxDistance", 1)
	v5.raycast.vineNode = nil
	v5.raycast.isRaycasting = false
	v5.raycast.firstHitPosition = { 0, 0, 0 }
	v5.raycast.currentHitPosition = { 0, 0, 0 }
	v5.raycast.currentHitDistance = 0
	v5.raycast.currentNode = nil
	v5.isVineDetectionActive = false
end
function VineDetector.onUpdate(p6, _, _, _, _)
	local v7 = p6.spec_vineDetector
	if p6.isServer and v7.raycast.node ~= nil then
		if p6:getCanStartVineDetection() then
			v7.isVineDetectionActive = true
			if not v7.raycast.isRaycasting then
				v7.raycast.isRaycasting = true
				local v8, v9, v10 = getWorldTranslation(v7.raycast.node)
				local v11, v12, v13 = localDirectionToWorld(v7.raycast.node, 0, -1, 0)
				raycastAllAsync(v8, v9, v10, v11, v12, v13, v7.raycast.maxDistance, "raycastCallbackVineDetection", p6, CollisionFlag.STATIC_OBJECT)
				return
			end
		elseif v7.isVineDetectionActive then
			p6:clearCurrentVinePlaceable()
			p6:finishedVineDetection()
			v7.isVineDetectionActive = false
		end
	end
end
function VineDetector.raycastCallbackVineDetection(p14, p15, p16, p17, p18, p19, _, _, _, _, p20, p21)
	if p15 == 0 then
		p14:clearCurrentVinePlaceable()
		p14:finishedVineDetection()
		return
	else
		if VehicleDebug.state == VehicleDebug.DEBUG then
			DebugGizmo.renderAtPositionSimple(p16, p17, p18, string.format("hitActorId %s (%s); hitShape %s (%s)", getName(p15), p15, getName(p20), p20))
		end
		if p14.spec_vineDetector.raycast.isRaycasting then
			local v22 = g_currentMission.vineSystem:getPlaceable(p15)
			if p14:getIsValidVinePlaceable(v22) and g_currentMission.nodeToObject[p15] ~= p14 then
				if p14:handleVinePlaceable(p15, v22, p16, p17, p18, p19) then
					p14:finishedVineDetection()
					return false
				end
				if not p21 then
					return true
				end
				p14:finishedVineDetection()
				return false
			else
				if not p21 then
					return true
				end
				p14:clearCurrentVinePlaceable()
				p14:finishedVineDetection()
				return false
			end
		else
			p14:cancelVineDetection()
			return false
		end
	end
end
function VineDetector.finishedVineDetection(p23)
	p23.spec_vineDetector.raycast.isRaycasting = false
end
function VineDetector.getCanStartVineDetection(_)
	return true
end
function VineDetector.getFirstVineHitPosition(p24)
	local v25 = p24.spec_vineDetector.raycast
	return v25.firstHitPosition[1], v25.firstHitPosition[2], v25.firstHitPosition[3]
end
function VineDetector.getCurrentVineHitPosition(p26)
	local v27 = p26.spec_vineDetector.raycast
	return v27.currentHitPosition[1], v27.currentHitPosition[2], v27.currentHitPosition[3]
end
function VineDetector.getCurrentVineHitDistance(p28)
	return p28.spec_vineDetector.raycast.currentHitDistance
end
function VineDetector.clearCurrentVinePlaceable(p29)
	local v30 = p29.spec_vineDetector.raycast
	v30.currentNode = nil
	v30.placeable = nil
end
function VineDetector.cancelVineDetection(p31)
	local v32 = p31.spec_vineDetector.raycast
	v32.currentNode = nil
	v32.placeable = nil
	p31:finishedVineDetection()
end
function VineDetector.getIsValidVinePlaceable(_, p33)
	return p33 ~= nil
end
function VineDetector.handleVinePlaceable(p34, p35, p36, p37, p38, p39, p40)
	local v41 = p34.spec_vineDetector.raycast
	if v41.currentNode ~= p35 then
		local v42 = v41.firstHitPosition
		local v43 = v41.firstHitPosition
		local v44 = v41.firstHitPosition
		v42[1] = p37
		v43[2] = p38
		v44[3] = p39
	end
	v41.currentNode = p35
	local v45 = v41.currentHitPosition
	local v46 = v41.currentHitPosition
	local v47 = v41.currentHitPosition
	v45[1] = p37
	v46[2] = p38
	v47[3] = p39
	v41.currentHitDistance = p40
	v41.placeable = p36
	return true
end

YarderTower = {}
YarderTower.TREE_RAYCAST_DISTANCE = 40
YarderTower.TERRAIN_RAYCAST_DISTANCE = 20
YarderTower.MAX_CONTROL_DISTANCE = 15
YarderTower.GROUND_COLLISION_MASK = CollisionFlag.TERRAIN + CollisionFlag.TERRAIN_DELTA + CollisionFlag.STATIC_OBJECT
YarderTower.DAMAGED_SPEED_REDUCTION = 0.3
YarderTower.FOLLOW_MODE_NONE = 0
YarderTower.FOLLOW_MODE_ME = 1
YarderTower.FOLLOW_MODE_HOME = 2
YarderTower.FOLLOW_MODE_PICKUP = 3
YarderTower.FAILED_REASON_NONE = 0
YarderTower.FAILED_REASON_TOO_LONG = 1
YarderTower.FAILED_REASON_WRONG_ANGLE = 2
YarderTower.FAILED_REASON_TREE_TOO_SMALL = 3
YarderTower.FAILED_REASON_WAY_BLOCKED = 4
YarderTower.FAILED_REASON_ONLY_UPHILL_YARDING = 5
source("dataS/scripts/vehicles/specializations/activatables/YarderTowerSetupActivatable.lua")
source("dataS/scripts/vehicles/specializations/activatables/YarderTowerControlActivatable.lua")
source("dataS/scripts/vehicles/specializations/events/YarderTowerFollowModeEvent.lua")
source("dataS/scripts/vehicles/specializations/events/YarderTowerSetTargetEvent.lua")
source("dataS/scripts/gui/hud/extensions/YarderTowerHUDExtension.lua")
function YarderTower.prerequisitesPresent(_)
	return true
end
function YarderTower.initSpecialization()
	g_storeManager:addSpecType("yarderMaxLength", "shopListAttributeIconWinchMaxLength", YarderTower.loadSpecValueMaxLength, YarderTower.getSpecValueMaxLength, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("yarderMaxMass", "shopListAttributeIconWinchMaxMass", YarderTower.loadSpecValueMaxMass, YarderTower.getSpecValueMaxMass, StoreSpecies.VEHICLE)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("YarderTower")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderTower#controlTrigger", "Trigger for player to control the tower")
	v1:register(XMLValueType.BOOL, "vehicle.yarderTower#requiresAttacherVehicle", "Attacher vehicle is not allowed to be detached", false)
	v1:register(XMLValueType.BOOL, "vehicle.yarderTower#requiresLowering", "Yarder can only be set up while lowered", false)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower#foldMinLimit", "Yarder can only be set up while fold time in between these limits", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower#foldMaxLimit", "Yarder can only be set up while fold time in between these limits", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.placement#height", "Default height used on the trees", 10)
	v1:register(XMLValueType.STRING, "vehicle.yarderTower.placement#minHeightOffset", "Min. height offset from main rope start to position on the tree (\'-\' for no limit)", "-1")
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.carriage#maxSpeed", "Max. speed of carriage in kph", 20)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.carriage#acceleration", "Acceleration speed", 0.01)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.carriage#deceleration", "Deceleration speed", 0.05)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.carriage#startOffset", "Min. offset from tower to the carriage in meter", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.carriage#endOffset", "Min. offset from tree to the carriage in meter", 1)
	v1:register(XMLValueType.STRING, "vehicle.yarderTower.carriage#filename", "Path to vehicle xml of carriage vehicle")
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.carriage#maxTreeMass", "Max. tree mass that can be attached (used for store spec data)")
	ForestryHook.registerXMLPaths(v1, "vehicle.yarderTower.hooks.tree")
	ForestryHook.registerXMLPaths(v1, "vehicle.yarderTower.hooks.ground")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderTower.ropes.setupRope#node", "Setup rope start node")
	v1:register(XMLValueType.COLOR, "vehicle.yarderTower.ropes.setupRope#colorInvalid", "Emissive color of rope while placement is invalid")
	v1:register(XMLValueType.COLOR, "vehicle.yarderTower.ropes.setupRope#colorValid", "Emissive color of rope while placement is valid")
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.ropes.setupRope#diameterTree", "Rope diameter while on a tree", 0.015)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.ropes.setupRope#diameterPlayer", "Rope diameter while in players hand", 0.015)
	YarderTower.registerRopeXMLPaths(v1, "vehicle.yarderTower.ropes.setupRope")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderTower.ropes.mainRope#node", "Main rope start node")
	v1:register(XMLValueType.ANGLE, "vehicle.yarderTower.ropes.mainRope#maxAngle", "Max angle to the target", 80)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.ropes.mainRope#maxLength", "Max distance to the target", 100)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.ropes.mainRope#clearance", "Min. clearance below the rope", 2)
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.ropes.mainRope#minTreeDiameter", "Min. diameter of target tree", 0.2)
	YarderTower.registerRopeXMLPaths(v1, "vehicle.yarderTower.ropes.mainRope")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderTower.ropes.pullRope#node", "Pull rope start node")
	YarderTower.registerRopeXMLPaths(v1, "vehicle.yarderTower.ropes.pullRope")
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.ropes.pushRope#yOffset", "Y Offset from main anchor point", 1.5)
	YarderTower.registerRopeXMLPaths(v1, "vehicle.yarderTower.ropes.pushRope")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderTower.ropes.supportRopes#centerNode", "Center of search radius")
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.ropes.supportRopes#treeRadius", "Radius to search mounting trees", 25)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderTower.ropes.supportRopes.supportRope(?)#node", "Support node which is automatically connected")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderTower.ropes.supportRopes.supportRope(?)#raycastNode", "Dedicated node only used for ground detection raycast", "#node")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.yarderTower.ropes.supportRopes.supportRope(?)#angleReferenceNode", "Node used for angle calculations to validate the mounting point")
	v1:register(XMLValueType.ANGLE, "vehicle.yarderTower.ropes.supportRopes.supportRope(?)#maxAngle", "Max. angle to tree", 15)
	v1:register(XMLValueType.ANGLE, "vehicle.yarderTower.ropes.supportRopes.supportRope(?)#raycastRotY", "Y rotation of rotNode while searching for ground mounting point via raycast")
	v1:register(XMLValueType.FLOAT, "vehicle.yarderTower.ropes.supportRopes.supportRope(?)#treeYOffset", "Y translation offset from tree root", 1)
	YarderTower.registerRopeXMLPaths(v1, "vehicle.yarderTower.ropes.supportRopes.supportRope(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "setupRopeIncrease")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "setupRopeDecrease")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "setupRopeValidTarget")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "setupStarted")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "setupFinished")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "setupCanceled")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "ropeLinkTree")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "ropeLinkGround")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "removeYarder")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "carriageMovePos")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "carriageMoveNeg")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "carriageMovePosLimit")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "carriageMoveNegLimit")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "carriageDriveMovePos")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "carriageDriveMoveNeg")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "carriageDriveMovePosLimit")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "carriageDriveMoveNegLimit")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.yarderTower.sounds", "motor")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.yarderTower.motorEffects")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.BOOL, "vehicles.vehicle(?).yarderTower#isActive", "Main rope is active")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).yarderTower#position", "Current carriage position")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).yarderTower.target#x", "Target x position")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).yarderTower.target#y", "Target y position")
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).yarderTower.target#z", "Target z position")
	YarderCarriage.registerSavegameXMLPaths(v2, "vehicles.vehicle(?).yarderTower")
end
function YarderTower.registerRopeXMLPaths(p3, p4)
	p3:register(XMLValueType.FLOAT, p4 .. "#maxOffset", "Max y offset from direct line in the center of the rope", 0.1)
	p3:register(XMLValueType.FLOAT, p4 .. "#offsetReferenceLength", "Y offset is interpolated up to this distance of rope length", 5)
	p3:register(XMLValueType.STRING, p4 .. "#filename", "Path to rope i3d file")
	p3:register(XMLValueType.STRING, p4 .. "#ropeNode", "Index path to rope to load", "0|0")
	p3:register(XMLValueType.FLOAT, p4 .. "#diameter", "Rope diameter", 0.015)
	p3:register(XMLValueType.NODE_INDEX, p4 .. "#rotNode", "Rotation node which is aligned in the rope direction")
	p3:register(XMLValueType.BOOL, p4 .. "#rotNodeAllAxis", "Adjust all axis of the rotation node - otherwise only rotated about the Y axis", false)
	p3:register(XMLValueType.NODE_INDEX, p4 .. ".ropeLengthNode(?)#node", "Node that is changing depending on the rope length")
	p3:register(XMLValueType.FLOAT, p4 .. ".ropeLengthNode(?)#minLength", "Min. length for reference", 0)
	p3:register(XMLValueType.FLOAT, p4 .. ".ropeLengthNode(?)#maxLength", "Max. length for reference", 10)
	p3:register(XMLValueType.VECTOR_ROT, p4 .. ".ropeLengthNode(?)#minRot", "Rotation to apply at min. length")
	p3:register(XMLValueType.VECTOR_ROT, p4 .. ".ropeLengthNode(?)#maxRot", "Rotation to apply at max. length")
	p3:register(XMLValueType.VECTOR_TRANS, p4 .. ".ropeLengthNode(?)#minTrans", "Translation to apply at min. length")
	p3:register(XMLValueType.VECTOR_TRANS, p4 .. ".ropeLengthNode(?)#maxTrans", "Translation to apply at max. length")
	p3:register(XMLValueType.VECTOR_SCALE, p4 .. ".ropeLengthNode(?)#minScale", "Scale to apply at min. length")
	p3:register(XMLValueType.VECTOR_SCALE, p4 .. ".ropeLengthNode(?)#maxScale", "Scale to apply at max. length")
	p3:register(XMLValueType.STRING, p4 .. ".ropeLengthNode(?)#shaderParameterName", "Shader parameter to adjust")
	p3:register(XMLValueType.VECTOR_4, p4 .. ".ropeLengthNode(?)#minShaderParameter", "Shader parameter to apply at min. length")
	p3:register(XMLValueType.VECTOR_4, p4 .. ".ropeLengthNode(?)#maxShaderParameter", "Shader parameter to apply at max. length")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p3, p4)
end
function YarderTower.registerEvents(p5)
	SpecializationUtil.registerEvent(p5, "onYarderCarriageTreeAttached")
end
function YarderTower.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "onHookI3DLoaded", YarderTower.onHookI3DLoaded)
	SpecializationUtil.registerFunction(p6, "onRopeI3DLoaded", YarderTower.onRopeI3DLoaded)
	SpecializationUtil.registerFunction(p6, "getIsSetupModeChangeAllowed", YarderTower.getIsSetupModeChangeAllowed)
	SpecializationUtil.registerFunction(p6, "setYarderSetupModeState", YarderTower.setYarderSetupModeState)
	SpecializationUtil.registerFunction(p6, "setYarderTargetActive", YarderTower.setYarderTargetActive)
	SpecializationUtil.registerFunction(p6, "setYarderCarriageFollowMode", YarderTower.setYarderCarriageFollowMode)
	SpecializationUtil.registerFunction(p6, "setYarderCarriageMoveInput", YarderTower.setYarderCarriageMoveInput)
	SpecializationUtil.registerFunction(p6, "setYarderCarriageLiftInput", YarderTower.setYarderCarriageLiftInput)
	SpecializationUtil.registerFunction(p6, "onYarderCarriageAttach", YarderTower.onYarderCarriageAttach)
	SpecializationUtil.registerFunction(p6, "onYarderCarriageDetach", YarderTower.onYarderCarriageDetach)
	SpecializationUtil.registerFunction(p6, "setupSupportRopes", YarderTower.setupSupportRopes)
	SpecializationUtil.registerFunction(p6, "onCreateCarriageFinished", YarderTower.onCreateCarriageFinished)
	SpecializationUtil.registerFunction(p6, "onCarriageVehicleDeleted", YarderTower.onCarriageVehicleDeleted)
	SpecializationUtil.registerFunction(p6, "setYarderRopeState", YarderTower.setYarderRopeState)
	SpecializationUtil.registerFunction(p6, "updateYarderRope", YarderTower.updateYarderRope)
	SpecializationUtil.registerFunction(p6, "updateYarderRopeLengthNodes", YarderTower.updateYarderRopeLengthNodes)
	SpecializationUtil.registerFunction(p6, "getTreeAtPosition", YarderTower.getTreeAtPosition)
	SpecializationUtil.registerFunction(p6, "getIsPlayerInYarderRange", YarderTower.getIsPlayerInYarderRange)
	SpecializationUtil.registerFunction(p6, "getIsPlayerInYarderControlRange", YarderTower.getIsPlayerInYarderControlRange)
	SpecializationUtil.registerFunction(p6, "getYarderIsSetUp", YarderTower.getYarderIsSetUp)
	SpecializationUtil.registerFunction(p6, "getYarderStatusInfo", YarderTower.getYarderStatusInfo)
	SpecializationUtil.registerFunction(p6, "getYarderMainRopeLength", YarderTower.getYarderMainRopeLength)
	SpecializationUtil.registerFunction(p6, "getYarderCarriageLastSpeed", YarderTower.getYarderCarriageLastSpeed)
	SpecializationUtil.registerFunction(p6, "getIsTreeShapeUsedForYarderSetup", YarderTower.getIsTreeShapeUsedForYarderSetup)
	SpecializationUtil.registerFunction(p6, "onYarderControlTriggerCallback", YarderTower.onYarderControlTriggerCallback)
	SpecializationUtil.registerFunction(p6, "onYarderTreeRaycastCallback", YarderTower.onYarderTreeRaycastCallback)
	SpecializationUtil.registerFunction(p6, "doRopePlacementValidation", YarderTower.doRopePlacementValidation)
	SpecializationUtil.registerFunction(p6, "onMainRopePlacementValidated", YarderTower.onMainRopePlacementValidated)
	SpecializationUtil.registerFunction(p6, "onYarderSupportTerrainRaycastCallback", YarderTower.onYarderSupportTerrainRaycastCallback)
	SpecializationUtil.registerFunction(p6, "onSupportRopeTreeOverlapCallback", YarderTower.onSupportRopeTreeOverlapCallback)
	SpecializationUtil.registerFunction(p6, "onYarderTowerPlayerDeleted", YarderTower.onYarderTowerPlayerDeleted)
end
function YarderTower.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "isDetachAllowed", YarderTower.isDetachAllowed)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsFoldAllowed", YarderTower.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p7, "getAllowsLowering", YarderTower.getAllowsLowering)
	SpecializationUtil.registerOverwrittenFunction(p7, "getDoConsumePtoPower", YarderTower.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p7, "getConsumingLoad", YarderTower.getConsumingLoad)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsPowerTakeOffActive", YarderTower.getIsPowerTakeOffActive)
	SpecializationUtil.registerOverwrittenFunction(p7, "getDirtMultiplier", YarderTower.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p7, "getWearMultiplier", YarderTower.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p7, "getUsageCausesDamage", YarderTower.getUsageCausesDamage)
	SpecializationUtil.registerOverwrittenFunction(p7, "addToPhysics", YarderTower.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p7, "removeFromPhysics", YarderTower.removeFromPhysics)
end
function YarderTower.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onLoadEnd", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onPreDelete", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onDelete", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onReadStream", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onWriteStream", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onReadUpdateStream", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onWriteUpdateStream", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onUpdate", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onYarderCarriageTreeAttached", YarderTower)
	SpecializationUtil.registerEventListener(p8, "onPostAttach", YarderTower)
end
function YarderTower.onLoad(p_u_9, _)
	local v_u_10 = p_u_9.spec_yarderTower
	local v11 = false
	v_u_10.sharedLoadRequestIds = {}
	v_u_10.controlTriggerNode = p_u_9.xmlFile:getValue("vehicle.yarderTower#controlTrigger", nil, p_u_9.components, p_u_9.i3dMappings)
	if v_u_10.controlTriggerNode == nil then
		Logging.xmlError(p_u_9.xmlFile, "Missing yarder control trigger")
		v11 = true
	else
		if not CollisionFlag.getHasMaskFlagSet(v_u_10.controlTriggerNode, CollisionFlag.PLAYER) then
			Logging.xmlError(p_u_9.xmlFile, "Yarder control trigger does not have the PLAYER collision flag set!")
			v11 = true
		end
		addTrigger(v_u_10.controlTriggerNode, "onYarderControlTriggerCallback", p_u_9)
	end
	v_u_10.requiresAttacherVehicle = p_u_9.xmlFile:getValue("vehicle.yarderTower#requiresAttacherVehicle", false)
	v_u_10.requiresLowering = p_u_9.xmlFile:getValue("vehicle.yarderTower#requiresLowering", false)
	v_u_10.foldMinLimit = p_u_9.xmlFile:getValue("vehicle.yarderTower#foldMinLimit", 0)
	v_u_10.foldMaxLimit = p_u_9.xmlFile:getValue("vehicle.yarderTower#foldMaxLimit", 1)
	v_u_10.requiresPowerTimeOffset = 0
	v_u_10.placementHeight = p_u_9.xmlFile:getValue("vehicle.yarderTower.placement#height", 10)
	local v12 = p_u_9.xmlFile:getValue("vehicle.yarderTower.placement#minHeightOffset", "-1")
	if v12 == "-" then
		v_u_10.placementMinHeightOffset = (1 / 0)
	else
		v_u_10.placementMinHeightOffset = tonumber(v12)
	end
	v_u_10.carriage = {}
	v_u_10.carriage.lastMoveInput = 0
	v_u_10.carriage.lastMoveInputTime = 0
	v_u_10.carriage.lastLiftInput = 0
	v_u_10.carriage.lastLiftInputTime = 0
	v_u_10.carriage.speed = 0
	v_u_10.carriage.targetSpeed = 0
	v_u_10.carriage.position = 0
	v_u_10.carriage.lastPosition = 0
	v_u_10.carriage.lastPositionTimeOffset = 0
	v_u_10.carriage.lastSpeed = 0
	v_u_10.carriage.followModeState = YarderTower.FOLLOW_MODE_NONE
	v_u_10.carriage.followModePlayer = nil
	v_u_10.carriage.followModeLocalPlayer = false
	v_u_10.carriage.followModePickupPosition = 0
	v_u_10.carriage.lastPlayerInRange = false
	v_u_10.carriage.maxSpeed = p_u_9.xmlFile:getValue("vehicle.yarderTower.carriage#maxSpeed", 20) / 3600
	v_u_10.carriage.acceleration = p_u_9.xmlFile:getValue("vehicle.yarderTower.carriage#acceleration", 0.01)
	v_u_10.carriage.deceleration = p_u_9.xmlFile:getValue("vehicle.yarderTower.carriage#deceleration", 0.05)
	v_u_10.carriage.startOffset = p_u_9.xmlFile:getValue("vehicle.yarderTower.carriage#startOffset", 1)
	v_u_10.carriage.endOffset = p_u_9.xmlFile:getValue("vehicle.yarderTower.carriage#endOffset", 1)
	v_u_10.carriage.filename = p_u_9.xmlFile:getValue("vehicle.yarderTower.carriage#filename")
	if v_u_10.carriage.filename == nil then
		Logging.xmlError(p_u_9.xmlFile, "No carriage filename given in \'vehicle.yarderTower.carriage#filename\'")
		v11 = true
	else
		v_u_10.carriage.filename = Utils.getFilename(v_u_10.carriage.filename, p_u_9.baseDirectory)
		if g_storeManager:getItemByXMLFilename(v_u_10.carriage.filename) == nil then
			Logging.xmlError(p_u_9.xmlFile, "Invalid carriage filename given. (%s)", v_u_10.carriage.filename)
			v11 = true
		end
	end
	v_u_10.hooks = {}
	v_u_10.hooks.treeData = ForestryHook.new(p_u_9, p_u_9.rootNode)
	v_u_10.hooks.treeData:loadFromXML(p_u_9.xmlFile, "vehicle.yarderTower.hooks.tree", p_u_9.baseDirectory)
	v_u_10.hooks.treeData:setVisibility(false)
	v_u_10.hooks.groundData = ForestryHook.new(p_u_9, p_u_9.rootNode)
	v_u_10.hooks.groundData:loadFromXML(p_u_9.xmlFile, "vehicle.yarderTower.hooks.ground", p_u_9.baseDirectory)
	v_u_10.hooks.groundData:setVisibility(false)
	if not (v_u_10.hooks.treeData:isValid() and v_u_10.hooks.groundData:isValid()) then
		Logging.xmlError(p_u_9.xmlFile, "Missing ground or tree hook for yarder!")
		v11 = true
	end
	local function v_u_20(p_u_13, p14)
		-- upvalues: (copy) p_u_9, (copy) v_u_10
		p_u_13.isActive = false
		p_u_13.maxOffset = p_u_9.xmlFile:getValue(p14 .. "#maxOffset", 0.4)
		p_u_13.offsetReferenceLength = p_u_9.xmlFile:getValue(p14 .. "#offsetReferenceLength", 5)
		p_u_13.diameter = p_u_9.xmlFile:getValue(p14 .. "#diameter", 0.015)
		p_u_13.filename = p_u_9.xmlFile:getValue(p14 .. "#filename")
		p_u_13.ropeNodePath = p_u_9.xmlFile:getValue(p14 .. "#ropeNode", "0|0")
		if p_u_13.filename ~= nil then
			p_u_13.filename = Utils.getFilename(p_u_13.filename, p_u_9.baseDirectory)
			local v15 = p_u_9:loadSubSharedI3DFile(p_u_13.filename, false, false, p_u_9.onRopeI3DLoaded, p_u_9, p_u_13)
			local v16 = v_u_10.sharedLoadRequestIds
			table.insert(v16, v15)
		end
		p_u_13.rotNode = p_u_9.xmlFile:getValue(p14 .. "#rotNode", nil, p_u_9.components, p_u_9.i3dMappings)
		p_u_13.rotNodeAllAxis = p_u_9.xmlFile:getValue(p14 .. "#rotNodeAllAxis", false)
		if p_u_13.rotNode ~= nil then
			p_u_13.rotNodeInitRot = { getRotation(p_u_13.rotNode) }
		end
		p_u_13.ropeLengthNodes = {}
		p_u_9.xmlFile:iterate(p14 .. ".ropeLengthNode", function(_, p17)
			-- upvalues: (ref) p_u_9, (copy) p_u_13
			local v18 = {
				["node"] = p_u_9.xmlFile:getValue(p17 .. "#node", nil, p_u_9.components, p_u_9.i3dMappings)
			}
			if v18.node ~= nil then
				v18.minLength = p_u_9.xmlFile:getValue(p17 .. "#minLength", 0)
				v18.maxLength = p_u_9.xmlFile:getValue(p17 .. "#maxLength", 10)
				v18.minRot = p_u_9.xmlFile:getValue(p17 .. "#minRot", nil, true)
				v18.maxRot = p_u_9.xmlFile:getValue(p17 .. "#maxRot", nil, true)
				v18.minTrans = p_u_9.xmlFile:getValue(p17 .. "#minTrans", nil, true)
				v18.maxTrans = p_u_9.xmlFile:getValue(p17 .. "#maxTrans", nil, true)
				v18.minScale = p_u_9.xmlFile:getValue(p17 .. "#minScale", nil, true)
				v18.maxScale = p_u_9.xmlFile:getValue(p17 .. "#maxScale", nil, true)
				v18.shaderParameterName = p_u_9.xmlFile:getValue(p17 .. "#shaderParameterName")
				v18.minShaderParameter = p_u_9.xmlFile:getValue(p17 .. "#minShaderParameter", nil, true)
				v18.maxShaderParameter = p_u_9.xmlFile:getValue(p17 .. "#maxShaderParameter", nil, true)
				if v18.shaderParameterName ~= nil and not getHasShaderParameter(v18.node, v18.shaderParameterName) then
					Logging.xmlWarning(p17, "Node does not have the provided shader parameter \'%s\'", v18.shaderParameterName)
				end
				local v19 = p_u_13.ropeLengthNodes
				table.insert(v19, v18)
			end
		end)
		p_u_13.changeObjects = {}
		ObjectChangeUtil.loadObjectChangeFromXML(p_u_9.xmlFile, p14, p_u_13.changeObjects, p_u_9.components, p_u_9)
		ObjectChangeUtil.setObjectChanges(p_u_13.changeObjects, false, p_u_9, p_u_9.setMovingToolDirty)
	end
	v_u_10.setupRope = {}
	v_u_10.setupRope.node = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.setupRope#node", nil, p_u_9.components, p_u_9.i3dMappings)
	if v_u_10.setupRope.node == nil then
		Logging.xmlWarning(p_u_9.xmlFile, "Missing setupRope for yarder tower")
		v11 = true
	end
	v_u_10.setupRope.colorInvalid = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.setupRope#colorInvalid", nil, true)
	v_u_10.setupRope.colorValid = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.setupRope#colorValid", nil, true)
	v_u_10.setupRope.diameterTree = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.setupRope#diameterTree", 0.015)
	v_u_10.setupRope.diameterPlayer = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.setupRope#diameterPlayer", 0.015)
	v_u_20(v_u_10.setupRope, "vehicle.yarderTower.ropes.setupRope")
	v_u_10.mainRope = {}
	v_u_10.mainRope.node = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.mainRope#node", nil, p_u_9.components, p_u_9.i3dMappings)
	if v_u_10.mainRope.node == nil then
		Logging.xmlWarning(p_u_9.xmlFile, "Missing mainRope for yarder tower")
		v11 = true
	end
	v_u_10.mainRope.maxAngle = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.mainRope#maxAngle", 80)
	v_u_10.mainRope.maxLength = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.mainRope#maxLength", 100)
	v_u_10.mainRope.clearance = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.mainRope#clearance", 2)
	v_u_10.mainRope.minTreeDiameter = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.mainRope#minTreeDiameter", 0.2)
	v_u_20(v_u_10.mainRope, "vehicle.yarderTower.ropes.mainRope")
	v_u_10.mainRope.isActive = false
	v_u_10.mainRope.isValid = false
	v_u_10.mainRope.lastIsValid = false
	v_u_10.mainRope.lastLength = 0
	v_u_10.mainRope.lastLengthOffsetTime = 0
	v_u_10.mainRope.failedWarning = nil
	v_u_10.mainRope.target = { 0, 0, 0 }
	v_u_10.pullRope = {}
	v_u_10.pullRope.node = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.pullRope#node", nil, p_u_9.components, p_u_9.i3dMappings)
	v_u_20(v_u_10.pullRope, "vehicle.yarderTower.ropes.pullRope")
	v_u_10.pushRope = {}
	v_u_10.pushRope.yOffset = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.pushRope#yOffset", 1.5)
	v_u_20(v_u_10.pushRope, "vehicle.yarderTower.ropes.pushRope")
	v_u_10.supportRopes = {}
	v_u_10.supportRopes.centerNode = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.supportRopes#centerNode", nil, p_u_9.components, p_u_9.i3dMappings)
	v_u_10.supportRopes.treeRadius = p_u_9.xmlFile:getValue("vehicle.yarderTower.ropes.supportRopes#treeRadius", 25)
	v_u_10.supportRopes.foundTrees = {}
	v_u_10.supportRopes.ropes = {}
	p_u_9.xmlFile:iterate("vehicle.yarderTower.ropes.supportRopes.supportRope", function(_, p21)
		-- upvalues: (copy) p_u_9, (copy) v_u_20, (copy) v_u_10
		local v22 = {
			["node"] = p_u_9.xmlFile:getValue(p21 .. "#node", nil, p_u_9.components, p_u_9.i3dMappings)
		}
		if v22.node ~= nil then
			v22.angleReferenceNode = p_u_9.xmlFile:getValue(p21 .. "#angleReferenceNode", v22.node, p_u_9.components, p_u_9.i3dMappings)
			v22.maxAngle = p_u_9.xmlFile:getValue(p21 .. "#maxAngle", 22.5)
			v22.raycastRotY = p_u_9.xmlFile:getValue(p21 .. "#raycastRotY")
			v22.treeYOffset = p_u_9.xmlFile:getValue(p21 .. "#treeYOffset", 1)
			v22.raycastNode = p_u_9.xmlFile:getValue(p21 .. "#raycastNode", v22.node, p_u_9.components, p_u_9.i3dMappings)
			v22.target = { 0, 0, 0 }
			v22.vehicle = p_u_9
			v22.onYarderSupportTerrainRaycastCallback = p_u_9.onYarderSupportTerrainRaycastCallback
			v_u_20(v22, p21)
			local v23 = v_u_10.supportRopes.ropes
			table.insert(v23, v22)
		end
	end)
	v_u_10.isPlayerInRange = false
	v_u_10.setupModeState = false
	v_u_10.updateRopesDirtyTime = 0
	v_u_10.treeRaycast = {}
	v_u_10.treeRaycast.hasStarted = false
	v_u_10.treeRaycast.lastValidTree = nil
	v_u_10.treeRaycast.lastValidTreeHeight = 0
	v_u_10.treeRaycast.foundTree = nil
	v_u_10.treeRaycast.data = {
		["vehicle"] = p_u_9,
		["x"] = 0,
		["y"] = 0,
		["z"] = 0,
		["hasStarted"] = false,
		["callback"] = p_u_9.onMainRopePlacementValidated
	}
	v_u_10.lastMotorRpm = 0
	v_u_10.lastMotorPowerTimeOffset = 0
	v_u_10.samples = {}
	if p_u_9.isClient then
		v_u_10.samples.setupRopeIncrease = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "setupRopeIncrease", p_u_9.baseDirectory, p_u_9.components, 0, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.setupRopeDecrease = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "setupRopeDecrease", p_u_9.baseDirectory, p_u_9.components, 0, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.setupRopeValidTarget = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "setupRopeValidTarget", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.setupStarted = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "setupStarted", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.setupFinished = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "setupFinished", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.setupCanceled = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "setupCanceled", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.ropeLinkTree = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "ropeLinkTree", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.ropeLinkGround = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "ropeLinkGround", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.removeYarder = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "removeYarder", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.carriageMovePos = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "carriageMovePos", p_u_9.baseDirectory, p_u_9.components, 0, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.carriageMoveNeg = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "carriageMoveNeg", p_u_9.baseDirectory, p_u_9.components, 0, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.carriageMovePosLimit = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "carriageMovePosLimit", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.carriageMoveNegLimit = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "carriageMoveNegLimit", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.carriageDriveMovePos = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "carriageDriveMovePos", p_u_9.baseDirectory, p_u_9.components, 0, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.carriageDriveMoveNeg = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "carriageDriveMoveNeg", p_u_9.baseDirectory, p_u_9.components, 0, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.carriageDriveMovePosLimit = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "carriageDriveMovePosLimit", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.carriageDriveMoveNegLimit = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "carriageDriveMoveNegLimit", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		v_u_10.samples.motor = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.yarderTower.sounds", "motor", p_u_9.baseDirectory, p_u_9.components, 0, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		for v24 = 1, #v_u_10.supportRopes.ropes do
			local v25 = v_u_10.supportRopes.ropes[v24]
			if v_u_10.samples.ropeLinkTree ~= nil then
				v25.sampleRopeLinkTree = g_soundManager:cloneSample(v_u_10.samples.ropeLinkTree, p_u_9.rootNode, p_u_9)
			end
			if v_u_10.samples.ropeLinkGround ~= nil then
				v25.sampleRopeLinkGround = g_soundManager:cloneSample(v_u_10.samples.ropeLinkGround, p_u_9.rootNode, p_u_9)
			end
		end
		if v_u_10.samples.ropeLinkTree ~= nil then
			v_u_10.mainRope.sampleRopeLinkTree = g_soundManager:cloneSample(v_u_10.samples.ropeLinkTree, p_u_9.rootNode, p_u_9)
		end
		v_u_10.motorEffects = g_effectManager:loadEffect(p_u_9.xmlFile, "vehicle.yarderTower.motorEffects", p_u_9.components, p_u_9, p_u_9.i3dMappings)
	end
	v_u_10.texts = {}
	v_u_10.texts.warningWrongAngle = g_i18n:getText("yarder_wrongAngle")
	v_u_10.texts.warningRopeTooLong = g_i18n:getText("yarder_ropeTooLong")
	v_u_10.texts.warningTreeTooSmall = g_i18n:getText("yarder_treeTooSmall")
	v_u_10.texts.warningWayIsBlocked = g_i18n:getText("yarder_wayIsBlocked")
	v_u_10.texts.actionStartSetup = g_i18n:getText("yarder_setup")
	v_u_10.texts.actionCancelSetup = g_i18n:getText("yarder_cancelSetup")
	v_u_10.texts.actionRemoveYarder = g_i18n:getText("yarder_remove")
	v_u_10.texts.actionSetTargetTree = g_i18n:getText("yarder_setTargetTree")
	v_u_10.texts.actionCarriageFollowModeEnable = g_i18n:getText("yarder_carriageFollowModeEnable")
	v_u_10.texts.actionCarriageFollowModeDisable = g_i18n:getText("yarder_carriageFollowModeDisable")
	v_u_10.texts.actionCarriageManualControl = g_i18n:getText("yarder_carriageMove")
	v_u_10.texts.actionCarriageLiftLower = g_i18n:getText("yarder_carriageLiftLower")
	v_u_10.texts.actionCarriageAttachTree = g_i18n:getText("yarder_carriageAttachTree")
	v_u_10.texts.actionCarriageDetachTree = g_i18n:getText("yarder_carriageDetachTree")
	v_u_10.texts.warningDetachNotAllowed = g_i18n:getText("yarder_detachNotAllowed")
	v_u_10.texts.warningDoNotMoveVehicle = g_i18n:getText("yarder_doNotMoveVehicle")
	v_u_10.texts.warningLowerFirst = g_i18n:getText("warning_lowerImplementFirst")
	v_u_10.texts.warningUnfoldFirst = g_i18n:getText("warning_firstUnfoldTheTool")
	v_u_10.texts.warningOnlyForUphillYarding = g_i18n:getText("yarder_onlyForUphillYarding")
	if v11 then
		Logging.xmlError(p_u_9.xmlFile, "Failed to load yarder")
		if v_u_10.controlTriggerNode ~= nil then
			removeTrigger(v_u_10.controlTriggerNode)
			v_u_10.controlTriggerNode = nil
		end
		SpecializationUtil.removeEventListener(p_u_9, "onLoadEnd", YarderTower)
		SpecializationUtil.removeEventListener(p_u_9, "onReadStream", YarderTower)
		SpecializationUtil.removeEventListener(p_u_9, "onWriteStream", YarderTower)
		SpecializationUtil.removeEventListener(p_u_9, "onReadUpdateStream", YarderTower)
		SpecializationUtil.removeEventListener(p_u_9, "onWriteUpdateStream", YarderTower)
		SpecializationUtil.removeEventListener(p_u_9, "onUpdate", YarderTower)
		SpecializationUtil.removeEventListener(p_u_9, "onYarderCarriageTreeAttached", YarderTower)
		SpecializationUtil.removeEventListener(p_u_9, "onPostAttach", YarderTower)
	else
		v_u_10.setupActivatable = YarderTowerSetupActivatable.new(p_u_9)
		v_u_10.controlActivatable = YarderTowerControlActivatable.new(p_u_9)
		v_u_10.hudExtension = YarderTowerHUDExtension.new(p_u_9)
	end
	v_u_10.dirtyFlag = p_u_9:getNextDirtyFlag()
end
function YarderTower.onLoadEnd(p26, p27)
	local v28 = p26.spec_yarderTower
	if p27 ~= nil and not p27.resetVehicles then
		local v29 = p27.key .. ".yarderTower"
		v28.mainRope.isActive = p27.xmlFile:getValue(v29 .. "#isActive", false)
		v28.carriage.position = p27.xmlFile:getValue(v29 .. "#position", 0)
		if v28.mainRope.isActive then
			v28.mainRope.isValid = true
			v28.mainRope.target[1] = p27.xmlFile:getValue(v29 .. ".target#x", v28.mainRope.target[1])
			v28.mainRope.target[2] = p27.xmlFile:getValue(v29 .. ".target#y", v28.mainRope.target[2])
			v28.mainRope.target[3] = p27.xmlFile:getValue(v29 .. ".target#z", v28.mainRope.target[3])
			p26:setYarderTargetActive(true, true)
			v28.loadedAttachedTreesData = YarderCarriage.loadAttachedTreesFromXML(p27.xmlFile, v29)
		end
	end
end
function YarderTower.onPreDelete(p30)
	local v31 = p30.spec_yarderTower
	if v31.mainRope ~= nil and v31.mainRope.isActive then
		p30:setYarderTargetActive(false, true)
	end
end
function YarderTower.onDelete(p32)
	local v33 = p32.spec_yarderTower
	if v33.hudExtension ~= nil then
		g_currentMission.hud:removeInfoExtension(v33.hudExtension)
		v33.hudExtension:delete()
	end
	if v33.controlTriggerNode ~= nil then
		removeTrigger(v33.controlTriggerNode)
		v33.controlTriggerNode = nil
	end
	if v33.sharedLoadRequestIds ~= nil then
		for _, v34 in ipairs(v33.sharedLoadRequestIds) do
			g_i3DManager:releaseSharedI3DFile(v34)
		end
	end
	if v33.hooks ~= nil then
		if v33.hooks.treeData ~= nil then
			v33.hooks.treeData:delete()
		end
		if v33.hooks.groundData ~= nil then
			v33.hooks.groundData:delete()
		end
	end
	if p32.isClient then
		g_soundManager:deleteSamples(v33.samples)
		if v33.supportRopes ~= nil then
			for v35 = 1, #v33.supportRopes.ropes do
				local v36 = v33.supportRopes.ropes[v35]
				g_soundManager:deleteSample(v36.sampleRopeLinkTree)
				g_soundManager:deleteSample(v36.sampleRopeLinkGround)
			end
		end
		if v33.mainRope ~= nil then
			g_soundManager:deleteSample(v33.mainRope.sampleRopeLinkTree)
		end
		g_effectManager:deleteEffects(v33.motorEffects)
	end
	g_currentMission.activatableObjectsSystem:removeActivatable(v33.setupActivatable)
	g_currentMission.activatableObjectsSystem:removeActivatable(v33.controlActivatable)
end
function YarderTower.saveToXMLFile(p37, p38, p39, p40)
	local v41 = p37.spec_yarderTower
	p38:setValue(p39 .. "#isActive", v41.mainRope.isActive)
	p38:setValue(p39 .. "#position", v41.carriage.position)
	if v41.mainRope.isActive then
		p38:setValue(p39 .. ".target#x", v41.mainRope.target[1])
		p38:setValue(p39 .. ".target#y", v41.mainRope.target[2])
		p38:setValue(p39 .. ".target#z", v41.mainRope.target[3])
	end
	if v41.carriage.vehicle ~= nil then
		v41.carriage.vehicle:saveAttachedTreesToXML(p38, p39, p40)
	end
end
function YarderTower.onReadStream(p42, p43, _)
	local v44 = p42.spec_yarderTower
	v44.carriage.followModeState = streamReadUIntN(p43, 2)
	if streamReadBool(p43) then
		local v45 = streamReadFloat32(p43)
		local v46 = streamReadFloat32(p43)
		local v47 = streamReadFloat32(p43)
		v44.mainRope.isValid = true
		local v48 = v44.mainRope.target
		local v49 = v44.mainRope.target
		local v50 = v44.mainRope.target
		v48[1] = v45
		v49[2] = v46
		v50[3] = v47
		p42:setYarderTargetActive(true, true)
	end
end
function YarderTower.onWriteStream(p51, p52, _)
	local v53 = p51.spec_yarderTower
	streamWriteUIntN(p52, v53.carriage.followModeState, 2)
	if streamWriteBool(p52, v53.mainRope.isActive) then
		streamWriteFloat32(p52, v53.mainRope.target[1])
		streamWriteFloat32(p52, v53.mainRope.target[2])
		streamWriteFloat32(p52, v53.mainRope.target[3])
	end
end
function YarderTower.onReadUpdateStream(p54, p55, _, p56)
	if not p56:getIsServer() and streamReadBool(p55) then
		p54:setYarderCarriageMoveInput(streamReadUIntN(p55, 2) - 1)
		p54:setYarderCarriageLiftInput(streamReadUIntN(p55, 2) - 1)
	end
end
function YarderTower.onWriteUpdateStream(p57, p58, p59, p60)
	local v61 = p57.spec_yarderTower
	if p59:getIsServer() and streamWriteBool(p58, bitAND(p60, v61.dirtyFlag) ~= 0) then
		local v62 = streamWriteUIntN
		local v63 = v61.carriage.lastMoveInput
		v62(p58, math.sign(v63) + 1, 2)
		local v64 = streamWriteUIntN
		local v65 = v61.carriage.lastLiftInput
		v64(p58, math.sign(v65) + 1, 2)
	end
end
function YarderTower.onUpdate(p66, p67, _, _, _)
	local v68 = p66.spec_yarderTower
	if v68.setupModeState then
		if v68.mainRope.node == nil or (g_localPlayer == nil or not g_localPlayer.isControlled) then
			p66:setYarderSetupModeState(false, true)
			v68.mainRope.isValid = false
			v68.mainRope.lastIsValid = false
		else
			local v69 = g_localPlayer
			local v70 = v69:getCurrentCameraNode()
			local v71, v72, v73 = getWorldTranslation(v68.mainRope.node)
			local v74 = v69.hands.spec_hands.kinematicNode
			local v75, v76, v77 = getWorldTranslation(v74)
			local v78 = MathUtil.vector3Length(v75 - v71, v76 - v72, v77 - v73)
			if not v68.treeRaycast.hasStarted then
				v68.treeRaycast.hasStarted = true
				v68.treeRaycast.foundTree = nil
				local v79, v80, v81 = localToWorld(v70, 0, 0, 1)
				local v82, v83, v84 = localDirectionToWorld(v70, 0, 0, -1)
				raycastClosestAsync(v79, v80, v81, v82, v83, v84, YarderTower.TREE_RAYCAST_DISTANCE, "onYarderTreeRaycastCallback", p66, CollisionFlag.TREE)
			end
			if v68.treeRaycast.lastValidTree == nil then
				v68.mainRope.isValid = false
				local v85 = v68.mainRope.target
				local v86 = v68.mainRope.target
				local v87 = v68.mainRope.target
				v85[1] = v75
				v86[2] = v76
				v87[3] = v77
				v68.setupRope.diameter = v68.setupRope.diameterPlayer
			else
				local v88 = v68.treeRaycast.lastValidTree
				local v89, v90, v91 = getWorldTranslation(v88)
				local v92 = v90 + v68.placementHeight
				local v93 = v68.treeRaycast.lastValidTreeHeight
				local v94 = math.max(v92, v93)
				local v95 = v72 + v68.placementMinHeightOffset
				local v96 = math.min(v94, v95)
				local v97 = getTerrainHeightAtWorldPos(g_terrainNode, v89, 0, v91) + 0.2
				local v98 = math.max(v96, v97)
				p66:doRopePlacementValidation(v68.mainRope.node, v88, v89, v98, v91, v68.mainRope.maxAngle, v68.mainRope.maxLength, v68.mainRope.clearance, v68.mainRope.minTreeDiameter, v68.treeRaycast.data)
				v75 = v68.mainRope.target[1]
				v76 = v68.mainRope.target[2]
				v77 = v68.mainRope.target[3]
				v78 = MathUtil.vector3Length(v75 - v71, v76 - v72, v77 - v73)
			end
			if v68.mainRope.isValid ~= v68.mainRope.lastIsValid then
				v68.mainRope.lastIsValid = v68.mainRope.isValid
				if v68.mainRope.isValid then
					g_soundManager:playSample(v68.samples.setupRopeValidTarget)
				end
			end
			if v78 ~= v68.mainRope.lastLength then
				if v68.mainRope.lastLength < v78 then
					if not g_soundManager:getIsSamplePlaying(v68.samples.setupRopeIncrease) then
						g_soundManager:playSample(v68.samples.setupRopeIncrease)
						g_soundManager:stopSample(v68.samples.setupRopeDecrease)
					end
				elseif not g_soundManager:getIsSamplePlaying(v68.samples.setupRopeDecrease) then
					g_soundManager:playSample(v68.samples.setupRopeDecrease)
					g_soundManager:stopSample(v68.samples.setupRopeIncrease)
				end
				v68.mainRope.lastLength = v78
				v68.mainRope.lastLengthOffsetTime = 250
			end
			if v68.mainRope.lastLengthOffsetTime > 0 then
				v68.mainRope.lastLengthOffsetTime = v68.mainRope.lastLengthOffsetTime - p67
				if v68.mainRope.lastLengthOffsetTime <= 0 then
					g_soundManager:stopSample(v68.samples.setupRopeIncrease)
					g_soundManager:stopSample(v68.samples.setupRopeDecrease)
				end
			end
			local v99 = v68.mainRope.isValid and v68.setupRope.colorValid or v68.setupRope.colorInvalid
			setShaderParameter(v68.setupRope.ropeNode, "ropeEmissiveColor", v99[1], v99[2], v99[3], 1, false)
			p66:updateYarderRope(v68.setupRope, v75, v76, v77, p67)
		end
		v68.setupActivatable:updateActionEventTexts()
		p66:raiseActive()
	end
	if v68.mainRope.isActive then
		if v68.loadedAttachedTreesData ~= nil and (v68.carriage.vehicle ~= nil and (v68.carriage.vehicle.isAddedToPhysics and v68.carriage.vehicle:resolveLoadedAttachedTrees(v68.loadedAttachedTreesData))) then
			v68.loadedAttachedTreesData = nil
		end
		local v100, v101, v102 = getWorldTranslation(v68.mainRope.node)
		local v103 = v68.mainRope.target[1]
		local v104 = v68.mainRope.target[2]
		local v105 = v68.mainRope.target[3]
		if p66.isServer and (v68.carriage.vehicle ~= nil and v68.carriage.vehicle.getCarriageDimensions ~= nil) then
			local v106, v107 = v68.carriage.vehicle:getCarriageDimensions()
			local v108 = MathUtil.vector3Length(v103 - v100, v104 - v101, v105 - v102)
			local v109 = v68.carriage.maxSpeed
			local v110 = p66:getVehicleDamage()
			if v110 > 0 then
				v109 = v109 * (1 - v110 * YarderTower.DAMAGED_SPEED_REDUCTION)
			end
			if v68.carriage.followModeState == YarderTower.FOLLOW_MODE_NONE then
				if v68.carriage.lastMoveInput == 0 then
					v68.carriage.targetSpeed = 0
				else
					v68.carriage.targetSpeed = v109 / v108 * p67 * v68.carriage.lastMoveInput
					if g_time - v68.carriage.lastMoveInputTime > 250 then
						v68.carriage.lastMoveInput = 0
					end
				end
			else
				local v111 = 0
				if v68.carriage.followModeState == YarderTower.FOLLOW_MODE_ME then
					local v112 = v68.carriage.followModePlayer
					if v112 ~= nil then
						local v113, v114, v115 = getWorldTranslation(v112.rootNode)
						local v116, v117, v118
						v116, v117, v118, v111 = MathUtil.getClosestPointOnLineSegment(v100, 0, v102, v103, 0, v105, v113, v114, v115)
					end
				end
				if v68.carriage.followModeState == YarderTower.FOLLOW_MODE_PICKUP then
					v111 = v68.carriage.followModePickupPosition
				end
				local v119 = v111 - v68.carriage.position
				local v120 = math.sign(v119)
				local v121 = v109 / v108 * p67
				local v122 = v111 - v68.carriage.position
				local v123 = math.abs(v122) * v108 / 2
				local v124 = v121 * math.min(v123, 1)
				v68.carriage.targetSpeed = v120 * v124
				if v68.carriage.followModeState ~= YarderTower.FOLLOW_MODE_ME then
					local v125 = v111 - v68.carriage.position
					if math.abs(v125) * v108 < 0.1 then
						p66:setYarderCarriageFollowMode(YarderTower.FOLLOW_MODE_NONE)
					end
				end
			end
			if v68.carriage.lastLiftInput ~= 0 then
				if g_time - v68.carriage.lastLiftInputTime > 250 then
					v68.carriage.lastLiftInput = 0
				end
				v68.carriage.vehicle:setCarriageLiftInput(v68.carriage.lastLiftInput)
			end
			if v68.requiresAttacherVehicle then
				if v68.carriage.followModeState ~= YarderTower.FOLLOW_MODE_NONE or (v68.carriage.lastLiftInput ~= 0 or v68.carriage.lastMoveInput ~= 0) then
					v68.requiresPowerTimeOffset = 10000
				end
				local v126 = p66:getAttacherVehicle()
				if v126 ~= nil and v126.startMotor ~= nil then
					if v68.requiresPowerTimeOffset > 0 then
						v68.requiresPowerTimeOffset = v68.requiresPowerTimeOffset - p67
						if v126:getIsMotorStarted() then
							local v127 = v126:getMotor()
							local v128 = v127:getMotorRotationAccelerationLimit()
							local v129, v130 = v127:getRequiredMotorRpmRange()
							local v131, _ = PowerConsumer.getTotalConsumedPtoTorque(v126)
							local v132 = v131 / v127:getPtoMotorRpmRatio()
							v126:controlVehicle(0, 0, 0, v129 * 3.141592653589793 / 30, v130 * 3.141592653589793 / 30, v128, 0, 0, v127:getMaxClutchTorque(), v132)
							v126:raiseActive()
						elseif v126:getCanMotorRun() then
							v126:startMotor()
						end
					elseif (v126.getIsControlled == nil or not v126:getIsControlled()) and v126:getIsMotorStarted() then
						v126:stopMotor()
					end
				end
			end
			local v133 = v68.carriage
			local v134 = v68.carriage.position + v68.carriage.speed
			v133.position = math.clamp(v134, 0, 1)
			local v135 = v68.carriage.targetSpeed - v68.carriage.speed
			local v136 = math.sign(v135)
			local v137 = v68.carriage.speed
			local v138 = v136 * math.sign(v137)
			local v139 = v136 == 1 and math.min or math.max
			v68.carriage.speed = v139(v68.carriage.speed + v68.carriage.maxSpeed / v108 * p67 * (v138 == 1 and v68.carriage.acceleration or v68.carriage.deceleration) * v136, v68.carriage.targetSpeed)
			local v140 = v106 / v108
			local v141 = v68.carriage.startOffset / v108 + v140 * 0.5
			local v142 = v68.carriage.endOffset / v108 + v140 * 0.5
			local v143 = v141 + v68.carriage.position * (1 - (v141 + v142))
			local v144, v145, v146 = MathUtil.vector3Lerp(v100, v101, v102, v103, v104, v105, v143)
			local v147 = v143 * 3.141592653589793
			local v148 = math.sin(v147) * v68.mainRope.maxOffset
			local v149 = v107 / v108 * 0.5
			local v150, v151, v152 = MathUtil.vector3Lerp(v100, v101, v102, v103, v104, v105, v143 - v149)
			local v153 = (v143 - v149) * 3.141592653589793
			local v154 = v151 - math.sin(v153) * v68.mainRope.maxOffset
			local v155, v156, v157 = MathUtil.vector3Lerp(v100, v101, v102, v103, v104, v105, v143 + v149)
			local v158 = (v143 + v149) * 3.141592653589793
			local v159 = v156 - math.sin(v158) * v68.mainRope.maxOffset
			local v160, v161, v162 = MathUtil.vector3Normalize(v155 - v150, v159 - v154, v157 - v152)
			setDirection(v68.carriage.vehicle.rootNode, v160, v161, v162, 0, 1, 0)
			local v163, v164, v165 = getWorldRotation(v68.carriage.vehicle.rootNode)
			if v68.carriage.vehicle.isAddedToPhysics then
				v68.carriage.vehicle:setWorldPosition(v144, v145 - v148, v146, v163, v164, v165, 1, false)
			else
				v68.carriage.vehicle:setAbsolutePosition(v144, v145 - v148, v146, v163, v164, v165)
				v68.carriage.vehicle:addToPhysics()
				v68.carriage.vehicle:addWearAmount(p66:getWearTotalAmount(), true)
				v68.carriage.vehicle:setDamageAmount(p66:getDamageAmount(), true)
				v68.carriage.vehicle:addDirtAmount(p66:getDirtAmount(), true)
			end
			v68.carriage.vehicle:raiseActive()
		end
		if v68.carriage.vehicle ~= nil and v68.carriage.vehicle.getCarriagePullRopeTargetNode ~= nil then
			local v166 = v68.carriage.vehicle:getCarriagePullRopeTargetNode()
			if v166 ~= nil then
				local v167, v168, v169 = getWorldTranslation(v166)
				local v170 = p66:updateYarderRope(v68.pullRope, v167, v168, v169, p67)
				v68.carriage.vehicle:updateRopeAlignmentNodes(v68.pullRope.ropeNode, v167, v168, v169, v170)
				local v171, _ = v68.carriage.vehicle:getCarriageDimensions()
				local v172 = MathUtil.vector3Length(v103 - v100, v104 - v101, v105 - v102)
				local v173 = (v171 + 0.025) / v172 * 0.5
				local v174 = v68.carriage.startOffset / v172 + v173
				local v175 = v68.carriage.endOffset / v172 + v173
				local v176, v177, v178 = getWorldTranslation(v68.carriage.vehicle.rootNode)
				local _, _, v179 = worldToLocal(v68.mainRope.ropeNode, v176, v177, v178)
				local v180 = (v179 / v172 - v174) / (1 - (v174 + v175))
				local v181 = math.clamp(v180, 0, 1)
				local v182 = v68.carriage
				local v183 = (v68.carriage.lastPosition - v181) / p67 * v172
				v182.lastSpeed = math.abs(v183) / v68.carriage.maxSpeed
				local v184 = v181 - v68.carriage.lastPosition
				if math.abs(v184) * v172 > 0.005 then
					if v68.carriage.lastPosition < v181 then
						if not g_soundManager:getIsSamplePlaying(v68.samples.carriageMovePos) then
							g_soundManager:playSample(v68.samples.carriageMovePos)
							g_soundManager:playSample(v68.samples.carriageDriveMovePos)
							g_soundManager:stopSample(v68.samples.carriageMoveNeg)
							g_soundManager:stopSample(v68.samples.carriageDriveMoveNeg)
						end
					elseif not g_soundManager:getIsSamplePlaying(v68.samples.carriageMoveNeg) then
						g_soundManager:playSample(v68.samples.carriageMoveNeg)
						g_soundManager:playSample(v68.samples.carriageDriveMoveNeg)
						g_soundManager:stopSample(v68.samples.carriageMovePos)
						g_soundManager:stopSample(v68.samples.carriageDriveMovePos)
					end
					if v181 == 1 then
						g_soundManager:playSample(v68.samples.carriageMovePosLimit)
						g_soundManager:playSample(v68.samples.carriageDriveMovePosLimit)
					elseif v181 == 0 then
						g_soundManager:playSample(v68.samples.carriageMoveNegLimit)
						g_soundManager:playSample(v68.samples.carriageDriveMoveNegLimit)
					end
					v68.carriage.lastPosition = v181
					v68.carriage.lastPositionTimeOffset = 250
					if v68.samples.carriageMovePos ~= nil then
						setWorldTranslation(v68.samples.carriageMovePos.soundNode, v176, v177, v178)
					end
					if v68.samples.carriageMoveNeg ~= nil then
						setWorldTranslation(v68.samples.carriageMoveNeg.soundNode, v176, v177, v178)
					end
					if v68.samples.carriageMovePosLimit ~= nil then
						setWorldTranslation(v68.samples.carriageMovePosLimit.soundNode, v176, v177, v178)
					end
					if v68.samples.carriageMoveNegLimit ~= nil then
						setWorldTranslation(v68.samples.carriageMoveNegLimit.soundNode, v176, v177, v178)
					end
					v68.controlActivatable:updateActionEventTexts()
				elseif v68.carriage.lastPositionTimeOffset > 0 then
					v68.carriage.lastPositionTimeOffset = v68.carriage.lastPositionTimeOffset - p67
					if v68.carriage.lastPositionTimeOffset <= 0 then
						g_soundManager:stopSample(v68.samples.carriageMovePos)
						g_soundManager:stopSample(v68.samples.carriageDriveMovePos)
						g_soundManager:stopSample(v68.samples.carriageMoveNeg)
						g_soundManager:stopSample(v68.samples.carriageDriveMoveNeg)
					end
				end
			end
			if v68.pushRope.isActive ~= nil then
				local v185 = v68.carriage.vehicle:getCarriagePushRopeTargetNode()
				if v185 ~= nil then
					v68.pushRope.hookData:setTargetNode(v185, false)
					setWorldTranslation(v68.pushRope.ropeNode, v68.pushRope.hookData:getRopeTargetPosition())
					local v186, v187, v188 = getWorldTranslation(v185)
					p66:updateYarderRope(v68.pushRope, v186, v187, v188, p67)
				end
			end
			local v189, _ = p66:getIsPlayerInYarderControlRange()
			if v189 then
				v68.carriage.vehicle:updateCarriageInRange(p67)
				if v68.hudExtension ~= nil then
					g_currentMission.hud:addInfoExtension(v68.hudExtension)
				end
			elseif v68.carriage.lastPlayerInRange then
				v68.carriage.vehicle:onYarderCarriageUpdateEnd()
			end
			v68.carriage.lastPlayerInRange = v189
		end
		local _ = v68.updateRopesDirtyTime > 0
		v68.updateRopesDirtyTime = v68.updateRopesDirtyTime - p67
		p66:updateYarderRope(v68.mainRope, v103, v104, v105, p67)
		for v190 = 1, #v68.supportRopes.ropes do
			local v191 = v68.supportRopes.ropes[v190]
			if v191.isActive then
				p66:updateYarderRope(v191, v191.target[1], v191.target[2], v191.target[3], p67)
			end
		end
		if v68.carriage.vehicle ~= nil then
			if not g_soundManager:getIsSamplePlaying(v68.samples.motor) then
				g_soundManager:playSample(v68.samples.motor)
				v68.lastMotorRpm = 0
				g_effectManager:startEffects(v68.motorEffects)
			end
			if v68.carriage.lastPositionTimeOffset > 0 then
				v68.lastMotorPowerTimeOffset = 10000
			else
				local v192 = v68.lastMotorPowerTimeOffset - p67
				v68.lastMotorPowerTimeOffset = math.max(v192, 0)
			end
			local v193 = 0.33 * v68.carriage.lastSpeed
			local v194 = v68.lastMotorPowerTimeOffset <= 0 and 0 or 0.5 + v68.carriage.lastSpeed * 0.5
			v68.lastMotorRpm = v68.lastMotorRpm * 0.975 + v194 * 0.025
			local v195 = v193 + v68.carriage.vehicle:getNumAttachedTrees() / v68.carriage.vehicle:getMaxNumAttachedTrees() * v68.carriage.lastSpeed * (1 - v193)
			g_soundManager:setSampleLoopSynthesisParameters(v68.samples.motor, v68.lastMotorRpm, v195)
			g_effectManager:setDensity(v68.motorEffects, v68.lastMotorRpm)
		end
		p66:raiseActive()
	end
end
function YarderTower.onYarderCarriageTreeAttached(p196, _)
	local v197 = p196.spec_yarderTower
	v197.carriage.followModePickupPosition = v197.carriage.lastPosition
	v197.controlActivatable:updateActionEventTexts()
end
function YarderTower.onPostAttach(p198, _, _, _, _)
	local v199 = p198.rootVehicle
	if v199.registerPlayerVehicleControlAllowedFunction ~= nil then
		v199:registerPlayerVehicleControlAllowedFunction(p198, YarderTower.getIsVehicleControlAllowed)
	end
end
function YarderTower.onHookI3DLoaded(_, p200, _, p201)
	if p200 ~= 0 then
		local v202 = getChildAt(p200, 0)
		link(getRootNode(), v202)
		setVisibility(v202, false)
		p201.hookNode = v202
		delete(p200)
	end
end
function YarderTower.onRopeI3DLoaded(p203, p204, _, p205)
	if p204 ~= 0 then
		local v206 = I3DUtil.indexToObject(p204, p205.ropeNodePath)
		if v206 ~= nil then
			link(p205.node or p203.rootNode, v206)
			setVisibility(v206, false)
			p205.ropeNode = v206
		end
		delete(p204)
	end
end
function YarderTower.getIsSetupModeChangeAllowed(p207)
	local v208 = p207.spec_yarderTower
	if v208.setupModeState then
		return true
	end
	if v208.requiresLowering and not p207:getIsLowered() then
		return false, string.format(v208.texts.warningLowerFirst, p207:getName())
	end
	if p207.getFoldAnimTime ~= nil then
		local v209 = p207:getFoldAnimTime()
		if v209 < v208.foldMinLimit or v208.foldMaxLimit < v209 then
			return false, string.format(v208.texts.warningUnfoldFirst, p207:getName())
		end
	end
	return true
end
function YarderTower.setYarderSetupModeState(p210, p211, p212)
	local v213 = p210.spec_yarderTower
	if p211 == nil then
		p211 = not v213.setupModeState
	end
	v213.setupModeState = p211
	if p211 then
		g_soundManager:playSample(v213.samples.setupStarted)
		p210:setYarderTargetActive(false)
		p210:setYarderRopeState(v213.setupRope, true)
		p210:raiseActive()
	else
		p210:setYarderRopeState(v213.setupRope, false)
		if not p210.spec_yarderTower.isPlayerInRange then
			g_currentMission.activatableObjectsSystem:removeActivatable(v213.setupActivatable)
		end
		if p212 then
			g_soundManager:playSample(v213.samples.setupCanceled)
		end
	end
end
function YarderTower.setYarderTargetActive(p214, p215, p216)
	local v217 = p214.spec_yarderTower
	if p215 then
		if v217.mainRope.isValid then
			local v218 = v217.mainRope.target[1]
			local v219 = v217.mainRope.target[2]
			local v220 = v217.mainRope.target[3]
			local v221 = p214:getTreeAtPosition(v218, v219, v220, 3)
			if v221 ~= nil and v221 ~= 0 then
				local v222, v223, v224 = getWorldTranslation(v217.mainRope.node)
				v217.mainRope.hookData = v217.hooks.treeData:clone()
				local v225, v226, v227 = v217.mainRope.hookData:mountToTree(v221, v218, v219, v220, 4, v222, v223, v224)
				if v225 == nil then
					return
				end
				v217.mainRope.hookData:setTargetNode(v217.mainRope.node, false)
				local v228 = v217.mainRope.target
				local v229 = v217.mainRope.target
				local v230 = v217.mainRope.target
				local v231, v232, v233 = v217.mainRope.hookData:getRopeTargetPosition()
				v228[1] = v231
				v229[2] = v232
				v230[3] = v233
				if v217.mainRope.sampleRopeLinkTree ~= nil then
					setWorldTranslation(v217.mainRope.sampleRopeLinkTree.soundNode, v225, v226, v227)
					g_soundManager:playSample(v217.mainRope.sampleRopeLinkTree)
				end
				v217.mainRope.isActive = true
				v217.mainRope.treeId = v221
				if v217.pushRope.ropeNode ~= nil then
					v217.pushRope.hookData = v217.hooks.treeData:clone()
					v217.pushRope.hookData:mountToTree(v221, v218, v219 - v217.pushRope.yOffset, v220, 4, v222, v223 - v217.pushRope.yOffset, v224)
					p214:setYarderRopeState(v217.pushRope, true)
				end
				g_splitShapeManager:addActiveYarder(p214)
				g_soundManager:playSample(v217.samples.setupFinished)
				p214:raiseActive()
				p214:setYarderSetupModeState(false, false)
				p214:setupSupportRopes()
				if p214.isServer then
					if v217.carriage.filename == nil then
						Logging.error("Carriage vehicle could not be loaded")
					else
						local v234 = MathUtil.getYRotationFromDirection(MathUtil.vector2Normalize(v218 - v222, v220 - v224))
						local v235 = VehicleLoadingData.new()
						v235:setFilename(v217.carriage.filename)
						v235:setPosition(v217.mainRope.target[1], v217.mainRope.target[2], v217.mainRope.target[3])
						v235:setRotation(0, v234, 0)
						v235:setPropertyState(VehiclePropertyState.OWNED)
						v235:setOwnerFarmId(p214:getOwnerFarmId())
						v235:load(p214.onCreateCarriageFinished, p214)
					end
					for v236 = 1, #p214.components do
						local v237 = p214.components[v236]
						setRigidBodyType(v237.node, RigidBodyType.KINEMATIC)
						v237.isDynamic = false
						v237.isKinematic = true
					end
				end
				v217.updateRopesDirtyTime = 500
				g_currentMission.activatableObjectsSystem:addActivatable(v217.controlActivatable)
				YarderTowerSetTargetEvent.sendEvent(p214, true, v225, v226, v227, p216)
			end
		end
		v217.treeRaycast.hasStarted = false
		v217.treeRaycast.lastValidTree = nil
	else
		if p214.isClient and v217.mainRope.isActive then
			g_soundManager:playSample(v217.samples.removeYarder)
			if g_soundManager:getIsSamplePlaying(v217.samples.motor) then
				g_soundManager:stopSample(v217.samples.motor)
				g_effectManager:stopEffects(v217.motorEffects)
			end
		end
		v217.mainRope.isValid = false
		v217.mainRope.isActive = false
		v217.mainRope.treeId = nil
		if not g_currentMission.isExitingGame then
			g_splitShapeManager:removeActiveYarder(p214)
		end
		for v238 = 1, #v217.supportRopes.ropes do
			local v239 = v217.supportRopes.ropes[v238]
			p214:setYarderRopeState(v239, false)
			v239.treeId = nil
		end
		p214:setYarderRopeState(v217.pushRope, false)
		if v217.carriage.vehicle ~= nil then
			if p214.isServer then
				v217.carriage.vehicle:setYarderTowerVehicle(nil)
				v217.carriage.vehicle:delete()
			end
			v217.carriage.vehicle = nil
			v217.carriage.lastPlayerInRange = false
		end
		v217.carriage.position = 0
		g_currentMission.activatableObjectsSystem:removeActivatable(v217.controlActivatable)
		if p214.isServer then
			for v240 = 1, #p214.components do
				local v241 = p214.components[v240]
				setRigidBodyType(v241.node, RigidBodyType.DYNAMIC)
				v241.isDynamic = true
				v241.isKinematic = false
			end
		end
		YarderTowerSetTargetEvent.sendEvent(p214, false, 0, 0, 0, p216)
	end
	p214:setYarderRopeState(v217.mainRope, v217.mainRope.isActive)
	p214:setYarderRopeState(v217.pullRope, v217.mainRope.isActive)
end
function YarderTower.setYarderCarriageFollowMode(p242, p243, p244, p245)
	local v246 = p242.spec_yarderTower
	if p243 == nil then
		p243 = YarderTower.FOLLOW_MODE_NONE
	end
	v246.carriage.followModeState = p243
	if p243 == YarderTower.FOLLOW_MODE_ME then
		if p242.isServer then
			if p244 == nil then
				v246.carriage.followModePlayer = g_localPlayer
				v246.carriage.followModePlayer:addDeleteListener(p242, "onYarderTowerPlayerDeleted")
			else
				for _, v247 in pairs(g_currentMission.playerSystem.players) do
					if v247.connection == p244 then
						v246.carriage.followModePlayer = v247
						v246.carriage.followModePlayer:addDeleteListener(p242, "onYarderTowerPlayerDeleted")
					end
				end
			end
		end
		if p244 == nil then
			v246.carriage.followModeLocalPlayer = true
		end
	else
		if v246.carriage.followModePlayer ~= nil then
			v246.carriage.followModePlayer:removeDeleteListener(p242, "onYarderTowerPlayerDeleted")
		end
		v246.carriage.followModePlayer = nil
		v246.carriage.followModeLocalPlayer = false
	end
	YarderTowerFollowModeEvent.sendEvent(p242, p243, p245)
	v246.controlActivatable:updateActionEventTexts()
end
function YarderTower.setYarderCarriageMoveInput(p248, p249)
	local v250 = p248.spec_yarderTower
	if p249 ~= 0 and v250.carriage.followModeState ~= YarderTower.FOLLOW_MODE_NONE then
		p248:setYarderCarriageFollowMode(YarderTower.FOLLOW_MODE_NONE)
	end
	v250.carriage.lastMoveInput = p249 or 0
	v250.carriage.lastMoveInputTime = g_time
	if v250.carriage.lastMoveInput ~= 0 then
		p248:raiseDirtyFlags(v250.dirtyFlag)
	end
end
function YarderTower.setYarderCarriageLiftInput(p251, p252)
	local v253 = p251.spec_yarderTower
	v253.carriage.lastLiftInput = p252 or 0
	v253.carriage.lastLiftInputTime = g_time
	if v253.carriage.lastLiftInput ~= 0 then
		p251:raiseDirtyFlags(v253.dirtyFlag)
	end
end
function YarderTower.onYarderCarriageAttach(p254)
	p254.spec_yarderTower.carriage.vehicle:onAttachTreeAction()
end
function YarderTower.onYarderCarriageDetach(p255)
	p255.spec_yarderTower.carriage.vehicle:onDetachTreeAction()
end
function YarderTower.setupSupportRopes(p_u_256)
	local v_u_257 = p_u_256.spec_yarderTower
	local v258, v259, v260 = getWorldTranslation(v_u_257.supportRopes.centerNode)
	for v261 = 1, #v_u_257.supportRopes.ropes do
		p_u_256:setYarderRopeState(v_u_257.supportRopes.ropes[v261], false)
	end
	for v262 = #v_u_257.supportRopes.foundTrees, 1, -1 do
		v_u_257.supportRopes.foundTrees[v262] = nil
	end
	overlapSphere(v258, v259, v260, v_u_257.supportRopes.treeRadius, "onSupportRopeTreeOverlapCallback", p_u_256, CollisionFlag.TREE, false, false, true, false)
	local function v278(p263, p264)
		-- upvalues: (copy) v_u_257
		local v265 = (1 / 0)
		local v266 = nil
		for v267 = 1, #v_u_257.supportRopes.foundTrees do
			local v268 = v_u_257.supportRopes.foundTrees[v267]
			local v269, v270, v271 = getWorldTranslation(v268)
			local v272, _, v273 = MathUtil.vector3Normalize(worldToLocal(p263, v269, v270, v271))
			local v274, v275 = MathUtil.vector2Normalize(v272, v273)
			local v276 = MathUtil.getYRotationFromDirection(v274, v275)
			local v277 = math.abs(v276)
			if v277 < p264 and v277 < v265 then
				v266 = v268
				v265 = v277
			end
		end
		return v266, v265
	end
	local v279 = {}
	local function v302(p280, p281)
		-- upvalues: (copy) v_u_257, (copy) p_u_256
		for v282 = 1, #v_u_257.supportRopes.foundTrees do
			local v283 = v_u_257.supportRopes.foundTrees[v282]
			if v283 == p281 then
				local v284, v285, v286 = getWorldTranslation(v283)
				local v287 = getTerrainHeightAtWorldPos
				local v288 = g_terrainNode
				local v289 = math.max(v285, v287(v288, v284, 0, v286))
				local v290, v291, v292, _, _, _, _ = SplitShapeUtil.getTreeOffsetPosition(v283, v284, v289 + p280.treeYOffset, v286, 3)
				if v290 ~= nil then
					p_u_256:setYarderRopeState(p280, true)
					local v293, v294, v295 = getWorldTranslation(p280.node)
					p280.hookData = v_u_257.hooks.treeData:clone()
					p280.hookData:mountToTree(v283, v290, v291, v292, 4, v293, v294, v295)
					p280.hookData:setTargetNode(v_u_257.mainRope.node, false)
					p280.treeId = v283
					local v296 = p280.target
					local v297 = p280.target
					local v298 = p280.target
					local v299, v300, v301 = p280.hookData:getRopeTargetPosition()
					v296[1] = v299
					v297[2] = v300
					v298[3] = v301
					if p280.sampleRopeLinkTree ~= nil then
						setWorldTranslation(p280.sampleRopeLinkTree.soundNode, v290, v291, v292)
						g_soundManager:playSample(p280.sampleRopeLinkTree)
					end
					table.remove(v_u_257.supportRopes.foundTrees, v282)
					return true
				end
			end
		end
		return false
	end
	for v303 = 1, #v_u_257.supportRopes.ropes do
		local v304 = v_u_257.supportRopes.ropes[v303]
		local v305, v306 = v278(v304.angleReferenceNode, v304.maxAngle)
		if v305 ~= nil then
			table.insert(v279, {
				["supportRope"] = v304,
				["treeId"] = v305,
				["angle"] = v306
			})
		end
	end
	table.sort(v279, function(p307, p308)
		return p307.angle > p308.angle
	end)
	local v309 = {}
	for v310 = #v279, 1, -1 do
		local v311 = v279[v310]
		if v309[v311.treeId] == nil and v302(v311.supportRope, v311.treeId) then
			v309[v311.treeId] = true
			table.remove(v279, v310)
		end
	end
	for v312 = 1, #v279 do
		local v313 = v279[v312]
		local v314, _ = v278(v313.supportRope.angleReferenceNode, v313.supportRope.maxAngle)
		if v314 ~= nil then
			v302(v313.supportRope, v314)
		end
	end
	for v315 = 1, #v_u_257.supportRopes.ropes do
		local v316 = v_u_257.supportRopes.ropes[v315]
		if not v316.isActive then
			if v316.rotNode ~= nil and v316.raycastRotY ~= nil then
				local v317, _, v318 = getRotation(v316.rotNode)
				setRotation(v316.rotNode, v317, v316.raycastRotY, v318)
				if p_u_256.setMovingToolDirty ~= nil then
					p_u_256:setMovingToolDirty(v316.rotNode)
				end
			end
			local v319, v320, v321 = getWorldTranslation(v316.raycastNode)
			local v322, v323, v324 = localToWorld(v316.raycastNode, 0, 0, YarderTower.TERRAIN_RAYCAST_DISTANCE)
			local v325 = getTerrainHeightAtWorldPos(g_terrainNode, v322, 0, v324) - 0.25
			local v326 = math.min(v323, v325)
			local v327 = v322 - v319
			local v328 = v326 - v320
			local v329 = v324 - v321
			local v330 = MathUtil.vector3Length(v327, v328, v329)
			local v331, v332, v333 = MathUtil.vector3Normalize(v327, v328, v329)
			raycastClosestAsync(v319, v320, v321, v331, v332, v333, v330, "onYarderSupportTerrainRaycastCallback", v316, YarderTower.GROUND_COLLISION_MASK)
		end
	end
end
function YarderTower.onCreateCarriageFinished(p334, p335, p336, _)
	local v337 = p334.spec_yarderTower
	if #p335 == 1 and p336 == VehicleLoadingState.OK then
		local v338 = p335[1]
		v337.carriage.vehicle = v338
		v338:addDeleteListener(p334, "onCarriageVehicleDeleted")
		v338:setYarderTowerVehicle(p334)
		v338:removeFromPhysics()
	else
		Logging.error("Failed to load yarder carriage \'%s\'", v337.carriage.filename)
	end
end
function YarderTower.onCarriageVehicleDeleted(p339, _, _)
	local v340 = p339.spec_yarderTower
	v340.carriage.vehicle = nil
	v340.carriage.lastPlayerInRange = nil
end
function YarderTower.setYarderRopeState(p341, p342, p343)
	p342.isActive = p343
	if p342.ropeNode ~= nil then
		setVisibility(p342.ropeNode, p343)
	end
	if p342.rotNode ~= nil and not p343 then
		local v344 = setRotation
		local v345 = p342.rotNode
		local v346 = p342.rotNodeInitRot
		v344(v345, unpack(v346))
		if p341.setMovingToolDirty ~= nil then
			p341:setMovingToolDirty(p342.rotNode)
		end
	end
	if not p343 then
		if p342.hookData ~= nil then
			p342.hookData:delete()
			p342.hookData = nil
		end
		p341:updateYarderRopeLengthNodes(p342, 0)
	end
	ObjectChangeUtil.setObjectChanges(p342.changeObjects, p343, p341, p341.setMovingToolDirty)
end
function YarderTower.updateYarderRope(p347, p348, p349, p350, p351, _, _, _)
	local v352, v353, v354 = getWorldTranslation(p348.node or p348.ropeNode)
	local v355 = MathUtil.vector3Length(p349 - v352, p350 - v353, p351 - v354)
	local v356 = p348.maxOffset or 0
	local v357 = v355 / (p348.offsetReferenceLength or 0)
	local v358 = v356 * math.min(v357, 1)
	if v355 ~= p348.lastTotalRopeLength then
		local v359, v360, v361 = MathUtil.vector3Normalize(p349 - v352, p350 - v353, p351 - v354)
		if p348.rotNode ~= nil then
			local v362, v363, v364 = worldDirectionToLocal(getParent(p348.rotNode), v359, v360, v361)
			if p348.rotNodeAllAxis then
				local v365, v366, v367 = MathUtil.vector3Normalize(v362, v363, v364)
				setDirection(p348.rotNode, v365, v366, v367, 0, 1, 0)
			else
				local v368, v369 = MathUtil.vector2Normalize(v362, v364)
				setDirection(p348.rotNode, v368, 0, v369, 0, 1, 0)
			end
			if p347.setMovingToolDirty ~= nil then
				p347:setMovingToolDirty(p348.rotNode)
			end
		end
		if p348.ropeNode ~= nil then
			local v370, v371, v372 = worldDirectionToLocal(getParent(p348.ropeNode), v359, v360, v361)
			setDirection(p348.ropeNode, v370, v371, v372, 0, 1, 0)
			g_animationManager:setPrevShaderParameter(p348.ropeNode, "ropeLengthBendSizeUv", v355, -v358, p348.diameter, 4, false, "prevRopeLengthBendSizeUv")
			local v373 = math.ceil(v355)
			local v374 = math.max(v373, 1) * 0.5
			if math.ceil(v374) ~= p348.boundingRadius then
				setShapeBoundingSphere(p348.ropeNode, 0, 0, v374, v374)
				p348.boundingRadius = v374
			end
		end
		p347:updateYarderRopeLengthNodes(p348, v355)
		p348.lastTotalRopeLength = v355
	end
	return v358
end
function YarderTower.updateYarderRopeLengthNodes(_, p375, p376)
	if p375.ropeLengthNodes ~= nil then
		for v377 = 1, #p375.ropeLengthNodes do
			local v378 = p375.ropeLengthNodes[v377]
			local v379 = MathUtil.inverseLerp(v378.minLength, v378.maxLength, p376)
			if v378.minRot ~= nil and v378.maxRot ~= nil then
				local v380, v381, v382 = MathUtil.vector3ArrayLerp(v378.minRot, v378.maxRot, v379)
				setRotation(v378.node, v380, v381, v382)
			end
			if v378.minTrans ~= nil and v378.maxTrans ~= nil then
				local v383, v384, v385 = MathUtil.vector3ArrayLerp(v378.minTrans, v378.maxTrans, v379)
				setTranslation(v378.node, v383, v384, v385)
			end
			if v378.minScale ~= nil and v378.maxScale ~= nil then
				local v386, v387, v388 = MathUtil.vector3ArrayLerp(v378.minScale, v378.maxScale, v379)
				setScale(v378.node, v386, v387, v388)
			end
			if v378.shaderParameterName ~= nil and (v378.minShaderParameter ~= nil and v378.maxShaderParameter ~= nil) then
				setShaderParameter(v378.node, v378.shaderParameterName, MathUtil.lerp(v378.minShaderParameter[1], v378.maxShaderParameter[1], v379), MathUtil.lerp(v378.minShaderParameter[2], v378.maxShaderParameter[2], v379), MathUtil.lerp(v378.minShaderParameter[3], v378.maxShaderParameter[3], v379), MathUtil.lerp(v378.minShaderParameter[4], v378.maxShaderParameter[4], v379), false)
			end
		end
	end
end
function YarderTower.getTreeAtPosition(_, p389, p390, p391, p392)
	local v393 = p389 - p392 * 0.5
	local v394 = p391 - p392 * 0.5
	local v395, _, _, _, _ = findSplitShape(v393, p390, v394, 0, 1, 0, 0, 0, 1, p392, p392)
	return v395
end
function YarderTower.getIsPlayerInYarderRange(p396)
	local v397 = p396.spec_yarderTower
	if p396:getOwnerFarmId() == g_currentMission:getFarmId() then
		return v397.isPlayerInRange or v397.setupModeState
	else
		return false
	end
end
function YarderTower.getIsPlayerInYarderControlRange(p398, p399, p400, p401)
	local v402 = p398.spec_yarderTower
	if v402.isPlayerInRange then
		return false, (1 / 0)
	end
	if p399 == nil then
		if g_localPlayer == nil then
			return false
		end
		p399, p400, p401 = getWorldTranslation(g_localPlayer.rootNode)
	end
	if p398:getOwnerFarmId() ~= g_currentMission:getFarmId() then
		return false
	end
	local v403, _, v404 = getWorldTranslation(v402.mainRope.node)
	local v405 = v402.mainRope.target[1]
	local v406 = v402.mainRope.target[3]
	local v407, _, v408 = MathUtil.getClosestPointOnLineSegment(v403, 0, v404, v405, 0, v406, p399, p400, p401)
	local v409 = MathUtil.vector2Length(p399 - v407, p401 - v408)
	return v409 < YarderTower.MAX_CONTROL_DISTANCE, v409
end
function YarderTower.getYarderIsSetUp(p410)
	return p410.spec_yarderTower.carriage.vehicle ~= nil
end
function YarderTower.getYarderStatusInfo(p411)
	local v412 = p411.spec_yarderTower
	local v413
	if v412.carriage.vehicle == nil then
		v413 = false
	else
		v413 = #v412.carriage.vehicle.spec_yarderCarriage.attachedTrees > 0
	end
	local v414 = nil
	if v412.carriage.followModeState == YarderTower.FOLLOW_MODE_HOME then
		v414 = 0
	elseif v412.carriage.followModeState == YarderTower.FOLLOW_MODE_PICKUP then
		v414 = v412.carriage.followModePickupPosition
	end
	if g_localPlayer == nil or not g_localPlayer.isControlled then
		return false, v413, 0, v412.carriage.lastPosition, v412.carriage.followModeState, v412.carriage.followModeLocalPlayer, v414
	end
	local v415, v416, v417 = getWorldTranslation(g_localPlayer.rootNode)
	local v418, _, v419 = getWorldTranslation(v412.mainRope.node)
	local v420 = v412.mainRope.target[1]
	local v421 = v412.mainRope.target[3]
	local _, _, _, v422 = MathUtil.getClosestPointOnLineSegment(v418, 0, v419, v420, 0, v421, v415, v416, v417)
	return true, v413, v422, v412.carriage.lastPosition, v412.carriage.followModeState, v412.carriage.followModeLocalPlayer, v414
end
function YarderTower.getYarderMainRopeLength(p423)
	local v424 = p423.spec_yarderTower
	if not v424.mainRope.isValid then
		return 0
	end
	local v425, v426, v427 = getWorldTranslation(v424.mainRope.node)
	local v428 = v424.mainRope.target[1]
	local v429 = v424.mainRope.target[2]
	local v430 = v424.mainRope.target[3]
	return MathUtil.vector3Length(v428 - v425, v429 - v426, v430 - v427)
end
function YarderTower.getYarderCarriageLastSpeed(p431)
	return p431.spec_yarderTower.carriage.lastSpeed
end
g_soundManager:registerModifierType("CARRIAGE_SPEED", YarderTower.getYarderCarriageLastSpeed)
function YarderTower.getIsTreeShapeUsedForYarderSetup(p432, p433)
	local v434 = p432.spec_yarderTower
	if p433 == v434.mainRope.treeId then
		return true
	end
	for v435 = 1, #v434.supportRopes.ropes do
		if v434.supportRopes.ropes[v435].treeId == p433 then
			return true
		end
	end
	return false
end
function YarderTower.onYarderControlTriggerCallback(p436, _, p437, p438, p439, _)
	if (p438 or p439) and (g_localPlayer ~= nil and p437 == g_localPlayer.rootNode) then
		local v440 = p436.spec_yarderTower
		if p438 then
			p436.spec_yarderTower.isPlayerInRange = true
			g_currentMission.activatableObjectsSystem:addActivatable(v440.setupActivatable)
			return
		end
		p436.spec_yarderTower.isPlayerInRange = false
		if not v440.setupModeState then
			g_currentMission.activatableObjectsSystem:removeActivatable(v440.setupActivatable)
		end
	end
end
function YarderTower.onYarderTreeRaycastCallback(p441, p442, _, p443, _, _, _, _, _, _, _, p444)
	local v445 = p441.spec_yarderTower
	if p442 ~= 0 and (getHasClassId(p442, ClassIds.SHAPE) and (getSplitType(p442) ~= 0 and not getIsSplitShapeSplit(p442))) then
		if p444 then
			v445.treeRaycast.hasStarted = false
			v445.treeRaycast.lastValidTree = p442
			v445.treeRaycast.lastValidTreeHeight = p443
		end
		return false
	end
	if p444 then
		v445.treeRaycast.hasStarted = false
		v445.treeRaycast.lastValidTree = nil
	end
end
function YarderTower.doRopePlacementValidation(p446, p447, p448, p449, p450, p451, p452, p453, _, p454, p455)
	if not p455.hasStarted then
		local v456, v457, v458 = getWorldTranslation(p447)
		if v457 + p446.spec_yarderTower.placementMinHeightOffset < p450 then
			return p455.callback(p455.vehicle, false, p449, p450, p451, YarderTower.FAILED_REASON_ONLY_UPHILL_YARDING)
		end
		local v459, v460 = MathUtil.vector2Normalize(v456 - p449, v458 - p451)
		local v461, _, v462 = worldDirectionToLocal(p447, v459, 0, v460)
		local v463 = MathUtil.getYRotationFromDirection(v461, v462)
		local v464 = 3.141592653589793 - math.abs(v463)
		local v465, v466, v467, _, _, _, v468 = SplitShapeUtil.getTreeOffsetPosition(p448, p449, p450, p451, 3)
		if v465 ~= nil and p454 <= v468 * 2 then
			local v469, v470 = MathUtil.vector2Normalize(v456 - v465, v458 - v467)
			local v471 = v465 + v469 * v468
			local v472 = v467 + v470 * v468
			if v464 < p452 then
				local v473 = MathUtil.vector3Length(v471 - v456, v466 - v457, v472 - v458)
				if v473 < p453 then
					local v474, v475, v476 = MathUtil.vector3Normalize(v471 - v456, v466 - v457, v472 - v458)
					p455.x = v471
					p455.y = v466
					p455.z = v472
					p455.hasStarted = true
					p455.onYarderMainTreeRaycastCallback = YarderTower.onYarderMainTreeRaycastCallback
					raycastClosestAsync(v456, v457 - 2, v458, v474, v475, v476, v473 - 0.5, "onYarderMainTreeRaycastCallback", p455, YarderTower.GROUND_COLLISION_MASK)
				else
					p455.callback(p455.vehicle, false, v471, v466, v472, YarderTower.FAILED_REASON_TOO_LONG)
				end
			else
				p455.callback(p455.vehicle, false, v471, v466, v472, YarderTower.FAILED_REASON_WRONG_ANGLE)
				return
			end
		end
		p455.callback(p455.vehicle, false, p449, p450, p451, YarderTower.FAILED_REASON_TREE_TOO_SMALL)
	end
end
function YarderTower.onYarderMainTreeRaycastCallback(p477, p478, _, _, _, _, _, _, _, _, _, p479)
	p477.hasStarted = false
	if p478 ~= 0 then
		return p477.callback(p477.vehicle, false, p477.x, p477.y, p477.z, YarderTower.FAILED_REASON_WAY_BLOCKED)
	end
	if p478 == 0 and p479 then
		return p477.callback(p477.vehicle, true, p477.x, p477.y, p477.z, YarderTower.FAILED_REASON_NONE)
	end
end
function YarderTower.onMainRopePlacementValidated(p480, p481, p482, p483, p484, p485)
	local v486 = p480.spec_yarderTower
	if v486.setupModeState then
		v486.mainRope.isValid = p481
		v486.mainRope.target[1] = p482
		v486.mainRope.target[2] = p483
		v486.mainRope.target[3] = p484
	end
	if not p481 then
		if p485 == YarderTower.FAILED_REASON_TOO_LONG then
			g_currentMission:showBlinkingWarning(v486.texts.warningRopeTooLong, 1000)
		elseif p485 == YarderTower.FAILED_REASON_WRONG_ANGLE then
			g_currentMission:showBlinkingWarning(v486.texts.warningWrongAngle, 1000)
		elseif p485 == YarderTower.FAILED_REASON_TREE_TOO_SMALL then
			g_currentMission:showBlinkingWarning(v486.texts.warningTreeTooSmall, 1000)
		elseif p485 == YarderTower.FAILED_REASON_WAY_BLOCKED then
			g_currentMission:showBlinkingWarning(v486.texts.warningWayIsBlocked, 1000)
		elseif p485 == YarderTower.FAILED_REASON_ONLY_UPHILL_YARDING then
			g_currentMission:showBlinkingWarning(v486.texts.warningOnlyForUphillYarding, 1000)
		end
	end
	v486.setupRope.diameter = v486.setupRope.diameterTree
end
function YarderTower.onYarderSupportTerrainRaycastCallback(p487, p488, p489, p490, p491, _, _, _, _, _, _, p492)
	if p488 ~= 0 and getHasClassId(p488, ClassIds.TERRAIN_TRANSFORM_GROUP) then
		p487.vehicle:setYarderRopeState(p487, true)
		local v493, _, v494 = getWorldTranslation(p487.node)
		p487.hookData = p487.vehicle.spec_yarderTower.hooks.groundData:clone()
		p487.hookData:setPositionAndDirection(p489, p490, p491, MathUtil.vector2Normalize(v493 - p489, v494 - p491))
		p487.hookData:setTargetNode(p487.node, false)
		local v495 = p487.target
		local v496 = p487.target
		local v497 = p487.target
		local v498, v499, v500 = p487.hookData:getRopeTargetPosition()
		v495[1] = v498
		v496[2] = v499
		v497[3] = v500
		if p487.sampleRopeLinkGround ~= nil then
			setWorldTranslation(p487.sampleRopeLinkGround.soundNode, p489, p490, p491)
			g_soundManager:playSample(p487.sampleRopeLinkGround)
		end
		return false
	end
	if p492 and not p487.isActive then
		p487.vehicle:setYarderRopeState(p487, false)
	end
end
function YarderTower.onSupportRopeTreeOverlapCallback(p501, p502, ...)
	local v503 = p501.spec_yarderTower
	if p502 ~= v503.mainRope.treeId then
		local v504 = v503.supportRopes.foundTrees
		table.insert(v504, p502)
	end
end
function YarderTower.onYarderTowerPlayerDeleted(p505)
	p505:setYarderCarriageFollowMode(YarderTower.FOLLOW_MODE_NONE)
end
function YarderTower.isDetachAllowed(p506, p507)
	local v508, v509, v510 = p507(p506)
	if v508 then
		local v511 = p506.spec_yarderTower
		if v511.requiresAttacherVehicle and v511.mainRope.isActive then
			return false, v511.texts.warningDetachNotAllowed
		else
			return true
		end
	else
		return v508, v509, v510
	end
end
function YarderTower.getIsFoldAllowed(p512, p513, p514, p515)
	if p512.spec_yarderTower.mainRope.isActive then
		return false
	else
		return p513(p512, p514, p515)
	end
end
function YarderTower.getAllowsLowering(p516, p517)
	if p516.spec_yarderTower.mainRope.isActive then
		return false
	else
		return p517(p516)
	end
end
function YarderTower.getDoConsumePtoPower(p518, p519)
	return p518.spec_yarderTower.mainRope.isActive and true or p519(p518)
end
function YarderTower.getConsumingLoad(p520, p521)
	local v522, v523 = p521(p520)
	local v524 = p520.spec_yarderTower
	return v522 + (not v524.mainRope.isActive and 0 or 0.05 + v524.carriage.lastSpeed * 0.95), v523 + 1
end
function YarderTower.getIsPowerTakeOffActive(p525, p526)
	if p525.spec_yarderTower.mainRope.isActive then
		local v527 = p525:getAttacherVehicle()
		if v527 ~= nil and (v527.getIsMotorStarted ~= nil and v527:getIsMotorStarted()) then
			return true
		end
	end
	return p526(p525)
end
function YarderTower.getDirtMultiplier(p528, p529)
	local v530 = p529(p528)
	local v531 = p528.spec_yarderTower
	if v531.mainRope.isActive then
		v530 = v530 + v531.carriage.lastSpeed * p528:getWorkDirtMultiplier()
	end
	return v530
end
function YarderTower.getWearMultiplier(p532, p533)
	local v534 = p533(p532)
	local v535 = p532.spec_yarderTower
	if v535.mainRope.isActive then
		v534 = v534 + v535.carriage.lastSpeed * p532:getWorkWearMultiplier()
	end
	return v534
end
function YarderTower.getUsageCausesDamage(p536, p537)
	local v538 = p536.spec_yarderTower
	if not v538.mainRope.isActive then
		return p537(p536)
	end
	local v539
	if v538.carriage.lastPositionTimeOffset > 0 then
		v539 = p536.propertyState ~= VehiclePropertyState.MISSION
	else
		v539 = false
	end
	return v539
end
function YarderTower.addToPhysics(p540, p541)
	if not p541(p540) then
		return false
	end
	if p540.spec_yarderTower.mainRope.isActive then
		for v542 = 1, #p540.components do
			local v543 = p540.components[v542]
			setRigidBodyType(v543.node, RigidBodyType.KINEMATIC)
			v543.isDynamic = false
			v543.isKinematic = true
		end
	end
	return true
end
function YarderTower.removeFromPhysics(p544, p545)
	if p544.spec_yarderTower.mainRope.isActive then
		for v546 = 1, #p544.components do
			local v547 = p544.components[v546]
			setRigidBodyType(v547.node, RigidBodyType.DYNAMIC)
			v547.isDynamic = true
			v547.isKinematic = false
		end
	end
	return p545(p544) and true or false
end
function YarderTower.getIsVehicleControlAllowed(p548)
	local v549 = p548.spec_yarderTower
	if v549.mainRope.isActive then
		return false, v549.texts.warningDoNotMoveVehicle
	else
		return true, nil
	end
end
function YarderTower.loadSpecValueMaxLength(p550, _, _)
	return p550:getValue("vehicle.yarderTower.ropes.mainRope#maxLength")
end
function YarderTower.getSpecValueMaxLength(p551, _, _, _, p552, p553)
	if p551.specs.yarderMaxLength ~= nil then
		local v554 = p551.specs.yarderMaxLength
		local v555 = string.format("%d%s", v554, g_i18n:getText("unit_mShort"))
		if p552 and p553 then
			return v554, v554, v555
		end
		if p552 then
			return v554, v555
		end
		if v554 ~= 0 then
			return v555
		end
	end
end
function YarderTower.loadSpecValueMaxMass(p556, _, _)
	return p556:getValue("vehicle.yarderTower.carriage#maxTreeMass")
end
function YarderTower.getSpecValueMaxMass(p557, _, _, _, p558, p559)
	if p557.specs.yarderMaxMass ~= nil then
		local v560 = p557.specs.yarderMaxMass
		local v561 = string.format("%.1f%s", v560, g_i18n:getText("unit_tonsShort"))
		if p558 and p559 then
			return v560, v560, v561
		end
		if p558 then
			return v560, v561
		end
		if v560 ~= 0 then
			return v561
		end
	end
end

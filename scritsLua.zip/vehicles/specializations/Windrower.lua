Windrower = {}
function Windrower.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("windrower", false, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Windrower")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.windrower.effects.effect(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.windrower.effects.effect(?).sounds", "work")
	v1:register(XMLValueType.INT, "vehicle.windrower.effects.effect(?)#workAreaIndex", "Work area index", 1)
	v1:register(XMLValueType.INT, "vehicle.windrower.effects.effect(?)#dropAreaIndex", "Drop area index (if defined the effect is only active if this drop area is set on workArea)")
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.windrower.animationNodes")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.windrower.sounds", "work")
	v1:register(XMLValueType.BOOL, "vehicle.windrower#limitToLineHeight", "Limit pickup to work area line height", false)
	v1:register(XMLValueType.STRING, "vehicle.windrower#fillTypeCategories", "Fill type categories")
	v1:register(XMLValueType.STRING, "vehicle.windrower#fillTypes", "List of supported fill types")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. ".windrower#particleSystemIndex", "Particle system index")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_KEY .. ".windrower#dropWindrowWorkAreaIndex", "Drop work area index", 1)
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".windrower#particleSystemIndex", "Particle system index")
	v1:register(XMLValueType.INT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. ".windrower#dropWindrowWorkAreaIndex", "Drop work area index", 1)
	v1:setXMLSpecializationType()
end
function Windrower.prerequisitesPresent(p2)
	return SpecializationUtil.hasSpecialization(WorkArea, p2)
end
function Windrower.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "processWindrowerArea", Windrower.processWindrowerArea)
	SpecializationUtil.registerFunction(p3, "processDropArea", Windrower.processDropArea)
end
function Windrower.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "doCheckSpeedLimit", Windrower.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadWorkAreaFromXML", Windrower.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p4, "getDirtMultiplier", Windrower.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p4, "getWearMultiplier", Windrower.getWearMultiplier)
end
function Windrower.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", Windrower)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", Windrower)
	SpecializationUtil.registerEventListener(p5, "onDelete", Windrower)
	SpecializationUtil.registerEventListener(p5, "onReadStream", Windrower)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", Windrower)
	SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", Windrower)
	SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", Windrower)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", Windrower)
	SpecializationUtil.registerEventListener(p5, "onTurnedOn", Windrower)
	SpecializationUtil.registerEventListener(p5, "onTurnedOff", Windrower)
	SpecializationUtil.registerEventListener(p5, "onStartWorkAreaProcessing", Windrower)
	SpecializationUtil.registerEventListener(p5, "onEndWorkAreaProcessing", Windrower)
	SpecializationUtil.registerEventListener(p5, "onAIFieldCourseSettingsInitialized", Windrower)
end
function Windrower.onLoad(p6, _)
	local v7 = p6.spec_windrower
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.animation", "vehicle.windrowers.windrower")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.windrowerParticleSystems", "vehicle.windrower.effects")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.windrower.animationNodes.animationNode", "windrower")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.windrowerSound", "vehicle.windrower.sounds.work")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.windrower.rakes.rake", "vehicle.windrower.animationNodes.animationNode with type \'RotationAnimationSpikes\'")
	if p6.isClient then
		v7.animationNodes = g_animationManager:loadAnimations(p6.xmlFile, "vehicle.windrower.animationNodes", p6.components, p6, p6.i3dMappings)
		v7.effects = {}
		v7.workAreaToEffects = {}
		local v8 = 0
		while true do
			local v9 = string.format("vehicle.windrower.effects.effect(%d)", v8)
			if not p6.xmlFile:hasProperty(v9) then
				break
			end
			local v10 = g_effectManager:loadEffect(p6.xmlFile, v9, p6.components, p6, p6.i3dMappings)
			if v10 ~= nil then
				local v11 = {
					["effects"] = v10,
					["workAreaIndex"] = p6.xmlFile:getValue(v9 .. "#workAreaIndex", 1),
					["dropAreaIndex"] = p6.xmlFile:getValue(v9 .. "#dropAreaIndex"),
					["activeTime"] = -1,
					["activeTimeDuration"] = 250,
					["isActive"] = false,
					["isActiveSent"] = false,
					["samples"] = {}
				}
				v11.samples.work = g_soundManager:loadSampleFromXML(p6.xmlFile, v9 .. ".sounds", "work", p6.baseDirectory, p6.components, 0, AudioGroup.VEHICLE, p6.i3dMappings, p6)
				local v12 = v7.effects
				table.insert(v12, v11)
				for v13 = 1, #v10 do
					if v10[v13].setWorkAreaIndex ~= nil then
						v10[v13]:setWorkAreaIndex(v11.workAreaIndex)
					end
				end
			end
			v8 = v8 + 1
		end
		v7.samples = {}
		v7.samples.work = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.windrower.sounds", "work", p6.baseDirectory, p6.components, 0, AudioGroup.VEHICLE, p6.i3dMappings, p6)
	end
	v7.isWorking = false
	v7.limitToLineHeight = p6.xmlFile:getValue("vehicle.windrower#limitToLineHeight", false)
	v7.stoneLastState = 0
	v7.stoneWearMultiplierData = g_currentMission.stoneSystem:getWearMultiplierByType("WINDROWER")
	v7.supportedFillTypes = g_fillTypeManager:getFillTypesFromXML(p6.xmlFile, "vehicle.windrower#fillTypeCategories", "vehicle.windrower#fillTypes", true)
	v7.fillTypesDirtyFlag = p6:getNextDirtyFlag()
	v7.effectDirtyFlag = p6:getNextDirtyFlag()
	if p6.addAIDensityHeightTypeRequirement ~= nil then
		for _, v14 in ipairs(v7.supportedFillTypes) do
			p6:addAIDensityHeightTypeRequirement(v14)
		end
	end
end
function Windrower.onPostLoad(p15, _)
	local v16 = p15.spec_windrower
	for v17 = #v16.effects, 1, -1 do
		local v18 = v16.effects[v17]
		local v19 = p15:getWorkAreaByIndex(v18.workAreaIndex)
		if v19 == nil then
			Logging.xmlWarning(p15.xmlFile, "Invalid workAreaIndex \'%d\' for effect \'vehicle.windrower.effects.effect(%d)\'!", v18.workAreaIndex, v17)
			local v20 = v16.effects
			table.insert(v20, v17)
		else
			v18.windrowerWorkAreaFillTypeIndex = v19.windrowerWorkAreaIndex
			if v16.workAreaToEffects[v19.index] == nil then
				v16.workAreaToEffects[v19.index] = {}
			end
			local v21 = v16.workAreaToEffects[v19.index]
			table.insert(v21, v18)
		end
	end
end
function Windrower.onDelete(p22)
	local v23 = p22.spec_windrower
	g_soundManager:deleteSamples(v23.samples)
	g_animationManager:deleteAnimations(v23.animationNodes)
	if v23.effects ~= nil then
		for _, v24 in ipairs(v23.effects) do
			g_effectManager:deleteEffects(v24.effects)
			g_soundManager:deleteSamples(v24.samples)
		end
	end
end
function Windrower.onReadStream(p25, p26, _)
	local v27 = p25.spec_windrower
	for v28, _ in ipairs(v27.windrowerWorkAreaFillTypes) do
		local v29 = streamReadUIntN(p26, FillTypeManager.SEND_NUM_BITS)
		v27.windrowerWorkAreaFillTypes[v28] = v29
	end
	for _, v30 in ipairs(v27.effects) do
		if streamReadBool(p26) then
			local v31 = v27.windrowerWorkAreaFillTypes[v30.windrowerWorkAreaFillTypeIndex]
			g_effectManager:setEffectTypeInfo(v30.effects, v31)
			g_effectManager:startEffects(v30.effects)
			if not g_soundManager:getIsSamplePlaying(v30.samples.work) then
				g_soundManager:playSample(v30.samples.work)
			end
		else
			g_effectManager:stopEffects(v30.effects)
			g_soundManager:stopSample(v30.samples.work)
		end
	end
end
function Windrower.onWriteStream(p32, p33, _)
	local v34 = p32.spec_windrower
	for _, v35 in ipairs(v34.windrowerWorkAreaFillTypes) do
		streamWriteUIntN(p33, v35, FillTypeManager.SEND_NUM_BITS)
	end
	for _, v36 in ipairs(v34.effects) do
		streamWriteBool(p33, v36.isActiveSent)
	end
end
function Windrower.onReadUpdateStream(p37, p38, _, p39)
	if p39:getIsServer() then
		local v40 = p37.spec_windrower
		if streamReadBool(p38) then
			for v41, _ in ipairs(v40.windrowerWorkAreaFillTypes) do
				local v42 = streamReadUIntN(p38, FillTypeManager.SEND_NUM_BITS)
				v40.windrowerWorkAreaFillTypes[v41] = v42
			end
		end
		if streamReadBool(p38) then
			for _, v43 in ipairs(v40.effects) do
				if streamReadBool(p38) then
					local v44 = v40.windrowerWorkAreaFillTypes[v43.windrowerWorkAreaFillTypeIndex]
					g_effectManager:setEffectTypeInfo(v43.effects, v44)
					g_effectManager:startEffects(v43.effects)
					if not g_soundManager:getIsSamplePlaying(v43.samples.work) then
						g_soundManager:playSample(v43.samples.work)
					end
				else
					g_effectManager:stopEffects(v43.effects)
					g_soundManager:stopSample(v43.samples.work)
				end
			end
		end
	end
end
function Windrower.onWriteUpdateStream(p45, p46, p47, p48)
	if not p47:getIsServer() then
		local v49 = p45.spec_windrower
		if streamWriteBool(p46, bitAND(p48, v49.fillTypesDirtyFlag) ~= 0) then
			for _, v50 in ipairs(v49.windrowerWorkAreaFillTypes) do
				streamWriteUIntN(p46, v50, FillTypeManager.SEND_NUM_BITS)
			end
		end
		if streamWriteBool(p46, bitAND(p48, v49.effectDirtyFlag) ~= 0) then
			for _, v51 in ipairs(v49.effects) do
				streamWriteBool(p46, v51.isActiveSent)
			end
		end
	end
end
function Windrower.onUpdateTick(p52, _, _, _, _)
	local v53 = p52.spec_windrower
	if p52.isServer then
		for _, v54 in ipairs(v53.effects) do
			if v54.isActive and g_currentMission.time > v54.activeTime then
				v54.isActive = false
				if v54.isActiveSent then
					v54.isActiveSent = false
					p52:raiseDirtyFlags(v53.effectDirtyFlag)
				end
				g_effectManager:stopEffects(v54.effects)
				g_soundManager:stopSample(v54.samples.work)
			end
		end
	end
end
function Windrower.onTurnedOn(p55)
	local v56 = p55.spec_windrower
	if p55.isClient then
		g_soundManager:playSample(v56.samples.work)
		g_animationManager:startAnimations(v56.animationNodes)
	end
end
function Windrower.onTurnedOff(p57)
	local v58 = p57.spec_windrower
	g_soundManager:stopSamples(v58.samples)
	for _, v59 in ipairs(v58.effects) do
		g_effectManager:stopEffects(v59.effects)
		g_soundManager:stopSample(v59.samples.work)
	end
	g_animationManager:stopAnimations(v58.animationNodes)
end
function Windrower.doCheckSpeedLimit(p60, p61)
	local v62 = p60.getIsTurnedOn == nil and true or p60:getIsTurnedOn()
	return p61(p60) or p60:getIsImplementChainLowered() and v62
end
function Windrower.getDefaultSpeedLimit()
	return 15
end
function Windrower.loadWorkAreaFromXML(p63, p64, p65, p66, p67)
	local v68 = p64(p63, p65, p66, p67)
	if p65.type == WorkAreaType.DEFAULT then
		p65.type = WorkAreaType.WINDROWER
	end
	if p65.type == WorkAreaType.WINDROWER then
		p65.particleSystemIndex = p66:getValue(p67 .. ".windrower#particleSystemIndex")
		p65.dropWindrowWorkAreaIndex = p66:getValue(p67 .. ".windrower#dropWindrowWorkAreaIndex", 1)
		p65.lastValidPickupFillType = FillType.UNKNOWN
		p65.lastPickupLiters = 0
		p65.lastDroppedLiters = 0
		p65.litersToDrop = 0
		local v69 = p63.spec_windrower
		if v69.windrowerWorkAreaFillTypes == nil then
			v69.windrowerWorkAreaFillTypes = {}
		end
		local v70 = v69.windrowerWorkAreaFillTypes
		local v71 = FillType.UNKNOWN
		table.insert(v70, v71)
		p65.windrowerWorkAreaIndex = #v69.windrowerWorkAreaFillTypes
	end
	return v68
end
function Windrower.getDirtMultiplier(p72, p73)
	local v74 = p72.spec_windrower
	local v75 = p73(p72)
	if v74.isWorking then
		v75 = v75 + p72:getWorkDirtMultiplier() * p72:getLastSpeed() / p72.speedLimit
	end
	return v75
end
function Windrower.getWearMultiplier(p76, p77)
	local v78 = p76.spec_windrower
	local v79 = p77(p76)
	if v78.isWorking then
		local v80 = (v78.stoneLastState == 0 or v78.stoneWearMultiplierData == nil) and 1 or (v78.stoneWearMultiplierData[v78.stoneLastState] or 1)
		v79 = v79 + p76:getWorkWearMultiplier() * p76:getLastSpeed() / p76.speedLimit * v80
	end
	return v79
end
function Windrower.onStartWorkAreaProcessing(p81, _, p82)
	local v83 = p81.spec_windrower
	for _, v84 in pairs(p82) do
		v84.lastValidPickupFillType = FillType.UNKNOWN
		v84.lastPickupLiters = 0
		v84.lastDroppedLiters = 0
	end
	v83.isWorking = false
end
function Windrower.onEndWorkAreaProcessing(p85, _, _)
	local v86 = p85.spec_windrower
	if p85.isClient and p85.getIsTurnedOn == nil then
		if v86.isWorking then
			if not g_soundManager:getIsSamplePlaying(v86.samples.work) then
				g_soundManager:playSample(v86.samples.work)
				return
			end
		elseif g_soundManager:getIsSamplePlaying(v86.samples.work) then
			g_soundManager:stopSample(v86.samples.work)
		end
	end
end
function Windrower.onAIFieldCourseSettingsInitialized(_, p87)
	p87.headlandsFirst = true
	p87.workInitialSegment = true
end
function Windrower.processWindrowerArea(p88, p89, _)
	local v90 = p88.spec_windrower
	local v91 = p88.spec_workArea
	v90.isWorking = p88:getLastSpeed() > 0.5
	local v92, v93, v94 = getWorldTranslation(p89.start)
	local v95, v96, v97 = getWorldTranslation(p89.width)
	local v98, v99, v100 = getWorldTranslation(p89.height)
	if v90.isWorking then
		v90.stoneLastState = FSDensityMapUtil.getStoneArea(v92, v94, v95, v97, v98, v100)
	else
		v90.stoneLastState = 0
	end
	local v101, v102, v103, v104, v105, v106, v107 = DensityMapHeightUtil.getLineByAreaDimensions(v92, v93, v94, v95, v96, v97, v98, v99, v100)
	local v108 = 0
	local v109 = FillType.UNKNOWN
	if p89.lastPickupLiters == 0 and (p89.lastValidPickupFillType == FillType.UNKNOWN or p89.litersToDrop < g_densityMapHeightManager:getMinValidLiterValue(p89.lastValidPickupFillType)) then
		for _, v110 in ipairs(v90.supportedFillTypes) do
			v108 = -DensityMapHeightUtil.tipToGroundAroundLine(p88, (-1 / 0), v110, v101, v102, v103, v104, v105, v106, v107, nil, nil, v90.limitToLineHeight, nil)
			if v108 > 0 then
				v109 = v110
				break
			end
		end
	else
		v108 = -DensityMapHeightUtil.tipToGroundAroundLine(p88, (-1 / 0), p89.lastValidPickupFillType, v101, v102, v103, v104, v105, v106, v107, nil, nil, false, nil)
		if p89.lastValidPickupFillType == FillType.GRASS_WINDROW then
			v108 = v108 - DensityMapHeightUtil.tipToGroundAroundLine(p88, (-1 / 0), FillType.DRYGRASS_WINDROW, v101, v102, v103, v104, v105, v106, v107, nil, nil, false, nil)
		elseif p89.lastValidPickupFillType == FillType.DRYGRASS_WINDROW then
			v108 = v108 - DensityMapHeightUtil.tipToGroundAroundLine(p88, (-1 / 0), FillType.GRASS_WINDROW, v101, v102, v103, v104, v105, v106, v107, nil, nil, false, nil)
		end
		if v108 > 0 then
			v109 = p89.lastValidPickupFillType
		end
	end
	if v109 ~= FillType.UNKNOWN then
		p89.lastValidPickupFillType = v109
		p88:setTestAreaRequirements(nil, v109, nil)
	end
	p89.lastPickupLiters = v108
	p89.litersToDrop = p89.litersToDrop + v108
	local v111 = MathUtil.vector3Length(v101 - v104, v102 - v105, v103 - v106) * p88.lastMovedDistance
	if p89.lastPickupLiters > 0 then
		local v112 = v91.workAreas[p89.dropWindrowWorkAreaIndex]
		if v112 ~= nil then
			local v113 = p89.lastValidPickupFillType
			local v114 = p88:processDropArea(v112, p89.lastPickupLiters, v113)
			p89.lastDroppedLiters = v114
			p89.litersToDrop = p89.litersToDrop - v114
			if p88.isServer and (p88:getLastSpeed(true) > 0.5 and v114 > 0) then
				local v115
				if v90.windrowerWorkAreaFillTypes[p89.windrowerWorkAreaIndex] == v113 then
					v115 = false
				else
					v90.windrowerWorkAreaFillTypes[p89.windrowerWorkAreaIndex] = v113
					p88:raiseDirtyFlags(v90.fillTypesDirtyFlag)
					v115 = true
				end
				local v116 = v90.workAreaToEffects[p89.index]
				if v116 ~= nil then
					for _, v117 in ipairs(v116) do
						if v117.dropAreaIndex == nil or v117.dropAreaIndex == p89.dropWindrowWorkAreaIndex then
							v117.activeTime = g_currentMission.time + v117.activeTimeDuration
							if not v117.isActiveSent then
								v117.isActiveSent = true
								p88:raiseDirtyFlags(v90.effectDirtyFlag)
							end
							if v115 then
								g_effectManager:setEffectTypeInfo(v117.effects, v113)
							end
							if not v117.isActive then
								g_effectManager:setEffectTypeInfo(v117.effects, v113)
								g_effectManager:startEffects(v117.effects)
								g_soundManager:playSample(v117.samples.work)
							end
							v117.isActive = true
						end
					end
				end
			end
		end
	end
	return p89.lastDroppedLiters, v111
end
function Windrower.processDropArea(p118, p119, p120, p121)
	local v122, v123, v124, v125, v126, v127, v128 = DensityMapHeightUtil.getLineByArea(p119.start, p119.width, p119.height)
	local v129, v130 = DensityMapHeightUtil.tipToGroundAroundLine(p118, p120, p121, v122, v123, v124, v125, v126, v127, v128, nil, p119.lineOffset, false, nil, false)
	p119.lineOffset = v130
	return v129
end

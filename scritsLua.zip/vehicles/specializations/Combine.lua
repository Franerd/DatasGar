source("dataS/scripts/vehicles/specializations/events/CombineStrawEnableEvent.lua")
Combine = {}
Combine.DAMAGED_YIELD_REDUCTION = 0.4
Combine.RAIN_YIELD_REDUCTION = 0.5
function Combine.initSpecialization()
	AIFieldWorker.registerDriveStrategy(function(p1)
		return SpecializationUtil.hasSpecialization(Combine, p1.specializations)
	end, AIDriveStrategyCombine)
	g_workAreaTypeManager:addWorkAreaType("combineChopper", false, false, false)
	g_workAreaTypeManager:addWorkAreaType("combineSwath", false, false, false)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Combine")
	v2:register(XMLValueType.L10N_STRING, "vehicle.combine.warning#noCutter", "No cutter warning", "$l10n_warning_noCuttersAttached")
	v2:register(XMLValueType.FLOAT, "vehicle.combine#fillLevelBufferTime", "Fill level buffer time for forage harvesters", 2000)
	v2:register(XMLValueType.BOOL, "vehicle.combine#showTrailerWarning", "Show warning if the combine is turned on, but no trailer below the pipe", false)
	v2:register(XMLValueType.BOOL, "vehicle.combine#allowThreshingDuringRain", "Allow threshing during rain", false)
	v2:register(XMLValueType.INT, "vehicle.combine#fillUnitIndex", "Fill unit index", 1)
	v2:register(XMLValueType.BOOL, "vehicle.combine#turnOffWhenFull", "Turn off the combine while it\'s full", true)
	v2:register(XMLValueType.INT, "vehicle.combine.buffer#fillUnitIndex", "Buffer fill unit index (This fill unit will be filled first until it\'s full. Will be emptied if stopped to harvest)")
	v2:register(XMLValueType.TIME, "vehicle.combine.buffer#unloadingTime", "Buffer unloading speed", 0)
	v2:register(XMLValueType.INT, "vehicle.combine#loadInfoIndex", "Load info index", 1)
	v2:register(XMLValueType.TIME, "vehicle.combine.buffer#loadingDelay", "Time until the crops from the cutter are added to the tank", 0)
	v2:register(XMLValueType.TIME, "vehicle.combine.buffer#unloadingDelay", "Time until the crops are not longer added to the tank after the cutting has been stopped", "same as #loadingDelay")
	v2:register(XMLValueType.BOOL, "vehicle.combine.swath#available", "Swath is available", false)
	v2:register(XMLValueType.BOOL, "vehicle.combine.swath#isDefaultActive", "Swath is default active", "true if available")
	v2:register(XMLValueType.INT, "vehicle.combine.swath#workAreaIndex", "Swath work area index")
	v2:register(XMLValueType.BOOL, "vehicle.combine.chopper#available", "Chopper is available", false)
	v2:register(XMLValueType.BOOL, "vehicle.combine.chopper#isPowered", "Vehicle needs to be powered to switch chopper", true)
	v2:register(XMLValueType.INT, "vehicle.combine.chopper#workAreaIndex", "Chopper work area index")
	v2:register(XMLValueType.STRING, "vehicle.combine.chopper#animName", "Chopper toggle animation name")
	v2:register(XMLValueType.FLOAT, "vehicle.combine.chopper#animSpeedScale", "Chopper toggle animation speed", 1)
	v2:register(XMLValueType.STRING, "vehicle.combine.ladder#animName", "Ladder animation name")
	v2:register(XMLValueType.FLOAT, "vehicle.combine.ladder#animSpeedScale", "Ladder animation speed scale", 1)
	v2:register(XMLValueType.FLOAT, "vehicle.combine.ladder#foldMinLimit", "Min. folding time to fold ladder", 0.99)
	v2:register(XMLValueType.FLOAT, "vehicle.combine.ladder#foldMaxLimit", "Max. folding time to fold ladder", 1)
	v2:register(XMLValueType.INT, "vehicle.combine.ladder#foldDirection", "Fold direction to unfold ladder", "signed animation speed")
	v2:register(XMLValueType.BOOL, "vehicle.combine.ladder#unfoldWhileCutterAttached", "Unfold ladder while a cutter is attached", false)
	v2:register(XMLValueType.TIME, "vehicle.combine#fillTimeThreshold", "After receiving no input for this threshold time we stop the fill effects", 0.5)
	v2:register(XMLValueType.FLOAT, "vehicle.combine.processing#toggleTime", "Time from crop cutting to dropping straw", 0)
	v2:register(XMLValueType.STRING, "vehicle.combine.threshingStartAnimation#name", "Threshing start animation")
	v2:register(XMLValueType.FLOAT, "vehicle.combine.threshingStartAnimation#speedScale", "Threshing start animation speed scale")
	v2:register(XMLValueType.BOOL, "vehicle.combine.threshingStartAnimation#initialIsStarted", "Threshing start animation is initial started")
	v2:register(XMLValueType.INT, "vehicle.combine.additives#fillUnitIndex", "Additives fill unit index")
	v2:register(XMLValueType.FLOAT, "vehicle.combine.additives#usage", "Usage per picked up liter", 2)
	v2:register(XMLValueType.STRING, "vehicle.combine.additives#fillTypes", "Fill types to apply additives", "CHAFF GRASS_WINDROW")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.combine.automaticTilt.automaticTiltNode(?)#node", "Automatic tilt node")
	v2:register(XMLValueType.ANGLE, "vehicle.combine.automaticTilt.automaticTiltNode(?)#minAngle", "Min. angle", -5)
	v2:register(XMLValueType.ANGLE, "vehicle.combine.automaticTilt.automaticTiltNode(?)#maxAngle", "Max. angle", 5)
	v2:register(XMLValueType.ANGLE, "vehicle.combine.automaticTilt.automaticTiltNode(?)#maxSpeed", "Max. angle change per second", 2)
	v2:register(XMLValueType.BOOL, "vehicle.combine.automaticTilt.automaticTiltNode(?)#updateAttacherJoint", "Update cutter attacher joint")
	v2:register(XMLValueType.STRING, "vehicle.combine.automaticTilt.automaticTiltNode(?)#dependentAnimation", "Animation that is updated depending on tilt state")
	v2:register(XMLValueType.FLOAT, "vehicle.combine.folding#fillLevelThresholdPct", "Max. fill level to be folded (percentage between 0 and 1)", 0.15)
	v2:register(XMLValueType.INT, "vehicle.combine.folding#direction", "Folding direction", 1)
	v2:register(XMLValueType.BOOL, "vehicle.combine.folding#allowWhileThreshing", "Allow folding while combine is threshing", false)
	EffectManager.registerEffectXMLPaths(v2, "vehicle.combine.chopperEffect")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.combine.strawEffect")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.combine.fillEffect")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.combine.effect")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.combine.animationNodes")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.combine.chopperAnimationNodes")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.combine.strawDropAnimationNodes")
	AnimationManager.registerAnimationNodesXMLPaths(v2, "vehicle.combine.fillingAnimationNodes")
	v2:register(XMLValueType.FLOAT, "vehicle.combine.animationNodes#speedReverseFillLevel", "If fill level is above the animation nodes will be reversed (Percent 0-1)")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "start")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "stop")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "work")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "chopperStart")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "chopperStop")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "chopperWork")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "chopStraw")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "dropStraw")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.combine.sounds", "fill")
	Dashboard.registerDashboardXMLPaths(v2, "vehicle.combine.dashboards", { "workedHectars", "workedHectarsSession" })
	v2:register(XMLValueType.BOOL, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#activeChopper", "Animation is active while chopper is active", true)
	v2:register(XMLValueType.BOOL, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#activeStrawDrop", "Animation is active while straw drop is active", true)
	v2:register(XMLValueType.BOOL, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#waitForStraw", "Animation is active as long as straw is dropped", true)
	v2:setXMLSpecializationType()
	local v3 = Vehicle.xmlSchemaSavegame
	v3:register(XMLValueType.BOOL, "vehicles.vehicle(?).combine#isSwathActive", "Swath is active")
	v3:register(XMLValueType.FLOAT, "vehicles.vehicle(?).combine#workedHectars", "Worked hectars")
	v3:register(XMLValueType.INT, "vehicles.vehicle(?).combine#numAttachedCutters", "Number of last attached cutters")
end
function Combine.prerequisitesPresent(p4)
	local v5 = SpecializationUtil.hasSpecialization(WorkArea, p4) and SpecializationUtil.hasSpecialization(FillUnit, p4) and (SpecializationUtil.hasSpecialization(Drivable, p4) or SpecializationUtil.hasSpecialization(Attachable, p4)) and SpecializationUtil.hasSpecialization(AnimatedVehicle, p4)
	if v5 then
		v5 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p4)
	end
	return v5
end
function Combine.registerEvents(p6)
	SpecializationUtil.registerEvent(p6, "onStartThreshing")
	SpecializationUtil.registerEvent(p6, "onStopThreshing")
end
function Combine.registerFunctions(p7)
	SpecializationUtil.registerFunction(p7, "loadCombineSetup", Combine.loadCombineSetup)
	SpecializationUtil.registerFunction(p7, "loadCombineEffects", Combine.loadCombineEffects)
	SpecializationUtil.registerFunction(p7, "loadCombineRotationNodes", Combine.loadCombineRotationNodes)
	SpecializationUtil.registerFunction(p7, "loadCombineSamples", Combine.loadCombineSamples)
	SpecializationUtil.registerFunction(p7, "setIsSwathActive", Combine.setIsSwathActive)
	SpecializationUtil.registerFunction(p7, "processCombineChopperArea", Combine.processCombineChopperArea)
	SpecializationUtil.registerFunction(p7, "processCombineSwathArea", Combine.processCombineSwathArea)
	SpecializationUtil.registerFunction(p7, "setChopperPSEnabled", Combine.setChopperPSEnabled)
	SpecializationUtil.registerFunction(p7, "setStrawPSEnabled", Combine.setStrawPSEnabled)
	SpecializationUtil.registerFunction(p7, "setCombineIsFilling", Combine.setCombineIsFilling)
	SpecializationUtil.registerFunction(p7, "startThreshing", Combine.startThreshing)
	SpecializationUtil.registerFunction(p7, "stopThreshing", Combine.stopThreshing)
	SpecializationUtil.registerFunction(p7, "setWorkedHectars", Combine.setWorkedHectars)
	SpecializationUtil.registerFunction(p7, "addCutterToCombine", Combine.addCutterToCombine)
	SpecializationUtil.registerFunction(p7, "removeCutterFromCombine", Combine.removeCutterFromCombine)
	SpecializationUtil.registerFunction(p7, "addCutterArea", Combine.addCutterArea)
	SpecializationUtil.registerFunction(p7, "getIsThreshingDuringRain", Combine.getIsThreshingDuringRain)
	SpecializationUtil.registerFunction(p7, "verifyCombine", Combine.verifyCombine)
	SpecializationUtil.registerFunction(p7, "getFillLevelDependentSpeed", Combine.getFillLevelDependentSpeed)
	SpecializationUtil.registerFunction(p7, "getCombineLastValidFillType", Combine.getCombineLastValidFillType)
	SpecializationUtil.registerFunction(p7, "getCombineFillLevelPercentage", Combine.getCombineFillLevelPercentage)
	SpecializationUtil.registerFunction(p7, "getCombineLoadPercentage", Combine.getCombineLoadPercentage)
	SpecializationUtil.registerFunction(p7, "getIsCutterCompatible", Combine.getIsCutterCompatible)
end
function Combine.registerOverwrittenFunctions(p8)
	SpecializationUtil.registerOverwrittenFunction(p8, "getCanBeTurnedOn", Combine.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p8, "getTurnedOnNotAllowedWarning", Combine.getTurnedOnNotAllowedWarning)
	SpecializationUtil.registerOverwrittenFunction(p8, "getAreControlledActionsAllowed", Combine.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p8, "getIsFoldAllowed", Combine.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p8, "getCanBeSelected", Combine.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p8, "loadWorkAreaFromXML", Combine.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p8, "getDirtMultiplier", Combine.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p8, "getWearMultiplier", Combine.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p8, "loadTurnedOnAnimationFromXML", Combine.loadTurnedOnAnimationFromXML)
	SpecializationUtil.registerOverwrittenFunction(p8, "getIsTurnedOnAnimationActive", Combine.getIsTurnedOnAnimationActive)
	SpecializationUtil.registerOverwrittenFunction(p8, "loadRandomlyMovingPartFromXML", Combine.loadRandomlyMovingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p8, "getIsRandomlyMovingPartActive", Combine.getIsRandomlyMovingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p8, "getDischargeFillType", Combine.getDischargeFillType)
	SpecializationUtil.registerOverwrittenFunction(p8, "getImplementAllowAutomaticSteering", Combine.getImplementAllowAutomaticSteering)
end
function Combine.registerEventListeners(p9)
	SpecializationUtil.registerEventListener(p9, "onLoad", Combine)
	SpecializationUtil.registerEventListener(p9, "onPostLoad", Combine)
	SpecializationUtil.registerEventListener(p9, "onRegisterDashboardValueTypes", Combine)
	SpecializationUtil.registerEventListener(p9, "onDelete", Combine)
	SpecializationUtil.registerEventListener(p9, "onReadStream", Combine)
	SpecializationUtil.registerEventListener(p9, "onWriteStream", Combine)
	SpecializationUtil.registerEventListener(p9, "onReadUpdateStream", Combine)
	SpecializationUtil.registerEventListener(p9, "onWriteUpdateStream", Combine)
	SpecializationUtil.registerEventListener(p9, "onUpdate", Combine)
	SpecializationUtil.registerEventListener(p9, "onUpdateTick", Combine)
	SpecializationUtil.registerEventListener(p9, "onDraw", Combine)
	SpecializationUtil.registerEventListener(p9, "onRegisterActionEvents", Combine)
	SpecializationUtil.registerEventListener(p9, "onStartWorkAreaProcessing", Combine)
	SpecializationUtil.registerEventListener(p9, "onEndWorkAreaProcessing", Combine)
	SpecializationUtil.registerEventListener(p9, "onChangedFillType", Combine)
	SpecializationUtil.registerEventListener(p9, "onDeactivate", Combine)
	SpecializationUtil.registerEventListener(p9, "onPostAttachImplement", Combine)
	SpecializationUtil.registerEventListener(p9, "onPostDetachImplement", Combine)
	SpecializationUtil.registerEventListener(p9, "onTurnedOn", Combine)
	SpecializationUtil.registerEventListener(p9, "onTurnedOff", Combine)
	SpecializationUtil.registerEventListener(p9, "onEnterVehicle", Combine)
	SpecializationUtil.registerEventListener(p9, "onLeaveVehicle", Combine)
	SpecializationUtil.registerEventListener(p9, "onFoldStateChanged", Combine)
	SpecializationUtil.registerEventListener(p9, "onFillUnitFillLevelChanged", Combine)
end
function Combine.onLoad(p10, _)
	local v11 = p10.spec_combine
	XMLUtil.checkDeprecatedXMLElements(p10.xmlFile, "vehicle.combine.chopperSwitch", "vehicle.combine.swath and vehicle.combine.chopper")
	XMLUtil.checkDeprecatedXMLElements(p10.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.combine.rotationNodes.rotationNode", "combine")
	XMLUtil.checkDeprecatedXMLElements(p10.xmlFile, "vehicle.indoorHud.workedHectars", "vehicle.combine.dashboards.dashboard with valueType \'workedHectars\'")
	XMLUtil.checkDeprecatedXMLElements(p10.xmlFile, "vehicle.combine.folding#fillLevelThreshold", "vehicle.combine.folding#fillLevelThresholdPct")
	p10:loadCombineSetup(p10.xmlFile, "vehicle.combine", v11)
	p10:loadCombineEffects(p10.xmlFile, "vehicle.combine", v11)
	p10:loadCombineRotationNodes(p10.xmlFile, "vehicle.combine", v11)
	p10:loadCombineSamples(p10.xmlFile, "vehicle.combine", v11)
	v11.attachedCutters = {}
	v11.numAttachedCutters = 0
	v11.texts = {}
	v11.texts.warningFoldingTurnedOn = g_i18n:getText("warning_foldingNotWhileTurnedOn")
	v11.texts.warningFoldingWhileFilled = g_i18n:getText("warning_foldingNotWhileFilled")
	v11.texts.warningRainReducesYield = g_i18n:getText("warning_rainReducesYield")
	v11.texts.warningNoCutter = p10.xmlFile:getValue("vehicle.combine.warning#noCutter", g_i18n:getText("warning_noCuttersAttached"), p10.customEnvironment)
	v11.threshingDuringRainWarningDisplayed = false
	v11.showTrailerWarning = p10.xmlFile:getValue("vehicle.combine#showTrailerWarning", false)
	v11.lastAreaZeroTime = 0
	v11.lastAreaNonZeroTime = -1000000
	v11.lastCuttersArea = 0
	v11.lastCuttersAreaTime = -10000
	v11.lastInputFruitType = FruitType.UNKNOWN
	v11.lastValidInputFruitType = FruitType.UNKNOWN
	v11.lastCuttersFruitType = FruitType.UNKNOWN
	v11.lastCuttersInputFruitType = FruitType.UNKNOWN
	v11.lastValidInputFillType = FillType.UNKNOWN
	v11.lastDischargeTime = 0
	v11.lastChargeTime = 0
	v11.fillLevelBufferTime = p10.xmlFile:getValue("vehicle.combine#fillLevelBufferTime", 2000)
	v11.workedHectars = 0
	v11.workedHectarsSent = 0
	v11.workedHectarsInitial = 0
	v11.threshingScale = 1
	v11.lastLostFillLevel = 0
	v11.workAreaParameters = {}
	v11.workAreaParameters.litersToDrop = 0
	v11.workAreaParameters.droppedLiters = 0
	v11.workAreaParameters.isChopperEffectEnabled = 0
	v11.workAreaParameters.isStrawEffectEnabled = 0
	v11.workAreaParameters.effectDensity = 0.2
	v11.workAreaParameters.effectDensitySent = 0.2
	v11.dirtyFlag = p10:getNextDirtyFlag()
	v11.effectDirtyFlag = p10:getNextDirtyFlag()
end
function Combine.onPostLoad(p12, p13)
	local v14 = p12.spec_combine
	if p13 == nil then
		p12:setIsSwathActive(v14.isSwathActive, true, true)
	else
		if v14.swath.isAvailable then
			p12:setIsSwathActive(p13.xmlFile:getValue(p13.key .. ".combine#isSwathActive", v14.isSwathActive), true, true)
		end
		p12:setWorkedHectars(p13.xmlFile:getValue(p13.key .. ".combine#workedHectars", v14.workedHectars), true)
	end
	v14.isBufferCombine = p12:getFillUnitCapacity(p12.spec_combine.fillUnitIndex) == (1 / 0)
	if v14.isBufferCombine and p12:getFillUnitByIndex(p12.spec_combine.fillUnitIndex).showOnInfoHud then
		Logging.xmlWarning(p12.xmlFile, "Buffer combine fill unit is displayed in info hud! Add showOnInfoHud=\'false\' to the fill unit.")
	end
	local v15 = v14.ladder
	if v15.animName ~= nil then
		local v16 = 0
		if p12.getFoldAnimTime ~= nil then
			local v17 = p12:getFoldAnimTime()
			v16 = (v15.foldMaxLimit < v17 or v17 < v15.foldMinLimit) and 1 or v16
		end
		local v18 = v15.unfoldWhileCutterAttached and (p13 ~= nil and (not p13.resetVehicles and p13.xmlFile:getValue(p13.key .. ".combine#numAttachedCutters", 0) > 0)) and 1 or v16
		if v15.foldDirection ~= 1 then
			v18 = 1 - v18
		end
		p12:setAnimationTime(v15.animName, v18, true)
	end
	if v14.bufferFillUnitIndex ~= nil then
		local v19 = p12:getFillUnitByIndex(v14.fillUnitIndex)
		local v20 = p12:getFillUnitByIndex(v14.bufferFillUnitIndex)
		if v19 ~= nil and v20 ~= nil then
			v20.parentUnitOnHud = v14.fillUnitIndex
			v19.childUnitOnHud = v14.bufferFillUnitIndex
		end
	end
	if p12:getFillUnitCapacity(v14.fillUnitIndex) == 0 then
		Logging.xmlWarning(p12.xmlFile, "Capacity of fill unit \'%d\' for combine needs to be set greater 0 or not defined! (not defined = infinity)", v14.fillUnitIndex)
	end
end
function Combine.onRegisterDashboardValueTypes(p21)
	local v_u_22 = p21.spec_combine
	local v23 = DashboardValueType.new("combine", "workedHectars")
	v23:setValue(v_u_22, "workedHectars")
	p21:registerDashboardValueType(v23)
	local v24 = DashboardValueType.new("combine", "workedHectarsSession")
	v24:setValue(v_u_22, function(_)
		-- upvalues: (copy) v_u_22
		return v_u_22.workedHectars - v_u_22.workedHectarsInitial
	end)
	p21:registerDashboardValueType(v24)
end
function Combine.onDelete(p25)
	local v26 = p25.spec_combine
	g_effectManager:deleteEffects(v26.effects)
	g_effectManager:deleteEffects(v26.fillEffects)
	g_effectManager:deleteEffects(v26.strawEffects)
	g_effectManager:deleteEffects(v26.chopperEffects)
	g_animationManager:deleteAnimations(v26.animationNodes)
	g_animationManager:deleteAnimations(v26.chopperAnimationNodes)
	g_animationManager:deleteAnimations(v26.strawDropAnimationNodes)
	g_animationManager:deleteAnimations(v26.fillingAnimationNodes)
	g_soundManager:deleteSamples(v26.samples)
end
function Combine.saveToXMLFile(p27, p28, p29, _)
	local v30 = p27.spec_combine
	if v30.swath.isAvailable then
		p28:setValue(p29 .. "#isSwathActive", v30.isSwathActive)
	end
	p28:setValue(p29 .. "#workedHectars", v30.workedHectars)
	p28:setValue(p29 .. "#numAttachedCutters", v30.numAttachedCutters)
end
function Combine.onReadStream(p31, p32, _)
	local v33 = p31.spec_combine
	v33.lastValidInputFruitType = streamReadUIntN(p32, FruitTypeManager.SEND_NUM_BITS)
	local v34 = streamReadBool(p32)
	local v35 = streamReadBool(p32)
	local v36 = streamReadBool(p32)
	v33.lastValidInputFillType = streamReadUIntN(p32, FillTypeManager.SEND_NUM_BITS)
	p31:setCombineIsFilling(v34, false, true)
	p31:setChopperPSEnabled(v35, false, 1, true)
	p31:setStrawPSEnabled(v36, false, 1, true)
	p31:setIsSwathActive(streamReadBool(p32), true)
	p31:setWorkedHectars(streamReadFloat32(p32), true)
end
function Combine.onWriteStream(p37, p38, _)
	local v39 = p37.spec_combine
	streamWriteUIntN(p38, v39.lastValidInputFruitType, FruitTypeManager.SEND_NUM_BITS)
	streamWriteBool(p38, v39.isFilling)
	streamWriteBool(p38, v39.chopperPSenabled)
	streamWriteBool(p38, v39.strawPSenabled)
	streamWriteUIntN(p38, p37:getCombineLastValidFillType(), FillTypeManager.SEND_NUM_BITS)
	streamWriteBool(p38, v39.isSwathActive)
	streamWriteFloat32(p38, v39.workedHectars)
end
function Combine.onReadUpdateStream(p40, p41, _, p42)
	if p42:getIsServer() then
		local v43 = p40.spec_combine
		if streamReadBool(p41) then
			v43.lastValidInputFruitType = streamReadUIntN(p41, FruitTypeManager.SEND_NUM_BITS)
			p40:setWorkedHectars((streamReadFloat32(p41)))
		end
		if streamReadBool(p41) then
			local v44 = streamReadBool(p41)
			local v45 = streamReadBool(p41)
			local v46 = streamReadBool(p41)
			local v47 = streamReadUIntN(p41, 5) / 31
			v43.lastValidInputFillType = streamReadUIntN(p41, FillTypeManager.SEND_NUM_BITS)
			p40:setCombineIsFilling(v44, false, true)
			p40:setChopperPSEnabled(v45, false, v47, true)
			p40:setStrawPSEnabled(v46, false, v47, true)
		end
	end
end
function Combine.onWriteUpdateStream(p48, p49, p50, p51)
	if not p50:getIsServer() then
		local v52 = p48.spec_combine
		if streamWriteBool(p49, bitAND(p51, v52.dirtyFlag) ~= 0) then
			streamWriteUIntN(p49, v52.lastValidInputFruitType, FruitTypeManager.SEND_NUM_BITS)
			streamWriteFloat32(p49, v52.workedHectars)
		end
		if streamWriteBool(p49, bitAND(p51, v52.effectDirtyFlag) ~= 0) then
			streamWriteBool(p49, v52.isFilling)
			streamWriteBool(p49, v52.chopperPSenabled)
			streamWriteBool(p49, v52.strawPSenabled)
			streamWriteUIntN(p49, v52.workAreaParameters.effectDensity * 31, 5)
			streamWriteUIntN(p49, p48:getCombineLastValidFillType(), FillTypeManager.SEND_NUM_BITS)
		end
	end
end
function Combine.onUpdate(p53, p54, _, _, _)
	local v55 = p53.spec_combine
	if p53:getIsTurnedOn() and (p53.isServer and v55.swath.isAvailable) then
		local v56 = v55.bufferFillUnitIndex or v55.fillUnitIndex
		local v57 = g_fruitTypeManager:getFruitTypeIndexByFillTypeIndex(p53:getFillUnitFillType(v56))
		if v55.isSwathActive and (v57 ~= nil and v57 ~= FruitType.UNKNOWN) then
			if not g_fruitTypeManager:getFruitTypeByIndex(v57).hasWindrow then
				p53:setIsSwathActive(false)
			end
		elseif (not v55.chopper.isAvailable or v55.automatedChopperSwitch) and (not v55.isSwathActive and (v57 ~= nil and (v57 ~= FruitType.UNKNOWN and g_fruitTypeManager:getFruitTypeByIndex(v57).hasWindrow))) then
			p53:setIsSwathActive(true)
			local v58 = v55.processing.inputBuffer
			for v59 = 1, #v58.buffer do
				v58.buffer[v59].area = 0
				v58.buffer[v59].liters = 0
				v58.buffer[v59].inputLiters = 0
			end
		end
	end
	if p53.isServer and p53:getFillUnitFillLevel(v55.fillUnitIndex) < 0.0001 then
		v55.lastDischargeTime = g_time
	end
	if v55.automaticTilt.hasNodes then
		local _, v60 = next(v55.attachedCutters)
		local v61, v62, v63
		if v60 == nil or not v60:getCutterTiltIsAvailable() then
			v61 = false
			v62 = false
			v63 = 0
		else
			v63, v61, v62 = v60:getCutterTiltDelta()
		end
		for v64 = 1, #v55.automaticTilt.nodes do
			local v65 = v55.automaticTilt.nodes[v64]
			local _, _, v66 = getRotation(v65.node)
			if not v61 and v62 then
				v63 = -v66
			end
			if math.abs(v63) > 0.00001 then
				local v67 = math.abs(v63) / 0.01745
				local v68 = math.pow(v67, 2)
				local v69 = math.min(v68, 1) * math.sign(v63)
				if not v61 and v62 then
					v69 = v69 * 0.5
				end
				local v70 = v66 + v69 * v65.maxSpeed * p54
				local v71 = v65.minAngle
				local v72 = v65.maxAngle
				local v73 = math.clamp(v70, v71, v72)
				setRotation(v65.node, 0, 0, v73)
				if v65.dependentAnimation ~= nil then
					local v74 = MathUtil.inverseLerp(v65.minAngle, v65.maxAngle, v73)
					p53:setAnimationTime(v65.dependentAnimation, v74, true)
				end
				if v60 ~= nil and v65.updateAttacherJoint then
					local v75 = v73 - v65.lastJointUpdateRot
					if math.abs(v75) > 0.00001 then
						v65.lastJointUpdateRot = v73
						local v76 = p53:getAttacherJointDescFromObject(v60)
						if v76.jointIndex ~= 0 then
							setJointFrame(v76.jointIndex, 0, v76.jointTransform)
						end
					end
				end
				if p53.setMovingToolDirty ~= nil then
					p53:setMovingToolDirty(v65.node)
				end
			end
		end
	end
end
function Combine.onUpdateTick(p77, p78, _, _, _)
	local v79 = p77.spec_combine
	if p77.isServer then
		v79.lastInputFruitType = v79.lastCuttersInputFruitType
		v79.lastCuttersArea = 0
		v79.lastCuttersInputFruitType = FruitType.UNKNOWN
		v79.lastCuttersFruitType = FruitType.UNKNOWN
		if v79.lastInputFruitType ~= nil and v79.lastInputFruitType ~= FruitType.UNKNOWN then
			v79.lastValidInputFruitType = v79.lastInputFruitType
		end
		local v80 = v79.processing.inputBuffer
		v79.lastAreaZeroTime = v79.lastAreaZeroTime + p78
		if v79.lastAreaZeroTime > v79.fillTimeThreshold and v79.fillDisableTime == nil then
			v79.fillDisableTime = g_currentMission.time + v79.processing.toggleTime
		end
		if v79.fillEnableTime ~= nil and v79.fillEnableTime <= g_currentMission.time then
			p77:setCombineIsFilling(true, false, false)
			v79.fillEnableTime = nil
		end
		if v79.fillDisableTime ~= nil and v79.fillDisableTime <= g_currentMission.time then
			p77:setCombineIsFilling(false, false, false)
			v79.fillDisableTime = nil
		end
		local v81 = v79.workAreaParameters
		local v82 = v79.workAreaParameters.isChopperEffectEnabled - p78
		v81.isChopperEffectEnabled = math.max(v82, 0)
		local v83 = v79.workAreaParameters
		local v84 = v79.workAreaParameters.isStrawEffectEnabled - p78
		v83.isStrawEffectEnabled = math.max(v84, 0)
		local v85 = v79.workAreaParameters.effectDensity
		local v86 = v79.workAreaParameters.isChopperEffectEnabled > 0
		local v87 = v79.workAreaParameters.isStrawEffectEnabled > 0
		p77:setChopperPSEnabled(v86, false, v85, false)
		p77:setStrawPSEnabled(v87, false, v85, false)
		if v86 or v87 then
			p77:raiseActive()
		end
		if p77:getIsTurnedOn() then
			g_farmManager:updateFarmStats(p77:getOwnerFarmId(), "threshedTime", p78 / 60000)
			p77:updateLastWorkedArea(0)
		end
		v80.slotTimer = v80.slotTimer - p78
		if v80.slotTimer < 0 then
			v80.slotTimer = v80.slotDuration
			v80.fillIndex = v80.fillIndex + 1
			if v80.fillIndex > v80.slotCount then
				v80.fillIndex = 1
			end
			local v88 = v80.dropIndex
			v80.dropIndex = v80.dropIndex + 1
			if v80.dropIndex > v80.slotCount then
				v80.dropIndex = 1
			end
			v80.buffer[v80.dropIndex].liters = v80.buffer[v80.dropIndex].liters + v80.buffer[v88].liters
			v80.buffer[v80.dropIndex].inputLiters = v80.buffer[v80.dropIndex].inputLiters + v80.buffer[v88].liters
			v80.buffer[v88].area = 0
			v80.buffer[v88].liters = 0
			v80.buffer[v88].inputLiters = 0
		end
		if v79.bufferFillUnitIndex ~= nil and (v79.lastCuttersAreaTime + p78 * 10 < g_currentMission.time and p77:getFillUnitFillLevel(v79.bufferFillUnitIndex) > 0) then
			local v89 = p78 * (p77:getFillUnitCapacity(v79.bufferFillUnitIndex) / v79.bufferUnloadingTime)
			local v90 = p77:addFillUnitFillLevel(p77:getOwnerFarmId(), v79.bufferFillUnitIndex, -v89, p77:getFillUnitFillType(v79.bufferFillUnitIndex), ToolType.UNDEFINED)
			p77:addFillUnitFillLevel(p77:getOwnerFarmId(), v79.fillUnitIndex, -v90, p77:getFillUnitFillType(v79.bufferFillUnitIndex), ToolType.UNDEFINED, p77:getFillVolumeLoadInfo(v79.loadInfoIndex))
		end
		if v79.loadingDelay > 0 then
			for v91 = 1, #v79.loadingDelaySlots do
				local v92 = v79.loadingDelaySlots[v91]
				if v92.valid and v92.time + v79.loadingDelay < g_time then
					v92.valid = false
					p77:addFillUnitFillLevel(p77:getOwnerFarmId(), v79.fillUnitIndex, v92.fillLevelDelta, v92.fillType, ToolType.UNDEFINED, p77:getFillVolumeLoadInfo(v79.loadInfoIndex))
				end
			end
		end
		if v79.isFilling ~= v79.sentIsFilling or (v79.chopperPSenabled ~= v79.sentChopperPSenabled or v79.strawPSenabled ~= v79.sentStrawPSenabled) then
			::l43::
			p77:raiseDirtyFlags(v79.effectDirtyFlag)
			v79.sentIsFilling = v79.isFilling
			v79.sentChopperPSenabled = v79.chopperPSenabled
			v79.sentStrawPSenabled = v79.strawPSenabled
			v79.workAreaParameters.effectDensitySent = v79.workAreaParameters.effectDensity
			goto l2
		end
		local v93 = v79.workAreaParameters.effectDensity - v79.workAreaParameters.effectDensitySent
		if math.abs(v93) > 0.05 then
			goto l43
		end
	end
	::l2::
end
function Combine.onDraw(p94, _, p95, _)
	local v96 = p94.spec_combine
	local v97 = p94:getIsTurnedOn()
	if v97 and p94:getIsThreshingDuringRain(false) then
		if not v96.threshingDuringRainWarningDisplayed then
			g_currentMission:showBlinkingWarning(v96.texts.warningRainReducesYield, 4000)
			v96.threshingDuringRainWarningDisplayed = true
		end
	else
		v96.threshingDuringRainWarningDisplayed = false
	end
	if v96.showTrailerWarning and (v97 and p95) then
		local v98 = p94:getCurrentDischargeNode()
		if v98 ~= nil and not v98.dischargeHitObject then
			g_currentMission:addExtraPrintText(g_i18n:getText("warning_harvesterRequiresTrailer"))
		end
	end
end
function Combine.loadCombineSetup(p_u_99, p_u_100, p101, p_u_102)
	p_u_102.allowThreshingDuringRain = p_u_100:getValue(p101 .. "#allowThreshingDuringRain", false)
	p_u_102.fillUnitIndex = p_u_100:getValue(p101 .. "#fillUnitIndex", 1)
	p_u_102.turnOffWhenFull = p_u_100:getValue(p101 .. "#turnOffWhenFull", true)
	p_u_102.bufferFillUnitIndex = p_u_100:getValue(p101 .. ".buffer#fillUnitIndex")
	p_u_102.bufferUnloadingTime = p_u_100:getValue(p101 .. ".buffer#unloadingTime", 0)
	p_u_102.loadInfoIndex = p_u_100:getValue(p101 .. "#loadInfoIndex", 1)
	p_u_102.loadingDelay = p_u_100:getValue(p101 .. ".buffer#loadingDelay", 0)
	if p_u_102.loadingDelay > 0 then
		p_u_102.unloadingDelay = p_u_100:getValue(p101 .. ".buffer#unloadingDelay", p_u_102.loadingDelay / 1000)
		p_u_102.loadingDelaySlotsDelayedInsert = false
		p_u_102.loadingDelaySlots = {}
		for v103 = 1, p_u_102.loadingDelay / 1000 * 60 + 1 do
			p_u_102.loadingDelaySlots[v103] = {
				["time"] = (-1 / 0),
				["fillLevelDelta"] = 0,
				["fillType"] = 0,
				["valid"] = false
			}
		end
	end
	p_u_102.swath = {}
	p_u_102.swath.isAvailable = p_u_100:getValue(p101 .. ".swath#available", false)
	local v104 = p_u_100:getValue(p101 .. ".swath#isDefaultActive", p_u_102.swath.isAvailable)
	if p_u_102.swath.isAvailable then
		p_u_102.swath.workAreaIndex = p_u_100:getValue(p101 .. ".swath#workAreaIndex")
		if p_u_102.swath.workAreaIndex == nil then
			p_u_102.swath.isAvailable = false
			Logging.xmlWarning(p_u_100, "Missing \'swath#workAreaIndex\' for combine swath function!")
		end
		p_u_102.warningTime = 0
	end
	p_u_102.chopper = {}
	p_u_102.chopper.isAvailable = p_u_100:getValue(p101 .. ".chopper#available", false)
	p_u_102.chopper.isPowered = p_u_100:getValue(p101 .. ".chopper#isPowered", true)
	if p_u_102.chopper.isAvailable then
		p_u_102.chopper.workAreaIndex = p_u_100:getValue(p101 .. ".chopper#workAreaIndex")
		if p_u_102.chopper.workAreaIndex == nil then
			p_u_102.chopper.isAvailable = false
			Logging.xmlWarning(p_u_100, "Missing \'chopper#workAreaIndex\' for combine chopper function!")
		end
		p_u_102.chopper.animName = p_u_100:getValue(p101 .. ".chopper#animName")
		p_u_102.chopper.animSpeedScale = p_u_100:getValue(p101 .. ".chopper#animSpeedScale", 1)
	end
	p_u_102.automatedChopperSwitch = GS_IS_MOBILE_VERSION
	p_u_102.isSwathActive = v104
	p_u_102.ladder = {}
	p_u_102.ladder.animName = p_u_100:getValue(p101 .. ".ladder#animName")
	p_u_102.ladder.animSpeedScale = p_u_100:getValue(p101 .. ".ladder#animSpeedScale", 1)
	p_u_102.ladder.foldMinLimit = p_u_100:getValue(p101 .. ".ladder#foldMinLimit", 0.99)
	p_u_102.ladder.foldMaxLimit = p_u_100:getValue(p101 .. ".ladder#foldMaxLimit", 1)
	local v105 = p_u_102.ladder
	local v106 = p101 .. ".ladder#foldDirection"
	local v107 = p_u_102.ladder.animSpeedScale
	v105.foldDirection = p_u_100:getValue(v106, (math.sign(v107)))
	p_u_102.ladder.unfoldWhileCutterAttached = p_u_100:getValue(p101 .. ".ladder#unfoldWhileCutterAttached", false)
	p_u_102.fillTimeThreshold = p_u_100:getValue(p101 .. "#fillTimeThreshold", 0.5)
	p_u_102.processing = {}
	local v108 = p_u_100:getValue(p101 .. ".processing#toggleTime")
	if v108 == nil and p_u_102.chopper.animName ~= nil then
		v108 = p_u_99:getAnimationDurection(p_u_102.chopper.animName)
		if v108 ~= nil then
			v108 = v108 / 1000
		end
	end
	p_u_102.processing.toggleTime = Utils.getNoNil(v108, 0) * 1000
	local v109 = {}
	local v110 = p_u_102.processing.toggleTime / 300
	local v111 = math.ceil(v110)
	v109.slotCount = math.clamp(v111, 2, 20)
	local v112 = p_u_102.processing.toggleTime / v109.slotCount
	v109.slotDuration = math.ceil(v112)
	v109.fillIndex = 1
	v109.dropIndex = v109.fillIndex + 1
	v109.slotTimer = v109.slotDuration
	v109.activeTimeout = v109.slotDuration * (v109.slotCount + 2)
	v109.activeTimer = v109.activeTimeout
	v109.buffer = {}
	for _ = 1, v109.slotCount do
		local v113 = v109.buffer
		table.insert(v113, {
			["area"] = 0,
			["liters"] = 0,
			["inputLiters"] = 0,
			["strawRatio"] = 0,
			["effectDensity"] = 0.2
		})
	end
	p_u_102.processing.inputBuffer = v109
	p_u_102.threshingStartAnimation = p_u_100:getValue(p101 .. ".threshingStartAnimation#name")
	p_u_102.threshingStartAnimationSpeedScale = p_u_100:getValue(p101 .. ".threshingStartAnimation#speedScale", 1)
	p_u_102.threshingStartAnimationInitialIsStarted = p_u_100:getValue(p101 .. ".threshingStartAnimation#initialIsStarted", false)
	p_u_102.foldFillLevelThreshold = p_u_100:getValue(p101 .. ".folding#fillLevelThresholdPct", Platform.gameplay.automaticVehicleControl and 0 or 0.15) * (p_u_99:getFillUnitCapacity(p_u_102.fillUnitIndex) or 0.04)
	p_u_102.foldDirection = p_u_100:getValue(p101 .. ".folding#direction", 1)
	p_u_102.allowFoldWhileThreshing = p_u_100:getValue(p101 .. ".folding#allowWhileThreshing", false)
	p_u_102.additives = {}
	p_u_102.additives.fillUnitIndex = p_u_100:getValue(p101 .. ".additives#fillUnitIndex")
	p_u_102.additives.available = p_u_99:getFillUnitByIndex(p_u_102.additives.fillUnitIndex) ~= nil
	p_u_102.additives.usage = p_u_100:getValue(p101 .. ".additives#usage", 0)
	local v114 = p_u_100:getValue(p101 .. ".additives#fillTypes", "CHAFF GRASS_WINDROW")
	p_u_102.additives.fillTypes = g_fillTypeManager:getFillTypesByNames(v114, "Warning: \'" .. p_u_100:getFilename() .. "\' has invalid fillType \'%s\'.")
	p_u_102.automaticTilt = {}
	p_u_102.automaticTilt.nodes = {}
	p_u_100:iterate(p101 .. ".automaticTilt.automaticTiltNode", function(_, p115)
		-- upvalues: (copy) p_u_100, (copy) p_u_99, (copy) p_u_102
		local v116 = {
			["node"] = p_u_100:getValue(p115 .. "#node", nil, p_u_99.components, p_u_99.i3dMappings)
		}
		if v116.node ~= nil then
			v116.minAngle = p_u_100:getValue(p115 .. "#minAngle", -5)
			v116.maxAngle = p_u_100:getValue(p115 .. "#maxAngle", 5)
			v116.maxSpeed = p_u_100:getValue(p115 .. "#maxSpeed", 2) / 1000
			v116.updateAttacherJoint = p_u_100:getValue(p115 .. "#updateAttacherJoint")
			v116.dependentAnimation = p_u_100:getValue(p115 .. "#dependentAnimation")
			v116.lastJointUpdateRot = 0
			local v117 = p_u_102.automaticTilt.nodes
			table.insert(v117, v116)
		end
	end)
	if not Platform.gameplay.allowAutomaticHeaderTilt and #p_u_102.automaticTilt.nodes > 0 then
		Logging.xmlWarning(p_u_99.xmlFile, "Automatic header tilt is not allowed on this platform!")
		p_u_102.automaticTilt.nodes = {}
	end
	p_u_102.automaticTilt.hasNodes = #p_u_102.automaticTilt.nodes > 0
end
function Combine.loadCombineEffects(p118, p119, p120, p121)
	if p118.isClient then
		XMLUtil.checkDeprecatedXMLElements(p119, p120 .. ".chopperParticleSystems", p120 .. ".chopperEffect")
		XMLUtil.checkDeprecatedXMLElements(p119, p120 .. ".strawParticleSystems", p120 .. ".strawEffect")
		XMLUtil.checkDeprecatedXMLElements(p119, p120 .. ".threshingFillParticleSystems", p120 .. ".fillEffect")
		p121.chopperEffects = g_effectManager:loadEffect(p119, p120 .. ".chopperEffect", p118.components, p118, p118.i3dMappings)
		p121.strawEffects = g_effectManager:loadEffect(p119, p120 .. ".strawEffect", p118.components, p118, p118.i3dMappings)
		p121.fillEffects = g_effectManager:loadEffect(p119, p120 .. ".fillEffect", p118.components, p118, p118.i3dMappings)
		p121.effects = g_effectManager:loadEffect(p119, p120 .. ".effect", p118.components, p118, p118.i3dMappings)
		p121.strawPSenabled = false
		p121.chopperPSenabled = false
		p121.isFilling = false
		p121.fillEnableTime = nil
		p121.fillDisableTime = nil
		p121.lastEffectFillType = FillType.UNKNOWN
	end
end
function Combine.loadCombineRotationNodes(p122, p123, p124, p125)
	if p122.isClient then
		p125.animationNodes = g_animationManager:loadAnimations(p123, p124 .. ".animationNodes", p122.components, p122, p122.i3dMappings)
		p125.chopperAnimationNodes = g_animationManager:loadAnimations(p123, p124 .. ".chopperAnimationNodes", p122.components, p122, p122.i3dMappings)
		p125.strawDropAnimationNodes = g_animationManager:loadAnimations(p123, p124 .. ".strawDropAnimationNodes", p122.components, p122, p122.i3dMappings)
		p125.fillingAnimationNodes = g_animationManager:loadAnimations(p123, p124 .. ".fillingAnimationNodes", p122.components, p122, p122.i3dMappings)
		p125.rotationNodesSpeedReverseFillLevel = p123:getValue(p124 .. ".animationNodes#speedReverseFillLevel")
	end
end
function Combine.loadCombineSamples(p126, p127, p128, p129)
	if p126.isClient then
		p129.samples = {}
		p129.samples.start = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "start", p126.baseDirectory, p126.components, 1, AudioGroup.VEHICLE, p126.i3dMappings, p126)
		p129.samples.stop = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "stop", p126.baseDirectory, p126.components, 1, AudioGroup.VEHICLE, p126.i3dMappings, p126)
		p129.samples.work = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "work", p126.baseDirectory, p126.components, 0, AudioGroup.VEHICLE, p126.i3dMappings, p126)
		p129.samples.chopperStart = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "chopperStart", p126.baseDirectory, p126.components, 1, AudioGroup.VEHICLE, p126.i3dMappings, p126)
		p129.samples.chopperStop = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "chopperStop", p126.baseDirectory, p126.components, 1, AudioGroup.VEHICLE, p126.i3dMappings, p126)
		p129.samples.chopperWork = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "chopperWork", p126.baseDirectory, p126.components, 0, AudioGroup.VEHICLE, p126.i3dMappings, p126)
		p129.samples.chopStraw = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "chopStraw", p126.baseDirectory, p126.components, 0, AudioGroup.VEHICLE, p126.i3dMappings, p126)
		p129.samples.dropStraw = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "dropStraw", p126.baseDirectory, p126.components, 0, AudioGroup.VEHICLE, p126.i3dMappings, p126)
		p129.samples.fill = g_soundManager:loadSampleFromXML(p127, p128 .. ".sounds", "fill", p126.baseDirectory, p126.components, 0, AudioGroup.VEHICLE, p126.i3dMappings, p126)
	end
end
function Combine.setIsSwathActive(p130, p131, p132, p133)
	local v134 = p130.spec_combine
	if p131 ~= v134.isSwathActive or p133 then
		CombineStrawEnableEvent.sendEvent(p130, p131, p132)
		v134.isSwathActive = p131
		local v135 = v134.chopper.animName
		if p130.playAnimation ~= nil and v135 ~= nil then
			p130:playAnimation(v135, (p131 and -1 or 1) * v134.chopper.animSpeedScale, p130:getAnimationTime(v135), true)
			if p133 then
				AnimatedVehicle.updateAnimationByName(p130, v135, 9999999, true)
			end
		end
		local v136 = v134.processing.inputBuffer
		for v137 = 1, #v136.buffer do
			v136.buffer[v137].liters = 0
		end
		if p130:getIsTurnedOn() and p130.isClient then
			if v134.isSwathActive then
				g_animationManager:stopAnimations(v134.chopperAnimationNodes)
				g_animationManager:startAnimations(v134.strawDropAnimationNodes)
				if g_soundManager:getIsSamplePlaying(v134.samples.chopperWork) then
					g_soundManager:stopSample(v134.samples.chopperWork)
					g_soundManager:playSample(v134.samples.chopperStop)
				end
			else
				g_animationManager:stopAnimations(v134.strawDropAnimationNodes)
				g_animationManager:startAnimations(v134.chopperAnimationNodes)
				g_soundManager:stopSample(v134.samples.chopperStop)
				g_soundManager:playSample(v134.samples.chopperStart)
				g_soundManager:playSample(v134.samples.chopperWork, 0, v134.samples.chopperStart)
			end
		end
		Combine.updateToggleStrawText(p130)
	end
end
function Combine.processCombineChopperArea(p138, p139)
	local v140 = p138.spec_combine
	if not v140.isSwathActive then
		local v141 = v140.workAreaParameters.litersToDrop
		local v142 = v140.workAreaParameters.strawRatio
		local v143 = v140.workAreaParameters.strawGroundType
		local v144 = v140.workAreaParameters.strawHaulmFruitTypeIndex
		v140.workAreaParameters.droppedLiters = v141
		if v141 > 0 and v142 > 0 then
			if v142 > 0.5 then
				local v145, _, v146 = getWorldTranslation(p139.start)
				local v147, _, v148 = getWorldTranslation(p139.width)
				local v149, _, v150 = getWorldTranslation(p139.height)
				if v144 == nil then
					if v143 ~= nil and Platform.gameplay.useSprayDiffuseMaps then
						FSDensityMapUtil.setGroundTypeLayerArea(v145, v146, v147, v148, v149, v150, v143)
						FSDensityMapUtil.eraseTireTrack(v145, v146, v147, v148, v149, v150)
					end
				elseif FSDensityMapUtil.updateFruitHaulmArea(v144, v145, v146, v147, v148, v149, v150) > 0 then
					FSDensityMapUtil.eraseTireTrack(v145, v146, v147, v148, v149, v150)
				end
				FSDensityMapUtil.setStubbleShredLevelArea(v145, v146, v147, v148, v149, v150, 1)
			end
			p138:raiseActive()
			v140.workAreaParameters.isChopperEffectEnabled = 500
			return 1, 1
		end
	end
	return 0, 0
end
function Combine.processCombineSwathArea(p151, p152)
	local v153 = p151.spec_combine
	local v154 = v153.workAreaParameters.litersToDrop
	if not v153.isSwathActive or v154 <= 0 then
		return 0, 0
	end
	local v155 = 0
	local v156 = g_fruitTypeManager:getFruitTypeByFillTypeIndex(v153.workAreaParameters.dropFillType)
	if v156 ~= nil and v156.windrowLiterPerSqm ~= nil then
		local v157 = g_fruitTypeManager:getWindrowFillTypeIndexByFruitTypeIndex(v156.index)
		if v157 ~= nil then
			local v158, v159, v160, v161, v162, v163 = DensityMapHeightUtil.getLineByArea(p152.start, p152.width, p152.height, true)
			local v164
			v155, v164 = DensityMapHeightUtil.tipToGroundAroundLine(p151, v154, v157, v158, v159, v160, v161, v162, v163, 0, nil, p152.lineOffset, false, nil, false)
			p152.lineOffset = v164
		end
	end
	if v155 > 0 then
		v153.workAreaParameters.isStrawEffectEnabled = 500
	end
	v153.workAreaParameters.droppedLiters = v155
	return 1, 1
end
function Combine.setChopperPSEnabled(p165, p166, p167, p168, p169)
	local v170 = p165.spec_combine
	if v170.chopperPSenabled ~= p166 or p167 then
		v170.chopperPSenabled = p166
		if p165.isServer and p169 then
			v170.sentChopperPSenabled = p166
		end
		if p165.isClient then
			if not p166 or p167 then
				g_effectManager:stopEffects(v170.chopperEffects)
			end
			if p166 then
				g_effectManager:setEffectTypeInfo(v170.chopperEffects, p165:getCombineLastValidFillType())
				g_effectManager:startEffects(v170.chopperEffects)
				if not g_soundManager:getIsSamplePlaying(v170.samples.chopStraw) then
					g_soundManager:playSample(v170.samples.chopStraw)
				end
			elseif g_soundManager:getIsSamplePlaying(v170.samples.chopStraw) then
				g_soundManager:stopSample(v170.samples.chopStraw)
			end
		end
	end
	if v170.chopperPSenabled and p168 ~= nil then
		g_effectManager:setDensity(v170.chopperEffects, p168)
	end
end
function Combine.setStrawPSEnabled(p171, p172, p173, p174, p175)
	local v176 = p171.spec_combine
	if v176.strawPSenabled ~= p172 or p173 then
		v176.strawPSenabled = p172
		if p171.isServer and p175 then
			v176.sentStrawPSenabled = p172
		end
		if not p172 then
			v176.strawToDrop = 0
		end
		if p171.isClient then
			if not p172 or p173 then
				g_effectManager:stopEffects(v176.strawEffects)
			end
			if p172 then
				g_effectManager:setEffectTypeInfo(v176.strawEffects, p171:getCombineLastValidFillType())
				g_effectManager:startEffects(v176.strawEffects)
				if not g_soundManager:getIsSamplePlaying(v176.samples.dropStraw) then
					g_soundManager:playSample(v176.samples.dropStraw)
				end
			elseif g_soundManager:getIsSamplePlaying(v176.samples.dropStraw) then
				g_soundManager:stopSample(v176.samples.dropStraw)
			end
		end
	end
	if v176.strawPSenabled and p174 ~= nil then
		g_effectManager:setDensity(v176.strawEffects, p174)
	end
end
function Combine.setCombineIsFilling(p177, p178, p179, p180)
	local v181 = p177.spec_combine
	if v181.isFilling ~= p178 or p179 then
		v181.isFilling = p178
		if p177.isServer and p180 then
			v181.sentIsFilling = p178
		end
		if p177.isClient then
			if p178 then
				g_animationManager:startAnimations(v181.fillingAnimationNodes)
			else
				g_animationManager:stopAnimations(v181.fillingAnimationNodes)
			end
			g_animationManager:setFillType(v181.fillingAnimationNodes, p177:getCombineLastValidFillType())
			g_effectManager:setEffectTypeInfo(v181.effects, p177:getCombineLastValidFillType(v181.fillUnitIndex))
			if not p178 or p179 then
				g_effectManager:stopEffects(v181.fillEffects)
			end
			if p178 then
				g_effectManager:setEffectTypeInfo(v181.fillEffects, p177:getCombineLastValidFillType())
				g_effectManager:startEffects(v181.fillEffects)
			end
			if p178 then
				if not g_soundManager:getIsSamplePlaying(v181.samples.fill) then
					g_soundManager:playSample(v181.samples.fill)
					return
				end
			elseif g_soundManager:getIsSamplePlaying(v181.samples.fill) then
				g_soundManager:stopSample(v181.samples.fill)
			end
		end
	end
end
function Combine.startThreshing(p182)
	local v183 = p182.spec_combine
	if v183.numAttachedCutters > 0 then
		for _, v184 in pairs(v183.attachedCutters) do
			v184:setIsTurnedOn(true, true)
		end
		if v183.threshingStartAnimation ~= nil and p182.playAnimation ~= nil then
			p182:playAnimation(v183.threshingStartAnimation, v183.threshingStartAnimationSpeedScale, p182:getAnimationTime(v183.threshingStartAnimation), true)
		end
		if p182.isClient then
			g_soundManager:stopSample(v183.samples.stop)
			g_soundManager:stopSample(v183.samples.work)
			g_soundManager:playSample(v183.samples.start)
			g_soundManager:playSample(v183.samples.work, 0, v183.samples.start)
		end
		SpecializationUtil.raiseEvent(p182, "onStartThreshing")
	end
end
function Combine.stopThreshing(p185)
	local v186 = p185.spec_combine
	if p185.isClient then
		g_soundManager:stopSample(v186.samples.start)
		g_soundManager:stopSample(v186.samples.work)
		g_soundManager:playSample(v186.samples.stop)
	end
	p185:setCombineIsFilling(false, false, true)
	local v187 = p185:getCombineFillLevelPercentage() > 0.999
	if v187 and p185.rootVehicle.setCruiseControlState ~= nil then
		p185.rootVehicle:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF)
	end
	for v188, _ in pairs(v186.attachedCutters) do
		if v187 then
			if v188.getAttacherVehicle ~= nil then
				local v189 = v188:getAttacherVehicle()
				if v189 ~= nil then
					v189:handleLowerImplementEvent(v188, false)
				end
			end
			if v188.setFoldMiddleState ~= nil then
				v188:setFoldMiddleState(false)
			end
		end
		v188:setIsTurnedOn(false, true)
	end
	if v186.threshingStartAnimation ~= nil and v186.playAnimation ~= nil then
		p185:playAnimation(v186.threshingStartAnimation, -v186.threshingStartAnimationSpeedScale, p185:getAnimationTime(v186.threshingStartAnimation), true)
	end
	SpecializationUtil.raiseEvent(p185, "onStopThreshing")
end
function Combine.setWorkedHectars(p190, p191, p192)
	local v193 = p190.spec_combine
	v193.workedHectars = p191
	if p192 then
		v193.workedHectarsInitial = p191
	end
	if p190.isServer then
		local v194 = v193.workedHectars - v193.workedHectarsSent
		if math.abs(v194) > 0.01 then
			p190:raiseDirtyFlags(v193.dirtyFlag)
			v193.workedHectarsSent = v193.workedHectars
		end
	end
end
function Combine.addCutterToCombine(p195, p196)
	local v197 = p195.spec_combine
	if v197.attachedCutters[p196] == nil then
		v197.attachedCutters[p196] = p196
		v197.numAttachedCutters = v197.numAttachedCutters + 1
		local v198 = p195.spec_combine.ladder
		if v198.unfoldWhileCutterAttached and (v198.animName ~= nil and p195:getAnimationTime(v198.animName) < 1) then
			p195:playAnimation(v198.animName, v198.animSpeedScale, p195:getAnimationTime(v198.animName), true)
		end
	end
end
function Combine.removeCutterFromCombine(p199, p200)
	local v201 = p199.spec_combine
	if v201.attachedCutters[p200] ~= nil then
		v201.numAttachedCutters = v201.numAttachedCutters - 1
		if v201.numAttachedCutters == 0 then
			p199:setIsTurnedOn(false, true)
			if v201.isBufferCombine then
				local v202 = p199:getFillUnitFillType(v201.fillUnitIndex)
				if v202 ~= FillType.UNKNOWN then
					p199:addFillUnitFillLevel(p199:getOwnerFarmId(), v201.fillUnitIndex, (-1 / 0), v202, ToolType.UNDEFINED, nil)
				end
			end
		end
		v201.attachedCutters[p200] = nil
		local v203 = p199.spec_combine.ladder
		if v203.unfoldWhileCutterAttached and v203.animName ~= nil then
			local v204 = true
			if p199.getFoldAnimTime ~= nil then
				local v205 = p199:getFoldAnimTime()
				if v203.foldMaxLimit < v205 or v205 < v203.foldMinLimit then
					v204 = false
				end
			end
			if v204 then
				p199:playAnimation(v203.animName, -v203.animSpeedScale, p199:getAnimationTime(v203.animName), true)
			end
		end
		if Platform.gameplay.automaticVehicleControl and (next(v201.attachedCutters) == nil and p199:getActionControllerDirection() == -1) then
			p199:playControlledActions()
		end
	end
end
function Combine.addCutterArea(p206, p207, p208, p209, p210, p211, p212, p213)
	local v214 = p206.spec_combine
	if p207 <= 0 and p208 <= 0 or v214.lastCuttersFruitType ~= FruitType.UNKNOWN and (v214.lastCuttersArea ~= 0 and v214.lastCuttersOutputFillType ~= p210) then
		return 0
	end
	v214.lastCuttersArea = v214.lastCuttersArea + p207
	v214.lastCuttersOutputFillType = p210
	v214.lastCuttersInputFruitType = p209
	v214.lastCuttersAreaTime = g_currentMission.time
	v214.lastAreaZeroTime = 0
	local v215 = p208 * v214.threshingScale
	if p206:getIsThreshingDuringRain() and p206.propertyState ~= VehiclePropertyState.MISSION then
		v215 = v215 * (1 - Combine.RAIN_YIELD_REDUCTION)
	end
	if p212 ~= AccessHandler.EVERYONE then
		local v216 = p206:getVehicleDamage()
		if v216 > 0 then
			v215 = v215 * (1 - v216 * Combine.DAMAGED_YIELD_REDUCTION)
		end
	end
	if p206:getFillUnitLastValidFillType(v214.fillUnitIndex) == p210 or p206:getFillUnitLastValidFillType(v214.bufferFillUnitIndex) == p210 then
		if p209 == nil then
			p209 = g_fruitTypeManager:getFruitTypeIndexByFillTypeIndex(p210)
		end
		if p209 ~= nil then
			local v217 = v214.processing.inputBuffer
			local v218 = v217.buffer[v217.fillIndex]
			local v219 = g_fruitTypeManager:getFruitTypeByIndex(p209)
			if v219.chopperType == nil then
				if v219.chopperUseHaulm then
					v218.strawGroundType = nil
					v218.strawHaulmFruitTypeIndex = p209
				end
			else
				v218.strawGroundType = FieldChopperType.getValueByType(v219.chopperType)
				v218.strawHaulmFruitTypeIndex = nil
			end
			local v220 = p208 / v219.literPerSqm * (v219.windrowLiterPerSqm or v219.literPerSqm)
			v218.area = v218.area + p207
			v218.liters = v218.liters + v220
			v218.inputLiters = v218.inputLiters + v220
			v218.strawRatio = p211
			v218.effectDensity = p213 * p211 * 0.8 + 0.2
		end
	end
	if v214.fillEnableTime == nil then
		v214.fillEnableTime = g_currentMission.time + v214.processing.toggleTime
	end
	if v214.additives.available then
		local v221 = false
		for v222 = 1, #v214.additives.fillTypes do
			if p210 == v214.additives.fillTypes[v222] then
				v221 = true
				break
			end
		end
		if v221 then
			local v223 = p206:getFillUnitFillLevel(v214.additives.fillUnitIndex)
			if v223 > 0 then
				local v224 = v214.additives.usage * v215
				if v224 > 0 then
					local v225 = v223 / v224
					v215 = v215 * (1 + 0.05 * math.min(v225, 1))
					p206:addFillUnitFillLevel(p206:getOwnerFarmId(), v214.additives.fillUnitIndex, -v224, p206:getFillUnitFillType(v214.additives.fillUnitIndex), ToolType.UNDEFINED)
				end
			end
		end
	end
	p206:setWorkedHectars(v214.workedHectars + MathUtil.areaToHa(p207, g_currentMission:getFruitPixelsToSqm()))
	if p206:getFillUnitCapacity(v214.fillUnitIndex) == (1 / 0) and (p206:getFillUnitFillLevel(v214.fillUnitIndex) > 0.001 and v214.lastDischargeTime + v214.fillLevelBufferTime < g_time) then
		return v215
	else
		local v226 = v214.fillUnitIndex
		if v214.bufferFillUnitIndex ~= nil and p206:getFillUnitFreeCapacity(v214.bufferFillUnitIndex) > 0 then
			v226 = v214.bufferFillUnitIndex
		end
		if v214.loadingDelay > 0 then
			for v227 = 1, #v214.loadingDelaySlots do
				if not v214.loadingDelaySlots[v227].valid then
					v214.loadingDelaySlots[v227].valid = true
					v214.loadingDelaySlots[v227].fillLevelDelta = v215
					v214.loadingDelaySlots[v227].fillType = p210
					if v214.loadingDelaySlotsDelayedInsert then
						v214.loadingDelaySlots[v227].time = g_time
					else
						v214.loadingDelaySlots[v227].time = g_time + (v214.unloadingDelay - v214.loadingDelay)
					end
					v214.loadingDelaySlotsDelayedInsert = not v214.loadingDelaySlotsDelayedInsert
					return v215
				end
			end
			return v215
		else
			local v228 = p206:getFillVolumeLoadInfo(v214.loadInfoIndex)
			return p206:addFillUnitFillLevel(p206:getOwnerFarmId(), v226, v215, p210, ToolType.UNDEFINED, v228)
		end
	end
end
function Combine.getIsThreshingDuringRain(p229, p230)
	if not p229.spec_combine.allowThreshingDuringRain then
		local v231 = g_currentMission.environment.weather:getRainFallScale()
		local v232 = g_currentMission.environment.weather:getTimeSinceLastRain()
		if p230 == nil or p230 ~= true then
			if v231 >= 0.1 and v232 < 20 then
				return true
			end
		elseif v231 >= 0.02 and v232 < 20 then
			return true
		end
	end
	return false
end
function Combine.verifyCombine(p233, p234, p235)
	local v236 = p233.spec_combine
	local v237 = v236.bufferFillUnitIndex or v236.fillUnitIndex
	if p233:getFillUnitFillLevelPercentage(v237) > p233:getFillTypeChangeThreshold() or v236.isBufferCombine then
		local v238 = p233:getFillUnitFillType(v237)
		if v238 ~= FillType.UNKNOWN and (p234 ~= FruitType.UNKNOWN and v238 ~= p235) then
			if not v236.isBufferCombine then
				return nil, p233, v238
			end
			p233:addFillUnitFillLevel(p233:getOwnerFarmId(), v237, (-1 / 0), v238, ToolType.UNDEFINED, nil)
			return p233
		end
	end
	if (v236.bufferFillUnitIndex == nil and 0 or p233:getFillUnitFillLevel(v236.bufferFillUnitIndex)) >= p233:getFillUnitFreeCapacity(v236.fillUnitIndex) then
		return nil
	else
		return p233
	end
end
function Combine.getFillLevelDependentSpeed(p239)
	local v240 = p239.spec_combine
	return v240.rotationNodesSpeedReverseFillLevel == nil and 1 or (p239:getFillUnitFillLevel(v240.fillUnitIndex) / p239:getFillUnitCapacity(v240.fillUnitIndex) > v240.rotationNodesSpeedReverseFillLevel and -1 or 1)
end
function Combine.getIsCutterCompatible(p241, p242)
	local v243 = p241:getFillUnitSupportedFillTypes(p241.spec_combine.fillUnitIndex)
	for v244 = 1, #p242 do
		local v245 = p242[v244]
		for v246, _ in pairs(v243) do
			if v245 == v246 then
				return true
			end
		end
	end
	return false
end
function Combine.getCombineLastValidFillType(p247)
	local v248 = p247.spec_combine
	local v249 = FillType.UNKNOWN
	if v248.bufferFillUnitIndex ~= nil then
		v249 = p247:getFillUnitLastValidFillType(v248.bufferFillUnitIndex)
	end
	if v249 == FillType.UNKNOWN then
		v249 = p247:getFillUnitLastValidFillType(v248.fillUnitIndex)
	end
	if v249 == FillType.UNKNOWN and v248.loadingDelay > 0 then
		for v250 = 1, #v248.loadingDelaySlots do
			if v248.loadingDelaySlots[v250].valid then
				v249 = v248.loadingDelaySlots[v250].fillType
				break
			end
		end
	end
	if v249 == FillType.UNKNOWN then
		v249 = v248.lastValidInputFillType
	end
	return v249
end
function Combine.getCombineFillLevelPercentage(p251)
	local v252 = p251.spec_combine
	local v253 = p251:getFillUnitFillLevel(v252.fillUnitIndex)
	if v252.loadingDelay > 0 then
		local v254 = p251:getFillUnitFillType(v252.fillUnitIndex)
		for _, v255 in pairs(v252.loadingDelaySlots) do
			if v255.valid and v255.fillType == v254 then
				v253 = v253 + v255.fillLevelDelta
			end
		end
	end
	local v256 = v253 / p251:getFillUnitCapacity(v252.fillUnitIndex)
	return math.min(v256, 1)
end
function Combine.getCombineLoadPercentage(p257)
	local v258 = p257.spec_combine
	if v258 == nil or v258.numAttachedCutters <= 0 then
		return 0
	end
	local v259 = 0
	for v260, _ in pairs(v258.attachedCutters) do
		if v260.getCutterLoad ~= nil then
			v259 = v259 + v260:getCutterLoad()
		end
	end
	return v259 / v258.numAttachedCutters
end
g_soundManager:registerModifierType("COMBINE_LOAD", Combine.getCombineLoadPercentage)
function Combine.getCanBeTurnedOn(p261, p262)
	local v263 = p261.spec_combine
	if v263.numAttachedCutters <= 0 then
		return false
	end
	for v264, _ in pairs(v263.attachedCutters) do
		if v264 ~= p261 and (v264.getCanBeTurnedOn ~= nil and not v264:getCanBeTurnedOn()) then
			return false
		end
	end
	return p262(p261)
end
function Combine.getTurnedOnNotAllowedWarning(p265, p266)
	if p265:getIsActiveForInput(true) then
		local v267 = p265.spec_combine
		if not p265:getCanBeTurnedOn() then
			if v267.numAttachedCutters == 0 then
				return v267.texts.warningNoCutter
			end
			for v268, _ in pairs(v267.attachedCutters) do
				if v268 ~= p265 and v268.getTurnedOnNotAllowedWarning ~= nil then
					local v269 = v268:getTurnedOnNotAllowedWarning()
					if v269 ~= nil then
						return v269
					end
				end
			end
		end
	end
	return p266(p265)
end
function Combine.getAreControlledActionsAllowed(p270, p271)
	if p270:getActionControllerDirection() == 1 then
		local v272 = p270.spec_combine
		if v272.numAttachedCutters <= 0 then
			return false, v272.texts.warningNoCutter
		end
	end
	return p271(p270)
end
function Combine.getIsFoldAllowed(p273, p274, p275, p276)
	local v277 = p273.spec_combine
	if v277.allowFoldWhileThreshing or not p273:getIsTurnedOn() then
		local v278 = p273:getFillUnitFillLevel(v277.fillUnitIndex)
		if p275 == v277.foldDirection and (v277.foldFillLevelThreshold < v278 and p273:getFillUnitCapacity(v277.fillUnitIndex) ~= (1 / 0)) then
			return false, v277.texts.warningFoldingWhileFilled
		else
			return p274(p273, p275, p276)
		end
	else
		return false, v277.texts.warningFoldingTurnedOn
	end
end
function Combine.getCanBeSelected(_, _)
	return true
end
function Combine.loadWorkAreaFromXML(p279, p280, p281, p282, p283)
	if not p280(p279, p281, p282, p283) then
		return false
	end
	if p281.type == WorkAreaType.COMBINECHOPPER or p281.type == WorkAreaType.COMBINESWATH then
		if p282:getValue(p283 .. "#requiresOwnedFarmland") == nil then
			p281.requiresOwnedFarmland = false
		end
		if p282:getValue(p283 .. "#needsSetIsTurnedOn") == nil then
			p281.needsSetIsTurnedOn = false
		end
	end
	return true
end
function Combine.getDirtMultiplier(p284, p285)
	local v286 = p284.spec_combine
	for v287, _ in pairs(v286.attachedCutters) do
		if v287.spec_cutter ~= nil and v287.spec_cutter.isWorking then
			return p285(p284) + p284:getWorkDirtMultiplier() * p284:getLastSpeed() / v287.speedLimit
		end
	end
	return p285(p284)
end
function Combine.getWearMultiplier(p288, p289)
	local v290 = p288.spec_combine
	for v291, _ in pairs(v290.attachedCutters) do
		if v291.spec_cutter ~= nil and v291.spec_cutter.isWorking then
			local v292 = v291:getCutterStoneMultiplier()
			return p289(p288) + p288:getWorkWearMultiplier() * p288:getLastSpeed() / v291.speedLimit * v292
		end
	end
	return p289(p288)
end
function Combine.loadTurnedOnAnimationFromXML(p293, p294, p295, p296, p297)
	p297.activeChopper = p295:getValue(p296 .. "#activeChopper", true)
	p297.activeStrawDrop = p295:getValue(p296 .. "#activeStrawDrop", true)
	p297.waitForStraw = p295:getValue(p296 .. "#waitForStraw", false)
	return p294(p293, p295, p296, p297)
end
function Combine.getIsTurnedOnAnimationActive(p298, p299, p300)
	local v301 = p298.spec_combine
	if (p300.activeChopper or v301.isSwathActive) and (p300.activeStrawDrop or not v301.isSwathActive) then
		if p300.waitForStraw then
			return p299(p298, p300) or v301.workAreaParameters.isChopperEffectEnabled > 0
		else
			return p299(p298, p300)
		end
	else
		return false
	end
end
function Combine.loadRandomlyMovingPartFromXML(p302, p303, p304, p305, p306)
	local v307 = p303(p302, p304, p305, p306)
	p304.moveOnlyIfCut = p305:getValue(p306 .. "#moveOnlyIfCut", false)
	return v307
end
function Combine.getIsRandomlyMovingPartActive(p308, p309, p310)
	local v311 = p309(p308, p310)
	if p310.moveOnlyIfCut then
		local v312 = p308.spec_combine
		local v313 = false
		for _, v314 in pairs(v312.attachedCutters) do
			v313 = v313 or v314.spec_cutter.lastAreaBiggerZeroTime >= g_currentMission.time - 150
		end
		v311 = v311 and v313
	end
	return v311
end
function Combine.getDischargeFillType(p315, p316, p317)
	local v318, v319 = p316(p315, p317)
	if v318 == FillType.UNKNOWN then
		local v320 = p315.spec_combine
		if v320.loadingDelay > 0 then
			for v321 = 1, #v320.loadingDelaySlots do
				local v322 = v320.loadingDelaySlots[v321]
				if v322.valid and (v322.fillLevelDelta > 0 and v322.fillType ~= 0) then
					local v323 = v322.fillType
					if p317.fillTypeConverter ~= nil then
						local v324 = p317.fillTypeConverter[v323]
						if v324 ~= nil then
							v323 = v324.targetFillTypeIndex
							v319 = v324.conversionFactor
						end
					end
					return v323, v319
				end
			end
		end
	end
	return v318, v319
end
function Combine.getImplementAllowAutomaticSteering(_, _)
	return true
end
function Combine.onRegisterActionEvents(p325, _, p326)
	if p325.isClient then
		local v327 = p325.spec_combine
		p325:clearActionEventsTable(v327.actionEvents)
		if p326 and (v327.swath.isAvailable and v327.chopper.isAvailable) then
			local v328 = p325.addActionEvent
			if v327.chopper.isPowered then
				v328 = p325.addPoweredActionEvent
			end
			local _, v329 = v328(p325, v327.actionEvents, InputAction.TOGGLE_CHOPPER, p325, Combine.actionEventToggleChopper, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v329, GS_PRIO_NORMAL)
			Combine.updateToggleStrawText(p325)
		end
	end
end
function Combine.onStartWorkAreaProcessing(p330, p331)
	local v332 = p330.spec_combine
	v332.workAreaParameters.droppedLiters = 0
	v332.workAreaParameters.litersToDrop = 0
	v332.workAreaParameters.strawRatio = 0
	v332.workAreaParameters.dropFillType = FillType.UNKNOWN
	local v333 = p330:getFillUnitLastValidFillType(v332.bufferFillUnitIndex or v332.fillUnitIndex)
	if v333 ~= FillType.UNKNOWN then
		local v334 = v332.processing.inputBuffer
		local v335 = v334.buffer[v334.dropIndex].inputLiters
		local v336 = v334.buffer[v334.dropIndex].liters
		if v334.slotDuration == 0 then
			v332.workAreaParameters.litersToDrop = v336
		else
			local v337 = p331 / v334.slotDuration * v335
			local v338 = math.min(v336, v337)
			if v338 > 0 then
				local v339 = g_fruitTypeManager:getFruitTypeByFillTypeIndex(v333)
				if v339 ~= nil and v339.windrowLiterPerSqm ~= nil then
					local v340 = g_fruitTypeManager:getWindrowFillTypeIndexByFruitTypeIndex(v339.index)
					if v340 ~= nil then
						local v341 = g_densityMapHeightManager:getMinValidLiterValue(v340)
						local v342 = math.min(v341, v336)
						v338 = math.max(v338, v342)
					end
				end
			end
			v332.workAreaParameters.litersToDrop = v338
		end
		v332.workAreaParameters.strawRatio = v334.buffer[v334.dropIndex].strawRatio
		v332.workAreaParameters.strawGroundType = v334.buffer[v334.dropIndex].strawGroundType
		v332.workAreaParameters.strawHaulmFruitTypeIndex = v334.buffer[v334.dropIndex].strawHaulmFruitTypeIndex
		v332.workAreaParameters.effectDensity = v334.buffer[v334.dropIndex].effectDensity
		v332.workAreaParameters.dropFillType = v333
	end
end
function Combine.onEndWorkAreaProcessing(p343, _, _)
	local v344 = p343.spec_combine
	local v345 = v344.processing.inputBuffer
	local v346 = v345.buffer[v345.dropIndex]
	local v347 = v345.buffer[v345.dropIndex].liters - v344.workAreaParameters.droppedLiters
	v346.liters = math.max(0, v347)
end
function Combine.onChangedFillType(p348, p349, p350)
	local v351 = p348.spec_combine
	if (v351.bufferFillUnitIndex ~= nil and p349 == v351.bufferFillUnitIndex or p349 == v351.fillUnitIndex) and p350 ~= FillType.UNKNOWN then
		if p350 ~= v351.lastEffectFillType then
			if v351.chopperPSenabled then
				p348:setChopperPSEnabled(true, true, 0, true)
			end
			if v351.strawPSenabled then
				p348:setStrawPSEnabled(true, true, 0, true)
			end
			if v351.isFilling then
				p348:setCombineIsFilling(true, true, true)
			end
		end
		v351.lastEffectFillType = p350
	end
end
function Combine.onDeactivate(p352)
	local v353 = p352.spec_combine
	p352:setChopperPSEnabled(false, false, 0, true)
	p352:setStrawPSEnabled(false, false, 0, true)
	p352:setCombineIsFilling(false, false, true)
	v353.fillEnableTime = nil
	v353.fillDisableTime = nil
end
function Combine.onPostAttachImplement(p354, p355, _, _)
	local v356 = p355:getActiveInputAttacherJoint()
	if v356 ~= nil and (v356.jointType == AttacherJoints.JOINTTYPE_CUTTER or v356.jointType == AttacherJoints.JOINTTYPE_CUTTERHARVESTER) then
		p354:addCutterToCombine(p355)
	end
end
function Combine.onPostDetachImplement(p357, p358)
	local v359 = p357:getObjectFromImplementIndex(p358)
	if v359 ~= nil then
		local v360 = v359:getActiveInputAttacherJoint()
		if v360 ~= nil and (v360.jointType == AttacherJoints.JOINTTYPE_CUTTER or v360.jointType == AttacherJoints.JOINTTYPE_CUTTERHARVESTER) then
			p357:removeCutterFromCombine(v359)
		end
	end
end
function Combine.onTurnedOn(p361)
	p361:startThreshing()
	local v362 = p361.spec_combine
	if p361.isClient then
		g_animationManager:startAnimations(v362.animationNodes)
		if v362.isSwathActive then
			g_animationManager:startAnimations(v362.strawDropAnimationNodes)
		else
			g_animationManager:startAnimations(v362.chopperAnimationNodes)
			g_soundManager:stopSample(v362.samples.chopperStop)
			g_soundManager:playSample(v362.samples.chopperStart)
			g_soundManager:playSample(v362.samples.chopperWork, 0, v362.samples.chopperStart)
		end
		g_effectManager:setEffectTypeInfo(v362.effects, p361:getCombineLastValidFillType())
		g_effectManager:startEffects(v362.effects)
	end
	if p361.isServer and (v362.turnOffWhenFull and p361:getCombineFillLevelPercentage() == 1) then
		p361:setIsTurnedOn(false)
	end
end
function Combine.onTurnedOff(p363)
	p363:stopThreshing()
	if p363.isClient then
		local v364 = p363.spec_combine
		g_animationManager:stopAnimations(v364.animationNodes)
		g_animationManager:stopAnimations(v364.chopperAnimationNodes)
		g_animationManager:stopAnimations(v364.strawDropAnimationNodes)
		g_effectManager:stopEffects(v364.effects)
		if g_soundManager:getIsSamplePlaying(v364.samples.chopperWork) then
			g_soundManager:stopSample(v364.samples.chopperWork)
			g_soundManager:playSample(v364.samples.chopperStop)
		end
	end
end
function Combine.onEnterVehicle(p365)
	local v366 = p365.spec_combine.ladder
	if v366.animName ~= nil then
		local v367 = true
		if p365.getFoldAnimTime ~= nil then
			local v368 = p365:getFoldAnimTime()
			if v366.foldMaxLimit < v368 or v368 < v366.foldMinLimit then
				v367 = false
			end
		end
		if v366.unfoldWhileCutterAttached and p365.spec_combine.numAttachedCutters > 0 then
			v367 = false
		end
		if v367 then
			p365:playAnimation(v366.animName, -v366.animSpeedScale, p365:getAnimationTime(v366.animName), true)
		end
	end
end
function Combine.onLeaveVehicle(p369)
	local v370 = p369.spec_combine.ladder
	if v370.animName ~= nil then
		local v371 = true
		if p369.getFoldAnimTime ~= nil then
			local v372 = p369:getFoldAnimTime()
			if v370.foldMaxLimit < v372 or v372 < v370.foldMinLimit then
				v371 = false
			end
		end
		if v370.unfoldWhileCutterAttached and p369.spec_combine.numAttachedCutters > 0 then
			v371 = false
		end
		if v371 then
			p369:playAnimation(v370.animName, v370.animSpeedScale, p369:getAnimationTime(v370.animName), true)
		end
	end
end
function Combine.onFoldStateChanged(p373, p374, p375)
	local v376 = p373.spec_combine.ladder
	if v376.animName ~= nil and (p374 ~= 0 and not p375) and (not v376.unfoldWhileCutterAttached or p373.spec_combine.numAttachedCutters <= 0) then
		p373:playAnimation(v376.animName, p374 * v376.animSpeedScale * v376.foldDirection, p373:getAnimationTime(v376.animName), true)
	end
end
function Combine.onFillUnitFillLevelChanged(p377, p378, p379, _, _, _, _)
	local v380 = p377.spec_combine
	if p378 == v380.fillUnitIndex then
		if p379 < 0 then
			v380.lastDischargeTime = g_time
		end
		if p377.isServer and (v380.turnOffWhenFull and p377:getCombineFillLevelPercentage() == 1) then
			p377:setIsTurnedOn(false)
		end
	end
end
function Combine.actionEventToggleChopper(p381, _, _, _, _)
	local v382 = p381.spec_combine
	if v382.swath.isAvailable then
		local v383 = v382.bufferFillUnitIndex or v382.fillUnitIndex
		local v384 = g_fruitTypeManager:getFruitTypeIndexByFillTypeIndex(p381:getFillUnitFillType(v383))
		if v384 ~= nil and v384 ~= FruitType.UNKNOWN then
			if g_fruitTypeManager:getFruitTypeByIndex(v384).hasWindrow then
				p381:setIsSwathActive(not v382.isSwathActive)
			else
				g_currentMission:showBlinkingWarning(g_i18n:getText("warning_couldNotToggleChopper"), 2000)
			end
		end
		p381:setIsSwathActive(not v382.isSwathActive)
	end
end
function Combine.updateToggleStrawText(p385)
	local v386 = p385.spec_combine
	local v387 = v386.actionEvents[InputAction.TOGGLE_CHOPPER]
	if v387 ~= nil and v387.actionEventId ~= nil then
		local v388
		if v386.isSwathActive then
			v388 = g_i18n:getText("action_disableStrawSwath")
		else
			v388 = g_i18n:getText("action_enableStrawSwath")
		end
		g_inputBinding:setActionEventText(v387.actionEventId, v388)
	end
end

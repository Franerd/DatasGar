SupportVehicle = {}
function SupportVehicle.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AttacherJoints, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Mountable, p1)
	end
	return v2
end
function SupportVehicle.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("SupportVehicle")
	v3:register(XMLValueType.STRING, "vehicle.supportVehicle#filename", "Path to support vehicle xml")
	v3:register(XMLValueType.INT, "vehicle.supportVehicle#attacherJointIndex", "Attacher joint index on support vehicle", 1)
	v3:register(XMLValueType.INT, "vehicle.supportVehicle#inputAttacherJointIndex", "Input attacher joint index on own vehicle", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.supportVehicle#terrainOffset", "Spawn Offset from terrain for the support vehicle", 0.2)
	v3:register(XMLValueType.FLOAT, "vehicle.supportVehicle#spawnOffset", "Tool will be moved this distance away in X direction of the attacher joint", 0.75)
	v3:register(XMLValueType.STRING, "vehicle.supportVehicle.configuration(?)#name", "Configuration name")
	v3:register(XMLValueType.INT, "vehicle.supportVehicle.configuration(?)#id", "Configuration id")
	v3:setXMLSpecializationType()
end
function SupportVehicle.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "addSupportVehicle", SupportVehicle.addSupportVehicle)
	SpecializationUtil.registerFunction(p4, "enableSupportVehicle", SupportVehicle.enableSupportVehicle)
	SpecializationUtil.registerFunction(p4, "removeSupportVehicle", SupportVehicle.removeSupportVehicle)
end
function SupportVehicle.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAllowMultipleAttachments", SupportVehicle.getAllowMultipleAttachments)
	SpecializationUtil.registerOverwrittenFunction(p5, "resolveMultipleAttachments", SupportVehicle.resolveMultipleAttachments)
	SpecializationUtil.registerOverwrittenFunction(p5, "getShowAttachableMapHotspot", SupportVehicle.getShowAttachableMapHotspot)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsReadyToFinishDetachProcess", SupportVehicle.getIsReadyToFinishDetachProcess)
	SpecializationUtil.registerOverwrittenFunction(p5, "startDetachProcess", SupportVehicle.startDetachProcess)
end
function SupportVehicle.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", SupportVehicle)
	SpecializationUtil.registerEventListener(p6, "onDelete", SupportVehicle)
	SpecializationUtil.registerEventListener(p6, "onUpdate", SupportVehicle)
	SpecializationUtil.registerEventListener(p6, "onPostDetach", SupportVehicle)
end
function SupportVehicle.onLoad(p7, _)
	local v8 = p7.spec_supportVehicle
	v8.attacherJointIndex = p7.xmlFile:getValue("vehicle.supportVehicle#attacherJointIndex", 1)
	v8.inputAttacherJointIndex = p7.xmlFile:getValue("vehicle.supportVehicle#inputAttacherJointIndex", 1)
	v8.terrainOffset = p7.xmlFile:getValue("vehicle.supportVehicle#terrainOffset", 0.2)
	v8.spawnOffset = p7.xmlFile:getValue("vehicle.supportVehicle#spawnOffset", 0.75)
	v8.heightChecks = {}
	local v9 = p7.xmlFile:getValue("vehicle.supportVehicle#filename")
	if v9 ~= nil then
		v8.filename = Utils.getFilename(v9, p7.customEnvironment)
		local v10 = g_storeManager:getItemByXMLFilename(v8.filename)
		if v10 == nil then
			Logging.xmlWarning(p7.xmlFile, "Unable to find support vehicle \'%s\'.", v9)
			v8.filename = nil
		else
			v8.storeItem = v10
			local v11 = StoreItemUtil.getSizeValues(v10.xmlFilename, "vehicle", v10.rotation)
			local v12 = v8.heightChecks
			local v13 = { v11.width / 2 + v11.widthOffset, v11.length / 2 + v11.lengthOffset }
			table.insert(v12, v13)
			local v14 = v8.heightChecks
			local v15 = { -v11.width / 2 + v11.widthOffset, v11.length / 2 + v11.lengthOffset }
			table.insert(v14, v15)
			local v16 = v8.heightChecks
			local v17 = { v11.width / 2 + v11.widthOffset, -v11.length / 2 + v11.lengthOffset }
			table.insert(v16, v17)
			local v18 = v8.heightChecks
			local v19 = { -v11.width / 2 + v11.widthOffset, -v11.length / 2 + v11.lengthOffset }
			table.insert(v18, v19)
		end
	end
	v8.configurations = {}
	local v20 = 0
	while true do
		local v21 = string.format("%s.configuration(%d)", "vehicle.supportVehicle", v20)
		if not p7.xmlFile:hasProperty(v21) then
			break
		end
		local v22 = p7.xmlFile:getValue(v21 .. "#name")
		local v23 = p7.xmlFile:getValue(v21 .. "#id")
		if v22 ~= nil and v23 ~= nil then
			v8.configurations[v22] = v23
		end
		v20 = v20 + 1
	end
	v8.firstRun = true
	v8.loadedSupportVehicle = nil
	v8.isLoadingSupportVehicle = false
	if not p7.isServer or v8.storeItem == nil then
		SpecializationUtil.removeEventListener(p7, "onDelete", SupportVehicle)
		SpecializationUtil.removeEventListener(p7, "onUpdate", SupportVehicle)
		SpecializationUtil.removeEventListener(p7, "onPostDetach", SupportVehicle)
	end
end
function SupportVehicle.onDelete(p24)
	if not p24.isReconfigurating then
		p24:removeSupportVehicle()
	end
end
function SupportVehicle.onPostDetach(p25, _, _)
	p25:enableSupportVehicle()
end
function SupportVehicle.onUpdate(p26, _, _, _, _)
	local v27 = p26.spec_supportVehicle
	if v27.firstRun and not g_currentMission.vehicleSystem.isReloadRunning then
		if p26:getAttacherVehicle() == nil then
			p26:addSupportVehicle(false)
		elseif v27.supportVehicle == nil then
			local v28 = p26:getAttacherVehicle()
			if v28.configFileName == v27.filename then
				v27.supportVehicle = v28
				v27.supportVehicle:setIsSupportVehicle()
				p26:setReducedComponentMass(true)
			end
		end
		v27.firstRun = false
	end
end
function SupportVehicle.addSupportVehicle(p29, p30)
	local v31 = p29.spec_supportVehicle
	if v31.storeItem ~= nil and (v31.supportVehicle == nil and (not v31.isLoadingSupportVehicle and v31.loadedSupportVehicle == nil)) then
		local v32 = p29:getInputAttacherJointByJointDescIndex(v31.inputAttacherJointIndex)
		if v32 ~= nil then
			local v33, _, v34 = getWorldTranslation(v32.node)
			if p30 == true then
				local v35, _, v36 = localDirectionToWorld(v32.node, 1, 0, 0)
				v33 = v33 + v35 * v31.spawnOffset
				v34 = v34 + v36 * v31.spawnOffset
			end
			local v37 = getTerrainHeightAtWorldPos(g_terrainNode, v33, 0, v34) + v31.terrainOffset
			local v38, v39, v40 = localRotationToWorld(v32.node, -3.141592653589793, 0, -3.141592653589793)
			v31.isLoadingSupportVehicle = true
			local v41 = VehicleLoadingData.new()
			v41:setStoreItem(v31.storeItem)
			v41:setPosition(v33, v37, v34)
			v41:setRotation(v38, v39, v40)
			v41:setPropertyState(VehiclePropertyState.NONE)
			v41:setOwnerFarmId(p29:getActiveFarm())
			v41:setConfigurations(v31.configurations)
			v41:load(SupportVehicle.supportVehicleLoaded, p29, {
				["isDetach"] = p30
			})
		end
	end
end
function SupportVehicle.supportVehicleLoaded(p42, p43, p44, p45)
	local v46 = p42.spec_supportVehicle
	if p44 == VehicleLoadingState.OK and #p43 > 0 then
		if p42.isDeleted then
			for _, v47 in ipairs(p43) do
				v47:delete()
			end
		else
			v46.loadedSupportVehicle = p43[1]
			if p45.isDetach ~= true then
				p42:enableSupportVehicle()
			end
		end
	end
	v46.isLoadingSupportVehicle = false
end
function SupportVehicle.enableSupportVehicle(p48)
	local v49 = p48.spec_supportVehicle
	if v49.loadedSupportVehicle ~= nil then
		local v50 = v49.loadedSupportVehicle
		v49.loadedSupportVehicle = nil
		v50:setIsSupportVehicle()
		p48:setReducedComponentMass(true)
		local v51 = p48:getInputAttacherJointByJointDescIndex(v49.inputAttacherJointIndex)
		if v51 ~= nil then
			local v52 = v51.jointOrigOffsetComponent
			local v53 = v51.jointOrigRotOffsetComponent
			if v50.getAttacherJointByJointDescIndex ~= nil then
				local v54 = v50:getAttacherJointByJointDescIndex(v49.attacherJointIndex)
				if v54 ~= nil then
					local v55, v56, v57 = getWorldTranslation(v50.rootNode)
					local v58, v59, v60 = getWorldRotation(v50.rootNode)
					local v61, v62, v63 = localDirectionToWorld(v50.rootNode, v54.jointOrigOffsetComponent[1], 0, v54.jointOrigOffsetComponent[3])
					local v64 = v55 - v61
					local v65 = v56 - v62
					local v66 = v57 - v63
					local v67 = getTerrainHeightAtWorldPos(g_terrainNode, v64, 0, v66) + v49.terrainOffset
					local v68 = math.max(v67, v65)
					v50:removeFromPhysics()
					v50:setAbsolutePosition(v64, v68, v66, v58, v59, v60)
					v50:addToPhysics()
					local v69, v70, v71 = localToWorld(v54.jointTransform, unpack(v52))
					local v72, v73, v74 = localRotationToWorld(v54.jointTransform, unpack(v53))
					p48:removeFromPhysics()
					p48:setAbsolutePosition(v69, v70, v71, v72, v73, v74)
					p48:addToPhysics()
					v50:attachImplement(p48, v49.inputAttacherJointIndex, v49.attacherJointIndex, true, nil, nil, true)
					p48.rootVehicle:updateSelectableObjects()
					p48.rootVehicle:setSelectedVehicle(p48)
					v49.supportVehicle = v50
					return
				end
			end
		end
		v50:delete()
	end
end
function SupportVehicle.removeSupportVehicle(p75)
	local v76 = p75.spec_supportVehicle
	if v76.supportVehicle ~= nil and not v76.supportVehicle.isDeleted then
		v76.supportVehicle:delete()
	end
	v76.supportVehicle = nil
	if p75.isServer and p75.components ~= nil then
		p75:setReducedComponentMass(false)
	end
end
function SupportVehicle.getAllowMultipleAttachments(p77, _)
	return p77.spec_supportVehicle.filename ~= nil
end
function SupportVehicle.resolveMultipleAttachments(p78, p79)
	if p78.isServer then
		p78:removeSupportVehicle()
	end
	p79(p78)
end
function SupportVehicle.getShowAttachableMapHotspot(p80, p81)
	if p80.spec_supportVehicle.supportVehicle == nil then
		return p81(p80)
	else
		return p80.spec_supportVehicle.supportVehicle:getAttacherVehicle() == nil
	end
end
function SupportVehicle.getIsReadyToFinishDetachProcess(p82, p83)
	local v84 = p82.spec_supportVehicle
	return not (p83(p82) and v84.isLoadingSupportVehicle) or v84.loadedSupportVehicle ~= nil
end
function SupportVehicle.startDetachProcess(p85, p86)
	if not p85.isDeleting then
		p85:addSupportVehicle(true)
	end
	return p86(p85)
end

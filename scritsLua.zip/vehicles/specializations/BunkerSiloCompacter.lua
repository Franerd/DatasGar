BunkerSiloCompacter = {}
BunkerSiloCompacter.XML_PATH = "vehicle.bunkerSiloCompacter"
function BunkerSiloCompacter.prerequisitesPresent(_)
	return true
end
function BunkerSiloCompacter.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("BunkerSiloCompacter")
	v1:register(XMLValueType.FLOAT, BunkerSiloCompacter.XML_PATH .. "#compactingScale", "Compacting scale", 1)
	v1:register(XMLValueType.BOOL, BunkerSiloCompacter.XML_PATH .. "#useSpeedLimit", "Defines if speed limit is used while compactor has contact with ground", false)
	SoundManager.registerSampleXMLPaths(v1, BunkerSiloCompacter.XML_PATH .. ".sounds", "rolling")
	SoundManager.registerSampleXMLPaths(v1, BunkerSiloCompacter.XML_PATH .. ".sounds", "compacting")
	v1:setXMLSpecializationType()
end
function BunkerSiloCompacter.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "loadBunkerSiloCompactorFromXML", BunkerSiloCompacter.loadBunkerSiloCompactorFromXML)
	SpecializationUtil.registerFunction(p2, "getBunkerSiloCompacterScale", BunkerSiloCompacter.getBunkerSiloCompacterScale)
end
function BunkerSiloCompacter.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "doCheckSpeedLimit", BunkerSiloCompacter.doCheckSpeedLimit)
end
function BunkerSiloCompacter.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", BunkerSiloCompacter)
	SpecializationUtil.registerEventListener(p4, "onUpdate", BunkerSiloCompacter)
	SpecializationUtil.registerEventListener(p4, "onDelete", BunkerSiloCompacter)
end
function BunkerSiloCompacter.onLoad(p5, _)
	local v6 = p5.spec_bunkerSiloCompacter
	p5:loadBunkerSiloCompactorFromXML(p5.xmlFile, BunkerSiloCompacter.XML_PATH)
	if p5.isClient then
		v6.samples = {}
		v6.samples.rolling = g_soundManager:loadSampleFromXML(p5.xmlFile, BunkerSiloCompacter.XML_PATH .. ".sounds", "rolling", p5.baseDirectory, p5.components, 0, AudioGroup.VEHICLE, p5.i3dMappings, p5)
		v6.samples.compacting = g_soundManager:loadSampleFromXML(p5.xmlFile, BunkerSiloCompacter.XML_PATH .. ".sounds", "compacting", p5.baseDirectory, p5.components, 0, AudioGroup.VEHICLE, p5.i3dMappings, p5)
		v6.lastIsCompacting = false
		v6.lastHasGroundContact = false
	end
	if p5.getWheels == nil then
		SpecializationUtil.removeEventListener(p5, "onUpdate", BunkerSiloCompacter)
	end
end
function BunkerSiloCompacter.onDelete(p7)
	local v8 = p7.spec_bunkerSiloCompacter
	g_soundManager:deleteSamples(v8.samples)
end
function BunkerSiloCompacter.loadBunkerSiloCompactorFromXML(p9, p10, p11)
	local v12 = p9.spec_bunkerSiloCompacter
	v12.scale = p10:getValue(p11 .. "#compactingScale", 1)
	v12.useSpeedLimit = p10:getValue(p11 .. "#useSpeedLimit", false)
end
function BunkerSiloCompacter.getBunkerSiloCompacterScale(p13)
	return p13.spec_bunkerSiloCompacter.scale
end
function BunkerSiloCompacter.onUpdate(p14, _, _, _, _)
	local v15 = p14.spec_bunkerSiloCompacter
	local v16 = p14:getWheels()
	local v17 = false
	local v18 = false
	for v19 = 1, #v16 do
		local v20 = v16[v19]
		if v20.physics.contact ~= WheelContactType.NONE then
			v17 = true
			if v20.physics.contact == WheelContactType.GROUND_HEIGHT then
				v18 = true
				break
			end
		end
	end
	if v15.lastHasGroundContact ~= v17 or v15.lastIsCompacting ~= v18 then
		if v17 then
			if v18 then
				if not g_soundManager:getIsSamplePlaying(v15.samples.compacting) then
					g_soundManager:playSample(v15.samples.compacting)
				end
			elseif g_soundManager:getIsSamplePlaying(v15.samples.compacting) then
				g_soundManager:stopSample(v15.samples.compacting)
			end
			if not g_soundManager:getIsSamplePlaying(v15.samples.rolling) then
				g_soundManager:playSample(v15.samples.rolling)
			end
		else
			if g_soundManager:getIsSamplePlaying(v15.samples.compacting) then
				g_soundManager:stopSample(v15.samples.compacting)
			end
			if g_soundManager:getIsSamplePlaying(v15.samples.rolling) then
				g_soundManager:stopSample(v15.samples.rolling)
			end
		end
		v15.lastHasGroundContact = v17
		v15.lastIsCompacting = v18
	end
end
function BunkerSiloCompacter.doCheckSpeedLimit(p21, p22)
	local v23 = p21.spec_bunkerSiloCompacter
	if v23.useSpeedLimit then
		return p22(p21) or v23.lastIsCompacting
	else
		return p22(p21)
	end
end
function BunkerSiloCompacter.getDefaultSpeedLimit()
	return 5
end

ManureBarrel = {}
function ManureBarrel.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Sprayer, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AttacherJoints, p1)
	end
	return v2
end
function ManureBarrel.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("ManureBarrel")
	v3:register(XMLValueType.INT, "vehicle.manureBarrel#attacherJointIndex", "Attacher joint index")
	v3:setXMLSpecializationType()
end
function ManureBarrel.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAreEffectsVisible", ManureBarrel.getAreEffectsVisible)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsWorkAreaActive", ManureBarrel.getIsWorkAreaActive)
end
function ManureBarrel.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", ManureBarrel)
	SpecializationUtil.registerEventListener(p5, "onPostAttachImplement", ManureBarrel)
	SpecializationUtil.registerEventListener(p5, "onPostDetachImplement", ManureBarrel)
end
function ManureBarrel.onLoad(p6, _)
	local v7 = p6.spec_manureBarrel
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.manureBarrel#toolAttachAnimName", "vehicle.attacherJoints.attacherJoint.objectChange")
	v7.attachToolJointIndex = p6.xmlFile:getValue("vehicle.manureBarrel#attacherJointIndex")
end
function ManureBarrel.onPostAttachImplement(p8, p9, _, p10)
	local v11 = p8.spec_manureBarrel
	if p10 == v11.attachToolJointIndex then
		v11.attachedTool = p9
	end
end
function ManureBarrel.onPostDetachImplement(p12, p13)
	local v14 = p12.spec_manureBarrel
	local v15
	if p12.getObjectFromImplementIndex == nil then
		v15 = nil
	else
		v15 = p12:getObjectFromImplementIndex(p13)
	end
	if v15 ~= nil and p12:getAttachedImplements()[p13].jointDescIndex == v14.attachToolJointIndex then
		v14.attachedTool = nil
	end
end
function ManureBarrel.getAreEffectsVisible(p16, p17)
	if p16.spec_manureBarrel.attachedTool == nil then
		return p17(p16)
	else
		return false
	end
end
function ManureBarrel.getIsWorkAreaActive(p18, p19, p20)
	if p18.spec_manureBarrel.attachedTool == nil then
		return p19(p18, p20)
	else
		return false
	end
end

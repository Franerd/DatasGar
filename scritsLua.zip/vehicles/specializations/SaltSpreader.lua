SaltSpreader = {}
function SaltSpreader.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("saltSpreader", false, false, false)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("SaltSpreader")
	v1:register(XMLValueType.INT, "vehicle.saltSpreader#fillUnitIndex", "Fill unit index", 1)
	v1:register(XMLValueType.INT, "vehicle.saltSpreader#unloadInfoIndex", "Unload info index", 1)
	v1:register(XMLValueType.INT, "vehicle.saltSpreader#usageWorkArea", "Width of this work area is used as multiplier for usage")
	v1:register(XMLValueType.FLOAT, "vehicle.saltSpreader#usage", "Salt usage in liter per second", 1)
	EffectManager.registerEffectXMLPaths(v1, "vehicle.saltSpreader.effects")
	v1:setXMLSpecializationType()
end
function SaltSpreader.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(WorkArea, p2)
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p2)
	end
	return v3
end
function SaltSpreader.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "processSaltSpreaderArea", SaltSpreader.processSaltSpreaderArea)
end
function SaltSpreader.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", SaltSpreader.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDirtMultiplier", SaltSpreader.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", SaltSpreader.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAreControlledActionsAllowed", SaltSpreader.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p5, "getCanBeTurnedOn", SaltSpreader.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p5, "getTurnedOnNotAllowedWarning", SaltSpreader.getTurnedOnNotAllowedWarning)
	SpecializationUtil.registerOverwrittenFunction(p5, "getVariableWorkWidthUsage", SaltSpreader.getVariableWorkWidthUsage)
end
function SaltSpreader.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", SaltSpreader)
	SpecializationUtil.registerEventListener(p6, "onDelete", SaltSpreader)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", SaltSpreader)
	SpecializationUtil.registerEventListener(p6, "onTurnedOn", SaltSpreader)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", SaltSpreader)
end
function SaltSpreader.onLoad(p7, _)
	local v8 = p7.spec_saltSpreader
	v8.fillUnitIndex = p7.xmlFile:getValue("vehicle.saltSpreader#fillUnitIndex", 1)
	v8.unloadInfoIndex = p7.xmlFile:getValue("vehicle.saltSpreader#unloadInfoIndex", 1)
	v8.usageWorkArea = p7.xmlFile:getValue("vehicle.saltSpreader#usageWorkArea")
	v8.usage = p7.xmlFile:getValue("vehicle.saltSpreader#usage", 1) / 1000
	if p7.isClient then
		v8.effects = g_effectManager:loadEffect(p7.xmlFile, "vehicle.saltSpreader.effects", p7.components, p7, p7.i3dMappings)
	end
	v8.fillToolWarning = g_i18n:getText("info_firstFillTheTool")
	v8.snowSystem = g_currentMission.snowSystem
	if not p7.isServer then
		SpecializationUtil.removeEventListener(p7, "onUpdateTick", SaltSpreader)
	end
end
function SaltSpreader.onDelete(p9)
	local v10 = p9.spec_saltSpreader
	g_effectManager:deleteEffects(v10.effects)
end
function SaltSpreader.onUpdateTick(p11, p12, _, _, _)
	if p11:getIsTurnedOn() then
		local v13 = p11.spec_saltSpreader
		if p11:getFillUnitFillLevel(v13.fillUnitIndex) > 0 then
			local v14 = v13.usageWorkArea == nil and 1 or p11:getWorkAreaWidth(v13.usageWorkArea)
			local v15 = v13.usage * p12 * v14
			local v16 = p11:getFillVolumeUnloadInfo(v13.unloadInfoIndex)
			p11:addFillUnitFillLevel(p11:getOwnerFarmId(), v13.fillUnitIndex, -v15, p11:getFillUnitFillType(v13.fillUnitIndex), ToolType.UNDEFINED, v16)
			return
		end
		p11:setIsTurnedOn(false)
	end
end
function SaltSpreader.onTurnedOn(p17)
	if p17.isClient then
		local v18 = p17.spec_saltSpreader
		local v19 = p17:getFillUnitFillType(v18.fillUnitIndex)
		if v19 ~= FillType.UNKNOWN then
			g_effectManager:setEffectTypeInfo(v18.effects, v19)
			g_effectManager:startEffects(v18.effects)
		end
	end
end
function SaltSpreader.onTurnedOff(p20)
	if p20.isClient then
		local v21 = p20.spec_saltSpreader
		g_effectManager:stopEffects(v21.effects)
	end
end
function SaltSpreader.doCheckSpeedLimit(p22, p23)
	return p23(p22) or p22:getIsTurnedOn()
end
function SaltSpreader.getDirtMultiplier(p24, p25)
	if p24:getIsTurnedOn() then
		return p25(p24) + p24:getWorkDirtMultiplier()
	else
		return p25(p24)
	end
end
function SaltSpreader.getWearMultiplier(p26, p27)
	if p26:getIsTurnedOn() then
		return p27(p26) + p26:getWorkWearMultiplier()
	else
		return p27(p26)
	end
end
function SaltSpreader.getAreControlledActionsAllowed(p28, p29)
	local v30 = p28.spec_saltSpreader
	if p28:getFillUnitFillLevel(v30.fillUnitIndex) <= 0 then
		return false, v30.fillToolWarning
	else
		return p29(p28)
	end
end
function SaltSpreader.getCanBeTurnedOn(p31, p32)
	if p31:getFillUnitFillLevel(p31.spec_saltSpreader.fillUnitIndex) <= 0 then
		return false
	else
		return p32(p31)
	end
end
function SaltSpreader.getTurnedOnNotAllowedWarning(p33, p34)
	local v35 = p33.spec_saltSpreader
	if p33:getFillUnitFillLevel(v35.fillUnitIndex) <= 0 then
		return v35.fillToolWarning
	else
		return p34(p33)
	end
end
function SaltSpreader.getVariableWorkWidthUsage(p36, p37)
	local v38 = p37(p36)
	if v38 ~= nil then
		return v38
	end
	if not p36:getIsTurnedOn() then
		return 0
	end
	local v39 = p36.spec_saltSpreader
	local v40 = v39.usageWorkArea == nil and 1 or p36:getWorkAreaWidth(v39.usageWorkArea)
	return v39.usage * v40 * 1000 * 60
end
function SaltSpreader.getDefaultSpeedLimit()
	return 20
end
function SaltSpreader.processSaltSpreaderArea(p41, p42)
	if not p41.isServer then
		return 0, 0
	end
	local v43, _, v44 = getWorldTranslation(p42.start)
	local v45, _, v46 = getWorldTranslation(p42.width)
	local v47, _, v48 = getWorldTranslation(p42.height)
	return p41.spec_saltSpreader.snowSystem:saltArea(v43, v44, v45, v46, v47, v48)
end

StumpCutterLight = {}
function StumpCutterLight.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(TurnOnVehicle, p1)
end
function StumpCutterLight.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("StumpCutterLight")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.stumpCutterLight#cutNode", "Cut nodes which is used as reference to detect the stumps")
	v2:register(XMLValueType.FLOAT, "vehicle.stumpCutterLight#cutRadius", "Stumps within this radius from the cut node will be removed", 1)
	v2:register(XMLValueType.TIME, "vehicle.stumpCutterLight#cutTime", "Time until the stump has been cut", 1)
	EffectManager.registerEffectXMLPaths(v2, "vehicle.stumpCutterLight.effects")
	v2:setXMLSpecializationType()
end
function StumpCutterLight.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "removeTreeStump", StumpCutterLight.removeTreeStump)
	SpecializationUtil.registerFunction(p3, "stumpCutterLightOverlapCallback", StumpCutterLight.stumpCutterLightOverlapCallback)
end
function StumpCutterLight.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAreControlledActionsAllowed", StumpCutterLight.getAreControlledActionsAllowed)
	SpecializationUtil.registerOverwrittenFunction(p4, "getDirtMultiplier", StumpCutterLight.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p4, "getWearMultiplier", StumpCutterLight.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p4, "getConsumingLoad", StumpCutterLight.getConsumingLoad)
end
function StumpCutterLight.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", StumpCutterLight)
	SpecializationUtil.registerEventListener(p5, "onDelete", StumpCutterLight)
	SpecializationUtil.registerEventListener(p5, "onUpdate", StumpCutterLight)
	SpecializationUtil.registerEventListener(p5, "onDeactivate", StumpCutterLight)
	SpecializationUtil.registerEventListener(p5, "onTurnedOn", StumpCutterLight)
	SpecializationUtil.registerEventListener(p5, "onTurnedOff", StumpCutterLight)
end
function StumpCutterLight.onLoad(p6, _)
	local v7 = p6.spec_stumpCutterLight
	v7.cutNode = p6.xmlFile:getValue("vehicle.stumpCutterLight#cutNode", nil, p6.components, p6.i3dMappings)
	v7.cutRadius = p6.xmlFile:getValue("vehicle.stumpCutterLight#cutRadius", 1)
	v7.cutTime = p6.xmlFile:getValue("vehicle.stumpCutterLight#cutTime", 1)
	v7.cutTimer = 0
	v7.foundStumps = {}
	v7.numFoundStumps = 0
	v7.overlapCheckActive = false
	if p6.isClient then
		v7.effects = g_effectManager:loadEffect(p6.xmlFile, "vehicle.stumpCutterLight.effects", p6.components, p6, p6.i3dMappings)
	end
	v7.texts = {}
	v7.texts.warning_stumpCutterNoStumpInRange = g_i18n:getText("warning_stumpCutterNoStumpInRange")
	if not p6.isServer then
		SpecializationUtil.removeEventListener(p6, "onUpdate", StumpCutterLight)
	end
	if not p6.isClient then
		SpecializationUtil.removeEventListener(p6, "onDelete", StumpCutterLight)
		SpecializationUtil.removeEventListener(p6, "onDeactivate", StumpCutterLight)
		SpecializationUtil.removeEventListener(p6, "onTurnedOn", StumpCutterLight)
		SpecializationUtil.removeEventListener(p6, "onTurnedOff", StumpCutterLight)
	end
end
function StumpCutterLight.onDelete(p8)
	local v9 = p8.spec_stumpCutterLight
	g_effectManager:deleteEffects(v9.effects)
end
function StumpCutterLight.onUpdate(p10, p11, _, _, _)
	local v12 = p10.spec_stumpCutterLight
	if p10:getIsTurnedOn() then
		local v13 = false
		if v12.numFoundStumps > 0 then
			v12.cutTimer = v12.cutTimer + p11
			if v12.cutTimer > v12.cutTime and not v12.overlapCheckActive then
				for v14 = 1, #v12.foundStumps do
					p10:removeTreeStump(v12.foundStumps[v14])
				end
				v12.cutTimer = 0
				v13 = true
			end
		else
			v13 = true
		end
		if v13 then
			if Platform.gameplay.automaticVehicleControl then
				p10.rootVehicle:playControlledActions()
			else
				p10:setIsTurnedOn(false, true)
			end
		end
	end
	if not v12.overlapCheckActive then
		v12.numFoundStumps = #v12.foundStumps
		for v15 = #v12.foundStumps, 1, -1 do
			v12.foundStumps[v15] = nil
		end
		v12.overlapCheckActive = true
		local v16, v17, v18 = getWorldTranslation(v12.cutNode)
		overlapSphereAsync(v16, v17, v18, v12.cutRadius, "stumpCutterLightOverlapCallback", p10, CollisionFlag.TREE, false, false, true, false)
	end
end
function StumpCutterLight.onDeactivate(p19)
	local v20 = p19.spec_stumpCutterLight
	g_effectManager:stopEffects(v20.effects)
end
function StumpCutterLight.onTurnedOn(p21)
	local v22 = p21.spec_stumpCutterLight
	g_effectManager:setEffectTypeInfo(v22.effects, FillType.WOODCHIPS)
	g_effectManager:startEffects(v22.effects)
end
function StumpCutterLight.onTurnedOff(p23)
	local v24 = p23.spec_stumpCutterLight
	g_effectManager:stopEffects(v24.effects)
end
function StumpCutterLight.removeTreeStump(p25, p26)
	if p25.isServer then
		local v27 = getSplitType(p26)
		local v28 = g_treePlantManager:getTreeTypeDescFromSplitType(v27)
		local v29, _, v30 = getWorldTranslation(p26)
		local v31 = getTerrainHeightAtWorldPos(g_terrainNode, v29, 0, v30)
		local v32 = math.random() * 2 * 3.141592653589793
		g_treePlantManager:plantTree(v28.index, v29, v31, v30, 0, v32, 0, 0)
		g_farmManager:updateFarmStats(p25:getActiveFarm(), "plantedTreeCount", 1)
		delete(p26)
	end
end
function StumpCutterLight.stumpCutterLightOverlapCallback(p33, p34, ...)
	local v35 = p33.spec_stumpCutterLight
	if not p33.isDeleted and (p34 ~= 0 and (p34 ~= 0 and (getHasClassId(p34, ClassIds.MESH_SPLIT_SHAPE) and getUserAttribute(p34, "isTreeStump")))) then
		local v36 = v35.foundStumps
		table.insert(v36, p34)
	end
	v35.overlapCheckActive = false
end
function StumpCutterLight.getAreControlledActionsAllowed(p37, p38)
	local v39 = p37.spec_stumpCutterLight
	if v39.numFoundStumps == 0 then
		return false, v39.texts.warning_stumpCutterNoStumpInRange
	else
		return p38(p37)
	end
end
function StumpCutterLight.getDirtMultiplier(p40, p41)
	local v42 = p41(p40)
	if p40:getIsTurnedOn() then
		v42 = v42 + p40:getWorkDirtMultiplier()
	end
	return v42
end
function StumpCutterLight.getWearMultiplier(p43, p44)
	local v45 = p44(p43)
	if p43:getIsTurnedOn() then
		v45 = v45 + p43:getWorkWearMultiplier()
	end
	return v45
end
function StumpCutterLight.getConsumingLoad(p46, p47)
	local v48, v49 = p47(p46)
	return v48 + (p46:getIsTurnedOn() and 1 or 0), v49 + 1
end

HydraulicHammer = {}
function HydraulicHammer.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(TurnOnVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	end
	return v2
end
function HydraulicHammer.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("HydraulicHammer")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.hydraulicHammer.workNode#node", "Cut node where raycast is fired from on -y axis")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.hydraulicHammer.workNode#hitAlignedNode", "Node will be moved and aligned to hit position and normal of worknode raycast")
	v3:register(XMLValueType.FLOAT, "vehicle.hydraulicHammer.workNode#destructionAmountPerHit", "Damage done to object per hit", 5)
	v3:register(XMLValueType.TIME, "vehicle.hydraulicHammer.workNode#hitIntervalMin", "Minimum time between cuts in seconds", 0.15)
	v3:register(XMLValueType.TIME, "vehicle.hydraulicHammer.workNode#hitIntervalMax", "Maximum time between cuts in seconds", 0.25)
	v3:register(XMLValueType.FLOAT, "vehicle.hydraulicHammer.workNode#raycastDistance", "Raycast distance in meters", 0.3)
	v3:register(XMLValueType.STRING, "vehicle.hydraulicHammer.workNode#supportedTypes", "Supported destructible types")
	EffectManager.registerEffectXMLPaths(v3, "vehicle.hydraulicHammer.workNode.effects")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.hydraulicHammer.sounds", "start")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.hydraulicHammer.sounds", "stop")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.hydraulicHammer.sounds", "idle")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.hydraulicHammer.sounds", "work")
	v3:register(XMLValueType.FLOAT, "vehicle.hydraulicHammer.sounds.work.progressPitch#factor", "Factor applied to sample pitch depending on destruction progress (0-1)")
	AnimationManager.registerAnimationNodesXMLPaths(v3, "vehicle.hydraulicHammer.animationNodes")
	v3:register(XMLValueType.STRING, "vehicle.hydraulicHammer.hitAnimation#name", "name of hit animation")
	v3:setXMLSpecializationType()
end
function HydraulicHammer.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "hydraulicHammerRaycastCallback", HydraulicHammer.hydraulicHammerRaycastCallback)
end
function HydraulicHammer.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDirtMultiplier", HydraulicHammer.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getWearMultiplier", HydraulicHammer.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p5, "getConsumingLoad", HydraulicHammer.getConsumingLoad)
end
function HydraulicHammer.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", HydraulicHammer)
	SpecializationUtil.registerEventListener(p6, "onDelete", HydraulicHammer)
	SpecializationUtil.registerEventListener(p6, "onUpdate", HydraulicHammer)
	SpecializationUtil.registerEventListener(p6, "onDeactivate", HydraulicHammer)
	SpecializationUtil.registerEventListener(p6, "onTurnedOn", HydraulicHammer)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", HydraulicHammer)
end
function HydraulicHammer.onLoad(p7, _)
	local v8 = p7.spec_hydraulicHammer
	local v9 = p7.xmlFile:getValue("vehicle.hydraulicHammer.workNode#node", nil, p7.components, p7.i3dMappings)
	if v9 == nil then
		Logging.xmlWarning(p7.xmlFile, "Missing \'node\' for \'vehicle.hydraulicHammer.workNode\'!")
	end
	local v10 = {
		["node"] = v9,
		["destructionAmount"] = p7.xmlFile:getValue("vehicle.hydraulicHammer.workNode#destructionAmountPerHit", 1),
		["hitIntervalMin"] = p7.xmlFile:getValue("vehicle.hydraulicHammer.workNode#hitIntervalMin", 0.15),
		["hitIntervalMax"] = p7.xmlFile:getValue("vehicle.hydraulicHammer.workNode#hitIntervalMax", 0.25),
		["raycastDistance"] = p7.xmlFile:getValue("vehicle.hydraulicHammer.workNode#raycastDistance", 0.4),
		["hitAlignedNode"] = p7.xmlFile:getValue("vehicle.hydraulicHammer.workNode#hitAlignedNode", nil, p7.components, p7.i3dMappings)
	}
	if v10.hitAlignedNode ~= nil then
		v10.hitAlignedNodeParent = getParent(v10.hitAlignedNode)
	end
	v10.lastWorkTime = -1000
	v10.nextHitTime = 0
	v8.workNode = v10
	local v11 = p7.xmlFile:getValue("vehicle.hydraulicHammer.workNode#supportedTypes")
	if v11 ~= nil then
		v8.supportedDestructibleTypes = table.toSet(string.split(v11, " "))
	end
	v8.raycastCollisionMask = CollisionFlag.STATIC_OBJECT
	v8.lastProgress = 0
	if p7.isClient then
		v10.effects = g_effectManager:loadEffect(p7.xmlFile, "vehicle.hydraulicHammer.workNode.effects", p7.components, p7, p7.i3dMappings)
		g_effectManager:setEffectTypeInfo(v10.effects, FillType.STONE)
		v8.samples = {}
		v8.samples.start = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.hydraulicHammer.sounds", "start", p7.baseDirectory, p7.components, 1, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.samples.stop = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.hydraulicHammer.sounds", "stop", p7.baseDirectory, p7.components, 1, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.samples.idle = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.hydraulicHammer.sounds", "idle", p7.baseDirectory, p7.components, 0, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v8.samples.work = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.hydraulicHammer.sounds", "work", p7.baseDirectory, p7.components, 0, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		if v8.samples.work ~= nil then
			v8.samples.work.progressPitchFactor = p7.xmlFile:getValue("vehicle.hydraulicHammer.sounds.work.progressPitch#factor", 0)
		end
		v8.animationNodes = g_animationManager:loadAnimations(p7.xmlFile, "vehicle.hydraulicHammer.animationNodes", p7.components, p7, p7.i3dMappings)
		local v12 = p7.xmlFile:getValue("vehicle.hydraulicHammer.hitAnimation#name")
		if p7:getAnimationExists(v12) then
			v8.hitAnimationName = v12
		end
	end
	v8.warningNoAccess = g_i18n:getText("warning_youDontHaveAccessToThisLand")
	v8.warningToolNotSupportingObject = g_i18n:getText("warning_toolDoesNotSupportThisObject")
end
function HydraulicHammer.onDelete(p13)
	local v14 = p13.spec_hydraulicHammer
	g_soundManager:deleteSamples(v14.samples)
	g_animationManager:deleteAnimations(v14.animationNodes)
	if v14.workNode ~= nil then
		g_effectManager:deleteEffects(v14.workNode.effects)
	end
end
function HydraulicHammer.onUpdate(p15, _, _, _, _)
	if p15:getIsTurnedOn() then
		local v16 = p15.spec_hydraulicHammer
		local v17 = v16.workNode
		if g_time >= v17.nextHitTime then
			g_effectManager:stopEffects(v16.workNode.effects)
			local v18, v19, v20 = getWorldTranslation(v17.node)
			local v21, v22, v23 = localDirectionToWorld(v17.node, 0, -1, 0)
			raycastClosest(v18, v19, v20, v21, v22, v23, v17.raycastDistance, "hydraulicHammerRaycastCallback", p15, v16.raycastCollisionMask)
		end
	end
end
function HydraulicHammer.hydraulicHammerRaycastCallback(p24, p25, p26, p27, p28, _, p29, p30, p31, _, _, _)
	local v32 = p24.spec_hydraulicHammer
	local v33, v34 = g_currentMission.destructibleMapObjectSystem:getDestructibleFromNode(p25, v32.supportedDestructibleTypes)
	if v33 == nil then
		if v34 ~= DestructibleMapObjectSystem.ERROR_WRONG_DESTRUCTIBLE_TYPE then
			return true
		end
		if p24:getRootVehicle() == g_localPlayer:getCurrentVehicle() then
			g_currentMission:showBlinkingWarning(v32.warningToolNotSupportingObject, 1000)
		end
		return false
	end
	local v35 = p24:getOwnerFarmId()
	if not (g_currentMission.accessHandler:canFarmAccessLand(v35, p26, p28) or g_missionManager:getIsMissionDestructible(v35, v33)) then
		if p24:getRootVehicle() == g_localPlayer:getCurrentVehicle() then
			g_currentMission:showBlinkingWarning(v32.warningNoAccess, 1000)
		end
		return false
	end
	v32.lastProgress = g_currentMission.destructibleMapObjectSystem:addDestructibleDamage(v33, v32.workNode.destructionAmount)
	if p24.isClient then
		if v32.hitAnimationName ~= nil then
			p24:playAnimation(v32.hitAnimationName, 1, 0, true)
		end
		if v32.samples.work ~= nil then
			g_soundManager:setSamplePitchOffset(v32.samples.work, v32.samples.work.progressPitchFactor * v32.lastProgress)
			g_soundManager:playSample(v32.samples.work)
		end
		if v32.workNode.hitAlignedNode ~= nil then
			setWorldTranslation(v32.workNode.hitAlignedNode, p26, p27, p28)
			local v36, v37, v38 = worldDirectionToLocal(v32.workNode.hitAlignedNodeParent, -p29, -p30, -p31)
			local v39, v40, v41 = worldDirectionToLocal(v32.workNode.hitAlignedNodeParent, 0, 1, 0)
			setDirection(v32.workNode.hitAlignedNode, v36, v37, v38, v39, v40, v41)
			g_effectManager:resetEffects(v32.workNode.effects)
			g_effectManager:startEffects(v32.workNode.effects)
		end
	end
	v32.workNode.lastWorkTime = g_time
	v32.workNode.nextHitTime = g_time + math.random(v32.workNode.hitIntervalMin, v32.workNode.hitIntervalMax)
	return false
end
function HydraulicHammer.onDeactivate(p42)
	if p42.isClient then
		local v43 = p42.spec_hydraulicHammer
		g_effectManager:stopEffects(v43.workNode.effects)
	end
end
function HydraulicHammer.onTurnedOn(p44)
	if p44.isClient then
		local v45 = p44.spec_hydraulicHammer
		g_soundManager:stopSamples(v45.samples)
		g_soundManager:playSample(v45.samples.start)
		g_soundManager:playSample(v45.samples.idle, 0, v45.samples.start)
		g_animationManager:startAnimations(v45.animationNodes)
	end
end
function HydraulicHammer.onTurnedOff(p46)
	if p46.isClient then
		local v47 = p46.spec_hydraulicHammer
		g_effectManager:stopEffects(v47.workNode.effects)
		g_soundManager:stopSamples(v47.samples)
		g_soundManager:playSample(v47.samples.stop)
		g_animationManager:stopAnimations(v47.animationNodes)
		if v47.hitAnimationName then
			p46:stopAnimation(v47.hitAnimationName)
		end
	end
end
function HydraulicHammer.getDirtMultiplier(p48, p49)
	local v50 = p49(p48)
	if p48.spec_hydraulicHammer.workNode.lastWorkTime + 500 > g_time then
		v50 = v50 + p48:getWorkDirtMultiplier()
	end
	return v50
end
function HydraulicHammer.getWearMultiplier(p51, p52)
	local v53 = p52(p51)
	if p51.spec_hydraulicHammer.workNode.lastWorkTime + 500 > g_time then
		v53 = v53 + p51:getWorkWearMultiplier()
	end
	return v53
end
function HydraulicHammer.getConsumingLoad(p54, p55)
	local v56, v57 = p55(p54)
	if p54.spec_hydraulicHammer.workNode.lastWorkTime + 500 > g_time then
		return v56 + 1, v57 + 1
	else
		return v56, v57
	end
end

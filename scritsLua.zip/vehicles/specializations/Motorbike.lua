Motorbike = {}
function Motorbike.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Motorized, p1)
	end
	return v2
end
function Motorbike.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Motorbike")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.motorbike.tilt#node", "Tilt Node")
	v3:register(XMLValueType.ANGLE, "vehicle.motorbike.tilt#maxTilt", "Max. tilt in corners", 0)
	v3:register(XMLValueType.ANGLE, "vehicle.motorbike.tilt#idleTilt", "Tilt while not driving", 0)
	v3:register(XMLValueType.ANGLE, "vehicle.motorbike.tilt#backwardTilt", "Tilt while going backward", 0)
	v3:register(XMLValueType.ANGLE, "vehicle.motorbike.tilt#tiltSpeed", "Tilt speed (deg/sec)", 5)
	v3:register(XMLValueType.STRING, "vehicle.motorbike.footAnimation#name", "Name of the foot animation")
	v3:register(XMLValueType.FLOAT, "vehicle.motorbike.footAnimation#speed", "Play speed of the animation", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.motorbike.footAnimation#speedThreshold", "Speed threshold to play the animation", 1)
	v3:register(XMLValueType.STRING, "vehicle.motorbike.backwardAnimation#name", "Name of the backward walk animation")
	v3:register(XMLValueType.FLOAT, "vehicle.motorbike.backwardAnimation#speed", "Speed of the animation", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.motorbike.steering#highSpeedScale", "Scale value for max. steering angle when above speed threshold", 0.5)
	v3:register(XMLValueType.FLOAT, "vehicle.motorbike.steering#highSpeedThreshold", "Threshold at which the steering is reduced to the defined scale", 20)
	v3:setXMLSpecializationType()
end
function Motorbike.registerFunctions(_) end
function Motorbike.registerOverwrittenFunctions(_) end
function Motorbike.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", Motorbike)
	SpecializationUtil.registerEventListener(p4, "onPostLoad", Motorbike)
	SpecializationUtil.registerEventListener(p4, "onUpdate", Motorbike)
	SpecializationUtil.registerEventListener(p4, "onLeaveVehicle", Motorbike)
end
function Motorbike.onLoad(p5, _)
	local v6 = p5.spec_motorbike
	v6.tilt = {}
	v6.tilt.node = p5.xmlFile:getValue("vehicle.motorbike.tilt#node", nil, p5.components, p5.i3dMappings)
	v6.tilt.maxTilt = p5.xmlFile:getValue("vehicle.motorbike.tilt#maxTilt", 0)
	v6.tilt.idleTilt = p5.xmlFile:getValue("vehicle.motorbike.tilt#idleTilt", 0)
	v6.tilt.backwardTilt = p5.xmlFile:getValue("vehicle.motorbike.tilt#backwardTilt", 0)
	v6.tilt.tiltSpeed = p5.xmlFile:getValue("vehicle.motorbike.tilt#tiltSpeed", 5) * 0.001
	v6.tilt.currentValue = v6.tilt.idleTilt
	setRotation(v6.tilt.node, 0, 0, v6.tilt.currentValue)
	v6.footAnimation = {}
	v6.footAnimation.name = p5.xmlFile:getValue("vehicle.motorbike.footAnimation#name")
	v6.footAnimation.speed = p5.xmlFile:getValue("vehicle.motorbike.footAnimation#speed", 1)
	v6.footAnimation.speedThreshold = p5.xmlFile:getValue("vehicle.motorbike.footAnimation#speedThreshold", 1)
	v6.footAnimation.state = false
	v6.backwardAnimation = {}
	v6.backwardAnimation.name = p5.xmlFile:getValue("vehicle.motorbike.backwardAnimation#name")
	v6.backwardAnimation.speed = p5.xmlFile:getValue("vehicle.motorbike.backwardAnimation#speed", 1)
	v6.backwardAnimation.state = false
	v6.backwardAnimation.maxBackwardSpeed = p5:getMotor():getMaximumBackwardSpeed()
	v6.steering = {}
	v6.steering.highSpeedScale = p5.xmlFile:getValue("vehicle.motorbike.steering#highSpeedScale", 0.5)
	v6.steering.highSpeedThreshold = p5.xmlFile:getValue("vehicle.motorbike.steering#highSpeedThreshold", 20)
end
function Motorbike.onPostLoad(p7, _)
	local v8 = p7.spec_motorbike
	v8.steering.minRotTime = p7.minRotTime
	v8.steering.maxRotTime = p7.maxRotTime
	v8.steering.wheelSteeringDuration = p7.wheelSteeringDuration
end
function Motorbike.onUpdate(p9, p10, _, _, _)
	local v11 = p9.spec_motorbike
	local v12 = p9:getLastSpeed()
	local v13
	if p9.movingDirection < 0 then
		v13 = v11.tilt.backwardTilt
	elseif v12 < 0.5 then
		v13 = v11.tilt.idleTilt
	else
		local v14 = v12 / 50
		v13 = -math.min(v14, 1) * p9.rotatedTime * v11.tilt.maxTilt
	end
	local v15 = v13 - v11.tilt.currentValue
	local v16 = math.sign(v15)
	local v17 = (v16 > 0 and math.min or math.max)(v11.tilt.currentValue + v16 * v11.tilt.tiltSpeed * p10, v13)
	if v17 ~= v11.tilt.currentValue then
		v11.tilt.currentValue = v17
		setRotation(v11.tilt.node, 0, 0, v11.tilt.currentValue)
	end
	local v18 = v12 < v11.footAnimation.speedThreshold and true or p9.movingDirection < 0
	if v18 ~= v11.footAnimation.state then
		v11.footAnimation.state = v18
		local v19 = p9:getAnimationTime(v11.footAnimation.name)
		if v18 then
			p9:playAnimation(v11.footAnimation.name, -v11.footAnimation.speed, v19, true)
		else
			p9:playAnimation(v11.footAnimation.name, v11.footAnimation.speed, v19, true)
		end
	end
	local v20
	if p9.movingDirection < 0 then
		v20 = v12 > 0.5
	else
		v20 = false
	end
	if v20 ~= v11.backwardAnimation.state then
		v11.backwardAnimation.state = v20
		if v20 then
			p9:playAnimation(v11.backwardAnimation.name, v11.backwardAnimation.speed, p9:getAnimationTime(v11.backwardAnimation.name), true)
		else
			p9:stopAnimation(v11.backwardAnimation.name)
			p9:setAnimationTime(v11.backwardAnimation.name, 0, true)
		end
	end
	if v11.backwardAnimation.state then
		p9:setAnimationSpeed(v11.backwardAnimation.name, v11.backwardAnimation.speed * (v12 / v11.backwardAnimation.maxBackwardSpeed))
	end
	local v21 = v11.steering.highSpeedScale
	local v22 = v12 / v11.steering.highSpeedThreshold
	local v23 = v21 + (1 - math.min(v22, 1)) * (1 - v11.steering.highSpeedScale)
	p9.minRotTime = v11.steering.minRotTime * v23
	p9.maxRotTime = v11.steering.maxRotTime * v23
	p9.wheelSteeringDuration = v11.steering.wheelSteeringDuration * v23
end
function Motorbike.onLeaveVehicle(p24)
	if p24.isServer then
		local _, v25, _ = localDirectionToWorld(p24.rootNode, 0, 1, 0)
		if v25 < 0.5 then
			local v26, v27, v28 = getWorldTranslation(p24.rootNode)
			local v29, _, v30 = localDirectionToWorld(p24.rootNode, 0, 0, 1)
			local v31, v32 = MathUtil.vector2Normalize(v29, v30)
			local v33 = MathUtil.getYRotationFromDirection(v31, v32)
			p24:removeFromPhysics()
			p24:setAbsolutePosition(v26, v27, v28, 0, v33, 0)
			p24:addToPhysics()
		end
	end
end

HighPressureWasher = {}
function HighPressureWasher.prerequisitesPresent(_)
	return true
end
function HighPressureWasher.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("HighPressureWasher")
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.highPressureWasher.animationNodes")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.highPressureWasher.effects")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.highPressureWasher.sounds", "start(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.highPressureWasher.sounds", "stop(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.highPressureWasher.sounds", "work(?)")
	v1:setXMLSpecializationType()
end
function HighPressureWasher.registerEventListeners(p2)
	SpecializationUtil.registerEventListener(p2, "onLoad", HighPressureWasher)
	SpecializationUtil.registerEventListener(p2, "onDelete", HighPressureWasher)
	SpecializationUtil.registerEventListener(p2, "onHandToolStoredInHolder", HighPressureWasher)
	SpecializationUtil.registerEventListener(p2, "onHandToolTakenFromHolder", HighPressureWasher)
end
function HighPressureWasher.onLoad(p3, _)
	local v4 = p3.spec_highPressureWasher
	if p3.isClient then
		v4.animationNodes = g_animationManager:loadAnimations(p3.xmlFile, "vehicle.highPressureWasher.animationNodes", p3.components, p3, p3.i3dMappings)
		v4.effects = g_effectManager:loadEffect(p3.xmlFile, "vehicle.highPressureWasher.effects", p3.components, p3, p3.i3dMappings)
		v4.samples = {}
		v4.samples.start = g_soundManager:loadSampleFromXML(p3.xmlFile, "vehicle.highPressureWasher.sounds", "start", p3.baseDirectory, p3.components, 1, AudioGroup.VEHICLE, p3.i3dMappings, p3)
		v4.samples.stop = g_soundManager:loadSampleFromXML(p3.xmlFile, "vehicle.highPressureWasher.sounds", "stop", p3.baseDirectory, p3.components, 1, AudioGroup.VEHICLE, p3.i3dMappings, p3)
		v4.samples.work = g_soundManager:loadSampleFromXML(p3.xmlFile, "vehicle.highPressureWasher.sounds", "work", p3.baseDirectory, p3.components, 0, AudioGroup.VEHICLE, p3.i3dMappings, p3)
	end
	if not p3.isClient then
		SpecializationUtil.removeEventListener(p3, "onDelete", HighPressureWasher)
		SpecializationUtil.removeEventListener(p3, "onUpdate", HighPressureWasher)
	end
end
function HighPressureWasher.onDelete(p5)
	local v6 = p5.spec_highPressureWasher
	if p5.isClient then
		g_soundManager:deleteSamples(v6.samples)
		g_animationManager:deleteAnimations(v6.animationNodes)
		g_effectManager:deleteEffects(v6.effects)
	end
end
function HighPressureWasher.onHandToolStoredInHolder(p7, _)
	if p7.isClient then
		local v8 = p7.spec_highPressureWasher
		g_soundManager:stopSample(v8.samples.start)
		g_soundManager:stopSample(v8.samples.work)
		g_soundManager:stopSample(v8.samples.stop)
		g_soundManager:playSample(v8.samples.stop)
		g_animationManager:stopAnimations(v8.animationNodes)
		g_effectManager:stopEffects(v8.effects)
	end
end
function HighPressureWasher.onHandToolTakenFromHolder(p9, _)
	if p9.isClient then
		local v10 = p9.spec_highPressureWasher
		g_soundManager:stopSample(v10.samples.start)
		g_soundManager:stopSample(v10.samples.work)
		g_soundManager:stopSample(v10.samples.stop)
		g_soundManager:playSample(v10.samples.start)
		g_soundManager:playSample(v10.samples.work, 0, v10.samples.start)
		g_animationManager:startAnimations(v10.animationNodes)
		g_effectManager:startEffects(v10.effects)
	end
end

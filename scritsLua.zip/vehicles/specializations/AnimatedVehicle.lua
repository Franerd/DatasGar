source("dataS/scripts/vehicles/specializations/events/AnimatedVehicleStartEvent.lua")
source("dataS/scripts/vehicles/specializations/events/AnimatedVehicleStopEvent.lua")
source("dataS/scripts/vehicles/AnimationValueFloat.lua")
source("dataS/scripts/vehicles/AnimationValueBool.lua")
AnimatedVehicle = {}
AnimatedVehicle.ANIMATION_PART_XML_KEY = "vehicle.animations.animation(?).part(?)"
function AnimatedVehicle.prerequisitesPresent(_)
	return true
end
function AnimatedVehicle.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("animation", g_i18n:getText("shop_configuration"), "animations", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("AnimatedVehicle")
	AnimatedVehicle.registerAnimationXMLPaths(v1, "vehicle.animations.animation(?)")
	AnimatedVehicle.registerAnimationXMLPaths(v1, "vehicle.animations.animationConfigurations.animationConfiguration(?).animation(?)")
	v1:register(XMLValueType.STRING, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#animName", "Animation name")
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#animOuterRange", "Anim limit outer range", false)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#animMinLimit", "Min. anim limit", 0)
	v1:register(XMLValueType.FLOAT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#animMaxLimit", "Max. anim limit", 1)
	v1:register(XMLValueType.STRING, WorkArea.WORK_AREA_XML_KEY .. "#animName", "Animation name")
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. "#animMinLimit", "Min. anim limit", 0)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_KEY .. "#animMaxLimit", "Max. anim limit", 1)
	v1:register(XMLValueType.STRING, WorkArea.WORK_AREA_XML_CONFIG_KEY .. "#animName", "Animation name")
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. "#animMinLimit", "Min. anim limit", 0)
	v1:register(XMLValueType.FLOAT, WorkArea.WORK_AREA_XML_CONFIG_KEY .. "#animMaxLimit", "Max. anim limit", 1)
	v1:addDelayedRegistrationFunc("Cylindered:movingTool", function(p2, p3)
		p2:register(XMLValueType.STRING, p3 .. "#requiredAnimation", "Name of the animation that needs to be in a certain range")
		p2:register(XMLValueType.FLOAT, p3 .. "#requiredAnimationMinTime", "Min. time of the animation that is allowed for the movingTool update [0-1]", 0)
		p2:register(XMLValueType.FLOAT, p3 .. "#requiredAnimationMaxTime", "Max. time of the animation that is allowed for the movingTool update [0-1]", 1)
	end)
	v1:addDelayedRegistrationFunc("Cylindered:movingPart", function(p4, p5)
		p4:register(XMLValueType.STRING, p5 .. "#requiredAnimation", "Name of the animation that needs to be in a certain range")
		p4:register(XMLValueType.FLOAT, p5 .. "#requiredAnimationMinTime", "Min. time of the animation that is allowed for the movingPart update [0-1]", 0)
		p4:register(XMLValueType.FLOAT, p5 .. "#requiredAnimationMaxTime", "Max. time of the animation that is allowed for the movingPart update [0-1]", 1)
	end)
	v1:setXMLSpecializationType()
end
function AnimatedVehicle.registerAnimationXMLPaths(p6, p7)
	p6:register(XMLValueType.STRING, p7 .. "#name", "Name of animation")
	p6:register(XMLValueType.BOOL, p7 .. "#looping", "Animation is looping", false)
	p6:register(XMLValueType.BOOL, p7 .. "#resetOnStart", "Animation is reset while loading the vehicle", true)
	p6:register(XMLValueType.FLOAT, p7 .. "#startAnimTime", "Animation is set to this time if resetOnStart is set", 0)
	p6:register(XMLValueType.FLOAT, p7 .. "#soundVolumeFactor", "Sound volume factor that is applied for all sounds in this animation", 1)
	p6:register(XMLValueType.BOOL, p7 .. "#isKeyframe", "Is static keyframe animation instead of dynamically interpolating animation (Keyframe animations only support trans/rot/scale!)", false)
	p6:addDelayedRegistrationPath(p7 .. ".part(?)", "AnimatedVehicle:part")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".part(?)#node", "Part node")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#startTime", "Start time")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#duration", "Duration")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#endTime", "End time")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#time", "Keyframe time (only for keyframe animations)")
	p6:register(XMLValueType.INT, p7 .. ".part(?)#direction", "Part direction", 0)
	p6:register(XMLValueType.STRING, p7 .. ".part(?)#tangentType", "Type of tangent to be used (linear, spline, step)", "linear")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#startRot", "Start rotation")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#endRot", "End rotation")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#startTrans", "Start translation")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#endTrans", "End translation")
	p6:register(XMLValueType.VECTOR_SCALE, p7 .. ".part(?)#startScale", "Start scale")
	p6:register(XMLValueType.VECTOR_SCALE, p7 .. ".part(?)#endScale", "End scale")
	p6:register(XMLValueType.BOOL, p7 .. ".part(?)#visibility", "Visibility")
	p6:register(XMLValueType.BOOL, p7 .. ".part(?)#startVisibility", "Visibility at start time (switched in the middle)")
	p6:register(XMLValueType.BOOL, p7 .. ".part(?)#endVisibility", "Visibility at end time (switched in the middle)")
	p6:register(XMLValueType.INT, p7 .. ".part(?)#componentJointIndex", "Component joint index")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#rotation", "Rotation  (only for keyframe animations)")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#translation", "Translation  (only for keyframe animations)")
	p6:register(XMLValueType.VECTOR_SCALE, p7 .. ".part(?)#scale", "Scale  (only for keyframe animations)")
	p6:register(XMLValueType.STRING, p7 .. ".part(?)#requiredAnimation", "Required animation needs to be in a specific range to play part")
	p6:register(XMLValueType.VECTOR_2, p7 .. ".part(?)#requiredAnimationRange", "Animation range of required animation")
	p6:register(XMLValueType.STRING, p7 .. ".part(?)#requiredConfigurationName", "This configuration needs to bet set to #requiredConfigurationIndex")
	p6:register(XMLValueType.INT, p7 .. ".part(?)#requiredConfigurationIndex", "Required configuration needs to be in this state to activate the animation part")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#startRotLimit", "Start rotation limit")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#startRotMinLimit", "Start rotation min limit")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#startRotMaxLimit", "Start rotation max limit")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#endRotLimit", "End rotation limit")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#endRotMinLimit", "End rotation min limit")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".part(?)#endRotMaxLimit", "End rotation max limit")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#startTransLimit", "Start translation limit")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#startTransMinLimit", "Start translation min limit")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#startTransMaxLimit", "Start translation max limit")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#endTransLimit", "End translation limit")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#endTransMinLimit", "End translation min limit")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#endTransMaxLimit", "End translation max limit")
	p6:register(XMLValueType.VECTOR_3, p7 .. ".part(?)#startRotLimitSpring", "Start rot limit spring")
	p6:register(XMLValueType.VECTOR_3, p7 .. ".part(?)#startRotLimitDamping", "Start rot limit damping")
	p6:register(XMLValueType.VECTOR_3, p7 .. ".part(?)#endRotLimitSpring", "End rot limit spring")
	p6:register(XMLValueType.VECTOR_3, p7 .. ".part(?)#endRotLimitDamping", "End rot limit damping")
	p6:register(XMLValueType.INT, p7 .. ".part(?)#componentIndex", "Component index")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#startMass", "Start mass of component")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#startCenterOfMass", "Start center of mass")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#endMass", "End mass of component")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".part(?)#endCenterOfMass", "End center of mass")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#startFrictionVelocity", "Start friction velocity applied to node")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#endFrictionVelocity", "End friction velocity applied to node")
	p6:register(XMLValueType.STRING, p7 .. ".part(?)#shaderParameter", "Shader parameter")
	p6:register(XMLValueType.STRING, p7 .. ".part(?)#shaderParameterPrev", "Shader parameter (prev)")
	p6:register(XMLValueType.STRING_LIST, p7 .. ".part(?)#shaderStartValues", "Start shader values")
	p6:register(XMLValueType.STRING_LIST, p7 .. ".part(?)#shaderEndValues", "End shader values")
	p6:register(XMLValueType.STRING, p7 .. ".part(?)#animationClip", "Animation clip name")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#clipStartTime", "Animation clip start time")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#clipEndTime", "Animation clip end time")
	p6:register(XMLValueType.STRING, p7 .. ".part(?)#dependentAnimation", "Dependent animation name")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#dependentAnimationStartTime", "Dependent animation start time")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#dependentAnimationEndTime", "Dependent animation end time")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".part(?)#spline", "Spline node")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#startSplinePos", "Start spline position")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#endSplinePos", "End spline position")
	RollingGateAnimation.registerXMLPaths(p6, p7 .. ".part(?).rollingGateAnimation")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#startGatePos", "Start rolling gate position")
	p6:register(XMLValueType.FLOAT, p7 .. ".part(?)#endGatePos", "End rolling gate position")
	SoundManager.registerSampleXMLPaths(p6, p7, "sound(?)")
	p6:register(XMLValueType.TIME, p7 .. ".sound(?)#startTime", "Start play time", 0)
	p6:register(XMLValueType.TIME, p7 .. ".sound(?)#endTime", "End play time for loops or used on opposite direction")
	p6:register(XMLValueType.INT, p7 .. ".sound(?)#direction", "Direction to play the sound (0 = any direction)", 0)
	p6:register(XMLValueType.FLOAT, p7 .. ".sound(?)#startPitchScale", "Pitch scale at the start time")
	p6:register(XMLValueType.FLOAT, p7 .. ".sound(?)#endPitchScale", "Pitch scale at the end time")
	SoundManager.registerSampleXMLPaths(p6, p7, "stopTimePosSound(?)")
	SoundManager.registerSampleXMLPaths(p6, p7, "stopTimeNegSound(?)")
end
function AnimatedVehicle.registerEvents(p8)
	SpecializationUtil.registerEvent(p8, "onRegisterAnimationValueTypes")
	SpecializationUtil.registerEvent(p8, "onPlayAnimation")
	SpecializationUtil.registerEvent(p8, "onStartAnimation")
	SpecializationUtil.registerEvent(p8, "onUpdateAnimation")
	SpecializationUtil.registerEvent(p8, "onFinishAnimation")
	SpecializationUtil.registerEvent(p8, "onStopAnimation")
	SpecializationUtil.registerEvent(p8, "onAnimationPartChanged")
end
function AnimatedVehicle.registerFunctions(p9)
	SpecializationUtil.registerFunction(p9, "registerAnimationValueType", AnimatedVehicle.registerAnimationValueType)
	SpecializationUtil.registerFunction(p9, "loadAnimation", AnimatedVehicle.loadAnimation)
	SpecializationUtil.registerFunction(p9, "loadAnimationPart", AnimatedVehicle.loadAnimationPart)
	SpecializationUtil.registerFunction(p9, "loadStaticAnimationPart", AnimatedVehicle.loadStaticAnimationPart)
	SpecializationUtil.registerFunction(p9, "loadStaticAnimationPartValues", AnimatedVehicle.loadStaticAnimationPartValues)
	SpecializationUtil.registerFunction(p9, "initializeAnimationParts", AnimatedVehicle.initializeAnimationParts)
	SpecializationUtil.registerFunction(p9, "initializeAnimationPart", AnimatedVehicle.initializeAnimationPart)
	SpecializationUtil.registerFunction(p9, "postInitializeAnimationPart", AnimatedVehicle.postInitializeAnimationPart)
	SpecializationUtil.registerFunction(p9, "playAnimation", AnimatedVehicle.playAnimation)
	SpecializationUtil.registerFunction(p9, "stopAnimation", AnimatedVehicle.stopAnimation)
	SpecializationUtil.registerFunction(p9, "getAnimationExists", AnimatedVehicle.getAnimationExists)
	SpecializationUtil.registerFunction(p9, "getAnimationByName", AnimatedVehicle.getAnimationByName)
	SpecializationUtil.registerFunction(p9, "getIsAnimationPlaying", AnimatedVehicle.getIsAnimationPlaying)
	SpecializationUtil.registerFunction(p9, "getRealAnimationTime", AnimatedVehicle.getRealAnimationTime)
	SpecializationUtil.registerFunction(p9, "setRealAnimationTime", AnimatedVehicle.setRealAnimationTime)
	SpecializationUtil.registerFunction(p9, "getAnimationTime", AnimatedVehicle.getAnimationTime)
	SpecializationUtil.registerFunction(p9, "setAnimationTime", AnimatedVehicle.setAnimationTime)
	SpecializationUtil.registerFunction(p9, "getAnimationDuration", AnimatedVehicle.getAnimationDuration)
	SpecializationUtil.registerFunction(p9, "setAnimationSpeed", AnimatedVehicle.setAnimationSpeed)
	SpecializationUtil.registerFunction(p9, "getAnimationSpeed", AnimatedVehicle.getAnimationSpeed)
	SpecializationUtil.registerFunction(p9, "setAnimationStopTime", AnimatedVehicle.setAnimationStopTime)
	SpecializationUtil.registerFunction(p9, "resetAnimationValues", AnimatedVehicle.resetAnimationValues)
	SpecializationUtil.registerFunction(p9, "resetAnimationPartValues", AnimatedVehicle.resetAnimationPartValues)
	SpecializationUtil.registerFunction(p9, "updateAnimationPart", AnimatedVehicle.updateAnimationPart)
	SpecializationUtil.registerFunction(p9, "getNumOfActiveAnimations", AnimatedVehicle.getNumOfActiveAnimations)
end
function AnimatedVehicle.registerOverwrittenFunctions(p10)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadSpeedRotatingPartFromXML", AnimatedVehicle.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsSpeedRotatingPartActive", AnimatedVehicle.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadWorkAreaFromXML", AnimatedVehicle.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsWorkAreaActive", AnimatedVehicle.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadMovingToolFromXML", AnimatedVehicle.loadMovingToolFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsMovingToolActive", AnimatedVehicle.getIsMovingToolActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadMovingPartFromXML", AnimatedVehicle.loadMovingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsMovingPartActive", AnimatedVehicle.getIsMovingPartActive)
end
function AnimatedVehicle.registerEventListeners(p11)
	SpecializationUtil.registerEventListener(p11, "onPreLoad", AnimatedVehicle)
	SpecializationUtil.registerEventListener(p11, "onLoad", AnimatedVehicle)
	SpecializationUtil.registerEventListener(p11, "onPostLoad", AnimatedVehicle)
	SpecializationUtil.registerEventListener(p11, "onDelete", AnimatedVehicle)
	SpecializationUtil.registerEventListener(p11, "onUpdate", AnimatedVehicle)
	SpecializationUtil.registerEventListener(p11, "onRegisterAnimationValueTypes", AnimatedVehicle)
end
function AnimatedVehicle.onPreLoad(p12, _)
	p12.spec_animatedVehicle.animationValueTypes = {}
	SpecializationUtil.raiseEvent(p12, "onRegisterAnimationValueTypes")
end
function AnimatedVehicle.onLoad(p13, _)
	local v14 = p13.spec_animatedVehicle
	v14.animations = {}
	for _, v15 in p13.xmlFile:iterator("vehicle.animations.animation") do
		local v16 = {}
		if p13:loadAnimation(p13.xmlFile, v15, v16) then
			v14.animations[v16.name] = v16
		end
	end
	local v17 = p13.configurations.animation or 1
	local v18 = string.format("vehicle.animations.animationConfigurations.animationConfiguration(%d)", v17 - 1)
	if p13.xmlFile:hasProperty(v18) then
		for _, v19 in p13.xmlFile:iterator(v18 .. ".animation") do
			local v20 = {}
			if p13:loadAnimation(p13.xmlFile, v19, v20) then
				v14.animations[v20.name] = v20
			end
		end
	end
	v14.activeAnimations = {}
	v14.numActiveAnimations = 0
	v14.fixedTimeSamplesDirtyDelay = 0
end
function AnimatedVehicle.onPostLoad(p21, _)
	local v22 = p21.spec_animatedVehicle
	for v23, v24 in pairs(v22.animations) do
		if v24.resetOnStart then
			p21:setAnimationTime(v23, 1, true, false)
			p21:setAnimationStopTime(v23, v24.startTime)
			p21:playAnimation(v23, -1, 1, true, false)
			AnimatedVehicle.updateAnimationByName(p21, v23, 9999999, true)
		end
	end
	if next(v22.animations) == nil then
		SpecializationUtil.removeEventListener(p21, "onUpdate", AnimatedVehicle)
	end
end
function AnimatedVehicle.onDelete(p25)
	local v26 = p25.spec_animatedVehicle
	if p25.isClient and v26.animations ~= nil then
		for _, v27 in pairs(v26.animations) do
			g_soundManager:deleteSamples(v27.samples)
			if v27.eventSamples ~= nil then
				g_soundManager:deleteSamples(v27.eventSamples.stopTimePos)
				g_soundManager:deleteSamples(v27.eventSamples.stopTimeNeg)
			end
		end
	end
end
function AnimatedVehicle.onUpdate(p28, p29, _, _, _)
	AnimatedVehicle.updateAnimations(p28, p29)
	local v30 = p28.spec_animatedVehicle
	if v30.fixedTimeSamplesDirtyDelay > 0 then
		v30.fixedTimeSamplesDirtyDelay = v30.fixedTimeSamplesDirtyDelay - 1
		if v30.fixedTimeSamplesDirtyDelay <= 0 then
			for _, v31 in pairs(v30.animations) do
				if not table.hasElement(v30.activeAnimations, v31) and p28.isClient then
					for v32 = 1, #v31.samples do
						local v33 = v31.samples[v32]
						if g_soundManager:getIsSamplePlaying(v33) and v33.loops == 0 then
							g_soundManager:stopSample(v33)
						end
					end
				end
			end
			v30.fixedTimeSamplesDirtyDelay = 0
		end
	end
	if v30.numActiveAnimations > 0 then
		p28:raiseActive()
	end
end
function AnimatedVehicle.registerAnimationValueType(p34, p35, p36, p37, p38, p39, p40, p41, p42)
	local v43 = p34.spec_animatedVehicle
	if v43.animationValueTypes[p35] == nil then
		v43.animationValueTypes[p35] = {
			["classObject"] = p39,
			["name"] = p35,
			["startName"] = p36,
			["endName"] = p37,
			["initialUpdate"] = p38,
			["load"] = p40,
			["get"] = p41,
			["set"] = p42
		}
	end
end
function AnimatedVehicle.loadAnimation(p_u_44, p_u_45, p_u_46, p_u_47, p_u_48)
	local v49 = p_u_45:getValue(p_u_46 .. "#name")
	if v49 == nil then
		return false
	end
	p_u_47.name = v49
	p_u_47.parts = {}
	p_u_47.currentTime = 0
	p_u_47.previousTime = 0
	p_u_47.currentSpeed = 1
	p_u_47.looping = p_u_45:getValue(p_u_46 .. "#looping", false)
	p_u_47.resetOnStart = p_u_45:getValue(p_u_46 .. "#resetOnStart", true)
	p_u_47.soundVolumeFactor = p_u_45:getValue(p_u_46 .. "#soundVolumeFactor", 1)
	p_u_47.isKeyframe = p_u_45:getValue(p_u_46 .. "#isKeyframe", false)
	local v50
	if p_u_47.isKeyframe then
		p_u_47.curvesByNode = {}
		v50 = 0
	else
		v50 = 0
	end
	while true do
		local v51 = p_u_46 .. string.format(".part(%d)", v50)
		if not p_u_45:hasProperty(v51) then
			break
		end
		local v52 = {}
		if p_u_47.isKeyframe then
			p_u_44:loadStaticAnimationPart(p_u_45, v51, v52, p_u_47, p_u_48)
		elseif p_u_44:loadAnimationPart(p_u_45, v51, v52, p_u_47, p_u_48) then
			local v53 = p_u_47.parts
			table.insert(v53, v52)
		end
		v50 = v50 + 1
	end
	p_u_47.partsReverse = {}
	for _, v54 in ipairs(p_u_47.parts) do
		local v55 = p_u_47.partsReverse
		table.insert(v55, v54)
	end
	table.sort(p_u_47.parts, AnimatedVehicle.animPartSorter)
	table.sort(p_u_47.partsReverse, AnimatedVehicle.animPartSorterReverse)
	p_u_44:initializeAnimationParts(p_u_47)
	p_u_47.currentPartIndex = 1
	p_u_47.duration = 0
	for _, v56 in ipairs(p_u_47.parts) do
		local v57 = p_u_47.duration
		local v58 = v56.startTime + v56.duration
		p_u_47.duration = math.max(v57, v58)
	end
	if p_u_47.isKeyframe then
		for _, v59 in pairs(p_u_47.curvesByNode) do
			local v60 = p_u_47.duration
			local v61 = v59.maxTime
			p_u_47.duration = math.max(v60, v61)
		end
	end
	p_u_47.startTime = p_u_45:getValue(p_u_46 .. "#startAnimTime", 0)
	p_u_47.currentTime = p_u_47.startTime * p_u_47.duration
	if p_u_44.isClient then
		p_u_47.samples = {}
		local v62 = 0
		while true do
			local v63 = string.format("sound(%d)", v62)
			local v64 = p_u_46 .. "." .. v63
			if not p_u_45:hasProperty(v64) then
				break
			end
			local v65 = g_soundManager:loadSampleFromXML(p_u_45, p_u_46, v63, p_u_44.baseDirectory, p_u_48 or p_u_44.components, 0, AudioGroup.VEHICLE, p_u_44.i3dMappings, p_u_44)
			if v65 ~= nil then
				v65.startTime = p_u_45:getValue(v64 .. "#startTime", 0)
				v65.endTime = p_u_45:getValue(v64 .. "#endTime")
				v65.direction = p_u_45:getValue(v64 .. "#direction", 0)
				v65.startPitchScale = p_u_45:getValue(v64 .. "#startPitchScale")
				v65.endPitchScale = p_u_45:getValue(v64 .. "#endPitchScale")
				if v65.startPitchScale ~= nil and v65.endPitchScale == nil or v65.startPitchScale == nil and v65.endPitchScale ~= nil then
					v65.startPitchScale = nil
					v65.endPitchScale = nil
					Logging.xmlWarning(p_u_45, "Animation sound requires both, startPitchScale and endPitchScale, not only one. (%s)", v64)
				end
				if v65.endTime == nil and v65.loops == 0 then
					v65.loops = 1
				end
				g_soundManager:setSampleVolumeScale(v65, g_soundManager:getSampleVolumeScale(v65) * p_u_47.soundVolumeFactor)
				local v66 = p_u_47.samples
				table.insert(v66, v65)
			end
			v62 = v62 + 1
		end
		p_u_45:iterate(p_u_46 .. ".stopTimePosSound", function(p67, _)
			-- upvalues: (copy) p_u_45, (copy) p_u_46, (copy) p_u_44, (copy) p_u_48, (copy) p_u_47
			local v68 = g_soundManager:loadSampleFromXML(p_u_45, p_u_46, string.format("stopTimePosSound(%d)", p67 - 1), p_u_44.baseDirectory, p_u_48 or p_u_44.components, 1, AudioGroup.VEHICLE, p_u_44.i3dMappings, p_u_44)
			if v68 ~= nil then
				p_u_47.eventSamples = p_u_47.eventSamples or {}
				p_u_47.eventSamples.stopTimePos = p_u_47.eventSamples.stopTimePos or {}
				local v69 = p_u_47.eventSamples.stopTimePos
				table.insert(v69, v68)
			end
		end)
		p_u_45:iterate(p_u_46 .. ".stopTimeNegSound", function(p70, _)
			-- upvalues: (copy) p_u_45, (copy) p_u_46, (copy) p_u_44, (copy) p_u_48, (copy) p_u_47
			local v71 = g_soundManager:loadSampleFromXML(p_u_45, p_u_46, string.format("stopTimeNegSound(%d)", p70 - 1), p_u_44.baseDirectory, p_u_48 or p_u_44.components, 1, AudioGroup.VEHICLE, p_u_44.i3dMappings, p_u_44)
			if v71 ~= nil then
				p_u_47.eventSamples = p_u_47.eventSamples or {}
				p_u_47.eventSamples.stopTimeNeg = p_u_47.eventSamples.stopTimeNeg or {}
				local v72 = p_u_47.eventSamples.stopTimeNeg
				table.insert(v72, v71)
			end
		end)
	end
	return true
end
function AnimatedVehicle.loadAnimationPart(p73, p74, p75, p76, p77, p78)
	local v79 = p74:getValue(p75 .. "#startTime")
	local v80 = p74:getValue(p75 .. "#duration")
	local v81 = p74:getValue(p75 .. "#endTime")
	local v82 = p74:getValue(p75 .. "#direction", 0)
	local v83 = math.sign(v82)
	p76.components = p78 or p73.components
	p76.i3dMappings = p73.i3dMappings
	p76.animationValues = {}
	local v84 = p73.spec_animatedVehicle
	for _, v85 in pairs(v84.animationValueTypes) do
		local v86 = v85.classObject.new(p73, p77, p76, v85.startName, v85.endName, v85.name, v85.initialUpdate, v85.get, v85.set, v85.load)
		if v86:load(p74, p75) then
			local v87 = p76.animationValues
			table.insert(v87, v86)
		end
	end
	local v88 = p74:getValue(p75 .. "#requiredAnimation")
	local v89 = p74:getValue(p75 .. "#requiredAnimationRange", nil, true)
	local v90 = p74:getValue(p75 .. "#requiredConfigurationName")
	local v91 = p74:getValue(p75 .. "#requiredConfigurationIndex")
	for v92 = 1, #p76.animationValues do
		p76.animationValues[v92].requiredAnimation = v88
		p76.animationValues[v92]:addCompareParameters("requiredAnimation")
		if v89 ~= nil then
			p76.animationValues[v92].requiredAnimationRange = string.format("%.2f %.2f", v89[1], v89[2])
			p76.animationValues[v92]:addCompareParameters("requiredAnimationRange")
		end
		p76.animationValues[v92].requiredConfigurationName = v90
		p76.animationValues[v92]:addCompareParameters("requiredConfigurationName")
		p76.animationValues[v92].requiredConfigurationIndex = v91
		p76.animationValues[v92]:addCompareParameters("requiredConfigurationIndex")
	end
	if #p76.animationValues == 0 then
		return false
	end
	if v79 == nil or v80 == nil and v81 == nil then
		return false
	end
	if v81 ~= nil then
		v80 = v81 - v79
	end
	p76.startTime = v79 * 1000
	p76.duration = v80 * 1000
	p76.direction = v83
	p76.requiredAnimation = v88
	p76.requiredAnimationRange = v89
	p76.requiredConfigurationName = v90
	p76.requiredConfigurationIndex = v91
	return true
end
function AnimatedVehicle.loadStaticAnimationPart(p93, p94, p95, _, p96, _)
	local v97 = p94:getValue(p95 .. "#node", nil, p93.components, p93.i3dMappings)
	if v97 == nil then
		return false
	end
	local v98 = p94:getValue(p95 .. "#time")
	local v99 = p94:getValue(p95 .. "#startTime")
	local v100 = p94:getValue(p95 .. "#endTime")
	if p96.curvesByNode[v97] == nil then
		p96.curvesByNode[v97] = AnimCurve.new(linearInterpolatorTransRotScale)
	end
	local v101 = p96.curvesByNode[v97]
	if v98 == nil then
		if v99 ~= nil or v100 ~= nil then
			if v99 ~= nil then
				local v102 = v99 * 1000
				if v101.maxTime == 0 or v101.maxTime ~= v102 then
					p93:loadStaticAnimationPartValues(p94, p95, v101, v97, "startTrans", "startRot", "startScale", v102)
				end
			end
			if v100 ~= nil then
				local v103 = v100 * 1000
				if v101.maxTime == 0 or v101.maxTime ~= v103 then
					p93:loadStaticAnimationPartValues(p94, p95, v101, v97, "endTrans", "endRot", "endScale", v103)
				end
			end
		end
	else
		p93:loadStaticAnimationPartValues(p94, p95, v101, v97, "translation", "rotation", "scale", v98 * 1000)
	end
	return true
end
function AnimatedVehicle.loadStaticAnimationPartValues(_, p104, p105, p106, p107, p108, p109, p110, p111)
	local v112, v113, v114 = p104:getValue(p105 .. "#" .. p108)
	if v112 == nil then
		v112, v113, v114 = getTranslation(p107)
	else
		p106.hasTranslation = true
	end
	local v115, v116, v117 = p104:getValue(p105 .. "#" .. p109)
	if v115 == nil then
		v115, v116, v117 = getRotation(p107)
	else
		p106.hasRotation = true
	end
	local v118, v119, v120 = p104:getValue(p105 .. "#" .. p110)
	if v118 == nil then
		v118, v119, v120 = getScale(p107)
	else
		p106.hasScale = true
	end
	p106:addKeyframe({
		["x"] = v112,
		["y"] = v113,
		["z"] = v114,
		["rx"] = v115,
		["ry"] = v116,
		["rz"] = v117,
		["sx"] = v118,
		["sy"] = v119,
		["sz"] = v120,
		["time"] = p111
	})
end
function AnimatedVehicle.initializeAnimationParts(p121, p122)
	local v123 = #p122.parts
	for v124, v125 in ipairs(p122.parts) do
		p121:initializeAnimationPart(p122, v125, v124, v123)
	end
	for v126, v127 in ipairs(p122.parts) do
		p121:postInitializeAnimationPart(p122, v127, v126, v123)
	end
end
function AnimatedVehicle.initializeAnimationPart(_, _, p128, p129, p130)
	for v131 = 1, #p128.animationValues do
		p128.animationValues[v131]:init(p129, p130)
	end
end
function AnimatedVehicle.postInitializeAnimationPart(_, _, p132, _, _)
	for v133 = 1, #p132.animationValues do
		p132.animationValues[v133]:postInit()
	end
end
function AnimatedVehicle.playAnimation(p134, p135, p136, p137, p138, _)
	local v139 = p134.spec_animatedVehicle
	local v140 = v139.animations[p135]
	if v140 ~= nil then
		SpecializationUtil.raiseEvent(p134, "onPlayAnimation", p135)
		if p136 == nil then
			p136 = v140.currentSpeed
		end
		if p136 == nil or p136 == 0 then
			return
		end
		if p137 == nil then
			if p134:getIsAnimationPlaying(p135) then
				p137 = p134:getAnimationTime(p135)
			else
				p137 = p136 > 0 and 0 or 1
			end
		end
		if p138 == nil or p138 == false then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(AnimatedVehicleStartEvent.new(p134, p135, p136, p137))
			else
				g_server:broadcastEvent(AnimatedVehicleStartEvent.new(p134, p135, p136, p137), nil, nil, p134)
			end
		end
		if not table.hasElement(v139.activeAnimations, v140) then
			table.addElement(v139.activeAnimations, v140)
			v139.numActiveAnimations = v139.numActiveAnimations + 1
			SpecializationUtil.raiseEvent(p134, "onStartAnimation", p135, p136)
		end
		v140.currentSpeed = p136
		v140.currentTime = p137 * v140.duration
		p134:resetAnimationValues(v140)
		p134:raiseActive()
	end
end
function AnimatedVehicle.stopAnimation(p141, p142, p143)
	local v144 = p141.spec_animatedVehicle
	if p143 == nil or p143 == false then
		if g_server == nil then
			g_client:getServerConnection():sendEvent(AnimatedVehicleStopEvent.new(p141, p142))
		else
			g_server:broadcastEvent(AnimatedVehicleStopEvent.new(p141, p142), nil, nil, p141)
		end
	end
	local v145 = v144.animations[p142]
	if v145 ~= nil then
		SpecializationUtil.raiseEvent(p141, "onStopAnimation", p142)
		v145.stopTime = nil
		if p141.isClient then
			for v146 = 1, #v145.samples do
				local v147 = v145.samples[v146]
				if v147.loops == 0 then
					g_soundManager:stopSample(v147)
				end
			end
		end
	end
	if table.hasElement(v144.activeAnimations, v145) then
		table.removeElement(v144.activeAnimations, v145)
		v144.numActiveAnimations = v144.numActiveAnimations - 1
		SpecializationUtil.raiseEvent(p141, "onFinishAnimation", p142)
	end
end
function AnimatedVehicle.getAnimationExists(p148, p149)
	return p148.spec_animatedVehicle.animations[p149] ~= nil
end
function AnimatedVehicle.getAnimationByName(p150, p151)
	return p150.spec_animatedVehicle.animations[p151]
end
function AnimatedVehicle.getIsAnimationPlaying(p152, p153)
	local v154 = p152.spec_animatedVehicle
	local v155 = v154.animations[p153]
	return table.hasElement(v154.activeAnimations, v155)
end
function AnimatedVehicle.getRealAnimationTime(p156, p157)
	local v158 = p156.spec_animatedVehicle.animations[p157]
	return v158 == nil and 0 or v158.currentTime
end
function AnimatedVehicle.setRealAnimationTime(p159, p160, p161, p162, p163)
	local v164 = p159.spec_animatedVehicle.animations[p160]
	if v164 ~= nil then
		if p162 == nil or p162 then
			local v165 = v164.currentSpeed
			v164.currentSpeed = 1
			if p161 < v164.currentTime then
				v164.currentSpeed = -1
			end
			p159:resetAnimationValues(v164)
			local v166, _ = AnimatedVehicle.updateAnimationCurrentTime(p159, v164, 99999999, p161)
			AnimatedVehicle.updateAnimation(p159, v164, v166, true, true, p163)
			v164.currentSpeed = v165
			return
		end
		v164.currentTime = p161
	end
end
function AnimatedVehicle.getAnimationTime(p167, p168)
	local v169 = p167.spec_animatedVehicle.animations[p168]
	return (v169 == nil or v169.duration <= 0) and 0 or v169.currentTime / v169.duration
end
function AnimatedVehicle.setAnimationTime(p170, p171, p172, p173, p174)
	local v175 = p170.spec_animatedVehicle
	if v175.animations == nil then
		printCallstack()
	end
	local v176 = v175.animations[p171]
	if v176 ~= nil then
		p170:setRealAnimationTime(p171, p172 * v176.duration, p173, p174)
	end
end
function AnimatedVehicle.getAnimationDuration(p177, p178)
	local v179 = p177.spec_animatedVehicle.animations[p178]
	return v179 == nil and 1 or v179.duration
end
function AnimatedVehicle.setAnimationSpeed(p180, p181, p182)
	local v183 = p180.spec_animatedVehicle.animations[p181]
	if v183 ~= nil then
		local v184 = v183.currentSpeed > 0 ~= (p182 > 0) and true or false
		v183.currentSpeed = p182
		if p180:getIsAnimationPlaying(p181) and v184 then
			p180:resetAnimationValues(v183)
		end
	end
end
function AnimatedVehicle.getAnimationSpeed(p185, p186)
	local v187 = p185.spec_animatedVehicle.animations[p186]
	return v187 == nil and 0 or v187.currentSpeed
end
function AnimatedVehicle.setAnimationStopTime(p188, p189, p190)
	local v191 = p188.spec_animatedVehicle.animations[p189]
	if v191 ~= nil then
		v191.stopTime = p190 * v191.duration
	end
end
function AnimatedVehicle.resetAnimationValues(p192, p193)
	AnimatedVehicle.findCurrentPartIndex(p193)
	for _, v194 in ipairs(p193.parts) do
		p192:resetAnimationPartValues(v194)
	end
end
function AnimatedVehicle.resetAnimationPartValues(_, p195)
	for v196 = 1, #p195.animationValues do
		p195.animationValues[v196]:reset()
	end
end
function AnimatedVehicle.loadSpeedRotatingPartFromXML(p197, p198, p199, p200, p201)
	if not p198(p197, p199, p200, p201) then
		return false
	end
	p199.animName = p200:getValue(p201 .. "#animName")
	p199.animOuterRange = p200:getValue(p201 .. "#animOuterRange", false)
	p199.animMinLimit = p200:getValue(p201 .. "#animMinLimit", 0)
	p199.animMaxLimit = p200:getValue(p201 .. "#animMaxLimit", 1)
	return true
end
function AnimatedVehicle.getIsSpeedRotatingPartActive(p202, p203, p204)
	if p204.animName ~= nil then
		local v205 = p202:getAnimationTime(p204.animName)
		if p204.animOuterRange then
			if p204.animMinLimit < v205 or v205 < p204.animMaxLimit then
				return false
			end
		elseif p204.animMaxLimit < v205 or v205 < p204.animMinLimit then
			return false
		end
	end
	return p203(p202, p204)
end
function AnimatedVehicle.loadWorkAreaFromXML(p206, p207, p208, p209, p210)
	p208.animName = p209:getValue(p210 .. "#animName")
	p208.animMinLimit = p209:getValue(p210 .. "#animMinLimit", 0)
	p208.animMaxLimit = p209:getValue(p210 .. "#animMaxLimit", 1)
	return p207(p206, p208, p209, p210)
end
function AnimatedVehicle.getIsWorkAreaActive(p211, p212, p213)
	if p213.animName ~= nil then
		local v214 = p211:getAnimationTime(p213.animName)
		if p213.animMaxLimit < v214 or v214 < p213.animMinLimit then
			return false
		end
	end
	return p212(p211, p213)
end
function AnimatedVehicle.loadMovingToolFromXML(p215, p216, p217, p218, p219)
	if not p216(p215, p217, p218, p219) then
		return false
	end
	p219.requiredAnimation = p217:getValue(p218 .. "#requiredAnimation")
	if p219.requiredAnimation ~= nil then
		p219.requiredAnimationMin = p217:getValue(p218 .. "#requiredAnimationMinTime", 0)
		p219.requiredAnimationMax = p217:getValue(p218 .. "#requiredAnimationMaxTime", 1)
	end
	return true
end
function AnimatedVehicle.getIsMovingToolActive(p220, p221, p222)
	if p222.requiredAnimation ~= nil then
		local v223 = p220:getAnimationTime(p222.requiredAnimation)
		if v223 < p222.requiredAnimationMin or p222.requiredAnimationMax < v223 then
			return false
		end
	end
	return p221(p220, p222)
end
function AnimatedVehicle.loadMovingPartFromXML(p224, p225, p226, p227, p228)
	if not p225(p224, p226, p227, p228) then
		return false
	end
	p228.requiredAnimation = p226:getValue(p227 .. "#requiredAnimation")
	if p228.requiredAnimation ~= nil then
		p228.requiredAnimationMin = p226:getValue(p227 .. "#requiredAnimationMinTime", 0)
		p228.requiredAnimationMax = p226:getValue(p227 .. "#requiredAnimationMaxTime", 1)
	end
	return true
end
function AnimatedVehicle.getIsMovingPartActive(p229, p230, p231)
	if p231.requiredAnimation ~= nil then
		local v232 = p229:getAnimationTime(p231.requiredAnimation)
		if v232 < p231.requiredAnimationMin or p231.requiredAnimationMax < v232 then
			return false
		end
	end
	return p230(p229, p231)
end
function AnimatedVehicle.initializeAnimationPartAttribute(p233, p234, p235, p236, p237, p238, p239, p240, p241, p242, p243, p244, p245)
	if p235[p241] ~= nil then
		for v246 = p236 + 1, p237 do
			local v247 = p234.parts[v246]
			local v248 = p245 == nil or p235[p245] == v247[p245]
			local v249 = true
			if p235.requiredAnimation ~= nil and p235.requiredAnimation == v247.requiredAnimation then
				for v250, v251 in ipairs(p235.requiredAnimationRange) do
					if v247.requiredAnimationRange[v250] ~= v251 then
						v249 = false
					end
				end
			end
			local v252 = p235.requiredConfigurationName == nil or (p235.requiredConfigurationName ~= v247.requiredConfigurationName or p235.requiredConfigurationIndex == v247.requiredConfigurationIndex)
			if p235.direction == v247.direction and (p235.node == v247.node and (v247[p241] ~= nil and (v248 and (v249 and v252)))) then
				if p235.direction == v247.direction and p235.startTime + p235.duration > v247.startTime + 0.001 then
					Logging.xmlWarning(p233.xmlFile, "Overlapping %s parts for node \'%s\' in animation \'%s\'", p242, getName(p235.node), p234.name)
				end
				p235[p238] = v247
				v247[p239] = p235
				if v247[p240] == nil then
					local v253 = {}
					local v254 = p235[p241]
					__set_list(v253, 1, {unpack(v254)})
					v247[p240] = v253
				end
				if p243 ~= nil and (p244 ~= nil and v247[p243] == nil) then
					local v255 = {}
					local v256 = p235[p244]
					__set_list(v255, 1, {unpack(v256)})
					v247[p243] = v255
					return
				end
				break
			end
		end
	end
end
function AnimatedVehicle.animPartSorter(p257, p258)
	if p257.startTime < p258.startTime then
		return true
	elseif p257.startTime == p258.startTime then
		return p257.duration < p258.duration
	else
		return false
	end
end
function AnimatedVehicle.animPartSorterReverse(p259, p260)
	local v261 = p259.startTime + p259.duration
	local v262 = p260.startTime + p260.duration
	if v262 < v261 then
		return true
	elseif v261 == v262 then
		return p259.startTime > p260.startTime
	else
		return false
	end
end
function AnimatedVehicle.getMovedLimitedValue(p263, p264, p265, p266)
	if p264 == p263 then
		return p263
	else
		return (p264 < p263 and math.max or math.min)(p263 + p265 * p266, p264)
	end
end
function AnimatedVehicle.setMovedLimitedValuesN(p267, p268, p269, p270, p271)
	local v272 = false
	for v273 = 1, p267 do
		local v274 = AnimatedVehicle.getMovedLimitedValue(p268[v273], p269[v273], p270[v273], p271)
		if p268[v273] ~= v274 then
			p268[v273] = v274
			v272 = true
		end
	end
	return v272
end
function AnimatedVehicle.setMovedLimitedValues3(p275, p276, p277, p278)
	return AnimatedVehicle.setMovedLimitedValuesN(3, p275, p276, p277, p278)
end
function AnimatedVehicle.setMovedLimitedValues4(p279, p280, p281, p282)
	return AnimatedVehicle.setMovedLimitedValuesN(4, p279, p280, p281, p282)
end
function AnimatedVehicle.findCurrentPartIndex(p283)
	if p283.currentSpeed > 0 then
		p283.currentPartIndex = #p283.parts + 1
		for v284, v285 in ipairs(p283.parts) do
			if v285.startTime + v285.duration >= p283.currentTime then
				p283.currentPartIndex = v284
				return
			end
		end
	else
		p283.currentPartIndex = #p283.partsReverse + 1
		for v286, v287 in ipairs(p283.partsReverse) do
			if v287.startTime <= p283.currentTime then
				p283.currentPartIndex = v286
				return
			end
		end
	end
end
function AnimatedVehicle.getDurationToEndOfPart(p288, p289)
	if p289.currentSpeed > 0 then
		return p288.startTime + p288.duration - p289.currentTime
	else
		return p289.currentTime - p288.startTime
	end
end
function AnimatedVehicle.getNextPartIsPlaying(p290, p291, p292, p293)
	if p292.currentSpeed > 0 then
		if p290 ~= nil then
			return p290.startTime > p292.currentTime
		end
	elseif p291 ~= nil then
		return p291.startTime + p291.duration < p292.currentTime
	end
	return p293
end
function AnimatedVehicle.updateAnimations(p294, p295, p296)
	local v297 = p294.spec_animatedVehicle
	for v298 = #v297.activeAnimations, 1, -1 do
		local v299 = v297.activeAnimations[v298]
		local v300, v301 = AnimatedVehicle.updateAnimationCurrentTime(p294, v299, p295, v299.stopTime)
		AnimatedVehicle.updateAnimation(p294, v299, v300, v301, p296)
	end
end
function AnimatedVehicle.updateAnimationByName(p302, p303, p304, p305)
	local v306 = p302.spec_animatedVehicle.animations[p303]
	if v306 ~= nil then
		local v307, v308 = AnimatedVehicle.updateAnimationCurrentTime(p302, v306, p304, v306.stopTime)
		AnimatedVehicle.updateAnimation(p302, v306, v307, v308, p305)
	end
end
function AnimatedVehicle.updateAnimationCurrentTime(_, p309, p310, p311)
	p309.previousTime = p309.currentTime
	p309.currentTime = p309.currentTime + p310 * p309.currentSpeed
	local v312 = p309.currentSpeed
	local v313 = p310 * math.abs(v312)
	local v314 = false
	if p311 ~= nil then
		if p309.currentSpeed > 0 then
			if p311 <= p309.currentTime then
				local v315 = v313 - (p309.currentTime - p311)
				p309.currentTime = p311
				return v315, true
			end
		elseif p309.currentTime <= p311 then
			v313 = v313 - (p311 - p309.currentTime)
			p309.currentTime = p311
			v314 = true
		end
	end
	return v313, v314
end
function AnimatedVehicle.updateAnimation(p316, p317, p318, p319, p320, p321)
	local v322 = p316.spec_animatedVehicle
	local v323 = #p317.parts
	local v324 = p317.parts
	if p317.currentSpeed < 0 then
		v324 = p317.partsReverse
	end
	local v325
	if p318 > 0 then
		local v326 = false
		local v327 = false
		if p317.isKeyframe then
			for v328, v329 in pairs(p317.curvesByNode) do
				local v330, v331, v332, v333, v334, v335, v336, v337, v338 = v329:get(p317.currentTime)
				if v329.hasTranslation then
					setTranslation(v328, v330, v331, v332)
				end
				if v329.hasRotation then
					setRotation(v328, v333, v334, v335)
				end
				if v329.hasScale then
					setScale(v328, v336, v337, v338)
				end
				SpecializationUtil.raiseEvent(p316, "onAnimationPartChanged", v328)
			end
			v325 = p317.currentTime <= 0 and true or p317.currentTime >= p317.duration
		else
			local v339 = p319
			for v340 = p317.currentPartIndex, v323 do
				local v341 = v324[v340]
				local v342 = true
				if v341.requiredAnimation ~= nil then
					local v343 = p316:getAnimationTime(v341.requiredAnimation)
					if v343 < v341.requiredAnimationRange[1] or v341.requiredAnimationRange[2] < v343 then
						v342 = false
					end
				end
				local v344 = v341.requiredConfigurationName == nil or (p316.configurations[v341.requiredConfigurationName] == nil or p316.configurations[v341.requiredConfigurationName] == v341.requiredConfigurationIndex)
				if (v341.direction == 0 or v341.direction > 0 == (p317.currentSpeed >= 0)) and (v342 and v344) then
					local v345 = AnimatedVehicle.getDurationToEndOfPart(v341, p317)
					if v341.duration < v345 then
						v327 = true
						break
					end
					local v346
					if p317.currentSpeed > 0 then
						local v347 = p317.currentTime - p318
						if v347 < v341.startTime then
							v346 = p318 - v341.startTime + v347
						else
							v346 = p318
						end
					else
						local v348 = p317.currentTime + p318
						local v349 = v341.startTime + v341.duration
						if v349 < v348 then
							v346 = p318 - (v348 - v349)
						else
							v346 = p318
						end
					end
					v326 = p316:updateAnimationPart(p317, v341, v345 + v346, p318, v346, p320) and true or v326
				end
				if v340 == p317.currentPartIndex and (p317.currentSpeed > 0 and v341.startTime + v341.duration < p317.currentTime or p317.currentSpeed <= 0 and v341.startTime > p317.currentTime) then
					p316:resetAnimationPartValues(v341)
					p317.currentPartIndex = p317.currentPartIndex + 1
				end
			end
			if v327 or (v326 or v323 > p317.currentPartIndex) then
				v325 = p319
				p319 = v339
			else
				p317.previousTime = p317.currentTime
				if p317.currentSpeed > 0 then
					p317.currentTime = p317.duration
					p319 = v339
					v325 = true
				else
					p317.currentTime = 0
					p319 = v339
					v325 = true
				end
			end
		end
		if table.hasElement(v322.activeAnimations, p317) or p321 == true then
			if p320 ~= true or p321 == true then
				for v350 = 1, #p317.samples do
					local v351 = p317.samples[v350]
					if g_soundManager:getIsSamplePlaying(v351) then
						if v351.endTime ~= nil then
							if v351.startPitchScale ~= nil then
								local v352 = MathUtil.inverseLerp(v351.startTime, v351.endTime, p317.currentTime)
								v351.pitchScale = (v351.endPitchScale - v351.startPitchScale) * v352 + v351.startPitchScale
							end
							if p317.currentSpeed > 0 then
								if p317.currentTime > v351.endTime then
									g_soundManager:stopSample(v351)
								end
							elseif p317.currentTime < v351.startTime then
								g_soundManager:stopSample(v351)
							end
							if v351.direction ~= 0 and v351.direction >= 0 ~= (p317.currentSpeed >= 0) then
								g_soundManager:stopSample(v351)
							end
						end
					elseif v351.direction == 0 or v351.direction >= 0 == (p317.currentSpeed >= 0) then
						if v351.loops == 0 then
							v351.readyToStart = true
						elseif v351.endTime == nil then
							if p317.currentSpeed < 0 then
								v351.readyToStart = p317.previousTime > v351.startTime
							else
								v351.readyToStart = p317.previousTime < v351.startTime
							end
						else
							v351.readyToStart = p317.previousTime < v351.startTime and true or p317.previousTime > v351.endTime
						end
						local v353 = p317.currentTime >= v351.startTime
						if v351.endTime == nil then
							if p317.currentSpeed < 0 then
								v353 = p317.currentTime <= v351.startTime
							end
						elseif p317.currentTime >= v351.startTime then
							v353 = p317.currentTime <= v351.endTime
						else
							v353 = false
						end
						if v351.readyToStart and v353 then
							g_soundManager:playSample(v351)
						end
					end
				end
			end
			SpecializationUtil.raiseEvent(p316, "onUpdateAnimation", p317.name)
			if not table.hasElement(v322.activeAnimations, p317) then
				v322.fixedTimeSamplesDirtyDelay = 2
			end
		end
	else
		v325 = p319
	end
	if v325 or v323 > 0 and (v323 < p317.currentPartIndex or p317.currentPartIndex < 1) then
		p317.previousTime = p317.currentTime
		if not v325 then
			if p317.currentSpeed > 0 then
				p317.currentTime = p317.duration
			else
				p317.currentTime = 0
			end
		end
		local v354 = p317.currentTime
		local v355 = math.max(v354, 0)
		local v356 = p317.duration
		p317.currentTime = math.min(v355, v356)
		local v357 = p317.stopTime ~= p317.currentTime
		p317.stopTime = nil
		if table.hasElement(v322.activeAnimations, p317) then
			if p316.isClient then
				for v358 = 1, #p317.samples do
					local v359 = p317.samples[v358]
					if v359.loops == 0 then
						g_soundManager:stopSample(v359)
					end
				end
				if p319 and p317.eventSamples ~= nil then
					if p317.currentSpeed > 0 then
						if p317.eventSamples.stopTimePos ~= nil then
							for v360 = 1, #p317.eventSamples.stopTimePos do
								g_soundManager:playSample(p317.eventSamples.stopTimePos[v360])
							end
						end
					elseif p317.eventSamples.stopTimeNeg ~= nil then
						for v361 = 1, #p317.eventSamples.stopTimeNeg do
							g_soundManager:playSample(p317.eventSamples.stopTimeNeg[v361])
						end
					end
				end
			end
			table.removeElement(v322.activeAnimations, p317)
			v322.numActiveAnimations = v322.numActiveAnimations - 1
			SpecializationUtil.raiseEvent(p316, "onFinishAnimation", p317.name)
		end
		if v357 and (p320 ~= true and p317.looping) then
			local v362 = p317.name
			local v363 = p317.currentTime
			local v364 = p317.duration
			local v365 = v363 / math.max(v364, 0.0001) - 1
			p316:setAnimationTime(v362, math.abs(v365), true)
			p316:playAnimation(p317.name, p317.currentSpeed, nil, true)
		end
	end
end
function AnimatedVehicle.updateAnimationPart(_, _, p366, p367, p368, p369, p370)
	local v371 = false
	for v372 = 1, #p366.animationValues do
		v371 = v371 or p366.animationValues[v372]:update(p367, p368, p369, p370)
	end
	return v371
end
function AnimatedVehicle.getNumOfActiveAnimations(p373)
	return p373.spec_animatedVehicle.numActiveAnimations
end
function AnimatedVehicle.onRegisterAnimationValueTypes(p_u_374)
	local function v378(p375, p376, p377)
		p375.node = p376:getValue(p377 .. "#node", nil, p375.part.components, p375.part.i3dMappings)
		if p375.node == nil then
			return false
		end
		p375:setWarningInformation("node: " .. getName(p375.node))
		p375:addCompareParameters("node")
		return true
	end
	p_u_374:registerAnimationValueType("rotation", "startRot", "endRot", false, AnimationValueFloat, v378, function(p379)
		return getRotation(p379.node)
	end, function(p380, ...)
		-- upvalues: (copy) p_u_374
		setRotation(p380.node, ...)
		SpecializationUtil.raiseEvent(p_u_374, "onAnimationPartChanged", p380.node)
	end)
	p_u_374:registerAnimationValueType("translation", "startTrans", "endTrans", false, AnimationValueFloat, v378, function(p381)
		return getTranslation(p381.node)
	end, function(p382, ...)
		-- upvalues: (copy) p_u_374
		setTranslation(p382.node, ...)
		SpecializationUtil.raiseEvent(p_u_374, "onAnimationPartChanged", p382.node)
	end)
	p_u_374:registerAnimationValueType("scale", "startScale", "endScale", false, AnimationValueFloat, v378, function(p383)
		return getScale(p383.node)
	end, function(p384, ...)
		-- upvalues: (copy) p_u_374
		setScale(p384.node, ...)
		SpecializationUtil.raiseEvent(p_u_374, "onAnimationPartChanged", p384.node)
	end)
	p_u_374:registerAnimationValueType("shaderParameter", "shaderStartValues", "shaderEndValues", false, AnimationValueFloat, function(p385, p386, p387)
		p385.node = p386:getValue(p387 .. "#node", nil, p385.part.components, p385.part.i3dMappings)
		p385.shaderParameter = p386:getValue(p387 .. "#shaderParameter")
		p385.shaderParameterPrev = p386:getValue(p387 .. "#shaderParameterPrev")
		if p385.node ~= nil and p385.shaderParameter ~= nil then
			if getHasClassId(p385.node, ClassIds.SHAPE) and getHasShaderParameter(p385.node, p385.shaderParameter) then
				p385:setWarningInformation("node: " .. getName(p385.node) .. "with shaderParam: " .. p385.shaderParameter)
				p385:addCompareParameters("node", "shaderParameter")
				p385.shaderParameterMask = {
					1,
					1,
					1,
					1
				}
				local v388 = p387 .. "#shaderStartValues"
				local v389 = p385.shaderParameterMask
				local v390 = false
				local v391 = p386:getValue(v388)
				if v391 ~= nil then
					for v392 = 1, #v391 do
						if v391[v392] == "-" then
							v389[v392] = 0
							v390 = true
						end
					end
				end
				p385.customShaderParameterMask = v390
				local v393 = p387 .. "#shaderEndValues"
				local v394 = p385.shaderParameterMask
				local v395 = false
				local v396 = p386:getValue(v393)
				if v396 ~= nil then
					for v397 = 1, #v396 do
						if v396[v397] == "-" then
							v394[v397] = 0
							v395 = true
						end
					end
				end
				p385.customShaderParameterMask = v395 or p385.customShaderParameterMask
				if p385.shaderParameterPrev == nil then
					local v398 = "prev" .. p385.shaderParameter:sub(1, 1):upper() .. p385.shaderParameter:sub(2)
					if getHasShaderParameter(p385.node, v398) then
						p385.shaderParameterPrev = v398
					end
				elseif not getHasShaderParameter(p385.node, p385.shaderParameterPrev) then
					Logging.xmlWarning(p386, "Node \'%s\' has no shaderParameterPrev \'%s\' for animation part \'%s\'!", getName(p385.node), p385.shaderParameterPrev, p387)
					return false
				end
				return true
			end
			Logging.xmlWarning(p386, "Node \'%s\' has no shaderParameter \'%s\' for animation part \'%s\'!", getName(p385.node), p385.shaderParameter, p387)
		end
		return false
	end, function(p399)
		return getShaderParameter(p399.node, p399.shaderParameter)
	end, function(p400, p401, p402, p403, p404)
		if p400.customShaderParameterMask then
			if p400.shaderParameterMask[1] == 0 then
				p401 = nil
			end
			if p400.shaderParameterMask[2] == 0 then
				p402 = nil
			end
			if p400.shaderParameterMask[3] == 0 then
				p403 = nil
			end
			if p400.shaderParameterMask[4] == 0 then
				p404 = nil
			end
		end
		if p400.shaderParameterPrev == nil then
			setShaderParameter(p400.node, p400.shaderParameter, p401, p402, p403, p404, false)
		else
			g_animationManager:setPrevShaderParameter(p400.node, p400.shaderParameter, p401, p402, p403, p404, false, p400.shaderParameterPrev)
		end
	end)
	p_u_374:registerAnimationValueType("visibility", "visibility", "", false, AnimationValueBool, v378, function(p405)
		return getVisibility(p405.node)
	end, function(p406, ...)
		setVisibility(p406.node, ...)
	end)
	p_u_374:registerAnimationValueType("visibilityInter", "startVisibility", "endVisibility", false, AnimationValueFloat, function(p407, p408, p409)
		p407.node = p408:getValue(p409 .. "#node", nil, p407.part.components, p407.part.i3dMappings)
		if p407.node == nil or (p407.startValue == nil or p407.endValue == nil) then
			return false
		end
		p407:setWarningInformation("node: " .. getName(p407.node))
		p407:addCompareParameters("node")
		return true
	end, function(p410)
		return p410.lastVisibilityValue == nil and (getVisibility(p410.node) and 1 or 0) or p410.lastVisibilityValue
	end, function(p411, p412)
		p411.lastVisibilityValue = p412
		setVisibility(p411.node, p412 >= 0.5)
	end)
	p_u_374:registerAnimationValueType("animationClip", "clipStartTime", "clipEndTime", true, AnimationValueFloat, function(p413, p414, p415)
		p413.node = p414:getValue(p415 .. "#node", nil, p413.part.components, p413.part.i3dMappings)
		p413.animationClip = p414:getValue(p415 .. "#animationClip")
		if p413.node ~= nil and p413.animationClip ~= nil then
			p413.animationCharSet = getAnimCharacterSet(p413.node)
			if p413.animationCharSet ~= 0 then
				p413.animationClipIndex = getAnimClipIndex(p413.animationCharSet, p413.animationClip)
				p413:setWarningInformation("node: " .. getName(p413.node) .. "with animationClip: " .. p413.animationClip)
				p413:addCompareParameters("node", "animationClip")
				return true
			end
			Logging.xmlWarning(p414, "Unable to find animation clip \'%s\' on node \'%s\' in \'%s\'", p413.animationClip, getName(p413.node), p415)
		end
		return false
	end, function(p416)
		local v417 = getAnimTrackAssignedClip(p416.animationCharSet, 0)
		clearAnimTrackClip(p416.animationCharSet, 0)
		assignAnimTrackClip(p416.animationCharSet, 0, p416.animationClipIndex)
		if v417 == p416.animationClipIndex then
			return getAnimTrackTime(p416.animationCharSet, 0)
		end
		local v418 = p416.startValue or p416.endValue
		if p416.animation.currentSpeed < 0 then
			v418 = p416.endValue or p416.startValue
		end
		return v418[1]
	end, function(p419, p420)
		if getAnimTrackAssignedClip(p419.animationCharSet, 0) ~= p419.animationClipIndex then
			clearAnimTrackClip(p419.animationCharSet, 0)
			assignAnimTrackClip(p419.animationCharSet, 0, p419.animationClipIndex)
		end
		enableAnimTrack(p419.animationCharSet, 0)
		setAnimTrackTime(p419.animationCharSet, 0, p420, true)
		disableAnimTrack(p419.animationCharSet, 0)
	end)
	p_u_374:registerAnimationValueType("dependentAnimation", "dependentAnimationStartTime", "dependentAnimationEndTime", true, AnimationValueFloat, function(p421, p422, p423)
		p421.dependentAnimation = p422:getValue(p423 .. "#dependentAnimation")
		if p421.dependentAnimation == nil then
			return false
		end
		p421:setWarningInformation("dependentAnimation: " .. p421.dependentAnimation)
		p421:addCompareParameters("dependentAnimation")
		return true
	end, function(p424)
		return p424.vehicle:getAnimationTime(p424.dependentAnimation)
	end, function(p425, p426)
		p425.vehicle:setAnimationTime(p425.dependentAnimation, p426, true)
	end)
	if p_u_374.isServer then
		p_u_374:registerAnimationValueType("rotLimit", "", "", false, AnimationValueFloat, function(p427, p428, p429)
			p427.startRotLimit = p428:getValue(p429 .. "#startRotLimit", nil, true)
			p427.startRotMinLimit = p428:getValue(p429 .. "#startRotMinLimit", nil, true)
			p427.startRotMaxLimit = p428:getValue(p429 .. "#startRotMaxLimit", nil, true)
			if p427.startRotLimit ~= nil then
				if p427.startRotMinLimit ~= nil then
					Logging.xmlWarning(p428, "Invalid rotLimit definition. \'startRotMinLimit\' defined but overwritten by defined \'startRotLimit\'! (%s)", p429)
				end
				if p427.startRotMaxLimit ~= nil then
					Logging.xmlWarning(p428, "Invalid rotLimit definition. \'startRotMaxLimit\' defined but overwritten by defined \'startRotLimit\'! (%s)", p429)
				end
				p427.startRotMinLimit = { -p427.startRotLimit[1], -p427.startRotLimit[2], -p427.startRotLimit[3] }
				p427.startRotMaxLimit = { p427.startRotLimit[1], p427.startRotLimit[2], p427.startRotLimit[3] }
			end
			p427.endRotLimit = p428:getValue(p429 .. "#endRotLimit", nil, true)
			p427.endRotMinLimit = p428:getValue(p429 .. "#endRotMinLimit", nil, true)
			p427.endRotMaxLimit = p428:getValue(p429 .. "#endRotMaxLimit", nil, true)
			if p427.endRotLimit ~= nil then
				if p427.endRotMinLimit ~= nil then
					Logging.xmlWarning(p428, "Invalid rotLimit definition. \'endRotMinLimit\' defined but overwritten by defined \'endRotLimit\'! (%s)", p429)
				end
				if p427.endRotMaxLimit ~= nil then
					Logging.xmlWarning(p428, "Invalid rotLimit definition. \'endRotMaxLimit\' defined but overwritten by defined \'endRotLimit\'! (%s)", p429)
				end
				p427.endRotMinLimit = { -p427.endRotLimit[1], -p427.endRotLimit[2], -p427.endRotLimit[3] }
				p427.endRotMaxLimit = { p427.endRotLimit[1], p427.endRotLimit[2], p427.endRotLimit[3] }
			end
			local v430 = p428:getValue(p429 .. "#componentJointIndex")
			if v430 ~= nil then
				if v430 >= 1 then
					p427.componentJoint = p427.vehicle.componentJoints[v430]
				end
				if p427.componentJoint == nil then
					Logging.xmlWarning(p428, "Invalid componentJointIndex for animation part \'%s\'. Indexing starts with 1!", p429)
					return false
				end
			end
			if p427.endRotMinLimit ~= nil and p427.endRotMaxLimit == nil or p427.endRotMinLimit == nil and p427.endRotMaxLimit ~= nil then
				Logging.xmlWarning(p428, "Incomplete end trans limit for animation part \'%s\'.", p429)
				return false
			end
			if p427.componentJoint == nil or (p427.endRotMinLimit == nil or p427.endRotMaxLimit == nil) then
				return false
			end
			if p427.startRotMinLimit ~= nil and p427.startRotMaxLimit ~= nil then
				p427.startValue = {
					p427.startRotMinLimit[1],
					p427.startRotMinLimit[2],
					p427.startRotMinLimit[3],
					p427.startRotMaxLimit[1],
					p427.startRotMaxLimit[2],
					p427.startRotMaxLimit[3]
				}
			end
			if p427.endRotMinLimit ~= nil and p427.endRotMaxLimit ~= nil then
				p427.endValue = {
					p427.endRotMinLimit[1],
					p427.endRotMinLimit[2],
					p427.endRotMinLimit[3],
					p427.endRotMaxLimit[1],
					p427.endRotMaxLimit[2],
					p427.endRotMaxLimit[3]
				}
			end
			if p427.endValue == nil then
				Logging.xmlWarning(p428, "Missing end rot limit for animation part \'%s\'.", p429)
				return false
			end
			p427.endName = "rotLimit"
			p427:setWarningInformation("componentJointIndex: " .. v430)
			p427:addCompareParameters("componentJoint")
			return true
		end, function(p431)
			return p431.componentJoint.rotMinLimit[1], p431.componentJoint.rotMinLimit[2], p431.componentJoint.rotMinLimit[3], p431.componentJoint.rotLimit[1], p431.componentJoint.rotLimit[2], p431.componentJoint.rotLimit[3]
		end, function(p432, p433, p434, p435, p436, p437, p438)
			p432.vehicle:setComponentJointRotLimit(p432.componentJoint, 1, p433, p436)
			p432.vehicle:setComponentJointRotLimit(p432.componentJoint, 2, p434, p437)
			p432.vehicle:setComponentJointRotLimit(p432.componentJoint, 3, p435, p438)
		end)
		p_u_374:registerAnimationValueType("transLimit", "", "", false, AnimationValueFloat, function(p439, p440, p441)
			p439.startTransLimit = p440:getValue(p441 .. "#startTransLimit", nil, true)
			p439.startTransMinLimit = p440:getValue(p441 .. "#startTransMinLimit", nil, true)
			p439.startTransMaxLimit = p440:getValue(p441 .. "#startTransMaxLimit", nil, true)
			if p439.startTransLimit ~= nil then
				if p439.startTransMinLimit ~= nil then
					Logging.xmlWarning(p440, "Invalid transLimit definition. \'startTransMinLimit\' defined but overwritten by defined \'startTransLimit\'! (%s)", p441)
				end
				if p439.startTransMaxLimit ~= nil then
					Logging.xmlWarning(p440, "Invalid transLimit definition. \'startTransMaxLimit\' defined but overwritten by defined \'startTransLimit\'! (%s)", p441)
				end
				p439.startTransMinLimit = { -p439.startTransLimit[1], -p439.startTransLimit[2], -p439.startTransLimit[3] }
				p439.startTransMaxLimit = { p439.startTransLimit[1], p439.startTransLimit[2], p439.startTransLimit[3] }
			end
			p439.endTransLimit = p440:getValue(p441 .. "#endTransLimit", nil, true)
			p439.endTransMinLimit = p440:getValue(p441 .. "#endTransMinLimit", nil, true)
			p439.endTransMaxLimit = p440:getValue(p441 .. "#endTransMaxLimit", nil, true)
			if p439.endTransLimit ~= nil then
				if p439.endTransMinLimit ~= nil then
					Logging.xmlWarning(p440, "Invalid transLimit definition. \'endTransMinLimit\' defined but overwritten by defined \'endTransLimit\'! (%s)", p441)
				end
				if p439.endTransMaxLimit ~= nil then
					Logging.xmlWarning(p440, "Invalid transLimit definition. \'endTransMaxLimit\' defined but overwritten by defined \'endTransLimit\'! (%s)", p441)
				end
				p439.endTransMinLimit = { -p439.endTransLimit[1], -p439.endTransLimit[2], -p439.endTransLimit[3] }
				p439.endTransMaxLimit = { p439.endTransLimit[1], p439.endTransLimit[2], p439.endTransLimit[3] }
			end
			local v442 = p440:getValue(p441 .. "#componentJointIndex")
			if v442 ~= nil then
				if v442 >= 1 then
					p439.componentJoint = p439.vehicle.componentJoints[v442]
				end
				if p439.componentJoint == nil then
					Logging.xmlWarning(p440, "Invalid componentJointIndex for animation part \'%s\'. Indexing starts with 1!", p441)
					return false
				end
			end
			if p439.endTransMinLimit ~= nil and p439.endTransMaxLimit == nil or p439.endTransMinLimit == nil and p439.endTransMaxLimit ~= nil then
				Logging.xmlWarning(p440, "Incomplete end trans limit for animation part \'%s\'.", p441)
				return false
			end
			if p439.componentJoint == nil or (p439.endTransMinLimit == nil or p439.endTransMaxLimit == nil) then
				return false
			end
			if p439.startTransMinLimit ~= nil and p439.startTransMaxLimit ~= nil then
				p439.startValue = {
					p439.startTransMinLimit[1],
					p439.startTransMinLimit[2],
					p439.startTransMinLimit[3],
					p439.startTransMaxLimit[1],
					p439.startTransMaxLimit[2],
					p439.startTransMaxLimit[3]
				}
			end
			if p439.endTransMinLimit ~= nil and p439.endTransMaxLimit ~= nil then
				p439.endValue = {
					p439.endTransMinLimit[1],
					p439.endTransMinLimit[2],
					p439.endTransMinLimit[3],
					p439.endTransMaxLimit[1],
					p439.endTransMaxLimit[2],
					p439.endTransMaxLimit[3]
				}
			end
			if p439.endValue == nil then
				Logging.xmlWarning(p440, "Missing end trans limit for animation part \'%s\'.", p441)
				return false
			end
			p439.endName = "transLimit"
			p439:setWarningInformation("componentJointIndex: " .. v442)
			p439:addCompareParameters("componentJoint")
			return true
		end, function(p443)
			return p443.componentJoint.transMinLimit[1], p443.componentJoint.transMinLimit[2], p443.componentJoint.transMinLimit[3], p443.componentJoint.transLimit[1], p443.componentJoint.transLimit[2], p443.componentJoint.transLimit[3]
		end, function(p444, p445, p446, p447, p448, p449, p450)
			p444.vehicle:setComponentJointTransLimit(p444.componentJoint, 1, p445, p448)
			p444.vehicle:setComponentJointTransLimit(p444.componentJoint, 2, p446, p449)
			p444.vehicle:setComponentJointTransLimit(p444.componentJoint, 3, p447, p450)
		end)
		p_u_374:registerAnimationValueType("rotationLimitSpring", "", "", false, AnimationValueFloat, function(p451, p452, p453)
			p451.startRotLimitSpring = p452:getValue(p453 .. "#startRotLimitSpring", nil, true)
			p451.startRotLimitDamping = p452:getValue(p453 .. "#startRotLimitDamping", nil, true)
			p451.endRotLimitSpring = p452:getValue(p453 .. "#endRotLimitSpring", nil, true)
			p451.endRotLimitDamping = p452:getValue(p453 .. "#endRotLimitDamping", nil, true)
			local v454 = p452:getValue(p453 .. "#componentJointIndex")
			if v454 ~= nil then
				if v454 >= 1 then
					p451.componentJoint = p451.vehicle.componentJoints[v454]
				end
				if p451.componentJoint == nil then
					Logging.xmlWarning(p452, "Invalid componentJointIndex for animation part \'%s\'. Indexing starts with 1!", p453)
					return false
				end
			end
			if p451.componentJoint == nil or p451.endRotLimitSpring == nil and p451.startRotLimitDamping == nil then
				return false
			end
			if p451.startRotLimitSpring ~= nil and p451.startRotLimitDamping ~= nil then
				p451.startValue = {
					p451.startRotLimitSpring[1],
					p451.startRotLimitSpring[2],
					p451.startRotLimitSpring[3],
					p451.startRotLimitDamping[1],
					p451.startRotLimitDamping[2],
					p451.startRotLimitDamping[3]
				}
			end
			if p451.endRotLimitSpring ~= nil and p451.endRotLimitDamping ~= nil then
				p451.endValue = {
					p451.endRotLimitSpring[1],
					p451.endRotLimitSpring[2],
					p451.endRotLimitSpring[3],
					p451.endRotLimitDamping[1],
					p451.endRotLimitDamping[2],
					p451.endRotLimitDamping[3]
				}
			end
			if p451.endValue == nil then
				Logging.xmlWarning(p452, "Missing \'endRotLimitSpring\' or \'endRotLimitDamping\' for animation part \'%s\'.", p453)
				return false
			end
			p451.endName = "rotationLimitSpring"
			p451:setWarningInformation("componentJointIndex: " .. v454)
			p451:addCompareParameters("componentJoint")
			return true
		end, function(p455)
			return p455.componentJoint.rotLimitSpring[1], p455.componentJoint.rotLimitSpring[2], p455.componentJoint.rotLimitSpring[3], p455.componentJoint.rotLimitDamping[1], p455.componentJoint.rotLimitDamping[2], p455.componentJoint.rotLimitDamping[3]
		end, function(p456, p457, p458, p459, p460, p461, p462)
			local v463 = p456.componentJoint.rotLimitSpring
			local v464 = p456.componentJoint.rotLimitSpring
			local v465 = p456.componentJoint.rotLimitSpring
			v463[1] = p457
			v464[2] = p458
			v465[3] = p459
			local v466 = p456.componentJoint.rotLimitDamping
			local v467 = p456.componentJoint.rotLimitDamping
			local v468 = p456.componentJoint.rotLimitDamping
			v466[1] = p460
			v467[2] = p461
			v468[3] = p462
			if p456.componentJoint.jointIndex ~= nil then
				for v469 = 1, 3 do
					setJointRotationLimitSpring(p456.componentJoint.jointIndex, v469 - 1, p456.componentJoint.rotLimitSpring[v469], p456.componentJoint.rotLimitDamping[v469])
				end
			end
		end)
		p_u_374:registerAnimationValueType("componentMass", "startMass", "endMass", false, AnimationValueFloat, function(p470, p471, p472)
			local v473 = p471:getValue(p472 .. "#componentIndex")
			if v473 ~= nil then
				if v473 >= 1 then
					p470.component = p470.vehicle.components[v473]
				end
				if p470.component == nil then
					Logging.xmlWarning(p471, "Invalid component for animation part \'%s\'. Indexing starts with 1!", p472)
					return false
				end
			end
			if p470.component == nil then
				return false
			end
			p470:setWarningInformation("componentIndex: " .. v473)
			p470:addCompareParameters("component")
			return true
		end, function(p474)
			return getMass(p474.component.node) * 1000
		end, function(p475, p476)
			setMass(p475.component.node, p476 * 0.001)
		end)
		p_u_374:registerAnimationValueType("centerOfMass", "startCenterOfMass", "endCenterOfMass", false, AnimationValueFloat, function(p477, p478, p479)
			local v480 = p478:getValue(p479 .. "#componentIndex")
			if v480 ~= nil then
				if v480 >= 1 then
					p477.component = p477.vehicle.components[v480]
				end
				if p477.component == nil then
					Logging.xmlWarning(p478, "Invalid component for animation part \'%s\'. Indexing starts with 1!", p479)
					return false
				end
			end
			if p477.component == nil then
				return false
			end
			p477:setWarningInformation("componentIndex: " .. v480)
			p477:addCompareParameters("component")
			return true
		end, function(p481)
			return getCenterOfMass(p481.component.node)
		end, function(p482, p483, p484, p485)
			setCenterOfMass(p482.component.node, p483, p484, p485)
		end)
		p_u_374:registerAnimationValueType("frictionVelocity", "startFrictionVelocity", "endFrictionVelocity", false, AnimationValueFloat, v378, function(p486)
			return p486.lastFrictionVelocity or 0
		end, function(p487, p488)
			setFrictionVelocity(p487.node, p488)
			p487.lastFrictionVelocity = p488
			if p487.origTransX == nil then
				local v489, v490, v491 = getTranslation(p487.node)
				p487.origTransX = v489
				p487.origTransY = v490
				p487.origTransZ = v491
			end
			setTranslation(p487.node, p487.origTransX + math.random() * 0.001, p487.origTransY, p487.origTransZ)
		end)
	end
	p_u_374:registerAnimationValueType("spline", "startSplinePos", "endSplinePos", false, AnimationValueFloat, function(p492, p493, p494)
		p492.node = p493:getValue(p494 .. "#node", nil, p492.part.components, p492.part.i3dMappings)
		p492.spline = p493:getValue(p494 .. "#spline", nil, p492.part.components, p492.part.i3dMappings)
		if p492.node == nil or p492.spline == nil then
			return false
		end
		p492:setWarningInformation("node:" .. getName(p492.node) .. " with spline: " .. getName(p492.spline))
		p492:addCompareParameters("node", "spline")
		return true
	end, function(p495)
		if p495.lastSplineTime ~= nil then
			return p495.lastSplineTime
		end
		local v496 = p495.startValue or p495.endValue
		if p495.animation.currentSpeed < 0 then
			v496 = p495.endValue or p495.startValue
		end
		return v496[1]
	end, function(p497, p498)
		local v499, v500, v501 = getSplinePosition(p497.spline, p498 % 1)
		local v502, v503, v504 = worldToLocal(getParent(p497.node), v499, v500, v501)
		setTranslation(p497.node, v502, v503, v504)
		p497.lastSplineTime = p498
		for _, v505 in ipairs(p497.animation.parts) do
			for v506 = 1, #v505.animationValues do
				local v507 = v505.animationValues[v506]
				if v507.node == p497.node and v507.name == p497.name then
					v507.lastSplineTime = p498
				end
			end
		end
	end)
	p_u_374:registerAnimationValueType("rollingGate", "startGatePos", "endGatePos", false, AnimationValueFloat, function(p508, p509, p510)
		if p509:hasProperty(p510 .. ".rollingGateAnimation") then
			local v511 = RollingGateAnimation.new()
			if v511:load(p509, p510 .. ".rollingGateAnimation", p508.part.components, p508.part.i3dMappings) then
				p508:setWarningInformation("rollingGateAnimation:" .. getName(v511.splineNode))
				p508.rollingGate = v511
				return true
			end
		end
		return false
	end, function(p512)
		return p512.rollingGate.state
	end, function(p513, p514)
		p513.rollingGate:setState(p514)
	end)
end

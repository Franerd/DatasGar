source("dataS/scripts/vehicles/specializations/events/BaleWrapperStateEvent.lua")
source("dataS/scripts/vehicles/specializations/events/BaleWrapperAutomaticDropEvent.lua")
source("dataS/scripts/vehicles/specializations/events/BaleWrapperDropEvent.lua")
BaleWrapper = {}
BaleWrapper.CONSUMABLE_TYPE_NAME = "BALE_WRAP"
BaleWrapper.STATE_NONE = 0
BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER = 1
BaleWrapper.STATE_MOVING_GRABBER_TO_WORK = 2
BaleWrapper.STATE_WRAPPER_WRAPPING_BALE = 3
BaleWrapper.STATE_WRAPPER_FINSIHED = 4
BaleWrapper.STATE_WRAPPER_DROPPING_BALE = 5
BaleWrapper.STATE_WRAPPER_RESETTING_PLATFORM = 6
BaleWrapper.STATE_NUM_BITS = 3
BaleWrapper.CHANGE_GRAB_BALE = 1
BaleWrapper.CHANGE_DROP_BALE_AT_GRABBER = 2
BaleWrapper.CHANGE_WRAPPING_START = 3
BaleWrapper.CHANGE_WRAPPING_BALE_FINSIHED = 4
BaleWrapper.CHANGE_WRAPPER_START_DROP_BALE = 5
BaleWrapper.CHANGE_WRAPPER_BALE_DROPPED = 6
BaleWrapper.CHANGE_WRAPPER_PLATFORM_RESET = 7
BaleWrapper.CHANGE_BUTTON_EMPTY = 8
BaleWrapper.ANIMATION_NAMES = {
	"moveToWrapper",
	"wrapBale",
	"dropFromWrapper",
	"resetAfterDrop",
	"resetWrapping"
}
BaleWrapper.DROP_COLLISION_MASK = CollisionFlag.VEHICLE + CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.PLAYER
BaleWrapper.BLOCK_COLLISION_MASK = CollisionFlag.VEHICLE + CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.PLAYER
function BaleWrapper.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Consumable, p1)
	end
	return v2
end
function BaleWrapper.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("wrappingColor", g_i18n:getText("configuration_wrappingColor"), nil, VehicleConfigurationItemColor)
	g_vehicleConfigurationManager:addConfigurationType("wrappingAnimation", g_i18n:getText("configuration_wrappingAnimation"), "baleWrapper", VehicleConfigurationItem)
	g_storeManager:addSpecType("baleWrapperBaleSizeRound", "shopListAttributeIconBaleWrapperBaleSizeRound", BaleWrapper.loadSpecValueBaleSizeRound, BaleWrapper.getSpecValueBaleSizeRound, StoreSpecies.VEHICLE)
	g_storeManager:addSpecType("baleWrapperBaleSizeSquare", "shopListAttributeIconBaleWrapperBaleSizeSquare", BaleWrapper.loadSpecValueBaleSizeSquare, BaleWrapper.getSpecValueBaleSizeSquare, StoreSpecies.VEHICLE)
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("BaleWrapper")
	v3:register(XMLValueType.FLOAT, "vehicle.baleWrapper#foldMinLimit", "Fold min limit (Allow grabbing if folding is between these values)", 0)
	v3:register(XMLValueType.FLOAT, "vehicle.baleWrapper#foldMaxLimit", "Fold max limit (Allow grabbing if folding is between these values)", 1)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.baleWrapper.grabber#node", "Grabber node")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.baleWrapper.grabber#triggerNode", "Grabber trigger node")
	v3:register(XMLValueType.FLOAT, "vehicle.baleWrapper.grabber#nearestDistance", "Distance to bale to grab it", 3)
	v3:register(XMLValueType.BOOL, "vehicle.baleWrapper.automaticDrop#enabled", "Automatic drop", "true on mobile")
	v3:register(XMLValueType.BOOL, "vehicle.baleWrapper.automaticDrop#toggleable", "Automatic bale drop can be toggled", "false on mobile")
	v3:register(XMLValueType.L10N_STRING, "vehicle.baleWrapper.automaticDrop#textPos", "Positive toggle automatic drop text", "action_toggleAutomaticBaleDropPos")
	v3:register(XMLValueType.L10N_STRING, "vehicle.baleWrapper.automaticDrop#textNeg", "Negative toggle automatic drop text", "action_toggleAutomaticBaleDropNeg")
	BaleWrapper.registerWrapperXMLPaths(v3, "vehicle.baleWrapper.roundBaleWrapper")
	BaleWrapper.registerWrapperXMLPaths(v3, "vehicle.baleWrapper.squareBaleWrapper")
	for v4 = 1, #BaleWrapper.ANIMATION_NAMES do
		BaleWrapper.registerWrapperAnimationXMLPaths(v3, "vehicle.baleWrapper.wrappingAnimationConfigurations.wrappingAnimationConfiguration(?).roundBaleWrapper", BaleWrapper.ANIMATION_NAMES[v4])
		BaleWrapper.registerWrapperAnimationXMLPaths(v3, "vehicle.baleWrapper.wrappingAnimationConfigurations.wrappingAnimationConfiguration(?).roundBaleWrapper.baleTypes.baleType(?)", BaleWrapper.ANIMATION_NAMES[v4])
		BaleWrapper.registerWrapperAnimationXMLPaths(v3, "vehicle.baleWrapper.wrappingAnimationConfigurations.wrappingAnimationConfiguration(?).squareBaleWrapper", BaleWrapper.ANIMATION_NAMES[v4])
		BaleWrapper.registerWrapperAnimationXMLPaths(v3, "vehicle.baleWrapper.wrappingAnimationConfigurations.wrappingAnimationConfiguration(?).squareBaleWrapper.baleTypes.baleType(?)", BaleWrapper.ANIMATION_NAMES[v4])
	end
	v3:setXMLSpecializationType()
	local v5 = Vehicle.xmlSchemaSavegame
	v5:register(XMLValueType.FLOAT, "vehicles.vehicle(?).baleWrapper#wrapperTime", "Bale wrapping time", 0)
	Bale.registerSavegameXMLPaths(v5, "vehicles.vehicle(?).baleWrapper.bale")
end
function BaleWrapper.registerWrapperXMLPaths(p6, p7)
	for v8 = 1, #BaleWrapper.ANIMATION_NAMES do
		BaleWrapper.registerWrapperAnimationXMLPaths(p6, p7, BaleWrapper.ANIMATION_NAMES[v8])
		BaleWrapper.registerWrapperAnimationXMLPaths(p6, p7 .. ".baleTypes.baleType(?)", BaleWrapper.ANIMATION_NAMES[v8])
	end
	p6:register(XMLValueType.STRING, p7 .. ".baleTypes.baleType(?)#fillType", "Fill type name")
	p6:register(XMLValueType.FLOAT, p7 .. ".baleTypes.baleType(?)#diameter", "Bale diameter", 0)
	p6:register(XMLValueType.FLOAT, p7 .. ".baleTypes.baleType(?)#width", "Bale width", 0)
	p6:register(XMLValueType.FLOAT, p7 .. ".baleTypes.baleType(?)#height", "Bale height", 0)
	p6:register(XMLValueType.FLOAT, p7 .. ".baleTypes.baleType(?)#length", "Bale length", 0)
	p6:register(XMLValueType.STRING, p7 .. ".baleTypes.baleType(?).textures#diffuse", "Path to wrap diffuse map")
	p6:register(XMLValueType.STRING, p7 .. ".baleTypes.baleType(?).textures#normal", "Path to wrap normal map")
	p6:register(XMLValueType.BOOL, p7 .. ".baleTypes.baleType(?)#skipWrapping", "Bale is picked up, but not wrapped", false)
	p6:register(XMLValueType.BOOL, p7 .. ".baleTypes.baleType(?)#forceWhileFolding", "Force this bale type while wrapper is folded", false)
	p6:register(XMLValueType.FLOAT, p7 .. ".baleTypes.baleType(?)#wrapUsage", "Usage of wrap rolls per bale", 0.1)
	p6:register(XMLValueType.FLOAT, p7 .. ".baleTypes.baleType(?).wrappingState.key(?)#time", "Time of wrapping (0-1)")
	p6:register(XMLValueType.FLOAT, p7 .. ".baleTypes.baleType(?).wrappingState.key(?)#wrappingState", "Wrapping state for shader")
	p6:register(XMLValueType.STRING, p7 .. ".baleTypes.baleType(?).dropAnimations.dropAnimation(?)#name", "Drop animation name")
	p6:register(XMLValueType.FLOAT, p7 .. ".baleTypes.baleType(?).dropAnimations.dropAnimation(?)#animSpeed", "Drop animation speed", 1)
	p6:register(XMLValueType.L10N_STRING, p7 .. ".baleTypes.baleType(?).dropAnimations.dropAnimation(?)#text", "Text to display in the input help")
	p6:register(XMLValueType.STRING, p7 .. ".baleTypes.baleType(?).dropAnimations.dropAnimation(?)#inputAction", "Name of input action")
	p6:register(XMLValueType.BOOL, p7 .. ".baleTypes.baleType(?).dropAnimations.dropAnimation(?)#liftOnDrop", "Lift the tools attacher joint while the bale is dropped", false)
	ObjectChangeUtil.registerObjectChangeXMLPaths(p6, p7 .. ".baleTypes.baleType(?)")
	BaleWrapper.registerWrapperFoilAnimationXMLPaths(p6, p7 .. ".baleTypes.baleType(?)")
	p6:register(XMLValueType.NODE_INDEX, p7 .. "#baleNode", "Bale Node")
	p6:register(XMLValueType.NODE_INDEX, p7 .. "#wrapperNode", "Wrapper Node")
	p6:register(XMLValueType.INT, p7 .. "#wrapperRotAxis", "Wrapper rotation axis", 2)
	p6:register(XMLValueType.FLOAT, p7 .. ".wrapperAnimation.key(?)#time", "Key time")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".wrapperAnimation.key(?)#baleRot", "Bale rotation")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".wrapperAnimation.key(?)#wrapperRot", "Wrapper rotation", "0 0 0")
	p6:register(XMLValueType.FLOAT, p7 .. "#wrappingTime", "Wrapping duration", 5)
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".wrapAnimNodes.wrapAnimNode(?)#node", "Wrap node")
	p6:register(XMLValueType.BOOL, p7 .. ".wrapAnimNodes.wrapAnimNode(?)#repeatWrapperRot", "Repeat wrapper rotation, so wrapper rotation is always between 0 and 360", false)
	p6:register(XMLValueType.INT, p7 .. ".wrapAnimNodes.wrapAnimNode(?)#normalizeRotationOnBaleDrop", "Normalize rotation on bale drop", 0)
	p6:register(XMLValueType.FLOAT, p7 .. ".wrapAnimNodes.wrapAnimNode(?).key(?)#wrapperRot", "Wrapper rotation")
	p6:register(XMLValueType.FLOAT, p7 .. ".wrapAnimNodes.wrapAnimNode(?).key(?)#wrapperTime", "Wrapper time")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".wrapAnimNodes.wrapAnimNode(?).key(?)#trans", "Trans", "0 0 0")
	p6:register(XMLValueType.VECTOR_ROT, p7 .. ".wrapAnimNodes.wrapAnimNode(?).key(?)#rot", "Rotation", "0 0 0")
	p6:register(XMLValueType.VECTOR_SCALE, p7 .. ".wrapAnimNodes.wrapAnimNode(?).key(?)#scale", "Scale", "1 1 1")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".wrapNodes.wrapNode(?)#node", "Wrap node")
	p6:register(XMLValueType.BOOL, p7 .. ".wrapNodes.wrapNode(?)#wrapVisibility", "Visibility while wrapping", false)
	p6:register(XMLValueType.BOOL, p7 .. ".wrapNodes.wrapNode(?)#emptyVisibility", "Visibility while empty", false)
	p6:register(XMLValueType.FLOAT, p7 .. ".wrapNodes.wrapNode(?)#maxWrapperRot", "Max. wrapper rotation")
	p6:register(XMLValueType.FLOAT, p7 .. ".wrappingState.key(?)#time", "Time of wrapping (0-1)")
	p6:register(XMLValueType.FLOAT, p7 .. ".wrappingState.key(?)#wrappingState", "Wrapping state for shader")
	p6:register(XMLValueType.FLOAT, p7 .. ".wrappingAnimationNodes#maxTime", "Max. time of animation nodes", "Wrapper anim time")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".wrappingAnimationNodes.key(?)#node", "Animation node")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".wrappingAnimationNodes.key(?)#rootNode", "Reference node for rotation")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".wrappingAnimationNodes.key(?)#linkNode", "Node will be linked to this node while key is activated")
	p6:register(XMLValueType.FLOAT, p7 .. ".wrappingAnimationNodes.key(?)#time", "Time to activate key")
	p6:register(XMLValueType.VECTOR_TRANS, p7 .. ".wrappingAnimationNodes.key(?)#translation", "Translation of key")
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".wrappingAnimationNodes#referenceNode", "Reference node")
	p6:register(XMLValueType.INT, p7 .. ".wrappingAnimationNodes#referenceAxis", "Reference axis", 1)
	p6:register(XMLValueType.ANGLE, p7 .. ".wrappingAnimationNodes#minRot", "Min. rotation", 0)
	p6:register(XMLValueType.ANGLE, p7 .. ".wrappingAnimationNodes#maxRot", "Max. rotation", 0)
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".dropArea#node", "Node in the center of the drop area (if defined this area will be checked if something blocks this area)")
	p6:register(XMLValueType.FLOAT, p7 .. ".dropArea#width", "Width of area", 1)
	p6:register(XMLValueType.FLOAT, p7 .. ".dropArea#height", "Height of area", 1)
	p6:register(XMLValueType.FLOAT, p7 .. ".dropArea#length", "Length of area", 1)
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".blockWrapArea#node", "Node in the center of the block area (if defined this area will be checked if it\'s clear to start the wrapping process)")
	p6:register(XMLValueType.FLOAT, p7 .. ".blockWrapArea#width", "Width of area", 1)
	p6:register(XMLValueType.FLOAT, p7 .. ".blockWrapArea#height", "Height of area", 1)
	p6:register(XMLValueType.FLOAT, p7 .. ".blockWrapArea#length", "Length of area", 1)
	BaleWrapper.registerWrapperFoilAnimationXMLPaths(p6, p7)
	p6:register(XMLValueType.NODE_INDEX, p7 .. ".wrappingCollisions.collision(?)#node", "Collision node")
	p6:register(XMLValueType.INT, p7 .. ".wrappingCollisions.collision(?)#activeCollisionMask", "Collision mask active")
	p6:register(XMLValueType.INT, p7 .. ".wrappingCollisions.collision(?)#inActiveCollisionMask", "Collision mask in active")
	p6:register(XMLValueType.L10N_STRING, p7 .. "#unloadBaleText", "Unload bale text", "\'action_unloadRoundBale\' for round bales and \'action_unloadSquareBale\' for square bales")
	p6:register(XMLValueType.BOOL, p7 .. "#skipUnsupportedBales", "Skip unsupported bales (pick them up and drop them instantly)")
	SoundManager.registerSampleXMLPaths(p6, p7 .. ".sounds", "wrap(?)")
	SoundManager.registerSampleXMLPaths(p6, p7 .. ".sounds", "start(?)")
	SoundManager.registerSampleXMLPaths(p6, p7 .. ".sounds", "stop(?)")
	p6:register(XMLValueType.FLOAT, p7 .. ".sounds#wrappingEndTime", "Wrapping time to play end wrapping sound", 1)
end
function BaleWrapper.registerWrapperAnimationXMLPaths(p9, p10, p11)
	p9:register(XMLValueType.STRING, p10 .. ".animations." .. p11 .. "#animName", "Animation name", 1)
	p9:register(XMLValueType.FLOAT, p10 .. ".animations." .. p11 .. "#animSpeed", "Animation speed", 1)
	p9:register(XMLValueType.BOOL, p10 .. ".animations." .. p11 .. "#reverseAfterMove", "Reverse animation after playing", true)
	p9:register(XMLValueType.BOOL, p10 .. ".animations." .. p11 .. "#resetOnStart", "Reset animation on start", false)
end
function BaleWrapper.registerWrapperFoilAnimationXMLPaths(p12, p13)
	p12:register(XMLValueType.NODE_INDEX, p13 .. ".wrappingFoilAnimation#referenceNode", "Time reference node")
	p12:register(XMLValueType.INT, p13 .. ".wrappingFoilAnimation#referenceAxis", "Rotation axis")
	p12:register(XMLValueType.ANGLE, p13 .. ".wrappingFoilAnimation#minRot", "Min. reference rotation")
	p12:register(XMLValueType.ANGLE, p13 .. ".wrappingFoilAnimation#maxRot", "Max. reference rotation")
	p12:register(XMLValueType.NODE_INDEX, p13 .. ".wrappingFoilAnimation#clipNode", "Node which has clip assigned")
	p12:register(XMLValueType.STRING, p13 .. ".wrappingFoilAnimation#clipName", "Name of the clip to control")
end
function BaleWrapper.registerFunctions(p14)
	SpecializationUtil.registerFunction(p14, "loadWrapperFromXML", BaleWrapper.loadWrapperFromXML)
	SpecializationUtil.registerFunction(p14, "loadWrapperAnimationsFromXML", BaleWrapper.loadWrapperAnimationsFromXML)
	SpecializationUtil.registerFunction(p14, "loadWrapperAnimCurveFromXML", BaleWrapper.loadWrapperAnimCurveFromXML)
	SpecializationUtil.registerFunction(p14, "loadWrapperAnimNodesFromXML", BaleWrapper.loadWrapperAnimNodesFromXML)
	SpecializationUtil.registerFunction(p14, "loadWrapperWrapNodesFromXML", BaleWrapper.loadWrapperWrapNodesFromXML)
	SpecializationUtil.registerFunction(p14, "loadWrapperStateCurveFromXML", BaleWrapper.loadWrapperStateCurveFromXML)
	SpecializationUtil.registerFunction(p14, "loadWrapperAnimationNodesFromXML", BaleWrapper.loadWrapperAnimationNodesFromXML)
	SpecializationUtil.registerFunction(p14, "loadWrapperFoilAnimationFromXML", BaleWrapper.loadWrapperFoilAnimationFromXML)
	SpecializationUtil.registerFunction(p14, "baleGrabberTriggerCallback", BaleWrapper.baleGrabberTriggerCallback)
	SpecializationUtil.registerFunction(p14, "allowsGrabbingBale", BaleWrapper.allowsGrabbingBale)
	SpecializationUtil.registerFunction(p14, "pickupWrapperBale", BaleWrapper.pickupWrapperBale)
	SpecializationUtil.registerFunction(p14, "getIsBaleWrappable", BaleWrapper.getIsBaleWrappable)
	SpecializationUtil.registerFunction(p14, "getIsBaleDropAllowed", BaleWrapper.getIsBaleDropAllowed)
	SpecializationUtil.registerFunction(p14, "onBaleWrapperDropOverlapCallback", BaleWrapper.onBaleWrapperDropOverlapCallback)
	SpecializationUtil.registerFunction(p14, "getIsBaleWrappingAllowed", BaleWrapper.getIsBaleWrappingAllowed)
	SpecializationUtil.registerFunction(p14, "onBaleWrapperBlockOverlapCallback", BaleWrapper.onBaleWrapperBlockOverlapCallback)
	SpecializationUtil.registerFunction(p14, "updateWrappingState", BaleWrapper.updateWrappingState)
	SpecializationUtil.registerFunction(p14, "doStateChange", BaleWrapper.doStateChange)
	SpecializationUtil.registerFunction(p14, "updateWrapNodes", BaleWrapper.updateWrapNodes)
	SpecializationUtil.registerFunction(p14, "playMoveToWrapper", BaleWrapper.playMoveToWrapper)
	SpecializationUtil.registerFunction(p14, "setBaleWrapperType", BaleWrapper.setBaleWrapperType)
	SpecializationUtil.registerFunction(p14, "getMatchingBaleTypeIndex", BaleWrapper.getMatchingBaleTypeIndex)
	SpecializationUtil.registerFunction(p14, "setBaleWrapperAutomaticDrop", BaleWrapper.setBaleWrapperAutomaticDrop)
	SpecializationUtil.registerFunction(p14, "setBaleWrapperDropAnimation", BaleWrapper.setBaleWrapperDropAnimation)
end
function BaleWrapper.registerOverwrittenFunctions(p15)
	SpecializationUtil.registerOverwrittenFunction(p15, "getIsFoldAllowed", BaleWrapper.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p15, "getCanBeSelected", BaleWrapper.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p15, "getShowConsumableEmptyWarning", BaleWrapper.getShowConsumableEmptyWarning)
	SpecializationUtil.registerOverwrittenFunction(p15, "addToPhysics", BaleWrapper.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p15, "removeFromPhysics", BaleWrapper.removeFromPhysics)
end
function BaleWrapper.registerEventListeners(p16)
	SpecializationUtil.registerEventListener(p16, "onLoad", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onPostLoad", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onLoadFinished", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onDelete", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onReadStream", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onWriteStream", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onUpdate", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onUpdateTick", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onDraw", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onRegisterActionEvents", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onRegisterExternalActionEvents", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onDeactivate", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onFoldStateChanged", BaleWrapper)
	SpecializationUtil.registerEventListener(p16, "onConsumableVariationChanged", BaleWrapper)
end
function BaleWrapper.onLoad(p17, _)
	local v18 = p17.spec_baleWrapper
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.wrapper", "vehicle.baleWrapper")
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.baleGrabber", "vehicle.baleWrapper.grabber")
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.baleWrapper.grabber#index", "vehicle.baleWrapper.grabber#node")
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.baleWrapper.grabber#index", "vehicle.baleWrapper.grabber#node")
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.baleWrapper.roundBaleWrapper#baleIndex", "vehicle.baleWrapper.roundBaleWrapper#baleNode")
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.baleWrapper.roundBaleWrapper#wrapperIndex", "vehicle.baleWrapper.roundBaleWrapper#wrapperNode")
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.baleWrapper.squareBaleWrapper#baleIndex", "vehicle.baleWrapper.squareBaleWrapper#baleNode")
	XMLUtil.checkDeprecatedXMLElements(p17.xmlFile, "vehicle.baleWrapper.squareBaleWrapper#wrapperIndex", "vehicle.baleWrapper.squareBaleWrapper#wrapperNode")
	v18.roundBaleWrapper = {}
	p17:loadWrapperFromXML(v18.roundBaleWrapper, p17.xmlFile, "vehicle.baleWrapper", "roundBaleWrapper")
	v18.squareBaleWrapper = {}
	p17:loadWrapperFromXML(v18.squareBaleWrapper, p17.xmlFile, "vehicle.baleWrapper", "squareBaleWrapper")
	v18.currentWrapper = {}
	v18.currentWrapperFoldMinLimit = p17.xmlFile:getValue("vehicle.baleWrapper#foldMinLimit", 0)
	v18.currentWrapperFoldMaxLimit = p17.xmlFile:getValue("vehicle.baleWrapper#foldMaxLimit", 1)
	v18.currentWrapper = v18.roundBaleWrapper
	p17:updateWrapNodes(false, true, 0)
	v18.currentWrapper = v18.squareBaleWrapper
	p17:updateWrapNodes(false, true, 0)
	v18.currentBaleTypeIndex = 1
	if v18.roundBaleWrapper.baleNode == nil then
		if v18.squareBaleWrapper.baleNode ~= nil then
			p17:setBaleWrapperType(false, 1)
		end
	else
		p17:setBaleWrapperType(true, 1)
	end
	v18.baleGrabber = {}
	v18.baleGrabber.grabNode = p17.xmlFile:getValue("vehicle.baleWrapper.grabber#node", nil, p17.components, p17.i3dMappings)
	v18.baleGrabber.triggerNode = p17.xmlFile:getValue("vehicle.baleWrapper.grabber#triggerNode", nil, p17.components, p17.i3dMappings)
	if v18.baleGrabber.triggerNode == nil then
		Logging.xmlWarning(p17.xmlFile, "Missing bale grab trigger node \'%s\'. This is required for all bale wrappers.", "vehicle.baleWrapper.grabber#triggerNode")
	else
		addTrigger(v18.baleGrabber.triggerNode, "baleGrabberTriggerCallback", p17)
	end
	v18.baleGrabber.nearestDistance = p17.xmlFile:getValue("vehicle.baleWrapper.grabber#nearestDistance", 3)
	v18.baleGrabber.balesInTrigger = {}
	v18.baleToLoad = nil
	v18.baleToMount = nil
	v18.baleWrapperState = BaleWrapper.STATE_NONE
	v18.grabberIsMoving = false
	v18.hasBaleWrapper = true
	v18.wrapColor = { 1, 1, 1 }
	v18.showInvalidBaleWarning = false
	v18.baleDropBlockedWarning = nil
	v18.dropAnimationIndex = 1
	v18.foundDropOverlappingObject = false
	v18.foundDropOverlappingObjectTime = (-1 / 0)
	v18.foundBlockOverlappingObject = false
	v18.automaticDrop = p17.xmlFile:getValue("vehicle.baleWrapper.automaticDrop#enabled", Platform.gameplay.automaticBaleDrop)
	v18.toggleableAutomaticDrop = p17.xmlFile:getValue("vehicle.baleWrapper.automaticDrop#toggleable", not Platform.gameplay.automaticBaleDrop)
	v18.toggleAutomaticDropTextPos = p17.xmlFile:getValue("vehicle.baleWrapper.automaticDrop#textPos", "action_toggleAutomaticBaleDropPos", p17.customEnvironment)
	v18.toggleAutomaticDropTextNeg = p17.xmlFile:getValue("vehicle.baleWrapper.automaticDrop#textNeg", "action_toggleAutomaticBaleDropNeg", p17.customEnvironment)
	v18.texts = {}
	v18.texts.warningFoldingWrapping = g_i18n:getText("warning_foldingNotWhileWrapping")
	v18.texts.warningBaleNotSupported = g_i18n:getText("warning_baleNotSupported")
	v18.texts.warningDropAreaBlocked = g_i18n:getText("warning_baleWrapperDropAreaBlocked")
end
function BaleWrapper.onPostLoad(p19, p20)
	local v21 = p19.spec_baleWrapper
	if p20 ~= nil and not p20.resetVehicles then
		local v22 = p20.xmlFile:getValue(p20.key .. ".baleWrapper.bale#filename")
		if v22 ~= nil then
			local v23 = {
				["filename"] = NetworkUtil.convertFromNetworkFilename(v22),
				["wrapperTime"] = p20.xmlFile:getValue(p20.key .. ".baleWrapper#wrapperTime", 0),
				["translation"] = { 0, 0, 0 },
				["rotation"] = { 0, 0, 0 },
				["attributes"] = {}
			}
			Bale.loadBaleAttributesFromXMLFile(v23.attributes, p20.xmlFile, p20.key .. ".baleWrapper.bale", p20.resetVehicles)
			v21.baleToLoad = v23
		end
	end
end
function BaleWrapper.loadWrapperFromXML(p_u_24, p_u_25, p_u_26, p27, p_u_28)
	local v_u_29 = p_u_24.spec_baleWrapper
	local v_u_30 = p_u_25 == v_u_29.roundBaleWrapper
	local v31 = Utils.getNoNil(p_u_24.configurations.wrappingAnimation, 1)
	local v_u_32 = string.format("vehicle.baleWrapper.wrappingAnimationConfigurations.wrappingAnimationConfiguration(%d)", v31 - 1)
	p_u_24:loadWrapperAnimationsFromXML(p_u_25, p_u_26, p27, v_u_32, "." .. p_u_28 .. ".animations")
	p_u_25.defaultAnimations = p_u_25.animations
	local v33 = p27 .. "." .. p_u_28
	p_u_25.baleNode = p_u_26:getValue(v33 .. "#baleNode", nil, p_u_24.components, p_u_24.i3dMappings)
	p_u_25.wrapperNode = p_u_26:getValue(v33 .. "#wrapperNode", nil, p_u_24.components, p_u_24.i3dMappings)
	p_u_25.wrapperRotAxis = p_u_26:getValue(v33 .. "#wrapperRotAxis", 2)
	p_u_25.animTime = p_u_26:getValue(v33 .. "#wrappingTime", 5) * 1000
	p_u_25.currentTime = 0
	p_u_25.currentBale = nil
	p_u_25.allowedBaleTypes = {}
	p_u_26:iterate(v33 .. ".baleTypes.baleType", function(p34, p35)
		-- upvalues: (copy) p_u_24, (copy) p_u_26, (copy) v_u_32, (copy) p_u_28, (copy) p_u_25, (copy) v_u_29, (copy) v_u_30
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#fillType")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#wrapperBaleFilename")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#minBaleDiameter", p35 .. "#diameter")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#maxBaleDiameter", p35 .. "#diameter")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#minBaleWidth", p35 .. "#width")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#maxBaleWidth", p35 .. "#width")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#minBaleHeight", p35 .. "#height")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#maxBaleHeight", p35 .. "#height")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#minBaleLength", p35 .. "#length")
		XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, p35 .. "#maxBaleLength", p35 .. "#length")
		local v36 = {
			["diameter"] = MathUtil.round(p_u_26:getValue(p35 .. "#diameter", 0), 2),
			["width"] = MathUtil.round(p_u_26:getValue(p35 .. "#width", 0), 2),
			["height"] = MathUtil.round(p_u_26:getValue(p35 .. "#height", 0), 2),
			["length"] = MathUtil.round(p_u_26:getValue(p35 .. "#length", 0), 2),
			["wrapDiffuse"] = p_u_26:getValue(p35 .. ".textures#diffuse")
		}
		if v36.wrapDiffuse ~= nil then
			v36.wrapDiffuse = Utils.getFilename(v36.wrapDiffuse, p_u_24.baseDirectory)
		end
		v36.wrapNormal = p_u_26:getValue(p35 .. ".textures#normal")
		if v36.wrapNormal ~= nil then
			v36.wrapNormal = Utils.getFilename(v36.wrapNormal, p_u_24.baseDirectory)
		end
		p_u_24:loadWrapperAnimationsFromXML(v36, p_u_26, p35, string.format("%s.%s.baleTypes.baleType(%d)", v_u_32, p_u_28, p34 - 1), ".animations", p_u_25.animations)
		p_u_24:loadWrapperFoilAnimationFromXML(v36, p_u_26, p35)
		v36.changeObjects = {}
		ObjectChangeUtil.loadObjectChangeFromXML(p_u_24.xmlFile, p35, v36.changeObjects, p_u_24.components, p_u_24)
		v36.skipWrapping = p_u_26:getValue(p35 .. "#skipWrapping", false)
		v36.forceWhileFolding = p_u_26:getValue(p35 .. "#forceWhileFolding", false)
		if v36.forceWhileFolding then
			v_u_29.foldedBaleType = {
				["isRoundBaleWrapper"] = v_u_30,
				["baleTypeIndex"] = p34
			}
		end
		v36.wrapUsage = p_u_26:getValue(p35 .. "#wrapUsage", 0.1) / p_u_25.animTime
		p_u_24:loadWrapperStateCurveFromXML(v36, p_u_26, p35)
		v36.dropAnimations = {}
		for _, v37 in p_u_24.xmlFile:iterator(p35 .. ".dropAnimations.dropAnimation") do
			local v38 = {
				["name"] = p_u_26:getValue(v37 .. "#name"),
				["animSpeed"] = p_u_26:getValue(v37 .. "#animSpeed", 1),
				["text"] = p_u_26:getValue(v37 .. "#text", nil, p_u_24.customEnvironment, false),
				["inputAction"] = p_u_26:getValue(v37 .. "#inputAction")
			}
			if v38.inputAction ~= nil then
				v38.inputAction = InputAction[v38.inputAction]
			end
			v38.liftOnDrop = p_u_26:getValue(v37 .. "#liftOnDrop", false)
			local v39 = v36.dropAnimations
			table.insert(v39, v38)
		end
		local v40 = p_u_25.allowedBaleTypes
		table.insert(v40, v36)
	end)
	p_u_24:loadWrapperAnimCurveFromXML(p_u_25, p_u_26, v33)
	p_u_24:loadWrapperAnimNodesFromXML(p_u_25, p_u_26, v33)
	p_u_24:loadWrapperWrapNodesFromXML(p_u_25, p_u_26, v33)
	p_u_24:loadWrapperStateCurveFromXML(p_u_25, p_u_26, v33)
	p_u_24:loadWrapperAnimationNodesFromXML(p_u_25, p_u_26, v33, p_u_25.animTime)
	p_u_24:loadWrapperFoilAnimationFromXML(p_u_25, p_u_26, v33, true)
	p_u_25.wrappingFoilAnimationDefault = p_u_25.wrappingFoilAnimation
	p_u_25.dropArea = {}
	p_u_25.dropArea.node = p_u_24.xmlFile:getValue(v33 .. ".dropArea#node", nil, p_u_24.components, p_u_24.i3dMappings)
	p_u_25.dropArea.width = p_u_24.xmlFile:getValue(v33 .. ".dropArea#width", 1)
	p_u_25.dropArea.height = p_u_24.xmlFile:getValue(v33 .. ".dropArea#height", 1)
	p_u_25.dropArea.length = p_u_24.xmlFile:getValue(v33 .. ".dropArea#length", 1)
	p_u_25.blockWrapArea = {}
	p_u_25.blockWrapArea.node = p_u_24.xmlFile:getValue(v33 .. ".blockWrapArea#node", nil, p_u_24.components, p_u_24.i3dMappings)
	p_u_25.blockWrapArea.width = p_u_24.xmlFile:getValue(v33 .. ".blockWrapArea#width", 1)
	p_u_25.blockWrapArea.height = p_u_24.xmlFile:getValue(v33 .. ".blockWrapArea#height", 1)
	p_u_25.blockWrapArea.length = p_u_24.xmlFile:getValue(v33 .. ".blockWrapArea#length", 1)
	p_u_25.unloadBaleText = p_u_26:getValue(v33 .. "#unloadBaleText", v_u_30 and "action_unloadRoundBale" or "action_unloadSquareBale", p_u_24.customEnvironment)
	XMLUtil.checkDeprecatedXMLElements(p_u_24.xmlFile, v33 .. "#skipWrappingFillTypes", v33 .. "#skipUnsupportedBales")
	p_u_25.skipUnsupportedBales = p_u_24.xmlFile:getValue(v33 .. "#skipUnsupportedBales", false)
	if p_u_24.isClient then
		p_u_25.samples = {}
		p_u_25.samples.wrap = g_soundManager:loadSamplesFromXML(p_u_24.xmlFile, v33 .. ".sounds", "wrap", p_u_24.baseDirectory, p_u_24.components, 0, AudioGroup.VEHICLE, p_u_24.i3dMappings, p_u_24)
		p_u_25.samples.start = g_soundManager:loadSamplesFromXML(p_u_24.xmlFile, v33 .. ".sounds", "start", p_u_24.baseDirectory, p_u_24.components, 1, AudioGroup.VEHICLE, p_u_24.i3dMappings, p_u_24)
		p_u_25.samples.stop = g_soundManager:loadSamplesFromXML(p_u_24.xmlFile, v33 .. ".sounds", "stop", p_u_24.baseDirectory, p_u_24.components, 1, AudioGroup.VEHICLE, p_u_24.i3dMappings, p_u_24)
		p_u_25.wrappingSoundEndTime = p_u_26:getValue(v33 .. ".sounds#wrappingEndTime", 1)
	end
end
function BaleWrapper.loadWrapperAnimationsFromXML(p41, p42, p43, p44, p45, p46, p47)
	p42.animations = {}
	if p47 ~= nil then
		local v48 = p42.animations
		setmetatable(v48, {
			["__index"] = p47
		})
	end
	for v49 = 1, #BaleWrapper.ANIMATION_NAMES do
		local v50 = BaleWrapper.ANIMATION_NAMES[v49]
		local v51 = p44 .. p46 .. "." .. v50
		local v52 = p45 .. p46 .. "." .. v50
		if not p43:hasProperty(v52) then
			v52 = v51
		end
		local v53 = {
			["animName"] = p43:getValue(v52 .. "#animName"),
			["animSpeed"] = p43:getValue(v52 .. "#animSpeed", 1),
			["reverseAfterMove"] = p43:getValue(v52 .. "#reverseAfterMove", true)
		}
		if p43:getValue(v52 .. "#resetOnStart", false) then
			p41:playAnimation(v53.animName, -1, 0.1, true)
			AnimatedVehicle.updateAnimationByName(p41, v53.animName, 9999999, true)
		end
		if p47 == nil or v53.animName ~= nil then
			p42.animations[v50] = v53
		end
	end
end
function BaleWrapper.loadWrapperAnimCurveFromXML(_, p_u_54, p_u_55, p56)
	p_u_54.animCurve = AnimCurve.new(linearInterpolatorN)
	p_u_55:iterate(p56 .. "wrapperAnimation.key", function(_, p57)
		-- upvalues: (copy) p_u_55, (copy) p_u_54
		local v58 = p_u_55:getValue(p57 .. "#time")
		local v59, v60, v61 = p_u_55:getValue(p57 .. "#baleRot")
		if v59 == nil or (v60 == nil or v61 == nil) then
			return false
		end
		local v62, v63, v64 = p_u_55:getValue(p57 .. "#wrapperRot", "0 0 0")
		p_u_54.animCurve:addKeyframe({
			v59,
			v60,
			v61,
			v62,
			v63,
			v64,
			["time"] = v58
		})
	end)
end
function BaleWrapper.loadWrapperAnimNodesFromXML(p_u_65, p_u_66, p_u_67, p68)
	p_u_66.wrapAnimNodes = {}
	p_u_67:iterate(p68 .. ".wrapAnimNodes.wrapAnimNode", function(_, p69)
		-- upvalues: (copy) p_u_65, (copy) p_u_67, (copy) p_u_66
		XMLUtil.checkDeprecatedXMLElements(p_u_65.xmlFile, p69 .. "#index", p69 .. "#node")
		local v_u_70 = {
			["nodeId"] = p_u_67:getValue(p69 .. "#node", nil, p_u_65.components, p_u_65.i3dMappings)
		}
		if v_u_70.nodeId ~= nil then
			v_u_70.useWrapperRot = false
			v_u_70.animCurve = AnimCurve.new(linearInterpolatorN)
			local v_u_71 = 0
			p_u_67:iterate(p69 .. ".key", function(_, p72)
				-- upvalues: (ref) p_u_67, (copy) v_u_70, (ref) v_u_71
				local v73 = p_u_67:getValue(p72 .. "#wrapperRot")
				local v74 = p_u_67:getValue(p72 .. "#wrapperTime")
				if v73 == nil and v74 == nil then
					return false
				end
				v_u_70.useWrapperRot = v73 ~= nil
				local v75, v76, v77 = p_u_67:getValue(p72 .. "#trans", "0 0 0")
				local v78, v79, v80 = p_u_67:getValue(p72 .. "#rot", "0 0 0")
				local v81, v82, v83 = p_u_67:getValue(p72 .. "#scale", "1 1 1")
				if v73 == nil then
					v_u_70.animCurve:addKeyframe({
						v75,
						v76,
						v77,
						v78,
						v79,
						v80,
						v81,
						v82,
						v83,
						["time"] = v74
					})
				else
					v_u_70.animCurve:addKeyframe({
						v75,
						v76,
						v77,
						v78,
						v79,
						v80,
						v81,
						v82,
						v83,
						["time"] = math.rad(v73)
					})
				end
				v_u_71 = v_u_71 + 1
			end)
			if v_u_71 > 0 then
				v_u_70.repeatWrapperRot = p_u_67:getValue(p69 .. "#repeatWrapperRot", false)
				v_u_70.normalizeRotationOnBaleDrop = p_u_67:getValue(p69 .. "#normalizeRotationOnBaleDrop", 0)
				local v84 = p_u_66.wrapAnimNodes
				table.insert(v84, v_u_70)
			end
		end
	end)
end
function BaleWrapper.loadWrapperWrapNodesFromXML(p_u_85, p_u_86, p_u_87, p88)
	p_u_86.wrapNodes = {}
	p_u_87:iterate(p88 .. ".wrapNodes.wrapNode", function(_, p89)
		-- upvalues: (copy) p_u_85, (copy) p_u_87, (copy) p_u_86
		XMLUtil.checkDeprecatedXMLElements(p_u_85.xmlFile, p89 .. "#index", p89 .. "#node")
		local v90 = {
			["nodeId"] = p_u_87:getValue(p89 .. "#node", nil, p_u_85.components, p_u_85.i3dMappings),
			["wrapVisibility"] = p_u_87:getValue(p89 .. "#wrapVisibility", false),
			["emptyVisibility"] = p_u_87:getValue(p89 .. "#emptyVisibility", false)
		}
		if v90.nodeId ~= nil and (v90.wrapVisibility or v90.emptyVisibility) then
			v90.maxWrapperRot = p_u_87:getValue(p89 .. "#maxWrapperRot", (1 / 0))
			local v91 = p_u_86.wrapNodes
			table.insert(v91, v90)
		end
	end)
end
function BaleWrapper.loadWrapperStateCurveFromXML(_, p_u_92, p_u_93, p94)
	p_u_92.wrappingStateCurve = AnimCurve.new(linearInterpolator1)
	p_u_93:iterate(p94 .. ".wrappingState.key", function(_, p95)
		-- upvalues: (copy) p_u_93, (copy) p_u_92
		local v96 = p_u_93:getValue(p95 .. "#time")
		local v97 = {
			p_u_93:getValue(p95 .. "#wrappingState"),
			["time"] = v96
		}
		p_u_92.wrappingStateCurve:addKeyframe(v97)
	end)
	if #p_u_92.wrappingStateCurve.keyframes == 0 then
		p_u_92.wrappingStateCurve = nil
	end
end
function BaleWrapper.loadWrapperAnimationNodesFromXML(p_u_98, p_u_99, p_u_100, p101, p102)
	local v_u_103 = p_u_100:getValue(p101 .. ".wrappingAnimationNodes#maxTime", p102 / 1000)
	p_u_99.wrappingAnimationNodes = {}
	p_u_99.wrappingAnimationNodes.nodes = {}
	p_u_99.wrappingAnimationNodes.nodeToRootNode = {}
	p_u_100:iterate(p101 .. ".wrappingAnimationNodes.key", function(_, p104)
		-- upvalues: (copy) p_u_100, (copy) p_u_98, (copy) v_u_103, (copy) p_u_99
		local v105 = p_u_100:getValue(p104 .. "#time")
		local v106 = p_u_100:getValue(p104 .. "#node", nil, p_u_98.components, p_u_98.i3dMappings)
		local v107 = p_u_100:getValue(p104 .. "#rootNode", nil, p_u_98.components, p_u_98.i3dMappings)
		local v108 = p_u_100:getValue(p104 .. "#linkNode", nil, p_u_98.components, p_u_98.i3dMappings)
		if v105 ~= nil and v106 ~= nil then
			local v109 = {
				["time"] = v105 / v_u_103,
				["nodeId"] = v106,
				["linkNode"] = v108,
				["parent"] = getParent(v106),
				["translation"] = p_u_100:getValue(p104 .. "#translation", nil, true)
			}
			if v109.translation == nil then
				Logging.xmlWarning(p_u_100, "Missing values for \'%s\'", p104 .. "#translation")
				return
			end
			if v107 ~= nil then
				p_u_99.wrappingAnimationNodes.nodeToRootNode[v106] = v107
			end
			local v110 = p_u_99.wrappingAnimationNodes.nodes
			table.insert(v110, v109)
		end
	end)
	for v111 = 1, #p_u_99.wrappingAnimationNodes.nodes do
		local v112 = p_u_99.wrappingAnimationNodes.nodes[v111]
		if v112.time == 0 then
			local v113 = setTranslation
			local v114 = v112.nodeId
			local v115 = v112.translation
			v113(v114, unpack(v115))
			if v112.linkNode ~= nil then
				local v116 = localToWorld
				local v117 = v112.parent
				local v118 = v112.translation
				local v119, v120, v121 = v116(v117, unpack(v118))
				link(v112.linkNode, v112.nodeId)
				setWorldTranslation(v112.nodeId, v119, v120, v121)
			end
		end
	end
	p_u_99.wrappingAnimationNodes.referenceNode = p_u_100:getValue(p101 .. ".wrappingAnimationNodes#referenceNode", nil, p_u_98.components, p_u_98.i3dMappings)
	p_u_99.wrappingAnimationNodes.referenceAxis = p_u_100:getValue(p101 .. ".wrappingAnimationNodes#referenceAxis", 2)
	p_u_99.wrappingAnimationNodes.referenceMinRot = p_u_100:getValue(p101 .. ".wrappingAnimationNodes#minRot", 0)
	p_u_99.wrappingAnimationNodes.referenceMaxRot = p_u_100:getValue(p101 .. ".wrappingAnimationNodes#maxRot", 0)
	if p_u_99.wrappingAnimationNodes.referenceNode ~= nil then
		p_u_99.wrappingAnimationNodes.referenceNodeRotation = { getRotation(p_u_99.wrappingAnimationNodes.referenceNode) }
	end
	p_u_99.wrappingAnimationNodes.lastTime = -1
	p_u_99.wrappingAnimationNodes.currentIndex = 0
end
function BaleWrapper.loadWrapperFoilAnimationFromXML(p122, p123, p124, p125, p126)
	local v127 = {
		["referenceNode"] = p124:getValue(p125 .. ".wrappingFoilAnimation#referenceNode", nil, p122.components, p122.i3dMappings)
	}
	if v127.referenceNode ~= nil then
		v127.referenceAxis = p124:getValue(p125 .. ".wrappingFoilAnimation#referenceAxis", 2)
		v127.referenceMinRot = p124:getValue(p125 .. ".wrappingFoilAnimation#minRot", 0)
		v127.referenceMaxRot = p124:getValue(p125 .. ".wrappingFoilAnimation#maxRot", 0)
		v127.referenceNodeRotation = { 0, 0, 0 }
		v127.clipNode = p124:getValue(p125 .. ".wrappingFoilAnimation#clipNode", nil, p122.components, p122.i3dMappings)
		if v127.clipNode ~= nil then
			v127.animationClip = p124:getValue(p125 .. ".wrappingFoilAnimation#clipName")
			if v127.animationClip == nil then
				Logging.xmlWarning(p122.xmlFile, "Missing clipName for foil animation \'%s\'", p125 .. ".wrappingFoilAnimation")
				return
			else
				v127.animationCharSet = getAnimCharacterSet(v127.clipNode)
				if v127.animationCharSet == 0 then
					Logging.xmlWarning(p122.xmlFile, "Unable to find animation clip \'%s\' on node \'%s\' in \'%s\'", v127.animationClip, getName(v127.clipNode), p125 .. ".wrappingFoilAnimation")
					return
				else
					v127.animationClipIndex = getAnimClipIndex(v127.animationCharSet, v127.animationClip)
					if v127.animationClipIndex >= 0 then
						v127.animationClipDuration = getAnimClipDuration(v127.animationCharSet, v127.animationClipIndex)
						if p126 then
							clearAnimTrackClip(v127.animationCharSet, 0)
							assignAnimTrackClip(v127.animationCharSet, 0, v127.animationClipIndex)
							enableAnimTrack(v127.animationCharSet, 0)
							setAnimTrackTime(v127.animationCharSet, 0, 0, true)
							disableAnimTrack(v127.animationCharSet, 0)
						end
						v127.lastTime = 0
						p123.wrappingFoilAnimation = v127
					else
						Logging.xmlWarning(p122.xmlFile, "Unable to find animation clip \'%s\' on node \'%s\' in \'%s\'", v127.animationClip, getName(v127.clipNode), p125 .. ".wrappingFoilAnimation")
					end
				end
			end
		end
		Logging.xmlWarning(p122.xmlFile, "Missing clipNode for foil animation \'%s\'", p125 .. ".wrappingFoilAnimation")
	end
end
function BaleWrapper.onLoadFinished(p128, _)
	local v129 = p128.spec_baleWrapper
	if v129.baleToLoad ~= nil then
		local v130 = v129.baleToLoad
		v129.baleToLoad = nil
		local v131 = Bale.new(p128.isServer, p128.isClient)
		local v132 = v130.translation
		local v133, v134, v135 = unpack(v132)
		local v136 = v130.rotation
		local v137, v138, v139 = unpack(v136)
		if v131:loadFromConfigXML(v130.filename, v133, v134, v135, v137, v138, v139, v130.attributes.uniqueId) then
			v131:applyBaleAttributes(v130.attributes)
			v131:register()
			if v131.nodeId ~= nil and v131.nodeId ~= 0 then
				p128:doStateChange(BaleWrapper.CHANGE_GRAB_BALE, NetworkUtil.getObjectId(v131))
				p128:doStateChange(BaleWrapper.CHANGE_DROP_BALE_AT_GRABBER)
				p128:doStateChange(BaleWrapper.CHANGE_WRAPPING_START)
				v129.currentWrapper.currentTime = v130.wrapperTime
				local v140 = v130.wrapperTime / v129.currentWrapper.animTime
				v131:setWrappingState((math.min(v140, 1)))
				local v141 = v129.currentWrapper.animations.wrapBale
				local v142 = v129.currentWrapper.currentTime / v129.currentWrapper.animTime
				p128:updateWrappingState(v142)
				AnimatedVehicle.updateAnimations(p128, 99999999, true)
				if v142 < 1 then
					p128:setAnimationTime(v141.animName, v142, true)
					p128:playAnimation(v141.animName, v141.animSpeed, v142, true)
					return
				end
				p128:doStateChange(BaleWrapper.CHANGE_WRAPPING_BALE_FINSIHED)
				p128:setAnimationTime(v141.animName, v142, true)
				v129.setWrappingStateFinished = false
			end
		end
	end
end
function BaleWrapper.onDelete(p143)
	local v144 = p143.spec_baleWrapper
	local v145
	if v144.currentWrapper == nil or v144.currentWrapper.currentBale == nil then
		v145 = nil
	else
		v145 = v144.currentWrapper.currentBale
	end
	if v144.baleGrabber ~= nil and v144.baleGrabber.currentBale ~= nil then
		v145 = v144.baleGrabber.currentBale
	end
	if v145 ~= nil then
		local v146 = NetworkUtil.getObject(v145)
		if v146 ~= nil then
			if p143.isServer then
				if p143.isReconfigurating == nil or not p143.isReconfigurating then
					v146:unmountKinematic()
					v146:setNeedsSaving(true)
					v146:setCanBeSold(true)
				else
					v146:delete()
				end
			else
				v146:unmountKinematic()
				v146:setNeedsSaving(true)
				v146:setCanBeSold(true)
			end
		end
	end
	if v144.baleGrabber ~= nil and v144.baleGrabber.triggerNode ~= nil then
		removeTrigger(v144.baleGrabber.triggerNode)
	end
	if v144.roundBaleWrapper ~= nil then
		g_soundManager:deleteSamples(v144.roundBaleWrapper.samples.wrap)
		g_soundManager:deleteSamples(v144.roundBaleWrapper.samples.start)
		g_soundManager:deleteSamples(v144.roundBaleWrapper.samples.stop)
	end
	if v144.squareBaleWrapper ~= nil then
		g_soundManager:deleteSamples(v144.squareBaleWrapper.samples.wrap)
		g_soundManager:deleteSamples(v144.squareBaleWrapper.samples.start)
		g_soundManager:deleteSamples(v144.squareBaleWrapper.samples.stop)
	end
end
function BaleWrapper.saveToXMLFile(p147, p148, p149, _)
	local v150 = p147.spec_baleWrapper
	local v151 = v150.baleGrabber.currentBale
	if v151 == nil then
		v151 = v150.currentWrapper.currentBale
	end
	p148:setValue(p149 .. "#wrapperTime", v150.currentWrapper.currentTime)
	if v151 ~= nil then
		local v152 = NetworkUtil.getObject(v151)
		if v152 ~= nil then
			v152:saveToXMLFile(p148, p149 .. ".bale")
		end
	end
end
function BaleWrapper.onReadStream(p153, p154, p155)
	if p155:getIsServer() then
		local v156 = p153.spec_baleWrapper
		p153:setBaleWrapperType(streamReadBool(p154), (streamReadUIntN(p154, 8)))
		local v157 = streamReadUIntN(p154, BaleWrapper.STATE_NUM_BITS)
		if BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER <= v157 then
			local v158
			if v157 == BaleWrapper.STATE_WRAPPER_RESETTING_PLATFORM then
				v158 = nil
			else
				v158 = NetworkUtil.readNodeObjectId(p154)
			end
			if v157 == BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER then
				p153:doStateChange(BaleWrapper.CHANGE_GRAB_BALE, v158)
				AnimatedVehicle.updateAnimations(p153, 99999999, true)
				return
			end
			if v157 == BaleWrapper.STATE_MOVING_GRABBER_TO_WORK then
				p153.baleGrabber.currentBale = v158
				p153:doStateChange(BaleWrapper.CHANGE_DROP_BALE_AT_GRABBER)
				AnimatedVehicle.updateAnimations(p153, 99999999, true)
				return
			end
			if v157 == BaleWrapper.STATE_WRAPPER_RESETTING_PLATFORM then
				v156.baleWrapperState = BaleWrapper.STATE_WRAPPER_RESETTING_PLATFORM
			else
				p153:doStateChange(BaleWrapper.CHANGE_GRAB_BALE, v158)
				AnimatedVehicle.updateAnimations(p153, 99999999, true)
				v156.currentWrapper.currentBale = v158
				p153:doStateChange(BaleWrapper.CHANGE_DROP_BALE_AT_GRABBER)
				AnimatedVehicle.updateAnimations(p153, 99999999, true)
				p153:updateWrapNodes(true, false, 0)
				if v157 == BaleWrapper.STATE_WRAPPER_WRAPPING_BALE then
					p153:doStateChange(BaleWrapper.CHANGE_WRAPPING_START)
					local v159 = streamReadFloat32(p154)
					v156.currentWrapper.currentTime = v159
					local v160 = v156.currentWrapper.animations.wrapBale
					local v161 = v156.currentWrapper.currentTime / v156.currentWrapper.animTime
					p153:setAnimationStopTime(v160.animName, v161)
					AnimatedVehicle.updateAnimationByName(p153, v160.animName, 9999999, true)
					p153:updateWrappingState(v161, true)
					if v161 < 1 then
						p153:playAnimation(v160.animName, v160.animSpeed, p153:getAnimationTime(v160.animName), true, false)
						return
					end
				else
					local v162 = v156.currentWrapper.animations.wrapBale
					if v162.animName ~= nil then
						p153:playAnimation(v162.animName, v162.animSpeed, nil, true)
						AnimatedVehicle.updateAnimationByName(p153, v162.animName, 9999999, true)
					end
					v156.currentWrapper.currentTime = v156.currentWrapper.animTime
					p153:updateWrappingState(1, true)
					p153:doStateChange(BaleWrapper.CHANGE_WRAPPING_BALE_FINSIHED)
					AnimatedVehicle.updateAnimations(p153, 99999999, true)
					if BaleWrapper.STATE_WRAPPER_DROPPING_BALE <= v157 then
						p153:doStateChange(BaleWrapper.CHANGE_WRAPPER_START_DROP_BALE)
						AnimatedVehicle.updateAnimations(p153, 99999999, true)
						return
					end
				end
			end
		end
	end
end
function BaleWrapper.onWriteStream(p163, p164, p165)
	if not p165:getIsServer() then
		local v166 = p163.spec_baleWrapper
		streamWriteBool(p164, v166.currentWrapper == v166.roundBaleWrapper)
		streamWriteUIntN(p164, v166.currentBaleTypeIndex, 8)
		local v167 = v166.baleWrapperState
		streamWriteUIntN(p164, v167, BaleWrapper.STATE_NUM_BITS)
		if BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER <= v167 and v167 ~= BaleWrapper.STATE_WRAPPER_RESETTING_PLATFORM then
			if v167 == BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER then
				NetworkUtil.writeNodeObjectId(p164, v166.baleGrabber.currentBale)
			else
				NetworkUtil.writeNodeObjectId(p164, v166.currentWrapper.currentBale)
			end
		end
		if v167 == BaleWrapper.STATE_WRAPPER_WRAPPING_BALE then
			streamWriteFloat32(p164, v166.currentWrapper.currentTime)
		end
	end
end
function BaleWrapper.onUpdate(p168, p169, _, _, _)
	local v170 = p168.spec_baleWrapper
	if v170.baleToMount ~= nil then
		local v171 = NetworkUtil.getObject(v170.baleToMount.serverId)
		if v171 ~= nil then
			local v172 = v170.baleToMount.trans
			local v173, v174, v175 = unpack(v172)
			local v176 = v170.baleToMount.rot
			local v177, v178, v179 = unpack(v176)
			v171:mountKinematic(p168, v170.baleToMount.linkNode, v173, v174, v175, v177, v178, v179)
			v171:setCanBeSold(false)
			v171:setNeedsSaving(false)
			v170.baleToMount = nil
			if v170.baleWrapperState == BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER then
				p168:playMoveToWrapper(v171)
			end
		end
	end
	if v170.baleWrapperState == BaleWrapper.STATE_WRAPPER_WRAPPING_BALE then
		local v180 = v170.currentWrapper
		local v181 = v180.allowedBaleTypes[v170.currentBaleTypeIndex]
		p168:updateConsumable(BaleWrapper.CONSUMABLE_TYPE_NAME, -v181.wrapUsage * p169, true)
		local v182 = v180.currentTime + p169
		local v183 = v170.currentWrapper.animTime
		v180.currentTime = math.min(v182, v183)
		local v184 = v180.currentTime / v180.animTime
		p168:updateWrappingState(v184)
		p168:raiseActive()
		if p168.isClient then
			if v180.wrappingSoundEndTime <= v184 then
				if g_soundManager:getIsSamplePlaying(v180.samples.wrap[1]) then
					g_soundManager:stopSamples(v180.samples.wrap)
					g_soundManager:playSamples(v180.samples.stop)
					return
				end
			elseif not g_soundManager:getIsSamplePlaying(v180.samples.wrap[1]) then
				g_soundManager:playSamples(v180.samples.wrap)
			end
		end
	end
end
function BaleWrapper.onUpdateTick(p185, _, _, _, _)
	local v186 = p185.spec_baleWrapper
	v186.showInvalidBaleWarning = false
	v186.baleDropBlockedWarning = nil
	if p185:allowsGrabbingBale() and (v186.baleGrabber.grabNode ~= nil and v186.baleGrabber.currentBale == nil) then
		local v187, v188, v189 = BaleWrapper.getBaleInRange(p185, v186.baleGrabber.grabNode, v186.baleGrabber.nearestDistance)
		if v188 then
			if v187 == nil and not (v188.isRoundbale and v186.roundBaleWrapper.skipUnsupportedBales) and not v186.squareBaleWrapper.skipUnsupportedBales then
				if p185.isClient and (v188 and v186.lastDroppedBale ~= v188) then
					v186.showInvalidBaleWarning = true
				end
			elseif p185.isServer then
				p185:pickupWrapperBale(v187 or v188, v189)
			end
		end
	end
	if p185.isServer and v186.baleWrapperState ~= BaleWrapper.STATE_NONE then
		if v186.baleWrapperState == BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER then
			if not p185:getIsAnimationPlaying(v186.currentWrapper.animations.moveToWrapper.animName) then
				g_server:broadcastEvent(BaleWrapperStateEvent.new(p185, BaleWrapper.CHANGE_DROP_BALE_AT_GRABBER), true, nil, p185)
			end
		elseif v186.baleWrapperState == BaleWrapper.STATE_MOVING_GRABBER_TO_WORK then
			if not p185:getIsAnimationPlaying(v186.currentWrapper.animations.moveToWrapper.animName) then
				local v190 = NetworkUtil.getObject(v186.currentWrapper.currentBale)
				if v190 == nil or v190.supportsWrapping then
					if p185:getIsBaleWrappingAllowed() then
						g_server:broadcastEvent(BaleWrapperStateEvent.new(p185, BaleWrapper.CHANGE_WRAPPING_START), true, nil, p185)
					end
				else
					g_server:broadcastEvent(BaleWrapperStateEvent.new(p185, BaleWrapper.CHANGE_WRAPPER_START_DROP_BALE), true, nil, p185)
				end
			end
		elseif v186.baleWrapperState == BaleWrapper.STATE_WRAPPER_DROPPING_BALE then
			if not p185:getIsAnimationPlaying(v186.currentWrapper.animations.dropFromWrapper.animName) then
				g_server:broadcastEvent(BaleWrapperStateEvent.new(p185, BaleWrapper.CHANGE_WRAPPER_BALE_DROPPED), true, nil, p185)
			end
		elseif v186.baleWrapperState == BaleWrapper.STATE_WRAPPER_RESETTING_PLATFORM and not p185:getIsAnimationPlaying(v186.currentWrapper.animations.resetAfterDrop.animName) then
			g_server:broadcastEvent(BaleWrapperStateEvent.new(p185, BaleWrapper.CHANGE_WRAPPER_PLATFORM_RESET), true, nil, p185)
		end
	end
	if v186.automaticDrop or p185:getIsAIActive() then
		local v191, _ = p185:getIsPowered()
		if v191 and v186.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED then
			local v192, v193 = p185:getIsBaleDropAllowed()
			if v192 then
				if p185.isServer then
					p185:doStateChange(BaleWrapper.CHANGE_BUTTON_EMPTY)
				end
			elseif v193 ~= nil then
				v186.baleDropBlockedWarning = v193
			end
		end
	end
	BaleWrapper.updateActionEvents(p185)
	if v186.setWrappingStateFinished then
		g_server:broadcastEvent(BaleWrapperStateEvent.new(p185, BaleWrapper.CHANGE_WRAPPING_BALE_FINSIHED), true, nil, p185)
		v186.setWrappingStateFinished = false
	end
end
function BaleWrapper.onDraw(p194, _, _, _)
	if p194.isClient then
		local v195 = p194.spec_baleWrapper
		if v195.showInvalidBaleWarning then
			g_currentMission:showBlinkingWarning(v195.texts.warningBaleNotSupported, 500)
			return
		end
		if v195.baleDropBlockedWarning ~= nil then
			g_currentMission:showBlinkingWarning(v195.baleDropBlockedWarning, 500)
		end
	end
end
function BaleWrapper.baleGrabberTriggerCallback(p196, _, p197, p198, p199, _, _)
	if p197 ~= 0 and getRigidBodyType(p197) == RigidBodyType.DYNAMIC then
		local v200 = g_currentMission:getNodeObject(p197)
		if v200 ~= nil and v200:isa(Bale) then
			local v201 = p196.spec_baleWrapper
			if p198 then
				v201.baleGrabber.balesInTrigger[v200] = Utils.getNoNil(v201.baleGrabber.balesInTrigger[v200], 0) + 1
				return
			end
			if p199 and v201.baleGrabber.balesInTrigger[v200] ~= nil then
				local v202 = v201.baleGrabber.balesInTrigger
				local v203 = v201.baleGrabber.balesInTrigger[v200] - 1
				v202[v200] = math.max(0, v203)
				if v201.baleGrabber.balesInTrigger[v200] == 0 then
					v201.baleGrabber.balesInTrigger[v200] = nil
				end
			end
		end
	end
end
function BaleWrapper.allowsGrabbingBale(p204)
	local v205 = p204.spec_baleWrapper
	local v206 = p204.spec_foldable
	if v206 == nil or (v206.foldAnimTime == nil or v206.foldAnimTime <= v205.currentWrapperFoldMaxLimit and v206.foldAnimTime >= v205.currentWrapperFoldMinLimit) then
		if v205.baleToLoad == nil then
			return v205.baleWrapperState == BaleWrapper.STATE_NONE
		else
			return false
		end
	else
		return false
	end
end
function BaleWrapper.updateWrapNodes(p207, p208, p209, p210, p211)
	local v212 = p207.spec_baleWrapper
	local v213 = p211 == nil and 0 or p211
	for _, v214 in pairs(v212.currentWrapper.wrapNodes) do
		local v215 = v214.maxWrapperRot == nil and true or v213 < v214.maxWrapperRot
		local v216 = setVisibility
		local v217 = v214.nodeId
		local v218 = not v215 or p208 and v214.wrapVisibility
		if not v218 then
			if p209 then
				v218 = v214.emptyVisibility
			else
				v218 = p209
			end
		end
		v216(v217, v218)
	end
	if p208 then
		local v219 = math.sign(v213) * (v213 % 3.141592653589793)
		if v219 < 0 then
			v219 = v219 + 3.141592653589793
		end
		for _, v220 in pairs(v212.currentWrapper.wrapAnimNodes) do
			local v221, v222, v223, v224, v225, v226, v227, v228, v229
			if v220.useWrapperRot then
				local v230
				if v220.repeatWrapperRot then
					v230 = v219
				else
					v230 = v213
				end
				v221, v222, v223, v224, v225, v226, v227, v228, v229 = v220.animCurve:get(v230)
			else
				v221, v222, v223, v224, v225, v226, v227, v228, v229 = v220.animCurve:get(p210)
			end
			if v221 ~= nil then
				setTranslation(v220.nodeId, v221, v222, v223)
				setRotation(v220.nodeId, v224, v225, v226)
				setScale(v220.nodeId, v227, v228, v229)
			end
		end
	elseif not p209 then
		for _, v231 in pairs(v212.currentWrapper.wrapAnimNodes) do
			if v231.normalizeRotationOnBaleDrop ~= 0 then
				local v232 = { getRotation(v231.nodeId) }
				for v233 = 1, 3 do
					local v234 = v231.normalizeRotationOnBaleDrop
					local v235 = v232[v233]
					v232[v233] = v234 * math.sign(v235) * (v232[v233] % 6.283185307179586)
				end
				setRotation(v231.nodeId, v232[1], v232[2], v232[3])
			end
		end
	end
end
function BaleWrapper.updateWrappingState(p236, p237, p238)
	local v239 = p236.spec_baleWrapper
	local v240 = v239.currentWrapper
	local v241
	if v240.wrappingFoilAnimation == nil then
		v241 = 0
	else
		local v242 = v240.wrappingFoilAnimation
		local v243 = v242.referenceNodeRotation
		local v244 = v242.referenceNodeRotation
		local v245 = v242.referenceNodeRotation
		local v246, v247, v248 = getRotation(v242.referenceNode)
		v243[1] = v246
		v244[2] = v247
		v245[3] = v248
		v241 = (v242.referenceNodeRotation[v242.referenceAxis] - v242.referenceMinRot) / (v242.referenceMaxRot - v242.referenceMinRot)
		if v241 > 0 and (v241 < 1 and v241 ~= v242.lastTime) then
			if getAnimTrackAssignedClip(v242.animationCharSet, 0) ~= v242.animationClipIndex then
				clearAnimTrackClip(v242.animationCharSet, 0)
				assignAnimTrackClip(v242.animationCharSet, 0, v242.animationClipIndex)
			end
			enableAnimTrack(v242.animationCharSet, 0)
			setAnimTrackTime(v242.animationCharSet, 0, v241 * v242.animationClipDuration, true)
			disableAnimTrack(v242.animationCharSet, 0)
			v242.lastTime = v241
		end
	end
	local v249
	if v240.wrappingAnimationNodes.referenceNode == nil then
		v249 = 0
	else
		local v250 = v240.wrappingAnimationNodes.referenceNodeRotation
		local v251 = v240.wrappingAnimationNodes.referenceNodeRotation
		local v252 = v240.wrappingAnimationNodes.referenceNodeRotation
		local v253, v254, v255 = getRotation(v240.wrappingAnimationNodes.referenceNode)
		v250[1] = v253
		v251[2] = v254
		v252[3] = v255
		local v256 = (v240.wrappingAnimationNodes.referenceNodeRotation[v240.wrappingAnimationNodes.referenceAxis] - v240.wrappingAnimationNodes.referenceMinRot) / (v240.wrappingAnimationNodes.referenceMaxRot - v240.wrappingAnimationNodes.referenceMinRot)
		local v257 = math.clamp(v256, 0, 1)
		v249 = MathUtil.round(v257, 5)
	end
	if v240.wrappingAnimationNodes.lastTime < v249 then
		local v258 = v240.wrappingAnimationNodes.nodes
		for v259 = v240.wrappingAnimationNodes.currentIndex + 1, #v258 do
			local v260 = v258[v259]
			if v260.time > v249 then
				break
			end
			if v260.linkNode == nil then
				if getParent(v260.nodeId) ~= v260.parent then
					link(v260.parent, v260.nodeId)
				end
				local v261 = setTranslation
				local v262 = v260.nodeId
				local v263 = v260.translation
				v261(v262, unpack(v263))
			else
				local v264 = localToWorld
				local v265 = v260.parent
				local v266 = v260.translation
				local v267, v268, v269 = v264(v265, unpack(v266))
				if getParent(v260.nodeId) ~= v260.linkNode then
					link(v260.linkNode, v260.nodeId)
				end
				setWorldTranslation(v260.nodeId, v267, v268, v269)
			end
			v240.wrappingAnimationNodes.currentIndex = v259
		end
	elseif v249 < v240.wrappingAnimationNodes.lastTime then
		v240.wrappingAnimationNodes.currentIndex = 0
	end
	v240.wrappingAnimationNodes.lastTime = v249
	for v270, v271 in pairs(v240.wrappingAnimationNodes.nodeToRootNode) do
		local v272, v273, v274 = localRotationToLocal(v271, getParent(v270), 0, 0, 0)
		setRotation(v270, v272, v273, v274)
	end
	local v275 = math.min(p237, 1)
	local v276 = 0
	if v240.animCurve ~= nil then
		local v277, v278, v279, v280, v281, v282 = v240.animCurve:get(p237)
		if v277 == nil then
			if v240.animations.wrapBale.animName ~= nil then
				p237 = p236:getAnimationTime(v240.animations.wrapBale.animName)
			end
		else
			setRotation(v240.baleNode, v277 % 6.283185307179586, v278 % 6.283185307179586, v279 % 6.283185307179586)
			setRotation(v240.wrapperNode, v280 % 6.283185307179586, v281 % 6.283185307179586, v282 % 6.283185307179586)
			v276 = v[3 + v240.wrapperRotAxis]
		end
		if v240.wrappingAnimationNodes.referenceNode == nil then
			v249 = v275
		end
		if v240.wrappingFoilAnimation == nil then
			v241 = v249
		end
		if v240.currentBale ~= nil then
			local v283 = NetworkUtil.getObject(v240.currentBale)
			if v283 ~= nil then
				local v284 = v239.currentWrapper.allowedBaleTypes[v239.currentBaleTypeIndex]
				if v283:getSupportsWrapping() and (not v284.skipWrapping and v283.wrappingState < 1) then
					local v285 = v284.wrappingStateCurve or v240.wrappingStateCurve
					if v285 ~= nil then
						v241 = v285:get(v241)
					end
					v283:setWrappingState(v241, true)
					if v283.setColor ~= nil then
						v283:setColor(v239.wrapColor[1], v239.wrapColor[2], v239.wrapColor[3])
					end
				end
			end
		end
	end
	p236:updateWrapNodes(p237 > 0, false, p237, v276)
	if p237 > 0.99999 and (p236.isServer and (v239.baleWrapperState == BaleWrapper.STATE_WRAPPER_WRAPPING_BALE and not p238)) then
		g_server:broadcastEvent(BaleWrapperStateEvent.new(p236, BaleWrapper.CHANGE_WRAPPING_BALE_FINSIHED), true, nil, p236)
	end
end
function BaleWrapper.playMoveToWrapper(p286, p287)
	local v288 = p286.spec_baleWrapper
	local v289 = p286:getMatchingBaleTypeIndex(p287.isRoundbale and v288.roundBaleWrapper.allowedBaleTypes or v288.squareBaleWrapper.allowedBaleTypes, p287)
	p286:setBaleWrapperType(p287.isRoundbale, v289)
	if v288.currentWrapper.animations.moveToWrapper.animName ~= nil then
		p286:playAnimation(v288.currentWrapper.animations.moveToWrapper.animName, v288.currentWrapper.animations.moveToWrapper.animSpeed, nil, true)
	end
end
function BaleWrapper.setBaleWrapperType(p290, p291, p292)
	local v293 = p290.spec_baleWrapper
	v293.currentWrapper = p291 and v293.roundBaleWrapper or v293.squareBaleWrapper
	v293.currentBaleTypeIndex = p292
	local v294 = v293.currentWrapper.allowedBaleTypes[p292]
	if v294 ~= nil then
		v293.currentWrapper.animations = v294.animations
		v293.currentWrapper.wrappingFoilAnimation = v294.wrappingFoilAnimation or v293.currentWrapper.wrappingFoilAnimationDefault
		ObjectChangeUtil.setObjectChanges(v294.changeObjects, true, p290, p290.setMovingToolDirty)
		if v293.currentWrapper.wrappingFoilAnimation ~= nil then
			local v295 = v293.currentWrapper.wrappingFoilAnimation
			clearAnimTrackClip(v295.animationCharSet, 0)
			assignAnimTrackClip(v295.animationCharSet, 0, v295.animationClipIndex)
			enableAnimTrack(v295.animationCharSet, 0)
			setAnimTrackTime(v295.animationCharSet, 0, 0, true)
			disableAnimTrack(v295.animationCharSet, 0)
		end
	end
	p290:requestActionEventUpdate()
end
function BaleWrapper.getMatchingBaleTypeIndex(_, p296, p297)
	for v298, v299 in ipairs(p296) do
		if p297:getBaleMatchesSize(v299.diameter, v299.width, v299.height, v299.length) then
			return v298
		end
	end
	return 1
end
function BaleWrapper.doStateChange(p300, p301, p302)
	local v303 = p300.spec_baleWrapper
	if p301 == BaleWrapper.CHANGE_WRAPPING_START or v303.baleWrapperState ~= BaleWrapper.STATE_WRAPPER_FINSIHED and p301 == BaleWrapper.CHANGE_WRAPPER_START_DROP_BALE then
		local v304 = NetworkUtil.getObject(v303.currentWrapper.currentBale)
		local v305 = v303.currentWrapper.allowedBaleTypes[v303.currentBaleTypeIndex]
		if not v304:getSupportsWrapping() or (v305.skipWrapping or v304.wrappingState == 1) then
			if p300.isServer then
				v303.setWrappingStateFinished = true
			end
			return
		end
	end
	if p301 == BaleWrapper.CHANGE_GRAB_BALE then
		local v306 = NetworkUtil.getObject(p302)
		v303.baleGrabber.currentBale = p302
		if v306 == nil then
			v303.baleToMount = {
				["serverId"] = p302,
				["linkNode"] = v303.baleGrabber.grabNode,
				["trans"] = { 0, 0, 0 },
				["rot"] = { 0, 0, 0 }
			}
		else
			local v307, v308, v309 = localToLocal(v306.nodeId, getParent(v303.baleGrabber.grabNode), 0, 0, 0)
			setTranslation(v303.baleGrabber.grabNode, v307, v308, v309)
			v306:mountKinematic(p300, v303.baleGrabber.grabNode, 0, 0, 0, 0, 0, 0)
			v306:setCanBeSold(false)
			v306:setNeedsSaving(false)
			v303.baleToMount = nil
			p300:playMoveToWrapper(v306)
		end
		v303.baleWrapperState = BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER
	elseif p301 == BaleWrapper.CHANGE_DROP_BALE_AT_GRABBER then
		local v310 = v303.currentWrapper.baleNode
		local v311 = NetworkUtil.getObject(v303.baleGrabber.currentBale)
		if v311 == nil then
			v303.baleToMount = {
				["serverId"] = v303.baleGrabber.currentBale,
				["linkNode"] = v310,
				["trans"] = { 0, 0, 0 },
				["rot"] = { 0, 0, 0 }
			}
		else
			v311:mountKinematic(p300, v310, 0, 0, 0, 0, 0, 0)
			v311:setCanBeSold(false)
			v311:setNeedsSaving(false)
			v303.baleToMount = nil
		end
		p300:updateWrapNodes(true, false, 0)
		v303.currentWrapper.currentBale = v303.baleGrabber.currentBale
		v303.baleGrabber.currentBale = nil
		if v303.currentWrapper.animations.moveToWrapper.animName ~= nil and v303.currentWrapper.animations.moveToWrapper.reverseAfterMove then
			p300:playAnimation(v303.currentWrapper.animations.moveToWrapper.animName, -v303.currentWrapper.animations.moveToWrapper.animSpeed, nil, true)
		end
		v303.baleWrapperState = BaleWrapper.STATE_MOVING_GRABBER_TO_WORK
	elseif p301 == BaleWrapper.CHANGE_WRAPPING_START then
		v303.baleWrapperState = BaleWrapper.STATE_WRAPPER_WRAPPING_BALE
		if p300.isClient then
			g_soundManager:playSamples(v303.currentWrapper.samples.start)
			g_soundManager:playSamples(v303.currentWrapper.samples.wrap, 0, v303.currentWrapper.samples.start[1])
		end
		if v303.currentWrapper.animations.wrapBale.animName ~= nil then
			p300:playAnimation(v303.currentWrapper.animations.wrapBale.animName, v303.currentWrapper.animations.wrapBale.animSpeed, nil, true)
		end
	elseif p301 == BaleWrapper.CHANGE_WRAPPING_BALE_FINSIHED then
		if p300.isClient then
			g_soundManager:stopSamples(v303.currentWrapper.samples.wrap)
			g_soundManager:stopSamples(v303.currentWrapper.samples.stop)
			if v303.currentWrapper.wrappingSoundEndTime == 1 then
				g_soundManager:playSamples(v303.currentWrapper.samples.stop)
			end
			g_soundManager:stopSamples(v303.currentWrapper.samples.start)
		end
		p300:updateWrappingState(1, true)
		v303.baleWrapperState = BaleWrapper.STATE_WRAPPER_FINSIHED
		local v312 = NetworkUtil.getObject(v303.currentWrapper.currentBale)
		local v313 = v303.currentWrapper.allowedBaleTypes[v303.currentBaleTypeIndex]
		local v314 = not v312:getSupportsWrapping() or v313.skipWrapping
		if v314 or v312.wrappingState == 1 then
			p300:updateWrappingState(0, true)
		end
		if not v314 then
			local v315 = v303.currentWrapper.animations.resetWrapping
			if v315.animName ~= nil then
				p300:playAnimation(v315.animName, v315.animSpeed, nil, true)
			end
		end
		p300:updateConsumable(BaleWrapper.CONSUMABLE_TYPE_NAME, 0)
	elseif p301 == BaleWrapper.CHANGE_WRAPPER_START_DROP_BALE then
		p300:updateWrapNodes(false, false, 0)
		local v316 = v303.currentWrapper.allowedBaleTypes[v303.currentBaleTypeIndex].dropAnimations[v303.dropAnimationIndex]
		if v316 ~= nil then
			v303.currentWrapper.animations.dropFromWrapper.animName = v316.name
			v303.currentWrapper.animations.dropFromWrapper.animSpeed = v316.animSpeed
			if p300.isServer and (v316.liftOnDrop and p300:getIsLowered()) then
				local v317 = p300:getAttacherVehicle()
				if v317 ~= nil then
					v317:handleLowerImplementEvent(p300)
				end
			end
		end
		if v303.currentWrapper.animations.dropFromWrapper.animName ~= nil then
			p300:playAnimation(v303.currentWrapper.animations.dropFromWrapper.animName, v303.currentWrapper.animations.dropFromWrapper.animSpeed, nil, true)
		end
		v303.dropAnimationIndex = 1
		v303.baleWrapperState = BaleWrapper.STATE_WRAPPER_DROPPING_BALE
	elseif p301 == BaleWrapper.CHANGE_WRAPPER_BALE_DROPPED then
		local v318 = NetworkUtil.getObject(v303.currentWrapper.currentBale)
		if v318 ~= nil then
			v318:unmountKinematic()
			v318:setNeedsSaving(true)
			v318:setCanBeSold(true)
			local v319 = v303.currentWrapper.allowedBaleTypes[v303.currentBaleTypeIndex]
			if v318:getSupportsWrapping() and not v319.skipWrapping then
				local v320, _ = g_farmManager:updateFarmStats(p300:getOwnerFarmId(), "wrappedBales", 1)
				if v320 ~= nil then
					g_achievementManager:tryUnlock("WrappedBales", v320)
				end
				if v318.wrappingState < 1 then
					v318:setWrappingState(1)
				end
			end
		end
		v303.lastDroppedBale = v318
		v303.currentWrapper.currentBale = nil
		v303.currentWrapper.currentTime = 0
		if v303.currentWrapper.animations.resetAfterDrop.animName ~= nil then
			local v321 = v303.currentWrapper.animations.dropFromWrapper.animName
			if p300:getIsAnimationPlaying(v321) then
				p300:stopAnimation(v321, true)
				p300:setAnimationTime(v321, 1, true, false)
			end
			p300:playAnimation(v303.currentWrapper.animations.resetAfterDrop.animName, v303.currentWrapper.animations.resetAfterDrop.animSpeed, nil, true)
		end
		p300:setBaleWrapperType(v303.currentWrapper == v303.roundBaleWrapper, v303.currentBaleTypeIndex)
		v303.baleWrapperState = BaleWrapper.STATE_WRAPPER_RESETTING_PLATFORM
	elseif p301 == BaleWrapper.CHANGE_WRAPPER_PLATFORM_RESET then
		p300:updateWrappingState(0)
		p300:updateWrapNodes(false, true, 0)
		v303.baleWrapperState = BaleWrapper.STATE_NONE
	elseif p301 == BaleWrapper.CHANGE_BUTTON_EMPTY then
		local v322 = p300.isServer
		assert(v322)
		if v303.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED then
			g_server:broadcastEvent(BaleWrapperStateEvent.new(p300, BaleWrapper.CHANGE_WRAPPER_START_DROP_BALE), true, nil, p300)
		end
	end
	BaleWrapper.updateActionEvents(p300)
end
function BaleWrapper.getIsBaleWrappable(p323, p324)
	local v325 = p323.spec_baleWrapper
	local v326 = false
	local v327 = p324.isRoundbale and v325.roundBaleWrapper.allowedBaleTypes or v325.squareBaleWrapper.allowedBaleTypes
	if v327 ~= nil then
		for v328, v329 in ipairs(v327) do
			if p324:getBaleMatchesSize(v329.diameter, v329.width, v329.height, v329.length) then
				v326 = true
				if not v329.skipWrapping and (p324:getSupportsWrapping() and p324.wrappingState < 1) then
					return true, v326, v328
				end
			end
		end
	end
	return false, v326
end
function BaleWrapper.getIsBaleDropAllowed(p330)
	local v331 = p330.spec_baleWrapper
	local v332 = v331.currentWrapper
	if v332.dropArea.node ~= nil then
		local v333, v334, v335 = getWorldTranslation(v332.dropArea.node)
		local v336, v337, v338 = getWorldRotation(v332.dropArea.node)
		local v339 = v332.dropArea.width * 0.5
		local v340 = v332.dropArea.height * 0.5
		local v341 = v332.dropArea.length * 0.5
		v331.foundDropOverlappingObject = false
		overlapBox(v333, v334, v335, v336, v337, v338, v339, v340, v341, "onBaleWrapperDropOverlapCallback", p330, BaleWrapper.DROP_COLLISION_MASK, true, true, false, true)
		if v331.foundDropOverlappingObject then
			return false, v331.texts.warningDropAreaBlocked
		end
	end
	return true, nil
end
function BaleWrapper.onBaleWrapperDropOverlapCallback(p342, p343)
	local v344 = g_currentMission:getNodeObject(p343)
	if v344 ~= nil and v344 ~= p342 then
		local v345 = p342.spec_baleWrapper
		local v346 = v345.currentWrapper
		if v346.currentBale ~= nil and v344 == NetworkUtil.getObject(v346.currentBale) then
			return
		end
		v345.foundDropOverlappingObject = true
		v345.foundDropOverlappingObjectTime = g_time
	end
end
function BaleWrapper.getIsBaleWrappingAllowed(p347)
	local v348 = p347.spec_baleWrapper
	local v349 = v348.currentWrapper
	if v349.blockWrapArea.node ~= nil then
		local v350, v351, v352 = getWorldTranslation(v349.blockWrapArea.node)
		local v353, v354, v355 = getWorldRotation(v349.blockWrapArea.node)
		local v356 = v349.blockWrapArea.width * 0.5
		local v357 = v349.blockWrapArea.height * 0.5
		local v358 = v349.blockWrapArea.length * 0.5
		v348.foundBlockOverlappingObject = false
		overlapBox(v350, v351, v352, v353, v354, v355, v356, v357, v358, "onBaleWrapperBlockOverlapCallback", p347, BaleWrapper.BLOCK_COLLISION_MASK, true, true, false, true)
		if v348.foundBlockOverlappingObject then
			return false
		end
	end
	return p347:getConsumableIsAvailable(BaleWrapper.CONSUMABLE_TYPE_NAME)
end
function BaleWrapper.onBaleWrapperBlockOverlapCallback(p359, p360)
	local v361 = g_currentMission:getNodeObject(p360)
	if v361 ~= nil and v361 ~= p359 then
		local v362 = p359.spec_baleWrapper
		local v363 = v362.currentWrapper
		if v363.currentBale ~= nil and v361 == NetworkUtil.getObject(v363.currentBale) then
			return
		end
		v362.foundBlockOverlappingObject = true
	end
end
function BaleWrapper.pickupWrapperBale(p364, p365, p366)
	local v367 = p364.spec_baleWrapper
	if p365:getSupportsWrapping() then
		local v368 = p365.isRoundbale and v367.roundBaleWrapper.allowedBaleTypes or v367.squareBaleWrapper.allowedBaleTypes
		if v368 ~= nil and p366 ~= nil then
			local v369 = v368[p366]
			if v369 ~= nil and (not v369.skipWrapping and (p365.wrappingState < 1 and (v369.wrapDiffuse ~= nil or v369.wrapNormal ~= nil))) then
				p365:setWrapTextures(v369.wrapDiffuse, v369.wrapNormal)
			end
		end
	end
	v367.baleGrabber.balesInTrigger[p365] = nil
	g_server:broadcastEvent(BaleWrapperStateEvent.new(p364, BaleWrapper.CHANGE_GRAB_BALE, NetworkUtil.getObjectId(p365)), true, nil, p364)
end
function BaleWrapper.getBaleInRange(p370, p371, p372)
	local v373 = p370.spec_baleWrapper
	local v374 = p372
	local v375 = nil
	local v376 = nil
	local v377 = nil
	for v378, _ in pairs(v373.baleGrabber.balesInTrigger) do
		if v378.dynamicMountType == MountableObject.MOUNT_TYPE_NONE and (v378.nodeId ~= 0 and calcDistanceFrom(p371, v378.nodeId) < p372) then
			local v379, v380, v381 = p370:getIsBaleWrappable(v378)
			if v379 and v380 then
				v377 = v381
				v376 = v378
				v375 = v376
				p372 = v374
				local v382 = v376
				v376 = v375
				v382 = v375
				v375 = v376
			else
				v376 = v378
				p372 = v374
			end
		end
	end
	return v375, v376, v377
end
function BaleWrapper.setBaleWrapperAutomaticDrop(p383, p384, p385)
	local v386 = p383.spec_baleWrapper
	if p384 == nil then
		p384 = not v386.automaticDrop
	end
	v386.automaticDrop = p384
	p383:requestActionEventUpdate()
	BaleWrapperAutomaticDropEvent.sendEvent(p383, p384, p385)
end
function BaleWrapper.setBaleWrapperDropAnimation(p387, p388)
	p387.spec_baleWrapper.dropAnimationIndex = p388
end
function BaleWrapper.getIsFoldAllowed(p389, p390, p391, p392)
	local v393 = p389.spec_baleWrapper
	if v393.baleWrapperState == BaleWrapper.STATE_NONE then
		return p390(p389, p391, p392)
	else
		return false, v393.texts.warningFoldingWrapping
	end
end
function BaleWrapper.getCanBeSelected(_, _)
	return true
end
function BaleWrapper.getShowConsumableEmptyWarning(p394, p395, p396)
	if p396 ~= BaleWrapper.CONSUMABLE_TYPE_NAME then
		return p395(p394, p396)
	end
	local v397
	if p394.spec_baleWrapper.baleWrapperState == BaleWrapper.STATE_NONE then
		v397 = false
	else
		v397 = p395(p394, p396)
	end
	return v397
end
function BaleWrapper.addToPhysics(p398, p399)
	if not p399(p398) then
		return false
	end
	local v400 = p398.spec_baleWrapper
	local v401 = NetworkUtil.getObject(v400.baleGrabber.currentBale)
	if v401 ~= nil then
		v401:addToPhysics()
		v401:mountKinematic(p398, v400.baleGrabber.grabNode, 0, 0, 0, 0, 0, 0)
	end
	local v402 = v400.currentWrapper
	if v402.currentBale ~= nil then
		local v403 = NetworkUtil.getObject(v402.currentBale)
		if v403 ~= nil then
			v403:addToPhysics()
			v403:mountKinematic(p398, v400.currentWrapper.baleNode, 0, 0, 0, 0, 0, 0)
		end
	end
	return true
end
function BaleWrapper.removeFromPhysics(p404, p405)
	if not p405(p404) then
		return false
	end
	local v406 = p404.spec_baleWrapper.currentWrapper
	if v406.currentBale ~= nil then
		local v407 = NetworkUtil.getObject(v406.currentBale)
		if v407 ~= nil then
			v407:unmountKinematic()
			v407:removeFromPhysics()
		end
	end
	return true
end
function BaleWrapper.onRegisterActionEvents(p408, _, p409)
	if p408.isClient then
		local v410 = p408.spec_baleWrapper
		p408:clearActionEventsTable(v410.actionEvents)
		if p409 then
			if not v410.automaticDrop then
				local _, v411 = p408:addPoweredActionEvent(v410.actionEvents, InputAction.IMPLEMENT_EXTRA3, p408, BaleWrapper.actionEventEmpty, false, true, false, true, nil)
				g_inputBinding:setActionEventText(v411, v410.currentWrapper.unloadBaleText)
				g_inputBinding:setActionEventTextPriority(v411, GS_PRIO_HIGH)
				local v412 = v410.currentWrapper.allowedBaleTypes[v410.currentBaleTypeIndex]
				for v413 = 1, #v412.dropAnimations do
					local v414 = v412.dropAnimations[v413]
					if v414.inputAction ~= nil then
						local _, v415 = p408:addPoweredActionEvent(v410.actionEvents, v414.inputAction, p408, BaleWrapper.actionEventDrop, false, true, false, false, v413)
						g_inputBinding:setActionEventTextPriority(v415, GS_PRIO_HIGH)
						g_inputBinding:setActionEventText(v415, v414.text)
					end
				end
			end
			if v410.toggleableAutomaticDrop then
				local _, v416 = p408:addActionEvent(v410.actionEvents, InputAction.IMPLEMENT_EXTRA4, p408, BaleWrapper.actionEventToggleAutomaticDrop, false, true, false, true, nil)
				g_inputBinding:setActionEventText(v416, v410.automaticDrop and v410.toggleAutomaticDropTextNeg or v410.toggleAutomaticDropTextPos)
				g_inputBinding:setActionEventTextPriority(v416, GS_PRIO_HIGH)
			end
			BaleWrapper.updateActionEvents(p408)
		end
	end
end
function BaleWrapper.onRegisterExternalActionEvents(p417, p418, p419, _, _)
	local v420 = p417.spec_baleWrapper
	if p419 == "baleWrapperDrop" then
		p417:registerExternalActionEvent(p418, p419, BaleWrapper.externalActionEventUnloadRegister, BaleWrapper.externalActionEventUnloadUpdate)
	elseif p419 == "baleWrapperAutomaticDrop" then
		if v420.toggleableAutomaticDrop then
			p417:registerExternalActionEvent(p418, p419, BaleWrapper.externalActionEventAutomaticUnloadRegister, BaleWrapper.externalActionEventAutomaticUnloadUpdate)
			return
		end
	elseif p419 == "baleWrapperWarnings" then
		p417:registerExternalActionEvent(p418, p419, BaleWrapper.externalActionEventWarningsRegister, BaleWrapper.externalActionEventWarningsUpdate)
	end
end
function BaleWrapper.onDeactivate(p421)
	local v422 = p421.spec_baleWrapper
	v422.showInvalidBaleWarning = false
	if p421.isClient then
		g_soundManager:stopSamples(v422.currentWrapper.samples.wrap)
		g_soundManager:stopSamples(v422.currentWrapper.samples.start)
		g_soundManager:stopSamples(v422.currentWrapper.samples.stop)
	end
end
function BaleWrapper.onFoldStateChanged(p423, p424, _)
	local v425 = p423.spec_baleWrapper
	if v425.foldedBaleType ~= nil and p423.spec_foldable.turnOnFoldDirection ~= p424 then
		p423:setBaleWrapperType(v425.foldedBaleType.isRoundBaleWrapper, v425.foldedBaleType.baleTypeIndex)
	end
end
function BaleWrapper.onConsumableVariationChanged(p426, _, p427)
	if p427.color ~= nil then
		local v428 = p426.spec_baleWrapper
		v428.wrapColor[1] = p427.color[1]
		v428.wrapColor[2] = p427.color[2]
		v428.wrapColor[3] = p427.color[3]
	end
end
function BaleWrapper.actionEventEmpty(p429, _, _, _, _)
	if p429.spec_baleWrapper.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED then
		local v430, v431 = p429:getIsBaleDropAllowed()
		if v430 then
			g_client:getServerConnection():sendEvent(BaleWrapperStateEvent.new(p429, BaleWrapper.CHANGE_BUTTON_EMPTY))
			return
		end
		if v431 ~= nil then
			g_currentMission:showBlinkingWarning(v431, 2000)
		end
	end
end
function BaleWrapper.actionEventToggleAutomaticDrop(p432, _, _, _, _)
	p432:setBaleWrapperAutomaticDrop()
end
function BaleWrapper.actionEventDrop(p433, _, _, p434, _)
	if p433.spec_baleWrapper.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED then
		g_client:getServerConnection():sendEvent(BaleWrapperDropEvent.new(p433, p434))
	end
end
function BaleWrapper.updateActionEvents(p435)
	local v436 = p435.spec_baleWrapper
	local v437 = v436.actionEvents[InputAction.IMPLEMENT_EXTRA3]
	if v437 ~= nil then
		g_inputBinding:setActionEventActive(v437.actionEventId, v436.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED)
		g_inputBinding:setActionEventText(v437.actionEventId, v436.currentWrapper.unloadBaleText)
	end
	if v436.toggleableAutomaticDrop then
		local v438 = v436.actionEvents[InputAction.IMPLEMENT_EXTRA4]
		if v438 ~= nil then
			g_inputBinding:setActionEventText(v438.actionEventId, v436.automaticDrop and v436.toggleAutomaticDropTextNeg or v436.toggleAutomaticDropTextPos)
		end
	end
	local v439 = v436.currentWrapper.allowedBaleTypes[v436.currentBaleTypeIndex]
	for v440 = 1, #v439.dropAnimations do
		local v441 = v439.dropAnimations[v440]
		if v441.inputAction ~= nil then
			local v442 = v436.actionEvents[v441.inputAction]
			if v442 ~= nil then
				g_inputBinding:setActionEventActive(v442.actionEventId, v436.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED)
			end
		end
	end
end
function BaleWrapper.externalActionEventUnloadRegister(p443, p_u_444)
	local v_u_445 = p_u_444.spec_baleWrapper
	local _, v450 = g_inputBinding:registerActionEvent(InputAction.IMPLEMENT_EXTRA3, p443, function(_, p446, p447, p448, p449)
		-- upvalues: (copy) v_u_445, (copy) p_u_444
		if not v_u_445.automaticDrop then
			BaleWrapper.actionEventEmpty(p_u_444, p446, p447, p448, p449)
		end
	end, false, true, false, true)
	p443.actionEventId = v450
	g_inputBinding:setActionEventTextPriority(p443.actionEventId, GS_PRIO_HIGH)
	g_inputBinding:setActionEventText(p443.actionEventId, v_u_445.currentWrapper.unloadBaleText)
end
function BaleWrapper.externalActionEventUnloadUpdate(p451, p452)
	local v453 = p452.spec_baleWrapper
	g_inputBinding:setActionEventActive(p451.actionEventId, v453.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED)
end
function BaleWrapper.externalActionEventAutomaticUnloadRegister(p454, p_u_455)
	local _, v460 = g_inputBinding:registerActionEvent(InputAction.IMPLEMENT_EXTRA4, p454, function(_, p456, p457, p458, p459)
		-- upvalues: (copy) p_u_455
		BaleWrapper.actionEventToggleAutomaticDrop(p_u_455, p456, p457, p458, p459)
	end, false, true, false, true)
	p454.actionEventId = v460
	g_inputBinding:setActionEventTextPriority(p454.actionEventId, GS_PRIO_HIGH)
end
function BaleWrapper.externalActionEventAutomaticUnloadUpdate(p461, p462)
	local v463 = p462.spec_baleWrapper
	g_inputBinding:setActionEventText(p461.actionEventId, v463.automaticDrop and v463.toggleAutomaticDropTextNeg or v463.toggleAutomaticDropTextPos)
end
function BaleWrapper.externalActionEventWarningsRegister(_, _) end
function BaleWrapper.externalActionEventWarningsUpdate(_, p464)
	local v465 = p464.spec_baleWrapper
	if v465.automaticDrop then
		if g_time - v465.foundDropOverlappingObjectTime < 500 then
			g_currentMission:showBlinkingWarning(v465.texts.warningDropAreaBlocked, 500)
			return
		end
	elseif v465.showInvalidBaleWarning then
		g_currentMission:showBlinkingWarning(v465.texts.warningBaleNotSupported, 500)
	end
end
function BaleWrapper.loadSpecValueBaleSize(p_u_466, _, _, p467)
	local v_u_468 = {
		["minDiameter"] = (1 / 0),
		["maxDiameter"] = (-1 / 0),
		["minLength"] = (1 / 0),
		["maxLength"] = (-1 / 0)
	}
	p_u_466:iterate(p_u_466:getRootName() .. ".baleWrapper." .. (p467 and "roundBaleWrapper" or "squareBaleWrapper") .. ".baleTypes.baleType", function(_, p469)
		-- upvalues: (copy) p_u_466, (copy) v_u_468
		if not p_u_466:getValue(p469 .. "#skipWrapping", false) then
			local v470 = MathUtil.round(p_u_466:getValue(p469 .. "#diameter", 0), 2)
			local v471 = v_u_468
			local v472 = v_u_468.minDiameter
			v471.minDiameter = math.min(v472, v470)
			local v473 = v_u_468
			local v474 = v_u_468.maxDiameter
			v473.maxDiameter = math.max(v474, v470)
			local v475 = MathUtil.round(p_u_466:getValue(p469 .. "#length", 0), 2)
			local v476 = v_u_468
			local v477 = v_u_468.minLength
			v476.minLength = math.min(v477, v475)
			local v478 = v_u_468
			local v479 = v_u_468.maxLength
			v478.maxLength = math.max(v479, v475)
		end
	end)
	if v_u_468.minDiameter == (1 / 0) and v_u_468.minLength == (1 / 0) then
		return nil
	else
		return v_u_468
	end
end
function BaleWrapper.getSpecValueBaleSize(p480, _, _, _, p481, p482, p483)
	local v484 = p483 and p480.specs.baleWrapperBaleSizeRound or p480.specs.baleWrapperBaleSizeSquare
	if v484 == nil then
		if p481 and p482 then
			return 0, 0, ""
		elseif p481 then
			return 0, ""
		else
			return ""
		end
	else
		local v485 = p483 and v484.minDiameter or v484.minLength
		local v486 = p483 and v484.maxDiameter or v484.maxLength
		if p481 == nil or not p481 then
			local v487 = g_i18n:getText("unit_cmShort")
			if v486 == v485 then
				return string.format("%d%s", v485 * 100, v487)
			else
				return string.format("%d%s-%d%s", v485 * 100, v487, v486 * 100, v487)
			end
		elseif p482 == true and v486 ~= v485 then
			return v485 * 100, v486 * 100, g_i18n:getText("unit_cmShort")
		else
			return v485 * 100, g_i18n:getText("unit_cmShort")
		end
	end
end
function BaleWrapper.loadSpecValueBaleSizeRound(p488, p489, p490)
	return BaleWrapper.loadSpecValueBaleSize(p488, p489, p490, true)
end
function BaleWrapper.loadSpecValueBaleSizeSquare(p491, p492, p493)
	return BaleWrapper.loadSpecValueBaleSize(p491, p492, p493, false)
end
function BaleWrapper.getSpecValueBaleSizeRound(p494, p495, p496, p497, p498, p499)
	if p494.specs.baleWrapperBaleSizeRound == nil then
		return nil
	else
		return BaleWrapper.getSpecValueBaleSize(p494, p495, p496, p497, p498, p499, true)
	end
end
function BaleWrapper.getSpecValueBaleSizeSquare(p500, p501, p502, p503, p504, p505)
	if p500.specs.baleWrapperBaleSizeSquare == nil then
		return nil
	else
		return BaleWrapper.getSpecValueBaleSize(p500, p501, p502, p503, p504, p505, false)
	end
end

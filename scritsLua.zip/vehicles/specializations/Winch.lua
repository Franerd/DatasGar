Winch = {}
Winch.TREE_RAYCAST_DISTANCE = 5
Winch.CONTROL_RANGE = 12.5
source("dataS/scripts/vehicles/specializations/events/TreeAttachEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TreeAttachRequestEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TreeAttachResponseEvent.lua")
source("dataS/scripts/vehicles/specializations/events/TreeDetachEvent.lua")
source("dataS/scripts/vehicles/specializations/activatables/WinchAttachTreeActivatable.lua")
source("dataS/scripts/vehicles/specializations/activatables/WinchControlRopeActivatable.lua")
function Winch.prerequisitesPresent(_)
	return true
end
function Winch.initSpecialization()
	if g_iconGenerator == nil then
		g_vehicleConfigurationManager:addConfigurationType("winch", g_i18n:getText("configuration_winch"), "winch", VehicleConfigurationItem)
	end
	g_storeManager:addSpecType("winchMaxMass", "shopListAttributeIconWinchMaxMass", Winch.loadSpecValueMaxMass, Winch.getSpecValueMaxMass, StoreSpecies.VEHICLE)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Winch")
	Winch.registerXMLPaths(v1, "vehicle.winch")
	Winch.registerXMLPaths(v1, "vehicle.winch.winchConfigurations.winchConfiguration(?)")
	ObjectChangeUtil.registerObjectChangeXMLPaths(v1, "vehicle.winch.winchConfigurations.winchConfiguration(?)")
	v1:setXMLSpecializationType()
end
function Winch.registerXMLPaths(p2, p3)
	p2:register(XMLValueType.INT, p3 .. "#controlGroupIndex", "Winch controls are only active while this cylindered control group is used")
	p2:register(XMLValueType.INT, p3 .. ".rope(?)#maxNumTrees", "Max. number of trees that can be attached", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".rope(?)#maxTreeMass", "Max. tree mass that can be attached (to)", 1)
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".rope(?)#node", "Outgoing node for the rope")
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".rope(?)#triggerNode", "Trigger node to pickup the rope as player")
	p2:register(XMLValueType.FLOAT, p3 .. ".rope(?)#minLength", "Minimum length of the rope", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".rope(?)#maxLength", "Maximum length of the rope", 30)
	p2:register(XMLValueType.FLOAT, p3 .. ".rope(?)#maxSubLength", "Maximum length of the rope from tree to tree when attaching multiple trees to one rope", 2)
	p2:register(XMLValueType.FLOAT, p3 .. ".rope(?)#speed", "Speed when pulling the rope [m/sec]", 1.5)
	p2:register(XMLValueType.FLOAT, p3 .. ".rope(?)#acceleration", "Acceleration (time in seconds until full speed is reached)", 1.5)
	ForestryPhysicsRope.registerXMLPaths(p2, p3 .. ".rope(?).mainRope")
	ForestryPhysicsRope.registerXMLPaths(p2, p3 .. ".rope(?).setupRope")
	p2:register(XMLValueType.INT, p3 .. ".rope(?).componentJoint(?)#jointIndex", "Index of component joint")
	p2:register(XMLValueType.VECTOR_ROT, p3 .. ".rope(?).componentJoint(?)#limitActive", "Rotation limit of component joint while tree is attached")
	p2:register(XMLValueType.VECTOR_ROT, p3 .. ".rope(?).componentJoint(?)#limitInactive", "Rotation limit of component joint while no tree is attached")
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".rope(?).attach#node", "Outgoing node for tree attach rope (used for dummy rope display)")
	p2:register(XMLValueType.TIME, p3 .. ".rope(?).attach#time", "Time until the tree is fully attached", 0.5)
	TargetTreeMarker.registerXMLPaths(p2, p3 .. ".rope(?).attach.marker")
	ForestryHook.registerXMLPaths(p2, p3 .. ".rope(?).treeHook")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p2, p3 .. ".rope(?)")
	SoundManager.registerSampleXMLPaths(p2, p3 .. ".rope(?).sounds", "pullRope")
	SoundManager.registerSampleXMLPaths(p2, p3 .. ".rope(?).sounds", "releaseRope")
	SoundManager.registerSampleXMLPaths(p2, p3 .. ".rope(?).sounds", "attachTree")
	SoundManager.registerSampleXMLPaths(p2, p3 .. ".rope(?).sounds", "detachTree")
	AnimationManager.registerAnimationNodesXMLPaths(p2, p3 .. ".rope(?).animationNodes")
	p2:addDelayedRegistrationFunc("Cylindered:movingTool", function(p4, p5)
		p4:register(XMLValueType.VECTOR_N, p5 .. ".winch#ropeIndices", "List of rope indices which are update while moving part changes")
	end)
	p2:addDelayedRegistrationFunc("Cylindered:movingPart", function(p6, p7)
		p6:register(XMLValueType.VECTOR_N, p7 .. ".winch#ropeIndices", "List of rope indices which are update while moving part changes")
	end)
	local v8 = Vehicle.xmlSchemaSavegame
	v8:register(XMLValueType.INT, "vehicles.vehicle(?).winch.rope(?)#index", "Rope index")
	v8:register(XMLValueType.VECTOR_TRANS, "vehicles.vehicle(?).winch.rope(?).attachedTree(?)#translation", "Translation of attached tree")
	v8:register(XMLValueType.INT, "vehicles.vehicle(?).winch.rope(?).attachedTree(?)#splitShapePart1", "Split shape data part 1")
	v8:register(XMLValueType.INT, "vehicles.vehicle(?).winch.rope(?).attachedTree(?)#splitShapePart2", "Split shape data part 2")
	v8:register(XMLValueType.INT, "vehicles.vehicle(?).winch.rope(?).attachedTree(?)#splitShapePart3", "Split shape data part 3")
	ForestryPhysicsRope.registerSavegameXMLPaths(v8, "vehicles.vehicle(?).winch.rope(?).attachedTree(?).physicsRope")
end
function Winch.registerFunctions(p9)
	SpecializationUtil.registerFunction(p9, "loadWinchRopeFromXML", Winch.loadWinchRopeFromXML)
	SpecializationUtil.registerFunction(p9, "setWinchTreeAttachMode", Winch.setWinchTreeAttachMode)
	SpecializationUtil.registerFunction(p9, "getIsWinchAttachModeActive", Winch.getIsWinchAttachModeActive)
	SpecializationUtil.registerFunction(p9, "getCanAttachWinchTree", Winch.getCanAttachWinchTree)
	SpecializationUtil.registerFunction(p9, "onAttachTreeInputEvent", Winch.onAttachTreeInputEvent)
	SpecializationUtil.registerFunction(p9, "getWinchRopeSpeedFactor", Winch.getWinchRopeSpeedFactor)
	SpecializationUtil.registerFunction(p9, "getIsWinchTreeAttachAllowed", Winch.getIsWinchTreeAttachAllowed)
	SpecializationUtil.registerFunction(p9, "showWinchTreeMountFailedWarning", Winch.showWinchTreeMountFailedWarning)
	SpecializationUtil.registerFunction(p9, "attachTreeToWinch", Winch.attachTreeToWinch)
	SpecializationUtil.registerFunction(p9, "detachTreeFromWinch", Winch.detachTreeFromWinch)
	SpecializationUtil.registerFunction(p9, "setWinchControlInput", Winch.setWinchControlInput)
	SpecializationUtil.registerFunction(p9, "onWinchPlayerTriggerCallback", Winch.onWinchPlayerTriggerCallback)
	SpecializationUtil.registerFunction(p9, "onWinchTreeRaycastCallback", Winch.onWinchTreeRaycastCallback)
	SpecializationUtil.registerFunction(p9, "onWinchTreeShapeCut", Winch.onWinchTreeShapeCut)
	SpecializationUtil.registerFunction(p9, "onWinchTreeShapeMounted", Winch.onWinchTreeShapeMounted)
end
function Winch.registerOverwrittenFunctions(p10)
	SpecializationUtil.registerOverwrittenFunction(p10, "loadExtraDependentParts", Winch.loadExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p10, "updateExtraDependentParts", Winch.updateExtraDependentParts)
	SpecializationUtil.registerOverwrittenFunction(p10, "getDoConsumePtoPower", Winch.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p10, "getConsumingLoad", Winch.getConsumingLoad)
	SpecializationUtil.registerOverwrittenFunction(p10, "getIsPowerTakeOffActive", Winch.getIsPowerTakeOffActive)
	SpecializationUtil.registerOverwrittenFunction(p10, "addToPhysics", Winch.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p10, "removeFromPhysics", Winch.removeFromPhysics)
end
function Winch.registerEventListeners(p11)
	SpecializationUtil.registerEventListener(p11, "onLoad", Winch)
	SpecializationUtil.registerEventListener(p11, "onLoadFinished", Winch)
	SpecializationUtil.registerEventListener(p11, "onDelete", Winch)
	SpecializationUtil.registerEventListener(p11, "onReadStream", Winch)
	SpecializationUtil.registerEventListener(p11, "onWriteStream", Winch)
	SpecializationUtil.registerEventListener(p11, "onReadUpdateStream", Winch)
	SpecializationUtil.registerEventListener(p11, "onWriteUpdateStream", Winch)
	SpecializationUtil.registerEventListener(p11, "onPostUpdate", Winch)
	SpecializationUtil.registerEventListener(p11, "onRegisterActionEvents", Winch)
end
function Winch.onLoad(p12, _)
	local v13 = p12.spec_winch
	v13.texts = {}
	local v14 = Utils.getNoNil(p12.configurations.winch, 1)
	local v15 = string.format("vehicle.winch.winchConfigurations.winchConfiguration(%d)", v14 - 1)
	ObjectChangeUtil.updateObjectChanges(p12.xmlFile, "vehicle.winch.winchConfigurations.winchConfiguration", v14, p12.components, p12)
	v13.controlGroupIndex = p12.xmlFile:getValue("vehicle.winch#controlGroupIndex", p12.xmlFile:getValue(v15 .. "#controlGroupIndex"))
	v13.ropes = {}
	for _, v16 in p12.xmlFile:iterator("vehicle.winch.rope") do
		local v17 = {}
		if p12:loadWinchRopeFromXML(p12.xmlFile, v16, v17) then
			local v18 = v13.ropes
			table.insert(v18, v17)
			v17.index = #v13.ropes
		end
	end
	for _, v19 in p12.xmlFile:iterator(v15 .. ".rope") do
		local v20 = {}
		if p12:loadWinchRopeFromXML(p12.xmlFile, v19, v20) then
			local v21 = v13.ropes
			table.insert(v21, v20)
			v20.index = #v13.ropes
		end
	end
	if #v13.ropes > 0 then
		v13.hasRopes = true
		v13.texts.startAttachMode = g_i18n:getText("input_WINCH_ATTACH_MODE")
		v13.texts.stopAttachMode = g_i18n:getText("winch_releaseRope")
		v13.texts.attachTree = g_i18n:getText("input_WINCH_ATTACH")
		v13.texts.attachAnotherTree = g_i18n:getText("winch_attachAnotherTree")
		v13.texts.detachTree = g_i18n:getText("input_WINCH_DETACH")
		v13.texts.control = g_i18n:getText("winch_control")
		v13.texts.warningTooHeavy = g_i18n:getText("winch_treeTooHeavy")
		v13.texts.warningMaxNumTreesReached = g_i18n:getText("winch_maxNumTreesReached")
		v13.texts.warningMaxLengthReached = g_i18n:getText("winch_ropeMaxLengthReached")
		v13.treeRaycast = {}
		v13.treeRaycast.hasStarted = false
		v13.treeRaycast.startPos = { 0, 0, 0 }
		v13.treeRaycast.treeTargetPos = { 0, 0, 0 }
		v13.treeRaycast.treeCenterPos = { 0, 0, 0 }
		v13.treeRaycast.treeUp = { 0, 1, 0 }
		v13.treeRaycast.treeRadius = 1
		v13.treeRaycast.maxDistance = (1 / 0)
		v13.splitShapesToAttach = {}
		v13.isAttachable = SpecializationUtil.hasSpecialization(Attachable, p12.specializations)
		g_messageCenter:subscribe(MessageType.TREE_SHAPE_CUT, p12.onWinchTreeShapeCut, p12)
		g_messageCenter:subscribe(MessageType.TREE_SHAPE_MOUNTED, p12.onWinchTreeShapeMounted, p12)
		v13.dirtyFlag = p12:getNextDirtyFlag()
		v13.ropeDirtyFlag = p12:getNextDirtyFlag()
	else
		SpecializationUtil.removeEventListener(p12, "onLoadFinished", Winch)
		SpecializationUtil.removeEventListener(p12, "onDelete", Winch)
		SpecializationUtil.removeEventListener(p12, "onReadStream", Winch)
		SpecializationUtil.removeEventListener(p12, "onWriteStream", Winch)
		SpecializationUtil.removeEventListener(p12, "onReadUpdateStream", Winch)
		SpecializationUtil.removeEventListener(p12, "onWriteUpdateStream", Winch)
		SpecializationUtil.removeEventListener(p12, "onPostUpdate", Winch)
		SpecializationUtil.removeEventListener(p12, "onRegisterActionEvents", Winch)
	end
end
function Winch.onLoadFinished(p_u_22, p_u_23)
	if p_u_23 ~= nil and not p_u_23.resetVehicles then
		local v24 = p_u_23.key .. ".winch"
		p_u_23.xmlFile:iterate(v24 .. ".rope", function(_, p25)
			-- upvalues: (copy) p_u_23, (copy) p_u_22
			local v_u_26 = p_u_23.xmlFile:getValue(p25 .. "#index", 1)
			p_u_23.xmlFile:iterate(p25 .. ".attachedTree", function(_, p27)
				-- upvalues: (ref) p_u_23, (ref) p_u_22, (copy) v_u_26
				local v28 = p_u_23.xmlFile:getValue(p27 .. "#translation", nil, true)
				if v28 ~= nil then
					local v29 = p_u_23.xmlFile:getValue(p27 .. "#splitShapePart1")
					if v29 ~= nil then
						local v30 = p_u_23.xmlFile:getValue(p27 .. "#splitShapePart2")
						local v31 = p_u_23.xmlFile:getValue(p27 .. "#splitShapePart3")
						local v32 = ForestryPhysicsRope.loadPositionDataFromSavegame(p_u_23.xmlFile, p27 .. ".physicsRope")
						local v33 = getShapeFromSaveableSplitShapeId(v29, v30, v31)
						if v33 ~= nil and v33 ~= 0 then
							p_u_22:attachTreeToWinch(v33, v28[1], v28[2], v28[3], v_u_26, v32, true)
						end
					end
				end
			end)
		end)
	end
end
function Winch.onDelete(p34)
	local v35 = p34.spec_winch
	if v35.ropes ~= nil then
		for v36 = 1, #v35.ropes do
			local v37 = v35.ropes[v36]
			p34:detachTreeFromWinch(v36, true)
			removeTrigger(v37.triggerNode)
			v37.mainRope:delete()
			v37.setupRope:delete()
			v37.attachMarker:delete()
			v37.hookData:delete()
			if p34.isClient then
				g_soundManager:deleteSamples(v37.samples)
				g_animationManager:deleteAnimations(v37.animationNodes)
			end
			g_currentMission.activatableObjectsSystem:removeActivatable(v37.attachTreeActivatable)
			g_currentMission.activatableObjectsSystem:removeActivatable(v37.controlActivatable)
		end
	end
end
function Winch.onReadStream(p38, p39, _)
	local v40 = p38.spec_winch
	for v41 = 1, #v40.ropes do
		local v42 = v40.ropes[v41]
		if streamReadBool(p39) then
			for _ = 1, streamReadUIntN(p39, v42.maxTreeBits) do
				local v43 = streamReadFloat32(p39)
				local v44 = streamReadFloat32(p39)
				local v45 = streamReadFloat32(p39)
				local v46, v47, v48 = readSplitShapeIdFromStream(p39)
				if v46 == 0 then
					if v47 ~= 0 then
						local v49 = v40.splitShapesToAttach
						table.insert(v49, {
							["splitShapeId1"] = v47,
							["splitShapeId2"] = v48,
							["x"] = v43,
							["y"] = v44,
							["z"] = v45,
							["ropeIndex"] = v41
						})
					end
				else
					local v50, v51, v52 = localToWorld(v46, v43, v44, v45)
					p38:attachTreeToWinch(v46, v50, v51, v52, v41, nil, true)
				end
			end
		end
	end
end
function Winch.onWriteStream(p53, p54, _)
	local v55 = p53.spec_winch
	for v56 = 1, #v55.ropes do
		local v57 = v55.ropes[v56]
		if streamWriteBool(p54, #v57.attachedTrees > 0) then
			streamWriteUIntN(p54, #v57.attachedTrees, v57.maxTreeBits)
			for v58 = 1, #v57.attachedTrees do
				local v59 = v57.attachedTrees[v58]
				local v60, v61, v62 = worldToLocal(v59.treeId, getWorldTranslation(v59.activeHookData.hookId))
				streamWriteFloat32(p54, v60)
				streamWriteFloat32(p54, v61)
				streamWriteFloat32(p54, v62)
				writeSplitShapeIdToStream(p54, v59.treeId)
			end
		end
	end
end
function Winch.onReadUpdateStream(p63, p64, _, p65)
	local v66 = p63.spec_winch
	if p65:getIsServer() then
		if streamReadBool(p64) then
			for v67 = 1, #v66.ropes do
				local v68 = v66.ropes[v67]
				v68.controlDirection = streamReadUIntN(p64, 2) - 1
				v68.lastControlTimer = 500
				if v68.controlDirection > 0 then
					if not g_soundManager:getIsSamplePlaying(v68.samples.pullRope) then
						g_soundManager:playSample(v68.samples.pullRope)
						g_soundManager:stopSample(v68.samples.releaseRope)
					end
					g_animationManager:startAnimations(v68.animationNodes)
				elseif v68.controlDirection < 0 then
					if not g_soundManager:getIsSamplePlaying(v68.samples.releaseRope) then
						g_soundManager:playSample(v68.samples.releaseRope)
						g_soundManager:stopSample(v68.samples.pullRope)
					end
					g_animationManager:startAnimations(v68.animationNodes)
				end
			end
		end
		if streamReadBool(p64) then
			for v69 = 1, #v66.ropes do
				v66.ropes[v69].mainRope:readUpdateStream(p64)
			end
		end
	elseif streamReadBool(p64) then
		for v70 = 1, #v66.ropes do
			p63:setWinchControlInput(v70, streamReadUIntN(p64, 2) - 1)
		end
		return
	end
end
function Winch.onWriteUpdateStream(p71, p72, p73, p74)
	local v75 = p71.spec_winch
	if p73:getIsServer() then
		if streamWriteBool(p72, bitAND(p74, v75.dirtyFlag) ~= 0) then
			for v76 = 1, #v75.ropes do
				local v77 = streamWriteUIntN
				local v78 = v75.ropes[v76].controlInputSent
				v77(p72, math.sign(v78) + 1, 2)
			end
			return
		end
	else
		if streamWriteBool(p72, bitAND(p74, v75.dirtyFlag) ~= 0) then
			for v79 = 1, #v75.ropes do
				local v80 = streamWriteUIntN
				local v81 = v75.ropes[v79].controlDirection
				v80(p72, math.sign(v81) + 1, 2)
			end
		end
		if streamWriteBool(p72, bitAND(p74, v75.ropeDirtyFlag) ~= 0) then
			for v82 = 1, #v75.ropes do
				v75.ropes[v82].mainRope:writeUpdateStream(p72)
			end
		end
	end
end
function Winch.saveToXMLFile(p83, p84, p85, _)
	local v86 = p83.spec_winch
	local v87 = 0
	for v88 = 1, #v86.ropes do
		local v89 = v86.ropes[v88]
		if #v89.attachedTrees > 0 then
			local v90 = string.format("%s.rope(%d)", p85, v87)
			p84:setValue(v90 .. "#index", v88)
			for v91 = 1, #v89.attachedTrees do
				local v92 = v89.attachedTrees[v91]
				local v93 = string.format("%s.attachedTree(%d)", v90, v91 - 1)
				p84:setValue(v93 .. "#translation", getWorldTranslation(v92.activeHookData.hookId))
				local v94, v95, v96 = getSaveableSplitShapeId(v92.treeId)
				if v94 ~= 0 and v94 ~= nil then
					p84:setValue(v93 .. "#splitShapePart1", v94)
					p84:setValue(v93 .. "#splitShapePart2", v95)
					p84:setValue(v93 .. "#splitShapePart3", v96)
				end
				v89.mainRope:saveToXMLFile(p84, v93 .. ".physicsRope")
			end
			v87 = v87 + 1
		end
	end
end
function Winch.onPostUpdate(p97, p98, _, _, _)
	local v99 = p97.spec_winch
	if p97.isServer then
		for v100 = 1, #v99.ropes do
			local v101 = v99.ropes[v100]
			for v102 = 1, #v101.attachedTrees do
				local v103 = v101.attachedTrees[v102]
				if v103.treeId == nil or not entityExists(v103.treeId) then
					p97:detachTreeFromWinch()
					break
				end
			end
		end
	else
		for v104 = #v99.splitShapesToAttach, 1, -1 do
			local v105 = v99.splitShapesToAttach[v104]
			local v106 = resolveStreamSplitShapeId(v105.splitShapeId1, v105.splitShapeId2)
			if v106 ~= 0 then
				local v107, v108, v109 = localToWorld(v106, v105.x, v105.y, v105.z)
				p97:attachTreeToWinch(v106, v107, v108, v109, v105.ropeIndex, nil, true)
				table.remove(v99.splitShapesToAttach, v104)
			end
		end
	end
	for v110 = 1, #v99.ropes do
		local v111 = v99.ropes[v110]
		if v111.isAttachModeActive then
			local v112 = g_localPlayer
			if v112 ~= nil then
				if v112:getIsHoldingHandTool() or not v112.isControlled then
					p97:setWinchTreeAttachMode(v111, false)
					v99.treeRaycast.lastValidTree = nil
				else
					local v113 = v112:getCurrentCameraNode()
					local v114, v115, v116 = localToWorld(v113, 0, 0, 1)
					local v117, v118, v119 = localDirectionToWorld(v113, 0, 0, -1)
					local v120, v121, v122
					if #v111.attachedTrees > 0 then
						v120, v121, v122 = v111.attachedTrees[1].activeHookData:getRopeTargetPosition()
					else
						v120, v121, v122 = getWorldTranslation(v111.attachNode)
					end
					local v123 = #v111.attachedTrees > 0 and v111.maxSubLength or v111.maxLength
					local v124 = #v111.attachedTrees > 0 and 2 or 7.5
					if not v99.treeRaycast.hasStarted then
						v99.treeRaycast.hasStarted = true
						v99.treeRaycast.isFirstAttachment = #v111.attachedTrees == 0
						v99.treeRaycast.maxDistance = v123
						local v125 = v99.treeRaycast.startPos
						local v126 = v99.treeRaycast.startPos
						local v127 = v99.treeRaycast.startPos
						v125[1] = v120
						v126[2] = v121
						v127[3] = v122
						raycastClosestAsync(v114, v115, v116, v117, v118, v119, Winch.TREE_RAYCAST_DISTANCE, "onWinchTreeRaycastCallback", p97, CollisionFlag.TREE)
					end
					if v111.setupRope.physicsRopeIndex == nil then
						local v128 = v112.hands.spec_hands.kinematicNode
						if #v111.attachedTrees == 0 then
							v111.setupRope:setMaxLength(v111.maxLength + v124)
							v111.setupRope:create(v128, v128, nil, nil, false)
						else
							local v129 = v111.attachedTrees[1]
							local v130 = v111.setupRope
							local v131 = v111.maxSubLength
							local v132 = calcDistanceFrom
							local v133 = v129.activeHookData
							v130:setMaxLength(math.max(v131, v132(v128, v133:getRopeTarget())) + v124)
							v111.setupRope:create(v128, v128, v129.treeId, v129.activeHookData:getRopeTarget(), false)
						end
						v111.setupRope:setUseDynamicLength(true)
					end
					local v134 = v111.setupRope:getRopeDirectLengthPercentage(v111.setupRope.maxLength - v124)
					if v134 > 1 then
						if (v134 - 1) * v123 > v124 * 0.75 then
							p97:setWinchTreeAttachMode(v111, false)
							v99.treeRaycast.lastValidTree = nil
						else
							g_currentMission:showBlinkingWarning(v99.texts.warningMaxLengthReached, 1000)
						end
					end
					if v99.treeRaycast.lastValidTree == nil then
						if v99.treeRaycast.lastInValidTree == nil then
							local v135, v136, v137, v138
							if v134 > 1 then
								v135 = 1
								v136 = 0
								v137 = 0
								v138 = 1
							else
								v135 = 0
								v136 = 1
								v137 = 0
								v138 = 1
							end
							v111.setupRope:setEmissiveColor(v135, v136, v137, v138)
						else
							v111.setupRope:setEmissiveColor(1, 0, 0, 1)
						end
					else
						v111.setupRope:setEmissiveColor(0, 1, 0, 1)
					end
				end
			end
			if v99.treeRaycast.lastValidTree == nil then
				v111.attachMarker:setIsActive(false)
			else
				v111.attachMarker:setIsActive(true)
				v111.attachMarker:setPosition(v99.treeRaycast.treeCenterPos[1], v99.treeRaycast.treeCenterPos[2], v99.treeRaycast.treeCenterPos[3], v99.treeRaycast.treeUp[1], v99.treeRaycast.treeUp[2], v99.treeRaycast.treeUp[3], v99.treeRaycast.treeRadius)
			end
			p97:raiseActive()
		end
		if v111.lastControlTimer > 0 then
			v111.lastControlTimer = v111.lastControlTimer - p98
			if v111.lastControlTimer <= 0 then
				v111.controlDirection = 0
				v111.curSpeedAlpha = 0
				g_soundManager:stopSample(v111.samples.pullRope)
				g_soundManager:stopSample(v111.samples.releaseRope)
				g_animationManager:stopAnimations(v111.animationNodes)
			end
			p97:raiseActive()
		end
	end
end
function Winch.onRegisterActionEvents(p139, _, p140)
	if p139.isClient then
		local v141 = p139.spec_winch
		p139:clearActionEventsTable(v141.actionEvents)
		if p140 and (v141.controlGroupIndex == nil or v141.controlGroupIndex == p139.spec_cylindered.currentControlGroupIndex) then
			local _, v142 = p139:addPoweredActionEvent(v141.actionEvents, InputAction.WINCH_CONTROL_VEHICLE, p139, Winch.actionEventControl, false, false, true, true, nil)
			g_inputBinding:setActionEventTextPriority(v142, GS_PRIO_HIGH)
			g_inputBinding:setActionEventText(v142, v141.texts.control)
			local _, v143 = p139:addPoweredActionEvent(v141.actionEvents, InputAction.WINCH_DETACH, p139, Winch.actionEventDetach, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v143, GS_PRIO_HIGH)
			g_inputBinding:setActionEventText(v143, v141.texts.detachTree)
			Winch.updateActionEvents(p139)
		end
	end
end
function Winch.actionEventControl(p144, _, p145, _, _)
	for v146 = 1, #p144.spec_winch.ropes do
		p144:setWinchControlInput(v146, p145)
	end
end
function Winch.actionEventDetach(p147, _, _, _, _)
	p147:detachTreeFromWinch()
end
function Winch.updateActionEvents(p148)
	if p148.isClient then
		local v149 = p148.spec_winch
		local v150 = false
		for v151 = 1, #v149.ropes do
			if #v149.ropes[v151].attachedTrees > 0 then
				v150 = true
				break
			end
		end
		local v152 = v149.actionEvents[InputAction.WINCH_CONTROL_VEHICLE]
		if v152 ~= nil then
			g_inputBinding:setActionEventActive(v152.actionEventId, v150)
		end
		local v153 = v149.actionEvents[InputAction.WINCH_DETACH]
		if v153 ~= nil then
			g_inputBinding:setActionEventActive(v153.actionEventId, v150)
		end
	end
end
function Winch.loadWinchRopeFromXML(p_u_154, p_u_155, p156, p_u_157)
	p_u_157.ropeNode = p_u_155:getValue(p156 .. "#node", nil, p_u_154.components, p_u_154.i3dMappings)
	p_u_157.triggerNode = p_u_155:getValue(p156 .. "#triggerNode", nil, p_u_154.components, p_u_154.i3dMappings)
	p_u_157.maxNumTrees = p_u_155:getValue(p156 .. "#maxNumTrees", 1)
	local v158 = p_u_157.maxNumTrees
	local v159 = math.sqrt(v158)
	p_u_157.maxTreeBits = math.ceil(v159)
	p_u_157.maxTreeMass = p_u_155:getValue(p156 .. "#maxTreeMass", 1)
	p_u_157.minLength = p_u_155:getValue(p156 .. "#minLength", 1)
	p_u_157.maxLength = p_u_155:getValue(p156 .. "#maxLength", 30)
	p_u_157.maxSubLength = p_u_155:getValue(p156 .. "#maxSubLength", 2)
	p_u_157.speed = p_u_155:getValue(p156 .. "#speed", 1.5) * 0.001
	p_u_157.acceleration = 1 / p_u_155:getValue(p156 .. "#acceleration", 1.5) * 0.001
	p_u_157.curSpeedAlpha = 0
	p_u_157.attachNode = p_u_155:getValue(p156 .. ".attach#node", nil, p_u_154.components, p_u_154.i3dMappings)
	if p_u_157.ropeNode == nil or (p_u_157.triggerNode == nil or p_u_157.attachNode == nil) then
		return false
	end
	addTrigger(p_u_157.triggerNode, "onWinchPlayerTriggerCallback", p_u_154)
	p_u_157.jointComponent = p_u_154:getParentComponent(p_u_157.ropeNode)
	p_u_157.mainRope = ForestryPhysicsRope.new(p_u_154, p_u_157.jointComponent, p_u_157.ropeNode, p_u_154.isServer)
	p_u_157.mainRope:loadFromXML(p_u_155, p156 .. ".mainRope", p_u_157.minLength, p_u_157.maxLength)
	p_u_157.setupRope = ForestryPhysicsRope.new(p_u_154, p_u_157.jointComponent, p_u_157.ropeNode, true)
	p_u_157.setupRope:loadFromXML(p_u_155, p156 .. ".setupRope", p_u_157.minLength, p_u_157.maxLength)
	p_u_157.componentJoints = {}
	p_u_155:iterate(p156 .. ".componentJoint", function(_, p160)
		-- upvalues: (copy) p_u_155, (copy) p_u_154, (copy) p_u_157
		local v161 = {
			["index"] = p_u_155:getValue(p160 .. "#jointIndex")
		}
		if v161.index ~= nil then
			v161.jointDesc = p_u_154.componentJoints[v161.index]
			v161.limitActive = p_u_155:getValue(p160 .. "#limitActive", nil, true)
			v161.limitInactive = p_u_155:getValue(p160 .. "#limitInactive", nil, true)
			if v161.limitActive ~= nil and v161.limitInactive ~= nil then
				local v162 = p_u_157.componentJoints
				table.insert(v162, v161)
			end
		end
	end)
	p_u_157.attachMarker = TargetTreeMarker.new(p_u_154, p_u_154.rootNode)
	p_u_157.attachMarker:loadFromXML(p_u_155, p156 .. ".attach.marker")
	p_u_157.attachTime = p_u_155:getValue(p156 .. ".attach#time", 0.5)
	p_u_157.hookData = ForestryHook.new(p_u_154, p_u_154.rootNode)
	p_u_157.hookData:loadFromXML(p_u_155, p156 .. ".treeHook")
	p_u_157.hookData:setVisibility(false)
	p_u_157.changeObjects = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p_u_155, p156, p_u_157.changeObjects, p_u_154.components, p_u_154)
	ObjectChangeUtil.setObjectChanges(p_u_157.changeObjects, false, p_u_154, p_u_154.setMovingToolDirty)
	p_u_157.isPlayerInRange = false
	p_u_157.isAttachModeActive = false
	p_u_157.attachedTrees = {}
	p_u_157.controlDirection = 0
	p_u_157.lastControlTimer = 0
	p_u_157.controlInputSent = 0
	p_u_157.samples = {}
	if p_u_154.isClient then
		p_u_157.samples.pullRope = g_soundManager:loadSampleFromXML(p_u_155, p156 .. ".sounds", "pullRope", p_u_154.baseDirectory, p_u_154.components, 0, AudioGroup.VEHICLE, p_u_154.i3dMappings, p_u_154)
		p_u_157.samples.releaseRope = g_soundManager:loadSampleFromXML(p_u_155, p156 .. ".sounds", "releaseRope", p_u_154.baseDirectory, p_u_154.components, 0, AudioGroup.VEHICLE, p_u_154.i3dMappings, p_u_154)
		p_u_157.samples.attachTree = g_soundManager:loadSampleFromXML(p_u_155, p156 .. ".sounds", "attachTree", p_u_154.baseDirectory, p_u_154.components, 1, AudioGroup.VEHICLE, p_u_154.i3dMappings, p_u_154)
		p_u_157.samples.detachTree = g_soundManager:loadSampleFromXML(p_u_155, p156 .. ".sounds", "detachTree", p_u_154.baseDirectory, p_u_154.components, 1, AudioGroup.VEHICLE, p_u_154.i3dMappings, p_u_154)
		p_u_157.animationNodes = g_animationManager:loadAnimations(p_u_155, p156 .. ".animationNodes", p_u_154.components, p_u_154, p_u_154.i3dMappings)
	end
	p_u_157.attachTreeActivatable = WinchAttachTreeActivatable.new(p_u_154, p_u_157)
	p_u_157.controlActivatable = WinchControlRopeActivatable.new(p_u_154, p_u_157)
	return true
end
function Winch.setWinchTreeAttachMode(p163, p164, p165)
	if p165 == nil then
		p165 = not p164.isAttachModeActive
	end
	if p165 ~= p164.isAttachModeActive then
		if p165 then
			g_currentMission.activatableObjectsSystem:removeActivatable(p164.controlActivatable)
			g_currentMission.activatableObjectsSystem:removeActivatable(p164.attachTreeActivatable)
			g_currentMission.activatableObjectsSystem:addActivatable(p164.attachTreeActivatable)
			p163:raiseActive()
		else
			p164.attachMarker:setIsActive(false)
			p164.setupRope:destroy()
			if not p164.isPlayerInRange then
				g_currentMission.activatableObjectsSystem:removeActivatable(p164.attachTreeActivatable)
			end
			if #p164.attachedTrees > 0 then
				g_currentMission.activatableObjectsSystem:addActivatable(p164.controlActivatable)
			end
		end
		p164.isAttachModeActive = p165
	end
end
function Winch.getIsWinchAttachModeActive(_, p166)
	return p166.isAttachModeActive
end
function Winch.getCanAttachWinchTree(p167, p168)
	if p168.isAttachModeActive then
		return p167.spec_winch.treeRaycast.lastValidTree ~= nil
	else
		return false
	end
end
function Winch.onAttachTreeInputEvent(p169, p170)
	if p170.isAttachModeActive then
		local v171 = p169.spec_winch
		if v171.treeRaycast.lastValidTree ~= nil then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(TreeAttachRequestEvent.new(p169, v171.treeRaycast.lastValidTree, v171.treeRaycast.treeTargetPos[1], v171.treeRaycast.treeTargetPos[2], v171.treeRaycast.treeTargetPos[3], p170.index, p170.setupRope))
			else
				local v172, v173 = p169:getIsWinchTreeAttachAllowed(p170.index, v171.treeRaycast.lastValidTree)
				if v172 then
					p169:attachTreeToWinch(v171.treeRaycast.lastValidTree, v171.treeRaycast.treeTargetPos[1], v171.treeRaycast.treeTargetPos[2], v171.treeRaycast.treeTargetPos[3], p170.index, nil)
				else
					p169:showWinchTreeMountFailedWarning(p170.index, v173)
				end
			end
			p169:setWinchTreeAttachMode(p170, false)
			v171.treeRaycast.lastValidTree = nil
		end
	end
end
function Winch.getWinchRopeSpeedFactor(p174, p175)
	local v176 = p174.spec_winch
	for v177 = 1, #v176.ropes do
		if tostring(v177) == p175 then
			return v176.ropes[v177].controlDirection
		end
	end
	return 1
end
function Winch.getIsWinchTreeAttachAllowed(p178, p179, p180)
	local v181 = p178.spec_winch.ropes[p179]
	if v181 ~= nil then
		local v182 = getMass(p180)
		for v183 = 1, #v181.attachedTrees do
			v182 = v182 + getMass(v181.attachedTrees[v183].treeId)
		end
		if v181.maxTreeMass < v182 then
			return false, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_TOO_HEAVY
		end
		if #v181.attachedTrees >= v181.maxNumTrees then
			return false, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_TOO_MANY
		end
	end
	return true, TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_DEFAULT
end
function Winch.showWinchTreeMountFailedWarning(p184, p185, p186)
	local v187 = p184.spec_winch
	local v188 = v187.ropes[p185]
	if v188 ~= nil then
		if p186 == TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_TOO_HEAVY then
			g_currentMission:showBlinkingWarning(string.format(v187.texts.warningTooHeavy, v188.maxTreeMass), 2500)
			return
		end
		if p186 == TreeAttachResponseEvent.TREE_ATTACH_FAIL_REASON_TOO_MANY then
			g_currentMission:showBlinkingWarning(v187.texts.warningMaxNumTreesReached, 2500)
		end
	end
end
function Winch.attachTreeToWinch(p189, p190, p191, p192, p193, p194, p195, p196)
	local v197 = p189.spec_winch.ropes[p194]
	if v197 ~= nil then
		local v198 = {
			["activeHookData"] = v197.hookData:clone()
		}
		local v199, _, _ = v198.activeHookData:mountToTree(p190, p191, p192, p193, 4)
		if v199 == nil then
			return
		end
		if #v197.attachedTrees == 0 then
			v198.activeHookData:setTargetNode(v197.ropeNode, true)
			if p195 == nil then
				v197.mainRope:copyNodePositions(v197.setupRope, true)
			else
				v197.mainRope:applySavegamePositions(p195)
			end
			v197.mainRope:create(p190, v198.activeHookData:getRopeTarget(), nil, nil, true, true)
		else
			local v200 = v197.attachedTrees[1]
			v198.activeHookData:setTargetNode(v200.activeHookData:getRopeTarget(), true)
			local v201 = v198.activeHookData:getRopeTarget()
			local v202 = v200.treeId
			local v203 = v200.activeHookData:getRopeTarget()
			local v204 = v197.mainRope:clone(p190, v201, calcDistanceFrom(v201, v203))
			v204:create(v202, v203)
			v198.additionalRope = v204
		end
		v198.treeId = p190
		local v205 = v197.attachedTrees
		table.insert(v205, v198)
		for v206 = 1, #v197.componentJoints do
			local v207 = v197.componentJoints[v206]
			local v208 = v207.limitActive
			p189:setComponentJointRotLimit(v207.jointDesc, 1, -v208[1], v208[1])
			p189:setComponentJointRotLimit(v207.jointDesc, 2, -v208[2], v208[2])
			p189:setComponentJointRotLimit(v207.jointDesc, 3, -v208[3], v208[3])
		end
		ObjectChangeUtil.setObjectChanges(v197.changeObjects, true, p189, p189.setMovingToolDirty)
		if p189.isClient and v197.samples.attachTree ~= nil then
			g_soundManager:playSample(v197.samples.attachTree)
			setWorldTranslation(v197.samples.attachTree.soundNode, p191, p192, p193)
		end
		g_currentMission.activatableObjectsSystem:removeActivatable(v197.controlActivatable)
		g_currentMission.activatableObjectsSystem:addActivatable(v197.controlActivatable)
		g_messageCenter:publish(MessageType.TREE_SHAPE_MOUNTED, p190, p189)
		Winch.updateActionEvents(p189)
		TreeAttachEvent.sendEvent(p189, p190, p191, p192, p193, p194, p196)
	end
end
function Winch.detachTreeFromWinch(p209, p210, p211)
	local v212 = p209.spec_winch
	for v213 = 1, #v212.ropes do
		if p210 == nil or v213 == p210 then
			local v214 = v212.ropes[v213]
			if v214.isAttachModeActive then
				p209:setWinchTreeAttachMode(v214, false)
			end
			for v215 = #v214.attachedTrees, 1, -1 do
				local v216 = v214.attachedTrees[v215]
				if not p209.isDeleting and (v215 == 1 and p209.isClient) then
					local v217, v218, v219 = v216.activeHookData:getRopeTargetPosition()
					if v214.samples.detachTree ~= nil and not g_soundManager:getIsSamplePlaying(v214.samples.pullRope) then
						g_soundManager:playSample(v214.samples.detachTree)
						setWorldTranslation(v214.samples.detachTree.soundNode, v217, v218, v219)
					end
				end
				if v216.additionalRope ~= nil then
					v216.additionalRope:destroy()
					v216.additionalRope:delete()
					v216.additionalRope = nil
				end
				v216.activeHookData:delete()
				v214.mainRope:destroy()
				v214.attachedTrees[v215] = nil
			end
			if p209.isServer then
				for v220 = 1, #v214.componentJoints do
					local v221 = v214.componentJoints[v220]
					local v222 = v221.limitInactive
					p209:setComponentJointRotLimit(v221.jointDesc, 1, -v222[1], v222[1])
					p209:setComponentJointRotLimit(v221.jointDesc, 2, -v222[2], v222[2])
					p209:setComponentJointRotLimit(v221.jointDesc, 3, -v222[3], v222[3])
				end
			end
			ObjectChangeUtil.setObjectChanges(v214.changeObjects, false, p209, p209.setMovingToolDirty)
			g_currentMission.activatableObjectsSystem:removeActivatable(v214.controlActivatable)
			if v214.isPlayerInRange then
				g_currentMission.activatableObjectsSystem:addActivatable(v214.attachTreeActivatable)
			end
		end
	end
	Winch.updateActionEvents(p209)
	TreeDetachEvent.sendEvent(p209, p210, p211)
end
function Winch.setWinchControlInput(p223, p224, p225)
	local v226 = p223.spec_winch
	if not v226.isAttachable or p223:getAttacherVehicle() ~= nil then
		local v227 = v226.ropes[p224]
		if v227 ~= nil then
			if p223.isServer then
				if p225 ~= 0 and #v227.attachedTrees >= 1 then
					if p225 ~= 0 then
						local v228 = v227.curSpeedAlpha + g_currentDt * v227.acceleration
						v227.curSpeedAlpha = math.min(v228, 1)
					end
					local v229 = v227.mainRope:adjustLength(-(v227.speed * v227.curSpeedAlpha) * g_currentDt * p225)
					if v229 ~= 0 then
						v227.controlDirection = v229
						v227.lastControlTimer = 500
					end
					if p223.isClient then
						if v227.controlDirection > 0 then
							if not g_soundManager:getIsSamplePlaying(v227.samples.pullRope) then
								g_soundManager:playSample(v227.samples.pullRope)
								g_soundManager:stopSample(v227.samples.releaseRope)
							end
							g_animationManager:startAnimations(v227.animationNodes)
						elseif v227.controlDirection < 0 then
							if not g_soundManager:getIsSamplePlaying(v227.samples.releaseRope) then
								g_soundManager:playSample(v227.samples.releaseRope)
								g_soundManager:stopSample(v227.samples.pullRope)
							end
							g_animationManager:startAnimations(v227.animationNodes)
						end
					end
					p223:raiseDirtyFlags(v226.dirtyFlag)
					p223:raiseDirtyFlags(v226.ropeDirtyFlag)
					return
				end
			else
				v227.controlInputSent = p225
				p223:raiseDirtyFlags(v226.dirtyFlag)
			end
		end
	end
end
function Winch.onWinchPlayerTriggerCallback(p230, p231, p232, p233, p234, _)
	local v235 = p230.spec_winch
	if (not v235.isAttachable or p230:getAttacherVehicle() ~= nil) and ((p233 or p234) and (g_localPlayer ~= nil and p232 == g_localPlayer.rootNode)) then
		for v236 = 1, #v235.ropes do
			local v237 = v235.ropes[v236]
			if v237.triggerNode == p231 then
				if p233 then
					v237.isPlayerInRange = true
					g_currentMission.activatableObjectsSystem:addActivatable(v237.attachTreeActivatable)
					return
				end
				v237.isPlayerInRange = false
				if not v237.isAttachModeActive then
					g_currentMission.activatableObjectsSystem:removeActivatable(v237.attachTreeActivatable)
					return
				end
				break
			end
		end
	end
end
function Winch.onWinchTreeRaycastCallback(p238, p239, p240, p241, p242, _, _, _, _, _, p243, p244)
	local v245 = p238.spec_winch
	if p239 ~= 0 and (getHasClassId(p239, ClassIds.SHAPE) and getSplitType(p239) ~= 0) then
		if p244 then
			v245.treeRaycast.hasStarted = false
			if getRigidBodyType(p243) == RigidBodyType.STATIC and not v245.treeRaycast.isFirstAttachment then
				v245.treeRaycast.lastValidTree = nil
				return false
			end
			for v246 = 1, #v245.ropes do
				local v247 = v245.ropes[v246]
				for v248 = 1, #v247.attachedTrees do
					if v247.attachedTrees[v248].treeId == p239 then
						v245.treeRaycast.lastValidTree = nil
						return false
					end
				end
			end
			local v249, v250, v251, v252, v253, v254, v255 = SplitShapeUtil.getTreeOffsetPosition(p239, p240, p241, p242, 4, 0.15)
			if v249 == nil then
				v245.treeRaycast.lastValidTree = nil
			else
				if MathUtil.vector3Length(v245.treeRaycast.startPos[1] - p240, v245.treeRaycast.startPos[2] - p241, v245.treeRaycast.startPos[3] - p242) > v245.treeRaycast.maxDistance then
					v245.treeRaycast.lastInValidTree = p239
					v245.treeRaycast.lastValidTree = nil
				else
					v245.treeRaycast.lastValidTree = p239
					v245.treeRaycast.lastInValidTree = nil
				end
				v245.treeRaycast.treeTargetPos[1] = p240
				v245.treeRaycast.treeTargetPos[2] = p241
				v245.treeRaycast.treeTargetPos[3] = p242
				v245.treeRaycast.treeCenterPos[1] = v249
				v245.treeRaycast.treeCenterPos[2] = v250
				v245.treeRaycast.treeCenterPos[3] = v251
				v245.treeRaycast.treeUp[1] = v252
				v245.treeRaycast.treeUp[2] = v253
				v245.treeRaycast.treeUp[3] = v254
				v245.treeRaycast.treeRadius = v255
				p238:raiseActive()
			end
		end
		return false
	end
	if p244 then
		v245.treeRaycast.hasStarted = false
		v245.treeRaycast.lastValidTree = nil
		v245.treeRaycast.lastInValidTree = nil
	end
end
function Winch.onWinchTreeShapeCut(p256, p257, _)
	if p256.isServer then
		local v258 = p256.spec_winch
		for v259 = 1, #v258.ropes do
			local v260 = v258.ropes[v259]
			for v261 = 1, #v260.attachedTrees do
				if v260.attachedTrees[v261].treeId == p257 then
					p256:detachTreeFromWinch()
					break
				end
			end
		end
	end
end
function Winch.onWinchTreeShapeMounted(p262, p263, p264)
	if p264 ~= p262 and p262.isServer then
		local v265 = p262.spec_winch
		for v266 = 1, #v265.ropes do
			local v267 = v265.ropes[v266]
			for v268 = 1, #v267.attachedTrees do
				if v267.attachedTrees[v268].treeId == p263 then
					p262:detachTreeFromWinch()
					break
				end
			end
		end
	end
end
function Winch.loadExtraDependentParts(p269, p270, p271, p272, p273)
	if not p270(p269, p271, p272, p273) then
		return false
	end
	p273.winchRopeIndices = p271:getValue(p272 .. ".winch#ropeIndices", nil, true)
	return true
end
function Winch.updateExtraDependentParts(p274, p275, p276, p277)
	p275(p274, p276, p277)
	if p276.winchRopeIndices ~= nil then
		for v278 = 1, #p276.winchRopeIndices do
			local v279 = p276.winchRopeIndices[v278]
			local v280 = p274.spec_winch.ropes[v279]
			if v280 ~= nil and v280.mainRope ~= nil then
				v280.mainRope:updateAnchorNodes()
			end
		end
	end
end
function Winch.getDoConsumePtoPower(p281, p282)
	local v283 = p281.spec_winch
	if v283.hasRopes then
		for v284 = 1, #v283.ropes do
			if #v283.ropes[v284].attachedTrees > 0 then
				return true
			end
		end
	end
	return p282(p281)
end
function Winch.getConsumingLoad(p285, p286)
	local v287, v288 = p286(p285)
	local v289 = 0
	local v290 = p285.spec_winch
	if v290.hasRopes then
		for v291 = 1, #v290.ropes do
			if v290.ropes[v291].lastControlTimer > 0 then
				v289 = 1
			end
		end
	end
	return v287 + v289, v288 + 1
end
function Winch.getIsPowerTakeOffActive(p292, p293)
	local v294 = p292.spec_winch
	if v294.hasRopes then
		for v295 = 1, #v294.ropes do
			if #v294.ropes[v295].attachedTrees > 0 then
				return true
			end
		end
	end
	return p293(p292)
end
function Winch.addToPhysics(p296, p297)
	if not p297(p296) then
		return false
	end
	for _, v298 in ipairs(p296.spec_winch.ropes) do
		if #v298.attachedTrees > 0 then
			local v299 = v298.attachedTrees[1]
			v298.mainRope:create(v299.treeId, v299.activeHookData:getRopeTarget(), nil, nil, true, true)
		end
	end
	return true
end
function Winch.removeFromPhysics(p300, p301)
	for _, v302 in ipairs(p300.spec_winch.ropes) do
		if #v302.attachedTrees > 0 then
			v302.mainRope:destroy()
		end
	end
	return p301(p300)
end
function Winch.loadSpecValueMaxMass(p_u_303, _, _)
	local v_u_304 = 0
	p_u_303:iterate("vehicle.winch.rope", function(_, p305)
		-- upvalues: (ref) v_u_304, (copy) p_u_303
		local v306 = p_u_303:getValue(p305 .. "#maxTreeMass", 0)
		local v307 = v_u_304
		v_u_304 = math.max(v306, v307)
	end)
	local v_u_308 = {}
	p_u_303:iterate("vehicle.winch.winchConfigurations.winchConfiguration", function(p309, p310)
		-- upvalues: (copy) p_u_303, (copy) v_u_308
		local v_u_311 = 0
		p_u_303:iterate(p310 .. ".rope", function(_, p312)
			-- upvalues: (ref) v_u_311, (ref) p_u_303
			local v313 = p_u_303:getValue(p312 .. "#maxTreeMass", 0)
			local v314 = v_u_311
			v_u_311 = math.max(v313, v314)
		end)
		v_u_308[p309] = v_u_311
	end)
	return {
		["maxTreeMass"] = v_u_304,
		["massByConfig"] = v_u_308
	}
end
function Winch.getSpecValueMaxMass(p315, _, p316, _, p317, p318)
	if p315.specs.winchMaxMass ~= nil then
		local v319 = p315.specs.winchMaxMass.maxTreeMass
		if p316 == nil then
			for _, v320 in pairs(p315.specs.winchMaxMass.massByConfig) do
				v319 = math.max(v320, v319)
			end
		else
			local v321 = p316.winch
			v319 = p315.specs.winchMaxMass.massByConfig[v321] or v319
		end
		local v322 = string.format("%.1f%s", v319, g_i18n:getText("unit_tonsShort"))
		if p317 and p318 then
			return v319, v319, v322
		end
		if p317 then
			return v319, v322
		end
		if v319 ~= 0 then
			return v322
		end
	end
end

LogGrab = {}
LogGrab.GRAB_INDEX_NUM_BITS = 3
source("dataS/scripts/vehicles/specializations/events/LogGrabClawStateEvent.lua")
function LogGrab.prerequisitesPresent(_)
	return true
end
function LogGrab.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("logGrab", g_i18n:getText("shop_configuration"), "logGrab", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("LogGrab")
	LogGrab.registerLogGrabXMLPaths(v1, "vehicle.logGrab.grab(?)")
	LogGrab.registerLogGrabXMLPaths(v1, "vehicle.logGrab.logGrabConfigurations.logGrabConfiguration(?).grab(?)")
	v1:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.BOOL, "vehicles.vehicle(?).logGrab.grab(?)#state", "Grab claw state")
end
function LogGrab.registerLogGrabXMLPaths(p2, p3)
	p2:register(XMLValueType.NODE_INDEX, p3 .. "#jointNode", "Joint node")
	p2:register(XMLValueType.NODE_INDEX, p3 .. "#jointRoot", "Joint root node")
	p2:register(XMLValueType.BOOL, p3 .. "#lockAllAxis", "Lock all axis", false)
	p2:register(XMLValueType.BOOL, p3 .. "#limitYAxis", "Limit joint y axis movement (only allows movement up, but not down)", false)
	p2:register(XMLValueType.ANGLE, p3 .. "#rotLimit", "Defines the rotation limit on all axis", 10)
	p2:register(XMLValueType.BOOL, p3 .. "#unmountOnTreeCut", "Unmount trees while the wood harvester cuts the tree (only if the vehicle is a wood harvester as well)", false)
	p2:register(XMLValueType.FLOAT, p3 .. "#foldMinLimit", "Min. folding time to attach trees", 0)
	p2:register(XMLValueType.FLOAT, p3 .. "#foldMaxLimit", "Max. folding time to attach trees", 1)
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".trigger#node", "Trigger node")
	p2:register(XMLValueType.INT, p3 .. ".claw(?)#componentJointIndex", "Component joint index")
	p2:register(XMLValueType.FLOAT, p3 .. ".claw(?)#dampingFactor", "Damping factor", 20)
	p2:register(XMLValueType.INT, p3 .. ".claw(?)#axis", "Grab axis", 1)
	p2:register(XMLValueType.ANGLE, p3 .. ".claw(?)#rotationOffsetThreshold", "Rotation offset threshold", 10)
	p2:register(XMLValueType.BOOL, p3 .. ".claw(?)#rotationOffsetInverted", "Invert threshold", false)
	p2:register(XMLValueType.FLOAT, p3 .. ".claw(?)#rotationOffsetTime", "Rotation offset time until mount", 1000)
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".claw(?).movingTool(?)#node", "Node of moving tool to block while limit is exceeded")
	p2:register(XMLValueType.FLOAT, p3 .. ".claw(?).movingTool(?)#direction", "Direction to block the moving tool", 1)
	p2:register(XMLValueType.INT, p3 .. ".claw(?).movingTool(?)#closeDirection", "Direction in which the grab is closed (if defined the trees are locked while fully closed)")
	p2:register(XMLValueType.STRING, p3 .. ".clawAnimation#name", "Claw animation name")
	p2:register(XMLValueType.FLOAT, p3 .. ".clawAnimation#speedScale", "Animation speed scale", 1)
	p2:register(XMLValueType.BOOL, p3 .. ".clawAnimation#initialState", "Initial state of the grab (true: closed, false: open)", true)
	p2:register(XMLValueType.FLOAT, p3 .. ".clawAnimation#lockTime", "Animation time when trees are locked", 1)
	p2:register(XMLValueType.STRING, p3 .. ".clawAnimation#inputAction", "Input action to toggle animation", "IMPLEMENT_EXTRA2")
	p2:register(XMLValueType.INT, p3 .. ".clawAnimation#controlGroupIndex", "Control group that needs to be active")
	p2:register(XMLValueType.L10N_STRING, p3 .. ".clawAnimation#textPos", "Input text to open the claw", "action_foldBenchPos")
	p2:register(XMLValueType.L10N_STRING, p3 .. ".clawAnimation#textNeg", "Input text to close the claw", "action_foldBenchNeg")
	p2:register(XMLValueType.FLOAT, p3 .. ".clawAnimation#foldMinLimit", "Min. folding time to control claw", 0)
	p2:register(XMLValueType.FLOAT, p3 .. ".clawAnimation#foldMaxLimit", "Max. folding time to control claw", 1)
	p2:register(XMLValueType.BOOL, p3 .. ".clawAnimation#openDuringFolding", "Claw will be opened during folding", false)
	p2:register(XMLValueType.BOOL, p3 .. ".clawAnimation#closeDuringFolding", "Claw will be closed during folding", false)
	p2:register(XMLValueType.STRING, p3 .. ".lockAnimation#name", "Lock animation played while tree joints are created and revered while joints are removed")
	p2:register(XMLValueType.FLOAT, p3 .. ".lockAnimation#speedScale", "Animation speed scale", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".lockAnimation#unlockSpeedScale", "Animation speed scale while trees are unlocked", "negative #speedScale")
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".treeDetection#node", "Tree detection node")
	p2:register(XMLValueType.FLOAT, p3 .. ".treeDetection#sizeY", "Tree detection node size y", 2)
	p2:register(XMLValueType.FLOAT, p3 .. ".treeDetection#sizeZ", "Tree detection node size z", 2)
	p2:register(XMLValueType.INT, p3 .. ".componentJointLimit(?)#jointIndex", "Index of component joint to change", 1)
	p2:register(XMLValueType.VECTOR_ROT, p3 .. ".componentJointLimit(?)#limitActive", "Limit when tree is mounted")
	p2:register(XMLValueType.VECTOR_ROT, p3 .. ".componentJointLimit(?)#limitInactive", "Limit when no tree is mounted")
	p2:register(XMLValueType.INT, p3 .. ".componentJointMassSetting(?)#jointIndex", "Index of component joint to change", 1)
	p2:register(XMLValueType.FLOAT, p3 .. ".componentJointMassSetting(?)#minMass", "Mass of mounted trees to use min defined value (t)", 0)
	p2:register(XMLValueType.FLOAT, p3 .. ".componentJointMassSetting(?)#maxMass", "Mass of mounted trees to use max defined value (t)", 1)
	p2:register(XMLValueType.VECTOR_3, p3 .. ".componentJointMassSetting(?)#minMaxRotDriveForce", "Max. rot drive force applied when the trees weight #minMass")
	p2:register(XMLValueType.VECTOR_3, p3 .. ".componentJointMassSetting(?)#maxMaxRotDriveForce", "Max. rot drive force applied when the trees weight #maxMass")
end
function LogGrab.registerEvents(p4)
	SpecializationUtil.registerEvent(p4, "onLogGrabMountedTreesChanged")
end
function LogGrab.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "loadLogGrabFromXML", LogGrab.loadLogGrabFromXML)
	SpecializationUtil.registerFunction(p5, "updateLogGrabClawState", LogGrab.updateLogGrabClawState)
	SpecializationUtil.registerFunction(p5, "getGrabCanMountSplitShape", LogGrab.getGrabCanMountSplitShape)
	SpecializationUtil.registerFunction(p5, "mountSplitShape", LogGrab.mountSplitShape)
	SpecializationUtil.registerFunction(p5, "unmountSplitShape", LogGrab.unmountSplitShape)
	SpecializationUtil.registerFunction(p5, "getIsLogGrabClawStateChangeAllowed", LogGrab.getIsLogGrabClawStateChangeAllowed)
	SpecializationUtil.registerFunction(p5, "setLogGrabClawState", LogGrab.setLogGrabClawState)
end
function LogGrab.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "setComponentJointFrame", LogGrab.setComponentJointFrame)
	SpecializationUtil.registerOverwrittenFunction(p6, "getMovingToolMoveValue", LogGrab.getMovingToolMoveValue)
	SpecializationUtil.registerOverwrittenFunction(p6, "onDelimbTree", LogGrab.onDelimbTree)
end
function LogGrab.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onPostLoad", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onDelete", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onReadStream", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onWriteStream", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onUpdateTick", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onCutTree", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onTurnedOn", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onRegisterActionEvents", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onLogGrabMountedTreesChanged", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onFoldStateChanged", LogGrab)
	SpecializationUtil.registerEventListener(p7, "onFoldTimeChanged", LogGrab)
end
function LogGrab.onLoad(p_u_8, _)
	local v_u_9 = p_u_8.spec_logGrab
	v_u_9.grabs = {}
	if p_u_8.xmlFile:hasProperty("vehicle.logGrab") then
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab.trigger#node", "vehicle.logGrab.grab.trigger#node")
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab#jointNode", "vehicle.logGrab.grab#jointNode")
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab#jointRoot", "vehicle.logGrab.grab#jointRoot")
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab#lockAllAxis", "vehicle.logGrab.grab#lockAllAxis")
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab.grab#componentJoint", "vehicle.logGrab.grab.claw#componentJointIndex")
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab.grab#dampingFactor", "vehicle.logGrab.grab.claw#dampingFactor")
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab.grab#axis", "vehicle.logGrab.grab.claw#axis")
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab.grab#rotationOffsetThreshold", "vehicle.logGrab.grab.claw#rotationOffsetThreshold")
		XMLUtil.checkDeprecatedXMLElements(p_u_8.xmlFile, "vehicle.logGrab.grab#rotationOffsetTime", "vehicle.logGrab.grab.claw#rotationOffsetTime")
		local v10 = p_u_8.configurations.logGrab or 1
		local v11 = string.format("vehicle.logGrab.logGrabConfigurations.logGrabConfiguration(%d)", v10 - 1)
		p_u_8.xmlFile:iterate(v11 .. ".grab", function(_, p12)
			-- upvalues: (copy) p_u_8, (copy) v_u_9
			local v13 = {}
			if p_u_8:loadLogGrabFromXML(p_u_8.xmlFile, p12, v13) then
				local v14 = v_u_9.grabs
				table.insert(v14, v13)
			end
		end)
		p_u_8.xmlFile:iterate("vehicle.logGrab.grab", function(_, p15)
			-- upvalues: (copy) p_u_8, (copy) v_u_9
			local v16 = {}
			if p_u_8:loadLogGrabFromXML(p_u_8.xmlFile, p15, v16) then
				local v17 = v_u_9.grabs
				table.insert(v17, v16)
			end
		end)
	end
	if #v_u_9.grabs == 0 then
		SpecializationUtil.removeEventListener(p_u_8, "onPostLoad", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onDelete", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onReadStream", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onWriteStream", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onUpdateTick", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onCutTree", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onTurnedOn", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onRegisterActionEvents", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onLogGrabMountedTreesChanged", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onFoldStateChanged", LogGrab)
		SpecializationUtil.removeEventListener(p_u_8, "onFoldTimeChanged", LogGrab)
	end
end
function LogGrab.onPostLoad(p18, p19)
	local v20 = p18.spec_logGrab
	for v21 = 1, #v20.grabs do
		local v22 = v20.grabs[v21]
		if v22.clawAnimation.name ~= nil then
			local v23 = v22.clawAnimation.initialState
			if p19 ~= nil and not p19.resetVehicles then
				local v24 = string.format("%s.logGrab.grab(%d)", p19.key, v21 - 1)
				v23 = p19.xmlFile:getValue(v24 .. "#state", v23)
			end
			if v23 then
				v22.clawAnimation.state = true
				p18:playAnimation(v22.clawAnimation.name, 1, 0, true)
				AnimatedVehicle.updateAnimationByName(p18, v22.clawAnimation.name, 9999999, true)
			end
		end
		for v25 = 1, #v22.claws do
			local v26 = v22.claws[v25]
			for v27 = #v26.movingTools, 1, -1 do
				local v28 = v26.movingTools[v27]
				v28.movingTool = p18:getMovingToolByNode(v28.node)
				if v28.movingTool == nil then
					table.remove(v26.movingTools, v27)
				end
			end
		end
	end
end
function LogGrab.onDelete(p29)
	local v30 = p29.spec_logGrab
	if v30.grabs ~= nil then
		for v31 = 1, #v30.grabs do
			local v32 = v30.grabs[v31]
			if v32.callbackId ~= nil then
				removeTrigger(v32.triggerNode, v32.callbackId)
			end
		end
	end
end
function LogGrab.saveToXMLFile(p33, p34, p35, _)
	local v36 = p33.spec_logGrab
	for v37 = 1, #v36.grabs do
		local v38 = v36.grabs[v37]
		if v38.clawAnimation.name ~= nil then
			p34:setValue((p35 .. string.format(".grab(%d)", v37 - 1)) .. "#state", v38.clawAnimation.state)
		end
	end
end
function LogGrab.onReadStream(p39, p40, _)
	local v41 = p39.spec_logGrab
	for v42 = 1, #v41.grabs do
		if v41.grabs[v42].clawAnimation.name ~= nil then
			p39:setLogGrabClawState(v42, streamReadBool(p40), true)
		end
	end
end
function LogGrab.onWriteStream(p43, p44, _)
	local v45 = p43.spec_logGrab
	for v46 = 1, #v45.grabs do
		local v47 = v45.grabs[v46]
		if v47.clawAnimation.name ~= nil then
			streamWriteBool(p44, v47.clawAnimation.state)
		end
	end
end
function LogGrab.onUpdateTick(p48, p49, _, _, _)
	if p48.isServer then
		local v50 = p48.spec_logGrab
		for v51 = 1, #v50.grabs do
			local v52 = v50.grabs[v51]
			local v53 = true
			if v52.clawAnimation.name == nil then
				local v54
				if next(v52.dynamicMountedShapes) == nil then
					v54 = next(v52.pendingDynamicMountShapes) == nil
				else
					v54 = false
				end
				for v55 = 1, #v52.claws do
					local v56 = v52.claws[v55]
					local v57 = p48:updateLogGrabClawState(v56, p49, nil, v54)
					if g_time - v52.lastGrabChangeTime > 2500 then
						v57 = v56.lastClawState
					end
					if v52.unmountOnTreeCut and (p48.spec_woodHarvester ~= nil and p48.spec_woodHarvester.attachedSplitShape ~= nil) then
						v57 = false
					end
					if not v57 then
						v53 = false
					end
					v56.lastClawState = v57
				end
			elseif v52.clawAnimation.state then
				if p48:getIsAnimationPlaying(v52.clawAnimation.name) then
					local v58 = true
					for v59 = 1, #v52.claws do
						if not p48:updateLogGrabClawState(v52.claws[v59], p49, true) then
							v58 = false
						end
					end
					if v58 then
						p48:stopAnimation(v52.clawAnimation.name)
					end
				end
				if p48:getIsAnimationPlaying(v52.clawAnimation.name) and p48:getAnimationTime(v52.clawAnimation.name) < v52.clawAnimation.lockTime then
					v53 = false
				end
			elseif p48:getAnimationTime(v52.clawAnimation.name) < v52.clawAnimation.lockTime then
				v53 = false
			end
			for v60, _ in pairs(v52.pendingDynamicMountShapes) do
				if not entityExists(v60) then
					v52.pendingDynamicMountShapes[v60] = nil
				end
			end
			if v53 then
				for v61, _ in pairs(v52.pendingDynamicMountShapes) do
					if v52.dynamicMountedShapes[v61] == nil and p48:getGrabCanMountSplitShape(v52, v61) then
						local v62, v63 = p48:mountSplitShape(v52, v61)
						if v62 ~= nil then
							v52.dynamicMountedShapes[v61] = {
								["jointIndex"] = v62,
								["jointTransform"] = v63
							}
							v52.pendingDynamicMountShapes[v61] = nil
						end
					end
				end
				if not v52.jointLimitsOpen and next(v52.dynamicMountedShapes) ~= nil then
					v52.jointLimitsOpen = true
					for v64 = 1, #v52.claws do
						local v65 = v52.claws[v64]
						local v66 = p48.componentJoints[v65.componentJoint]
						if v66 ~= nil then
							for v67 = 1, 3 do
								setJointRotationLimitSpring(v66.jointIndex, v67 - 1, v66.rotLimitSpring[v67], v66.rotLimitDamping[v67] * v65.dampingFactor)
							end
						end
					end
				end
			else
				for v68, v69 in pairs(v52.dynamicMountedShapes) do
					p48:unmountSplitShape(v52, v68, v69.jointIndex, v69.jointTransform, false)
				end
				if v52.jointLimitsOpen then
					v52.jointLimitsOpen = false
					for v70 = 1, #v52.claws do
						local v71 = v52.claws[v70]
						local v72 = p48.componentJoints[v71.componentJoint]
						if v72 ~= nil then
							setJointRotationLimitSpring(v72.jointIndex, 0, v72.rotLimitSpring[1], v72.rotLimitDamping[1])
							setJointRotationLimitSpring(v72.jointIndex, 1, v72.rotLimitSpring[2], v72.rotLimitDamping[2])
							setJointRotationLimitSpring(v72.jointIndex, 2, v72.rotLimitSpring[3], v72.rotLimitDamping[3])
						end
					end
				end
			end
			if v52.lockAnimation.name ~= nil then
				if v53 then
					v53 = next(v52.dynamicMountedShapes) ~= nil
				end
				if v53 ~= v52.lockAnimation.state then
					v52.lockAnimation.state = v53
					if v53 then
						p48:playAnimation(v52.lockAnimation.name, v52.lockAnimation.speedScale, p48:getAnimationTime(v52.lockAnimation.name))
					else
						p48:playAnimation(v52.lockAnimation.name, v52.lockAnimation.unlockSpeedScale, p48:getAnimationTime(v52.lockAnimation.name))
					end
				end
			end
			local v73
			if v52.clawAnimation.name == nil then
				v73 = false
			else
				v73 = p48:getIsAnimationPlaying(v52.clawAnimation.name)
			end
			if v52.componentLimitsDirty or v73 then
				local v74 = next(v52.dynamicMountedShapes) ~= nil
				for v75 = 1, #v52.componentJointLimits do
					local v76 = v52.componentJointLimits[v75]
					if v76.isActive ~= v74 or v73 then
						v76.isActive = v74
						local v77 = next(v52.dynamicMountedShapes) == nil and 1 or 0
						if v52.clawAnimation.name ~= nil and (next(v52.dynamicMountedShapes) ~= nil or next(v52.pendingDynamicMountShapes)) then
							v77 = 1 - p48:getAnimationTime(v52.clawAnimation.name)
						end
						local v78, v79, v80 = MathUtil.vector3Lerp(v76.limitActive[1], v76.limitActive[2], v76.limitActive[3], v76.limitInactive[1], v76.limitInactive[2], v76.limitInactive[3], v77)
						p48:setComponentJointRotLimit(v76.joint, 0, -v78, v78)
						p48:setComponentJointRotLimit(v76.joint, 1, -v79, v79)
						p48:setComponentJointRotLimit(v76.joint, 2, -v80, v80)
					end
				end
				v52.componentLimitsDirty = false
			end
		end
	end
end
function LogGrab.loadLogGrabFromXML(p_u_81, p_u_82, p83, p_u_84)
	p_u_84.claws = {}
	p_u_82:iterate(p83 .. ".claw", function(_, p85)
		-- upvalues: (copy) p_u_81, (copy) p_u_82, (copy) p_u_84
		XMLUtil.checkDeprecatedXMLElements(p_u_81.xmlFile, p85 .. "#componentJoint", p85 .. "#componentJointIndex")
		local v_u_86 = {
			["componentJoint"] = p_u_82:getValue(p85 .. "#componentJointIndex")
		}
		if v_u_86.componentJoint == nil then
			Logging.xmlWarning(p_u_82, "Missing claw componentJoint in xml. \'%s\'", p85)
		else
			v_u_86.dampingFactor = p_u_82:getValue(p85 .. "#dampingFactor", 20)
			v_u_86.axis = p_u_82:getValue(p85 .. "#axis", 1)
			v_u_86.direction = { 0, 0, 0 }
			v_u_86.direction[v_u_86.axis] = 1
			local v87 = p_u_81.componentJoints[v_u_86.componentJoint]
			if v87 == nil then
				Logging.xmlWarning(p_u_82, "Unable to load claw componentJoint from xml. \'%s\'", p85)
				return false
			end
			v_u_86.jointActor0 = v87.jointNode
			v_u_86.jointActor1 = v87.jointNodeActor1
			if v87.jointNodeActor1 == v87.jointNode then
				local v88 = createTransformGroup("jointNodeActor1Reference")
				local v89 = p_u_81.components[v87.componentIndices[2]]
				link(v89.node, v88)
				setWorldTranslation(v88, getWorldTranslation(v87.jointNode))
				setWorldRotation(v88, getWorldRotation(v87.jointNode))
				v_u_86.jointActor1 = v88
			end
			v_u_86.rotationOffsetThreshold = p_u_82:getValue(p85 .. "#rotationOffsetThreshold", 10)
			v_u_86.rotationOffsetInverted = p_u_82:getValue(p85 .. "#rotationOffsetInverted", false)
			v_u_86.rotationOffsetTime = p_u_82:getValue(p85 .. "#rotationOffsetTime", 1000)
			v_u_86.rotationOffsetTimer = 0
			v_u_86.rotationChangedTimer = 0
			v_u_86.currentOffset = 0
			v_u_86.lastClawState = false
			v_u_86.movingTools = {}
			p_u_82:iterate(p85 .. ".movingTool", function(_, p90)
				-- upvalues: (ref) p_u_82, (ref) p_u_81, (copy) v_u_86
				local v91 = {
					["node"] = p_u_82:getValue(p90 .. "#node", nil, p_u_81.components, p_u_81.i3dMappings)
				}
				if v91.node == nil then
					Logging.xmlWarning(p_u_82, "Unable to load movingTool from xml. \'%s\'", p90)
				else
					v91.direction = p_u_82:getValue(p90 .. "#direction", 1)
					v91.closeDirection = p_u_82:getValue(p90 .. "#closeDirection")
					local v92 = v_u_86.movingTools
					table.insert(v92, v91)
				end
			end)
			local v93 = p_u_84.claws
			table.insert(v93, v_u_86)
		end
	end)
	p_u_84.clawAnimation = {}
	p_u_84.clawAnimation.state = false
	p_u_84.clawAnimation.name = p_u_82:getValue(p83 .. ".clawAnimation#name")
	p_u_84.clawAnimation.speedScale = p_u_82:getValue(p83 .. ".clawAnimation#speedScale", 1)
	p_u_84.clawAnimation.initialState = p_u_82:getValue(p83 .. ".clawAnimation#initialState", true)
	p_u_84.clawAnimation.lockTime = p_u_82:getValue(p83 .. ".clawAnimation#lockTime", 1)
	p_u_84.clawAnimation.inputAction = InputAction[p_u_82:getValue(p83 .. ".clawAnimation#inputAction", "IMPLEMENT_EXTRA2")] or InputAction.IMPLEMENT_EXTRA2
	p_u_84.clawAnimation.controlGroupIndex = p_u_82:getValue(p83 .. ".clawAnimation#controlGroupIndex")
	p_u_84.clawAnimation.textPos = p_u_82:getValue(p83 .. ".clawAnimation#textPos", "action_foldBenchPos", p_u_81.customEnvironment, false)
	p_u_84.clawAnimation.textNeg = p_u_82:getValue(p83 .. ".clawAnimation#textNeg", "action_foldBenchNeg", p_u_81.customEnvironment, false)
	p_u_84.clawAnimation.foldMinLimit = p_u_82:getValue(p83 .. ".clawAnimation#foldMinLimit", 0)
	p_u_84.clawAnimation.foldMaxLimit = p_u_82:getValue(p83 .. ".clawAnimation#foldMaxLimit", 0)
	p_u_84.clawAnimation.openDuringFolding = p_u_82:getValue(p83 .. ".clawAnimation#openDuringFolding", false)
	p_u_84.clawAnimation.closeDuringFolding = p_u_82:getValue(p83 .. ".clawAnimation#closeDuringFolding", false)
	p_u_84.lockAnimation = {}
	p_u_84.lockAnimation.state = false
	p_u_84.lockAnimation.name = p_u_82:getValue(p83 .. ".lockAnimation#name")
	p_u_84.lockAnimation.speedScale = p_u_82:getValue(p83 .. ".lockAnimation#speedScale", 1)
	p_u_84.lockAnimation.unlockSpeedScale = p_u_82:getValue(p83 .. ".lockAnimation#unlockSpeedScale", -p_u_84.lockAnimation.speedScale)
	p_u_84.jointNode = p_u_82:getValue(p83 .. "#jointNode", nil, p_u_81.components, p_u_81.i3dMappings)
	p_u_84.jointRoot = p_u_82:getValue(p83 .. "#jointRoot", nil, p_u_81.components, p_u_81.i3dMappings)
	p_u_84.lockAllAxis = p_u_82:getValue(p83 .. "#lockAllAxis", false)
	p_u_84.limitYAxis = p_u_82:getValue(p83 .. "#limitYAxis", false)
	p_u_84.rotLimit = p_u_82:getValue(p83 .. "#rotLimit", 10)
	p_u_84.unmountOnTreeCut = p_u_82:getValue(p83 .. "#unmountOnTreeCut", false)
	p_u_84.foldMinLimit = p_u_82:getValue(p83 .. "#foldMinLimit", 0)
	p_u_84.foldMaxLimit = p_u_82:getValue(p83 .. "#foldMaxLimit", 1)
	p_u_84.triggerNode = p_u_82:getValue(p83 .. ".trigger#node", nil, p_u_81.components, p_u_81.i3dMappings)
	if p_u_84.triggerNode == nil then
		Logging.xmlWarning(p_u_82, "Missing grab trigger in \'%s\'", p83)
		return false
	end
	if getCollisionFilterMask(p_u_84.triggerNode) == CollisionFlag.TREE then
		p_u_84.callbackId = addTrigger(p_u_84.triggerNode, "logGrabTriggerCallback", p_u_81, false, LogGrab.logGrabTriggerCallback)
		p_u_84.pendingDynamicMountShapes = {}
		p_u_84.dynamicMountedShapes = {}
		p_u_84.jointLimitsOpen = false
		p_u_84.treeDetectionNode = p_u_82:getValue(p83 .. ".treeDetection#node", nil, p_u_81.components, p_u_81.i3dMappings)
		if p_u_84.treeDetectionNode == nil then
			Logging.xmlWarning(p_u_82, "Missing tree detection node in \'%s\'", p83)
			return false
		end
		p_u_84.treeDetectionNodeSizeY = p_u_82:getValue(p83 .. ".treeDetection#sizeY", 2)
		p_u_84.treeDetectionNodeSizeZ = p_u_82:getValue(p83 .. ".treeDetection#sizeZ", 2)
		p_u_84.componentJointLimits = {}
		p_u_82:iterate(p83 .. ".componentJointLimit", function(_, p94)
			-- upvalues: (copy) p_u_82, (copy) p_u_81, (copy) p_u_84
			local v95 = {
				["jointIndex"] = p_u_82:getValue(p94 .. "#jointIndex")
			}
			if v95.jointIndex ~= nil then
				v95.joint = p_u_81.componentJoints[v95.jointIndex]
				v95.limitActive = p_u_82:getValue(p94 .. "#limitActive", nil, true)
				v95.limitInactive = p_u_82:getValue(p94 .. "#limitInactive", nil, true)
				if v95.joint ~= nil and (v95.limitActive ~= nil and v95.limitInactive ~= nil) then
					v95.isActive = false
					local v96 = p_u_84.componentJointLimits
					table.insert(v96, v95)
				end
			end
		end)
		p_u_84.componentJointMassSettings = {}
		p_u_82:iterate(p83 .. ".componentJointMassSetting", function(_, p97)
			-- upvalues: (copy) p_u_82, (copy) p_u_81, (copy) p_u_84
			local v98 = {
				["jointIndex"] = p_u_82:getValue(p97 .. "#jointIndex")
			}
			if v98.jointIndex ~= nil then
				v98.joint = p_u_81.componentJoints[v98.jointIndex]
				v98.minMass = p_u_82:getValue(p97 .. "#minMass", 0)
				v98.maxMass = p_u_82:getValue(p97 .. "#maxMass", 1)
				v98.minMaxRotDriveForce = p_u_82:getValue(p97 .. "#minMaxRotDriveForce", nil, true)
				v98.maxMaxRotDriveForce = p_u_82:getValue(p97 .. "#maxMaxRotDriveForce", nil, true)
				v98.maxRotDriveForce = { 0, 0, 0 }
				if v98.joint ~= nil and (v98.minMaxRotDriveForce ~= nil and v98.maxMaxRotDriveForce ~= nil) then
					local v99 = p_u_84.componentJointMassSettings
					table.insert(v99, v98)
				end
			end
		end)
		p_u_84.componentLimitsDirty = false
		p_u_84.lastGrabChangeTime = (-1 / 0)
		return true
	end
	Logging.xmlWarning(p_u_82, "LogGrab trigger \'%s\' has wrong collision mask, only the Tree bit is allowed!", getName(p_u_84.triggerNode))
end
function LogGrab.updateLogGrabClawState()
	-- failed to decompile
end
function LogGrab.onCutTree(p100, p101, p102)
	if p100.isServer and (p101 > 0 and p102) then
		for v103 = 1, #p100.spec_logGrab.grabs do
			if p100:getIsLogGrabClawStateChangeAllowed(v103) then
				p100:setLogGrabClawState(v103, true)
			end
		end
	end
end
function LogGrab.onTurnedOn(p104)
	if p104.isServer then
		for v105 = 1, #p104.spec_logGrab.grabs do
			if p104:getIsLogGrabClawStateChangeAllowed(v105) then
				p104:setLogGrabClawState(v105, false)
			end
		end
	end
end
function LogGrab.onTurnedOff(p106)
	if p106.isServer then
		for v107 = 1, #p106.spec_logGrab.grabs do
			if p106:getIsLogGrabClawStateChangeAllowed(v107) then
				p106:setLogGrabClawState(v107, true)
			end
		end
	end
end
function LogGrab.onRegisterActionEvents(p108, _, p109)
	if p108.isClient then
		local v110 = p108.spec_logGrab
		p108:clearActionEventsTable(v110.actionEvents)
		if p109 then
			for v111 = 1, #v110.grabs do
				local v112 = v110.grabs[v111]
				if v112.clawAnimation.name ~= nil and (v112.clawAnimation.controlGroupIndex == nil or (p108.spec_cylindered == nil or p108.spec_cylindered.currentControlGroupIndex == v112.clawAnimation.controlGroupIndex)) then
					local _, v113 = p108:addPoweredActionEvent(v110.actionEvents, v112.clawAnimation.inputAction, p108, LogGrab.actionEventClawAnimation, false, true, false, true, v111)
					g_inputBinding:setActionEventTextPriority(v113, GS_PRIO_HIGH)
					LogGrab.updateActionEvents(p108)
				end
			end
		end
	end
end
function LogGrab.actionEventClawAnimation(p114, _, _, p115, _)
	if p114:getIsLogGrabClawStateChangeAllowed(p115) then
		p114:setLogGrabClawState(p115, nil)
	end
end
function LogGrab.updateActionEvents(p116)
	local v117 = p116.spec_logGrab
	for v118 = 1, #v117.grabs do
		local v119 = v117.grabs[v118]
		local v120 = v117.actionEvents[v119.clawAnimation.inputAction]
		if v120 ~= nil then
			g_inputBinding:setActionEventText(v120.actionEventId, v119.clawAnimation.state and v119.clawAnimation.textNeg or v119.clawAnimation.textPos)
			g_inputBinding:setActionEventActive(v120.actionEventId, p116:getIsLogGrabClawStateChangeAllowed(v118))
		end
	end
end
function LogGrab.setComponentJointFrame(p121, p122, p123, p124)
	p122(p121, p123, p124)
	local v125 = p121.spec_logGrab
	for v126 = 1, #v125.grabs do
		local v127 = v125.grabs[v126]
		for v128 = 1, #v127.claws do
			local v129 = v127.claws[v128]
			if p123 == p121.componentJoints[v129.componentJoint] then
				v127.lastGrabChangeTime = g_time
			end
		end
	end
end
function LogGrab.getMovingToolMoveValue(p130, p131, p132)
	local v133 = p131(p130, p132)
	local v134 = p130.spec_logGrab
	for v135 = 1, #v134.grabs do
		local v136 = v134.grabs[v135]
		for v137 = 1, #v136.claws do
			local v138 = v136.claws[v137]
			for v139 = 1, #v138.movingTools do
				local v140 = v138.movingTools[v139]
				if v140.movingTool == p132 then
					v140.lastMoveValue = v133
					if v138.currentOffset > v138.rotationOffsetThreshold and math.sign(v133) == v140.direction then
						v133 = 0
					end
				end
			end
		end
	end
	return v133
end
function LogGrab.onDelimbTree(p141, p142, p143, ...)
	local v144 = p141.spec_logGrab
	for v145 = 1, #v144.grabs do
		if v144.grabs[v145].clawAnimation.state then
			p141:setLogGrabClawState(v145, false, true)
		end
	end
	return p142(p141, p143, ...)
end
function LogGrab.getGrabCanMountSplitShape(p146, p147, _)
	if p146.getFoldAnimTime ~= nil then
		local v148 = p146:getFoldAnimTime()
		if v148 < p147.foldMinLimit or p147.foldMaxLimit < v148 then
			return false
		end
	end
	return true
end
function LogGrab.mountSplitShape(p149, p150, p151)
	local v152 = JointConstructor.new()
	v152:setActors(p150.jointRoot, p151)
	local v153 = createTransformGroup("dynamicMountJoint")
	local v154, v155, v156 = getWorldTranslation(p150.treeDetectionNode)
	local v157, v158, v159 = localDirectionToWorld(p150.treeDetectionNode, 1, 0, 0)
	local v160, v161, v162 = localDirectionToWorld(p150.treeDetectionNode, 0, 1, 0)
	local v163, v164, v165, v166 = testSplitShape(p151, v154, v155, v156, v157, v158, v159, v160, v161, v162, p150.treeDetectionNodeSizeY, p150.treeDetectionNodeSizeZ)
	if v163 == nil then
		link(p150.jointNode, v153)
		setTranslation(v153, 0, 0, 0)
		v152:setRotationLimit(0, 0, 0)
		v152:setRotationLimit(1, 0, 0)
		v152:setRotationLimit(2, 0, 0)
	else
		link(p150.jointNode, v153)
		local v167, v168, v169 = localToWorld(p150.treeDetectionNode, 0, (v163 + v164) * 0.5, (v165 + v166) * 0.5)
		setWorldTranslation(v153, v167, v168, v169)
		v152:setRotationLimit(0, -p150.rotLimit, p150.rotLimit)
		v152:setRotationLimit(1, -p150.rotLimit, p150.rotLimit)
		v152:setRotationLimit(2, -p150.rotLimit, p150.rotLimit)
	end
	v152:setJointTransforms(v153, v153)
	if not p150.lockAllAxis then
		if p150.limitYAxis then
			v152:setTranslationLimit(1, true, -0.1, 2)
			v152:setTranslationLimit(2, false, 0, 0)
		else
			v152:setTranslationLimit(1, false, 0, 0)
			v152:setTranslationLimit(2, false, 0, 0)
		end
		v152:setEnableCollision(true)
	end
	v152:setRotationLimitSpring(7500, 1500, 7500, 1500, 7500, 1500)
	v152:setTranslationLimitSpring(7500, 1500, 7500, 1500, 7500, 1500)
	p150.componentLimitsDirty = true
	g_messageCenter:publish(MessageType.TREE_SHAPE_MOUNTED, p151, p149)
	SpecializationUtil.raiseEvent(p149, "onLogGrabMountedTreesChanged", p150)
	return v152:finalize(), v153
end
function LogGrab.unmountSplitShape(p170, p171, p172, p173, p174, p175)
	removeJoint(p173)
	delete(p174)
	p171.dynamicMountedShapes[p172] = nil
	if p175 == nil or not p175 then
		p171.pendingDynamicMountShapes[p172] = true
	else
		p171.pendingDynamicMountShapes[p172] = nil
	end
	p171.componentLimitsDirty = true
	SpecializationUtil.raiseEvent(p170, "onLogGrabMountedTreesChanged", p171)
end
function LogGrab.onLogGrabMountedTreesChanged(p176, p177)
	if p176.isServer then
		local v178 = 0
		for v179, _ in pairs(p177.dynamicMountedShapes) do
			if entityExists(v179) then
				v178 = v178 + getMass(v179)
			end
		end
		for v180 = 1, #p177.componentJointMassSettings do
			local v181 = p177.componentJointMassSettings[v180]
			local v182 = MathUtil.inverseLerp(v181.minMass, v181.maxMass, v178)
			local v183 = v181.maxRotDriveForce
			local v184 = v181.maxRotDriveForce
			local v185 = v181.maxRotDriveForce
			local v186, v187, v188 = MathUtil.vector3ArrayLerp(v181.minMaxRotDriveForce, v181.maxMaxRotDriveForce, v182)
			v183[1] = v186
			v184[1] = v187
			v185[3] = v188
			local v189 = v181.joint
			for v190 = 1, 3 do
				local v191 = v189.rotDriveRotation[v190] or 0
				local v192 = v189.rotDriveVelocity[v190] or 0
				setJointAngularDrive(v189.jointIndex, v190 - 1, v189.rotDriveRotation[v190] ~= nil, v189.rotDriveVelocity[v190] ~= nil, v189.rotDriveSpring[v190], v189.rotDriveDamping[v190], v181.maxRotDriveForce[v190], v191, v192)
			end
		end
	end
end
function LogGrab.onFoldStateChanged(p193, p194, _)
	local v195 = p193.spec_logGrab
	for v196 = 1, #v195.grabs do
		local v197 = v195.grabs[v196]
		if v197.clawAnimation.openDuringFolding then
			if p194 ~= p193.spec_foldable.turnOnFoldDirection then
				p193:setLogGrabClawState(v196, false, true)
			end
		elseif v197.clawAnimation.closeDuringFolding and p194 ~= p193.spec_foldable.turnOnFoldDirection then
			p193:setLogGrabClawState(v196, true, true)
		end
	end
end
function LogGrab.onFoldTimeChanged(p198, _)
	LogGrab.updateActionEvents(p198)
end
function LogGrab.getIsLogGrabClawStateChangeAllowed(p199, p200)
	local v201 = p199.spec_logGrab.grabs[p200]
	if v201 ~= nil and p199.getFoldAnimTime ~= nil then
		local v202 = p199:getFoldAnimTime()
		if v202 < v201.clawAnimation.foldMinLimit or v201.clawAnimation.foldMaxLimit < v202 then
			return false
		end
	end
	return true
end
function LogGrab.setLogGrabClawState(p203, p204, p205, p206)
	local v207 = p203.spec_logGrab.grabs[p204]
	if v207 ~= nil then
		if p205 == nil then
			p205 = not v207.clawAnimation.state
		end
		v207.clawAnimation.state = p205
		p203:playAnimation(v207.clawAnimation.name, v207.clawAnimation.state and v207.clawAnimation.speedScale or -v207.clawAnimation.speedScale, p203:getAnimationTime(v207.clawAnimation.name), true)
	end
	LogGrab.updateActionEvents(p203)
	LogGrabClawStateEvent.sendEvent(p203, p205, p204, p206)
end
function LogGrab.logGrabTriggerCallback(p208, p209, p210, p211, p212, _, _)
	local v213 = p208.spec_logGrab
	for v214 = 1, #v213.grabs do
		local v215 = v213.grabs[v214]
		if v215.triggerNode == p209 then
			if p211 then
				if getSplitType(p210) ~= 0 then
					local v216 = getRigidBodyType(p210)
					if (v216 == RigidBodyType.DYNAMIC or v216 == RigidBodyType.KINEMATIC) and v215.pendingDynamicMountShapes[p210] == nil then
						v215.pendingDynamicMountShapes[p210] = true
					end
				end
			elseif p212 and getSplitType(p210) ~= 0 then
				if v215.pendingDynamicMountShapes[p210] == nil then
					if v215.dynamicMountedShapes[p210] ~= nil then
						p208:unmountSplitShape(v215, p210, v215.dynamicMountedShapes[p210].jointIndex, v215.dynamicMountedShapes[p210].jointTransform, true)
					end
				else
					v215.pendingDynamicMountShapes[p210] = nil
				end
			end
		end
	end
end
function LogGrab.addNodeObjectMapping(p217, p218, p219)
	p218(p217, p219)
	local v220 = p217.spec_logGrab
	for v221 = 1, #v220.grabs do
		local v222 = v220.grabs[v221]
		if v222.triggerNode ~= nil then
			p219[v222.triggerNode] = p217
		end
	end
end
function LogGrab.removeNodeObjectMapping(p223, p224, p225)
	p224(p223, p225)
	local v226 = p223.spec_logGrab
	for v227 = 1, #v226.grabs do
		local v228 = v226.grabs[v227]
		if v228.triggerNode ~= nil then
			p225[v228.triggerNode] = nil
		end
	end
end
function LogGrab.updateDebugValues(p229, p230)
	if p229.isServer then
		local v231 = p229.spec_logGrab
		for v232 = 1, #v231.grabs do
			local v233 = v231.grabs[v232]
			for v234, v235 in ipairs(v233.claws) do
				local v236 = nil
				local v237 = nil
				for v238 = 1, #v235.movingTools do
					v236 = v235.movingTools[v238].lastMoveValue
					v237 = v235.movingTools[v238].direction
				end
				local v239
				if v236 == nil or v237 == nil then
					v239 = ""
				else
					local v240 = math.sign(v236) == v237
					v239 = string.format(" | isClosing: %s (%.2f/%d)", v240, v236, v237)
				end
				local v241 = {
					["name"] = string.format("grab (%d) claw (%d):", v232, v234)
				}
				local v242 = string.format
				local v243 = v235.currentOffset
				local v244 = math.deg(v243)
				local v245 = v235.rotationOffsetThreshold
				v241.value = v242("current: %.2fdeg / threshold: %.2fdeg  (timer: %d)%s", v244, math.deg(v245), v235.rotationOffsetTimer, v239)
				table.insert(p230, v241)
			end
			for v246, _ in pairs(v233.dynamicMountedShapes) do
				if entityExists(v246) then
					local v247 = {
						["name"] = string.format("grab (%d) mounted:", v232),
						["value"] = string.format("%s - %d", getName(v246), v246)
					}
					table.insert(p230, v247)
				end
			end
			for v248, _ in pairs(v233.pendingDynamicMountShapes) do
				if entityExists(v248) then
					local v249 = {
						["name"] = string.format("grab (%d) pending:", v232),
						["value"] = string.format("%s - %d", getName(v248), v248)
					}
					table.insert(p230, v249)
				end
			end
		end
	end
end

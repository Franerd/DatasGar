ProtectedBundleVehicle = {}
function ProtectedBundleVehicle.prerequisitesPresent(_)
	return true
end
function ProtectedBundleVehicle.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("ProtectedBundleVehicle")
	v1:register(XMLValueType.BOOL, "vehicle.protectedBundleVehicle#isBundleRoot", "Vehicle acts are bundle root vehicle (the only vehicle to be selectable, shown in overview, sellable, resetable)", false)
	v1:register(XMLValueType.BOOL, "vehicle.protectedBundleVehicle#isBundleChild", "Vehicle acts as bundle child vehicle (can not be selected, not shown in map overview, reset and sold with attacher vehicle)", false)
	v1:register(XMLValueType.STRING, "vehicle.protectedBundleVehicle#bundleFilename", "Path to bundle xml file (required for reset of the vehicle to spawn the bundle instead of the single vehicle)")
	v1:setXMLSpecializationType()
end
function ProtectedBundleVehicle.registerOverwrittenFunctions(p2)
	SpecializationUtil.registerOverwrittenFunction(p2, "getReloadXML", ProtectedBundleVehicle.getReloadXML)
end
function ProtectedBundleVehicle.registerEventListeners(p3)
	SpecializationUtil.registerEventListener(p3, "onLoad", ProtectedBundleVehicle)
	SpecializationUtil.registerEventListener(p3, "onPostDetach", ProtectedBundleVehicle)
end
function ProtectedBundleVehicle.onLoad(p4, _)
	local v5 = p4.spec_protectedBundleVehicle
	v5.isBundleRoot = p4.xmlFile:getValue("vehicle.protectedBundleVehicle#isBundleRoot", false)
	v5.isBundleChild = p4.xmlFile:getValue("vehicle.protectedBundleVehicle#isBundleChild", false)
	v5.bundleFilename = Utils.getFilename(p4.xmlFile:getValue("vehicle.protectedBundleVehicle#bundleFilename"), p4.baseDirectory)
	if v5.bundleFilename ~= nil and g_storeManager:getItemByXMLFilename(v5.bundleFilename) == nil then
		Logging.xmlWarning(p4.xmlFile, "Missing bundle vehicle store item for \'%s\'", v5.bundleFilename)
	end
	if v5.isBundleChild then
		p4.canBeReset = false
		p4.showInVehicleOverview = false
		p4.allowSelection = false
	end
	if not (p4.isServer and v5.isBundleChild) then
		SpecializationUtil.removeEventListener(p4, "onPostDetach", ProtectedBundleVehicle)
	end
end
function ProtectedBundleVehicle.onPostDetach(p6)
	if not (g_currentMission.vehicleSystem.isReloadRunning or (g_currentMission.isTeleporting or (p6.isDeleted or p6.isDeleting))) then
		p6:delete()
	end
end
function ProtectedBundleVehicle.getReloadXML(p7, p8)
	local v9 = p7.spec_protectedBundleVehicle
	if not v9.isBundleRoot or v9.bundleFilename == nil then
		return p8(p7)
	end
	local v10 = p8(p7)
	if v10 ~= nil then
		v10:setValue("vehicles.vehicle(0)#filename", HTMLUtil.encodeToHTML(NetworkUtil.convertToNetworkFilename(v9.bundleFilename)))
	end
	return v10
end

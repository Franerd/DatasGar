source("dataS/scripts/vehicles/specializations/events/WaterTrailerSetIsFillingEvent.lua")
WaterTrailer = {}
function WaterTrailer.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(FillUnit, p1)
end
function WaterTrailer.initSpecialization()
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("WaterTrailer")
	v2:register(XMLValueType.INT, "vehicle.waterTrailer#fillUnitIndex", "Fill unit index")
	v2:register(XMLValueType.FLOAT, "vehicle.waterTrailer#fillLitersPerSecond", "Fill liters per second", 500)
	v2:register(XMLValueType.NODE_INDEX, "vehicle.waterTrailer#fillNode", "Fill node", "Root component")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.waterTrailer.sounds", "refill")
	v2:setXMLSpecializationType()
end
function WaterTrailer.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "setIsWaterTrailerFilling", WaterTrailer.setIsWaterTrailerFilling)
end
function WaterTrailer.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getDrawFirstFillText", WaterTrailer.getDrawFirstFillText)
end
function WaterTrailer.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", WaterTrailer)
	SpecializationUtil.registerEventListener(p5, "onDelete", WaterTrailer)
	SpecializationUtil.registerEventListener(p5, "onReadStream", WaterTrailer)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", WaterTrailer)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", WaterTrailer)
	SpecializationUtil.registerEventListener(p5, "onPreDetach", WaterTrailer)
end
function WaterTrailer.onLoad(p6, _)
	local v7 = p6.spec_waterTrailer
	local v8 = p6.xmlFile:getValue("vehicle.waterTrailer#fillUnitIndex")
	if v8 ~= nil then
		v7.fillUnitIndex = v8
		v7.fillLitersPerSecond = p6.xmlFile:getValue("vehicle.waterTrailer#fillLitersPerSecond", 500)
		v7.waterFillNode = p6.xmlFile:getValue("vehicle.waterTrailer#fillNode", p6.components[1].node, p6.components, p6.i3dMappings)
	end
	v7.isFilling = false
	v7.activatable = WaterTrailerActivatable.new(p6)
	if p6.isClient then
		v7.samples = {}
		v7.samples.refill = g_soundManager:loadSampleFromXML(p6.xmlFile, "vehicle.waterTrailer.sounds", "refill", p6.baseDirectory, p6.components, 0, AudioGroup.VEHICLE, p6.i3dMappings, p6)
	end
	p6.needWaterInfo = true
end
function WaterTrailer.onDelete(p9)
	local v10 = p9.spec_waterTrailer
	g_currentMission.activatableObjectsSystem:removeActivatable(v10.activatable)
	g_soundManager:deleteSamples(v10.samples)
end
function WaterTrailer.onReadStream(p11, p12, _)
	p11:setIsWaterTrailerFilling(streamReadBool(p12), true)
end
function WaterTrailer.onWriteStream(p13, p14, _)
	local v15 = p13.spec_waterTrailer
	streamWriteBool(p14, v15.isFilling)
end
function WaterTrailer.onUpdateTick(p16, p17, _, _, _)
	local v18 = p16.spec_waterTrailer
	local _, v19, _ = getWorldTranslation(v18.waterFillNode)
	local v20 = v19 <= p16.waterY + 0.2
	if v20 then
		g_currentMission.activatableObjectsSystem:addActivatable(v18.activatable)
	else
		g_currentMission.activatableObjectsSystem:removeActivatable(v18.activatable)
	end
	if p16.isServer then
		if v18.isFilling and not v20 then
			p16:setIsWaterTrailerFilling(false)
		end
		if v18.isFilling and (p16:getFillUnitAllowsFillType(v18.fillUnitIndex, FillType.WATER) and p16:addFillUnitFillLevel(p16:getOwnerFarmId(), v18.fillUnitIndex, v18.fillLitersPerSecond * p17 * 0.001, FillType.WATER, ToolType.TRIGGER, nil) <= 0) then
			p16:setIsWaterTrailerFilling(false)
		end
	end
end
function WaterTrailer.setIsWaterTrailerFilling(p21, p22, p23)
	local v24 = p21.spec_waterTrailer
	if p22 ~= v24.isFilling then
		WaterTrailerSetIsFillingEvent.sendEvent(p21, p22, p23)
		v24.isFilling = p22
		if p21.isClient then
			if p22 then
				g_soundManager:playSample(v24.samples.refill)
				return
			end
			g_soundManager:stopSample(v24.samples.refill)
		end
	end
end
function WaterTrailer.getDrawFirstFillText(p25, p26)
	local v27 = p25.spec_waterTrailer
	return p25.isClient and (p25:getIsActiveForInput() and (p25:getIsSelected() and (p25:getFillUnitFillLevel(v27.fillUnitIndex) <= 0 and p25:getFillUnitCapacity(v27.fillUnitIndex) ~= 0))) and true or p26(p25)
end
function WaterTrailer.onPreDetach(p28, _, _)
	local v29 = p28.spec_waterTrailer
	g_currentMission.activatableObjectsSystem:removeActivatable(v29.activatable)
end
WaterTrailerActivatable = {}
local v_u_30 = Class(WaterTrailerActivatable)
function WaterTrailerActivatable.new(p31)
	-- upvalues: (copy) v_u_30
	local v32 = v_u_30
	local v33 = setmetatable({}, v32)
	v33.trailer = p31
	v33.activateText = "unknown"
	return v33
end
function WaterTrailerActivatable.getIsActivatable(p34)
	local v35 = p34.trailer.spec_waterTrailer.fillUnitIndex
	if not p34.trailer:getIsActiveForInput(true) or (p34.trailer:getFillUnitFillLevel(v35) >= p34.trailer:getFillUnitCapacity(v35) or not p34.trailer:getFillUnitAllowsFillType(v35, FillType.WATER)) then
		return false
	end
	p34:updateActivateText()
	return true
end
function WaterTrailerActivatable.run(p36)
	p36.trailer:setIsWaterTrailerFilling(not p36.trailer.spec_waterTrailer.isFilling)
	p36:updateActivateText()
end
function WaterTrailerActivatable.updateActivateText(p37)
	if p37.trailer.spec_waterTrailer.isFilling then
		p37.activateText = string.format(g_i18n:getText("action_stopRefillingOBJECT"), p37.trailer.typeDesc)
	else
		p37.activateText = string.format(g_i18n:getText("action_refillOBJECT"), p37.trailer.typeDesc)
	end
end

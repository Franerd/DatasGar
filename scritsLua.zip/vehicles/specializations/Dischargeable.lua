source("dataS/scripts/vehicles/specializations/events/SetDischargeStateEvent.lua")
Dischargeable = {}
Dischargeable.DISCHARGE_STATE_OFF = 0
Dischargeable.DISCHARGE_STATE_OBJECT = 1
Dischargeable.DISCHARGE_STATE_GROUND = 2
Dischargeable.SEND_NUM_BITS_DISCHARGE_STATE = 2
Dischargeable.DISCHARGE_REASON_NOT_ALLOWED_HERE = 1
Dischargeable.DISCHARGE_REASON_NO_FREE_CAPACITY = 2
Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED = 3
Dischargeable.DISCHARGE_REASON_TOOLTYPE_NOT_SUPPORTED = 4
Dischargeable.DISCHARGE_REASON_NO_ACCESS = 5
Dischargeable.DISCHARGE_REASON_NO_ACCESS_LAND = 6
Dischargeable.DISCHARGE_WARNINGS = {}
Dischargeable.DISCHARGE_WARNINGS[Dischargeable.DISCHARGE_REASON_NOT_ALLOWED_HERE] = "warning_actionNotAllowedHere"
Dischargeable.DISCHARGE_WARNINGS[Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED] = "warning_notAcceptedHere"
Dischargeable.DISCHARGE_WARNINGS[Dischargeable.DISCHARGE_REASON_TOOLTYPE_NOT_SUPPORTED] = "warning_notAcceptedTool"
Dischargeable.DISCHARGE_WARNINGS[Dischargeable.DISCHARGE_REASON_NO_FREE_CAPACITY] = "warning_noMoreFreeCapacity"
Dischargeable.DISCHARGE_WARNINGS[Dischargeable.DISCHARGE_REASON_NO_ACCESS] = "warning_youDontHaveAccessToThis"
Dischargeable.DISCHARGE_WARNINGS[Dischargeable.DISCHARGE_REASON_NO_ACCESS_LAND] = "warning_youDontHaveAccessToThisLand"
Dischargeable.DISCHARGE_NODE_XML_PATH = "vehicle.dischargeable.dischargeNode(?)"
Dischargeable.DISCHARGE_NODE_CONFIG_XML_PATH = "vehicle.dischargeable.dischargeableConfigurations.dischargeableConfiguration(?).dischargeNode(?)"
function Dischargeable.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(FillUnit, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(FillVolume, p1)
	end
	return v2
end
function Dischargeable.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("dischargeable", g_i18n:getText("configuration_dischargeable"), "dischargeable", VehicleConfigurationItem)
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Dischargeable")
	Dischargeable.registerXMLPaths(v3, "vehicle.dischargeable")
	Dischargeable.registerXMLPaths(v3, "vehicle.dischargeable.dischargeableConfigurations.dischargeableConfiguration(?)")
	Dashboard.registerDashboardXMLPaths(v3, "vehicle.dischargeable.dashboards", { "activeDischargeNode", "dischargeState" })
	v3:register(XMLValueType.INT, "vehicle.dischargeable.dashboards.dashboard(?)#dischargeNodeIndex", "Index of discharge node")
	v3:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.BOOL, "vehicles.vehicle(?).dischargeable#isAllowed", "If is dicharge allowed", nil)
end
function Dischargeable.registerXMLPaths(p4, p5)
	p4:register(XMLValueType.BOOL, p5 .. "#requiresTipOcclusionArea", "Requires tip occlusion area", true)
	p4:register(XMLValueType.BOOL, p5 .. "#consumePower", "While in discharge state, PTO power is consumed", true)
	p4:register(XMLValueType.BOOL, p5 .. "#stopDischargeOnDeactivate", "Stop discharge if the vehicle is deactivated", true)
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".dischargeNode(?)#node", "Discharge node")
	p4:register(XMLValueType.INT, p5 .. ".dischargeNode(?)#fillUnitIndex", "Fill unit index")
	p4:register(XMLValueType.INT, p5 .. ".dischargeNode(?)#unloadInfoIndex", "Unload info index", 1)
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#stopDischargeOnEmpty", "Stop discharge if fill unit empty", true)
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#canDischargeToGround", "Can discharge to ground", true)
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#canDischargeToObject", "Can discharge to object", true)
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#canDischargeToVehicle", "Can discharge to other vehicles", "same as canDischargeToObject")
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#canStartDischargeAutomatically", "Can start discharge automatically", false)
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#canStartGroundDischargeAutomatically", "Can start discharge to ground automatically", false)
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#stopDischargeIfNotPossible", "Stop discharge if not possible", "default \'true\' while having discharge trigger")
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#canDischargeToGroundAnywhere", "Can discharge to ground independent of land owned state", false)
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?)#emptySpeed", "Empty speed in l/sec", "fill unit capacity")
	p4:register(XMLValueType.TIME, p5 .. ".dischargeNode(?)#effectTurnOffThreshold", "After this time has passed and nothing has been harvested the effects are turned off", 0.25)
	p4:register(XMLValueType.STRING, p5 .. ".dischargeNode(?)#toolType", "Tool type", "dischargable")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".dischargeNode(?).info#node", "Discharge info node", "Discharge node")
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).info#width", "Discharge info width", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).info#length", "Discharge info length", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).info#zOffset", "Discharge info Z axis offset", 0)
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).info#yOffset", "Discharge info y axis offset", 2)
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?).info#limitToGround", "Discharge info is limited to ground", true)
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?).info#useRaycastHitPosition", "Discharge info uses raycast hit position", false)
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".dischargeNode(?).raycast#node", "Raycast node", "Discharge node")
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?).raycast#useWorldNegYDirection", "Use world negative Y Direction", false)
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).raycast#yOffset", "Y Offset", 0)
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).raycast#maxDistance", "Max. raycast distance", 10)
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?)#maxDistance", "Max. raycast distance", 10)
	p4:register(XMLValueType.STRING, p5 .. ".dischargeNode(?).fillType#converterName", "Converter to be used to convert the fill types")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".dischargeNode(?).trigger#node", "Discharge trigger node")
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".dischargeNode(?).activationTrigger#node", "Discharge activation trigger node")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p4, p5 .. ".dischargeNode(?).distanceObjectChanges")
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).distanceObjectChanges#threshold", "Defines at which raycast distance the object changes", 0.5)
	ObjectChangeUtil.registerObjectChangeXMLPaths(p4, p5 .. ".dischargeNode(?).stateObjectChanges")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p4, p5 .. ".dischargeNode(?).nodeActiveObjectChanges")
	EffectManager.registerEffectXMLPaths(p4, p5 .. ".dischargeNode(?).effects")
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?)#playSound", "Play discharge sound", true)
	p4:register(XMLValueType.NODE_INDEX, p5 .. ".dischargeNode(?)#soundNode", "Sound link node", "Discharge node")
	p4:register(XMLValueType.STRING, p5 .. ".dischargeNode(?).animation#name", "Name of animation to play while discharging")
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).animation#speed", "Animation speed while discharging", 1)
	p4:register(XMLValueType.FLOAT, p5 .. ".dischargeNode(?).animation#resetSpeed", "Animation speed while discharge has been stopped", 1)
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".dischargeNode(?)", "dischargeSound")
	p4:register(XMLValueType.BOOL, p5 .. ".dischargeNode(?).dischargeSound#overwriteSharedSound", "Overwrite shared discharge sound with sound defined in discharge node", false)
	SoundManager.registerSampleXMLPaths(p4, p5 .. ".dischargeNode(?)", "dischargeStateSound(?)")
	AnimationManager.registerAnimationNodesXMLPaths(p4, p5 .. ".dischargeNode(?).animationNodes")
	AnimationManager.registerAnimationNodesXMLPaths(p4, p5 .. ".dischargeNode(?).effectAnimationNodes")
end
function Dischargeable.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "loadDischargeNode", Dischargeable.loadDischargeNode)
	SpecializationUtil.registerFunction(p6, "setCurrentDischargeNodeIndex", Dischargeable.setCurrentDischargeNodeIndex)
	SpecializationUtil.registerFunction(p6, "getCurrentDischargeNode", Dischargeable.getCurrentDischargeNode)
	SpecializationUtil.registerFunction(p6, "getCurrentDischargeNodeIndex", Dischargeable.getCurrentDischargeNodeIndex)
	SpecializationUtil.registerFunction(p6, "getDischargeTargetObject", Dischargeable.getDischargeTargetObject)
	SpecializationUtil.registerFunction(p6, "getCurrentDischargeObject", Dischargeable.getCurrentDischargeObject)
	SpecializationUtil.registerFunction(p6, "discharge", Dischargeable.discharge)
	SpecializationUtil.registerFunction(p6, "dischargeToGround", Dischargeable.dischargeToGround)
	SpecializationUtil.registerFunction(p6, "dischargeToObject", Dischargeable.dischargeToObject)
	SpecializationUtil.registerFunction(p6, "setManualDischargeState", Dischargeable.setManualDischargeState)
	SpecializationUtil.registerFunction(p6, "setDischargeState", Dischargeable.setDischargeState)
	SpecializationUtil.registerFunction(p6, "getDischargeState", Dischargeable.getDischargeState)
	SpecializationUtil.registerFunction(p6, "getDischargeFillType", Dischargeable.getDischargeFillType)
	SpecializationUtil.registerFunction(p6, "getCanDischargeToGround", Dischargeable.getCanDischargeToGround)
	SpecializationUtil.registerFunction(p6, "getCanDischargeAtPosition", Dischargeable.getCanDischargeAtPosition)
	SpecializationUtil.registerFunction(p6, "getCanDischargeToLand", Dischargeable.getCanDischargeToLand)
	SpecializationUtil.registerFunction(p6, "getCanDischargeToObject", Dischargeable.getCanDischargeToObject)
	SpecializationUtil.registerFunction(p6, "getDischargeNotAllowedWarning", Dischargeable.getDischargeNotAllowedWarning)
	SpecializationUtil.registerFunction(p6, "getCanToggleDischargeToObject", Dischargeable.getCanToggleDischargeToObject)
	SpecializationUtil.registerFunction(p6, "getCanToggleDischargeToGround", Dischargeable.getCanToggleDischargeToGround)
	SpecializationUtil.registerFunction(p6, "getIsPossibleToDischargeToObject", Dischargeable.getIsPossibleToDischargeToObject)
	SpecializationUtil.registerFunction(p6, "getIsDischargeNodeActive", Dischargeable.getIsDischargeNodeActive)
	SpecializationUtil.registerFunction(p6, "setIsDischargeAllowed", Dischargeable.setIsDischargeAllowed)
	SpecializationUtil.registerFunction(p6, "getDischargeNodeEmptyFactor", Dischargeable.getDischargeNodeEmptyFactor)
	SpecializationUtil.registerFunction(p6, "getDischargeNodeAutomaticDischarge", Dischargeable.getDischargeNodeAutomaticDischarge)
	SpecializationUtil.registerFunction(p6, "getDischargeNodeByNode", Dischargeable.getDischargeNodeByNode)
	SpecializationUtil.registerFunction(p6, "updateRaycast", Dischargeable.updateRaycast)
	SpecializationUtil.registerFunction(p6, "updateDischargeInfo", Dischargeable.updateDischargeInfo)
	SpecializationUtil.registerFunction(p6, "raycastCallbackDischargeNode", Dischargeable.raycastCallbackDischargeNode)
	SpecializationUtil.registerFunction(p6, "finishDischargeRaycast", Dischargeable.finishDischargeRaycast)
	SpecializationUtil.registerFunction(p6, "getDischargeNodeByIndex", Dischargeable.getDischargeNodeByIndex)
	SpecializationUtil.registerFunction(p6, "handleDischargeOnEmpty", Dischargeable.handleDischargeOnEmpty)
	SpecializationUtil.registerFunction(p6, "handleDischargeNodeChanged", Dischargeable.handleDischargeNodeChanged)
	SpecializationUtil.registerFunction(p6, "handleDischarge", Dischargeable.handleDischarge)
	SpecializationUtil.registerFunction(p6, "handleDischargeRaycast", Dischargeable.handleDischargeRaycast)
	SpecializationUtil.registerFunction(p6, "handleFoundDischargeObject", Dischargeable.handleFoundDischargeObject)
	SpecializationUtil.registerFunction(p6, "setDischargeEffectDistance", Dischargeable.setDischargeEffectDistance)
	SpecializationUtil.registerFunction(p6, "setDischargeEffectActive", Dischargeable.setDischargeEffectActive)
	SpecializationUtil.registerFunction(p6, "updateDischargeSound", Dischargeable.updateDischargeSound)
	SpecializationUtil.registerFunction(p6, "dischargeTriggerCallback", Dischargeable.dischargeTriggerCallback)
	SpecializationUtil.registerFunction(p6, "onDeleteDischargeTriggerObject", Dischargeable.onDeleteDischargeTriggerObject)
	SpecializationUtil.registerFunction(p6, "dischargeActivationTriggerCallback", Dischargeable.dischargeActivationTriggerCallback)
	SpecializationUtil.registerFunction(p6, "onDeleteActivationTriggerObject", Dischargeable.onDeleteActivationTriggerObject)
	SpecializationUtil.registerFunction(p6, "setForcedFillTypeIndex", Dischargeable.setForcedFillTypeIndex)
end
function Dischargeable.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "getRequiresTipOcclusionArea", Dischargeable.getRequiresTipOcclusionArea)
	SpecializationUtil.registerOverwrittenFunction(p7, "getCanBeSelected", Dischargeable.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p7, "getDoConsumePtoPower", Dischargeable.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsPowerTakeOffActive", Dischargeable.getIsPowerTakeOffActive)
	SpecializationUtil.registerOverwrittenFunction(p7, "getAllowLoadTriggerActivation", Dischargeable.getAllowLoadTriggerActivation)
end
function Dischargeable.registerEvents(p8)
	SpecializationUtil.registerEvent(p8, "onDischargeStateChanged")
	SpecializationUtil.registerEvent(p8, "onDischargeTargetObjectChanged")
end
function Dischargeable.registerEventListeners(p9)
	SpecializationUtil.registerEventListener(p9, "onLoad", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onPostLoad", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onRegisterDashboardValueTypes", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onDelete", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onReadStream", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onWriteStream", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onReadUpdateStream", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onWriteUpdateStream", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onUpdate", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onUpdateTick", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onRegisterActionEvents", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onFillUnitFillLevelChanged", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onDeactivate", Dischargeable)
	SpecializationUtil.registerEventListener(p9, "onStateChange", Dischargeable)
end
function Dischargeable.onLoad(p_u_10, _)
	local v_u_11 = p_u_10.spec_dischargeable
	XMLUtil.checkDeprecatedXMLElements(p_u_10.xmlFile, "vehicle.pipeEffect", "vehicle.dischargeable.dischargeNode.effects")
	local v12 = Utils.getNoNil(p_u_10.configurations.dischargeable, 1)
	local v13 = string.format("vehicle.dischargeable.dischargeableConfigurations.dischargeableConfiguration(%d)", v12 - 1)
	local v14 = not p_u_10.xmlFile:hasProperty(v13) and "vehicle.dischargeable" or v13
	v_u_11.isDischargeAllowed = true
	v_u_11.dischargeNodes = {}
	v_u_11.fillUnitDischargeNodeMapping = {}
	v_u_11.dischargNodeMapping = {}
	v_u_11.triggerToDischargeNode = {}
	v_u_11.activationTriggerToDischargeNode = {}
	v_u_11.requiresTipOcclusionArea = p_u_10.xmlFile:getValue(v14 .. "#requiresTipOcclusionArea", true)
	v_u_11.consumePower = p_u_10.xmlFile:getValue(v14 .. "#consumePower", true)
	v_u_11.stopDischargeOnDeactivate = p_u_10.xmlFile:getValue(v14 .. "#stopDischargeOnDeactivate", true)
	v_u_11.dischargedLiters = 0
	p_u_10.xmlFile:iterate(v14 .. ".dischargeNode", function(_, p15)
		-- upvalues: (copy) p_u_10, (copy) v_u_11
		local v16 = {}
		if p_u_10:loadDischargeNode(p_u_10.xmlFile, p15, v16) then
			local v17
			if v_u_11.dischargNodeMapping[v16.node] == nil then
				v17 = true
			else
				Logging.xmlWarning(p_u_10.xmlFile, "DischargeNode \'%s\' already defined. Discharge nodes need to be unique. Ignoring it!", getName(v16.node))
				v17 = false
			end
			if v16.trigger.node ~= nil and v_u_11.triggerToDischargeNode[v16.trigger.node] ~= nil then
				Logging.xmlWarning(p_u_10.xmlFile, "DischargeNode trigger \'%s\' already defined. DischargeNode triggers need to be unique. Ignoring it!", getName(v16.trigger.node))
				v17 = false
			end
			if v16.activationTrigger.node ~= nil and v_u_11.activationTriggerToDischargeNode[v16.activationTrigger.node] ~= nil then
				Logging.xmlWarning(p_u_10.xmlFile, "DischargeNode activationTrigger \'%s\' already defined. DischargeNode activationTriggers need to be unique. Ignoring it!", getName(v16.activationTrigger.node))
				v17 = false
			end
			if p_u_10.getFillUnitExists ~= nil and not p_u_10:getFillUnitExists(v16.fillUnitIndex) then
				Logging.xmlWarning(p_u_10.xmlFile, "FillUnit with index \'%d\' does not exist for discharge node \'%s\'. Ignoring discharge node!", v16.fillUnitIndex, p15)
				v17 = false
			end
			if v17 then
				local v18 = v_u_11.dischargeNodes
				table.insert(v18, v16)
				v16.index = #v_u_11.dischargeNodes
				v_u_11.fillUnitDischargeNodeMapping[v16.fillUnitIndex] = v16
				v_u_11.dischargNodeMapping[v16.node] = v16
				if v16.trigger.node ~= nil then
					v_u_11.triggerToDischargeNode[v16.trigger.node] = v16
				end
				if v16.activationTrigger.node ~= nil then
					v_u_11.activationTriggerToDischargeNode[v16.activationTrigger.node] = v16
				end
			end
		end
	end)
	local v19 = v_u_11.requiresTipOcclusionArea
	if v19 then
		v19 = #v_u_11.dischargeNodes > 0
	end
	v_u_11.requiresTipOcclusionArea = v19
	v_u_11.currentDischargeState = Dischargeable.DISCHARGE_STATE_OFF
	v_u_11.currentRaycast = nil
	v_u_11.forcedFillTypeIndex = nil
	v_u_11.raycastCollisionMask = CollisionFlag.FILLABLE + CollisionFlag.VEHICLE + CollisionFlag.TERRAIN
	v_u_11.isAsyncRaycastActive = false
	v_u_11.currentRaycast = {}
	p_u_10:setCurrentDischargeNodeIndex(1)
	v_u_11.dirtyFlag = p_u_10:getNextDirtyFlag()
	if #v_u_11.dischargeNodes == 0 then
		SpecializationUtil.removeEventListener(p_u_10, "onPostLoad", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onReadStream", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onWriteStream", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onReadUpdateStream", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onWriteUpdateStream", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onUpdate", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onUpdateTick", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onRegisterActionEvents", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onFillUnitFillLevelChanged", Dischargeable)
		SpecializationUtil.removeEventListener(p_u_10, "onDeactivate", Dischargeable)
	end
end
function Dischargeable.onPostLoad(p20, p21)
	local v22 = p20.spec_dischargeable
	if p21 ~= nil and not p21.resetVehicles then
		v22.isDischargeAllowed = p21.xmlFile:getValue(p21.key .. ".dischargeable#isAllowed", v22.isDischargeAllowed)
	end
end
function Dischargeable.saveToXMLFile(p23, p24, p25, _)
	local v26 = p23.spec_dischargeable
	p24:setValue(p25 .. "#isAllowed", v26.isDischargeAllowed)
end
function Dischargeable.onRegisterDashboardValueTypes(p_u_27)
	local v28 = p_u_27.spec_dischargeable
	local v29 = DashboardValueType.new("dischargeable", "activeDischargeNode")
	v29:setValue(p_u_27, function(_, p30)
		-- upvalues: (copy) p_u_27
		local v31
		if p30.dischargeNodeIndex == nil then
			v31 = false
		else
			v31 = p_u_27:getCurrentDischargeNodeIndex() == p30.dischargeNodeIndex
		end
		return v31
	end)
	v29:setAdditionalFunctions(Dischargeable.dashboardDischargeAttributes)
	p_u_27:registerDashboardValueType(v29)
	local v32 = DashboardValueType.new("dischargeable", "dischargeState")
	v32:setValue(v28, "currentDischargeState")
	v32:setValueCompare(Dischargeable.DISCHARGE_STATE_OBJECT, Dischargeable.DISCHARGE_STATE_GROUND)
	p_u_27:registerDashboardValueType(v32)
end
function Dischargeable.onDelete(p33)
	local v34 = p33.spec_dischargeable
	if v34.dischargeNodes ~= nil then
		for _, v35 in ipairs(v34.dischargeNodes) do
			g_effectManager:deleteEffects(v35.effects)
			g_soundManager:deleteSample(v35.sample)
			g_soundManager:deleteSample(v35.dischargeSample)
			g_soundManager:deleteSamples(v35.dischargeStateSamples)
			g_animationManager:deleteAnimations(v35.animationNodes)
			g_animationManager:deleteAnimations(v35.effectAnimationNodes)
			if v35.trigger.node ~= nil then
				removeTrigger(v35.trigger.node)
			end
			if v35.activationTrigger.node ~= nil then
				removeTrigger(v35.activationTrigger.node)
			end
		end
	end
	v34.dischargeNodes = nil
end
function Dischargeable.onReadStream(p36, p37, p38)
	if p38:getIsServer() then
		local v39 = p36.spec_dischargeable
		for _, v40 in ipairs(v39.dischargeNodes) do
			if streamReadBool(p37) then
				local v41 = streamReadUIntN(p37, 8) * v40.maxDistance / 255
				v40.dischargeDistance = v41
				p36:setDischargeEffectActive(v40, true, true, (streamReadUIntN(p37, FillTypeManager.SEND_NUM_BITS)))
				p36:setDischargeEffectDistance(v40, v41)
			else
				p36:setDischargeEffectActive(v40, false, true)
			end
		end
		p36:setDischargeState(streamReadUIntN(p37, Dischargeable.SEND_NUM_BITS_DISCHARGE_STATE), true)
	end
end
function Dischargeable.onWriteStream(p42, p43, p44)
	if not p44:getIsServer() then
		local v45 = p42.spec_dischargeable
		for _, v46 in ipairs(v45.dischargeNodes) do
			if streamWriteBool(p43, v46.isEffectActiveSent) then
				local v47 = streamWriteUIntN
				local v48 = v46.dischargeDistanceSent / v46.maxDistance * 255
				local v49 = math.floor(v48)
				v47(p43, math.clamp(v49, 1, 255), 8)
				streamWriteUIntN(p43, p42:getDischargeFillType(v46), FillTypeManager.SEND_NUM_BITS)
			end
		end
		streamWriteUIntN(p43, v45.currentDischargeState, Dischargeable.SEND_NUM_BITS_DISCHARGE_STATE)
	end
end
function Dischargeable.onReadUpdateStream(p50, p51, _, p52)
	if p52:getIsServer() then
		local v53 = p50.spec_dischargeable
		if streamReadBool(p51) then
			for _, v54 in ipairs(v53.dischargeNodes) do
				if streamReadBool(p51) then
					local v55 = streamReadUIntN(p51, 8) * v54.maxDistance / 255
					v54.dischargeDistance = v55
					p50:setDischargeEffectActive(v54, true, true, (streamReadUIntN(p51, FillTypeManager.SEND_NUM_BITS)))
					p50:setDischargeEffectDistance(v54, v55)
				else
					p50:setDischargeEffectActive(v54, false, true)
				end
			end
		end
	end
end
function Dischargeable.onWriteUpdateStream(p56, p57, p58, p59)
	if not p58:getIsServer() then
		local v60 = p56.spec_dischargeable
		if streamWriteBool(p57, bitAND(p59, v60.dirtyFlag) ~= 0) then
			for _, v61 in ipairs(v60.dischargeNodes) do
				if streamWriteBool(p57, v61.isEffectActiveSent) then
					local v62 = streamWriteUIntN
					local v63 = v61.dischargeDistanceSent / v61.maxDistance * 255
					local v64 = math.floor(v63)
					v62(p57, math.clamp(v64, 1, 255), 8)
					streamWriteUIntN(p57, p56:getDischargeFillType(v61), FillTypeManager.SEND_NUM_BITS)
				end
			end
		end
	end
end
function Dischargeable.onUpdate(p65, _, _, _, _)
	local v66 = p65.spec_dischargeable
	local v67 = v66.currentDischargeNode
	if v67 ~= nil and (v67.activationTrigger.numObjects > 0 or v66.currentDischargeState ~= Dischargeable.DISCHARGE_STATE_OFF) then
		p65:raiseActive()
	end
end
function Dischargeable.onUpdateTick(p68, p69, _, p70, _)
	local v71 = p68.spec_dischargeable
	local v72 = v71.currentDischargeNode
	if v72 ~= nil then
		if p68.isClient then
			Dischargeable.updateActionEvents(p68)
		end
		if p68:getIsDischargeNodeActive(v72) then
			local v73 = v72.trigger
			if v73.numObjects > 0 then
				local v74 = v72.dischargeObject
				v72.dischargeObject = nil
				v72.dischargeHitObject = nil
				v72.dischargeHitObjectUnitIndex = nil
				v72.dischargeHitTerrain = false
				v72.dischargeShape = nil
				v72.dischargeDistance = 0
				v72.dischargeFillUnitIndex = nil
				v72.dischargeHit = false
				local v75 = (1 / 0)
				for v76, v77 in pairs(v73.objects) do
					local v78 = v71.forcedFillTypeIndex
					if v78 == nil then
						v78 = p68:getDischargeFillType(v72)
					end
					local v79 = nil
					local v80 = false
					local v81 = nil
					local v82
					if v76:getFillUnitSupportsFillType(v77.fillUnitIndex, v78) then
						local v83 = v76:getFillUnitAllowsFillType(v77.fillUnitIndex, v78)
						local v84 = v76:getFillUnitSupportsToolType(v77.fillUnitIndex, ToolType.TRIGGER)
						local v85 = v76:getFillUnitFreeCapacity(v77.fillUnitIndex, v78, p68:getActiveFarm()) > 0
						local v86 = v76:getIsFillAllowedFromFarm(p68:getActiveFarm())
						if v83 and (v84 and v85) then
							local v87 = v76:getFillUnitExactFillRootNode(v77.fillUnitIndex)
							if v87 == nil or not entityExists(v87) then
								v82 = v75
							else
								v82 = calcDistanceFrom(v72.node, v87)
								if v82 < v75 then
									v72.dischargeObject = v76
									v72.dischargeHitTerrain = false
									v72.dischargeShape = v77.shape
									v72.dischargeDistance = v82
									v72.dischargeFillUnitIndex = v77.fillUnitIndex
									if v76 ~= v74 then
										SpecializationUtil.raiseEvent(p68, "onDischargeTargetObjectChanged", v76)
										p68.rootVehicle:raiseActive()
									end
								else
									v82 = v75
								end
							end
						elseif v83 then
							if v84 then
								if v86 then
									if v85 then
										v82 = v75
									else
										v79 = Dischargeable.DISCHARGE_REASON_NO_FREE_CAPACITY
										v82 = v75
									end
								else
									v79 = Dischargeable.DISCHARGE_REASON_NO_ACCESS
									v82 = v75
								end
							else
								v79 = Dischargeable.DISCHARGE_REASON_TOOLTYPE_NOT_SUPPORTED
								v82 = v75
							end
						else
							v79 = Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED
							v82 = v75
						end
						v72.dischargeHitObject = v76
						v72.dischargeHitObjectUnitIndex = v77.fillUnitIndex
					elseif v78 == FillType.UNKNOWN then
						v82 = v75
					else
						v79 = Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED
						v82 = v75
					end
					if v79 == Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED or (v79 == Dischargeable.DISCHARGE_REASON_NO_FREE_CAPACITY or v79 == Dischargeable.DISCHARGE_REASON_NO_ACCESS) then
						v80 = (v76.isa == nil or not v76:isa(Vehicle)) and true or v80
					end
					if v79 ~= nil and (v79 ~= Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED and v76.getCustomDischargeNotAllowedWarning ~= nil) then
						v81 = v76:getCustomDischargeNotAllowedWarning()
					end
					if v72.dischargeObject == nil and v79 ~= nil then
						if v72.dischargeFailedReason == nil or v79 < v72.dischargeFailedReason then
							v72.dischargeFailedReason = v79
							v72.dischargeFailedReasonShowAuto = v80
							v72.customNotAllowedWarning = v81
						end
					else
						v72.dischargeFailedReason = nil
						v72.dischargeFailedReasonShowAuto = false
						v72.customNotAllowedWarning = nil
					end
					v72.dischargeHit = true
					v75 = v82
				end
				if v74 ~= nil and v72.dischargeObject == nil then
					SpecializationUtil.raiseEvent(p68, "onDischargeTargetObjectChanged", nil)
					p68.rootVehicle:raiseActive()
				end
			elseif not v71.isAsyncRaycastActive then
				p68:updateRaycast(v72)
			end
		else
			if v71.currentDischargeState ~= Dischargeable.DISCHARGE_STATE_OFF then
				p68:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF, true)
			end
			if v72.dischargeObject ~= nil then
				SpecializationUtil.raiseEvent(p68, "onDischargeTargetObjectChanged", nil)
				p68.rootVehicle:raiseActive()
			end
			v72.dischargeObject = nil
			v72.dischargeHitObject = nil
			v72.dischargeHitObjectUnitIndex = nil
			v72.dischargeHitTerrain = false
			v72.dischargeShape = nil
			v72.dischargeDistance = 0
			v72.dischargeFillUnitIndex = nil
			v72.dischargeHit = false
		end
		p68:updateDischargeSound(v72, p69)
		if p68.isServer then
			if v71.currentDischargeState == Dischargeable.DISCHARGE_STATE_OFF then
				if v72.dischargeObject ~= nil then
					p68:handleFoundDischargeObject(v72)
				end
			else
				local v88 = p68:getFillUnitFillLevel(v72.fillUnitIndex)
				local v89 = p68:getDischargeNodeEmptyFactor(v72)
				local v90 = p68:getCanDischargeToObject(v72)
				if v90 then
					v90 = v71.currentDischargeState == Dischargeable.DISCHARGE_STATE_OBJECT
				end
				local v91 = p68:getCanDischargeToGround(v72)
				if v91 then
					v91 = v71.currentDischargeState == Dischargeable.DISCHARGE_STATE_GROUND
				end
				local v92 = v90 or v91
				local v93 = v72.dischargeObject == nil and p68:getCanDischargeToLand(v72)
				if v93 then
					v93 = p68:getCanDischargeAtPosition(v72)
				end
				local v94
				if v88 > 0 and v89 > 0 then
					if v93 then
						v94 = v92
					else
						v94 = v93
					end
				else
					v94 = false
				end
				p68:setDischargeEffectActive(v72, v94)
				p68:setDischargeEffectDistance(v72, v72.dischargeDistance)
				if (v72.lastEffect == nil and true or v72.lastEffect:getIsFullyVisible()) and (v93 and v92) then
					local v95 = v72.emptySpeed * v89 * p69
					local v96, v97, v98 = p68:discharge(v72, (math.min(v88, v95)))
					v71.dischargedLiters = v96
					p68:handleDischarge(v72, v96, v97, v98)
				end
			end
			local v99 = v72.dischargeDistanceSent - v72.dischargeDistance
			if math.abs(v99) > 0.05 then
				p68:raiseDirtyFlags(v71.dirtyFlag)
				v72.dischargeDistanceSent = v72.dischargeDistance
			end
		end
	end
	if v71.currentDischargeState == Dischargeable.DISCHARGE_STATE_OFF then
		local v100 = v71.currentDischargeNode
		if p68:getIsActiveForInput() and (p68:getCanDischargeToObject(v100) and p68:getCanToggleDischargeToObject()) then
			g_currentMission:showTipContext(p68:getFillUnitFillType(v72.fillUnitIndex))
		end
	end
	if p70 and (v72 ~= nil and (v72.canStartDischargeAutomatically and (v72.dischargeHit and (v72.dischargeFailedReasonShowAuto and (v72.dischargeFailedReason ~= nil and g_currentMission.time > 10000))))) then
		local v101 = p68:getDischargeNotAllowedWarning(v72)
		g_currentMission:showBlinkingWarning(v101, 5000)
	end
	if p68.isServer then
		for _, v102 in ipairs(v71.dischargeNodes) do
			if v102.stopEffectTime ~= nil then
				if v102.stopEffectTime < g_time then
					p68:setDischargeEffectActive(v102, false, true)
					v102.stopEffectTime = nil
				else
					p68:raiseActive()
				end
			end
		end
	end
end
function Dischargeable.loadDischargeNode(p103, p104, p105, p106)
	p106.isActive = true
	p106.node = p104:getValue(p105 .. "#node", nil, p103.components, p103.i3dMappings)
	if p106.node == nil then
		Logging.xmlWarning(p103.xmlFile, "Missing discharge \'node\' for dischargeNode \'%s\'", p105)
		return false
	end
	p106.fillUnitIndex = p104:getValue(p105 .. "#fillUnitIndex")
	if p106.fillUnitIndex == nil then
		Logging.xmlWarning(p103.xmlFile, "Missing \'fillUnitIndex\' for dischargeNode \'%s\'", p105)
		return false
	end
	p106.unloadInfoIndex = p104:getValue(p105 .. "#unloadInfoIndex", 1)
	p106.stopDischargeOnEmpty = p104:getValue(p105 .. "#stopDischargeOnEmpty", true)
	p106.canDischargeToGround = p104:getValue(p105 .. "#canDischargeToGround", true)
	p106.canDischargeToObject = p104:getValue(p105 .. "#canDischargeToObject", true)
	p106.canDischargeToVehicle = p104:getValue(p105 .. "#canDischargeToVehicle", p106.canDischargeToObject)
	p106.canStartDischargeAutomatically = p104:getValue(p105 .. "#canStartDischargeAutomatically", Platform.gameplay.automaticDischarge)
	p106.canStartGroundDischargeAutomatically = p104:getValue(p105 .. "#canStartGroundDischargeAutomatically", false)
	p106.stopDischargeIfNotPossible = p104:getValue(p105 .. "#stopDischargeIfNotPossible", p104:hasProperty(p105 .. ".trigger#node"))
	p106.canDischargeToGroundAnywhere = p104:getValue(p105 .. "#canDischargeToGroundAnywhere", false)
	p106.emptySpeed = p104:getValue(p105 .. "#emptySpeed", p103:getFillUnitCapacity(p106.fillUnitIndex)) / 1000 * Platform.gameplay.dischargeSpeedFactor
	p106.effectTurnOffThreshold = p104:getValue(p105 .. "#effectTurnOffThreshold", 0.25)
	p106.lineOffset = 0
	p106.litersToDrop = 0
	local v107 = p104:getValue(p105 .. "#toolType", "dischargeable")
	p106.toolType = g_toolTypeManager:getToolTypeIndexByName(v107)
	p106.info = {}
	p106.info.node = p104:getValue(p105 .. ".info#node", p106.node, p103.components, p103.i3dMappings)
	if p106.info.node == p106.node then
		p106.info.node = createTransformGroup("dischargeInfoNode")
		link(p106.node, p106.info.node)
	end
	p106.info.width = p104:getValue(p105 .. ".info#width", 1) / 2
	p106.info.length = p104:getValue(p105 .. ".info#length", 1) / 2
	p106.info.zOffset = p104:getValue(p105 .. ".info#zOffset", 0)
	p106.info.yOffset = p104:getValue(p105 .. ".info#yOffset", 2)
	p106.info.limitToGround = p104:getValue(p105 .. ".info#limitToGround", true)
	p106.info.useRaycastHitPosition = p104:getValue(p105 .. ".info#useRaycastHitPosition", false)
	p106.raycast = {}
	p106.raycast.node = p104:getValue(p105 .. ".raycast#node", p106.node, p103.components, p103.i3dMappings)
	p106.raycast.useWorldNegYDirection = p104:getValue(p105 .. ".raycast#useWorldNegYDirection", false)
	p106.raycast.yOffset = p104:getValue(p105 .. ".raycast#yOffset", 0)
	local v108 = p104:getValue(p105 .. ".raycast#maxDistance")
	p106.maxDistance = p104:getValue(p105 .. "#maxDistance", v108) or 10
	p106.dischargeObject = nil
	p106.dischargeHitObject = nil
	p106.dischargeHitObjectUnitIndex = nil
	p106.dischargeHitTerrain = false
	p106.dischargeShape = nil
	p106.dischargeDistance = 0
	p106.dischargeDistanceSent = 0
	p106.dischargeFillUnitIndex = nil
	p106.dischargeHit = false
	p106.trigger = {}
	p106.trigger.node = p104:getValue(p105 .. ".trigger#node", nil, p103.components, p103.i3dMappings)
	if p106.trigger.node ~= nil then
		addTrigger(p106.trigger.node, "dischargeTriggerCallback", p103)
	end
	p106.trigger.objects = {}
	p106.trigger.numObjects = 0
	p106.activationTrigger = {}
	p106.activationTrigger.node = p104:getValue(p105 .. ".activationTrigger#node", nil, p103.components, p103.i3dMappings)
	if p106.activationTrigger.node ~= nil then
		addTrigger(p106.activationTrigger.node, "dischargeActivationTriggerCallback", p103)
	end
	p106.activationTrigger.objects = {}
	p106.activationTrigger.numObjects = 0
	local v109 = p104:getValue(p105 .. ".fillType#converterName")
	if v109 ~= nil then
		p106.fillTypeConverter = g_fillTypeManager:getConverterDataByName(v109)
	end
	p106.distanceObjectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p104, p105 .. ".distanceObjectChanges", p106.distanceObjectChanges, p103.components, p103)
	if #p106.distanceObjectChanges == 0 then
		p106.distanceObjectChanges = nil
	else
		p106.distanceObjectChangeThreshold = p104:getValue(p105 .. ".distanceObjectChanges#threshold", 0.5)
		ObjectChangeUtil.setObjectChanges(p106.distanceObjectChanges, false, p103, p103.setMovingToolDirty)
	end
	p106.stateObjectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p104, p105 .. ".stateObjectChanges", p106.stateObjectChanges, p103.components, p103)
	if #p106.stateObjectChanges == 0 then
		p106.stateObjectChanges = nil
	else
		ObjectChangeUtil.setObjectChanges(p106.stateObjectChanges, false, p103, p103.setMovingToolDirty)
	end
	p106.nodeActiveObjectChanges = {}
	ObjectChangeUtil.loadObjectChangeFromXML(p104, p105 .. ".nodeActiveObjectChanges", p106.nodeActiveObjectChanges, p103.components, p103)
	if #p106.nodeActiveObjectChanges == 0 then
		p106.nodeActiveObjectChanges = nil
	else
		ObjectChangeUtil.setObjectChanges(p106.nodeActiveObjectChanges, false, p103, p103.setMovingToolDirty)
	end
	p106.effects = g_effectManager:loadEffect(p104, p105 .. ".effects", p103.components, p103, p103.i3dMappings)
	p106.animationName = p104:getValue(p105 .. ".animation#name")
	p106.animationSpeed = p104:getValue(p105 .. ".animation#speed", 1)
	p106.animationResetSpeed = p104:getValue(p105 .. ".animation#resetSpeed", 1)
	if p103.isClient then
		p106.playSound = p104:getValue(p105 .. "#playSound", true)
		p106.soundNode = p104:getValue(p105 .. "#soundNode", nil, p103.components, p103.i3dMappings)
		if p106.playSound then
			p106.dischargeSample = g_soundManager:loadSampleFromXML(p103.xmlFile, p105, "dischargeSound", p103.baseDirectory, p103.components, 0, AudioGroup.VEHICLE, p103.i3dMappings, p103)
		end
		if p104:getValue(p105 .. ".dischargeSound#overwriteSharedSound", false) then
			p106.playSound = false
		end
		p106.dischargeStateSamples = g_soundManager:loadSamplesFromXML(p103.xmlFile, p105, "dischargeStateSound", p103.baseDirectory, p103.components, 0, AudioGroup.VEHICLE, p103.i3dMappings, p103)
		p106.animationNodes = g_animationManager:loadAnimations(p103.xmlFile, p105 .. ".animationNodes", p103.components, p103, p103.i3dMappings)
		p106.effectAnimationNodes = g_animationManager:loadAnimations(p103.xmlFile, p105 .. ".effectAnimationNodes", p103.components, p103, p103.i3dMappings)
	end
	p106.sentHitDistance = 0
	p106.isEffectActive = false
	p106.isEffectActiveSent = false
	p106.lastEffect = p106.effects[#p106.effects]
	return true
end
function Dischargeable.setCurrentDischargeNodeIndex(p110, p111)
	local v112 = p110.spec_dischargeable
	if v112.currentDischargeNode ~= nil and v112.dischargeNodes[p111] ~= v112.currentDischargeNode then
		p110:setDischargeEffectActive(v112.currentDischargeNode, false, true)
		p110:updateDischargeSound(v112.currentDischargeNode, 99999)
		if v112.dischargeNodes[p111] ~= v112.currentDischargeNode then
			g_animationManager:stopAnimations(v112.currentDischargeNode.animationNodes)
			g_animationManager:stopAnimations(v112.currentDischargeNode.effectAnimationNodes)
		end
		g_soundManager:stopSamples(v112.currentDischargeNode.dischargeStateSamples)
	end
	v112.currentDischargeNode = v112.dischargeNodes[p111]
	for v113 = 1, #v112.dischargeNodes do
		local v114 = v112.dischargeNodes[v113]
		if v114.nodeActiveObjectChanges ~= nil then
			ObjectChangeUtil.setObjectChanges(v114.nodeActiveObjectChanges, v113 == p111, p110, p110.setMovingToolDirty)
		end
	end
	if p110.setDashboardsDirty ~= nil then
		p110:setDashboardsDirty()
	end
	p110:handleDischargeNodeChanged()
end
function Dischargeable.getCurrentDischargeNode(p115)
	return p115.spec_dischargeable.currentDischargeNode
end
function Dischargeable.getCurrentDischargeNodeIndex(p116)
	local v117 = p116.spec_dischargeable
	return v117.currentDischargeNode == nil and 0 or v117.currentDischargeNode.index
end
function Dischargeable.getDischargeTargetObject(_, p118)
	return p118.dischargeObject, p118.dischargeFillUnitIndex
end
function Dischargeable.getCurrentDischargeObject(_, p119)
	return p119.currentDischargeObject
end
function Dischargeable.getRequiresTipOcclusionArea(p120)
	return p120.spec_dischargeable.requiresTipOcclusionArea
end
function Dischargeable.getCanBeSelected(_, _)
	return true
end
function Dischargeable.getDoConsumePtoPower(p121, p122)
	return p121.spec_dischargeable.consumePower and p121:getDischargeState() ~= Dischargeable.DISCHARGE_STATE_OFF and true or p122(p121)
end
function Dischargeable.getIsPowerTakeOffActive(p123, p124)
	return p123.spec_dischargeable.consumePower and p123:getDischargeState() ~= Dischargeable.DISCHARGE_STATE_OFF and true or p124(p123)
end
function Dischargeable.getAllowLoadTriggerActivation(p125, p126, p127)
	if p126(p125, p127) then
		return true
	end
	local v128 = p125.spec_dischargeable
	if v128.currentDischargeNode ~= nil then
		local v129 = v128.currentDischargeNode.dischargeHitObject
		if v129 ~= nil and v129.getAllowLoadTriggerActivation ~= nil then
			if v129 == p127 then
				return false
			else
				return v129:getAllowLoadTriggerActivation(p127)
			end
		end
	end
	return false
end
function Dischargeable.discharge(p130, p131, p132)
	local v133 = p130.spec_dischargeable
	local v134 = 0
	local v135 = true
	local v136 = true
	local v137, v138 = p130:getDischargeTargetObject(p131)
	p131.currentDischargeObject = nil
	if v137 == nil then
		if p131.dischargeHitTerrain and v133.currentDischargeState == Dischargeable.DISCHARGE_STATE_GROUND then
			v134, v135, v136 = p130:dischargeToGround(p131, p132)
		end
	elseif v133.currentDischargeState == Dischargeable.DISCHARGE_STATE_OBJECT then
		return p130:dischargeToObject(p131, p132, v137, v138), v135, v136
	end
	return v134, v135, v136
end
function Dischargeable.dischargeToGround(p139, p140, p141)
	if p141 == 0 then
		return 0, false, false
	end
	local v142, v143 = p139:getDischargeFillType(p140)
	local v144 = p139:getFillUnitFillLevel(p140.fillUnitIndex)
	local v145 = g_densityMapHeightManager:getMinValidLiterValue(v142)
	local v146 = p140.litersToDrop + p141
	local v147 = p140.emptySpeed * 250
	local v148 = math.max(v147, v145)
	p140.litersToDrop = math.min(v146, v148)
	local v149 = v145 < p140.litersToDrop
	local v150 = v145 < v144
	local v151 = p140.info
	local v152 = 0
	local v153, v154, v155 = localToWorld(v151.node, -v151.width, 0, v151.zOffset)
	local v156, v157, v158 = localToWorld(v151.node, v151.width, 0, v151.zOffset)
	local v159 = v154 + v151.yOffset
	local v160 = v157 + v151.yOffset
	if v151.limitToGround then
		local v161 = getTerrainHeightAtWorldPos(g_terrainNode, v153, 0, v155) + 0.1
		v159 = math.max(v161, v159)
		local v162 = getTerrainHeightAtWorldPos(g_terrainNode, v156, 0, v158) + 0.1
		v160 = math.max(v162, v160)
	end
	local v163, v164 = DensityMapHeightUtil.tipToGroundAroundLine(p139, p140.litersToDrop * v143, v142, v153, v159, v155, v156, v160, v158, v151.length, nil, p140.lineOffset, true, nil, true)
	local v165 = v163 / v143
	p140.lineOffset = v164
	p140.litersToDrop = p140.litersToDrop - v165
	if v165 > 0 then
		local v166 = p139:getFillVolumeUnloadInfo(p140.unloadInfoIndex)
		v152 = p139:addFillUnitFillLevel(p139:getOwnerFarmId(), p140.fillUnitIndex, -v165, p139:getFillUnitFillType(p140.fillUnitIndex), ToolType.UNDEFINED, v166)
	end
	local v167 = p139:getFillUnitFillLevel(p140.fillUnitIndex)
	if v167 > 0 and v167 <= v145 then
		p140.litersToDrop = v145
	end
	return v152, v149, v150
end
function Dischargeable.dischargeToObject(p168, p169, p170, p171, p172)
	local v173, v174 = p168:getDischargeFillType(p169)
	local v175
	if p171:getFillUnitSupportsFillType(p172, v173) and p171:getFillUnitAllowsFillType(p172, v173) then
		p169.currentDischargeObject = p171
		local v176 = p171:addFillUnitFillLevel(p168:getActiveFarm(), p172, p170 * v174, v173, p169.toolType, p169.info) / v174
		local v177 = p168:getFillVolumeUnloadInfo(p169.unloadInfoIndex)
		v175 = p168:addFillUnitFillLevel(p168:getOwnerFarmId(), p169.fillUnitIndex, -v176, p168:getFillUnitFillType(p169.fillUnitIndex), ToolType.UNDEFINED, v177)
	else
		v175 = 0
	end
	return v175
end
function Dischargeable.setManualDischargeState(p178, p179, p180)
	p178:setDischargeState(p179, p180)
end
function Dischargeable.setDischargeState(p181, p182, p183)
	local v184 = p181.spec_dischargeable
	if p182 ~= v184.currentDischargeState then
		SetDischargeStateEvent.sendEvent(p181, p182, p183)
		v184.currentDischargeState = p182
		local v185 = v184.currentDischargeNode
		if p182 == Dischargeable.DISCHARGE_STATE_OFF then
			if p181.isServer then
				p181:setDischargeEffectActive(v185, false)
			end
			g_animationManager:stopAnimations(v185.animationNodes)
			g_soundManager:stopSamples(v185.dischargeStateSamples)
		else
			g_animationManager:startAnimations(v185.animationNodes)
			g_soundManager:playSamples(v185.dischargeStateSamples)
		end
		for v186 = 1, #v184.dischargeNodes do
			local v187 = v184.dischargeNodes[v186]
			if v187.stateObjectChanges ~= nil then
				local v188 = ObjectChangeUtil.setObjectChanges
				local v189 = v187.stateObjectChanges
				local v190
				if p182 == Dischargeable.DISCHARGE_STATE_OFF then
					v190 = false
				else
					v190 = v187 == v185
				end
				v188(v189, v190, p181, p181.setMovingToolDirty)
			end
		end
		if v185.animationName ~= nil then
			if p182 == Dischargeable.DISCHARGE_STATE_OFF then
				p181:playAnimation(v185.animationName, -v185.animationResetSpeed, p181:getAnimationTime(v185.animationName), true)
			else
				p181:playAnimation(v185.animationName, v185.animationSpeed, p181:getAnimationTime(v185.animationName), true)
			end
		end
		if p181.setDashboardsDirty ~= nil then
			p181:setDashboardsDirty()
		end
		SpecializationUtil.raiseEvent(p181, "onDischargeStateChanged", p182)
	end
end
function Dischargeable.getDischargeState(p191)
	return p191.spec_dischargeable.currentDischargeState
end
function Dischargeable.getDischargeFillType(p192, p193)
	local v194 = p192:getFillUnitFillType(p193.fillUnitIndex)
	local v195 = 1
	if p193.fillTypeConverter ~= nil then
		local v196 = p193.fillTypeConverter[v194]
		if v196 ~= nil then
			v194 = v196.targetFillTypeIndex
			v195 = v196.conversionFactor
		end
	end
	return v194, v195
end
function Dischargeable.getCanDischargeToGround(p197, p198)
	if p197.spec_dischargeable.isDischargeAllowed then
		if p198 == nil then
			return false
		elseif p198.dischargeHitTerrain then
			if p197:getFillUnitFillLevel(p198.fillUnitIndex) > 0 then
				local v199 = p197:getDischargeFillType(p198)
				if not DensityMapHeightUtil.getCanTipToGround(v199) then
					return false
				end
			end
			if p197:getCanDischargeToLand(p198) then
				return p197:getCanDischargeAtPosition(p198) and true or false
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end
end
function Dischargeable.getCanDischargeToLand(p200, p201)
	if p201 == nil then
		return false
	elseif p201.canDischargeToGroundAnywhere then
		return true
	else
		local v202 = p201.info
		local v203, _, v204 = localToWorld(v202.node, -v202.width, 0, v202.zOffset)
		local v205, _, v206 = localToWorld(v202.node, v202.width, 0, v202.zOffset)
		local v207 = p200:getActiveFarm()
		if g_currentMission.accessHandler:canFarmAccessLand(v207, v203, v204) then
			return g_currentMission.accessHandler:canFarmAccessLand(v207, v205, v206) and true or false
		else
			return false
		end
	end
end
function Dischargeable.getCanDischargeAtPosition(p208, p209)
	if p209 == nil then
		return false
	end
	if p208:getFillUnitFillLevel(p209.fillUnitIndex) > 0 then
		local v210 = p209.info
		local v211, v212, v213 = localToWorld(v210.node, -v210.width, 0, v210.zOffset)
		local v214, v215, v216 = localToWorld(v210.node, v210.width, 0, v210.zOffset)
		local v217 = p208.spec_dischargeable
		if v217.currentDischargeState == Dischargeable.DISCHARGE_STATE_OFF or v217.currentDischargeState == Dischargeable.DISCHARGE_STATE_GROUND then
			local v218 = v212 + v210.yOffset
			local v219 = v215 + v210.yOffset
			if v210.limitToGround then
				local v220 = getTerrainHeightAtWorldPos(g_terrainNode, v211, 0, v213) + 0.1
				v218 = math.max(v220, v218)
				local v221 = getTerrainHeightAtWorldPos(g_terrainNode, v214, 0, v216) + 0.1
				v219 = math.max(v221, v219)
			end
			local v222 = p208:getDischargeFillType(p209)
			local v223 = g_densityMapHeightManager:getMinValidLiterValue(v222)
			if not DensityMapHeightUtil.getCanTipToGroundAroundLine(p208, v223, v222, v211, v218, v213, v214, v219, v216, v210.length, nil, p209.lineOffset, true, nil, true) then
				return false
			end
		end
	end
	return true
end
function Dischargeable.getCanDischargeToObject(p224, p225)
	if not p224.spec_dischargeable.isDischargeAllowed then
		return false
	end
	if p225 == nil then
		return false
	end
	local v226 = p225.dischargeObject
	if v226 == nil then
		return false
	end
	local v227 = p224:getDischargeFillType(p225)
	if not v226:getFillUnitSupportsFillType(p225.dischargeFillUnitIndex, v227) then
		return false
	end
	if not v226:getFillUnitAllowsFillType(p225.dischargeFillUnitIndex, v227) then
		return false
	end
	if v226.getFillUnitFreeCapacity ~= nil and v226:getFillUnitFreeCapacity(p225.dischargeFillUnitIndex, v227, p224:getActiveFarm()) <= 0 then
		return false
	end
	if v226.getIsFillAllowedFromFarm ~= nil and not v226:getIsFillAllowedFromFarm(p224:getActiveFarm()) then
		return false
	end
	if p224.getMountObject ~= nil then
		local v228 = p224:getDynamicMountObject() or p224:getMountObject()
		if v228 ~= nil and not g_currentMission.accessHandler:canFarmAccess(v228:getActiveFarm(), p224, true) then
			return false
		end
	end
	return true
end
function Dischargeable.getDischargeNotAllowedWarning(p229, p230)
	local v231 = g_i18n:getText(Dischargeable.DISCHARGE_WARNINGS[p230.dischargeFailedReason or Dischargeable.DISCHARGE_REASON_NOT_ALLOWED_HERE] or "warning_actionNotAllowedHere")
	if p230.customNotAllowedWarning ~= nil then
		v231 = p230.customNotAllowedWarning
	end
	local v232 = p229:getDischargeFillType(p230)
	local v233 = g_fillTypeManager:getFillTypeByIndex(v232)
	return string.format(v231, v233.title)
end
function Dischargeable.getCanToggleDischargeToObject(p234)
	local v235 = p234.spec_dischargeable.currentDischargeNode
	local v236
	if v235 == nil then
		v236 = false
	else
		v236 = v235.canDischargeToObject
	end
	return v236
end
function Dischargeable.getCanToggleDischargeToGround(p237)
	local v238 = p237.spec_dischargeable.currentDischargeNode
	local v239 = v238 ~= nil and v238.canDischargeToGround
	if v239 then
		v239 = not v238.canStartGroundDischargeAutomatically
	end
	return v239
end
function Dischargeable.getIsPossibleToDischargeToObject(p240)
	local v241 = p240.spec_dischargeable
	if v241.currentDischargeState ~= Dischargeable.DISCHARGE_STATE_OFF then
		return false
	end
	local v242 = v241.currentDischargeNode
	local v243 = p240:getIsActiveForInput() and p240:getCanDischargeToObject(v242)
	if v243 then
		v243 = p240:getCanToggleDischargeToObject()
	end
	return v243
end
function Dischargeable.getIsDischargeNodeActive(p244, _)
	return p244.spec_dischargeable.isDischargeAllowed
end
function Dischargeable.setIsDischargeAllowed(p245, p246)
	p245.spec_dischargeable.isDischargeAllowed = p246
end
function Dischargeable.getDischargeNodeEmptyFactor(_, _)
	return 1
end
function Dischargeable.getDischargeNodeAutomaticDischarge(_, p247)
	return p247.canStartDischargeAutomatically
end
function Dischargeable.getDischargeNodeByNode(p248, p249)
	return p248.spec_dischargeable.dischargNodeMapping[p249]
end
function Dischargeable.updateRaycast(p250, p251)
	local v252 = p250.spec_dischargeable
	local v253 = p251.raycast
	if v253.node ~= nil then
		p251.lastDischargeObject = p251.dischargeObject
		p251.dischargeObject = nil
		p251.dischargeHitObject = nil
		p251.dischargeHitObjectUnitIndex = nil
		p251.dischargeHitTerrain = false
		p251.dischargeShape = nil
		p251.dischargeDistance = (1 / 0)
		p251.dischargeFillUnitIndex = nil
		p251.dischargeHit = false
		p251.dischargeFailedReason = nil
		local v254, v255, v256 = getWorldTranslation(v253.node)
		local v257 = v255 + v253.yOffset
		local v258, v259, v260
		if v253.useWorldNegYDirection then
			v258 = 0
			v259 = 0
			v260 = -1
		else
			v259, v260, v258 = localDirectionToWorld(v253.node, 0, -1, 0)
		end
		v252.currentRaycastDischargeNode = p251
		v252.currentRaycast = v253
		v252.isAsyncRaycastActive = true
		raycastAll(v254, v257, v256, v259, v260, v258, p251.maxDistance, "raycastCallbackDischargeNode", p250, v252.raycastCollisionMask)
		if VehicleDebug.state == VehicleDebug.DEBUG then
			drawDebugLine(v254, v257, v256, 0, 1, 0, v254 + v259 * p251.maxDistance, v257 + v260 * p251.maxDistance, v256 + v258 * p251.maxDistance, 0, 1, 0, true)
		end
		p250:raycastCallbackDischargeNode(nil)
	end
end
function Dischargeable.updateDischargeInfo(_, p261, p262, p263, p264)
	if p261.info.useRaycastHitPosition then
		setWorldTranslation(p261.info.node, p262, p263, p264)
	end
end
function Dischargeable.raycastCallbackDischargeNode(p265, p266, p267, p268, p269, p270, _, _, _, _, p271)
	if p266 ~= nil then
		local v272 = p265.spec_dischargeable
		local v273 = v272.currentRaycastDischargeNode
		local v274 = g_currentMission:getNodeObject(p266)
		local v275 = p270 - v273.raycast.yOffset
		if VehicleDebug.state == VehicleDebug.DEBUG then
			DebugGizmo.renderAtPositionSimple(p267, p268, p269, string.format("hitActorId %s; hitShape %s; object %s", getName(p266), getName(p271), v274))
		end
		local v276
		if v274 == nil then
			v276 = false
		else
			v276 = v274 ~= p265
		end
		if v276 and v275 < 0 then
			if v274.getFillUnitIndexFromNode ~= nil then
				if v276 then
					v276 = v274:getFillUnitIndexFromNode(p271) ~= nil
				end
			end
			if not v273.canDischargeToVehicle then
				if v276 then
					v276 = not v274:isa(Vehicle)
				end
			end
		end
		if v276 then
			if v274.getFillUnitIndexFromNode ~= nil then
				local v277 = v274:getFillUnitIndexFromNode(p271)
				if v277 == nil then
					if v273.dischargeHit then
						v273.dischargeDistance = v275 + (v273.dischargeExtraDistance or 0)
						v273.dischargeExtraDistance = nil
						p265:updateDischargeInfo(v273, p267, p268, p269)
						return false
					end
				else
					local v278 = v272.forcedFillTypeIndex
					if v278 == nil then
						v278 = p265:getDischargeFillType(v273)
					end
					local v279 = nil
					local v280 = false
					local v281 = nil
					if v274:getFillUnitSupportsFillType(v277, v278) then
						local v282 = v274:getFillUnitAllowsFillType(v277, v278)
						local v283 = v274:getFillUnitSupportsToolType(v277, v273.toolType)
						local v284 = v274:getFillUnitFreeCapacity(v277, v278, p265:getActiveFarm()) > 0
						local v285 = v274:getIsFillAllowedFromFarm(p265:getActiveFarm())
						if v282 and (v283 and v284) then
							v273.dischargeObject = v274
							v273.dischargeShape = p271
							v273.dischargeDistance = v275
							v273.dischargeFillUnitIndex = v277
							if v274.getFillUnitExtraDistanceFromNode ~= nil then
								v273.dischargeExtraDistance = v274:getFillUnitExtraDistanceFromNode(p271)
							end
						elseif v282 then
							if v283 then
								if v285 then
									if not v284 then
										v279 = Dischargeable.DISCHARGE_REASON_NO_FREE_CAPACITY
									end
								else
									v279 = Dischargeable.DISCHARGE_REASON_NO_ACCESS
								end
							else
								v279 = Dischargeable.DISCHARGE_REASON_TOOLTYPE_NOT_SUPPORTED
							end
						else
							v279 = Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED
						end
					elseif v278 ~= FillType.UNKNOWN then
						v279 = Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED
					end
					if v279 == Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED or (v279 == Dischargeable.DISCHARGE_REASON_NO_FREE_CAPACITY or v279 == Dischargeable.DISCHARGE_REASON_NO_ACCESS) then
						v280 = (v274.isa == nil or not v274:isa(Vehicle)) and true or v280
					end
					if v279 ~= nil and (v279 ~= Dischargeable.DISCHARGE_REASON_FILLTYPE_NOT_SUPPORTED and v274.getCustomDischargeNotAllowedWarning ~= nil) then
						v281 = v274:getCustomDischargeNotAllowedWarning()
					end
					if v273.dischargeObject == nil and v279 ~= nil then
						if v273.dischargeFailedReason == nil or v279 < v273.dischargeFailedReason then
							v273.dischargeFailedReason = v279
							v273.dischargeFailedReasonShowAuto = v280
							v273.customNotAllowedWarning = v281
						end
					else
						v273.dischargeFailedReason = nil
						v273.dischargeFailedReasonShowAuto = false
						v273.customNotAllowedWarning = nil
					end
					v273.dischargeHit = true
					v273.dischargeHitObject = v274
					v273.dischargeHitObjectUnitIndex = v277
				end
			end
		elseif p266 == g_terrainNode then
			local v286 = v273.dischargeDistance
			v273.dischargeDistance = math.min(v286, v275)
			v273.dischargeHitTerrain = true
			p265:updateDischargeInfo(v273, p267, p268, p269)
			return false
		end
		return true
	end
	p265:finishDischargeRaycast()
end
function Dischargeable.finishDischargeRaycast(p287)
	local v288 = p287.spec_dischargeable
	local v289 = v288.currentRaycastDischargeNode
	p287:handleDischargeRaycast(v289, v289.dischargeObject, v289.dischargeShape, v289.dischargeDistance, v289.dischargeFillUnitIndex, v289.dischargeHitTerrain)
	v288.isAsyncRaycastActive = false
	if v289.lastDischargeObject ~= v289.dischargeObject then
		SpecializationUtil.raiseEvent(p287, "onDischargeTargetObjectChanged", v289.dischargeObject)
		p287.rootVehicle:raiseActive()
	end
end
function Dischargeable.getDischargeNodeByIndex(p290, p291)
	return p290.spec_dischargeable.dischargeNodes[p291]
end
function Dischargeable.handleDischargeOnEmpty(p292, _)
	if p292.spec_dischargeable.currentDischargeNode.stopDischargeOnEmpty then
		p292:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF, true)
	end
end
function Dischargeable.handleDischargeNodeChanged(_) end
function Dischargeable.handleDischarge(p293, p294, p295, p296, p297)
	if p293.spec_dischargeable.currentDischargeState == Dischargeable.DISCHARGE_STATE_GROUND then
		if p294.stopDischargeIfNotPossible and (p295 == 0 and ((p296 or not p297) and true or false)) then
			p293:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF)
			return
		end
	elseif p294.stopDischargeIfNotPossible and p295 == 0 then
		p293:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF)
	end
end
function Dischargeable.handleDischargeRaycast(p298, p299, p300, _, p301, _, _)
	local v302 = p298.spec_dischargeable
	if p298.isServer then
		if p300 == nil and v302.currentDischargeState == Dischargeable.DISCHARGE_STATE_OBJECT then
			p298:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF)
		end
		if p300 == nil and (p299.canStartGroundDischargeAutomatically and p298:getCanDischargeToGround(p299)) then
			p298:setDischargeState(Dischargeable.DISCHARGE_STATE_GROUND)
		end
	end
	local v303 = v302.currentDischargeNode
	if v303.distanceObjectChanges ~= nil then
		ObjectChangeUtil.setObjectChanges(v303.distanceObjectChanges, v303.distanceObjectChangeThreshold < p301 and true or v302.currentDischargeState ~= Dischargeable.DISCHARGE_STATE_OFF, p298, p298.setMovingToolDirty)
	end
end
function Dischargeable.handleFoundDischargeObject(p304, p305)
	if p304:getDischargeNodeAutomaticDischarge(p305) then
		p304:setDischargeState(Dischargeable.DISCHARGE_STATE_OBJECT)
	end
end
function Dischargeable.setDischargeEffectDistance(_, p306, p307)
	if p306.isEffectActive and (p306.effects ~= nil and p307 ~= (1 / 0)) then
		for _, v308 in pairs(p306.effects) do
			if v308.setDistance ~= nil then
				v308:setDistance(p307, g_terrainNode)
			end
		end
	end
end
function Dischargeable.setDischargeEffectActive(p309, p310, p311, p312, p313)
	if p311 then
		if not p310.isEffectActive then
			if p313 == nil then
				p313 = p309:getDischargeFillType(p310)
			end
			g_effectManager:setEffectTypeInfo(p310.effects, p313)
			g_effectManager:startEffects(p310.effects)
			g_animationManager:startAnimations(p310.effectAnimationNodes)
			p310.isEffectActive = true
		end
		p310.stopEffectTime = nil
	elseif p312 == nil or not p312 then
		if p310.stopEffectTime == nil then
			p310.stopEffectTime = g_time + p310.effectTurnOffThreshold
			p309:raiseActive()
		end
	elseif p310.isEffectActive then
		g_effectManager:stopEffects(p310.effects)
		g_animationManager:stopAnimations(p310.effectAnimationNodes)
		p310.isEffectActive = false
	end
	if p309.isServer and p310.isEffectActive ~= p310.isEffectActiveSent then
		p309:raiseDirtyFlags(p309.spec_dischargeable.dirtyFlag)
		p310.isEffectActiveSent = p310.isEffectActive
	end
end
function Dischargeable.updateDischargeSound(p314, p315, p316)
	if p314.isClient then
		local v317 = p314:getDischargeFillType(p315)
		local v318 = p314.spec_dischargeable.currentDischargeState ~= Dischargeable.DISCHARGE_STATE_OFF
		local v319 = p315.isEffectActive
		if v319 then
			v319 = v317 ~= FillType.UNKNOWN
		end
		local v320 = p315.lastEffect == nil and true or p315.lastEffect:getIsVisible()
		local v321
		if p315.lastEffect == nil then
			v321 = false
		else
			v321 = p315.lastEffect:getIsVisible()
		end
		if (v318 and v319 or v321) and v320 then
			if p315.playSound and v317 ~= FillType.UNKNOWN then
				local v322 = g_fillTypeManager:getSampleByFillType(v317)
				if v322 ~= nil then
					if v322 == p315.sharedSample then
						if not g_soundManager:getIsSamplePlaying(p315.sample) then
							g_soundManager:playSample(p315.sample)
						end
					else
						if p315.sample ~= nil then
							g_soundManager:deleteSample(p315.sample)
						end
						p315.sample = g_soundManager:cloneSample(v322, p315.node or p315.soundNode, p314)
						p315.sharedSample = v322
						g_soundManager:playSample(p315.sample)
					end
				end
			end
			if p315.dischargeSample ~= nil and not g_soundManager:getIsSamplePlaying(p315.dischargeSample) then
				g_soundManager:playSample(p315.dischargeSample)
			end
			p315.turnOffSoundTimer = 250
			return
		end
		if p315.turnOffSoundTimer ~= nil and p315.turnOffSoundTimer > 0 then
			p315.turnOffSoundTimer = p315.turnOffSoundTimer - p316
			if p315.turnOffSoundTimer <= 0 then
				if p315.playSound and g_soundManager:getIsSamplePlaying(p315.sample) then
					g_soundManager:stopSample(p315.sample)
				end
				if p315.dischargeSample ~= nil and g_soundManager:getIsSamplePlaying(p315.dischargeSample) then
					g_soundManager:stopSample(p315.dischargeSample)
				end
				p315.turnOffSoundTimer = 0
			end
		end
	end
end
function Dischargeable.dischargeTriggerCallback(p323, p324, p325, p326, p327, _, p328)
	local v329 = p323.spec_dischargeable
	if p326 or p327 then
		local v330 = g_currentMission:getNodeObject(p325)
		if v330 ~= nil and (v330 ~= p323 and v330.getFillUnitIndexFromNode ~= nil) then
			local v331 = v330:getFillUnitIndexFromNode(p328)
			local v332 = v329.triggerToDischargeNode[p324]
			local v333 = v331 ~= nil
			if not v332.canDischargeToVehicle then
				if v333 then
					v333 = not v330:isa(Vehicle)
				end
			end
			if v332 ~= nil and v333 then
				local v334 = v332.trigger
				if p326 then
					if v334.objects[v330] == nil then
						v334.objects[v330] = {
							["count"] = 0,
							["fillUnitIndex"] = v331,
							["shape"] = p328
						}
						v334.numObjects = v334.numObjects + 1
						v330:addDeleteListener(p323, "onDeleteDischargeTriggerObject")
					end
					v334.objects[v330].count = v334.objects[v330].count + 1
					p323:raiseActive()
					return
				end
				if p327 then
					v334.objects[v330].count = v334.objects[v330].count - 1
					if v334.objects[v330].count == 0 then
						v334.objects[v330] = nil
						v334.numObjects = v334.numObjects - 1
						v330:removeDeleteListener(p323, "onDeleteDischargeTriggerObject")
					end
				end
			end
		end
	end
end
function Dischargeable.onDeleteDischargeTriggerObject(p335, p336)
	local v337 = p335.spec_dischargeable
	for _, v338 in pairs(v337.triggerToDischargeNode) do
		local v339 = v338.trigger
		if v339.objects[p336] ~= nil then
			v339.objects[p336] = nil
			v339.numObjects = v339.numObjects - 1
		end
	end
end
function Dischargeable.dischargeActivationTriggerCallback(p340, p341, p342, p343, p344, _, p345)
	local v346 = p340.spec_dischargeable
	if p343 or p344 then
		local v347 = g_currentMission:getNodeObject(p342)
		if v347 ~= nil and (v347 ~= p340 and v347.getFillUnitIndexFromNode ~= nil) then
			local v348 = v347:getFillUnitIndexFromNode(p345)
			local v349 = v346.activationTriggerToDischargeNode[p341]
			if v349 ~= nil and v348 ~= nil then
				local v350 = v349.activationTrigger
				if p343 then
					if v350.objects[v347] == nil then
						v350.objects[v347] = {
							["count"] = 0,
							["fillUnitIndex"] = v348,
							["shape"] = p345
						}
						v350.numObjects = v350.numObjects + 1
						v347:addDeleteListener(p340, "onDeleteActivationTriggerObject")
					end
					v350.objects[v347].count = v350.objects[v347].count + 1
					p340:raiseActive()
					return
				end
				if p344 then
					v350.objects[v347].count = v350.objects[v347].count - 1
					if v350.objects[v347].count == 0 then
						v350.objects[v347] = nil
						v350.numObjects = v350.numObjects - 1
						v347:removeDeleteListener(p340, "onDeleteActivationTriggerObject")
					end
				end
			end
		end
	end
end
function Dischargeable.onDeleteActivationTriggerObject(p351, p352)
	local v353 = p351.spec_dischargeable
	for _, v354 in pairs(v353.activationTriggerToDischargeNode) do
		local v355 = v354.activationTrigger
		if v355.objects[p352] ~= nil then
			v355.objects[p352] = nil
			v355.numObjects = v355.numObjects - 1
		end
	end
end
function Dischargeable.setForcedFillTypeIndex(p356, p357)
	p356.spec_dischargeable.forcedFillTypeIndex = p357
end
function Dischargeable.onRegisterActionEvents(p358, _, p359)
	if p358.isClient then
		local v360 = p358.spec_dischargeable
		p358:clearActionEventsTable(v360.actionEvents)
		if p359 then
			if p358:getCanToggleDischargeToGround() then
				local _, v361 = p358:addPoweredActionEvent(v360.actionEvents, InputAction.TOGGLE_TIPSTATE_GROUND, p358, Dischargeable.actionEventToggleDischargeToGround, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v361, GS_PRIO_NORMAL)
			end
			if p358:getCanToggleDischargeToObject() then
				local _, v362 = p358:addPoweredActionEvent(v360.actionEvents, InputAction.TOGGLE_TIPSTATE, p358, Dischargeable.actionEventToggleDischarging, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v362, GS_PRIO_VERY_HIGH)
			end
			Dischargeable.updateActionEvents(p358)
		end
	end
end
function Dischargeable.onFillUnitFillLevelChanged(p363, p364, _, _, _, _, _)
	local v365 = p363.spec_dischargeable.fillUnitDischargeNodeMapping[p364]
	if v365 ~= nil and p363:getFillUnitFillLevel(p364) == 0 then
		p363:handleDischargeOnEmpty(v365)
	end
end
function Dischargeable.onDeactivate(p366)
	local v367 = p366.spec_dischargeable
	if v367.stopDischargeOnDeactivate and v367.currentDischargeState ~= Dischargeable.DISCHARGE_STATE_OFF then
		p366:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF, true)
	end
end
function Dischargeable.onStateChange(p368, p369, _)
	if p369 == VehicleStateChange.MOTOR_TURN_OFF and not p368:getIsPowered() then
		local v370 = p368.spec_dischargeable
		if v370.stopDischargeOnDeactivate and v370.currentDischargeState ~= Dischargeable.DISCHARGE_STATE_OFF then
			p368:setDischargeState(Dischargeable.DISCHARGE_STATE_OFF, true)
		end
	end
end
function Dischargeable.updateDebugValues(p371, p372)
	local v373 = p371.spec_dischargeable
	local v374 = v373.currentDischargeNode
	local v375 = v373.currentDischargeState == Dischargeable.DISCHARGE_STATE_OBJECT and "OBJECT" or (v373.currentDischargeState == Dischargeable.DISCHARGE_STATE_GROUND and "GROUND" or "OFF")
	table.insert(p372, {
		["name"] = "state",
		["value"] = v375
	})
	local v376 = {
		["name"] = "getCanDischargeToObject",
		["value"] = tostring(p371:getCanDischargeToObject(v374))
	}
	table.insert(p372, v376)
	local v377 = {
		["name"] = "getCanDischargeToGround",
		["value"] = tostring(p371:getCanDischargeToGround(v374))
	}
	table.insert(p372, v377)
	local v378 = {
		["name"] = "dischargedLiters"
	}
	local v379 = v373.dischargedLiters
	v378.value = tostring(v379)
	table.insert(p372, v378)
	local v380 = {
		["name"] = "currentNode",
		["value"] = tostring(v374)
	}
	table.insert(p372, v380)
	for _, v381 in ipairs(v373.dischargeNodes) do
		local v382 = {
			["name"] = "--->",
			["value"] = tostring(v381)
		}
		table.insert(p372, v382)
		local v383
		if v381.dischargeObject == nil then
			v383 = nil
		else
			local v384 = v381.dischargeObject.configFileName
			v383 = tostring(v384)
		end
		local v385 = {
			["name"] = "object",
			["value"] = tostring(v383)
		}
		table.insert(p372, v385)
		local v386 = {
			["name"] = "distance",
			["value"] = v381.dischargeDistance
		}
		table.insert(p372, v386)
		local v387 = {
			["name"] = "effect"
		}
		local v388 = v381.isEffectActive
		v387.value = tostring(v388)
		table.insert(p372, v387)
		local v389 = {
			["name"] = "fillLevel"
		}
		local v390 = v381.fillUnitIndex
		v389.value = tostring(p371:getFillUnitFillLevel(v390))
		table.insert(p372, v389)
		local v391 = {
			["name"] = "litersToDrop"
		}
		local v392 = v381.litersToDrop
		v391.value = tostring(v392)
		table.insert(p372, v391)
		local v393 = {
			["name"] = "emptyFactor",
			["value"] = tostring(p371:getDischargeNodeEmptyFactor(v381))
		}
		table.insert(p372, v393)
		local v394 = {
			["name"] = "emptySpeed",
			["value"] = tostring(p371:getDischargeNodeEmptyFactor(v381))
		}
		table.insert(p372, v394)
		local v395 = {
			["name"] = "readyForDischarge"
		}
		local v396 = v381.lastEffect == nil and true or v381.lastEffect:getIsFullyVisible()
		v395.value = tostring(v396)
		table.insert(p372, v395)
		local v397 = {
			["name"] = "objectsInTrigger"
		}
		local v398 = v381.trigger.numObjects
		v397.value = tostring(v398)
		table.insert(p372, v397)
		local v399 = {
			["name"] = "objectsInActivationTrigger"
		}
		local v400 = v381.activationTrigger.numObjects
		v399.value = tostring(v400)
		table.insert(p372, v399)
	end
end
function Dischargeable.actionEventToggleDischargeToGround(p401, _, _, _, _)
	if p401:getCanToggleDischargeToGround() then
		local v402 = p401.spec_dischargeable
		local v403 = v402.currentDischargeNode
		if v402.currentDischargeState == Dischargeable.DISCHARGE_STATE_OFF then
			if p401:getCanDischargeToGround(v403) then
				p401:setManualDischargeState(Dischargeable.DISCHARGE_STATE_GROUND)
				return
			end
			if not p401:getCanDischargeToLand(v403) then
				g_currentMission:showBlinkingWarning(g_i18n:getText("warning_youDontHaveAccessToThisLand"), 5000)
				return
			end
			if not p401:getCanDischargeAtPosition(v403) then
				g_currentMission:showBlinkingWarning(g_i18n:getText("warning_actionNotAllowedHere"), 5000)
				return
			end
		else
			p401:setManualDischargeState(Dischargeable.DISCHARGE_STATE_OFF)
		end
	end
end
function Dischargeable.actionEventToggleDischarging(p404, _, _, _, _)
	if p404:getCanToggleDischargeToObject() then
		local v405 = p404.spec_dischargeable
		local v406 = v405.currentDischargeNode
		if v405.currentDischargeState == Dischargeable.DISCHARGE_STATE_OFF then
			if p404:getCanDischargeToObject(v406) then
				p404:setManualDischargeState(Dischargeable.DISCHARGE_STATE_OBJECT)
				return
			end
			if v406.dischargeHit and p404:getDischargeFillType(v406) ~= FillType.UNKNOWN then
				local v407 = p404:getDischargeNotAllowedWarning(v406)
				g_currentMission:showBlinkingWarning(v407, 5000)
				return
			end
		else
			p404:setManualDischargeState(Dischargeable.DISCHARGE_STATE_OFF)
		end
	end
end
function Dischargeable.updateActionEvents(p408)
	local v409 = p408.spec_dischargeable
	local v410 = v409.actionEvents[InputAction.TOGGLE_TIPSTATE]
	local v411 = v409.actionEvents[InputAction.TOGGLE_TIPSTATE_GROUND]
	local v412 = false
	local v413 = false
	if v409.currentDischargeState == Dischargeable.DISCHARGE_STATE_OFF then
		local v414 = v409.currentDischargeNode
		if p408:getIsDischargeNodeActive(v414) then
			if p408:getCanDischargeToObject(v414) and p408:getCanToggleDischargeToObject() then
				if v410 ~= nil then
					g_inputBinding:setActionEventText(v410.actionEventId, g_i18n:getText("action_startOverloading"))
					v412 = true
				end
			elseif p408:getCanDischargeToGround(v414) and (p408:getCanToggleDischargeToGround() and v411 ~= nil) then
				g_inputBinding:setActionEventText(v411.actionEventId, g_i18n:getText("action_startTipToGround"))
				v413 = true
			end
		end
	elseif v409.currentDischargeState == Dischargeable.DISCHARGE_STATE_GROUND then
		if v411 ~= nil then
			g_inputBinding:setActionEventText(v411.actionEventId, g_i18n:getText("action_stopTipToGround"))
			v413 = true
		end
	elseif v410 ~= nil then
		g_inputBinding:setActionEventText(v410.actionEventId, g_i18n:getText("action_stopOverloading"))
		v412 = true
	end
	if v410 ~= nil then
		g_inputBinding:setActionEventTextVisibility(v410.actionEventId, v412)
	end
	if v411 ~= nil then
		g_inputBinding:setActionEventTextVisibility(v411.actionEventId, v413)
	end
end
function Dischargeable.dashboardDischargeAttributes(_, p415, p416, p417, _)
	p417.dischargeNodeIndex = p415:getValue(p416 .. "#dischargeNodeIndex")
	return true
end

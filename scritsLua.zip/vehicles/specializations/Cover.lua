source("dataS/scripts/vehicles/specializations/events/SetCoverStateEvent.lua")
Cover = {}
Cover.SEND_NUM_BITS = 4
Cover.COVER_XML_KEY = "vehicle.cover.coverConfigurations.coverConfiguration(?).cover(?)"
function Cover.prerequisitesPresent(p1)
	return SpecializationUtil.hasSpecialization(AnimatedVehicle, p1)
end
function Cover.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("cover", g_i18n:getText("configuration_cover"), "cover", VehicleConfigurationItem)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("Cover")
	v2:register(XMLValueType.STRING, Cover.COVER_XML_KEY .. "#openAnimation", "Open animation name")
	v2:register(XMLValueType.FLOAT, Cover.COVER_XML_KEY .. "#openAnimationStopTime", "Open animation stop time")
	v2:register(XMLValueType.FLOAT, Cover.COVER_XML_KEY .. "#openAnimationStartTime", "Open animation start time")
	v2:register(XMLValueType.STRING, Cover.COVER_XML_KEY .. "#closeAnimation", "Close animation name")
	v2:register(XMLValueType.FLOAT, Cover.COVER_XML_KEY .. "#closeAnimationStopTime", "Close animation stop time")
	v2:register(XMLValueType.BOOL, Cover.COVER_XML_KEY .. "#openOnBuy", "Open after buying", false)
	v2:register(XMLValueType.BOOL, Cover.COVER_XML_KEY .. "#forceOpenOnTip", "Open while tipping", true)
	v2:register(XMLValueType.BOOL, Cover.COVER_XML_KEY .. "#autoReactToTrigger", "Automatically open in triggers", true)
	v2:register(XMLValueType.VECTOR_N, Cover.COVER_XML_KEY .. "#fillUnitIndices", "Fill unit indices to cover")
	v2:register(XMLValueType.STRING, Cover.COVER_XML_KEY .. "#blockedToolTypes", "List with blocked tool types", "dischargeable bale trigger pallet")
	v2:register(XMLValueType.BOOL, "vehicle.cover.coverConfigurations.coverConfiguration(?)#closeCoverIfNotAllowed", "Close cover if not allowed to open it", false)
	v2:register(XMLValueType.BOOL, "vehicle.cover.coverConfigurations.coverConfiguration(?)#openCoverWhileTipping", "Open cover while tipping", false)
	v2:register(XMLValueType.INT, "vehicle.pipe#coverMinState", "Min. cover state to allow pipe state change", 0)
	v2:register(XMLValueType.INT, "vehicle.pipe#coverMaxState", "Max. cover state to allow pipe state change", "Max. cover state")
	v2:setXMLSpecializationType()
	Vehicle.xmlSchemaSavegame:register(XMLValueType.INT, "vehicles.vehicle(?).cover#state", "Current cover state")
end
function Cover.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "loadCoverFromXML", Cover.loadCoverFromXML)
	SpecializationUtil.registerFunction(p3, "getIsNextCoverStateAllowed", Cover.getIsNextCoverStateAllowed)
	SpecializationUtil.registerFunction(p3, "getIsNextCoverStateAllowedWarning", Cover.getIsNextCoverStateAllowedWarning)
	SpecializationUtil.registerFunction(p3, "setCoverState", Cover.setCoverState)
	SpecializationUtil.registerFunction(p3, "playCoverAnimation", Cover.playCoverAnimation)
	SpecializationUtil.registerFunction(p3, "getCoverByFillUnitIndex", Cover.getCoverByFillUnitIndex)
end
function Cover.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getFillUnitSupportsToolType", Cover.getFillUnitSupportsToolType)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanBeSelected", Cover.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadPipeNodes", Cover.loadPipeNodes)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsPipeStateChangeAllowed", Cover.getIsPipeStateChangeAllowed)
	SpecializationUtil.registerOverwrittenFunction(p4, "aiPrepareLoading", Cover.aiPrepareLoading)
	SpecializationUtil.registerOverwrittenFunction(p4, "aiFinishLoading", Cover.aiFinishLoading)
	SpecializationUtil.registerOverwrittenFunction(p4, "finishedAIDischarge", Cover.finishedAIDischarge)
	SpecializationUtil.registerOverwrittenFunction(p4, "setFillUnitInTriggerRange", Cover.setFillUnitInTriggerRange)
end
function Cover.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", Cover)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", Cover)
	SpecializationUtil.registerEventListener(p5, "onReadStream", Cover)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", Cover)
	SpecializationUtil.registerEventListener(p5, "onUpdate", Cover)
	SpecializationUtil.registerEventListener(p5, "onRegisterActionEvents", Cover)
	SpecializationUtil.registerEventListener(p5, "onStartTipping", Cover)
	SpecializationUtil.registerEventListener(p5, "onOpenBackDoor", Cover)
	SpecializationUtil.registerEventListener(p5, "onFillUnitTriggerChanged", Cover)
	SpecializationUtil.registerEventListener(p5, "onRemovedFillUnitTrigger", Cover)
end
function Cover.onLoad(p6, _)
	local v7 = p6.spec_cover
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.cover#animationName", "vehicle.cover.coverConfigurations.coverConfiguration.cover#openAnimation")
	XMLUtil.checkDeprecatedXMLElements(p6.xmlFile, "vehicle.foldable.foldingParts#closeCoverOnFold", "vehicle.cover.coverConfigurations.coverConfiguration.cover#closeCoverIfNotAllowed")
	local v8 = Utils.getNoNil(p6.configurations.cover, 1)
	local v9 = string.format("vehicle.cover.coverConfigurations.coverConfiguration(%d)", v8 - 1)
	v7.state = 0
	v7.runningAnimations = {}
	v7.covers = {}
	v7.fillUnitIndexToCovers = {}
	v7.isStateSetAutomatically = false
	local v10 = 0
	while true do
		local v11 = string.format("%s.cover(%d)", v9, v10)
		if not p6.xmlFile:hasProperty(v11) then
			break
		end
		local v12 = {}
		if p6:loadCoverFromXML(p6.xmlFile, v11, v12) then
			for v13 = #v12.fillUnitIndices, 1, -1 do
				local v14 = v12.fillUnitIndices[v13]
				if v7.fillUnitIndexToCovers[v14] == nil then
					v7.fillUnitIndexToCovers[v14] = { v12 }
				else
					local v15 = v7.fillUnitIndexToCovers[v14]
					table.insert(v15, v12)
				end
			end
			local v16 = v7.covers
			table.insert(v16, v12)
			v12.index = #v7.covers
		end
		v10 = v10 + 1
	end
	v7.closeCoverIfNotAllowed = p6.xmlFile:getValue(v9 .. "#closeCoverIfNotAllowed", false)
	v7.openCoverWhileTipping = p6.xmlFile:getValue(v9 .. "#openCoverWhileTipping", false)
	v7.hasCovers = #v7.covers > 0
	v7.isDirty = false
	if not v7.hasCovers then
		SpecializationUtil.removeEventListener(p6, "onReadStream", Cover)
		SpecializationUtil.removeEventListener(p6, "onWriteStream", Cover)
		SpecializationUtil.removeEventListener(p6, "onUpdate", Cover)
		SpecializationUtil.removeEventListener(p6, "onRegisterActionEvents", Cover)
		SpecializationUtil.removeEventListener(p6, "onStartTipping", Cover)
		SpecializationUtil.removeEventListener(p6, "onFillUnitTriggerChanged", Cover)
		SpecializationUtil.removeEventListener(p6, "onRemovedFillUnitTrigger", Cover)
	end
end
function Cover.onPostLoad(p17, p18)
	local v19 = p17.spec_cover
	if v19.hasCovers then
		local v20 = 0
		if p18 == nil then
			for v21 = 1, #v19.covers do
				if v19.covers[v21].startOpenState then
					v20 = v21
				end
			end
		else
			v20 = p18.xmlFile:getValue(p18.key .. ".cover#state", v20)
		end
		if v20 == 0 then
			v19.state = #v19.covers
		end
		p17:setCoverState(v20, true)
		for v22 = #v19.runningAnimations, 1, -1 do
			local v23 = v19.runningAnimations[v22]
			AnimatedVehicle.updateAnimationByName(p17, v23.name, 9999999, true)
			table.remove(v19.runningAnimations, v22)
		end
		v19.isDirty = false
	end
end
function Cover.saveToXMLFile(p24, p25, p26, _)
	local v27 = p24.spec_cover
	if v27.hasCovers then
		p25:setValue(p26 .. "#state", v27.state)
	end
end
function Cover.onReadStream(p28, p29, p30)
	if p30:getIsServer() then
		local v31 = p28.spec_cover
		p28:setCoverState(streamReadUIntN(p29, Cover.SEND_NUM_BITS), true)
		for v32 = #v31.runningAnimations, 1, -1 do
			local v33 = v31.runningAnimations[v32]
			AnimatedVehicle.updateAnimationByName(p28, v33.name, 9999999, true)
			table.remove(v31.runningAnimations, v32)
		end
		v31.isDirty = false
	end
end
function Cover.onWriteStream(p34, p35, p36)
	if not p36:getIsServer() then
		streamWriteUIntN(p35, p34.spec_cover.state, Cover.SEND_NUM_BITS)
	end
end
function Cover.onUpdate(p37, _, _, _, _)
	local v38 = p37.spec_cover
	if v38.isDirty then
		local v39 = v38.runningAnimations[1]
		if v39 ~= nil then
			local v40 = v38.runningAnimations[2]
			if v40 ~= nil and v40.name == v39.name then
				table.remove(v38.runningAnimations, 1)
				p37:stopAnimation(v39.name, true)
				p37:playCoverAnimation(v40)
			end
			if not p37:getIsAnimationPlaying(v39.name) then
				table.remove(v38.runningAnimations, 1)
				local v41 = v38.runningAnimations[1]
				if v41 == nil then
					v38.isDirty = false
				else
					p37:playCoverAnimation(v41)
				end
			end
		end
	end
	if v38.closeCoverIfNotAllowed and v38.state ~= 0 then
		local v42 = v38.state + 1
		if not p37:getIsNextCoverStateAllowed(#v38.covers < v42 and 0 or v42) then
			p37:setCoverState(0, true)
		end
	end
end
function Cover.loadCoverFromXML(p43, p44, p45, p46)
	p46.openAnimation = p44:getValue(p45 .. "#openAnimation")
	p46.openAnimationStartTime = p44:getValue(p45 .. "#openAnimationStartTime")
	p46.openAnimationStopTime = p44:getValue(p45 .. "#openAnimationStopTime")
	if p46.openAnimation == nil then
		Logging.xmlWarning(p43.xmlFile, "Missing \'openAnimation\' for cover \'%s\'!", p45)
		return false
	end
	p46.closeAnimation = p44:getValue(p45 .. "#closeAnimation")
	p46.closeAnimationStopTime = p44:getValue(p45 .. "#closeAnimationStopTime")
	p46.startOpenState = p44:getValue(p45 .. "#openOnBuy", false)
	p46.forceOpenOnTip = p44:getValue(p45 .. "#forceOpenOnTip", true)
	p46.autoReactToTrigger = p44:getValue(p45 .. "#autoReactToTrigger", true)
	p46.fillUnitIndices = p44:getValue(p45 .. "#fillUnitIndices", nil, true)
	if p46.fillUnitIndices == nil or #p46.fillUnitIndices == 0 then
		Logging.xmlWarning(p43.xmlFile, "Missing \'fillUnitIndices\' for cover \'%s\'!", p45)
		return false
	end
	p46.blockedToolTypes = {}
	local v47 = p44:getValue(p45 .. "#blockedToolTypes", "dischargeable bale trigger pallet"):trim():split(" ")
	for _, v48 in ipairs(v47) do
		local v49 = g_toolTypeManager:getToolTypeIndexByName(v48)
		if v49 ~= ToolType.UNDEFINED then
			p46.blockedToolTypes[v49] = true
		end
	end
	return true
end
function Cover.setCoverState(p50, p51, p52)
	local v53 = p50.spec_cover
	if v53.hasCovers and (p51 >= 0 and (p51 <= #v53.covers and v53.state ~= p51)) then
		SetCoverStateEvent.sendEvent(p50, p51, p52)
		local v54 = #v53.runningAnimations == 0
		if v53.state > 0 then
			local v55 = v53.covers[v53.state]
			local v56 = v55.closeAnimation
			local v57 = v55.closeAnimationStopTime or 1
			if v56 == nil then
				v56 = v55.openAnimation
				v57 = v55.openAnimationStopTime or 0
			end
			if p50:getAnimationExists(v56) then
				local v58 = v53.runningAnimations
				table.insert(v58, {
					["name"] = v56,
					["stopTime"] = v57
				})
			end
		end
		if p51 > 0 then
			local v59 = v53.covers[p51]
			local v60 = v53.runningAnimations
			local v61 = {
				["name"] = v59.openAnimation,
				["startTime"] = v59.openAnimationStartTime,
				["stopTime"] = v59.openAnimationStopTime or 1
			}
			table.insert(v60, v61)
		end
		v53.state = p51
		v53.isDirty = #v53.runningAnimations > 0
		if v54 and #v53.runningAnimations > 0 then
			p50:playCoverAnimation(v53.runningAnimations[1])
		end
		Cover.updateActionText(p50)
	end
end
function Cover.playCoverAnimation(p62, p63)
	if p63.startTime ~= nil then
		p62:setAnimationTime(p63.name, p63.startTime, true)
	end
	local v64 = p63.stopTime - p62:getAnimationTime(p63.name)
	local v65 = math.sign(v64)
	p62:setAnimationStopTime(p63.name, p63.stopTime)
	p62:playAnimation(p63.name, v65, p63.startTime or p62:getAnimationTime(p63.name), true)
end
function Cover.getCoverByFillUnitIndex(p66, p67)
	local v68 = p66.spec_cover.fillUnitIndexToCovers[p67]
	if v68 == nil then
		return nil
	else
		return v68[1]
	end
end
function Cover.getIsNextCoverStateAllowed(_, _)
	return true
end
function Cover.getIsNextCoverStateAllowedWarning(_, _)
	return nil
end
function Cover.getFillUnitSupportsToolType(p69, p70, p71, p72)
	local v73 = p69.spec_cover
	if v73.hasCovers then
		local v74 = v73.fillUnitIndexToCovers[p71]
		if v74 ~= nil and #v74 > 0 then
			local v75 = false
			for v76 = 1, #v74 do
				local v77 = v74[v76]
				if v73.state == v77.index then
					v75 = true
					break
				end
			end
			if not v75 and v74[1].blockedToolTypes[p72] then
				return false
			end
		end
	end
	return p70(p69, p71, p72)
end
function Cover.getCanBeSelected(_, _)
	return true
end
function Cover.loadPipeNodes(p78, p79, p80, p81, p82)
	p79(p78, p80, p81, p82)
	local v83 = p78.spec_pipe
	v83.coverMinState = p81:getValue("vehicle.pipe#coverMinState", 0)
	v83.coverMaxState = p81:getValue("vehicle.pipe#coverMaxState", #p78.spec_cover.covers)
end
function Cover.getIsPipeStateChangeAllowed(p84, p85)
	if not p85(p84) then
		return false
	end
	local v86 = p84.spec_pipe
	local v87 = p84.spec_cover
	return v87.state >= v86.coverMinState and v87.state <= v86.coverMaxState
end
function Cover.onRegisterActionEvents(p88, _, p89)
	if p88.isClient then
		local v90 = p88.spec_cover
		p88:clearActionEventsTable(v90.actionEvents)
		if p89 then
			local v91, v92 = p88:addActionEvent(v90.actionEvents, InputAction.TOGGLE_COVER, p88, Cover.actionEventToggleCover, false, true, false, true, nil, nil, true, true)
			if not v91 then
				local v93
				v93, v92 = p88:addActionEvent(v90.actionEvents, InputAction.IMPLEMENT_EXTRA4, p88, Cover.actionEventToggleCover, false, true, false, true, nil, nil, true, true)
			end
			g_inputBinding:setActionEventTextPriority(v92, GS_PRIO_NORMAL)
			Cover.updateActionText(p88)
		end
	end
end
function Cover.onStartTipping(p94, p95)
	if p94.spec_cover.openCoverWhileTipping then
		local v96 = p94:getCoverByFillUnitIndex(p94:getDischargeNodeByIndex(p94.spec_trailer.tipSides[p95].dischargeNodeIndex).fillUnitIndex)
		if v96 ~= nil then
			p94:setCoverState(v96.index, true)
		end
	end
end
function Cover.onOpenBackDoor(p97, p98)
	if p97.spec_cover.openCoverWhileTipping then
		local v99 = p97:getCoverByFillUnitIndex(p97:getDischargeNodeByIndex(p97.spec_trailer.tipSides[p98].dischargeNodeIndex).fillUnitIndex)
		if v99 ~= nil then
			p97:setCoverState(v99.index, true)
		end
	end
end
function Cover.finishedAIDischarge(p100, p101)
	if p100.spec_cover.hasCovers then
		p100:setCoverState(0)
	end
	p101(p100)
end
function Cover.aiPrepareLoading(p102, p103, p104, p105)
	local v106 = p102:getCoverByFillUnitIndex(p104)
	if v106 ~= nil then
		p102:setCoverState(v106.index)
	end
	p103(p102, p104, p105)
end
function Cover.aiFinishLoading(p107, p108, p109, p110)
	if p107.spec_cover.hasCovers then
		p107:setCoverState(0)
	end
	p108(p107, p109, p110)
end
function Cover.setFillUnitInTriggerRange(p111, p112, p113, p114)
	p112(p111, p113, p114)
	local v115 = p111.spec_cover
	local v116 = v115.fillUnitIndexToCovers[p113]
	if v116 ~= nil then
		if p114 then
			local v117 = true
			for _, v118 in pairs(v116) do
				if v117 then
					v117 = v115.state ~= v118.index
				end
			end
			local v119 = p111:getIsNextCoverStateAllowed(v116[1].index)
			if v116[1].autoReactToTrigger and (v117 and v119) then
				p111:setCoverState(v116[1].index, true)
				v115.isStateSetAutomatically = true
				return
			end
		else
			local v120 = v115.covers[v115.state]
			if v120 ~= nil and (v115.isStateSetAutomatically and v120.autoReactToTrigger) then
				p111:setCoverState(0, true)
				v115.isStateSetAutomatically = false
			end
		end
	end
end
function Cover.onFillUnitTriggerChanged(p121, _, _, p122, _)
	local v123 = p121.spec_cover
	local v124 = v123.fillUnitIndexToCovers[p122]
	if v124 ~= nil then
		local v125 = true
		for _, v126 in pairs(v124) do
			if v125 then
				v125 = v123.state ~= v126.index
			end
		end
		local v127 = p121:getIsNextCoverStateAllowed(v124[1].index)
		if v124[1].autoReactToTrigger and (v125 and v127) then
			p121:setCoverState(v124[1].index, true)
			v123.isStateSetAutomatically = true
		end
	end
end
function Cover.onRemovedFillUnitTrigger(p128, p129)
	local v130 = p128.spec_cover
	if p129 == 0 then
		local v131 = v130.covers[v130.state]
		if v131 ~= nil and (v130.isStateSetAutomatically and v131.autoReactToTrigger) then
			p128:setCoverState(0, true)
			v130.isStateSetAutomatically = false
		end
	end
end
function Cover.updateActionText(p132)
	local v133 = p132.spec_cover
	if next(v133.actionEvents) ~= nil then
		local v134 = v133.actionEvents[next(v133.actionEvents)]
		if v134 ~= nil then
			local v135 = g_i18n:getText("action_nextCover")
			if v133.state == #v133.covers then
				v135 = g_i18n:getText("action_closeCover")
			elseif v133.state == 0 then
				v135 = g_i18n:getText("action_openCover")
			end
			g_inputBinding:setActionEventText(v134.actionEventId, v135)
		end
	end
end
function Cover.actionEventToggleCover(p136, _, _, _, _)
	local v137 = p136.spec_cover
	local v138 = v137.state + 1
	local v139 = #v137.covers < v138 and 0 or v138
	if p136:getIsNextCoverStateAllowed(v139) then
		p136:setCoverState(v139)
		v137.isStateSetAutomatically = false
	else
		local v140 = p136:getIsNextCoverStateAllowedWarning(v139)
		if v140 ~= nil then
			g_currentMission:showBlinkingWarning(v140, 3000)
		end
	end
end

ForageWagon = {}
function ForageWagon.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("forageWagon", false, false, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("ForageWagon")
	v1:register(XMLValueType.INT, "vehicle.forageWagon#workAreaIndex", "Work area index", 1)
	v1:register(XMLValueType.INT, "vehicle.forageWagon#fillUnitIndex", "Fill unit index", 1)
	v1:register(XMLValueType.INT, "vehicle.forageWagon#loadInfoIndex", "Load info index", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.forageWagon#maxPickupLitersPerSecond", "Max. pickup liters per second", 500)
	v1:register(XMLValueType.INT, "vehicle.forageWagon.additives#fillUnitIndex", "Additives fill unit index")
	v1:register(XMLValueType.FLOAT, "vehicle.forageWagon.additives#usage", "Usage per picked up liter", 0.0000275)
	v1:register(XMLValueType.STRING, "vehicle.forageWagon.additives#fillTypes", "Fill types to apply additives", "GRASS_WINDROW")
	v1:register(XMLValueType.FLOAT, "vehicle.forageWagon.startFillEffect#fillStartDelay", "if defined the filling of the fill unit will be delayed until this time has passed", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.forageWagon.startFillEffect#fillStartFadeOff", "Fade out fill level for start fill effect (fillLevel 0: density 1 | fillLevel at fillStartFadeOff: density 0)", 0)
	v1:register(XMLValueType.VECTOR_3, "vehicle.forageWagon.fillVolume#loadScrollSpeed", "Scroll speed while loading", "0 0 0")
	v1:register(XMLValueType.VECTOR_3, "vehicle.forageWagon.fillVolume#dischargeScrollSpeed", "Scroll speed while unloading", "0 0 0")
	v1:register(XMLValueType.BOOL, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#rotateOnlyIfFillLevelIncreased", "Rotate only if fill level increased", false)
	EffectManager.registerEffectXMLPaths(v1, "vehicle.forageWagon.fillEffect")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.forageWagon.startFillEffect")
	v1:setXMLSpecializationType()
end
function ForageWagon.prerequisitesPresent(p2)
	local v3 = SpecializationUtil.hasSpecialization(FillUnit, p2) and (SpecializationUtil.hasSpecialization(TurnOnVehicle, p2) and SpecializationUtil.hasSpecialization(Pickup, p2))
	if v3 then
		v3 = SpecializationUtil.hasSpecialization(WorkArea, p2)
	end
	return v3
end
function ForageWagon.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "processForageWagonArea", ForageWagon.processForageWagonArea)
	SpecializationUtil.registerFunction(p4, "setFillEffectActive", ForageWagon.setFillEffectActive)
	SpecializationUtil.registerFunction(p4, "fillForageWagon", ForageWagon.fillForageWagon)
end
function ForageWagon.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "loadSpeedRotatingPartFromXML", ForageWagon.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsWorkAreaActive", ForageWagon.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p5, "doCheckSpeedLimit", ForageWagon.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p5, "getConsumingLoad", ForageWagon.getConsumingLoad)
	SpecializationUtil.registerOverwrittenFunction(p5, "getIsSpeedRotatingPartActive", ForageWagon.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p5, "getFillVolumeUVScrollSpeed", ForageWagon.getFillVolumeUVScrollSpeed)
end
function ForageWagon.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onDelete", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onReadStream", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onWriteStream", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onReadUpdateStream", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onWriteUpdateStream", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onStartWorkAreaProcessing", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onEndWorkAreaProcessing", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onTurnedOff", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onDeactivate", ForageWagon)
	SpecializationUtil.registerEventListener(p6, "onFillUnitFillLevelChanged", ForageWagon)
end
function ForageWagon.onLoad(p7, _)
	local v8 = p7.spec_forageWagon
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.forageWagon#turnedOnTipScrollerSpeedFactor")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.turnOnVehicle.rotationNodes.rotationNode", "forageWagon")
	v8.isFilling = false
	v8.isFillingSent = false
	v8.lastFillType = FillType.UNKNOWN
	v8.lastFillTypeSent = FillType.UNKNOWN
	v8.fillTimer = 0
	v8.workAreaIndex = p7.xmlFile:getValue("vehicle.forageWagon#workAreaIndex", 1)
	v8.fillUnitIndex = p7.xmlFile:getValue("vehicle.forageWagon#fillUnitIndex", 1)
	v8.loadInfoIndex = p7.xmlFile:getValue("vehicle.forageWagon#loadInfoIndex", 1)
	v8.additives = {}
	v8.additives.fillUnitIndex = p7.xmlFile:getValue("vehicle.forageWagon.additives#fillUnitIndex")
	v8.additives.available = p7:getFillUnitByIndex(v8.additives.fillUnitIndex) ~= nil
	v8.additives.usage = p7.xmlFile:getValue("vehicle.forageWagon.additives#usage", 0.0000275)
	local v9 = p7.xmlFile:getValue("vehicle.forageWagon.additives#fillTypes", "GRASS_WINDROW")
	v8.additives.fillTypes = g_fillTypeManager:getFillTypesByNames(v9, "Warning: \'" .. p7.xmlFile:getFilename() .. "\' has invalid fillType \'%s\'.")
	v8.loadUVScrollSpeed = p7.xmlFile:getValue("vehicle.forageWagon.fillVolume#loadScrollSpeed", "0 0 0", true)
	v8.dischargeUVScrollSpeed = p7.xmlFile:getValue("vehicle.forageWagon.fillVolume#dischargeScrollSpeed", "0 0 0", true)
	v8.maxPickupLitersPerSecond = p7.xmlFile:getValue("vehicle.forageWagon#maxPickupLitersPerSecond", 500)
	if p7.isClient then
		v8.fillEffects = g_effectManager:loadEffect(p7.xmlFile, "vehicle.forageWagon.fillEffect", p7.components, p7, p7.i3dMappings)
		v8.startFillEffect = g_effectManager:loadEffect(p7.xmlFile, "vehicle.forageWagon.startFillEffect", p7.components, p7, p7.i3dMappings)
	end
	v8.fillStartEffectDelay = p7.xmlFile:getValue("vehicle.forageWagon.startFillEffect#fillStartDelay", 0) * 0.001
	v8.fillStartEffectTimer = 0
	v8.fillStartEffectFadeOff = p7.xmlFile:getValue("vehicle.forageWagon.startFillEffect#fillStartFadeOff", 0)
	v8.workAreaParameters = {}
	v8.workAreaParameters.forcedFillType = FillType.UNKNOWN
	v8.workAreaParameters.lastPickupLiters = 0
	v8.workAreaParameters.litersToFill = 0
	v8.pickUpLitersBuffer = ValueBuffer.new(750)
	if v8.startFillEffect == nil or #v8.startFillEffect == 0 then
		SpecializationUtil.removeEventListener(p7, "onFillUnitFillLevelChanged", ForageWagon)
	end
	v8.dirtyFlag = p7:getNextDirtyFlag()
end
function ForageWagon.onDelete(p10)
	local v11 = p10.spec_forageWagon
	g_effectManager:deleteEffects(v11.fillEffects)
	g_effectManager:deleteEffects(v11.startFillEffect)
end
function ForageWagon.onReadStream(p12, p13, _)
	local v14 = p12.spec_forageWagon
	v14.isFilling = streamReadBool(p13)
	v14.lastFillType = streamReadUIntN(p13, FillTypeManager.SEND_NUM_BITS)
	p12:setFillEffectActive(v14.isFilling)
end
function ForageWagon.onWriteStream(p15, p16, _)
	local v17 = p15.spec_forageWagon
	streamWriteBool(p16, v17.isFillingSent)
	streamWriteUIntN(p16, v17.lastFillType, FillTypeManager.SEND_NUM_BITS)
end
function ForageWagon.onReadUpdateStream(p18, p19, _, p20)
	if p20:getIsServer() and streamReadBool(p19) then
		local v21 = p18.spec_forageWagon
		v21.isFilling = streamReadBool(p19)
		v21.lastFillType = streamReadUIntN(p19, FillTypeManager.SEND_NUM_BITS)
		p18:setFillEffectActive(v21.isFilling)
	end
end
function ForageWagon.onWriteUpdateStream(p22, p23, p24, p25)
	if not p24:getIsServer() then
		local v26 = p22.spec_forageWagon
		if streamWriteBool(p23, bitAND(p25, v26.dirtyFlag) ~= 0) then
			streamWriteBool(p23, v26.isFillingSent)
			streamWriteUIntN(p23, v26.lastFillType, FillTypeManager.SEND_NUM_BITS)
		end
	end
end
function ForageWagon.onUpdateTick(p27, p28, _, _, _)
	local v29 = p27.spec_forageWagon
	if p27.isServer then
		local v30
		if v29.fillTimer > 0 then
			v29.fillTimer = v29.fillTimer - p28
			v30 = true
		else
			v30 = false
		end
		v29.isFilling = v30
		if v29.isFilling ~= v29.isFillingSent then
			p27:raiseDirtyFlags(v29.dirtyFlag)
			v29.isFillingSent = v29.isFilling
			p27:setFillEffectActive(v29.isFilling)
		end
		v29.pickUpLitersBuffer:add(v29.workAreaParameters.lastPickupLiters)
	end
end
function ForageWagon.processForageWagonArea(p31, p32)
	local v33 = p31.spec_forageWagon
	local v34, v35, v36, v37, v38, v39 = DensityMapHeightUtil.getLineByArea(p32.start, p32.width, p32.height)
	local v40 = 0
	if v33.workAreaParameters.forcedFillType == FillType.UNKNOWN then
		local v41 = p31:getFillUnitSupportedFillTypes(v33.fillUnitIndex)
		if v41 ~= nil then
			for v42, v43 in pairs(v41) do
				if v43 then
					v40 = -DensityMapHeightUtil.tipToGroundAroundLine(p31, (-1 / 0), v42, v34, v35, v36, v37, v38, v39, 0.5, nil, nil, false, nil)
					if v40 > 0 then
						v33.workAreaParameters.forcedFillType = v42
						break
					end
				end
			end
		end
	else
		v40 = -DensityMapHeightUtil.tipToGroundAroundLine(p31, (-1 / 0), v33.workAreaParameters.forcedFillType, v34, v35, v36, v37, v38, v39, 0.5, nil, nil, false, nil)
		if v33.workAreaParameters.forcedFillType == FillType.GRASS_WINDROW then
			v40 = v40 - DensityMapHeightUtil.tipToGroundAroundLine(p31, (-1 / 0), FillType.DRYGRASS_WINDROW, v34, v35, v36, v37, v38, v39, 0.5, nil, nil, false, nil)
		elseif v33.workAreaParameters.forcedFillType == FillType.DRYGRASS_WINDROW then
			v40 = v40 - DensityMapHeightUtil.tipToGroundAroundLine(p31, (-1 / 0), FillType.GRASS_WINDROW, v34, v35, v36, v37, v38, v39, 0.5, nil, nil, false, nil)
		end
	end
	if p31.isServer and v33.additives.available then
		local v44 = false
		for v45 = 1, #v33.additives.fillTypes do
			if v33.workAreaParameters.forcedFillType == v33.additives.fillTypes[v45] then
				v44 = true
				break
			end
		end
		if v44 then
			local v46 = p31:getFillUnitFillLevel(v33.additives.fillUnitIndex)
			if v46 > 0 then
				local v47 = v33.additives.usage * v40
				if v47 > 0 then
					local v48 = v46 / v47
					v40 = v40 * (1 + 0.05 * math.min(v48, 1))
					p31:addFillUnitFillLevel(p31:getOwnerFarmId(), v33.additives.fillUnitIndex, -v47, p31:getFillUnitFillType(v33.additives.fillUnitIndex), ToolType.UNDEFINED)
				end
			end
		end
	end
	p32.lastPickUpLiters = v40
	p32.pickupParticlesActive = v40 > 0
	v33.workAreaParameters.lastPickupLiters = v33.workAreaParameters.lastPickupLiters + v40
	v33.workAreaParameters.litersToFill = v33.workAreaParameters.litersToFill + v40
	if v33.workAreaParameters.forcedFillType ~= FillType.UNKNOWN then
		v33.lastFillType = v33.workAreaParameters.forcedFillType
		if v33.lastFillType ~= v33.lastFillTypeSent then
			v33.lastFillTypeSent = v33.lastFillType
			p31:raiseDirtyFlags(v33.dirtyFlag)
		end
	end
	local v49, v50
	if p31.movingDirection == 1 then
		v49 = MathUtil.vector3Length(v34 - v37, v35 - v38, v36 - v39) * p31.lastMovedDistance
		v50 = v49
	else
		v49 = 0
		v50 = 0
	end
	return v49, v50
end
function ForageWagon.setFillEffectActive(p51, p52)
	local v53 = p51.spec_forageWagon
	if p52 then
		g_effectManager:setEffectTypeInfo(v53.fillEffects, v53.lastFillType)
		g_effectManager:setEffectTypeInfo(v53.startFillEffect, v53.lastFillType)
		g_effectManager:startEffects(v53.fillEffects)
		g_effectManager:startEffects(v53.startFillEffect)
	else
		g_effectManager:stopEffects(v53.fillEffects)
		g_effectManager:stopEffects(v53.startFillEffect)
	end
end
function ForageWagon.fillForageWagon(p54)
	local v55 = p54.spec_forageWagon
	local v56 = p54:getFillVolumeLoadInfo(v55.loadInfoIndex)
	local v57 = p54:addFillUnitFillLevel(p54:getOwnerFarmId(), v55.fillUnitIndex, v55.workAreaParameters.litersToFill, v55.lastFillType, ToolType.UNDEFINED, v56)
	if v57 + 0.01 < v55.workAreaParameters.litersToFill then
		p54:setIsTurnedOn(false)
		p54:setPickupState(false)
	end
	v55.workAreaParameters.litersToFill = v55.workAreaParameters.litersToFill - v57
	if v55.workAreaParameters.litersToFill < 0.01 then
		v55.workAreaParameters.litersToFill = 0
	end
end
function ForageWagon.loadSpeedRotatingPartFromXML(p58, p59, p60, p61, p62)
	if not p59(p58, p60, p61, p62) then
		return false
	end
	p60.rotateOnlyIfFillLevelIncreased = p61:getValue(p62 .. "#rotateOnlyIfFillLevelIncreased", false)
	return true
end
function ForageWagon.getIsSpeedRotatingPartActive(p63, p64, p65)
	local v66 = p63.spec_forageWagon
	if p65.rotateOnlyIfFillLevelIncreased == nil or (not p65.rotateOnlyIfFillLevelIncreased or v66.isFilling) then
		return p64(p63, p65)
	else
		return false
	end
end
function ForageWagon.getFillVolumeUVScrollSpeed(p67, p68, p69)
	local v70 = p67.spec_forageWagon
	if v70.isFilling then
		return v70.loadUVScrollSpeed[1], v70.loadUVScrollSpeed[2], v70.loadUVScrollSpeed[3]
	elseif p67:getDischargeState() == Dischargeable.DISCHARGE_STATE_OFF then
		return p68(p67, p69)
	else
		return v70.dischargeUVScrollSpeed[1], v70.dischargeUVScrollSpeed[2], v70.dischargeUVScrollSpeed[3]
	end
end
function ForageWagon.getIsWorkAreaActive(p71, p72, p73)
	local v74 = p71.spec_forageWagon
	local v75 = p71.spec_workArea.workAreas[v74.workAreaIndex]
	if v75 == nil or (p73 ~= v75 or p71:getIsTurnedOn() and p71:allowPickingUp()) then
		return p72(p71, p73)
	else
		return false
	end
end
function ForageWagon.doCheckSpeedLimit(p76, p77)
	local v78 = not p77(p76) and p76:getIsTurnedOn()
	if v78 then
		v78 = p76:getIsLowered()
	end
	return v78
end
function ForageWagon.getConsumingLoad(p79, p80)
	local v81, v82 = p80(p79)
	local v83 = p79.spec_forageWagon
	return v81 + v83.pickUpLitersBuffer:get(1000) / v83.maxPickupLitersPerSecond, v82 + 1
end
function ForageWagon.onStartWorkAreaProcessing(p84, _)
	local v85 = p84.spec_forageWagon
	v85.workAreaParameters.forcedFillType = FillType.UNKNOWN
	local v86 = p84:getFillUnitFillLevel(v85.fillUnitIndex)
	if p84:getFillTypeChangeThreshold(v85.fillUnitIndex) < v86 then
		v85.workAreaParameters.forcedFillType = p84:getFillUnitFillType(v85.fillUnitIndex)
	end
	if v86 == 0 and (v85.fillStartEffectDelay > 0 and v85.fillStartEffectTimer <= 0) then
		v85.fillStartEffectTimer = v85.fillStartEffectDelay
	end
	v85.workAreaParameters.lastPickupLiters = 0
end
function ForageWagon.onEndWorkAreaProcessing(p87, p88, _)
	local v89 = p87.spec_forageWagon
	if p87.isServer and v89.workAreaParameters.lastPickupLiters > 0 then
		local v90 = true
		if v89.fillStartEffectTimer > 0 then
			v89.fillStartEffectTimer = v89.fillStartEffectTimer - p88
			if v89.fillStartEffectTimer > 0 then
				v90 = false
			end
		end
		if v90 then
			p87:fillForageWagon()
		end
		v89.fillTimer = 500
	end
end
function ForageWagon.onTurnedOff(p91)
	local v92 = p91.spec_forageWagon
	if p91.isClient then
		v92.fillTimer = 0
		p91:setFillEffectActive(false)
	end
end
function ForageWagon.onDeactivate(p93)
	if p93.isClient then
		p93.spec_forageWagon.fillTimer = 0
		p93:setFillEffectActive(false)
	end
end
function ForageWagon.onFillUnitFillLevelChanged(p94, _, _, _, _, _, _)
	if p94.isClient then
		local v95 = p94.spec_forageWagon
		local v96
		if v95.fillStartEffectFadeOff > 0 then
			local v97 = p94:getFillUnitFillLevel(v95.fillUnitIndex) / v95.fillStartEffectFadeOff
			v96 = 1 - math.min(v97, 1)
		else
			v96 = 1
		end
		g_effectManager:setDensity(v95.startFillEffect, v96)
	end
end
function ForageWagon.getDefaultSpeedLimit()
	return 20
end

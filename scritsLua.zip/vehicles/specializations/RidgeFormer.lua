RidgeFormer = {}
RidgeFormer.AI_REQUIRED_GROUND_TYPES = {
	FieldGroundType.STUBBLE_TILLAGE,
	FieldGroundType.CULTIVATED,
	FieldGroundType.SEEDBED,
	FieldGroundType.PLOWED,
	FieldGroundType.ROLLED_SEEDBED
}
function RidgeFormer.prerequisitesPresent(_)
	return true
end
function RidgeFormer.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("ridgeFormer", true, true, true)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("RidgeFormer")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.ridgeFormer.sounds", "work")
	v1:setXMLSpecializationType()
end
function RidgeFormer.registerFunctions(p2)
	SpecializationUtil.registerFunction(p2, "processRidgeFormerArea", RidgeFormer.processRidgeFormerArea)
end
function RidgeFormer.registerOverwrittenFunctions(p3)
	SpecializationUtil.registerOverwrittenFunction(p3, "doCheckSpeedLimit", RidgeFormer.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p3, "getDirtMultiplier", RidgeFormer.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p3, "getWearMultiplier", RidgeFormer.getWearMultiplier)
end
function RidgeFormer.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", RidgeFormer)
	SpecializationUtil.registerEventListener(p4, "onDelete", RidgeFormer)
	SpecializationUtil.registerEventListener(p4, "onDeactivate", RidgeFormer)
	SpecializationUtil.registerEventListener(p4, "onStartWorkAreaProcessing", RidgeFormer)
	SpecializationUtil.registerEventListener(p4, "onEndWorkAreaProcessing", RidgeFormer)
end
function RidgeFormer.onLoad(p5, _)
	local v6 = p5.spec_ridgeFormer
	v6.stoneLastState = 0
	v6.stoneWearMultiplierData = g_currentMission.stoneSystem:getWearMultiplierByType("SOWINGMACHINE")
	if p5.addAIGroundTypeRequirements ~= nil then
		p5:addAIGroundTypeRequirements(RidgeFormer.AI_REQUIRED_GROUND_TYPES)
	end
	if p5.isClient then
		v6.samples = {}
		v6.samples.work = g_soundManager:loadSampleFromXML(p5.xmlFile, "vehicle.ridgeFormer.sounds", "work", p5.baseDirectory, p5.components, 0, AudioGroup.VEHICLE, p5.i3dMappings, p5)
		v6.isWorkSamplePlaying = false
	end
end
function RidgeFormer.onDelete(p7)
	local v8 = p7.spec_ridgeFormer
	g_soundManager:deleteSamples(v8.samples)
end
function RidgeFormer.onDeactivate(p9)
	if p9.isClient then
		local v10 = p9.spec_ridgeFormer
		g_soundManager:stopSamples(v10.samples)
		v10.isWorkSamplePlaying = false
	end
end
function RidgeFormer.onStartWorkAreaProcessing(p11, _)
	p11.spec_ridgeFormer.isWorking = false
end
function RidgeFormer.onEndWorkAreaProcessing(p12, _)
	local v13 = p12.spec_ridgeFormer
	if p12.isClient then
		if v13.isWorking then
			if not v13.isWorkSamplePlaying then
				g_soundManager:playSample(v13.samples.work)
				v13.isWorkSamplePlaying = true
				return
			end
		elseif v13.isWorkSamplePlaying then
			g_soundManager:stopSample(v13.samples.work)
			v13.isWorkSamplePlaying = false
		end
	end
end
function RidgeFormer.processRidgeFormerArea(p14, p15, _)
	local v16 = p14.spec_ridgeFormer
	local v17 = 0
	local v18 = 0
	v16.isWorking = p14:getLastSpeed() > 0.5
	if not v16.isWorking then
		v16.stoneLastState = 0
		return v17, v18
	end
	local v19, _, v20 = getWorldTranslation(p15.start)
	local v21, _, v22 = getWorldTranslation(p15.width)
	local v23, _, v24 = getWorldTranslation(p15.height)
	local v25, _, v26 = localDirectionToWorld(p14.rootNode, 0, 0, 1)
	local v27 = MathUtil.getYRotationFromDirection(v25, v26) / 1.5707963267948966 + 0.5
	local v28 = math.floor(v27) * 1.5707963267948966
	local v29 = FSDensityMapUtil.convertToDensityMapAngle(v28, g_currentMission.fieldGroundSystem:getGroundAngleMaxValue())
	local v30, v31 = FSDensityMapUtil.updateRidgeFormerArea(v19, v20, v21, v22, v23, v24, v29)
	v16.stoneLastState = FSDensityMapUtil.getStoneArea(v19, v20, v21, v22, v23, v24)
	FSDensityMapUtil.eraseTireTrack(v19, v20, v21, v22, v23, v24)
	return v30, v31
end
function RidgeFormer.doCheckSpeedLimit(p32, p33)
	local v34 = p32.spec_ridgeFormer
	local v35 = not p33(p32) and p32:getIsImplementChainLowered()
	if v35 then
		v35 = v34.isWorking
	end
	return v35
end
function RidgeFormer.getDirtMultiplier(p36, p37)
	local v38 = p36.spec_ridgeFormer
	local v39 = p37(p36)
	if p36.movingDirection > 0 and v38.isWorking then
		v39 = v39 + p36:getWorkDirtMultiplier() * p36:getLastSpeed() / p36.speedLimit
	end
	return v39
end
function RidgeFormer.getWearMultiplier(p40, p41)
	local v42 = p40.spec_ridgeFormer
	local v43 = p41(p40)
	if p40.movingDirection > 0 and v42.isWorking then
		local v44 = (v42.stoneLastState == 0 or v42.stoneWearMultiplierData == nil) and 1 or (v42.stoneWearMultiplierData[v42.stoneLastState] or 1)
		v43 = v43 + p40:getWorkWearMultiplier() * p40:getLastSpeed() / p40.speedLimit * v44
	end
	return v43
end

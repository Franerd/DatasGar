MultipleItemPurchase = {}
function MultipleItemPurchase.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("multipleItemPurchaseAmount", g_i18n:getText("configuration_buyableBaleAmount"), nil, VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("MultipleItemPurchase")
	v1:register(XMLValueType.STRING, "vehicle.multipleItemPurchase#filename", "Item filename")
	v1:register(XMLValueType.BOOL, "vehicle.multipleItemPurchase#isVehicle", "Is Loading a vehicle (false=Bale)", false)
	v1:register(XMLValueType.STRING, "vehicle.multipleItemPurchase#fillType", "Bale fill type", "STRAW")
	v1:register(XMLValueType.BOOL, "vehicle.multipleItemPurchase#baleIsWrapped", "Bale is wrapped", false)
	v1:register(XMLValueType.STRING, "vehicle.multipleItemPurchase#baleVariationId", "Bale variation identifier", "DEFAULT")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.multipleItemPurchase.offsets.offset(?)#offset", "Offset")
	v1:register(XMLValueType.FLOAT, "vehicle.multipleItemPurchase.offsets.offset(?)#amount", "Amount of items to activate offset")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.multipleItemPurchase.itemPositions.itemPosition(?)#position", "Bale position")
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.multipleItemPurchase.itemPositions.itemPosition(?)#rotation", "Bale rotation")
	v1:setXMLSpecializationType()
end
function MultipleItemPurchase.prerequisitesPresent(p2)
	return SpecializationUtil.hasSpecialization(FillUnit, p2)
end
function MultipleItemPurchase.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "loadItemAtPosition", MultipleItemPurchase.loadItemAtPosition)
	SpecializationUtil.registerFunction(p3, "onFinishLoadingVehicle", MultipleItemPurchase.onFinishLoadingVehicle)
end
function MultipleItemPurchase.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getTotalMass", MultipleItemPurchase.getTotalMass)
	SpecializationUtil.registerOverwrittenFunction(p4, "getFillUnitCapacity", MultipleItemPurchase.getFillUnitCapacity)
	SpecializationUtil.registerOverwrittenFunction(p4, "setVisibility", MultipleItemPurchase.setVisibility)
	SpecializationUtil.registerOverwrittenFunction(p4, "addToPhysics", MultipleItemPurchase.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p4, "removeFromPhysics", MultipleItemPurchase.removeFromPhysics)
end
function MultipleItemPurchase.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", MultipleItemPurchase)
	SpecializationUtil.registerEventListener(p5, "onPreLoadFinished", MultipleItemPurchase)
	SpecializationUtil.registerEventListener(p5, "onDelete", MultipleItemPurchase)
	SpecializationUtil.registerEventListener(p5, "onUpdate", MultipleItemPurchase)
end
function MultipleItemPurchase.onLoad(p6, _)
	local v7 = p6.spec_multipleItemPurchase
	v7.loadedBales = {}
	v7.loadedVehicles = {}
	v7.itemFilename = Utils.getFilename(p6.xmlFile:getValue("vehicle.multipleItemPurchase#filename"), p6.baseDirectory)
	v7.isVehicle = p6.xmlFile:getValue("vehicle.multipleItemPurchase#isVehicle", false)
	local v8 = p6.xmlFile:getValue("vehicle.multipleItemPurchase#fillType", "STRAW")
	v7.baleFillTypeIndex = g_fillTypeManager:getFillTypeIndexByName(v8)
	v7.baleIsWrapped = p6.xmlFile:getValue("vehicle.multipleItemPurchase#baleIsWrapped", false)
	v7.baleVariationId = p6.xmlFile:getValue("vehicle.multipleItemPurchase#baleVariationId", "DEFAULT")
	local v9 = 0
	local v10 = { 0, 0, 0 }
	while true do
		local v11 = string.format("vehicle.multipleItemPurchase.offsets.offset(%d)", v9)
		if not p6.xmlFile:hasProperty(v11) then
			break
		end
		local v12 = p6.xmlFile:getValue(v11 .. "#offset", nil, true)
		if p6.xmlFile:getValue(v11 .. "#amount") > p6.configurations.multipleItemPurchaseAmount then
			v12 = v10
		end
		v9 = v9 + 1
		v10 = v12
	end
	v7.positions = {}
	local v13 = 0
	while true do
		local v14 = string.format("vehicle.multipleItemPurchase.itemPositions.itemPosition(%d)", v13)
		if not p6.xmlFile:hasProperty(v14) then
			break
		end
		local v15 = p6.xmlFile:getValue(v14 .. "#position", nil, true)
		local v16 = p6.xmlFile:getValue(v14 .. "#rotation", nil, true)
		if v15 ~= nil and v16 ~= nil then
			if v10 ~= nil then
				v15[1] = v15[1] + v10[1]
				v15[2] = v15[2] + v10[2]
				v15[3] = v15[3] + v10[3]
			end
			local v17 = v7.positions
			table.insert(v17, {
				["position"] = v15,
				["rotation"] = v16
			})
		end
		v13 = v13 + 1
	end
	for _, v18 in ipairs(p6.components) do
		setCollisionFilterMask(v18.node, bitXOR(getCollisionFilterMask(v18.node), CollisionFlag.VEHICLE + CollisionFlag.CAMERA_BLOCKING + CollisionFlag.DYNAMIC_OBJECT))
	end
	if not p6.isServer then
		SpecializationUtil.removeEventListener(p6, "onUpdate", MultipleItemPurchase)
	end
end
function MultipleItemPurchase.onPreLoadFinished(p19, _)
	local v20 = p19.spec_multipleItemPurchase
	for v21, v22 in ipairs(v20.positions) do
		if v21 <= p19.configurations.multipleItemPurchaseAmount then
			p19:loadItemAtPosition(v22)
		end
	end
end
function MultipleItemPurchase.loadItemAtPosition(p23, p24)
	local v25 = p23.spec_multipleItemPurchase
	if p23.isServer or p23.propertyState == VehiclePropertyState.SHOP_CONFIG then
		local v26 = localToWorld
		local v27 = p23.components[1].node
		local v28 = p24.position
		local v29, v30, v31 = v26(v27, unpack(v28))
		local v32 = localRotationToWorld
		local v33 = p23.components[1].node
		local v34 = p24.rotation
		local v35, v36, v37 = v32(v33, unpack(v34))
		if not v25.isVehicle then
			local v38 = Bale.new(p23.isServer, p23.isClient)
			if v38:loadFromConfigXML(v25.itemFilename, v29, v30, v31, v35, v36, v37) then
				v38:setFillType(v25.baleFillTypeIndex, true)
				v38:setOwnerFarmId(p23:getActiveFarm(), true)
				v38:setVariationId(v25.baleVariationId)
				if p23.propertyState ~= VehiclePropertyState.SHOP_CONFIG then
					v38:register()
				end
				if v25.baleIsWrapped then
					v38:setWrappingState(1)
					if p23.configurations.baseColor ~= nil then
						local v39 = ConfigurationUtil.getColorByConfigId(p23, "baseColor", p23.configurations.baseColor)
						v38:setColor(unpack(v39))
					end
				end
				v38:removeFromPhysics()
				local v40 = v25.loadedBales
				table.insert(v40, v38)
			else
				Logging.error("Failed to load multi purchase item \'%s\'", v25.itemFilename)
			end
		end
		local v41 = p23:createLoadingTask(p23)
		local v42 = VehicleLoadingData.new()
		v42:setFilename(v25.itemFilename)
		v42:setPosition(v29, v30, v31)
		v42:setRotation(v35, v36, v37)
		v42:setPropertyState(p23.propertyState)
		v42:setIsRegistered(p23.propertyState ~= VehiclePropertyState.SHOP_CONFIG)
		v42:setForceServer(p23.propertyState == VehiclePropertyState.SHOP_CONFIG)
		v42:setOwnerFarmId(p23:getActiveFarm())
		local v43 = {}
		local v44 = g_storeManager:getItemByXMLFilename(v25.itemFilename)
		if v44 ~= nil and v44.configurations ~= nil then
			for v45, _ in pairs(v44.configurations) do
				if p23.configurations[v45] ~= nil then
					v43[v45] = p23.configurations[v45]
				end
			end
		end
		v42:setConfigurations(v43)
		v42:load(p23.onFinishLoadingVehicle, p23, v41)
	end
end
function MultipleItemPurchase.onFinishLoadingVehicle(p46, p47, p48, p49)
	if p46.isDeleted or p46.isDeleting then
		if p48 == VehicleLoadingState.OK then
			for _, v50 in ipairs(p47) do
				v50:delete()
			end
		end
	else
		local v51 = p46.spec_multipleItemPurchase
		if p48 == VehicleLoadingState.OK then
			for _, v52 in ipairs(p47) do
				v52:removeFromPhysics()
				v52:setVisibility(false)
				local v53 = v51.loadedVehicles
				table.insert(v53, v52)
			end
		else
			Logging.error("Failed to load multi purchase item \'%s\'", v51.itemFilename)
		end
		if p49 ~= nil then
			p46:finishLoadingTask(p49)
		end
	end
end
function MultipleItemPurchase.onDelete(p54)
	if p54.propertyState == VehiclePropertyState.SHOP_CONFIG or (g_iconGenerator ~= nil or g_currentMission.vehicleSystem.debugVehiclesToBeLoaded ~= nil) then
		local v55 = p54.spec_multipleItemPurchase
		if v55.loadedBales ~= nil then
			for _, v56 in ipairs(v55.loadedBales) do
				v56:delete()
			end
			v55.loadedBales = {}
			for _, v57 in ipairs(v55.loadedVehicles) do
				v57:delete()
			end
			v55.loadedVehicles = {}
		end
	end
end
function MultipleItemPurchase.onUpdate(p58, _, _, _, _)
	if p58.propertyState ~= VehiclePropertyState.SHOP_CONFIG then
		p58:delete()
	end
end
function MultipleItemPurchase.getTotalMass(p59, _, _)
	if p59.propertyState ~= VehiclePropertyState.SHOP_CONFIG then
		return 0
	end
	local v60 = p59.spec_multipleItemPurchase
	local v61 = 0
	for _, v62 in ipairs(v60.loadedBales) do
		v61 = v61 + v62:getMass()
	end
	for _, v63 in ipairs(v60.loadedVehicles) do
		v61 = v61 + v63:getTotalMass()
	end
	return v61
end
function MultipleItemPurchase.getFillUnitCapacity(p64, _, _)
	if p64.propertyState ~= VehiclePropertyState.SHOP_CONFIG then
		return 0
	end
	local v65 = p64.spec_multipleItemPurchase
	local v66 = 0
	for _, v67 in ipairs(v65.loadedBales) do
		v66 = v66 + v67:getFillLevel()
	end
	for _, v68 in ipairs(v65.loadedVehicles) do
		if v68.getFillUnitCapacity ~= nil then
			v66 = v66 + v68:getFillUnitCapacity(1)
		end
	end
	return v66
end
function MultipleItemPurchase.setVisibility(p69, p70, p71)
	local v72 = p69.spec_multipleItemPurchase
	for _, v73 in ipairs(v72.loadedVehicles) do
		v73:setVisibility(p71)
	end
	p70(p69, p71)
end
function MultipleItemPurchase.addToPhysics(p74, p75)
	if not p75(p74) then
		return false
	end
	local v76 = p74.spec_multipleItemPurchase
	for _, v77 in ipairs(v76.loadedBales) do
		v77:addToPhysics()
	end
	for _, v78 in ipairs(v76.loadedVehicles) do
		v78:addToPhysics()
	end
	return true
end
function MultipleItemPurchase.removeFromPhysics(p79, p80)
	local v81 = p79.spec_multipleItemPurchase
	for _, v82 in ipairs(v81.loadedBales) do
		v82:removeFromPhysics()
	end
	for _, v83 in ipairs(v81.loadedVehicles) do
		v83:removeFromPhysics()
	end
	return p80(p79)
end

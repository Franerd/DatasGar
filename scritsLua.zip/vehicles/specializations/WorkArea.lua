WorkArea = {}
WorkArea.WORK_AREA_XML_KEY = "vehicle.workAreas.workArea(?)"
WorkArea.WORK_AREA_XML_CONFIG_KEY = "vehicle.workAreas.workAreaConfigurations.workAreaConfiguration(?).workArea(?)"
function WorkArea.initSpecialization()
	g_workAreaTypeManager:addWorkAreaType("default", false, false, false)
	g_workAreaTypeManager:addWorkAreaType("auxiliary", false, false, false)
	g_vehicleConfigurationManager:addConfigurationType("workArea", g_i18n:getText("configuration_workArea"), "workAreas", VehicleConfigurationItem)
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("WorkArea")
	WorkArea.registerWorkAreaXMLPaths(v1, WorkArea.WORK_AREA_XML_KEY)
	WorkArea.registerWorkAreaXMLPaths(v1, WorkArea.WORK_AREA_XML_CONFIG_KEY)
	v1:register(XMLValueType.INT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#workAreaIndex", "Work area index")
	v1:setXMLSpecializationType()
end
function WorkArea.registerWorkAreaXMLPaths(p2, p3)
	p2:register(XMLValueType.STRING, p3 .. "#type", "Work area type", "DEFAULT")
	p2:register(XMLValueType.BOOL, p3 .. "#requiresGroundContact", "Requires ground contact to work", true)
	p2:register(XMLValueType.BOOL, p3 .. "#disableBackwards", "Area is disabled while driving backwards", true)
	p2:register(XMLValueType.BOOL, p3 .. "#requiresOwnedFarmland", "Requires owned farmland", true)
	p2:register(XMLValueType.STRING, p3 .. "#functionName", "Work area script function")
	p2:register(XMLValueType.STRING, p3 .. "#preprocessFunctionName", "Pre process work area script function")
	p2:register(XMLValueType.STRING, p3 .. "#postprocessFunctionName", "Post process work area script function")
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".area#startNode", "Start node")
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".area#widthNode", "Width node")
	p2:register(XMLValueType.NODE_INDEX, p3 .. ".area#heightNode", "Height node")
	p2:register(XMLValueType.INT, p3 .. ".groundReferenceNode#index", "Ground reference node index")
	p2:register(XMLValueType.BOOL, p3 .. ".onlyActiveWhenLowered#value", "Work area is only active when lowered", false)
end
function WorkArea.prerequisitesPresent(p4)
	return SpecializationUtil.hasSpecialization(GroundReference, p4)
end
function WorkArea.registerEvents(p5)
	SpecializationUtil.registerEvent(p5, "onStartWorkAreaProcessing")
	SpecializationUtil.registerEvent(p5, "onEndWorkAreaProcessing")
end
function WorkArea.registerFunctions(p6)
	SpecializationUtil.registerFunction(p6, "loadWorkAreaFromXML", WorkArea.loadWorkAreaFromXML)
	SpecializationUtil.registerFunction(p6, "getWorkAreaByIndex", WorkArea.getWorkAreaByIndex)
	SpecializationUtil.registerFunction(p6, "getIsWorkAreaActive", WorkArea.getIsWorkAreaActive)
	SpecializationUtil.registerFunction(p6, "updateWorkAreaWidth", WorkArea.updateWorkAreaWidth)
	SpecializationUtil.registerFunction(p6, "getWorkAreaWidth", WorkArea.getWorkAreaWidth)
	SpecializationUtil.registerFunction(p6, "getIsWorkAreaProcessing", WorkArea.getIsWorkAreaProcessing)
	SpecializationUtil.registerFunction(p6, "getTypedNetworkAreas", WorkArea.getTypedNetworkAreas)
	SpecializationUtil.registerFunction(p6, "getTypedWorkAreas", WorkArea.getTypedWorkAreas)
	SpecializationUtil.registerFunction(p6, "getIsTypedWorkAreaActive", WorkArea.getIsTypedWorkAreaActive)
	SpecializationUtil.registerFunction(p6, "getIsFarmlandNotOwnedWarningShown", WorkArea.getIsFarmlandNotOwnedWarningShown)
	SpecializationUtil.registerFunction(p6, "getLastTouchedFarmlandFarmId", WorkArea.getLastTouchedFarmlandFarmId)
	SpecializationUtil.registerFunction(p6, "getIsAccessibleAtWorldPosition", WorkArea.getIsAccessibleAtWorldPosition)
	SpecializationUtil.registerFunction(p6, "updateLastWorkedArea", WorkArea.updateLastWorkedArea)
	SpecializationUtil.registerFunction(p6, "getMissionByWorkArea", WorkArea.getMissionByWorkArea)
	SpecializationUtil.registerFunction(p6, "getAIWorkAreaWidth", WorkArea.getAIWorkAreaWidth)
end
function WorkArea.registerOverwrittenFunctions(p7)
	SpecializationUtil.registerOverwrittenFunction(p7, "loadSpeedRotatingPartFromXML", WorkArea.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p7, "getIsSpeedRotatingPartActive", WorkArea.getIsSpeedRotatingPartActive)
	SpecializationUtil.registerOverwrittenFunction(p7, "checkMovingPartDirtyUpdateNode", WorkArea.checkMovingPartDirtyUpdateNode)
	SpecializationUtil.registerOverwrittenFunction(p7, "getImplementAllowAutomaticSteering", WorkArea.getImplementAllowAutomaticSteering)
end
function WorkArea.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", WorkArea)
	SpecializationUtil.registerEventListener(p8, "onUpdateTick", WorkArea)
	SpecializationUtil.registerEventListener(p8, "onDraw", WorkArea)
end
function WorkArea.onLoad(p9, _)
	local v10 = p9.spec_workArea
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.workAreas.workArea(0)#startIndex", "vehicle.workAreas.workArea(0).area#startIndex")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.workAreas.workArea(0)#widthIndex", "vehicle.workAreas.workArea(0).area#widthIndex")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.workAreas.workArea(0)#heightIndex", "vehicle.workAreas.workArea(0).area#heightIndex")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.workAreas.workArea(0)#foldMinLimit", "vehicle.workAreas.workArea(0).folding#minLimit")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.workAreas.workArea(0)#foldMaxLimit", "vehicle.workAreas.workArea(0).folding#maxLimit")
	XMLUtil.checkDeprecatedXMLElements(p9.xmlFile, "vehicle.workAreas.workArea(0)#refNodeIndex", "vehicle.workAreas.workArea(0).groundReferenceNode#index")
	local v11 = Utils.getNoNil(p9.configurations.workArea, 1)
	local v12 = string.format("vehicle.workAreas.workAreaConfigurations.workAreaConfiguration(%d)", v11 - 1)
	local v13 = not p9.xmlFile:hasProperty(v12) and "vehicle.workAreas" or v12
	v10.workAreas = {}
	local v14 = 0
	while true do
		local v15 = string.format("%s.workArea(%d)", v13, v14)
		if not p9.xmlFile:hasProperty(v15) then
			break
		end
		local v16 = {}
		if p9:loadWorkAreaFromXML(v16, p9.xmlFile, v15) then
			local v17 = v10.workAreas
			table.insert(v17, v16)
			v16.index = #v10.workAreas
			p9:updateWorkAreaWidth(v16.index)
		end
		v14 = v14 + 1
	end
	v10.workAreaByType = {}
	for _, v18 in pairs(v10.workAreas) do
		if v10.workAreaByType[v18.type] == nil then
			v10.workAreaByType[v18.type] = {}
		end
		local v19 = v10.workAreaByType[v18.type]
		table.insert(v19, v18)
	end
	v10.lastAccessedFarmlandOwner = 0
	v10.lastWorkedArea = -1
	v10.showFarmlandNotOwnedWarning = false
	v10.warningCantUseMissionVehiclesOnOtherLand = g_i18n:getText("warning_cantUseMissionVehiclesOnOtherLand")
	v10.warningYouDontHaveAccessToThisLand = g_i18n:getText("warning_youDontHaveAccessToThisLand")
end
function WorkArea.getIsAccessibleAtWorldPosition(p20, p21, p22, p23, p24)
	if p20.propertyState == VehiclePropertyState.MISSION then
		return g_missionManager:getIsMissionWorkAllowed(p21, p22, p23, p24, p20), p21, true
	end
	local v25 = g_farmlandManager:getFarmlandIdAtWorldPosition(p22, p23)
	if v25 == nil then
		return false, nil, false
	end
	if v25 == FarmlandManager.NOT_BUYABLE_FARM_ID then
		return false, FarmlandManager.NO_OWNER_FARM_ID, false
	end
	local v26 = g_farmlandManager:getFarmlandOwner(v25)
	return v26 ~= 0 and g_currentMission.accessHandler:canFarmAccessOtherId(p21, v26) or g_missionManager:getIsMissionWorkAllowed(p21, p22, p23, p24, p20), v26, true
end
function WorkArea.updateLastWorkedArea(p27, p28)
	local v29 = p27.spec_workArea
	local v30 = v29.lastWorkedArea
	v29.lastWorkedArea = math.max(p28, v30)
end
function WorkArea.getLastTouchedFarmlandFarmId(p31)
	local v32 = p31.spec_workArea
	return v32.lastAccessedFarmlandOwner == 0 and 0 or v32.lastAccessedFarmlandOwner
end
function WorkArea.onUpdateTick(p33, p34, _, _, _)
	local v35 = p33.spec_workArea
	SpecializationUtil.raiseEvent(p33, "onStartWorkAreaProcessing", p34, v35.workAreas)
	v35.showFarmlandNotOwnedWarning = false
	local v36 = false
	local v37 = p33:getActiveFarm()
	if v37 == nil then
		v37 = AccessHandler.EVERYONE
	end
	local v38 = false
	local v39 = false
	local v40 = false
	for v41 = 1, #v35.workAreas do
		local v42 = v35.workAreas[v41]
		if v42.type ~= WorkAreaType.AUXILIARY then
			v42.lastWorkedHectares = 0
			local v43 = p33:getIsWorkAreaActive(v42)
			if v43 and v42.requiresOwnedFarmland then
				local v44, _, v45 = getWorldTranslation(v42.start)
				local v46, v47, v48 = p33:getIsAccessibleAtWorldPosition(v37, v44, v45, v42.type)
				v38 = v38 or v48
				if v46 then
					if v47 == nil then
						v39 = true
					else
						v35.lastAccessedFarmlandOwner = v47
						v39 = true
					end
				else
					local v49, _, v50 = getWorldTranslation(v42.width)
					local v51, _, v52 = p33:getIsAccessibleAtWorldPosition(v37, v49, v50, v42.type)
					v38 = v38 or v52
					if v51 then
						v39 = true
					else
						local v53, _, v54 = getWorldTranslation(v42.height)
						local v55, _, v56 = p33:getIsAccessibleAtWorldPosition(v37, v53, v54, v42.type)
						v38 = v38 or v56
						if v55 then
							v39 = true
						else
							local v57, _, v58 = p33:getIsAccessibleAtWorldPosition(v37, v49 + (v53 - v44), v50 + (v54 - v45), v42.type)
							v38 = v38 or v58
							if v57 then
								v39 = true
							end
						end
					end
				end
				if not v39 then
					v43 = false
				end
				v40 = v38
			end
			if v43 then
				if v42.preprocessingFunction ~= nil then
					v42.preprocessingFunction(p33, v42, p34)
				end
				if v42.processingFunction ~= nil then
					local v59, _ = v42.processingFunction(p33, v42, p34)
					if v59 > 0 then
						v42.lastWorkedHectares = MathUtil.areaToHa(v59, g_currentMission:getFruitPixelsToSqm())
						v42.lastProcessingTime = g_currentMission.time
					else
						v42.lastWorkedHectares = 0
					end
				end
				if v42.postprocessingFunction ~= nil then
					v42.postprocessingFunction(p33, v42, p34)
				end
				v36 = true
			end
		end
	end
	if v40 and not v39 then
		v35.showFarmlandNotOwnedWarning = true
	end
	SpecializationUtil.raiseEvent(p33, "onEndWorkAreaProcessing", p34, v36)
	if v35.lastWorkedArea >= 0 then
		local v60 = p33:getLastTouchedFarmlandFarmId()
		local v61 = MathUtil.areaToHa(v35.lastWorkedArea, g_currentMission:getFruitPixelsToSqm())
		g_farmManager:updateFarmStats(v60, "workedHectares", v61)
		g_farmManager:updateFarmStats(v60, "workedTime", p34 / 60000)
		v35.lastWorkedArea = -1
	end
end
function WorkArea.onDraw(p62, _, _, _)
	local v63 = p62.spec_workArea
	if v63.showFarmlandNotOwnedWarning then
		if p62.propertyState == VehiclePropertyState.MISSION then
			g_currentMission:showBlinkingWarning(v63.warningCantUseMissionVehiclesOnOtherLand)
			return
		end
		g_currentMission:showBlinkingWarning(v63.warningYouDontHaveAccessToThisLand)
	end
end
function WorkArea.loadWorkAreaFromXML(p64, p65, p66, p67)
	XMLUtil.checkDeprecatedXMLElements(p66, p67 .. ".area#startIndex", p67 .. ".area#startNode")
	XMLUtil.checkDeprecatedXMLElements(p66, p67 .. ".area#widthIndex", p67 .. ".area#widthNode")
	XMLUtil.checkDeprecatedXMLElements(p66, p67 .. ".area#heightIndex", p67 .. ".area#heightNode")
	local v68 = p66:getValue(p67 .. ".area#startNode", p65.start, p64.components, p64.i3dMappings)
	local v69 = p66:getValue(p67 .. ".area#widthNode", p65.width, p64.components, p64.i3dMappings)
	local v70 = p66:getValue(p67 .. ".area#heightNode", p65.height, p64.components, p64.i3dMappings)
	if v68 == nil or (v69 == nil or v70 == nil) then
		return false
	end
	if calcDistanceFrom(v68, v69) < 0.001 then
		Logging.xmlError(p66, "\'start\' and \'width\' have the same position for \'%s\'!", p67)
		return false
	end
	if calcDistanceFrom(v69, v70) < 0.001 then
		Logging.xmlError(p66, "\'width\' and \'height\' have the same position for \'%s\'!", p67)
		return false
	end
	local v71 = p66:getValue(p67 .. "#type")
	p65.type = g_workAreaTypeManager:getWorkAreaTypeIndexByName(v71) or WorkAreaType.DEFAULT
	if p65.type == nil then
		Logging.xmlWarning(p66, "Invalid workArea type \'%s\' for workArea \'%s\'!", v71, p67)
		return false
	end
	p65.requiresGroundContact = p66:getValue(p67 .. "#requiresGroundContact", true)
	if p65.type ~= WorkAreaType.AUXILIARY then
		if p65.requiresGroundContact then
			XMLUtil.checkDeprecatedXMLElements(p66, p67 .. "#refNodeIndex", p67 .. ".groundReferenceNode#index")
			local v72 = p66:getValue(p67 .. ".groundReferenceNode#index")
			if v72 == nil then
				Logging.xmlWarning(p66, "Missing groundReference \'groundReferenceNode#index\' for workArea \'%s\'. Add requiresGroundContact=\"false\" if groundContact is not required!", p67)
				return false
			end
			local v73 = p64:getGroundReferenceNodeFromIndex(v72)
			if v73 == nil then
				Logging.xmlWarning(p66, "Invalid groundReferenceNode-index for workArea \'%s\'!", p67)
				return false
			end
			p65.groundReferenceNode = v73
		end
		p65.disableBackwards = p66:getValue(p67 .. "#disableBackwards", true)
		p65.onlyActiveWhenLowered = p66:getValue(p67 .. ".onlyActiveWhenLowered#value", false)
		p65.functionName = p66:getValue(p67 .. "#functionName")
		if p65.functionName == nil then
			Logging.xmlWarning(p66, "Missing \'functionName\' for workArea \'%s\'!", p67)
			return false
		end
		if p64[p65.functionName] == nil then
			local v74 = Logging.xmlWarning
			local v75 = p65.functionName
			v74(p66, "Given functionName \'%s\' not defined. Please add missing function or specialization!", (tostring(v75)))
			return false
		end
		p65.processingFunction = p64[p65.functionName]
		if g_isDevelopmentVersion and (not SpecializationUtil.hasSpecialization(Cutter, p64.specializations) and (not SpecializationUtil.hasSpecialization(Pickup, p64.specializations) and (not SpecializationUtil.hasSpecialization(Drivable, p64.specializations) and p66:getString(p67 .. ".onlyActiveWhenLowered#value") == nil))) then
			Logging.xmlDevWarning(p66, "Work area has no \'onlyActiveWhenLowered\' attribute set! \'%s\'", p67)
		end
		p65.preprocessFunctionName = p66:getValue(p67 .. "#preprocessFunctionName")
		if p65.preprocessFunctionName ~= nil then
			if p64[p65.preprocessFunctionName] == nil then
				local v76 = Logging.xmlWarning
				local v77 = p65.preprocessFunctionName
				v76(p66, "Given preprocessFunctionName \'%s\' not defined. Please add missing function or specialization!", (tostring(v77)))
				return false
			end
			p65.preprocessingFunction = p64[p65.preprocessFunctionName]
		end
		p65.postprocessFunctionName = p66:getValue(p67 .. "#postprocessFunctionName")
		if p65.postprocessFunctionName ~= nil then
			if p64[p65.postprocessFunctionName] == nil then
				local v78 = Logging.xmlWarning
				local v79 = p65.postprocessFunctionName
				v78(p66, "Given postprocessFunctionName \'%s\' not defined. Please add missing function or specialization!", (tostring(v79)))
				return false
			end
			p65.postprocessingFunction = p64[p65.postprocessFunctionName]
		end
		p65.requiresOwnedFarmland = p66:getValue(p67 .. "#requiresOwnedFarmland", true)
	end
	p65.lastProcessingTime = 0
	p65.start = v68
	p65.width = v69
	p65.height = v70
	p65.workWidth = -1
	return true
end
function WorkArea.getWorkAreaByIndex(p80, p81)
	return p80.spec_workArea.workAreas[p81]
end
function WorkArea.getIsWorkAreaActive(p82, p83)
	if p83.requiresGroundContact == true and (p83.groundReferenceNode ~= nil and not p82:getIsGroundReferenceNodeActive(p83.groundReferenceNode)) then
		return false
	elseif p83.disableBackwards and p82.movingDirection <= 0 then
		return false
	else
		return (not p83.onlyActiveWhenLowered or (p82.getIsLowered == nil or p82:getIsLowered(false))) and true or false
	end
end
function WorkArea.updateWorkAreaWidth(p84, p85)
	local v86 = p84.spec_workArea.workAreas[p85]
	if v86 ~= nil then
		local v87, _, _ = localToLocal(p84.components[1].node, v86.start, 0, 0, 0)
		local v88, _, _ = localToLocal(p84.components[1].node, v86.width, 0, 0, 0)
		local v89, _, _ = localToLocal(p84.components[1].node, v86.height, 0, 0, 0)
		v86.workWidth = math.max(v87, v88, v89) - math.min(v87, v88, v89)
	end
end
function WorkArea.getWorkAreaWidth(p90, p91)
	return p90.spec_workArea.workAreas[p91].workWidth
end
function WorkArea.getIsWorkAreaProcessing(_, p92)
	return p92.lastProcessingTime + 200 >= g_currentMission.time
end
function WorkArea.getTypedNetworkAreas(p93, p94, p95)
	local v96 = p93:getTypedWorkAreas(p94)
	local v97 = 0
	local v98 = {}
	local v99 = false
	for _, v100 in pairs(v96) do
		if p93:getIsWorkAreaActive(v100) then
			local v101, _, v102 = getWorldTranslation(v100.start)
			local v103
			if p95 then
				local v104 = g_currentMission:getFarmId()
				v103 = g_currentMission.accessHandler:canFarmAccessLand(v104, v101, v102) or g_missionManager:getIsMissionWorkAllowed(v104, v101, v102, p94, p93)
			else
				v103 = not p95
			end
			if v103 then
				local v105, _, v106 = getWorldTranslation(v100.width)
				local v107, _, v108 = getWorldTranslation(v100.height)
				local v109 = (v106 - v102) * (v107 - v101) - (v105 - v101) * (v108 - v102)
				v97 = v97 + math.abs(v109)
				table.insert(v98, {
					v101,
					v102,
					v105,
					v106,
					v107,
					v108
				})
			else
				v99 = true
			end
		end
	end
	return v98, v99, v97
end
function WorkArea.getTypedWorkAreas(p110, p111)
	local v112 = p110.spec_workArea.workAreaByType[p111]
	return v112 == nil and {} or v112
end
function WorkArea.getIsTypedWorkAreaActive(p113, p114)
	local v115 = p113:getTypedWorkAreas(p114)
	local v116 = false
	for _, v117 in pairs(v115) do
		if p113:getIsWorkAreaActive(v117) then
			return true, v115
		end
	end
	return v116, v115
end
function WorkArea.getMissionByWorkArea(_, p118)
	if p118 == nil then
		return nil
	else
		local v119, _, v120 = getWorldTranslation(p118.start)
		local v121 = g_missionManager:getMissionAtWorldPosition(v119, v120)
		if v121 == nil then
			local v122, _, v123 = getWorldTranslation(p118.width)
			local v124 = g_missionManager:getMissionAtWorldPosition(v122, v123)
			if v124 == nil then
				local v125, _, v126 = getWorldTranslation(p118.height)
				local v127 = g_missionManager:getMissionAtWorldPosition(v125, v126)
				if v127 == nil then
					return nil
				else
					return v127
				end
			else
				return v124
			end
		else
			return v121
		end
	end
end
function WorkArea.getAIWorkAreaWidth(p128)
	local v129 = 0
	for _, v130 in pairs(p128.spec_workArea.workAreas) do
		if g_workAreaTypeManager:getWorkAreaTypeIsAIArea(v130.type) then
			local v131 = v130.workWidth
			v129 = math.max(v131, v129)
		end
	end
	return v129
end
function WorkArea.getIsFarmlandNotOwnedWarningShown(p132)
	return p132.spec_workArea.showFarmlandNotOwnedWarning
end
function WorkArea.loadSpeedRotatingPartFromXML(p133, p134, p135, p136, p137)
	if not p134(p133, p135, p136, p137) then
		return false
	end
	p135.workAreaIndex = p136:getValue(p137 .. "#workAreaIndex")
	return true
end
function WorkArea.getIsSpeedRotatingPartActive(p138, p139, p140)
	if p140.workAreaIndex ~= nil then
		local v141 = p138.spec_workArea
		if v141.workAreas[p140.workAreaIndex] == nil then
			p140.workAreaIndex = nil
			local v142 = Logging.xmlWarning
			local v143 = p138.xmlFile
			local v144 = p140.workAreaIndex
			v142(v143, "Invalid workAreaIndex \'%s\'. Indexing starts with 1!", (tostring(v144)))
			return true
		end
		if not p138:getIsWorkAreaProcessing(v141.workAreas[p140.workAreaIndex]) then
			return false
		end
	end
	return p139(p138, p140)
end
function WorkArea.checkMovingPartDirtyUpdateNode(p145, p146, p147, p148)
	p146(p145, p147, p148)
	local v149 = p145.spec_workArea
	for v150 = 1, #v149.workAreas do
		local v151 = v149.workAreas[v150]
		if p147 == v151.start or (p147 == v151.width or p147 == v151.height) then
			Logging.xmlError(p145.xmlFile, "Found work area node \'%s\' in active dirty moving part \'%s\' with limited update distance. Remove limit or adjust hierarchy for correct function. (maxUpdateDistance=\'-\')", getName(p147), getName(p148.node))
		end
		if v151.groundReferenceNode ~= nil and p147 == v151.groundReferenceNode.node then
			Logging.xmlError(p145.xmlFile, "Found ground reference node \'%s\' in active dirty moving part \'%s\' with limited update distance. Remove limit or adjust hierarchy for correct function. (maxUpdateDistance=\'-\')", getName(p147), getName(p148.node))
		end
	end
end
function WorkArea.getImplementAllowAutomaticSteering(p152, p153)
	local v154 = p152.spec_workArea
	for _, v155 in ipairs(v154.workAreas) do
		if g_workAreaTypeManager:getWorkAreaTypeIsSteeringAssistArea(v155.type) then
			return true
		end
	end
	return p153(p152)
end

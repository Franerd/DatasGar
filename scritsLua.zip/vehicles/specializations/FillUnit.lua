source("dataS/scripts/vehicles/specializations/events/SetFillUnitIsFillingEvent.lua")
source("dataS/scripts/vehicles/specializations/events/SetFillUnitCapacityEvent.lua")
source("dataS/scripts/vehicles/specializations/events/FillUnitUnloadEvent.lua")
source("dataS/scripts/vehicles/specializations/events/FillUnitUnloadedEvent.lua")
FillUnit = {}
FillUnit.FILL_UNIT_CONFIG_XML_KEY = "vehicle.fillUnit.fillUnitConfigurations.fillUnitConfiguration(?)"
FillUnit.FILL_UNIT_XML_KEY = FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits.fillUnit(?)"
FillUnit.ALARM_TRIGGER_XML_KEY = FillUnit.FILL_UNIT_XML_KEY .. ".alarmTriggers.alarmTrigger(?)"
FillUnit.CAPACITY_TO_NETWORK_BITS = {}
FillUnit.CAPACITY_TO_NETWORK_BITS[0] = 16
FillUnit.CAPACITY_TO_NETWORK_BITS[1] = 12
FillUnit.CAPACITY_TO_NETWORK_BITS[2048] = 16
FillUnit.UNIT = {}
FillUnit.UNIT.CUBICMETER = {
	["conversionFunc"] = function(p1)
		return MathUtil.round(p1 * 0.001, 1)
	end,
	["l10n"] = "unit_cubicShort"
}
FillUnit.UNIT.LITER = {
	["conversionFunc"] = function(p2)
		return p2
	end,
	["l10n"] = "unit_literShort"
}
function FillUnit.initSpecialization()
	g_vehicleConfigurationManager:addConfigurationType("fillUnit", g_i18n:getText("configuration_fillUnit"), "fillUnit", VehicleConfigurationItem)
	g_storeManager:addSpecType("capacity", "shopListAttributeIconCapacity", FillUnit.loadSpecValueCapacity, FillUnit.getSpecValueCapacity, StoreSpecies.VEHICLE, { "fillUnit" })
	g_storeManager:addSpecType("fillTypes", "shopListAttributeIconFillTypes", FillUnit.loadSpecValueFillTypes, FillUnit.getSpecValueFillTypes, StoreSpecies.VEHICLE, { "fillUnit" })
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("FillUnit")
	v3:register(XMLValueType.STRING, "vehicle.storeData.specs.fillTypes", "Fill types")
	v3:register(XMLValueType.STRING, "vehicle.storeData.specs.fillTypeCategories", "Fill type categories")
	v3:register(XMLValueType.STRING, "vehicle.storeData.specs.fruitTypes", "Fruit types")
	v3:register(XMLValueType.STRING, "vehicle.storeData.specs.fruitTypeCategories", "Fruit type categories")
	v3:register(XMLValueType.FLOAT, "vehicle.storeData.specs.capacity", "Capacity")
	FillUnit.registerUnitDisplaySchema(v3, "vehicle.storeData.specs.capacity")
	v3:register(XMLValueType.BOOL, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits#removeVehicleIfEmpty", "Remove vehicle if unit empty", false)
	v3:register(XMLValueType.FLOAT, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits#removeVehicleThreshold", "Remove vehicle if empty threshold in liters", 0)
	v3:register(XMLValueType.TIME, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits#removeVehicleDelay", "Delay for vehicle removal (e.g. can be used while sounds are still playing)", 0)
	v3:register(XMLValueType.FLOAT, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits#removeVehicleReward", "Amount of money as reward of removing the pallet", 0)
	v3:register(XMLValueType.BOOL, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits#allowFoldingWhileFilled", "Allow folding while filled", true)
	v3:register(XMLValueType.FLOAT, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits#allowFoldingThreshold", "Allow folding threshold", 0.0001)
	v3:register(XMLValueType.FLOAT, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits#fillTypeChangeThreshold", "Fill type overwrite threshold", 0.05)
	v3:register(XMLValueType.FLOAT, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits.fillTrigger#litersPerSecond", "Fill liters per second", 200)
	v3:register(XMLValueType.BOOL, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits.fillTrigger#consumePtoPower", "Consume pto power while filling", false)
	local v4 = FillUnit.FILL_UNIT_XML_KEY
	v3:register(XMLValueType.FLOAT, v4 .. "#capacity", "Capacity", "unlimited")
	v3:register(XMLValueType.BOOL, v4 .. "#updateMass", "Update vehicle mass while fill level changes", true)
	v3:register(XMLValueType.BOOL, v4 .. "#canBeUnloaded", "Can be unloaded", true)
	v3:register(XMLValueType.FLOAT, v4 .. "#allowFoldingThreshold", "Allow folding threshold", "Value of fillUnits#allowFoldingThreshold")
	FillUnit.registerUnitDisplaySchema(v3, v4)
	v3:register(XMLValueType.BOOL, v4 .. "#showCapacityInShop", "Show capacity in shop", true)
	v3:register(XMLValueType.BOOL, v4 .. "#showInShop", "Show in shop", true)
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".exactFillRootNode#node", "Exact fill root node")
	v3:register(XMLValueType.FLOAT, v4 .. ".exactFillRootNode#extraEffectDistance", "Exact fill root node extra distance", 0)
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".autoAimTargetNode#node", "Auto aim target node")
	v3:register(XMLValueType.FLOAT, v4 .. ".autoAimTargetNode#startZ", "Start Z translation")
	v3:register(XMLValueType.FLOAT, v4 .. ".autoAimTargetNode#endZ", "End Z translation")
	v3:register(XMLValueType.FLOAT, v4 .. ".autoAimTargetNode#startPercentage", "Start move percentage")
	v3:register(XMLValueType.BOOL, v4 .. ".autoAimTargetNode#invert", "Invert Z movement")
	v3:register(XMLValueType.STRING, v4 .. "#fillTypeCategories", "Supported fill type categories")
	v3:register(XMLValueType.STRING, v4 .. "#fillTypes", "Supported fill types")
	v3:register(XMLValueType.FLOAT, v4 .. "#startFillLevel", "Start fill level")
	v3:register(XMLValueType.STRING, v4 .. "#startFillType", "Start fill type")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".fillRootNode#node", "Fill root node", "first component")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".fillMassNode#node", "Fill root node", "first component")
	v3:register(XMLValueType.BOOL, v4 .. "#updateFillLevelMass", "Update fill level mass", true)
	v3:register(XMLValueType.BOOL, v4 .. "#ignoreFillLimit", "Ignores limiting of filling if the max mass is reached (if the settings is turned on)", false)
	v3:register(XMLValueType.BOOL, v4 .. "#synchronizeFillLevel", "Synchronize fill level", true)
	v3:register(XMLValueType.BOOL, v4 .. "#synchronizeFullFillLevel", "Synchronize fill level as 32bit float instead of percentage with max. 16 bits", false)
	v3:register(XMLValueType.INT, v4 .. "#synchronizationNumBits", "Synchronization bits")
	v3:register(XMLValueType.BOOL, v4 .. "#showOnHud", "Show on HUD", true)
	v3:register(XMLValueType.BOOL, v4 .. "#showOnInfoHud", "Show on Info HUD", true)
	v3:register(XMLValueType.INT, v4 .. "#uiPrecision", "Precision in UI display", 0)
	v3:register(XMLValueType.L10N_STRING, v4 .. "#uiCustomFillTypeName", "Custom fill type name for UI display")
	v3:register(XMLValueType.STRING, v4 .. "#uiDisplayType", "The style that is used for the display of the fill level in the HUD (\'BAR\' or \'STEP\')", "BAR")
	v3:register(XMLValueType.BOOL, v4 .. "#blocksAutomatedTrainTravel", "Block automated train travel if not empty", false)
	v3:register(XMLValueType.STRING, v4 .. "#fillAnimation", "Fill animation name")
	v3:register(XMLValueType.FLOAT, v4 .. "#fillAnimationLoadTime", "Fill animation load time")
	v3:register(XMLValueType.FLOAT, v4 .. "#fillAnimationEmptyTime", "Fill animation empty time")
	v3:register(XMLValueType.STRING, v4 .. ".fillLevelAnimation(?)#name", "Fill level animation name (Animation time is set depending on fill level percentage)")
	v3:register(XMLValueType.BOOL, v4 .. ".fillLevelAnimation(?)#resetOnEmpty", "Update animation when fill level reaches zero", true)
	v3:register(XMLValueType.BOOL, v4 .. ".fillLevelAnimation(?)#updateWhileFilled", "Animation will be updated while filled (If not \'true\', the animation will be set the the max. state)", true)
	v3:register(XMLValueType.BOOL, v4 .. ".fillLevelAnimation(?)#useMaxStateIfEmpty", "If the fill unit is empty, the animation will use the max. state", true)
	v3:register(XMLValueType.FLOAT, v4 .. ".alarmTriggers.alarmTrigger(?)#minFillLevel", "Fill animation empty time")
	v3:register(XMLValueType.FLOAT, v4 .. ".alarmTriggers.alarmTrigger(?)#maxFillLevel", "Fill animation empty time")
	v3:register(XMLValueType.BOOL, v4 .. ".alarmTriggers.alarmTrigger(?)#needsTurnOn", "Needs turn on", false)
	v3:register(XMLValueType.BOOL, v4 .. ".alarmTriggers.alarmTrigger(?)#turnOffInTrigger", "Turn off in trigger", false)
	SoundManager.registerSampleXMLPaths(v3, v4 .. ".alarmTriggers.alarmTrigger(?)", "alarmSound")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".measurementNodes.measurementNode(?)#node", "Measurement node")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".fillPlane.node(?)#node", "Fill plane node")
	v3:register(XMLValueType.FLOAT, v4 .. ".fillPlane.node(?).key(?)#time", "Key time")
	v3:register(XMLValueType.VECTOR_TRANS, v4 .. ".fillPlane.node(?).key(?)#translation", "Translation")
	v3:register(XMLValueType.FLOAT, v4 .. ".fillPlane.node(?).key(?)#y", "Y Translation")
	v3:register(XMLValueType.VECTOR_ROT, v4 .. ".fillPlane.node(?).key(?)#rotation", "Rotation")
	v3:register(XMLValueType.VECTOR_SCALE, v4 .. ".fillPlane.node(?).key(?)#scale", "Scale")
	v3:register(XMLValueType.VECTOR_2, v4 .. ".fillPlane.node(?)#minMaxY", "Min. and max. Y translation")
	v3:register(XMLValueType.BOOL, v4 .. ".fillPlane.node(?)#alwaysVisible", "Is always visible", false)
	v3:register(XMLValueType.STRING, v4 .. ".fillPlane#defaultFillType", "Default fill type name")
	v3:register(XMLValueType.STRING, v4 .. ".fillTypeMaterials.material(?)#fillType", "Fill type name")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".fillTypeMaterials.material(?)#node", "Node which receives material")
	v3:register(XMLValueType.NODE_INDEX, v4 .. ".fillTypeMaterials.material(?)#refNode", "Node which provides material")
	v3:register(XMLValueType.STRING, v4 .. ".fillTypeMaterials.material(?)#materialSlotName", "Material slot name to apply the defined texture as diffuse map")
	v3:register(XMLValueType.FILENAME, v4 .. ".fillTypeMaterials.material(?)#diffuse", "Path to a custom diffuse texture to apply")
	EffectManager.registerEffectXMLPaths(v3, v4 .. ".fillEffect")
	AnimationManager.registerAnimationNodesXMLPaths(v3, v4 .. ".animationNodes")
	Dashboard.registerDashboardXMLPaths(v3, v4, { "fillLevel", "fillLevelPct", "fillLevelWarning" })
	Dashboard.addDelayedRegistrationFunc(v3, function(p5, p6)
		p5:register(XMLValueType.STRING, p6 .. "#fillType", "Fill type of fillUnit to be used")
		p5:register(XMLValueType.INT, p6 .. "#fillUnitIndex", "Fill unit index to represent")
	end)
	v3:register(XMLValueType.NODE_INDEX, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits.unloading(?)#node", "Unloading node")
	v3:register(XMLValueType.FLOAT, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits.unloading(?)#width", "Unloading width", 15)
	v3:register(XMLValueType.VECTOR_TRANS, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits.unloading(?)#offset", "Unloading offset", "0 0 0")
	EffectManager.registerEffectXMLPaths(v3, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits.fillEffect")
	AnimationManager.registerAnimationNodesXMLPaths(v3, FillUnit.FILL_UNIT_CONFIG_XML_KEY .. ".fillUnits.animationNodes")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.fillUnit.sounds", "fill")
	v3:register(XMLValueType.INT, Leveler.LEVELER_NODE_XML_KEY .. "#fillUnitIndex", "Reference fill unit index", 1)
	v3:register(XMLValueType.FLOAT, Leveler.LEVELER_NODE_XML_KEY .. "#minFillLevel", "Min. fill level to activate leveler node (pct between 0 and 1)", 0)
	v3:register(XMLValueType.FLOAT, Leveler.LEVELER_NODE_XML_KEY .. "#maxFillLevel", "Max. fill level to activate leveler node (pct between 0 and 1)", 1)
	v3:setXMLSpecializationType()
	local v7 = Vehicle.xmlSchemaSavegame
	v7:register(XMLValueType.INT, "vehicles.vehicle(?).fillUnit.unit(?)#index", "Fill Unit index")
	v7:register(XMLValueType.STRING, "vehicles.vehicle(?).fillUnit.unit(?)#fillType", "Fill type")
	v7:register(XMLValueType.FLOAT, "vehicles.vehicle(?).fillUnit.unit(?)#fillLevel", "Fill level")
end
function FillUnit.registerUnitDisplaySchema(p8, p9)
	p8:register(XMLValueType.STRING, p9 .. "#shopDisplayUnit", "Unit used for displaying the capacity in shop (converts to given unit from capacity in liters)", "LITER", false, table.toList(FillUnit.UNIT))
	p8:register(XMLValueType.STRING, p9 .. "#unitTextOverride", "Unit text override, no conversion performed on given capacity")
end
function FillUnit.prerequisitesPresent(_)
	return true
end
function FillUnit.registerEvents(p10)
	SpecializationUtil.registerEvent(p10, "onFillUnitFillLevelChanged")
	SpecializationUtil.registerEvent(p10, "onChangedFillType")
	SpecializationUtil.registerEvent(p10, "onAlarmTriggerChanged")
	SpecializationUtil.registerEvent(p10, "onAddedFillUnitTrigger")
	SpecializationUtil.registerEvent(p10, "onFillUnitTriggerChanged")
	SpecializationUtil.registerEvent(p10, "onRemovedFillUnitTrigger")
	SpecializationUtil.registerEvent(p10, "onFillUnitIsFillingStateChanged")
	SpecializationUtil.registerEvent(p10, "onFillUnitUnloadPallet")
end
function FillUnit.registerFunctions(p11)
	SpecializationUtil.registerFunction(p11, "getDrawFirstFillText", FillUnit.getDrawFirstFillText)
	SpecializationUtil.registerFunction(p11, "getFillUnits", FillUnit.getFillUnits)
	SpecializationUtil.registerFunction(p11, "getFillUnitByIndex", FillUnit.getFillUnitByIndex)
	SpecializationUtil.registerFunction(p11, "getFillUnitExists", FillUnit.getFillUnitExists)
	SpecializationUtil.registerFunction(p11, "getFillUnitCapacity", FillUnit.getFillUnitCapacity)
	SpecializationUtil.registerFunction(p11, "getFillUnitFreeCapacity", FillUnit.getFillUnitFreeCapacity)
	SpecializationUtil.registerFunction(p11, "getIsFillAllowedFromFarm", FillUnit.getIsFillAllowedFromFarm)
	SpecializationUtil.registerFunction(p11, "getFillUnitFillLevel", FillUnit.getFillUnitFillLevel)
	SpecializationUtil.registerFunction(p11, "getFillUnitFillLevelPercentage", FillUnit.getFillUnitFillLevelPercentage)
	SpecializationUtil.registerFunction(p11, "getFillUnitFillType", FillUnit.getFillUnitFillType)
	SpecializationUtil.registerFunction(p11, "getFillUnitLastValidFillType", FillUnit.getFillUnitLastValidFillType)
	SpecializationUtil.registerFunction(p11, "getFillUnitFirstSupportedFillType", FillUnit.getFillUnitFirstSupportedFillType)
	SpecializationUtil.registerFunction(p11, "getFillUnitExactFillRootNode", FillUnit.getFillUnitExactFillRootNode)
	SpecializationUtil.registerFunction(p11, "getFillUnitRootNode", FillUnit.getFillUnitRootNode)
	SpecializationUtil.registerFunction(p11, "getFillUnitAutoAimTargetNode", FillUnit.getFillUnitAutoAimTargetNode)
	SpecializationUtil.registerFunction(p11, "getFillUnitSupportsFillType", FillUnit.getFillUnitSupportsFillType)
	SpecializationUtil.registerFunction(p11, "getFillUnitSupportsToolType", FillUnit.getFillUnitSupportsToolType)
	SpecializationUtil.registerFunction(p11, "getFillUnitSupportsToolTypeAndFillType", FillUnit.getFillUnitSupportsToolTypeAndFillType)
	SpecializationUtil.registerFunction(p11, "getFillUnitSupportedFillTypes", FillUnit.getFillUnitSupportedFillTypes)
	SpecializationUtil.registerFunction(p11, "getFillUnitSupportedToolTypes", FillUnit.getFillUnitSupportedToolTypes)
	SpecializationUtil.registerFunction(p11, "getFillUnitAllowsFillType", FillUnit.getFillUnitAllowsFillType)
	SpecializationUtil.registerFunction(p11, "getFillTypeChangeThreshold", FillUnit.getFillTypeChangeThreshold)
	SpecializationUtil.registerFunction(p11, "getFirstValidFillUnitToFill", FillUnit.getFirstValidFillUnitToFill)
	SpecializationUtil.registerFunction(p11, "getFillUnitCanBeFilled", FillUnit.getFillUnitCanBeFilled)
	SpecializationUtil.registerFunction(p11, "setFillUnitFillType", FillUnit.setFillUnitFillType)
	SpecializationUtil.registerFunction(p11, "setFillUnitFillTypeToDisplay", FillUnit.setFillUnitFillTypeToDisplay)
	SpecializationUtil.registerFunction(p11, "setFillUnitFillLevelToDisplay", FillUnit.setFillUnitFillLevelToDisplay)
	SpecializationUtil.registerFunction(p11, "setFillUnitCapacityToDisplay", FillUnit.setFillUnitCapacityToDisplay)
	SpecializationUtil.registerFunction(p11, "setFillUnitCapacity", FillUnit.setFillUnitCapacity)
	SpecializationUtil.registerFunction(p11, "setFillUnitForcedMaterialFillType", FillUnit.setFillUnitForcedMaterialFillType)
	SpecializationUtil.registerFunction(p11, "getFillUnitForcedMaterialFillType", FillUnit.getFillUnitForcedMaterialFillType)
	SpecializationUtil.registerFunction(p11, "setFillUnitInTriggerRange", FillUnit.setFillUnitInTriggerRange)
	SpecializationUtil.registerFunction(p11, "updateAlarmTriggers", FillUnit.updateAlarmTriggers)
	SpecializationUtil.registerFunction(p11, "getAlarmTriggerIsActive", FillUnit.getAlarmTriggerIsActive)
	SpecializationUtil.registerFunction(p11, "setAlarmTriggerState", FillUnit.setAlarmTriggerState)
	SpecializationUtil.registerFunction(p11, "getFillUnitIndexFromNode", FillUnit.getFillUnitIndexFromNode)
	SpecializationUtil.registerFunction(p11, "getFillUnitExtraDistanceFromNode", FillUnit.getFillUnitExtraDistanceFromNode)
	SpecializationUtil.registerFunction(p11, "getFillUnitFromNode", FillUnit.getFillUnitFromNode)
	SpecializationUtil.registerFunction(p11, "addFillUnitFillLevel", FillUnit.addFillUnitFillLevel)
	SpecializationUtil.registerFunction(p11, "setFillUnitLastValidFillType", FillUnit.setFillUnitLastValidFillType)
	SpecializationUtil.registerFunction(p11, "loadFillUnitFromXML", FillUnit.loadFillUnitFromXML)
	SpecializationUtil.registerFunction(p11, "loadAlarmTrigger", FillUnit.loadAlarmTrigger)
	SpecializationUtil.registerFunction(p11, "loadMeasurementNode", FillUnit.loadMeasurementNode)
	SpecializationUtil.registerFunction(p11, "updateMeasurementNodes", FillUnit.updateMeasurementNodes)
	SpecializationUtil.registerFunction(p11, "loadFillPlane", FillUnit.loadFillPlane)
	SpecializationUtil.registerFunction(p11, "setFillPlaneForcedFillType", FillUnit.setFillPlaneForcedFillType)
	SpecializationUtil.registerFunction(p11, "updateFillUnitFillPlane", FillUnit.updateFillUnitFillPlane)
	SpecializationUtil.registerFunction(p11, "loadFillTypeMaterials", FillUnit.loadFillTypeMaterials)
	SpecializationUtil.registerFunction(p11, "updateFillTypeMaterials", FillUnit.updateFillTypeMaterials)
	SpecializationUtil.registerFunction(p11, "updateFillUnitAutoAimTarget", FillUnit.updateFillUnitAutoAimTarget)
	SpecializationUtil.registerFunction(p11, "addFillUnitTrigger", FillUnit.addFillUnitTrigger)
	SpecializationUtil.registerFunction(p11, "removeFillUnitTrigger", FillUnit.removeFillUnitTrigger)
	SpecializationUtil.registerFunction(p11, "setFillUnitIsFilling", FillUnit.setFillUnitIsFilling)
	SpecializationUtil.registerFunction(p11, "setFillSoundIsPlaying", FillUnit.setFillSoundIsPlaying)
	SpecializationUtil.registerFunction(p11, "getIsFillUnitActive", FillUnit.getIsFillUnitActive)
	SpecializationUtil.registerFunction(p11, "updateFillUnitTriggers", FillUnit.updateFillUnitTriggers)
	SpecializationUtil.registerFunction(p11, "emptyAllFillUnits", FillUnit.emptyAllFillUnits)
	SpecializationUtil.registerFunction(p11, "unloadFillUnits", FillUnit.unloadFillUnits)
	SpecializationUtil.registerFunction(p11, "loadFillUnitUnloadingFromXML", FillUnit.loadFillUnitUnloadingFromXML)
	SpecializationUtil.registerFunction(p11, "getFillUnitUnloadPalletFilename", FillUnit.getFillUnitUnloadPalletFilename)
	SpecializationUtil.registerFunction(p11, "getFillUnitHasMountedPalletsToUnload", FillUnit.getFillUnitHasMountedPalletsToUnload)
	SpecializationUtil.registerFunction(p11, "getFillUnitMountedPalletsToUnload", FillUnit.getFillUnitMountedPalletsToUnload)
	SpecializationUtil.registerFunction(p11, "getAllowLoadTriggerActivation", FillUnit.getAllowLoadTriggerActivation)
	SpecializationUtil.registerFunction(p11, "addExactFillRootAimToUpdate", FillUnit.addExactFillRootAimToUpdate)
	SpecializationUtil.registerFunction(p11, "debugGetSupportedFillTypesPerFillUnit", FillUnit.debugGetSupportedFillTypesPerFillUnit)
end
function FillUnit.registerOverwrittenFunctions(p12)
	SpecializationUtil.registerOverwrittenFunction(p12, "getAdditionalComponentMass", FillUnit.getAdditionalComponentMass)
	SpecializationUtil.registerOverwrittenFunction(p12, "getFillLevelInformation", FillUnit.getFillLevelInformation)
	SpecializationUtil.registerOverwrittenFunction(p12, "getIsFoldAllowed", FillUnit.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p12, "getIsReadyForAutomatedTrainTravel", FillUnit.getIsReadyForAutomatedTrainTravel)
	SpecializationUtil.registerOverwrittenFunction(p12, "loadMovingToolFromXML", FillUnit.loadMovingToolFromXML)
	SpecializationUtil.registerOverwrittenFunction(p12, "getIsMovingToolActive", FillUnit.getIsMovingToolActive)
	SpecializationUtil.registerOverwrittenFunction(p12, "getDoConsumePtoPower", FillUnit.getDoConsumePtoPower)
	SpecializationUtil.registerOverwrittenFunction(p12, "getIsPowerTakeOffActive", FillUnit.getIsPowerTakeOffActive)
	SpecializationUtil.registerOverwrittenFunction(p12, "getCanBeTurnedOn", FillUnit.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p12, "showInfo", FillUnit.showInfo)
	SpecializationUtil.registerOverwrittenFunction(p12, "loadLevelerNodeFromXML", FillUnit.loadLevelerNodeFromXML)
	SpecializationUtil.registerOverwrittenFunction(p12, "getIsLevelerPickupNodeActive", FillUnit.getIsLevelerPickupNodeActive)
end
function FillUnit.registerEventListeners(p13)
	SpecializationUtil.registerEventListener(p13, "onLoad", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onPostLoad", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onDelete", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onReadStream", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onWriteStream", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onReadUpdateStream", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onWriteUpdateStream", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onUpdateTick", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onPostUpdate", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onDraw", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onDeactivate", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onRegisterActionEvents", FillUnit)
	SpecializationUtil.registerEventListener(p13, "onDischargeTargetObjectChanged", FillUnit)
end
function FillUnit.onLoad(p_u_14, _)
	local v_u_15 = p_u_14.spec_fillUnit
	XMLUtil.checkDeprecatedXMLElements(p_u_14.xmlFile, "vehicle.measurementNodes.measurementNode", "vehicle.fillUnit.fillUnitConfigurations.fillUnitConfiguration.fillUnits.fillUnit.measurementNodes.measurementNode")
	XMLUtil.checkDeprecatedXMLElements(p_u_14.xmlFile, "vehicle.fillPlanes.fillPlane", "vehicle.fillUnit.fillUnitConfigurations.fillUnitConfiguration.fillUnits.fillUnit.fillPlane")
	XMLUtil.checkDeprecatedXMLElements(p_u_14.xmlFile, "vehicle.foldable.foldingParts#onlyFoldOnEmpty", "vehicle.fillUnit#allowFoldingWhileFilled")
	XMLUtil.checkDeprecatedXMLElements(p_u_14.xmlFile, "vehicle.fillAutoAimTargetNode", "vehicle.fillUnit.fillUnitConfigurations.fillUnitConfiguration.fillUnits.fillUnit.autoAimTargetNode")
	local v16 = Utils.getNoNil(p_u_14.configurations.fillUnit, 1)
	local v17 = string.format("vehicle.fillUnit.fillUnitConfigurations.fillUnitConfiguration(%d).fillUnits", v16 - 1)
	v_u_15.removeVehicleIfEmpty = p_u_14.xmlFile:getValue(v17 .. "#removeVehicleIfEmpty", false)
	v_u_15.removeVehicleThreshold = p_u_14.xmlFile:getValue(v17 .. "#removeVehicleThreshold", 0)
	v_u_15.removeVehicleDelay = p_u_14.xmlFile:getValue(v17 .. "#removeVehicleDelay", 0)
	v_u_15.removeVehicleReward = p_u_14.xmlFile:getValue(v17 .. "#removeVehicleReward", 0)
	v_u_15.allowFoldingWhileFilled = p_u_14.xmlFile:getValue(v17 .. "#allowFoldingWhileFilled", true)
	v_u_15.allowFoldingThreshold = p_u_14.xmlFile:getValue(v17 .. "#allowFoldingThreshold", 0.0001)
	v_u_15.fillTypeChangeThreshold = p_u_14.xmlFile:getValue(v17 .. "#fillTypeChangeThreshold", 0.05)
	v_u_15.fillUnits = {}
	v_u_15.exactFillRootNodeToFillUnit = {}
	v_u_15.exactFillRootNodeToExtraDistance = {}
	v_u_15.exactFillRootNodeAimToUpdate = {}
	v_u_15.hasExactFillRootNodes = false
	v_u_15.activeAlarmTriggers = {}
	v_u_15.fillTrigger = {}
	v_u_15.fillTrigger.triggers = {}
	v_u_15.fillTrigger.activatable = FillActivatable.new(p_u_14)
	v_u_15.fillTrigger.isFilling = false
	v_u_15.fillTrigger.currentTrigger = nil
	v_u_15.fillTrigger.selectedTrigger = nil
	v_u_15.fillTrigger.litersPerSecond = p_u_14.xmlFile:getValue(v17 .. ".fillTrigger#litersPerSecond", 200)
	v_u_15.fillTrigger.consumePtoPower = p_u_14.xmlFile:getValue(v17 .. ".fillTrigger#consumePtoPower", false)
	local v_u_18 = 0
	while true do
		local v19 = string.format("%s.fillUnit(%d)", v17, v_u_18)
		if not p_u_14.xmlFile:hasProperty(v19) then
			break
		end
		local v20 = {}
		if not p_u_14:loadFillUnitFromXML(p_u_14.xmlFile, v19, v20, v_u_18 + 1) then
			Logging.xmlWarning(p_u_14.xmlFile, "Could not load fillUnit for \'%s\'", v19)
			p_u_14:setLoadingState(VehicleLoadingState.ERROR)
			break
		end
		local v21 = v_u_15.fillUnits
		table.insert(v21, v20)
		v_u_18 = v_u_18 + 1
	end
	if p_u_14.xmlFile:hasProperty(v17 .. ".unloading") then
		v_u_15.unloading = {}
		p_u_14.xmlFile:iterate(v17 .. ".unloading", function(_, p22)
			-- upvalues: (copy) p_u_14, (ref) v_u_18, (copy) v_u_15
			local v23 = {}
			if not p_u_14:loadFillUnitUnloadingFromXML(p_u_14.xmlFile, p22, v23, v_u_18 + 1) then
				Logging.xmlWarning(p_u_14.xmlFile, "Could not load unloading node for \'%s\'", p22)
				return false
			end
			local v24 = v_u_15.unloading
			table.insert(v24, v23)
		end)
	end
	if p_u_14.isClient then
		v_u_15.samples = {}
		v_u_15.samples.fill = g_soundManager:loadSampleFromXML(p_u_14.xmlFile, "vehicle.fillUnit.sounds", "fill", p_u_14.baseDirectory, p_u_14.components, 0, AudioGroup.VEHICLE, p_u_14.i3dMappings, p_u_14)
		v_u_15.fillEffects = g_effectManager:loadEffect(p_u_14.xmlFile, v17 .. ".fillEffect", p_u_14.components, p_u_14, p_u_14.i3dMappings)
		v_u_15.animationNodes = g_animationManager:loadAnimations(p_u_14.xmlFile, v17 .. ".animationNodes", p_u_14.components, p_u_14, p_u_14.i3dMappings)
		v_u_15.activeFillEffects = {}
		v_u_15.activeFillAnimations = {}
	end
	v_u_15.texts = {}
	v_u_15.texts.warningFoldingFilled = g_i18n:getText("warning_foldingNotWhileFilled")
	v_u_15.texts.firstFillTheTool = g_i18n:getText("info_firstFillTheTool")
	v_u_15.texts.unloadNoSpace = g_i18n:getText("fillUnit_unload_nospace")
	v_u_15.texts.stopRefill = g_i18n:getText("action_stopRefillingOBJECT")
	v_u_15.texts.startRefill = g_i18n:getText("action_refillOBJECT")
	v_u_15.isInfoDirty = false
	v_u_15.fillUnitInfos = {}
	v_u_15.dirtyFlag = p_u_14:getNextDirtyFlag()
end
function FillUnit.onPostLoad(p25, p26)
	local v27 = p25.spec_fillUnit
	if p25.isServer then
		local v28 = {}
		for v29, v30 in ipairs(v27.fillUnits) do
			if v30.startFillLevel == nil and v30.startFillTypeIndex == nil then
				v28[v29] = v30
			end
		end
		if p26 == nil or not p26.xmlFile:hasProperty(p26.key .. ".fillUnit") then
			if not p25.vehicleLoadingData:getCustomParameter("spawnEmpty") then
				for v31, v32 in pairs(v27.fillUnits) do
					if v32.startFillLevel ~= nil and v32.startFillTypeIndex ~= nil then
						p25:addFillUnitFillLevel(p25:getOwnerFarmId(), v31, v32.startFillLevel, v32.startFillTypeIndex, ToolType.UNDEFINED, nil)
						for _, v33 in ipairs(v32.fillLevelAnimations) do
							AnimatedVehicle.updateAnimationByName(p25, v33.name, 9999999, true)
						end
					end
				end
			end
		else
			local v34 = p26.xmlFile
			local v35 = 0
			while true do
				local v36 = string.format("%s.fillUnit.unit(%d)", p26.key, v35)
				if not v34:hasProperty(v36) then
					break
				end
				local v37 = v34:getValue(v36 .. "#index")
				local v38
				if v28[v37] == nil then
					v38 = true
				elseif v28[v37] == nil then
					v38 = false
				else
					v38 = not p26.resetVehicles
				end
				if v38 then
					local v39 = v34:getValue(v36 .. "#fillType")
					local v40 = v34:getValue(v36 .. "#fillLevel")
					local v41 = g_fillTypeManager:getFillTypeIndexByName(v39)
					p25:addFillUnitFillLevel(p25:getOwnerFarmId(), v37, v40, v41, ToolType.UNDEFINED, nil)
					local v42 = v27.fillUnits[v37]
					if v42 ~= nil then
						for _, v43 in ipairs(v42.fillLevelAnimations) do
							AnimatedVehicle.updateAnimationByName(p25, v43.name, 9999999, true)
						end
					end
				end
				v35 = v35 + 1
			end
		end
		for _, v44 in ipairs(v27.fillUnits) do
			p25:updateAlarmTriggers(v44.alarmTriggers)
		end
	end
	if #v27.fillUnits == 0 then
		SpecializationUtil.removeEventListener(p25, "onReadStream", FillUnit)
		SpecializationUtil.removeEventListener(p25, "onWriteStream", FillUnit)
		SpecializationUtil.removeEventListener(p25, "onReadUpdateStream", FillUnit)
		SpecializationUtil.removeEventListener(p25, "onWriteUpdateStream", FillUnit)
		SpecializationUtil.removeEventListener(p25, "onUpdateTick", FillUnit)
		SpecializationUtil.removeEventListener(p25, "onPostUpdate", FillUnit)
		SpecializationUtil.removeEventListener(p25, "onDraw", FillUnit)
		SpecializationUtil.removeEventListener(p25, "onDeactivate", FillUnit)
		SpecializationUtil.removeEventListener(p25, "onRegisterActionEvents", FillUnit)
	end
end
function FillUnit.onDelete(p45)
	local v46 = p45.spec_fillUnit
	if v46.fillTrigger ~= nil then
		g_currentMission.activatableObjectsSystem:removeActivatable(v46.fillTrigger.activatable)
		for _, v47 in pairs(v46.fillTrigger.triggers) do
			v47:onVehicleDeleted(p45)
		end
	end
	if v46.fillUnits ~= nil then
		for _, v48 in ipairs(v46.fillUnits) do
			for _, v49 in ipairs(v48.alarmTriggers) do
				g_soundManager:deleteSample(v49.sample)
			end
			if v48.exactFillRootNode ~= nil then
				g_currentMission:removeNodeObject(v48.exactFillRootNode)
			end
		end
	end
	g_soundManager:deleteSamples(v46.samples)
	if v46.unloadTrigger ~= nil then
		v46.unloadTrigger:delete()
	end
	if v46.loadTrigger ~= nil then
		v46.loadTrigger:delete()
	end
end
function FillUnit.saveToXMLFile(p50, p51, p52, _)
	local v53 = p50.spec_fillUnit
	local v54 = 0
	for v55, v56 in ipairs(v53.fillUnits) do
		if v56.needsSaving then
			local v57 = string.format("%s.unit(%d)", p52, v54)
			local v58 = Utils.getNoNil(g_fillTypeManager:getFillTypeNameByIndex(v56.fillType), "unknown")
			p51:setValue(v57 .. "#index", v55)
			p51:setValue(v57 .. "#fillType", v58)
			p51:setValue(v57 .. "#fillLevel", v56.fillLevel)
			v54 = v54 + 1
		end
	end
end
function FillUnit.saveStatsToXMLFile(p59, p60, p61)
	local v62 = p59.spec_fillUnit
	local v63 = #v62.fillUnits
	local v64 = ""
	local v65 = ""
	for v66, v67 in ipairs(v62.fillUnits) do
		local v68 = Utils.getNoNil(g_fillTypeManager:getFillTypeNameByIndex(v67.fillType), "unknown")
		v64 = v64 .. HTMLUtil.encodeToHTML((tostring(v68)))
		v65 = v65 .. string.format("%.3f", v67.fillLevel)
		if v63 > 1 and v66 ~= v63 then
			v64 = v64 .. " "
			v65 = v65 .. " "
		end
	end
	setXMLString(p60, p61 .. "#fillTypes", v64)
	setXMLString(p60, p61 .. "#fillLevels", v65)
end
function FillUnit.onReadStream(p69, p70, p71)
	if p71:getIsServer() then
		local v72 = p69.spec_fillUnit
		p69:setFillUnitIsFilling(streamReadBool(p70), true)
		if v72.loadTrigger ~= nil then
			local v73 = streamReadInt32(p70)
			v72.loadTrigger:readStream(p70, p71)
			g_client:finishRegisterObject(p69.loadTrigger, v73)
		end
		if v72.unloadTrigger ~= nil then
			local v74 = streamReadInt32(p70)
			v72.unloadTrigger:readStream(p70, p71)
			g_client:finishRegisterObject(p69.unloadTrigger, v74)
		end
		for v75 = 1, #v72.fillUnits do
			if v72.fillUnits[v75].synchronizeFillLevel then
				local v76 = streamReadFloat32(p70)
				local v77 = streamReadUIntN(p70, FillTypeManager.SEND_NUM_BITS)
				p69:addFillUnitFillLevel(p69:getOwnerFarmId(), v75, v76, v77, ToolType.UNDEFINED, nil)
				p69:setFillUnitLastValidFillType(v75, streamReadUIntN(p70, FillTypeManager.SEND_NUM_BITS), true)
			end
		end
	end
end
function FillUnit.onWriteStream(p78, p79, p80)
	if not p80:getIsServer() then
		local v81 = p78.spec_fillUnit
		streamWriteBool(p79, v81.fillTrigger.isFilling)
		if v81.loadTrigger ~= nil then
			streamWriteInt32(p79, NetworkUtil.getObjectId(v81.loadTrigger))
			v81.loadTrigger:writeStream(p79, p80)
			g_server:registerObjectInStream(p80, v81.loadTrigger)
		end
		if v81.unloadTrigger ~= nil then
			streamWriteInt32(p79, NetworkUtil.getObjectId(v81.unloadTrigger))
			v81.unloadTrigger:writeStream(p79, p80)
			g_server:registerObjectInStream(p80, v81.unloadTrigger)
		end
		for v82 = 1, #v81.fillUnits do
			if v81.fillUnits[v82].synchronizeFillLevel then
				local v83 = v81.fillUnits[v82]
				streamWriteFloat32(p79, v83.fillLevel)
				streamWriteUIntN(p79, v83.fillType, FillTypeManager.SEND_NUM_BITS)
				streamWriteUIntN(p79, v83.lastValidFillType, FillTypeManager.SEND_NUM_BITS)
			end
		end
	end
end
function FillUnit.onReadUpdateStream(p84, p85, _, p86)
	if p86:getIsServer() then
		local v87 = p84.spec_fillUnit
		if streamReadBool(p85) then
			for v88 = 1, #v87.fillUnits do
				local v89 = v87.fillUnits[v88]
				if v89.synchronizeFillLevel then
					local v90
					if v89.synchronizeFullFillLevel then
						v90 = streamReadFloat32(p85)
					else
						local v91 = 2 ^ v89.synchronizationNumBits - 1
						v90 = v89.capacity * streamReadUIntN(p85, v89.synchronizationNumBits) / v91
					end
					local v92 = streamReadUIntN(p85, FillTypeManager.SEND_NUM_BITS)
					if v90 ~= v89.fillLevel or v92 ~= v89.fillType then
						local v93 = p84:getFillUnitFillType(v88)
						if v92 == FillType.UNKNOWN then
							p84:addFillUnitFillLevel(p84:getOwnerFarmId(), v88, (-1 / 0), v93, ToolType.UNDEFINED, nil)
						else
							if v93 ~= FillType.UNKNOWN and v92 ~= v93 then
								p84:setFillUnitFillType(v88, v92)
							end
							p84:addFillUnitFillLevel(p84:getOwnerFarmId(), v88, v90 - v89.fillLevel, v92, ToolType.UNDEFINED, nil)
						end
					end
					local v94 = streamReadUIntN(p85, FillTypeManager.SEND_NUM_BITS)
					p84:setFillUnitLastValidFillType(v88, v94, v94 ~= v89.lastValidFillType)
				end
			end
		end
	end
end
function FillUnit.onWriteUpdateStream(p95, p96, p97, p98)
	if not p97:getIsServer() then
		local v99 = p95.spec_fillUnit
		if streamWriteBool(p96, bitAND(p98, v99.dirtyFlag) ~= 0) then
			for v100 = 1, #v99.fillUnits do
				local v101 = v99.fillUnits[v100]
				if v101.synchronizeFillLevel then
					if v101.synchronizeFullFillLevel then
						streamWriteFloat32(p96, v101.fillLevelSent)
					else
						local v102
						if v101.capacity > 0 then
							local v103 = v101.fillLevelSent / v101.capacity
							v102 = math.clamp(v103, 0, 1)
						else
							v102 = 0
						end
						local v104 = v102 * (2 ^ v101.synchronizationNumBits - 1) + 0.5
						local v105 = math.floor(v104)
						streamWriteUIntN(p96, v105, v101.synchronizationNumBits)
					end
					streamWriteUIntN(p96, v101.fillTypeSent, FillTypeManager.SEND_NUM_BITS)
					streamWriteUIntN(p96, v101.lastValidFillTypeSent, FillTypeManager.SEND_NUM_BITS)
				end
			end
		end
	end
end
function FillUnit.onUpdateTick(p106, p107, _, _, _)
	local v108 = p106.spec_fillUnit
	if p106.isServer and v108.fillTrigger.isFilling then
		local v109 = v108.fillTrigger.currentTrigger
		if (v109 == nil and 0 or v109:fillVehicle(p106, v108.fillTrigger.litersPerSecond * p107 * 0.001, p107)) <= 0 then
			p106:setFillUnitIsFilling(false)
		end
	end
	if p106.isClient then
		for _, v110 in pairs(v108.fillUnits) do
			p106:updateMeasurementNodes(v110, p107, false)
		end
		p106:updateAlarmTriggers(v108.activeAlarmTriggers)
		local v111 = false
		for v112, v113 in pairs(v108.activeFillEffects) do
			local v114 = v113 - p107
			if v114 < 0 then
				g_effectManager:stopEffects(v112)
				v108.activeFillEffects[v112] = nil
			else
				v108.activeFillEffects[v112] = v114
				v111 = true
			end
		end
		for v115, v116 in pairs(v108.activeFillAnimations) do
			local v117 = v116 - p107
			if v117 < 0 then
				g_animationManager:stopAnimations(v115)
				v108.activeFillAnimations[v115] = nil
			else
				v108.activeFillAnimations[v115] = v117
				v111 = true
			end
		end
		if v111 then
			p106:raiseActive()
		end
	end
end
function FillUnit.onPostUpdate(p118, p119, _, _, _)
	local v120 = p118.spec_fillUnit
	for v121, v122 in pairs(v120.exactFillRootNodeAimToUpdate) do
		if not v121.isDeleted then
			v122(v121, p119)
		end
		v120.exactFillRootNodeAimToUpdate[v121] = nil
	end
end
function FillUnit.onDraw(p123, _, _, _)
	if p123:getDrawFirstFillText() then
		local v124 = p123.spec_fillUnit
		g_currentMission:addExtraPrintText(v124.texts.firstFillTheTool)
	end
end
function FillUnit.onDeactivate(p125)
	local v126 = p125.spec_fillUnit
	if v126.fillTrigger.isFilling then
		p125:setFillUnitIsFilling(false, true)
	end
	for _, v127 in pairs(v126.fillUnits) do
		p125:updateMeasurementNodes(v127, 0, false, 0)
	end
end
function FillUnit.onRegisterActionEvents(p128, _, p129)
	if p128.isClient then
		local v130 = p128.spec_fillUnit
		p128:clearActionEventsTable(v130.actionEvents)
		if p129 then
			if p128.isServer and (GS_IS_CONSOLE_VERSION and g_isDevelopmentVersion) then
				local _, v131 = p128:addActionEvent(v130.actionEvents, InputAction.CONSOLE_DEBUG_FILLUNIT_NEXT, p128, FillUnit.actionEventConsoleFillUnitNext, false, true, false, true, nil)
				g_inputBinding:setActionEventTextVisibility(v131, false)
				g_inputBinding:setActionEventTextPriority(v131, GS_PRIO_VERY_LOW)
				local _, v132 = p128:addActionEvent(v130.actionEvents, InputAction.CONSOLE_DEBUG_FILLUNIT_INC, p128, FillUnit.actionEventConsoleFillUnitInc, false, true, false, true, nil)
				g_inputBinding:setActionEventTextVisibility(v132, false)
				g_inputBinding:setActionEventTextPriority(v132, GS_PRIO_VERY_LOW)
				local _, v133 = p128:addActionEvent(v130.actionEvents, InputAction.CONSOLE_DEBUG_FILLUNIT_DEC, p128, FillUnit.actionEventConsoleFillUnitDec, false, true, false, true, nil)
				g_inputBinding:setActionEventTextVisibility(v133, false)
				g_inputBinding:setActionEventTextPriority(v133, GS_PRIO_VERY_LOW)
			end
			if v130.unloading ~= nil then
				local _, v134 = p128:addActionEvent(v130.actionEvents, InputAction.UNLOAD, p128, FillUnit.actionEventUnload, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v134, GS_PRIO_NORMAL)
				v130.unloadActionEventId = v134
				FillUnit.updateUnloadActionDisplay(p128)
			end
		end
	end
end
function FillUnit.onDischargeTargetObjectChanged(p135, _)
	FillUnit.updateUnloadActionDisplay(p135)
end
function FillUnit.getDrawFirstFillText(_)
	return false
end
function FillUnit.getFillUnits(p136)
	return p136.spec_fillUnit.fillUnits
end
function FillUnit.getFillUnitByIndex(p137, p138)
	local v139 = p137.spec_fillUnit
	if p137:getFillUnitExists(p138) then
		return v139.fillUnits[p138]
	else
		return nil
	end
end
function FillUnit.getFillUnitExists(p140, p141)
	local v142 = p140.spec_fillUnit
	local v143
	if p141 == nil then
		v143 = false
	else
		v143 = v142.fillUnits[p141] ~= nil
	end
	return v143
end
function FillUnit.getFillUnitCapacity(p144, p145)
	local v146 = p144.spec_fillUnit
	if v146.fillUnits[p145] == nil then
		return nil
	else
		return v146.fillUnits[p145].capacity
	end
end
function FillUnit.getFillUnitFreeCapacity(p147, p148, _, _)
	local v149 = p147.spec_fillUnit.fillUnits[p148]
	if v149 == nil then
		return nil
	end
	local v150 = v149.capacity - v149.fillLevel
	return not v149.ignoreFillLimit and (g_currentMission.missionInfo.trailerFillLimit and p147:getMaxComponentMassReached()) and 0 or v150
end
function FillUnit.getIsFillAllowedFromFarm(_, _)
	return true
end
function FillUnit.getFillUnitFillLevel(p151, p152)
	local v153 = p151.spec_fillUnit
	if v153.fillUnits[p152] == nil then
		return nil
	else
		return v153.fillUnits[p152].fillLevel
	end
end
function FillUnit.getFillUnitFillLevelPercentage(p154, p155)
	local v156 = p154.spec_fillUnit.fillUnits[p155]
	if v156 == nil then
		return nil
	else
		return v156.capacity <= 0 and 0 or v156.fillLevel / v156.capacity
	end
end
function FillUnit.getFillUnitFillType(p157, p158)
	local v159 = p157.spec_fillUnit
	if v159.fillUnits[p158] == nil then
		return nil
	else
		return v159.fillUnits[p158].fillType
	end
end
function FillUnit.getFillUnitLastValidFillType(p160, p161)
	local v162 = p160.spec_fillUnit
	if v162.fillUnits[p161] == nil then
		return nil
	else
		return v162.fillUnits[p161].lastValidFillType
	end
end
function FillUnit.getFillUnitFirstSupportedFillType(p163, p164)
	local v165 = p163.spec_fillUnit
	if v165.fillUnits[p164] == nil then
		return nil
	else
		return next(v165.fillUnits[p164].supportedFillTypes)
	end
end
function FillUnit.getFillUnitExactFillRootNode(p166, p167)
	local v168 = p166.spec_fillUnit
	if v168.fillUnits[p167] == nil then
		return nil
	else
		return v168.fillUnits[p167].exactFillRootNode
	end
end
function FillUnit.getFillUnitRootNode(p169, p170)
	local v171 = p169.spec_fillUnit
	if v171.fillUnits[p170] == nil then
		return nil
	else
		return v171.fillUnits[p170].fillRootNode
	end
end
function FillUnit.getFillUnitAutoAimTargetNode(p172, p173)
	local v174 = p172.spec_fillUnit
	if v174.fillUnits[p173] == nil then
		return nil
	else
		return v174.fillUnits[p173].autoAimTarget.node
	end
end
function FillUnit.getFillUnitSupportsFillType(p175, p176, p177)
	local v178 = p175.spec_fillUnit
	if v178.fillUnits[p176] == nil then
		return false
	else
		return v178.fillUnits[p176].supportedFillTypes[p177]
	end
end
function FillUnit.getFillUnitSupportsToolType(p179, p180, p181)
	local v182 = p179.spec_fillUnit
	if v182.fillUnits[p180] == nil then
		return false
	else
		return v182.fillUnits[p180].supportedToolTypes[p181]
	end
end
function FillUnit.getFillUnitSupportsToolTypeAndFillType(p183, p184, p185, p186)
	local v187 = p183:getFillUnitSupportsToolType(p184, p185)
	if v187 then
		v187 = p183:getFillUnitSupportsFillType(p184, p186)
	end
	return v187
end
function FillUnit.getFillUnitSupportedFillTypes(p188, p189)
	local v190 = p188.spec_fillUnit
	if v190.fillUnits[p189] == nil then
		return nil
	else
		return v190.fillUnits[p189].supportedFillTypes
	end
end
function FillUnit.getFillUnitSupportedToolTypes(p191, p192)
	local v193 = p191.spec_fillUnit
	if v193.fillUnits[p192] == nil then
		return nil
	else
		return v193.fillUnits[p192].supportedToolTypes
	end
end
function FillUnit.getFillUnitAllowsFillType(p194, p195, p196)
	local v197 = p194.spec_fillUnit
	if v197.fillUnits[p195] == nil or not p194:getFillUnitSupportsFillType(p195, p196) then
		return false
	end
	if p196 == v197.fillUnits[p195].fillType then
		return true
	end
	local v198 = v197.fillUnits[p195].fillLevel
	local v199 = v197.fillUnits[p195].capacity
	return v198 / math.max(v199, 0.0001) <= p194:getFillTypeChangeThreshold()
end
function FillUnit.getFillTypeChangeThreshold(p200, p201)
	if p201 == nil then
		return p200.spec_fillUnit.fillTypeChangeThreshold
	else
		return (p200:getFillUnitCapacity(p201) or 1) * p200.spec_fillUnit.fillTypeChangeThreshold
	end
end
function FillUnit.getFirstValidFillUnitToFill(p202, p203, p204)
	local v205 = p202.spec_fillUnit
	for v206, _ in ipairs(v205.fillUnits) do
		if p202:getFillUnitAllowsFillType(v206, p203) and (p202:getFillUnitFreeCapacity(v206) > 0 or p204 ~= nil and p204) then
			return v206
		end
	end
	return nil
end
function FillUnit.getFillUnitCanBeFilled(p207, p208, p209, p210)
	return p207:getFillUnitAllowsFillType(p208, p209) and (p207:getFillUnitFreeCapacity(p208) > 0 or p210 ~= nil and p210) and true or false
end
function FillUnit.setFillUnitFillType(p211, p212, p213)
	local v214 = p211.spec_fillUnit
	local v215 = v214.fillUnits[p212].fillType
	if v215 ~= p213 then
		v214.fillUnits[p212].fillType = p213
		SpecializationUtil.raiseEvent(p211, "onChangedFillType", p212, p213, v215)
	end
end
function FillUnit.setFillUnitFillTypeToDisplay(p216, p217, p218, p219)
	local v220 = p216.spec_fillUnit
	if v220.fillUnits[p217] ~= nil then
		v220.fillUnits[p217].fillTypeToDisplay = p218
		local v221 = v220.fillUnits[p217]
		if p219 == nil then
			p219 = false
		end
		v221.fillTypeToDisplayIsPersistent = p219
	end
end
function FillUnit.setFillUnitFillLevelToDisplay(p222, p223, p224, p225)
	local v226 = p222.spec_fillUnit
	if v226.fillUnits[p223] ~= nil then
		v226.fillUnits[p223].fillLevelToDisplay = p224
		local v227 = v226.fillUnits[p223]
		if p225 == nil then
			p225 = false
		end
		v227.fillLevelToDisplayIsPersistent = p225
	end
end
function FillUnit.setFillUnitCapacityToDisplay(p228, p229, p230)
	local v231 = p228.spec_fillUnit
	if v231.fillUnits[p229] ~= nil then
		v231.fillUnits[p229].capacityToDisplay = p230
	end
end
function FillUnit.setFillUnitCapacity(p232, p233, p234, p235)
	local v236 = p232.spec_fillUnit
	if v236.fillUnits[p233] ~= nil and p234 ~= v236.fillUnits[p233].capacity then
		v236.fillUnits[p233].capacity = p234
		SetFillUnitCapacityEvent.sendEvent(p232, p233, p234, p235)
	end
end
function FillUnit.setFillUnitForcedMaterialFillType(p237, p238, p239)
	local v240 = p237.spec_fillUnit
	if v240.fillUnits[p238] ~= nil then
		v240.fillUnits[p238].forcedMaterialFillType = p239
	end
	p237:setFillPlaneForcedFillType(p238, p239)
	if p237.setFillVolumeForcedFillTypeByFillUnitIndex ~= nil then
		p237:setFillVolumeForcedFillTypeByFillUnitIndex(p238, p239)
	end
end
function FillUnit.getFillUnitForcedMaterialFillType(p241, p242)
	local v243 = p241.spec_fillUnit
	if v243.fillUnits[p242] == nil then
		return FillType.UNKNOWN
	else
		return v243.fillUnits[p242].forcedMaterialFillType
	end
end
function FillUnit.setFillUnitInTriggerRange(_, _, _) end
function FillUnit.updateAlarmTriggers(p244, p245)
	for _, v246 in pairs(p245) do
		p244:setAlarmTriggerState(v246, p244:getAlarmTriggerIsActive(v246))
	end
end
function FillUnit.getAlarmTriggerIsActive(_, p247)
	local v248 = p247.fillUnit.fillLevel / p247.fillUnit.capacity
	return p247.minFillLevel <= v248 and v248 <= p247.maxFillLevel
end
function FillUnit.setAlarmTriggerState(p249, p250, p251)
	local v252 = p249.spec_fillUnit
	if p251 ~= p250.isActive then
		if p251 then
			if p250.sample ~= nil then
				g_soundManager:playSample(p250.sample)
			end
			v252.activeAlarmTriggers[p250] = p250
		else
			if p250.sample ~= nil then
				g_soundManager:stopSample(p250.sample)
			end
			v252.activeAlarmTriggers[p250] = nil
		end
		p250.isActive = p251
		SpecializationUtil.raiseEvent(p249, "onAlarmTriggerChanged", p250, p251)
	end
end
function FillUnit.getFillUnitIndexFromNode(p253, p254)
	local v255 = p253.spec_fillUnit.exactFillRootNodeToFillUnit[p254]
	if v255 == nil then
		return nil
	else
		return v255.fillUnitIndex
	end
end
function FillUnit.getFillUnitExtraDistanceFromNode(p256, p257)
	return p256.spec_fillUnit.exactFillRootNodeToExtraDistance[p257] or 0
end
function FillUnit.getFillUnitFromNode(p258, p259)
	return p258.spec_fillUnit.exactFillRootNodeToFillUnit[p259]
end
function FillUnit.emptyAllFillUnits(p260, p261)
	local v262 = p260.spec_fillUnit
	local v263 = v262.removeVehicleIfEmpty
	if p261 then
		v262.removeVehicleIfEmpty = false
	end
	for v264, _ in ipairs(p260:getFillUnits()) do
		local v265 = p260:getFillUnitFillType(v264)
		p260:addFillUnitFillLevel(p260:getOwnerFarmId(), v264, (-1 / 0), v265, ToolType.UNDEFINED, nil)
	end
	v262.removeVehicleIfEmpty = v263
end
function FillUnit.loadFillUnitUnloadingFromXML(p266, p267, p268, p269, _)
	p269.node = p267:getValue(p268 .. "#node", p266.rootNode, p266.components, p266.i3dMappings)
	p269.width = p267:getValue(p268 .. "#width", 15)
	p269.offset = p267:getValue(p268 .. "#offset", "0 0 0", true)
	return true
end
function FillUnit.getFillUnitUnloadPalletFilename(p270, p271)
	local v272 = p270:getFillUnitFillType(p271)
	if v272 == FillType.UNKNOWN then
		return nil
	else
		return g_fillTypeManager:getFillTypeByIndex(v272).palletFilename
	end
end
function FillUnit.getFillUnitHasMountedPalletsToUnload(_)
	return false
end
function FillUnit.getFillUnitMountedPalletsToUnload(_)
	return nil
end
function FillUnit.getAllowLoadTriggerActivation(p273, _)
	return p273.rootVehicle == g_localPlayer:getCurrentVehicle()
end
function FillUnit.addExactFillRootAimToUpdate(p274, p275, p276)
	p274.spec_fillUnit.exactFillRootNodeAimToUpdate[p275] = p276
end
function FillUnit.unloadFillUnits(p_u_277, p_u_278)
	if p_u_277.isServer then
		local v_u_279 = p_u_277.spec_fillUnit
		if not v_u_279.unloadingFillUnitsRunning then
			local v280 = v_u_279.unloading
			local v_u_281 = {}
			for _, v282 in ipairs(v280) do
				local v283 = v282.node
				local v284 = v282.offset
				local v285, v286, v287 = unpack(v284)
				local v288, v289, v290 = localToWorld(v283, v285 - v282.width * 0.5, v286, v287)
				local v291 = {
					["startX"] = v288,
					["startY"] = v289,
					["startZ"] = v290
				}
				local v292, v293, v294 = getWorldRotation(v283)
				v291.rotX = v292
				v291.rotY = v293
				v291.rotZ = v294
				local v295, v296, v297 = localDirectionToWorld(v283, 1, 0, 0)
				v291.dirX = v295
				v291.dirY = v296
				v291.dirZ = v297
				local v298, v299, v300 = localDirectionToWorld(v283, 0, 0, 1)
				v291.dirPerpX = v298
				v291.dirPerpY = v299
				v291.dirPerpZ = v300
				v291.yOffset = 1
				v291.maxWidth = (1 / 0)
				v291.maxLength = (1 / 0)
				v291.maxHeight = (1 / 0)
				v291.width = v282.width
				table.insert(v_u_281, v291)
			end
			local v_u_301 = {}
			local v_u_302 = {}
			local v_u_303 = {}
			for v304, v305 in ipairs(p_u_277:getFillUnits()) do
				local v306 = p_u_277:getFillUnitFillLevel(v304)
				if v305.canBeUnloaded and p_u_277:getFillUnitFillLevel(v304) > 0 then
					local v307 = p_u_277:getFillUnitUnloadPalletFilename(v304)
					if v307 ~= nil then
						local v308 = {
							["fillUnitIndex"] = v304,
							["fillTypeIndex"] = p_u_277:getFillUnitFillType(v304),
							["fillLevel"] = v306,
							["filename"] = v307
						}
						table.insert(v_u_301, v308)
					end
				end
			end
			if p_u_277:getFillUnitHasMountedPalletsToUnload() then
				local v309 = p_u_277:getFillUnitMountedPalletsToUnload()
				if v309 ~= nil and #v309 > 0 then
					for _, v310 in ipairs(v309) do
						local v311, v312, v313, v314, v315, _ = PlacementUtil.getPlace(v_u_281, v310.size, v_u_302, true, true, false, true)
						if v311 == nil then
							if p_u_278 == nil or not p_u_278 then
								g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, v_u_279.texts.unloadNoSpace)
							end
							g_server:broadcastEvent(FillUnitUnloadedEvent.new(p_u_277, nil), false, nil, p_u_277)
						else
							if v310.unmount ~= nil then
								v310:unmount()
							end
							PlacementUtil.markPlaceUsed(v_u_302, v314, v315)
							v310:setAbsolutePosition(v311, v312, v313, 0, MathUtil.getYRotationFromDirection(v314.dirPerpX, v314.dirPerpZ), 0)
							SpecializationUtil.raiseEvent(p_u_277, "onFillUnitUnloadPallet", v310)
							g_server:broadcastEvent(FillUnitUnloadedEvent.new(p_u_277, v310), false, nil, p_u_277)
						end
					end
				end
			end
			local function v_u_325()
				-- upvalues: (copy) v_u_301, (copy) v_u_303, (copy) p_u_277, (copy) v_u_325, (copy) p_u_278, (copy) v_u_279, (copy) v_u_281, (copy) v_u_302
				local v316 = v_u_301[1]
				if v316 ~= nil then
					for v317, _ in pairs(v_u_303) do
						local v318 = v317:getFirstValidFillUnitToFill(v316.fillTypeIndex)
						if v318 ~= nil then
							local v319 = v317:addFillUnitFillLevel(p_u_277:getOwnerFarmId(), v318, v316.fillLevel, v316.fillTypeIndex, ToolType.UNDEFINED, nil)
							p_u_277:addFillUnitFillLevel(p_u_277:getOwnerFarmId(), v316.fillUnitIndex, -v319, v316.fillTypeIndex, ToolType.UNDEFINED, nil)
							v316.fillLevel = v316.fillLevel - v319
							if v317:getFillUnitFreeCapacity(v318) <= 0 then
								v_u_303[v317] = nil
							end
						end
					end
					if v316.fillLevel > 0 then
						local function v323(_, p320, p321, _)
							-- upvalues: (ref) v_u_303, (ref) p_u_277, (ref) v_u_325, (ref) p_u_278, (ref) v_u_279
							if p321 == VehicleLoadingState.OK then
								for _, v322 in ipairs(p320) do
									v322:emptyAllFillUnits(true)
									v_u_303[v322] = true
									SpecializationUtil.raiseEvent(p_u_277, "onFillUnitUnloadPallet", v322)
								end
								v_u_325()
							elseif p321 == VehicleLoadingState.NO_SPACE then
								if p_u_278 == nil or not p_u_278 then
									g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, v_u_279.texts.unloadNoSpace)
								end
								g_server:broadcastEvent(FillUnitUnloadedEvent.new(p_u_277, nil), false, nil, p_u_277)
							end
						end
						local v324 = VehicleLoadingData.new()
						v324:setFilename(v316.filename)
						v324:setLoadingPlace(v_u_281, v_u_302, 0.5, true)
						v324:setPropertyState(VehiclePropertyState.OWNED)
						v324:setOwnerFarmId(p_u_277:getOwnerFarmId())
						v324:load(v323)
						return
					end
					table.remove(v_u_301, 1)
					v_u_325()
				end
			end
			v_u_325()
		end
	else
		g_client:getServerConnection():sendEvent(FillUnitUnloadEvent.new(p_u_277))
		return
	end
end
function FillUnit.addFillUnitFillLevel(p_u_326, p327, p328, p329, p330, p331, p332)
	local v_u_333 = p_u_326.spec_fillUnit
	v_u_333.isInfoDirty = true
	if p329 < 0 and not (g_currentMission.accessHandler:canFarmAccess(p327, p_u_326, true) or g_guidedTourManager:getIsTourRunning()) then
		return 0
	end
	if p_u_326.getMountObject ~= nil then
		local v334 = p_u_326:getDynamicMountObject() or p_u_326:getMountObject()
		if v334 ~= nil and not g_currentMission.accessHandler:canFarmAccess(v334:getActiveFarm(), p_u_326, true) then
			return 0
		end
	end
	local v335 = v_u_333.fillUnits[p328]
	if v335 == nil then
		return 0
	end
	if p329 > 0 and (not v335.ignoreFillLimit and (g_currentMission.missionInfo.trailerFillLimit and p_u_326:getMaxComponentMassReached())) then
		return 0
	end
	if not p_u_326:getFillUnitSupportsToolTypeAndFillType(p328, p331, p330) then
		return 0
	end
	if p_u_326.isServer and (p329 > 0 and (not v335.ignoreFillLimit and g_currentMission.missionInfo.trailerFillLimit)) then
		local v336 = p_u_326:getAvailableComponentMass()
		local v337 = g_fillTypeManager:getFillTypeByIndex(p330)
		if v337 ~= nil and v337.massPerLiter ~= 0 then
			local v338 = v336 / v337.massPerLiter
			p329 = math.min(p329, v338)
		end
	end
	local v339 = v335.fillLevel
	local v340 = v335.capacity
	local v341 = v340 == 0 and (1 / 0) or v340
	local v342 = false
	if v335.fillType == p330 then
		local v343 = v339 + p329
		local v344 = math.min(v341, v343)
		v335.fillLevel = math.max(0, v344)
	elseif p329 > 0 then
		if not p_u_326:getFillUnitAllowsFillType(p328, p330) then
			return 0
		end
		local v345 = v335.fillType
		if v339 > 0 then
			local v346 = v_u_333.removeVehicleIfEmpty
			v_u_333.removeVehicleIfEmpty = false
			p_u_326:addFillUnitFillLevel(p327, p328, (-1 / 0), v335.fillType, p331, p332)
			v_u_333.removeVehicleIfEmpty = v346
		end
		local v347 = math.min(v341, p329)
		v335.fillLevel = math.max(0, v347)
		v335.fillType = p330
		p_u_326.rootVehicle:raiseStateChange(VehicleStateChange.FILLTYPE_CHANGE)
		SpecializationUtil.raiseEvent(p_u_326, "onChangedFillType", p328, p330, v345)
		v339 = 0
		v342 = true
	end
	if v335.fillLevel < 0.00001 then
		v335.fillLevel = 0
	end
	if v335.fillLevel > 0 then
		v335.lastValidFillType = v335.fillType
	else
		SpecializationUtil.raiseEvent(p_u_326, "onChangedFillType", p328, FillType.UNKNOWN, v335.fillType)
		v335.fillType = FillType.UNKNOWN
		if not v335.fillTypeToDisplayIsPersistent then
			v335.fillTypeToDisplay = FillType.UNKNOWN
		end
		if not v335.fillLevelToDisplayIsPersistent then
			v335.fillLevelToDisplay = nil
		end
	end
	local v348 = v335.fillLevel - v339
	if p_u_326.isServer and v335.synchronizeFillLevel then
		local v349 = false
		if v335.fillLevel ~= v335.fillLevelSent then
			local v350 = 2 ^ v335.synchronizationNumBits - 1
			local v351 = v335.capacity / v350
			local v352 = v335.fillLevel - v335.fillLevelSent
			if v351 < math.abs(v352) then
				v335.fillLevelSent = v335.fillLevel
				v349 = true
			end
		end
		if v335.fillType ~= v335.fillTypeSent then
			v335.fillTypeSent = v335.fillType
			v349 = true
		end
		if v335.lastValidFillType ~= v335.lastValidFillTypeSent then
			v335.lastValidFillTypeSent = v335.lastValidFillType
			v349 = true
		end
		if v349 then
			p_u_326:raiseDirtyFlags(v_u_333.dirtyFlag)
		end
	end
	if v335.updateMass then
		p_u_326:setMassDirty()
	end
	p_u_326:updateFillUnitAutoAimTarget(v335)
	if p_u_326.isClient then
		p_u_326:updateAlarmTriggers(v335.alarmTriggers)
		p_u_326:updateFillUnitFillPlane(v335)
		p_u_326:updateMeasurementNodes(v335, 0, true)
		if v342 then
			p_u_326:updateFillTypeMaterials(v335.fillTypeMaterials, v335.fillType)
		end
	end
	SpecializationUtil.raiseEvent(p_u_326, "onFillUnitFillLevelChanged", p328, p329, p330, p331, p332, v348)
	if p_u_326.isServer and (v_u_333.removeVehicleIfEmpty and (v335.fillLevel <= v_u_333.removeVehicleThreshold and p329 ~= 0)) then
		if v_u_333.removeVehicleDelay == 0 then
			p_u_326:delete()
			if v_u_333.removeVehicleReward > 0 then
				g_currentMission:addMoney(v_u_333.removeVehicleReward, p_u_326:getOwnerFarmId(), MoneyType.SOLD_PRODUCTS, true, true)
			end
		else
			Timer.createOneshot(v_u_333.removeVehicleDelay, function()
				-- upvalues: (copy) p_u_326, (copy) v_u_333
				p_u_326:delete()
				if v_u_333.removeVehicleReward > 0 then
					g_currentMission:addMoney(v_u_333.removeVehicleReward, p_u_326:getOwnerFarmId(), MoneyType.SOLD_PRODUCTS, true, true)
				end
			end)
		end
	end
	if v348 > 0 then
		if #v_u_333.fillEffects > 0 then
			g_effectManager:setEffectTypeInfo(v_u_333.fillEffects, v335.fillType)
			g_effectManager:startEffects(v_u_333.fillEffects)
			v_u_333.activeFillEffects[v_u_333.fillEffects] = 500
		end
		if #v335.fillEffects > 0 then
			g_effectManager:setEffectTypeInfo(v335.fillEffects, v335.fillType)
			g_effectManager:startEffects(v335.fillEffects)
			v_u_333.activeFillEffects[v335.fillEffects] = 500
		end
		if #v_u_333.animationNodes > 0 then
			g_animationManager:startAnimations(v_u_333.animationNodes)
			v_u_333.activeFillAnimations[v_u_333.animationNodes] = 500
		end
		if #v335.animationNodes > 0 then
			g_animationManager:startAnimations(v335.animationNodes)
			v_u_333.activeFillAnimations[v335.animationNodes] = 500
		end
		if v335.fillAnimation ~= nil and v335.fillAnimationLoadTime ~= nil then
			local v353 = p_u_326:getAnimationTime(v335.fillAnimation)
			local v354 = v335.fillAnimationLoadTime - v353
			local v355 = math.sign(v354)
			if v355 ~= 0 then
				p_u_326:playAnimation(v335.fillAnimation, v355, v353)
				p_u_326:setAnimationStopTime(v335.fillAnimation, v335.fillAnimationLoadTime)
			end
		end
	end
	if v348 ~= 0 then
		for _, v356 in ipairs(v335.fillLevelAnimations) do
			if v335.fillLevel > 0 or v356.resetOnEmpty then
				local v357 = p_u_326:getAnimationTime(v356.name)
				local v358 = v335.fillLevel / v335.capacity
				local v359 = v356.useMaxStateIfEmpty and v335.fillLevel == 0 and 1 or v358
				local v360 = not v356.updateWhileFilled and p329 > 0 and 1 or v359
				p_u_326:setAnimationStopTime(v356.name, v360)
				local v361 = v360 - v357
				local v362 = math.sign(v361)
				p_u_326:playAnimation(v356.name, v362, v357, true)
			end
		end
	end
	if v335.fillLevel < 0.0001 and (v335.fillAnimation ~= nil and v335.fillAnimationEmptyTime ~= nil) then
		local v363 = p_u_326:getAnimationTime(v335.fillAnimation)
		local v364 = v335.fillAnimationEmptyTime - v363
		local v365 = math.sign(v364)
		p_u_326:playAnimation(v335.fillAnimation, v365, v363)
		p_u_326:setAnimationStopTime(v335.fillAnimation, v335.fillAnimationEmptyTime)
	end
	if p_u_326.setDashboardsDirty ~= nil then
		p_u_326:setDashboardsDirty()
	end
	FillUnit.updateUnloadActionDisplay(p_u_326)
	return v348
end
function FillUnit.setFillUnitLastValidFillType(p366, p367, p368, _)
	local v369 = p366.spec_fillUnit
	local v370 = v369.fillUnits[p367]
	if v370 ~= nil and v370.lastValidFillType ~= p368 then
		v370.lastValidFillType = p368
		v370.lastValidFillTypeSent = p368
		p366:raiseDirtyFlags(v369.dirtyFlag)
	end
end
function FillUnit.loadFillUnitFromXML(p371, p372, p373, p374, p375)
	local v_u_376 = p371.spec_fillUnit
	p374.fillUnitIndex = p375
	p374.capacity = p372:getValue(p373 .. "#capacity", (1 / 0))
	p374.defaultCapacity = p374.capacity
	p374.updateMass = p372:getValue(p373 .. "#updateMass", true)
	p374.canBeUnloaded = p372:getValue(p373 .. "#canBeUnloaded", true)
	p374.allowFoldingThreshold = p372:getValue(p373 .. "#allowFoldingThreshold")
	p374.needsSaving = true
	p374.fillLevel = 0
	p374.fillLevelSent = 0
	p374.fillType = FillType.UNKNOWN
	p374.fillTypeSent = FillType.UNKNOWN
	p374.fillTypeToDisplay = FillType.UNKNOWN
	p374.fillLevelToDisplay = nil
	p374.capacityToDisplay = nil
	p374.lastValidFillType = FillType.UNKNOWN
	p374.lastValidFillTypeSent = FillType.UNKNOWN
	if p372:hasProperty(p373 .. ".exactFillRootNode") then
		XMLUtil.checkDeprecatedXMLElements(p372, p373 .. ".exactFillRootNode#index", p373 .. ".exactFillRootNode#node")
		p374.exactFillRootNode = p372:getValue(p373 .. ".exactFillRootNode#node", nil, p371.components, p371.i3dMappings)
		if p374.exactFillRootNode == nil then
			Logging.xmlWarning(p371.xmlFile, "ExactFillRootNode not found for fillUnit \'%s\'!", p373)
		elseif CollisionFlag.getHasGroupFlagSet(p374.exactFillRootNode, CollisionFlag.FILLABLE) then
			v_u_376.exactFillRootNodeToFillUnit[p374.exactFillRootNode] = p374
			v_u_376.exactFillRootNodeToExtraDistance[p374.exactFillRootNode] = p372:getValue(p373 .. ".exactFillRootNode#extraEffectDistance", 0)
			v_u_376.hasExactFillRootNodes = true
			g_currentMission:addNodeObject(p374.exactFillRootNode, p371)
		else
			Logging.xmlWarning(p371.xmlFile, "Missing collision group %s. Please add this bit to exact fill root node \'%s\' collision filter group in \'%s\'", CollisionFlag.getBitAndName(CollisionFlag.FILLABLE), getName(p374.exactFillRootNode), p373)
		end
	end
	XMLUtil.checkDeprecatedXMLElements(p372, p373 .. ".autoAimTargetNode#index", p373 .. ".autoAimTargetNode#node")
	p374.autoAimTarget = {}
	p374.autoAimTarget.node = p372:getValue(p373 .. ".autoAimTargetNode#node", nil, p371.components, p371.i3dMappings)
	if p374.autoAimTarget.node ~= nil then
		p374.autoAimTarget.baseTrans = { getTranslation(p374.autoAimTarget.node) }
		p374.autoAimTarget.startZ = p372:getValue(p373 .. ".autoAimTargetNode#startZ")
		p374.autoAimTarget.endZ = p372:getValue(p373 .. ".autoAimTargetNode#endZ")
		p374.autoAimTarget.startPercentage = p372:getValue(p373 .. ".autoAimTargetNode#startPercentage", 25) / 100
		p374.autoAimTarget.invert = p372:getValue(p373 .. ".autoAimTargetNode#invert", false)
		if p374.autoAimTarget.startZ ~= nil and p374.autoAimTarget.endZ ~= nil then
			local v377 = p374.autoAimTarget.startZ
			if p374.autoAimTarget.invert then
				v377 = p374.autoAimTarget.endZ
			end
			setTranslation(p374.autoAimTarget.node, p374.autoAimTarget.baseTrans[1], p374.autoAimTarget.baseTrans[2], v377)
		end
	end
	p374.supportedFillTypes = {}
	local v378 = p372:getValue(p373 .. "#fillTypeCategories")
	local v379 = p372:getValue(p373 .. "#fillTypes")
	local v380
	if v378 == nil or v379 ~= nil then
		if v378 ~= nil or v379 == nil then
			Logging.xmlWarning(p371.xmlFile, "Missing \'fillTypeCategories\' or \'fillTypes\' for fillUnit \'%s\'", p373)
			return false
		end
		v380 = g_fillTypeManager:getFillTypesByNames(v379, "Warning: \'" .. p371.configFileName .. "\' has invalid fillType \'%s\'.")
	else
		v380 = g_fillTypeManager:getFillTypesByCategoryNames(v378, "Warning: \'" .. p371.configFileName .. "\' has invalid fillTypeCategory \'%s\'.")
	end
	if v380 ~= nil then
		for _, v381 in pairs(v380) do
			p374.supportedFillTypes[v381] = true
		end
	end
	p374.supportedToolTypes = {}
	for v382 = 1, g_toolTypeManager:getNumberOfToolTypes() do
		p374.supportedToolTypes[v382] = true
	end
	local v383 = p372:getValue(p373 .. "#startFillLevel")
	local v384 = p372:getValue(p373 .. "#startFillType")
	if v384 ~= nil then
		local v385 = g_fillTypeManager:getFillTypeIndexByName(v384)
		if v385 ~= nil then
			p374.startFillLevel = v383
			p374.startFillTypeIndex = v385
		end
	end
	p374.fillRootNode = p372:getValue(p373 .. ".fillRootNode#node", nil, p371.components, p371.i3dMappings)
	if p374.fillRootNode == nil then
		p374.fillRootNode = p371.components[1].node
	end
	p374.fillMassNode = p372:getValue(p373 .. ".fillMassNode#node", nil, p371.components, p371.i3dMappings)
	local v386 = p372:getValue(p373 .. "#updateFillLevelMass", true)
	if p374.fillMassNode == nil and v386 then
		p374.fillMassNode = p371.components[1].node
	end
	p374.ignoreFillLimit = p372:getValue(p373 .. "#ignoreFillLimit", false)
	p374.synchronizeFillLevel = p372:getValue(p373 .. "#synchronizeFillLevel", true)
	p374.synchronizeFullFillLevel = p372:getValue(p373 .. "#synchronizeFullFillLevel", false)
	local v387 = 16
	for v388, v389 in pairs(FillUnit.CAPACITY_TO_NETWORK_BITS) do
		if v388 <= p374.capacity then
			v387 = v389
		end
	end
	p374.synchronizationNumBits = p372:getValue(p373 .. "#synchronizationNumBits", v387)
	p374.showOnHud = p372:getValue(p373 .. "#showOnHud", true)
	p374.showOnInfoHud = p372:getValue(p373 .. "#showOnInfoHud", true)
	p374.uiPrecision = p372:getValue(p373 .. "#uiPrecision", 0)
	p374.uiCustomFillTypeName = p372:getValue(p373 .. "#uiCustomFillTypeName", nil, p371.customEnvironment, false)
	p374.uiDisplayTypeId = FillLevelsDisplay["TYPE_" .. p372:getValue(p373 .. "#uiDisplayType", "BAR")] or FillLevelsDisplay.TYPE_BAR
	local v390 = p372:getValue(p373 .. "#unitTextOverride")
	if v390 ~= nil then
		p374.unitText = g_i18n:convertText(v390)
	end
	p374.parentUnitOnHud = nil
	p374.childUnitOnHud = nil
	p374.blocksAutomatedTrainTravel = p372:getValue(p373 .. "#blocksAutomatedTrainTravel", false)
	p374.fillAnimation = p372:getValue(p373 .. "#fillAnimation")
	p374.fillAnimationLoadTime = p372:getValue(p373 .. "#fillAnimationLoadTime")
	p374.fillAnimationEmptyTime = p372:getValue(p373 .. "#fillAnimationEmptyTime")
	p374.fillLevelAnimations = {}
	for _, v391 in p372:iterator(p373 .. ".fillLevelAnimation") do
		local v392 = {
			["name"] = p372:getValue(v391 .. "#name")
		}
		if v392.name == nil then
			Logging.xmlWarning(p372, "Missing \'name\' for fillLevelAnimation \'%s\'", v391)
		else
			v392.resetOnEmpty = p372:getValue(v391 .. "#resetOnEmpty", true)
			v392.updateWhileFilled = p372:getValue(v391 .. "#updateWhileFilled", true)
			v392.useMaxStateIfEmpty = p372:getValue(v391 .. "#useMaxStateIfEmpty", false)
			local v393 = p374.fillLevelAnimations
			table.insert(v393, v392)
		end
	end
	if p371.isClient then
		p374.alarmTriggers = {}
		local v394 = 0
		while true do
			local v395 = p373 .. string.format(".alarmTriggers.alarmTrigger(%d)", v394)
			if not p372:hasProperty(v395) then
				break
			end
			local v396 = {}
			if p371:loadAlarmTrigger(p372, v395, v396, p374) then
				local v397 = p374.alarmTriggers
				table.insert(v397, v396)
			end
			v394 = v394 + 1
		end
		p374.measurementNodes = {}
		local v398 = 0
		while true do
			local v399 = p373 .. string.format(".measurementNodes.measurementNode(%d)", v398)
			if not p372:hasProperty(v399) then
				break
			end
			local v400 = {}
			if p371:loadMeasurementNode(p372, v399, v400) then
				local v401 = p374.measurementNodes
				table.insert(v401, v400)
			end
			v398 = v398 + 1
		end
		p374.fillPlane = {}
		p374.lastFillPlaneType = nil
		if not p371:loadFillPlane(p372, p373 .. ".fillPlane", p374.fillPlane, p374) then
			p374.fillPlane = nil
		end
		p374.fillTypeMaterials = p371:loadFillTypeMaterials(p372, p373)
		p374.fillEffects = g_effectManager:loadEffect(p372, p373 .. ".fillEffect", p371.components, p371, p371.i3dMappings)
		p374.animationNodes = g_animationManager:loadAnimations(p372, p373 .. ".animationNodes", p371.components, p371, p371.i3dMappings)
		XMLUtil.checkDeprecatedXMLElements(p372, p373 .. ".fillLevelHud", p373 .. ".dashboard")
		if p371.registerDashboardValueType ~= nil then
			local function v_u_409(_, p402, p403, p404, _)
				-- upvalues: (copy) v_u_376
				local v405 = p402:getValue(p403 .. "#fillType")
				if v405 ~= nil then
					local v406 = g_fillTypeManager:getFillTypeIndexByName(v405)
					if v406 ~= nil then
						for _, v407 in ipairs(v_u_376.fillUnits) do
							if v407.supportedFillTypes[v406] then
								p404.fillUnit = v407
							end
						end
					end
				end
				local v408 = p402:getValue(p403 .. "#fillUnitIndex")
				if v408 ~= nil then
					p404.fillUnit = v_u_376.fillUnits[v408]
				end
				return true
			end
			local v410 = DashboardValueType.new("fillUnit", "fillLevel")
			v410:setXMLKey(p373)
			v410:setValue(p374, function(p411, p412)
				return (p412.fillUnit or p411).fillLevel
			end)
			v410:setRange(0, function(p413, p414)
				return (p414.fillUnit or p413).capacity
			end)
			v410:setInterpolationSpeed(function(p415, p416)
				return (p416.fillUnit or p415).capacity * 0.001
			end)
			v410:setAdditionalFunctions(v_u_409, nil)
			p371:registerDashboardValueType(v410)
			local v417 = DashboardValueType.new("fillUnit", "fillLevelPct")
			v417:setXMLKey(p373)
			v417:setValue(p374, function(p418, p419)
				local v420 = p419.fillUnit or p418
				local v421 = v420.fillLevel / v420.capacity
				return math.clamp(v421, 0, 1) * 100
			end)
			v417:setRange(0, 100)
			v417:setInterpolationSpeed(0.1)
			v417:setAdditionalFunctions(v_u_409, nil)
			p371:registerDashboardValueType(v417)
			local v422 = DashboardValueType.new("fillUnit", "fillLevelWarning")
			v422:setXMLKey(p373)
			v422:setValue(p374, function(p423, p424)
				local v425 = (p424.fillUnit or p423).fillLevel
				local v426
				if p424.warningThresholdMin < v425 then
					v426 = v425 < p424.warningThresholdMax
				else
					v426 = false
				end
				return v426
			end)
			v422:setAdditionalFunctions(function(p427, p428, p429, p430, p431)
				-- upvalues: (copy) v_u_409
				v_u_409(p427, p428, p429, p430, p431)
				return Dashboard.warningAttributes(p427, p428, p429, p430, p431)
			end)
			p371:registerDashboardValueType(v422)
		end
	end
	return true
end
function FillUnit.loadAlarmTrigger(p432, p433, p434, p435, p436)
	p435.fillUnit = p436
	p435.isActive = false
	p435.minFillLevel = p433:getValue(p434 .. "#minFillLevel")
	local v437
	if p435.minFillLevel == nil then
		Logging.xmlWarning(p432.xmlFile, "Missing \'minFillLevel\' for alarmTrigger \'%s\'", p434)
		v437 = false
	else
		v437 = true
	end
	p435.maxFillLevel = p433:getValue(p434 .. "#maxFillLevel")
	if p435.maxFillLevel == nil then
		Logging.xmlWarning(p432.xmlFile, "Missing \'maxFillLevel\' for alarmTrigger \'%s\'", p434)
		v437 = false
	end
	p435.sample = g_soundManager:loadSampleFromXML(p433, p434, "alarmSound", p432.baseDirectory, p432.components, 0, AudioGroup.VEHICLE, p432.i3dMappings, p432)
	return v437
end
function FillUnit.loadMeasurementNode(p438, p439, p440, p441)
	XMLUtil.checkDeprecatedXMLElements(p439, p440 .. "#index", p440 .. "#node")
	local v442 = p439:getValue(p440 .. "#node", nil, p438.components, p438.i3dMappings)
	if v442 == nil then
		Logging.xmlWarning(p438.xmlFile, "Missing \'node\' for measurementNode \'%s\'", p440)
		return false
	end
	p441.node = v442
	p441.measurementTime = 0
	p441.intensity = 0
	return true
end
function FillUnit.updateMeasurementNodes(p443, p444, p445, p446, p447)
	if p444.measurementNodes ~= nil then
		for _, v448 in pairs(p444.measurementNodes) do
			if p446 ~= nil and p446 then
				v448.measurementTime = 5000
			end
			if v448.measurementTime > 0 then
				local v449 = v448.measurementTime - p445
				v448.measurementTime = math.max(v449, 0)
			end
			local v450 = v448.measurementTime / 5000
			local v451 = math.min(v450, 1)
			local v452 = p443.lastSpeed * 3600 / 10
			local v453 = math.min(v452, 1)
			local v454 = p447 or math.max(v451, v453)
			if v454 ~= v448.intensity then
				setShaderParameter(v448.node, "fillLevel", p444.fillLevel / p444.capacity, v454, 0, 0, false)
				setShaderParameter(v448.node, "prevFillLevel", p444.fillLevel / p444.capacity, v448.intensity, 0, 0, false)
				v448.intensity = v454
			end
		end
	end
end
function FillUnit.loadFillPlane(p455, p456, p457, p458, p459)
	XMLUtil.checkDeprecatedXMLElements(p456, p457 .. "#fillType", "Material is dynamically assigned to the nodes")
	if not p456:hasProperty(p457) then
		return false
	end
	p458.nodes = {}
	local v460 = 0
	while true do
		local v461 = string.format("%s.node(%d)", p457, v460)
		if not p456:hasProperty(v461) then
			p458.forcedFillType = nil
			local v462 = p456:getValue(p457 .. "#defaultFillType")
			if v462 == nil then
				p458.defaultFillType = next(p459.supportedFillTypes)
			else
				local v463 = g_fillTypeManager:getFillTypeIndexByName(v462)
				if v463 == nil then
					Logging.xmlWarning(p455.xmlFile, "Invalid defaultFillType \'%s\' for \'%s\'!", tostring(v462), p457)
					return false
				end
				p458.defaultFillType = v463
			end
			return true
		end
		XMLUtil.checkDeprecatedXMLElements(p456, v461 .. "#index", v461 .. "#node")
		local v464 = p456:getValue(v461 .. "#node", nil, p455.components, p455.i3dMappings)
		if v464 ~= nil then
			local v465, v466, v467 = getTranslation(v464)
			local v468, v469, v470 = getRotation(v464)
			local v471 = AnimCurve.new(linearInterpolatorTransRotScale)
			local v472 = 0
			while true do
				local v473 = string.format("%s.key(%d)", v461, v472)
				if not p456:hasProperty(v473) then
					break
				end
				local v474 = p456:getValue(v473 .. "#time")
				if v474 == nil then
					break
				end
				local v475, v476, v477 = p456:getValue(v473 .. "#translation")
				if v476 == nil then
					v476 = p456:getValue(v473 .. "#y")
				end
				local v478, v479, v480 = p456:getValue(v473 .. "#rotation")
				local v481, v482, v483 = p456:getValue(v473 .. "#scale")
				v471:addKeyframe({
					["x"] = v475 or v465,
					["y"] = v476 or v466,
					["z"] = v477 or v467,
					["rx"] = v478 or v468,
					["ry"] = v479 or v469,
					["rz"] = v480 or v470,
					["sx"] = v481 or 1,
					["sy"] = v482 or 1,
					["sz"] = v483 or 1,
					["time"] = v474
				})
				v472 = v472 + 1
			end
			if v472 == 0 then
				local v484, v485 = p456:getValue(v461 .. "#minMaxY")
				v471:addKeyframe({
					v465,
					v484 or v466,
					v467,
					v468,
					v469,
					v470,
					1,
					1,
					1,
					["time"] = 0
				})
				v471:addKeyframe({
					v465,
					v485 or v466,
					v467,
					v468,
					v469,
					v470,
					1,
					1,
					1,
					["time"] = 1
				})
			end
			local v486 = p456:getValue(v461 .. "#alwaysVisible", false)
			setVisibility(v464, v486)
			local v487 = p458.nodes
			table.insert(v487, {
				["node"] = v464,
				["animCurve"] = v471,
				["alwaysVisible"] = v486
			})
			local v488 = g_materialManager:getBaseMaterialByName("fillPlane")
			if v488 == nil then
				Logging.error("Failed to assign material to fill plane. Base Material \'fillPlane\' not found!")
			else
				setMaterial(v464, v488, 0)
				g_fillTypeManager:assignFillTypeTextureArraysFromTerrain(v464, g_terrainNode, true, true, true)
				setShaderParameter(v464, "isCustomShape", 1, 0, 0, 0, false)
			end
		end
		v460 = v460 + 1
	end
end
function FillUnit.setFillPlaneForcedFillType(p489, p490, p491)
	local v492 = p489.spec_fillUnit
	if v492.fillUnits[p490] ~= nil and v492.fillUnits[p490].fillPlane ~= nil then
		v492.fillUnits[p490].fillPlane.forcedFillType = p491
	end
end
function FillUnit.updateFillUnitFillPlane(p493, p494)
	local v495 = p494.fillPlane
	if v495 ~= nil then
		local v496 = p493:getFillUnitFillLevelPercentage(p494.fillUnitIndex)
		for _, v497 in ipairs(v495.nodes) do
			local v498, v499, v500, v501, v502, v503, v504, v505, v506 = v497.animCurve:get(v496)
			setTranslation(v497.node, v498, v499, v500)
			setRotation(v497.node, v501, v502, v503)
			setScale(v497.node, v504, v505, v506)
			setVisibility(v497.node, p494.fillLevel > 0 and true or v497.alwaysVisible)
		end
		if p494.fillType ~= p494.lastFillPlaneType then
			local v507 = g_fillTypeManager:getTextureArrayIndexByFillTypeIndex(p494.fillType)
			if v507 ~= nil then
				for _, v508 in ipairs(v495.nodes) do
					setShaderParameter(v508.node, "fillTypeId", v507 - 1, 0, 0, 0, false)
				end
			end
		end
	end
end
function FillUnit.loadFillTypeMaterials(p_u_509, p_u_510, p511)
	local v_u_512 = {}
	p_u_510:iterate(p511 .. ".fillTypeMaterials.material", function(_, p513)
		-- upvalues: (copy) p_u_510, (copy) p_u_509, (copy) v_u_512
		local v514 = p_u_510:getValue(p513 .. "#fillType")
		if v514 == nil then
			Logging.xmlWarning(p_u_510, "Missing fill type in \'%s\'", p513)
			return
		else
			local v515 = g_fillTypeManager:getFillTypeIndexByName(v514)
			if v515 == nil then
				Logging.xmlWarning(p_u_510, "Unknown fill type \'%s\' in \'%s\'", v514, p513)
				return
			else
				local v516 = p_u_510:getValue(p513 .. "#node", nil, p_u_509.components, p_u_509.i3dMappings)
				local v517 = p_u_510:getValue(p513 .. "#refNode", nil, p_u_509.components, p_u_509.i3dMappings)
				local v518 = p_u_510:getValue(p513 .. "#materialSlotName")
				if v516 == nil or v517 == nil then
					if v518 == nil then
						Logging.xmlWarning(p_u_510, "Missing node or ref node or materialSlotName in \'%s\'", p513)
						return
					else
						local v519 = MaterialUtil.getMaterialBySlotName(p_u_509.rootNode, v518)
						if v519 == nil then
							Logging.xmlWarning(p_u_510, "Material for slot name \'%s\' not found in \'%s\'", v518, p513)
							return
						else
							local v520 = p_u_510:getValue(p513 .. "#diffuse", nil, p_u_509.baseDirectory)
							if v520 == nil then
								Logging.xmlWarning(p_u_510, "Missing diffuse texture for fill type \'%s\' in \'%s\'", v514, p513)
								return
							elseif fileExists(v520) then
								local v521 = v_u_512
								table.insert(v521, {
									["fillTypeIndex"] = v515,
									["materialId"] = v519,
									["diffuse"] = v520
								})
							else
								Logging.xmlWarning(p_u_510, "Diffuse texture \'%s\' not found in \'%s\'", v520, p513)
							end
						end
					end
				else
					local v522 = v_u_512
					table.insert(v522, {
						["fillTypeIndex"] = v515,
						["node"] = v516,
						["refNode"] = v517
					})
					return
				end
			end
		end
	end)
	return v_u_512
end
function FillUnit.updateFillTypeMaterials(p523, p524, p525)
	for v526 = 1, #p524 do
		local v527 = p524[v526]
		if v527.fillTypeIndex == p525 then
			if v527.refNode == nil then
				if v527.materialId ~= nil then
					local v528 = setMaterialDiffuseMapFromFile(v527.materialId, v527.diffuse, true, true, false)
					MaterialUtil.replaceMaterialRec(p523.rootNode, v527.materialId, v528)
					v527.materialId = v528
				end
			else
				local v529 = getMaterial(v527.refNode, 0)
				setMaterial(v527.node, v529, 0)
			end
		end
	end
end
function FillUnit.updateFillUnitAutoAimTarget(_, p530)
	local v531 = p530.autoAimTarget
	if v531.node ~= nil and (v531.startZ ~= nil and v531.endZ ~= nil) then
		local v532 = p530.capacity * v531.startPercentage
		local v533 = (p530.fillLevel - v532) / (p530.capacity - v532)
		local v534 = math.clamp(v533, 0, 1)
		if v531.invert then
			v534 = 1 - v534
		end
		local v535 = (v531.endZ - v531.startZ) * v534 + v531.startZ
		setTranslation(v531.node, v531.baseTrans[1], v531.baseTrans[2], v535)
	end
end
function FillUnit.addFillUnitTrigger(p536, p537, p538, p539)
	local v540 = p536.spec_fillUnit
	if #v540.fillTrigger.triggers == 0 then
		g_currentMission.activatableObjectsSystem:addActivatable(v540.fillTrigger.activatable)
		v540.fillTrigger.activatable:setFillType(p538)
		if p536.isServer and Platform.gameplay.automaticFilling then
			p536:setFillUnitIsFilling(true)
		end
	end
	table.addElement(v540.fillTrigger.triggers, p537)
	SpecializationUtil.raiseEvent(p536, "onAddedFillUnitTrigger", p538, p539, #v540.fillTrigger.triggers)
	p536:updateFillUnitTriggers()
end
function FillUnit.removeFillUnitTrigger(p541, p542)
	local v543 = p541.spec_fillUnit
	table.removeElement(v543.fillTrigger.triggers, p542)
	if p541.isServer and p542 == v543.fillTrigger.currentTrigger then
		p541:setFillUnitIsFilling(false)
	end
	if #v543.fillTrigger.triggers == 0 then
		g_currentMission.activatableObjectsSystem:removeActivatable(v543.fillTrigger.activatable)
		if p541.isServer and Platform.gameplay.automaticFilling then
			p541:setFillUnitIsFilling(false)
		end
	end
	SpecializationUtil.raiseEvent(p541, "onRemovedFillUnitTrigger", #v543.fillTrigger.triggers)
	p541:updateFillUnitTriggers()
end
function FillUnit.updateFillUnitTriggers(p_u_544)
	local v545 = p_u_544.spec_fillUnit
	table.sort(v545.fillTrigger.triggers, function(p546, p547)
		-- upvalues: (copy) p_u_544
		local v548 = p546:getCurrentFillType()
		local v549 = p547:getCurrentFillType()
		local v550 = p_u_544:getFirstValidFillUnitToFill(v548)
		local v551 = p_u_544:getFirstValidFillUnitToFill(v549)
		if v550 == nil or v551 == nil then
			return v550 ~= nil
		else
			return p_u_544:getFillUnitFillLevel(v550) > p_u_544:getFillUnitFillLevel(v551)
		end
	end)
	if #v545.fillTrigger.triggers > 0 then
		local v552 = v545.fillTrigger.triggers[1]:getCurrentFillType()
		v545.fillTrigger.activatable:setFillType(v552)
		if v545.fillTrigger.selectedTrigger ~= v545.fillTrigger.triggers[1] then
			SpecializationUtil.raiseEvent(p_u_544, "onFillUnitTriggerChanged", v545.fillTrigger.triggers[1], v552, p_u_544:getFirstValidFillUnitToFill(v552), #v545.fillTrigger.triggers)
			v545.fillTrigger.selectedTrigger = v545.fillTrigger.triggers[1]
			return
		end
	else
		v545.fillTrigger.selectedTrigger = nil
	end
end
function FillUnit.setFillUnitIsFilling(p553, p554, p555)
	local v556 = p553.spec_fillUnit
	if p554 ~= v556.fillTrigger.isFilling then
		if p555 == nil or p555 == false then
			if g_server == nil then
				g_client:getServerConnection():sendEvent(SetFillUnitIsFillingEvent.new(p553, p554))
			else
				g_server:broadcastEvent(SetFillUnitIsFillingEvent.new(p553, p554), nil, nil, p553)
			end
		end
		v556.fillTrigger.isFilling = p554
		if p554 then
			v556.fillTrigger.currentTrigger = nil
			for _, v557 in ipairs(v556.fillTrigger.triggers) do
				if v557:getIsActivatable(p553) then
					v556.fillTrigger.currentTrigger = v557
					break
				end
			end
		end
		if p553.isClient then
			p553:setFillSoundIsPlaying(p554)
			if v556.fillTrigger.currentTrigger ~= nil then
				v556.fillTrigger.currentTrigger:setFillSoundIsPlaying(p554)
			end
		end
		SpecializationUtil.raiseEvent(p553, "onFillUnitIsFillingStateChanged", p554)
		if not p554 then
			p553:updateFillUnitTriggers()
		end
	end
end
function FillUnit.setFillSoundIsPlaying(p558, p559)
	local v560 = p558.spec_fillUnit
	if p559 then
		if not g_soundManager:getIsSamplePlaying(v560.samples.fill) then
			g_soundManager:playSample(v560.samples.fill)
			return
		end
	elseif g_soundManager:getIsSamplePlaying(v560.samples.fill) then
		g_soundManager:stopSample(v560.samples.fill)
	end
end
function FillUnit.getIsFillUnitActive(_, _)
	return true
end
function FillUnit.getAdditionalComponentMass(p561, p562, p563)
	local v564 = p562(p561, p563)
	local v565 = p561.spec_fillUnit
	for _, v566 in ipairs(v565.fillUnits) do
		if v566.updateMass and (v566.fillMassNode == p563.node and (v566.fillType ~= nil and v566.fillType ~= FillType.UNKNOWN)) then
			local v567 = g_fillTypeManager:getFillTypeByIndex(v566.fillType)
			v564 = v564 + v566.fillLevel * v567.massPerLiter
		end
	end
	return v564
end
function FillUnit.getFillLevelInformation(p568, p569, p570)
	p569(p568, p570)
	local v571 = p568.spec_fillUnit
	for v572 = 1, #v571.fillUnits do
		local v573 = v571.fillUnits[v572]
		if v573.capacity > 0 and v573.showOnHud then
			local v574 = v573.fillType
			if v574 == FillType.UNKNOWN and table.size(v573.supportedFillTypes) == 1 then
				v574 = next(v573.supportedFillTypes)
			end
			if v573.fillTypeToDisplay ~= FillType.UNKNOWN then
				v574 = v573.fillTypeToDisplay
			end
			local v575 = v573.fillLevel
			if v573.fillLevelToDisplay ~= nil then
				v575 = v573.fillLevelToDisplay
			end
			local v576 = v573.capacity
			if v573.capacityToDisplay ~= nil then
				v576 = v573.capacityToDisplay
			end
			if v573.parentUnitOnHud == nil then
				if v573.childUnitOnHud ~= nil and v574 == FillType.UNKNOWN then
					v574 = v571.fillUnits[v573.childUnitOnHud].fillType
				end
			else
				if v574 == FillType.UNKNOWN then
					v574 = v571.fillUnits[v573.parentUnitOnHud].fillType
				end
				v576 = 0
			end
			local v577 = not v573.ignoreFillLimit and g_currentMission.missionInfo.trailerFillLimit
			if v577 then
				v577 = p568:getMaxComponentMassReached()
			end
			p570:addFillLevel(v574, v575, v576, v575 > 0 and (v573.uiPrecision or 0) or 0, v577, v573.uiDisplayTypeId, v573.uiCustomFillTypeName)
		end
	end
end
function FillUnit.getIsFoldAllowed(p578, p579, p580, p581)
	local v582 = p578.spec_fillUnit
	if not v582.allowFoldingWhileFilled then
		for v583, v584 in ipairs(v582.fillUnits) do
			if p578:getFillUnitFillLevel(v583) > (v584.allowFoldingThreshold or v582.allowFoldingThreshold) then
				return false, v582.texts.warningFoldingFilled
			end
		end
	end
	return p579(p578, p580, p581)
end
function FillUnit.getIsReadyForAutomatedTrainTravel(p585, p586)
	local v587 = p585.spec_fillUnit
	for _, v588 in ipairs(v587.fillUnits) do
		if v588.blocksAutomatedTrainTravel and v588.fillLevel > 0 then
			return false
		end
	end
	return p586(p585)
end
function FillUnit.loadMovingToolFromXML(p589, p590, p591, p592, p593)
	if not p590(p589, p591, p592, p593) then
		return false
	end
	p593.fillUnitIndex = p591:getValue(p592 .. "#fillUnitIndex")
	p593.minFillLevel = p591:getValue(p592 .. "#minFillLevel")
	p593.maxFillLevel = p591:getValue(p592 .. "#maxFillLevel")
	return true
end
function FillUnit.getIsMovingToolActive(p594, p595, p596)
	if p596.fillUnitIndex ~= nil then
		local v597 = p594:getFillUnitFillLevelPercentage(p596.fillUnitIndex)
		if p596.minFillLevel < v597 or v597 < p596.maxFillLevel then
			return false
		end
	end
	return p595(p594, p596)
end
function FillUnit.getDoConsumePtoPower(p598, p599)
	local v600 = p598.spec_fillUnit.fillTrigger
	local v601 = not p599(p598) and v600.isFilling
	if v601 then
		v601 = v600.consumePtoPower
	end
	return v601
end
function FillUnit.getIsPowerTakeOffActive(p602, p603)
	local v604 = p602.spec_fillUnit.fillTrigger
	local v605 = not p603(p602) and v604.isFilling
	if v605 then
		v605 = v604.consumePtoPower
	end
	return v605
end
function FillUnit.getCanBeTurnedOn(p606, p607)
	local v608 = p606.spec_fillUnit
	for _, v609 in pairs(v608.activeAlarmTriggers) do
		if v609.turnOffInTrigger then
			return false
		end
	end
	return p607(p606)
end
function FillUnit.showInfo(p610, p611, p612)
	local v613 = p610.spec_fillUnit
	if v613.isInfoDirty then
		v613.fillUnitInfos = {}
		local v614 = {}
		for _, v615 in ipairs(v613.fillUnits) do
			if v615.showOnInfoHud and v615.fillLevel > 0 then
				local v616 = v614[v615.fillType]
				if v616 == nil then
					v616 = {
						["title"] = g_fillTypeManager:getFillTypeByIndex(v615.fillType).title,
						["fillLevel"] = 0,
						["unit"] = v615.unitText,
						["precision"] = 0
					}
					local v617 = v613.fillUnitInfos
					table.insert(v617, v616)
					v614[v615.fillType] = v616
				end
				v616.fillLevel = v616.fillLevel + v615.fillLevel
				if v616.precision == 0 and v615.fillLevel > 0 then
					v616.precision = v615.uiPrecision or 0
				end
			end
		end
		v613.isInfoDirty = false
	end
	for _, v618 in ipairs(v613.fillUnitInfos) do
		local v619
		if v618.precision > 0 then
			local v620 = MathUtil.round(v618.fillLevel, v618.precision)
			v619 = string.format("%d%s%0" .. v618.precision .. "d", math.floor(v620), g_i18n.decimalSeparator, (v620 - math.floor(v620)) * 10 ^ v618.precision)
		else
			v619 = string.format("%d", MathUtil.round(v618.fillLevel))
		end
		local v621 = v619 .. " " .. (v618.unit or g_i18n:getVolumeUnit())
		p612:addLine(v618.title, v621)
	end
	p611(p610, p612)
end
function FillUnit.loadLevelerNodeFromXML(p622, p623, p624, p625, p626)
	p624.limitFillUnitIndex = p625:getValue(p626 .. "#fillUnitIndex", 1)
	p624.minFillLevel = p625:getValue(p626 .. "#minFillLevel", 0)
	p624.maxFillLevel = p625:getValue(p626 .. "#maxFillLevel", 1)
	return p623(p622, p624, p625, p626)
end
function FillUnit.getIsLevelerPickupNodeActive(p627, p628, p629)
	local v630 = p627:getFillUnitFillLevelPercentage(p629.limitFillUnitIndex)
	if v630 < p629.minFillLevel or p629.maxFillLevel < v630 then
		return false
	else
		return p628(p627, p629)
	end
end
function FillUnit.debugGetSupportedFillTypesPerFillUnit(p631)
	local v632 = {}
	for _, v633 in ipairs(p631:getFillUnits()) do
		v632[v633.fillUnitIndex] = v633.supportedFillTypes
	end
	return v632
end
function FillUnit.addFillTypeSources(p634, p635, p636, p637)
	if p635 ~= p636 then
		local v638 = p635.spec_fillUnit
		if v638 ~= nil then
			for v639, v640 in pairs(v638.fillUnits) do
				for _, v641 in pairs(p637) do
					if v640.supportedFillTypes[v641] then
						if p634[v641] == nil then
							p634[v641] = {}
						end
						local v642 = p634[v641]
						table.insert(v642, {
							["vehicle"] = p635,
							["fillUnitIndex"] = v639
						})
					end
				end
			end
		end
	end
	if p635.getAttachedImplements ~= nil then
		local v643 = p635:getAttachedImplements()
		for _, v644 in pairs(v643) do
			if v644.object ~= nil then
				FillUnit.addFillTypeSources(p634, v644.object, p636, p637)
			end
		end
	end
end
function FillUnit.loadSpecValueCapacity(p_u_645, _, _)
	local function v_u_652(p646, p647)
		-- upvalues: (copy) p_u_645
		local v648 = p_u_645:getValue(p646 .. "#unitTextOverride")
		if v648 ~= nil then
			return p647, v648
		end
		local v649 = p_u_645:getValue(p646 .. "#shopDisplayUnit")
		local v650 = FillUnit.UNIT[v649]
		if v649 ~= nil and v650 == nil then
			Logging.xmlWarning(p_u_645, "Unit \'%s\' is not defined in fillUnit \'%s\'. Available units: %s. Using LITER as default", v649, p646, table.concatKeys(FillUnit.UNIT, " "))
		end
		local v651 = v650 or FillUnit.UNIT.LITER
		return v651.conversionFunc(p647), v651.l10n, v651.conversionFunc
	end
	local v653 = p_u_645:getRootName()
	local v_u_654 = {}
	XMLUtil.checkDeprecatedXMLElements(p_u_645, v653 .. ".storeData.specs.capacity#unit", v653 .. ".storeData.specs.capacity#unitTextOverride")
	local v655 = p_u_645:getValue(v653 .. ".storeData.specs.capacity")
	local v_u_656, v657
	if v655 == nil then
		v_u_656 = nil
		v657 = nil
	else
		v655, v657, v_u_656 = v_u_652(v653 .. ".storeData.specs.capacity", v655)
	end
	if v655 == nil or v657 == nil then
		p_u_645:iterate(v653 .. ".fillUnit.fillUnitConfigurations.fillUnitConfiguration", function(_, p658)
			-- upvalues: (copy) p_u_645, (ref) v_u_656, (copy) v_u_652, (copy) v_u_654
			local v_u_659 = {
				["isSelectable"] = p_u_645:getValue(p658 .. "#isSelectable", true),
				["fillUnits"] = {}
			}
			p_u_645:iterate(p658 .. ".fillUnits.fillUnit", function(p660, p661)
				-- upvalues: (ref) p_u_645, (ref) v_u_656, (ref) v_u_652, (copy) v_u_659
				XMLUtil.checkDeprecatedXMLElements(p_u_645, p661 .. "#unit", p661 .. "#unitTextOverride")
				if p_u_645:getValue(p661 .. "#showCapacityInShop") ~= false and p_u_645:getValue(p661 .. "#showInShop") ~= false then
					local v662, v663, v664 = v_u_652(p661, p_u_645:getValue(p661 .. "#capacity") or 0)
					v_u_656 = v664
					local v665 = v_u_659.fillUnits
					local v666 = {
						["capacity"] = v662,
						["unit"] = v663,
						["conversionFunc"] = v_u_656,
						["fillUnitIndex"] = p660
					}
					table.insert(v665, v666)
				end
			end)
			local v667 = v_u_654
			table.insert(v667, v_u_659)
		end)
		if #v_u_654 > 0 then
			return v_u_654
		else
			return nil
		end
	else
		local v668 = {
			["isSelectable"] = true,
			["fillUnits"] = {
				{
					["capacity"] = v655,
					["unit"] = v657,
					["conversionFunc"] = v_u_656
				}
			}
		}
		table.insert(v_u_654, v668)
		return v_u_654
	end
end
function FillUnit.getSpecValueCapacity(p669, p670, p671, p672, p673, p674)
	local v675 = 1
	if p670 == nil or (p669.configurations == nil or (p670.configurations.fillUnit == nil or p669.configurations.fillUnit == nil)) then
		if p671 ~= nil and (p669.configurations ~= nil and (p671.fillUnit ~= nil and p669.configurations.fillUnit ~= nil)) then
			v675 = p671.fillUnit
		end
	else
		v675 = p670.configurations.fillUnit
	end
	local v676 = 0
	local v677 = 0
	local v678 = ""
	local v679 = p669.specs.capacity
	if v679 ~= nil then
		if p670 == nil and (p671 == nil or p672 == nil) then
			v676 = (1 / 0)
			v677 = 0
			for _, v680 in ipairs(v679) do
				if v680.isSelectable then
					local v681 = 0
					for _, v682 in ipairs(v680.fillUnits) do
						v681 = v681 + v682.capacity
						v678 = v682.unit
					end
					if v681 ~= 0 then
						v676 = math.min(v676, v681)
						v677 = math.max(v677, v681)
					end
				end
			end
			if v676 == v677 then
				v677 = v676
			elseif v676 ~= (1 / 0) and (v677 ~= 0 and (p673 == nil or not p673)) then
				v677 = string.format("%s-%s", v676, v677)
			end
		elseif v679[v675] ~= nil then
			for _, v683 in ipairs(v679[v675].fillUnits) do
				if p670 == nil or (p670.getFillUnitCapacity == nil or v683.fillUnitIndex == nil) then
					v677 = v677 + v683.capacity
				else
					local v684 = p670:getFillUnitCapacity(v683.fillUnitIndex)
					if v684 ~= 0 and v684 ~= (1 / 0) then
						if v683.conversionFunc ~= nil then
							v684 = v683.conversionFunc(v684)
						end
						v677 = v677 + v684
					end
				end
				v678 = v683.unit
			end
			v676 = v677
		end
	end
	if type(v677) == "number" and (v677 == 0 and (p673 == nil or not p673)) then
		return nil
	else
		if v678 ~= "" and v678:sub(1, 6) == "$l10n_" then
			v678 = v678:sub(7)
		end
		if p673 == nil or not p673 then
			return string.format(g_i18n:getText("shop_capacityValue"), v677, g_i18n:getText(v678 or "unit_literShort"))
		elseif p674 == true and v677 ~= v676 then
			return v676, v677, v678
		else
			return v676, v678
		end
	end
end
function FillUnit.getCapacityFromXml(p_u_685)
	local v686 = p_u_685:getRootName()
	local v_u_687 = 0
	p_u_685:iterate(v686 .. ".fillUnit.fillUnitConfigurations.fillUnitConfiguration", function(_, p688)
		-- upvalues: (copy) p_u_685, (ref) v_u_687
		p_u_685:iterate(p688 .. ".fillUnits.fillUnit", function(_, p689)
			-- upvalues: (ref) v_u_687, (ref) p_u_685
			local v690 = v_u_687
			local v691 = p_u_685:getValue(p689 .. "#capacity") or 0
			v_u_687 = math.max(v690, v691)
		end)
	end)
	return v_u_687
end
function FillUnit.loadSpecValueFillTypes(p692, _, _)
	local v693 = p692:getRootName()
	XMLUtil.checkDeprecatedXMLElements(p692, v693 .. ".fillTypes", v693 .. ".cutter#fruitTypes")
	XMLUtil.checkDeprecatedXMLElements(p692, v693 .. ".fruitTypes", v693 .. ".storeData.specs.fillTypes")
	XMLUtil.checkDeprecatedXMLElements(p692, v693 .. ".fillTypeCategories", v693 .. ".storeData.specs.fillTypeCategories")
	local v694 = 0
	local v695 = nil
	local v696 = nil
	local v697 = {}
	while true do
		local v698 = string.format(v693 .. ".fillUnit.fillUnitConfigurations.fillUnitConfiguration(%d)", v694)
		if not p692:hasProperty(v698) then
			break
		end
		local v699 = 0
		while true do
			local v700 = string.format(v698 .. ".fillUnits.fillUnit(%d)", v699)
			if not p692:hasProperty(v700) then
				break
			end
			local v701 = p692:getValue(v700 .. "#showInShop")
			local v702 = p692:getValue(v700 .. "#capacity")
			if (v701 == nil or v701) and (v702 == nil or v702 > 0) then
				local v703 = p692:getValue(v700 .. "#fillTypes")
				if v703 ~= nil then
					if v695 == nil then
						v695 = v703
					else
						v695 = v695 .. " " .. v703
					end
				end
				local v704 = p692:getValue(v700 .. "#fillTypeCategories")
				if v704 ~= nil then
					if v696 == nil then
						v696 = v704
					else
						v696 = v696 .. " " .. v704
					end
				end
				v697[v694 + 1] = {
					["fillTypeNames"] = v703,
					["categoryNames"] = v704
				}
			end
			v699 = v699 + 1
		end
		v694 = v694 + 1
	end
	local v705 = p692:getValue(v693 .. ".storeData.specs.fillTypes")
	if v705 == nil then
		v705 = v695
	else
		v696 = nil
	end
	local v706 = p692:getValue(v693 .. ".storeData.specs.fruitTypes")
	if v706 == nil then
		v706 = p692:getValue(v693 .. ".cutter#fruitTypes")
	end
	local v707 = p692:getValue(v693 .. ".storeData.specs.fruitTypeCategories")
	if v707 == nil then
		v707 = p692:getValue(v693 .. ".cutter#fruitTypeCategories")
	end
	local v708 = nil
	local v709 = p692:getValue(v693 .. ".cutter#fillTypeConverter")
	if v709 ~= nil then
		local v710 = g_fillTypeManager:getConverterDataByName(v709)
		if v710 ~= nil then
			v708 = {}
			for v711, _ in pairs(v710) do
				table.insert(v708, v711)
			end
			table.sort(v708)
		end
	end
	return {
		["categoryNames"] = p692:getValue(v693 .. ".storeData.specs.fillTypeCategories", v696),
		["fillTypeNames"] = v705,
		["fruitTypeNames"] = v706,
		["fruitTypeCategoryNames"] = v707,
		["windrowFillTypes"] = v708,
		["fillTypesByConfiguration"] = v697
	}
end
function FillUnit.getFillTypeNamesFromXML(p_u_712)
	local v_u_713 = nil
	local v_u_714 = nil
	p_u_712:iterate(p_u_712:getRootName() .. ".fillUnit.fillUnitConfigurations.fillUnitConfiguration", function(_, p715)
		-- upvalues: (copy) p_u_712, (ref) v_u_713, (ref) v_u_714
		p_u_712:iterate(p715 .. ".fillUnits.fillUnit", function(_, p716)
			-- upvalues: (ref) p_u_712, (ref) v_u_713, (ref) v_u_714
			local v717 = p_u_712:getValue(p716 .. "#capacity")
			if v717 == nil or v717 > 0 then
				local v718 = p_u_712:getValue(p716 .. "#fillTypes")
				if v718 ~= nil then
					if v_u_713 == nil then
						v_u_713 = v718
					else
						v_u_713 = v_u_713 .. " " .. v718
					end
				end
				local v719 = p_u_712:getValue(p716 .. "#fillTypeCategories")
				if v719 ~= nil then
					if v_u_714 == nil then
						v_u_714 = v719
						return
					end
					v_u_714 = v_u_714 .. " " .. v719
				end
			end
		end)
	end)
	return {
		["fillTypeNames"] = v_u_713,
		["fillTypeCategoryNames"] = v_u_714
	}
end
function FillUnit.getSpecValueFillTypes(p720, _, p721)
	local v722 = p720.specs.fillTypes
	if v722 ~= nil then
		local v723
		if p721 == nil then
			v723 = nil
		else
			local v724 = p721.fillUnit
			v723 = v722.fillTypesByConfiguration[v724]
		end
		local v725 = v722.categoryNames
		if v723 ~= nil then
			v725 = v723.categoryNames or v725
		end
		local v726 = v722.fillTypeNames
		if v723 ~= nil then
			v726 = v723.fillTypeNames or v726
		end
		if v725 ~= nil or v726 ~= nil then
			local v727 = {}
			if v725 ~= nil then
				g_fillTypeManager:getFillTypesByCategoryNames(v725, nil, v727)
			end
			if v726 ~= nil then
				g_fillTypeManager:getFillTypesByNames(v726, nil, v727)
			end
			return v727
		end
		if v722.fruitTypeNames ~= nil then
			return g_fruitTypeManager:getFillTypeIndicesByFruitTypeNames(v722.fruitTypeNames, nil)
		end
		if v722.fruitTypeCategoryNames ~= nil then
			return g_fruitTypeManager:getFillTypeIndicesByFruitTypeCategoryName(v722.fruitTypeCategoryNames, nil)
		end
		if v722.windrowFillTypes ~= nil then
			return v722.windrowFillTypes
		end
	end
	return nil
end
function FillUnit.loadSpecValueFillUnitMassData(p_u_728, _, _)
	local v_u_729 = {}
	p_u_728:iterate("vehicle.motorized.consumerConfigurations.consumerConfiguration(0).consumer", function(_, p730)
		-- upvalues: (copy) p_u_728, (copy) v_u_729
		local v731 = p_u_728:getValue(p730 .. "#fillUnitIndex", 0)
		if v731 ~= 0 then
			local v732 = p_u_728:getValue(p730 .. "#capacity")
			local v733 = string.format("vehicle.fillUnit.fillUnitConfigurations.fillUnitConfiguration(0).fillUnits.fillUnit(%d)", v731 - 1)
			local v734 = p_u_728:getValue(v733 .. "#fillTypeCategories")
			local v735 = p_u_728:getValue(v733 .. "#fillTypes")
			if v732 == nil then
				v732 = p_u_728:getValue(v733 .. "#capacity", 0)
			end
			if v732 > 0 then
				local v736 = v_u_729
				table.insert(v736, {
					["fillTypeCategories"] = v734,
					["fillTypes"] = v735,
					["capacity"] = v732
				})
			end
		end
	end)
	p_u_728:iterate("vehicle.fillUnit.fillUnitConfigurations.fillUnitConfiguration(0).fillUnits.fillUnit", function(_, p737)
		-- upvalues: (copy) p_u_728, (copy) v_u_729
		local v738 = p_u_728:getValue(p737 .. "#startFillLevel", 0)
		if v738 > 0 then
			local v739 = v_u_729
			local v740 = {
				["fillType"] = p_u_728:getValue(p737 .. "#startFillType"),
				["capacity"] = v738
			}
			table.insert(v739, v740)
		end
	end)
	return v_u_729
end
function FillUnit.getSpecValueStartFillUnitMassByMassData(p741)
	local v742 = 0
	for _, v743 in pairs(p741) do
		local v744 = nil
		if v743.fillTypeCategories == nil then
			if v743.fillTypes == nil then
				if v743.fillType ~= nil then
					v744 = g_fillTypeManager:getFillTypeIndexByName(v743.fillType)
				end
			else
				v744 = g_fillTypeManager:getFillTypesByNames(v743.fillTypes)[1]
			end
		else
			v744 = g_fillTypeManager:getFillTypesByCategoryNames(v743.fillTypeCategories)[1]
		end
		if v744 ~= nil then
			local v745 = g_fillTypeManager:getFillTypeByIndex(v744)
			v742 = v742 + v743.capacity * v745.massPerLiter
		end
	end
	return v742
end
function FillUnit.actionEventConsoleFillUnitNext(p746, _, _, _, _)
	if p746:getIsSelected() then
		local v747 = p746:getFillUnitFillType(1)
		local v748 = p746:getFillUnitByIndex(1)
		local v749 = false
		local v750 = nil
		for v751, _ in pairs(v748.supportedFillTypes) do
			if v749 then
				v750 = v751
				break
			end
			if v751 == v747 then
				v749 = true
			end
		end
		if v750 == nil then
			v750 = next(v748.supportedFillTypes)
		end
		p746:addFillUnitFillLevel(p746:getOwnerFarmId(), 1, (-1 / 0), v747, ToolType.UNDEFINED, nil)
		p746:addFillUnitFillLevel(p746:getOwnerFarmId(), 1, 100, v750, ToolType.UNDEFINED, nil)
	end
end
function FillUnit.actionEventConsoleFillUnitInc(p752, _, _, _, _)
	if p752:getIsSelected() then
		local v753 = p752:getFillUnitFillType(1)
		if v753 == FillType.UNKNOWN then
			local v754 = p752:getFillUnitByIndex(1)
			v753 = next(v754.supportedFillTypes)
		end
		p752:addFillUnitFillLevel(p752:getOwnerFarmId(), 1, 1000, v753, ToolType.UNDEFINED, nil)
	end
end
function FillUnit.actionEventConsoleFillUnitDec(p755, _, _, _, _)
	if p755:getIsSelected() then
		local v756 = p755:getFillUnitFillType(1)
		p755:addFillUnitFillLevel(p755:getOwnerFarmId(), 1, -1000, v756, ToolType.UNDEFINED, nil)
	end
end
function FillUnit.actionEventUnload(p757, _, _, _, _)
	p757:unloadFillUnits()
end
function FillUnit.updateUnloadActionDisplay(p758)
	local v759 = p758.spec_fillUnit
	if v759 ~= nil and v759.unloading ~= nil then
		local v760 = false
		for v761, v762 in ipairs(p758:getFillUnits()) do
			if v762.canBeUnloaded and (p758:getFillUnitFillLevel(v761) > 0 and p758:getFillUnitUnloadPalletFilename(v761) ~= nil) then
				v760 = true
				break
			end
		end
		local v763 = p758:getFillUnitHasMountedPalletsToUnload() and true or v760
		if p758.getCurrentDischargeNode ~= nil then
			local v764 = p758:getCurrentDischargeNode()
			if v764 ~= nil then
				local v765, _ = p758:getDischargeTargetObject(v764)
				if v765 ~= nil then
					v763 = false
				end
			end
		end
		g_inputBinding:setActionEventActive(v759.unloadActionEventId, v763)
	end
end
FillActivatable = {}
local v_u_766 = Class(FillActivatable)
function FillActivatable.new(p767)
	-- upvalues: (copy) v_u_766
	local v768 = v_u_766
	local v769 = setmetatable({}, v768)
	v769.vehicle = p767
	v769.fillTypeIndex = FillType.UNKNOWN
	v769.activateText = "unknown"
	return v769
end
function FillActivatable.getIsActivatable(p770)
	if p770.vehicle:getIsActiveForInput(true) then
		local v771 = p770.vehicle:getFirstValidFillUnitToFill(p770.fillTypeIndex)
		if v771 ~= nil and (p770.vehicle:getFillUnitFillLevel(v771) < p770.vehicle:getFillUnitCapacity(v771) - 1 and (p770.vehicle:getFillUnitAllowsFillType(v771, p770.fillTypeIndex) and p770.vehicle:getFillUnitSupportsToolType(v771, ToolType.TRIGGER))) then
			local v772 = p770.vehicle.spec_fillUnit
			for _, v773 in ipairs(v772.fillTrigger.triggers) do
				if v773:getIsActivatable(p770.vehicle) then
					p770:updateActivateText(v772.fillTrigger.isFilling)
					return true
				end
			end
		end
	end
	return false
end
function FillActivatable.run(p774)
	local v775 = p774.vehicle.spec_fillUnit
	p774.vehicle:setFillUnitIsFilling(not v775.fillTrigger.isFilling)
	p774:updateActivateText(v775.fillTrigger.isFilling)
end
function FillActivatable.activate(p776)
	g_currentMission:addDrawable(p776)
end
function FillActivatable.deactivate(p777)
	g_currentMission:removeDrawable(p777)
end
function FillActivatable.draw(p778)
	if p778.fillTypeIndex == FillType.FUEL then
		g_currentMission:showFuelContext(p778.vehicle)
	end
end
function FillActivatable.updateActivateText(p779, p780)
	local v781 = p779.vehicle.spec_fillUnit
	if p780 then
		p779.activateText = string.format(v781.texts.stopRefill, p779.vehicle.typeDesc)
	else
		p779.activateText = string.format(v781.texts.startRefill, p779.vehicle.typeDesc)
	end
end
function FillActivatable.setFillType(p782, p783)
	p782.fillTypeIndex = p783
end

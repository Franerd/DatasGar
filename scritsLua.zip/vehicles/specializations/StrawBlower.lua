StrawBlower = {}
function StrawBlower.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(FillUnit, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Trailer, p1)
	end
	return v2
end
function StrawBlower.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("StrawBlower")
	v3:register(XMLValueType.NODE_INDEX, "vehicle.strawBlower.baleTrigger#node", "Bale trigger node")
	v3:register(XMLValueType.INT, "vehicle.strawBlower#fillUnitIndex", "Fill unit index", 1)
	AnimationManager.registerAnimationNodesXMLPaths(v3, "vehicle.strawBlower.animationNodes")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.strawBlower.sounds", "start")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.strawBlower.sounds", "stop")
	SoundManager.registerSampleXMLPaths(v3, "vehicle.strawBlower.sounds", "work")
	v3:setXMLSpecializationType()
end
function StrawBlower.registerFunctions(p4)
	SpecializationUtil.registerFunction(p4, "strawBlowerBaleTriggerCallback", StrawBlower.strawBlowerBaleTriggerCallback)
	SpecializationUtil.registerFunction(p4, "onDeleteStrawBlowerObject", StrawBlower.onDeleteStrawBlowerObject)
end
function StrawBlower.registerOverwrittenFunctions(p5)
	SpecializationUtil.registerOverwrittenFunction(p5, "getDrawFirstFillText", StrawBlower.getDrawFirstFillText)
	SpecializationUtil.registerOverwrittenFunction(p5, "getAllowDynamicMountFillLevelInfo", StrawBlower.getAllowDynamicMountFillLevelInfo)
	SpecializationUtil.registerOverwrittenFunction(p5, "addFillUnitFillLevel", StrawBlower.addFillUnitFillLevel)
end
function StrawBlower.registerEventListeners(p6)
	SpecializationUtil.registerEventListener(p6, "onLoad", StrawBlower)
	SpecializationUtil.registerEventListener(p6, "onDelete", StrawBlower)
	SpecializationUtil.registerEventListener(p6, "onUpdateTick", StrawBlower)
	SpecializationUtil.registerEventListener(p6, "onFillUnitFillLevelChanged", StrawBlower)
	SpecializationUtil.registerEventListener(p6, "onDischargeStateChanged", StrawBlower)
end
function StrawBlower.onLoad(p7, p8)
	local v9 = p7.spec_strawBlower
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.strawBlower.baleTrigger#index", "vehicle.strawBlower.baleTrigger#node")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.strawBlower.doorAnimation#name", "vehicle.foldable.foldingParts.foldingPart.animationName")
	XMLUtil.checkDeprecatedXMLElements(p7.xmlFile, "vehicle.strawBlower.balePickupTrigger", "vehicle.autoLoaderBales.trigger")
	v9.triggeredBales = {}
	if p7.isServer then
		v9.triggerId = p7.xmlFile:getValue("vehicle.strawBlower.baleTrigger#node", nil, p7.components, p7.i3dMappings)
		if v9.triggerId ~= nil then
			addTrigger(v9.triggerId, "strawBlowerBaleTriggerCallback", p7)
		end
	end
	if p7.isClient then
		v9.animationNodes = g_animationManager:loadAnimations(p7.xmlFile, "vehicle.strawBlower.animationNodes", p7.components, p7, p7.i3dMappings)
		v9.samples = {}
		v9.samples.start = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.strawBlower.sounds", "start", p7.baseDirectory, p7.components, 1, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v9.samples.stop = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.strawBlower.sounds", "stop", p7.baseDirectory, p7.components, 1, AudioGroup.VEHICLE, p7.i3dMappings, p7)
		v9.samples.work = g_soundManager:loadSampleFromXML(p7.xmlFile, "vehicle.strawBlower.sounds", "work", p7.baseDirectory, p7.components, 0, AudioGroup.VEHICLE, p7.i3dMappings, p7)
	end
	v9.fillUnitIndex = p7.xmlFile:getValue("vehicle.strawBlower#fillUnitIndex", 1)
	local v10 = p7:getFillUnitByIndex(v9.fillUnitIndex)
	v10.synchronizeFullFillLevel = true
	v10.needsSaving = false
	if p8 ~= nil and not p8.resetVehicles then
		p7:addFillUnitFillLevel(p7:getOwnerFarmId(), v9.fillUnitIndex, (-1 / 0), FillType.UNKNOWN, ToolType.UNDEFINED)
	end
	if not p7.isServer then
		SpecializationUtil.removeEventListener(p7, "onUpdateTick", StrawBlower)
	end
end
function StrawBlower.onDelete(p11)
	local v12 = p11.spec_strawBlower
	if v12.triggerId ~= nil then
		removeTrigger(v12.triggerId)
	end
	if v12.triggeredBales ~= nil then
		for v13, _ in pairs(v12.triggeredBales) do
			if entityExists(v13.nodeId) then
				I3DUtil.wakeUpObject(v13.nodeId)
				v13.allowPickup = true
			end
		end
	end
	g_soundManager:deleteSamples(v12.samples)
	g_animationManager:deleteAnimations(v12.animationNodes)
end
function StrawBlower.onUpdateTick(p14, _, _, _, _)
	local v15 = p14.spec_strawBlower
	if v15.currentBale == nil and p14:getFillUnitSupportsToolType(v15.fillUnitIndex, ToolType.BALE) then
		local v16 = next(v15.triggeredBales)
		if v16 ~= nil then
			p14:setFillUnitCapacity(v15.fillUnitIndex, v16:getFillLevel())
			p14:addFillUnitFillLevel(p14:getOwnerFarmId(), v15.fillUnitIndex, (-1 / 0), FillType.UNKNOWN, ToolType.UNDEFINED)
			p14:addFillUnitFillLevel(p14:getOwnerFarmId(), v15.fillUnitIndex, v16:getFillLevel(), v16:getFillType(), ToolType.BALE)
			v15.currentBale = v16
		end
	end
end
function StrawBlower.addFillUnitFillLevel(p17, p18, p19, p20, p21, p22, p23, p24)
	if p20 == p17.spec_strawBlower.fillUnitIndex then
		local v25 = p17:getFillUnitCapacity(p20)
		local v26 = p17:getFillUnitFillLevel(p20) + p21
		p17:setFillUnitCapacity(p20, (math.max(v25, v26)))
	end
	return p18(p17, p19, p20, p21, p22, p23, p24)
end
function StrawBlower.strawBlowerBaleTriggerCallback(p27, _, p28, p29, p30, _, _)
	local v31 = p27.spec_strawBlower
	if p29 then
		if p28 ~= 0 then
			local v32 = g_currentMission:getNodeObject(p28)
			if v32 ~= nil and (v32:isa(Bale) and (g_currentMission.accessHandler:canFarmAccess(p27:getActiveFarm(), v32) and (v32:getAllowPickup() and p27:getFillUnitSupportsFillType(v31.fillUnitIndex, v32:getFillType())))) then
				v31.triggeredBales[v32] = Utils.getNoNil(v31.triggeredBales[v32], 0) + 1
				v32.allowPickup = false
				if v31.triggeredBales[v32] == 1 and v32.addDeleteListener ~= nil then
					v32:addDeleteListener(p27, "onDeleteStrawBlowerObject")
					return
				end
			end
		end
	elseif p30 and p28 ~= 0 then
		local v33 = g_currentMission:getNodeObject(p28)
		if v33 ~= nil then
			local v34 = v31.triggeredBales[v33]
			if v34 ~= nil then
				if v34 == 1 then
					v31.triggeredBales[v33] = nil
					v33.allowPickup = true
					if v33 == v31.currentBale then
						v31.currentBale = nil
						p27:addFillUnitFillLevel(p27:getOwnerFarmId(), v31.fillUnitIndex, (-1 / 0), p27:getFillUnitFillType(v31.fillUnitIndex), ToolType.UNDEFINED)
					end
					if v33.removeDeleteListener ~= nil then
						v33:removeDeleteListener(p27)
						return
					end
				else
					v31.triggeredBales[v33] = v34 - 1
				end
			end
		end
	end
end
function StrawBlower.onDeleteStrawBlowerObject(p35, p36)
	local v37 = p35.spec_strawBlower
	if v37.triggeredBales[p36] ~= nil then
		v37.triggeredBales[p36] = nil
		if p36 == v37.currentBale then
			v37.currentBale = nil
			p35:addFillUnitFillLevel(p35:getOwnerFarmId(), v37.fillUnitIndex, (-1 / 0), p35:getFillUnitFillType(v37.fillUnitIndex), ToolType.UNDEFINED)
		end
	end
end
function StrawBlower.getDrawFirstFillText(p38, p39)
	local v40 = p38.spec_strawBlower
	return p39(p38) or p38:getFillUnitFillLevel(v40.fillUnitIndex) <= 0
end
function StrawBlower.getAllowDynamicMountFillLevelInfo(_, _)
	return false
end
function StrawBlower.onFillUnitFillLevelChanged(p41, p42, _, p43, _, _, _)
	local v44 = p41.spec_strawBlower
	if p42 == v44.fillUnitIndex then
		local v45 = p41:getFillUnitFillLevel(v44.fillUnitIndex)
		if p41.isServer then
			local v46 = v44.currentBale
			if v46 ~= nil then
				if v45 <= 0.01 then
					if p41.removeDynamicMountedObject ~= nil then
						p41:removeDynamicMountedObject(v46)
					end
					local v47 = v46:getOwnerFarmId()
					v46:delete()
					v44.currentBale = nil
					v44.triggeredBales[v46] = nil
					p41:setFillUnitCapacity(v44.fillUnitIndex, 1)
					p41:addFillUnitFillLevel(v47, v44.fillUnitIndex, (-1 / 0), FillType.UNKNOWN, ToolType.UNDEFINED)
					return
				end
				if v45 < v46:getFillLevel() and p43 == v46:getFillType() then
					v46:setFillLevel(v45)
					return
				end
			end
		elseif v45 <= 0 then
			p41:setFillUnitCapacity(v44.fillUnitIndex, 1)
		end
	end
end
function StrawBlower.onDischargeStateChanged(p48, p49)
	local v50 = p48.spec_strawBlower
	local v51 = v50.samples
	if p48.isClient then
		if p49 ~= Dischargeable.DISCHARGE_STATE_OFF then
			g_soundManager:stopSample(v51.work)
			g_soundManager:stopSample(v51.stop)
			g_soundManager:playSample(v51.start)
			g_soundManager:playSample(v51.work, 0, v51.start)
			g_animationManager:startAnimations(v50.animationNodes)
			return
		end
		g_soundManager:stopSample(v51.start)
		g_soundManager:stopSample(v51.work)
		g_soundManager:playSample(v51.stop)
		g_animationManager:stopAnimations(v50.animationNodes)
	end
end

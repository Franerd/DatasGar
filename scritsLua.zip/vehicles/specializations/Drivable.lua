source("dataS/scripts/vehicles/specializations/events/SetCruiseControlStateEvent.lua")
source("dataS/scripts/vehicles/specializations/events/SetCruiseControlSpeedEvent.lua")
Drivable = {}
Drivable.CRUISECONTROL_STATE_OFF = 0
Drivable.CRUISECONTROL_STATE_ACTIVE = 1
Drivable.CRUISECONTROL_STATE_FULL = 2
Drivable.CRUISECONTROL_FULL_TOGGLE_TIME = 500
source("dataS/scripts/gui/hud/extensions/CruiseControlHUDExtension.lua")
function Drivable.prerequisitesPresent(p1)
	local v2 = SpecializationUtil.hasSpecialization(Enterable, p1)
	if v2 then
		v2 = SpecializationUtil.hasSpecialization(Motorized, p1)
	end
	return v2
end
function Drivable.initSpecialization()
	local v3 = Vehicle.xmlSchema
	v3:setXMLSpecializationType("Drivable")
	v3:register(XMLValueType.INT, "vehicle.drivable#reverserDirection", "Default state of reverser direction (when set to -1 the driving direction is inverted)", 1)
	v3:register(XMLValueType.INT, "vehicle.drivable#steeringDirection", "Default state of steering direction (when set to -1 the steering direction is inverted)", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.drivable.speedRotScale#scale", "Speed dependent steering speed scale", 80)
	v3:register(XMLValueType.FLOAT, "vehicle.drivable.speedRotScale#offset", "Speed dependent steering speed offset", 0.7)
	v3:register(XMLValueType.FLOAT, "vehicle.drivable.cruiseControl#maxSpeed", "Max. cruise control speed", "Max. vehicle speed")
	v3:register(XMLValueType.FLOAT, "vehicle.drivable.cruiseControl#minSpeed", "Min. cruise control speed", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.drivable.cruiseControl#maxSpeedReverse", "Max. cruise control speed in reverse", "Max. value reverse speed")
	v3:register(XMLValueType.BOOL, "vehicle.drivable.cruiseControl#enabled", "Cruise control enabled", true)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.drivable.steeringWheel#node", "Steering wheel node")
	v3:register(XMLValueType.ANGLE, "vehicle.drivable.steeringWheel#indoorRotation", "Steering wheel indoor rotation", 0)
	v3:register(XMLValueType.ANGLE, "vehicle.drivable.steeringWheel#outdoorRotation", "Steering wheel outdoor rotation", 0)
	v3:register(XMLValueType.BOOL, "vehicle.drivable.idleTurning#allowed", "When vehicle is not moving and steering keys are pressed turns on the same spot", false)
	v3:register(XMLValueType.BOOL, "vehicle.drivable.idleTurning#updateSteeringWheel", "Update steering wheel", true)
	v3:register(XMLValueType.BOOL, "vehicle.drivable.idleTurning#lockDirection", "Defines if the direction is locked until player accelerates again", true)
	v3:register(XMLValueType.INT, "vehicle.drivable.idleTurning#direction", "Driving direction [-1, 1]", 1)
	v3:register(XMLValueType.FLOAT, "vehicle.drivable.idleTurning#maxSpeed", "Max. speed while turning", 10)
	v3:register(XMLValueType.FLOAT, "vehicle.drivable.idleTurning#steeringFactor", "Steering speed factor", 100)
	v3:register(XMLValueType.NODE_INDEX, "vehicle.drivable.idleTurning.wheel(?)#node", "Wheel node to change")
	v3:register(XMLValueType.ANGLE, "vehicle.drivable.idleTurning.wheel(?)#steeringAngle", "Steering angle while idle turning")
	v3:register(XMLValueType.BOOL, "vehicle.drivable.idleTurning.wheel(?)#inverted", "Acceleration is inverted", false)
	Dashboard.registerDashboardXMLPaths(v3, "vehicle.drivable.dashboards", {
		"cruiseControl",
		"cruiseControlReverse",
		"directionForward",
		"directionBackward",
		"movingDirection",
		"cruiseControlActive",
		"accelerationAxis",
		"decelerationAxis",
		"ac_decelerationAxis",
		"steeringAngle",
		"combinedPedalLeft",
		"combinedPedalRight"
	})
	SoundManager.registerSampleXMLPaths(v3, "vehicle.drivable.sounds", "waterSplash")
	v3:setXMLSpecializationType()
	local v4 = Vehicle.xmlSchemaSavegame
	v4:register(XMLValueType.INT, "vehicles.vehicle(?).drivable#cruiseControl", "Current cruise control speed")
	v4:register(XMLValueType.INT, "vehicles.vehicle(?).drivable#cruiseControlReverse", "Current cruise control speed reverse")
end
function Drivable.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "updateSteeringWheel", Drivable.updateSteeringWheel)
	SpecializationUtil.registerFunction(p5, "setCruiseControlState", Drivable.setCruiseControlState)
	SpecializationUtil.registerFunction(p5, "setCruiseControlMaxSpeed", Drivable.setCruiseControlMaxSpeed)
	SpecializationUtil.registerFunction(p5, "getCruiseControlState", Drivable.getCruiseControlState)
	SpecializationUtil.registerFunction(p5, "getCruiseControlSpeed", Drivable.getCruiseControlSpeed)
	SpecializationUtil.registerFunction(p5, "getCruiseControlMaxSpeed", Drivable.getCruiseControlMaxSpeed)
	SpecializationUtil.registerFunction(p5, "getCruiseControlDisplayInfo", Drivable.getCruiseControlDisplayInfo)
	SpecializationUtil.registerFunction(p5, "getAxisForward", Drivable.getAxisForward)
	SpecializationUtil.registerFunction(p5, "getAccelerationAxis", Drivable.getAccelerationAxis)
	SpecializationUtil.registerFunction(p5, "getDecelerationAxis", Drivable.getDecelerationAxis)
	SpecializationUtil.registerFunction(p5, "getCruiseControlAxis", Drivable.getCruiseControlAxis)
	SpecializationUtil.registerFunction(p5, "getAcDecelerationAxis", Drivable.getAcDecelerationAxis)
	SpecializationUtil.registerFunction(p5, "getDashboardSteeringAxis", Drivable.getDashboardSteeringAxis)
	SpecializationUtil.registerFunction(p5, "setReverserDirection", Drivable.setReverserDirection)
	SpecializationUtil.registerFunction(p5, "getReverserDirection", Drivable.getReverserDirection)
	SpecializationUtil.registerFunction(p5, "getSteeringDirection", Drivable.getSteeringDirection)
	SpecializationUtil.registerFunction(p5, "getIsDrivingForward", Drivable.getIsDrivingForward)
	SpecializationUtil.registerFunction(p5, "getIsDrivingBackward", Drivable.getIsDrivingBackward)
	SpecializationUtil.registerFunction(p5, "getDrivingDirection", Drivable.getDrivingDirection)
	SpecializationUtil.registerFunction(p5, "getIsVehicleControlledByPlayer", Drivable.getIsVehicleControlledByPlayer)
	SpecializationUtil.registerFunction(p5, "getIsPlayerVehicleControlAllowed", Drivable.getIsPlayerVehicleControlAllowed)
	SpecializationUtil.registerFunction(p5, "registerPlayerVehicleControlAllowedFunction", Drivable.registerPlayerVehicleControlAllowedFunction)
	SpecializationUtil.registerFunction(p5, "updateVehiclePhysics", Drivable.updateVehiclePhysics)
	SpecializationUtil.registerFunction(p5, "setAccelerationPedalInput", Drivable.setAccelerationPedalInput)
	SpecializationUtil.registerFunction(p5, "setBrakePedalInput", Drivable.setBrakePedalInput)
	SpecializationUtil.registerFunction(p5, "setTargetSpeedAndDirection", Drivable.setTargetSpeedAndDirection)
	SpecializationUtil.registerFunction(p5, "setSteeringInput", Drivable.setSteeringInput)
	SpecializationUtil.registerFunction(p5, "brakeToStop", Drivable.brakeToStop)
	SpecializationUtil.registerFunction(p5, "updateSteeringAngle", Drivable.updateSteeringAngle)
end
function Drivable.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsManualDirectionChangeAllowed", Drivable.getIsManualDirectionChangeAllowed)
	SpecializationUtil.registerOverwrittenFunction(p6, "getMapHotspotRotation", Drivable.getMapHotspotRotation)
	SpecializationUtil.registerOverwrittenFunction(p6, "setTransmissionDirection", Drivable.setTransmissionDirection)
end
function Drivable.registerEvents(p7)
	SpecializationUtil.registerEvent(p7, "onVehiclePhysicsUpdate")
end
function Drivable.registerEventListeners(p8)
	SpecializationUtil.registerEventListener(p8, "onLoad", Drivable)
	SpecializationUtil.registerEventListener(p8, "onRegisterDashboardValueTypes", Drivable)
	SpecializationUtil.registerEventListener(p8, "onDelete", Drivable)
	SpecializationUtil.registerEventListener(p8, "onReadStream", Drivable)
	SpecializationUtil.registerEventListener(p8, "onWriteStream", Drivable)
	SpecializationUtil.registerEventListener(p8, "onReadUpdateStream", Drivable)
	SpecializationUtil.registerEventListener(p8, "onWriteUpdateStream", Drivable)
	SpecializationUtil.registerEventListener(p8, "onUpdate", Drivable)
	SpecializationUtil.registerEventListener(p8, "onDraw", Drivable)
	SpecializationUtil.registerEventListener(p8, "onRegisterActionEvents", Drivable)
	SpecializationUtil.registerEventListener(p8, "onLeaveVehicle", Drivable)
	SpecializationUtil.registerEventListener(p8, "onSetBroken", Drivable)
end
function Drivable.onLoad(p_u_9, p10)
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.steering#index", "vehicle.drivable.steeringWheel#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.steering#node", "vehicle.drivable.steeringWheel#node")
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.cruiseControl", "vehicle.drivable.cruiseControl")
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.indoorHud.cruiseControl", "vehicle.drivable.dashboards.dashboard with valueType \'cruiseControl\'")
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.showChangeToolSelectionHelp")
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.maxRotatedTimeSpeed#value")
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.speedRotScale#scale", "vehicle.drivable.speedRotScale#scale")
	XMLUtil.checkDeprecatedXMLElements(p_u_9.xmlFile, "vehicle.speedRotScale#offset", "vehicle.drivable.speedRotScale#offset")
	local v_u_11 = p_u_9.spec_drivable
	v_u_11.showToolSelectionHud = true
	v_u_11.doHandbrake = false
	v_u_11.doHandbrakeSend = false
	v_u_11.reverserDirection = p_u_9.xmlFile:getValue("vehicle.drivable#reverserDirection", 1)
	v_u_11.steeringDirection = p_u_9.xmlFile:getValue("vehicle.drivable#steeringDirection", 1)
	v_u_11.lastInputValues = {}
	v_u_11.lastInputValues.axisAccelerate = 0
	v_u_11.lastInputValues.axisBrake = 0
	v_u_11.lastInputValues.axisSteer = 0
	v_u_11.lastInputValues.axisSteerIsAnalog = false
	v_u_11.lastInputValues.axisSteerDeviceCategory = InputDevice.CATEGORY.UNKNOWN
	v_u_11.lastInputValues.cruiseControlValue = 0
	v_u_11.lastInputValues.cruiseControlState = 0
	v_u_11.axisForward = 0
	v_u_11.axisForwardSend = 0
	v_u_11.axisSide = 0
	v_u_11.axisSideSend = 0
	v_u_11.axisSideLast = 0
	v_u_11.lastIsControlled = false
	v_u_11.speedRotScale = p_u_9.xmlFile:getValue("vehicle.drivable.speedRotScale#scale", 80)
	v_u_11.speedRotScaleOffset = p_u_9.xmlFile:getValue("vehicle.drivable.speedRotScale#offset", 0.7)
	local v12 = p_u_9:getMotor()
	v_u_11.cruiseControl = {}
	v_u_11.cruiseControl.maxSpeed = p_u_9.xmlFile:getValue("vehicle.drivable.cruiseControl#maxSpeed", MathUtil.round(v12:getMaximumForwardSpeed() * 3.6))
	local v13 = v_u_11.cruiseControl
	local v14 = p_u_9.xmlFile
	local v15 = v_u_11.cruiseControl.maxSpeed
	v13.minSpeed = v14:getValue("vehicle.drivable.cruiseControl#minSpeed", (math.min(1, v15)))
	v_u_11.cruiseControl.speed = v_u_11.cruiseControl.maxSpeed
	v_u_11.cruiseControl.maxSpeedReverse = p_u_9.xmlFile:getValue("vehicle.drivable.cruiseControl#maxSpeedReverse", MathUtil.round(v12:getMaximumBackwardSpeed() * 3.6))
	v_u_11.cruiseControl.speedReverse = v_u_11.cruiseControl.maxSpeedReverse
	v_u_11.cruiseControl.isActive = p_u_9.xmlFile:getValue("vehicle.drivable.cruiseControl#enabled", true)
	v_u_11.cruiseControl.state = Drivable.CRUISECONTROL_STATE_OFF
	v_u_11.cruiseControl.topSpeedTime = 1000
	v_u_11.cruiseControl.changeDelay = 250
	v_u_11.cruiseControl.changeCurrentDelay = 0
	v_u_11.cruiseControl.changeMultiplier = 1
	v_u_11.cruiseControl.transmissionDirection = 1
	v_u_11.cruiseControl.speedSent = v_u_11.cruiseControl.speed
	v_u_11.cruiseControl.speedReverseSent = v_u_11.cruiseControl.speedReverse
	local v16 = p_u_9.xmlFile:getValue("vehicle.drivable.steeringWheel#node", nil, p_u_9.components, p_u_9.i3dMappings)
	if v16 ~= nil then
		v_u_11.steeringWheel = {}
		v_u_11.steeringWheel.node = v16
		local _, v17, _ = getRotation(v_u_11.steeringWheel.node)
		v_u_11.steeringWheel.lastRotation = v17
		v_u_11.steeringWheel.indoorRotation = p_u_9.xmlFile:getValue("vehicle.drivable.steeringWheel#indoorRotation", 0)
		v_u_11.steeringWheel.outdoorRotation = p_u_9.xmlFile:getValue("vehicle.drivable.steeringWheel#outdoorRotation", 0)
	end
	v_u_11.idleTurningAllowed = p_u_9.xmlFile:getValue("vehicle.drivable.idleTurning#allowed", false)
	v_u_11.idleTurningUpdateSteeringWheel = p_u_9.xmlFile:getValue("vehicle.drivable.idleTurning#updateSteeringWheel", true)
	v_u_11.idleTurningLockDirection = p_u_9.xmlFile:getValue("vehicle.drivable.idleTurning#lockDirection", true)
	v_u_11.idleTurningDrivingDirection = p_u_9.xmlFile:getValue("vehicle.drivable.idleTurning#direction", 1)
	v_u_11.idleTurningMaxSpeed = p_u_9.xmlFile:getValue("vehicle.drivable.idleTurning#maxSpeed", 10)
	v_u_11.idleTurningSteeringFactor = p_u_9.xmlFile:getValue("vehicle.drivable.idleTurning#steeringFactor", 100)
	v_u_11.idleTurningWheels = {}
	p_u_9.xmlFile:iterate("vehicle.drivable.idleTurning.wheel", function(_, p18)
		-- upvalues: (copy) p_u_9, (copy) v_u_11
		local v19 = p_u_9.xmlFile:getValue(p18 .. "#node", nil, p_u_9.components, p_u_9.i3dMappings)
		if v19 ~= nil then
			local v20 = {
				["wheelNode"] = v19,
				["steeringAngle"] = p_u_9.xmlFile:getValue(p18 .. "#steeringAngle", 0),
				["inverted"] = p_u_9.xmlFile:getValue(p18 .. "#inverted", false)
			}
			local v21 = v_u_11.idleTurningWheels
			table.insert(v21, v20)
		end
	end)
	v_u_11.idleTurningActive = false
	v_u_11.idleTurningActiveSend = false
	v_u_11.idleTurningDirection = 0
	p_u_9.customSteeringAngleFunction = p_u_9.customSteeringAngleFunction or #v_u_11.idleTurningWheels > 0
	v_u_11.forceFeedback = {}
	v_u_11.forceFeedback.isActive = false
	v_u_11.forceFeedback.device = nil
	v_u_11.forceFeedback.binding = nil
	v_u_11.forceFeedback.axisIndex = 0
	v_u_11.forceFeedback.intensity = g_gameSettings:getValue(GameSettings.SETTING.FORCE_FEEDBACK)
	v_u_11.playerControlAllowedFunctions = {}
	v_u_11.hasPlayerControlAllowedFunctions = false
	if p_u_9.isClient then
		v_u_11.samples = {}
		v_u_11.samples.waterSplash = g_soundManager:loadSampleFromXML(p_u_9.xmlFile, "vehicle.drivable.sounds", "waterSplash", p_u_9.baseDirectory, p_u_9.components, 1, AudioGroup.VEHICLE, p_u_9.i3dMappings, p_u_9)
		if p_u_9.isClient and (g_isDevelopmentVersion and (not GS_IS_MOBILE_VERSION and v_u_11.samples.waterSplash == nil)) then
			Logging.xmlDevWarning(p_u_9.xmlFile, "Missing drivable waterSplash sound")
		end
	end
	if p10 ~= nil then
		p_u_9:setCruiseControlMaxSpeed(p10.xmlFile:getValue(p10.key .. ".drivable#cruiseControl"), (p10.xmlFile:getValue(p10.key .. ".drivable#cruiseControlReverse")))
	end
	v_u_11.hudExtension = CruiseControlHUDExtension.new(p_u_9)
	v_u_11.dirtyFlag = p_u_9:getNextDirtyFlag()
end
function Drivable.onRegisterDashboardValueTypes(p22)
	local v23 = p22.spec_drivable
	local v24 = DashboardValueType.new("drivable", "cruiseControl")
	v24:setValue(v23.cruiseControl, "speed")
	p22:registerDashboardValueType(v24)
	local v25 = DashboardValueType.new("drivable", "cruiseControlReverse")
	v25:setValue(v23.cruiseControl, "speedReverse")
	p22:registerDashboardValueType(v25)
	local v26 = DashboardValueType.new("drivable", "cruiseControlActive")
	v26:setValue(v23.cruiseControl, "state")
	v26:setValueCompare(Drivable.CRUISECONTROL_STATE_ACTIVE, Drivable.CRUISECONTROL_STATE_FULL)
	p22:registerDashboardValueType(v26)
	local v27 = DashboardValueType.new("drivable", "directionForward")
	v27:setValue(p22, "getIsDrivingForward")
	p22:registerDashboardValueType(v27)
	local v28 = DashboardValueType.new("drivable", "directionBackward")
	v28:setValue(p22, "getIsDrivingBackward")
	p22:registerDashboardValueType(v28)
	local v29 = DashboardValueType.new("drivable", "movingDirection")
	v29:setValue(p22, "getDrivingDirection")
	v29:setRange(-1, 1)
	p22:registerDashboardValueType(v29)
	local v30 = DashboardValueType.new("drivable", "accelerationAxis")
	v30:setValue(p22, "getAccelerationAxis")
	p22:registerDashboardValueType(v30)
	local v31 = DashboardValueType.new("drivable", "decelerationAxis")
	v31:setValue(p22, "getDecelerationAxis")
	p22:registerDashboardValueType(v31)
	local v32 = DashboardValueType.new("drivable", "ac_decelerationAxis")
	v32:setValue(p22, "getAcDecelerationAxis")
	p22:registerDashboardValueType(v32)
	local v33 = DashboardValueType.new("drivable", "steeringAngle")
	v33:setValue(p22, "getDashboardSteeringAxis")
	v33:setRange(-1, 1)
	p22:registerDashboardValueType(v33)
	local v34 = DashboardValueType.new("drivable", "combinedPedalLeft")
	v34:setValue(p22, Drivable.getDashboardCombinedPedalLeft)
	v34:setRange(-1, 1)
	p22:registerDashboardValueType(v34)
	local v35 = DashboardValueType.new("drivable", "combinedPedalRight")
	v35:setValue(p22, Drivable.getDashboardCombinedPedalRight)
	v35:setRange(-1, 1)
	p22:registerDashboardValueType(v35)
end
function Drivable.onDelete(p36)
	local v37 = p36.spec_drivable
	g_soundManager:deleteSamples(v37.samples)
	if v37.hudExtension ~= nil then
		v37.hudExtension:delete()
	end
end
function Drivable.saveToXMLFile(p38, p39, p40, _)
	local v41 = p38.spec_drivable
	p39:setValue(p40 .. "#cruiseControl", v41.cruiseControl.speed)
	p39:setValue(p40 .. "#cruiseControlReverse", v41.cruiseControl.speedReverse)
end
function Drivable.onReadStream(p42, p43, _)
	local v44 = p42.spec_drivable
	if v44.cruiseControl.isActive then
		p42:setCruiseControlState(streamReadUIntN(p43, 2), true)
		local v45 = streamReadUInt8(p43)
		local v46 = streamReadUInt8(p43)
		p42:setCruiseControlMaxSpeed(v45, v46)
		v44.cruiseControl.speedSent = v45
		v44.cruiseControl.speedReverseSent = v46
	end
end
function Drivable.onWriteStream(p47, p48, _)
	local v49 = p47.spec_drivable
	if v49.cruiseControl.isActive then
		streamWriteUIntN(p48, v49.cruiseControl.state, 2)
		streamWriteUInt8(p48, v49.cruiseControl.speed)
		streamWriteUInt8(p48, v49.cruiseControl.speedReverse)
	end
end
function Drivable.onReadUpdateStream(p50, p51, _, _)
	local v52 = p50.spec_drivable
	if streamReadBool(p51) then
		v52.axisForward = streamReadUIntN(p51, 10) / 1023 * 2 - 1
		local v53 = v52.axisForward
		if math.abs(v53) < 0.00099 then
			v52.axisForward = 0
		end
		v52.axisSide = streamReadUIntN(p51, 10) / 1023 * 2 - 1
		local v54 = v52.axisSide
		if math.abs(v54) < 0.00099 then
			v52.axisSide = 0
		end
		v52.doHandbrake = streamReadBool(p51)
		v52.idleTurningActive = streamReadBool(p51)
	end
end
function Drivable.onWriteUpdateStream(p55, p56, _, p57)
	local v58 = p55.spec_drivable
	if streamWriteBool(p56, bitAND(p57, v58.dirtyFlag) ~= 0) then
		local v59 = (v58.axisForward + 1) / 2 * 1023
		streamWriteUIntN(p56, v59, 10)
		local v60 = (v58.axisSide + 1) / 2 * 1023
		streamWriteUIntN(p56, v60, 10)
		streamWriteBool(p56, v58.doHandbrake)
		streamWriteBool(p56, v58.idleTurningActive)
	end
end
function Drivable.onUpdate(p61, p62, _, _, _)
	local v63 = p61.spec_drivable
	if p61.isClient and (p61.getIsEntered ~= nil and p61:getIsEntered()) then
		if p61.isActiveForInputIgnoreSelectionIgnoreAI then
			if p61:getIsVehicleControlledByPlayer() then
				local v64 = p61:getLastSpeed()
				v63.doHandbrake = false
				local v65 = v63.lastInputValues.axisAccelerate - v63.lastInputValues.axisBrake
				local v66 = math.clamp(v65, -1, 1)
				v63.axisForward = v66
				if v63.brakeToStop then
					v63.lastInputValues.targetSpeed = 0.51
					v63.lastInputValues.targetDirection = 1
					if v64 < 1 then
						v63.brakeToStop = false
						v63.lastInputValues.targetSpeed = nil
						v63.lastInputValues.targetDirection = nil
					end
				end
				if v63.lastInputValues.targetSpeed ~= nil then
					local v67 = v64 * p61.movingDirection * p61:getReverserDirection()
					local v68 = v63.lastInputValues.targetSpeed * v63.lastInputValues.targetDirection
					local v69 = v68 - v67
					if math.abs(v69) > 0.1 and math.abs(v68) > 0.5 then
						local v70 = math.abs(v69)
						local v71 = math.pow(v70, 1.5) * math.sign(v69)
						v63.axisForward = math.clamp(v71, -1, 1)
					end
				end
				if p61:getIsPowered() then
					local v72 = 1
					local v73 = g_gameSettings:getValue(GameSettings.SETTING.STEERING_SENSITIVITY)
					local v74 = v63.lastInputValues.axisSteer
					local v75
					if v63.lastInputValues.axisSteerIsAnalog then
						local v76
						if p61.spec_articulatedAxis == nil then
							v76 = false
						else
							v76 = p61.spec_articulatedAxis.componentJoint ~= nil
						end
						v75 = v76 and 1.5 or 2.5
						if GS_IS_MOBILE_VERSION then
							v75 = v75 * 1.5
							if v74 == 0 then
								v75 = v75 * g_gameSettings:getValue(GameSettings.SETTING.STEERING_BACK_SPEED) / 10
							end
							local v77 = math.abs(v74)
							local v78 = 1 / v73
							v74 = math.pow(v77, v78) * (v74 >= 0 and 1 or -1)
						elseif v63.lastInputValues.axisSteerDeviceCategory == InputDevice.CATEGORY.GAMEPAD then
							v75 = v75 * v73
						end
						local v79 = v63.forceFeedback
						if v79.isActive then
							if v79.intensity > 0 then
								local v80 = math.abs(v74)
								local v81 = (v64 - 2) / 15
								local v82 = math.min(v81, 1)
								local v83 = math.max(v82, 0)
								local v84 = v74 - 0.2 * v83 * math.sign(v74)
								local v85 = math.abs(v84) * 0.4
								local v86 = math.max(v85, 0.25) * v83 * v80 * 2 * v79.intensity
								v79.device:setForceFeedback(v79.axisIndex, v86, v84)
							else
								v79.device:setForceFeedback(v79.axisIndex, 0, v74)
							end
						end
					else
						local v87
						if v63.lastInputValues.axisSteer == 0 then
							v87 = false
						else
							local v88 = v63.lastInputValues.axisSteer
							local v89 = math.sign(v88)
							local v90 = v63.axisSide
							v87 = v89 ~= math.sign(v90)
						end
						if v63.lastInputValues.axisSteer == 0 or v87 then
							local v91 = g_gameSettings:getValue(GameSettings.SETTING.STEERING_BACK_SPEED) / 10
							if not v87 and (v91 < 1 and p61.speedDependentRotateBack) then
								local v92 = v64 / 36 * (v91 / 0.5)
								v72 = v72 * math.min(v92, 1)
							end
							v75 = v72 * (p61.autoRotateBackSpeed or 1) / 1.5
						else
							local v93 = 1 / (p61.lastSpeed * v63.speedRotScale + v63.speedRotScaleOffset)
							v75 = math.min(v93, 1) * v73
						end
					end
					if v63.idleTurningAllowed then
						if v66 == 0 and (math.abs(v74) > 0.05 and (v64 < 1 and not v63.idleTurningActive)) then
							v63.idleTurningActive = true
							v63.idleTurningDirection = math.sign(v74) * v63.idleTurningDrivingDirection
						end
						if v66 ~= 0 and v63.idleTurningActive then
							v63.idleTurningActive = false
							if v74 > 0 then
								p61.rotatedTime = p61.minRotTime
								v63.axisSide = 1
							elseif v74 < 0 then
								p61.rotatedTime = p61.maxRotTime
								v63.axisSide = -1
							end
						end
						if v63.idleTurningActive and not v63.idleTurningLockDirection then
							v63.idleTurningDirection = v63.idleTurningDrivingDirection
							if v74 == 0 then
								v63.idleTurningActive = false
								v63.axisSide = 0
							end
						end
						if v63.idleTurningActive then
							v63.axisForward = v63.idleTurningDirection * math.sign(v74)
							v74 = math.abs(v74) * v63.idleTurningDirection
							v75 = v75 * v63.idleTurningSteeringFactor
						end
					end
					local v94 = p62 / ((p61.wheelSteeringDuration or 1) * 1000) * v75
					if v63.axisSide < v74 then
						local v95 = v63.axisSide + v94
						v63.axisSide = math.min(v74, v95)
					elseif v74 < v63.axisSide then
						local v96 = v63.axisSide - v94
						v63.axisSide = math.max(v74, v96)
					end
				end
			else
				v63.axisForward = 0
				v63.idleTurningActive = false
				if p61.rotatedTime < 0 then
					v63.axisSide = p61.rotatedTime / -p61.maxRotTime / p61:getSteeringDirection()
				else
					v63.axisSide = p61.rotatedTime / p61.minRotTime / p61:getSteeringDirection()
				end
			end
		else
			v63.doHandbrake = true
			v63.axisForward = 0
			v63.idleTurningActive = false
		end
		v63.lastInputValues.axisAccelerate = 0
		v63.lastInputValues.axisBrake = 0
		v63.lastInputValues.axisSteer = 0
		if v63.axisForward ~= v63.axisForwardSend or (v63.axisSide ~= v63.axisSideSend or (v63.doHandbrake ~= v63.doHandbrakeSend or v63.idleTurningActiveSend ~= v63.idleTurningActive)) then
			v63.axisForwardSend = v63.axisForward
			v63.axisSideSend = v63.axisSide
			v63.doHandbrakeSend = v63.doHandbrake
			v63.idleTurningActiveSend = v63.idleTurningActive
			p61:raiseDirtyFlags(v63.dirtyFlag)
		end
	end
	if p61.isClient and (p61.getIsEntered ~= nil and p61:getIsEntered()) then
		local v97 = v63.lastInputValues.cruiseControlState
		v63.lastInputValues.cruiseControlState = 0
		if v97 == 1 then
			if v63.cruiseControl.topSpeedTime == Drivable.CRUISECONTROL_FULL_TOGGLE_TIME then
				if v63.cruiseControl.state == Drivable.CRUISECONTROL_STATE_OFF then
					p61:setCruiseControlState(Drivable.CRUISECONTROL_STATE_ACTIVE)
				else
					p61:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF)
				end
			end
			if v63.cruiseControl.topSpeedTime > 0 then
				v63.cruiseControl.topSpeedTime = v63.cruiseControl.topSpeedTime - p62
				if v63.cruiseControl.topSpeedTime < 0 then
					p61:setCruiseControlState(Drivable.CRUISECONTROL_STATE_FULL)
				end
			end
		else
			v63.cruiseControl.topSpeedTime = Drivable.CRUISECONTROL_FULL_TOGGLE_TIME
		end
		local v98 = v63.lastInputValues.cruiseControlValue
		v63.lastInputValues.cruiseControlValue = 0
		if v98 == 0 then
			v63.cruiseControl.changeCurrentDelay = 0
			v63.cruiseControl.changeMultiplier = 1
		else
			v63.cruiseControl.changeCurrentDelay = v63.cruiseControl.changeCurrentDelay - p62 * v63.cruiseControl.changeMultiplier
			local v99 = v63.cruiseControl
			local v100 = v63.cruiseControl.changeMultiplier + p62 * 0.003
			v99.changeMultiplier = math.min(v100, 10)
			if v63.cruiseControl.changeCurrentDelay < 0 then
				v63.cruiseControl.changeCurrentDelay = v63.cruiseControl.changeDelay
				local v101 = math.sign(v98)
				local v102 = v63.cruiseControl.speed
				local v103 = v63.cruiseControl.speedReverse
				local v104 = p61:getDrivingDirection() < 0
				if p61:getReverserDirection() < 0 then
					v104 = not v104
				end
				if v104 then
					v103 = v103 + v101
				else
					v102 = v102 + v101
				end
				p61:setCruiseControlMaxSpeed(v102, v103)
				if v63.cruiseControl.speed ~= v63.cruiseControl.speedSent or v63.cruiseControl.speedReverse ~= v63.cruiseControl.speedReverseSent then
					if g_server == nil then
						g_client:getServerConnection():sendEvent(SetCruiseControlSpeedEvent.new(p61, v63.cruiseControl.speed, v63.cruiseControl.speedReverse))
					else
						g_server:broadcastEvent(SetCruiseControlSpeedEvent.new(p61, v63.cruiseControl.speed, v63.cruiseControl.speedReverse), nil, nil, p61)
					end
					v63.cruiseControl.speedSent = v63.cruiseControl.speed
					v63.cruiseControl.speedReverseSent = v63.cruiseControl.speedReverse
				end
			end
		end
	end
	local v105
	if p61.getIsControlled == nil then
		v105 = false
	else
		v105 = p61:getIsControlled()
	end
	if p61:getIsVehicleControlledByPlayer() and p61.isServer then
		if v105 then
			local v106
			if v63.cruiseControl.state == Drivable.CRUISECONTROL_STATE_ACTIVE then
				if p61:getReverserDirection() < 0 then
					v106 = v63.cruiseControl.speedReverse
				else
					v106 = v63.cruiseControl.speed
				end
			else
				v106 = (1 / 0)
			end
			if p61:getDrivingDirection() < 0 then
				if p61:getReverserDirection() < 0 then
					local v107 = v63.cruiseControl.speed
					v106 = math.min(v106, v107)
				else
					local v108 = v63.cruiseControl.speedReverse
					v106 = math.min(v106, v108)
				end
			end
			if v106 == (1 / 0) then
				v63.cruiseControl.speedInterpolated = nil
			else
				v63.cruiseControl.speedInterpolated = v63.cruiseControl.speedInterpolated or v106
				if v106 ~= v63.cruiseControl.speedInterpolated then
					local v109 = v106 - v63.cruiseControl.speedInterpolated
					local v110 = math.sign(v109)
					local v111 = v110 == 1 and math.min or math.max
					local v112 = v63.cruiseControl
					local v113 = v63.cruiseControl.speedInterpolated
					local v114 = p62 * 0.0025
					local v115 = math.abs(v109)
					v112.speedInterpolated = v111(v113 + v114 * math.max(1, v115) * v110, v106)
					v106 = v63.cruiseControl.speedInterpolated
				end
			end
			local v116, _ = p61:getSpeedLimit(true)
			local v117 = math.min(v116, v106)
			if v63.idleTurningAllowed and v63.idleTurningActive then
				local v118 = v63.idleTurningMaxSpeed
				v117 = math.min(v117, v118)
			end
			p61:getMotor():setSpeedLimit(v117)
			p61:updateVehiclePhysics(v63.axisForward, v63.axisSide, v63.doHandbrake, p62)
		elseif v63.lastIsControlled then
			SpecializationUtil.raiseEvent(p61, "onVehiclePhysicsUpdate", 0, 0, true, 0)
		end
	end
	if p61.isClient and v105 and (not v63.idleTurningAllowed or (not v63.idleTurningActive or v63.idleTurningUpdateSteeringWheel)) then
		p61:updateSteeringWheel(v63.steeringWheel, p62, 1)
	end
	v63.lastIsControlled = v105
	if p61:getIsActiveForInput(true) and (g_inputBinding:getInputHelpMode() ~= GS_INPUT_HELP_MODE_GAMEPAD or GS_PLATFORM_SWITCH) and g_gameSettings:getValue(GameSettings.SETTING.GYROSCOPE_STEERING) then
		local v119, v120, v121 = getGravityDirection()
		p61:setSteeringInput(MathUtil.getSteeringAngleFromDeviceGravity(v119, v120, v121), true, InputDevice.CATEGORY.WHEEL)
	end
end
function Drivable.onDraw(p122)
	local v123 = p122.spec_drivable
	if v123.hudExtension ~= nil and (p122.getIsControlled ~= nil and p122:getIsControlled()) then
		g_currentMission.hud:addHelpExtension(v123.hudExtension)
	end
end
function Drivable.setCruiseControlState(p124, p125, p126)
	local v127 = p124.spec_drivable
	if v127.cruiseControl ~= nil and v127.cruiseControl.state ~= p125 then
		v127.cruiseControl.state = p125
		if p126 == nil or not p126 then
			if p124.isServer then
				local v128 = p124:getOwnerConnection()
				if v128 ~= nil then
					v128:sendEvent(SetCruiseControlStateEvent.new(p124, p125))
				end
			else
				g_client:getServerConnection():sendEvent(SetCruiseControlStateEvent.new(p124, p125))
			end
		end
		if v127.toggleCruiseControlEvent ~= nil then
			local v129
			if p125 == Drivable.CRUISECONTROL_STATE_ACTIVE then
				v129 = g_i18n:getText("action_deactivateCruiseControl")
			else
				v129 = g_i18n:getText("action_activateCruiseControl")
			end
			g_inputBinding:setActionEventText(v127.toggleCruiseControlEvent, v129)
		end
	end
end
function Drivable.setCruiseControlMaxSpeed(p130, p131, p132)
	local v133 = p130.spec_drivable
	if p131 ~= nil then
		local v134 = v133.cruiseControl.minSpeed
		local v135 = v133.cruiseControl.maxSpeed
		local v136 = math.clamp(p131, v134, v135)
		if v133.cruiseControl.speed ~= v136 then
			v133.cruiseControl.speed = v136
			if v133.cruiseControl.state == Drivable.CRUISECONTROL_STATE_FULL then
				v133.cruiseControl.state = Drivable.CRUISECONTROL_STATE_ACTIVE
			end
		end
		if p132 ~= nil then
			local v137 = v133.cruiseControl.minSpeed
			local v138 = v133.cruiseControl.maxSpeedReverse
			local v139 = math.clamp(p132, v137, v138)
			v133.cruiseControl.speedReverse = v139
		end
		if v133.cruiseControl.state ~= Drivable.CRUISECONTROL_STATE_OFF then
			if v133.cruiseControl.state == Drivable.CRUISECONTROL_STATE_ACTIVE then
				local v140, _ = p130:getSpeedLimit(true)
				local v141 = v133.cruiseControl.speed
				local v142 = math.min(v140, v141)
				p130:getMotor():setSpeedLimit(v142)
			else
				p130:getMotor():setSpeedLimit((1 / 0))
			end
		end
		if p130:getDrivingDirection() < 0 then
			local v143, _ = p130:getSpeedLimit(true)
			local v144 = v133.cruiseControl.speedReverse
			local v145 = math.min(v143, v144)
			p130:getMotor():setSpeedLimit(v145)
		end
	end
end
function Drivable.updateSteeringWheel(p146, p147, _, p148)
	if p147 ~= nil then
		local v149 = p147.outdoorRotation
		if g_localPlayer:getCurrentVehicle() == p146 and p146.getActiveCamera ~= nil then
			local v150 = p146:getActiveCamera()
			if v150 ~= nil and v150.isInside then
				v149 = p147.indoorRotation
			end
		end
		local v151 = p146.rotatedTime * v149
		if p147.lastRotation ~= v151 then
			p147.lastRotation = v151
			setRotation(p147.node, 0, v151 * p148, 0)
			if p146.getVehicleCharacter ~= nil then
				local v152 = p146:getVehicleCharacter()
				if v152 ~= nil and v152:getAllowCharacterUpdate() then
					v152:setDirty(true)
				end
			end
		end
	end
end
function Drivable.getCruiseControlState(p153)
	return p153.spec_drivable.cruiseControl.state
end
function Drivable.getCruiseControlSpeed(p154)
	local v155 = p154.spec_drivable
	if v155.cruiseControl.state == Drivable.CRUISECONTROL_STATE_FULL then
		return v155.cruiseControl.maxSpeed
	else
		return v155.cruiseControl.speed
	end
end
function Drivable.getCruiseControlMaxSpeed(p156)
	return p156.spec_drivable.cruiseControl.maxSpeed
end
function Drivable.getCruiseControlDisplayInfo(p157)
	local v158 = true
	local v159 = p157.spec_drivable.cruiseControl
	local v160
	if p157:getReverserDirection() < 0 then
		v160 = v159.speedReverse
	else
		v160 = v159.speed
	end
	if v159.state == Drivable.CRUISECONTROL_STATE_FULL then
		v160 = v159.maxSpeed
	elseif v159.state == Drivable.CRUISECONTROL_STATE_OFF then
		v158 = false
	end
	if p157:getDrivingDirection() < 0 then
		if p157:getReverserDirection() < 0 then
			return v159.speed, v158
		end
		v160 = v159.speedReverse
	end
	return v160, v158
end
function Drivable.getAxisForward(p161)
	return p161.spec_drivable.axisForward
end
function Drivable.getAccelerationAxis(p162)
	local v163 = p162.movingDirection > -1 and 1 or -1
	local v164 = p162.spec_drivable.axisForward * v163 * p162:getReverserDirection()
	return math.max(v164, 0)
end
g_soundManager:registerModifierType("ACCELERATE", Drivable.getAccelerationAxis)
function Drivable.getDecelerationAxis(p165)
	if p165.lastSpeedReal > 0.0001 then
		local v166 = p165.movingDirection
		local v167 = p165.spec_drivable.axisForward
		if v166 == math.sign(v167) or p165.lastSpeedReal > 0.002 then
			local v168 = p165.spec_drivable.axisForward * p165.movingDirection * p165:getReverserDirection()
			local v169 = math.min(v168, 0)
			return math.abs(v169)
		end
	end
	return 0
end
g_soundManager:registerModifierType("DECELERATE", Drivable.getDecelerationAxis)
function Drivable.getCruiseControlAxis(p170)
	return p170.spec_drivable.cruiseControl.state == Drivable.CRUISECONTROL_STATE_OFF and 0 or 1
end
g_soundManager:registerModifierType("CRUISECONTROL", Drivable.getCruiseControlAxis)
function Drivable.getAcDecelerationAxis(p171)
	return p171.spec_drivable.axisForward * p171:getReverserDirection()
end
function Drivable.getDashboardSteeringAxis(p172)
	local v173 = p172.spec_drivable
	if v173.idleTurningAllowed and v173.idleTurningActive then
		return not v173.idleTurningUpdateSteeringWheel and 0 or p172.rotatedTime / p172.maxRotTime * p172:getReverserDirection() * v173.idleTurningDirection * v173.axisForward
	else
		return p172.rotatedTime / p172.maxRotTime * p172:getReverserDirection()
	end
end
function Drivable.getDashboardCombinedPedalLeft(p174)
	local v175 = p174:getAcDecelerationAxis()
	local v176 = p174.spec_drivable
	if v176.idleTurningAllowed and v176.idleTurningActive then
		return v175 * v176.idleTurningDirection
	end
	local v177 = v175 - p174:getDashboardSteeringAxis()
	return math.clamp(v177, -1, 1)
end
function Drivable.getDashboardCombinedPedalRight(p178)
	local v179 = p178:getAcDecelerationAxis()
	local v180 = p178.spec_drivable
	if v180.idleTurningAllowed and v180.idleTurningActive then
		return -v179 * v180.idleTurningDirection
	end
	local v181 = v179 + p178:getDashboardSteeringAxis()
	return math.clamp(v181, -1, 1)
end
function Drivable.setReverserDirection(p182, p183)
	p182.spec_drivable.reverserDirection = p183
end
function Drivable.getReverserDirection(p184)
	return p184.spec_drivable.reverserDirection
end
function Drivable.getSteeringDirection(p185)
	return p185.spec_drivable.steeringDirection
end
function Drivable.getIsDrivingForward(p186)
	return p186:getDrivingDirection() >= 0
end
function Drivable.getIsDrivingBackward(p187)
	return p187:getDrivingDirection() < 0
end
function Drivable.getDrivingDirection(p188)
	local v189 = p188:getLastSpeed()
	return v189 < 0.2 and 0 or (v189 < 1.5 and p188.spec_drivable.axisForward == 0 and 0 or p188.movingDirection * p188:getReverserDirection())
end
g_soundManager:registerModifierType("DRIVING_DIRECTION", Drivable.getDrivingDirection)
function Drivable.getIsVehicleControlledByPlayer(_)
	return true
end
function Drivable.getIsPlayerVehicleControlAllowed(p190)
	local v191 = p190.spec_drivable
	if v191.hasPlayerControlAllowedFunctions then
		for v192, v193 in pairs(v191.playerControlAllowedFunctions) do
			local v194 = NetworkUtil.getObject(v192)
			if v194 == nil or v194.rootVehicle ~= p190 then
				v191.playerControlAllowedFunctions[v192] = nil
				v191.hasPlayerControlAllowedFunctions = table.size(v191.playerControlAllowedFunctions) > 0
			else
				local v195, v196 = v193(v194)
				if not v195 then
					return v195, v196
				end
			end
		end
	end
	return true, nil
end
function Drivable.registerPlayerVehicleControlAllowedFunction(p197, p198, p199)
	local v200 = NetworkUtil.getObjectId(p198)
	if v200 ~= nil and p199 ~= nil then
		local v201 = p197.spec_drivable
		v201.playerControlAllowedFunctions[v200] = p199
		v201.hasPlayerControlAllowedFunctions = table.size(v201.playerControlAllowedFunctions) > 0
	end
end
function Drivable.stopMotor(p202, _)
	p202:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF, true)
end
function Drivable.onRegisterActionEvents(p203, _, _)
	if p203.isClient then
		local v204 = p203.spec_drivable
		v204.toggleCruiseControlEvent = nil
		p203:clearActionEventsTable(v204.actionEvents)
		local v205 = p203.getIsEntered == nil and true or p203:getIsEntered()
		if p203:getIsActiveForInput(true, true) and v205 then
			if not p203:getIsAIActive() then
				local _, v206 = p203:addPoweredActionEvent(v204.actionEvents, InputAction.AXIS_ACCELERATE_VEHICLE, p203, Drivable.actionEventAccelerate, false, false, true, true, nil)
				g_inputBinding:setActionEventTextPriority(v206, GS_PRIO_VERY_LOW)
				g_inputBinding:setActionEventTextVisibility(v206, false)
				local _, v207 = p203:addPoweredActionEvent(v204.actionEvents, InputAction.AXIS_BRAKE_VEHICLE, p203, Drivable.actionEventBrake, false, false, true, true, nil)
				g_inputBinding:setActionEventTextPriority(v207, GS_PRIO_VERY_LOW)
				g_inputBinding:setActionEventTextVisibility(v207, false)
				local _, v208 = p203:addPoweredActionEvent(v204.actionEvents, InputAction.AXIS_MOVE_SIDE_VEHICLE, p203, Drivable.actionEventSteer, false, false, true, true, nil)
				g_inputBinding:setActionEventTextPriority(v208, GS_PRIO_VERY_LOW)
				g_inputBinding:setActionEventTextVisibility(v208, false)
				g_inputBinding:setActionEventText(v208, g_i18n:getText("action_steer"))
				local _, v209 = p203:addActionEvent(v204.actionEvents, InputAction.TOGGLE_CRUISE_CONTROL, p203, Drivable.actionEventCruiseControlState, false, true, true, true, nil)
				g_inputBinding:setActionEventTextPriority(v209, GS_PRIO_LOW)
				v204.toggleCruiseControlEvent = v209
			end
			local _, v210 = p203:addActionEvent(v204.actionEvents, InputAction.AXIS_CRUISE_CONTROL, p203, Drivable.actionEventCruiseControlValue, false, true, true, true, nil)
			g_inputBinding:setActionEventText(v210, g_i18n:getText("action_changeCruiseControlLevel"))
			g_inputBinding:setActionEventTextPriority(v210, GS_PRIO_LOW)
		end
	end
end
function Drivable.onLeaveVehicle(p211, p212)
	p211:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF)
	if p211.brake ~= nil then
		p211:brake(1)
	end
	if p212 then
		local v213 = p211.spec_drivable.forceFeedback
		if v213.isActive then
			v213.device:setForceFeedback(v213.axisIndex, 0, 0)
			v213.isActive = false
			v213.device = nil
		end
	end
end
function Drivable.onSetBroken(p214)
	if p214.isClient then
		local v215 = p214.spec_drivable
		g_soundManager:playSample(v215.samples.waterSplash)
	end
end
function Drivable.updateVehiclePhysics(p216, p217, p218, p219, p220)
	local v221 = p216.spec_drivable
	local v222 = p216:getSteeringDirection() * p218
	local v223
	if p216:getIsMotorStarted() then
		if math.abs(p217) > 0 then
			p216:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF)
		end
		v223 = v221.cruiseControl.state ~= Drivable.CRUISECONTROL_STATE_OFF and 1 or p217
	else
		v223 = 0
	end
	if not p216:getCanMotorRun() then
		v223 = 0
		if p216:getIsMotorStarted() then
			p216:stopMotor()
		end
	end
	if p216.getIsControlled ~= nil and p216:getIsControlled() then
		local v224
		if p216.maxRotTime == nil or p216.minRotTime == nil then
			v224 = 0
		elseif v222 < 0 then
			local v225 = -p216.maxRotTime * v222
			local v226 = p216.maxRotTime
			v224 = math.min(v225, v226)
		else
			local v227 = p216.minRotTime * v222
			local v228 = p216.minRotTime
			v224 = math.max(v227, v228)
		end
		p216.rotatedTime = v224
	end
	if p216.finishedFirstUpdate and (p216.spec_wheels ~= nil and #p216.spec_wheels.wheels > 0) then
		WheelsUtil.updateWheelsPhysics(p216, p220, p216.lastSpeedReal * p216.movingDirection, v223, p219, g_currentMission.missionInfo.stopAndGoBraking)
	end
	return v223
end
function Drivable.setAccelerationPedalInput(p229, p230)
	local v231 = p229.spec_drivable
	v231.lastInputValues.axisAccelerate = math.clamp(p230, 0, 1)
	if v231.lastInputValues.targetSpeed ~= nil then
		v231.lastInputValues.targetSpeed = nil
		v231.lastInputValues.targetDirection = nil
	end
end
function Drivable.setBrakePedalInput(p232, p233)
	local v234 = p232.spec_drivable
	v234.lastInputValues.axisBrake = math.clamp(p233, 0, 1)
	if v234.lastInputValues.targetSpeed ~= nil then
		v234.lastInputValues.targetSpeed = nil
		v234.lastInputValues.targetDirection = nil
	end
end
function Drivable.setTargetSpeedAndDirection(p235, p236, p237)
	local v238 = p235.spec_drivable
	if p237 > 0 then
		p236 = p236 * p235:getMotor():getMaximumForwardSpeed() * 3.6
	elseif p237 < 0 then
		p236 = p236 * p235:getMotor():getMaximumBackwardSpeed() * 3.6
	end
	v238.lastInputValues.targetSpeed = p236
	v238.lastInputValues.targetDirection = p237
end
function Drivable.setSteeringInput(p239, p240, p241, p242)
	local v243 = p239.spec_drivable
	v243.lastInputValues.axisSteer = p240
	if p240 ~= 0 then
		v243.lastInputValues.axisSteerIsAnalog = p241
		v243.lastInputValues.axisSteerDeviceCategory = p242
	end
end
function Drivable.brakeToStop(p244)
	p244.spec_drivable.brakeToStop = true
end
function Drivable.updateSteeringAngle(p245, p246, _, p247)
	local v248 = p245.spec_drivable
	if v248.idleTurningAllowed then
		for v249 = 1, #v248.idleTurningWheels do
			local v250 = v248.idleTurningWheels[v249]
			if p246.repr == v250.wheelNode or p246.driveNode == v250.wheelNode then
				local v251 = v250.steeringAngle
				if v250.inverted then
					v251 = v250.steeringAngle + 3.141592653589793
				end
				if v248.idleTurningActive then
					p247 = v251 or p247
				end
				return p247
			end
		end
	end
	return p247
end
function Drivable.getIsManualDirectionChangeAllowed(p252, p253)
	local v254 = p252.spec_drivable
	if v254.idleTurningAllowed and v254.idleTurningActive then
		return false
	else
		return p253(p252)
	end
end
function Drivable.getMapHotspotRotation(p255, p256, p257)
	if p255:getReverserDirection() < 0 then
		return p256(p255, p257) + 3.141592653589793
	else
		return p256(p255, p257)
	end
end
function Drivable.setTransmissionDirection(p258, p259, p260)
	p259(p258, p260)
	if p260 ~= p258.spec_drivable.cruiseControl.transmissionDirection then
		local v261 = p258.spec_drivable
		local v262 = v261.cruiseControl
		local v263 = v261.cruiseControl
		local v264 = v261.cruiseControl.maxSpeedReverse
		local v265 = v261.cruiseControl.maxSpeed
		v262.maxSpeed = v264
		v263.maxSpeedReverse = v265
		p258:setCruiseControlMaxSpeed(v261.cruiseControl.speedReverse, v261.cruiseControl.speed)
		v261.cruiseControl.transmissionDirection = p260
	end
end
function Drivable.actionEventAccelerate(p266, _, p267, _, _)
	if p267 ~= 0 then
		local v268, v269 = p266:getIsPlayerVehicleControlAllowed()
		if v268 then
			p266:setAccelerationPedalInput(p267)
			return
		end
		if v269 ~= nil then
			g_currentMission:showBlinkingWarning(v269, 2000)
		end
	end
end
function Drivable.actionEventBrake(p270, _, p271, _, _)
	if p271 ~= 0 then
		local v272, v273 = p270:getIsPlayerVehicleControlAllowed()
		if v272 then
			p270:setBrakePedalInput(p271)
			return
		end
		if v273 ~= nil then
			g_currentMission:showBlinkingWarning(v273, 2000)
		end
	end
end
function Drivable.actionEventSteer(p274, _, p275, _, p276, _, p277, p278)
	local v279 = p274.spec_drivable
	if v279.forceFeedback.isActive then
		if p278 ~= v279.forceFeedback.binding then
			local v280, _, _ = g_inputBinding:getBindingForceFeedbackInfo(p278)
			if not v280 then
				v279.forceFeedback.isActive = false
				v279.forceFeedback.device = nil
				v279.forceFeedback.binding = nil
				v279.forceFeedback.axisIndex = 0
			end
		end
	else
		local v281, v282, v283 = g_inputBinding:getBindingForceFeedbackInfo(p278)
		v279.forceFeedback.isActive = v281
		v279.forceFeedback.device = v282
		v279.forceFeedback.binding = p278
		v279.forceFeedback.axisIndex = v283
		if v281 then
			v282:setForceFeedback(v283, 0, p275)
		end
	end
	if p275 ~= 0 then
		local v284, v285 = p274:getIsPlayerVehicleControlAllowed()
		if v284 then
			p274:setSteeringInput(p275, p276, p277)
			return
		end
		if v285 ~= nil then
			g_currentMission:showBlinkingWarning(v285, 2000)
		end
	end
end
function Drivable.actionEventCruiseControlState(p286, _, _, _, _)
	local v287 = p286.spec_drivable
	local v288, v289 = p286:getIsPlayerVehicleControlAllowed()
	if v288 then
		v287.lastInputValues.cruiseControlState = 1
	elseif v289 ~= nil then
		g_currentMission:showBlinkingWarning(v289, 2000)
	end
end
function Drivable.actionEventCruiseControlValue(p290, _, p291, _, _)
	p290.spec_drivable.lastInputValues.cruiseControlValue = p291
end

Dashboard = {}
source("dataS/scripts/vehicles/DashboardValueType.lua")
Dashboard.DEFAULT_MAX_UPDATE_DISTANCE = 7.5
Dashboard.DEFAULT_MAX_UPDATE_DISTANCE_CRITICAL = 20
Dashboard.GROUP_XML_KEY = "vehicle.dashboard.groups.group(?)"
Dashboard.TYPES = {}
Dashboard.TYPES.EMITTER = 0
Dashboard.TYPES.NUMBER = 1
Dashboard.TYPES.ANIMATION = 2
Dashboard.TYPES.ROT = 3
Dashboard.TYPES.TRANS = 4
Dashboard.TYPES.VISIBILITY = 5
Dashboard.TYPES.TEXT = 6
Dashboard.TYPES.SLIDER = 7
Dashboard.TYPES.MULTI_STATE = 8
Dashboard.TYPE_DATA = {}
Dashboard.COLORS = {}
Dashboard.COLORS.GREY = {
	0.3,
	0.3,
	0.3,
	1
}
Dashboard.COLORS.DARK_GREY = {
	0.15,
	0.15,
	0.15,
	1
}
Dashboard.COLORS.BLACK = {
	0.05,
	0.05,
	0.05,
	1
}
Dashboard.COLORS.LIGHT_GREEN = {
	0.05,
	0.15,
	0.05,
	1
}
Dashboard.COLORS.RED = {
	1,
	0,
	0,
	1
}
Dashboard.COLORS.GREEN = {
	0,
	1,
	0,
	1
}
Dashboard.COLORS.BLUE = {
	0,
	0,
	1,
	1
}
Dashboard.COLORS.YELLOW = {
	1,
	1,
	0,
	1
}
Dashboard.COLORS.ORANGE = {
	1,
	0.5,
	0,
	1
}
Dashboard.COLORS.WHITE = {
	1,
	1,
	1,
	1
}
Dashboard.compoundsXMLSchema = nil
function Dashboard.prerequisitesPresent(_)
	return true
end
function Dashboard.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("Dashboard")
	Dashboard.registerDashboardXMLPaths(v1, "vehicle.dashboard.default")
	v1:register(XMLValueType.STRING, Dashboard.GROUP_XML_KEY .. "#name", "Dashboard group name")
	v1:register(XMLValueType.FLOAT, "vehicle.dashboard#maxUpdateDistance", "Max. distance to vehicle root to update connection hoses", Dashboard.DEFAULT_MAX_UPDATE_DISTANCE)
	v1:register(XMLValueType.FLOAT, "vehicle.dashboard#maxUpdateDistanceCritical", "Max. distance to vehicle root to update critical connection hoses (All with type \'ROT\')", Dashboard.DEFAULT_MAX_UPDATE_DISTANCE_CRITICAL)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.dashboard.compounds.compound(?)#linkNode", "Link node for dashboard compound")
	v1:register(XMLValueType.STRING, "vehicle.dashboard.compounds.compound(?)#filename", "Path to compound xml file")
	v1:register(XMLValueType.STRING, "vehicle.dashboard.compounds.compound(?)#name", "Name of dashboard compound to load")
	v1:register(XMLValueType.STRING_LIST, "vehicle.dashboard.compounds.compound(?)#configIds", "Configuration identifiers (the given configuations will be enabled, separated by whitespace)")
	v1:register(XMLValueType.STRING, "vehicle.dashboard.compounds.compound(?).configurationDependency(?)#configName", "Name of the vehicle config")
	v1:register(XMLValueType.INT, "vehicle.dashboard.compounds.compound(?).configurationDependency(?)#configIndex", "Index of the vehicle config")
	v1:register(XMLValueType.STRING_LIST, "vehicle.dashboard.compounds.compound(?).configurationDependency(?)#additionalConfigIds", "Dashboard config ids to be used when this vehicle config is active")
	v1:register(XMLValueType.STRING_LIST, "vehicle.dashboard.compounds.compound(?).configurationDependency(?)#disabledConfigIds", "Dashboard config ids to be used when this vehicle config is active")
	v1:setXMLSpecializationType()
	Dashboard.compoundsXMLSchema = XMLSchema.new("dashboardCompounds")
	Dashboard.compoundsXMLSchema:register(XMLValueType.NODE_INDEX, "dashboardCompounds.dashboardCompound(?)#node", "Root node in i3d file to load")
	Dashboard.compoundsXMLSchema:register(XMLValueType.STRING, "dashboardCompounds.dashboardCompound(?)#filename", "Path to i3d file")
	Dashboard.compoundsXMLSchema:register(XMLValueType.STRING, "dashboardCompounds.dashboardCompound(?)#name", "Name of dashboard compound")
	I3DUtil.registerI3dMappingXMLPaths(Dashboard.compoundsXMLSchema, "dashboardCompounds")
	Dashboard.registerDashboardXMLPaths(Dashboard.compoundsXMLSchema, "dashboardCompounds.dashboardCompound(?)")
	Dashboard.compoundsXMLSchema:register(XMLValueType.STRING, "dashboardCompounds.dashboardCompound(?).configuration(?)#id", "Identifier of the configuration")
	Dashboard.registerDashboardXMLPaths(Dashboard.compoundsXMLSchema, "dashboardCompounds.dashboardCompound(?).configuration(?)")
	ObjectChangeUtil.registerObjectChangeXMLPaths(Dashboard.compoundsXMLSchema, "dashboardCompounds.dashboardCompound(?).configuration(?)")
end
function Dashboard.registerEvents(p2)
	SpecializationUtil.registerEvent(p2, "onRegisterDashboardValueTypes")
end
function Dashboard.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "registerDashboardValueType", Dashboard.registerDashboardValueType)
	SpecializationUtil.registerFunction(p3, "updateDashboards", Dashboard.updateDashboards)
	SpecializationUtil.registerFunction(p3, "loadDashboardGroupFromXML", Dashboard.loadDashboardGroupFromXML)
	SpecializationUtil.registerFunction(p3, "getIsDashboardGroupActive", Dashboard.getIsDashboardGroupActive)
	SpecializationUtil.registerFunction(p3, "getDashboardGroupByName", Dashboard.getDashboardGroupByName)
	SpecializationUtil.registerFunction(p3, "loadDashboardCompoundFromXML", Dashboard.loadDashboardCompoundFromXML)
	SpecializationUtil.registerFunction(p3, "onDashboardCompoundLoaded", Dashboard.onDashboardCompoundLoaded)
	SpecializationUtil.registerFunction(p3, "loadDashboardsFromXML", Dashboard.loadDashboardsFromXML)
	SpecializationUtil.registerFunction(p3, "loadDashboardFromXML", Dashboard.loadDashboardFromXML)
	SpecializationUtil.registerFunction(p3, "setDashboardsDirty", Dashboard.setDashboardsDirty)
	SpecializationUtil.registerFunction(p3, "getDashboardValue", Dashboard.getDashboardValue)
end
function Dashboard.registerEventListeners(p4)
	SpecializationUtil.registerEventListener(p4, "onLoad", Dashboard)
	SpecializationUtil.registerEventListener(p4, "onPostLoad", Dashboard)
	SpecializationUtil.registerEventListener(p4, "onDelete", Dashboard)
	SpecializationUtil.registerEventListener(p4, "onUpdate", Dashboard)
	SpecializationUtil.registerEventListener(p4, "onUpdateTick", Dashboard)
	SpecializationUtil.registerEventListener(p4, "onUpdateEnd", Dashboard)
end
function Dashboard.onLoad(p5, _)
	local v6 = p5.spec_dashboard
	v6.dashboards = {}
	v6.criticalDashboards = {}
	v6.groups = {}
	v6.sortedGroups = {}
	v6.groupUpdateIndex = 1
	v6.hasGroups = false
	v6.dashboardTypesLoaded = false
	v6.dashboardValueTypes = {}
	v6.sharedLoadRequestIds = {}
	local v7 = 0
	while true do
		local v8 = string.format("%s.groups.group(%d)", "vehicle.dashboard", v7)
		if not p5.xmlFile:hasProperty(v8) then
			break
		end
		local v9 = {}
		if p5:loadDashboardGroupFromXML(p5.xmlFile, v8, v9) then
			v6.groups[v9.name] = v9
			local v10 = v6.sortedGroups
			table.insert(v10, v9)
			v6.hasGroups = true
		end
		v7 = v7 + 1
	end
	v6.isDirty = false
	v6.isDirtyTick = false
	v6.maxUpdateDistance = p5.xmlFile:getValue("vehicle.dashboard#maxUpdateDistance", Dashboard.DEFAULT_MAX_UPDATE_DISTANCE)
	v6.maxUpdateDistanceCritical = p5.xmlFile:getValue("vehicle.dashboard#maxUpdateDistanceCritical", Dashboard.DEFAULT_MAX_UPDATE_DISTANCE_CRITICAL)
end
function Dashboard.onPostLoad(p_u_11, _)
	local v_u_12 = p_u_11.spec_dashboard
	if p_u_11.isClient then
		SpecializationUtil.raiseEvent(p_u_11, "onRegisterDashboardValueTypes")
		v_u_12.dashboardTypesLoaded = true
		p_u_11:loadDashboardsFromXML(p_u_11.xmlFile, "vehicle.dashboard.default")
		for _, v13 in ipairs(v_u_12.dashboardValueTypes) do
			v13:loadFromXML(p_u_11.xmlFile, p_u_11)
		end
		v_u_12.dashboardCompounds = {}
		p_u_11.xmlFile:iterate("vehicle.dashboard.compounds.compound", function(_, p14)
			-- upvalues: (copy) p_u_11, (copy) v_u_12
			local v15 = {}
			if p_u_11:loadDashboardCompoundFromXML(p_u_11.xmlFile, p14, v15) then
				local v16 = v_u_12.dashboardCompounds
				table.insert(v16, v15)
			end
		end)
	end
	if not p_u_11.isClient or #v_u_12.criticalDashboards == 0 and #v_u_12.dashboards == 0 then
		SpecializationUtil.removeEventListener(p_u_11, "onUpdate", Dashboard)
		SpecializationUtil.removeEventListener(p_u_11, "onUpdateTick", Dashboard)
	end
end
function Dashboard.onDelete(p17)
	local v18 = p17.spec_dashboard
	if v18.sharedLoadRequestIds ~= nil then
		for _, v19 in ipairs(v18.sharedLoadRequestIds) do
			g_i3DManager:releaseSharedI3DFile(v19)
		end
		v18.sharedLoadRequestIds = nil
	end
end
function Dashboard.registerDashboardValueType(p20, p21)
	local v22 = p20.spec_dashboard
	local v23 = v22.dashboardValueTypes
	table.insert(v23, p21)
	if v22.dashboardTypesLoaded then
		p21:loadFromXML(p20.xmlFile, p20)
	end
end
function Dashboard.onUpdate(p24, p25, _, _, _)
	if p24.isClient then
		local v26 = p24.spec_dashboard
		if v26.hasGroups then
			local v27 = v26.sortedGroups[v26.groupUpdateIndex]
			if p24:getIsDashboardGroupActive(v27) ~= v27.isActive then
				v27.isActive = not v27.isActive
				p24:updateDashboards(v26.dashboards, p25, true)
				p24:updateDashboards(v26.criticalDashboards, p25, true)
			end
			v26.groupUpdateIndex = v26.groupUpdateIndex + 1
			if v26.groupUpdateIndex > #v26.sortedGroups then
				v26.groupUpdateIndex = 1
			end
		end
		if p24.currentUpdateDistance < v26.maxUpdateDistanceCritical or v26.isDirty then
			p24:updateDashboards(v26.criticalDashboards, p25)
			v26.isDirty = false
		end
		if v26.isDirtyTick then
			p24:raiseActive()
		end
	end
end
function Dashboard.onUpdateTick(p28, p29, _, _, _)
	if p28.isClient then
		local v30 = p28.spec_dashboard
		if p28.currentUpdateDistance < v30.maxUpdateDistance or v30.isDirtyTick then
			p28:updateDashboards(v30.dashboards, p29)
			v30.isDirtyTick = false
		end
	end
end
function Dashboard.onUpdateEnd(p31, p32, _, _, _)
	if p31.isClient then
		local v33 = p31.spec_dashboard
		p31:updateDashboards(v33.dashboards, p32, true)
		p31:updateDashboards(v33.criticalDashboards, p32, true)
	end
end
function Dashboard.updateDashboards(p34, p35, p36, p37)
	for v38 = 1, #p35 do
		local v39 = p35[v38]
		local v40 = true
		for v41 = 1, #v39.groups do
			if not v39.groups[v41].isActive then
				v40 = false
				break
			end
		end
		if v39.valueType == nil then
			if p37 then
				v39.stateFunc(p34, v39, true, nil, nil, v40)
			end
		else
			local v42, v43, v44, v45, v46 = v39.valueType:getValue(v39)
			if v39.minActiveValue ~= nil and v42 < v39.minActiveValue then
				v40 = false
			end
			if v39.maxActiveValue ~= nil and v39.maxActiveValue < v42 then
				v40 = false
			end
			if v46 then
				if v39.offsetValue ~= nil then
					v42 = v42 + v39.offsetValue
				end
				if v39.valueMapping ~= nil then
					v42 = v39.valueMapping:get(v42)
				end
			end
			if not v40 then
				v42 = v39.idleValue
			end
			if v39.doInterpolation then
				v42 = not v46 and (v42 and 1 or 0) or v42
				if v42 ~= v39.lastInterpolationValue then
					local v47 = v42 - v39.lastInterpolationValue
					local v48 = math.sign(v47)
					local v49 = math.min
					if v48 < 0 then
						v49 = math.max
					end
					v42 = v49(v39.lastInterpolationValue + v39.interpolationSpeed * v48 * p36, v42)
					v39.lastInterpolationValue = v42
				end
			end
			if v42 ~= v39.lastValue or p37 then
				v39.lastValue = v42
				local v50
				if v46 then
					if v43 ~= nil then
						if v39.doInterpolation then
							local v51 = v39.idleValue
							v43 = math.min(v43, v51)
						end
						v42 = math.max(v43, v42)
					end
					if v44 ~= nil and v40 then
						if v39.doInterpolation then
							local v52 = v39.idleValue
							v44 = math.max(v44, v52)
						end
						v42 = math.min(v44, v42)
					end
					if v45 == nil then
						v50 = v44
					else
						local v53 = math.abs(v43)
						local v54 = math.abs(v44)
						v50 = math.max(v53, v54)
						if v42 < v45 then
							v42 = -v42 / v43 * v50
						elseif v45 < v42 then
							v42 = v42 / v44 * v50
						end
						v43 = -v50
					end
				else
					v50 = v44
				end
				v39.stateFunc(p34, v39, v42, v43, v50, v40)
			end
		end
	end
end
function Dashboard.loadDashboardGroupFromXML(p55, p56, p57, p58)
	p58.name = p56:getValue(p57 .. "#name")
	if p58.name == nil then
		Logging.xmlWarning(p55.xmlFile, "Missing name for dashboard group \'%s\'", p57)
		return false
	elseif p55:getDashboardGroupByName(p58.name) == nil then
		p58.isActive = false
		return true
	else
		Logging.xmlWarning(p55.xmlFile, "Duplicated dashboard group name \'%s\' for group \'%s\'", p58.name, p57)
		return false
	end
end
function Dashboard.getIsDashboardGroupActive(_, _)
	return true
end
function Dashboard.getDashboardGroupByName(p59, p60)
	return p59.spec_dashboard.groups[p60]
end
function Dashboard.loadDashboardCompoundFromXML(p61, p62, p63, p_u_64)
	p_u_64.linkNode = p62:getValue(p63 .. "#linkNode", nil, p61.components, p61.i3dMappings)
	if p_u_64.linkNode == nil then
		return false
	end
	p_u_64.filename = p62:getValue(p63 .. "#filename")
	if p_u_64.filename == nil then
		return false
	end
	p_u_64.filename = Utils.getFilename(p_u_64.filename, p61.baseDirectory)
	if p_u_64.filename ~= nil then
		p_u_64.name = p62:getValue(p63 .. "#name")
		p_u_64.configIds = p62:getValue(p63 .. "#configIds", nil, true)
		for _, v65 in p62:iterator(p63 .. ".configurationDependency") do
			local v66 = p62:getValue(v65 .. "#configName")
			local v67 = p62:getValue(v65 .. "#configIndex")
			if v66 ~= nil and (v67 ~= nil and p61.configurations[v66] == v67) then
				local v68 = p62:getValue(v65 .. "#additionalConfigIds", nil, true)
				for _, v69 in ipairs(v68) do
					local v70 = p_u_64.configIds
					table.insert(v70, v69)
				end
				local v71 = p62:getValue(v65 .. "#disabledConfigIds", nil, true)
				for _, v72 in ipairs(v71) do
					for v73 = #p_u_64.configIds, 1, -1 do
						if p_u_64.configIds[v73] == v72 then
							table.remove(p_u_64.configIds, v73)
						end
					end
				end
			end
		end
		if p_u_64.name == nil then
			Logging.xmlWarning(p62, "Missing name in \'%s\'", p63)
			return false
		end
		local v_u_74 = XMLFile.load("dashboardCompoundsXML", p_u_64.filename, Dashboard.compoundsXMLSchema)
		if v_u_74 ~= nil then
			local v_u_75 = nil
			v_u_74:iterate("dashboardCompounds.dashboardCompound", function(_, p76)
				-- upvalues: (copy) v_u_74, (copy) p_u_64, (ref) v_u_75
				if v_u_74:getValue(p76 .. "#name") == p_u_64.name then
					v_u_75 = p76
				end
			end)
			if v_u_75 == nil then
				Logging.xmlWarning(v_u_74, "Unable to find compound by name \'%s\'", p_u_64.name)
				v_u_74:delete()
				return false
			end
			local v77 = v_u_74:getValue(v_u_75 .. "#filename")
			if v77 ~= nil then
				v77 = Utils.getFilename(v77, p61.baseDirectory)
			end
			if v77 == nil then
				Logging.xmlWarning(v_u_74, "Missing filename for compound \'%s\'", p_u_64.name)
				return false
			end
			local v78 = {
				["dashboardXMLFile"] = v_u_74,
				["compound"] = p_u_64,
				["compoundKey"] = v_u_75
			}
			local v79 = p61:loadSubSharedI3DFile(v77, false, false, p61.onDashboardCompoundLoaded, p61, v78)
			local v80 = p61.spec_dashboard.sharedLoadRequestIds
			table.insert(v80, v79)
			return true
		end
	end
	return false
end
function Dashboard.onDashboardCompoundLoaded(p81, p82, _, p83)
	local v84 = p83.dashboardXMLFile
	local v85 = p83.compound
	local v86 = p83.compoundKey
	if p82 ~= 0 then
		local v87 = {}
		for v88 = 1, getNumOfChildren(p82) do
			local v89 = {
				["node"] = getChildAt(p82, v88 - 1)
			}
			table.insert(v87, v89)
		end
		v85.i3dMappings = {}
		I3DUtil.loadI3DMapping(v84, "dashboardCompounds", v87, v85.i3dMappings, nil)
		local v90 = v84:getValue(v86 .. "#node", nil, v87, v85.i3dMappings)
		if v90 == nil then
			Logging.xmlWarning(v84, "Unable to find node for compound at \'%s\'", v86)
		else
			link(v85.linkNode, v90)
			setTranslation(v90, 0, 0, 0)
			setRotation(v90, 0, 0, 0)
			p81:loadDashboardsFromXML(v84, v86, nil, v87, v85.i3dMappings, v90)
			for _, v91 in v84:iterator(v86 .. ".configuration") do
				local v92 = false
				local v93 = v84:getValue(v91 .. "#id")
				if v93 ~= nil and v85.configIds ~= nil then
					for _, v94 in ipairs(v85.configIds) do
						if string.lower(v93) == string.lower(v94) then
							v92 = true
						end
					end
				end
				local v95 = {}
				ObjectChangeUtil.loadObjectChangeFromXML(v84, v91, v95, v87, v85)
				ObjectChangeUtil.setObjectChanges(v95, v92, v85)
				if v92 then
					p81:loadDashboardsFromXML(v84, v91, nil, v87, v85.i3dMappings, v90)
				end
			end
		end
		delete(p82)
	end
	v84:delete()
end
function Dashboard.loadDashboardsFromXML(p_u_96, p_u_97, p98, p_u_99, p_u_100, p_u_101, p_u_102)
	if p_u_96.isClient then
		local v_u_103 = p_u_96.spec_dashboard
		p_u_97:iterate(p98 .. ".dashboard", function(_, p104)
			-- upvalues: (copy) p_u_97, (copy) p_u_99, (copy) v_u_103, (copy) p_u_96, (copy) p_u_100, (copy) p_u_101, (copy) p_u_102
			local v105 = p_u_97:getValue(p104 .. "#valueType")
			local v106 = p_u_99
			local v107 = 0
			if v106 == nil and v105 ~= nil then
				for _, v108 in ipairs(v_u_103.dashboardValueTypes) do
					if v105 == v108.name or v105 == v108.fullName then
						v107 = v107 + 1
						v106 = v108
					end
				end
			end
			if v107 > 1 and v106.xmlKey == nil then
				Logging.xmlWarning(p_u_97, "Dashboard valueType name \'%s\' is used in multiple specializations. Please specify with specialization prefix. (e.g. \'motorized.rpm\')", v105)
			end
			local v109 = {}
			if p_u_96:loadDashboardFromXML(p_u_97, p104, v109, v106, p_u_100 or p_u_96.components, p_u_101 or p_u_96.i3dMappings, p_u_102) then
				if Dashboard.TYPE_DATA[v109.displayTypeIndex].isCritical then
					local v110 = v_u_103.criticalDashboards
					table.insert(v110, v109)
					return
				end
				local v111 = v_u_103.dashboards
				table.insert(v111, v109)
			end
		end)
	end
	return true
end
function Dashboard.loadDashboardFromXML(p112, p113, p114, p115, p116, p117, p118, p119)
	p115.valueType = p116
	if p116 ~= nil then
		if p116.isa == nil or not p116:isa(DashboardValueType) then
			Logging.error("Deprecated call of Dashboard:loadDashboardFromXML. Needs to be called with DashboardValueType object or nil.")
			printCallstack()
			return false
		end
		local v120 = p113:getValue(p114 .. "#valueType")
		if v120 ~= p115.valueType.name and v120 ~= p115.valueType.fullName then
			return false
		end
	end
	local v121 = p113:getValue(p114 .. "#displayType")
	if v121 == nil then
		Logging.xmlWarning(p113, "Missing displayType for dashboard \'%s\'", p114)
		return false
	end
	local v122 = Dashboard.TYPES[v121:upper()]
	if v122 == nil then
		Logging.xmlWarning(p113, "Unknown displayType \'%s\' for dashboard \'%s\'", v121, p114)
		return false
	end
	p115.displayTypeIndex = v122
	p115.doInterpolation = p113:getValue(p114 .. "#doInterpolation", false)
	p115.idleValue = p113:getValue(p114 .. "#idleValue", p116 == nil and 0 or (p116.idleValue or 0))
	p115.lastInterpolationValue = p115.idleValue
	p115.offsetValue = p113:getValue(p114 .. "#offsetValue")
	p115.minActiveValue = p113:getValue(p114 .. "#minActiveValue")
	p115.maxActiveValue = p113:getValue(p114 .. "#maxActiveValue")
	if p113:hasProperty(p114 .. ".valueMapping") then
		p115.valueMapping = AnimCurve.new(linearInterpolator1)
		for _, v123 in p113:iterator(p114 .. ".valueMapping") do
			local v124 = p113:getValue(v123 .. "#sourceValue")
			local v125 = p113:getValue(v123 .. "#dashboardValue")
			if v124 ~= nil and v125 ~= nil then
				p115.valueMapping:addKeyframe({
					v125,
					["time"] = v124
				})
			end
		end
		if p115.valueMapping.numKeyframes == 0 then
			p115.valueMapping = nil
		end
	end
	p115.groups = {}
	local v126 = p113:getValue(p114 .. "#groups")
	if v126 ~= nil then
		local v127 = string.split(v126, " ")
		for _, v128 in ipairs(v127) do
			local v129 = p112:getDashboardGroupByName(v128)
			if v129 == nil then
				Logging.xmlWarning(p113, "Unable to find dashboard group \'%s\' for dashboard \'%s\'", v128, p114)
			else
				local v130 = p115.groups
				table.insert(v130, v129)
			end
		end
	end
	local v131
	if p116 == nil then
		v131 = nil
	else
		v131 = p116:getInterpolationSpeed(p115)
	end
	p115.interpolationSpeed = p113:getValue(p114 .. "#interpolationSpeed", v131 or 0.005)
	local v132 = Dashboard.TYPE_DATA[p115.displayTypeIndex]
	if v132 == nil then
		return false
	end
	if not v132.loadFunc(p112, p113, p114, p115, p117, p118, p119) then
		return false
	end
	if p116 ~= nil and (p116.loadFunction ~= nil and not p116.loadFunction(p112, p113, p114, p115, p117, p118, p119)) then
		return false
	end
	if p116 == nil or p116.stateFunction == nil then
		p115.stateFunc = Dashboard.defaultDashboardStateFunc
	else
		p115.stateFunc = p116.stateFunction
	end
	p115.lastValue = nil
	return true
end
function Dashboard.defaultDashboardStateFunc(p133, p134, p135, p136, p137, p138)
	Dashboard.TYPE_DATA[p134.displayTypeIndex].updateFunc(p133, p134, p135, p136, p137, p138)
end
function Dashboard.setDashboardsDirty(p139)
	p139.spec_dashboard.isDirty = true
	p139.spec_dashboard.isDirtyTick = true
	p139:raiseActive()
end
function Dashboard.getDashboardValue(_, p140, p141, p142)
	if type(p141) == "number" or type(p141) == "boolean" then
		return p141
	elseif type(p141) == "function" then
		return p141(p140, p142)
	else
		local v143 = p140[p141]
		if type(v143) == "function" then
			return p140[p141](p140, p142)
		elseif type(v143) == "number" or type(v143) == "boolean" then
			return v143
		else
			return nil
		end
	end
end
function Dashboard.getDashboardColor(p144, p145, p146)
	if p145 == nil then
		return nil
	elseif Dashboard.COLORS[p145:upper()] == nil then
		local v147 = g_vehicleMaterialManager:getMaterialTemplateColorByName(p145, p146)
		if v147 == nil then
			local v148 = string.getVector(p145)
			if v148 == nil or #v148 < 3 then
				Logging.xmlWarning(p144, "Unable to resolve color \'%s\'", p145)
				return nil
			else
				if #v148 == 3 then
					v148[4] = 1
				end
				return v148
			end
		else
			return v147
		end
	else
		return Dashboard.COLORS[p145:upper()]
	end
end
function Dashboard.warningAttributes(_, p149, p150, p151, _)
	p151.warningThresholdMin = p149:getValue(p150 .. "#warningThresholdMin", (-1 / 0))
	p151.warningThresholdMax = p149:getValue(p150 .. "#warningThresholdMax", (1 / 0))
	return true
end
function Dashboard.registerDisplayType(p152, p153, p154, p155, p156)
	Dashboard.TYPE_DATA[p152] = {
		["isCritical"] = p153,
		["schemaFunc"] = p154,
		["loadFunc"] = p155,
		["updateFunc"] = p156
	}
end
Dashboard.registerDisplayType(Dashboard.TYPES.EMITTER, false, function(p157, p158)
	p157:register(XMLValueType.STRING, p158 .. ".dashboard(?)#baseColor", "(EMITTER) Base color (DashboardColor OR BrandColor OR r g b a)")
	p157:register(XMLValueType.STRING, p158 .. ".dashboard(?)#emitColor", "(EMITTER) Emit color (DashboardColor OR BrandColor OR r g b a)")
	p157:register(XMLValueType.FLOAT, p158 .. ".dashboard(?)#intensity", "Intensity", 1)
	p157:register(XMLValueType.BOOL, p158 .. ".dashboard(?)#inverted", "(EMITTER) State will be inverted", false)
	p157:register(XMLValueType.BOOL, p158 .. ".dashboard(?)#toggleVisibility", "(EMITTER) If the mesh is not emitting (idle), the mesh will be hidden", false)
	p157:register(XMLValueType.STRING, p158 .. ".dashboard(?)#inactiveGroups", "(EMITTER) If defined, the inactive color/intensity will only be set if this group is active (if not active, the disabled color/intensity is used)")
	p157:register(XMLValueType.FLOAT, p158 .. ".dashboard(?)#disabledIntensity", "(EMITTER) Intensity while the dashboard group is not active")
	p157:register(XMLValueType.STRING, p158 .. ".dashboard(?)#disabledColor", "(EMITTER) Disabled emit color (DashboardColor OR BrandColor OR r g b a)")
	p157:register(XMLValueType.FLOAT, p158 .. ".dashboard(?)#inactiveIntensity", "(EMITTER) Intensity while the dashboard state is not active, but the group is active")
	p157:register(XMLValueType.STRING, p158 .. ".dashboard(?)#inactiveColor", "(EMITTER) Inactive emit color (DashboardColor OR BrandColor OR r g b a)")
	p157:register(XMLValueType.BOOL, p158 .. ".dashboard(?)#hideInactive", "(EMITTER) Hide the emitter shape when the dashboard is inactive", false)
	p157:register(XMLValueType.BOOL, p158 .. ".dashboard(?)#hideInactiveChildren", "(EMITTER) Hide all the children when the dashboard is inactive", false)
end, function(p159, p160, p161, p162, p163, p164, p165)
	local v166 = p160:getValue(p161 .. "#node", nil, p163, p164)
	if v166 == nil then
		Logging.xmlWarning(p160, "Missing node for emitter dashboard \'%s\'", p161)
		return false
	end
	if p165 ~= nil and not I3DUtil.getIsLinkedToNode(p165, v166) then
		Logging.xmlWarning(p160, "Emitter dashboard node \'%s\' is not a child of the parent node \'%s\' in \'%s\'", getName(v166), getName(p165), p161)
		return false
	end
	if not getHasClassId(v166, ClassIds.SHAPE) then
		Logging.xmlWarning(p160, "Emitter Dashboard node is not a shape! \'%s\' in \'%s\'", getName(v166), p161)
		return false
	end
	if not (getHasShaderParameter(v166, "lightControl") or getHasShaderParameter(v166, "lightIds0")) then
		Logging.xmlWarning(p160, "Emitter dashboard shape not using \'lightControl\' or \'lightIds0\' shader parameter in \'%s\'", p161)
		return false
	end
	p162.node = v166
	p162.inverted = p160:getValue(p161 .. "#inverted", false)
	p162.toggleVisibility = p160:getValue(p161 .. "#toggleVisibility", false)
	if p162.toggleVisibility then
		setVisibility(p162.node, false)
	end
	p162.baseColor = Dashboard.getDashboardColor(p160, p160:getValue(p161 .. "#baseColor"), p159.customEnvironment)
	if p162.baseColor ~= nil then
		setShaderParameter(p162.node, "baseColor", p162.baseColor[1], p162.baseColor[2], p162.baseColor[3], 1, false)
	end
	p162.disabledIntensity = p160:getValue(p161 .. "#disabledIntensity")
	p162.disabledColor = Dashboard.getDashboardColor(p160, p160:getValue(p161 .. "#disabledColor"), p159.customEnvironment)
	p162.inactiveIntensity = p160:getValue(p161 .. "#inactiveIntensity")
	p162.inactiveColor = Dashboard.getDashboardColor(p160, p160:getValue(p161 .. "#inactiveColor"), p159.customEnvironment)
	p162.inactiveGroups = {}
	local v167 = p160:getValue(p161 .. "#inactiveGroups")
	if v167 ~= nil then
		local v168 = string.split(v167, " ")
		for _, v169 in ipairs(v168) do
			local v170 = p159:getDashboardGroupByName(v169)
			if v170 == nil then
				Logging.xmlWarning(p160, "Unable to find inactive dashboard group \'%s\' for dashboard \'%s\'", v169, p161)
			else
				local v171 = p162.inactiveGroups
				table.insert(v171, v170)
			end
		end
	end
	p162.emitColor = Dashboard.getDashboardColor(p160, p160:getValue(p161 .. "#emitColor"), p159.customEnvironment)
	if p162.emitColor ~= nil then
		setShaderParameter(p162.node, "emitColor", p162.emitColor[1], p162.emitColor[2], p162.emitColor[3], 1, false)
	end
	p162.intensity = p160:getValue(p161 .. "#intensity", 1)
	p162.hideInactive = p160:getValue(p161 .. "#hideInactive", false)
	if p162.hideInactive then
		setVisibility(p162.node, false)
	end
	p162.hideInactiveChildren = p160:getValue(p161 .. "#hideInactiveChildren", false)
	if p162.hideInactiveChildren then
		for v172 = 1, getNumOfChildren(p162.node) do
			setVisibility(getChildAt(p162.node, v172 - 1), false)
		end
	end
	p162.useLightControlShaderParameter = getHasShaderParameter(v166, "lightControl")
	if p162.useLightControlShaderParameter then
		setShaderParameter(p162.node, "lightControl", p162.idleValue, nil, nil, nil, false)
	else
		local v173 = p162.idleValue
		setShaderParameter(p162.node, "lightIds0", v173, v173, v173, v173, false)
		setShaderParameter(p162.node, "lightIds1", v173, v173, v173, v173, false)
		setShaderParameter(p162.node, "lightIds2", v173, v173, v173, v173, false)
		setShaderParameter(p162.node, "lightIds3", v173, v173, v173, v173, false)
	end
	return true
end, function(_, p174, p175, _, _, p176)
	if type(p175) == "number" then
		p175 = p175 > 0.5
	end
	local v177 = 1
	local v178 = nil
	if p174.hideInactive then
		if not p176 then
			setVisibility(p174.node, false)
			return
		end
		setVisibility(p174.node, true)
	end
	if p174.hideInactiveChildren then
		for v179 = 1, getNumOfChildren(p174.node) do
			setVisibility(getChildAt(p174.node, v179 - 1), p176)
		end
	end
	if p175 ~= nil then
		if p174.inverted then
			p175 = not p175
		end
		local v180 = p174.inactiveIntensity
		v178 = p174.inactiveColor
		for v181 = 1, #p174.inactiveGroups do
			if not p174.inactiveGroups[v181].isActive then
				v180 = p174.disabledIntensity
				v178 = p174.disabledColor
				break
			end
		end
		v177 = p175 and p174.intensity or (v180 or p174.idleValue)
		if p175 then
			v178 = p174.emitColor or v178
		end
		if not p176 then
			v177 = p174.disabledIntensity or p174.idleValue
			v178 = p174.disabledColor
		end
		if p174.toggleVisibility then
			setVisibility(p174.node, p175)
		end
	end
	if v178 ~= nil then
		setShaderParameter(p174.node, "emitColor", v178[1], v178[2], v178[3], 1, false)
	end
	if p174.useLightControlShaderParameter then
		setShaderParameter(p174.node, "lightControl", v177, nil, nil, nil, false)
	else
		setShaderParameter(p174.node, "lightIds0", v177, v177, v177, v177, false)
		setShaderParameter(p174.node, "lightIds1", v177, v177, v177, v177, false)
		setShaderParameter(p174.node, "lightIds2", v177, v177, v177, v177, false)
		setShaderParameter(p174.node, "lightIds3", v177, v177, v177, v177, false)
	end
end)
Dashboard.registerDisplayType(Dashboard.TYPES.NUMBER, false, function(p182, p183)
	p182:register(XMLValueType.NODE_INDEX, p183 .. ".dashboard(?)#numbers", "(NUMBER) Numbers node")
	p182:register(XMLValueType.STRING, p183 .. ".dashboard(?)#numberColor", "(NUMBER) Numbers color (DashboardColor OR BrandColor OR r g b a)")
	p182:register(XMLValueType.INT, p183 .. ".dashboard(?)#precision", "(NUMBER) Precision", 1)
	p182:register(XMLValueType.STRING, p183 .. ".dashboard(?)#font", "(NUMBER) Name of font to apply to mesh", "DIGIT")
	p182:register(XMLValueType.BOOL, p183 .. ".dashboard(?)#hasNormalMap", "(NUMBER) Normal map will be applied to number decals", false)
	p182:register(XMLValueType.FLOAT, p183 .. ".dashboard(?)#emissiveScale", "(NUMBER) Scale of emissive map", 0.2)
end, function(p184, p185, p186, p187, p188, p189, p190)
	p187.numbers = p185:getValue(p186 .. "#numbers", nil, p188, p189)
	if p190 ~= nil and not I3DUtil.getIsLinkedToNode(p190, p187.numbers) then
		Logging.xmlWarning(p185, "Numbers dashboard node \'%s\' is not a child of the parent node \'%s\' in \'%s\'", getName(p187.numbers), getName(p190), p186)
		return false
	end
	p187.numberColor = Dashboard.getDashboardColor(p185, p185:getValue(p186 .. "#numberColor"), p184.customEnvironment)
	if p187.numberColor == nil then
		p187.numberColor = {
			0.9,
			0.9,
			0.9,
			1
		}
	end
	if p187.numbers == nil then
		Logging.xmlWarning(p185, "Missing numbers node for dashboard \'%s\'", p186)
		return false
	end
	p187.precision = p185:getValue(p186 .. "#precision", 1)
	p187.numChildren = getNumOfChildren(p187.numbers)
	p187.fontMaterialName = p185:getValue(p186 .. "#font", "DIGIT")
	p187.hasNormalMap = p185:getValue(p186 .. "#hasNormalMap", false)
	p187.emissiveScale = p185:getValue(p186 .. "#emissiveScale", 0.2)
	XMLUtil.checkDeprecatedXMLElements(p185, p186 .. "#hiddenAlpha")
	p187.fontMaterial = g_materialManager:getFontMaterial(p187.fontMaterialName, p184.customEnvironment)
	if p187.fontMaterial == nil then
		Logging.xmlWarning(p185, "Unknown font \'%s\' in \'%s\'", p187.fontMaterialName, p186)
		return false
	end
	p187.numberNodes = {}
	if p187.numChildren - p187.precision <= 0 then
		Logging.xmlWarning(p185, "Not enough number meshes for vehicle hud \'%s\'", p186)
		return false
	end
	for v191 = 1, p187.numChildren do
		local v192 = getChildAt(p187.numbers, v191 - 1)
		if v192 ~= nil then
			p187.fontMaterial:assignFontMaterialToNode(v192, p187.hasNormalMap)
			if p187.numberColor ~= nil then
				p187.fontMaterial:setFontCharacterColor(v192, p187.numberColor[1], p187.numberColor[2], p187.numberColor[3], 1, p187.emissiveScale)
			end
			setVisibility(v192, false)
			local v193 = p187.numberNodes
			table.insert(v193, v192)
		end
	end
	p187.maxValue = 10 ^ p187.numChildren - 1 / 10 ^ p187.precision
	return true
end, function(_, p194, p195, _, _, p196)
	if type(p195) == "number" then
		local v197 = string.format
		local v198 = "%." .. p194.precision .. "f"
		local v199 = tonumber(v197(v198, p195)) * 10 ^ p194.precision
		local v200 = math.floor(v199)
		for v201 = 1, #p194.numberNodes do
			local v202 = p194.numberNodes[v201]
			if v200 > 0 then
				local v203 = v200 / 10
				local v204 = v200 - math.floor(v203) * 10
				v200 = (v200 - v204) / 10
				p194.fontMaterial:setFontCharacter(v202, ("%d"):format(v204))
				setVisibility(v202, true)
			else
				p194.fontMaterial:setFontCharacter(v202, "0")
				if not p196 or v201 - 1 > p194.precision then
					setVisibility(v202, false)
				end
			end
		end
	elseif type(p195) == "string" then
		local v205 = p195:len()
		for v206 = 1, #p194.numberNodes do
			local v207 = p194.numberNodes[v206]
			if v206 <= v205 then
				local v208 = v205 - (v206 - 1)
				p194.fontMaterial:setFontCharacter(v207, p195:sub(v208, v208))
			end
			setVisibility(v207, p196)
		end
	end
end)
Dashboard.registerDisplayType(Dashboard.TYPES.ANIMATION, true, function(p209, p210)
	p209:register(XMLValueType.STRING, p210 .. ".dashboard(?)#animName", "(ANIMATION) Animation name")
	p209:register(XMLValueType.FLOAT, p210 .. ".dashboard(?)#minValueAnim", "(ANIMATION) Min. reference value for animation")
	p209:register(XMLValueType.FLOAT, p210 .. ".dashboard(?)#maxValueAnim", "(ANIMATION) Max. reference value for animation")
end, function(_, p211, p212, p213, _, _)
	p213.animName = p211:getValue(p212 .. "#animName")
	if p213.animName == nil then
		Logging.xmlWarning(p211, "Missing animation for dashboard \'%s\'", p212)
		return false
	end
	p213.minValueAnim = p211:getValue(p212 .. "#minValueAnim")
	p213.maxValueAnim = p211:getValue(p212 .. "#maxValueAnim")
	return true
end, function(p214, p215, p216, p217, p218, _)
	if p215.animName ~= nil then
		if p214:getAnimationExists(p215.animName) then
			local v219 = type(p216) == "boolean" and (p216 and 1 or 0) or p216
			local v220
			if p215.minValueAnim == nil or p215.maxValueAnim == nil then
				local v221 = p217 or 0
				v220 = MathUtil.round((v219 - v221) / ((p218 or 1) - v221), 3)
			else
				local v222 = p215.minValueAnim
				local v223 = p215.maxValueAnim
				local v224 = math.clamp(v219, v222, v223)
				v220 = MathUtil.round((v224 - p215.minValueAnim) / (p215.maxValueAnim - p215.minValueAnim), 3)
			end
			p214:setAnimationTime(p215.animName, v220, true)
			return
		end
		Logging.xmlWarning(p214.xmlFile, "Unknown animation name \'%s\' for dashboard!", p215.animName)
		p215.animName = nil
	end
end)
Dashboard.registerDisplayType(Dashboard.TYPES.ROT, true, function(p225, p226)
	p225:register(XMLValueType.FLOAT, p226 .. ".dashboard(?)#rotAxis", "(ROT) Rotation axis")
	p225:register(XMLValueType.STRING, p226 .. ".dashboard(?)#minRot", "(ROT) Min. rotation (Rotation value if rotAxis is given | Rotation Vector of rotAxis is not given)")
	p225:register(XMLValueType.STRING, p226 .. ".dashboard(?)#maxRot", "(ROT) Max. rotation (Rotation value if rotAxis is given | Rotation Vector of rotAxis is not given)")
	p225:register(XMLValueType.FLOAT, p226 .. ".dashboard(?)#minValueRot", "(ROT) Min. reference value for rotation")
	p225:register(XMLValueType.FLOAT, p226 .. ".dashboard(?)#maxValueRot", "(ROT) Max. reference value for rotation")
end, function(_, p227, p228, p229, p230, p231, p232)
	p229.node = p227:getValue(p228 .. "#node", nil, p230, p231)
	if p229.node == nil then
		Logging.xmlWarning(p227, "Missing \'node\' for dashboard \'%s\'", p228)
		return false
	end
	if p232 ~= nil and not I3DUtil.getIsLinkedToNode(p232, p229.node) then
		Logging.xmlWarning(p227, "Rotation dashboard node \'%s\' is not a child of the parent node \'%s\' in \'%s\'", getName(p229.node), getName(p232), p228)
		return false
	end
	p229.rotAxis = p227:getValue(p228 .. "#rotAxis")
	local v233 = p227:getValue(p228 .. "#minRot")
	if v233 == nil then
		Logging.xmlWarning(p227, "Missing \'minRot\' attribute for dashboard \'%s\'", p228)
		return false
	end
	if p229.rotAxis == nil then
		p229.minRot = v233:getRadians(3)
	else
		local v234 = tonumber(v233)
		p229.minRot = math.rad(v234)
	end
	local v235 = p227:getValue(p228 .. "#maxRot")
	if v235 == nil then
		Logging.xmlWarning(p227, "Missing \'maxRot\' attribute for dashboard \'%s\'", p228)
		return false
	end
	if p229.rotAxis == nil then
		p229.maxRot = v235:getRadians(3)
	else
		local v236 = tonumber(v235)
		p229.maxRot = math.rad(v236)
	end
	p229.minValueRot = p227:getValue(p228 .. "#minValueRot")
	p229.maxValueRot = p227:getValue(p228 .. "#maxValueRot")
	return true
end, function(p237, p238, p239, p240, p241, _)
	local v242
	if type(p239) == "boolean" then
		v242 = p239 and 1 or 0
	elseif p238.minValueRot == nil or p238.maxValueRot == nil then
		local v243 = p240 or 0
		v242 = (p239 - v243) / ((p241 or 1) - v243)
	else
		local v244 = p238.minValueRot
		local v245 = p238.maxValueRot
		local v246 = math.clamp(p239, v244, v245)
		v242 = MathUtil.round((v246 - p238.minValueRot) / (p238.maxValueRot - p238.minValueRot), 3)
	end
	if p238.rotAxis == nil then
		local v247, v248, v249 = MathUtil.vector3ArrayLerp(p238.minRot, p238.maxRot, v242)
		setRotation(p238.node, v247, v248, v249)
		if p237.setCharacterTargetNodeStateDirty ~= nil then
			p237:setCharacterTargetNodeStateDirty(p238.node)
		end
		if p237.setMovingToolDirty ~= nil then
			p237:setMovingToolDirty(p238.node)
		end
	else
		local v250, v251, v252 = getRotation(p238.node)
		local v253 = MathUtil.lerp(p238.minRot, p238.maxRot, v242)
		if p238.rotAxis == 1 then
			v250 = v253
			v253 = v252
		elseif p238.rotAxis == 2 then
			v251 = v253
			v253 = v252
		end
		setRotation(p238.node, v250, v251, v253)
		if p237.setCharacterTargetNodeStateDirty ~= nil then
			p237:setCharacterTargetNodeStateDirty(p238.node)
		end
		if p237.setMovingToolDirty ~= nil then
			p237:setMovingToolDirty(p238.node)
			return
		end
	end
end)
Dashboard.registerDisplayType(Dashboard.TYPES.TRANS, true, function(p254, p255)
	p254:register(XMLValueType.VECTOR_TRANS, p255 .. ".dashboard(?)#minTrans", "(TRANS) Min. translation")
	p254:register(XMLValueType.VECTOR_TRANS, p255 .. ".dashboard(?)#maxTrans", "(TRANS) Max. translation")
	p254:register(XMLValueType.FLOAT, p255 .. ".dashboard(?)#minValueTrans", "(TRANS) Min. reference value for translation")
	p254:register(XMLValueType.FLOAT, p255 .. ".dashboard(?)#maxValueTrans", "(TRANS) Max. reference value for translation")
end, function(_, p256, p257, p258, p259, p260, p261)
	p258.node = p256:getValue(p257 .. "#node", nil, p259, p260)
	if p258.node == nil then
		Logging.xmlWarning(p256, "Missing \'node\' for dashboard \'%s\'", p257)
		return false
	end
	if p261 ~= nil and not I3DUtil.getIsLinkedToNode(p261, p258.node) then
		Logging.xmlWarning(p256, "Translation dashboard node \'%s\' is not a child of the parent node \'%s\' in \'%s\'", getName(p258.node), getName(p261), p257)
		return false
	end
	p258.minTrans = p256:getValue(p257 .. "#minTrans", nil, true)
	p258.maxTrans = p256:getValue(p257 .. "#maxTrans", nil, true)
	if p258.minTrans == nil or p258.maxTrans ~= nil then
		if p258.maxTrans ~= nil and p258.minTrans == nil then
			Logging.xmlWarning(p256, "Missing \'minTrans\' attribute for dashboard \'%s\'", p257)
		end
	else
		Logging.xmlWarning(p256, "Missing \'maxTrans\' attribute for dashboard \'%s\'", p257)
	end
	p258.minValueTrans = p256:getValue(p257 .. "#minValueTrans")
	p258.maxValueTrans = p256:getValue(p257 .. "#maxValueTrans")
	return true
end, function(p262, p263, p264, p265, p266, _)
	local v267
	if type(p264) == "boolean" then
		v267 = p264 and 1 or 0
	elseif p263.minValueTrans == nil or p263.maxValueTrans == nil then
		local v268 = p265 or 0
		v267 = (p264 - v268) / ((p266 or 1) - v268)
	else
		local v269 = p263.minValueTrans
		local v270 = p263.maxValueTrans
		local v271 = math.clamp(p264, v269, v270)
		v267 = MathUtil.round((v271 - p263.minValueTrans) / (p263.maxValueTrans - p263.minValueTrans), 3)
	end
	local v272, v273, v274 = MathUtil.vector3ArrayLerp(p263.minTrans, p263.maxTrans, v267)
	setTranslation(p263.node, v272, v273, v274)
	if p262.setCharacterTargetNodeStateDirty ~= nil then
		p262:setCharacterTargetNodeStateDirty(p263.node)
	end
	if p262.setMovingToolDirty ~= nil then
		p262:setMovingToolDirty(p263.node)
	end
end)
Dashboard.registerDisplayType(Dashboard.TYPES.VISIBILITY, false, function(_, _) end, function(_, p275, p276, p277, p278, p279, p280)
	p277.node = p275:getValue(p276 .. "#node", nil, p278, p279)
	if p277.node == nil then
		Logging.xmlWarning(p275, "Missing \'node\' for dashboard \'%s\'", p276)
		return false
	elseif p280 == nil or I3DUtil.getIsLinkedToNode(p280, p277.node) then
		setVisibility(p277.node, false)
		return true
	else
		Logging.xmlWarning(p275, "Visibility dashboard node \'%s\' is not a child of the parent node \'%s\' in \'%s\'", getName(p277.node), getName(p280), p276)
		return false
	end
end, function(_, p281, p282, _, _, p283)
	if type(p282) == "number" then
		p282 = p282 > 0.5
	end
	if p282 ~= nil then
		p283 = p282 and p283
	end
	setVisibility(p281.node, p283)
end)
Dashboard.registerDisplayType(Dashboard.TYPES.TEXT, false, function(p284, p285)
	p284:register(XMLValueType.STRING, p285 .. ".dashboard(?)#textColor", "(TEXT) Font color (DashboardColor OR BrandColor OR r g b a)")
	p284:register(XMLValueType.STRING, p285 .. ".dashboard(?)#hiddenColor", "(TEXT) Color of hidden character (if defined a \'0\' in this color is display instead of nothing)")
	p284:register(XMLValueType.STRING, p285 .. ".dashboard(?)#textAlignment", "(TEXT) Alignment of text (LEFT | RIGHT | CENTER)", "RIGHT")
	p284:register(XMLValueType.FLOAT, p285 .. ".dashboard(?)#textSize", "(TEXT) Size of font in meter", 0.03)
	p284:register(XMLValueType.FLOAT, p285 .. ".dashboard(?)#fontThickness", "(TEXT) Thickness factor for font characters", 1)
	p284:register(XMLValueType.FLOAT, p285 .. ".dashboard(?)#textScaleX", "(TEXT) Global X scale of text", 1)
	p284:register(XMLValueType.FLOAT, p285 .. ".dashboard(?)#textScaleY", "(TEXT) Global Y scale of text", 1)
	p284:register(XMLValueType.STRING, p285 .. ".dashboard(?)#textMask", "(TEXT) Font Mask", "00.0")
end, function(p286, p287, p288, p289, p290, p291, p292)
	p289.node = p287:getValue(p288 .. "#node", nil, p290, p291)
	if p289.node == nil then
		Logging.xmlWarning(p287, "Missing \'node\' for text dashboard \'%s\'", p288)
		return false
	end
	if p292 ~= nil and not I3DUtil.getIsLinkedToNode(p292, p289.node) then
		Logging.xmlWarning(p287, "Visibility dashboard node \'%s\' is not a child of the parent node \'%s\' in \'%s\'", getName(p289.node), getName(p292), p288)
		return false
	end
	p289.textColor = Dashboard.getDashboardColor(p287, p287:getValue(p288 .. "#textColor"), p286.customEnvironment)
	if p289.textColor == nil then
		p289.textColor = {
			0.9,
			0.9,
			0.9,
			1
		}
	end
	p289.hiddenColor = Dashboard.getDashboardColor(p287, p287:getValue(p288 .. "#hiddenColor"), p286.customEnvironment)
	local v293 = p287:getValue(p288 .. "#textAlignment", "RIGHT")
	p289.textAlignment = RenderText["ALIGN_" .. v293:upper()] or RenderText.ALIGN_RIGHT
	p289.textSize = p287:getValue(p288 .. "#textSize", 0.03)
	p289.textScaleX = p287:getValue(p288 .. "#textScaleX", 1)
	p289.textScaleY = p287:getValue(p288 .. "#textScaleY", 1)
	p289.textMask = p287:getValue(p288 .. "#textMask", "00.0")
	local v294, v295 = Utils.maskToFormat(p289.textMask)
	p289.textFormatStr = v294
	p289.textFormatPrecision = v295
	p289.fontName = p287:getValue(p288 .. "#font", "DIGIT"):upper()
	p289.fontThickness = p287:getValue(p288 .. "#fontThickness", 1)
	p289.emissiveScale = p287:getValue(p288 .. "#emissiveScale", 0.2)
	local v296 = g_materialManager:getFontMaterial(p289.fontName, p286.customEnvironment)
	if v296 == nil then
		Logging.xmlWarning(p287, "Unknown font \'%s\' in \'%s\'", p289.fontName, p288)
		return false
	end
	p289.characterLine = CharacterLine.new(p289.node, v296, p289.textMask:len())
	p289.characterLine:setSizeAndScale(p289.textSize, p289.textScaleX, p289.textScaleY)
	p289.characterLine:setTextAlignment(p289.textAlignment)
	p289.characterLine:setFontThickness(p289.fontThickness)
	p289.characterLine:setUseNormalMap(false)
	p289.characterLine:setColor(p289.textColor, p289.hiddenColor, p289.emissiveScale)
	p289.characterLine:setDecalLayer(2)
	if p289.characterLine == nil then
		Logging.xmlWarning(p287, "Failed to create text in \'%s\'", p288)
		return false
	end
	p289.characterLine:setText(p289.textMask)
	setVisibility(p289.characterLine.rootNode, false)
	return true
end, function(_, p297, p298, _, _, p299)
	if type(p298) == "number" then
		local v300, v301 = math.modf(p298)
		local v302 = string.format
		local v303 = p297.textFormatStr
		local v304 = (v301 + 1e-6) * 10 ^ p297.textFormatPrecision
		local v305 = math.floor(v304)
		local v306 = v302(v303, v300, (math.abs(v305)))
		p297.characterLine:setText(v306)
	elseif type(p298) == "string" then
		p297.characterLine:setText(p298)
	end
	setVisibility(p297.characterLine.rootNode, p299)
end)
Dashboard.registerDisplayType(Dashboard.TYPES.SLIDER, false, function(p307, p308)
	p307:register(XMLValueType.FLOAT, p308 .. ".dashboard(?)#minValueSlider", "(SLIDER) Min. reference value for slider")
	p307:register(XMLValueType.FLOAT, p308 .. ".dashboard(?)#maxValueSlider", "(SLIDER) Max. reference value for slider")
	p307:register(XMLValueType.FLOAT, p308 .. ".dashboard(?)#intensity", "Intensity", 1)
end, function(_, p309, p310, p311, p312, p313, p314)
	p311.node = p309:getValue(p310 .. "#node", nil, p312, p313)
	if p311.node == nil then
		Logging.xmlWarning(p309, "Missing \'node\' for dashboard \'%s\'", p310)
		return false
	end
	if p314 ~= nil and not I3DUtil.getIsLinkedToNode(p314, p311.node) then
		Logging.xmlWarning(p309, "Slider dashboard node \'%s\' is not a child of the parent node \'%s\' in \'%s\'", getName(p311.node), getName(p314), p310)
		return false
	end
	if not getHasClassId(p311.node, ClassIds.SHAPE) then
		Logging.xmlWarning(p309, "Slider Dashboard node is not a shape! \'%s\' in \'%s\'", getName(p311.node), p310)
		return false
	end
	if not getHasShaderParameter(p311.node, "sliderPos") then
		Logging.xmlWarning(p309, "Node \'%s\' does not have a \'sliderPos\' shader parameter for dashboard \'%s\'", getName(p311.node), p310)
		return false
	end
	setShaderParameter(p311.node, "sliderPos", 0, 0, 0, 0, false)
	p311.minValueSlider = p309:getValue(p310 .. "#minValueSlider")
	p311.maxValueSlider = p309:getValue(p310 .. "#maxValueSlider")
	p311.intensity = p309:getValue(p310 .. "#intensity", 1)
	setShaderParameter(p311.node, "lightControl", p311.intensity, 0, 0, 0, false)
	return true
end, function(_, p315, p316, p317, p318, _)
	if p315.node ~= nil then
		local v319 = type(p316) == "boolean" and (p316 and 1 or 0) or p316
		local v320
		if p315.minValueSlider == nil or p315.maxValueSlider == nil then
			local v321 = p317 or 0
			v320 = MathUtil.round((v319 - v321) / ((p318 or 1) - v321), 3)
		else
			local v322 = p315.minValueSlider
			local v323 = p315.maxValueSlider
			local v324 = math.clamp(v319, v322, v323)
			v320 = MathUtil.round((v324 - p315.minValueSlider) / (p315.maxValueSlider - p315.minValueSlider), 3)
		end
		setShaderParameter(p315.node, "sliderPos", v320, 0, 0, 0, false)
	end
end)
Dashboard.registerDisplayType(Dashboard.TYPES.MULTI_STATE, false, function(p325, p326)
	p325:register(XMLValueType.VECTOR_N, p326 .. ".dashboard(?).state(?)#value", "(MULTI_STATE) One or multiple values separated by space to activate the state")
	p325:register(XMLValueType.VECTOR_ROT, p326 .. ".dashboard(?).state(?)#rotation", "(MULTI_STATE) Rotation while state is active")
	p325:register(XMLValueType.VECTOR_TRANS, p326 .. ".dashboard(?).state(?)#translation", "(MULTI_STATE) Translation while state is active")
	p325:register(XMLValueType.VECTOR_SCALE, p326 .. ".dashboard(?).state(?)#scale", "(MULTI_STATE) Scale while state is active")
	p325:register(XMLValueType.FLOAT, p326 .. ".dashboard(?).state(?)#intensity", "(MULTI_STATE) Intensity if the node is a emitter")
	p325:register(XMLValueType.STRING, p326 .. ".dashboard(?).state(?)#emitColor", "(MULTI_STATE) Emit color if the node is a emitter")
	p325:register(XMLValueType.BOOL, p326 .. ".dashboard(?).state(?)#visibility", "(MULTI_STATE) Visibility while state is active")
end, function(p_u_327, p_u_328, p329, p_u_330, p331, p332, p333)
	p_u_330.node = p_u_328:getValue(p329 .. "#node", nil, p331, p332)
	if p_u_330.node == nil then
		Logging.xmlWarning(p_u_328, "Missing \'node\' for dashboard \'%s\'", p329)
		return false
	end
	if p333 ~= nil and not I3DUtil.getIsLinkedToNode(p333, p_u_330.node) then
		Logging.xmlWarning(p_u_328, "Multi state dashboard node \'%s\' is not a child of the parent node \'%s\' in \'%s\'", getName(p_u_330.node), getName(p333), p329)
		return false
	end
	p_u_330.hasVisibility = false
	p_u_330.hasEmitColor = false
	p_u_330.hasIntensity = false
	p_u_330.states = {}
	p_u_328:iterate(p329 .. ".state", function(_, p334)
		-- upvalues: (copy) p_u_328, (copy) p_u_330, (copy) p_u_327
		local v335 = {
			["values"] = p_u_328:getValue(p334 .. "#value", nil, true)
		}
		if v335.values ~= nil and #v335.values > 0 then
			v335.rotation = p_u_328:getValue(p334 .. "#rotation", nil, true)
			v335.translation = p_u_328:getValue(p334 .. "#translation", nil, true)
			v335.scale = p_u_328:getValue(p334 .. "#scale", nil, true)
			v335.visibility = p_u_328:getValue(p334 .. "#visibility")
			p_u_330.hasVisibility = p_u_330.hasVisibility or v335.visibility ~= nil
			v335.emitColor = Dashboard.getDashboardColor(p_u_328, p_u_328:getValue(p334 .. "#emitColor"), p_u_327.customEnvironment)
			p_u_330.hasEmitColor = p_u_330.hasEmitColor or v335.emitColor ~= nil
			v335.intensity = p_u_328:getValue(p334 .. "#intensity")
			p_u_330.hasIntensity = p_u_330.hasIntensity or v335.intensity ~= nil
			local v336 = p_u_330.states
			table.insert(v336, v335)
		end
	end)
	if (p_u_330.hasEmitColor or p_u_330.hasIntensity) and not getHasClassId(p_u_330.node, ClassIds.SHAPE) then
		Logging.xmlWarning(p_u_328, "Intensity or emitColor defined for non shape node in \'%s\'", p329)
		return false
	end
	if #p_u_330.states == 0 then
		Logging.xmlWarning(p_u_328, "No states defined for dashboard \'%s\'", p329)
		return false
	end
	p_u_330.multiStateInterpolationTime = 1 / p_u_330.interpolationSpeed
	p_u_330.interpolationSpeed = 99999
	p_u_330.lastState = nil
	function p_u_330.get()
		-- upvalues: (copy) p_u_330
		local v337, v338, v339 = getTranslation(p_u_330.node)
		local v340, v341, v342 = getRotation(p_u_330.node)
		local v343, v344, v345 = getScale(p_u_330.node)
		local v346 = getVisibility(p_u_330.node) and 1 or 0
		local v347, v348, v349
		if p_u_330.hasEmitColor and getHasShaderParameter(p_u_330.node, "emitColor") then
			v347, v348, v349 = getShaderParameter(p_u_330.node, "emitColor")
		else
			v347 = 1
			v348 = 1
			v349 = 1
		end
		return v337, v338, v339, v340, v341, v342, v343, v344, v345, v346, v347, v348, v349, not (p_u_330.hasIntensity and getHasShaderParameter(p_u_330.node, "lightControl")) and 0 or getShaderParameter(p_u_330.node, "lightControl")
	end
	function p_u_330.set(p350, p351, p352, p353, p354, p355, p356, p357, p358, p359, p360, p361, p362, p363)
		-- upvalues: (copy) p_u_330, (copy) p_u_327
		setTranslation(p_u_330.node, p350, p351, p352)
		setRotation(p_u_330.node, p353, p354, p355)
		setScale(p_u_330.node, p356, p357, p358)
		if p_u_330.hasVisibility then
			setVisibility(p_u_330.node, p359 >= 0.5)
		end
		if p_u_330.hasEmitColor and getHasShaderParameter(p_u_330.node, "emitColor") then
			setShaderParameter(p_u_330.node, "emitColor", p360, p361, p362, 1, false)
		end
		if p_u_330.hasIntensity and getHasShaderParameter(p_u_330.node, "lightControl") then
			setShaderParameter(p_u_330.node, "lightControl", p363, nil, nil, nil, false)
		end
		if p_u_327.setCharacterTargetNodeStateDirty ~= nil then
			p_u_327:setCharacterTargetNodeStateDirty(p_u_330.node)
		end
		if p_u_327.setMovingToolDirty ~= nil then
			p_u_327:setMovingToolDirty(p_u_330.node)
		end
	end
	p_u_330.defaultRotation = { getRotation(p_u_330.node) }
	p_u_330.defaultTranslation = { getTranslation(p_u_330.node) }
	p_u_330.defaultScale = { getScale(p_u_330.node) }
	p_u_330.defaultVisibility = getVisibility(p_u_330.node)
	p_u_330.defaultEmitColor = { 1, 1, 1 }
	p_u_330.defaultIntensity = 0
	return true
end, function(p364, p365, p366, _, _, p367)
	if p365.node ~= nil then
		local v368 = nil
		if p367 then
			for v369 = 1, #p365.states do
				local v370 = p365.states[v369]
				if type(p366) == "table" then
					for v371 = 1, #v370.values do
						if p366[v370.values[v371]] == true then
							v368 = v370
						end
					end
				elseif type(p366) == "number" then
					for v372 = 1, #v370.values do
						if v370.values[v372] == MathUtil.round(p366) then
							v368 = v370
						end
					end
				end
			end
		end
		if v368 ~= p365.lastState then
			local v373 = p365.defaultRotation
			local v374 = p365.defaultTranslation
			local v375 = p365.defaultScale
			local v376 = p365.defaultVisibility
			local v377 = p365.defaultEmitColor
			local v378 = p365.defaultIntensity
			if v368 ~= nil then
				v373 = v368.rotation or v373
				v374 = v368.translation or v374
				v375 = v368.scale or v375
				if v368.visibility ~= nil then
					v376 = v368.visibility
				end
				if v368.emitColor ~= nil then
					v377 = v368.emitColor
				end
				if v368.intensity ~= nil then
					v378 = v368.intensity
				end
			end
			if p365.doInterpolation then
				if p365.interpolator ~= nil then
					p365.interpolator:update(9999999)
				end
				local v379 = ValueInterpolator.new(p365.node .. "_dashboard", p365.get, p365.set, {
					v374[1],
					v374[2],
					v374[3],
					v373[1],
					v373[2],
					v373[3],
					v375[1],
					v375[2],
					v375[3],
					v376 and 1 or 0,
					v377[1],
					v377[2],
					v377[3],
					v378
				}, p365.multiStateInterpolationTime)
				if v379 ~= nil then
					p365.interpolator = v379
					p365.interpolator:setDeleteListenerObject(p364)
					p365.interpolator:setFinishedFunc(function(p380)
						p380.interpolator = nil
					end, p365)
				end
			else
				p365.set(v374[1], v374[2], v374[3], v373[1], v373[2], v373[3], v375[1], v375[2], v375[3], v376 and 1 or 0, v377[1], v377[2], v377[3], v378)
			end
			p365.lastState = v368
		end
	end
end)
function Dashboard.registerDashboardXMLPaths(p381, p382, p383)
	p381:register(XMLValueType.STRING, p382 .. ".dashboard(?)#valueType", "Value type name", nil, nil, p383)
	p381:register(XMLValueType.STRING, p382 .. ".dashboard(?)#displayType", "Display type name", nil, nil, table.toList(Dashboard.TYPES))
	p381:register(XMLValueType.BOOL, p382 .. ".dashboard(?)#doInterpolation", "Do interpolation", false)
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?)#interpolationSpeed", "Interpolation speed", 0.005)
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?)#idleValue", "Idle value", 0)
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?)#offsetValue", "Offset the value by the given amount", 0)
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?)#minActiveValue", "Min. value to activate this dashboard")
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?)#maxActiveValue", "Max. value to activate this dashboard")
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?).valueMapping(?)#sourceValue", "Source value")
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?).valueMapping(?)#dashboardValue", "Value to be used for dashboard at this source value")
	p381:register(XMLValueType.STRING, p382 .. ".dashboard(?)#groups", "List of groups")
	p381:register(XMLValueType.NODE_INDEX, p382 .. ".dashboard(?)#node", "Node")
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?)#warningThresholdMin", "(WARNING) Threshold min.")
	p381:register(XMLValueType.FLOAT, p382 .. ".dashboard(?)#warningThresholdMax", "(WARNING) Threshold max.")
	for _, v384 in pairs(Dashboard.TYPE_DATA) do
		v384.schemaFunc(p381, p382)
	end
	p381:addDelayedRegistrationPath(p382 .. ".dashboard(?)", "Dashboard")
end
function Dashboard.addDelayedRegistrationFunc(p385, p386)
	p385:addDelayedRegistrationFunc("Dashboard", p386)
	Dashboard.compoundsXMLSchema:addDelayedRegistrationFunc("Dashboard", p386)
end

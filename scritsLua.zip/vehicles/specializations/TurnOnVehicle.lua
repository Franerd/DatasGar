source("dataS/scripts/vehicles/specializations/events/SetTurnedOnEvent.lua")
TurnOnVehicle = {}
TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH = "vehicle.turnOnVehicle.turnedOnAnimation(?)"
function TurnOnVehicle.prerequisitesPresent(_)
	return true
end
function TurnOnVehicle.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("TurnOnVehicle")
	v1:register(XMLValueType.STRING, "vehicle.turnOnVehicle#toggleButton", "Input action name", "IMPLEMENT_EXTRA")
	v1:register(XMLValueType.L10N_STRING, "vehicle.turnOnVehicle#turnOffText", "Turn off text", "action_turnOffOBJECT")
	v1:register(XMLValueType.L10N_STRING, "vehicle.turnOnVehicle#turnOnText", "Turn on text", "action_turnOnOBJECT")
	v1:register(XMLValueType.BOOL, "vehicle.turnOnVehicle#isAlwaysTurnedOn", "Always turned on", false)
	v1:register(XMLValueType.BOOL, "vehicle.turnOnVehicle#turnedOnByAttacherVehicle", "Turned on by attacher vehicle", false)
	v1:register(XMLValueType.BOOL, "vehicle.turnOnVehicle#turnOffIfNotAllowed", "Turn off if not allowed", true)
	v1:register(XMLValueType.BOOL, "vehicle.turnOnVehicle#turnOffOnDeactivate", "Turn off if the vehicle is deactivated", true)
	v1:register(XMLValueType.BOOL, "vehicle.turnOnVehicle#aiRequiresTurnOn", "AI requires turned on vehicle", true)
	v1:register(XMLValueType.BOOL, "vehicle.turnOnVehicle#requiresTurnOn", "(Mobile only) Vehicle requires turn on", true)
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.turnOnVehicle.animationNodes")
	EffectManager.registerEffectXMLPaths(v1, "vehicle.turnOnVehicle.effects")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.turnOnVehicle.sounds", "start(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.turnOnVehicle.sounds", "stop(?)")
	SoundManager.registerSampleXMLPaths(v1, "vehicle.turnOnVehicle.sounds", "work(?)")
	v1:register(XMLValueType.STRING, "vehicle.turnOnVehicle.turnedAnimation#name", "Turned animation name (Animation played while activating and deactivating)")
	v1:register(XMLValueType.FLOAT, "vehicle.turnOnVehicle.turnedAnimation#turnOnSpeedScale", "Turn on speed scale", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.turnOnVehicle.turnedAnimation#turnOffSpeedScale", "Turn off speed scale", "Inversed turnOnSpeedScale")
	v1:register(XMLValueType.STRING, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#name", "Turned on animation name (Animation played while turn on)")
	v1:register(XMLValueType.FLOAT, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#turnOnFadeTime", "Turn on fade time", 1)
	v1:register(XMLValueType.FLOAT, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#turnOffFadeTime", "Turn off fade time", 1)
	v1:register(XMLValueType.FLOAT, TurnOnVehicle.TURNED_ON_ANIMATION_XML_PATH .. "#speedScale", "Speed scale", 1)
	v1:register(XMLValueType.INT, "vehicle.turnOnVehicle.activatableFillUnits.activatableFillUnit(?)#index", "Activateable fill unit index")
	v1:register(XMLValueType.BOOL, Attachable.INPUT_ATTACHERJOINT_XML_KEY .. "#canBeTurnedOn", "Attacher joint can turn on implement", true)
	v1:register(XMLValueType.BOOL, Attachable.INPUT_ATTACHERJOINT_CONFIG_XML_KEY .. "#canBeTurnedOn", "Attacher joint can turn on implement", true)
	v1:register(XMLValueType.BOOL, WorkArea.WORK_AREA_XML_KEY .. "#needsSetIsTurnedOn", "Work area needs turned on vehicle to work", true)
	v1:register(XMLValueType.BOOL, WorkArea.WORK_AREA_XML_CONFIG_KEY .. "#needsSetIsTurnedOn", "Work area needs turned on vehicle to work", true)
	v1:register(XMLValueType.BOOL, FillUnit.ALARM_TRIGGER_XML_KEY .. "#needsTurnOn", "Needs turned on vehicle", false)
	v1:register(XMLValueType.BOOL, FillUnit.ALARM_TRIGGER_XML_KEY .. "#turnOffInTrigger", "Turn vehicle off when triggered", false)
	v1:register(XMLValueType.BOOL, Shovel.SHOVEL_NODE_XML_KEY .. "#needsActivation", "Needs activation", false)
	v1:register(XMLValueType.BOOL, Dischargeable.DISCHARGE_NODE_XML_PATH .. "#needsSetIsTurnedOn", "Vehicle needs to be turned on to activate discharge node", false)
	v1:register(XMLValueType.BOOL, Dischargeable.DISCHARGE_NODE_XML_PATH .. "#turnOnActivateNode", "Discharge node is set active when vehicle is turned on", false)
	v1:register(XMLValueType.BOOL, Dischargeable.DISCHARGE_NODE_CONFIG_XML_PATH .. "#needsSetIsTurnedOn", "Vehicle needs to be turned on to activate discharge node", false)
	v1:register(XMLValueType.BOOL, Dischargeable.DISCHARGE_NODE_CONFIG_XML_PATH .. "#turnOnActivateNode", "Discharge node is set active when vehicle is turned on", false)
	v1:register(XMLValueType.FLOAT, BunkerSiloCompacter.XML_PATH .. "#turnedOnCompactingScale", "Compacting scale which is used while vehicle is turned on", "normal scale")
	v1:register(XMLValueType.TIME, "vehicle.turnOnVehicle.turnedOnSpeed#fadeInTime", "(Turned on speed simulation - used as sound modifier and for rpm dashboards) Time to reach max. turned on speed", 1)
	v1:register(XMLValueType.TIME, "vehicle.turnOnVehicle.turnedOnSpeed#fadeOutTime", "(Turned on speed simulation - used as sound modifier and for rpm dashboards) Time to reach the turned off speed again", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.turnOnVehicle.turnedOnSpeed#variance", "Variation value at max. speed", 0.02)
	v1:register(XMLValueType.FLOAT, "vehicle.turnOnVehicle.turnedOnSpeed#varianceSpeed", "Speed factor of variance change", 1)
	Dashboard.registerDashboardXMLPaths(v1, "vehicle.turnOnVehicle.dashboards", { "turnedOn", "rpm" })
	v1:register(XMLValueType.FLOAT, "vehicle.turnOnVehicle.dashboards.dashboard(?)#minRpm", "Rpm value if vehicle is turned off", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.turnOnVehicle.dashboards.dashboard(?)#maxRpm", "Rpm value if vehicle is turned on", 1000)
	v1:setXMLSpecializationType()
end
function TurnOnVehicle.registerEvents(p2)
	SpecializationUtil.registerEvent(p2, "onTurnedOn")
	SpecializationUtil.registerEvent(p2, "onTurnedOff")
end
function TurnOnVehicle.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "setIsTurnedOn", TurnOnVehicle.setIsTurnedOn)
	SpecializationUtil.registerFunction(p3, "getIsTurnedOn", TurnOnVehicle.getIsTurnedOn)
	SpecializationUtil.registerFunction(p3, "getCanBeTurnedOn", TurnOnVehicle.getCanBeTurnedOn)
	SpecializationUtil.registerFunction(p3, "getCanBeTurnedOnAll", TurnOnVehicle.getCanBeTurnedOnAll)
	SpecializationUtil.registerFunction(p3, "getCanToggleTurnedOn", TurnOnVehicle.getCanToggleTurnedOn)
	SpecializationUtil.registerFunction(p3, "getTurnedOnNotAllowedWarning", TurnOnVehicle.getTurnedOnNotAllowedWarning)
	SpecializationUtil.registerFunction(p3, "getAIRequiresTurnOn", TurnOnVehicle.getAIRequiresTurnOn)
	SpecializationUtil.registerFunction(p3, "getRequiresTurnOn", TurnOnVehicle.getRequiresTurnOn)
	SpecializationUtil.registerFunction(p3, "getAIRequiresTurnOffOnHeadland", TurnOnVehicle.getAIRequiresTurnOffOnHeadland)
	SpecializationUtil.registerFunction(p3, "loadTurnedOnAnimationFromXML", TurnOnVehicle.loadTurnedOnAnimationFromXML)
	SpecializationUtil.registerFunction(p3, "getIsTurnedOnAnimationActive", TurnOnVehicle.getIsTurnedOnAnimationActive)
	SpecializationUtil.registerFunction(p3, "getTurnedOnSpeedFactor", TurnOnVehicle.getTurnedOnSpeedFactor)
end
function TurnOnVehicle.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getUseTurnedOnSchema", TurnOnVehicle.getUseTurnedOnSchema)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadInputAttacherJoint", TurnOnVehicle.loadInputAttacherJoint)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadWorkAreaFromXML", TurnOnVehicle.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsWorkAreaActive", TurnOnVehicle.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanAIImplementContinueWork", TurnOnVehicle.getCanAIImplementContinueWork)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsOperating", TurnOnVehicle.getIsOperating)
	SpecializationUtil.registerOverwrittenFunction(p4, "getAlarmTriggerIsActive", TurnOnVehicle.getAlarmTriggerIsActive)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadAlarmTrigger", TurnOnVehicle.loadAlarmTrigger)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsFillUnitActive", TurnOnVehicle.getIsFillUnitActive)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadShovelNode", TurnOnVehicle.loadShovelNode)
	SpecializationUtil.registerOverwrittenFunction(p4, "getShovelNodeIsActive", TurnOnVehicle.getShovelNodeIsActive)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsSeedChangeAllowed", TurnOnVehicle.getIsSeedChangeAllowed)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanBeSelected", TurnOnVehicle.getCanBeSelected)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsPowerTakeOffActive", TurnOnVehicle.getIsPowerTakeOffActive)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadDischargeNode", TurnOnVehicle.loadDischargeNode)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsDischargeNodeActive", TurnOnVehicle.getIsDischargeNodeActive)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadBunkerSiloCompactorFromXML", TurnOnVehicle.loadBunkerSiloCompactorFromXML)
	SpecializationUtil.registerOverwrittenFunction(p4, "getBunkerSiloCompacterScale", TurnOnVehicle.getBunkerSiloCompacterScale)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsWorkModeChangeAllowed", TurnOnVehicle.getIsWorkModeChangeAllowed)
end
function TurnOnVehicle.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onRegisterDashboardValueTypes", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onDelete", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onReadStream", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onUpdate", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onRegisterActionEvents", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onRegisterExternalActionEvents", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onDeactivate", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onPostAttach", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onPreDetach", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onRootVehicleChanged", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onTurnedOn", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onTurnedOff", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onAlarmTriggerChanged", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onSetBroken", TurnOnVehicle)
	SpecializationUtil.registerEventListener(p5, "onStateChange", TurnOnVehicle)
end
function TurnOnVehicle.onLoad(p_u_6, _)
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnOnSettings#turnOffText", "vehicle.turnOnVehicle#turnOffText")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnOnSettings#turnOnText", "vehicle.turnOnVehicle#turnOnText")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnOnSettings#needsSelection")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnOnSettings#isAlwaysTurnedOn", "vehicle.turnOnVehicle#isAlwaysTurnedOn")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnOnSettings#toggleButton", "vehicle.turnOnVehicle#toggleButton")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnOnSettings#animationName", "vehicle.turnOnVehicle.turnedAnimation#name")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnOnSettings#turnOnSpeedScale", "vehicle.turnOnVehicle.turnedAnimation#turnOnSpeedScale")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnOnSettings#turnOffSpeedScale", "vehicle.turnOnVehicle.turnedAnimation#turnOffSpeedScale")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.turnedOnRotationNodes.turnedOnRotationNode#type", "vehicle.turnOnVehicle.animationNodes.animationNode", "turnOn")
	XMLUtil.checkDeprecatedXMLElements(p_u_6.xmlFile, "vehicle.foldable.foldingParts#turnOffOnFold", "vehicle.turnOnVehicle#turnOffIfNotAllowed")
	local v_u_7 = p_u_6.spec_turnOnVehicle
	local v8 = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#toggleButton")
	if v8 ~= nil then
		v_u_7.toggleTurnOnInputBinding = InputAction[v8]
	end
	v_u_7.toggleTurnOnInputBinding = Utils.getNoNil(v_u_7.toggleTurnOnInputBinding, InputAction.IMPLEMENT_EXTRA)
	v_u_7.turnOffText = string.format(p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#turnOffText", "action_turnOffOBJECT", p_u_6.customEnvironment), p_u_6.typeDesc)
	v_u_7.turnOnText = string.format(p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#turnOnText", "action_turnOnOBJECT", p_u_6.customEnvironment), p_u_6.typeDesc)
	v_u_7.isTurnedOn = false
	v_u_7.isAlwaysTurnedOn = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#isAlwaysTurnedOn", false)
	v_u_7.turnedOnByAttacherVehicle = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#turnedOnByAttacherVehicle", false)
	v_u_7.turnOffIfNotAllowed = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#turnOffIfNotAllowed", true)
	v_u_7.turnOffOnDeactivate = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#turnOffOnDeactivate", not GS_IS_MOBILE_VERSION)
	v_u_7.aiRequiresTurnOn = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#aiRequiresTurnOn", true)
	v_u_7.requiresTurnOn = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle#requiresTurnOn", true)
	if p_u_6.isClient then
		v_u_7.animationNodes = g_animationManager:loadAnimations(p_u_6.xmlFile, "vehicle.turnOnVehicle.animationNodes", p_u_6.components, p_u_6, p_u_6.i3dMappings)
		local v9 = SpecializationUtil.hasSpecialization(AnimatedVehicle, p_u_6.specializations)
		if v9 then
			local v10 = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle.turnedAnimation#name")
			if v10 ~= nil then
				v_u_7.turnOnAnimation = {}
				v_u_7.turnOnAnimation.name = v10
				v_u_7.turnOnAnimation.turnOnSpeedScale = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle.turnedAnimation#turnOnSpeedScale", 1)
				v_u_7.turnOnAnimation.turnOffSpeedScale = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle.turnedAnimation#turnOffSpeedScale", -v_u_7.turnOnAnimation.turnOnSpeedScale)
			end
		end
		v_u_7.turnedOnAnimations = {}
		if v9 then
			p_u_6.xmlFile:iterate("vehicle.turnOnVehicle.turnedOnAnimation", function(_, p11)
				-- upvalues: (copy) p_u_6, (copy) v_u_7
				local v12 = {}
				if p_u_6:loadTurnedOnAnimationFromXML(p_u_6.xmlFile, p11, v12) then
					local v13 = v_u_7.turnedOnAnimations
					table.insert(v13, v12)
				end
			end)
		end
		v_u_7.activatableFillUnits = {}
		local v14 = 0
		while true do
			local v15 = string.format("vehicle.turnOnVehicle.activatableFillUnits.activatableFillUnit(%d)", v14)
			if not p_u_6.xmlFile:hasProperty(v15) then
				break
			end
			local v16 = p_u_6.xmlFile:getValue(v15 .. "#index")
			if v16 ~= nil then
				v_u_7.activatableFillUnits[v16] = true
			end
			v14 = v14 + 1
		end
		v_u_7.effects = g_effectManager:loadEffect(p_u_6.xmlFile, "vehicle.turnOnVehicle.effects", p_u_6.components, p_u_6, p_u_6.i3dMappings)
		v_u_7.samples = {}
		v_u_7.samples.start = g_soundManager:loadSamplesFromXML(p_u_6.xmlFile, "vehicle.turnOnVehicle.sounds", "start", p_u_6.baseDirectory, p_u_6.components, 1, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
		v_u_7.samples.stop = g_soundManager:loadSamplesFromXML(p_u_6.xmlFile, "vehicle.turnOnVehicle.sounds", "stop", p_u_6.baseDirectory, p_u_6.components, 1, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
		v_u_7.samples.work = g_soundManager:loadSamplesFromXML(p_u_6.xmlFile, "vehicle.turnOnVehicle.sounds", "work", p_u_6.baseDirectory, p_u_6.components, 0, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
		v_u_7.turnedOnSpeed = {}
		v_u_7.turnedOnSpeed.isActive = p_u_6.xmlFile:hasProperty("vehicle.turnOnVehicle.turnedOnSpeed")
		v_u_7.turnedOnSpeed.alpha = 0
		v_u_7.turnedOnSpeed.fadeInTime = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle.turnedOnSpeed#fadeInTime", 1)
		v_u_7.turnedOnSpeed.fadeOutTime = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle.turnedOnSpeed#fadeOutTime", 1)
		v_u_7.turnedOnSpeed.variance = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle.turnedOnSpeed#variance", 0.02)
		v_u_7.turnedOnSpeed.varianceSpeed = p_u_6.xmlFile:getValue("vehicle.turnOnVehicle.turnedOnSpeed#varianceSpeed", 0.01)
	end
	if not p_u_6.isClient then
		SpecializationUtil.removeEventListener(p_u_6, "onDelete", TurnOnVehicle)
		SpecializationUtil.removeEventListener(p_u_6, "onUpdate", TurnOnVehicle)
	end
end
function TurnOnVehicle.onRegisterDashboardValueTypes(p17)
	local v18 = p17.spec_turnOnVehicle
	local v19 = DashboardValueType.new("turnOnVehicle", "turnedOn")
	v19:setValue(v18, "isTurnedOn")
	p17:registerDashboardValueType(v19)
	local v20 = DashboardValueType.new("turnOnVehicle", "rpm")
	v20:setValue(p17, TurnOnVehicle.dashboardRpmValue)
	v20:setAdditionalFunctions(TurnOnVehicle.dashboardRpmAttributes, nil)
	p17:registerDashboardValueType(v20)
end
function TurnOnVehicle.onDelete(p21)
	local v22 = p21.spec_turnOnVehicle
	if p21.isClient then
		if v22.samples ~= nil then
			g_soundManager:deleteSamples(v22.samples.start)
			g_soundManager:deleteSamples(v22.samples.stop)
			g_soundManager:deleteSamples(v22.samples.work)
		end
		g_animationManager:deleteAnimations(v22.animationNodes)
		g_effectManager:deleteEffects(v22.effects)
	end
end
function TurnOnVehicle.onReadStream(p23, p24, _)
	p23:setIsTurnedOn(streamReadBool(p24), true)
end
function TurnOnVehicle.onWriteStream(p25, p26, _)
	local v27 = p25.spec_turnOnVehicle
	streamWriteBool(p26, v27.isTurnedOn)
end
function TurnOnVehicle.onUpdate(p28, p29, _, _, _)
	local v30 = p28.spec_turnOnVehicle
	for v31 = 1, #v30.turnedOnAnimations do
		local v32 = v30.turnedOnAnimations[v31]
		local v33 = p28:getIsTurnedOnAnimationActive(v32)
		if v32.isTurnedOn ~= v33 then
			if v33 then
				v32.speedDirection = 1
				local v34 = v32.name
				local v35 = v32.currentSpeed * v32.speedScale
				p28:playAnimation(v34, math.max(v35, 0.001), p28:getAnimationTime(v32.name), true)
			else
				v32.speedDirection = -1
			end
			v32.isTurnedOn = v33
		end
		if v32.speedDirection ~= 0 then
			local v36 = v32.turnOnFadeTime
			if v32.speedDirection == -1 then
				v36 = v32.turnOffFadeTime
			end
			local v37 = v32.currentSpeed + v32.speedDirection * p29 / v36
			v32.currentSpeed = math.clamp(v37, 0, 1)
			p28:setAnimationSpeed(v32.name, v32.currentSpeed * v32.speedScale)
			if v32.speedDirection == -1 and v32.currentSpeed == 0 then
				p28:stopAnimation(v32.name, true)
			end
			if v32.currentSpeed == 1 or v32.currentSpeed == 0 then
				v32.speedDirection = 0
			end
		end
	end
	if p28.isClient and v30.turnedOnSpeed.isActive then
		local v38
		if p28:getIsTurnedOn() then
			local v39 = g_time * v30.turnedOnSpeed.varianceSpeed * 0.05
			local v40 = math.sin(v39)
			local v41 = (v39 + 2) * 0.3
			local v42 = v40 * math.sin(v41) * 0.8
			local v43 = v39 * 5
			v38 = 1 + (v42 + math.cos(v43) * 0.2) * v30.turnedOnSpeed.variance
		else
			v38 = 0
		end
		if v38 ~= v30.turnedOnSpeed.alpha then
			local v44 = v38 - v30.turnedOnSpeed.alpha
			local v45 = math.sign(v44)
			local v46 = v45 < 0 and math.max or math.min
			local v47 = v45 < 0 and v30.turnedOnSpeed.fadeOutTime or v30.turnedOnSpeed.fadeInTime
			v30.turnedOnSpeed.alpha = v46(v30.turnedOnSpeed.alpha + 1 / v47 * v45 * p29, v38)
		end
	end
end
function TurnOnVehicle.onUpdateTick(p48, _, _, _, _)
	local v49 = p48.spec_turnOnVehicle
	if p48.isClient and not (v49.isAlwaysTurnedOn or v49.turnedOnByAttacherVehicle) then
		TurnOnVehicle.updateActionEvents(p48)
	end
	if p48.isServer and (v49.turnOffIfNotAllowed and not p48:getCanBeTurnedOn()) then
		if p48:getIsTurnedOn() then
			p48:setIsTurnedOn(false)
			return
		end
		if p48.getAttacherVehicle ~= nil then
			local v50 = p48:getAttacherVehicle()
			if v50 ~= nil and (v50.setIsTurnedOn ~= nil and v50:getIsTurnedOn()) then
				v50:setIsTurnedOn(false)
			end
		end
	end
end
function TurnOnVehicle.setIsTurnedOn(p51, p52, p53)
	local v54 = p51.spec_turnOnVehicle
	if p52 ~= v54.isTurnedOn then
		SetTurnedOnEvent.sendEvent(p51, p52, p53)
		v54.isTurnedOn = p52
		if v54.isTurnedOn then
			SpecializationUtil.raiseEvent(p51, "onTurnedOn")
			p51.rootVehicle:raiseStateChange(VehicleStateChange.TURN_ON, p51)
			return
		end
		SpecializationUtil.raiseEvent(p51, "onTurnedOff")
		p51.rootVehicle:raiseStateChange(VehicleStateChange.TURN_OFF, p51)
	end
end
function TurnOnVehicle.onTurnedOn(p55)
	local v56 = p55.spec_turnOnVehicle
	if p55.isClient then
		if v56.turnOnAnimation ~= nil then
			p55:playAnimation(v56.turnOnAnimation.name, v56.turnOnAnimation.turnOnSpeedScale, p55:getAnimationTime(v56.turnOnAnimation.name), true)
		end
		g_soundManager:stopSamples(v56.samples.start)
		g_soundManager:stopSamples(v56.samples.work)
		g_soundManager:stopSamples(v56.samples.stop)
		g_soundManager:playSamples(v56.samples.start)
		for v57 = 1, #v56.samples.work do
			g_soundManager:playSample(v56.samples.work[v57], 0, v56.samples.start[v57] or v56.samples.start[1])
		end
		g_animationManager:startAnimations(v56.animationNodes)
		g_effectManager:startEffects(v56.effects)
	end
	if v56.activateableDischargeNode ~= nil and v56.activateableDischargeNode.index ~= nil then
		v56.activateableDischargeNodePrev = p55:getCurrentDischargeNode()
		p55:setCurrentDischargeNodeIndex(v56.activateableDischargeNode.index)
	end
end
function TurnOnVehicle.onTurnedOff(p58)
	local v59 = p58.spec_turnOnVehicle
	if p58.isClient then
		if v59.turnOnAnimation ~= nil then
			p58:playAnimation(v59.turnOnAnimation.name, v59.turnOnAnimation.turnOffSpeedScale, p58:getAnimationTime(v59.turnOnAnimation.name), true)
		end
		g_soundManager:stopSamples(v59.samples.start)
		g_soundManager:stopSamples(v59.samples.work)
		g_soundManager:stopSamples(v59.samples.stop)
		g_soundManager:playSamples(v59.samples.stop)
		g_animationManager:stopAnimations(v59.animationNodes)
		g_effectManager:stopEffects(v59.effects)
	end
	if v59.activateableDischargeNodePrev ~= nil and v59.activateableDischargeNodePrev.index ~= nil then
		p58:setCurrentDischargeNodeIndex(v59.activateableDischargeNodePrev.index)
		v59.activateableDischargeNodePrev = nil
	end
end
function TurnOnVehicle.getIsTurnedOn(p60)
	local v61 = p60.spec_turnOnVehicle
	return v61.isAlwaysTurnedOn or v61.isTurnedOn
end
function TurnOnVehicle.getCanBeTurnedOn(p62)
	if p62.spec_turnOnVehicle.isAlwaysTurnedOn then
		return false
	end
	if p62.getInputAttacherJoint ~= nil then
		local v63 = p62:getInputAttacherJoint()
		if v63 ~= nil and (v63.canBeTurnedOn ~= nil and not v63.canBeTurnedOn) then
			return false
		end
	end
	return p62:getIsPowered() and true or false
end
function TurnOnVehicle.getCanBeTurnedOnAll(p64)
	local v65 = p64.rootVehicle:getChildVehicles()
	for v66 = 1, #v65 do
		local v67 = v65[v66]
		if v67.getCanBeTurnedOn ~= nil and not v67:getCanBeTurnedOn() then
			return false
		end
	end
	return true
end
function TurnOnVehicle.getCanToggleTurnedOn(p68)
	local v69 = p68.spec_turnOnVehicle
	if v69.isAlwaysTurnedOn then
		return false
	else
		return not v69.turnedOnByAttacherVehicle
	end
end
function TurnOnVehicle.getTurnedOnNotAllowedWarning(p70)
	if p70:getIsPowered() then
		return nil
	else
		return g_i18n:getText("warning_attachToPower")
	end
end
function TurnOnVehicle.getAIRequiresTurnOn(p71)
	return p71.spec_turnOnVehicle.aiRequiresTurnOn
end
function TurnOnVehicle.getRequiresTurnOn(p72)
	return p72.spec_turnOnVehicle.requiresTurnOn
end
function TurnOnVehicle.getAIRequiresTurnOffOnHeadland(_)
	return false
end
function TurnOnVehicle.loadTurnedOnAnimationFromXML(p73, p74, p75, p76)
	local v77 = p73.xmlFile:getValue(p75 .. "#name")
	if v77 == nil then
		Logging.xmlWarning(p74, "Missing animation name in \'%s\'", p75)
		return false
	end
	p76.name = v77
	p76.turnOnFadeTime = p73.xmlFile:getValue(p75 .. "#turnOnFadeTime", 1) * 1000
	p76.turnOffFadeTime = p73.xmlFile:getValue(p75 .. "#turnOffFadeTime", 1) * 1000
	p76.speedScale = p73.xmlFile:getValue(p75 .. "#speedScale", 1)
	p76.speedDirection = 0
	p76.currentSpeed = 0
	p76.isTurnedOn = false
	return true
end
function TurnOnVehicle.getIsTurnedOnAnimationActive(p78, _)
	return p78:getIsTurnedOn() and true or false
end
function TurnOnVehicle.getUseTurnedOnSchema(p79, p80)
	return p80(p79) or p79:getIsTurnedOn()
end
function TurnOnVehicle.loadInputAttacherJoint(p81, p82, p83, p84, p85, p86)
	if not p82(p81, p83, p84, p85, p86) then
		return false
	end
	p85.canBeTurnedOn = p83:getValue(p84 .. "#canBeTurnedOn", true)
	return true
end
function TurnOnVehicle.loadWorkAreaFromXML(p87, p88, p89, p90, p91)
	local v92 = p88(p87, p89, p90, p91)
	p89.needsSetIsTurnedOn = p90:getValue(p91 .. "#needsSetIsTurnedOn", true)
	return v92
end
function TurnOnVehicle.getIsWorkAreaActive(p93, p94, p95)
	if p93:getIsTurnedOn() or not p95.needsSetIsTurnedOn then
		return p94(p93, p95)
	else
		return false
	end
end
function TurnOnVehicle.getCanAIImplementContinueWork(p96, p97, p98)
	local v99, v100, v101 = p97(p96, p98)
	if v99 then
		return not p96:getAIRequiresTurnOn() and true or (not p96:getIsAIImplementInLine() and true or ((not p96:getCanBeTurnedOn() or p96:getIsTurnedOn()) and true or false))
	else
		return false, v100, v101
	end
end
function TurnOnVehicle.getIsOperating(p102, p103)
	return p102:getIsTurnedOn() and true or p103(p102)
end
function TurnOnVehicle.getAlarmTriggerIsActive(p104, p105, p106)
	local v107 = p105(p104, p106)
	if p106.needsTurnOn and not p104:getIsTurnedOn() then
		v107 = false
	end
	return v107
end
function TurnOnVehicle.loadAlarmTrigger(p108, p109, p110, p111, p112, p113)
	local v114 = p109(p108, p110, p111, p112, p113)
	p112.needsTurnOn = p110:getValue(p111 .. "#needsTurnOn", false)
	p112.turnOffInTrigger = p110:getValue(p111 .. "#turnOffInTrigger", false)
	return v114
end
function TurnOnVehicle.getIsFillUnitActive(p115, p116, p117)
	if p115.spec_turnOnVehicle.activatableFillUnits[p117] == true and not p115:getIsTurnedOn() then
		return false
	else
		return p116(p115, p117)
	end
end
function TurnOnVehicle.loadShovelNode(p118, p119, p120, p121, p122)
	p119(p118, p120, p121, p122)
	p122.needsActiveVehicle = p120:getValue(p121 .. "#needsActivation", false)
	return true
end
function TurnOnVehicle.getShovelNodeIsActive(p123, p124, p125)
	if p125.needsActiveVehicle and not p123:getIsTurnedOn() then
		return false
	else
		return p124(p123, p125)
	end
end
function TurnOnVehicle.getIsSeedChangeAllowed(p126, p127)
	local v128 = p127(p126)
	if v128 then
		v128 = not p126:getIsTurnedOn()
	end
	return v128
end
function TurnOnVehicle.getCanBeSelected(_, _)
	return true
end
function TurnOnVehicle.getIsPowerTakeOffActive(p129, p130)
	return p129:getIsTurnedOn() or p130(p129)
end
function TurnOnVehicle.loadDischargeNode(p131, p132, p133, p134, p135)
	if not p132(p131, p133, p134, p135) then
		return false
	end
	p135.needsSetIsTurnedOn = p133:getValue(p134 .. "#needsSetIsTurnedOn", false)
	p135.turnOnActivateNode = p133:getValue(p134 .. "#turnOnActivateNode", false)
	if p135.turnOnActivateNode then
		p131.spec_turnOnVehicle.activateableDischargeNode = p135
	end
	return true
end
function TurnOnVehicle.getIsDischargeNodeActive(p136, p137, p138)
	if p138.needsSetIsTurnedOn and not p136:getIsTurnedOn() then
		return false
	else
		return p137(p136, p138)
	end
end
function TurnOnVehicle.loadBunkerSiloCompactorFromXML(p139, p140, p141, p142)
	p140(p139, p141, p142)
	p139.spec_bunkerSiloCompacter.turnedOnCompactingScale = p141:getValue(p142 .. "#turnedOnCompactingScale")
end
function TurnOnVehicle.getBunkerSiloCompacterScale(p143, p144)
	local v145 = p143.spec_bunkerSiloCompacter
	if v145.turnedOnCompactingScale == nil or not p143:getIsTurnedOn() then
		return p144(p143)
	else
		return v145.turnedOnCompactingScale
	end
end
function TurnOnVehicle.getIsWorkModeChangeAllowed(p146, p147)
	if p146.spec_workMode.allowChangeWhileTurnedOn == false and p146:getIsTurnedOn() then
		return false
	else
		return p147(p146)
	end
end
function TurnOnVehicle.onRegisterActionEvents(p148, _, p149)
	if p148.isClient then
		local v150 = p148.spec_turnOnVehicle
		p148:clearActionEventsTable(v150.actionEvents)
		if p149 and p148:getCanToggleTurnedOn() then
			local _, v151 = p148:addPoweredActionEvent(v150.actionEvents, v150.toggleTurnOnInputBinding, p148, TurnOnVehicle.actionEventTurnOn, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v151, GS_PRIO_HIGH)
			TurnOnVehicle.updateActionEvents(p148)
			local _, v152 = p148:addPoweredActionEvent(v150.actionEvents, InputAction.TURN_ON_ALL_IMPLEMENTS, p148, TurnOnVehicle.actionEventTurnOnAll, false, true, false, true, nil)
			g_inputBinding:setActionEventTextVisibility(v152, false)
		end
	end
end
function TurnOnVehicle.onRegisterExternalActionEvents(p153, p154, p155, _, _)
	if p155 == "turnOn" then
		p153:registerExternalActionEvent(p154, p155, TurnOnVehicle.externalActionEventRegister, TurnOnVehicle.externalActionEventUpdate)
	end
end
function TurnOnVehicle.onAlarmTriggerChanged(p156, p157, p158)
	if p158 and p157.turnOffInTrigger then
		p156:setIsTurnedOn(false, true)
	end
end
function TurnOnVehicle.onSetBroken(p159)
	p159:setIsTurnedOn(false, true)
end
function TurnOnVehicle.onStateChange(p160, p161, _)
	if p161 == VehicleStateChange.MOTOR_TURN_OFF and not p160:getCanBeTurnedOn() then
		p160:setIsTurnedOn(false, true)
	end
end
function TurnOnVehicle.onDeactivate(p162)
	if p162.spec_turnOnVehicle.turnOffOnDeactivate then
		p162:setIsTurnedOn(false, true)
	end
end
function TurnOnVehicle.onPostAttach(p163, p164, _, _)
	if p163.spec_turnOnVehicle.turnedOnByAttacherVehicle and p164.getIsTurnedOn ~= nil then
		p163:setIsTurnedOn(p164:getIsTurnedOn(), true)
	end
end
function TurnOnVehicle.onPreDetach(p165, _, _)
	p165:setIsTurnedOn(false, true)
end
function TurnOnVehicle.onRootVehicleChanged(p166, p167)
	local v168 = p166.spec_turnOnVehicle
	local v169 = p167.actionController
	if v169 == nil or not p166:getCanToggleTurnedOn() then
		if v168.controlledAction ~= nil then
			v168.controlledAction:remove()
		end
	else
		if v168.controlledAction ~= nil then
			v168.controlledAction:updateParent(v169)
			return
		end
		v168.controlledAction = v169:registerAction("turnOn", v168.toggleTurnOnInputBinding, 1)
		v168.controlledAction:setCallback(p166, TurnOnVehicle.actionControllerTurnOnEvent)
		v168.controlledAction:setFinishedFunctions(p166, p166.getIsTurnedOn, true, false)
		v168.controlledAction:setIsSaved(true)
		v168.controlledAction:setIsAccessibleFunction(function()
			return true
		end)
		if p166:getAIRequiresTurnOn() then
			if not p166:getAIRequiresTurnOffOnHeadland() then
				v168.controlledAction:addAIEventListener(p166, "onAIFieldWorkerPrepareForWork", 1, true)
				v168.controlledAction:addAIEventListener(p166, "onAIImplementPrepareForWork", 1, true)
			end
			v168.controlledAction:addAIEventListener(p166, "onAIImplementStartLine", 1, true)
			v168.controlledAction:addAIEventListener(p166, "onAIImplementContinue", 1)
			v168.controlledAction:addAIEventListener(p166, "onAIImplementEnd", -1)
			v168.controlledAction:addAIEventListener(p166, "onAIImplementStart", -1)
			v168.controlledAction:addAIEventListener(p166, "onAIFieldWorkerEnd", -1)
			if p166:getAIRequiresTurnOffOnHeadland() then
				v168.controlledAction:addAIEventListener(p166, "onAIImplementEndLine", -1)
			end
			v168.controlledAction:addAIEventListener(p166, "onAIImplementBlock", -1)
			v168.controlledAction:addAIEventListener(p166, "onAIImplementPrepareForTransport", -1)
			return
		end
	end
end
function TurnOnVehicle.actionControllerTurnOnEvent(p170, p171)
	if p171 <= 0 then
		p170:setIsTurnedOn(false)
		return not p170:getIsTurnedOn()
	end
	if not p170:getCanBeTurnedOn() then
		return false
	end
	p170:setIsTurnedOn(true)
	return true
end
function TurnOnVehicle.actionEventTurnOn(p172, _, _, _, _)
	if p172:getCanToggleTurnedOn() and p172:getCanBeTurnedOn() then
		p172:setIsTurnedOn(not p172:getIsTurnedOn())
	elseif not p172:getIsTurnedOn() then
		local v173 = p172:getTurnedOnNotAllowedWarning()
		if v173 ~= nil then
			g_currentMission:showBlinkingWarning(v173, 2000)
		end
	end
end
function TurnOnVehicle.actionEventTurnOnAll(p174, _, _, _, _)
	if p174:getCanToggleTurnedOn() then
		local v175, v176 = p174:getCanBeTurnedOnAll()
		if v175 then
			local v177 = p174.rootVehicle:getChildVehicles()
			for v178 = 1, #v177 do
				local v179 = v177[v178]
				if v179.setIsTurnedOn ~= nil then
					v179:setIsTurnedOn(not v179:getIsTurnedOn())
				end
			end
			return
		end
		if not p174:getIsTurnedOn() and v176 ~= nil then
			g_currentMission:showBlinkingWarning(v176, 2000)
		end
	end
end
function TurnOnVehicle.updateActionEvents(p180)
	local v181 = p180.spec_turnOnVehicle
	local v182 = v181.actionEvents[v181.toggleTurnOnInputBinding]
	if v182 ~= nil then
		local v183 = p180:getCanToggleTurnedOn()
		if v183 then
			local v184
			if p180:getIsTurnedOn() then
				v184 = v181.turnOffText
			else
				v184 = v181.turnOnText
			end
			g_inputBinding:setActionEventText(v182.actionEventId, v184)
		end
		g_inputBinding:setActionEventActive(v182.actionEventId, v183)
	end
end
function TurnOnVehicle.externalActionEventRegister(p185, p_u_186)
	local v187 = p_u_186.spec_turnOnVehicle
	local _, v192 = g_inputBinding:registerActionEvent(v187.toggleTurnOnInputBinding, p185, function(_, p188, p189, p190, p191)
		-- upvalues: (copy) p_u_186
		Motorized.tryStartMotor(p_u_186)
		TurnOnVehicle.actionEventTurnOn(p_u_186, p188, p189, p190, p191)
	end, false, true, false, true)
	p185.actionEventId = v192
	g_inputBinding:setActionEventTextPriority(p185.actionEventId, GS_PRIO_HIGH)
end
function TurnOnVehicle.externalActionEventUpdate(p193, p194)
	if p193.actionEventId ~= nil then
		local v195 = p194:getCanToggleTurnedOn()
		if v195 then
			local v196
			if p194:getIsTurnedOn() then
				v196 = p194.spec_turnOnVehicle.turnOffText
			else
				v196 = p194.spec_turnOnVehicle.turnOnText
			end
			g_inputBinding:setActionEventText(p193.actionEventId, v196)
		end
		g_inputBinding:setActionEventActive(p193.actionEventId, v195)
	end
end
function TurnOnVehicle.getTurnedOnSpeedFactor(p197)
	return p197.spec_turnOnVehicle.turnedOnSpeed.alpha
end
g_soundManager:registerModifierType("TURNED_ON_SPEED", TurnOnVehicle.getTurnedOnSpeedFactor)
function TurnOnVehicle.dashboardRpmAttributes(_, p198, p199, p200, _)
	p200.minRpm = p198:getValue(p199 .. "#minRpm", 0)
	p200.maxRpm = p198:getValue(p199 .. "#maxRpm", 1000)
	return true
end
function TurnOnVehicle.dashboardRpmValue(p201, p202)
	return p202.minRpm + (p202.maxRpm - p202.minRpm) * p201.spec_turnOnVehicle.turnedOnSpeed.alpha
end

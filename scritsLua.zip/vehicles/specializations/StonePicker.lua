StonePicker = {}
function StonePicker.initSpecialization()
	AIFieldWorker.registerDriveStrategy(function(p1)
		return SpecializationUtil.hasSpecialization(StonePicker, p1.specializations)
	end, AIDriveStrategyStonePicker)
	g_workAreaTypeManager:addWorkAreaType("stonePicker", true, true, true)
	local v2 = Vehicle.xmlSchema
	v2:setXMLSpecializationType("StonePicker")
	v2:register(XMLValueType.INT, "vehicle.stonePicker#fillUnitIndex", "Index of fillunit to be used for picked stones")
	v2:register(XMLValueType.INT, "vehicle.stonePicker#loadInfoIndex", "Index of load info to use")
	v2:register(XMLValueType.NODE_INDEX, "vehicle.stonePicker.directionNode#node", "Direction node")
	v2:register(XMLValueType.BOOL, "vehicle.stonePicker.onlyActiveWhenLowered#value", "Only active when lowered", true)
	v2:register(XMLValueType.BOOL, "vehicle.stonePicker.needsActivation#value", "Needs activation", true)
	EffectManager.registerEffectXMLPaths(v2, "vehicle.stonePicker.effects")
	EffectManager.registerEffectXMLPaths(v2, "vehicle.stonePicker.soilEffects")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.stonePicker.sounds", "work")
	SoundManager.registerSampleXMLPaths(v2, "vehicle.stonePicker.sounds", "stone")
	v2:setXMLSpecializationType()
end
function StonePicker.prerequisitesPresent(p3)
	local v4 = SpecializationUtil.hasSpecialization(FillUnit, p3)
	if v4 then
		v4 = SpecializationUtil.hasSpecialization(WorkArea, p3)
	end
	return v4
end
function StonePicker.registerFunctions(p5)
	SpecializationUtil.registerFunction(p5, "processStonePickerArea", StonePicker.processStonePickerArea)
	SpecializationUtil.registerFunction(p5, "setStonePickerEffectsState", StonePicker.setStonePickerEffectsState)
end
function StonePicker.registerOverwrittenFunctions(p6)
	SpecializationUtil.registerOverwrittenFunction(p6, "doCheckSpeedLimit", StonePicker.doCheckSpeedLimit)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDoGroundManipulation", StonePicker.getDoGroundManipulation)
	SpecializationUtil.registerOverwrittenFunction(p6, "getDirtMultiplier", StonePicker.getDirtMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "getWearMultiplier", StonePicker.getWearMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p6, "loadWorkAreaFromXML", StonePicker.loadWorkAreaFromXML)
	SpecializationUtil.registerOverwrittenFunction(p6, "getIsWorkAreaActive", StonePicker.getIsWorkAreaActive)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanBeTurnedOn", StonePicker.getCanBeTurnedOn)
	SpecializationUtil.registerOverwrittenFunction(p6, "getTurnedOnNotAllowedWarning", StonePicker.getTurnedOnNotAllowedWarning)
	SpecializationUtil.registerOverwrittenFunction(p6, "getCanToggleTurnedOn", StonePicker.getCanToggleTurnedOn)
end
function StonePicker.registerEventListeners(p7)
	SpecializationUtil.registerEventListener(p7, "onLoad", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onDelete", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onReadStream", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onWriteStream", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onReadUpdateStream", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onWriteUpdateStream", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onPostAttach", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onDeactivate", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onStartWorkAreaProcessing", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onEndWorkAreaProcessing", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onFillUnitFillLevelChanged", StonePicker)
	SpecializationUtil.registerEventListener(p7, "onAIFieldCourseSettingsInitialized", StonePicker)
end
function StonePicker.onLoad(p8, _)
	if p8:getGroundReferenceNodeFromIndex(1) == nil then
		printWarning("Warning: No ground reference nodes in  " .. p8.configFileName)
	end
	local v9 = p8.spec_stonePicker
	if p8.isClient then
		v9.samples = {}
		v9.samples.work = g_soundManager:loadSampleFromXML(p8.xmlFile, "vehicle.stonePicker.sounds", "work", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v9.samples.stone = g_soundManager:loadSampleFromXML(p8.xmlFile, "vehicle.stonePicker.sounds", "stone", p8.baseDirectory, p8.components, 0, AudioGroup.VEHICLE, p8.i3dMappings, p8)
		v9.isWorkSamplePlaying = false
		v9.isStoneSamplePlaying = false
		v9.effects = g_effectManager:loadEffect(p8.xmlFile, "vehicle.stonePicker.effects", p8.components, p8, p8.i3dMappings)
		v9.soilEffects = g_effectManager:loadEffect(p8.xmlFile, "vehicle.stonePicker.soilEffects", p8.components, p8, p8.i3dMappings)
	end
	v9.fillUnitIndex = p8.xmlFile:getValue("vehicle.stonePicker#fillUnitIndex", 1)
	v9.loadInfoIndex = p8.xmlFile:getValue("vehicle.stonePicker#loadInfoIndex", 1)
	v9.directionNode = p8.xmlFile:getValue("vehicle.stonePicker.directionNode#node", p8.components[1].node, p8.components, p8.i3dMappings)
	v9.onlyActiveWhenLowered = p8.xmlFile:getValue("vehicle.stonePicker.onlyActiveWhenLowered#value", true)
	v9.needsActivation = p8.xmlFile:getValue("vehicle.stonePicker.needsActivation#value", true)
	v9.startActivationTimeout = 2000
	v9.startActivationTime = 0
	v9.hasGroundContact = false
	v9.isWorking = false
	v9.isEffectActive = false
	v9.effectGrowthState = 1
	v9.isSoilEffectActive = false
	v9.texts = {}
	v9.texts.warningToolIsFull = g_i18n:getText("warning_toolIsFull")
	v9.workAreaParameters = {}
	v9.workAreaParameters.angle = 0
	v9.workAreaParameters.pickedLiters = 0
	v9.workAreaParameters.lastChangedArea = 0
	v9.workAreaParameters.lastChangedAreaTime = (-1 / 0)
	v9.workAreaParameters.lastGrowthState = 1
	v9.workAreaParameters.lastStatsArea = 0
	v9.workAreaParameters.lastTotalArea = 0
	if p8.isServer then
		local v10, v11 = g_currentMission.fieldGroundSystem:getSowableRange()
		p8:addAITerrainDetailRequiredRange(v10, v11)
		if g_currentMission.stoneSystem ~= nil then
			local v12, v13, v14 = g_currentMission.stoneSystem:getDensityMapData()
			local v15, v16 = g_currentMission.stoneSystem:getMinMaxValues()
			p8:addAIFruitRequirement(nil, v15, v16, v12, v13, v14)
		end
	end
	v9.dirtyFlag = p8:getNextDirtyFlag()
end
function StonePicker.onDelete(p17)
	local v18 = p17.spec_stonePicker
	g_soundManager:deleteSamples(v18.samples)
	g_effectManager:deleteEffects(v18.effects)
	g_effectManager:deleteEffects(v18.soilEffects)
end
function StonePicker.onReadStream(p19, p20, _)
	p19:setStonePickerEffectsState(streamReadBool(p20), streamReadUIntN(p20, 2), (streamReadBool(p20)))
end
function StonePicker.onWriteStream(p21, p22, _)
	local v23 = p21.spec_stonePicker
	streamWriteBool(p22, v23.isEffectActive)
	streamWriteUIntN(p22, v23.effectGrowthState, 2)
	streamWriteBool(p22, v23.isSoilEffectActive)
end
function StonePicker.onReadUpdateStream(p24, p25, _, p26)
	if p26.isServer and streamReadBool(p25) then
		p24:setStonePickerEffectsState(streamReadBool(p25), streamReadUIntN(p25, 2), (streamReadBool(p25)))
	end
end
function StonePicker.onWriteUpdateStream(p27, p28, p29, p30)
	if not p29.isServer then
		local v31 = p27.spec_stonePicker
		if streamWriteBool(p28, bitAND(p30, v31.dirtyFlag) ~= 0) then
			streamWriteBool(p28, v31.isEffectActive)
			streamWriteUIntN(p28, v31.effectGrowthState, 2)
			streamWriteBool(p28, v31.isSoilEffectActive)
		end
	end
end
function StonePicker.processStonePickerArea(p32, p33, _)
	local v34 = p32.spec_stonePicker
	if not v34.workAreaParameters.isActive then
		return 0, 0
	end
	local v35, _, v36 = getWorldTranslation(p33.start)
	local v37, _, v38 = getWorldTranslation(p33.width)
	local v39, _, v40 = getWorldTranslation(p33.height)
	local v41 = v34.workAreaParameters
	local v42, v43, v44 = FSDensityMapUtil.updateStonePickerArea(v35, v36, v37, v38, v39, v40, v41.angle)
	local v45 = g_currentMission.stoneSystem:getLitersPerSqm()
	local v46 = g_currentMission:getFruitPixelsToSqm() * v43 * v45 * v42
	v41.pickedLiters = v41.pickedLiters + v46
	v41.lastChangedArea = v41.lastChangedArea + v43
	v41.lastStatsArea = v41.lastStatsArea + v43
	v41.lastTotalArea = v41.lastTotalArea + v44
	if v43 > 0 then
		v41.lastChangedAreaTime = g_time
		local v47 = v42 + 0.49
		local v48 = math.floor(v47)
		v41.lastGrowthState = math.clamp(v48, 1, 3)
	end
	FSDensityMapUtil.eraseTireTrack(v35, v36, v37, v38, v39, v40)
	v34.isWorking = p32:getLastSpeed() > 0.5
	return v43, v44
end
function StonePicker.setStonePickerEffectsState(p49, p50, p51, p52)
	local v53 = p49.spec_stonePicker
	if p50 ~= v53.isEffectActive or (p51 ~= v53.effectGrowthState or p52 ~= v53.isSoilEffectActive) then
		v53.isEffectActive = p50
		v53.effectGrowthState = p51
		v53.isSoilEffectActive = p52
		if p49.isClient then
			if p50 then
				g_effectManager:setEffectTypeInfo(v53.effects, FillType.STONE, nil, p51)
				g_effectManager:startEffects(v53.effects)
				if not v53.isStoneSamplePlaying then
					g_soundManager:playSample(v53.samples.stone)
					v53.isStoneSamplePlaying = true
				end
			else
				g_effectManager:stopEffects(v53.effects)
				if v53.isStoneSamplePlaying then
					g_soundManager:stopSample(v53.samples.stone)
					v53.isStoneSamplePlaying = false
				end
			end
			if p52 then
				g_effectManager:startEffects(v53.soilEffects)
				if not v53.isWorkSamplePlaying then
					g_soundManager:playSample(v53.samples.work)
					v53.isWorkSamplePlaying = true
					return
				end
			else
				g_effectManager:stopEffects(v53.soilEffects)
				if v53.isWorkSamplePlaying then
					g_soundManager:stopSample(v53.samples.work)
					v53.isWorkSamplePlaying = false
				end
			end
		end
	end
end
function StonePicker.doCheckSpeedLimit(p54, p55)
	local v56 = p54.spec_stonePicker
	local v57 = not p55(p54) and p54:getIsImplementChainLowered()
	if v57 then
		v57 = not v56.needsActivation or p54:getIsTurnedOn()
	end
	return v57
end
function StonePicker.getDoGroundManipulation(p58, p59)
	if p58.spec_stonePicker.isWorking then
		return p59(p58)
	else
		return false
	end
end
function StonePicker.getDirtMultiplier(p60, p61)
	local v62 = p60.spec_stonePicker
	local v63 = p61(p60)
	if p60.movingDirection > 0 and (v62.isWorking and (not v62.needsActivation or p60:getIsTurnedOn())) then
		v63 = v63 + p60:getWorkDirtMultiplier() * p60:getLastSpeed() / v62.speedLimit
	end
	return v63
end
function StonePicker.getWearMultiplier(p64, p65)
	local v66 = p64.spec_stonePicker
	local v67 = p65(p64)
	if p64.movingDirection > 0 and (v66.isWorking and (not v66.needsActivation or p64:getIsTurnedOn())) then
		v67 = v67 + p64:getWorkWearMultiplier() * p64:getLastSpeed() / p64.speedLimit
	end
	return v67
end
function StonePicker.loadWorkAreaFromXML(p68, p69, p70, p71, p72)
	local v73 = p69(p68, p70, p71, p72)
	if p70.type == WorkAreaType.DEFAULT then
		p70.type = WorkAreaType.STONEPICKER
	end
	return v73
end
function StonePicker.getIsWorkAreaActive(p74, p75, p76)
	if p76.type == WorkAreaType.STONEPICKER then
		local v77 = p74.spec_stonePicker
		if v77.startActivationTime > g_currentMission.time then
			return false
		end
		if v77.onlyActiveWhenLowered and (p74.getIsLowered ~= nil and not p74:getIsLowered(false)) then
			return false
		end
		if p74:getFillUnitFreeCapacity(v77.fillUnitIndex) <= 0 and not p74:getIsAIActive() then
			return false
		end
	end
	return p75(p74, p76)
end
function StonePicker.getCanBeTurnedOn(p78, p79)
	if p78:getFillUnitFreeCapacity(p78.spec_stonePicker.fillUnitIndex) <= 0 and not p78:getIsAIActive() then
		return false
	else
		return p79(p78)
	end
end
function StonePicker.getTurnedOnNotAllowedWarning(p80, p81)
	local v82 = p80.spec_stonePicker
	if p80:getFillUnitFreeCapacity(v82.fillUnitIndex) <= 0 and not p80:getIsAIActive() then
		return v82.texts.warningToolIsFull
	else
		return p81(p80)
	end
end
function StonePicker.getCanToggleTurnedOn(p83, p84)
	if p83.spec_stonePicker.needsActivation then
		return p84(p83)
	else
		return false
	end
end
function StonePicker.onFillUnitFillLevelChanged(p85, p86, _, _, _, _, _)
	local v87 = p85.spec_stonePicker
	if p85.isServer and (v87.fillUnitIndex == p86 and (p85:getFillUnitFreeCapacity(v87.fillUnitIndex) <= 0 and (p85:getIsTurnedOn() and not p85:getIsAIActive()))) then
		p85:setIsTurnedOn(false, false)
	end
end
function StonePicker.onAIFieldCourseSettingsInitialized(_, p88)
	p88.headlandsFirst = true
	p88.workInitialSegment = true
	p88.segmentSplitDistance = 50
	p88.toolAlwaysActive = true
end
function StonePicker.onPostAttach(p89, _, _, _)
	local v90 = p89.spec_stonePicker
	v90.startActivationTime = g_currentMission.time + v90.startActivationTimeout
end
function StonePicker.onDeactivate(p91)
	if p91.isClient then
		local v92 = p91.spec_stonePicker
		g_soundManager:stopSamples(v92.samples)
		v92.isWorkSamplePlaying = false
	end
end
function StonePicker.onStartWorkAreaProcessing(p93, _)
	local v94 = p93.spec_stonePicker
	v94.isWorking = false
	local v95, _, v96 = localDirectionToWorld(v94.directionNode, 0, 0, 1)
	local v97 = FSDensityMapUtil.convertToDensityMapAngle(MathUtil.getYRotationFromDirection(v95, v96), g_currentMission.fieldGroundSystem:getGroundAngleMaxValue())
	v94.workAreaParameters.isActive = not v94.needsActivation or p93:getIsTurnedOn()
	v94.workAreaParameters.angle = v97
	v94.workAreaParameters.pickedLiters = 0
	v94.workAreaParameters.lastChangedArea = 0
	v94.workAreaParameters.lastStatsArea = 0
	v94.workAreaParameters.lastTotalArea = 0
end
function StonePicker.onEndWorkAreaProcessing(p98, _)
	local v99 = p98.spec_stonePicker
	local v100 = v99.workAreaParameters
	if p98.isServer then
		local v101 = v99.workAreaParameters.lastStatsArea
		if v101 > 0 then
			p98:updateLastWorkedArea(v101)
		end
		local v102 = g_time - v99.workAreaParameters.lastChangedAreaTime < 500
		local v103 = v99.isWorking
		if v103 then
			v103 = p98:getIsOnField()
		end
		if v99.isEffectActive ~= v102 or (v99.effectGrowthState ~= v99.workAreaParameters.lastGrowthState or v103 ~= v99.isSoilEffectActive) then
			p98:setStonePickerEffectsState(v102, v99.workAreaParameters.lastGrowthState, v103)
			p98:raiseDirtyFlags(v99.dirtyFlag)
		end
	end
	local v104 = p98:getFillVolumeLoadInfo(v99.loadInfoIndex)
	p98:addFillUnitFillLevel(p98:getOwnerFarmId(), v99.fillUnitIndex, v100.pickedLiters, FillType.STONE, ToolType.UNDEFINED, v104)
end
function StonePicker.getDefaultSpeedLimit()
	return 10
end

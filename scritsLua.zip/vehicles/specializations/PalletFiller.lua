PalletFiller = {}
source("dataS/scripts/vehicles/specializations/enums/PalletFillerState.lua")
source("dataS/scripts/vehicles/specializations/events/PalletFillerBuyPalletEvent.lua")
source("dataS/scripts/vehicles/specializations/events/PalletFillerStateEvent.lua")
function PalletFiller.prerequisitesPresent(_)
	return true
end
function PalletFiller.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("PalletFiller")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.palletFiller.pickupTrigger#node", "Pickup pallet trigger")
	v1:register(XMLValueType.STRING, "vehicle.palletFiller.pallet#filename", "Filename to supported pallet xml file")
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.pallet#spacing", "Spacing between the pallets while they are loaded", 0.5)
	v1:register(XMLValueType.NODE_INDEX, "vehicle.palletFiller.palletRow#node", "Pallet row node")
	v1:register(XMLValueType.INT, "vehicle.palletFiller.palletRow#maxNumPallets", "Max. number of pallets that can be picked up", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.palletRow#minTransZ", "Min. translation of the row (drop off point)", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.palletRow#maxTransZ", "Max. translation of the row (pick up point)", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.palletRow#moveSpeed", "Move speed of pallet on the row (m/sec)", 1)
	v1:register(XMLValueType.TIME, "vehicle.palletFiller.palletRow#pickupTime", "Time until the pallet is fully picked up (sec)", 2)
	v1:register(XMLValueType.TIME, "vehicle.palletFiller.palletRow#loadingDelay", "Loading delay used for combine", 0)
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.palletFiller.palletRow.rotLimit#startLimit", "Start rotation limit after pickup", "0 0 0")
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.palletFiller.palletRow.rotLimit#endLimit", "End rotation limit while fully mounted", "0 0 0")
	v1:register(XMLValueType.VECTOR_ROT, "vehicle.palletFiller.palletRow.rotLimit#unloadLimit", "Rotation limit while unloading", "0 0 25")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.palletFiller.palletRow.transLimit#startLimit", "Start translation limit after pickup", "0.25 2 0.25")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.palletFiller.palletRow.transLimit#endLimit", "End translation limit while fully mounted", "0.05 2 0")
	v1:register(XMLValueType.VECTOR_TRANS, "vehicle.palletFiller.palletRow.transLimit#unloadLimit", "Translation limit while unloading", "0.25 2 0")
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.palletRow.fillStep(?)#transZ", "Target Z translation of the pickup of pallet while filling this pallet index", 0)
	v1:register(XMLValueType.INT, "vehicle.palletFiller.palletRow.fillStep(?)#palletIndex", "Pallet index to fill", 1)
	v1:register(XMLValueType.INT, "vehicle.palletFiller.palletRow.fillStep(?)#dischargeNodeIndex", "Discharge Node Index (defines which discharge node is used while the defined pallet index is available & not full)", 1)
	v1:register(XMLValueType.STRING, "vehicle.palletFiller.fillDeflectorAnimation#name", "Name of fill deflector animation (animation is played before the pallets are moving and revered after they are in the new position)")
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.fillDeflectorAnimation#speed", "Animation speed scale", 1)
	v1:register(XMLValueType.STRING, "vehicle.palletFiller.platformAnimation#name", "Name of platform animation (animation to lower the tool for pallet pickup and drop -> 0=pickup, #middleTime=idle, 1=drop)")
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.platformAnimation#speed", "Animation speed scale", 1)
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.platformAnimation#middleTime", "Animation middle time", 0.5)
	v1:register(XMLValueType.BOOL, "vehicle.palletFiller.platformAnimation#automaticLift", "Automatically lift platform after dropping or pickup", false)
	v1:register(XMLValueType.BOOL, "vehicle.palletFiller.platformAnimation#lowerToUnload", "Tool needs to be lowered first to be unloaded", false)
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.foldable#minLimit", "Min. folding time for platform state change [0-1]", 0)
	v1:register(XMLValueType.FLOAT, "vehicle.palletFiller.foldable#maxLimit", "Max. folding time for platform state change [0-1]", 1)
	SoundManager.registerSampleXMLPaths(v1, "vehicle.palletFiller.sounds", "move")
	AnimationManager.registerAnimationNodesXMLPaths(v1, "vehicle.palletFiller.animationNodes")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).palletFiller#state", "Current vehicle state")
	v2:register(XMLValueType.BOOL, "vehicles.vehicle(?).palletFiller#deflectorState", "Current deflector state")
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).palletFiller.palletSlot(?)#slotIndex", "Index of slot")
	v2:register(XMLValueType.STRING, "vehicles.vehicle(?).palletFiller.palletSlot(?)#objectUniqueId", "Unique id of the object that is loaded on this slot")
	v2:register(XMLValueType.VECTOR_TRANS, "vehicles.vehicle(?).palletFiller.palletSlot(?)#translation", "Translation of the joint")
	v2:register(XMLValueType.VECTOR_ROT, "vehicles.vehicle(?).palletFiller.palletSlot(?)#rotation", "Rotation of the joint")
end
function PalletFiller.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "loadPalletFillerPallet", PalletFiller.loadPalletFillerPallet)
	SpecializationUtil.registerFunction(p3, "unloadPalletFillerPallet", PalletFiller.unloadPalletFillerPallet)
	SpecializationUtil.registerFunction(p3, "buyPalletFillerPallets", PalletFiller.buyPalletFillerPallets)
	SpecializationUtil.registerFunction(p3, "getCanChangePalletFillerState", PalletFiller.getCanChangePalletFillerState)
	SpecializationUtil.registerFunction(p3, "getCanBuyPalletFillerPallets", PalletFiller.getCanBuyPalletFillerPallets)
	SpecializationUtil.registerFunction(p3, "setPalletFillerState", PalletFiller.setPalletFillerState)
	SpecializationUtil.registerFunction(p3, "setPalletFillerDeflectorState", PalletFiller.setPalletFillerDeflectorState)
	SpecializationUtil.registerFunction(p3, "getPalletFillerFillStep", PalletFiller.getPalletFillerFillStep)
	SpecializationUtil.registerFunction(p3, "getPalletFillerMovementDirection", PalletFiller.getPalletFillerMovementDirection)
end
function PalletFiller.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanToggleDischargeToObject", PalletFiller.getCanToggleDischargeToObject)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanToggleDischargeToGround", PalletFiller.getCanToggleDischargeToGround)
	SpecializationUtil.registerOverwrittenFunction(p4, "removeFromPhysics", PalletFiller.removeFromPhysics)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsFoldAllowed", PalletFiller.getIsFoldAllowed)
	SpecializationUtil.registerOverwrittenFunction(p4, "getFillLevelInformation", PalletFiller.getFillLevelInformation)
	SpecializationUtil.registerOverwrittenFunction(p4, "getCanAIImplementContinueWork", PalletFiller.getCanAIImplementContinueWork)
	SpecializationUtil.registerOverwrittenFunction(p4, "verifyCombine", PalletFiller.verifyCombine)
end
function PalletFiller.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onLoadFinished", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onDelete", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onReadStream", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onWriteStream", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onUpdate", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onFinishAnimation", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onFoldTimeChanged", PalletFiller)
	SpecializationUtil.registerEventListener(p5, "onRegisterActionEvents", PalletFiller)
end
function PalletFiller.onLoad(p_u_6, _)
	local v_u_7 = p_u_6.spec_palletFiller
	v_u_7.state = PalletFillerState.IDLE
	v_u_7.pickupTrigger = {}
	v_u_7.pickupTrigger.node = p_u_6.xmlFile:getValue("vehicle.palletFiller.pickupTrigger#node", nil, p_u_6.components, p_u_6.i3dMappings)
	if v_u_7.pickupTrigger.node ~= nil then
		v_u_7.pickupTrigger.triggeredObjects = {}
		function v_u_7.pickupTrigger.pickupTriggerCallback(_, _, p8, p9, p10, _, _)
			-- upvalues: (copy) v_u_7, (copy) p_u_6
			local v11 = g_currentMission:getNodeObject(p8)
			if v11 ~= nil and v11:isa(Vehicle) then
				if p9 then
					for _, v12 in ipairs(v_u_7.palletRow.palletSlots) do
						if v12.object == v11 then
							return
						end
					end
					if v11.configFileName == v_u_7.pallet.filename then
						v_u_7.pickupTrigger.triggeredObjects[p8] = (v_u_7.pickupTrigger.triggeredObjects[p8] or 0) + 1
						v11:addDeleteListener(p_u_6, PalletFiller.onObjectDeleted)
						p_u_6:raiseActive()
						return
					end
				elseif p10 then
					v_u_7.pickupTrigger.triggeredObjects[p8] = (v_u_7.pickupTrigger.triggeredObjects[p8] or 0) - 1
					if v_u_7.pickupTrigger.triggeredObjects[p8] <= 0 then
						v_u_7.pickupTrigger.triggeredObjects[p8] = nil
						v11:removeDeleteListener(p_u_6, PalletFiller.onObjectDeleted)
					end
				end
			end
		end
		addTrigger(v_u_7.pickupTrigger.node, "pickupTriggerCallback", v_u_7.pickupTrigger)
	end
	v_u_7.pallet = {}
	v_u_7.pallet.filename = p_u_6.xmlFile:getValue("vehicle.palletFiller.pallet#filename")
	if v_u_7.pallet.filename == nil then
		Logging.xmlWarning(p_u_6.xmlFile, "No pallet filename defined for \'%s\'", "vehicle.palletFiller")
	else
		v_u_7.pallet.filename = Utils.getFilename(v_u_7.pallet.filename, p_u_6.baseDirectory)
		v_u_7.pallet.storeItem = g_storeManager:getItemByXMLFilename(v_u_7.pallet.filename)
		if v_u_7.pallet.storeItem == nil then
			Logging.xmlWarning(p_u_6.xmlFile, "Invalid pallet filename defined for \'%s\' (%s)", "vehicle.palletFiller", v_u_7.pallet.filename)
			v_u_7.pallet.filename = nil
		end
	end
	v_u_7.pallet.spacing = p_u_6.xmlFile:getValue("vehicle.palletFiller.pallet#spacing", 0.5)
	v_u_7.palletRow = {}
	v_u_7.palletRow.node = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow#node", nil, p_u_6.components, p_u_6.i3dMappings)
	v_u_7.palletRow.maxNumPallets = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow#maxNumPallets", 1)
	v_u_7.palletRow.minTransZ = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow#minTransZ", 0)
	v_u_7.palletRow.maxTransZ = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow#maxTransZ", 0)
	v_u_7.palletRow.moveSpeed = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow#moveSpeed", 1) / 1000
	v_u_7.palletRow.pickupTime = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow#pickupTime", 2)
	v_u_7.palletRow.loadingDelay = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow#loadingDelay", 0)
	v_u_7.palletRow.fillSteps = {}
	p_u_6.xmlFile:iterate("vehicle.palletFiller.palletRow.fillStep", function(_, p13)
		-- upvalues: (copy) p_u_6, (copy) v_u_7
		local v14 = {
			["transZ"] = p_u_6.xmlFile:getValue(p13 .. "#transZ", 0),
			["palletIndex"] = p_u_6.xmlFile:getValue(p13 .. "#palletIndex", 1),
			["dischargeNodeIndex"] = p_u_6.xmlFile:getValue(p13 .. "#dischargeNodeIndex", 1),
			["index"] = #v_u_7.palletRow.fillSteps + 1
		}
		local v15 = v_u_7.palletRow.fillSteps
		table.insert(v15, v14)
	end)
	v_u_7.palletRow.startRotLimit = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow.rotLimit#startLimit", "0 0 0", true)
	v_u_7.palletRow.endRotLimit = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow.rotLimit#endLimit", "0 0 0", true)
	v_u_7.palletRow.unloadRotLimit = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow.rotLimit#unloadLimit", "0 0 25", true)
	v_u_7.palletRow.startTransLimit = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow.transLimit#startLimit", "0.25 2 0.25", true)
	v_u_7.palletRow.endTransLimit = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow.transLimit#endLimit", "0 2 0", true)
	v_u_7.palletRow.unloadTransLimit = p_u_6.xmlFile:getValue("vehicle.palletFiller.palletRow.transLimit#unloadLimit", "0.25 2 0", true)
	v_u_7.palletRow.palletSlots = {}
	for v16 = 1, v_u_7.palletRow.maxNumPallets do
		local v17 = {
			["jointNode"] = createTransformGroup("jointNode" .. v16)
		}
		link(v_u_7.palletRow.node, v17.jointNode)
		setTranslation(v17.jointNode, 0, 0, 0)
		setRotation(v17.jointNode, 0, 0, 0)
		v17.object = nil
		v17.interpolationTimer = 0
		v17.index = #v_u_7.palletRow.palletSlots + 1
		local v18 = v_u_7.palletRow.palletSlots
		table.insert(v18, v17)
	end
	v_u_7.palletRow.currentTransZ = 0
	v_u_7.palletRow.currentDischargeNodeIndex = 1
	v_u_7.palletRow.isMoving = false
	v_u_7.fillDeflectorAnimation = {}
	v_u_7.fillDeflectorAnimation.name = p_u_6.xmlFile:getValue("vehicle.palletFiller.fillDeflectorAnimation#name")
	v_u_7.fillDeflectorAnimation.speed = p_u_6.xmlFile:getValue("vehicle.palletFiller.fillDeflectorAnimation#speed", 1)
	v_u_7.fillDeflectorAnimation.state = false
	v_u_7.platformAnimation = {}
	v_u_7.platformAnimation.name = p_u_6.xmlFile:getValue("vehicle.palletFiller.platformAnimation#name")
	v_u_7.platformAnimation.speed = p_u_6.xmlFile:getValue("vehicle.palletFiller.platformAnimation#speed", 1)
	v_u_7.platformAnimation.middleTime = p_u_6.xmlFile:getValue("vehicle.palletFiller.platformAnimation#middleTime", 0.5)
	v_u_7.platformAnimation.automaticLift = p_u_6.xmlFile:getValue("vehicle.palletFiller.platformAnimation#automaticLift", false)
	v_u_7.platformAnimation.lowerToUnload = p_u_6.xmlFile:getValue("vehicle.palletFiller.platformAnimation#lowerToUnload", false)
	v_u_7.foldable = {}
	v_u_7.foldable.minLimit = p_u_6.xmlFile:getValue("vehicle.palletFiller.foldable#minLimit", 0)
	v_u_7.foldable.maxLimit = p_u_6.xmlFile:getValue("vehicle.palletFiller.foldable#maxLimit", 1)
	if p_u_6.isClient then
		v_u_7.animationNodes = g_animationManager:loadAnimations(p_u_6.xmlFile, "vehicle.palletFiller.animationNodes", p_u_6.components, p_u_6, p_u_6.i3dMappings)
		v_u_7.samples = {}
		v_u_7.samples.move = g_soundManager:loadSampleFromXML(p_u_6.xmlFile, "vehicle.palletFiller.sounds", "move", p_u_6.baseDirectory, p_u_6.components, 0, AudioGroup.VEHICLE, p_u_6.i3dMappings, p_u_6)
	end
	v_u_7.texts = {}
	v_u_7.texts.warningPalletFillerNoPalletAvailable = g_i18n:getText("warning_palletFillerNoPalletAvailable", PalletFiller.MOD_NAME)
	v_u_7.dirtyFlag = p_u_6:getNextDirtyFlag()
	if not p_u_6.isServer then
		SpecializationUtil.removeEventListener(p_u_6, "onUpdate", PalletFiller)
	end
	if not p_u_6.isClient then
		SpecializationUtil.removeEventListener(p_u_6, "onUpdateTick", PalletFiller)
	end
end
function PalletFiller.onLoadFinished(p19, p_u_20)
	local v_u_21 = p19.spec_palletFiller
	if v_u_21.palletRow.loadingDelay > 0 then
		local v22 = p19.spec_combine
		if p19.spec_combine ~= nil then
			v22.loadingDelay = v_u_21.palletRow.loadingDelay
			v22.unloadingDelay = v_u_21.palletRow.loadingDelay
			v22.loadingDelaySlotsDelayedInsert = false
			v22.loadingDelaySlots = {}
			for v23 = 1, v22.loadingDelay / 1000 * 60 + 1 do
				v22.loadingDelaySlots[v23] = {
					["time"] = (-1 / 0),
					["fillLevelDelta"] = 0,
					["fillType"] = 0,
					["valid"] = false
				}
			end
		end
	end
	p19:setAnimationTime(v_u_21.platformAnimation.name, 1, true, false)
	p19:setAnimationTime(v_u_21.platformAnimation.name, 0, true, false)
	if p_u_20 == nil then
		p19:setPalletFillerState(v_u_21.state, true)
	else
		local v24 = p_u_20.key .. ".palletFiller"
		local v25 = p_u_20.xmlFile:getValue(v24 .. "#state")
		if v25 ~= nil then
			p19:setPalletFillerState(PalletFillerState[v25:upper()] or v_u_21.state, true, true)
		end
		p19:setPalletFillerDeflectorState(p_u_20.xmlFile:getValue(v24 .. "#deflectorState", v_u_21.fillDeflectorAnimation.state), true)
		v_u_21.objectsToLoad = {}
		p_u_20.xmlFile:iterate(v24 .. ".palletSlot", function(_, p26)
			-- upvalues: (copy) p_u_20, (copy) v_u_21
			local v27 = {
				["slotIndex"] = p_u_20.xmlFile:getValue(p26 .. "#slotIndex"),
				["objectUniqueId"] = p_u_20.xmlFile:getValue(p26 .. "#objectUniqueId")
			}
			if v27.slotIndex ~= nil and v27.objectUniqueId ~= nil then
				v27.translation = p_u_20.xmlFile:getValue(p26 .. "#translation", nil, true)
				v27.rotation = p_u_20.xmlFile:getValue(p26 .. "#rotation", nil, true)
				local v28 = v_u_21.objectsToLoad
				table.insert(v28, v27)
			end
		end)
	end
end
function PalletFiller.saveToXMLFile(p29, p30, p31, _)
	local v32 = p29.spec_palletFiller
	p30:setValue(p31 .. "#state", PalletFillerState.getName(v32.state))
	p30:setValue(p31 .. "#deflectorState", v32.fillDeflectorAnimation.state)
	for v33, v34 in ipairs(v32.palletRow.palletSlots) do
		if v34.object ~= nil then
			local v35 = string.format("%s.palletSlot(%d)", p31, v33 - 1)
			p30:setValue(v35 .. "#slotIndex", v33)
			p30:setValue(v35 .. "#objectUniqueId", v34.object:getUniqueId())
			p30:setValue(v35 .. "#translation", getTranslation(v34.jointNode))
			p30:setValue(v35 .. "#rotation", getRotation(v34.jointNode))
		end
	end
end
function PalletFiller.onDelete(p36)
	local v37 = p36.spec_palletFiller
	if v37.pickupTrigger ~= nil and v37.pickupTrigger.node ~= nil then
		removeTrigger(v37.pickupTrigger.node)
	end
	if v37.samples ~= nil then
		g_soundManager:deleteSamples(v37.samples)
	end
	if v37.palletRow ~= nil then
		for _, v38 in ipairs(v37.palletRow.palletSlots) do
			if v38.object ~= nil then
				p36:unloadPalletFillerPallet(v38.object)
			end
		end
	end
end
function PalletFiller.onReadStream(p39, p40, _)
	local v41 = p39.spec_palletFiller
	p39:setPalletFillerState(streamReadUIntN(p40, PalletFiller.getNumBits()), true)
	p39:setPalletFillerDeflectorState(streamReadBool(p40), true)
	for _, v42 in ipairs(v41.palletRow.palletSlots) do
		if streamReadBool(p40) then
			v42.object = NetworkUtil.readNodeObject(p40)
		else
			v42.object = nil
		end
		v42.pendingObjectLoading = false
	end
end
function PalletFiller.onWriteStream(p43, p44, _)
	local v45 = p43.spec_palletFiller
	streamWriteUIntN(p44, v45.state, PalletFiller.getNumBits())
	streamWriteBool(p44, v45.fillDeflectorAnimation.state)
	for _, v46 in ipairs(v45.palletRow.palletSlots) do
		if streamWriteBool(p44, v46.object ~= nil) then
			NetworkUtil.writeNodeObject(p44, v46.object)
		end
	end
end
function PalletFiller.onReadUpdateStream(p47, p48, _, p49)
	if p49:getIsServer() and streamReadBool(p48) then
		local v50 = p47.spec_palletFiller
		v50.palletRow.isMoving = streamReadBool(p48)
		if v50.palletRow.isMoving then
			g_animationManager:startAnimations(v50.animationNodes)
			g_soundManager:playSample(v50.samples.move)
		else
			g_animationManager:stopAnimations(v50.animationNodes)
			g_soundManager:stopSample(v50.samples.move)
		end
		for _, v51 in ipairs(v50.palletRow.palletSlots) do
			if streamReadBool(p48) then
				v51.objectId = NetworkUtil.readNodeObjectId(p48)
				v51.object = NetworkUtil.getObject(v51.objectId)
				if v51.object == nil then
					p47:raiseActive()
				else
					v51.objectId = nil
					v51.pendingObjectLoading = false
				end
			else
				v51.object = nil
				v51.pendingObjectLoading = false
			end
		end
		PalletFiller.updatePalletFillerDeflectorState(p47)
		PalletFiller.updateActionEventTexts(p47)
	end
end
function PalletFiller.onWriteUpdateStream(p52, p53, p54, p55)
	if not p54:getIsServer() then
		local v56 = p52.spec_palletFiller
		if streamWriteBool(p53, bitAND(p55, v56.dirtyFlag) ~= 0) then
			streamWriteBool(p53, v56.palletRow.isMoving)
			for _, v57 in ipairs(v56.palletRow.palletSlots) do
				if streamWriteBool(p53, v57.object ~= nil) then
					NetworkUtil.writeNodeObject(p53, v57.object)
				end
			end
		end
	end
end
function PalletFiller.onUpdate(p58, p59, _, _, _)
	local v60 = p58.spec_palletFiller
	if v60.objectsToLoad ~= nil and #v60.objectsToLoad > 0 then
		for v61 = #v60.objectsToLoad, 1, -1 do
			local v62 = v60.objectsToLoad[v61]
			local v63 = g_currentMission.vehicleSystem:getVehicleByUniqueId(v62.objectUniqueId)
			if v63 ~= nil then
				if not p58:loadPalletFillerPallet(v63, v62) then
					Logging.warning("Failed to load pallet object from savegame. UniqueId: %d SlotIndex: %d", v62.objectUniqueId, v62.slotIndex)
				end
				v60.objectsToLoad[v61] = nil
			end
		end
	end
	if v60.state == PalletFillerState.LOADING and not p58:getIsAnimationPlaying(v60.platformAnimation.name) then
		for v64, _ in pairs(v60.pickupTrigger.triggeredObjects) do
			local v65 = g_currentMission:getNodeObject(v64)
			if v65 ~= nil and (v65:isa(Vehicle) and p58.dynamicMountType == MountableObject.MOUNT_TYPE_NONE) then
				local v66 = true
				for _, v67 in ipairs(v60.palletRow.palletSlots) do
					if v67.object == v65 or v67.interpolationTimer ~= 0 then
						v66 = false
						break
					end
				end
				if v66 then
					p58:loadPalletFillerPallet(v65)
				end
			end
			p58:raiseActive()
		end
	end
	local v68 = p58:getPalletFillerFillStep()
	if v68 ~= nil then
		v60.palletRow.currentTransZ = v68.transZ
		v60.palletRow.currentDischargeNodeIndex = v68.dischargeNodeIndex
		if p58:getCurrentDischargeNodeIndex() ~= v68.dischargeNodeIndex then
			p58:setCurrentDischargeNodeIndex(v68.dischargeNodeIndex)
		end
	end
	local v69 = 0
	local v70 = false
	for _, v71 in ipairs(v60.palletRow.palletSlots) do
		if v71.interpolationTimer == 0 then
			if v71.object ~= nil then
				local v72 = v60.palletRow.currentTransZ + v69
				if v60.state == PalletFillerState.UNLOADING and v60.palletRow.minTransZ ~= v60.palletRow.maxTransZ then
					v72 = v60.palletRow.minTransZ - 0.1
				end
				local _, _, v73 = getTranslation(v71.jointNode)
				local v74 = v72 - v73
				local v75 = (v74 > 0 and math.min or math.max)(v73 + math.sign(v74) * v60.palletRow.moveSpeed * p59, v72)
				local v76 = v60.palletRow.endRotLimit
				local v77 = v60.palletRow.endTransLimit
				if v60.state == PalletFillerState.UNLOADING then
					v76 = v60.palletRow.unloadRotLimit
					v77 = v60.palletRow.unloadTransLimit
				end
				setTranslation(v71.jointNode, 0, 0, v75)
				if v71.jointIndex ~= nil then
					local v78 = v76[1]
					local v79 = v76[2]
					local v80 = v76[3]
					setJointRotationLimit(v71.jointIndex, 0, true, -v78, v78)
					setJointRotationLimit(v71.jointIndex, 1, true, -v79, v79)
					setJointRotationLimit(v71.jointIndex, 2, true, -v80, v80)
					local v81 = v77[1]
					local v82 = v77[2]
					local v83 = v77[3]
					setJointTranslationLimit(v71.jointIndex, 0, true, -v81, v81)
					setJointTranslationLimit(v71.jointIndex, 1, true, 0, v82)
					setJointTranslationLimit(v71.jointIndex, 2, true, -v83, v83)
					setJointFrame(v71.jointIndex, 0, v71.jointNode)
				end
				v69 = v69 + v60.pallet.spacing
				v70 = v70 or math.abs(v74) > 0.01
				if v60.state == PalletFillerState.UNLOADING then
					if v60.palletRow.minTransZ == v60.palletRow.maxTransZ then
						if not p58:getIsAnimationPlaying(v60.platformAnimation.name) then
							p58:unloadPalletFillerPallet(v71.object)
						end
					elseif v75 < v60.palletRow.minTransZ then
						p58:unloadPalletFillerPallet(v71.object)
					end
				end
			end
		elseif v71.object == nil then
			v71.interpolationTimer = 0
		else
			local v84 = v71.interpolationTimer - p59
			v71.interpolationTimer = math.max(v84, 0)
			local v85 = 1 - v71.interpolationTimer / v60.palletRow.pickupTime
			local v86, v87, v88, v89 = MathUtil.slerpQuaternionShortestPath(v71.startQuaternion[1], v71.startQuaternion[2], v71.startQuaternion[3], v71.startQuaternion[4], v71.endQuaternion[1], v71.endQuaternion[2], v71.endQuaternion[3], v71.endQuaternion[4], v85)
			setQuaternion(v71.jointNode, v86, v87, v88, v89)
			local v90, v91, v92 = MathUtil.vector3ArrayLerp(v71.startTranslation, v71.endTranslation, v85)
			setTranslation(v71.jointNode, v90, v91, v92)
			if v71.jointIndex ~= nil then
				local v93, v94, v95 = MathUtil.vector3ArrayLerp(v60.palletRow.startRotLimit, v60.palletRow.endRotLimit, v85)
				setJointRotationLimit(v71.jointIndex, 0, true, -v93, v93)
				setJointRotationLimit(v71.jointIndex, 1, true, -v94, v94)
				setJointRotationLimit(v71.jointIndex, 2, true, -v95, v95)
				local v96, v97, v98 = MathUtil.vector3ArrayLerp(v60.palletRow.startTransLimit, v60.palletRow.endTransLimit, v85)
				setJointTranslationLimit(v71.jointIndex, 0, true, -v96, v96)
				setJointTranslationLimit(v71.jointIndex, 1, true, 0, v97)
				setJointTranslationLimit(v71.jointIndex, 2, true, -v98, v98)
				setJointFrame(v71.jointIndex, 0, v71.jointNode)
			end
			v70 = true
		end
	end
	if v60.platformAnimation.automaticLift then
		local v99 = 0
		for _, v100 in ipairs(v60.palletRow.palletSlots) do
			if v100.interpolationTimer == 0 and v100.object ~= nil then
				v99 = v99 + 1
			end
		end
		if v60.state == PalletFillerState.LOADING then
			if v99 == #v60.palletRow.palletSlots then
				p58:setPalletFillerState(PalletFillerState.IDLE)
			end
		elseif v60.state == PalletFillerState.UNLOADING and (v99 == 0 and next(v60.pickupTrigger.triggeredObjects) == nil) then
			p58:setPalletFillerState(PalletFillerState.IDLE)
		end
	end
	if v70 ~= v60.palletRow.isMoving then
		v60.palletRow.isMoving = v70
		p58:raiseDirtyFlags(v60.dirtyFlag)
		PalletFiller.updatePalletFillerDeflectorState(p58)
		if p58.isClient then
			if v70 then
				g_animationManager:startAnimations(v60.animationNodes)
				g_soundManager:playSample(v60.samples.move)
				return
			end
			g_animationManager:stopAnimations(v60.animationNodes)
			g_soundManager:stopSample(v60.samples.move)
		end
	end
end
function PalletFiller.onUpdateTick(p101, _, _, p102, _)
	local v103 = p101.spec_palletFiller
	if p102 and (p101:getIsTurnedOn() and v103.state == PalletFillerState.IDLE) then
		local v104 = 0
		for _, v105 in ipairs(v103.palletRow.palletSlots) do
			if v105.object ~= nil and v105.object.getFillUnitFreeCapacity ~= nil then
				v104 = v104 + v105.object:getFillUnitFreeCapacity(1)
			end
		end
		if v104 == 0 then
			g_currentMission:showBlinkingWarning(v103.texts.warningPalletFillerNoPalletAvailable, 250)
		end
	end
	for _, v106 in ipairs(v103.palletRow.palletSlots) do
		if v106.objectId ~= nil then
			local v107 = NetworkUtil.getObject(v106.objectId)
			if v107 == nil or not v107:getIsSynchronized() then
				p101:raiseActive()
			else
				v106.object = v107
				v106.objectId = nil
				v106.pendingObjectLoading = false
				PalletFiller.updateActionEventTexts(p101)
			end
		end
	end
end
function PalletFiller.onFinishAnimation(p108, p109)
	if p109 == p108.spec_palletFiller.platformAnimation.name then
		PalletFiller.updatePalletFillerDeflectorState(p108)
	end
end
function PalletFiller.onFoldTimeChanged(p110, _)
	PalletFiller.updateActionEventTexts(p110)
end
function PalletFiller.loadPalletFillerPallet(p111, p112, p113)
	local v114 = p111.spec_palletFiller
	for v115, v116 in ipairs(v114.palletRow.palletSlots) do
		if p113 == nil and v116.object == nil or p113 ~= nil and p113.slotIndex == v115 then
			v116.object = p112
			if p113 == nil or p113.translation == nil then
				setWorldTranslation(v116.jointNode, getWorldTranslation(p112.rootNode))
				setWorldRotation(v116.jointNode, getWorldRotation(p112.rootNode))
			else
				setTranslation(v116.jointNode, p113.translation[1], p113.translation[2], p113.translation[3])
				setRotation(v116.jointNode, p113.rotation[1], p113.rotation[2], p113.rotation[3])
			end
			local v117 = calcDistanceFrom(v116.jointNode, p112.rootNode)
			local v118 = JointConstructor.new()
			v118:setActors(p111.rootNode, p112.rootNode)
			v118:setJointTransforms(v116.jointNode, p112.rootNode)
			v118:setEnableCollision(true)
			local v119 = v114.palletRow.startRotLimit[1]
			local v120 = v114.palletRow.startRotLimit[2]
			local v121 = v114.palletRow.startRotLimit[3]
			v118:setRotationLimit(0, -v119, v119)
			v118:setRotationLimit(1, -v120, v120)
			v118:setRotationLimit(2, -v121, v121)
			local v122 = v114.palletRow.startTransLimit[1]
			local v123 = v114.palletRow.startTransLimit[2]
			local v124 = v114.palletRow.startTransLimit[3]
			v118:setTranslationLimit(0, true, -v122, v122)
			v118:setTranslationLimit(1, true, 0, v123)
			v118:setTranslationLimit(2, true, -v124, v124)
			if p113 == nil then
				v116.startQuaternion = { getQuaternion(v116.jointNode) }
				local v125, _, v126 = worldDirectionToLocal(getParent(v116.jointNode), localDirectionToWorld(p112.rootNode, 0, 0, 1))
				local v127 = MathUtil.vector2Normalize(v125, v126)
				if math.abs(v127) < 1.5707963267948966 then
					v116.endQuaternion = { mathEulerToQuaternion(0, 0, 0) }
				else
					v116.endQuaternion = { mathEulerToQuaternion(0, 3.141592653589793, 0) }
				end
				v116.startTranslation = { getTranslation(v116.jointNode) }
				v116.endTranslation = { 0, 0, v114.palletRow.maxTransZ }
				v116.interpolationDistance = v117
				v116.interpolationTimer = v114.palletRow.pickupTime
			else
				v116.interpolationDistance = v117
				v116.interpolationTimer = 0
			end
			v116.jointIndex = v118:finalize()
			p112:setDynamicMountType(MountableObject.MOUNT_TYPE_DYNAMIC)
			p111:raiseDirtyFlags(v114.dirtyFlag)
			PalletFiller.updateActionEventTexts(p111)
			return true
		end
	end
	return false
end
function PalletFiller.unloadPalletFillerPallet(p128, p129)
	local v130 = p128.spec_palletFiller
	for _, v131 in ipairs(v130.palletRow.palletSlots) do
		if v131.object == p129 then
			v131.object = nil
			v131.interpolationTimer = 0
			if v131.jointIndex ~= nil then
				removeJoint(v131.jointIndex)
				v131.jointIndex = nil
			end
			p129:setDynamicMountType(MountableObject.MOUNT_TYPE_NONE)
			break
		end
	end
	p128:raiseDirtyFlags(v130.dirtyFlag)
	PalletFiller.updateActionEventTexts(p128)
end
function PalletFiller.buyPalletFillerPallets(p132, p133)
	local v134 = p132.spec_palletFiller
	if p132.isServer then
		local v135 = 0
		for _, v136 in ipairs(v134.palletRow.palletSlots) do
			local v137 = v134.palletRow.currentTransZ + v135
			setTranslation(v136.jointNode, 0, 0, v137)
			if v136.object == nil then
				v136.pendingObjectLoading = true
				local v138 = VehicleLoadingData.new()
				v138:setFilename(v134.pallet.filename)
				v138:setSpawnNode(v136.jointNode)
				v138:setIgnoreShopOffset(true)
				v138:setPropertyState(VehiclePropertyState.OWNED)
				v138:setOwnerFarmId(p132:getOwnerFarmId())
				v138:load(PalletFiller.onCreatePalletFinished, p132, {
					["palletSlot"] = v136
				})
			elseif v136.jointIndex ~= nil then
				setJointFrame(v136.jointIndex, 0, v136.jointNode)
			end
			v135 = v135 + v134.pallet.spacing
		end
	else
		for _, v139 in ipairs(v134.palletRow.palletSlots) do
			if v139.object == nil then
				v139.pendingObjectLoading = true
			end
		end
		if p133 ~= true then
			g_client:getServerConnection():sendEvent(PalletFillerBuyPalletEvent.new(p132))
		end
	end
end
function PalletFiller.onCreatePalletFinished(p140, p141, p142, p143)
	local v144 = p140.spec_palletFiller
	p143.palletSlot.pendingObjectLoading = false
	if p142 == VehicleLoadingState.OK and #p141 >= 1 then
		local v145 = p141[1]
		v145:removeFromPhysics()
		v145:addToPhysics()
		if not p140:loadPalletFillerPallet(v145, {
			["slotIndex"] = p143.palletSlot.index,
			["translation"] = { getTranslation(p143.palletSlot.jointNode) },
			["rotation"] = { getRotation(p143.palletSlot.jointNode) }
		}) then
			v145:delete()
			return
		end
		g_currentMission:addMoney(-v144.pallet.storeItem.price, p140:getOwnerFarmId(), MoneyType.PURCHASE_PALLETS)
		g_currentMission:addMoneyChange(-v144.pallet.storeItem.price, p140:getOwnerFarmId(), MoneyType.PURCHASE_PALLETS, false)
		local v146 = false
		for _, v147 in ipairs(v144.palletRow.palletSlots) do
			v146 = v146 or v147.object == nil
		end
		if not v146 then
			g_currentMission:showMoneyChange(MoneyType.PURCHASE_PALLETS)
		end
	end
end
function PalletFiller.getCanChangePalletFillerState(p148, p149)
	local v150 = p148.spec_palletFiller
	if v150.platformAnimation.automaticLift and v150.state == PalletFillerState.UNLOADING then
		return false
	end
	local v151 = false
	local v152 = false
	for _, v153 in ipairs(v150.palletRow.palletSlots) do
		if v153.object == nil then
			v152 = true
		else
			v151 = true
		end
	end
	if v150.state == PalletFillerState.UNLOADING and v151 then
		return false
	end
	if v150.state == PalletFillerState.IDLE and p149 == PalletFillerState.UNLOADING then
		if not v151 then
			return false
		end
		if v150.platformAnimation.lowerToUnload and not p148:getIsLowered(true) then
			return false, string.format(g_i18n:getText("warning_lowerImplementFirst"), p148:getName())
		end
	end
	if v150.state == PalletFillerState.IDLE and (p149 == PalletFillerState.LOADING and not v152) then
		return false
	end
	if p149 ~= PalletFillerState.IDLE then
		local v154 = p148:getFoldAnimTime()
		if v154 < v150.foldable.minLimit or v150.foldable.maxLimit < v154 then
			return false
		end
	end
	return true
end
function PalletFiller.getCanBuyPalletFillerPallets(p155)
	local v156 = p155.spec_palletFiller
	local v157 = p155:getFoldAnimTime()
	if v157 < v156.foldable.minLimit or v156.foldable.maxLimit < v157 then
		return false, string.format(g_i18n:getText("warning_firstUnfoldTheTool"), p155:getFullName())
	else
		return true
	end
end
function PalletFiller.setPalletFillerState(p158, p159, p160, p161)
	local v162 = p158.spec_palletFiller
	v162.state = p159
	local v163 = p158:getAnimationTime(v162.platformAnimation.name)
	local v164 = v162.platformAnimation.middleTime
	local v165 = v162.state == PalletFillerState.LOADING and 0 or (v162.state == PalletFillerState.UNLOADING and 1 or v164)
	if v165 ~= v163 then
		p158:setAnimationStopTime(v162.platformAnimation.name, v165)
		local v166 = v162.platformAnimation.name
		local v167 = v162.platformAnimation.speed
		local v168 = v165 - v163
		p158:playAnimation(v166, v167 * math.sign(v168), v163, true)
		if p160 == true then
			AnimatedVehicle.updateAnimationByName(p158, v162.platformAnimation.name, 99999, true)
		end
	end
	PalletFiller.updateActionEventTexts(p158)
	PalletFillerStateEvent.sendEvent(p158, p159, p161)
end
function PalletFiller.updatePalletFillerDeflectorState(p169)
	local v170 = p169.spec_palletFiller
	local v171 = p169:getAnimationTime(v170.platformAnimation.name) - v170.platformAnimation.middleTime
	local v172 = (math.abs(v171) > 0.01 or v170.palletRow.isMoving) and true or false
	if v172 ~= v170.fillDeflectorAnimation.state then
		p169:setPalletFillerDeflectorState(v172)
	end
end
function PalletFiller.setPalletFillerDeflectorState(p173, p174, p175)
	local v176 = p173.spec_palletFiller
	v176.fillDeflectorAnimation.state = p174
	local v177 = v176.fillDeflectorAnimation.state and 1 or -1
	p173:playAnimation(v176.fillDeflectorAnimation.name, v176.fillDeflectorAnimation.speed * v177, p173:getAnimationTime(v176.fillDeflectorAnimation.name), true)
	if p175 == true then
		AnimatedVehicle.updateAnimationByName(p173, v176.fillDeflectorAnimation.name, 99999, true)
	end
end
function PalletFiller.getPalletFillerFillStep(p178)
	local v179 = p178.spec_palletFiller
	for _, v180 in ipairs(v179.palletRow.fillSteps) do
		local v181 = v179.palletRow.palletSlots[v180.palletIndex]
		if v181.object ~= nil and v181.object:getFillUnitFreeCapacity(1) > 0 then
			return v180
		end
	end
	for _, v182 in ipairs(v179.palletRow.fillSteps) do
		if v179.palletRow.palletSlots[v182.palletIndex].object == nil then
			return v182
		end
	end
	return v179.palletRow.fillSteps[1]
end
function PalletFiller.getPalletFillerMovementDirection(p183)
	local v184 = p183.spec_palletFiller
	return v184.state == PalletFillerState.LOADING and 1 or (v184.state == PalletFillerState.UNLOADING and -1 or 0)
end
function PalletFiller.getCanToggleDischargeToObject(_, _)
	return false
end
function PalletFiller.getCanToggleDischargeToGround(_, _)
	return false
end
function PalletFiller.removeFromPhysics(p185, p186)
	local v187 = p185.spec_palletFiller
	if v187.palletRow ~= nil then
		for _, v188 in ipairs(v187.palletRow.palletSlots) do
			if v188.object ~= nil then
				p185:unloadPalletFillerPallet(v188.object)
			end
		end
	end
	return p186(p185)
end
function PalletFiller.getIsFoldAllowed(p189, p190, p191, p192)
	local v193 = p189.spec_palletFiller
	if v193.state ~= PalletFillerState.IDLE then
		return false, g_i18n:getText("warning_palletFillerPlatformLowered")
	end
	if v193.palletRow ~= nil then
		for _, v194 in ipairs(v193.palletRow.palletSlots) do
			if v194.object ~= nil or v194.pendingObjectLoading then
				return false, g_i18n:getText("warning_palletFillerNoEmpty")
			end
		end
	end
	return p190(p189, p191, p192)
end
function PalletFiller.getFillLevelInformation(p195, p196, p197)
	p196(p195, p197)
	local v198 = p195.spec_palletFiller
	local v199 = 0
	local v200 = 0
	local v201 = nil
	for _, v202 in ipairs(v198.palletRow.palletSlots) do
		if v202.object ~= nil and v202.object.getFillUnitFillLevel ~= nil then
			local v203 = v202.object:getFillUnitFillType(1)
			if v203 == FillType.UNKNOWN then
				v203 = v201
			end
			v199 = v199 + v202.object:getFillUnitFillLevel(1)
			v200 = v200 + v202.object:getFillUnitCapacity(1)
			v201 = v203
		end
	end
	if v200 > 0 then
		p197:addFillLevel(v201 or FillType.UNKNOWN, v199, v200)
	end
end
function PalletFiller.getCanAIImplementContinueWork(p204, p205, p206)
	local v207 = p204.spec_palletFiller
	local v208 = 0
	local v209 = 0
	for _, v210 in ipairs(v207.palletRow.palletSlots) do
		if v210.object ~= nil and v210.object.getFillUnitFillLevel ~= nil then
			v208 = v208 + v210.object:getFillUnitFreeCapacity(1)
			v209 = v209 + 1
		end
	end
	if v208 == 0 then
		if v209 > 0 then
			return false, true, AIMessageErrorPalletsFull.new()
		else
			return false, true, AIMessageErrorNoPalletsLoaded.new()
		end
	else
		return p205(p204, p206)
	end
end
function PalletFiller.verifyCombine(p211, p212, p213, p214, ...)
	local v215 = p211.spec_palletFiller
	local v216 = 0
	for _, v217 in ipairs(v215.palletRow.palletSlots) do
		if v217.object ~= nil and v217.object.getFillUnitFillType ~= nil then
			if p214 ~= FillType.UNKNOWN and not v217.object:getFillUnitAllowsFillType(1, p214) then
				return nil, p211, v217.object:getFillUnitFillType(1)
			end
			v216 = v216 + v217.object:getFillUnitFreeCapacity(1)
		end
	end
	if v216 == 0 then
		return nil
	else
		return p212(p211, p213, p214, ...)
	end
end
function PalletFiller.onRegisterActionEvents(p218, _, p219)
	if p219 and p218.isClient then
		local v220 = p218.spec_palletFiller
		p218:clearActionEventsTable(v220.actionEvents)
		if v220.platformAnimation.name ~= nil then
			local _, v221 = p218:addPoweredActionEvent(v220.actionEvents, InputAction.IMPLEMENT_EXTRA3, p218, PalletFiller.actionEventLowerPlatformLoad, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v221, GS_PRIO_HIGH)
			local _, v222 = p218:addPoweredActionEvent(v220.actionEvents, InputAction.IMPLEMENT_EXTRA4, p218, PalletFiller.actionEventLowerPlatformUnload, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v222, GS_PRIO_HIGH)
			if v220.pallet.storeItem ~= nil then
				local _, v223 = p218:addPoweredActionEvent(v220.actionEvents, InputAction.PALLET_FILLER_BUY_PALLETS, p218, PalletFiller.actionEventBuyPallets, false, true, false, true, nil)
				g_inputBinding:setActionEventTextPriority(v223, GS_PRIO_HIGH)
				g_inputBinding:setActionEventText(v223, g_i18n:getText("action_palletFillerBuyPallets"))
			end
			PalletFiller.updateActionEventTexts(p218)
		end
	end
end
function PalletFiller.updateActionEventTexts(p224)
	local v225 = p224.spec_palletFiller
	local v226 = v225.actionEvents[InputAction.IMPLEMENT_EXTRA3]
	if v226 ~= nil then
		local v227 = nil
		if v225.state == PalletFillerState.IDLE then
			local v228, v229 = p224:getCanChangePalletFillerState(PalletFillerState.LOADING)
			if v228 or v229 ~= nil then
				v227 = g_i18n:getText("action_palletFillerLoad")
			end
		elseif v225.state == PalletFillerState.LOADING then
			local v230, v231 = p224:getCanChangePalletFillerState(PalletFillerState.IDLE)
			if v230 or v231 ~= nil then
				v227 = g_i18n:getText("action_palletFillerIdle")
			end
		end
		if v227 == nil then
			g_inputBinding:setActionEventActive(v226.actionEventId, false)
		else
			g_inputBinding:setActionEventText(v226.actionEventId, v227)
			g_inputBinding:setActionEventActive(v226.actionEventId, true)
		end
	end
	local v232 = v225.actionEvents[InputAction.IMPLEMENT_EXTRA4]
	if v232 ~= nil then
		local v233 = nil
		if v225.state == PalletFillerState.IDLE then
			local v234, v235 = p224:getCanChangePalletFillerState(PalletFillerState.UNLOADING)
			if v234 or v235 ~= nil then
				v233 = g_i18n:getText("action_palletFillerUnload")
			end
		elseif v225.state == PalletFillerState.UNLOADING then
			local v236, v237 = p224:getCanChangePalletFillerState(PalletFillerState.IDLE)
			if v236 or v237 ~= nil then
				v233 = g_i18n:getText("action_palletFillerIdle")
			end
		end
		if v233 == nil then
			g_inputBinding:setActionEventActive(v232.actionEventId, false)
		else
			g_inputBinding:setActionEventText(v232.actionEventId, v233)
			g_inputBinding:setActionEventActive(v232.actionEventId, true)
		end
	end
	local v238 = v225.actionEvents[InputAction.PALLET_FILLER_BUY_PALLETS]
	if v238 ~= nil then
		local v239 = 0
		for _, v240 in ipairs(v225.palletRow.palletSlots) do
			if v240.object == nil then
				v239 = v239 + 1
			end
		end
		local v241 = g_inputBinding
		local v242 = v238.actionEventId
		local v243
		if v225.state == PalletFillerState.IDLE then
			v243 = v239 > 0
		else
			v243 = false
		end
		v241:setActionEventActive(v242, v243)
	end
end
function PalletFiller.actionEventLowerPlatformLoad(p244, _, _, _, _)
	local v245 = p244.spec_palletFiller.state == PalletFillerState.IDLE and PalletFillerState.LOADING or PalletFillerState.IDLE
	local v246, v247 = p244:getCanChangePalletFillerState(v245)
	if v246 then
		p244:setPalletFillerState(v245)
	elseif v247 ~= nil then
		g_currentMission:showBlinkingWarning(v247, 2000)
	end
end
function PalletFiller.actionEventLowerPlatformUnload(p248, _, _, _, _)
	local v249 = p248.spec_palletFiller.state == PalletFillerState.IDLE and PalletFillerState.UNLOADING or PalletFillerState.IDLE
	local v250, v251 = p248:getCanChangePalletFillerState(v249)
	if v250 then
		p248:setPalletFillerState(v249)
	elseif v251 ~= nil then
		g_currentMission:showBlinkingWarning(v251, 2000)
	end
end
function PalletFiller.actionEventBuyPallets(p_u_252, _, _, _, _)
	local v253 = p_u_252.spec_palletFiller
	local v254, v255 = p_u_252:getCanBuyPalletFillerPallets()
	if v254 then
		local v256 = 0
		for _, v257 in ipairs(v253.palletRow.palletSlots) do
			if v257.object == nil then
				v256 = v256 + 1
			end
		end
		local v258 = v253.pallet.storeItem.price * v256
		YesNoDialog.show(function(_, p259)
			-- upvalues: (copy) p_u_252
			if p259 then
				p_u_252:buyPalletFillerPallets()
			end
		end, p_u_252, string.format(g_i18n:getText("ui_palletFillerBuyPalletsText"), v256, g_i18n:formatMoney(v258)), p_u_252:getFullName())
	elseif v255 ~= nil then
		g_currentMission:showBlinkingWarning(v255, 2000)
	end
end
function PalletFiller.onObjectDeleted(p260, p261)
	p260.spec_palletFiller.pickupTrigger.triggeredObjects[p261.rootNode] = nil
end

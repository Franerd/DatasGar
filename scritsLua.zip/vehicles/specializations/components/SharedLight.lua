SharedLight = {}
SharedLight.FS22_RENAMED_LIGHTS = {
	["frontLight_01"] = "frontLight01",
	["frontLightCone_01"] = "frontLight02",
	["frontLightOval_01"] = "frontLight03",
	["frontLightOval_02"] = "frontLight04",
	["frontLightOval_03"] = "frontLight05",
	["frontLightRectangle_01"] = "frontLight06White",
	["frontLightRectangle_01Orange"] = "frontLight06Orange",
	["frontLightRectangle_02"] = "frontLight07",
	["rear2ChamberLed_01"] = "rearLight01",
	["rear2ChamberLight_02"] = "rearLight02",
	["rear2ChamberLight_03"] = "rearLight03",
	["rear2ChamberLight_04"] = "rearLight04",
	["rear2ChamberLight_05"] = "rearLight05",
	["rear2ChamberLight_06"] = "rearLight06",
	["rear2ChamberLight_07"] = "rearLight07",
	["rear3ChamberLight_01"] = "rearLight08",
	["rear3ChamberLight_02"] = "rearLight09",
	["rear3ChamberLight_03"] = "rearLight10",
	["rear3ChamberLight_04"] = "rearLight11",
	["rear3ChamberLight_05"] = "rearLight12",
	["rear4ChamberLight_01"] = "rearLight13",
	["rear4ChamberLight_02"] = "rearLight14",
	["rear5ChamberLight_01"] = "rearLight15",
	["rear5ChamberLight_02"] = "rearLight16",
	["rearLEDLight_01"] = "rearLight17",
	["rearLight_01"] = "rearLight18",
	["rearLightCircle_01Orange"] = "rearLight19Orange",
	["rearLightCircle_01Red"] = "rearLight19Red",
	["rearLightCircleLEDRed_01"] = "rearLight20",
	["rearLightCircleOrange_01"] = "rearLight21Orange",
	["rearLightCircleRed_01"] = "rearLight21Red",
	["rearLightCircleWhite_02"] = "rearLight22White",
	["rearLightCircleRed_02"] = "rearLight22Red",
	["rearLightCircleOrange_02"] = "rearLight22Orange",
	["rearLightOvalLEDWhite_01"] = "rearLight22White",
	["rearLightOvalLEDRed_01"] = "rearLight23Red",
	["rearLightOvalLEDOrange_01"] = "rearLight23Orange",
	["rearLightOvalLEDChromeWhite_01"] = "rearLight24",
	["rearLightOvalLEDRed_02"] = "rearLight25",
	["rearLightOvalWhite_01"] = "rearLight26White",
	["rearLightOvalRed_01"] = "rearLight26Red",
	["rearLightOvalOrange_01"] = "rearLight26Orange",
	["rearLightSquare_01Orange"] = "rearLight27Orange",
	["rearMultipointLight_04"] = "rearLight28",
	["rearMultipointLight_05"] = "rearLight29",
	["rearMultipointLEDLight_01"] = "rearLight30",
	["rearMultipointLight_01"] = "rearLight31",
	["rearMultipointLight_02"] = "rearLight32",
	["rearMultipointLight_03"] = "rearLight33",
	["rear3ChamberLight_06"] = "rearLight34",
	["rear3ChamberLight_07"] = "rearLight35",
	["rear2ChamberLight_01"] = "rearLight36",
	["sideMarker_01"] = "sideMarker01",
	["sideMarker_02"] = "sideMarker02",
	["sideMarker_03"] = "sideMarker03",
	["sideMarker_04"] = "sideMarker04",
	["sideMarker_05"] = "sideMarker05",
	["sideMarker_06"] = "sideMarker06",
	["sideMarker_04White"] = "sideMarker05White",
	["sideMarker_04Red"] = "sideMarker05Red",
	["sideMarker_04Orange"] = "sideMarker05Orange",
	["sideMarker_05White"] = "sideMarker06White",
	["sideMarker_05Orange"] = "sideMarker06Orange",
	["sideMarker_05Red"] = "sideMarker06Red",
	["sideMarker_06White"] = "sideMarker07White",
	["sideMarker_06Orange"] = "sideMarker07Orange",
	["sideMarker_06Red"] = "sideMarker07Red",
	["sideMarker_07White"] = "sideMarker08White",
	["sideMarker_07Orange"] = "sideMarker08Orange",
	["sideMarker_08White"] = "sideMarker09White",
	["sideMarker_08Orange"] = "sideMarker09Orange",
	["sideMarker_09White"] = "sideMarker10White",
	["sideMarker_09Orange"] = "sideMarker10Orange",
	["sideMarker_09Red"] = "sideMarker10Red",
	["sideMarker_10Orange"] = "sideMarker11Orange",
	["sideMarker_10Red"] = "sideMarker11Red",
	["sideMarker_14White"] = "sideMarker14White",
	["turnLight_01"] = "turnLight01",
	["sideMarker_09Orange_turn"] = "turnLight02",
	["rear2ChamberTurnLed_01"] = "turnLight03",
	["workingLightCircle_01"] = "workingLight01",
	["workingLightCircle_02"] = "workingLight02",
	["workingLightOval_01"] = "workingLight03",
	["workingLightOval_02"] = "workingLight04",
	["workingLightOval_03"] = "workingLight05",
	["workingLightOval_04"] = "workingLight06",
	["workingLightOval_05"] = "workingLight07",
	["workingLightSquare_01"] = "workingLight08",
	["workingLightSquare_02"] = "workingLight09",
	["workingLightSquare_03"] = "workingLight10",
	["workingLightSquare_04"] = "workingLight11",
	["rearPlateNumberLight_01"] = "plateNumberLight01",
	["hellaRear2ChamberLightLED_01_left"] = "hellaRearLight01_left",
	["hellaRear2ChamberLightLED_01_right"] = "hellaRearLight01_right",
	["hellaTurnlight_01_left"] = "hellaTurnlight01_left",
	["hellaTurnlight_01_right"] = "hellaTurnlight01_right",
	["hellaWorkingLightOval_01_back"] = "hellaWorkingLight01",
	["hellaWorkingLightOval_01_front"] = "hellaWorkingLight01",
	["hellaWorkingLightRound_01_back"] = "hellaWorkingLight02",
	["hellaWorkingLightRound_01_front"] = "hellaWorkingLight02",
	["hellaWorkingLightRound_02_back"] = "hellaWorkingLight03",
	["hellaWorkingLightRound_02_front"] = "hellaWorkingLight03",
	["hellaWorkingLightSquare_01_front"] = "hellaWorkingLight05",
	["hellaWorkingLightSquare_01_back"] = "hellaWorkingLight05",
	["hellaWorkingLightSquare_01_reverse"] = "hellaWorkingLight05",
	["hellaWorkingLightSquare_02_front"] = "hellaWorkingLight06",
	["hellaWorkingLightSquare_02_back"] = "hellaWorkingLight06"
}
local v_u_1 = Class(SharedLight)
function SharedLight.new(p2, p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = p4 or v_u_1
	local v6 = setmetatable({}, v5)
	v6.vehicle = p2
	v6.staticLights = p3
	v6.reverseLight = false
	v6.turnLightLeft = false
	v6.turnLightRight = false
	return v6
end
function SharedLight.delete(p7)
	if p7.xmlFile ~= nil then
		p7.xmlFile:delete()
		p7.xmlFile = nil
	end
	if p7.node ~= nil then
		delete(p7.node)
		p7.node = nil
	end
	if p7.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(p7.sharedLoadRequestId)
		p7.sharedLoadRequestId = nil
	end
end
function SharedLight.setCallback(p8, p9, p10)
	p8.callback = p9
	p8.callbackTarget = p10
end
function SharedLight.onFinished(p11, p12)
	if p11.callback ~= nil then
		if p11.callbackTarget ~= nil then
			p11.callback(p11.callbackTarget, p12)
			return
		end
		p11.callback(p12)
	end
end
function SharedLight.setRotationNodes(p13, p14)
	p13.rotationNodes = p14
end
function SharedLight.setLightTypes(p15, p16, p17)
	p15.lightTypes = p16
	p15.excludedLightTypes = p17
end
function SharedLight.loadFromVehicleXML(p_u_18, p19, p20, p_u_21)
	local v22 = p_u_18.vehicle.xmlFile
	local v23 = v22:getValue(p19 .. "#filename")
	if v23 ~= nil then
		local v24 = Utils.getFilename(v23, p20)
		local v25 = v22:getValue(p19 .. "#linkNode", "0>", p_u_18.vehicle.components, p_u_18.vehicle.i3dMappings)
		if v25 == nil then
			Logging.xmlWarning(v22, "Missing light linkNode in \'%s\'!", p19)
			return
		end
		local v26, v27, v28 = getReferenceInfo(v25)
		if v26 and v28 then
			local v29 = Utils.getFilenameInfo(v24, true)
			local v30 = Utils.getFilenameInfo(v27, true)
			if v29 ~= v30 then
				Logging.xmlWarning(v22, "Shared light \'%s\' loading different file from XML compared to i3D. (XML: %s vs i3D: %s)", getName(v25), v29, v30)
			end
			Logging.xmlWarning(v22, "Shared light link node \'%s\' is a runtime loaded reference. Please load functional lights via XML and non-functional (e.g. reflectors) as i3D reference, but not both!", getName(v25))
			return
		end
		if not getVisibility(v25) then
			Logging.xmlWarning(v22, "Shared light link node \'%s\' is hidden!", getName(v25))
			return
		end
		local v31 = {}
		for _, v32 in v22:iterator(p19 .. ".rotationNode") do
			local v33 = v22:getValue(v32 .. "#name")
			if v33 ~= nil then
				v31[v33] = v22:getValue(v32 .. "#rotation", nil, true)
			end
		end
		local v34 = v22:getValue(p19 .. "#lightTypes", nil, true)
		local v35 = v22:getValue(p19 .. "#excludedLightTypes", nil, true)
		p_u_18.reverseLight = v22:getValue(p19 .. "#reverseLight", p_u_18.reverseLight)
		p_u_18.turnLightLeft = v22:getValue(p19 .. "#turnLightLeft", p_u_18.turnLightLeft)
		p_u_18.turnLightRight = v22:getValue(p19 .. "#turnLightRight", p_u_18.turnLightRight)
		p_u_18.functionMappingData = StaticLightCompound.loadFunctionMappingData(v22, p19)
		p_u_18.additionalAttributes = {}
		p_u_18.vehicle:loadAdditionalLightAttributesFromXML(v22, p19, p_u_18.additionalAttributes)
		p_u_18:setRotationNodes(v31)
		p_u_18:setLightTypes(v34, v35)
		p_u_18:setCallback(function(p36)
			-- upvalues: (copy) p_u_21, (copy) p_u_18
			p_u_21(p36, p36 and p_u_18 or nil)
		end)
		p_u_18:loadFromXML(v25, v24, p20)
	end
end
function SharedLight.loadFromXML(p37, p38, p39, p40)
	p37.xmlFile = XMLFile.loadIfExists("sharedLight", p39, SharedLight.xmlSchema)
	if p37.xmlFile == nil then
		for v41, v42 in pairs(SharedLight.FS22_RENAMED_LIGHTS) do
			if p39:find(v41) then
				local v43 = p39:gsub(v41, v42)
				if fileExists(v43) then
					if p37.vehicle == nil then
						Logging.warning("Light \'%s\' has been renamed to \'%s\' in \'%s\'!", v41, v42)
					else
						Logging.xmlWarning(p37.vehicle.xmlFile, "Light has been renamed from \'%s\' to \'%s\'!", v41, v42)
					end
					p37:onFinished(false)
					return false
				end
			end
		end
		if p37.vehicle == nil then
			Logging.warning("Unable to load shared lights from xml \'%s\'", p39)
		else
			Logging.xmlWarning(p37.vehicle.xmlFile, "Unable to load shared lights from xml \'%s\'", p39)
		end
		p37:onFinished(false)
		return false
	end
	local v44 = p37.xmlFile:getValue("light.filename")
	if v44 ~= nil then
		p37.filename = Utils.getFilename(v44, p40)
		p37.linkNode = p38
		if p37.vehicle == nil or p37.vehicle.loadSubSharedI3DFile == nil then
			p37.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(p37.filename, false, false, p37.onI3DLoaded, p37, nil)
		else
			p37.sharedLoadRequestId = p37.vehicle:loadSubSharedI3DFile(p37.filename, false, false, p37.onI3DLoaded, p37, nil)
		end
		return true
	end
	Logging.xmlWarning(p37.xmlFile, "Missing light i3d filename!")
	p37.xmlFile:delete()
	p37.xmlFile = nil
	p37:onFinished(false)
	return false
end
function SharedLight.onI3DLoaded(p_u_45, p_u_46, _, _)
	if p_u_46 ~= 0 then
		p_u_45.node = p_u_45.xmlFile:getValue("light.rootNode#node", "0", p_u_46)
		if p_u_45.node ~= nil then
			if p_u_45.reverseLight then
				StaticLight.loadLightsFromXML(p_u_45.staticLights.reverseLights, p_u_45.xmlFile, "light.defaultLight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			elseif p_u_45.turnLightLeft then
				StaticLight.loadLightsFromXML(p_u_45.staticLights.turnLightsLeft, p_u_45.xmlFile, "light.defaultLight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			elseif p_u_45.turnLightRight then
				StaticLight.loadLightsFromXML(p_u_45.staticLights.turnLightsRight, p_u_45.xmlFile, "light.defaultLight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			else
				StaticLight.loadLightsFromXML(p_u_45.staticLights.defaultLights, p_u_45.xmlFile, "light.defaultLight", p_u_45.vehicle, p_u_46, nil, true, p_u_45)
			end
			StaticLight.loadLightsFromXML(p_u_45.staticLights.topLights, p_u_45.xmlFile, "light.topLight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			StaticLight.loadLightsFromXML(p_u_45.staticLights.bottomLights, p_u_45.xmlFile, "light.bottomLight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			StaticLight.loadLightsFromXML(p_u_45.staticLights.brakeLights, p_u_45.xmlFile, "light.brakeLight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			StaticLight.loadLightsFromXML(p_u_45.staticLights.reverseLights, p_u_45.xmlFile, "light.reverseLight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			StaticLight.loadLightsFromXML(p_u_45.staticLights.dayTimeLights, p_u_45.xmlFile, "light.dayTimeLight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			StaticLight.loadLightsFromXML(p_u_45.staticLights.turnLightsLeft, p_u_45.xmlFile, "light.turnLightLeft", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			StaticLight.loadLightsFromXML(p_u_45.staticLights.turnLightsRight, p_u_45.xmlFile, "light.turnLightRight", p_u_45.vehicle, p_u_46, nil, false, p_u_45)
			if p_u_45.rotationNodes ~= nil then
				p_u_45.xmlFile:iterate("light.rotationNode", function(_, p47)
					-- upvalues: (copy) p_u_45, (copy) p_u_46
					local v48 = p_u_45.xmlFile:getValue(p47 .. "#name")
					if v48 ~= nil then
						local v49 = p_u_45.xmlFile:getValue(p47 .. "#node", nil, p_u_46)
						if p_u_45.rotationNodes[v48] ~= nil then
							local v50 = setRotation
							local v51 = p_u_45.rotationNodes[v48]
							v50(v49, unpack(v51))
						end
					end
				end)
			end
			if p_u_45.xmlFile:hasProperty("light.staticLightCompound") then
				local v52 = StaticLightCompound.new(p_u_45.vehicle)
				if v52:loadFromXML(p_u_45.xmlFile, "light.staticLightCompound", p_u_46, nil, nil, p_u_45) then
					v52:setLightTypes(p_u_45.lightTypes, p_u_45.excludedLightTypes)
					v52:setOverwriteSettings(p_u_45.turnLightLeft, p_u_45.turnLightRight, p_u_45.reverseLight)
					p_u_45.staticLightCompound = v52
				end
			end
			if p_u_45.xmlFile:hasProperty("light.baseMaterial") then
				local v53 = VehicleMaterial.new(p_u_45.vehicle.baseDirectory)
				if v53:loadFromXML(p_u_45.xmlFile, "light.baseMaterial", p_u_45.vehicle.customEnvironment) then
					v53:apply(p_u_45.node, "sharedLightBase_mat")
				end
			end
			if p_u_45.xmlFile:hasProperty("light.glassMaterial") then
				local v54 = VehicleMaterial.new(p_u_45.vehicle.baseDirectory)
				if v54:loadFromXML(p_u_45.xmlFile, "light.glassMaterial", p_u_45.vehicle.customEnvironment) then
					v54:apply(p_u_45.node, "sharedLightGlass_mat")
				end
			end
			link(p_u_45.linkNode, p_u_45.node)
		end
		delete(p_u_46)
	end
	p_u_45.xmlFile:delete()
	p_u_45.xmlFile = nil
	p_u_45:onFinished(p_u_45.node ~= nil)
end
function SharedLight.consoleCommandDebug(_, p55, p56, p57, p58, p59, p60, p61, p62)
	if SharedLight.debugRootNode == nil then
		SharedLight.debugRootNode = createTransformGroup("sharedLightDebugRoot")
		link(getRootNode(), SharedLight.debugRootNode)
		local v63, v64, v65 = g_localPlayer:getPosition()
		local v66, v67 = g_localPlayer:getCurrentFacingDirection()
		local v68 = v63 + v66 * 4
		local v69 = v65 + v67 * 4
		local v70 = MathUtil.getYRotationFromDirection(v66, v67)
		setWorldTranslation(SharedLight.debugRootNode, v68, v64, v69)
		setWorldRotation(SharedLight.debugRootNode, 0, v70, 0)
	end
	if SharedLight.debugSharedLights ~= nil then
		for _, v71 in ipairs(SharedLight.debugSharedLights) do
			v71:delete()
			delete(v71.linkNode)
		end
	end
	SharedLight.debugSharedLights = {}
	SharedLight.debugStaticLights = {}
	SharedLight.debugStaticLights.defaultLights = {}
	SharedLight.debugStaticLights.topLights = {}
	SharedLight.debugStaticLights.bottomLights = {}
	SharedLight.debugStaticLights.brakeLights = {}
	SharedLight.debugStaticLights.reverseLights = {}
	SharedLight.debugStaticLights.dayTimeLights = {}
	SharedLight.debugStaticLights.turnLightsLeft = {}
	SharedLight.debugStaticLights.turnLightsRight = {}
	local v_u_72 = {
		["getIsPowered"] = function(...)
			return true
		end,
		["getIsInShowroom"] = function(...)
			return false
		end,
		["getIsLightActive"] = function(...)
			return true
		end,
		["getIsActiveForLights"] = function(...)
			return true
		end,
		["getStaticLightFromNode"] = function(...)
			return nil
		end,
		["spec_lights"] = {}
	}
	local v_u_73 = v_u_72.spec_lights
	v_u_73.topLightsVisibility = false
	v_u_73.maxLightState = Lights.LIGHT_TYPE_HIGHBEAM
	v_u_73.additionalLightTypes = {}
	v_u_73.additionalLightTypes.bottomLight = v_u_73.maxLightState + 1
	v_u_73.additionalLightTypes.topLight = v_u_73.maxLightState + 2
	v_u_73.additionalLightTypes.brakeLight = v_u_73.maxLightState + 3
	v_u_73.additionalLightTypes.turnLightLeft = v_u_73.maxLightState + 4
	v_u_73.additionalLightTypes.turnLightRight = v_u_73.maxLightState + 5
	v_u_73.additionalLightTypes.turnLightAny = v_u_73.maxLightState + 6
	v_u_73.additionalLightTypes.reverseLight = v_u_73.maxLightState + 7
	v_u_73.additionalLightTypes.interiorLight = v_u_73.maxLightState + 8
	local v74 = {
		[Lights.LIGHT_TYPE_DEFAULT] = string.lower(p55 or "false") == "true",
		[v_u_73.additionalLightTypes.brakeLight] = string.lower(p56 or "false") == "true",
		[Lights.LIGHT_TYPE_HIGHBEAM] = string.lower(p57 or "false") == "true",
		[Lights.LIGHT_TYPE_WORK_BACK] = string.lower(p58 or "false") == "true",
		[Lights.LIGHT_TYPE_WORK_FRONT] = string.lower(p59 or "false") == "true",
		[v_u_73.additionalLightTypes.turnLightLeft] = string.lower(p60 or "false") == "true",
		[v_u_73.additionalLightTypes.turnLightRight] = string.lower(p61 or "false") == "true",
		[v_u_73.additionalLightTypes.reverseLight] = string.lower(p62 or "false") == "true"
	}
	local v_u_75 = 0
	for v76, v77 in pairs(v74) do
		if v77 then
			v_u_75 = bitOR(v_u_75, bitShiftLeft(1, v76))
		end
	end
	local v78 = Files.getFilesRecursive(getAppBasePath() .. "data/shared/assets/lights")
	table.sort(v78, function(p79, p80)
		return p79.path < p80.path
	end)
	local v_u_81 = 0
	local v_u_82 = 0
	local v83 = nil
	local v84 = nil
	local v85 = 0
	local v_u_86 = 0
	local v_u_87 = 0
	local v88 = 0
	for _, v89 in ipairs(v78) do
		if not v89.isDirectory and v89.filename:contains(".xml") then
			v_u_81 = v_u_81 + 1
			v_u_82 = v_u_82 + 1
			local v90 = createTransformGroup("linkNode")
			link(SharedLight.debugRootNode, v90)
			local v91 = v89.filename
			local v92 = string.gsub(v91, "White", "")
			local v93 = string.gsub(v92, "Orange", "")
			local v94 = string.gsub(v93, "Red", "")
			local v95 = string.gsub(v94, "Reverse", "")
			local v96 = string.gsub(v95, ".xml", "")
			local v97 = string.split(v96, "_")[1]
			local v98 = string.gsub(v97, "%d", "")
			local v99 = v89.path:split(v89.filename)[1]
			local v100
			if v99 == v83 and v98 == v84 then
				v100 = v88
				v98 = v84
				v99 = v83
			else
				v85 = v85 + 1
				local v101, v102, v103 = localToWorld(SharedLight.debugRootNode, v85 * 2, 1, -1)
				local v104, v105, v106 = localRotationToWorld(SharedLight.debugRootNode, -1.5707963267948966, 3.141592653589793, 0)
				g_debugManager:addElement(DebugText3D.new():createWithWorldPos(v101, v102, v103, v104, v105, v106, v98, 0.15), nil, nil, (1 / 0))
				v100 = 0
			end
			local v107 = v85 * 2
			v88 = v100 + 1
			setTranslation(v90, v107, 1, v100)
			setRotation(v90, 0, 3.141592653589793, 0)
			local v_u_108 = SharedLight.new(v_u_72, SharedLight.debugStaticLights)
			v_u_108:setCallback(function(p109)
				-- upvalues: (ref) v_u_81, (ref) v_u_86, (copy) v_u_108, (ref) v_u_87, (copy) v_u_72, (copy) v_u_73, (ref) v_u_75, (ref) v_u_82
				v_u_81 = v_u_81 - 1
				if p109 then
					v_u_86 = v_u_86 + 1
					local v110 = SharedLight.debugSharedLights
					local v111 = v_u_108
					table.insert(v110, v111)
				else
					v_u_87 = v_u_87 + 1
				end
				if v_u_81 == 0 then
					Lights.applyAdditionalActiveLightType(v_u_72, SharedLight.debugStaticLights.topLights, v_u_73.additionalLightTypes.topLight)
					Lights.applyAdditionalActiveLightType(v_u_72, SharedLight.debugStaticLights.bottomLights, v_u_73.additionalLightTypes.bottomLight)
					Lights.applyAdditionalActiveLightType(v_u_72, SharedLight.debugStaticLights.brakeLights, v_u_73.additionalLightTypes.brakeLight)
					Lights.applyAdditionalActiveLightType(v_u_72, SharedLight.debugStaticLights.reverseLights, v_u_73.additionalLightTypes.reverseLight)
					Lights.applyAdditionalActiveLightType(v_u_72, SharedLight.debugStaticLights.turnLightsLeft, v_u_73.additionalLightTypes.turnLightLeft, true)
					Lights.applyAdditionalActiveLightType(v_u_72, SharedLight.debugStaticLights.turnLightsLeft, v_u_73.additionalLightTypes.turnLightAny, true)
					Lights.applyAdditionalActiveLightType(v_u_72, SharedLight.debugStaticLights.turnLightsRight, v_u_73.additionalLightTypes.turnLightRight, true)
					Lights.applyAdditionalActiveLightType(v_u_72, SharedLight.debugStaticLights.turnLightsRight, v_u_73.additionalLightTypes.turnLightAny, true)
					for _, v112 in pairs(SharedLight.debugStaticLights) do
						for _, v113 in ipairs(v112) do
							v113:setLightTypesMask(v_u_75)
						end
					end
					for _, v114 in ipairs(SharedLight.debugSharedLights) do
						if v114.staticLightCompound ~= nil then
							v114.staticLightCompound:setLightTypesMask(v_u_75, v_u_72)
						end
					end
					Logging.info("%d Static lights: %d loaded, %d failed to load", v_u_82, v_u_86, v_u_87)
				end
			end)
			if v_u_108:loadFromXML(v90, string.gsub(v89.path, getAppBasePath(), ""), "") then
				local v115, v116, v117 = localToWorld(v90, 0, 0, -0.2)
				local v118, v119, v120 = localRotationToWorld(v90, -1.5707963267948966, 0, 0)
				g_debugManager:addElement(DebugText3D.new():createWithWorldPos(v115, v116, v117, v118, v119, v120, v89.filename, 0.07), nil, nil, (1 / 0))
				g_debugManager:addElement(DebugGizmo.new():createWithNode(v90, "", nil, nil, 0.1), nil, nil, (1 / 0))
				v84 = v98
				v83 = v99
			else
				v84 = v98
				v83 = v99
			end
		end
	end
	BeaconLight.spawnDebugBeacons(SharedLight.debugRootNode)
end
function SharedLight.registerXMLPaths(p121, p122)
	p121:register(XMLValueType.STRING, p122 .. "#filename", "Shared light filename")
	p121:register(XMLValueType.NODE_INDEX, p122 .. "#linkNode", "Link node", "0>")
	p121:register(XMLValueType.VECTOR_N, p122 .. "#lightTypes", "Light types")
	p121:register(XMLValueType.VECTOR_N, p122 .. "#excludedLightTypes", "Excluded light types")
	p121:register(XMLValueType.STRING, p122 .. ".rotationNode(?)#name", "Rotation node name")
	p121:register(XMLValueType.VECTOR_ROT, p122 .. ".rotationNode(?)#rotation", "Rotation")
	p121:register(XMLValueType.BOOL, p122 .. "#reverseLight", "All \'defaultLight\' nodes will be used as reverse light", false)
	p121:register(XMLValueType.BOOL, p122 .. "#turnLightLeft", "All \'defaultLight\' nodes will be used as left turn light", false)
	p121:register(XMLValueType.BOOL, p122 .. "#turnLightRight", "All \'defaultLight\' nodes will be used as right turn light", false)
	p121:register(XMLValueType.STRING, p122 .. ".function(?)#name", "Function name", nil, nil, StaticLightCompoundUVSlot.getAllOrderedByName())
	p121:register(XMLValueType.INT, p122 .. ".function(?)#uvSlotIndex", "Custom UV slot index to assign the defined function name")
	p121:register(XMLValueType.INT, p122 .. ".function(?)#uvOffset", "Vertical UV offset that is used while this light function is active (value range: 0-64 -> this represents the height of the texture with a resolution of 1/64). This is used for double usage of certain lights with different colors.", 0)
	p121:register(XMLValueType.FLOAT, p122 .. ".function(?)#intensityScale", "Custom intensity scale for this light type (is multiplied by the intensity defined in the node)")
	p121:register(XMLValueType.STRING, p122 .. ".function(?)#lightType", "Name of the light type to use", nil, nil, StaticLightCompoundLightType.getAllOrderedByName())
end
function SharedLight.registerExternalXMLPaths(p123)
	p123:register(XMLValueType.STRING, "light.filename", "Path to i3d file", nil, true)
	p123:register(XMLValueType.NODE_INDEX, "light.rootNode#node", "Node index", "0")
	StaticLight.registerXMLPaths(p123, "light.defaultLight(?)")
	StaticLight.registerXMLPaths(p123, "light.topLight(?)")
	StaticLight.registerXMLPaths(p123, "light.bottomLight(?)")
	StaticLight.registerXMLPaths(p123, "light.brakeLight(?)")
	StaticLight.registerXMLPaths(p123, "light.reverseLight(?)")
	StaticLight.registerXMLPaths(p123, "light.dayTimeLight(?)")
	StaticLight.registerXMLPaths(p123, "light.turnLightLeft(?)")
	StaticLight.registerXMLPaths(p123, "light.turnLightRight(?)")
	p123:register(XMLValueType.STRING, "light.rotationNode(?)#name", "Name for reference in vehicle xml")
	p123:register(XMLValueType.NODE_INDEX, "light.rotationNode(?)#node", "Node")
	VehicleMaterial.registerXMLPaths(p123, "light.baseMaterial")
	VehicleMaterial.registerXMLPaths(p123, "light.glassMaterial")
	StaticLightCompound.registerXMLPaths(p123, "light.staticLightCompound")
end
g_xmlManager:addCreateSchemaFunction(function()
	SharedLight.xmlSchema = XMLSchema.new("sharedLight")
end)
g_xmlManager:addInitSchemaFunction(function()
	SharedLight.registerExternalXMLPaths(SharedLight.xmlSchema)
end)
addConsoleCommand("gsVehicleDebugSharedLights", "Spawns all shared lights in front of the player", "SharedLight.consoleCommandDebug", nil, "[defaultLight]; [brakeLight]; [highBeam]; [workLightBack]; [workLightFront]; [turnLightLeft]; [turnLeftRight]; [reverseLight]")

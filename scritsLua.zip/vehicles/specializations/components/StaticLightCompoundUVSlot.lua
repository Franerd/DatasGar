StaticLightCompoundUVSlot = {}
StaticLightCompoundUVSlot.DEFAULT_LIGHT = 1
StaticLightCompoundUVSlot.DEFAULT_LIGHT_HIGH_BEAM = 2
StaticLightCompoundUVSlot.HIGH_BEAM = 3
StaticLightCompoundUVSlot.BOTTOM_LIGHT = 4
StaticLightCompoundUVSlot.TOP_LIGHT = 5
StaticLightCompoundUVSlot.DAY_TIME_RUNNING_LIGHT = 6
StaticLightCompoundUVSlot.TURN_LIGHT_LEFT = 7
StaticLightCompoundUVSlot.TURN_LIGHT_RIGHT = 8
StaticLightCompoundUVSlot.BACK_LIGHT = 9
StaticLightCompoundUVSlot.BRAKE_LIGHT = 10
StaticLightCompoundUVSlot.BACK_BRAKE_LIGHT = 11
StaticLightCompoundUVSlot.REVERSE_LIGHT = 12
StaticLightCompoundUVSlot.WORK_LIGHT_FRONT = 13
StaticLightCompoundUVSlot.WORK_LIGHT_BACK = 14
StaticLightCompoundUVSlot.WORK_LIGHT_ADDITIONAL = 15
StaticLightCompoundUVSlot.WORK_LIGHT_ADDITIONAL2 = 16
Enum(StaticLightCompoundUVSlot)

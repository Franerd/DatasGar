StaticLightCompoundLightType = {}
StaticLightCompoundLightType.STATIC = 1
StaticLightCompoundLightType.BLINKING = 2
StaticLightCompoundLightType.MULTI_BLINK = 3
StaticLightCompoundLightType.SLIDE = 4
Enum(StaticLightCompoundLightType)

BeaconLight = {}
BeaconLight.LIGHT_TYPE_BITMASK = 8
local v_u_1 = Class(BeaconLight)
function BeaconLight.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.vehicle = p2
	v5.components = {}
	v5.i3dMappings = {}
	v5.staticLights = {}
	v5.speed = 1
	v5.realLightRangeScale = 1
	v5.intensity = 1
	v5.lastCameraDistance = 0
	v5.requiresDirtyUpdate = false
	v5.hasDynamicStaticLights = false
	return v5
end
function BeaconLight.delete(p6)
	if p6.node ~= nil then
		delete(p6.node)
		p6.node = nil
	end
	if p6.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(p6.sharedLoadRequestId)
		p6.sharedLoadRequestId = nil
	end
	g_currentMission:removeUpdateable(p6)
end
function BeaconLight.setCallback(p7, p8, p9)
	p7.callback = p8
	p7.callbackTarget = p9
end
function BeaconLight.loadFromVehicleXML(p_u_10, p11, p12, p13)
	local v14 = p11:getValue(p12 .. "#filename", nil, p13.baseDirectory)
	if v14 == nil then
		local v15 = false
		local v16 = {}
		for _, v17 in p11:iterator(p12 .. ".staticLight") do
			local v18 = {
				["node"] = p11:getValue(v17 .. "#node", nil, p13.components, p13.i3dMappings)
			}
			if v18.node ~= nil then
				v18.intensity = p11:getValue(v17 .. "#intensity", 1)
				v18.multiBlink = p11:getValue(v17 .. "#multiBlink", false)
				v18.multiBlinkParameters = p11:getValue(v17 .. "#multiBlinkParameters", "2 5 50 0", true)
				v18.uvOffsetParameter = p11:getValue(v17 .. "#uvOffsetParameter", 0)
				v18.minDistance = p11:getValue(v17 .. "#minDistance", 0)
				v18.intensityScaleMinDistance = p11:getValue(v17 .. ".intensityScale#minDistance")
				v18.intensityScaleMinIntensity = p11:getValue(v17 .. ".intensityScale#minIntensity")
				v18.intensityScaleMaxDistance = p11:getValue(v17 .. ".intensityScale#maxDistance")
				v18.intensityScaleMaxIntensity = p11:getValue(v17 .. ".intensityScale#maxIntensity")
				local v19
				if v18.intensityScaleMinDistance == nil or (v18.intensityScaleMinIntensity == nil or v18.intensityScaleMaxDistance == nil) then
					v19 = false
				else
					v19 = v18.intensityScaleMaxIntensity ~= nil
				end
				v18.hasDynamicIntensity = v19
				v15 = v15 or (v18.hasDynamicIntensity or v18.minDistance > 0)
				table.insert(v16, v18)
			end
		end
		if v16 ~= nil and #v16 > 0 then
			local v20 = p11:getValue(p12 .. "#speed")
			local v21 = p11:getValue(p12 .. "#intensity", 1)
			local v22 = p11:getValue(p12 .. "#realLight", nil, p13.components, p13.i3dMappings)
			local v23 = p11:getValue(p12 .. "#realLightRange", 1)
			local v24 = BeaconLight.new(p13)
			v24:setXMLSettings(v20, v21, nil, nil)
			v24:setRealLight(true, v22, v23)
			v24.staticLights = v16
			v24.hasStaticLights = true
			v24.hasDynamicStaticLights = v15
			v24:onFinished(true)
			table.insert(p_u_10, v24)
		end
		return
	else
		local v25 = p11:getValue(p12 .. "#node", nil, p13.components, p13.i3dMappings)
		if v25 == nil then
			Logging.xmlWarning(p11, "Missing link node for beacon light in \'%s\'", p12)
			return
		else
			local v26, _, v27 = getReferenceInfo(v25)
			if v26 and v27 then
				Logging.xmlWarning(p11, "Beacon light link node \'%s\' is a runtime loaded reference, please load beacon lights only via XML!", getName(v25))
			else
				local v28 = p11:getValue(p12 .. "#speed")
				local v29 = p11:getValue(p12 .. "#realLight", nil, p13.components, p13.i3dMappings)
				local v30 = p11:getValue(p12 .. "#useRealLights", v29 == nil)
				local v31 = p11:getValue(p12 .. "#realLightRange", 1)
				local v32 = p11:getValue(p12 .. "#intensity", 1)
				local v33 = p11:getValue(p12 .. "#mountType")
				local v34 = p11:getValue(p12 .. "#variationName")
				local v_u_35 = BeaconLight.new(p13)
				v_u_35:setXMLSettings(v28, v32, v33, v34)
				v_u_35:setRealLight(v30, v29, v31)
				v_u_35:setCallback(function(p36)
					-- upvalues: (copy) p_u_10, (copy) v_u_35
					if p36 then
						local v37 = p_u_10
						local v38 = v_u_35
						table.insert(v37, v38)
					end
				end)
				v_u_35:loadFromXML(v25, v14, p13.baseDirectory)
			end
		end
	end
end
function BeaconLight.setXMLSettings(p39, p40, p41, p42, p43)
	p39.speed = p40 or p39.speed
	p39.intensity = p41 or p39.intensity
	p39.mountType = p42
	p39.variationName = p43
end
function BeaconLight.setRealLight(p44, p45, p46, p47)
	p44.useRealLights = Utils.getNoNil(p45, p44.useRealLights)
	p44.customRealLight = p46
	p44.realLightRangeScale = p47 or p44.realLightRangeScale
end
function BeaconLight.loadFromXML(p48, p49, p50, p51)
	p48.xmlFile = XMLFile.loadIfExists("BeaconLight", p50, BeaconLight.xmlSchema)
	if p48.xmlFile == nil then
		if p48.vehicle == nil then
			Logging.warning("Unable to load shared lights from xml \'%s\'", p50)
		else
			Logging.xmlWarning(p48.vehicle.xmlFile, "Unable to load shared lights from xml \'%s\'", p50)
		end
		p48:onFinished(false)
		return false
	end
	local v52 = p48.xmlFile:getValue("beaconLight.filename")
	if v52 ~= nil then
		p48.filename = Utils.getFilename(v52, p51)
		p48.linkNode = p49
		if p48.vehicle == nil then
			p48.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(p48.filename, false, false, p48.onI3DLoaded, p48, nil)
		else
			p48.sharedLoadRequestId = p48.vehicle:loadSubSharedI3DFile(p48.filename, false, false, p48.onI3DLoaded, p48, nil)
		end
		return true
	end
	Logging.xmlWarning(p48.xmlFile, "Missing light i3d filename!")
	p48.xmlFile:delete()
	p48.xmlFile = nil
	p48:onFinished(false)
	return false
end
function BeaconLight.onI3DLoaded(p53, p54, _, _)
	if p53.vehicle == nil or not p53.vehicle.isDeleted then
		if p54 ~= 0 then
			I3DUtil.loadI3DComponents(p54, p53.components)
			I3DUtil.loadI3DMapping(p53.xmlFile, "beaconLight", p53.components, p53.i3dMappings)
			p53.node = p53.xmlFile:getValue("beaconLight.rootNode#node", "0", p53.components, p53.i3dMappings)
			if p53.node ~= nil then
				p53.nodesToRemove = {}
				p53.variationRootNode = nil
				local v55 = nil
				for v56, v57 in p53.xmlFile:iterator("beaconLight.variations.variation") do
					local v58 = p53.xmlFile:getValue(v57 .. "#name")
					if v58 ~= nil then
						if p53.variationName == nil and v56 == 1 or p53.variationName ~= nil and string.lower(v58) == string.lower(p53.variationName) then
							p53.variationRootNode = p53.xmlFile:getValue(v57 .. "#rootNode", nil, p53.components, p53.i3dMappings)
							v55 = v57
						else
							local v59 = p53.xmlFile:getValue(v57 .. "#rootNode", nil, p53.components, p53.i3dMappings)
							if v59 ~= nil then
								p53.nodesToRemove[v59] = true
							end
						end
					end
				end
				p53:loadVariationFromXML(p53.xmlFile, "beaconLight")
				if v55 ~= nil then
					p53:loadVariationFromXML(p53.xmlFile, v55)
				end
				local v60 = 0
				for v61, v62 in p53.xmlFile:iterator("beaconLight.mountTypes.mountType") do
					local v63 = p53.xmlFile:getValue(v62 .. "#name")
					if v63 ~= nil then
						local v64 = p53.xmlFile:getValue(v62 .. "#node", nil, p53.components, p53.i3dMappings)
						if p53.mountType == nil and v61 == 1 or p53.mountType ~= nil and string.lower(v63) == string.lower(p53.mountType) then
							v60 = p53.xmlFile:getValue(v62 .. "#yOffset", 0)
							if v64 ~= nil then
								setVisibility(v64, true)
							end
						elseif v64 ~= nil then
							p53.nodesToRemove[v64] = true
						end
					end
				end
				for v65, _ in pairs(p53.nodesToRemove) do
					if v65 ~= p53.variationRootNode then
						delete(v65)
					end
				end
				p53.nodesToRemove = nil
				link(p53.linkNode, p53.node)
				setTranslation(p53.node, 0, v60, 0)
			end
			delete(p54)
		end
		p53.xmlFile:delete()
		p53.xmlFile = nil
		local v66
		if p53.node == nil then
			v66 = false
		else
			v66 = p53.hasStaticLights
		end
		p53:onFinished(v66)
	end
end
function BeaconLight.onFinished(p67, p68)
	for _, v69 in ipairs(p67.staticLights) do
		v69.useLightControlShaderParameter = getHasShaderParameter(v69.node, "lightControl")
		if v69.useLightControlShaderParameter then
			setShaderParameter(v69.node, "lightControl", 0, nil, nil, nil, false)
		else
			setShaderParameter(v69.node, "lightIds0", 0, 0, 0, 0, false)
			setShaderParameter(v69.node, "lightIds1", 0, 0, 0, 0, false)
			setShaderParameter(v69.node, "lightTypeBitMask", BeaconLight.LIGHT_TYPE_BITMASK, 0, 0, 0, false)
			setShaderParameter(v69.node, "lightUvOffsetBitMask", v69.uvOffsetParameter, 0, 0, 0, false)
		end
		setShaderParameter(v69.node, "blinkMulti", v69.multiBlinkParameters[1], v69.multiBlinkParameters[2], v69.multiBlinkParameters[3], v69.multiBlinkParameters[4], false)
		if v69.multiBlink or (v69.minDistance > 0 or v69.hasDynamicIntensity) then
			p67.requiresDirtyUpdate = true
		end
	end
	if p67.speed > 0 and p67.rotatorNode ~= nil then
		setRotation(p67.rotatorNode, 0, math.random(0, 6.283185307179586), 0)
		p67.requiresDirtyUpdate = true
	end
	if g_gameSettings:getValue(GameSettings.SETTING.REAL_BEACON_LIGHTS) then
		if (not p67.useRealLights or p67.customRealLight ~= nil) and p67.realLightNode ~= nil then
			delete(p67.realLightNode)
			p67.realLightNode = nil
		end
		if p67.customRealLight ~= nil then
			p67.realLightNode = p67.customRealLight
		end
	else
		if p67.realLightNode ~= nil then
			delete(p67.realLightNode)
			p67.realLightNode = nil
		end
		if p67.customRealLight ~= nil then
			delete(p67.customRealLight)
			p67.customRealLight = nil
		end
	end
	if p67.realLightNode ~= nil then
		p67.defaultColor = { getLightColor(p67.realLightNode) }
		setVisibility(p67.realLightNode, false)
		p67.defaultLightRange = getLightRange(p67.realLightNode)
		setLightRange(p67.realLightNode, p67.defaultLightRange * p67.realLightRangeScale)
	end
	if p67.callback ~= nil then
		if p67.callbackTarget ~= nil then
			p67.callback(p67.callbackTarget, p68)
			return
		end
		p67.callback(p68)
	end
end
function BeaconLight.loadVariationFromXML(p70, p71, p72)
	p70.rotatorNode = p71:getValue(p72 .. ".rotator#node", p70.rotatorNode, p70.components, p70.i3dMappings)
	p70.speed = p71:getValue(p72 .. ".rotator#speed", p70.speed or 0.015)
	p70.realLightNode = p71:getValue(p72 .. ".realLight#node", p70.realLightNode, p70.components, p70.i3dMappings)
	if p70.realLightNode ~= nil and not getHasClassId(p70.realLightNode, ClassIds.LIGHT_SOURCE) then
		Logging.xmlWarning(p71, "Node \'%s\' defined as light source for beacon light, but is not a light source!", getName(p70.realLightNode))
		p70.realLightNode = nil
	end
	if not p71:getValue(p72 .. ".realLight#useRealLight", true) and p70.realLightNode ~= nil then
		delete(p70.realLightNode)
		p70.realLightNode = nil
	end
	for _, v73 in p71:iterator(p72 .. ".staticLight") do
		local v74 = {
			["node"] = p71:getValue(v73 .. "#node", nil, p70.components, p70.i3dMappings)
		}
		if v74.node ~= nil then
			if v74.node == nil or getHasClassId(v74.node, ClassIds.SHAPE) then
				v74.intensity = p71:getValue(v73 .. "#intensity", 1)
				v74.multiBlink = p71:getValue(v73 .. "#multiBlink", false)
				v74.multiBlinkParameters = p71:getValue(v73 .. "#multiBlinkParameters", "2 5 50 0", true)
				v74.uvOffsetParameter = p71:getValue(v73 .. "#uvOffsetParameter", 0)
				v74.minDistance = p71:getValue(v73 .. "#minDistance", 0)
				v74.intensityScaleMinDistance = p71:getValue(v73 .. ".intensityScale#minDistance")
				v74.intensityScaleMinIntensity = p71:getValue(v73 .. ".intensityScale#minIntensity")
				v74.intensityScaleMaxDistance = p71:getValue(v73 .. ".intensityScale#maxDistance")
				v74.intensityScaleMaxIntensity = p71:getValue(v73 .. ".intensityScale#maxIntensity")
				local v75
				if v74.intensityScaleMinDistance == nil or (v74.intensityScaleMinIntensity == nil or v74.intensityScaleMaxDistance == nil) then
					v75 = false
				else
					v75 = v74.intensityScaleMaxIntensity ~= nil
				end
				v74.hasDynamicIntensity = v75
				p70.hasDynamicStaticLights = p70.hasDynamicStaticLights or (v74.hasDynamicIntensity or v74.minDistance > 0)
				local v76 = p70.staticLights
				table.insert(v76, v74)
			else
				Logging.xmlWarning(p71, "Node \'%s\' defined as shader node for beacon light, but is not a shape!", getName(v74.node))
			end
		end
	end
	p70.hasStaticLights = #p70.staticLights > 0
	p70.device = BeaconLightManager.loadDeviceFromXML(p71, p72 .. ".device") or p70.device
	if p71:hasProperty(p72 .. ".material") then
		local v77, v78
		if p70.vehicle == nil then
			v77 = ""
			v78 = ""
		else
			v77 = p70.vehicle.baseDirectory
			v78 = p70.vehicle.customEnvironment
		end
		local v79 = VehicleMaterial.new(v77)
		if v79:loadFromXML(p71, p72 .. ".material", v78) then
			v79:apply(p70.node)
		end
	end
end
function BeaconLight.update(p80, p81)
	if p80.rotatorNode ~= nil then
		rotate(p80.rotatorNode, 0, p80.speed * p81, 0)
	end
	if p80.realLightNode ~= nil and (p80.hasStaticLights and p80.staticLights[1].multiBlink) then
		local v82 = p80.staticLights[1]
		local v83 = v82.multiBlinkParameters[1]
		local v84 = v82.multiBlinkParameters[2]
		local v85 = v82.multiBlinkParameters[3]
		local v86 = v82.multiBlinkParameters[4]
		local v87 = getShaderTimeSec() * v85 + v86
		local v88 = math.sin(v87)
		local v89 = v87 % ((v83 * 2 + v84 * 2) * 3.141592653589793) - (v83 * 2 - 1) * 3.141592653589793
		local v90 = v88 - math.max(v89, 0) + 0.2
		local v91 = math.clamp(v90, 0, 1)
		local v92 = p80.defaultColor[1]
		local v93 = p80.defaultColor[2]
		local v94 = p80.defaultColor[3]
		setLightColor(p80.realLightNode, v92 * v91, v93 * v91, v94 * v91)
		for v95 = 0, getNumOfChildren(p80.realLightNode) - 1 do
			setLightColor(getChildAt(p80.realLightNode, v95), v92 * v91, v93 * v91, v94 * v91)
		end
	end
	if p80.hasDynamicStaticLights then
		local v96 = p80.node == nil and 0 or calcDistanceFrom(p80.node, g_cameraManager:getActiveCamera())
		local v97 = p80.lastCameraDistance - v96
		if math.abs(v97) > 1 then
			for _, v98 in ipairs(p80.staticLights) do
				if v98.hasDynamicIntensity then
					local v99 = (v96 - v98.intensityScaleMinDistance) / (v98.intensityScaleMaxDistance - v98.intensityScaleMinDistance)
					local v100 = math.max(v99, 0)
					local v101 = math.min(v100, 1)
					local v102 = (v98.intensityScaleMinIntensity + (v98.intensityScaleMaxIntensity - v98.intensityScaleMinIntensity) * v101) * p80.intensity
					if v98.useLightControlShaderParameter then
						setShaderParameter(v98.node, "lightControl", v102, nil, nil, nil, false)
					else
						setShaderParameter(v98.node, "lightIds0", v102, v102, 0, 0, false)
					end
				end
				if v98.minDistance > 0 then
					setVisibility(v98.node, v98.minDistance <= v96)
				end
			end
			p80.lastCameraDistance = v96
		end
	end
end
function BeaconLight.setIsActive(p103, p104, p105)
	if p103.requiresDirtyUpdate then
		if p104 then
			g_currentMission:addUpdateable(p103)
		else
			g_currentMission:removeUpdateable(p103)
		end
	end
	if p103.realLightNode ~= nil then
		setVisibility(p103.realLightNode, p104)
	end
	if p103.node ~= nil and p104 then
		p103.lastCameraDistance = calcDistanceFrom(p103.node, g_cameraManager:getActiveCamera())
	end
	for _, v106 in ipairs(p103.staticLights) do
		local v107 = p104 and (v106.intensity or 0) or 0
		if p104 and v106.hasDynamicIntensity then
			local v108 = (p103.lastCameraDistance - v106.intensityScaleMinDistance) / (v106.intensityScaleMaxDistance - v106.intensityScaleMinDistance)
			local v109 = math.max(v108, 0)
			local v110 = math.min(v109, 1)
			v107 = v106.intensityScaleMinIntensity + (v106.intensityScaleMaxIntensity - v106.intensityScaleMinIntensity) * v110
		end
		local v111 = v107 * p103.intensity
		if v106.useLightControlShaderParameter then
			setShaderParameter(v106.node, "lightControl", v111, nil, nil, nil, false)
		else
			setShaderParameter(v106.node, "lightIds0", v111, v111, 0, 0, false)
		end
		if v106.minDistance > 0 then
			if p104 then
				setVisibility(v106.node, p103.lastCameraDistance >= v106.minDistance)
			else
				setVisibility(v106.node, false)
			end
		end
	end
	if p105 then
		local v112 = p103.device
		if v112 ~= nil then
			if p104 then
				v112.deviceId = g_beaconLightManager:activateBeaconLight(v112.mode, v112.numLEDScale, v112.rpm, v112.brightnessScale)
				return
			end
			if v112.deviceId ~= nil then
				g_beaconLightManager:deactivateBeaconLight(v112.deviceId)
				v112.deviceId = nil
			end
		end
	end
end
function BeaconLight.spawnDebugBeacons(p113)
	local v114 = Files.getFilesRecursive("data/shared/assets/beaconLights")
	table.sort(v114, function(p115, p116)
		return p115.path < p116.path
	end)
	if BeaconLight.debugBeaconLights ~= nil then
		for _, v117 in ipairs(BeaconLight.debugBeaconLights) do
			v117:delete()
		end
	end
	BeaconLight.debugBeaconLights = {}
	local v118 = -1
	local v119 = 0
	local v120 = 0
	local v_u_121 = 0
	local v_u_122 = 0
	for _, v123 in ipairs(v114) do
		if not v123.isDirectory and v123.filename:contains(".xml") then
			v118 = v118 - 2
			local v124 = 0
			local v125 = string.gsub(v123.path, getAppBasePath(), "")
			local v126 = XMLFile.loadIfExists("BeaconLight", v125, BeaconLight.xmlSchema)
			if v126 ~= nil then
				for _, v127 in v126:iterator("beaconLight.mountTypes.mountType") do
					local v128 = v126:getValue(v127 .. "#name")
					for _, v129 in v126:iterator("beaconLight.variations.variation") do
						local v130 = v126:getValue(v129 .. "#name")
						local v_u_131 = v119 + 1
						local v_u_132 = v120 + 1
						v124 = v124 + 1
						local v133 = createTransformGroup("linkNode")
						link(p113, v133)
						setTranslation(v133, v118, 1, v124)
						setRotation(v133, 0, 3.141592653589793, 0)
						local v_u_134 = BeaconLight.new(nil)
						v_u_134:setXMLSettings(nil, nil, v128, v130)
						v_u_134:setRealLight(false)
						v_u_134:setCallback(function(p135)
							-- upvalues: (ref) v_u_131, (ref) v_u_121, (copy) v_u_134, (ref) v_u_122, (ref) v_u_132
							v_u_131 = v_u_131 - 1
							if p135 then
								v_u_121 = v_u_121 + 1
								local v136 = BeaconLight.debugBeaconLights
								local v137 = v_u_134
								table.insert(v136, v137)
							else
								v_u_134:delete()
								v_u_122 = v_u_122 + 1
							end
							if v_u_131 == 0 then
								for _, v138 in ipairs(BeaconLight.debugBeaconLights) do
									v138:setIsActive(true)
								end
								Logging.info("%d Beacon lights: %d loaded, %d failed to load", v_u_132, v_u_121, v_u_122)
							end
						end)
						if v_u_134:loadFromXML(v133, v125, "") then
							local v139, v140, v141 = localToWorld(v133, 0, 0, -0.2)
							local v142, v143, v144 = localRotationToWorld(v133, -1.5707963267948966, 0, 0)
							g_debugManager:addElement(DebugText3D.new():createWithWorldPos(v139, v140, v141, v142, v143, v144, string.format("%s (%s, %s)", v123.filename, v128, v130), 0.07), nil, nil, (1 / 0))
							g_debugManager:addElement(DebugGizmo.new():createWithNode(v133, "", nil, nil, 0.1), nil, nil, (1 / 0))
							v120 = v_u_132
							v119 = v_u_131
						else
							v120 = v_u_132
							v119 = v_u_131
						end
					end
				end
				v126:delete()
			end
		end
	end
end
function BeaconLight.registerXMLPaths(p145)
	p145:register(XMLValueType.STRING, "beaconLight.filename", "Path to i3d file", nil, true)
	p145:register(XMLValueType.NODE_INDEX, "beaconLight.rootNode#node", "Root node")
	p145:register(XMLValueType.STRING, "beaconLight.mountTypes.mountType(?)#name", "Name of the mount type")
	p145:register(XMLValueType.NODE_INDEX, "beaconLight.mountTypes.mountType(?)#node", "Node to show while this mount type is used")
	p145:register(XMLValueType.FLOAT, "beaconLight.mountTypes.mountType(?)#yOffset", "Y translation offset of the while beacon light while this mount type is used", 0)
	BeaconLight.registerVariationPaths(p145, "beaconLight")
	p145:register(XMLValueType.STRING, "beaconLight.variations.variation(?)#name", "Name of the variation")
	p145:register(XMLValueType.NODE_INDEX, "beaconLight.variations.variation(?)#rootNode", "Node that contains the variation data. Will be deleted if not used.")
	BeaconLight.registerVariationPaths(p145, "beaconLight.variations.variation(?)")
	I3DUtil.registerI3dMappingXMLPaths(p145, "beaconLight")
end
function BeaconLight.registerVariationPaths(p146, p147)
	p146:register(XMLValueType.NODE_INDEX, p147 .. ".rotator#node", "Node that is rotating")
	p146:register(XMLValueType.FLOAT, p147 .. ".rotator#speed", "Rotating speed", 0.015)
	p146:register(XMLValueType.NODE_INDEX, p147 .. ".staticLight(?)#node", "Light control shader node")
	p146:register(XMLValueType.FLOAT, p147 .. ".staticLight(?)#intensity", "Light intensity of shader node", 100)
	p146:register(XMLValueType.BOOL, p147 .. ".staticLight(?)#multiBlink", "Uses multiblink functionality", false)
	p146:register(XMLValueType.VECTOR_4, p147 .. ".staticLight(?)#multiBlinkParameters", "Parameters for multi blink function (blink ticks, pause ticks, frequency)", "2 5 50 0")
	p146:register(XMLValueType.INT, p147 .. ".staticLight(?)#uvOffsetParameter", "Parameter for light UV offset bit mask", 0)
	p146:register(XMLValueType.FLOAT, p147 .. ".staticLight(?)#minDistance", "Starting from this camera distance to static light is visible", 0)
	p146:register(XMLValueType.FLOAT, p147 .. ".staticLight(?).intensityScale#minDistance", "Reference distance for default intensity")
	p146:register(XMLValueType.FLOAT, p147 .. ".staticLight(?).intensityScale#minIntensity", "Intensity to be used at min. distance")
	p146:register(XMLValueType.FLOAT, p147 .. ".staticLight(?).intensityScale#maxDistance", "Reference distance for max intensity")
	p146:register(XMLValueType.FLOAT, p147 .. ".staticLight(?).intensityScale#maxIntensity", "Intensity to be used at max. distance")
	p146:register(XMLValueType.NODE_INDEX, p147 .. ".realLight#node", "Real light source node")
	p146:register(XMLValueType.BOOL, p147 .. ".realLight#useRealLight", "Defines if the real light is used at all for this variation", true)
	VehicleMaterial.registerXMLPaths(p146, p147 .. ".material")
	BeaconLightManager.registerXMLPaths(p146, p147 .. ".device")
end
function BeaconLight.registerVehicleXMLPaths(p148, p149)
	p148:register(XMLValueType.NODE_INDEX, p149 .. "#node", "Link node")
	p148:register(XMLValueType.FILENAME, p149 .. "#filename", "Beacon light xml file")
	p148:register(XMLValueType.FLOAT, p149 .. "#speed", "Beacon light speed override")
	p148:register(XMLValueType.BOOL, p149 .. "#useRealLights", "Use the real lights from the external beacon light file", true)
	p148:register(XMLValueType.NODE_INDEX, p149 .. "#realLight", "Custom real light to be used from the vehicle file instead of the external beacon light file")
	p148:register(XMLValueType.FLOAT, p149 .. "#realLightRange", "Factor that is applied on real light range of the beacon light", 1)
	p148:register(XMLValueType.INT, p149 .. "#intensity", "Beacon light intensity scale", 1)
	p148:register(XMLValueType.STRING, p149 .. "#mountType", "Name of the mount type to use (SURFACE or POLE for most of the beacon lights)")
	p148:register(XMLValueType.STRING, p149 .. "#variationName", "Name of the variation to use (ROTATE or BLINK for most of the beacon lights)")
	p148:register(XMLValueType.NODE_INDEX, p149 .. ".staticLight(?)#node", "Static light node inside the vehicle i3d file")
	p148:register(XMLValueType.FLOAT, p149 .. ".staticLight(?)#intensity", "Intensity of this static light node", 100)
	p148:register(XMLValueType.BOOL, p149 .. ".staticLight(?)#multiBlink", "Uses multiblink functionality", false)
	p148:register(XMLValueType.VECTOR_4, p149 .. ".staticLight(?)#multiBlinkParameters", "Parameters for multi blink function (blink ticks, pause ticks, frequency)", "2 5 50 0")
	p148:register(XMLValueType.INT, p149 .. ".staticLight(?)#uvOffsetParameter", "Parameter for light UV offset bit mask", 0)
	p148:register(XMLValueType.FLOAT, p149 .. ".staticLight(?)#minDistance", "Starting from this camera distance to static light is visible", 0)
	p148:register(XMLValueType.FLOAT, p149 .. ".staticLight(?).intensityScale#minDistance", "Reference distance for default intensity", 0)
	p148:register(XMLValueType.FLOAT, p149 .. ".staticLight(?).intensityScale#minIntensity", "Intensity to be used at min. distance", 0)
	p148:register(XMLValueType.FLOAT, p149 .. ".staticLight(?).intensityScale#maxDistance", "Reference distance for max intensity", 0)
	p148:register(XMLValueType.FLOAT, p149 .. ".staticLight(?).intensityScale#maxIntensity", "Intensity to be used at max. distance", 0)
end
g_xmlManager:addCreateSchemaFunction(function()
	BeaconLight.xmlSchema = XMLSchema.new("beaconLight")
end)
g_xmlManager:addInitSchemaFunction(function()
	BeaconLight.registerXMLPaths(BeaconLight.xmlSchema)
end)

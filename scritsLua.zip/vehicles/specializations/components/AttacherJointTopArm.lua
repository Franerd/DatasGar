AttacherJointTopArm = {}
AttacherJointTopArm.RENAMED_UPPER_LINKS = {}
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid01 = "walterscheidSO_65_460"
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid02 = "walterscheidSO_65_660"
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid03 = "walterscheidHO_90_600"
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid04 = "walterscheidHO_110_700"
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid05 = "walterscheidSO_65_1210"
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid06 = "walterscheidSO_65_560"
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid07 = "walterscheidHO_110_610"
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid08 = "walterscheidHO_110_735"
AttacherJointTopArm.RENAMED_UPPER_LINKS.walterscheid09 = "walterscheidHO_140_750"
local v_u_1 = Class(AttacherJointTopArm)
function AttacherJointTopArm.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.vehicle = p2
	v5.components = {}
	v5.i3dMappings = {}
	v5.zScale = -1
	v5.toggleVisibility = false
	v5.useMountArm = true
	v5.useBrandDecal = true
	v5.changeObjects = {}
	return v5
end
function AttacherJointTopArm.delete(p6)
	if p6.node ~= nil then
		delete(p6.node)
		p6.node = nil
	end
	if p6.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(p6.sharedLoadRequestId)
		p6.sharedLoadRequestId = nil
	end
end
function AttacherJointTopArm.setCallback(p7, p8, p9)
	p7.callback = p8
	p7.callbackTarget = p9
end
function AttacherJointTopArm.onFinished(p10, p11)
	if p10.xmlFile ~= nil then
		p10.xmlFile:delete()
		p10.xmlFile = nil
	end
	p10:finalize()
	if p10.callback ~= nil then
		if p10.callbackTarget ~= nil then
			p10.callback(p10.callbackTarget, p11)
			return
		end
		p10.callback(p11)
	end
end
function AttacherJointTopArm.loadFromVehicleXML(p12, p13)
	local v14 = nil
	local v15 = p12.xmlFile:getValue(p13 .. "#baseNode", nil, p12.components, p12.i3dMappings)
	local v16 = p12.xmlFile:getValue(p13 .. "#filename", nil, p12.baseDirectory)
	if v15 == nil or v16 == nil then
		local v17 = p12.xmlFile:getValue(p13 .. "#rotationNode", nil, p12.components, p12.i3dMappings)
		if v17 ~= nil then
			v14 = AttacherJointTopArm.new(p12)
			v14.node = v17
			v14.translationNode = p12.xmlFile:getValue(p13 .. "#translationNode", nil, p12.components, p12.i3dMappings)
			v14.referenceNodeTranslation = p12.xmlFile:getValue(p13 .. "#referenceNode", nil, p12.components, p12.i3dMappings)
			v14:finalize()
		end
	else
		XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, p13 .. "#color", p13 .. "#materialTemplateName")
		XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, p13 .. "#color2", p13 .. "#materialTemplateName2")
		XMLUtil.checkDeprecatedXMLElements(p12.xmlFile, p13 .. "#decalColor", p13 .. "#decalMaterialTemplateName")
		if string.contains(v16, ".i3d") then
			Logging.xmlWarning(p12.xmlFile, "Top arm filename is referring to the i3d file. Please use the xml file instead. (%s)", v16)
			v16 = string.gsub(v16, ".i3d", ".xml")
		end
		for v18, v19 in pairs(AttacherJointTopArm.RENAMED_UPPER_LINKS) do
			if v16 == string.format("data/shared/assets/upperLinks/%s.xml", v18) then
				Logging.xmlWarning(p12.xmlFile, "Top arm has been renamed from \'%s\' to \'%s\' in \'%s\' (Names now include type, diameter and min. length)", v18, v19, p13)
				v16 = string.format("data/shared/assets/upperLinks/%s.xml", v19)
			end
		end
		v14 = AttacherJointTopArm.new(p12)
		if not v14:loadFromXML(v15, v16, p12.baseDirectory) then
			v14 = nil
		end
	end
	if v14 ~= nil then
		v14.zScale = p12.xmlFile:getValue(p13 .. "#zScale", -1)
		v14.toggleVisibility = p12.xmlFile:getValue(p13 .. "#toggleVisibility", v14.toggleVisibility)
		v14.useMountArm = p12.xmlFile:getValue(p13 .. "#useMountArm", v14.useMountArm)
		v14.mountArmRotation = p12.xmlFile:getValue(p13 .. "#mountArmRotation", nil, true)
		v14.useBrandDecal = p12.xmlFile:getValue(p13 .. "#useBrandDecal", v14.useBrandDecal)
		v14.material = p12.xmlFile:getValue(p13 .. "#materialTemplateName")
		v14.material2 = p12.xmlFile:getValue(p13 .. "#materialTemplateName2")
		v14.decalMaterial = p12.xmlFile:getValue(p13 .. "#decalMaterialTemplateName")
		v14.useMainColor = p12.xmlFile:getValue(p13 .. "#secondPartUseMainColor", true)
		ObjectChangeUtil.loadObjectChangeFromXML(p12.xmlFile, p13, v14.changeObjects, p12.components, p12)
		ObjectChangeUtil.setObjectChanges(v14.changeObjects, false, p12, p12.setMovingToolDirty, true)
	end
	return v14
end
function AttacherJointTopArm.loadFromXML(p20, p21, p22, p23)
	p20.xmlFile = XMLFile.loadIfExists("AttacherJointTopArm", p22, AttacherJointTopArm.xmlSchema)
	if p20.xmlFile == nil then
		if p20.vehicle == nil then
			Logging.warning("Unable to load top arm from xml \'%s\'", p22)
		else
			Logging.xmlWarning(p20.vehicle.xmlFile, "Unable to load top arm from xml \'%s\'", p22)
		end
		p20:onFinished(false)
		return false
	end
	local v24 = p20.xmlFile:getValue("topArm.filename", nil, p23)
	if v24 == nil then
		Logging.xmlWarning(p20.xmlFile, "Missing top arm i3d filename!")
		p20:onFinished(false)
		return false
	end
	p20.filename = v24
	p20.linkNode = p21
	if p20.vehicle == nil then
		p20.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(p20.filename, false, false, p20.onI3DLoaded, p20, nil)
	else
		p20.sharedLoadRequestId = p20.vehicle:loadSubSharedI3DFile(p20.filename, false, false, p20.onI3DLoaded, p20, nil)
	end
	return true
end
function AttacherJointTopArm.onI3DLoaded(p25, p26, _, _)
	if p26 ~= 0 then
		I3DUtil.loadI3DComponents(p26, p25.components)
		I3DUtil.loadI3DMapping(p25.xmlFile, "topArm", p25.components, p25.i3dMappings)
		p25.node = p25.xmlFile:getValue("topArm.rootNode#node", "0", p25.components, p25.i3dMappings)
		if p25.node ~= nil then
			link(p25.linkNode, p25.node)
			setTranslation(p25.node, 0, 0, 0)
			setRotation(p25.node, 0, p25.zScale < 0 and 3.141592653589793 or 0, 0)
			p25.translationNode = p25.xmlFile:getValue("topArm.translation#node", nil, p25.components, p25.i3dMappings)
			p25.referenceNodeTranslation = p25.xmlFile:getValue("topArm.translation#referenceNode", nil, p25.components, p25.i3dMappings)
			p25.scaleNode = p25.xmlFile:getValue("topArm.scale#node", nil, p25.components, p25.i3dMappings)
			p25.referenceNodeScale = p25.xmlFile:getValue("topArm.scale#referenceNode", nil, p25.components, p25.i3dMappings)
			p25.brandDecal = p25.xmlFile:getValue("topArm.brandDecal#node", nil, p25.components, p25.i3dMappings)
			if not p25.useBrandDecal and p25.brandDecal ~= nil then
				setVisibility(p25.brandDecal, false)
			end
			p25.mountArmNode = p25.xmlFile:getValue("topArm.mountArm#node", nil, p25.components, p25.i3dMappings)
			if p25.mountArmNode ~= nil then
				if p25.useMountArm then
					p25.mountArmRotationDefault = { getRotation(p25.mountArmNode) }
				else
					setVisibility(p25.mountArmNode, false)
					p25.mountArmNode = nil
				end
			end
			if p25.decalMaterial == nil and p25.material ~= nil then
				local v27 = p25.material:getBrightness()
				if v27 ~= nil then
					local v28 = v27 > 0.075 and 1 or 0
					VehicleMaterial.new():setColor(1 - v28, 1 - v28, 1 - v28)
				end
			end
			if p25.material ~= nil then
				p25.material:apply(p25.node, "upperLink_main_mat")
			end
			if p25.material2 ~= nil then
				p25.material2:apply(p25.node, "upperLink_base_mat")
			end
			if p25.useMainColor then
				if p25.material ~= nil then
					p25.material:apply(p25.node, "upperLink_head_mat")
				end
			elseif p25.material2 ~= nil then
				p25.material2:apply(p25.node, "upperLink_head_mat")
			end
			if p25.decalMaterial ~= nil then
				p25.decalMaterial:apply(p25.node, "upperLink_decal_mat")
			end
		end
		delete(p26)
	end
	if p25.node ~= nil then
		p25:setIsActive(false)
	end
	p25:onFinished(p25.node ~= nil)
end
function AttacherJointTopArm.finalize(p29)
	if p29.translationNode ~= nil and p29.referenceNodeTranslation ~= nil then
		p29.referenceDistance = calcDistanceFrom(p29.referenceNodeTranslation, p29.translationNode)
		p29.translationDefault = { getTranslation(p29.translationNode) }
	end
	if p29.scaleNode ~= nil and p29.referenceNodeScale ~= nil then
		local _, _, v30 = localToLocal(p29.referenceNodeScale, p29.scaleNode, 0, 0, 0)
		p29.scaleReferenceDistance = v30
	end
end
function AttacherJointTopArm.setIsActive(p31, p32)
	if p31.mountArmNode ~= nil and p31.mountArmRotation ~= nil then
		local v33 = p32 and p31.mountArmRotationDefault or p31.mountArmRotation
		setRotation(p31.mountArmNode, v33[1], v33[2], v33[3])
	end
	if p31.toggleVisibility then
		setVisibility(p31.node, p32)
	end
	if not p32 then
		setRotation(p31.node, 0, p31.zScale < 0 and 3.141592653589793 or 0, 0)
		if p31.translationDefault ~= nil then
			setTranslation(p31.translationNode, p31.translationDefault[1], p31.translationDefault[2], p31.translationDefault[3])
		end
		if p31.scaleNode ~= nil then
			setScale(p31.scaleNode, 1, 1, 1)
		end
	end
	ObjectChangeUtil.setObjectChanges(p31.changeObjects, p32, p31.vehicle, p31.vehicle.setMovingToolDirty, true)
end
function AttacherJointTopArm.update(p34, _, p35)
	local v36, v37, v38 = getWorldTranslation(p34.node)
	local v39, v40, v41 = getWorldTranslation(p35)
	local v42, v43, v44 = worldDirectionToLocal(getParent(p34.node), v39 - v36, v40 - v37, v41 - v38)
	local _, _, v45 = worldToLocal(p34.vehicle.rootNode, v36, v37, v38)
	local v46 = v45 < 0 and 1.5707963267948966 or -1.5707963267948966
	local v47, v48, v49 = localDirectionToLocal(p34.node, getParent(p34.node), 0, 0, 1)
	local v50 = math.cos(v46) * v48 - math.sin(v46) * v49
	local v51 = math.sin(v46) * v48 + math.cos(v46) * v49
	setDirection(p34.node, v42, v43, v44, v47, v50, v51)
	if p34.referenceDistance ~= nil then
		local v52 = MathUtil.vector3Length(v42, v43, v44) - p34.referenceDistance
		setTranslation(p34.translationNode, 0, 0, v52)
		if p34.scaleReferenceDistance ~= nil then
			local v53 = setScale
			local v54 = p34.scaleNode
			local v55 = (v52 + p34.scaleReferenceDistance) / p34.scaleReferenceDistance
			v53(v54, 1, 1, (math.max(v55, 0)))
		end
	end
end
function AttacherJointTopArm.registerVehicleXMLPaths(p56, p57)
	p56:register(XMLValueType.FILENAME, p57 .. "#filename", "Path to top arm i3d file")
	p56:register(XMLValueType.NODE_INDEX, p57 .. "#baseNode", "Link node for upper link")
	p56:register(XMLValueType.INT, p57 .. "#zScale", "Inverts top arm direction", 1)
	p56:register(XMLValueType.BOOL, p57 .. "#toggleVisibility", "Top arm will be hidden on detach", false)
	p56:register(XMLValueType.BOOL, p57 .. "#useMountArm", "Defines if the mount arm is visible or not", true)
	p56:register(XMLValueType.VECTOR_ROT, p57 .. "#mountArmRotation", "Defines a custom mount arm rotation while no tool is attached")
	p56:register(XMLValueType.VEHICLE_MATERIAL, p57 .. "#materialTemplateName", "Top arm material (applied to \'upperLink_main_mat\')")
	p56:registerAutoCompletionDataSource(p57 .. "#materialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p56:register(XMLValueType.VEHICLE_MATERIAL, p57 .. "#materialTemplateName2", "Top arm material 2 (applied to \'upperLink_base_mat\')")
	p56:registerAutoCompletionDataSource(p57 .. "#materialTemplateName2", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p56:register(XMLValueType.VEHICLE_MATERIAL, p57 .. "#decalMaterialTemplateName", "Top arm decal color (applied to \'upperLink_decal_mat\')")
	p56:registerAutoCompletionDataSource(p57 .. "#decalMaterialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p56:register(XMLValueType.BOOL, p57 .. "#secondPartUseMainColor", "Defines if the material \'upperLink_head_mat\' uses the \'material\' or \'material2\' value", true)
	p56:register(XMLValueType.BOOL, p57 .. "#useBrandDecal", "Defines if the brand decal on the top arm is allowed or not", true)
	p56:register(XMLValueType.NODE_INDEX, p57 .. "#rotationNode", "Rotation node if top arm not loaded from i3d")
	p56:register(XMLValueType.NODE_INDEX, p57 .. "#translationNode", "Translation node if top arm not loaded from i3d")
	p56:register(XMLValueType.NODE_INDEX, p57 .. "#referenceNode", "Reference node if top arm not loaded from i3d")
	ObjectChangeUtil.registerObjectChangeXMLPaths(p56, p57)
end
function AttacherJointTopArm.registerXMLPaths(p58)
	p58:register(XMLValueType.FILENAME, "topArm.filename", "Path to top arm i3d file")
	p58:register(XMLValueType.NODE_INDEX, "topArm.rootNode#node", "Root node of the top arm")
	p58:register(XMLValueType.NODE_INDEX, "topArm.translation#node", "Translating part of the top arm")
	p58:register(XMLValueType.NODE_INDEX, "topArm.translation#referenceNode", "Reference node at the end of the top arm")
	p58:register(XMLValueType.NODE_INDEX, "topArm.scale#node", "Node that is scaled")
	p58:register(XMLValueType.NODE_INDEX, "topArm.scale#referenceNode", "Reference node at the end of the scale part")
	p58:register(XMLValueType.NODE_INDEX, "topArm.brandDecal#node", "Branded decal on the top arm")
	p58:register(XMLValueType.NODE_INDEX, "topArm.mountArm#node", "Mount arm node that can be adjusted from the vehicle")
	I3DUtil.registerI3dMappingXMLPaths(p58, "topArm")
end
g_xmlManager:addCreateSchemaFunction(function()
	AttacherJointTopArm.xmlSchema = XMLSchema.new("attacherJointTopArm")
end)
g_xmlManager:addInitSchemaFunction(function()
	AttacherJointTopArm.registerXMLPaths(AttacherJointTopArm.xmlSchema)
end)

StaticLight = {}
local v_u_1 = Class(StaticLight)
function StaticLight.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.vehicle = p2
	v5.chargeFunction = nil
	return v5
end
function StaticLight.loadFromXML(p6, p7, p8, p9, p10, p11, p12)
	p6.node = p7:getValue(p8 .. "#node", nil, p9, p10) or p7:getValue(p8 .. "#shaderNode", nil, p9, p10)
	if p6.node == nil then
		Logging.xmlWarning(p7, "Missing static lights node in \'%s\'", p8)
		return false
	end
	if getHasClassId(p6.node, ClassIds.LIGHT_SOURCE) then
		Logging.xmlWarning(p7, "Light source used in static light \'%s\'", p8)
		return false
	end
	if p12 ~= nil then
		local v13 = p6.node
		local v14 = false
		while v13 ~= nil and (v13 ~= 0 and v13 ~= getRootNode()) do
			if v13 == p12.node then
				v14 = true
				break
			end
			v13 = getParent(v13)
		end
		if not v14 then
			Logging.xmlWarning(p7, "Static light mesh \'%s\' is outside of the root shared light node (%s) in \'%s\'", getName(p6.node), getName(p12.node), p8)
			return false
		end
	end
	p6.useLightControlShaderParameter = getHasShaderParameter(p6.node, "lightControl")
	if not p6.useLightControlShaderParameter then
		p6.absUVSlotIndex = p7:getValue(p8 .. "#uvSlotIndex")
		if p6.absUVSlotIndex ~= nil then
			p6.uvSlotParameter = "lightIds0"
			p6.uvSlotIndex = p6.absUVSlotIndex
			if p6.uvSlotIndex > 4 then
				p6.uvSlotParameter = "lightIds1"
				p6.uvSlotIndex = p6.uvSlotIndex - 4
			end
			if p6.uvSlotIndex > 4 then
				p6.uvSlotParameter = "lightIds2"
				p6.uvSlotIndex = p6.uvSlotIndex - 4
			end
			if p6.uvSlotIndex > 4 then
				p6.uvSlotParameter = "lightIds3"
				p6.uvSlotIndex = p6.uvSlotIndex - 4
			end
		end
	end
	p6.intensity = p7:getValue(p8 .. "#intensity", 5)
	p6.toggleVisibility = p7:getValue(p8 .. "#toggleVisibility", false)
	if p6.toggleVisibility then
		setVisibility(p6.node, false)
	elseif not (getHasShaderParameter(p6.node, "lightControl") or getHasShaderParameter(p6.node, "lightIds0")) then
		Logging.xmlWarning(p7, "Static lights not using \'lightControl\' or \'lightIds0\' shader parameter in \'%s\'", p8)
		return false
	end
	if p11 ~= false then
		p6.lightTypes = p7:getValue(p8 .. "#lightTypes", nil, true)
		p6.excludedLightTypes = p7:getValue(p8 .. "#excludedLightTypes", nil, true)
		if p12 ~= nil then
			if p12.lightTypes ~= nil then
				p6.lightTypes = table.clone(p12.lightTypes, 1)
			end
			if p12.excludedLightTypes ~= nil then
				p6.excludedLightTypes = table.clone(p12.excludedLightTypes, 1)
			end
		end
	end
	if p12 ~= nil and p12.additionalAttributes ~= nil then
		for v15, v16 in pairs(p12.additionalAttributes) do
			p6[v15] = v16
		end
	end
	if p6.lightTypes == nil then
		p6.lightTypes = {}
	end
	if p6.excludedLightTypes == nil then
		p6.excludedLightTypes = {}
	end
	if p6.vehicle ~= nil and p7:getRootName() == "vehicle" then
		p6.vehicle:loadAdditionalLightAttributesFromXML(p7, p8, p6)
	end
	p6:setState(false)
	return true
end
function StaticLight.merge(p17, p18)
	if p17.uvSlotIndex ~= nil and (p17.uvSlotIndex ~= p18.uvSlotIndex or p17.uvSlotParameter ~= p18.uvSlotParameter) then
		return p17
	end
	for _, v19 in ipairs(p17.lightTypes) do
		table.addElement(p18.lightTypes, v19)
	end
	for _, v20 in ipairs(p17.excludedLightTypes) do
		table.addElement(p18.excludedLightTypes, v20)
	end
	return p18
end
function StaticLight.setLightTypesMask(p21, p22)
	if #p21.lightTypes == 0 then
		return
	end
	if p21.vehicle == nil then
		return
	end
	if not p21.vehicle:getIsLightActive(p21) then
		p21:setState(false, 0)
		return
	end
	local v23 = false
	local v24 = nil
	for _, v25 in pairs(p21.lightTypes) do
		if bitAND(p22, 2 ^ v25) ~= 0 or v25 == -1 and p21.vehicle:getIsActiveForLights(true) then
			if v23 then
				if p21.vehicle.spec_lights.maxLightState < v25 then
					v24 = 2
				end
			else
				v23 = true
			end
		end
	end
	if v23 and p21.excludedLightTypes ~= nil then
		for _, v26 in pairs(p21.excludedLightTypes) do
			if bitAND(p22, 2 ^ v26) ~= 0 then
				v23 = false
				break
			end
		end
	end
	if p21.chargeFunction ~= nil then
		v24 = p21.chargeFunction(p21.chargeFunctionTarget)
	end
	p21:setState(v23, v24)
end
function StaticLight.setIsBlinking(p27, _)
	if not p27.useLightControlShaderParameter then
		if p27.absUVSlotIndex == nil then
			local v28 = 0
			for v29 = 0, 11 do
				v28 = bitOR(v28, bitShiftLeft(StaticLightCompoundLightType.BLINKING - 1, v29 * 2))
			end
			setShaderParameter(p27.node, "lightTypeBitMask", v28, nil, nil, nil, false)
			return
		end
		if p27.absUVSlotIndex <= 12 then
			local v30 = getShaderParameter(p27.node, "lightTypeBitMask")
			local v31 = (p27.absUVSlotIndex - 1) * 2
			local v32 = 16777215 - bitShiftLeft(3, v31)
			local v33 = bitAND(v30, v32)
			local v34 = bitOR(v33, bitShiftLeft(StaticLightCompoundLightType.BLINKING - 1, v31))
			setShaderParameter(p27.node, "lightTypeBitMask", v34, nil, nil, nil, false)
		end
	end
end
function StaticLight.setState(p35, p36, p37)
	if p35.toggleVisibility then
		setVisibility(p35.node, p36)
		return
	else
		local v38 = p35.intensity * (p37 or (p36 and 1 or 0))
		if p35.useLightControlShaderParameter then
			setShaderParameter(p35.node, "lightControl", v38, nil, nil, nil, false)
		elseif p35.uvSlotIndex == nil then
			setShaderParameter(p35.node, "lightIds0", v38, v38, v38, v38, false)
			setShaderParameter(p35.node, "lightIds1", v38, v38, v38, v38, false)
			setShaderParameter(p35.node, "lightIds2", v38, v38, v38, v38, false)
			setShaderParameter(p35.node, "lightIds3", v38, v38, v38, v38, false)
		else
			if p35.uvSlotIndex == 1 then
				setShaderParameter(p35.node, p35.uvSlotParameter, v38, nil, nil, nil, false)
				return
			end
			if p35.uvSlotIndex == 2 then
				setShaderParameter(p35.node, p35.uvSlotParameter, nil, v38, nil, nil, false)
				return
			end
			if p35.uvSlotIndex == 3 then
				setShaderParameter(p35.node, p35.uvSlotParameter, nil, nil, v38, nil, false)
				return
			end
			if p35.uvSlotIndex == 4 then
				setShaderParameter(p35.node, p35.uvSlotParameter, nil, nil, nil, v38, false)
				return
			end
		end
	end
end
function StaticLight.setChargeFunction(p39, p40, p41)
	p39.chargeFunction = p40
	p39.chargeFunctionTarget = p41
end
function StaticLight.loadLightsFromXML(p42, p43, p44, p45, p46, p47, p48, p49)
	local v50 = p42 == nil and {} or p42
	for _, v51 in p43:iterator(p44) do
		local v52 = StaticLight.new(p45)
		if v52:loadFromXML(p43, v51, p46, p47, p48, p49) then
			if p45 ~= nil then
				local v53 = p45:getStaticLightFromNode(v52.node)
				if v53 ~= nil then
					v52 = v52:merge(v53)
				end
			end
			table.insert(v50, v52)
		end
	end
	return v50
end
function StaticLight.registerXMLPaths(p54, p55)
	p54:register(XMLValueType.NODE_INDEX, p55 .. "#node", "Visual light node")
	p54:register(XMLValueType.NODE_INDEX, p55 .. "#shaderNode", "Shader node")
	p54:register(XMLValueType.INT, p55 .. "#uvSlotIndex", "UV slot if vehicleShader with \'lightIds\' shader parameter is used (slot 1-16)", "if not defined, all slots will be set equally")
	p54:register(XMLValueType.FLOAT, p55 .. "#intensity", "Intensity", 5)
	p54:register(XMLValueType.BOOL, p55 .. "#toggleVisibility", "Toggle visibility", false)
	p54:register(XMLValueType.VECTOR_N, p55 .. "#excludedLightTypes", "Excluded light types")
	p54:register(XMLValueType.VECTOR_N, p55 .. "#lightTypes", "Light types")
end

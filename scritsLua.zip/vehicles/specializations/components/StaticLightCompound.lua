StaticLightCompound = {}
source("dataS/scripts/vehicles/specializations/components/StaticLightCompoundUVSlot.lua")
source("dataS/scripts/vehicles/specializations/components/StaticLightCompoundLightType.lua")
local v_u_1 = Class(StaticLightCompound)
function StaticLightCompound.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.vehicle = p2
	return v5
end
function StaticLightCompound.loadFunctionMappingData(p6, p7)
	local v8 = {}
	for _, v9 in p6:iterator(p7 .. ".function") do
		local v10 = p6:getValue(v9 .. "#name")
		if v10 == nil then
			Logging.xmlWarning(p6, "Missing function name in \'%s\'", v9)
		else
			local v11 = StaticLightCompoundUVSlot.getByName(v10)
			if v11 == nil then
				Logging.xmlWarning(p6, "Invalid function name \'%s\' in \'%s\'", v10, v9)
			else
				local v12 = p6:getValue(v9 .. "#uvSlotIndex", v11)
				if v12 >= 1 and v12 <= 16 then
					local v13 = p6:getValue(v9 .. "#uvOffset", 0)
					local v14 = p6:getValue(v9 .. "#intensityScale", 1)
					local v15 = p6:getValue(v9 .. "#lightType")
					local v16 = {
						["defaultSlotIndex"] = v11,
						["uvSlotIndex"] = v12,
						["uvOffset"] = v13,
						["intensityScale"] = v14,
						["lightTypeIndex"] = StaticLightCompoundLightType.getByName(v15)
					}
					table.insert(v8, v16)
				else
					Logging.xmlWarning(p6, "UV slot index out of range \'%d\' in \'%s\'. Range 1-16 is allowed.", v12, v9)
				end
			end
		end
	end
	return v8
end
function StaticLightCompound.loadFromXML(p17, p18, p19, p20, p21, p22, p23)
	p17.bottomLightAsHighBeam = p18:getValue(p19 .. "#bottomLightAsHighBeam", true)
	p17.topLightAsHighBeam = p18:getValue(p19 .. "#topLightAsHighBeam", true)
	p17.useSliderTurnLights = p18:getValue(p19 .. "#useSliderTurnLights", false)
	p17.intensity = {}
	p17.intensity[StaticLightCompoundUVSlot.HIGH_BEAM] = 1.4
	p17.intensity[StaticLightCompoundUVSlot.DAY_TIME_RUNNING_LIGHT] = 0.4
	p17.funcToUVSlotMapping = {}
	for v24 = 1, 16 do
		p17.funcToUVSlotMapping[v24] = {}
	end
	local v25 = StaticLightCompound.loadFunctionMappingData(p18, p19)
	for _, v26 in ipairs(v25) do
		local v27 = p17.funcToUVSlotMapping[v26.defaultSlotIndex]
		table.insert(v27, v26)
	end
	if p23 ~= nil and p23.functionMappingData ~= nil then
		for _, v28 in ipairs(p23.functionMappingData) do
			for _, v29 in pairs(p17.funcToUVSlotMapping) do
				for v30 = #v29, 1, -1 do
					if v29[v30].uvSlotIndex == v28.uvSlotIndex then
						table.remove(v29, v30)
					end
				end
			end
		end
		for _, v31 in ipairs(p23.functionMappingData) do
			local v32 = p17.funcToUVSlotMapping[v31.defaultSlotIndex]
			table.insert(v32, v31)
		end
	end
	for v33 = 1, 16 do
		local v34 = false
		for _, v35 in pairs(p17.funcToUVSlotMapping) do
			for _, v36 in pairs(v35) do
				if v36.uvSlotIndex == v33 then
					v34 = true
					break
				end
			end
			if v34 then
				break
			end
		end
		if not v34 then
			local v37 = p17.funcToUVSlotMapping[v33]
			table.insert(v37, {
				["uvSlotIndex"] = v33,
				["uvOffset"] = 0,
				["intensityScale"] = 1
			})
		end
	end
	p17.nodes = {}
	for _, v38 in p18:iterator(p19 .. ".node") do
		local v39 = p18:getValue(v38 .. "#node", nil, p20, p21)
		if v39 == nil then
			Logging.xmlWarning(p18, "Invalid node in \'%s\'", v38)
		elseif p23 == nil then
			::l40::
			if getHasClassId(v39, ClassIds.LIGHT_SOURCE) then
				Logging.xmlWarning(p18, "Light source used in static light compound in \'%s\'", v38)
			elseif getHasShaderParameter(v39, "lightIds0") then
				setShaderParameter(v39, "lightIds0", 0, 0, 0, 0, false)
				setShaderParameter(v39, "lightIds1", 0, 0, 0, 0, false)
				setShaderParameter(v39, "lightIds2", 0, 0, 0, 0, false)
				setShaderParameter(v39, "lightIds3", 0, 0, 0, 0, false)
				local v40 = {
					["node"] = v39,
					["intensity"] = p18:getValue(v38 .. "#intensity", 5),
					["useSliderTurnLights"] = p18:getValue(v38 .. "#useSliderTurnLights", p17.useSliderTurnLights)
				}
				if p22 ~= nil and p18:getRootName() == "vehicle" then
					p22:loadAdditionalLightAttributesFromXML(p18, v38, v40)
				end
				if p23 ~= nil and p23.additionalAttributes ~= nil then
					for v41, v42 in pairs(p23.additionalAttributes) do
						v40[v41] = v42
					end
				end
				local v43 = p17.nodes
				table.insert(v43, v40)
			else
				Logging.xmlWarning(p18, "Wrong shader applied to static light compound in \'%s\'. Missing \'lightIds\' shader parameter.", v38)
			end
		else
			local v44 = v39
			local v45 = false
			while v39 ~= nil and (v39 ~= 0 and v39 ~= getRootNode()) do
				if v39 == p23.node then
					v45 = true
					break
				end
				v39 = getParent(v39)
			end
			if v45 then
				v39 = v44
				goto l40
			end
			Logging.xmlWarning(p18, "Static compound light mesh \'%s\' is outside of the root shared light node (%s) in \'%s\'", getName(v44), getName(p23.node), p19)
		end
	end
	if #p17.nodes == 0 then
		Logging.xmlWarning(p18, "Missing nodes for static light compound in \'%s\'", p19)
		return false
	end
	p17.states = {}
	p17.stateFuncTypes = {}
	p17.stateLightTypes = {}
	p17.stateUVOffsets = {}
	for _ = 1, 16 do
		local v46 = p17.states
		table.insert(v46, 0)
		local v47 = p17.stateFuncTypes
		table.insert(v47, 0)
		local v48 = p17.stateLightTypes
		table.insert(v48, -1)
		local v49 = p17.stateUVOffsets
		table.insert(v49, 0)
	end
	return true
end
function StaticLightCompound.setLightTypes(p50, p51, p52)
	if p51 ~= nil and next(p51) ~= nil then
		p50.lightTypes = p51
	end
	if p52 ~= nil and next(p52) ~= nil then
		p50.excludedLightTypes = p52
	end
end
function StaticLightCompound.setOverwriteSettings(p53, p54, p55, p56)
	p53.turnLightLeft = p54
	p53.turnLightRight = p55
	p53.reverseLight = p56
	if p54 then
		if p53.lightTypes == nil then
			p53.lightTypes = {}
		end
		local v57 = p53.lightTypes
		local v58 = p53.vehicle.spec_lights.additionalLightTypes.turnLightLeft
		table.insert(v57, v58)
		local v59 = p53.lightTypes
		local v60 = p53.vehicle.spec_lights.additionalLightTypes.turnLightAny
		table.insert(v59, v60)
	end
	if p55 then
		if p53.lightTypes == nil then
			p53.lightTypes = {}
		end
		local v61 = p53.lightTypes
		local v62 = p53.vehicle.spec_lights.additionalLightTypes.turnLightRight
		table.insert(v61, v62)
		local v63 = p53.lightTypes
		local v64 = p53.vehicle.spec_lights.additionalLightTypes.turnLightAny
		table.insert(v63, v64)
	end
	if p56 then
		if p53.lightTypes == nil then
			p53.lightTypes = {}
		end
		local v65 = p53.lightTypes
		local v66 = p53.vehicle.spec_lights.additionalLightTypes.reverseLight
		table.insert(v65, v66)
	end
end
function StaticLightCompound.setLightTypesMask(p67, p68, p69)
	local v70
	if p67.lightTypes == nil then
		v70 = 1
	else
		local v71 = false
		for _, v72 in pairs(p67.lightTypes) do
			if bitAND(p68, 2 ^ v72) ~= 0 then
				v71 = true
				break
			end
		end
		if v71 and p67.excludedLightTypes ~= nil then
			for _, v73 in pairs(p67.excludedLightTypes) do
				if bitAND(p68, 2 ^ v73) ~= 0 then
					v71 = false
					break
				end
			end
		end
		p67.states[1] = v71 and 1 or 0
		if p67.turnLightLeft then
			p67.stateFuncTypes[1] = StaticLightCompoundUVSlot.TURN_LIGHT_LEFT
			v70 = 2
		elseif p67.turnLightRight then
			p67.stateFuncTypes[1] = StaticLightCompoundUVSlot.TURN_LIGHT_RIGHT
			v70 = 2
		else
			v70 = 2
		end
	end
	for v74 = v70, 16 do
		p67.states[v74] = 0
		p67.stateFuncTypes[v74] = 0
		p67.stateLightTypes[v74] = -1
		p67.stateUVOffsets[v74] = 0
		for v75, v76 in pairs(p67.funcToUVSlotMapping) do
			for _, v77 in pairs(v76) do
				if v77.uvSlotIndex == v74 then
					local v78 = p67:getStateValueByFunction(v74, v75, p68, p69)
					if v78 > 0 then
						p67.states[v74] = v78 * (p67.intensity[v75] or 1) * v77.intensityScale
						if p67.stateFuncTypes[v74] ~= StaticLightCompoundUVSlot.TURN_LIGHT_LEFT and p67.stateFuncTypes[v74] ~= StaticLightCompoundUVSlot.TURN_LIGHT_RIGHT then
							p67.stateFuncTypes[v74] = v75
						end
						p67.stateUVOffsets[v74] = v77.uvOffset
						if v77.lightTypeIndex ~= nil then
							p67.stateLightTypes[v74] = v77.lightTypeIndex
						end
						break
					end
				end
			end
		end
	end
	local v79 = p67:getLightTypeMaskFromStates(p67.useSliderTurnLights)
	local v80 = p67:getUVOffsetMaskFromStates()
	for _, v81 in ipairs(p67.nodes) do
		if p69:getIsLightActive(v81) then
			local v82 = v81.intensity
			setShaderParameter(v81.node, "lightIds0", p67.states[1] * v82, p67.states[2] * v82, p67.states[3] * v82, p67.states[4] * v82, false)
			setShaderParameter(v81.node, "lightIds1", p67.states[5] * v82, p67.states[6] * v82, p67.states[7] * v82, p67.states[8] * v82, false)
			setShaderParameter(v81.node, "lightIds2", p67.states[9] * v82, p67.states[10] * v82, p67.states[11] * v82, p67.states[12] * v82, false)
			setShaderParameter(v81.node, "lightIds3", p67.states[13] * v82, p67.states[14] * v82, p67.states[15] * v82, p67.states[16] * v82, false)
			if p67.useSliderTurnLights == v81.useSliderTurnLights then
				setShaderParameter(v81.node, "lightTypeBitMask", v79, nil, nil, nil, false)
			else
				local v83 = p67:getLightTypeMaskFromStates(v81.useSliderTurnLights)
				setShaderParameter(v81.node, "lightTypeBitMask", v83, nil, nil, nil, false)
			end
			setShaderParameter(v81.node, "lightUvOffsetBitMask", v80, nil, nil, nil, false)
		else
			setShaderParameter(v81.node, "lightIds0", 0, 0, 0, 0, false)
			setShaderParameter(v81.node, "lightIds1", 0, 0, 0, 0, false)
			setShaderParameter(v81.node, "lightIds2", 0, 0, 0, 0, false)
			setShaderParameter(v81.node, "lightIds3", 0, 0, 0, 0, false)
		end
	end
end
function StaticLightCompound.getStateValueByFunction(p84, _, p85, p86, p87)
	local v88 = p87.spec_lights
	local v89 = bitAND(p86, 2 ^ Lights.LIGHT_TYPE_HIGHBEAM) ~= 0
	local v90 = 0
	if p85 == StaticLightCompoundUVSlot.DEFAULT_LIGHT then
		return bitAND(p86, 2 ^ Lights.LIGHT_TYPE_DEFAULT) == 0 and 0 or 1
	end
	local v91
	if p85 == StaticLightCompoundUVSlot.DEFAULT_LIGHT_HIGH_BEAM then
		v91 = (v89 or bitAND(p86, 2 ^ Lights.LIGHT_TYPE_DEFAULT) ~= 0) and 1 or 0
		if v89 then
			return math.max(v91, 1) * (p84.intensity[StaticLightCompoundUVSlot.HIGH_BEAM] or 2)
		end
	else
		if p85 == StaticLightCompoundUVSlot.HIGH_BEAM then
			return v89 and 1 or 0
		end
		if p85 == StaticLightCompoundUVSlot.BOTTOM_LIGHT then
			v91 = bitAND(p86, 2 ^ v88.additionalLightTypes.bottomLight) == 0 and 0 or 1
			if p84.bottomLightAsHighBeam and (not v88.topLightsVisibility and v89) then
				return math.max(v91, 1) * (p84.intensity[StaticLightCompoundUVSlot.HIGH_BEAM] or 2)
			end
		elseif p85 == StaticLightCompoundUVSlot.TOP_LIGHT then
			v91 = bitAND(p86, 2 ^ v88.additionalLightTypes.topLight) == 0 and 0 or 1
			if p84.topLightAsHighBeam and (v88.topLightsVisibility and v89) then
				return math.max(v91, 1) * (p84.intensity[StaticLightCompoundUVSlot.HIGH_BEAM] or 2)
			end
		else
			if p85 == StaticLightCompoundUVSlot.DAY_TIME_RUNNING_LIGHT then
				return (p87:getIsPowered() or p87:getIsInShowroom()) and 1 or 0
			end
			if p85 == StaticLightCompoundUVSlot.TURN_LIGHT_LEFT then
				return bitAND(p86, 2 ^ v88.additionalLightTypes.turnLightLeft) == 0 and bitAND(p86, 2 ^ v88.additionalLightTypes.turnLightAny) == 0 and 0 or 1
			end
			if p85 == StaticLightCompoundUVSlot.TURN_LIGHT_RIGHT then
				return bitAND(p86, 2 ^ v88.additionalLightTypes.turnLightRight) == 0 and bitAND(p86, 2 ^ v88.additionalLightTypes.turnLightAny) == 0 and 0 or 1
			end
			if p85 == StaticLightCompoundUVSlot.BACK_LIGHT then
				return bitAND(p86, 2 ^ Lights.LIGHT_TYPE_DEFAULT) == 0 and 0 or 1
			end
			if p85 == StaticLightCompoundUVSlot.BRAKE_LIGHT then
				return bitAND(p86, 2 ^ v88.additionalLightTypes.brakeLight) == 0 and 0 or 1
			end
			if p85 == StaticLightCompoundUVSlot.BACK_BRAKE_LIGHT then
				local v92 = 0
				if bitAND(p86, 2 ^ Lights.LIGHT_TYPE_DEFAULT) ~= 0 then
					v92 = v92 + 1
				end
				if bitAND(p86, 2 ^ v88.additionalLightTypes.brakeLight) ~= 0 then
					v92 = v92 + 1
				end
				return v92
			end
			if p85 == StaticLightCompoundUVSlot.REVERSE_LIGHT then
				return bitAND(p86, 2 ^ v88.additionalLightTypes.reverseLight) == 0 and 0 or 1
			end
			if p85 == StaticLightCompoundUVSlot.WORK_LIGHT_FRONT then
				return bitAND(p86, 2 ^ Lights.LIGHT_TYPE_WORK_FRONT) == 0 and 0 or 1
			end
			if p85 == StaticLightCompoundUVSlot.WORK_LIGHT_BACK then
				return bitAND(p86, 2 ^ Lights.LIGHT_TYPE_WORK_BACK) == 0 and 0 or 1
			end
			if p85 == StaticLightCompoundUVSlot.WORK_LIGHT_ADDITIONAL then
				return bitAND(p86, 2 ^ (Lights.LIGHT_TYPE_HIGHBEAM + 1)) == 0 and 0 or 1
			end
			v91 = p85 == StaticLightCompoundUVSlot.WORK_LIGHT_ADDITIONAL2 and (bitAND(p86, 2 ^ (Lights.LIGHT_TYPE_HIGHBEAM + 2)) == 0 and 0 or 1) or v90
		end
	end
	return v91
end
function StaticLightCompound.getLightTypeMaskFromStates(p93, p94)
	local v95 = 0
	for v96 = 1, 12 do
		local v97 = p93.stateFuncTypes[v96]
		local v98
		if v97 == StaticLightCompoundUVSlot.TURN_LIGHT_LEFT or v97 == StaticLightCompoundUVSlot.TURN_LIGHT_RIGHT then
			v98 = p94 and StaticLightCompoundLightType.SLIDE or StaticLightCompoundLightType.BLINKING
		else
			v98 = nil
		end
		if p93.stateLightTypes[v96] ~= -1 then
			v98 = p93.stateLightTypes[v96]
		end
		if v98 ~= nil then
			v95 = bitOR(bitShiftLeft(v98 - 1, (v96 - 1) * 2), v95)
		end
	end
	return v95
end
function StaticLightCompound.getUVOffsetMaskFromStates(p99)
	local v100 = 0
	for v101 = 1, 4 do
		local v102 = p99.stateUVOffsets[v101]
		v100 = bitOR(bitShiftLeft(v102, (v101 - 1) * 6), v100)
	end
	return v100
end
function StaticLightCompound.registerXMLPaths(p103, p104)
	p103:register(XMLValueType.BOOL, p104 .. "#bottomLightAsHighBeam", "Use bottom light as high beam as well", true)
	p103:register(XMLValueType.BOOL, p104 .. "#topLightAsHighBeam", "Use top light as high beam as well", true)
	p103:register(XMLValueType.BOOL, p104 .. "#useSliderTurnLights", "Turn lights will work as sliders if set to \'true\'", false)
	p103:register(XMLValueType.NODE_INDEX, p104 .. ".node(?)#node", "Static light node")
	p103:register(XMLValueType.FLOAT, p104 .. ".node(?)#intensity", "Intensity for all lights in this node", 5)
	p103:register(XMLValueType.BOOL, p104 .. ".node(?)#useSliderTurnLights", "Turn lights will work as sliders if set to \'true\'", false)
	p103:register(XMLValueType.INT, p104 .. ".node(?)#lightTypeBitMask", "Custom light type bit mask")
	p103:register(XMLValueType.STRING, p104 .. ".function(?)#name", "Function name", nil, nil, StaticLightCompoundUVSlot.getAllOrderedByName())
	p103:register(XMLValueType.INT, p104 .. ".function(?)#uvSlotIndex", "Custom UV slot index to assign the defined function name")
	p103:register(XMLValueType.INT, p104 .. ".function(?)#uvOffset", "Vertical UV offset that is used while this light function is active (value range: 0-64 -> this represents the height of the texture with a resolution of 1/64). This is used for double usage of certain lights with different colors.", 0)
	p103:register(XMLValueType.FLOAT, p104 .. ".function(?)#intensityScale", "Custom intensity scale for this light type (is multiplied by the intensity defined in the node)")
	p103:register(XMLValueType.STRING, p104 .. ".function(?)#lightType", "Name of the light type to use", nil, nil, StaticLightCompoundLightType.getAllOrderedByName())
	p103:register(XMLValueType.INT, p104 .. "#lightTypeBitMask", "Custom light type bit mask", "Default mask is \'20480\' with blinking type set for turn light slots 7 & 8")
end

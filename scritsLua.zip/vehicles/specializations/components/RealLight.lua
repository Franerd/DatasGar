RealLight = {}
RealLight.SCATTERING_MAX_ANGLE = 60
RealLight.DEFAULT_LIGHT_PROFILE = {}
RealLight.DEFAULT_LIGHT_PROFILE.worklight = {
	["iesProfile"] = "data/shared/ies/workLight.ies",
	["intensityScale"] = 1.25
}
RealLight.DEFAULT_LIGHT_PROFILE.highbeam = {
	["iesProfile"] = "data/shared/ies/highBeam.ies",
	["intensityScale"] = 2
}
RealLight.DEFAULT_LIGHT_PROFILE.backlight = {
	["iesProfile"] = "data/shared/ies/backLight.ies",
	["intensityScale"] = 1
}
RealLight.DEFAULT_LIGHT_PROFILE.brakelight = {
	["iesProfile"] = "data/shared/ies/backLight.ies",
	["intensityScale"] = 1
}
RealLight.DEFAULT_LIGHT_PROFILE.frontlight = {
	["iesProfile"] = "data/shared/ies/frontLight.ies",
	["intensityScale"] = 1
}
RealLight.DEFAULT_LIGHT_PROFILE.turnlight = {
	["iesProfile"] = "data/shared/ies/turnLight.ies",
	["intensityScale"] = 1
}
RealLight.DEFAULT_LIGHT_PROFILE.reverselight = {
	["iesProfile"] = "data/shared/ies/workLight.ies",
	["intensityScale"] = 1.25
}
local v_u_1 = Class(RealLight)
function RealLight.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.vehicle = p2
	v5.chargeFunction = nil
	return v5
end
function RealLight.loadFromXML(p_u_6, p_u_7, p_u_8, p9, p10, p11)
	p_u_6.node = p_u_7:getValue(p_u_8 .. "#node", nil, p9, p10)
	if p_u_6.node == nil then
		Logging.xmlWarning(p_u_7, "Missing light source node in \'%s\'", p_u_8)
		return false
	end
	if not getHasClassId(p_u_6.node, ClassIds.LIGHT_SOURCE) then
		Logging.xmlWarning(p_u_7, "Defined node is not a light source \'%s\'", p_u_8)
		return false
	end
	p_u_6.lightSources = { p_u_6.node }
	I3DUtil.iterateRecursively(p_u_6.node, function(p12)
		-- upvalues: (copy) p_u_7, (copy) p_u_8, (copy) p_u_6
		if not getVisibility(p12) then
			Logging.xmlWarning(p_u_7, "Real light source \'%s\' is hidden in \'%s\'!", getName(p12), p_u_8)
		end
		if getHasClassId(p12, ClassIds.LIGHT_SOURCE) then
			local v13 = p_u_6.lightSources
			table.insert(v13, p12)
		end
	end)
	p_u_6.defaultColor = p_u_6.defaultColor or { getLightColor(p_u_6.node) }
	p_u_6.intensityScale = p_u_7:getValue(p_u_8 .. "#intensityScale", 1)
	p_u_6.curIntensityScale = p_u_6.intensityScale
	setVisibility(p_u_6.node, false)
	if p11 ~= false then
		p_u_6.lightTypes = p_u_7:getValue(p_u_8 .. "#lightTypes", nil, true)
		p_u_6.excludedLightTypes = p_u_7:getValue(p_u_8 .. "#excludedLightTypes", nil, true)
	end
	if p_u_6.lightTypes == nil then
		p_u_6.lightTypes = {}
	end
	if p_u_6.excludedLightTypes == nil then
		p_u_6.excludedLightTypes = {}
	end
	local v14 = false
	for _, v15 in ipairs(p_u_6.lightTypes) do
		if v15 == Lights.LIGHT_TYPE_DEFAULT or v15 == Lights.LIGHT_TYPE_HIGHBEAM then
			v14 = true
			break
		end
	end
	local v16 = g_gameSettings:getValue(GameSettings.SETTING.LIGHTS_PROFILE)
	local v17 = p_u_7:getValue(p_u_8 .. "#iesProfile")
	if v17 ~= nil then
		p_u_6.xmlIESProfile = Utils.getFilename(v17, p_u_6.vehicle.baseDirectory)
	end
	p_u_6:updateDefaultProfile(v16 == GS_PROFILE_VERY_HIGH and true or v16 == GS_PROFILE_ULTRA)
	for _, v18 in ipairs(p_u_6.lightSources) do
		local v19 = false
		local v20 = p_u_7:getValue(p_u_8 .. "#useLightScattering")
		if v20 == true then
			v19 = GS_PROFILE_HIGH <= v16
		elseif v20 == nil then
			if v14 then
				v19 = GS_PROFILE_HIGH <= v16
			elseif #p_u_6.lightTypes > 0 then
				v19 = GS_PROFILE_VERY_HIGH <= v16
			end
			if v19 then
				v19 = getLightRange(v18) > 7.5
			end
		end
		if v19 then
			setLightUseLightScattering(v18, true)
			if getLightConeAngle(v18) > RealLight.SCATTERING_MAX_ANGLE then
				setLightScatteringConeAngle(v18, RealLight.SCATTERING_MAX_ANGLE)
			end
			setLightScatteringIntensity(v18, 1)
		elseif getLightUseLightScattering(v18) then
			setLightUseLightScattering(v18, false)
		end
	end
	p_u_6.hasMergedShadows = false
	if v16 == GS_PROFILE_ULTRA and p_u_7:getValue(p_u_8 .. "#hasShadows", getLightRange(p_u_6.node) > 7.5) then
		if #p_u_6.lightSources > 1 then
			local v21 = p_u_7:getValue(p_u_8 .. "#shadowLightOffset", nil, true)
			local v22 = 0
			local v23 = 0
			local v24 = 0
			local v25 = 0
			local v26 = 0
			local v27 = 0
			local v28 = 0
			local v29 = 0
			for _, v30 in ipairs(p_u_6.lightSources) do
				local v31 = getLightRange
				v24 = math.max(v24, v31(v30))
				local v32 = getLightConeAngle
				v25 = math.max(v25, v32(v30))
				local v33, v34, v35 = localToLocal(v30, getParent(p_u_6.node), 0, 0, 0)
				v26 = v26 + v33
				v27 = v27 + v34
				v28 = v28 + v35
				local v36, v37, v38 = localToLocal(v30, getParent(p_u_6.node), 0, 0, -20)
				v29 = v29 + v36
				v22 = v22 + v37
				v23 = v23 + v38
			end
			local v39 = #p_u_6.lightSources
			if v39 > 1 then
				v26 = v26 / v39
				v27 = v27 / v39
				v28 = v28 / v39
				v29 = v29 / v39
				v22 = v22 / v39
				v23 = v23 / v39
			end
			local v40 = createLightSource(getName(p_u_6.node) .. "_shadow", LightType.SPOT, 0.85, 0.85, 1, v24)
			local v41 = setLightConeAngle
			local v42 = RealLight.getMergedConeAngleSize
			local v43 = p_u_6.lightSources
			v41(v40, (math.max(v25, v42(v43))))
			setLightShadowMap(v40, true, 512)
			setVisibility(v40, false)
			link(getParent(p_u_6.node), v40)
			setTranslation(v40, v26, v27, v28)
			setLightSoftShadowSize(v40, 0.008)
			setLightSoftShadowDistance(v40, 15)
			setLightSoftShadowDepthBiasFactor(v40, 0.02)
			local v44, v45, v46 = MathUtil.vector3Normalize(v29 - v26, v22 - v27, v23 - v28)
			setDirection(v40, -v44, -v45, -v46, 0, 1, 0)
			if v21 ~= nil then
				local v47, v48, v49 = localToLocal(v40, getParent(v40), v21[1], v21[2], -v21[3])
				setTranslation(v40, v47, v48, v49)
			end
			for _, v50 in ipairs(p_u_6.lightSources) do
				setLightShadowMap(v50, true, 512)
			end
			local v51 = mergeLightShadows
			local v52 = p_u_6.lightSources
			v51(table.unpack(v52))
			setMergedShadowSettingsLight(p_u_6.node, v40)
			p_u_6.hasMergedShadows = true
		else
			setLightShadowMap(p_u_6.node, true, 512)
		end
	end
	if p_u_7:getRootName() == "vehicle" then
		p_u_6.vehicle:loadAdditionalLightAttributesFromXML(p_u_7, p_u_8, p_u_6)
	end
	return true
end
function RealLight.merge(p53, p54)
	for _, v55 in ipairs(p53.lightTypes) do
		table.addElement(p54.lightTypes, v55)
	end
	for _, v56 in ipairs(p53.excludedLightTypes) do
		table.addElement(p54.excludedLightTypes, v56)
	end
	return p54
end
function RealLight.updateDefaultProfile(p57, p58)
	for _, v59 in ipairs(p57.lightSources) do
		local v60 = string.lower(getName(v59))
		for v61, v62 in pairs(RealLight.DEFAULT_LIGHT_PROFILE) do
			if string.contains(v60, v61) then
				if p58 then
					if p57.xmlIESProfile == nil then
						if getLightIESProfile(v59) == "" then
							setLightIESProfile(v59, v62.iesProfile)
						end
					else
						setLightIESProfile(v59, p57.xmlIESProfile)
					end
				elseif getLightIESProfile(v59) ~= "" then
					setLightIESProfile(v59, "")
					p57.curIntensityScale = p57.intensityScale
				end
				p57.curIntensityScale = p57.intensityScale * v62.intensityScale
				break
			end
		end
	end
end
function RealLight.finalize(p63)
	if p63.hasMergedShadows then
		for _, v64 in ipairs(p63.vehicle.components) do
			addMergedShadowIgnoreShapes(p63.lightSources[1], v64.node)
		end
	end
end
function RealLight.setLightTypesMask(p65, p66)
	if not p65.vehicle:getIsLightActive(p65) then
		p65:setState(false, 0)
		return
	end
	local v67 = false
	local v68 = 1
	if p65.lightTypes == nil then
		v67 = false
	else
		for _, v69 in pairs(p65.lightTypes) do
			if bitAND(p66, 2 ^ v69) ~= 0 or v69 == -1 and p65.vehicle:getIsActiveForLights(true) then
				if v67 then
					if p65.vehicle.spec_lights.maxLightState < v69 then
						v68 = 2
					end
				else
					v67 = true
				end
			end
		end
		if v67 and p65.excludedLightTypes ~= nil then
			for _, v70 in pairs(p65.excludedLightTypes) do
				if bitAND(p66, 2 ^ v70) ~= 0 then
					v67 = false
					break
				end
			end
		end
	end
	if p65.chargeFunction ~= nil then
		v68 = p65.chargeFunction(p65.chargeFunctionTarget)
	end
	p65:setState(v67, v68)
end
function RealLight.setIsBlinking(_, _) end
function RealLight.setState(p71, p72, p73)
	p71:setCharge(p73 or (p72 and 1 or 0))
	setVisibility(p71.node, p72)
end
function RealLight.setCharge(p74, p75)
	local v76 = p75 * p74.curIntensityScale
	local v77 = p74.defaultColor
	for _, v78 in ipairs(p74.lightSources) do
		setLightColor(v78, v77[1] * v76, v77[2] * v76, v77[3] * v76)
	end
end
function RealLight.setChargeFunction(p79, p80, p81)
	p79.chargeFunction = p80
	p79.chargeFunctionTarget = p81
end
function RealLight.getAreShadowsMergable(p82)
	for _, v83 in ipairs(p82) do
		for _, v84 in ipairs(p82) do
			if v83 ~= v84 then
				local v85 = getLightConeAngle(v84)
				local v86, v87 = MathUtil.getDirectionFromYRotation(v85 * 0.5)
				local v88, v89, v90 = localDirectionToLocal(v84, v83, v86, 0, -v87)
				local v91 = v88 ^ 2 + v89 ^ 2
				local v92 = math.sqrt(v91)
				local v93 = math.abs(v90)
				local v94 = math.abs(v90) ^ 2 + v92 ^ 2
				local v95 = v93 / math.sqrt(v94)
				local v96 = math.acos(v95)
				if v90 > 0 then
					v96 = 3.141592653589793 - v96
				end
				if v96 + v85 * 0.5 > 3.141592653589793 then
					return false
				end
				local v97, v98 = MathUtil.getDirectionFromYRotation(-v85 * 0.5)
				local v99, v100, v101 = localDirectionToLocal(v84, v83, v97, 0, -v98)
				local v102 = v99 ^ 2 + v100 ^ 2
				local v103 = math.sqrt(v102)
				local v104 = math.abs(v101)
				local v105 = math.abs(v101) ^ 2 + v103 ^ 2
				local v106 = v104 / math.sqrt(v105)
				local v107 = math.acos(v106)
				if v101 > 0 then
					v107 = 3.141592653589793 - v107
				end
				if v107 + v85 * 0.5 > 3.141592653589793 then
					return false
				end
			end
		end
	end
	return true
end
function RealLight.getMergedConeAngleSize(p108)
	local v109 = 0
	for _, v110 in ipairs(p108) do
		for _, v111 in ipairs(p108) do
			if v110 ~= v111 then
				local v112 = getLightConeAngle(v111)
				local v113, v114 = MathUtil.getDirectionFromYRotation(v112 * 0.5)
				local v115, v116, v117 = localDirectionToLocal(v111, v110, v113, 0, -v114)
				local v118 = v115 ^ 2 + v116 ^ 2
				local v119 = math.sqrt(v118)
				local v120 = math.abs(v117)
				local v121 = math.abs(v117) ^ 2 + v119 ^ 2
				local v122 = v120 / math.sqrt(v121)
				local v123 = math.acos(v122)
				if v117 > 0 then
					v123 = 3.141592653589793 - v123
				end
				local v124 = v123 + v112 * 0.5
				local v125 = math.max(v109, v124)
				local v126, v127 = MathUtil.getDirectionFromYRotation(-v112 * 0.5)
				local v128, v129, v130 = localDirectionToLocal(v111, v110, v126, 0, -v127)
				local v131 = v128 ^ 2 + v129 ^ 2
				local v132 = math.sqrt(v131)
				local v133 = math.abs(v130)
				local v134 = math.abs(v130) ^ 2 + v132 ^ 2
				local v135 = v133 / math.sqrt(v134)
				local v136 = math.acos(v135)
				if v130 > 0 then
					v136 = 3.141592653589793 - v136
				end
				local v137 = v136 + v112 * 0.5
				v109 = math.max(v125, v137)
			end
		end
	end
	return v109
end
function RealLight.loadLightsFromXML(p138, p139, p140, p141, p142, p143, p144)
	local v145 = p138 == nil and {} or p138
	for _, v146 in p139:iterator(p140) do
		local v147 = RealLight.new(p141)
		if v147:loadFromXML(p139, v146, p142, p143, p144) then
			local v148 = p141:getRealLightFromNode(v147.node)
			if v148 ~= nil then
				v147 = v147:merge(v148)
			end
			table.insert(v145, v147)
		end
	end
	return v145
end
function RealLight.registerXMLPaths(p149, p150)
	p149:register(XMLValueType.NODE_INDEX, p150 .. "#node", "Real light node")
	p149:register(XMLValueType.FLOAT, p150 .. "#intensityScale", "Additional scale of the light source intensity", 1)
	p149:register(XMLValueType.VECTOR_N, p150 .. "#excludedLightTypes", "Excluded light types")
	p149:register(XMLValueType.VECTOR_N, p150 .. "#lightTypes", "Light types")
	p149:register(XMLValueType.BOOL, p150 .. "#hasShadows", "Defines if the light has shadows or not (Only in ULTRA game setting)", "Automatically when range is greater 7.5m")
	p149:register(XMLValueType.VECTOR_TRANS, p150 .. "#shadowLightOffset", "Offset of the shadow light calculation from the center of all light sources (in lighting direction)")
	p149:register(XMLValueType.STRING, p150 .. "#iesProfile", "Path to IES profile file (Only used in very high and above)")
	p149:register(XMLValueType.BOOL, p150 .. "#useLightScattering", "Defines if light scattering is used", "automatically calculated based on lightType and range")
end
function RealLight.consoleCommandDebugIES(_, p151)
	if RealLight.IES_DEBUG_ENABLED == nil then
		local v152 = Utils.getPerformanceClassId()
		RealLight.IES_DEBUG_ENABLED = v152 == GS_PROFILE_VERY_HIGH and true or v152 == GS_PROFILE_ULTRA
	end
	local v153
	if p151 == nil then
		v153 = not RealLight.IES_DEBUG_ENABLED
	else
		v153 = p151 == "true"
	end
	RealLight.IES_DEBUG_ENABLED = v153
	if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
		local v154 = g_localPlayer:getCurrentVehicle()
		for v155 = 1, #v154.childVehicles do
			local v156 = v154.childVehicles[v155]
			Logging.info("IES Profiles Enabled: \'%s\' on \'%s\'", v153, v154:getFullName())
			if v156.spec_lights ~= nil then
				for _, v157 in pairs(v156.spec_lights.realLights) do
					for _, v158 in pairs(v157) do
						for _, v159 in ipairs(v158) do
							v159:updateDefaultProfile(v153)
						end
					end
				end
			end
		end
	end
end
addConsoleCommand("gsVehicleDebugLightIESProfiles", "Enables and disables IES profiles on the light source (only the automatically assigned profiles)", "RealLight.consoleCommandDebugIES", nil)

GroundReference = {}
GroundReference.GROUND_REFERENCE_XML_KEY = "vehicle.groundReferenceNodes.groundReferenceNode(?)"
function GroundReference.prerequisitesPresent(_)
	return true
end
function GroundReference.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("GroundReference")
	local v2 = GroundReference.GROUND_REFERENCE_XML_KEY
	v1:register(XMLValueType.NODE_INDEX, v2 .. "#node", "Ground reference node")
	v1:register(XMLValueType.FLOAT, v2 .. "#threshold", "Threshold", 0)
	v1:register(XMLValueType.BOOL, v2 .. "#onlyActiveWhenLowered", "Node is only active when tool is lowered", true)
	v1:register(XMLValueType.FLOAT, v2 .. "#chargeValue", "Charge value to calculate power consumption", 1)
	v1:register(XMLValueType.FLOAT, v2 .. "#forceFactor", "Ground force factor")
	v1:register(XMLValueType.FLOAT, v2 .. "#maxActivationDepth", "Max. activation depth", 10)
	v1:register(XMLValueType.INT, SpeedRotatingParts.SPEED_ROTATING_PART_XML_KEY .. "#groundReferenceNodeIndex", "Ground reference node index")
	v1:setXMLSpecializationType()
end
function GroundReference.registerEvents(_) end
function GroundReference.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "loadGroundReferenceNode", GroundReference.loadGroundReferenceNode)
	SpecializationUtil.registerFunction(p3, "updateGroundReferenceNode", GroundReference.updateGroundReferenceNode)
	SpecializationUtil.registerFunction(p3, "getGroundReferenceNodeFromIndex", GroundReference.getGroundReferenceNodeFromIndex)
	SpecializationUtil.registerFunction(p3, "getIsGroundReferenceNodeActive", GroundReference.getIsGroundReferenceNodeActive)
	SpecializationUtil.registerFunction(p3, "getIsGroundReferenceNodeThreshold", GroundReference.getIsGroundReferenceNodeThreshold)
	SpecializationUtil.registerFunction(p3, "getGroundReferenceNodeForwardSpeed", GroundReference.getGroundReferenceNodeForwardSpeed)
end
function GroundReference.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "getPowerMultiplier", GroundReference.getPowerMultiplier)
	SpecializationUtil.registerOverwrittenFunction(p4, "loadSpeedRotatingPartFromXML", GroundReference.loadSpeedRotatingPartFromXML)
	SpecializationUtil.registerOverwrittenFunction(p4, "getIsSpeedRotatingPartActive", GroundReference.getIsSpeedRotatingPartActive)
end
function GroundReference.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", GroundReference)
	SpecializationUtil.registerEventListener(p5, "onReadUpdateStream", GroundReference)
	SpecializationUtil.registerEventListener(p5, "onWriteUpdateStream", GroundReference)
	SpecializationUtil.registerEventListener(p5, "onUpdateTick", GroundReference)
end
function GroundReference.onLoad(p6, _)
	local v7 = p6.spec_groundReference
	v7.hasForceFactors = false
	v7.groundReferenceNodes = {}
	local v8 = 0
	while true do
		local v9 = string.format("vehicle.groundReferenceNodes.groundReferenceNode(%d)", v8)
		if not p6.xmlFile:hasProperty(v9) then
			break
		end
		local v10 = {}
		if p6:loadGroundReferenceNode(p6.xmlFile, v9, v10) then
			local v11 = v7.groundReferenceNodes
			table.insert(v11, v10)
		end
		v8 = v8 + 1
	end
	local v12 = 0
	for _, v13 in pairs(v7.groundReferenceNodes) do
		v12 = v12 + v13.chargeValue
	end
	if v12 > 0 then
		for _, v14 in pairs(v7.groundReferenceNodes) do
			v14.chargeValue = v14.chargeValue / v12
		end
	end
	local v15 = 0
	for _, v16 in pairs(v7.groundReferenceNodes) do
		v15 = v15 + v16.forceFactor
	end
	if v15 > 0 then
		for _, v17 in pairs(v7.groundReferenceNodes) do
			v17.forceFactor = v17.forceFactor / v15
		end
	end
	if #v7.groundReferenceNodes == 0 then
		SpecializationUtil.removeEventListener(p6, "onUpdateTick", GroundReference)
	end
end
function GroundReference.onReadUpdateStream(p18, p19, _, p20)
	local v21 = p18.spec_groundReference
	if p20:getIsServer() then
		for _, v22 in ipairs(v21.groundReferenceNodes) do
			v22.isActive = streamReadBool(p19)
		end
	end
end
function GroundReference.onWriteUpdateStream(p23, p24, p25, _)
	local v26 = p23.spec_groundReference
	if not p25:getIsServer() then
		for _, v27 in ipairs(v26.groundReferenceNodes) do
			streamWriteBool(p24, v27.isActive)
		end
	end
end
function GroundReference.onUpdateTick(p28, _, _, _, _)
	local v29 = p28.spec_groundReference
	for _, v30 in ipairs(v29.groundReferenceNodes) do
		p28:updateGroundReferenceNode(v30)
	end
end
function GroundReference.loadGroundReferenceNode(p31, p32, p33, p34)
	XMLUtil.checkDeprecatedXMLElements(p32, p33 .. "#index", p33 .. "#node")
	local v35 = p31.spec_groundReference
	local v36 = p32:getValue(p33 .. "#node", nil, p31.components, p31.i3dMappings)
	if v36 == nil then
		return false
	end
	p34.node = v36
	p34.threshold = p32:getValue(p33 .. "#threshold", 0)
	p34.onlyActiveWhenLowered = p32:getValue(p33 .. "#onlyActiveWhenLowered", true)
	p34.chargeValue = p32:getValue(p33 .. "#chargeValue", 1)
	p34.forceFactor = p32:getValue(p33 .. "#forceFactor")
	if p34.forceFactor ~= nil then
		v35.hasForceFactors = true
	end
	p34.forceFactor = p34.forceFactor or 1
	p34.maxActivationDepth = p32:getValue(p33 .. "#maxActivationDepth", 10)
	p34.isActive = false
	return true
end
function GroundReference.updateGroundReferenceNode(p37, p38)
	if p37.isServer then
		local v39 = (not p38.onlyActiveWhenLowered or (p37.getIsLowered == nil or p37:getIsLowered(false))) and true or false
		local v40 = p37:getIsGroundReferenceNodeThreshold(p38)
		local v41, v42, v43 = getWorldTranslation(p38.node)
		local v44 = getTerrainHeightAtWorldPos(g_terrainNode, v41, v42, v43) + v40 - v42
		local v45
		if v44 > 0 then
			v45 = v44 < p38.maxActivationDepth
		else
			v45 = false
		end
		local v46, _ = DensityMapHeightUtil.getHeightAtWorldPos(v41, v42, v43)
		local v47 = v46 + v40 - v42
		local v48
		if v47 > 0 then
			v48 = v47 < p38.maxActivationDepth
		else
			v48 = false
		end
		if v39 then
			v39 = v45 or v48
		end
		p38.isActive = v39
	end
end
function GroundReference.getGroundReferenceNodeFromIndex(p49, p50)
	return p49.spec_groundReference.groundReferenceNodes[p50]
end
function GroundReference.getIsGroundReferenceNodeActive(_, p51)
	return p51.isActive
end
function GroundReference.getIsGroundReferenceNodeThreshold(_, p52)
	return p52.threshold
end
function GroundReference.getGroundReferenceNodeForwardSpeed(p53, p54)
	if p54 ~= nil then
		local v55 = p53.spec_groundReference.groundReferenceNodes[tonumber(p54)]
		if v55 ~= nil then
			return v55.isActive and (p53.movingDirection > 0 and p53:getLastSpeed()) or 0
		end
	end
	return 0
end
function GroundReference.getPowerMultiplier(p56, p57)
	local v58 = p57(p56)
	local v59 = p56.spec_groundReference
	if #v59.groundReferenceNodes > 0 then
		local v60 = 0
		if v59.hasForceFactors then
			for _, v61 in ipairs(v59.groundReferenceNodes) do
				if v61.isActive then
					v60 = v60 + v61.forceFactor
				end
			end
		else
			for _, v62 in ipairs(v59.groundReferenceNodes) do
				if v62.isActive then
					v60 = v62.chargeValue
				end
			end
		end
		v58 = v58 * v60
	end
	return v58
end
function GroundReference.loadSpeedRotatingPartFromXML(p63, p64, p65, p66, p67)
	if not p64(p63, p65, p66, p67) then
		return false
	end
	XMLUtil.checkDeprecatedXMLElements(p63.xmlFile, p67 .. "#refNodeIndex", p67 .. "#groundReferenceNodeIndex")
	p65.groundReferenceNodeIndex = p66:getValue(p67 .. "#groundReferenceNodeIndex")
	if p65.groundReferenceNodeIndex ~= nil and p65.groundReferenceNodeIndex == 0 then
		Logging.xmlWarning(p63.xmlFile, "Unknown ground reference node index \'%d\' in \'%s\'! Indices start with 1!", p65.groundReferenceNodeIndex, p67)
	end
	return true
end
function GroundReference.getIsSpeedRotatingPartActive(p68, p69, p70)
	if p70.groundReferenceNodeIndex ~= nil then
		local v71 = p68.spec_groundReference
		if v71.groundReferenceNodes[p70.groundReferenceNodeIndex] == nil then
			Logging.xmlWarning(p68.xmlFile, "Unknown ground reference node index \'%d\' for speed rotating part \'%s\'! Indices start with 1!", p70.groundReferenceNodeIndex, getName(p70.repr or p70.shaderNode))
			p70.groundReferenceNodeIndex = nil
		elseif not v71.groundReferenceNodes[p70.groundReferenceNodeIndex].isActive then
			return false
		end
	end
	return p69(p68, p70)
end

AutoLoadFork = {}
AutoLoadFork.BLOCK_REMOUNT_TIME = 1000
function AutoLoadFork.prerequisitesPresent(_)
	return true
end
function AutoLoadFork.initSpecialization()
	local v1 = Vehicle.xmlSchema
	v1:setXMLSpecializationType("AutoLoadFork")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.autoLoadFork#triggerNode", "Trigger to detect the pallets")
	v1:register(XMLValueType.NODE_INDEX, "vehicle.autoLoadFork#jointNode", "Node to join the pallets to")
	v1:register(XMLValueType.STRING, "vehicle.autoLoadFork.liftAnimation#name", "Lift animation name")
	v1:register(XMLValueType.FLOAT, "vehicle.autoLoadFork.liftAnimation#speedScale", "Animation speed scale")
	v1:setXMLSpecializationType()
	local v2 = Vehicle.xmlSchemaSavegame
	v2:register(XMLValueType.FLOAT, "vehicles.vehicle(?).autoLoadFork#liftAnimationTime", "Current state of lift animation")
	v2:register(XMLValueType.INT, "vehicles.vehicle(?).autoLoadFork.mountedObject(?)#vehicleUniqueId", "Vehicle unique id")
	Bale.registerSavegameXMLPaths(v2, "vehicles.vehicle(?).autoLoadFork.mountedObject(?).bale")
end
function AutoLoadFork.registerFunctions(p3)
	SpecializationUtil.registerFunction(p3, "onAutoLoadForkTriggerCallback", AutoLoadFork.onAutoLoadForkTriggerCallback)
	SpecializationUtil.registerFunction(p3, "getCanUnloadFork", AutoLoadFork.getCanUnloadFork)
	SpecializationUtil.registerFunction(p3, "getIsForkUnloadingAllowed", AutoLoadFork.getIsForkUnloadingAllowed)
	SpecializationUtil.registerFunction(p3, "doUnloadFork", AutoLoadFork.doUnloadFork)
	SpecializationUtil.registerFunction(p3, "onUnmountObject", AutoLoadFork.onUnmountObject)
	SpecializationUtil.registerFunction(p3, "mountObjectToFork", AutoLoadFork.mountObjectToFork)
end
function AutoLoadFork.registerOverwrittenFunctions(p4)
	SpecializationUtil.registerOverwrittenFunction(p4, "addToPhysics", AutoLoadFork.addToPhysics)
	SpecializationUtil.registerOverwrittenFunction(p4, "removeFromPhysics", AutoLoadFork.removeFromPhysics)
end
function AutoLoadFork.registerEventListeners(p5)
	SpecializationUtil.registerEventListener(p5, "onLoad", AutoLoadFork)
	SpecializationUtil.registerEventListener(p5, "onPostLoad", AutoLoadFork)
	SpecializationUtil.registerEventListener(p5, "onDelete", AutoLoadFork)
	SpecializationUtil.registerEventListener(p5, "onUpdate", AutoLoadFork)
	SpecializationUtil.registerEventListener(p5, "onDeactivate", AutoLoadFork)
	SpecializationUtil.registerEventListener(p5, "onRootVehicleChanged", AutoLoadFork)
	SpecializationUtil.registerEventListener(p5, "onRegisterActionEvents", AutoLoadFork)
end
function AutoLoadFork.onLoad(p6, _)
	local v7 = p6.spec_autoLoadFork
	if p6.isServer then
		v7.triggerNode = p6.xmlFile:getValue("vehicle.autoLoadFork#triggerNode", nil, p6.components, p6.i3dMappings)
		if v7.triggerNode ~= nil then
			addTrigger(v7.triggerNode, "onAutoLoadForkTriggerCallback", p6)
		end
	end
	v7.jointNode = p6.xmlFile:getValue("vehicle.autoLoadFork#jointNode", nil, p6.components, p6.i3dMappings)
	v7.remountDistance = 0
	v7.mountedObjects = {}
	v7.unmountedObjects = {}
	v7.liftAnimation = {}
	v7.liftAnimation.name = p6.xmlFile:getValue("vehicle.autoLoadFork.liftAnimation#name")
	v7.liftAnimation.speedScale = p6.xmlFile:getValue("vehicle.autoLoadFork.liftAnimation#speedScale", 1)
end
function AutoLoadFork.onPostLoad(p_u_8, p9)
	local v_u_10 = p_u_8.spec_autoLoadFork
	if p9 ~= nil and not p9.resetVehicles then
		local v_u_11 = p9.xmlFile
		if v_u_10.liftAnimation.name ~= nil then
			local v12 = v_u_11:getValue(p9.key .. ".autoLoadFork#liftAnimationTime")
			if v12 ~= nil then
				p_u_8:setAnimationTime(v_u_10.liftAnimation.name, v12, true, false)
			end
		end
		local v13 = string.format("%s.autoLoadFork.mountedObject", p9.key)
		v_u_10.pendingVehicles = {}
		v_u_11:iterate(v13, function(_, p14)
			-- upvalues: (copy) v_u_11, (copy) v_u_10, (copy) p_u_8
			local v15 = v_u_11:getValue(p14 .. "#vehicleUniqueId")
			if v15 == nil then
				if v_u_11:hasProperty(p14 .. ".bale") then
					local v16 = Bale.new(p_u_8.isServer, p_u_8.isClient)
					if v16:loadFromXMLFile(v_u_11, p14 .. ".bale", false) then
						v16:register()
						p_u_8:mountObjectToFork(v16)
						return
					end
					Logging.xmlWarning(v_u_11, "Could not load autoLoadFork bale for \'%s\'", p14)
					v16:delete()
				end
			else
				local v17 = v_u_10.pendingVehicles
				table.insert(v17, {
					["vehicleUniqueId"] = v15
				})
			end
		end)
	end
end
function AutoLoadFork.onDelete(p18)
	local v19 = p18.spec_autoLoadFork
	if p18.isServer then
		for _, v20 in pairs(v19.mountedObjects) do
			local v21 = NetworkUtil.getObject(v20)
			if v21 ~= nil then
				v21:unmountKinematic()
			end
		end
	end
	if v19.triggerNode ~= nil then
		removeTrigger(v19.triggerNode)
	end
end
function AutoLoadFork.onUpdate(p22, _, _, _, _)
	local v23 = p22.spec_autoLoadFork
	if p22.isServer then
		if v23.pendingVehicles ~= nil then
			for _, v24 in ipairs(v23.pendingVehicles) do
				local v25 = v24.vehicleUniqueId
				local v26 = g_currentMission.vehicleSystem:getVehicleByUniqueId(v25)
				if v26 ~= nil then
					p22:mountObjectToFork(v26)
				end
			end
			v23.pendingVehicles = nil
		end
		if v23.remountDistance > 0 then
			local v27 = p22.lastMovedDistance
			local v28 = v23.remountDistance - v27
			v23.remountDistance = math.max(0, v28)
		end
	end
end
function AutoLoadFork.onDeactivate(p29)
	if p29.isServer then
		p29.spec_autoLoadFork.remountDistance = 0
	end
end
function AutoLoadFork.saveToXMLFile(p30, p31, p32, _)
	local v33 = p30.spec_autoLoadFork
	if v33.liftAnimation.name ~= nil then
		p31:setValue(p32 .. "#liftAnimationTime", p30:getAnimationTime(v33.liftAnimation.name))
	end
	local v34 = 0
	for _, v35 in pairs(v33.mountedObjects) do
		local v36 = NetworkUtil.getObject(v35)
		if v36 ~= nil then
			local v37 = string.format("%s.mountedObject(%d)", p32, v34)
			if v36:isa(Vehicle) then
				p31:setValue(v37 .. "#vehicleUniqueId", v36:getUniqueId())
			elseif v36:isa(Bale) then
				v36:saveToXMLFile(p31, v37 .. ".bale")
			end
			v34 = v34 + 1
		end
	end
end
function AutoLoadFork.onRegisterActionEvents(p38, _, p39)
	if p38.isClient then
		local v40 = p38.spec_autoLoadFork
		p38:clearActionEventsTable(v40.actionEvents)
		if p39 then
			local _, v41 = p38:addActionEvent(v40.actionEvents, InputAction.UNLOAD_FORK, p38, AutoLoadFork.actionEventUnloadFork, false, true, false, true, nil)
			g_inputBinding:setActionEventTextPriority(v41, GS_PRIO_NORMAL)
		end
	end
end
function AutoLoadFork.onRootVehicleChanged(p42, p43)
	local v44 = p42.spec_autoLoadFork
	local v45 = p43.actionController
	if v45 == nil then
		if v44.controlledAction ~= nil then
			v44.controlledAction:remove()
			v44.controlledAction = nil
		end
		return
	elseif v44.controlledAction == nil then
		v44.controlledAction = v45:registerAction("forkLifting", nil, 4)
		v44.controlledAction:setCallback(p42, AutoLoadFork.actionControllerEvent)
		v44.controlledAction:setActionIcons("LOADER_LOWER", "LOADER_LIFT", false)
	else
		v44.controlledAction:updateParent(v45)
	end
end
function AutoLoadFork.actionControllerEvent(p46, p47)
	local v48 = p46.spec_autoLoadFork
	if v48.liftAnimation.name ~= nil then
		p46:playAnimation(v48.liftAnimation.name, v48.liftAnimation.speedScale * p47, p46:getAnimationTime(v48.liftAnimation.name))
	end
	return true
end
function AutoLoadFork.onDeleteMountedObject(p49, p50)
	local v51 = p49.spec_autoLoadFork
	for v52 = #v51.mountedObjects, 1, -1 do
		if v51.mountedObjects[v52] == p50.id then
			table.remove(v51.mountedObjects, v52)
			local v53 = v51.unmountedObjects
			local v54 = {
				["objectId"] = p50.id,
				["time"] = g_time
			}
			table.insert(v53, v54)
			return
		end
	end
end
function AutoLoadFork.onAutoLoadForkTriggerCallback(p55, _, p56, p57, p58, _, _)
	local v59 = g_currentMission:getNodeObject(p56)
	if v59 ~= nil and (v59.isPallet or v59:isa(Bale)) then
		local v60 = p55.spec_autoLoadFork
		if p57 then
			if #v60.mountedObjects == 0 and v60.remountDistance <= 0 then
				for v61 = 1, #v60.mountedObjects do
					if v60.mountedObjects[v61] == v59.id then
						return
					end
				end
				for v62 = #v60.unmountedObjects, 1, -1 do
					local v63 = v60.unmountedObjects[v62]
					if v63.objectId == v59.id then
						if v63.time + AutoLoadFork.BLOCK_REMOUNT_TIME > g_time then
							return
						end
					elseif v63.time + AutoLoadFork.BLOCK_REMOUNT_TIME < g_time then
						table.remove(v60.unmountedObjects, v62)
					end
				end
				p55:mountObjectToFork(v59)
				return
			end
		elseif p58 then
			for v64 = #v60.mountedObjects, 1, -1 do
				if v60.mountedObjects[v64] == v59.id then
					v59:removeDeleteListener(p55, AutoLoadFork.onDeleteMountedObject)
					table.remove(v60.mountedObjects, v64)
					local v65 = v60.unmountedObjects
					local v66 = {
						["objectId"] = v59.id,
						["time"] = g_time
					}
					table.insert(v65, v66)
					return
				end
			end
		end
	end
end
function AutoLoadFork.mountObjectToFork(p67, p68)
	local v69 = p67.spec_autoLoadFork
	local v70 = 0
	local v71 = 0
	local v72 = 0
	if p68.isPallet then
		v70 = -p68.spec_mountable.dynamicMountJointTransY or 0
		v71 = p68.size.length * 0.5 + p68.size.lengthOffset
	elseif p68:isa(Bale) then
		v71 = p68.width * 0.5
		v70 = p68.height * 0.2
		v72 = 1.5707963267948966
	end
	if p68.dynamicMountType == MountableObject.MOUNT_TYPE_KINEMATIC then
		p68:unmountKinematic()
	end
	p68:mountKinematic(p67, v69.jointNode, 0, v70, v71, 0, v72, 0)
	local v73 = v69.mountedObjects
	local v74 = p68.id
	table.insert(v73, v74)
	p68:addDeleteListener(p67, AutoLoadFork.onDeleteMountedObject)
end
function AutoLoadFork.getCanUnloadFork(p75)
	return #p75.spec_autoLoadFork.mountedObjects > 0
end
function AutoLoadFork.getIsForkUnloadingAllowed(_)
	return true
end
function AutoLoadFork.doUnloadFork(p76)
	local v77 = p76.spec_autoLoadFork
	for v78 = #v77.mountedObjects, 1, -1 do
		local v79 = v77.mountedObjects[v78]
		local v80 = NetworkUtil.getObject(v79)
		if v80 ~= nil then
			v80:unmountKinematic()
			v80:removeDeleteListener(p76, AutoLoadFork.onDeleteMountedObject)
			table.remove(v77.mountedObjects, v78)
			local v81 = v77.unmountedObjects
			local v82 = {
				["objectId"] = v80.id,
				["time"] = g_time
			}
			table.insert(v81, v82)
		end
	end
end
function AutoLoadFork.actionEventUnloadFork(p83, _, _, _, _)
	p83:doUnloadFork()
end
function AutoLoadFork.onUnmountObject(p84, p85)
	local v86 = p84.spec_autoLoadFork
	v86.remountDistance = 5
	for v87 = #v86.mountedObjects, 1, -1 do
		if v86.mountedObjects[v87] == p85.id then
			p85:removeDeleteListener(p84, AutoLoadFork.onDeleteMountedObject)
			table.remove(v86.mountedObjects, v87)
			local v88 = v86.unmountedObjects
			local v89 = {
				["objectId"] = p85.id,
				["time"] = g_time
			}
			table.insert(v88, v89)
			return
		end
	end
end
function AutoLoadFork.addToPhysics(p90, p91)
	if not p91(p90) then
		return false
	end
	if p90.isServer then
		local v92 = p90.spec_autoLoadFork
		for v93 = #v92.mountedObjects, 1, -1 do
			local v94 = v92.mountedObjects[v93]
			local v95 = NetworkUtil.getObject(v94)
			if v95 ~= nil and v95.addToPhysics ~= nil then
				v95:addToPhysics()
			end
		end
	end
	return true
end
function AutoLoadFork.removeFromPhysics(p96, p97)
	local v98 = p97(p96)
	if p96.isServer then
		local v99 = p96.spec_autoLoadFork
		for v100 = #v99.mountedObjects, 1, -1 do
			local v101 = v99.mountedObjects[v100]
			local v102 = NetworkUtil.getObject(v101)
			if v102 ~= nil and v102.removeFromPhysics ~= nil then
				v102:removeFromPhysics()
			end
		end
	end
	return v98
end

VehicleMaterial = {}
local v_u_1 = Class(VehicleMaterial)
function VehicleMaterial.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.baseDirectory = p2
	v5.colorOnly = false
	return v5
end
function VehicleMaterial.clone(p6)
	local v7 = VehicleMaterial.new(p6.baseDirectory)
	v7.targetMaterialSlotName = p6.targetMaterialSlotName
	v7.templateName = p6.templateName
	v7.materialTemplate = p6.materialTemplate
	v7.colorScale = p6.colorScale
	v7.smoothnessScale = p6.smoothnessScale
	v7.metalnessScale = p6.metalnessScale
	v7.clearCoatSmoothness = p6.clearCoatSmoothness
	v7.clearCoatIntensity = p6.clearCoatIntensity
	v7.porosity = p6.porosity
	v7.detailDiffuse = p6.detailDiffuse
	v7.detailNormal = p6.detailNormal
	v7.detailSpecular = p6.detailSpecular
	v7.diffuseMap = p6.diffuseMap
	v7.normalMap = p6.normalMap
	v7.specularMap = p6.specularMap
	return v7
end
function VehicleMaterial.setColor(p8, p9, p10, p11)
	if p9 == nil then
		return
	elseif type(p9) == "table" then
		p8.colorScale = { p9[1], p9[2], p9[3] }
	else
		p8.colorScale = { p9, p10, p11 }
	end
end
function VehicleMaterial.getBrightness(p12)
	if p12.colorScale == nil then
		return nil
	else
		return MathUtil.getBrightnessFromColor(p12.colorScale[1], p12.colorScale[2], p12.colorScale[3])
	end
end
function VehicleMaterial.setTemplateName(p13, p14, p15, p16)
	p13.templateName = p14
	p13.materialTemplate = g_vehicleMaterialManager:getMaterialTemplateByName(p14, p16)
	if p13.materialTemplate == nil then
		return false
	end
	p13.colorScale = p13.materialTemplate.colorScale or p13.materialTemplate.parentTemplate.colorScale
	if p13.colorScale == nil then
		p13.colorScale = { 1, 1, 1 }
	end
	if p15 then
		return true
	end
	p13.smoothnessScale = p13.materialTemplate.smoothnessScale or (p13.materialTemplate.parentTemplate.smoothnessScale or 1)
	p13.metalnessScale = p13.materialTemplate.metalnessScale or (p13.materialTemplate.parentTemplate.metalnessScale or 1)
	p13.clearCoatSmoothness = p13.materialTemplate.clearCoatSmoothness or (p13.materialTemplate.parentTemplate.clearCoatSmoothness or 0)
	p13.clearCoatIntensity = p13.materialTemplate.clearCoatIntensity or (p13.materialTemplate.parentTemplate.clearCoatIntensity or 0)
	p13.porosity = p13.materialTemplate.porosity or (p13.materialTemplate.parentTemplate.porosity or 0)
	p13.detailDiffuse = p13.materialTemplate.detailDiffuse or (p13.materialTemplate.parentTemplate.detailDiffuse or "data/shared/detailLibrary/nonMetallic/default_diffuse.png")
	p13.detailNormal = p13.materialTemplate.detailNormal or (p13.materialTemplate.parentTemplate.detailNormal or "data/shared/detailLibrary/nonMetallic/default_normal.png")
	p13.detailSpecular = p13.materialTemplate.detailSpecular or (p13.materialTemplate.parentTemplate.detailSpecular or "data/shared/detailLibrary/nonMetallic/default_specular.png")
	return true
end
function VehicleMaterial.loadFromXML(p17, p18, p19, p20)
	p17.targetMaterialSlotName = p18:getValue(p19 .. "#materialSlotName")
	local v21 = p17.templateName or p18:getValue(p19 .. "#materialTemplateName")
	if v21 ~= nil and (v21 ~= p17.templateName and not p17:setTemplateName(v21, p18:getValue(p19 .. "#materialTemplateUseColorOnly", false), p20)) then
		Logging.xmlWarning(p18.xmlFile or p18, "Unable to find material template \'%s\' in \'%s\'", v21, p19)
		return false
	end
	local v22 = p18:getValue(p19 .. ".colorScale#value")
	if v22 ~= nil then
		local v23 = g_vehicleMaterialManager:getMaterialTemplateByName(v22, p20)
		if v23 == nil then
			p17.colorScale = string.getVector(v22, 3) or p17.colorScale
		else
			p17.colorScale = v23.colorScale or v23.parentTemplate.colorScale
		end
	end
	p17.smoothnessScale = p18:getValue(p19 .. ".smoothness#value", p17.smoothnessScale)
	p17.metalnessScale = p18:getValue(p19 .. ".metalness#value", p17.metalnessScale)
	p17.clearCoatSmoothness = p18:getValue(p19 .. ".clearCoat#smoothness", p17.clearCoatSmoothness)
	p17.clearCoatIntensity = p18:getValue(p19 .. ".clearCoat#intensity", p17.clearCoatIntensity)
	p17.detailDiffuse = p18:getValue(p19 .. ".detail#diffuse", nil, p17.baseDirectory) or p17.detailDiffuse
	p17.detailNormal = p18:getValue(p19 .. ".detail#normal", nil, p17.baseDirectory) or p17.detailNormal
	p17.detailSpecular = p18:getValue(p19 .. ".detail#specular", nil, p17.baseDirectory) or p17.detailSpecular
	p17.diffuseMap = p18:getValue(p19 .. ".textures#diffuse", nil, p17.baseDirectory) or p17.diffuseMap
	p17.normalMap = p18:getValue(p19 .. ".textures#normal", nil, p17.baseDirectory) or p17.normalMap
	p17.specularMap = p18:getValue(p19 .. ".textures#specular", nil, p17.baseDirectory) or p17.specularMap
	return (p17.colorScale ~= nil or (p17.smoothnessScale ~= nil or (p17.metalnessScale ~= nil or (p17.clearCoatSmoothness ~= nil or (p17.clearCoatIntensity ~= nil or (p17.porosity ~= nil or (p17.detailDiffuse ~= nil or (p17.detailNormal ~= nil or (p17.detailSpecular ~= nil or (p17.diffuseMap ~= nil or p17.normalMap ~= nil)))))))))) and true or p17.specularMap ~= nil
end
function VehicleMaterial.loadShortFromXML(p24, p25, p26, p27)
	p24.targetMaterialSlotName = p25:getValue(p26 .. "#materialSlotName")
	local v28 = p24.templateName or p25:getValue(p26 .. "#materialTemplateName")
	if v28 == nil then
		return false
	end
	if not p24:setTemplateName(v28, p25:getValue(p26 .. "#materialTemplateUseColorOnly", false), p27) then
		Logging.xmlWarning(p25.xmlFile or p25, "Unable to find material template \'%s\' in \'%s\'", v28, p26)
		return false
	end
	local v29 = p25:getValue(p26 .. "#materialTemplateNameColor")
	if v29 ~= nil then
		local v30 = g_vehicleMaterialManager:getMaterialTemplateByName(v29, p27)
		if v30 ~= nil then
			p24.colorScale = v30.colorScale or v30.parentTemplate.colorScale
		end
	end
	return true
end
function VehicleMaterial.applyToVehicle(p31, p32, p33)
	local v34 = false
	for _, v35 in ipairs(p32.components) do
		v34 = p31:apply(v35.node, p33) or v34
	end
	return v34
end
function VehicleMaterial.apply(p36, p37, p38, p39)
	local v40 = false
	local v41 = p38 or p36.targetMaterialSlotName
	if getHasClassId(p37, ClassIds.SHAPE) then
		for v42 = 1, getNumOfMaterials(p37) do
			if getMaterialSlotName(p37, v42 - 1) == v41 or v41 == nil then
				p36:applyToMaterial(p37, v42 - 1, p39)
				v40 = true
			end
		end
	end
	for v43 = 1, getNumOfChildren(p37) do
		v40 = p36:apply(getChildAt(p37, v43 - 1), v41, p39) or v40
	end
	return v40
end
function VehicleMaterial.applyToMaterial(p44, p45, p46, p47)
	if p44.colorScale ~= nil then
		setShaderParameter(p45, "colorScale", p44.colorScale[1], p44.colorScale[2], p44.colorScale[3], nil, false, p46)
	end
	if not p47 then
		if p44.smoothnessScale ~= nil then
			setShaderParameter(p45, "smoothnessScale", p44.smoothnessScale, nil, nil, nil, false, p46)
		end
		if p44.metalnessScale ~= nil then
			setShaderParameter(p45, "metalnessScale", p44.metalnessScale, nil, nil, nil, false, p46)
		end
		if p44.clearCoatSmoothness ~= nil then
			setShaderParameter(p45, "clearCoatSmoothness", p44.clearCoatSmoothness, nil, nil, nil, false, p46)
		end
		if p44.clearCoatIntensity ~= nil then
			setShaderParameter(p45, "clearCoatIntensity", p44.clearCoatIntensity, nil, nil, nil, false, p46)
		end
		if p44.porosity ~= nil then
			setShaderParameter(p45, "porosity", p44.porosity, nil, nil, nil, false, p46)
		end
		local v48 = getMaterial(p45, p46)
		local v49
		if p44.detailDiffuse == nil then
			v49 = v48
		else
			v49 = setMaterialCustomMapFromFile(v48, "detailDiffuse", p44.detailDiffuse, false, true, false)
		end
		if p44.detailNormal ~= nil then
			v49 = setMaterialCustomMapFromFile(v49, "detailNormal", p44.detailNormal, false, false, false)
		end
		if p44.detailSpecular ~= nil then
			v49 = setMaterialCustomMapFromFile(v49, "detailSpecular", p44.detailSpecular, false, false, false)
		end
		if p44.diffuseMap ~= nil then
			v49 = setMaterialDiffuseMapFromFile(v49, p44.diffuseMap, false, true, false)
		end
		if p44.normalMap ~= nil then
			v49 = setMaterialNormalMapFromFile(v49, p44.normalMap, false, false, false)
		end
		if p44.specularMap ~= nil then
			v49 = setMaterialGlossMapFromFile(v49, p44.specularMap, false, false, false)
		end
		if v49 ~= v48 then
			setMaterial(p45, v49, p46)
		end
	end
end
function VehicleMaterial.getIsApplied(p50, _, p51, p52)
	if p52 ~= false then
		local v53, v54, v55, _ = getMaterialCustomParameter(p51, "colorScale")
		if p50.colorScale == nil then
			if v53 ~= 1 or (v54 ~= 1 or v55 ~= 1) then
				return false
			end
		elseif v53 ~= p50.colorScale[1] or (v54 ~= p50.colorScale[2] or v55 ~= p50.colorScale[3]) then
			return false
		end
	end
	local v56 = getMaterialCustomParameter(p51, "smoothnessScale")
	if p50.smoothnessScale ~= nil and v56 ~= p50.smoothnessScale then
		return false
	end
	if p50.smoothnessScale == nil and v56 ~= 1 then
		return false
	end
	local v57 = getMaterialCustomParameter(p51, "metalnessScale")
	if p50.metalnessScale ~= nil and v57 ~= p50.metalnessScale then
		return false
	end
	if p50.metalnessScale == nil and v57 ~= 1 then
		return false
	end
	local v58 = getMaterialCustomParameter(p51, "clearCoatSmoothness")
	if p50.clearCoatSmoothness ~= nil and v58 ~= p50.clearCoatSmoothness then
		return false
	end
	if p50.clearCoatSmoothness == nil and v58 ~= 0 then
		return false
	end
	local v59 = getMaterialCustomParameter(p51, "clearCoatIntensity")
	if p50.clearCoatIntensity ~= nil and v59 ~= p50.clearCoatIntensity then
		return false
	end
	if p50.clearCoatIntensity == nil and v59 ~= 0 then
		return false
	end
	local v60 = getMaterialCustomParameter(p51, "porosity")
	if p50.porosity ~= nil and v60 ~= p50.porosity then
		return false
	end
	if p50.porosity == nil and v60 ~= 0 then
		return false
	end
	local v61 = getMaterialCustomMapFilename(p51, "detailDiffuse")
	if p50.detailDiffuse ~= nil and v61 ~= p50.detailDiffuse then
		return false
	end
	local v62 = getMaterialCustomMapFilename(p51, "detailNormal")
	if p50.detailNormal ~= nil and v62 ~= p50.detailNormal then
		return false
	end
	local v63 = getMaterialCustomMapFilename(p51, "detailSpecular")
	if p50.detailSpecular ~= nil and v63 ~= p50.detailSpecular then
		return false
	end
	local v64 = getMaterialDiffuseMapFilename(p51)
	if p50.diffuseMap ~= nil and v64 ~= p50.diffuseMap then
		return false
	end
	local v65 = getMaterialNormalMapFilename(p51)
	if p50.normalMap ~= nil and v65 ~= p50.normalMap then
		return false
	end
	local v66 = getMaterialGlossMapFilename(p51)
	return p50.specularMap == nil or v66 == p50.specularMap
end
function VehicleMaterial.registerXMLPaths(p67, p68)
	p67:register(XMLValueType.STRING, p68 .. "#materialSlotName", "Material slot name in the i3d file")
	p67:register(XMLValueType.STRING, p68 .. "#materialTemplateName", "Name of template to apply (all attributes will be used from template)")
	p67:registerAutoCompletionDataSource(p68 .. "#materialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p67:register(XMLValueType.BOOL, p68 .. "#materialTemplateUseColorOnly", "If \'true\', only the color is used from the material template. The rest from the i3d file.", false)
	p67:register(XMLValueType.STRING, p68 .. ".colorScale#value", "Material color if it should not be used from configuration (can also be a different material template, from which then ONLY the color is taken)")
	p67:register(XMLValueType.FLOAT, p68 .. ".smoothness#value", "Smoothness value")
	p67:register(XMLValueType.FLOAT, p68 .. ".metalness#value", "Metalness value")
	p67:register(XMLValueType.FLOAT, p68 .. ".clearCoat#smoothness", "Smoothness of clear coat")
	p67:register(XMLValueType.FLOAT, p68 .. ".clearCoat#intensity", "Intensity of clear coat")
	p67:register(XMLValueType.FILENAME, p68 .. ".detail#diffuse", "Path to detail diffuse texture")
	p67:register(XMLValueType.FILENAME, p68 .. ".detail#normal", "Path to detail normal texture")
	p67:register(XMLValueType.FILENAME, p68 .. ".detail#specular", "Path to detail specular texture")
	p67:register(XMLValueType.FILENAME, p68 .. ".textures#diffuse", "Path to diffuse texture")
	p67:register(XMLValueType.FILENAME, p68 .. ".textures#normal", "Path to normal texture")
	p67:register(XMLValueType.FILENAME, p68 .. ".textures#specular", "Path to specular texture")
end
function VehicleMaterial.registerShortXMLPaths(p69, p70)
	p69:register(XMLValueType.STRING, p70 .. "#materialSlotName", "Material slot name in the i3d file")
	p69:register(XMLValueType.STRING, p70 .. "#materialTemplateName", "Name of template to apply (all attributes will be used from template)")
	p69:registerAutoCompletionDataSource(p70 .. "#materialTemplateName", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
	p69:register(XMLValueType.BOOL, p70 .. "#materialTemplateUseColorOnly", "If \'true\', only the color is used from the material template. The rest from the i3d file.", false)
	p69:register(XMLValueType.STRING, p70 .. "#materialTemplateNameColor", "Name of the material template that is used ONLY for the color")
	p69:registerAutoCompletionDataSource(p70 .. "#materialTemplateNameColor", "$data/shared/brandMaterialTemplates.xml", "templates.template#name")
end

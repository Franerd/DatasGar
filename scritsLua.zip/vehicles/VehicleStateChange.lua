VehicleStateChange = {}
VehicleStateChange.ATTACH = 1
VehicleStateChange.DETACH = 2
VehicleStateChange.LOWER_ALL_IMPLEMENTS = 3
VehicleStateChange.ENTER_VEHICLE = 4
VehicleStateChange.LEAVE_VEHICLE = 5
VehicleStateChange.FILLTYPE_CHANGE = 6
VehicleStateChange.MOTOR_TURN_ON = 7
VehicleStateChange.MOTOR_TURN_OFF = 8
VehicleStateChange.TURN_ON = 9
VehicleStateChange.TURN_OFF = 10
VehicleStateChange.AI_START_LINE = 11
VehicleStateChange.AI_END_LINE = 12
Enum(VehicleStateChange)

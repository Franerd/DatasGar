VehicleDebug = {}
VehicleDebug.DEBUG_COLORS = {
	Color.new(1, 0, 0, 1),
	Color.new(0, 1, 0, 1),
	Color.new(0, 0, 1, 1),
	Color.new(1, 1, 0, 1),
	Color.new(1, 0, 1, 1),
	Color.new(0, 1, 1, 1),
	Color.new(1, 1, 1, 1)
}
VehicleDebug.COLOR = {}
VehicleDebug.COLOR.ACTIVE = Color.new(0.5, 1, 0.5, 1)
VehicleDebug.COLOR.INACTIVE = Color.new(1, 0.1, 0.1, 1)
VehicleDebug.COLOR.GREY = Color.new(0.2, 0.2, 0.2, 1)
VehicleDebug.NONE = 0
VehicleDebug.DEBUG = 1
VehicleDebug.DEBUG_PHYSICS = 2
VehicleDebug.DEBUG_TUNING = 3
VehicleDebug.DEBUG_TRANSMISSION = 4
VehicleDebug.DEBUG_ATTRIBUTES = 5
VehicleDebug.DEBUG_ATTACHER_JOINTS = 6
VehicleDebug.DEBUG_AI = 7
VehicleDebug.DEBUG_SOUNDS = 8
VehicleDebug.DEBUG_ANIMATIONS = 9
VehicleDebug.STATE_NAMES = {}
VehicleDebug.STATE_NAMES[VehicleDebug.NONE] = "None"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG] = "Values"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG_PHYSICS] = "Physics"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG_TUNING] = "Tuning"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG_TRANSMISSION] = "Transmission"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG_ATTRIBUTES] = "Attributes"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG_ATTACHER_JOINTS] = "Attacher Joints"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG_AI] = "AI"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG_SOUNDS] = "Sounds"
VehicleDebug.STATE_NAMES[VehicleDebug.DEBUG_ANIMATIONS] = "Animations"
VehicleDebug.NUM_STATES = 9
VehicleDebug.state = 0
VehicleDebug.selectedAnimation = 0
if g_isDevelopmentVersion then
	VehicleDebug.state = 0
end
function VehicleDebug.consoleCommandVehicleDebug(_, p1)
	local v2 = VehicleDebug.DEBUG
	if p1 ~= nil then
		local v3 = tonumber(p1)
		if v3 == nil then
			for v4, v5 in pairs(VehicleDebug.STATE_NAMES) do
				if string.startsWith(v5:lower(), p1:lower()) then
					v2 = v4
				end
			end
		else
			v2 = v3
		end
	end
	VehicleDebug.setState(v2)
	return string.format("VehicleDebug set to \'%s\'", VehicleDebug.STATE_NAMES[VehicleDebug.state])
end
function VehicleDebug.setState(p6)
	if VehicleDebug.state == 0 then
		VehicleDebug.debugActionEvents = {}
		for v7 = 1, VehicleDebug.NUM_STATES do
			local _, v8 = g_inputBinding:registerActionEvent(InputAction["DEBUG_VEHICLE_" .. v7], VehicleDebug, VehicleDebug.debugActionCallback, false, true, false, true, v7)
			g_inputBinding:setActionEventTextVisibility(v8, false)
			local v9 = VehicleDebug.debugActionEvents
			table.insert(v9, v8)
		end
	elseif p6 == 0 then
		for v10 = 1, #VehicleDebug.debugActionEvents do
			g_inputBinding:removeActionEvent(VehicleDebug.debugActionEvents[v10])
		end
	end
	if p6 == VehicleDebug.DEBUG_ATTACHER_JOINTS then
		if VehicleDebug.attacherJointUpperEventId == nil and VehicleDebug.attacherJointLowerEventId == nil then
			local _, v11 = g_inputBinding:registerActionEvent(InputAction.AXIS_FRONTLOADER_ARM, VehicleDebug, VehicleDebug.moveUpperRotation, false, false, true, true)
			g_inputBinding:setActionEventTextVisibility(v11, false)
			VehicleDebug.attacherJointUpperEventId = v11
			local _, v12 = g_inputBinding:registerActionEvent(InputAction.AXIS_FRONTLOADER_TOOL, VehicleDebug, VehicleDebug.moveLowerRotation, false, false, true, true)
			g_inputBinding:setActionEventTextVisibility(v12, false)
			VehicleDebug.attacherJointLowerEventId = v12
		end
	else
		g_inputBinding:removeActionEvent(VehicleDebug.attacherJointUpperEventId)
		g_inputBinding:removeActionEvent(VehicleDebug.attacherJointLowerEventId)
		VehicleDebug.attacherJointUpperEventId = nil
		VehicleDebug.attacherJointLowerEventId = nil
	end
	if p6 == VehicleDebug.DEBUG_AI and g_currentMission ~= nil then
		for _, v13 in pairs(g_currentMission.vehicleSystem.vehicles) do
			if v13.spec_aiDrivable ~= nil and (v13:getIsActiveForInput(true, true) and v13.spec_aiDrivable.agentId ~= nil) then
				enableVehicleNavigationAgentDebugRendering(v13.spec_aiDrivable.agentId, true)
			end
		end
	end
	local v14 = false
	if p6 == VehicleDebug.DEBUG_TUNING then
		WheelPhysics.COLLISION_MASK = CollisionMask.ALL - CollisionFlag.TERRAIN_DISPLACEMENT
		v14 = true
	elseif VehicleDebug.state == VehicleDebug.DEBUG_TUNING and WheelPhysics.COLLISION_MASK ~= CollisionMask.ALL then
		WheelPhysics.COLLISION_MASK = CollisionMask.ALL
		v14 = true
	end
	if v14 then
		for _, v15 in pairs(g_currentMission.vehicleSystem.vehicles) do
			if v15.getWheels ~= nil then
				for _, v16 in ipairs(v15:getWheels()) do
					v16.physics:updateBase()
				end
			end
		end
	end
	local v17 = false
	if VehicleDebug.state == p6 then
		VehicleDebug.state = 0
	else
		VehicleDebug.state = p6
		v17 = true
	end
	if g_currentMission ~= nil then
		for _, v18 in pairs(g_currentMission.vehicleSystem.vehicles) do
			v18:updateSelectableObjects()
			v18:updateActionEvents()
			v18:setSelectedVehicle(v18)
		end
	end
	return v17
end
function VehicleDebug.delete(p19)
	if p19.isServer then
		local v20 = p19.spec_motorized
		if v20 ~= nil then
			local v21 = v20.motor
			if v21 ~= nil then
				if v21.debugCurveOverlay ~= nil then
					delete(v21.debugCurveOverlay)
				end
				if v21.debugTorqueGraph ~= nil then
					v21.debugTorqueGraph:delete()
				end
				if v21.debugPowerGraph ~= nil then
					v21.debugPowerGraph:delete()
				end
				if v21.debugGraphs ~= nil then
					for _, v22 in ipairs(v21.debugGraphs) do
						v22:delete()
					end
				end
				if v21.debugLoadGraph ~= nil then
					v21.debugLoadGraph:delete()
				end
				if v21.debugLoadGraphSmooth ~= nil then
					v21.debugLoadGraphSmooth:delete()
				end
				if v21.debugLoadGraphSound ~= nil then
					v21.debugLoadGraphSound:delete()
				end
				if v21.debugRPMGraphSmooth ~= nil then
					v21.debugRPMGraphSmooth:delete()
				end
				if v21.debugRPMGraphSound ~= nil then
					v21.debugRPMGraphSound:delete()
				end
				if v21.debugRPMGraph ~= nil then
					v21.debugRPMGraph:delete()
				end
				if v21.debugAccelerationGraph ~= nil then
					v21.debugAccelerationGraph:delete()
				end
			end
		end
	end
end
function VehicleDebug.debugActionCallback(_, _, _, p23, _)
	if VehicleDebug.state ~= p23 then
		VehicleDebug.setState(p23)
		log(string.format("VehicleDebug set to \'%s\'", VehicleDebug.STATE_NAMES[VehicleDebug.state]))
	end
end
function VehicleDebug.updateDebug(p24, p25)
	if VehicleDebug.state == VehicleDebug.DEBUG_ATTRIBUTES then
		VehicleDebug.drawDebugAttributeRendering(p24)
	elseif VehicleDebug.state == VehicleDebug.DEBUG_ATTACHER_JOINTS then
		VehicleDebug.drawDebugAttacherJoints(p24)
	elseif VehicleDebug.state == VehicleDebug.DEBUG_AI then
		VehicleDebug.drawDebugAIRendering(p24)
	elseif VehicleDebug.state == VehicleDebug.DEBUG_TUNING then
		VehicleDebug.updateTuningDebugRendering(p24, p25)
	end
	if VehicleDebug.state == VehicleDebug.DEBUG and (p24:getIsActiveForInput() or p24.rootVehicle ~= g_localPlayer:getCurrentVehicle()) then
		VehicleDebug.drawDebugValues(p24)
	end
end
function VehicleDebug.drawDebug(p26)
	if p26.getIsEntered ~= nil and p26:getIsEntered() then
		local v27 = p26:getSelectedVehicle()
		if v27 ~= nil then
			p26 = v27
		end
		if VehicleDebug.state == VehicleDebug.DEBUG_PHYSICS then
			VehicleDebug.drawDebugRendering(p26)
		elseif VehicleDebug.state == VehicleDebug.DEBUG_SOUNDS then
			VehicleDebug.drawSoundDebugValues(p26)
		elseif VehicleDebug.state == VehicleDebug.DEBUG_ANIMATIONS then
			VehicleDebug.drawAnimationDebug(p26)
		elseif VehicleDebug.state == VehicleDebug.DEBUG_TRANSMISSION then
			VehicleDebug.drawTransmissionDebug(p26)
		elseif VehicleDebug.state == VehicleDebug.DEBUG_TUNING then
			VehicleDebug.drawTuningDebug(p26)
		end
		if VehicleDebug.state > 0 then
			setTextAlignment(RenderText.ALIGN_CENTER)
			for v28 = 1, VehicleDebug.NUM_STATES do
				local v29 = 1 / (VehicleDebug.NUM_STATES + 1) * v28
				if VehicleDebug.state == v28 then
					setTextColor(0, 1, 0, 1)
					renderText(v29, 0.01, 0.03, string.format("%s", VehicleDebug.STATE_NAMES[v28]))
				else
					setTextColor(1, 1, 0, 1)
					renderText(v29, 0.01, 0.015, string.format("SHIFT + %d: \'%s\'", v28, VehicleDebug.STATE_NAMES[v28]))
				end
			end
			setTextColor(1, 1, 1, 1)
			setTextAlignment(RenderText.ALIGN_LEFT)
		end
	end
end
function VehicleDebug.registerActionEvents(p30)
	if p30.getIsEntered ~= nil and (p30:getIsEntered() and VehicleDebug.state == VehicleDebug.DEBUG_ANIMATIONS) then
		p30:addActionEvent(p30.actionEvents, InputAction.DEBUG_PLAYER_ENABLE, p30, function()
			VehicleDebug.selectedAnimation = VehicleDebug.selectedAnimation + 1
		end, false, true, false, true, nil)
	end
	if VehicleDebug.state > 0 then
		if VehicleDebug.debugActionEvents ~= nil then
			for v31 = 1, #VehicleDebug.debugActionEvents do
				g_inputBinding:removeActionEvent(VehicleDebug.debugActionEvents[v31])
			end
		end
		VehicleDebug.debugActionEvents = {}
		for v32 = 1, 9 do
			local _, v33 = g_inputBinding:registerActionEvent(InputAction["DEBUG_VEHICLE_" .. v32], VehicleDebug, VehicleDebug.debugActionCallback, false, true, false, true, v32)
			g_inputBinding:setActionEventTextVisibility(v33, false)
			local v34 = VehicleDebug.debugActionEvents
			table.insert(v34, v33)
		end
	end
end
function VehicleDebug.drawBaseDebugRendering(p35, p36, p37)
	local v38, _, v39 = getWorldTranslation(p35.components[1].node)
	local v40 = g_farmlandManager:getIsOwnedByFarmAtWorldPosition(g_currentMission:getFarmId(), v38, v39)
	local v41 = ""
	local v42 = ""
	local v43 = ""
	local v44 = ""
	local v45 = p35.spec_motorized
	local v46
	if v45 == nil then
		v46 = nil
	else
		local v47 = v45.motor
		local v48 = v47:getMotorAvailableTorque()
		local v49 = v47:getMotorExternalTorque()
		local v50 = v47:getMotorRotSpeed() * (v48 - v49) * 1000
		local v51 = v41 .. "motor:\n"
		local v52 = v42 .. string.format("%1.2frpm\n", v47:getNonClampedMotorRpm())
		local v53 = v51 .. "clutch:\n"
		local v54 = v52 .. string.format("%1.2frpm\n", v47:getClutchRotSpeed() * 30 / 3.141592653589793)
		local v55 = v53 .. "available power:\n"
		local v56 = v54 .. string.format("%1.2fhp %1.2fkW\n", v50 / 735.49875, v50 / 1000)
		local v57 = v55 .. "gear:\n"
		local v58 = v56 .. string.format("%d %d (%d, %1.2f)\n", v47.gear, v47.targetGear * v47.currentDirection, v47.activeGearGroupIndex or 0, v47:getGearRatio())
		v41 = v57 .. "motor load:\n"
		v42 = v58 .. string.format("%1.2fkN %1.2fkN\n", v48, v47:getMotorAppliedTorque())
		local v59 = v47:getNonClampedMotorRpm() * 3.141592653589793 / 30 * v49
		local v60 = v49 / v47:getPeakTorque()
		local v61 = v43 .. "pto load:\n"
		local v62 = v44 .. string.format("%.2f%% %.2fhp %.2fkW %1.2fkN\n", v60 * 100, v59 * 1.359621, v59, v49)
		local v63 = v61 .. "motor load:\n"
		local v64 = v62 .. string.format("%.2f%%\n", v45.smoothedLoadPercentage * 100)
		local v65 = v63 .. "motor rpm for sounds:\n"
		local v66 = v64 .. string.format("%drpm\n", v47:getLastMotorRpm())
		v43 = v65 .. "brakeForce:\n"
		v44 = v66 .. string.format("%.2f\n", (p35.spec_wheels or {
			["brakePedal"] = 0
		}).brakePedal)
		local v67 = p35:getConsumerFillUnitIndex(FillType.DIESEL) or (p35:getConsumerFillUnitIndex(FillType.ELECTRICCHARGE) or p35:getConsumerFillUnitIndex(FillType.METHANE))
		if v67 ~= nil then
			local v68 = p35:getFillUnitFillLevel(v67)
			local v69 = p35:getFillUnitFillType(v67)
			local v70 = v69 == FillType.ELECTRICCHARGE and "kw" or (v69 == FillType.METHANE and "kg" or "l")
			v43 = v43 .. string.format("%s:\n", g_fillTypeManager:getFillTypeNameByIndex(v69))
			v44 = v44 .. string.format("%.2f%s/h (%.2f%s)\n", v45.lastFuelUsage, v70, v68, v70)
		end
		local v71 = p35:getConsumerFillUnitIndex(FillType.DEF)
		if v71 ~= nil then
			local v72 = p35:getFillUnitFillLevel(v71)
			v43 = v43 .. "DEF:\n"
			v44 = v44 .. string.format("%.2fl/h (%.2fl)\n", v45.lastDefUsage, v72)
		end
		local v73 = p35:getConsumerFillUnitIndex(FillType.AIR)
		if v73 ~= nil then
			local v74 = p35:getFillUnitFillLevel(v73)
			v43 = v43 .. "AIR:\n"
			v44 = v44 .. string.format("%.2fl/sec (%.2fl)\n", v45.lastAirUsage, v74)
		end
		v46 = v47.differentialRotSpeed * 3.6
	end
	local v75 = v41 .. "vel acc[m/s2]:\n"
	local v76 = v42 .. string.format("%1.4f\n", p35.lastSpeedAcceleration * 1000 * 1000)
	local v77, v78
	if v46 == nil then
		v77 = v75 .. "vel[km/h]:\n"
		v78 = v76 .. string.format("%1.3f\n", p35:getLastSpeed())
	else
		local v79 = v75 .. "vel[km/h]:\n"
		local v80 = v76 .. string.format("%1.3f\n", p35:getLastSpeed())
		local v81 = p35.lastSpeedReal * 3600
		local v82 = (v46 <= 0.01 or v81 <= 0.01) and 0 or (v46 / v81 - 1) * 100
		v77 = v79 .. "differential[km/h]:\n"
		v78 = v80 .. string.format("%1.3f (slip: %d%%)\n", v46, v82)
	end
	local v83 = v77 .. "field owned:\n"
	local v84 = v78 .. tostring(v40) .. "\n"
	local v85 = v83 .. "mass:\n"
	local v86 = v84 .. string.format("%1.1fkg\n", p35:getTotalMass(true) * 1000)
	local v87 = v85 .. "mass incl. attach:\n"
	local v88 = v86 .. string.format("%1.1fkg\n", p35:getTotalMass() * 1000)
	if p35.spec_attachable ~= nil then
		local v89 = p35.spec_wheels == nil and 0 or p35.spec_wheels.brakePedal
		local v90 = p35:getBrakeForce() / 10
		v87 = v87 .. "brakeForce:\n"
		v88 = v88 .. string.format("%1.2f / %1.2f\n", v90 * v89, v90)
	end
	local v91 = getCorrectTextSize(0.02)
	Utils.renderMultiColumnText(p36, p37, v91, { v87, v88 }, 0.008, { RenderText.ALIGN_RIGHT, RenderText.ALIGN_LEFT })
	Utils.renderMultiColumnText(p36 + 0.22, p37, v91, { v43, v44 }, 0.008, { RenderText.ALIGN_RIGHT, RenderText.ALIGN_LEFT })
	return getTextHeight(v91, v87), getTextHeight(v91, v43)
end
function VehicleDebug.drawWheelInfoRendering(p92, p93, p94)
	if p92.isServer then
		local v95 = p92.spec_wheels
		if v95 ~= nil and #v95.wheels > 0 then
			local v96 = WheelDebug.getDebugValueHeader()
			for v97, v98 in ipairs(v95.wheels) do
				v98.debug:fillDebugValues(v96)
				if #v95.wheels > 4 and DebugUtil.isNodeInCameraRange(v98.repr, 30) then
					local v99, v100, v101 = getWorldTranslation(v98.repr)
					Utils.renderTextAtWorldPosition(v99, v100, v101, string.format("%d\n%s", v97, getName(v98.driveNode or v98.linkNode)), getCorrectTextSize(0.008))
				end
			end
			local v102 = getCorrectTextSize(0.02)
			Utils.renderMultiColumnText(p93, p94, v102, v96, 0.008, { RenderText.ALIGN_RIGHT, RenderText.ALIGN_LEFT })
			return getTextHeight(v102, v96[1])
		end
	end
	return 0
end
function VehicleDebug.drawWheelSlipGraphs(p103)
	if p103.isServer then
		local v104 = p103.spec_wheels
		if v104 ~= nil then
			for _, v105 in ipairs(v104.wheels) do
				v105.debug:drawSlipGraphs()
			end
		end
	end
end
function VehicleDebug.drawDifferentialInfoRendering(p_u_106, p107, p108)
	local v_u_109 = p_u_106.spec_motorized
	if v_u_109 ~= nil and v_u_109.differentials ~= nil then
		local function v_u_120(p110)
			-- upvalues: (copy) p_u_106, (ref) v_u_120, (copy) v_u_109
			local v111 = p_u_106.spec_wheels
			local v112
			if p110.diffIndex1IsWheel then
				local v113 = v111.wheels[p110.diffIndex1]
				v112 = not v113.physics.wheelShapeCreated and 0 or getWheelShapeAxleSpeed(v113.node, v113.physics.wheelShape) * v113.physics.radius
			else
				local v114, v115 = v_u_120(v_u_109.differentials[p110.diffIndex1 + 1])
				v112 = (v114 + v115) / 2
			end
			local v116
			if p110.diffIndex2IsWheel then
				local v117 = v111.wheels[p110.diffIndex2]
				if v117.physics.wheelShapeCreated then
					return v112, getWheelShapeAxleSpeed(v117.node, v117.physics.wheelShape) * v117.physics.radius
				end
				v116 = 0
			else
				local v118, v119 = v_u_120(v_u_109.differentials[p110.diffIndex2 + 1])
				v116 = (v118 + v119) / 2
			end
			return v112, v116
		end
		local v121 = v_u_120
		local v122 = {
			"\n",
			"torqueRatio\n",
			"maxSpeedRatio\n",
			"actualSpeedRatio\n"
		}
		for v123, v124 in pairs(v_u_109.differentials) do
			v122[1] = v122[1] .. string.format("%d:\n", v123)
			v122[2] = v122[2] .. string.format("%2.2f\n", v124.torqueRatio)
			v122[3] = v122[3] .. string.format("%2.2f\n", v124.maxSpeedRatio)
			local v125, v126 = v121(v124)
			local v127 = math.abs(v125)
			local v128 = math.abs(v126)
			local v129 = math.max(v127, v128)
			local v130 = math.abs(v125)
			local v131 = math.abs(v126)
			local v132 = math.min(v130, v131)
			local v133 = v129 / math.max(v132, 0.001)
			v122[4] = v122[4] .. string.format("%2.2f\n", v133)
		end
		Utils.renderMultiColumnText(p107, p108, getCorrectTextSize(0.02), v122, 0.008, { RenderText.ALIGN_RIGHT, RenderText.ALIGN_LEFT })
	end
end
function VehicleDebug.drawMotorGraphs(p134, p135, p136, p137, p138, p139)
	if p134.isServer then
		local v140 = p134.spec_motorized
		if v140 ~= nil then
			local v141 = v140.motor
			local v142 = v141.debugCurveOverlay
			if v142 == nil then
				v142 = createImageOverlay("dataS/menu/base/graph_pixel.png")
				setOverlayColor(v142, 0, 1, 0, 0.2)
				v141.debugCurveOverlay = v142
			end
			local v143 = v141:getTorqueCurve()
			local v144 = #v143.keyframes
			local v145 = v141:getMinRpm()
			local v146 = v143.keyframes[1].time
			local v147 = math.min(v145, v146)
			local v148 = v141:getMaxRpm()
			local v149 = v143.keyframes[v144].time
			local v150 = math.max(v148, v149)
			local v151 = v141.debugTorqueGraph
			local v152 = v141.debugPowerGraph
			if v151 == nil then
				local v153 = v144 * 32
				v151 = Graph.new(v153, p135, p136, p137, p138, 0, 0.0001, true, "kN", Graph.STYLE_LINES)
				v151:setColor(1, 1, 1, 1)
				v141.debugTorqueGraph = v151
				v152 = Graph.new(v153, p135, p136, p137, p138, 0, 0.0001, false, "", Graph.STYLE_LINES)
				v152:setColor(1, 0, 0, 1)
				v141.debugPowerGraph = v152
				v151.maxValue = 0.01
				v152.maxValue = 0.01
				for v154 = 1, v153 do
					local v155 = (v154 - 1) / (v153 - 1) * (v143.keyframes[v144].time - v143.keyframes[1].time) + v143.keyframes[1].time
					local v156 = v141:getTorqueCurveValue(v155)
					local v157 = v156 * 1000 * v155 * 3.141592653589793 / 30 / 735.49875
					local v158 = (v155 - v147) / (v150 - v147)
					v151:setValue(v154, v156)
					local v159 = v151.maxValue
					v151.maxValue = math.max(v159, v156)
					v151:setXPosition(v154, v158)
					v152:setValue(v154, v157)
					local v160 = v152.maxValue
					v152.maxValue = math.max(v160, v157)
					v152:setXPosition(v154, v158)
				end
			else
				v151.left = p135
				v151.bottom = p136
				v151.width = p137
				v151.height = p138
				v152.left = p135
				v152.bottom = p136
				v152.width = p137
				v152.height = p138
			end
			v151:draw()
			v152:draw()
			local v161 = renderOverlay
			local v162 = (v141:getNonClampedMotorRpm() - v147) / (v150 - v147)
			v161(v142, p135, p136, p137 * math.clamp(v162, 0, 1), p138)
			if p139 then
				p135 = p135 + p137 + 0.013
			else
				p136 = p136 - p138 - 0.013
			end
			local v163 = v141:getMaximumForwardSpeed()
			local v164 = v141.debugGraphs
			if v164 == nil then
				local v165 = 1
				local v166 = v141.forwardGears
				if v141.currentDirection < 0 then
					v166 = v141.backwardGears or v166
				end
				local v167 = v141.minForwardGearRatio == nil and v166 ~= nil and #v166 or v165
				v164 = {}
				v141.debugGraphs = v164
				for v168 = 1, v167 do
					local v169 = Graph.new(20, p135, p136, p137, p138, 0, 0.0001, true, "kN", Graph.STYLE_LINES)
					v169:setColor(1, 1, 1, 1)
					table.insert(v164, v169)
					local v170 = Graph.new(20, p135, p136, p137, p138, 0, 0.0001, false, "", Graph.STYLE_LINES)
					v170:setColor(1, 0, 0, 1)
					table.insert(v164, v170)
					local v171 = Graph.new(20, p135, p136, p137, p138, 0, 0.0001, false, "", Graph.STYLE_LINES)
					v171:setColor(0.35, 1, 0.85, 1)
					table.insert(v164, v171)
					local v172 = Graph.new(20, p135, p136, p137, p138, 0, 0.0001, false, "", Graph.STYLE_LINES)
					v172:setColor(0.18, 0.18, 1, 1)
					table.insert(v164, v172)
					v169.maxValue = 0.01
					v170.maxValue = 0.01
					v171.maxValue = 0.01
					v172.maxValue = 0.01
					for v173 = 1, 20 do
						local v174 = (v173 - 1) / 19 * v163
						local v175
						if v167 == 1 then
							local v176
							v176, v175 = v141:getBestGear(1, v174 * 30 / 3.141592653589793, 0, (1 / 0), 0)
						else
							v175 = v166[v168].ratio
						end
						local v177 = v174 * 30 / 3.141592653589793 * v175
						local v178 = v143:get(v177)
						local v179 = v178 * 1000 * v177 * 3.141592653589793 / 30 / 735.49875
						if v147 <= v177 and v177 <= v150 then
							v169:setValue(v173, v178)
							local v180 = v169.maxValue
							v169.maxValue = math.max(v180, v178)
							v170:setValue(v173, v179)
							local v181 = v170.maxValue
							v170.maxValue = math.max(v181, v179)
							v171:setValue(v173, v175)
							local v182 = v171.maxValue
							v171.maxValue = math.max(v182, v175)
							v172:setValue(v173, v177)
							local v183 = v172.maxValue
							v172.maxValue = math.max(v183, v177)
						end
					end
				end
			else
				for v184 = 1, #v164 do
					local v185 = v164[v184]
					v185.left = p135
					v185.bottom = p136
					v185.width = p137
					v185.height = p138
				end
			end
			for _, v186 in pairs(v164) do
				v186:draw()
			end
			local v187 = renderOverlay
			local v188 = p134.lastSpeedReal * 1000 / v163
			v187(v142, p135, p136, p137 * math.clamp(v188, 0, 1), p138)
			if p139 then
				p135 = p135 + p137 + 0.013
			else
				p136 = p136 - p138 - 0.013
			end
			VehicleDebug.drawMotorLoadGraph(p134, p135, p136, p137, p138)
		end
	end
end
function VehicleDebug.drawMotorLoadGraph(p189, p190, p191, p192, p193)
	if p189.isServer then
		local v194 = p189.spec_motorized
		if v194 ~= nil then
			local v195 = v194.motor
			local v196 = v195.debugLoadGraph
			local v197 = v195.debugLoadGraphSmooth
			local v198 = v195.debugLoadGraphSound
			if v196 == nil then
				v196 = Graph.new(500, p190, p191, p192, p193, 0, 100, true, "%", Graph.STYLE_LINES, 0.1, "time")
				v196:setColor(1, 1, 1, 0.3)
				v195.debugLoadGraph = v196
				v197 = Graph.new(500, p190, p191, p192, p193, 0, 100, false, "", Graph.STYLE_LINES)
				v197:setColor(0, 1, 0, 1)
				v195.debugLoadGraphSmooth = v197
				v198 = Graph.new(500, p190, p191, p192, p193, 0, 100, false, "", Graph.STYLE_LINES)
				v198:setColor(0, 1, 1, 1)
				v195.debugLoadGraphSound = v198
			else
				v196.left = p190
				v196.bottom = p191
				v196.width = p192
				v196.height = p193
				v197.left = p190
				v197.bottom = p191
				v197.width = p192
				v197.height = p193
				v198.left = p190
				v198.bottom = p191
				v198.width = p192
				v198.height = p193
			end
			if v196 ~= nil and (v197 ~= nil and v198 ~= nil) then
				local v199 = v195:getMotorAppliedTorque()
				local v200 = v195:getMotorAvailableTorque()
				v196:addValue(v199 / math.max(v200, 0.0001) * 100, nil, true)
				v197:addValue(v194.smoothedLoadPercentage * 100, nil, true)
				for v201 = 1, #v194.motorSamples do
					local v202 = v194.motorSamples[v201]
					if v202.isGlsFile then
						v198:addValue(getSampleLoopSynthesisLoadFactor(v202.soundSample) * 100, nil, true)
						break
					end
				end
			end
			v196:draw()
			v197:draw()
			v198:draw()
		end
	end
end
function VehicleDebug.drawMotorRPMGraph(p203, p204, p205, p206, p207)
	if p203.isServer then
		local v208 = p203.spec_motorized
		if v208 ~= nil then
			local v209 = v208.motor
			local v210 = v209.debugRPMGraph
			local v211 = v209.debugRPMGraphSmooth
			local v212 = v209.debugRPMGraphSound
			if v210 == nil then
				v210 = Graph.new(500, p204, p205, p206, p207, v209:getMinRpm(), v209:getMaxRpm(), true, " RPM", Graph.STYLE_LINES, 0.1, "")
				v210:setColor(1, 1, 1, 0.3)
				v209.debugRPMGraph = v210
				v211 = Graph.new(500, p204, p205, p206, p207, v209:getMinRpm(), v209:getMaxRpm(), false, "", Graph.STYLE_LINES)
				v211:setColor(0, 1, 0, 1)
				v209.debugRPMGraphSmooth = v211
				local v213 = v209:getMinRpm()
				local v214 = v209:getMaxRpm()
				for v215 = 1, #v208.motorSamples do
					local v216 = v208.motorSamples[v215]
					if v216.isGlsFile then
						v213 = getSampleLoopSynthesisMinRPM(v216.soundSample)
						v214 = getSampleLoopSynthesisMaxRPM(v216.soundSample)
						break
					end
				end
				v212 = Graph.new(500, p204, p205, p206, p207, v213, v214, false, "", Graph.STYLE_LINES)
				v212:setColor(0, 1, 1, 1)
				v209.debugRPMGraphSound = v212
			else
				v210.left = p204
				v210.bottom = p205
				v210.width = p206
				v210.height = p207
				v211.left = p204
				v211.bottom = p205
				v211.width = p206
				v211.height = p207
				v212.left = p204
				v212.bottom = p205
				v212.width = p206
				v212.height = p207
			end
			if v210 ~= nil and (v211 ~= nil and v212 ~= nil) then
				v210:addValue(v209:getLastRealMotorRpm(), nil, true)
				v211:addValue(v209:getLastModulatedMotorRpm(), nil, true)
				for v217 = 1, #v208.motorSamples do
					local v218 = v208.motorSamples[v217]
					if v218.isGlsFile then
						v212:addValue(getSampleLoopSynthesisRPM(v218.soundSample, false), nil, true)
						break
					end
				end
			end
			v210:draw()
			v211:draw()
			v212:draw()
		end
	end
end
function VehicleDebug.drawMotorAccelerationGraph(p219, p220, p221, p222, p223)
	if p219.isServer then
		local v224 = p219.spec_motorized
		if v224 ~= nil then
			local v225 = v224.motor
			local v226 = v225.debugAccelerationGraph
			if v226 == nil then
				v226 = Graph.new(250, p220, p221, p222, p223, 0, 1, true, " Load Factor", Graph.STYLE_LINES, 0.1, "")
				v226:setColor(1, 1, 1, 0.3)
				v225.debugAccelerationGraph = v226
				v225.debugAccelerationGraphAddValue = true
			else
				v226.left = p220
				v226.bottom = p221
				v226.width = p222
				v226.height = p223
			end
			if v226 ~= nil then
				if v225.debugAccelerationGraphAddValue then
					v226:addValue(v225.constantAccelerationCharge, nil, true)
				end
				v225.debugAccelerationGraphAddValue = not v225.debugAccelerationGraphAddValue
			end
			v226:draw()
		end
	end
end
function VehicleDebug.drawDebugRendering(p227)
	local v228, _ = VehicleDebug.drawBaseDebugRendering(p227, 0.015, 0.65)
	local v229 = 0.64 - v228 - 0.005
	local v230 = VehicleDebug.drawWheelInfoRendering(p227, 0.015, v229)
	VehicleDebug.drawDifferentialInfoRendering(p227, 0.015, v229 - (v230 + getCorrectTextSize(0.02)))
	VehicleDebug.drawWheelSlipGraphs(p227)
	VehicleDebug.drawMotorGraphs(p227, 0.65, 0.44, 0.25, 0.2, false)
end
function VehicleDebug.drawTuningDebug(p231)
	local v232, _ = VehicleDebug.drawBaseDebugRendering(p231, 0.015, 0.9)
	local v233 = 0.89 - v232 - 0.005
	local v234 = VehicleDebug.drawWheelInfoRendering(p231, 0.015, v233)
	VehicleDebug.drawDifferentialInfoRendering(p231, 0.015, v233 - (v234 + getCorrectTextSize(0.02)))
end
function VehicleDebug.drawTransmissionDebug(p235)
	local v236, _ = VehicleDebug.drawBaseDebugRendering(p235, 0.015, 0.65)
	VehicleDebug.drawMotorGraphs(p235, 0.01, 0.73, 0.25, 0.2, true)
	local v237 = ""
	local v238 = ""
	local v239 = p235.spec_motorized
	if v239 ~= nil then
		local v240 = v239.motor
		local v241 = v237 .. "\ngear start values:\n"
		local v242 = v238 .. "\n\n"
		local v243 = v241 .. "peakPower:\n"
		local v244 = v242 .. string.format("%d/%dkW\n", v240.startGearValues.availablePower, v240.peakMotorPower)
		local v245 = v243 .. "maxForce:\n"
		local v246 = v244 .. string.format("%.2fkN\n", v240.startGearValues.maxForce)
		local v247 = v245 .. "mass:\n"
		local v248 = v246 .. string.format("%.2fto\n", v240.startGearValues.mass)
		local v249 = v247 .. "slope angle:\n"
		local v250 = string.format
		local v251 = v240.startGearValues.slope
		local v252 = v248 .. v250("%.2f\194\176\n", (math.deg(v251)))
		local v253 = v249 .. "slope percentage:\n"
		local v254 = string.format
		local v255 = v240.startGearValues.slope
		local v256 = v252 .. v254("%.2f%%\n", math.atan(v255) * 100)
		local v257 = v253 .. "dirDiffXZ:\n"
		local v258 = v256 .. string.format("%.2f\n", v240.startGearValues.massDirectionDifferenceXZ)
		local v259 = v257 .. "dirDiffY:\n"
		local v260 = v258 .. string.format("%.2f\n", v240.startGearValues.massDirectionDifferenceY)
		local v261 = v259 .. "dirFac:\n"
		local v262 = v260 .. string.format("%.2f\n", v240.startGearValues.massDirectionFactor)
		local v263 = v261 .. "massFac:\n"
		local v264 = v262 .. string.format("%.2f\n", v240.startGearValues.massFactor)
		local v265 = v263 .. "speedLimit:\n"
		local v266 = v264 .. string.format("%.1f / %.1f \n", v240.speedLimit, p235:getSpeedLimit(true))
		local v267 = v265 .. "auto shift allowed:\n"
		local v268 = v266 .. string.format("%s\n", p235:getIsAutomaticShiftingAllowed())
		local v269 = v267 .. "gear/group change allowed:\n"
		local v270 = v268 .. string.format("%s/%s\n", v240:getIsGearChangeAllowed(), v240:getIsGearGroupChangeAllowed())
		local v271 = v269 .. "gear group shift timer:\n"
		local v272 = v270 .. string.format("%.1f/%.1f sec\n", v240.gearGroupUpShiftTimer / 1000, v240.gearGroupUpShiftTime / 1000)
		local v273 = v271 .. "clutch slipping simer:\n"
		local v274 = v272 .. string.format("%d ms\n", v240.clutchSlippingTimer)
		local v275 = v273 .. "motor can run:\n"
		local v276 = v274 .. string.format("%s\n", v240:getCanMotorRun())
		local v277 = v275 .. "stall timer:\n"
		local v278 = v276 .. string.format("%.2f\n", v240.stallTimer)
		local v279 = v277 .. "turbo scale:\n"
		local v280 = v278 .. string.format("%d%%\n", v240.lastTurboScale * 100)
		local v281 = v279 .. "blowOffValveState:\n"
		local v282 = v280 .. string.format("%d%%\n", v240.blowOffValveState * 100)
		Utils.renderMultiColumnText(0.015, 0.65 - v236, getCorrectTextSize(0.018), { v281, v282 }, 0.008, { RenderText.ALIGN_RIGHT, RenderText.ALIGN_LEFT })
		if v240.forwardGears or v240.backwardGears then
			local v283 = v240.forwardGears
			if v240.currentDirection < 0 then
				v283 = v240.backwardGears or v283
			end
			local v284 = #v283 * 0.035 + 0.05
			drawOutlineRect(0.222, 0.15, v284, 0.35, g_pixelSizeX, g_pixelSizeY, 0, 0, 0, 1)
			drawFilledRect(0.222, 0.15, v284, 0.35, 0, 0, 0, 0.4)
			local v285 = v284 - 0.05
			drawFilledRect(0.272, 0.15, g_pixelSizeX, 0.35, 0, 0, 0, 1)
			drawFilledRect(0.272, 0.46499999999999997, v285, g_pixelSizeY, 0, 0, 0, 1)
			drawFilledRect(0.272, 0.255, v285, g_pixelSizeY, 0, 0, 0, 1)
			local v286 = v240:getGearRatioMultiplier()
			local v287 = v240:getGearRatioMultiplier()
			local v288 = math.abs(v287)
			local v289 = #v283
			local v290 = v285 / v289
			local v291 = 1
			local v292 = 0.21
			for v293 = 1, v289 do
				local v294 = v240.maxRpm * 3.141592653589793 / (30 * v283[v293].ratio * v288) * 3.6
				v291 = math.max(v291, v294)
			end
			local v295 = nil
			local v296 = nil
			for v297 = 1, v289 do
				local v298 = v283[v297]
				v295 = v295 or v298.lastDiffSpeedAfterChange
				v296 = v296 or v298.lastMaxPower
				local v299 = v240.minRpm * 3.141592653589793 / (30 * v298.ratio * v288) * 3.6
				local v300 = v240.maxRpm * 3.141592653589793 / (30 * v298.ratio * v288) * 3.6
				local v301 = v299 / v291 * 0.21
				local v302 = (v300 - v299) / v291 * 0.21
				local v303 = 0.272 + v290 * (v297 - 1)
				local v304 = 0.255 + g_pixelSizeY + v301
				drawFilledRect(v303, v304, v290, v302, (v240.gear == v297 or not v298.lastHasPower) and 0.05 or 1, (v240.gear == v297 or v298.lastHasPower) and 1 or 0.05, 0.05, 0.85)
				setTextAlignment(RenderText.ALIGN_CENTER)
				renderText(v303 + v290 * 0.5, v304 + 0.00375, 0.015, string.format("%.2f", v298.ratio * v288))
				local v305 = v240:getStartInGearFactor(v298.ratio * v288)
				if v305 < v240.startGearThreshold then
					setTextColor(0, 1, 0, 1)
				else
					setTextColor(1, 0, 0, 1)
				end
				renderText(v303 + v290 * 0.5, 0.255 + g_pixelSizeY + 0.21 - 0.015, 0.015, string.format("%.2f", v305))
				if v286 ~= v288 then
					local v306 = v240:getStartInGearFactor(v298.ratio * v286)
					if v306 < v240.startGearThreshold then
						setTextColor(0, 1, 0, 1)
					else
						setTextColor(1, 0, 0, 1)
					end
					renderText(v303 + v290 * 0.5, 0.255 + g_pixelSizeY + 0.21 - 0.03, 0.012, string.format("%.2f", v306))
				end
				setTextColor(1, 1, 1, 1)
				renderText(v303 + v290 * 0.5, 0.1575, 0.0125, string.format("%.2f %.2f", v298.lastPowerFactor or 0, v298.lastRpmFactor or 0))
				renderText(v303 + v290 * 0.5, 0.1785, 0.0125, string.format("%.2f %.2f", v298.lastGearChangeFactor or 0, v298.lastRpmPreferenceFactor or 0))
				if v298.nextPowerValid then
					setTextColor(0, 1, 0, 1)
				else
					setTextColor(1, 0, 0, 1)
				end
				renderText(v303 + v290 * 0.5, 0.1995, 0.015, string.format("%d", v298.lastNextPower or -1))
				if v298.nextRpmValid then
					setTextColor(0, 1, 0, 1)
				else
					setTextColor(1, 0, 0, 1)
				end
				renderText(v303 + v290 * 0.5, 0.2205, 0.015, string.format("%d", v298.lastNextRpm or -1))
				setTextColor(1, 1, 1, 1)
				renderText(v303 + v290 * 0.5, 0.2415, 0.015, string.format("%.2f", v298.lastTradeoff or 0))
			end
			setTextAlignment(RenderText.ALIGN_CENTER)
			renderText(0.247, 0.255 + g_pixelSizeY + 0.21 - 0.015, 0.015, "startFactor")
			local v307, v308 = v240:getBestStartGear(v240.currentGears)
			renderText(0.247, 0.255 + g_pixelSizeY + 0.21 - 0.03, 0.015, string.format("best %d>%d", v308, v307))
			renderText(0.247, 0.1575, 0.01, "pwr/rpm")
			renderText(0.247, 0.1785, 0.01, "gearC/rpmPref")
			renderText(0.247, 0.1995, 0.01, string.format("nextPwr (%d)", v296 or -1))
			renderText(0.247, 0.2205, 0.01, "nextRpm")
			renderText(0.247, 0.2415, 0.01, "tradeoff")
			local v309 = v240.differentialRotSpeed * 3.6
			local v310 = math.abs(v309)
			local v311 = 0.255 + v310 / v291 * (v292 - g_pixelSizeY) + g_pixelSizeY
			setTextBold(true)
			setTextAlignment(RenderText.ALIGN_CENTER)
			renderText(0.247, v311 - 0.005, 0.015, string.format("%.2f", v310))
			setTextBold(false)
			if v295 ~= nil then
				setTextAlignment(RenderText.ALIGN_LEFT)
				renderText(0.277, 0.4774999999999999, 0.01, string.format("Speed after change: %.2fkm/h (%.1f sec)", v295 * 3.6, v240.gearChangeTime / 1000))
			end
			drawFilledRect(0.272, v311, v285, g_pixelSizeY, 0, 1, 0, 0.5)
		end
	end
end
function VehicleDebug.drawDebugAttributeRendering(p_u_312)
	if p_u_312.debugSizeOffsetNode == nil then
		p_u_312.debugSizeOffsetNode = createTransformGroup("debugSizeOffsetNode")
		link(p_u_312.rootNode, p_u_312.debugSizeOffsetNode)
		local v313 = g_storeManager:getItemByXMLFilename(p_u_312.configFileName)
		if v313 ~= nil then
			local v314 = v313.shopTranslationOffset
			if v314 ~= nil then
				setTranslation(p_u_312.debugSizeOffsetNode, -v314[1], -v314[2], -v314[3])
			end
			local v315 = v313.shopRotationOffset
			if v315 ~= nil then
				setRotation(p_u_312.debugSizeOffsetNode, -v315[1], -v315[2], -v315[3])
			end
		end
	end
	local v316 = p_u_312.size.widthOffset
	local v317 = p_u_312.size.heightOffset + p_u_312.size.height / 2
	local v318 = p_u_312.size.lengthOffset
	DebugBox.renderAtNodeWithOffset(p_u_312.debugSizeOffsetNode, v316, v317, v318, p_u_312.size.width, p_u_312.size.height, p_u_312.size.length, Color.PRESETS.BLUE, true, "size")
	if p_u_312.spec_attacherJoints ~= nil then
		for _, v_u_319 in pairs(p_u_312.spec_attacherJoints.attachedImplements) do
			if v_u_319.object ~= nil then
				local v320 = p_u_312.spec_attacherJoints.attacherJoints[v_u_319.jointDescIndex]
				local v321, v322, v323 = getWorldTranslation(v320.jointTransform)
				drawDebugPoint(v321, v322, v323, 1, 0, 0, 1)
				local v327 = {
					["raycastCallback"] = function(p324, p325, _, _, _, p326)
						-- upvalues: (copy) p_u_312, (copy) v_u_319
						if p_u_312.vehicleNodes[p325] ~= nil or v_u_319.object.vehicleNodes[p325] ~= nil then
							return true
						end
						p324.groundDistance = p326
						return false
					end,
					["vehicle"] = p_u_312,
					["object"] = v_u_319.object,
					["groundDistance"] = 0
				}
				raycastAll(v321, v322, v323, 0, -1, 0, 4, "raycastCallback", v327, CollisionFlag.TERRAIN + CollisionFlag.STATIC_OBJECT)
				drawDebugLine(v321, v322, v323, 0, 1, 0, v321, v322 - v327.groundDistance, v323, 0, 1, 0)
				drawDebugPoint(v321, v322 - v327.groundDistance, v323, 1, 0, 0, 1)
				Utils.renderTextAtWorldPosition(v321, v322 + 0.1, v323, string.format("%.4f", v327.groundDistance), getCorrectTextSize(0.02), 0)
				local v328 = v_u_319.object:getActiveInputAttacherJoint()
				if #v328.heightNodes > 0 then
					for v329 = 1, #v328.heightNodes do
						local v330 = v328.heightNodes[v329]
						local v331, v332, v333 = getWorldTranslation(v330.node)
						local v334 = getTerrainHeightAtWorldPos(g_terrainNode, v331, v332, v333)
						DebugGizmo.renderAtNode(v330.node, string.format("HeightNode: %.3f", v332 - v334))
					end
				end
			end
		end
		for _, v335 in pairs(p_u_312:getAttacherJoints()) do
			DebugGizmo.renderAtNode(v335.jointTransform, getName(v335.jointTransform), false, 0.3)
			if v335.bottomArm ~= nil and v335.bottomArm.referenceDistance ~= nil then
				for v336, v337 in pairs(AttacherJoints.LOWER_LINK_WIDTH_BY_CATEGORY) do
					local v338 = VehicleDebug.DEBUG_COLORS[v336 + 1]
					if v337 < v335.bottomArm.minWidth or v335.bottomArm.maxWidth < v337 then
						v338 = VehicleDebug.COLOR.GREY
					end
					local v339, v340, v341 = v338:unpack()
					local v342, v343, v344 = localToWorld(v335.bottomArm.translationNode, v337 * 0.5, 0, v335.bottomArm.referenceDistance * v335.bottomArm.zScale)
					local v345, v346, v347 = localToWorld(v335.bottomArm.translationNode, -v337 * 0.5, 0, v335.bottomArm.referenceDistance * v335.bottomArm.zScale)
					drawDebugLine(v342, v343 - 0.1, v344, v339, v340, v341, v342, v343 + 0.1, v344, v339, v340, v341, true)
					drawDebugLine(v345, v346 - 0.1, v347, v339, v340, v341, v345, v346 + 0.1, v347, v339, v340, v341, true)
					local v348 = AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY[v336] * 0.5
					DebugSphere.renderAtPosition(v342, v343, v344, v348, v338, 10, true, false, nil)
					DebugSphere.renderAtPosition(v345, v346, v347, v348, v338, 10, true, false, nil)
				end
			end
			if v335.transNode ~= nil and getVisibility(v335.transNode) then
				local v349, v350, v351 = getWorldTranslation(v335.transNode)
				local v352, v353, v354 = localDirectionToWorld(v335.jointTransform, 0, 1, 0)
				local v355, v356, v357 = localDirectionToWorld(v335.jointTransform, 0, 0, 1)
				local v358 = v349 - v357 * 0.05
				local v359 = v350 + v356 * 0.05
				local v360 = v351 + v355 * 0.05
				DebugBox.renderAtPosition(v358, v359, v360, v352, v353, v354, v355, v356, v357, 0.2, v335.transNodeHeight, 0.3, Color.PRESETS.GREEN, true, nil, false)
			end
		end
	end
	if p_u_312.spec_attachable ~= nil then
		for _, v361 in pairs(p_u_312:getInputAttacherJoints()) do
			if v361.jointType == AttacherJoints.JOINTTYPE_IMPLEMENT and v361.bottomArm ~= nil then
				for _, v362 in ipairs(v361.bottomArm.widths) do
					local v363 = AttacherJoints.getClosestLowerLinkCategoryIndex(v362)
					local v364, v365, v366 = VehicleDebug.DEBUG_COLORS[v363 + 1]:unpack()
					local v367, v368, v369 = localToWorld(v361.node, 0, 0, v362 * 0.5)
					local v370, v371, v372 = localToWorld(v361.node, 0, 0, -v362 * 0.5)
					drawDebugLine(v367, v368 - 0.1, v369, v364, v365, v366, v367, v368 + 0.1, v369, v364, v365, v366, true)
					drawDebugLine(v370, v371 - 0.1, v372, v364, v365, v366, v370, v371 + 0.1, v372, v364, v365, v366, true)
					local v373 = AttacherJoints.LOWER_LINK_BALL_SIZE_BY_CATEGORY[v363] * 0.5
					DebugSphere.renderAtPosition(v367, v368, v369, v373, VehicleDebug.DEBUG_COLORS[v363 + 1], 10, true, false, nil)
					DebugSphere.renderAtPosition(v370, v371, v372, v373, VehicleDebug.DEBUG_COLORS[v363 + 1], 10, true, false, nil)
				end
			end
		end
	end
	if p_u_312.spec_wheels ~= nil then
		for _, v374 in ipairs(p_u_312:getWheels()) do
			v374.destruction:drawAreas()
		end
	end
	if p_u_312.spec_workArea ~= nil then
		local v375 = {}
		local v376 = 0
		for _, v377 in pairs(p_u_312.spec_workArea.workAreas) do
			local v378 = v375[v377.type]
			if v378 == nil then
				v376 = v376 + 1
				v378 = VehicleDebug.DEBUG_COLORS[v376]
				v375[v377.type] = v378
			end
			local v379, v380, v381 = getWorldTranslation(v377.start)
			local v382 = v380 < 0 and -100 or getTerrainHeightAtWorldPos(g_terrainNode, v379, 0, v381) + 0.1
			local v383, v384, v385 = getWorldTranslation(v377.width)
			local v386 = v384 < 0 and -100 or getTerrainHeightAtWorldPos(g_terrainNode, v383, 0, v385) + 0.1
			local v387, v388, v389 = getWorldTranslation(v377.height)
			local v390 = v388 < 0 and -100 or getTerrainHeightAtWorldPos(g_terrainNode, v387, 0, v389) + 0.1
			DebugPlane.renderWithPositions(v379, v382, v381, v383, v386, v385, v387, v390, v389, v378, false)
			local v391, _, v392 = getWorldTranslation(v377.start)
			local v393, _, v394 = getWorldTranslation(v377.width)
			local v395, _, v396 = getWorldTranslation(v377.height)
			local v397 = v395 + (v393 - v395) * 0.5
			local v398 = v396 + (v394 - v396) * 0.5
			local v399 = getTerrainHeightAtWorldPos(g_terrainNode, v397, 0, v398) + 0.1
			local v400 = v399 < 0 and -100 or v399
			local v401 = p_u_312:getIsWorkAreaActive(v377) and VehicleDebug.COLOR.ACTIVE or VehicleDebug.COLOR.INACTIVE
			local v402 = Utils.renderTextAtWorldPosition
			local v403 = g_workAreaTypeManager
			local v404 = v377.type
			v402(v397, v400, v398, tostring(v403:getWorkAreaTypeNameByIndex(v404)), getCorrectTextSize(0.015), -getCorrectTextSize(0.015) * 0.5, v401)
			if p_u_312.spec_ridgeMarker ~= nil and (#p_u_312.spec_ridgeMarker.ridgeMarkers > 0 and v377.type == WorkAreaType.SOWINGMACHINE) then
				local v405 = calcDistanceFrom(v377.start, v377.width)
				local v406 = calcDistanceFrom(v377.start, v377.height)
				local v407, v408 = MathUtil.vector2Normalize(v391 - v393, v392 - v394)
				local v409, v410 = MathUtil.vector2Normalize(v395 - v391, v396 - v392)
				local v411 = (v391 + v393) * 0.5
				local v412 = (v392 + v394) * 0.5
				drawDebugLine(v411 + v407 * v405, v400, v412 + v408 * v405, 0, 1, 1, v411 + v407 * v405 + v409 * v406, v400, v412 + v408 * v405 + v410 * v406, 0, 1, 1, true)
				drawDebugLine(v411 - v407 * v405, v400, v412 - v408 * v405, 0, 1, 1, v411 - v407 * v405 + v409 * v406, v400, v412 - v408 * v405 + v410 * v406, 0, 1, 1, true)
			end
		end
	end
	if p_u_312.getTipOcclusionAreas ~= nil then
		for _, v413 in pairs(p_u_312:getTipOcclusionAreas()) do
			DebugPlane.renderWithNodes(v413.start, v413.width, v413.height, Color.PRESETS.YELLOW, true)
		end
	end
	if p_u_312.spec_foliageBending ~= nil then
		for _, v414 in ipairs(p_u_312.spec_foliageBending.bendingNodes) do
			if v414.id ~= nil then
				DebugUtil.drawDebugRectangle(v414.node, v414.minX, v414.maxX, v414.minZ, v414.maxZ, v414.yOffset, 1, 0, 0)
				DebugUtil.drawDebugRectangle(v414.node, v414.minX - 0.25, v414.maxX + 0.25, v414.minZ - 0.25, v414.maxZ + 0.25, v414.yOffset, 0, 1, 0)
			end
		end
	end
	if p_u_312.spec_licensePlates ~= nil then
		local function v432(p415, p416, p417, p418, p419)
			if math.abs(p416) ~= (1 / 0) then
				local v420, v421, v422
				if p417 == (1 / 0) then
					v420 = 0
					v421 = 1
					v422 = 0
					p417 = 0.25
				else
					v420 = 1
					v421 = 0
					v422 = 0
				end
				local v423, v424, v425
				if p418 == (1 / 0) then
					p418 = 0.25
					v423 = 0
					v424 = 1
					v425 = 0
				else
					v423 = 1
					v424 = 0
					v425 = 0
				end
				local v426, v427, v428, v429, v430, v431
				if p419 then
					v426, v427, v428 = localToWorld(p415.node, p416, p417, 0)
					v429, v430, v431 = localToWorld(p415.node, p416, -p418, 0)
				else
					v426, v427, v428 = localToWorld(p415.node, p417, p416, 0)
					v429, v430, v431 = localToWorld(p415.node, -p418, p416, 0)
				end
				drawDebugLine(v426, v427, v428, v420, v421, v422, v429, v430, v431, v423, v424, v425)
			end
		end
		for _, v433 in ipairs(p_u_312.spec_licensePlates.licensePlates) do
			DebugGizmo.renderAtNode(v433.node)
			local v434 = v433.placementArea[1]
			local v435 = v433.placementArea[2]
			local v436 = v433.placementArea[3]
			local v437 = v433.placementArea[4]
			v432(v433, v435, v434, v436, true)
			v432(v433, -v437, v434, v436, true)
			v432(v433, v434, v435, v437, false)
			v432(v433, -v436, v435, v437, false)
		end
	end
	if p_u_312.spec_fillUnit ~= nil then
		local v438 = p_u_312:getFillUnits()
		for v439 = 1, #v438 do
			local v440 = v438[v439]
			local v441 = v440.autoAimTarget
			if v441.node ~= nil and (v441.startZ ~= nil and v441.endZ ~= nil) then
				local v442 = v440.capacity * v441.startPercentage
				local v443 = (v440.fillLevel - v442) / (v440.capacity - v442)
				local v444 = math.clamp(v443, 0, 1)
				if v441.invert then
					v444 = 1 - v444
				end
				local v445 = (v441.endZ - v441.startZ) * v444 + v441.startZ
				local v446, v447, v448 = localToWorld(getParent(v441.node), v441.baseTrans[1], v441.baseTrans[2], v441.startZ)
				local v449, v450, v451 = localToWorld(getParent(v441.node), v441.baseTrans[1], v441.baseTrans[2], v441.endZ)
				drawDebugLine(v446, v447, v448, 0, 1, 0, v449, v450, v451, 0, 1, 0, true)
				drawDebugLine(v446, v447, v448, 1, 0, 0, v446, v447 + 0.2, v448, 1, 0, 0, true)
				drawDebugLine(v449, v450, v451, 1, 0, 0, v449, v450 + 0.2, v451, 1, 0, 0, true)
				local v452, v453, v454 = localToWorld(getParent(v441.node), v441.baseTrans[1], v441.baseTrans[2], v445)
				drawDebugLine(v452, v453, v454, 0, 0, 1, v452, v453 - 0.5, v454, 0, 0, 1, true)
				local v455, v456, v457 = localToWorld(getParent(v441.node), v441.baseTrans[1] - 0.5, v441.baseTrans[2], v441.startZ + 0.75)
				local v458, v459, v460 = localToWorld(getParent(v441.node), v441.baseTrans[1] + 0.5, v441.baseTrans[2], v441.startZ + 0.75)
				drawDebugLine(v455, v456, v457, 0, 1, 1, v458, v459, v460, 0, 1, 1, true)
				local v461, v462, v463 = localToWorld(getParent(v441.node), v441.baseTrans[1] - 0.5, v441.baseTrans[2], v441.endZ - 0.75)
				local v464, v465, v466 = localToWorld(getParent(v441.node), v441.baseTrans[1] + 0.5, v441.baseTrans[2], v441.endZ - 0.75)
				drawDebugLine(v461, v462, v463, 0, 1, 1, v464, v465, v466, 0, 1, 1, true)
			end
		end
	end
	if p_u_312.spec_dischargeable ~= nil then
		local v467 = p_u_312.spec_dischargeable.dischargeNodes
		for v468 = 1, #v467 do
			local v469 = v467[v468].info
			local v470, v471, v472 = localToWorld(v469.node, -v469.width, 0, v469.zOffset)
			local v473, v474, v475 = localToWorld(v469.node, v469.width, 0, v469.zOffset)
			drawDebugLine(v470, v471, v472, 1, 0, 1, v473, v474, v475, 1, 0, 1)
		end
	end
	if p_u_312:getIsActiveForInput() and p_u_312.spec_enterable ~= nil then
		local v476 = p_u_312.spec_enterable
		local v477 = v476.cameras[v476.camIndex]
		if v477 ~= nil then
			local v478 = getName(v477.cameraPositionNode)
			local v479, v480, v481 = getTranslation(v477.cameraPositionNode)
			local v482 = v477.cameraPositionNode
			if v477.rotateNode ~= nil then
				v482 = v477.rotateNode
			end
			local v483, v484, v485 = getRotation(v482)
			if v477.hasExtraRotationNode then
				v483 = -((3.141592653589793 - v483) % 6.283185307179586)
				v484 = (v484 + 3.141592653589793) % 6.283185307179586
				v485 = (v485 - 3.141592653589793) % 6.283185307179586
			end
			local v486 = string.format("camera \'%s\': translation: %.2f %.2f %.2f  rotation: %.2f %.2f %.2f", v478, v479, v480, v481, math.deg(v483), math.deg(v484), (math.deg(v485)))
			setTextAlignment(RenderText.ALIGN_CENTER)
			setTextColor(0, 0, 0, 1)
			renderText(0.5 + g_pixelSizeX, 0.95 - g_pixelSizeY, 0.02, v486)
			renderText(0.5 + g_pixelSizeX, 0.98 - g_pixelSizeY, 0.05, "______________________________________________________________________")
			setTextColor(1, 1, 1, 1)
			renderText(0.5, 0.95, 0.02, v486)
			renderText(0.5, 0.98, 0.05, "______________________________________________________________________")
			setTextAlignment(RenderText.ALIGN_LEFT)
		end
	end
	for v487, v488 in pairs(p_u_312.components) do
		local v489, v490, v491 = getCenterOfMass(v488.node)
		local v492, v493, v494 = localToWorld(v488.node, v489, v490, v491)
		local v495, v496, v497 = localDirectionToWorld(v488.node, 0, 0, 1)
		local v498, v499, v500 = localDirectionToWorld(v488.node, 0, 1, 0)
		DebugGizmo.renderAtPosition(v492, v493, v494, v495, v496, v497, v498, v499, v500, "CoM comp" .. v487, false, 0.7)
	end
	if p_u_312.spec_ikChains ~= nil then
		IKUtil.debugDrawChains(p_u_312.spec_ikChains.chains, true)
	end
	if p_u_312.spec_powerTakeOffs ~= nil then
		for v501 = 1, #p_u_312.spec_powerTakeOffs.outputPowerTakeOffs do
			local v502 = p_u_312.spec_powerTakeOffs.outputPowerTakeOffs[v501]
			if v502.outputNode ~= nil then
				local v503, v504, v505 = getWorldTranslation(v502.outputNode)
				local v506, v507, v508 = localDirectionToWorld(v502.outputNode, 0, 0, 1)
				local v509, v510, v511 = localDirectionToWorld(v502.outputNode, 0, 1, 0)
				drawDebugLine(v503, v504, v505, 0, 1, 0, v503 + v509 * 0.25, v504 + v510 * 0.25, v505 + v511 * 0.25, 0, 1, 0)
				drawDebugLine(v503, v504, v505, 0, 0, 1, v503 + v506 * 0.25, v504 + v507 * 0.25, v505 + v508 * 0.25, 0, 0, 1)
				if v502.connectedInput ~= nil then
					local v512, v513, v514 = localToWorld(v502.outputNode, 0, 0, -0.05)
					local v515, v516, v517 = localDirectionToWorld(v502.outputNode, 0, 1, 0)
					local v518, v519, v520 = localDirectionToWorld(v502.outputNode, 0, 0, -1)
					DebugBox.renderAtPosition(v512, v513, v514, v515, v516, v517, v518, v519, v520, v502.connectedInput.size, v502.connectedInput.size, 0.1, Color.PRESETS.YELLOW, true, nil, false)
				end
			end
		end
	end
	if p_u_312.spec_connectionHoses ~= nil then
		for v521 = 1, #p_u_312.spec_connectionHoses.targetNodes do
			local v522 = p_u_312.spec_connectionHoses.targetNodes[v521]
			local v523, v524, v525 = getWorldTranslation(v522.node)
			local v526, v527, v528 = localDirectionToWorld(v522.node, 0, 0, -1)
			local v529, v530, v531 = localDirectionToWorld(v522.node, 0, 1, 0)
			drawDebugLine(v523, v524, v525, 0, 1, 0, v523 + v529 * 0.1, v524 + v530 * 0.1, v525 + v531 * 0.1, 0, 1, 0)
			drawDebugLine(v523, v524, v525, 0, 0, 1, v523 + v526 * 0.1, v524 + v527 * 0.1, v525 + v528 * 0.1, 0, 0, 1)
		end
	end
	if p_u_312.spec_mountable ~= nil then
		if p_u_312.spec_mountable.dynamicMountJointTransY ~= nil then
			DebugUtil.drawDebugRectangle(p_u_312.rootNode, -p_u_312.size.width * 0.5, p_u_312.size.width * 0.5, -p_u_312.size.length * 0.5, p_u_312.size.length * 0.5, p_u_312.spec_mountable.dynamicMountJointTransY, 0, 1, 0, 0.2, true)
		end
		if p_u_312.spec_mountable.additionalMountDistance ~= 0 then
			DebugUtil.drawDebugRectangle(p_u_312.rootNode, -p_u_312.size.width * 0.5, p_u_312.size.width * 0.5, -p_u_312.size.length * 0.5, p_u_312.size.length * 0.5, p_u_312.spec_mountable.additionalMountDistance, 1, 1, 0, 0.2, true)
		end
	end
end
function VehicleDebug.drawDebugAIRendering(p_u_532)
	local function v_u_534(p533)
		if math.abs(p533) < 0.001 then
			return "0.0"
		elseif math.abs(p533) < 0.01 then
			return string.format("%.3f", p533)
		elseif math.abs(p533) < 0.1 then
			return string.format("%.2f", p533)
		else
			return string.format("%.1f", p533)
		end
	end
	local function v556(p535, p536, p537)
		-- upvalues: (copy) p_u_532, (copy) v_u_534
		local v538
		if p_u_532.rootVehicle.getAIRootNode == nil then
			v538 = p_u_532.rootNode
		else
			v538 = p_u_532.rootVehicle:getAIRootNode()
		end
		local v539 = (-1 / 0)
		local v540 = (1 / 0)
		if p_u_532.spec_workArea ~= nil then
			local v541, _, v542 = localToLocal(p535, v538, 0, 0, 0)
			for _, v543 in pairs(p_u_532.spec_workArea.workAreas) do
				if p536 == true then
					local _, _, v544 = localToLocal(v543.height, v538, 0, 0, 0)
					local v545 = v542 - v544
					if v545 > 0 then
						v540 = math.min(v540, v545)
					else
						v539 = math.max(v539, v545)
					end
				elseif p537 == true then
					local _, _, v546 = localToLocal(v543.start, v538, 0, 0, 0)
					local v547 = v542 - v546
					if v547 > 0 then
						v540 = math.min(v540, v547)
					else
						v539 = math.max(v539, v547)
					end
					local _, _, v548 = localToLocal(v543.width, v538, 0, 0, 0)
					local v549 = v542 - v548
					if v549 > 0 then
						v540 = math.min(v540, v549)
					else
						v539 = math.max(v539, v549)
					end
				else
					local v550, _, _ = localToLocal(v543.start, v538, 0, 0, 0)
					local v551 = v541 - v550
					if v551 > 0 then
						v540 = math.min(v540, v551)
					else
						v539 = math.max(v539, v551)
					end
					local v552, _, _ = localToLocal(v543.width, v538, 0, 0, 0)
					local v553 = v541 - v552
					if v553 > 0 then
						v540 = math.min(v540, v553)
					else
						v539 = math.max(v539, v553)
					end
					local v554, _, _ = localToLocal(v543.height, v538, 0, 0, 0)
					local v555 = v541 - v554
					if v555 > 0 then
						v540 = math.min(v540, v555)
					else
						v539 = math.max(v539, v555)
					end
				end
			end
		end
		if math.abs(v539) < math.abs(v540) then
			return v_u_534(v539)
		else
			return v_u_534(v540)
		end
	end
	local function v571(p557, p558, p559)
		local v560, v561, v562 = getWorldTranslation(p557)
		local v563 = getTerrainHeightAtWorldPos(g_terrainNode, v560, 0, v562)
		local v564 = v561 < 0 and -100 or v563
		local v565, v566, v567 = localDirectionToWorld(p557, 0, 1, 0)
		local v568, v569, v570 = localDirectionToWorld(p557, 0, 0, 1)
		DebugGizmo.renderAtPosition(v560, v564 + (p559 or 0), v562, v568, v569, v570, v565, v566, v567, p558, false, 0.5)
	end
	if p_u_532.getAIMarkers ~= nil then
		if p_u_532:getCanImplementBeUsedForAI() then
			local v572, v573, v574 = p_u_532:getAIMarkers()
			v571(v572, string.format("%s (x%sm z%sm)", getName(v572), v556(v572), v556(v572, false, true)))
			v571(v573, string.format("%s (x%sm z%sm)", getName(v573), v556(v573), v556(v573, false, true)))
			v571(v574, string.format("%s (z%sm)", getName(v574), v556(v574, true)))
			local v575 = p_u_532:getAIToolReverserDirectionNode()
			if v575 ~= nil then
				local v576
				if p_u_532.rootVehicle.getAIRootNode == nil then
					v576 = nil
				else
					local v577 = p_u_532.rootVehicle:getAIRootNode()
					local v578, v579
					v576, v578, v579 = localToLocal(v575, v577, 0, 0, 0)
				end
				local v580 = v575 == v574 and "" or " " .. getName(v575)
				v571(v575, string.format("reverser%s (x%sm)", v580, v_u_534(v576 or 0)), 0.3)
			end
		end
		if not p_u_532:getIsAIActive() then
			local v581 = p_u_532:getAIImplementCollisionTrigger()
			if v581 ~= nil and v581.node ~= nil then
				local v582, v583, v584 = getWorldTranslation(v581.node)
				local v585 = getTerrainHeightAtWorldPos(g_terrainNode, v582, 0, v584)
				local v586 = v583 - (v583 < 0 and -100 or v585) - v581.height * 0.5
				DebugUtil.drawDebugCube(v581.node, v581.width, v581.height, v581.length, 0, 0, 1, 0, -v586, v581.length * 0.5)
			end
		end
		local v587 = true
		for _, v588 in ipairs(p_u_532.rootVehicle.childVehicles) do
			if v588 ~= p_u_532 and (v588.getCanImplementBeUsedForAI ~= nil and v588:getCanImplementBeUsedForAI()) then
				v587 = false
				break
			end
		end
		if (v587 or p_u_532:getIsSelected()) and (p_u_532.spec_aiImplement ~= nil and p_u_532.spec_aiImplement.debugArea ~= nil) then
			g_debugManager:addFrameElement(p_u_532.spec_aiImplement.debugArea)
		end
	end
	if p_u_532.drawDebugAIAgent ~= nil then
		p_u_532:drawDebugAIAgent()
	end
	if p_u_532.drawAIAgentAttachments ~= nil then
		p_u_532:drawAIAgentAttachments()
	end
	if Platform.gameplay.automaticVehicleControl then
		local v589 = p_u_532.rootVehicle
		if v589.getIsControlled ~= nil and (v589:getIsControlled() and v589.actionController ~= nil) then
			v589.actionController:drawDebugRendering()
		end
	end
end
function VehicleDebug.drawDebugValues(p590)
	local v591 = {}
	for v592, v593 in ipairs(p590.specializations) do
		if v593.updateDebugValues ~= nil then
			local v594 = {}
			v593.updateDebugValues(p590, v594)
			if #v594 > 0 then
				local v595 = {
					["title"] = p590.specializationNames[v592],
					["content"] = v594
				}
				table.insert(v591, v595)
			end
		end
	end
	local v596 = DebugInfoTable.new()
	v596:createWithNodeToCamera(p590.rootNode, v591, 4, 0.05)
	g_debugManager:addFrameElement(v596)
end
function VehicleDebug.drawSoundDebugValues(p597)
	local v_u_598 = 0.015
	local v599 = 0.1 + g_pixelSizeX
	local function v_u_612(p600, p601, p602, p603, p604, p605, p606, p607, p608, p609, p610, p611)
		-- upvalues: (copy) v_u_598
		drawOutlineRect(p600, p601, p602, p603, g_pixelSizeX, g_pixelSizeY, 0, 0, 0, 1)
		drawFilledRect(p600 + g_pixelSizeX, p601 + g_pixelSizeY, p602 - g_pixelSizeX * 2, p603 - g_pixelSizeY * 2, 0, 0, 0, 0.4)
		drawFilledRect(p600 + g_pixelSizeX, p601 + g_pixelSizeY, p602 * p604 - g_pixelSizeX * 2, p603 - g_pixelSizeY * 2, p607, p608, p609, p610)
		if p605 ~= -1 then
			drawFilledRect(p600 + p602 * p605, p601, g_pixelSizeX, p603, 1, 0, 0, 1)
		end
		setTextAlignment(RenderText.ALIGN_CENTER)
		renderText(p600 + p602 * 0.5, p601 + p603 - 0.0075 - g_pixelSizeY * 4, 0.012 * (p611 or 1), p606)
	end
	setTextColor(1, 1, 1, 1)
	local v613 = 0.15
	local function v636(p614, p615, p616, p617, p618, p619)
		-- upvalues: (copy) v_u_612
		local v620 = {}
		for v621, v622 in pairs(g_soundManager.modifierTypeIndexToDesc) do
			local v623, v624, v625 = g_soundManager:getSampleModifierValue(p618, p619, v621)
			if v625 then
				local v626 = {
					["changeValue"] = v623,
					["t"] = v624,
					["name"] = v622.name
				}
				table.insert(v620, v626)
			end
		end
		if p618.maxValuePerModifier == nil then
			p618.maxValuePerModifier = {}
			for _, v627 in pairs(g_soundManager.modifierTypeIndexToDesc) do
				p618.maxValuePerModifier[v627.name] = 0
			end
		end
		local v628 = #v620
		if v628 > 0 then
			local v629 = p616 / v628
			for v630 = 1, v628 do
				local v631 = v620[v630]
				local v632 = p618.maxValuePerModifier
				local v633 = v631.name
				local v634 = p618.maxValuePerModifier[v631.name]
				local v635 = v631.changeValue
				v632[v633] = math.max(v634, v635, 1)
				v_u_612(p614 + v629 * (v630 - 1), p615, v629 * (v630 < v628 and 0.95 or 1), p617, v631.changeValue / p618.maxValuePerModifier[v631.name], -1, string.format("%s raw:%.2f mod:%.2f", v631.name, v631.t, v631.changeValue), 0, 0.5, 0, 0.3, 0.7)
			end
		end
	end
	local v637 = 0.9
	local v638 = 0.06
	local v639 = 1
	for _, v640 in pairs(g_soundManager.orderedSamples) do
		local v641 = false
		for _, v642 in pairs(g_currentMission.surfaceSounds) do
			if v642.name == v640.sampleName then
				v641 = true
			end
		end
		if v640.modifierTargetObject == p597 and not v641 then
			local v643 = v640.isGlsFile
			if not v643 then
				for v644, _ in pairs(g_soundManager.modifierTypeIndexToDesc) do
					for _, v645 in pairs({ "volume", "pitch", "lowpassGain" }) do
						local _, _, v646 = g_soundManager:getSampleModifierValue(v640, v645, v644)
						v643 = v643 or v646
						if v643 then
							break
						end
					end
				end
			end
			if v643 then
				v637 = v637 - 0.06
				drawOutlineRect(0.15, v637, v599, v638 + g_pixelSizeY, g_pixelSizeX, g_pixelSizeY, 0, 0, 0, 1)
				drawOutlineRect(0.15, v637, 0.7, v638 + g_pixelSizeY, g_pixelSizeX, g_pixelSizeY, 0, 0, 0, 1)
				drawFilledRect(0.15, v637, v599, 0.06, 0, g_soundManager:getIsSamplePlaying(v640) and 1 or 0, 0, 0.4)
				setTextAlignment(RenderText.ALIGN_CENTER)
				renderText(v613 + v599 * 0.5, v637 + 0.06 - 0.012 - 0.0075, 0.018, v640.sampleName)
				if v640.isGlsFile then
					renderText(v613 + v599 * 0.5, v637 + 0.06 - 0.024 - 0.0075, 0.012, string.format("loopSyn: rpm=%d load=%d%%", getSampleLoopSynthesisRPM(v640.soundSample, false), getSampleLoopSynthesisLoadFactor(v640.soundSample) * 100))
				end
				setTextAlignment(RenderText.ALIGN_RIGHT)
				renderText(v613 + v599 + v599 * 0.6, v637 + 0.06 - 0.015 - 0.0075, 0.015, "volume:")
				renderText(v613 + v599 + v599 * 0.6, v637 + 0.06 - 0.03 - 0.0075, 0.015, "pitch:")
				renderText(v613 + v599 + v599 * 0.6, v637 + 0.06 - 0.045 - 0.0075, 0.015, "lowpassGain:")
				local v647 = g_soundManager:getModifierFactor(v640, "volume")
				local v648 = v640.debugMaxVolume or 1
				local v649 = v640.current.volume * v647
				local v650 = v640.current.volume
				v640.debugMaxVolume = math.max(v648, v649, v650)
				local v651 = v613 + v599 + v599 * 0.7
				local v652 = v637 + 0.06 - 0.015 - 0.0075
				local v653 = 0.015
				v_u_612(v651, v652, v599, v653, v640.current.volume * v647 / v640.debugMaxVolume, v640.current.volume / v640.debugMaxVolume, string.format("%.2f", v640.current.volume * v647), 0, 0.5, 0, 0.4)
				local v654 = v651 + v599 + v599 * 0.1
				v636(v654, v652, 1 - v654 - 0.15 - v599 * 0.1, v653, v640, "volume")
				local v655 = g_soundManager:getModifierFactor(v640, "pitch")
				local v656 = v640.debugMaxPitch or 1
				local v657 = v640.current.pitch * v655
				local v658 = v640.current.pitch
				v640.debugMaxPitch = math.max(v656, v657, v658)
				local v659 = v613 + v599 + v599 * 0.7
				local v660 = v637 + 0.06 - 0.03 - 0.0075
				local v661 = 0.015
				v_u_612(v659, v660, v599, v661, v640.current.pitch * v655 / v640.debugMaxPitch, v640.current.pitch / v640.debugMaxPitch, string.format("%.2f", v640.current.pitch * v655), 0.5, 0.5, 0, 0.4)
				local v662 = v659 + v599 + v599 * 0.1
				v636(v662, v660, 1 - v662 - 0.15, v661, v640, "pitch")
				local v663 = g_soundManager:getModifierFactor(v640, "lowpassGain")
				local v664 = v640.debugMaxLowPass or 1
				local v665 = v640.current.lowpassGain * v663
				local v666 = v640.current.lowpassGain
				v640.debugMaxLowPass = math.max(v664, v665, v666)
				local v667 = v613 + v599 + v599 * 0.7
				local v668 = v637 + 0.06 - 0.045 - 0.0075
				local v669 = 0.015
				v_u_612(v667, v668, v599, v669, v640.current.lowpassGain * v663 / v640.debugMaxLowPass, v640.current.lowpassGain / v640.debugMaxLowPass, string.format("%.2f", v640.current.lowpassGain * v663), 0, 0.5, 0.5, 0.4)
				local v670 = v667 + v599 + v599 * 0.1
				v636(v670, v668, 1 - v670 - 0.15, v669, v640, "lowpassGain")
			end
			v639 = v639 + 1
		end
	end
	local v671 = p597.spec_wheels
	if v671 then
		local v672, v673, v674 = getWorldTranslation(p597.rootNode)
		Utils.renderTextAtWorldPosition(v672, v673, v674, string.format("surfaceSound: %s", v671.currentSurfaceSound and v671.currentSurfaceSound.sampleName or "none"), 0.01)
	end
	setTextAlignment(RenderText.ALIGN_LEFT)
	VehicleDebug.drawMotorLoadGraph(p597, 0.2, 0.05, 0.25, 0.2)
	VehicleDebug.drawMotorRPMGraph(p597, 0.55, 0.05, 0.25, 0.2)
	VehicleDebug.drawMotorAccelerationGraph(p597, 0.2, 0.28, 0.25, 0.1)
end
function VehicleDebug.drawAnimationDebug(p675)
	if p675.playAnimation ~= nil then
		local v676 = 0.1 + g_pixelSizeX
		local v677 = 0.7 - v676 - g_pixelSizeX * 2
		local v678 = p675.spec_animatedVehicle
		local v679 = 0
		local v680 = 0.05
		local v681 = 0.15
		local v682 = 0.0125
		for _, v683 in pairs(v678.animations) do
			if #v683.parts > 0 then
				v679 = v679 + 1
			end
		end
		local v684 = VehicleDebug.selectedAnimation % v679 + 1
		setTextColor(1, 1, 1, 1)
		local v685 = 1
		local v686 = 0.9
		for v687, v688 in pairs(v678.animations) do
			if #v688.parts > 0 then
				local v689 = v686 - 0.05
				drawOutlineRect(0.15, v689, 0.7, v680 + g_pixelSizeY, g_pixelSizeX, g_pixelSizeY, 0, 0, 0, 1)
				drawFilledRect(0.15, v689, 0.7, 0.05, 0, 0, 0, 0.4)
				drawFilledRect(v681 + v676 - g_pixelSizeX, v689, g_pixelSizeX, 0.05, 0, 0, 0, 1)
				local v690 = v677 / v688.duration
				local v691 = v688.duration < 2000 and 500 or 1000
				local v692 = v688.duration < 1000 and 100 or v691
				local v693 = v688.duration / v692
				for v694 = 1, math.floor(v693) do
					if v694 * v692 ~= v688.duration then
						setTextAlignment(RenderText.ALIGN_CENTER)
						renderText(v681 + v676 + v690 * v694 * v692, v689 + 0.025 - 0.005, 0.01, string.format("%.1f", v694 * v692 / 1000))
						drawFilledRect(v681 + v676 + v690 * v694 * v692, v689, g_pixelSizeX, 0.015, 0, 0, 0, 1)
					end
				end
				setTextBold(v684 == v685)
				setTextAlignment(RenderText.ALIGN_CENTER)
				renderText(v681 + v676 * 0.5, v689 + 0.025 - 0.0075, 0.015, v687)
				setTextBold(false)
				if v684 == v685 then
					if v688.lineHeightByPart == nil then
						v688.lineHeightByPart = {}
						v686 = v689
					else
						v686 = v689
						for v695, _ in pairs(v688.lineHeightByPart) do
							v688.lineHeightByPart[v695] = nil
						end
					end
					for v696 = 1, #v688.parts do
						local v697 = v688.parts[v696].animationValues[1]
						local v698 = v697.node or v697.componentJoint
						if v698 ~= nil and v688.lineHeightByPart[v698] == nil then
							v686 = v686 - 0.0125
							drawOutlineRect(0.15, v686, 0.7, v682 + g_pixelSizeY, g_pixelSizeX, g_pixelSizeY, 0, 0, 0, 1)
							drawFilledRect(0.15, v686, 0.7, 0.0125, 0, 0, 0, 0.2)
							drawFilledRect(v681 + v676 - g_pixelSizeX, v686, g_pixelSizeX, 0.0125, 0, 0, 0, 1)
							local v699 = "unknown"
							if v697.node == nil then
								if v697.componentJoint ~= nil then
									v699 = string.format("compJoint \'%d\'", v697.componentJoint.index)
								end
							else
								v699 = string.format("node \'%s\'", getName(v697.node))
							end
							setTextAlignment(RenderText.ALIGN_CENTER)
							renderText(v681 + v676 * 0.5, v686 + 0.00625 - 0.005 + g_pixelSizeY * 2, 0.01, v699)
							v688.lineHeightByPart[v698] = v686
						end
					end
					if #v688.samples > 0 then
						v686 = v686 - 0.018750000000000003
						drawOutlineRect(0.15, v686, 0.7, 0.018750000000000003 + g_pixelSizeY, g_pixelSizeX, g_pixelSizeY, 0, 0, 0, 1)
						drawFilledRect(0.15, v686, 0.7, 0.018750000000000003, 0, 0, 0, 0.2)
						setTextAlignment(RenderText.ALIGN_CENTER)
						renderText(0.5, v686 + 0.009375000000000001 - 0.0075 + g_pixelSizeY * 2, 0.015, "Sounds:")
					end
					local v700 = {}
					for v701 = 1, #v688.samples do
						local v702 = v688.samples[v701]
						if v700[v702.filename] == nil then
							v700[v702.filename] = {}
						end
						local v703 = v700[v702.filename]
						local v704 = {
							["sample"] = v702,
							["startTime"] = v702.startTime,
							["endTime"] = v702.endTime,
							["loops"] = v702.loops,
							["direction"] = v702.direction
						}
						table.insert(v703, v704)
					end
					for _, v705 in pairs(v700) do
						v686 = v686 - 0.0125
						drawOutlineRect(0.15, v686, 0.7, v682 + g_pixelSizeY, g_pixelSizeX, g_pixelSizeY, 0, 0, 0, 1)
						drawFilledRect(0.15, v686, 0.7, 0.0125, 0, 0, 0, 0.2)
						drawFilledRect(v681 + v676 - g_pixelSizeX, v686, g_pixelSizeX, 0.0125, 0, 0, 0, 1)
						local v706 = "unknown"
						for v707 = 1, #v705 do
							local v708 = v705[v707]
							v706 = v708.sample.templateName or v708.sample.sampleName
							local v709 = 0
							local v710
							if g_soundManager:getIsSamplePlaying(v708.sample) then
								v710 = 1
								if v708.loops == 1 then
									v709 = 1
								end
							else
								v710 = 0
							end
							local v711 = v681 + v676
							local v712 = 0.85
							local v713 = 0
							local v714 = v686 + 0.0012500000000000002 + g_pixelSizeY
							local v715 = 0
							local v716 = 0.010000000000000002 - g_pixelSizeY
							if v708.startTime == nil or v708.endTime ~= nil then
								if v708.startTime == nil or (v708.endTime == nil or v708.loops ~= 0) then
									if v708.startTime ~= nil and (v708.endTime ~= nil and v708.loops == 1) then
										local v717 = v681 + v676 + v690 * v708.startTime - v690 * 25
										local v718 = math.max(v711, v717)
										local v719 = v690 * 50
										local v720 = v712 - (v718 + v719)
										local v721 = v719 + math.min(v720, 0)
										drawFilledRect(v718, v714, v721, v716, v709, v710, 0, 0.9)
										local v722 = v681 + v676 + v690 * v708.endTime - v690 * 25
										v713 = math.max(v711, v722)
										local v723 = v690 * 50
										local v724 = v712 - (v713 + v723)
										v715 = v723 + math.min(v724, 0)
									end
								else
									v713 = v681 + v676 + v690 * v708.startTime + v690 * 5
									v715 = v690 * (v708.endTime - v708.startTime) - v690 * 10
								end
							else
								local v725 = v681 + v676 + v690 * v708.startTime - v690 * 25
								v713 = math.max(v711, v725)
								local v726 = v690 * 50
								local v727 = v712 - (v713 + v726)
								v715 = v726 + math.min(v727, 0)
							end
							drawFilledRect(v713, v714, v715, v716, v709, v710, 0, 0.9)
						end
						setTextAlignment(RenderText.ALIGN_CENTER)
						renderText(v681 + v676 * 0.5, v686 + 0.00625 - 0.005 + g_pixelSizeY * 2, 0.01, v706)
					end
					for v728 = 1, #v688.parts do
						local v729 = v688.parts[v728]
						local v730 = v729.animationValues[1]
						local v731 = v730.node or v730.componentJoint
						if v731 ~= nil then
							drawFilledRect(v681 + v676 + v690 * v729.startTime, v688.lineHeightByPart[v731] + 0.0012500000000000002 + g_pixelSizeY, v690 * v729.duration, 0.010000000000000002 - g_pixelSizeY, 0, 0, 0, 0.9)
						end
					end
				else
					v686 = v689
				end
				drawFilledRect(v681 + v676 + v690 * v688.currentTime, v686, g_pixelSizeX, v689 - v686 + 0.034999999999999996, 0, 1, 0, 1)
				setTextAlignment(RenderText.ALIGN_CENTER)
				renderText(v681 + v676 + v690 * v688.currentTime, v686 + (v689 - v686) + 0.045000000000000005 - 0.005, 0.01, string.format("%.2f", v688.currentTime / 1000))
				v685 = v685 + 1
			end
		end
		setTextAlignment(RenderText.ALIGN_LEFT)
	end
end
function VehicleDebug.updateTuningDebugRendering(p732, _)
	if p732.propertyState == VehiclePropertyState.SHOP_CONFIG then
		local v733 = p732:getWheels()
		local v734 = 0
		for v735 = 1, #v733 do
			local v736 = v733[v735]
			local v737, v738, v739 = getWorldTranslation(v733[v735].driveNodeDirectionNode)
			local v740
			if v738 < 50 then
				v740 = v738 + 100
			else
				v740 = v738 - getTerrainHeightAtWorldPos(g_terrainNode, v737, 0, v739)
			end
			drawDebugLine(v737, v738 - v736.physics.radius, v739, 0, 1, 0, v737, v738, v739, 0, 1, 0, false)
			Utils.renderTextAtWorldPosition(v737, v738 - v736.physics.radius * 0.5, v739, string.format("%.3f", v740), getCorrectTextSize(0.012), 0, 0, 1, 0, 1)
			for _, v741 in ipairs(v736.visualWheels) do
				for _, v742 in ipairs(v741.visualParts) do
					if v742:isa(WheelVisualPartTire) then
						local v743, v744, v745 = localToLocal(v742.node, v736.node, 0, 0, 0)
						local v746, v747, v748 = localToWorld(v742.node, 0, 0, 0)
						local v749, v750, v751 = localToWorld(v736.node, 0, v744, v745)
						drawDebugLine(v746, v747, v748, 1, 0, 0, v749, v750, v751, 1, 0, 0, false)
						Utils.renderTextAtWorldPosition(v746, v747, v748, string.format("%.3f", math.abs(v743) * 2), getCorrectTextSize(0.012), 0, 1, 0, 0, 1)
						local v752 = v741.width * 0.5 * (v736.isLeft and 1 or -1)
						local v753, _, _ = localToLocal(v742.node, v736.node, v752, 0, 0)
						local v754, v755, v756 = localToWorld(v742.node, v752, 0, 0)
						drawDebugLine(v754, v755 - 0.1, v756, 0, 1, 1, v754, v755 + 0.1, v756, 0, 1, 1, false)
						Utils.renderTextAtWorldPosition(v754, v755, v756, string.format("%.3f", math.abs(v753) * 2), getCorrectTextSize(0.012), 0, 0, 1, 1, 1)
					end
				end
				renderText(0.25, 0.1 + 0.02 * v734, 0.018, string.format("%d - %s (%s)", v735, v741.externalXMLFilename, v741.externalConfigId))
				v734 = v734 + 1
			end
		end
	end
end
function VehicleDebug.consoleCommandAnalyze(_)
	if g_currentMission == nil or (g_localPlayer:getCurrentVehicle() == nil or not g_localPlayer:getCurrentVehicle().isServer) then
		return "Failed to analyze vehicle. Invalid controlled vehicle"
	end
	local v757 = g_localPlayer:getCurrentVehicle():getSelectedVehicle()
	if v757 == nil then
		v757 = g_localPlayer:getCurrentVehicle()
	end
	print("Analyzing vehicle \'" .. v757.configFileName .. "\'. Make sure vehicle is standing on a flat plane parallel to xz-plane")
	local v761 = {
		["raycastCallback"] = function(p758, p759, _, _, _, p760, _, _, _)
			if p758.vehicle.vehicleNodes[p759] ~= nil then
				return true
			end
			if p758.vehicle.aiTrafficCollisionTrigger == p759 then
				return true
			end
			if p759 ~= g_terrainNode then
				printWarning("Warning: Vehicle is not standing on ground! " .. getName(p759))
			end
			p758.groundDistance = p760
			return false
		end
	}
	if v757.spec_attacherJoints ~= nil then
		for v762, v763 in ipairs(v757.spec_attacherJoints.attacherJoints) do
			local v764, v765, v766 = getRotation(v763.jointTransform)
			local v767 = setRotation
			local v768 = v763.jointTransform
			local v769 = v763.jointOrigRot
			v767(v768, unpack(v769))
			if v763.rotationNode ~= nil or v763.rotationNode2 ~= nil then
				local v770, v771, v772
				if v763.rotationNode == nil then
					v770 = nil
					v771 = nil
					v772 = nil
				else
					v770, v771, v772 = getRotation(v763.rotationNode)
				end
				local v773, v774, v775
				if v763.rotationNode2 == nil then
					v773 = nil
					v774 = nil
					v775 = nil
				else
					v773, v774, v775 = getRotation(v763.rotationNode2)
				end
				if v763.rotationNode ~= nil then
					local v776 = setRotation
					local v777 = v763.rotationNode
					local v778 = v763.lowerRotation
					v776(v777, unpack(v778))
				end
				if v763.rotationNode2 ~= nil then
					local v779 = setRotation
					local v780 = v763.rotationNode2
					local v781 = v763.lowerRotation2
					v779(v780, unpack(v781))
				end
				local v782, v783, v784 = getWorldTranslation(v763.jointTransform)
				v761.groundDistance = 0
				v761.vehicle = v757
				raycastAll(v782, v783, v784, 0, -1, 0, 4, "raycastCallback", v761, 4294967295)
				local v785 = v761.groundDistance - v763.lowerDistanceToGround
				if math.abs(v785) > 0.01 then
					print(string.format(" Issue found: Attacher joint %d has invalid lowerDistanceToGround. True value is: %.3f (Value in xml: %.3f)", v762, MathUtil.round(v761.groundDistance, 3), v763.lowerDistanceToGround))
				end
				if v763.rotationNode ~= nil and v763.rotationNode2 ~= nil then
					local _, v786, _ = localDirectionToWorld(v763.jointTransform, 0, 1, 0)
					local v787 = math.clamp(v786, -1, 1)
					local v788 = math.acos(v787)
					local v789 = math.deg(v788)
					local _, v790, _ = localDirectionToWorld(v763.jointTransform, 1, 0, 0)
					if v790 < 0 then
						v789 = -v789
					end
					local v791 = v763.lowerRotationOffset
					local v792 = v789 - math.deg(v791)
					if math.abs(v792) > 0.1 then
						local v793 = print
						local v794 = string.format
						local v795 = v763.lowerRotationOffset
						v793(v794(" Issue found: Attacher joint %d has invalid lowerRotationOffset. True value is: %.2f\194\176 (Value in xml: %.2f\194\176)", v762, v789, (math.deg(v795))))
					end
				end
				if v763.rotationNode ~= nil then
					local v796 = setRotation
					local v797 = v763.rotationNode
					local v798 = v763.upperRotation
					v796(v797, unpack(v798))
				end
				if v763.rotationNode2 ~= nil then
					local v799 = setRotation
					local v800 = v763.rotationNode2
					local v801 = v763.upperRotation2
					v799(v800, unpack(v801))
				end
				local v802, v803, v804 = getWorldTranslation(v763.jointTransform)
				v761.groundDistance = 0
				raycastAll(v802, v803, v804, 0, -1, 0, 4, "raycastCallback", v761, 4294967295)
				local v805 = v761.groundDistance - v763.upperDistanceToGround
				if math.abs(v805) > 0.01 then
					print(string.format(" Issue found: Attacher joint %d has invalid upperDistanceToGround. True value is: %.3f (Value in xml: %.3f)", v762, MathUtil.round(v761.groundDistance, 3), v763.upperDistanceToGround))
				end
				if v763.rotationNode ~= nil and v763.rotationNode2 ~= nil then
					local _, v806, _ = localDirectionToWorld(v763.jointTransform, 0, 1, 0)
					local v807 = math.clamp(v806, -1, 1)
					local v808 = math.acos(v807)
					local v809 = math.deg(v808)
					local _, v810, _ = localDirectionToWorld(v763.jointTransform, 1, 0, 0)
					if v810 < 0 then
						v809 = -v809
					end
					local v811 = v763.upperRotationOffset
					local v812 = v809 - math.deg(v811)
					if math.abs(v812) > 0.1 then
						local v813 = print
						local v814 = string.format
						local v815 = v763.upperRotationOffset
						v813(v814(" Issue found: Attacher joint %d has invalid upperRotationOffset. True value is: %.2f\194\176 (Value in xml: %.2f\194\176)", v762, v809, (math.deg(v815))))
					end
				end
				if v763.rotationNode ~= nil then
					setRotation(v763.rotationNode, v770, v771, v772)
				end
				if v763.rotationNode2 ~= nil then
					setRotation(v763.rotationNode2, v773, v774, v775)
				end
			end
			setRotation(v763.jointTransform, v764, v765, v766)
			if v763.transNode ~= nil then
				local v816, v817, v818 = getTranslation(v763.transNode)
				local _, v819, _ = localToLocal(v757.rootNode, getParent(v763.transNode), 0, v763.transNodeMinY, 0)
				setTranslation(v763.transNode, v816, v819, v818)
				v761.groundDistance = 0
				v761.vehicle = v757
				local v820, v821, v822 = getWorldTranslation(v763.transNode)
				raycastAll(v820, v821, v822, 0, -1, 0, 4, "raycastCallback", v761, 4294967295)
				local v823 = v761.groundDistance - v763.lowerDistanceToGround
				if math.abs(v823) > 0.02 then
					print(string.format(" Issue found: Attacher joint %d has invalid lowerDistanceToGround. True value is: %.3f (Value in xml: %.3f)", v762, MathUtil.round(v761.groundDistance, 3), v763.lowerDistanceToGround))
				end
				local _, v824, _ = localToLocal(v757.rootNode, getParent(v763.transNode), 0, v763.transNodeMaxY, 0)
				setTranslation(v763.transNode, v816, v824, v818)
				v761.groundDistance = 0
				local v825, v826, v827 = getWorldTranslation(v763.transNode)
				raycastAll(v825, v826, v827, 0, -1, 0, 4, "raycastCallback", v761, 4294967295)
				local v828 = v761.groundDistance - v763.upperDistanceToGround
				if math.abs(v828) > 0.02 then
					print(string.format(" Issue found: Attacher joint %d has invalid upperDistanceToGround. True value is: %.3f (Value in xml: %.3f)", v762, MathUtil.round(v761.groundDistance, 3), v763.upperDistanceToGround))
				end
				setTranslation(v763.transNode, v816, v817, v818)
			end
		end
	end
	if v757.spec_wheels ~= nil then
		for v829, v830 in ipairs(v757.spec_wheels.wheels) do
			if v830.physics.wheelShapeCreated then
				local _, v831, _ = getCenterOfMass(v830.node)
				local v832 = v830.physics.positionY + v830.physics.deltaY - v830.physics.radius * v830.physics.forcePointRatio
				if v831 < v832 then
					print(string.format(" Issue found: Wheel %d has force point higher than center of mass. %.2f > %.2f. This can lead to undesired driving behavior (inward-leaning).", v829, v832, v831))
				end
				local v833 = getWheelShapeContactForce(v830.node, v830.physics.wheelShape)
				if v833 ~= nil then
					local v834, v835, v836 = getWheelShapeContactNormal(v830.node, v830.physics.wheelShape)
					local v837, v838, v839 = localDirectionToWorld(v830.node, 0, -1, 0)
					local v840 = -v833 * MathUtil.dotProduct(v837, v838, v839, v834, v835, v836)
					local v841 = v835 * 9.81
					local v842 = (v840 + math.max(v841, 0) * v830:getMass()) / 9.81
					local v843 = v842 - v830.physics.restLoad
					if math.abs(v843) > 0.2 then
						print(string.format(" Issue found: Wheel %d has wrong restLoad. %.2f vs. %.2f in XML. Verify that this leads to the desired behavior.", v829, v842, v830.physics.restLoad))
					end
				end
			end
		end
	end
	return "Analyzed vehicle"
end
function VehicleDebug.moveUpperRotation(_, _, p844, _, _)
	if VehicleDebug.currentAttacherJointVehicle ~= nil and p844 ~= 0 then
		local v845 = VehicleDebug.currentAttacherJointVehicle
		if v845.getAttacherVehicle ~= nil then
			local v846 = v845:getAttacherVehicle()
			if v846 ~= nil then
				local v847 = v846:getImplementByObject(v845)
				if v847 ~= nil then
					local v848 = v847.jointDescIndex
					local v849 = v846.spec_attacherJoints.attacherJoints[v848]
					if v849.rotationNode ~= nil then
						local v850 = v849.upperRotation
						local v851 = v849.upperRotation[1]
						local v852 = p844 * 0.002 * 16
						v850[1] = v851 + math.rad(v852)
						v849.moveAlpha = v849.moveAlpha - 0.001
						local v853 = print
						local v854 = v849.upperRotation[1]
						v853("upperRotation: " .. math.deg(v854))
					end
				end
			end
		end
	end
end
function VehicleDebug.moveLowerRotation(_, _, p855, _, _)
	if VehicleDebug.currentAttacherJointVehicle ~= nil and p855 ~= 0 then
		local v856 = VehicleDebug.currentAttacherJointVehicle
		if v856.getAttacherVehicle ~= nil then
			local v857 = v856:getAttacherVehicle()
			if v857 ~= nil then
				local v858 = v857:getImplementByObject(v856)
				if v858 ~= nil then
					local v859 = v858.jointDescIndex
					local v860 = v857.spec_attacherJoints.attacherJoints[v859]
					if v860.rotationNode ~= nil then
						local v861 = v860.lowerRotation
						local v862 = v860.lowerRotation[1]
						local v863 = p855 * 0.002 * 16
						v861[1] = v862 + math.rad(v863)
						v860.moveAlpha = v860.moveAlpha - 0.001
						local v864 = print
						local v865 = v860.lowerRotation[1]
						v864("lowerRotation: " .. math.deg(v865))
					end
				end
			end
		end
	end
end
function VehicleDebug.consoleCommandExportScenegraph(_, p_u_866, p867, p_u_868)
	local function v_u_905(p_u_869)
		-- upvalues: (copy) p_u_868
		local v870 = getTimeSec()
		local v871 = p_u_868 or ""
		local v872 = string.format(getUserProfileAppPath() .. "scenegraph_%s%s.xml", p_u_869.configFileNameClean, (tostring(v871)))
		local v_u_873 = XMLFile.create("scenegraph", v872, "scenegraph", nil)
		local function v_u_899(p874, p875, p876, p877, p878)
			-- upvalues: (copy) v_u_873, (copy) p_u_869, (copy) v_u_899
			local v879 = p876 .. string.format("(%d)", p877)
			v_u_873:setString(v879 .. "#name", getName(p874))
			v_u_873:setString(v879 .. "#indexPath", p875)
			local v880, v881, v882 = getTranslation(p874)
			v_u_873:setString(v879 .. "#translation", v880 .. " " .. v881 .. " " .. v882)
			local v883, v884, v885 = getRotation(p874)
			v_u_873:setString(v879 .. "#rotation", math.deg(v883) .. " " .. math.deg(v884) .. " " .. math.deg(v885))
			if p878 ~= nil then
				v_u_873:setFloat(v879 .. "#mass", p_u_869:getComponentMass(p878))
			end
			local v886 = getNumOfChildren(p874)
			if v886 > 0 then
				local v887 = 0
				local v888 = 0
				local v889 = 0
				local v890 = 0
				for v891 = 1, v886 do
					local v892 = getChildAt(p874, v891 - 1)
					local v893
					if p875 == nil then
						v893 = "" .. v891 - 1
					else
						v893 = p875 .. "|" .. v891 - 1
					end
					local _ = v891 - 1
					local v894 = ".Node"
					local v895
					if getHasClassId(v892, ClassIds.SHAPE) then
						v895 = v888 + 1
						v894 = ".Shape"
					elseif getHasClassId(v892, ClassIds.LIGHT_SOURCE) then
						local v896 = v889 + 1
						v895 = v888
						v888 = v889
						v889 = v896
						v894 = ".Light"
					elseif getHasClassId(v892, ClassIds.TRANSFORM_GROUP) then
						local v897 = v890 + 1
						v895 = v888
						v888 = v890
						v890 = v897
						v894 = ".TransformGroup"
					else
						local v898 = v887 + 1
						v895 = v888
						v888 = v887
						v887 = v898
					end
					v_u_899(v892, v893, v879 .. v894, v888, nil)
					v888 = v895
				end
			end
		end
		for v900, v901 in ipairs(p_u_869.components) do
			local v902 = v901.node
			local v903 = v900 - 1
			v_u_899(v902, tostring(v903) .. ">", "scenegraph.Shape", v900 - 1, v901)
		end
		v_u_873:save()
		v_u_873:delete()
		local v904 = getTimeSec()
		Logging.info("Exported \'%s\' in %.1fms", v872, (v904 - v870) * 1000)
	end
	if p_u_866 == nil or p867 == nil then
		if g_currentMission ~= nil and g_localPlayer ~= nil then
			local v906 = g_localPlayer:getCurrentVehicle()
			if v906 == nil then
				Logging.error("Please enter vehicle first!")
			else
				for v907 = 1, #v906.childVehicles do
					v_u_905(v906.childVehicles[v907])
				end
			end
		end
	else
		local v_u_908 = tonumber(p867)
		if VehicleDebug.defaultUpdateAnimationFunc == nil then
			VehicleDebug.defaultUpdateAnimationFunc = AnimatedVehicle.updateAnimation
		end
		function AnimatedVehicle.updateAnimation(p909, p910, p911, p912, p913, p914, ...)
			-- upvalues: (copy) p_u_866, (ref) v_u_908, (copy) v_u_905
			VehicleDebug.defaultUpdateAnimationFunc(p909, p910, p911, p912, p913, p914, ...)
			if p910.name == p_u_866 and (p910.currentSpeed > 0 and v_u_908 < p910.currentTime or p910.currentSpeed < 0 and p910.currentTime < v_u_908) then
				v_u_905(p909)
				AnimatedVehicle.updateAnimation = VehicleDebug.defaultUpdateAnimationFunc
				VehicleDebug.defaultUpdateAnimationFunc = nil
			end
		end
	end
end
function VehicleDebug.drawDebugAttacherJoints(p915)
	VehicleDebug.currentAttacherJointVehicle = p915
end
function VehicleDebug.consoleCommandMergeGroupDebug()
	local function v_u_921(p916)
		-- upvalues: (copy) v_u_921
		if getHasClassId(p916, ClassIds.SHAPE) then
			local _, v917 = getShapeIsSkinned(p916)
			if v917 then
				if getHasShaderParameter(p916, "colorScale") then
					local v918 = VehicleMaterial.new()
					v918:setTemplateName("plasticPainted")
					v918:setColor(0, math.random(), math.random())
					v918:apply(p916)
				end
			elseif getHasShaderParameter(p916, "colorScale") then
				local v919 = VehicleMaterial.new()
				v919:setTemplateName("plasticPainted")
				v919:setColor(1, 0, 0)
				v919:apply(p916)
			end
		end
		for v920 = 0, getNumOfChildren(p916) - 1 do
			v_u_921(getChildAt(p916, v920))
		end
	end
	if g_gui.currentGuiName == "ShopConfigScreen" then
		for _, v922 in pairs(g_shopConfigScreen.previewVehicles) do
			for _, v923 in ipairs(v922.components) do
				v_u_921(v923.node)
			end
		end
	end
	if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
		local v924 = g_localPlayer:getCurrentVehicle()
		for v925 = 1, #v924.childVehicles do
			for _, v926 in ipairs(v924.childVehicles[v925].components) do
				v_u_921(v926.node)
			end
		end
	end
end
function VehicleDebug.consoleCommandCastShadow()
	local function v_u_931(p927)
		-- upvalues: (copy) v_u_931
		if getHasClassId(p927, ClassIds.SHAPE) then
			local v928 = getMaterial(p927, 0)
			if v928 ~= 0 and string.contains(getMaterialCustomShaderFilename(v928), "vehicleShader.xml") then
				local v929 = VehicleMaterial.new()
				v929:setTemplateName("plasticPainted")
				v929:setColor(0, 0, 0)
				if getShapeCastShadowmap(p927) then
					v929:setColor(1, 1, 1)
				end
				v929.diffuseMap = "data/shared/white_diffuse.dds"
				v929:apply(p927)
			end
		end
		for v930 = 0, getNumOfChildren(p927) - 1 do
			v_u_931(getChildAt(p927, v930))
		end
	end
	if g_gui.currentGuiName == "ShopConfigScreen" then
		for _, v932 in pairs(g_shopConfigScreen.previewVehicles) do
			for _, v933 in ipairs(v932.components) do
				v_u_931(v933.node)
			end
		end
	end
	if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
		local v934 = g_localPlayer:getCurrentVehicle()
		for v935 = 1, #v934.childVehicles do
			for _, v936 in ipairs(v934.childVehicles[v935].components) do
				v_u_931(v936.node)
			end
		end
	end
end
function VehicleDebug.consoleCommandDecalLayer()
	local function v_u_941(p937)
		-- upvalues: (copy) v_u_941
		if getHasClassId(p937, ClassIds.SHAPE) then
			local v938 = getShapeDecalLayer(p937)
			local v939 = VehicleMaterial.new()
			v939:setTemplateName("plasticPainted")
			v939:setColor(1, 1, 1)
			if v938 == 1 then
				v939:setColor(1, 0, 0)
			elseif v938 == 2 then
				v939:setColor(0, 1, 0)
			elseif v938 > 2 then
				v939:setColor(0, 0, 1)
			end
			v939.diffuseMap = "data/shared/white_diffuse.dds"
			v939:apply(p937)
		end
		for v940 = 0, getNumOfChildren(p937) - 1 do
			v_u_941(getChildAt(p937, v940))
		end
	end
	if g_gui.currentGuiName == "ShopConfigScreen" then
		for _, v942 in pairs(g_shopConfigScreen.previewVehicles) do
			for _, v943 in ipairs(v942.components) do
				v_u_941(v943.node)
			end
		end
	end
	if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
		local v944 = g_localPlayer:getCurrentVehicle()
		for v945 = 1, #v944.childVehicles do
			for _, v946 in ipairs(v944.childVehicles[v945].components) do
				v_u_941(v946.node)
			end
		end
	end
end
function VehicleDebug.consoleCommandDebugMaterial(_, p947)
	if g_vehicleMaterialManager:getMaterialTemplateByName(p947) == nil then
		Logging.error("Material template \'%s\' not found", p947)
	else
		local v_u_948 = VehicleMaterial.new()
		v_u_948:setTemplateName(p947)
		local function v_u_954(p949)
			-- upvalues: (copy) v_u_948, (copy) v_u_954
			if getHasClassId(p949, ClassIds.SHAPE) then
				for v950 = 1, getNumOfMaterials(p949) do
					if v_u_948:getIsApplied(p949, getMaterial(p949, v950 - 1), false) then
						local v951 = VehicleMaterial.new()
						v951:setTemplateName("plasticPainted")
						v951:setColor(0, 1, 0)
						v951:applyToMaterial(p949, v950 - 1)
					else
						local v952 = VehicleMaterial.new()
						v952:setTemplateName("plasticPainted")
						v952:setColor(1, 0, 0)
						v952:applyToMaterial(p949, v950 - 1)
					end
				end
			end
			for v953 = 0, getNumOfChildren(p949) - 1 do
				v_u_954(getChildAt(p949, v953))
			end
		end
		if g_gui.currentGuiName == "ShopConfigScreen" then
			for _, v955 in pairs(g_shopConfigScreen.previewVehicles) do
				for _, v956 in ipairs(v955.components) do
					v_u_954(v956.node)
				end
			end
		end
		if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
			local v957 = g_localPlayer:getCurrentVehicle()
			for v958 = 1, #v957.childVehicles do
				for _, v959 in ipairs(v957.childVehicles[v958].components) do
					v_u_954(v959.node)
				end
			end
		end
	end
end
function VehicleDebug.consoleCommandAttacherJointConnections(_, p960)
	local v961 = tonumber(p960) or 1
	if VehicleDebug.DEBUG_ATTACHER_JOINT_INDEX == v961 then
		Logging.info("Disconnect to attacher joint \'%s\'", v961)
		VehicleDebug.DEBUG_ATTACHER_JOINT_INDEX = nil
		v961 = nil
	else
		Logging.info("Connect to attacher joint \'%s\'", v961)
		VehicleDebug.DEBUG_ATTACHER_JOINT_INDEX = v961
	end
	if g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
		local v962 = g_localPlayer:getCurrentVehicle()
		for v963 = 1, #v962.childVehicles do
			local v964 = v962.childVehicles[v963]
			if v964.getAttacherJoints ~= nil then
				local v965 = ""
				for v966, v967 in ipairs(v964:getAttacherJoints()) do
					v965 = v965 .. string.format("%d-%s  ", v966, getName(v967.jointTransform))
				end
				if v965 ~= "" then
					Logging.info(v964:getFullName() .. ": " .. v965)
				end
			end
			if v964.jointIndexDebugText ~= nil then
				g_debugManager:removeElement(v964.jointIndexDebugText)
				v964.jointIndexDebugText = nil
			end
			local v968 = v964:getAttacherJointByJointDescIndex(v961)
			if v968 ~= nil then
				v964.jointIndexDebugText = DebugText.new():createWithNode(v968.jointTransform, "j" .. tostring(v961), 0.02, true)
				g_debugManager:addElement(v964.jointIndexDebugText, nil, nil, (1 / 0))
			end
			ConnectionHoses.consoleCommandTestSockets(v964, v961)
			PowerTakeOffs.consoleCommandTestConnection(v964, v961)
		end
	end
end
function VehicleDebug.consoleCommandWheelDisplacement()
	if WheelPhysics.COLLISION_MASK == CollisionMask.ALL then
		WheelPhysics.COLLISION_MASK = CollisionMask.ALL - CollisionFlag.TERRAIN_DISPLACEMENT
		Logging.info("Disabled wheel interaction with displacement collision")
	else
		WheelPhysics.COLLISION_MASK = CollisionMask.ALL
		Logging.info("Enabled wheel interaction with displacement collision")
	end
	for _, v969 in pairs(g_currentMission.vehicleSystem.vehicles) do
		if v969.getWheels ~= nil then
			for _, v970 in ipairs(v969:getWheels()) do
				v970.physics:updateBase()
			end
		end
	end
end
VehicleDebug.cylinderedUpdateDebugState = false
function VehicleDebug.consoleCommandCylinderedUpdate()
	VehicleDebug.cylinderedUpdateDebugState = not VehicleDebug.cylinderedUpdateDebugState
	local v971 = print
	local v972 = VehicleDebug.cylinderedUpdateDebugState
	v971("Cylindered Update Debug: " .. tostring(v972))
end
VehicleDebug.wetnessDebugState = false
function VehicleDebug.consoleCommandWetnessDebug()
	VehicleDebug.wetnessDebugState = not VehicleDebug.wetnessDebugState
	local v973 = print
	local v974 = VehicleDebug.wetnessDebugState
	v973("Wetness Debug: " .. tostring(v974))
	local function v_u_987(p975)
		local v976 = g_debugManager:getDebugMat()
		local v977 = setMaterialCustomShaderVariation(v976, "wetnessDebug", false)
		local v_u_978 = setMaterialDiffuseMapFromFile(v977, "data/shared/default_diffuse.dds", true, true, false)
		local function v_u_985(p979, p980)
			-- upvalues: (ref) v_u_978, (copy) v_u_985
			if p979.spec_washable.wetnessIgnoreNodes[p980] ~= true then
				if getHasClassId(p980, ClassIds.SHAPE) then
					for v981 = 1, getNumOfMaterials(p980) do
						local v982 = getMaterial(p980, v981 - 1)
						local v983 = getMaterialCustomShaderFilename(v982)
						if string.contains(v983, "vehicleShader.xml") then
							setMaterial(p980, v_u_978, v981 - 1)
							setShaderParameter(p980, "alpha", 1, 0, 0, 0, false, v981 - 1)
						end
					end
				end
				for v984 = 0, getNumOfChildren(p980) - 1 do
					v_u_985(p979, getChildAt(p980, v984))
				end
			end
		end
		for _, v986 in ipairs(p975.components) do
			v_u_985(p975, v986.node)
		end
	end
	if VehicleDebug.wetnessDebugState then
		if g_gui.currentGuiName == "ShopConfigScreen" then
			for _, v988 in pairs(g_shopConfigScreen.previewVehicles) do
				v_u_987(v988)
			end
		elseif g_currentMission ~= nil and g_localPlayer:getCurrentVehicle() ~= nil then
			local v989 = g_localPlayer:getCurrentVehicle()
			for v990 = 1, #v989.childVehicles do
				v_u_987(v989.childVehicles[v990])
			end
		end
		VehicleDebug.vehicleOnFinishedLoading = Vehicle.onFinishedLoading
		function Vehicle.onFinishedLoading(p991, ...)
			-- upvalues: (copy) v_u_987
			v_u_987(p991)
			VehicleDebug.vehicleOnFinishedLoading(p991, ...)
		end
	else
		if VehicleDebug.vehicleOnFinishedLoading ~= nil then
			Vehicle.onFinishedLoading = VehicleDebug.vehicleOnFinishedLoading
			VehicleDebug.vehicleOnFinishedLoading = nil
		end
		executeConsoleCommand("gsVehicleReload")
	end
end
VehicleDebug.wheelEffectDebugState = false
function VehicleDebug.consoleCommandWheelEffectsDebug()
	VehicleDebug.wheelEffectDebugState = not VehicleDebug.wheelEffectDebugState
	print("Wheel Effects Debug: " .. (VehicleDebug.wheelEffectDebugState and "Enabled" or "Disabled"))
end
addConsoleCommand("gsVehicleAnalyze", "Analyze vehicle", "VehicleDebug.consoleCommandAnalyze", nil)
addConsoleCommand("gsVehicleDebug", "Toggles the vehicle debug values rendering", "VehicleDebug.consoleCommandVehicleDebug", nil)
addConsoleCommand("gsVehicleExportScenegraph", "Exports the vehicle scenegraph to a xml file", "VehicleDebug.consoleCommandExportScenegraph", nil)
addConsoleCommand("gsVehicleDebugMergeGroups", "Visualizes all merge groups", "VehicleDebug.consoleCommandMergeGroupDebug", nil)
addConsoleCommand("gsVehicleDebugCastShadow", "Visualizes all shapes that cast shadows", "VehicleDebug.consoleCommandCastShadow", nil)
addConsoleCommand("gsVehicleDebugDecalLayer", "Visualizes all shapes with decal layer", "VehicleDebug.consoleCommandDecalLayer", nil)
addConsoleCommand("gsVehicleDebugMaterial", "Visualizes all shapes that got the given material template assigned", "VehicleDebug.consoleCommandDebugMaterial", nil, "materialTemplateName")
addConsoleCommand("gsVehicleDebugAttacherJointConnections", "Visualization of the connection hoses and power take offs per attacher joint", "VehicleDebug.consoleCommandAttacherJointConnections", nil, "jointIndex")
addConsoleCommand("gsVehicleDebugToggleWheelDisplacement", "Toggles the interaction of the wheels with the displacement", "VehicleDebug.consoleCommandWheelDisplacement", nil)
addConsoleCommand("gsVehicleDebugCylinderedUpdateDebug", "Shows the name of each movingPart or movingTool that is updated", "VehicleDebug.consoleCommandCylinderedUpdate", nil)
addConsoleCommand("gsVehicleDebugWetness", "Visualizes the wetness masking of the vehicle", "VehicleDebug.consoleCommandWetnessDebug", nil)
addConsoleCommand("gsVehicleDebugWheelEffects", "Enabled the wheel effects all the time", "VehicleDebug.consoleCommandWheelEffectsDebug", nil)
if StartParams.getIsSet("vehicleDebugMode") then
	VehicleDebug.consoleCommandVehicleDebug(nil, StartParams.getValue("vehicleDebugMode"))
end

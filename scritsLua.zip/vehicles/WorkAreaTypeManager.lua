WorkAreaTypeManager = {}
WorkAreaType = nil
local v_u_1 = Class(WorkAreaTypeManager, AbstractManager)
function WorkAreaTypeManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function WorkAreaTypeManager.initDataStructures(p3)
	p3.workAreaTypes = {}
	p3.workAreaTypeNameToInt = {}
	p3.workAreaTypeNameToDesc = {}
	WorkAreaType = p3.workAreaTypeNameToInt
end
function WorkAreaTypeManager.addWorkAreaType(p4, p5, p6, p7, p8)
	if p5 == nil then
		Logging.error("WorkArea name missing!")
		return
	elseif p4.workAreaTypeNameToInt[p5] == nil then
		local v9 = p5:upper()
		local v10 = {
			["name"] = v9,
			["index"] = #p4.workAreaTypes + 1,
			["attractWildlife"] = Utils.getNoNil(p6, false),
			["isAIArea"] = Utils.getNoNil(p7, false),
			["isSteeringAssistArea"] = Utils.getNoNil(p8, false)
		}
		p4.workAreaTypeNameToInt[v9] = v10.index
		p4.workAreaTypeNameToDesc[v9] = v10
		local v11 = p4.workAreaTypes
		table.insert(v11, v10)
		print("  Register workAreaType \'" .. v9 .. "\'")
	else
		Logging.error("WorkArea name \'%s\' is already in use!", p5)
	end
end
function WorkAreaTypeManager.getWorkAreaTypeNameByIndex(p12, p13)
	local v14 = p12.workAreaTypes[p13]
	if v14 then
		return v14.name
	else
		return nil
	end
end
function WorkAreaTypeManager.getWorkAreaTypeIndexByName(p15, p16)
	if p16 == nil then
		return nil
	else
		return p15.workAreaTypeNameToInt[p16:upper()]
	end
end
function WorkAreaTypeManager.getConfigurationDescByName(p17, p18)
	if p18 == nil then
		return nil
	else
		return p17.workAreaTypeNameToDesc[p18:upper()]
	end
end
function WorkAreaTypeManager.getWorkAreaTypeByIndex(p19, p20)
	return p19.workAreaTypes[p20]
end
function WorkAreaTypeManager.getWorkAreaTypeIsAIArea(p21, p22)
	if p21.workAreaTypes[p22] == nil then
		return false
	else
		return p21.workAreaTypes[p22].isAIArea
	end
end
function WorkAreaTypeManager.getWorkAreaTypeIsSteeringAssistArea(p23, p24)
	if p23.workAreaTypes[p24] == nil then
		return false
	else
		return p23.workAreaTypes[p24].isSteeringAssistArea
	end
end
g_workAreaTypeManager = WorkAreaTypeManager.new()

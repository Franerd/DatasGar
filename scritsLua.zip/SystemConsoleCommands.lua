SystemConsoleCommands = {}
function SystemConsoleCommands.init()
	addConsoleCommand("gsGuiDrawHelper", "", "drawGuiHelper", SystemConsoleCommands, "[lineSpacing [0..1]]")
	addConsoleCommand("gsI3DCacheClean", "Removes all cached i3d files to ensure the latest versions are loaded from disk", "cleanI3DCache", SystemConsoleCommands)
	addConsoleCommand("gsSetHighQuality", "Increase draw and LOD distances of foliage, terrain and objects", "setHighQuality", SystemConsoleCommands, "coeff;[foliageCoeff: default=coeff*0.5]")
	addConsoleCommand("gsGuiSafeFrameShow", "", "showSafeFrame", SystemConsoleCommands)
	addConsoleCommand("gsGuiDebug", "", "toggleUiDebug", SystemConsoleCommands)
	addConsoleCommand("gsGuiFocusDebug", "", "toggleUiFocusDebug", SystemConsoleCommands)
	addConsoleCommand("gsRenderColorAndDepthScreenShot", "", "renderColorAndDepthScreenShot", SystemConsoleCommands)
	addConsoleCommand("gsCustomEnvMapList", "", "listCustomEnvMaps", SystemConsoleCommands)
	addConsoleCommand("gsCustomEnvMapSet", "", "setCustomEnvMap", SystemConsoleCommands, "index")
	if g_addCheatCommands then
		addConsoleCommand("gsRenderingDebugMode", "", "setDebugRenderingMode", SystemConsoleCommands)
		addConsoleCommand("gsInputDrawRaw", "", "drawRawInput", SystemConsoleCommands)
		addConsoleCommand("gsTextureStreamingSetBudget", "", "setTextureStreamingBudget", SystemConsoleCommands)
	end
	if g_addTestCommands then
		addConsoleCommand("gsLanguageSet", "Set active language", "changeLanguage", SystemConsoleCommands)
		addConsoleCommand("gsGuiReloadCurrent", "", "reloadCurrentGui", SystemConsoleCommands)
		addConsoleCommand("gsGuiReloadCurrentDialog", "", "reloadCurrentDialog", SystemConsoleCommands)
		addConsoleCommand("gsHudResetHelpSystem", "", "resetHelpSystem", SystemConsoleCommands)
		addConsoleCommand("gsHudResetHelpSystemWithDraw", "", "resetHelpSystemWithDraw", SystemConsoleCommands)
		if not (GS_IS_CONSOLE_VERSION or GS_IS_MOBILE_VERSION) then
			addConsoleCommand("gsSuspendApp", "", "suspendApp", SystemConsoleCommands)
		end
		addConsoleCommand("gsInputFuzz", "", "fuzzInput", SystemConsoleCommands)
		addConsoleCommand("gsUpdateDownloadFinished", "", "updateDownloadFinished", SystemConsoleCommands)
		addConsoleCommand("gsRenderingFidelityFxSRSet", "", "setFidelityFxSR", SystemConsoleCommands)
		addConsoleCommand("gsSoftRestart", "", "softRestart", SystemConsoleCommands, nil, true)
	end
end
function SystemConsoleCommands.delete()
	removeConsoleCommand("gsGuiDrawHelper")
	removeConsoleCommand("gsI3DCacheClean")
	removeConsoleCommand("gsSetHighQuality")
	removeConsoleCommand("gsGuiSafeFrameShow")
	removeConsoleCommand("gsGuiDebug")
	removeConsoleCommand("gsGuiFocusDebug")
	removeConsoleCommand("gsRenderColorAndDepthScreenShot")
	removeConsoleCommand("gsCustomEnvMapList")
	removeConsoleCommand("gsCustomEnvMapSet")
	removeConsoleCommand("gsRenderingDebugMode")
	removeConsoleCommand("gsInputDrawRaw")
	removeConsoleCommand("gsTextureStreamingSetBudget")
	removeConsoleCommand("gsLanguageSet")
	removeConsoleCommand("gsGuiReloadCurrent")
	removeConsoleCommand("gsGuiReloadCurrentDialog")
	removeConsoleCommand("gsSuspendApp")
	removeConsoleCommand("gsInputFuzz")
	removeConsoleCommand("gsUpdateDownloadFinished")
	removeConsoleCommand("gsRenderingFidelityFxSRSet")
	removeConsoleCommand("gsSoftRestart")
end
function SystemConsoleCommands.drawGuiHelper(_, p1)
	local v2 = tonumber(p1)
	if v2 == nil then
		g_guiHelperSteps = 0.1
		g_drawGuiHelper = false
	else
		g_guiHelperSteps = math.max(v2, 0.001)
		g_drawGuiHelper = true
	end
	return not g_drawGuiHelper and "DrawGuiHelper = false" or "DrawGuiHelper = true (step = " .. g_guiHelperSteps .. ")"
end
function SystemConsoleCommands.showSafeFrame(_)
	g_showSafeFrame = not g_showSafeFrame
	return string.format("showSafeFrame = %s", g_showSafeFrame)
end
function SystemConsoleCommands.drawRawInput(_)
	g_showRawInput = not g_showRawInput
	return string.format("showRawInput = %s", g_showRawInput)
end
function SystemConsoleCommands.setTextureStreamingBudget(_, p3)
	local v4 = tonumber(p3)
	if v4 == nil then
		setTextureStreamingMemoryBudget(0)
		return "Reset Texture Streaming Memory Budget to default"
	else
		setTextureStreamingMemoryBudget(v4)
		return "Set Texture Streaming Memory Budget to " .. v4 .. " MB"
	end
end
function SystemConsoleCommands.cleanI3DCache(_, p5)
	local v6 = Utils.stringToBoolean(p5)
	g_i3DManager:clearEntireSharedI3DFileCache(v6)
	local v7 = "I3D cache cleaned."
	if not v6 then
		v7 = v7 .. " Use \'true\' parameter for verbose output"
	end
	return v7
end
function SystemConsoleCommands.setHighQuality(_, p8, p9)
	local v10 = string.format("Usage \'gsSetHighQuality <factor (default=%d)>\'", 5)
	local v11 = tonumber(p8) or 5
	local v12 = math.clamp(v11, 1e-6, 10)
	local v13 = tonumber(p9) or v12 * 0.5
	setViewDistanceCoeff(v12)
	setLODDistanceCoeff(v12)
	setTerrainLODDistanceCoeff((math.clamp(v12, 0, 2.5)))
	setFoliageViewDistanceCoeff((math.max(1, v13)))
	return string.format("High quality activated, used factor=%f\n%s", MathUtil.round(v12, 8), p8 == nil and (" " .. v10 or "") or "")
end
function SystemConsoleCommands.renderColorAndDepthScreenShot(_, p14, p15)
	local v16, v17
	if p14 == nil or p15 == nil then
		local v18 = getScreenMode()
		v16, v17 = getScreenModeInfo(v18)
	else
		v16 = tonumber(p14)
		v17 = tonumber(p15)
	end
	setDebugRenderingMode(DebugRendering.NONE)
	local v19 = getDate("%Y_%m_%d_%H_%M_%S") .. ".hdr"
	local v20 = g_screenshotsDirectory .. "fsScreen_color_" .. v19
	print("Saving color screenshot: " .. v20)
	renderScreenshot(v20, v16, v17, v16 / v17, "raw_hdr", 1, 0, 0, 0, 0, 0, 15, false)
	setDebugRenderingMode(DebugRendering.DEPTH)
	local v21 = g_screenshotsDirectory .. "fsScreen_depth_" .. v19
	print("Saving depth screenshot: " .. v21)
	renderScreenshot(v21, v16, v17, v16 / v17, "raw_hdr", 1, 0, 0, 0, 0, 0, 15, false)
	setDebugRenderingMode(DebugRendering.NONE)
end
local v_u_22 = {
	["AO"] = DebugRendering.AMBIENT_OCCLUSION,
	["BAKEDAO"] = DebugRendering.BAKED_AMBIENT_OCCLUSION,
	["SSAO"] = DebugRendering.SCREEN_SPACE_AMBIENT_OCCLUSION,
	["DIFFUSE"] = DebugRendering.DIFFUSE_LIGHTING,
	["SPECULAR"] = DebugRendering.SPECULAR_LIGHTING,
	["INDIRECT"] = DebugRendering.INDIRECT_LIGHTING,
	["DEPTH"] = DebugRendering.DEPTH_SCALED,
	["MIPS"] = DebugRendering.MIP_LEVELS,
	["VRS"] = DebugRendering.SHADING_RATE,
	["LOD"] = DebugRendering.MESH_LOD
}
for v23, v24 in pairs(DebugRendering) do
	if string.contains(v23, "_") then
		v_u_22[string.gsub(v23, "_", "")] = v24
	end
end
function SystemConsoleCommands.setDebugRenderingMode(_, p25)
	-- upvalues: (copy) v_u_22
	local function v32()
		-- upvalues: (ref) v_u_22
		local v26 = {}
		for v27, v28 in pairs(DebugRendering) do
			v26[v27] = true
			for v29, v30 in pairs(v_u_22) do
				if v28 == v30 then
					v26[v27] = nil
					v26[v29] = true
				end
			end
		end
		local v31 = table.toList(v26)
		table.sort(v31)
		return "Possible modes: " .. table.concat(v31, ", ")
	end
	if p25 == nil or p25 == "" then
		if getDebugRenderingMode() == DebugRendering.NONE then
			printError("Error: No debug mode given")
			return v32()
		else
			setDebugRenderingMode(DebugRendering.NONE)
			return "Changed debug rendering mode to NONE"
		end
	end
	local v33 = p25:upper()
	local v34 = string.gsub(v33, "_", "")
	local v35 = DebugRendering[v33] or DebugRendering[v34] or (v_u_22[v33] or v_u_22[v34])
	if v35 == nil then
		printError(string.format("Error: Unknown DebugRendering mode %q", v33))
		return v32()
	end
	setDebugRenderingMode(v35)
	local v36 = ""
	for v37, v38 in pairs(DebugRendering) do
		if v38 == v35 then
			v36 = v37
			break
		end
	end
	return "Changed debug rendering mode to " .. v36
end
function SystemConsoleCommands.changeLanguage(_, p39)
	local v40 = getNumOfLanguages()
	local v41 = -1
	if p39 == nil then
		local v42 = g_settingsLanguageGUI + 1
		local v43 = #g_availableLanguagesTable <= v42 and 0 or v42
		v41 = g_availableLanguagesTable[v43 + 1]
	else
		for v44 = 0, v40 - 1 do
			if getLanguageCode(v44) == p39 then
				v41 = v44
				break
			end
		end
		if v41 < 0 then
			return "Invalid language parameter " .. tostring(p39)
		end
	end
	if not setLanguage(v41) then
		return "Invalid language parameter " .. tostring(p39)
	end
	local v45 = XMLFile.load("SettingsFile", "dataS/settings.xml")
	loadLanguageSettings(v45)
	v45:delete()
	g_i18n:load()
	return string.format("Changed language to \'%s\'. Note that many texts are loaded on game start and need a reboot to be updated.", getLanguageCode(v41))
end
function SystemConsoleCommands.reloadCurrentGui(_)
	if g_gui.currentGuiName == nil or g_gui.currentGuiName == "" then
		return "No GUI active!"
	end
	g_gui.currentlyReloading = true
	local v46 = g_gui.currentGuiName
	local v47 = g_gui.currentGui.target
	g_gui:showGui("")
	g_i18n:delete()
	g_i18n:load()
	if not g_gui:loadProfiles("dataS/guiProfiles.xml") then
		g_gui.currentlyReloading = false
		return "Failed to reload profiles"
	end
	local v48 = ClassUtil.getClassObject(v46)
	if v48 == nil then
		for v49, _ in pairs(g_modIsLoaded) do
			for v50, v51 in pairs(_G[v49]) do
				if v50 == v46 then
					v48 = v51
				end
			end
		end
	end
	if v48 == nil then
		return "Given GUI class not found"
	end
	g_dummyGui = nil
	if v48.createFromExistingGui == nil then
		g_dummyGui = v48.new()
		g_gui.guis[v46]:delete()
		g_gui.guis[v46].target:delete()
		g_gui:loadGui(v47.xmlFilename, v46, g_dummyGui)
	else
		g_dummyGui = v48.createFromExistingGui(v47, v46)
	end
	g_gui:showGui(v46)
	g_gui.currentlyReloading = false
	return "Reloaded gui " .. tostring(v46)
end
function SystemConsoleCommands.reloadCurrentDialog(_)
	if g_gui.currentDialogName == nil or g_gui.currentDialogName == "" then
		return "No Dialog active!"
	end
	g_gui.currentlyReloading = true
	local v52 = g_gui.currentDialogName
	local v53 = g_gui.currentListener.target
	g_gui:closeDialog(g_gui.currentListener)
	g_i18n:delete()
	g_i18n:load()
	if not g_gui:loadProfiles("dataS/guiProfiles.xml") then
		g_gui.currentlyReloading = false
		return "Failed to reload profiles"
	end
	local v54 = ClassUtil.getClassObject(v52)
	if v54 == nil then
		for v55, _ in pairs(g_modIsLoaded) do
			for v56, v57 in pairs(_G[v55]) do
				if v56 == v52 then
					v54 = v57
				end
			end
		end
	end
	if v54 == nil then
		return "Given GUI Dialog class not found"
	end
	g_dummyGui = nil
	if v54.createFromExistingGui == nil then
		g_dummyGui = v54.new()
		g_gui.guis[v52]:delete()
		g_gui.guis[v52].target:delete()
		g_gui:loadGui(v53.xmlFilename, v52, g_dummyGui)
	else
		g_dummyGui = v54.createFromExistingGui(v53, v52)
	end
	g_gui.currentlyReloading = false
	return "Reloaded dialog " .. tostring(v52)
end
function SystemConsoleCommands.resetHelpSystem(_)
	if g_currentMission == nil or g_currentMission.introductionHelpSystem == nil then
		return "Not currently in a mission"
	end
	g_currentMission.introductionHelpSystem:resetHelpSystem()
	return "Reset Introduction Help System"
end
function SystemConsoleCommands.resetHelpSystemWithDraw(_)
	if g_currentMission == nil or g_currentMission.resetHelpSystemWithDraw == nil then
		return "Not currently in a mission"
	end
	g_currentMission.introductionHelpSystem:resetHelpSystemWithDraw()
	return "Reset Introduction Help System"
end
function SystemConsoleCommands.toggleUiDebug(_)
	if g_uiDebugEnabled then
		g_uiDebugEnabled = false
		return "UI Debug disabled"
	else
		g_uiDebugEnabled = true
		return "UI Debug enabled"
	end
end
function SystemConsoleCommands.toggleUiFocusDebug(_)
	if g_uiFocusDebugEnabled then
		g_uiFocusDebugEnabled = false
		return "UI Focus Debug disabled"
	else
		g_uiFocusDebugEnabled = true
		return "UI Focus Debug enabled"
	end
end
function SystemConsoleCommands.suspendApp(_)
	if g_appIsSuspended then
		notifyAppResumed()
	else
		notifyAppSuspended()
	end
	local v58 = g_appIsSuspended
	return "App Suspended: " .. tostring(v58)
end
function SystemConsoleCommands.fuzzInput(_)
	beginInputFuzzing()
end
function SystemConsoleCommands.softRestart(_)
	if g_currentMission == nil then
		RestartManager:setStartScreen(RestartManager.START_SCREEN_MAIN)
		doRestart(false, "")
	else
		OnInGameMenuMenu()
	end
end
function SystemConsoleCommands.updateDownloadFinished(_)
	g_updateDownloadFinished = true
	log("g_updateDownloadFinished = true")
end
function SystemConsoleCommands.setFidelityFxSR(_, p59)
	local v60 = tonumber(p59)
	local v61 = getFidelityFxSRQuality()
	print(string.format("current setting: %s (%d)", getFidelityFxSRQualityName(v61), v61))
	print("Available settings:")
	local v62 = "Usage: gsRenderingFidelityFxSRSet <qualityNumber>"
	for v63 = 0, FidelityFxSRQuality.NUM - 1 do
		local v64 = getFidelityFxSRQualityName(v63)
		local v65 = print
		local v66 = string.format
		local v67 = getSupportsFidelityFxSRQuality
		v65(v66("    %d | %s | supported=%s", v63, v64, (tostring(v67(v63)))))
	end
	if v60 == nil then
		return v62
	end
	if v60 < 0 or (v60 >= FidelityFxSRQuality.NUM or not getSupportsFidelityFxSRQuality(v60)) then
		return string.format("Error: Given quality \'%d\' not supported\n%s", v60, "Usage: gsRenderingFidelityFxSRSet <qualityNumber>")
	end
	setFidelityFxSRQuality(v60)
	local v68 = getFidelityFxSRQuality()
	return string.format("new setting: %s (%d)", getFidelityFxSRQualityName(v68), v68)
end
local v_u_69 = {}
local v_u_70 = setEnvMap
function SystemConsoleCommands.registerCustomEnvMap(p71)
	-- upvalues: (copy) v_u_69
	table.addElement(v_u_69, p71)
end
function SystemConsoleCommands.listCustomEnvMaps(_)
	-- upvalues: (copy) v_u_69
	if #v_u_69 == 0 then
		print("No custom env maps registered")
	else
		for v72, v73 in ipairs(v_u_69) do
			print(string.format("%d - %s", v72, v73))
		end
	end
end
function SystemConsoleCommands.setCustomEnvMap(_, p74, p75)
	-- upvalues: (copy) v_u_70, (copy) v_u_69
	local v76 = tonumber(p74)
	if v76 == 0 then
		setEnvMap = v_u_70
		print("reset custom env map")
		return
	elseif v76 == nil then
		printError("Error: no index given")
		print("Usage: gsCustomEnvMapSet index")
		print("Use gsCustomEnvMapList to see available env maps")
	else
		local v77 = v_u_69[v76]
		if v77 == nil then
			printError("Error: no env map for index %d", v76)
		end
		local v78 = tonumber(p75) or 1
		function setEnvMap() end
		v_u_70(v77, v77, v77, v77, v78, 0, 0, 0, true, true)
		print(string.format("set custom env map to %q with a weight of %.2f", v77, v78))
	end
end

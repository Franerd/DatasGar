StartParams = {}
local v_u_1 = {}
function StartParams.init(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2:split(" ")
	local v4 = "exe"
	for _, v5 in pairs(v3) do
		if v5:startsWith("-") then
			v4 = string.sub(v5, 2)
			v_u_1[v4] = ""
		else
			if v_u_1[v4] == nil then
				v_u_1[v4] = ""
			end
			if v_u_1[v4] ~= "" then
				v_u_1[v4] = v_u_1[v4] .. " "
			end
			v_u_1[v4] = v_u_1[v4] .. v5
		end
	end
	StartParams.printAll()
end
function StartParams.getValue(p6)
	-- upvalues: (copy) v_u_1
	return v_u_1[p6]
end
function StartParams.getIsSet(p7)
	-- upvalues: (copy) v_u_1
	return v_u_1[p7] ~= nil
end
function StartParams.setValue(p8, p9)
	-- upvalues: (copy) v_u_1
	v_u_1[p8] = p9
end
function StartParams.printAll()
	-- upvalues: (copy) v_u_1
	log("Used Start Parameters:")
	for v10, v11 in pairs(v_u_1) do
		log("  ", v10, v11)
	end
end

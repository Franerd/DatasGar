Mission00 = {}
local v_u_1 = Class(Mission00, FSBaseMission)
g_xmlManager:addCreateSchemaFunction(function()
	Mission00.xmlSchema = XMLSchema.new("mission00")
end)
g_xmlManager:addInitSchemaFunction(function()
	local v2 = Mission00.xmlSchema
	v2:register(XMLValueType.STRING, "map.filename", "filepath to map i3d file", nil, true)
	v2:register(XMLValueType.INT, "map#width", "Width of the world", 2048)
	v2:register(XMLValueType.INT, "map#height", "Height of the world", 2048)
	v2:register(XMLValueType.STRING, "map#imageFilename", "2D map filename")
	v2:register(XMLValueType.VECTOR_3, "map#mapFieldColor", "2D map field color rgb")
	v2:register(XMLValueType.VECTOR_3, "map#mapGrassFieldColor", "2D map grass color rgb")
	v2:register(XMLValueType.FLOAT, "map.culling#xzOffset", "")
	v2:register(XMLValueType.FLOAT, "map.culling#minY", "")
	v2:register(XMLValueType.FLOAT, "map.culling#maxY", "")
	v2:register(XMLValueType.FLOAT, "map.culling#clipDistanceThreshold1", "")
	v2:register(XMLValueType.FLOAT, "map.culling#clipDistanceThreshold2", "")
	v2:register(XMLValueType.INT, "map.densityMap#revision", "")
	v2:register(XMLValueType.INT, "map.terrainTexture#revision", "")
	v2:register(XMLValueType.INT, "map.terrainLodTexture#revision", "")
	v2:register(XMLValueType.INT, "map.splitShapes#revision", "")
	v2:register(XMLValueType.INT, "map.tipCollision#revision", "")
	v2:register(XMLValueType.INT, "map.placementCollision#revision", "")
	v2:register(XMLValueType.INT, "map.navigationCollision#revision", "")
	v2:register(XMLValueType.FLOAT, "map.vertexBufferMemoryUsage", "")
	v2:register(XMLValueType.FLOAT, "map.indexBufferMemoryUsage", "")
	v2:register(XMLValueType.FLOAT, "map.textureMemoryUsage", "")
	v2:register(XMLValueType.STRING, "map.shop#filename", "")
	v2:register(XMLValueType.STRING, "map.storeItems#filename", "")
	v2:register(XMLValueType.STRING, "map.sounds#filename", "")
	v2:register(XMLValueType.STRING, "map.environment#filename", "")
	v2:register(XMLValueType.STRING, "map.weed#filename", "")
	v2:register(XMLValueType.STRING, "map.fieldGround#filename", "")
	v2:register(XMLValueType.STRING, "map.motionPathEffects#filename", "")
	v2:register(XMLValueType.STRING, "map.bales#filename", "")
	v2:register(XMLValueType.STRING, "map.helpers#filename", "")
	v2:register(XMLValueType.STRING, "map.densityHeightTypes#filename", "")
	v2:register(XMLValueType.STRING, "map.fillTypes#filename", "")
	v2:register(XMLValueType.STRING, "map.groundTypes#filename", "")
	v2:register(XMLValueType.STRING, "map.sprayTypes#filename", "")
	v2:register(XMLValueType.STRING, "map.animals#filename", "")
	v2:register(XMLValueType.STRING, "map.animals.food#filename", "")
	v2:register(XMLValueType.STRING, "map.animals.names#filename", "")
	v2:register(XMLValueType.STRING, "map.wildlife#filename", "")
	v2:register(XMLValueType.STRING, "map.aiSystem#filename", "")
	v2:register(XMLValueType.STRING, "map.licensePlates#filename", "")
	v2:register(XMLValueType.STRING, "map.helpline#filename", "")
	v2:register(XMLValueType.VECTOR_TRANS, "map.helpline.trigger(?)#position", "")
	v2:register(XMLValueType.INT, "map.helpline.trigger(?)#categoryIndex", "")
	v2:register(XMLValueType.INT, "map.helpline.trigger(?)#pageIndex", "")
	v2:register(XMLValueType.STRING, "map.gameplayHints#filename", "")
	v2:register(XMLValueType.STRING, "map.collectibles#filename", "")
	v2:register(XMLValueType.STRING, "map.additionalFiles.additionalFile(?)#filename", "Path to additional i3d- or xml files to load for the map")
	v2:register(XMLValueType.STRING, "map.decoFoliages.decoFoliage(?)#layerName", "")
	v2:register(XMLValueType.INT, "map.decoFoliages.decoFoliage(?)#startChannel", "")
	v2:register(XMLValueType.INT, "map.decoFoliages.decoFoliage(?)#numChannels", "")
	v2:register(XMLValueType.BOOL, "map.decoFoliages.decoFoliage(?)#mowable", "")
	v2:register(XMLValueType.STRING, "map.decoFoliages.mapping(?)#name", "")
	v2:register(XMLValueType.STRING, "map.decoFoliages.mapping(?)#layerName", "")
	v2:register(XMLValueType.INT, "map.decoFoliages.mapping(?)#state", "")
	v2:register(XMLValueType.STRING, "map.paintableFoliages.paintableFoliage(?)#layerName", "")
	v2:register(XMLValueType.INT, "map.paintableFoliages.paintableFoliage(?)#startChannel", "")
	v2:register(XMLValueType.INT, "map.paintableFoliages.paintableFoliage(?)#numStateChannels", "")
	v2:register(XMLValueType.STRING, "map.groundTypeMappings.groundTypeMapping(?)#type", "")
	v2:register(XMLValueType.STRING, "map.groundTypeMappings.groundTypeMapping(?)#title", "")
	v2:register(XMLValueType.STRING, "map.groundTypeMappings.groundTypeMapping(?)#layer", "")
	v2:register(XMLValueType.STRING, "map.hotspots.placeableHotspot(?)#type", "Placeable hotspot type")
	v2:register(XMLValueType.VECTOR_2, "map.hotspots.placeableHotspot(?)#worldPosition", "Placeable world position")
	v2:register(XMLValueType.VECTOR_3, "map.hotspots.placeableHotspot(?)#teleportWorldPosition", "Placeable teleport world position")
	v2:register(XMLValueType.STRING, "map.hotspots.placeableHotspot(?)#text", "Placeable hotspot text")
end)
function Mission00.new(p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = Mission00:superClass().new(p3, p4 or v_u_1)
	if g_dedicatedServer ~= nil then
		v5:setAutoSaveInterval(g_dedicatedServer.autoSaveInterval, true)
	end
	v5.isSaving = false
	g_mission00StartPoint = nil
	v5.gameStarted = false
	v5.mapHotspots = {}
	return v5
end
function Mission00.delete(p6)
	if p6.xmlFile ~= nil then
		delete(p6.xmlFile)
		p6.xmlFile = nil
	end
	g_autoSaveManager:unloadMapData()
	for _, v7 in ipairs(p6.mapHotspots) do
		p6:removeMapHotspot(v7)
		v7:delete()
	end
	Mission00:superClass().delete(p6)
end
function Mission00.setMissionInfo(p_u_8, p_u_9, p_u_10)
	local v11 = Utils.getFilename(p_u_9.mapXMLFilename, p_u_8.baseDirectory)
	local v12 = XMLFile.load("MapXML", v11, Mission00.xmlSchema)
	p_u_8.xmlFile = v12:getHandle()
	p_u_8.mapWidth = v12:getValue("map#width", 2048)
	p_u_8.mapHeight = v12:getValue("map#height", 2048)
	p_u_8.mapImageFilename = Utils.getFilename(v12:getValue("map#imageFilename"), p_u_8.baseDirectory)
	p_u_8.mapFieldColor = v12:getValue("map#mapFieldColor", nil, true) or { 0.15, 0.1195, 0.0953 }
	p_u_8.mapGrassFieldColor = v12:getValue("map#mapGrassFieldColor", nil, true) or { 0.147, 0.1441, 0.0823 }
	p_u_8.cullingWorldXZOffset = v12:getValue("map.culling#xzOffset", p_u_8.cullingWorldXZOffset)
	p_u_8.cullingWorldMinY = v12:getValue("map.culling#minY", p_u_8.cullingWorldMinY)
	p_u_8.cullingWorldMaxY = v12:getValue("map.culling#maxY", p_u_8.cullingWorldMaxY)
	p_u_8.cullingClipDistanceThreshold1 = v12:getValue("map.culling#clipDistanceThreshold1", p_u_8.cullingClipDistanceThreshold1)
	p_u_8.cullingClipDistanceThreshold2 = v12:getValue("map.culling#clipDistanceThreshold2", p_u_8.cullingClipDistanceThreshold2)
	p_u_8.mapDensityMapRevision = v12:getValue("map.densityMap#revision", 1)
	p_u_8.mapTerrainTextureRevision = v12:getValue("map.terrainTexture#revision", 1)
	p_u_8.mapTerrainLodTextureRevision = v12:getValue("map.terrainLodTexture#revision", 1)
	p_u_8.mapSplitShapesRevision = v12:getValue("map.splitShapes#revision", 1)
	p_u_8.mapTipCollisionRevision = v12:getValue("map.tipCollision#revision", 1)
	p_u_8.mapPlacementCollisionRevision = v12:getValue("map.placementCollision#revision", 1)
	p_u_8.mapNavigationCollisionRevision = v12:getValue("map.navigationCollision#revision", 1)
	p_u_8.vertexBufferMemoryUsage = v12:getValue("map.vertexBufferMemoryUsage", p_u_8.vertexBufferMemoryUsage)
	p_u_8.indexBufferMemoryUsage = v12:getValue("map.indexBufferMemoryUsage", p_u_8.indexBufferMemoryUsage)
	p_u_8.textureMemoryUsage = v12:getValue("map.textureMemoryUsage", p_u_8.textureMemoryUsage)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_gameplayHintManager:loadMapData(p_u_8.xmlFile, p_u_9)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.navigationSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.slotSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.fieldGroundSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.aiMessageManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
		p_u_8.aiJobTypeManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_wheelManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_treePlantManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.treeMarkerSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_vehicleMaterialManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_storeManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
		g_mpLoadingScreen:hitLoadingTarget(MPLoadingScreen.LOAD_TARGETS.STORE)
	end, "Mission00:setMissionInfo - StoreManager:loadMapData")
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_groundTypeManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_connectionHoseManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_consumableManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_fillTypeManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_fruitTypeManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_sprayTypeManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_baleManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.weedSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.stoneSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.aiSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.animalSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end, "Mission00:setMissionInfo - AnimalSystem:loadMapData")
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.animalFoodSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_sleepManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		p_u_8.animalNameSystem:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_densityMapHeightManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_npcManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		g_helperManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9, (copy) p_u_10
		g_materialManager:loadMapData(p_u_8.xmlFile, p_u_9, p_u_8.baseDirectory, function()
			-- upvalues: (ref) p_u_8, (ref) p_u_9, (ref) p_u_10
			p_u_8:onMaterialsLoaded(p_u_9, p_u_10)
		end)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9, (copy) p_u_10
		Mission00:superClass().setMissionInfo(p_u_8, p_u_9, p_u_10)
	end)
end
function Mission00.onMaterialsLoaded(p_u_13, p_u_14, _)
	if not p_u_13.cancelLoading then
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_13, (copy) p_u_14
			g_licensePlateManager:loadMapData(p_u_13.xmlFile, p_u_14, p_u_13.baseDirectory)
		end)
		g_asyncTaskManager:addTask(function()
			g_particleSystemManager:loadMapData()
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_13, (copy) p_u_14
			g_motionPathEffectManager:loadMapData(p_u_13.xmlFile, p_u_14, p_u_13.baseDirectory)
		end)
		g_asyncTaskManager:addTask(function()
			g_effectManager:loadMapData()
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_13, (copy) p_u_14
			p_u_13.foliageSystem:loadMapData(p_u_13.xmlFile, p_u_14, p_u_13.baseDirectory)
			g_mpLoadingScreen:hitLoadingTarget(MPLoadingScreen.LOAD_TARGETS.DATA)
		end)
	end
end
function Mission00.load(p15)
	p15:startLoadingTask()
	p15:loadEnvironment(p15.xmlFile)
	local v16 = getXMLString(p15.xmlFile, "map.filename")
	p15:loadMap(Utils.getFilename(v16, p15.baseDirectory), true, p15.loadMission00Finished, p15)
	local v17 = Utils.getNoNil(getXMLString(p15.xmlFile, "map.sounds#filename"), "$data/maps/map01_sound.xml")
	local v18 = Utils.getFilename(v17, p15.baseDirectory)
	p15.missionInfo.mapSoundXmlFilename = v18
	p15:loadMapSounds(v18, p15.baseDirectory)
	p15.ambientSoundSystem:loadMapData(p15.xmlFile, p15.missionInfo, p15.baseDirectory)
	p15.reverbSystem:loadMapData(p15.xmlFile, p15.missionInfo, p15.baseDirectory)
	p15.collectiblesSystem:loadMapData(p15.xmlFile, p15.missionInfo, p15.baseDirectory)
	p15.growthSystem:loadMapData(p15.xmlFile, p15.missionInfo, p15.baseDirectory)
	p15.snowSystem:loadMapData(p15.xmlFile, p15.missionInfo, p15.baseDirectory)
end
function Mission00.loadMission00Finished(p_u_19, _, _)
	if not p_u_19.cancelLoading then
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_19
			local function v20()
				-- upvalues: (ref) p_u_19
				p_u_19.numAdditionalFiles = p_u_19.numAdditionalFiles - 1
				if p_u_19.numAdditionalFiles == 0 then
					p_u_19:loadAdditionalFilesFinished()
				end
			end
			local v21 = p_u_19:loadAdditionalFiles(p_u_19.xmlFile, v20, nil)
			if v21 > 0 then
				p_u_19.numAdditionalFiles = v21
			else
				p_u_19:loadAdditionalFilesFinished()
			end
		end)
	end
end
function Mission00.loadAdditionalFilesFinished(p_u_22)
	if not p_u_22.cancelLoading then
		g_asyncTaskManager:addTask(function()
			g_materialManager:loadModMaterialHolders()
			g_mpLoadingScreen:hitLoadingTarget(MPLoadingScreen.LOAD_TARGETS.ADDITIONAL_FILES)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			p_u_22.hud:loadIngameMap(p_u_22.mapImageFilename, p_u_22.mapWidth, p_u_22.mapHeight, p_u_22.mapFieldColor, p_u_22.mapGrassFieldColor)
		end, "Mission00:loadAdditionalFilesFinished - Load Ingamemap")
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			p_u_22:loadHotspots(p_u_22.xmlFile, p_u_22.missionInfo.customEnvironment)
		end, "Mission00:loadAdditionalFilesFinished - Load Hotspots")
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			p_u_22.handToolSystem:loadMapData(p_u_22.xmlFile, p_u_22.missionInfo, p_u_22.baseDirectory)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_farmlandManager:loadMapData(p_u_22.xmlFile)
		end, "Mission00:loadAdditionalFilesFinished - FarmlandManager:loadMapData")
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_guidedTourManager:loadMapData(p_u_22.xmlFile, p_u_22.missionInfo, p_u_22.baseDirectory)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_fieldManager:loadMapData(p_u_22.xmlFile, p_u_22.missionInfo, p_u_22.baseDirectory)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_fieldCourseManager:loadMapData(p_u_22.xmlFile, p_u_22.missionInfo, p_u_22.baseDirectory)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_farmManager:loadMapData(p_u_22.xmlFile)
			if p_u_22.missionDynamicInfo.isMultiplayer then
				p_u_22:loadCompetitiveMultiplayer(p_u_22.xmlFile)
			end
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			p_u_22:loadPlaceables(p_u_22.missionInfo.placeablesXMLLoad)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_missionManager:loadMapData(p_u_22.xmlFile)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_helpLineManager:loadMapData(p_u_22.xmlFile, p_u_22.missionInfo)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_gui:loadMapData(p_u_22.xmlFile, p_u_22.missionInfo, p_u_22.baseDirectory)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			if p_u_22:getIsServer() and (p_u_22.missionInfo.savegameDirectory ~= nil and fileExists(p_u_22.missionInfo.savegameDirectory .. "/collectibles.xml")) then
				p_u_22.collectiblesSystem:loadFromXMLFile(p_u_22.missionInfo.savegameDirectory .. "/collectibles.xml")
			end
		end)
		g_asyncTaskManager:addTask(function()
			g_autoSaveManager:loadFinished()
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			if p_u_22.missionDynamicInfo.isMultiplayer then
				p_u_22:removeAllHelpIcons()
			else
				p_u_22:updateFoundHelpIcons()
			end
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			if p_u_22.xmlFile ~= nil then
				delete(p_u_22.xmlFile)
				p_u_22.xmlFile = nil
			end
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			Mission00:superClass().load(p_u_22)
			if p_u_22.missionInfo.economyXMLLoad ~= nil then
				p_u_22:loadEconomy(p_u_22.missionInfo.economyXMLLoad)
			end
		end)
		if p_u_22:getIsServer() then
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				if p_u_22.missionInfo.fieldsXMLLoad ~= nil then
					g_fieldManager:loadFromXMLFile(p_u_22.missionInfo.fieldsXMLLoad)
				end
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				g_missionManager:loadFromXMLFile(p_u_22.missionInfo.missionsXMLLoad)
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				g_farmManager:loadFromXMLFile(p_u_22.missionInfo.farmsXMLLoad)
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				g_guidedTourManager:loadFromXMLFile(p_u_22.missionInfo.guidedTourXMLLoad)
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				g_farmlandManager:loadFromXMLFile(p_u_22.missionInfo.farmlandXMLLoad)
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				if p_u_22.missionInfo.playersXMLLoad ~= nil then
					p_u_22.playerSystem:loadFromSavegameXML(p_u_22.missionInfo.playersXMLLoad)
				end
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				g_npcManager:loadFromSavegameXMLFile(p_u_22.missionInfo.npcXMLLoad)
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				p_u_22.vehicleSaleSystem:loadFromXMLFile(p_u_22.missionInfo.vehicleSaleXML)
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				if p_u_22.missionInfo.treeMarkerXMLLoad ~= nil then
					p_u_22.treeMarkerSystem:loadFromSavegameXML(p_u_22.missionInfo.treeMarkerXMLLoad)
				end
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				if p_u_22.missionInfo.destructibleMapObjectsXMLLoad ~= nil then
					p_u_22.destructibleMapObjectSystem:loadFromSavegameXML(p_u_22.missionInfo.destructibleMapObjectsXMLLoad)
				end
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				p_u_22.growthSystem:loadFromXMLFile(p_u_22.missionInfo.environmentXMLLoad)
				if p_u_22.missionInfo.environmentXMLLoad ~= nil then
					p_u_22.snowSystem:loadFromXMLFile(p_u_22.missionInfo.environmentXMLLoad)
				end
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				if p_u_22.missionInfo.aiSystemXMLLoad ~= nil then
					p_u_22.aiSystem:loadFromXMLFile(p_u_22.missionInfo.aiSystemXMLLoad)
				end
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_22
				if p_u_22.missionInfo.navigationSystemXMLLoad ~= nil then
					p_u_22.aiSystem:loadFromXMLFile(p_u_22.missionInfo.navigationSystemXMLLoad)
				end
			end)
		end
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			g_treePlantManager:loadFromXMLFile(p_u_22.missionInfo.treePlantXMLLoad)
		end)
		g_asyncTaskManager:addTask(function()
			-- upvalues: (copy) p_u_22
			p_u_22:finishLoadingTask()
		end)
	end
end
function Mission00.loadAdditionalFiles(p_u_23, p24, p_u_25, p_u_26)
	local v27 = 0
	local v_u_28 = 0
	while true do
		local v29 = string.format("map.additionalFiles.additionalFile(%d)", v27)
		if not hasXMLProperty(p24, v29) then
			break
		end
		local v_u_30 = getXMLString(p24, v29 .. "#filename")
		if v_u_30 ~= nil then
			if v_u_30:contains(".i3d") then
				g_asyncTaskManager:addSubtask(function()
					-- upvalues: (ref) v_u_30, (copy) p_u_23, (copy) p_u_25, (copy) p_u_26
					v_u_30 = Utils.getFilename(v_u_30, p_u_23.baseDirectory)
					local v31 = { p_u_25, p_u_26 }
					g_i3DManager:loadI3DFileAsync(v_u_30, true, true, p_u_23.onLoadedMapI3DFiles, p_u_23, v31)
				end)
				v_u_28 = v_u_28 + 1
			elseif v_u_30:contains(".xml") then
				local v32 = Utils.getFilename(v_u_30, p_u_23.baseDirectory)
				local v_u_33 = XMLFile.load("additionalFilesXML", v32)
				if v_u_33 ~= nil then
					v_u_33:iterate("additionalFiles.additionalFile", function(_, p34)
						-- upvalues: (copy) v_u_33, (copy) p_u_23, (copy) p_u_25, (copy) p_u_26, (ref) v_u_28
						local v35 = v_u_33:getString(p34 .. "#filename")
						if v35 ~= nil then
							local v36 = Utils.getFilename(v35, p_u_23.baseDirectory)
							local v37 = { p_u_25, p_u_26 }
							g_i3DManager:loadI3DFileAsync(v36, true, true, p_u_23.onLoadedMapI3DFiles, p_u_23, v37)
							v_u_28 = v_u_28 + 1
						end
					end)
					v_u_33:delete()
				end
			end
		end
		v27 = v27 + 1
	end
	return v_u_28
end
function Mission00.onLoadedMapI3DFiles(p38, p39, _, p40)
	if p39 ~= 0 then
		unlink(p39)
		local v41 = p38.dynamicallyLoadedObjects
		table.insert(v41, p39)
	end
	p40[1](p40[2])
end
function Mission00.loadHotspots(p42, p43, p44)
	local v45 = XMLFile.wrap(p43, Mission00.xmlSchema)
	local v46 = 0
	while true do
		local v47 = string.format("map.hotspots.placeableHotspot(%d)", v46)
		if not v45:hasProperty(v47) then
			break
		end
		local v48 = PlaceableHotspot.new()
		local v49 = v45:getValue(v47 .. "#text", nil)
		if v49 == nil then
			Logging.xmlWarning(v45, "Missing placeable hotspot name for \'%s\'", v47)
			break
		end
		v48:setName(g_i18n:convertText(v49, p44))
		v48:createIcon()
		local v50 = v45:getValue(v47 .. "#type", "UNLOADING")
		local v51 = PlaceableHotspot.getTypeByName(v50)
		if v51 == nil then
			Logging.xmlWarning(v45, "Unknown placeable hotspot type \'%s\'. Falling back to type \'UNLOADING\'\nAvailable types: %s", v50, table.concatKeys(PlaceableHotspot.TYPE, " "))
			v51 = PlaceableHotspot.TYPE.UNLOADING
		end
		v48:setPlaceableType(v51)
		local v52, v53 = v45:getValue(v47 .. "#worldPosition", nil)
		if v52 ~= nil then
			v48:setWorldPosition(v52, v53)
		end
		local v54, v55, v56 = v45:getValue(v47 .. "#teleportWorldPosition", nil)
		if v54 ~= nil then
			local v57 = getTerrainHeightAtWorldPos
			local v58 = g_terrainNode
			v48:setTeleportWorldPosition(v54, math.max(v55, v57(v58, v54, 0, v56)), v56)
		end
		p42:addMapHotspot(v48)
		local v59 = p42.mapHotspots
		table.insert(v59, v48)
		v46 = v46 + 1
	end
	v45:delete()
end
function Mission00.onStartMission(p60)
	Mission00:superClass().onStartMission(p60)
	g_gameStateManager:setGameState(GameState.PLAY)
	g_achievementManager:loadMapData()
	g_currentMission.economyManager:restartGreatDemands()
	g_messageCenter:publish(MessageType.CURRENT_MISSION_START, not p60.missionInfo.isValid)
	p60.gameStarted = true
end
function Mission00.getIsTourSupported(p61)
	if Profiler.IS_INITIALIZED then
		return false
	elseif p61.missionInfo.startWithGuidedTour then
		return p61.missionInfo.loadDefaultFarm and true or false
	else
		return false
	end
end
function Mission00.update(p62, p63)
	Mission00:superClass().update(p62, p63)
	if p62:getIsServer() then
		g_autoSaveManager:update(p63)
		p62.isSaving = g_savegameController:getIsSaving()
		if (GS_IS_CONSOLE_VERSION or GS_IS_MOBILE_VERSION) and not p62.isSaving then
			p62:tryUnpauseGame()
		end
	end
end
function Mission00.doPauseGame(p64)
	Mission00:superClass().doPauseGame(p64)
	p64:showPauseDisplay(true)
end
function Mission00.doUnpauseGame(p65)
	Mission00:superClass().doUnpauseGame(p65)
	p65:showPauseDisplay(false)
end
function Mission00.canUnpauseGame(p66)
	local v67 = Mission00:superClass().canUnpauseGame(p66)
	if v67 then
		v67 = not p66.isSaving
	end
	return v67
end
function Mission00.draw(p68)
	Mission00:superClass().draw(p68)
	if p68.missionDynamicInfo.isMultiplayer and p68.gameStarted then
		p68.hud:drawCommunicationDisplay()
	end
end
function Mission00.loadPlaceables(p_u_69, p70)
	if p70 ~= nil and p_u_69:getIsServer() then
		p_u_69:startLoadingTask()
		p_u_69.placeableSystem:load(p70, p_u_69.finishLoadingTask, p_u_69)
	end
	g_asyncTaskManager:addSubtask(function()
		-- upvalues: (copy) p_u_69
		g_messageCenter:publish(MessageType.LOADED_ALL_SAVEGAME_PLACEABLES)
		p_u_69:loadVehicles(p_u_69.missionInfo.vehiclesXMLLoad)
	end)
end
function Mission00.loadVehicles(p_u_71, p72)
	if p72 ~= nil and p_u_71:getIsServer() then
		p_u_71:startLoadingTask()
		p_u_71.vehicleSystem:load(p72, p_u_71.finishLoadingTask, p_u_71)
	end
	g_asyncTaskManager:addSubtask(function()
		-- upvalues: (copy) p_u_71
		g_mpLoadingScreen:hitLoadingTarget(MPLoadingScreen.LOAD_TARGETS.VEHICLES)
		g_messageCenter:publish(MessageType.LOADED_ALL_SAVEGAME_VEHICLES)
		p_u_71:loadHandTools(p_u_71.missionInfo.handToolsXMLLoad)
	end)
end
function Mission00.loadHandTools(p_u_73, p74)
	if p_u_73:getIsServer() then
		p_u_73:startLoadingTask()
		p_u_73.handToolSystem:load(p74, p_u_73.finishLoadingTask, p_u_73)
	end
	g_asyncTaskManager:addSubtask(function()
		-- upvalues: (copy) p_u_73
		g_messageCenter:publish(MessageType.LOADED_ALL_SAVEGAME_HANDTOOLS)
		p_u_73:loadItems(p_u_73.missionInfo.itemsXMLLoad)
	end)
end
function Mission00.loadItems(p75, p76, p77)
	if p76 == nil then
		p75:loadItemsFinished()
	else
		p75:startLoadingTask()
		p75.itemSystem:loadItems(p76, p77, p75.missionInfo, p75.missionDynamicInfo, p75.loadItemsFinished, p75, nil)
	end
end
function Mission00.loadItemsFinished(p_u_78)
	g_mpLoadingScreen:hitLoadingTarget(MPLoadingScreen.LOAD_TARGETS.ITEMS)
	if p_u_78:getIsServer() then
		g_asyncTaskManager:addTask(function()
			g_farmManager:mergeObjectsForSingleplayer()
		end)
		g_asyncTaskManager:addSubtask(function()
			-- upvalues: (copy) p_u_78
			if p_u_78.missionInfo.onCreateObjectsXMLLoad ~= nil then
				p_u_78.onCreateObjectSystem:load(p_u_78.missionInfo.onCreateObjectsXMLLoad)
			end
		end)
		g_asyncTaskManager:addSubtask(function()
			-- upvalues: (copy) p_u_78
			p_u_78:finishLoadingTask()
		end)
	end
end
function Mission00.onCreateStartPoint(_, p79)
	g_mission00StartPoint = p79
end
function Mission00.addChatMessage(p80, p81, p82, p83, p84)
	local v85 = true
	if p84 ~= nil then
		local v86 = p80.userManager:getUserByUserId(p84, false)
		if v86 ~= nil then
			p81 = v86:getNickname()
			v85 = v86:getAllowTextCommunication()
		end
	end
	if v85 then
		p80.hud:addChatMessage(p82, p81, p83)
	end
end
function Mission00.scrollChatMessages(p87, p88)
	p87.hud:scrollChatMessages(p88)
end
function Mission00.loadEconomy(p89, p90)
	if p89:getIsServer() then
		local v91 = loadXMLFile("economyXML", p90)
		g_currentMission.economyManager:loadFromXMLFile(v91, "economy")
		delete(v91)
	end
end
function Mission00.loadCompetitiveMultiplayer(p92, p93)
	local v94 = getXMLString(p93, "map.competitiveMultiplayer#filename")
	if v94 ~= nil and p92:getIsServer() then
		local v95 = Utils.getFilename(v94, p92.baseDirectory)
		if not p92.missionInfo.isValid then
			local v96 = loadXMLFile("CompetitiveXML", v95)
			local v97 = 0
			while true do
				local v98 = string.format("competitiveMultiplayer.farms.farm(%d)", v97)
				if not hasXMLProperty(v96, v98) then
					break
				end
				local v99 = getXMLInt(v96, v98 .. "#farmId")
				local v100 = getXMLString(v96, v98 .. "#name")
				local v101 = getXMLInt(v96, v98 .. "#color")
				local v102 = g_farmManager:createFarm(v100, v101, nil, v99)
				if v102 ~= nil then
					local v103 = getXMLFloat(v96, v98 .. "#money")
					if v103 ~= nil then
						v102.money = v103
					end
					local v104 = getXMLFloat(v96, v98 .. "#loan")
					if v104 ~= nil then
						v102.loan = v104
					end
				end
				v97 = v97 + 1
			end
			delete(v96)
		end
		p92.missionInfo.isCompetitiveMultiplayer = true
	end
end

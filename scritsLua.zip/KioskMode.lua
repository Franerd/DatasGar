local v_u_1 = deleteFile
local v_u_2 = deleteFolder
KioskMode = {}
KioskMode.GAMEPAD_NAME = "JoyWarrior Gamepad 32"
KioskMode.BIT_TO_BUTTON_ID = {
	[1] = 7,
	[2] = 6,
	[3] = 5,
	[4] = 4,
	[5] = 3,
	[6] = 2,
	[7] = 1,
	[8] = 0,
	[15] = 8,
	[16] = 9,
	[17] = 10
}
function KioskMode.EMPTY_FUNC() end
local v_u_3 = Class(KioskMode)
function KioskMode.new(p4)
	-- upvalues: (copy) v_u_3
	local v5 = p4 or v_u_3
	local v6 = setmetatable({}, v5)
	v6.configPaths = { "dataS/kioskMode/", "data/kioskMode/", getUserProfileAppPath() .. "kioskMode/" }
	v6.profileSelectorGamepadId = nil
	v6.currentProfile = nil
	v6.profiles = {}
	v6.maskToProfile = {}
	v6.settings = {}
	v6.nextLanguageRestartTimer = nil
	v6.nextLanguageIndex = nil
	v6.maps = {}
	return v6
end
function KioskMode.generateBitmasks(_)
	local v_u_7 = {
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		15,
		16,
		17
	}
	local v_u_8 = {}
	local v_u_9 = {}
	local function v_u_15(p10, _)
		-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_8
		local v11 = 0
		for v12, v13 in ipairs(p10) do
			if v13 == 1 then
				v11 = Utils.setBit(v11, v_u_7[v12])
			end
		end
		if v_u_9[v11] == nil then
			local v14 = v_u_8
			table.insert(v14, v11)
			v_u_9[v11] = true
		else
			Logging.warning("Mask %s already exists", table.concat(p10, ""))
		end
	end
	local function v_u_19(p16, p17, p18)
		-- upvalues: (copy) v_u_15, (copy) v_u_19
		if p18 == p16 then
			v_u_15(p17, p16)
		else
			p17[p18] = 0
			v_u_19(p16, p17, p18 + 1)
			p17[p18] = 1
			v_u_19(p16, p17, p18 + 1)
		end
	end
	local v20 = { 0 }
	v_u_19(12, v20, 2)
	v20[1] = 1
	v_u_19(12, v20, 2)
	for _, v21 in ipairs(v_u_8) do
		local v22 = ""
		for v23 = 1, 20 do
			if (v23 - 1) % 5 == 0 then
				v22 = v22 .. " "
			end
			if v23 == 18 then
				v22 = v22 .. "0"
			elseif KioskMode.BIT_TO_BUTTON_ID[v23] == nil then
				v22 = v22 .. (math.random() > 0.5 and 1 or 0)
			else
				v22 = v22 .. (Utils.isBitSet(v21, v23) and 1 or 0)
			end
		end
		print(string.format("%s", v22))
	end
end
function KioskMode.delete(p24)
	p24:disposeVideo()
end
function KioskMode.load(p25)
	-- upvalues: (copy) v_u_1
	if StartParams.getIsSet("kioskDisabled") then
		return false
	end
	local v26 = false
	for _, v27 in ipairs(p25.configPaths) do
		if p25:loadFromPath(v27) then
			v26 = true
		end
	end
	if not v26 then
		return false
	end
	InGameMenu.makeIsAIEnabledPredicate = KioskMode.inj_inGameMenu_makeIsAIEnabledPredicate
	InGameMenu.makeIsPricesEnabledPredicate = KioskMode.inj_inGameMenu_makeIsPricesEnabledPredicate
	InGameMenu.makeIsAnimalsEnabledPredicate = KioskMode.inj_inGameMenu_makeIsAnimalsEnabledPredicate
	InGameMenu.makeIsContractsEnabledPredicate = KioskMode.inj_inGameMenu_makeIsContractsEnabledPredicate
	InGameMenu.makeIsGarageEnabledPredicate = KioskMode.inj_inGameMenu_makeIsGarageEnabledPredicate
	InGameMenu.makeIsSettingsEnabledPredicate = KioskMode.inj_inGameMenu_makeIsSettingsEnabledPredicate
	InGameMenu.makeIsHelpEnabledPredicate = KioskMode.inj_inGameMenu_makeIsHelpEnabledPredicate
	InGameMenuSettingsFrame.initializeButtons = Utils.overwrittenFunction(InGameMenuSettingsFrame.initializeButtons, KioskMode.inj_inGameMenuSettingsFrame_initializeButtons)
	MapManager.addMapItem = Utils.overwrittenFunction(MapManager.addMapItem, KioskMode.inj_mapManager_addMapItem)
	function loadMods()
		haveModsChanged()
	end
	InputBinding.loadModActions = Utils.overwrittenFunction(InputBinding.loadModActions, KioskMode.inj_inputBinding_loadModActions)
	InputBinding.loadModBindingDefaults = Utils.overwrittenFunction(InputBinding.loadModBindingDefaults, KioskMode.inj_inputBinding_loadModBindingDefaults)
	Gui.changeScreen = Utils.overwrittenFunction(Gui.changeScreen, KioskMode.inj_gui_changeScreen)
	Gui.showGui = Utils.overwrittenFunction(Gui.showGui, KioskMode.inj_gui_showGui)
	MessageCenter.publish = Utils.overwrittenFunction(MessageCenter.publish, KioskMode.inj_messageCenter_publish)
	if Platform.isPC and StartParams.getIsSet("kioskModeResetFiles") then
		local v28 = getUserProfileAppPath() .. "inputBinding.xml"
		if fileExists(v28) then
			v_u_1(v28)
		end
		local v29 = getUserProfileAppPath() .. "gameSettings.xml"
		if fileExists(v29) then
			v_u_1(v29)
		end
	end
	return true
end
function KioskMode.loadFromPath(p_u_30, p_u_31)
	local v32 = p_u_31 .. "kioskMode.xml"
	if not fileExists(v32) then
		return false
	end
	local v33 = #p_u_31 - 1
	local v34 = string.sub(p_u_31, 1, v33) .. ".zip"
	if folderExists(p_u_31) and fileExists(v34) then
		Logging.error("Kiosk mode config directory %q also has a zip file with the same name %q next to it overriding any changes made in the directory. Delete or rename the zip file!", p_u_31, v34)
		return false
	end
	local v_u_35 = XMLFile.load("KioskMode", v32, nil)
	if v_u_35 == nil then
		return false
	end
	local v36 = Utils.getFilename(v_u_35:getString("kioskMode.defaultProfile.configFile", ""), p_u_31)
	if not fileExists(v36) then
		Logging.xmlWarning(v_u_35, "KioskMode:loadFromPath - default config file \'%s\' not found", v36)
		return false
	end
	p_u_30.defaultConfigFile = v36
	v_u_35:iterate("kioskMode.profiles.profile", function(_, p37)
		-- upvalues: (copy) v_u_35, (copy) p_u_31, (copy) p_u_30
		local v38 = v_u_35:getString(p37 .. "#name", "")
		local v39 = Utils.getFilename(v_u_35:getString(p37 .. ".configFile", ""), p_u_31)
		if not fileExists(v39) then
			Logging.xmlWarning(v_u_35, "KioskMode:loadFromPath - config file \'%s\' for profile \'%s\' not found", v39, v38)
			return false
		end
		local v40 = 0
		local v41 = 1
		local v42 = v_u_35:getString(p37 .. "#bits", "")
		if v42:len() ~= 23 then
			Logging.xmlWarning(v_u_35, "KioskMode:loadFromPath - invalid bitsformat (##### ##### ##### #####) for profile \'%s\'", v38)
			return false
		end
		for v43 = 1, v42:len() do
			local v44 = v42:sub(v43, v43)
			if v44 ~= " " then
				if tonumber(v44) == 1 then
					if KioskMode.BIT_TO_BUTTON_ID[v41] == nil then
						if v41 == 18 then
							Logging.xmlWarning(v_u_35, "KioskMode:loadFromPath - Bit %d cannot be used. Please replace it with 0 for profile \'%s\'", v41, v38)
						end
					else
						v40 = Utils.setBit(v40, v41)
					end
				end
				v41 = v41 + 1
			end
		end
		if p_u_30.maskToProfile[v40] ~= nil then
			local v45 = p_u_30.maskToProfile[v40]
			Logging.xmlWarning(v_u_35, "KioskMode:loadFromPath - %s mask already used for profile \'%s\'", v38, v45.name)
			return false
		end
		local v46 = {
			["id"] = #p_u_30.profiles + 1,
			["name"] = v38,
			["mask"] = v40,
			["configFile"] = v39
		}
		p_u_30.maskToProfile[v40] = v46
		local v47 = p_u_30.profiles
		table.insert(v47, v46)
	end)
	v_u_35:delete()
	if #p_u_30.profiles == 0 then
		Logging.xmlWarning(v_u_35, "KioskMode:loadFromPath - No profiles defined!")
		return false
	end
	p_u_30.configFileName = v32
	local v48 = g_dlcsDirectories
	local v49 = {
		["path"] = p_u_31 .. "pdlc/",
		["isLoaded"] = true
	}
	table.insert(v48, v49)
	return true
end
function KioskMode.loadInputActions(p50)
	if p50.configFileName ~= nil then
		local v51 = XMLFile.load("KioskMode Inputs", p50.configFileName)
		local v52 = v51:getHandle()
		g_inputBinding:loadActionsFromXMLPath(v52, "kioskMode.input.actions", g_i18n, nil)
		v51:delete()
	end
end
function KioskMode.loadInputBindings(p53)
	if p53.configFileName ~= nil then
		local v54 = XMLFile.load("KioskMode Inputs", p53.configFileName)
		local v55 = v54:getHandle()
		g_inputBinding:loadActionBindingsFromXMLPath(v55, "kioskMode.input.bindings", true, nil, true, true)
		v54:delete()
	end
end
function KioskMode.initializedGUIClasses(_)
	MainScreen.onOpen = Utils.appendedFunction(MainScreen.onOpen, KioskMode.inj_mainScreen_onOpen)
	MainScreen.update = Utils.overwrittenFunction(MainScreen.update, KioskMode.inj_mainScreen_update)
	MainScreen.onClose = Utils.appendedFunction(MainScreen.onClose, KioskMode.inj_mainScreen_onClose)
	MainScreen.inputEvent = Utils.overwrittenFunction(MainScreen.inputEvent, KioskMode.inj_mainScreen_inputEvent)
	MainScreen.updateStoreButtons = KioskMode.EMPTY_FUNC
	MPLoadingScreen.openWardrobe = KioskMode.EMPTY_FUNC
	InGameMenuMobileSettingsFrame.onFrameOpen = Utils.appendedFunction(InGameMenuMobileSettingsFrame.onFrameOpen, KioskMode.inj_inGameMenuMobileSettingsFrame_onFrameOpen)
	InGameMenu.onButtonSaveGame = KioskMode.EMPTY_FUNC
	CareerScreen.updateButtons = Utils.appendedFunction(CareerScreen.updateButtons, KioskMode.inj_careerScreen_updateButtons)
	CareerScreen.update = Utils.appendedFunction(CareerScreen.update, KioskMode.inj_careerScreen_update)
	ModSelectionScreen.update = Utils.appendedFunction(ModSelectionScreen.update, KioskMode.inj_modSelectionScreenn_update)
	NewGameScreen.update = Utils.appendedFunction(NewGameScreen.update, KioskMode.inj_newGameScreen_update)
	InGameMenuMapFrame.updateInputGlyphs = Utils.appendedFunction(InGameMenuMapFrame.updateInputGlyphs, KioskMode.inj_inGameMenuMapFrame_updateInputGlyphs)
end
function KioskMode.init(p56)
	p56:initProfileSelectorGamepad()
	HUD.createDisplayComponents = Utils.appendedFunction(HUD.createDisplayComponents, KioskMode.inj_hud_createDisplayComponents)
	Mission00.getIsTourSupported = Utils.overwrittenFunction(Mission00.getIsTourSupported, KioskMode.inj_mission00_getIsTourSupported)
	Mission00.onStartMission = Utils.appendedFunction(Mission00.onStartMission, KioskMode.inj_mission00_onStartMission)
	SpecializationManager.addSpecialization = Utils.appendedFunction(SpecializationManager.addSpecialization, KioskMode.inj_specializationManager_addSpecialization)
	PlayerInputComponent.registerGlobalPlayerActionEvents = Utils.appendedFunction(PlayerInputComponent.registerGlobalPlayerActionEvents, KioskMode.inj_playerInputComponent_registerGlobalPlayerActionEvents)
	PlayerInputComponent.getCanToggleCamera = Utils.appendedFunction(PlayerInputComponent.getCanToggleCamera, KioskMode.inj_playerInputComponent_getCanToggleCamera)
	FSBaseMission.getIsAutoSaveSupported = Utils.appendedFunction(FSBaseMission.getIsAutoSaveSupported, KioskMode.inj_fsBaseMission_getIsAutoSaveSupported)
	FSBaseMission.update = Utils.appendedFunction(FSBaseMission.update, KioskMode.inj_fsBaseMission_update)
	AnimalLoadingTrigger.load = Utils.overwrittenFunction(AnimalLoadingTrigger.load, KioskMode.inj_animalLoadingTrigger_load)
	VehicleSellingPoint.load = Utils.overwrittenFunction(VehicleSellingPoint.load, KioskMode.inj_vehicleSellingPoint_load)
	ShopTrigger.new = Utils.overwrittenFunction(ShopTrigger.new, KioskMode.inj_shopTrigger_new)
	LoanTrigger.new = Utils.overwrittenFunction(LoanTrigger.new, KioskMode.inj_loanTrigger_new)
	Environment.load = Utils.overwrittenFunction(Environment.load, KioskMode.inj_environment_load)
	StoreManager.getDefaultStoreItemsFilename = Utils.overwrittenFunction(StoreManager.getDefaultStoreItemsFilename, KioskMode.inj_storeManager_getDefaultStoreItemsFilename)
	ProductionPointActivatable.run = Utils.overwrittenFunction(ProductionPointActivatable.run, KioskMode.inj_productionPointActivatable_run)
	Farm.setInitialEconomy = Utils.appendedFunction(Farm.setInitialEconomy, KioskMode.inj_Farm_setInitialEconomy)
	function MissionManager.update(_) end
	function SavegameController.getCanDeleteGame()
		return false
	end
	IngameMap.registerInput = Utils.overwrittenFunction(IngameMap.registerInput, KioskMode.inj_ingameMap_registerInput)
	RailroadCallerActivatable.run = Utils.overwrittenFunction(RailroadCallerActivatable.run, KioskMode.inj_railroadCallerActivatable_run)
	function getNumOfNotifications()
		return 0
	end
	function areAchievementsAvailable()
		return false
	end
	p56:loadProfileConfig(p56.defaultConfigFile)
	if GS_PLATFORM_PC and not g_gameSettings:getValue("gamepadEnabledSetByUser") then
		g_gameSettings:setValue("gamepadEnabledSetByUser", true)
		g_gameSettings:setValue("isGamepadEnabled", true)
		g_gameSettings:save()
	end
end
function KioskMode.initProfileSelectorGamepad(p57)
	for v58 = 0, getNumOfGamepads() - 1 do
		local v59 = getGamepadName(v58)
		if v59 == KioskMode.GAMEPAD_NAME then
			Logging.info("KioskMode:initProfileSelectorGamepad - Found Gaming Station with gamepad \'%s\'", v59)
			p57.profileSelectorGamepadId = v58
		end
	end
	if p57.profileSelectorGamepadId ~= nil then
		local v_u_60 = InputDevice.getIsDeviceSupported
		function InputDevice.getIsDeviceSupported(p61, p62)
			-- upvalues: (copy) v_u_60
			if v_u_60(p61, p62) then
				return p62 ~= KioskMode.GAMEPAD_NAME
			else
				return false
			end
		end
	end
	return p57.profileSelectorGamepadId ~= nil
end
function KioskMode.loadProfileConfig(p63, p64)
	Logging.info("KioskMode:loadProfileConfig - Loading profile config \'%s\'", p64)
	local v_u_65 = XMLFile.load("KioskMode Profile", p64)
	local v66 = Utils.getDirectory(p64)
	p63.settings.canSelectSavegame = v_u_65:getBool("config.canSelectSavegame", false)
	p63.settings.canSelectMods = v_u_65:getBool("config.canSelectMods", false)
	if not p63.settings.canSelectSavegame then
		local v67 = v_u_65:getString("config.savegame")
		if v67 ~= nil then
			v67 = Utils.getFilename(v67, v66)
		end
		p63:setSavegame(v67)
		p63.settings.savegame = v67
	end
	local v68 = v_u_65:getString("config.logo")
	if v68 ~= nil then
		p63.settings.logoFilename = Utils.getFilename(v68, v66)
		p63.settings.logoWidth = v_u_65:getInt("config.logo#width", 600)
		p63.settings.logoHeight = v_u_65:getInt("config.logo#height", 150)
	end
	p63.settings.logoEnabled = v68 ~= nil
	p63.settings.tourEnabled = v_u_65:getBool("config.tourEnabled", false)
	p63.settings.aiEnabled = v_u_65:getBool("config.aiEnabled", true)
	p63.settings.aiWorkerEnabled = v_u_65:getBool("config.aiWorkerEnabled", true)
	p63.settings.mainMenuEnabled = v_u_65:getBool("config.mainMenuEnabled", false)
	p63.settings.watermarkEnabled = v_u_65:getBool("config.watermarkEnabled", false)
	p63.settings.ingameMenuEnabled = v_u_65:getBool("config.ingameMenuEnabled", true)
	p63.settings.reloadEnabled = v_u_65:getBool("config.reloadEnabled", false)
	p63.settings.animalShopEnabled = v_u_65:getBool("config.shopsEnabled.animals", false)
	p63.settings.vehicleShopEnabled = v_u_65:getBool("config.shopsEnabled.vehicles", false)
	p63.settings.farmlandShopEnabled = v_u_65:getBool("config.shopsEnabled.farmlands", false)
	p63.settings.placeableShopEnabled = v_u_65:getBool("config.shopsEnabled.placeables", false)
	p63.settings.wardrobeShopEnabled = v_u_65:getBool("config.shopsEnabled.wardrobe", false)
	p63.settings.productionEnabled = v_u_65:getBool("config.productionEnabled", true)
	p63.settings.trainEnabled = v_u_65:getBool("config.trainEnabled", false)
	p63.settings.riceFieldEnabled = v_u_65:getBool("config.riceFieldEnabled", true)
	p63.settings.helpLineTriggerEnabled = v_u_65:getBool("config.helpLineTriggerEnabled", true)
	p63.settings.extendedDrivingHelp = v_u_65:getBool("config.extendedDrivingHelp", false)
	p63.settings.alwaysDay = v_u_65:getBool("config.alwaysDay", false)
	p63.settings.startMoney = v_u_65:getInt("config.startMoney", 1000000)
	p63.settings.skipMainMenu = v_u_65:getBool("config.skipMainMenu", false)
	p63.settings.farmlandsBuyAll = v_u_65:getBool("config.farmlandsBuyAll", false)
	p63.settings.startVehicleIndex = v_u_65:getInt("config.startVehicleIndex", nil)
	p63.settings.playerCanToggleCamera = v_u_65:getBool("config.player.canToggleCamera", false)
	if KioskMode.TIMESCALE_BACKUP == nil then
		KioskMode.TIMESCALE_BACKUP = Platform.gameplay.timeScaleSettings
		KioskMode.TIMESCALE_DEV_BACKUP = Platform.gameplay.timeScaleDevSettings
	end
	Platform.gameplay.timeScaleSettings = KioskMode.TIMESCALE_BACKUP
	Platform.gameplay.timeScaleDevSettings = KioskMode.TIMESCALE_DEV_BACKUP
	local v69 = v_u_65:getString("config.timescales", nil)
	if v69 ~= nil then
		local v70 = string.getVector(v69)
		if #v70 > 0 then
			Platform.gameplay.timeScaleSettings = v70
			Platform.gameplay.timeScaleDevSettings = {}
		end
	end
	local v71 = v_u_65:getString("config.maps", "")
	local v72 = string.split(v71, " ")
	p63.settings.maps = nil
	for _, v73 in ipairs(v72) do
		if p63.settings.maps == nil then
			p63.settings.maps = {}
		end
		p63.settings.maps[v73] = true
	end
	p63:updateAvailableMaps()
	local v74 = v_u_65:getString("config.storeItems", "")
	local v75
	if v74 == "" then
		v75 = nil
	else
		v75 = Utils.getFilename(v74, v66)
	end
	p63.settings.storeItems = v75
	local v76 = nil
	local v77 = v_u_65:getString("config.videos", "")
	local v78
	if v77 == "" then
		v78 = nil
	else
		local v79 = Utils.getFilename(v77, v66)
		local v80 = Files.new(v79).files
		for _, v81 in ipairs(v80) do
			local v82 = v79 .. "/" .. v81.filename
			if fileExists(v82) then
				v76 = v76 == nil and {} or v76
				local v83 = v79 .. "/" .. v81.filename
				table.insert(v76, v83)
			end
		end
		v78 = v_u_65:getInt("config.videos#inactiveDurationSeconds", 180) * 1000
		if v76 == nil or #v76 == 0 then
			Logging.warning("KioskMode: No videos found in \'%s\'", v79)
			v76 = nil
			v78 = nil
		end
	end
	p63.settings.videos = v76
	p63.settings.videoTimer = v78
	local v84 = v_u_65:getFloat("config.playtimeSeconds")
	if v84 ~= nil then
		p63.settings.playtimeDuration = v84 * 1000
	end
	p63.settings.playtimeEnabled = v84 ~= nil
	local v_u_85 = {}
	v_u_65:iterate("config.mods.mod", function(_, p86)
		-- upvalues: (copy) v_u_65, (copy) v_u_85
		local v87 = v_u_65:getString(p86)
		if v87 ~= nil then
			local v88 = v_u_85
			table.insert(v88, v87)
		end
	end)
	p63.settings.mods = v_u_85
	p63:openMainMenu()
	p63:setupMainMenu()
	v_u_65:delete()
end
function KioskMode.update(p89, p90)
	if (p89.profileSelectorGamepadId ~= nil or (StartParams.getIsSet("kioskProfileId") or StartParams.getIsSet("kioskProfileName"))) and (g_gui.currentGuiName == "MainScreen" and p89.currentProfile == nil) then
		local v91 = p89:getProfile()
		if v91 ~= nil then
			p89:loadProfileConfig(v91.configFile)
			p89.currentProfile = v91
		end
	end
	if GS_PLATFORM_PC and (p89.nextLanguageRestartTimer ~= nil and p89.nextLanguageRestartTimer < g_time) then
		doRestart(false, "")
	end
	if g_currentMission ~= nil and p89.playtimeReloadTimer ~= nil then
		p89.playtimeReloadTimer = p89.playtimeReloadTimer - p90
		if p89.playtimeReloadTimer <= 0 then
			p89:onReloadSavegame()
		end
	end
	if p89.currentVideoIndex == nil then
		if p89.videoStartTimer ~= nil then
			p89.videoStartTimer = p89.videoStartTimer - p90
			if p89.videoStartTimer < 0 then
				p89:nextVideo()
				return
			end
		end
	else
		if p89.videoOverlay ~= nil and isVideoOverlayPlaying(p89.videoOverlay) then
			updateVideoOverlay(p89.videoOverlay)
			return
		end
		if p89.videoOverlay ~= nil then
			p89:disposeVideo()
			p89:nextVideo()
		end
	end
end
function KioskMode.draw(p92)
	if p92.nextLanguageIndex ~= nil then
		setTextAlignment(RenderText.ALIGN_CENTER)
		setTextBold(true)
		setTextColor(0, 0, 0, 1)
		local v93 = (p92.nextLanguageRestartTimer - g_time) / 1000
		local v94 = math.ceil(v93)
		local v95 = getLanguageName(p92.nextLanguageIndex)
		renderText(0.5 + 2 * g_pixelSizeX, 0.75 - g_pixelSizeY, 0.025, string.format("Changing Language.\nNew language after restart will be \'%s\'. \nRestarting in %d seconds...", v95, v94))
		setTextColor(1, 1, 1, 1)
		renderText(0.5, 0.75, 0.025, string.format("Changing Language.\nNew language after restart will be \'%s\'. \nRestarting in %d seconds...", v95, v94))
		setTextAlignment(RenderText.ALIGN_LEFT)
		setTextBold(false)
	end
	if g_gui.currentGuiName == "MainScreen" and p92.currentProfile ~= nil then
		setTextAlignment(RenderText.ALIGN_LEFT)
		local v96 = p92.currentProfile.name
		setTextColor(0, 0, 0, 0.75)
		renderText(0.01, 0.9585, 0.011, v96)
		setTextColor(1, 1, 1, 1)
		renderText(0.01, 0.96, 0.011, v96)
	end
	if g_currentMission ~= nil and g_currentMission.hud ~= nil then
		local v97 = not g_currentMission.hud:getIsFading()
		local v98 = g_gui:getIsGuiVisible()
		if p92:getSetting("logoEnabled") and (not v98 and v97) then
			g_currentMission.hud.kioskModeLogoElement:draw()
		end
		if p92.playtimeReloadTimer ~= nil then
			local v99 = string.format("%0.1d:", p92.playtimeReloadTimer / 60000)
			local v100 = string.format("%0.2d", p92.playtimeReloadTimer / 1000 % 60)
			setTextBold(true)
			setTextAlignment(RenderText.ALIGN_RIGHT)
			renderText(0.5, v98 and 0.85 or 0.932, 0.05, v99)
			setTextAlignment(RenderText.ALIGN_LEFT)
			renderText(0.5, v98 and 0.85 or 0.932, 0.05, v100)
			setTextBold(false)
		end
	end
	if p92:getSetting("watermarkEnabled") then
		setTextAlignment(RenderText.ALIGN_CENTER)
		setTextBold(true)
		setTextColor(1, 1, 1, 0.5)
		renderText(0.5, 0.75, getCorrectTextSize(0.075), "INTERNAL USE ONLY")
		renderText(0.5, 0.73, getCorrectTextSize(0.03), "Copyright GIANTS Software GmbH")
		setTextColor(1, 1, 1, 1)
		setTextBold(false)
		setTextAlignment(RenderText.ALIGN_LEFT)
	end
	if p92.videoOverlay ~= nil and isVideoOverlayPlaying(p92.videoOverlay) then
		new2DLayer()
		renderOverlay(p92.videoOverlay, 0, 0, 1, 1)
	end
end
function KioskMode.getSetting(p101, p102)
	return p101.settings[p102]
end
function KioskMode.getProfile(p103)
	if StartParams.getIsSet("kioskProfileId") then
		local v104 = StartParams.getValue
		local v105 = tonumber(v104("kioskProfileId"))
		local v106 = p103.profiles[v105]
		if v106 ~= nil then
			return v106
		end
		if not p103.startParamProfileIdWarningShown then
			p103.startParamProfileIdWarningShown = true
			Logging.error("Invalid kioskProfileId \'%s\'!", v105)
		end
		return nil
	else
		if not StartParams.getIsSet("kioskProfileName") then
			if p103.profileSelectorGamepadId ~= nil then
				local v107 = 0
				for v108, v109 in pairs(KioskMode.BIT_TO_BUTTON_ID) do
					if getInputButton(v109, p103.profileSelectorGamepadId) > 0 then
						v107 = Utils.setBit(v107, v108)
					end
				end
				local v110 = p103.maskToProfile[v107]
				if v110 ~= nil then
					return v110
				end
			end
			return nil
		end
		local v111 = StartParams.getValue("kioskProfileName")
		local v112 = string.upper(v111)
		for _, v113 in pairs(p103.profiles) do
			if string.upper(v113.name) == v112 then
				return v113
			end
		end
		if not p103.startParamProfileNameWarningShown then
			p103.startParamProfileNameWarningShown = true
			Logging.error("Invalid kioskProfileName \'%s\'!", v111)
		end
		return nil
	end
end
function KioskMode.setSavegame(_, p114)
	-- upvalues: (copy) v_u_2
	if p114 == nil then
		if not GS_IS_CONSOLE_VERSION then
			v_u_2(getUserProfileAppPath() .. "savegame1")
		end
	else
		if GS_IS_CONSOLE_VERSION then
			saveSetFixedSavegame(p114)
			return
		end
		local v115 = getUserProfileAppPath() .. "savegame1"
		v_u_2(v115)
		createFolder(v115)
		local v116 = Files.new(p114).files
		for _, v117 in ipairs(v116) do
			copyFile(p114 .. "/" .. v117.filename, v115 .. "/" .. v117.filename, true)
		end
		if not fileExists(v115 .. "/careerSavegame.xml") then
			Logging.error("Failed to copy savegame from \'%s\' to \'%s\'!", p114, v115)
			return
		end
	end
end
function KioskMode.setupMainMenu(p118)
	local v119 = not p118:getSetting("mainMenuEnabled")
	g_mainScreen.careerButton:setDisabled(p118:getSetting("bscSPAutoStart"))
	g_mainScreen.multiplayerButton:setDisabled(v119)
	g_mainScreen.downloadModsButton:setDisabled(v119)
	g_mainScreen.achievementsButton:setDisabled(v119)
	if Platform.isConsole then
		g_mainScreen.settingsButton:setDisabled(true)
	else
		g_mainScreen.settingsButton:setDisabled(v119)
	end
	g_mainScreen.quitButton:setDisabled(v119)
	g_mainScreen.storeButton:setDisabled(v119)
	g_mainScreen.buttonBox:invalidateLayout()
end
function KioskMode.addRegisteredMaps(p120, p121)
	table.addElement(p120.maps, p121)
end
function KioskMode.updateAvailableMaps(p122)
	local v123 = p122.settings.maps
	table.clear(g_mapManager.maps)
	for _, v124 in ipairs(p122.maps) do
		if v123 == nil or v123[v124.id] == true then
			local v125 = g_mapManager.maps
			table.insert(v125, v124)
			g_mapManager.idToMap[v124.id] = v124
		end
	end
end
function KioskMode.resetVideoTimer(p126)
	if p126:getSetting("videos") == nil then
		return false
	end
	local v127 = p126.videoOverlay ~= nil
	p126.videoStartTimer = p126:getSetting("videoTimer")
	p126:disposeVideo()
	p126.currentVideoIndex = nil
	return v127
end
function KioskMode.openMainMenu(p128)
	p128:resetVideoTimer()
end
function KioskMode.closeMainMenu(p129)
	p129.videoStartTimer = nil
end
function KioskMode.disposeVideo(p130)
	if p130.videoOverlay ~= nil and isVideoOverlayPlaying(p130.videoOverlay) then
		stopVideoOverlay(p130.videoOverlay)
		delete(p130.videoOverlay)
		p130.videoOverlay = nil
	end
end
function KioskMode.nextVideo(p131)
	p131:disposeVideo()
	if p131.currentVideoIndex == nil or p131.currentVideoIndex >= #p131:getSetting("videos") then
		p131.currentVideoIndex = 1
	else
		p131.currentVideoIndex = p131.currentVideoIndex + 1
	end
	p131.videoStartTimer = nil
	p131.videoOverlay = createVideoOverlay(p131.settings.videos[p131.currentVideoIndex], false, 1)
	playVideoOverlay(p131.videoOverlay)
end
function KioskMode.onResetFiles(_)
	if GS_PLATFORM_PC then
		doRestart(false, "-kioskModeResetFiles")
	end
end
function KioskMode.onStartVideos(_)
	if g_gui.currentGuiName == "MainScreen" then
		g_kioskMode:nextVideo()
	end
end
function KioskMode.onToggleLanguage(_, _, p132, _, _, _, _, _)
	if GS_PLATFORM_PC and g_gui.currentGuiName == "MainScreen" then
		local v133 = getLanguage()
		local v134 = nil
		for v135, v136 in ipairs(g_availableLanguagesTable) do
			if v136 == v133 then
				v134 = v135 + math.sign(p132)
			end
		end
		local v137 = (v134 == nil or #g_availableLanguagesTable < v134) and 1 or (v134 < 1 and #g_availableLanguagesTable or v134)
		local v138 = g_availableLanguagesTable[v137]
		g_kioskMode.nextLanguageIndex = v138
		g_kioskMode.nextLanguageRestartTimer = g_time + 5000
		setLanguage(v138)
		g_kioskMode:resetVideoTimer()
	end
end
function KioskMode.onReloadSavegame(p139)
	if g_kioskMode:getSetting("reloadEnabled") or p139.playtimeReloadTimer ~= nil then
		OnInGameMenuMenu()
	end
end
function KioskMode.registerGlobalInputActionEvents(_)
	if GS_PLATFORM_PC then
		local _, v140 = g_inputBinding:registerActionEvent(InputAction.KIOSK_MODE_RESET_FILES, g_kioskMode, g_kioskMode.onResetFiles, false, true, false, true)
		g_inputBinding:setActionEventTextVisibility(v140, false)
		local _, v141 = g_inputBinding:registerActionEvent(InputAction.KIOSK_MODE_RELOAD_GAME, g_kioskMode, g_kioskMode.onReloadSavegame, false, true, false, true)
		g_inputBinding:setActionEventTextVisibility(v141, false)
		local _, v142 = g_inputBinding:registerActionEvent(InputAction.KIOSK_MODE_TOGGLE_LANGUAGE, nil, g_kioskMode.onToggleLanguage, false, true, false, true)
		g_inputBinding:setActionEventTextVisibility(v142, false)
		local _, v143 = g_inputBinding:registerActionEvent(InputAction.KIOSK_MODE_START_VIDEOS, nil, g_kioskMode.onStartVideos, false, true, false, true)
		g_inputBinding:setActionEventTextVisibility(v143, false)
	end
end
function KioskMode.inj_mapManager_addMapItem(p144, p145, ...)
	local v146 = p145(p144, ...)
	if v146 then
		local v147 = table.remove(p144.maps, #p144.maps)
		p144.idToMap[v147.id] = nil
		g_kioskMode:addRegisteredMaps(v147)
	end
	g_kioskMode:updateAvailableMaps()
	return v146
end
function KioskMode.inj_Farm_setInitialEconomy(p148, ...)
	if not p148.isSpectator then
		p148.money = g_kioskMode:getSetting("startMoney")
		Logging.info("Set Kiosk-Mode farm startmoney: %d", p148.money)
	end
end
function KioskMode.inj_ingameMap_registerInput(p149, p150, ...)
	if not g_kioskMode:getSetting("logoEnabled") then
		p150(p149, ...)
	end
end
function KioskMode.inj_inGameMenuMapFrame_updateInputGlyphs(p151, ...)
	local v152 = g_kioskMode:getSetting("farmlandShopEnabled")
	p151.buttonSwitchMapMode:setDisabled(not v152)
end
function KioskMode.inj_storeManager_getDefaultStoreItemsFilename(p153, p154, ...)
	local v155 = g_kioskMode:getSetting("storeItems")
	if v155 == nil then
		return p154(p153, ...)
	else
		return v155
	end
end
function KioskMode.inj_environment_load(p156, p157, ...)
	local v158 = p157(p156, ...)
	if g_kioskMode:getSetting("alwaysDay") then
		p156.dayNightCycle = false
	end
	return v158
end
function KioskMode.inj_loanTrigger_new(p159, p160, ...)
	local v161 = p160(p159)
	v161.isEnabled = g_kioskMode:getSetting("vehicleShopEnabled")
	return v161
end
function KioskMode.inj_shopTrigger_new(p162, p163, ...)
	local v164 = p163(p162)
	v164.isEnabled = g_kioskMode:getSetting("vehicleShopEnabled")
	return v164
end
function KioskMode.inj_vehicleSellingPoint_load(p165, p166, ...)
	local v167 = p166(p165, ...)
	p165.isEnabled = g_kioskMode:getSetting("vehicleShopEnabled")
	return v167
end
function KioskMode.inj_animalLoadingTrigger_load(p168, p169, ...)
	local v170 = p169(p168, ...)
	p168.isEnabled = g_kioskMode:getSetting("animalShopEnabled")
	return v170
end
function KioskMode.inj_fsBaseMission_getIsAutoSaveSupported(_)
	return false
end
function KioskMode.inj_playerInputComponent_registerGlobalPlayerActionEvents(_)
	g_kioskMode:getSetting("reloadEnabled")
end
function KioskMode.inj_playerInputComponent_getCanToggleCamera(p171, p172, ...)
	if g_kioskMode:getSetting("playerCanToggleCamera") then
		return p172(p171, ...)
	else
		return false
	end
end
function KioskMode.inj_fsBaseMission_update(_, _)
	if g_kioskMode.tryToEnterVehicle ~= nil then
		g_localPlayer:requestToEnterVehicle(g_kioskMode.tryToEnterVehicle)
		g_kioskMode.tryToEnterVehicle = nil
	end
end
function KioskMode.inj_mission00_onStartMission()
	if g_kioskMode:getSetting("playtimeEnabled") then
		g_kioskMode.playtimeReloadTimer = g_kioskMode:getSetting("playtimeDuration")
	end
	if g_kioskMode:getSetting("farmlandsBuyAll") then
		g_currentMission:playerOwnsAllFields()
	end
	local v173 = g_kioskMode:getSetting("startVehicleIndex")
	if v173 ~= nil then
		local v174 = g_currentMission.vehicleSystem.enterables[v173]
		if v174 ~= nil then
			g_kioskMode.tryToEnterVehicle = v174
		end
	end
	if not g_kioskMode:getSetting("helpLineTriggerEnabled") then
		g_currentMission:setShowHelpTrigger(false)
	end
end
function KioskMode.inj_inGameMenu_makeIsAIEnabledPredicate(_)
	return function()
		return g_kioskMode:getSetting("aiEnabled")
	end
end
function KioskMode.inj_inGameMenu_makeIsPricesEnabledPredicate(_)
	return function()
		return false
	end
end
function KioskMode.inj_inGameMenu_makeIsAnimalsEnabledPredicate(_)
	return function()
		return false
	end
end
function KioskMode.inj_inGameMenu_makeIsContractsEnabledPredicate(_)
	return function()
		return false
	end
end
function KioskMode.inj_inGameMenu_makeIsGarageEnabledPredicate(_)
	return function()
		return false
	end
end
function KioskMode.inj_inGameMenu_makeIsSettingsEnabledPredicate(_)
	return function()
		return false
	end
end
function KioskMode.inj_inGameMenu_makeIsHelpEnabledPredicate(_)
	return function()
		return false
	end
end
function KioskMode.inj_inGameMenuSettingsFrame_initializeButtons(p175)
	p175.saveButton = nil
end
function KioskMode.inj_inputBinding_loadModActions(p176, p177)
	p177(p176)
	g_kioskMode:loadInputActions()
end
function KioskMode.inj_inputBinding_loadModBindingDefaults(p178, p179)
	p179(p178)
	g_kioskMode:loadInputBindings()
end
function KioskMode.inj_productionPointActivatable_run(p180, p181)
	if g_kioskMode:getSetting("productionEnabled") then
		p181(p180)
	else
		InfoDialog.show(g_i18n:getText("ui_featureDisabled"))
	end
end
function KioskMode.inj_railroadCallerActivatable_run(p182, p183)
	if g_kioskMode:getSetting("trainEnabled") then
		p183(p182)
	else
		InfoDialog.show(g_i18n:getText("ui_featureDisabled"))
	end
end
function KioskMode.inj_specializationManager_addSpecialization(p184, _, p185, ...)
	if p184 == g_specializationManager then
		if p185 == "AIJobVehicle" then
			if not g_kioskMode:getSetting("aiEnabled") then
				local v_u_186 = AIJobVehicle.onRegisterActionEvents
				function AIJobVehicle.onRegisterActionEvents(p187, p188, p189)
					-- upvalues: (copy) v_u_186
					if p187.isClient then
						p187:clearActionEventsTable(p187.spec_aiJobVehicle.actionEvents)
					end
					if g_kioskMode:getSetting("aiEnabled") then
						if g_kioskMode:getSetting("ingameMenuEnabled") or p187:getStartableAIJob() ~= nil then
							v_u_186(p187, p188, p189)
						end
					else
						return
					end
				end
			end
			if not g_kioskMode:getSetting("aiWorkerEnabled") then
				local v_u_190 = AIJobVehicle.onRegisterActionEvents
				function AIJobVehicle.toggleAIVehicle(p191)
					-- upvalues: (copy) v_u_190
					if g_kioskMode:getSetting("aiWorkerEnabled") then
						v_u_190(p191)
					else
						InfoDialog.show(g_i18n:getText("ui_featureDisabled"))
					end
				end
				return
			end
		elseif p185 == "Drivable" and g_kioskMode:getSetting("extendedDrivingHelp") then
			local v_u_192 = Drivable.onRegisterActionEvents
			function Drivable.onRegisterActionEvents(p193, p194, p195)
				-- upvalues: (copy) v_u_192
				v_u_192(p193, p194, p195)
				local v196 = p193.spec_drivable
				for _, v197 in pairs(v196.actionEvents) do
					local v198 = v197.actionEventId
					local v199 = g_inputBinding.events[v198]
					if v199.displayPriority == GS_PRIO_VERY_LOW then
						g_inputBinding:setActionEventTextPriority(v198, GS_PRIO_VERY_HIGH)
					elseif v199.displayPriority == GS_PRIO_LOW then
						g_inputBinding:setActionEventTextPriority(v198, GS_PRIO_HIGH)
					end
					if not v199.displayIsVisible then
						g_inputBinding:setActionEventTextVisibility(v198, true)
					end
				end
			end
			return
		end
	elseif p184 == g_placeableSpecializationManager then
		if p185 == "PlaceableWardrobe" then
			if not g_kioskMode:getSetting("wardrobeShopEnabled") then
				function WardrobeActivatable.run()
					InfoDialog.show(g_i18n:getText("ui_featureDisabled"))
				end
				return
			end
		elseif p185 == "PlaceableRiceField" and not g_kioskMode:getSetting("riceFieldEnabled") then
			function PlaceableRiceFieldActivatable.run()
				InfoDialog.show(g_i18n:getText("ui_featureDisabled"))
			end
		end
	end
end
function KioskMode.inj_mission00_getIsTourSupported(p200, p201)
	if g_kioskMode:getSetting("tourEnabled") then
		return p201(p200)
	else
		return false
	end
end
function KioskMode.inj_hud_createDisplayComponents(p202, _)
	if g_kioskMode:getSetting("logoEnabled") then
		p202.ingameMap:setIsVisible(false)
		local v203 = g_kioskMode:getSetting("logoWidth")
		local v204 = g_kioskMode:getSetting("logoHeight")
		local v205 = g_kioskMode:getSetting("logoFilename")
		local v206, v207 = getNormalizedScreenValues(v203, v204)
		local v208 = Overlay.new(v205, g_safeFrameOffsetX, g_safeFrameOffsetY, v206, v207)
		p202.kioskModeLogoElement = HUDElement.new(v208)
		local v209 = p202.displayComponents
		local v210 = p202.kioskModeLogoElement
		table.insert(v209, v210)
	end
end
function KioskMode.inj_inGameMenuMobileSettingsFrame_onFrameOpen(p211)
	p211.multiGraphics:setDisabled(true)
	p211.checkGyroscope:setDisabled(true)
	p211.checkTilt:setDisabled(true)
end
function KioskMode.inj_careerScreen_updateButtons(p212)
	if p212.buttonDelete then
		p212.buttonDelete:setDisabled(true)
	end
end
function KioskMode.inj_modSelectionScreenn_update(p213, _)
	if not g_kioskMode:getSetting("canSelectMods") then
		for _, v214 in pairs(p213.selectedMods) do
			p213:setItemState(v214, false)
		end
		for _, v215 in pairs(g_kioskMode:getSetting("mods")) do
			local v216 = g_modManager:getModByName(v215)
			if v216 ~= nil then
				if p213:shouldShowModInList(v216) then
					p213:setItemState(v216, true)
				else
					Logging.error("Mod \'%s\' is not available for current kiosk mode setup", v216.title)
				end
			end
		end
		p213:onClickOk()
	end
end
function KioskMode.inj_newGameScreen_update(p217, _)
	local v218 = p217.startMissionInfo or g_startMissionInfo
	if g_mapManager:getNumOfMaps() == 1 then
		v218.mapId = g_mapManager:getMapDataByIndex(1).id
	end
	v218.initialMoney = g_kioskMode:getSetting("startMoney") or 100000
	p217:onClickOk()
end
function KioskMode.inj_careerScreen_update(p219, _)
	if not g_kioskMode:getSetting("canSelectSavegame") then
		p219.selectedIndex = 1
		p219:startSavegame(((p219.savegameController or g_savegameController):getSavegame(p219.selectedIndex)))
	end
end
function KioskMode.inj_mainScreen_inputEvent(p220, p221, p222, p223, p224)
	return p221(p220, p222, p223, p222 == InputAction.KIOSK_MODE_START_VIDEOS and true or (g_kioskMode:resetVideoTimer() and true or p224))
end
function KioskMode.inj_mainScreen_onClose(_)
	g_kioskMode:closeMainMenu()
end
function KioskMode.inj_mainScreen_update(p225, p226, p227)
	if g_kioskMode:getSetting("skipMainMenu") then
		p225:onCareerClick()
	else
		p226(p225, p227)
	end
end
function KioskMode.inj_mainScreen_onOpen(_)
	g_kioskMode:openMainMenu()
end
function KioskMode.inj_gui_changeScreen(p228, p229, p230, p231, ...)
	if p231 == InGameMenu then
		if not g_kioskMode:getSetting("ingameMenuEnabled") then
			return
		end
	elseif p231 == ShopMenu then
		if not g_kioskMode:getSetting("vehicleShopEnabled") then
			return
		end
	elseif p231 == WardrobeScreen then
		if not g_kioskMode:getSetting("wardrobeShopEnabled") then
			return
		end
	elseif p231 == ConstructionScreen then
		if not g_kioskMode:getSetting("placeableShopEnabled") then
			return
		end
	elseif p231 == AnimalScreen and not g_kioskMode:getSetting("animalShopEnabled") then
		return
	end
	return p229(p228, p230, p231, ...)
end
function KioskMode.inj_gui_showGui(p232, p233, p234, ...)
	if p234 == "InGameMenu" then
		if not g_kioskMode:getSetting("ingameMenuEnabled") then
			return
		end
	elseif p234 == "ShopMenu" then
		if not g_kioskMode:getSetting("vehicleShopEnabled") then
			return
		end
	elseif p234 == "WardrobeScreen" then
		if not g_kioskMode:getSetting("wardrobeShopEnabled") then
			return
		end
	elseif p234 == "ConstructionScreen" then
		if not g_kioskMode:getSetting("placeableShopEnabled") then
			return
		end
	elseif p234 == "AnimalScreen" and not g_kioskMode:getSetting("animalShopEnabled") then
		return
	end
	return p233(p232, p234, ...)
end
function KioskMode.inj_messageCenter_publish(p235, p236, p237, ...)
	if g_kioskMode:getSetting("ingameMenuEnabled") or p237 ~= MessageType.GUI_INGAME_OPEN_AI_SCREEN then
		return p236(p235, p237, ...)
	end
end

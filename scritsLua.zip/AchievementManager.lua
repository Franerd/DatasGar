AchievementManager = {}
local v_u_1 = Class(AchievementManager, AbstractManager)
function AchievementManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function AchievementManager.initDataStructures(p3)
	p3.achievementList = {}
	p3.achievementListById = {}
	p3.achievementListByName = {}
	p3.pendingAchievements = {}
	p3.numberOfAchievements = 0
	p3.numberOfUnlockedAchievements = 0
	p3.achievementsValid = false
	p3.achievementTimer = 0
	p3.achievementTimeInterval = 30000
	p3.fillTypeAchievements = {}
end
function AchievementManager.load(p4)
	local v5 = XMLFile.load("achievementsXML", "dataS/achievements.xml")
	if v5 == nil then
		return false
	end
	local v6 = GS_PLATFORM_PLAYSTATION
	local v7 = v5:getAsString()
	initAchievements(v7)
	p4.numberOfAchievements = 0
	for _, v8 in v5:iterator("achievements.achievement") do
		local v9 = v5:getInt(v8 .. "#id")
		if v9 == nil then
			Logging.xmlDevWarning(v5, "Missing or non-integer \'id\' for achievement \'%s\'", v8)
		else
			local v10 = v5:getString(v8 .. "#idName")
			if string.isNilOrWhitespace(v10) then
				Logging.xmlDevWarning(v5, "Missing \'idName\' for achievement \'%s\'", v8)
			else
				local v11 = v5:getInt(v8 .. "#score")
				local v12 = v5:getInt(v8 .. "#targetScore")
				local v13 = v5:getBool(v8 .. "#showScore")
				local v14 = v5:getString(v8 .. "#imageFilename")
				local v15 = string.getVector(v5:getString(v8 .. "#imageSize"), 2) or { 2048, 2048 }
				local v16 = GuiUtils.getUVs(v5:getString(v8 .. "#imageUVs") or "0 0 1 1", v15)
				if (v5:getString(v8 .. "#psn_type") or "") ~= "P" or v6 then
					local v17 = g_i18n:getText("achievement_name" .. v10)
					local v18 = g_i18n:getText("achievement_desc" .. v10)
					local v19 = string.gsub(v18, "$MEASURING_UNIT", g_i18n:getMeasuringUnit(true))
					p4:addAchievement(v9, v10, v17, string.gsub(v19, "$CURRENCY_SYMBOL", g_i18n:getCurrencySymbol(true)), v11, v12, v13, v14, v16)
				end
			end
		end
	end
	local v20 = string.getVector(v5:getString("achievements#lockedImageSize"), 2) or { 2048, 2048 }
	p4.lockedImage = v5:getString("achievements#lockedImageFilename")
	p4.lockedUVs = GuiUtils.getUVs(v5:getString("achievements#lockedImageUVs") or "0 0 1 1", v20)
	v5:delete()
	if areAchievementsAvailable() then
		p4:loadAchievementsState(false)
	end
	return true
end
function AchievementManager.loadMapData(p21)
	local v22 = g_currentMission
	local v23 = v22.missionInfo.isNewSPCareer
	if v23 then
		p21.startPlayTime = nil
		p21.startMoney = nil
		p21.startMissionCount = nil
		p21.startCultivatedHectares = nil
		p21.startSownHectares = nil
		p21.startFertilizedHectares = nil
		p21.startThreshedHectares = nil
		p21.startCutTreeCount = nil
		p21.startBreedCowsCount = nil
		p21.startBreedSheepCount = nil
		p21.startBreedPigsCount = nil
		p21.startBreedChickenCount = nil
		p21.startPetDogCount = nil
		p21.startTractorDistance = nil
		p21.startTruckDistance = nil
		p21.startCarDistance = nil
		p21.repairVehicleCount = nil
		p21.repaintVehicleCount = nil
		p21.startHorseDistance = nil
		p21.startHorseJumpCount = nil
		p21.startSoldCottonBales = nil
		p21.startWrappedBales = nil
	else
		local v24 = v22:farmStats()
		local v25 = v24:getTotalValue("playTime") / 60 + 0.0001
		p21.startPlayTime = math.floor(v25)
		p21.startMoney = g_farmManager:getFarmById(0).money
		p21.startMissionCount = v24:getTotalValue("missionCount")
		p21.startCultivatedHectares = v24:getTotalValue("cultivatedHectares")
		p21.startSownHectares = v24:getTotalValue("sownHectares")
		p21.startFertilizedHectares = v24:getTotalValue("sprayedHectares")
		p21.startThreshedHectares = v24:getTotalValue("threshedHectares")
		p21.startCutTreeCount = v24:getTotalValue("cutTreeCount")
		p21.startBreedCowsCount = v24:getTotalValue("breedCowsCount")
		p21.startBreedSheepCount = v24:getTotalValue("breedSheepCount")
		p21.startBreedPigsCount = v24:getTotalValue("breedPigsCount")
		p21.startBreedChickenCount = v24:getTotalValue("breedChickenCount")
		p21.startPetDogCount = v24:getTotalValue("petDogCount")
		p21.startTractorDistance = v24:getTotalValue("tractorDistance")
		p21.startTruckDistance = v24:getTotalValue("truckDistance")
		p21.startCarDistance = v24:getTotalValue("carDistance")
		p21.startRepairVehicleCount = v24:getTotalValue("repairVehicleCount")
		p21.startRepaintVehicleCount = v24:getTotalValue("repaintVehicleCount")
		p21.startHorseDistance = v24:getTotalValue("horseDistance")
		p21.startHorseJumpCount = v24:getTotalValue("horseJumpCount")
		p21.startSoldCottonBales = v24:getTotalValue("soldCottonBales")
		p21.startWrappedBales = v24:getTotalValue("wrappedBales")
	end
	p21.fillTypeAchievements = {}
	for _, v26 in ipairs(g_fillTypeManager:getFillTypes()) do
		local v27 = v26.achievementName
		if v27 ~= nil and p21.achievementListByName[v27] ~= nil then
			local v28 = {
				["name"] = v27,
				["fillType"] = v26
			}
			if not v23 then
				v28.startValue = v26.totalAmount
			end
			local v29 = p21.fillTypeAchievements
			table.insert(v29, v28)
		end
	end
	return true
end
function AchievementManager.addAchievement(p30, p31, p32, p33, p34, p35, p36, p37, p38, p39)
	local v40 = {
		["id"] = p31,
		["idName"] = p32,
		["name"] = p33,
		["description"] = p34,
		["score"] = p35,
		["targetScore"] = p36,
		["showScore"] = p37,
		["imageFilename"] = p38,
		["imageUVs"] = p39,
		["unlocked"] = false
	}
	local v41 = p30.achievementList
	table.insert(v41, v40)
	p30.achievementListById[p31] = v40
	p30.achievementListByName[p32] = v40
	p30.numberOfAchievements = p30.numberOfAchievements + 1
	return v40
end
function AchievementManager.resetAchievementsState(p42)
	p42.numberOfUnlockedAchievements = 0
	for _, v43 in pairs(p42.achievementList) do
		v43.unlocked = false
	end
	p42.achievementsValid = false
end
function AchievementManager.loadAchievementsState(p44, p45)
	p44.numberOfUnlockedAchievements = 0
	for _, v46 in pairs(p44.achievementList) do
		local v47 = v46.unlocked
		v46.unlocked = getAchievement(v46.id)
		if v46.unlocked then
			if not v47 and (p45 and not hasNativeAchievementGUI()) then
				g_messageCenter:publish(MessageType.ACHIEVEMENT_UNLOCKED, v46.name, v46.description, v46.imageFilename, v46.imageUVs)
			end
			p44.numberOfUnlockedAchievements = p44.numberOfUnlockedAchievements + 1
		end
	end
	p44.achievementsValid = true
end
function AchievementManager.handleStandardScoreAchievement(p48, p49, p50, p51)
	local v52 = p48.achievementListByName[p49]
	if v52 ~= nil and not v52.unlocked and (g_currentMission.missionInfo.isNewSPCareer or (p51 == nil or p50 ~= p51)) then
		v52.score = p50
		setAchievementProgress(v52.id, v52.score, v52.targetScore)
		if not areAchievementsAvailable() then
			p48.pendingAchievements[v52] = true
		end
	end
end
function AchievementManager.tryUnlock(p53, p54, p55)
	if p53:getCanUnlockAchievement() then
		local v56 = p53.achievementListByName[p54]
		if v56 ~= nil and not v56.unlocked then
			v56.score = p55
			setAchievementProgress(v56.id, p55, v56.targetScore)
			if not areAchievementsAvailable() then
				p53.pendingAchievements[v56] = true
			end
		end
	end
end
function AchievementManager.update(p57, p58)
	if areAchievementsAvailable() then
		for v59, _ in pairs(p57.pendingAchievements) do
			p57:tryUnlock(v59.id, v59.score)
			p57.pendingAchievements[v59] = nil
		end
		if getHaveAchievementsChanged() then
			p57.achievementsValid = false
		end
		if not p57.achievementsValid then
			p57:loadAchievementsState(true)
		end
		if p57:getCanUnlockAchievement() then
			p57:updateAchievements(p58)
		end
	end
end
function AchievementManager.getCanUnlockAchievement(_)
	local v60 = g_currentMission
	if v60 == nil then
		return false
	elseif v60.missionInfo:isa(FSCareerMissionInfo) then
		if v60.missionDynamicInfo.isMultiplayer then
			return false
		else
			return v60.gameStarted and true or false
		end
	else
		return false
	end
end
function AchievementManager.updateAchievements(p61, p62)
	p61.achievementTimer = p61.achievementTimer + p62
	if p61.achievementTimer >= p61.achievementTimeInterval then
		local v63 = g_currentMission
		local v64 = g_farmManager:getFarmById(v63:getFarmId())
		if v64 == nil then
			return
		end
		local v65 = v64.stats
		local v66 = v65:getTotalValue("playTime") / 60 + 0.0001
		p61:handleStandardScoreAchievement("PlayTime", math.floor(v66), p61.startPlayTime)
		p61:handleStandardScoreAchievement("Money", v64.money, p61.startMoney)
		local v67 = v65:getTotalValue("cultivatedHectares")
		p61:handleStandardScoreAchievement("CultivateFirst", v67, p61.startCultivatedHectares)
		p61:handleStandardScoreAchievement("Cultivate", v67, p61.startCultivatedHectares)
		local v68 = v65:getTotalValue("sownHectares")
		p61:handleStandardScoreAchievement("SowFirst", v68, p61.startSownHectares)
		p61:handleStandardScoreAchievement("Sow", v68, p61.startSownHectares)
		local v69 = v65:getTotalValue("sprayedHectares")
		p61:handleStandardScoreAchievement("FertilizeFirst", v69, p61.startFertilizedHectares)
		p61:handleStandardScoreAchievement("Fertilize", v69, p61.startFertilizedHectares)
		local v70 = v65:getTotalValue("threshedHectares")
		p61:handleStandardScoreAchievement("HarvestedFirst", v70, p61.startThreshedHectares)
		p61:handleStandardScoreAchievement("Harvested", v70, p61.startThreshedHectares)
		p61:handleStandardScoreAchievement("BreedCows", v65:getTotalValue("breedCowsCount"), p61.startBreedCowsCount)
		p61:handleStandardScoreAchievement("BreedSheep", v65:getTotalValue("breedSheepCount"), p61.startBreedSheepCount)
		p61:handleStandardScoreAchievement("BreedPigs", v65:getTotalValue("breedPigsCount"), p61.startBreedPigsCount)
		p61:handleStandardScoreAchievement("BreedChicken", v65:getTotalValue("breedChickenCount"), p61.startBreedChickenCount)
		p61:handleStandardScoreAchievement("TractorDriving", v65:getTotalValue("tractorDistance"), p61.startTractorDistance)
		p61:handleStandardScoreAchievement("TruckDriving", v65:getTotalValue("truckDistance"), p61.startTruckDistance)
		p61:handleStandardScoreAchievement("CarDriving", v65:getTotalValue("carDistance"), p61.startCarDistance)
		local v71 = v65:getTotalValue("horseDistance")
		p61:handleStandardScoreAchievement("HorseRidingFirst", v71, p61.startHorseDistance)
		p61:handleStandardScoreAchievement("HorseRiding", v71, p61.startHorseDistance)
		for _, v72 in ipairs(p61.fillTypeAchievements) do
			p61:handleStandardScoreAchievement(v72.name, v72.fillType.totalAmount, v72.startValue)
		end
		p61.achievementTimer = 0
	end
end
function AchievementManager.getLockedImageData(p73)
	return p73.lockedImage, p73.lockedUVs
end

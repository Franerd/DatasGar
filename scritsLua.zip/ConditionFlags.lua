ConditionFlags = {}
local v_u_1 = Class(ConditionFlags)
function ConditionFlags.loadFlagFromXML(p2, p3, p4, p5, p6)
	local v7 = string.format("%s.prevent#%s", p3, p4.xmlAttributeName)
	local v8 = string.format("%s.required#%s", p3, p4.xmlAttributeName)
	if p2:getBool(v7) then
		p6 = bitOR(p6, p4.bitflag)
	end
	if p2:getBool(v8) then
		p5 = bitOR(p5, p4.bitflag)
	end
	return p5, p6
end
function ConditionFlags.new(p9)
	-- upvalues: (copy) v_u_1
	local v10 = p9 or v_u_1
	local v11 = setmetatable({}, v10)
	v11.modifiers = {}
	v11.nameToModifier = {}
	v11.mask = 0
	return v11
end
function ConditionFlags.delete(_) end
function ConditionFlags.loadFlagsFromXMLFile(p12, p13, p14)
	local v15 = 0
	local v16 = 0
	if p13:getNumOfElements(string.format("%s.prevent", p14)) > 1 then
		Logging.xmlWarning(p13, "More than one \'prevent\' element defined for \'%s\'", p14)
	end
	if p13:getNumOfElements(string.format("%s.required", p14)) > 1 then
		Logging.xmlWarning(p13, "More than one \'required\' element defined for \'%s\'", p14)
	end
	for _, v17 in ipairs(p12.modifiers) do
		v15, v16 = v17.loadFromXMLFunc(p13, p14, v17, v15, v16)
	end
	if bitAND(v15, v16) ~= 0 then
		for _, v18 in ipairs(p12.modifiers) do
			if bitAND(v15, v18.bitflag) ~= 0 and bitAND(v16, v18.bitflag) ~= 0 then
				Logging.xmlWarning(p13, "Modifier \'%s\' is set for prevent and required in \'%s\'", v18.xmlAttributeName, p14)
			end
		end
	end
	return v15, v16
end
function ConditionFlags.registerXMLPaths(p19, p20, p21)
	for _, v22 in ipairs(p19.modifiers) do
		if not v22.hasCustomLoadFunction then
			local v23 = v22.xmlAttributeName
			p20:register(XMLValueType.BOOL, p21 .. ".prevent#" .. v23, "Prevent flag " .. v23)
			p20:register(XMLValueType.BOOL, p21 .. ".required#" .. v23, "Required flag " .. v23)
		end
	end
end
function ConditionFlags.registerModifier(p_u_24, p25, p26)
	local v27 = string.upper(p25)
	for _, v28 in ipairs(p_u_24.modifiers) do
		if v28.xmlAttributeName == p25 then
			Logging.warning("Given ConditionFlags modifier xml attribute name \'%s\' already used", p25)
			return v28.updateFunc
		end
	end
	local v_u_30 = {
		["name"] = v27,
		["xmlAttributeName"] = p25,
		["hasCustomLoadFunction"] = p26 ~= nil,
		["bitflag"] = 2 ^ (#p_u_24.modifiers + 1),
		["loadFromXMLFunc"] = p26 or ConditionFlags.loadFlagFromXML,
		["updateFunc"] = function(p29)
			-- upvalues: (copy) p_u_24, (copy) v_u_30
			if p29 then
				p_u_24.mask = bitOR(p_u_24.mask, v_u_30.bitflag)
			else
				p_u_24.mask = bitAND(p_u_24.mask, bitNOT(v_u_30.bitflag))
			end
		end
	}
	local v31 = p_u_24.modifiers
	table.insert(v31, v_u_30)
	p_u_24.nameToModifier[v27] = v_u_30
	return v_u_30.updateFunc
end
function ConditionFlags.setModifierValue(p32, p33, p34)
	local v35 = string.upper(p33)
	local v36 = p32.nameToModifier[v35]
	if v36 ~= nil then
		v36.updateFunc(p34)
	end
end
function ConditionFlags.getMask(p37)
	return p37.mask
end
function ConditionFlags.drawDebug(p38, p39, p40)
	setTextColor(1, 1, 1, 1)
	setTextBold(true)
	setTextAlignment(RenderText.ALIGN_CENTER)
	renderText(p39, p40, getCorrectTextSize(0.014), "Modifiers:")
	setTextBold(false)
	local v41 = getCorrectTextSize(0.012)
	local v42 = getCorrectTextSize(0.001)
	local v43 = p40 - 0.02
	for _, v44 in ipairs(p38.modifiers) do
		local v45 = bitAND(p38.mask, v44.bitflag) ~= 0
		setTextAlignment(RenderText.ALIGN_RIGHT)
		renderText(p39, v43, v41, v44.xmlAttributeName .. ":  ")
		setTextAlignment(RenderText.ALIGN_LEFT)
		renderText(p39, v43, v41, (tostring(v45)))
		v43 = v43 - v41 - v42
	end
	return v43
end

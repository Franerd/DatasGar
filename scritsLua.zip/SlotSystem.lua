SlotSystem = {}
SlotSystem.TOTAL_VRAM_MEGABYTES = {
	[PlatformId.WIN] = (1 / 0),
	[PlatformId.MAC] = (1 / 0),
	[PlatformId.PS5] = 3500,
	[PlatformId.XBOX_SERIES] = 3500,
	[PlatformId.IOS] = 640,
	[PlatformId.ANDROID] = 640,
	[PlatformId.SWITCH] = 640
}
SlotSystem.VRAM_MEGABYTES_PER_SLOT = {
	[PlatformId.WIN] = 1,
	[PlatformId.MAC] = 1,
	[PlatformId.PS5] = 1,
	[PlatformId.XBOX_SERIES] = 1,
	[PlatformId.IOS] = 0.5,
	[PlatformId.ANDROID] = 0.5,
	[PlatformId.SWITCH] = 0.5
}
SlotSystem.VISIBILITY_THRESHOLD = 10000
SlotSystem.CRITICAL_FACTOR = 0.9
SlotSystem.TOTAL_NUM_GARAGE_SLOTS = {}
for v1, v2 in pairs(SlotSystem.TOTAL_VRAM_MEGABYTES) do
	local v3 = SlotSystem.TOTAL_NUM_GARAGE_SLOTS
	local v4 = v2 / SlotSystem.VRAM_MEGABYTES_PER_SLOT[v1]
	v3[v1] = math.floor(v4)
end
SlotSystem.LIMITED_OBJECT_BALE = 1
SlotSystem.LIMITED_OBJECT_PALLET = 2
local v5 = SlotSystem
local v6 = {
	[SlotSystem.LIMITED_OBJECT_BALE] = {
		[PlatformId.WIN] = (1 / 0),
		[PlatformId.MAC] = (1 / 0),
		[PlatformId.PS5] = 200,
		[PlatformId.XBOX_SERIES] = 200,
		[PlatformId.IOS] = 100,
		[PlatformId.ANDROID] = 100,
		[PlatformId.SWITCH] = 100
	},
	[SlotSystem.LIMITED_OBJECT_PALLET] = {
		[PlatformId.WIN] = 300,
		[PlatformId.MAC] = 300,
		[PlatformId.PS5] = 150,
		[PlatformId.XBOX_SERIES] = 150,
		[PlatformId.IOS] = 50,
		[PlatformId.ANDROID] = 50,
		[PlatformId.SWITCH] = 50
	}
}
v5.NUM_OBJECT_LIMITS = v6
local v_u_7 = Class(SlotSystem)
function SlotSystem.new(p8, p9, p10)
	-- upvalues: (copy) v_u_7
	local v11 = p10 or v_u_7
	local v12 = setmetatable({}, v11)
	v12.mission = p8
	v12.isServer = p9
	v12.slotUsage = 0
	v12.slotLimit = SlotSystem.TOTAL_NUM_GARAGE_SLOTS[getPlatformId()]
	v12.vramPerSlot = SlotSystem.VRAM_MEGABYTES_PER_SLOT[getPlatformId()] * 1024 * 1024
	if p9 then
		v12.objectLimits = {}
		for v13, v14 in pairs(SlotSystem.NUM_OBJECT_LIMITS) do
			v12.objectLimits[v13] = {
				["objects"] = {},
				["limit"] = v14[getPlatformId()]
			}
		end
	end
	return v12
end
function SlotSystem.delete(_) end
function SlotSystem.loadMapData(p15, _, _)
	p15:updateSlotLimit()
	return true
end
function SlotSystem.saveToXMLFile(p16, p17, p18)
	setXMLInt(p17, p18 .. "#slotUsage", p16.slotUsage)
end
function SlotSystem.getIsCountableObject(_, p19)
	return p19:isa(Vehicle) or p19:isa(Placeable)
end
function SlotSystem.updateSlotUsage(p20)
	local v21 = (p20.mission.vertexBufferMemoryUsage + p20.mission.indexBufferMemoryUsage + p20.mission.textureMemoryUsage) / p20.vramPerSlot
	p20.slotUsage = math.ceil(v21)
	for v22, v23 in pairs(p20.mission.ownedItems) do
		if v23.numItems > 0 and not v22.ignoreVramUsage then
			local v24 = p20:getStoreItemSlotUsage(v22, true)
			local v25 = p20:getStoreItemSlotUsage(v22, false) * (v23.numItems - 1)
			p20.slotUsage = p20.slotUsage + v24 + v25
		end
	end
	for v26, v27 in pairs(p20.mission.leasedItems) do
		if v27.numItems > 0 and not v26.ignoreVramUsage then
			p20.slotUsage = p20.slotUsage + p20:getStoreItemSlotUsage(v26, true) + p20:getStoreItemSlotUsage(v26, false) * (v27.numItems - 1)
		end
	end
	g_shopMenu:onSlotUsageChanged(p20.slotUsage, p20.slotLimit)
	g_shopConfigScreen:onSlotUsageChanged(p20.slotUsage, p20.slotLimit)
	g_messageCenter:publish(MessageType.SLOT_USAGE_CHANGED, p20.slotUsage, p20.slotLimit)
end
function SlotSystem.updateSlotLimit(p28)
	local v29 = SlotSystem.TOTAL_NUM_GARAGE_SLOTS[getPlatformId()]
	for _, v30 in ipairs(p28.mission.userManager:getUsers()) do
		local v31 = SlotSystem.TOTAL_NUM_GARAGE_SLOTS[v30:getPlatformId()]
		if v31 ~= nil then
			v29 = math.min(v29, v31)
		end
	end
	p28:setSlotLimit(v29)
end
function SlotSystem.setSlotLimit(p32, p33)
	local v34
	if p33 == p32.slotLimit then
		v34 = false
	else
		local v35 = g_i18n:getText("ingameNotification_crossPlaySlotLimitInactive")
		local v36 = FSBaseMission.INGAME_NOTIFICATION_OK
		if p33 < (1 / 0) then
			v35 = string.format(g_i18n:getText("ingameNotification_crossPlayNewSlotLimit"), p33)
			v36 = FSBaseMission.INGAME_NOTIFICATION_CRITICAL
		end
		p32.mission:addIngameNotification(v36, v35)
		p32.slotLimit = p33
		if g_server == nil then
			v34 = true
		else
			g_server:broadcastEvent(SlotSystemUpdateEvent.new(p33))
			v34 = true
		end
	end
	g_shopMenu:onSlotUsageChanged(p32.slotUsage, p33)
	g_messageCenter:publish(MessageType.SLOT_USAGE_CHANGED, p32.slotUsage, p32.slotLimit)
	return v34
end
function SlotSystem.hasEnoughSlots(p37, p38)
	if p38.ignoreVramUsage then
		return true
	end
	local v39 = p37:getStoreItemSlotUsage(p38, p37.mission:getNumOfItems(p38) == 0)
	return p37.slotLimit >= p37.slotUsage + v39
end
function SlotSystem.getAreSlotsVisible(p40)
	return p40.slotLimit < SlotSystem.VISIBILITY_THRESHOLD and true or p40.slotUsage >= p40.slotLimit * SlotSystem.CRITICAL_FACTOR
end
function SlotSystem.getStoreItemSlotUsage(p41, p42, p43)
	if p42 == nil or (StoreItemUtil.getIsAnimal(p42) or StoreItemUtil.getIsObject(p42)) then
		return 0
	end
	local v44
	if p43 then
		v44 = p42.perInstanceVramUsage + p42.sharedVramUsage * 1.2
	else
		local v45 = p42.perInstanceVramUsage
		local v46 = p42.sharedVramUsage * 0.05
		v44 = math.max(v45, v46)
	end
	local v47 = v44 / p41.vramPerSlot
	local v48 = math.ceil(v47)
	return math.max(v48, 1)
end
function SlotSystem.getCanConnect(p49, _, p50)
	local v51 = SlotSystem.TOTAL_NUM_GARAGE_SLOTS[p50]
	return v51 == nil and true or p49.slotUsage <= v51
end
function SlotSystem.addLimitedObject(p52, p53, p54)
	if p52.isServer then
		local v55 = p52.objectLimits[p53]
		if v55 ~= nil then
			table.addElement(v55.objects, p54)
		end
	else
		return
	end
end
function SlotSystem.removeLimitedObject(p56, p57, p58)
	if p56.isServer then
		local v59 = p56.objectLimits[p57]
		if v59 ~= nil then
			table.removeElement(v59.objects, p58)
		end
	else
		return
	end
end
function SlotSystem.getCanAddLimitedObjects(p60, p61, p62)
	if p60.isServer then
		local v63 = p60.objectLimits[p61]
		if v63 == nil then
			return false
		else
			return #v63.objects + (p62 or 1) <= v63.limit
		end
	else
		return true
	end
end

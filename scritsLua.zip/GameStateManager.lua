GameStateManager = {}
local v_u_1 = Class(GameStateManager)
function GameStateManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.gameStateChangeListeners = {}
	v4.gameState = GameState.STARTING
	return v4
end
function GameStateManager.getGameStateIndexByName(_, p5)
	if p5 == nil then
		return nil
	end
	local v6 = p5:upper()
	return GameState[v6]
end
function GameStateManager.setGameState(p7, p8)
	if p8 ~= nil and p7.gameState ~= p8 then
		g_messageCenter:publish(MessageType.GAME_STATE_CHANGED, p8, p7.gameState)
		p7.gameState = p8
	end
end
function GameStateManager.getGameState(p9)
	return p9.gameState
end
g_gameStateManager = GameStateManager.new()

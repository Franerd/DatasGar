g_currentTest = nil
local v_u_1 = {
	["TestAnimalCluster"] = {
		["className"] = "TestAnimalCluster",
		["filename"] = "dataS/scripts/animals/husbandry/cluster/TestAnimalCluster.lua"
	},
	["TestI3DManager"] = {
		["className"] = "TestI3DManager",
		["filename"] = "dataS/scripts/i3d/TestI3DManager.lua"
	},
	["TestDebugElements"] = {
		["className"] = "TestDebugElements",
		["filename"] = "dataS/scripts/debug/TestDebugElements.lua"
	},
	["TestXML"] = {
		["className"] = "TestXML",
		["filename"] = "dataS/scripts/xml/TestXML.lua"
	},
	["TestPolygon"] = {
		["className"] = "TestPolygon",
		["filename"] = "dataS/scripts/collections/TestPolygon.lua"
	},
	["TestMathUtil"] = {
		["className"] = "TestMathUtil",
		["filename"] = "dataS/scripts/utils/TestMathUtil.lua"
	}
}
function initTesting()
	-- upvalues: (copy) v_u_1
	local v2 = StartParams.getValue("test")
	if v2 ~= nil then
		local v3 = v_u_1[v2]
		if v3 ~= nil then
			source(v3.filename)
			g_currentTest = ClassUtil.getClassObject(v3.className)
			if g_currentTest ~= nil then
				g_currentTest.init()
				Logging.info("Started test \'%s\'", v2)
				return true
			end
			Logging.error("Test \'%s\' not defined", v2)
		end
	end
	return false
end

Line3D = {}
Line3D.VISUALS_FILENAME = "data/shared/visualization/line.i3d"
local v_u_1 = Class(Line3D)
function Line3D.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.visNodes = createTransformGroup("line3DVisualizationShapes")
	link(getRootNode(), v4.visNodes)
	v4.nodeCache = NodeCache.new()
	v4.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(Line3D.VISUALS_FILENAME, false, false, Line3D.onVisualsLoaded, v4)
	return v4
end
function Line3D.onVisualsLoaded(p5, p6)
	if p6 ~= nil then
		local v7 = getChildAt(p6, 0)
		unlink(v7)
		p5.nodeCache:addTemplate(v7)
		delete(p6)
	end
end
function Line3D.delete(p8)
	if p8.visNodes ~= nil then
		delete(p8.visNodes)
		p8.visNodes = nil
	end
	if p8.nodeCache ~= nil then
		p8.nodeCache:delete()
		p8.nodeCache = nil
	end
	if p8.sharedLoadRequestId ~= nil then
		g_i3DManager:releaseSharedI3DFile(p8.sharedLoadRequestId)
		p8.sharedLoadRequestId = nil
	end
end
function Line3D.visualizeLine(p9, p10, p11, p12, p13, p14, p15, p16, p17)
	local v18 = MathUtil.vector3Length(p13 - p10, p14 - p11, p15 - p12)
	local v19 = math.round(v18)
	if v19 ~= 0 then
		local v20 = p9.nodeCache:getNodeInstance(1)
		link(p9.visNodes, v20)
		local v21 = getChildAt(v20, 0)
		setShapeBoundingSphere(v21, 0, 0, 0, 60)
		local v22, v23, v24
		if p17 == nil then
			v22 = nil
			v23 = nil
			v24 = nil
		else
			v22, v23, v24 = p17:unpack()
			setShaderParameter(v21, "emitColor", v22, v23, v24, 1, false)
		end
		local v25 = getNumOfChildren(v20)
		local v26 = getChildAt(v20, 0)
		local v27 = 0
		local v28 = nil
		local v29 = nil
		local v30 = nil
		local v31 = nil
		for v32 = 0, v19 do
			if p16 then
				v29, v31 = MathUtil.vector2Lerp(p10, p12, p13, p15, v32 / v19)
				v30 = getTerrainHeightAtWorldPos(g_terrainNode, v29, 0, v31) + 0.05
			else
				v29, v30, v31 = MathUtil.vector3Lerp(p10, p11, p12, p13, p14, p15, v32 / v19)
			end
			local v33 = getChildAt(v20, v27)
			setWorldTranslation(v33, v29, v30, v31)
			setVisibility(v33, true)
			if v28 ~= nil then
				local v34, v35, v36 = getWorldTranslation(v28)
				local v37, v38, v39 = MathUtil.vector3Normalize(v29 - v34, v30 - v35, v31 - v36)
				setDirection(v28, v37, v38, v39, 0, 1, 0)
			end
			v27 = v27 + 1
			if v25 <= v27 then
				v20 = p9.nodeCache:getNodeInstance(1)
				link(p9.visNodes, v20)
				local v40 = getChildAt(v20, 0)
				if v22 ~= nil then
					setShaderParameter(v40, "emitColor", v22, v23, v24, 1, false)
				end
				setShapeBoundingSphere(v40, 0, 0, 0, v25)
				v28 = v33
				v27 = 0
			else
				v28 = v33
			end
		end
		if v28 ~= nil and v26 ~= v28 then
			local v41, v42, v43 = getWorldTranslation(v26)
			local v44, v45, v46 = MathUtil.vector3Normalize(v41 - v29, v42 - v30, v43 - v31)
			setDirection(v28, v44, v45, v46, 0, 1, 0)
		end
		for v47 = v27, v25 - 1 do
			setVisibility(getChildAt(v20, v47), false)
		end
	end
end
function Line3D.clearVisualization(p48)
	if p48.visNodes ~= nil then
		local v49 = getNumOfChildren(p48.visNodes)
		if v49 ~= 0 then
			for v50 = v49 - 1, 0, -1 do
				local v51 = getChildAt(p48.visNodes, v50)
				unlink(v51)
				p48.nodeCache:returnNodeToCache(v51)
			end
		end
	end
end

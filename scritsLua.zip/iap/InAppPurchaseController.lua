InAppPurchaseController = {}
local v_u_1 = Class(InAppPurchaseController)
InAppPurchaseController.PENDING_DELAY = 1000
function InAppPurchaseController.new()
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3.isLoaded = false
	v3.isInitialized = false
	v3.callbacks = {}
	v3.pendingTimer = InAppPurchaseController.PENDING_DELAY
	v3.lastNumOfPendingPurchases = 0
	v3.ignoreNextPendingPurchaseChange = false
	v3.pendingProductsToRestore = {}
	v3.xmlPath = "dataS/inAppProducts.xml"
	return v3
end
function InAppPurchaseController.load(p4)
	if not p4.isLoaded then
		p4:loadProductsFromXML()
		if inAppInit ~= nil then
			inAppInit(p4.xmlPath)
		end
		p4.isLoaded = true
	end
end
function InAppPurchaseController.loadProductsFromXML(p_u_5)
	p_u_5.products = {}
	p_u_5.productIdToProduct = {}
	local v_u_6 = XMLFile.load("products", p_u_5.xmlPath)
	if v_u_6 ~= nil then
		v_u_6:iterate("inAppPurchases.inAppPurchase", function(_, p7)
			-- upvalues: (copy) v_u_6, (copy) p_u_5
			local v8 = v_u_6:getInt(p7 .. "#productId")
			if v8 == nil then
				Logging.xmlWarning(v_u_6, "Failed to load IAP Product. Missing productId. (%s)", p7)
				return
			else
				local v9 = v_u_6:getBool(p7 .. "#isConsumable", true)
				local v10 = v_u_6:getString(p7 .. ".product#className")
				if v10 == nil or v10 == "" then
					Logging.xmlWarning(v_u_6, "Failed to load IAP Product. Missing product #className (%s)", p7)
					return
				else
					local v11 = ClassUtil.getClassObject(v10)
					if v11 == nil then
						Logging.xmlWarning(v_u_6, "Failed to load IAP Product. Unknown class \'%s\'. (%s)", v10, p7)
					else
						local v12 = v11.new(v8, v9)
						if v12 ~= nil and v12:loadFromXMLFile(v_u_6, p7 .. ".product") then
							local v13 = p_u_5.products
							table.insert(v13, v12)
							p_u_5.productIdToProduct[v8] = v12
						end
					end
				end
			end
		end)
		v_u_6:delete()
	end
end
function InAppPurchaseController.setMission(p14, p15)
	p14.mission = p15
end
function InAppPurchaseController.getIsAvailable(p16)
	if p16.isInitialized then
		return true
	end
	if inAppIsLoaded == nil or not inAppIsLoaded() then
		return false
	end
	p16.isInitialized = true
	return true
end
function InAppPurchaseController.getProducts(p17)
	return p17.products
end
function InAppPurchaseController.getProductById(p18, p19)
	for v20 = 1, #p18.products do
		local v21 = p18.products[v20]
		if v21:getId() == p19 then
			return v21
		end
	end
	return nil
end
function InAppPurchaseController.purchase(p22, p23, p24)
	local v25
	if p23 == nil then
		v25 = false
	else
		v25 = p24 ~= nil
	end
	assert(v25)
	if p22.mission ~= nil then
		p22.callbacks[p23] = p24
		inAppStartPurchase(p23:getId(), "onPurchaseEnd", p22)
	end
end
function InAppPurchaseController.onPurchaseEnd(p_u_26, p_u_27, p_u_28)
	local v_u_29 = p_u_26.productIdToProduct[p_u_28]
	if p_u_27 == InAppPurchase.ERROR_OK then
		if p_u_26.mission ~= nil then
			v_u_29:onProductBought(function(p30, _)
				-- upvalues: (copy) p_u_28, (copy) p_u_26, (copy) v_u_29, (copy) p_u_27
				if p30 then
					inAppFinishPurchase(p_u_28)
					p_u_26.callbacks[v_u_29](true, false, p_u_27)
					p_u_26:onPendingPurchasesChanged(0)
				else
					p_u_26.callbacks[v_u_29](false, true, InAppPurchase.ERROR_FAILED)
					p_u_26.ignoreNextPendingPurchaseChange = true
				end
			end)
			return
		end
	else
		p_u_26.callbacks[v_u_29](false, p_u_27 == InAppPurchase.ERROR_CANCELLED, p_u_27)
	end
end
function InAppPurchaseController.getHasPendingPurchase(_, p31)
	local v32 = inAppGetNumPendingPurchases()
	local v33 = p31:getId()
	for v34 = 0, v32 - 1 do
		if inAppGetPendingPurchaseProductId(v34) == v33 then
			return true
		end
	end
	return false
end
function InAppPurchaseController.getHasAnyPendingPurchases(_)
	return inAppGetNumPendingPurchases() > 0
end
function InAppPurchaseController.checkPendingPurchasesChanged(p35)
	p35.pendingTimer = InAppPurchaseController.PENDING_DELAY
	local v36 = inAppGetNumPendingPurchases()
	if v36 ~= p35.lastNumOfPendingPurchases then
		if p35.ignoreNextPendingPurchaseChange then
			p35.ignoreNextPendingPurchaseChange = false
		else
			p35:onPendingPurchasesChanged(v36 - p35.lastNumOfPendingPurchases)
		end
		p35.lastNumOfPendingPurchases = v36
	end
end
function InAppPurchaseController.onPendingPurchasesChanged(p_u_37, p38)
	if p_u_37.pendingPurchaseCallback ~= nil then
		p_u_37.pendingPurchaseCallback()
	end
	if p38 > 0 then
		local v39 = inAppGetNumPendingPurchases()
		if v39 > 0 then
			p_u_37.pendingProductsToRestore = {}
			for v40 = v39 - p38, v39 - 1 do
				local v41 = p_u_37:getProductById((inAppGetPendingPurchaseProductId(v40)))
				if v41 ~= nil then
					local v42 = p_u_37.pendingProductsToRestore
					table.insert(v42, v41)
				end
			end
			local function v_u_50()
				-- upvalues: (copy) p_u_37, (copy) v_u_50
				if #p_u_37.pendingProductsToRestore > 0 then
					local v_u_43 = p_u_37.pendingProductsToRestore[1]
					local function v48(_, p44)
						-- upvalues: (ref) p_u_37, (copy) v_u_43, (ref) v_u_50
						if p44 then
							p_u_37:tryPerformPendingPurchase(v_u_43, function(p45, p46)
								-- upvalues: (ref) v_u_50
								local v47 = g_i18n:getText(p45 and "ui_iap_purchaseComplete" or "ui_iap_errorFailed")
								if p46 ~= nil then
									v47 = v47 .. "\n" .. p46
								end
								InfoDialog.show(v47, function()
									-- upvalues: (ref) v_u_50
									v_u_50()
								end)
							end)
						else
							v_u_50()
						end
					end
					local v49 = string.format(g_i18n:getText("ui_iap_pendingPurchaseFound"), v_u_43:getTitle())
					YesNoDialog.show(v48, p_u_37, v49)
					table.remove(p_u_37.pendingProductsToRestore, 1)
				end
			end
			v_u_50()
		end
	end
end
function InAppPurchaseController.setPendingPurchaseCallback(p51, p52)
	p51.pendingPurchaseCallback = p52
end
function InAppPurchaseController.tryPerformPendingPurchase(_, p53, p_u_54)
	local v55
	if p53 == nil then
		v55 = false
	else
		v55 = p_u_54 ~= nil
	end
	assert(v55)
	local v56 = inAppGetNumPendingPurchases()
	local v57 = p53:getId()
	for v_u_58 = 0, v56 - 1 do
		if inAppGetPendingPurchaseProductId(v_u_58) == v57 then
			p53:onProductBought(function(p59, p60)
				-- upvalues: (copy) p_u_54, (copy) v_u_58
				p_u_54(p59, p60)
				if p59 then
					inAppFinishPendingPurchase(v_u_58)
				end
			end)
			return true
		end
	end
	return false
end
function InAppPurchaseController.getHasPurchasesToRestore(_)
	return inAppHasRestorePurchases == nil and true or inAppHasRestorePurchases()
end
function InAppPurchaseController.restorePurchases(p61)
	inAppRestorePurchases("onPurchasesRestored", p61)
end
function InAppPurchaseController.onPurchasesRestored(p62, p63)
	if p63 == InAppPurchaseResponse.OK then
		InfoDialog.show(g_i18n:getText("ui_iap_purchaseRestoreCompleted"), nil, nil, DialogElement.TYPE_INFO)
	elseif p63 == InAppPurchaseResponse.PURCHASE_IN_PROGRESS then
		InfoDialog.show(g_i18n:getText("ui_iap_purchaseInProgress"), nil, nil, DialogElement.TYPE_INFO)
	else
		InfoDialog.show(g_i18n:getText("ui_iap_purchaseRestoreFailed"), nil, nil, DialogElement.TYPE_WARNING)
	end
	for v64, v65 in pairs(InAppPurchaseResponse) do
		if v65 == p63 then
			Logging.devInfo("Restored In-app purchases (%s):", v64)
		end
	end
	for v66 = 1, #p62.products do
		local v67 = p62.products[v66]
		Logging.devInfo("Product %d (%s) has been bought: %s", v67:getId(), v67:getTitle(), v67:getHasBeenBought() and "Yes" or "No")
	end
end
function InAppPurchaseController.update(p68, p69)
	if p68.isLoaded and p68.isInitialized then
		p68.pendingTimer = p68.pendingTimer - p69
		if p68.pendingTimer < 0 then
			p68:checkPendingPurchasesChanged()
		end
	end
end

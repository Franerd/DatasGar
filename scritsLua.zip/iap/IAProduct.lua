IAProduct = {}
local v_u_1 = Class(IAProduct)
function IAProduct.new(p2, p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = p4 or v_u_1
	local v6 = setmetatable({}, v5)
	v6.productId = p2
	v6.isConsumable = p3
	return v6
end
function IAProduct.loadFromXMLFile(p7, p8, p9)
	p7.imageFilename = p8:getString(p9 .. "#imageFilename")
	return true
end
function IAProduct.getId(p10)
	return p10.productId
end
function IAProduct.getPriceText(p11)
	return g_inAppPurchaseController:getIsAvailable() and (inAppGetProductPrice(p11.productId) or "Unknown") or g_i18n:getText("ui_modUnavailable")
end
function IAProduct.getTitle(p12)
	return inAppGetProductDescription(p12.productId) or "Unknown"
end
function IAProduct.getImageFilename(p13)
	return p13.imageFilename
end
function IAProduct.getHasBeenBought(p14)
	if p14.isConsumable then
		return false
	else
		return inAppGetProductPurchaseState(p14.productId) == InAppPurchasePurchaseState.PURCHASED
	end
end
function IAProduct.getDisplayItem(_)
	return nil
end
function IAProduct.onProductBought(_, p15)
	p15(true)
end

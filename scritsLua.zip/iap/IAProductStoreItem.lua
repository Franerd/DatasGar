IAProductStoreItem = {}
local v_u_1 = Class(IAProductStoreItem, IAProduct)
IAProductStoreItem.ADDITIONAL_SPECS = {}
IAProductStoreItem.ADDITIONAL_SPECS.workingWidth = true
IAProductStoreItem.COMBINED_SPECS = {}
IAProductStoreItem.COMBINED_SPECS.slots = true
function IAProductStoreItem.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = IAProduct.new(p2, p3, v_u_1)
	v4.items = {}
	v4.pendingStoreItemPurchases = {}
	return v4
end
function IAProductStoreItem.loadFromXMLFile(p_u_5, p_u_6, p7)
	if not IAProductStoreItem:superClass().loadFromXMLFile(p_u_5, p_u_6, p7) then
		return false
	end
	p_u_5.title = p_u_6:getString(p7 .. "#title")
	p_u_5.imageFilename = p_u_6:getString(p7 .. "#imageFilename")
	p_u_6:iterate(p7 .. ".item", function(_, p8)
		-- upvalues: (copy) p_u_6, (copy) p_u_5
		local v9 = p_u_6:getString(p8 .. "#xmlFilename")
		if v9 ~= nil then
			local v10 = p_u_5.items
			table.insert(v10, v9)
		end
	end)
	if #p_u_5.items ~= 0 then
		return true
	end
	Logging.xmlWarning(p_u_6, "Failed to load IAP Product. Missing xmlFilename definition. (%s)", p7)
	return false
end
function IAProductStoreItem.onVehicleBuyEvent(p11, p12)
	if p12 == BuyVehicleEvent.STATE_SUCCESS then
		if #p11.pendingStoreItemPurchases > 0 then
			g_client:getServerConnection():sendEvent(BuyVehicleEvent.new(p11.pendingStoreItemPurchases[1], false, {}, false, g_currentMission:getFarmId(), nil, nil, 0))
			table.remove(p11.pendingStoreItemPurchases, 1)
		else
			g_messageCenter:unsubscribe(BuyVehicleEvent, p11)
			p11:onProductBoughtFinished(true)
		end
	else
		p11.pendingStoreItemPurchases = {}
		local v13
		if p12 == BuyVehicleEvent.STATE_NO_SPACE then
			v13 = g_i18n:getText(ShopController.L10N_SYMBOL.WARNING_NO_SPACE)
		else
			v13 = nil
		end
		g_messageCenter:unsubscribe(BuyVehicleEvent, p11)
		p11:onProductBoughtFinished(false, v13)
		return
	end
end
function IAProductStoreItem.getIsStoreItemOfProduct(p14, p15)
	for v16 = 1, #p14.items do
		if p15.xmlFilename == p14.items[v16] then
			return true
		end
	end
	return false
end
function IAProductStoreItem.getDisplayItem(p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27)
	if p18.xmlFilename ~= p17.items[1] then
		return nil
	end
	local v28 = p18.name
	if p17.title ~= nil then
		local v29 = {}
		for v30 = 1, #p17.items do
			local v31 = g_storeManager:getItemByXMLFilename(p17.items[v30])
			if v31 ~= nil then
				local v32 = v31.name
				table.insert(v29, v32)
			end
		end
		v28 = string.format(p17.title, unpack(v29))
	end
	local v33 = {
		["name"] = p17:getId(),
		["isInAppPurchase"] = true,
		["isInAppPurchaseConsumable"] = false,
		["priceText"] = p17:getPriceText(),
		["title"] = v28,
		["brandIndex"] = p18.brandIndex,
		["imageFilename"] = p17.imageFilename or p18.imageFilename,
		["xmlFilename"] = p18.xmlFilename,
		["product"] = p17,
		["canBeRecovered"] = g_inAppPurchaseController:getHasPendingPurchase(p17)
	}
	if #p17.items > 0 then
		for v34 = 2, #p17.items do
			local v35 = g_storeManager:getItemByXMLFilename(p17.items[v34])
			local v36 = g_shopController:makeDisplayItem(v35, nil, nil, nil, true)
			if v36 ~= nil then
				for v37 = 1, #v36.attributeIconProfiles do
					local v38 = v36.attributeIconProfiles[v37]
					local v39 = g_storeManager:getSpecTypeByProfile(v38)
					if IAProductStoreItem.ADDITIONAL_SPECS[v39.name] then
						local v40 = v36.attributeIconProfiles[v37]
						table.insert(p20, v40)
						local v41 = v36.attributeValues[v37]
						table.insert(p21, v41)
					end
					if IAProductStoreItem.COMBINED_SPECS[v39.name] then
						for v42 = 1, #p20 do
							if p20[v42] == v39.profile then
								local v43 = p21[v42]
								local v44 = tonumber(v43)
								local v45 = v36.attributeValues[v37]
								local v46 = v44 + tonumber(v45)
								p21[v42] = tostring(v46)
							end
						end
					end
				end
			end
		end
	end
	return ShopDisplayItem.new(v33, p19, p20, p21, p22, p23, p24, p25, p26, p27)
end
function IAProductStoreItem.onProductBought(p47, p48)
	if g_currentMission ~= nil then
		for v49 = 1, #p47.items do
			if g_storeManager:getItemByXMLFilename(p47.items[v49]) == nil then
				Logging.error("Unable to buy IAP store item \'%s", p47.items[v49])
			else
				local v50 = p47.pendingStoreItemPurchases
				local v51 = p47.items[v49]
				table.insert(v50, v51)
			end
		end
		if #p47.pendingStoreItemPurchases > 0 then
			p47.boughtCallback = p48
			g_messageCenter:subscribe(BuyVehicleEvent, p47.onVehicleBuyEvent, p47)
			g_client:getServerConnection():sendEvent(BuyVehicleEvent.new(p47.pendingStoreItemPurchases[1], false, {}, false, g_currentMission:getFarmId(), nil, nil, 0))
			table.remove(p47.pendingStoreItemPurchases, 1)
			return
		end
	end
	p48(false)
end
function IAProductStoreItem.onProductBoughtFinished(p52, p53, p54)
	local v55 = g_currentMission
	if v55 ~= nil then
		v55:saveSavegame()
	end
	p52.boughtCallback(p53, p54)
	p52.boughtCallback = nil
end

IAProductCoins = {}
local v_u_1 = Class(IAProductCoins, IAProduct)
function IAProductCoins.new(p2, p3)
	-- upvalues: (copy) v_u_1
	return IAProduct.new(p2, p3, v_u_1)
end
function IAProductCoins.loadFromXMLFile(p4, p5, p6)
	if not IAProductCoins:superClass().loadFromXMLFile(p4, p5, p6) then
		return false
	end
	p4.coins = p5:getInt(p6 .. "#coins")
	if p4.coins ~= nil then
		return true
	end
	Logging.xmlWarning(p5, "Failed to load IAP Product. Missing coins definition. (%s)", p6)
	return false
end
function IAProductCoins.getDisplayItem(p7, _, _, _, _, _, _, _, _, _, _)
	local v8 = {
		["name"] = p7:getId(),
		["isInAppPurchase"] = true,
		["isInAppPurchaseConsumable"] = true,
		["priceText"] = p7:getPriceText(),
		["title"] = p7:getTitle(),
		["imageFilename"] = p7:getImageFilename(),
		["product"] = p7,
		["canBeRecovered"] = g_inAppPurchaseController:getHasPendingPurchase(p7)
	}
	return ShopDisplayItem.new(v8, nil, nil, nil, nil, g_i18n:getText("function_coins"), p7.productId)
end
function IAProductCoins.onProductBought(p9, p10)
	local v11 = g_currentMission
	if v11 ~= nil then
		v11:addPurchasedMoney(p9.coins)
		v11:saveSavegame()
	end
	IAProductCoins:superClass().onProductBought(p9, p10)
end

InterpolationTime = {}
local v_u_1 = Class(InterpolationTime)
function InterpolationTime.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.maxInterpolationAlpha = p2
	v5.interpolationAlpha = p2
	v5.interpolationDuration = 80
	v5.isDirty = false
	v5.lastPhysicsNetworkTime = nil
	return v5
end
function InterpolationTime.startNewPhase(p6, p7)
	p6.interpolationDuration = p7
	p6.interpolationAlpha = 0
	p6.isDirty = true
end
function InterpolationTime.startNewPhaseNetwork(p8)
	local v9 = g_client.tickDuration
	if p8.lastPhysicsNetworkTime ~= nil then
		local v10 = g_packetPhysicsNetworkTime - p8.lastPhysicsNetworkTime
		local v11 = 3 * g_client.tickDuration
		v9 = math.min(v10, v11)
	end
	p8.lastPhysicsNetworkTime = g_packetPhysicsNetworkTime
	local v12 = g_clientInterpDelay
	if p8.interpolationAlpha < 1 then
		local v13 = (1 - p8.interpolationAlpha) * p8.interpolationDuration * 0.95 + g_clientInterpDelay * 0.05
		local v14 = 3 * g_clientInterpDelay
		v12 = math.min(v13, v14)
	end
	p8.interpolationDuration = v12 + v9
	p8.interpolationAlpha = 0
	p8.isDirty = true
end
function InterpolationTime.reset(p15)
	p15.interpolationAlpha = p15.maxInterpolationAlpha
	p15.isDirty = false
end
function InterpolationTime.update(p16, p17)
	local v18 = p16.interpolationAlpha + p17 / p16.interpolationDuration
	if p16.maxInterpolationAlpha <= v18 then
		v18 = p16.maxInterpolationAlpha
		p16.isDirty = false
	end
	p16.interpolationAlpha = v18
end
function InterpolationTime.getAlpha(p19)
	return p19.interpolationAlpha
end
function InterpolationTime.isInterpolating(p20)
	return p20.interpolationAlpha < p20.maxInterpolationAlpha
end

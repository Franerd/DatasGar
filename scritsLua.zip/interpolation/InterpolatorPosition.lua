InterpolatorPosition = {}
local v_u_1 = Class(InterpolatorPosition)
function InterpolatorPosition.new(p2, p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = p5 or v_u_1
	local v7 = setmetatable({}, v6)
	v7.positionX = p2
	v7.positionY = p3
	v7.positionZ = p4
	v7.lastPositionX = p2
	v7.lastPositionY = p3
	v7.lastPositionZ = p4
	v7.targetPositionX = p2
	v7.targetPositionY = p3
	v7.targetPositionZ = p4
	return v7
end
function InterpolatorPosition.setPosition(p8, p9, p10, p11)
	p8.positionX = p9
	p8.positionY = p10
	p8.positionZ = p11
	p8.lastPositionX = p9
	p8.lastPositionY = p10
	p8.lastPositionZ = p11
	p8.targetPositionX = p9
	p8.targetPositionY = p10
	p8.targetPositionZ = p11
end
function InterpolatorPosition.setTargetPosition(p12, p13, p14, p15)
	p12.targetPositionX = p13
	p12.targetPositionY = p14
	p12.targetPositionZ = p15
	p12.lastPositionX = p12.positionX
	p12.lastPositionY = p12.positionY
	p12.lastPositionZ = p12.positionZ
end
function InterpolatorPosition.getInterpolatedValues(p16, p17)
	p16.positionX = p16.lastPositionX + p17 * (p16.targetPositionX - p16.lastPositionX)
	p16.positionY = p16.lastPositionY + p17 * (p16.targetPositionY - p16.lastPositionY)
	p16.positionZ = p16.lastPositionZ + p17 * (p16.targetPositionZ - p16.lastPositionZ)
	return p16.positionX, p16.positionY, p16.positionZ
end

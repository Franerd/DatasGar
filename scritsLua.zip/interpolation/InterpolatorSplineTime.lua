InterpolatorSplineTime = {}
local v_u_1 = Class(InterpolatorSplineTime)
function InterpolatorSplineTime.new(p2, p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = p4 or v_u_1
	local v6 = setmetatable({}, v5)
	v6.value = p2
	v6.lastValue = p2
	v6.targetValue = p2
	v6.isLooping = p3
	if not p3 then
		v6.min = 0
		v6.max = 1
	end
	return v6
end
function InterpolatorSplineTime.setValue(p7, p8)
	p7.value = p8
	p7.lastValue = p8
	p7.targetValue = p8
end
function InterpolatorSplineTime.setTargetValue(p9, p10, p11)
	if p9.isLooping then
		if p11 == 1 then
			if p10 < p9.lastValue then
				p9.lastValue = p9.lastValue - 1
			end
		elseif p9.lastValue < p10 then
			p9.lastValue = p9.lastValue + 1
		end
	end
	p9.targetValue = p9:clampValue(p10)
	p9.lastValue = p9.value
end
function InterpolatorSplineTime.getInterpolatedValue(p12, p13)
	p12.value = p12.lastValue + p13 * (p12.targetValue - p12.lastValue)
	p12.value = p12:clampValue(p12.value)
	if p12.value == p12.min or p12.value == p12.max then
		p12:setValue(p12.value)
	end
	if p12.isLooping then
		return p12.value % 1
	else
		return p12.value
	end
end
function InterpolatorSplineTime.clampValue(p14, p15)
	if p14.min ~= nil then
		local v16 = p14.min
		p15 = math.max(p15, v16)
	end
	if p14.max ~= nil then
		local v17 = p14.max
		p15 = math.min(p15, v17)
	end
	return p15
end

InterpolatorAngle = {}
local v_u_1 = Class(InterpolatorAngle)
function InterpolatorAngle.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.value = p2
	v5.lastValue = p2
	v5.targetValue = p2
	return v5
end
function InterpolatorAngle.setAngle(p6, p7)
	p6.value = p7
	p6.lastValue = p7
	p6.targetValue = p7
end
function InterpolatorAngle.setTargetAngle(p8, p9)
	local v10 = p8:clampValue(p9)
	p8.targetValue = v10
	p8.lastValue = p8.value
	if v10 - p8.value > 3.141592653589793 then
		p8.lastValue = p8.value + 6.283185307179586
	elseif v10 - p8.value < -3.141592653589793 then
		p8.lastValue = p8.value - 6.283185307179586
	end
end
function InterpolatorAngle.getInterpolatedValue(p11, p12)
	p11.value = p11.lastValue + p12 * (p11.targetValue - p11.lastValue)
	p11.value = p11:clampValue(p11.value)
	if p11.value == p11.min or p11.value == p11.max then
		p11:setAngle(p11.value)
	end
	return p11.value
end
function InterpolatorAngle.clampValue(p13, p14)
	if p13.min ~= nil then
		local v15 = p13.min
		p14 = math.max(p14, v15)
	end
	if p13.max ~= nil then
		local v16 = p13.max
		p14 = math.min(p14, v16)
	end
	return p14
end
function InterpolatorAngle.setMinMax(p17, p18, p19)
	p17.min = Utils.getNoNil(p18, p17.min)
	p17.max = Utils.getNoNil(p19, p17.max)
end

InterpolatorValue = {}
local v_u_1 = Class(InterpolatorValue)
function InterpolatorValue.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.value = p2
	v5.lastValue = p2
	v5.targetValue = p2
	return v5
end
function InterpolatorValue.setValue(p6, p7)
	p6.value = p7
	p6.lastValue = p7
	p6.targetValue = p7
end
function InterpolatorValue.setTargetValue(p8, p9)
	p8.targetValue = p8:clampValue(p9)
	p8.lastValue = p8.value
end
function InterpolatorValue.getInterpolatedValue(p10, p11)
	p10.value = p10.lastValue + p11 * (p10.targetValue - p10.lastValue)
	p10.value = p10:clampValue(p10.value)
	if p10.value == p10.min or p10.value == p10.max then
		p10:setValue(p10.value)
	end
	return p10.value
end
function InterpolatorValue.clampValue(p12, p13)
	if p12.min ~= nil then
		local v14 = p12.min
		p13 = math.max(p13, v14)
	end
	if p12.max ~= nil then
		local v15 = p12.max
		p13 = math.min(p13, v15)
	end
	return p13
end
function InterpolatorValue.setMinMax(p16, p17, p18)
	p16.min = Utils.getNoNil(p17, p16.min)
	p16.max = Utils.getNoNil(p18, p16.max)
end

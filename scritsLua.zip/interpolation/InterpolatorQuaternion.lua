InterpolatorQuaternion = {}
local v_u_1 = Class(InterpolatorQuaternion)
function InterpolatorQuaternion.new(p2, p3, p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = p6 or v_u_1
	local v8 = setmetatable({}, v7)
	v8.quaternionX = p2
	v8.quaternionY = p3
	v8.quaternionZ = p4
	v8.quaternionW = p5
	v8.lastQuaternionX = p2
	v8.lastQuaternionY = p3
	v8.lastQuaternionZ = p4
	v8.lastQuaternionW = p5
	v8.targetQuaternionX = p2
	v8.targetQuaternionY = p3
	v8.targetQuaternionZ = p4
	v8.targetQuaternionW = p5
	return v8
end
function InterpolatorQuaternion.setQuaternion(p9, p10, p11, p12, p13)
	p9.quaternionX = p10
	p9.quaternionY = p11
	p9.quaternionZ = p12
	p9.quaternionW = p13
	p9.lastQuaternionX = p10
	p9.lastQuaternionY = p11
	p9.lastQuaternionZ = p12
	p9.lastQuaternionW = p13
	p9.targetQuaternionX = p10
	p9.targetQuaternionY = p11
	p9.targetQuaternionZ = p12
	p9.targetQuaternionW = p13
end
function InterpolatorQuaternion.setTargetQuaternion(p14, p15, p16, p17, p18)
	p14.targetQuaternionX = p15
	p14.targetQuaternionY = p16
	p14.targetQuaternionZ = p17
	p14.targetQuaternionW = p18
	p14.lastQuaternionX = p14.quaternionX
	p14.lastQuaternionY = p14.quaternionY
	p14.lastQuaternionZ = p14.quaternionZ
	p14.lastQuaternionW = p14.quaternionW
end
function InterpolatorQuaternion.getInterpolatedValues(p19, p20)
	local v21, v22, v23, v24 = MathUtil.nlerpQuaternionShortestPath(p19.lastQuaternionX, p19.lastQuaternionY, p19.lastQuaternionZ, p19.lastQuaternionW, p19.targetQuaternionX, p19.targetQuaternionY, p19.targetQuaternionZ, p19.targetQuaternionW, p20)
	p19.quaternionX = v21
	p19.quaternionY = v22
	p19.quaternionZ = v23
	p19.quaternionW = v24
	return p19.quaternionX, p19.quaternionY, p19.quaternionZ, p19.quaternionW
end

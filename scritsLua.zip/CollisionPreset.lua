CollisionPreset = {}
if CollisionFlag == nil then
	printError("Cannot source \'CollisionPreset\' without \'CollisionFlag\'")
else
	local v_u_1 = {}
	local v_u_2 = {}
	local v3 = CollisionFlag.CAMERA_BLOCKING
	local v4 = CollisionFlag.GROUND_TIP_BLOCKING
	local v5 = CollisionFlag.PLACEMENT_BLOCKING
	local v6 = CollisionFlag.AI_BLOCKING
	local v7 = CollisionFlag.PRECIPITATION_BLOCKING
	local v8 = CollisionFlag.TERRAIN_DISPLACEMENT
	local v9 = CollisionFlag.ANIMAL_POSITIONING
	local v10 = CollisionFlag.ANIMAL_NAV_MESH_BLOCKING
	local v11 = CollisionFlag.TRAFFIC_VEHICLE_BLOCKING
	local v_u_12 = 4294967295 - bit32.bor(v3, v4, v5, v6, v7, v8, v9, v10, v11)
	local v13 = CollisionFlag.TERRAIN_DISPLACEMENT
	local v14 = 4294967295 - bit32.bor(v13)
	local function v23(p15, p16, p17, p18)
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		if string.upper(p15) == p15 then
			if v_u_1[p15] == nil then
				for v19, v20 in pairs(v_u_1) do
					if v20.group == p16 and v20.mask == p17 then
						Logging.error("Collision Preset %q is identical to %q", p15, v19)
						return
					end
				end
				local v21 = {
					["name"] = p15,
					["group"] = p16,
					["mask"] = p17,
					["desc"] = p18
				}
				v_u_1[p15] = v21
				local v22 = v_u_2
				table.insert(v22, v21)
				return v_u_1[p15]
			end
			Logging.error("Collision Preset name %q already defined", p15)
		else
			Logging.error("Collision Preset name needs to be all uppercase: %q", p15)
		end
	end
	CollisionPreset.VEHICLE = v23("VEHICLE", CollisionFlag.VEHICLE + CollisionFlag.CAMERA_BLOCKING, v_u_12, "Vehicle main collisions")
	CollisionPreset.VEHICLE_NO_TIP_ANY = v23("VEHICLE_NO_TIP_ANY", CollisionFlag.VEHICLE + CollisionFlag.CAMERA_BLOCKING, bitXOR(v_u_12, CollisionFlag.TERRAIN_DELTA), "Vehicle collision not colliding with terrain delta/tipany")
	CollisionPreset.EXACT_FILL_ROOT_NODE = v23("EXACT_FILL_ROOT_NODE", CollisionFlag.FILLABLE, CollisionFlag.TRIGGER, "target shape for fill triggers and raycasts")
	CollisionPreset.FILL_TRIGGER = v23("FILL_TRIGGER", CollisionFlag.TRIGGER, CollisionFlag.FILLABLE, "trigger for shapes using the FILLABLE-flag in their collision group")
	CollisionPreset.VEHICLE_TRIGGER = v23("VEHICLE_TRIGGER", CollisionFlag.TRIGGER, CollisionFlag.VEHICLE, "trigger for shapes using the VEHICLE-flag in their collision group")
	CollisionPreset.DYN_OBJECT_TRIGGER = v23("DYN_OBJECT_TRIGGER", CollisionFlag.TRIGGER, CollisionFlag.DYNAMIC_OBJECT, "trigger for shapes using the DYNAMIC_OBJECT-flag in their collision group")
	CollisionPreset.PLAYER_TRIGGER = v23("PLAYER_TRIGGER", CollisionFlag.TRIGGER, CollisionFlag.PLAYER, "trigger for player characters")
	CollisionPreset.PLAYER_VEHICLE_TRIGGER = v23("PLAYER_VEHICLE_TRIGGER", CollisionFlag.TRIGGER, CollisionFlag.PLAYER + CollisionFlag.VEHICLE, "trigger for players and vehicles")
	CollisionPreset.WOOD_TRIGGER = v23("WOOD_TRIGGER", CollisionFlag.TRIGGER, CollisionFlag.TREE, "trigger for trees/logs")
	CollisionPreset.TREE = v23("TREE", CollisionFlag.TREE + CollisionFlag.PLACEMENT_BLOCKING + CollisionFlag.AI_BLOCKING, v_u_12)
	CollisionPreset.FORK = v23("FORK", CollisionFlag.VEHICLE_FORK, v_u_12)
	CollisionPreset.PALLET_FLOOR = v23("PALLET_FLOOR", CollisionFlag.VEHICLE, bitXOR(v_u_12, CollisionFlag.VEHICLE_FORK))
	CollisionPreset.BALE = v23("BALE", CollisionFlag.DYNAMIC_OBJECT, bitXOR(v_u_12, CollisionFlag.VEHICLE_FORK))
	local v24 = CollisionPreset
	local v25 = CollisionFlag.TRAFFIC_VEHICLE + CollisionFlag.CAMERA_BLOCKING + CollisionFlag.AI_BLOCKING
	local v26 = CollisionFlag.TREE
	local v27 = CollisionFlag.VEHICLE
	local v28 = CollisionFlag.VEHICLE_FORK
	local v29 = CollisionFlag.DYNAMIC_OBJECT
	local v30 = CollisionFlag.PLAYER
	local v31 = CollisionFlag.ANIMAL
	v24.TRAFFIC_VEHICLE = v23("TRAFFIC_VEHICLE", v25, (bit32.bor(v26, v27, v28, v29, v30, v31)))
	CollisionPreset.BUILDING = v23("BUILDING", CollisionFlag.BUILDING + CollisionFlag.CAMERA_BLOCKING + CollisionFlag.AI_BLOCKING + CollisionFlag.PLACEMENT_BLOCKING + CollisionFlag.GROUND_TIP_BLOCKING, v14)
	CollisionPreset.PLACEABLE_BUILDING = v23("PLACEABLE_BUILDING", CollisionFlag.BUILDING + CollisionFlag.CAMERA_BLOCKING + CollisionFlag.AI_BLOCKING + CollisionFlag.PLACEMENT_BLOCKING, v14)
	CollisionPreset.ROAD = v23("ROAD", CollisionFlag.ROAD + CollisionFlag.CAMERA_BLOCKING + CollisionFlag.PLACEMENT_BLOCKING + CollisionFlag.GROUND_TIP_BLOCKING + CollisionFlag.AI_DRIVABLE, v14)
	CollisionPreset.WATER = v23("WATER", CollisionFlag.WATER, 1, "Collision used by water planes to make it interact with players and vehicles")
	CollisionPreset.STATIC_OBJECT = v23("STATIC_OBJECT", CollisionFlag.STATIC_OBJECT + CollisionFlag.CAMERA_BLOCKING + CollisionFlag.AI_BLOCKING + CollisionFlag.PLACEMENT_BLOCKING + CollisionFlag.GROUND_TIP_BLOCKING, v14)
	CollisionPreset.DYNAMIC_OBJECT = v23("DYNAMIC_OBJECT", CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.CAMERA_BLOCKING + CollisionFlag.AI_BLOCKING + CollisionFlag.PLACEMENT_BLOCKING + CollisionFlag.GROUND_TIP_BLOCKING, v_u_12)
	CollisionPreset.TIP_BLOCKING_COL = v23("TIP_BLOCKING_COL", CollisionFlag.GROUND_TIP_BLOCKING, 1)
	CollisionPreset.PLACEMENT_BLOCKING_COL = v23("PLACEMENT_BLOCKING_COL", CollisionFlag.PLACEMENT_BLOCKING, 1)
	CollisionPreset.ANIMAL_POSITIONING_COL = v23("ANIMAL_POSITIONING_COL", CollisionFlag.ANIMAL_POSITIONING, 1, "Collision used by animals in nav meshes to determine their y position/height")
	CollisionPreset.DEFAULT = v23("DEFAULT", 0, v_u_12)
	function CollisionPreset.exportToXML(_)
		-- upvalues: (copy) v_u_12, (copy) v_u_2
		local v32 = XMLFile.create("CollisionMaskFlags", "", "collisionMaskFlags")
		v32:addComment("collisionMaskFlags", "Warning: This file is exported from script and should not be edited manually")
		local v33 = 0
		for v34, v35, _, v36 in CollisionFlag.iteratorFlags() do
			local v37 = string.format("collisionMaskFlags.flag(%d)", v33)
			v32:setInt(v37 .. "#bit", v35)
			v32:setString(v37 .. "#name", v34)
			v32:setString(v37 .. "#desc", v36.description)
			v33 = v33 + 1
		end
		v32:addComment("collisionMaskFlags", "Warning: This file is exported from script and should not be edited manually")
		v32:setString("collisionMaskFlags.defaultMask", string.format("0x%x", v_u_12))
		local v38 = 0
		for _, v39 in ipairs(v_u_2) do
			local v40 = string.format("collisionMaskFlags.preset(%d)", v38)
			v32:setString(v40 .. "#name", v39.name)
			if v39.desc ~= nil then
				v32:setString(v40 .. "#desc", v39.desc)
			end
			local v41 = CollisionFlag.getFlagsFromMask(v39.group)
			local v42 = 0
			for _, v43 in pairs(v41) do
				v32:setString(v40 .. string.format(".group.flag(%d)#name", v42), v43.name)
				v42 = v42 + 1
			end
			local v44, _ = CollisionFlag.getFlagsFromMask(v39.mask)
			if #v44 < 10 then
				local v45 = 0
				for _, v46 in pairs(v44) do
					v32:setString(v40 .. string.format(".mask.flag(%d)#name", v45), v46.name)
					v45 = v45 + 1
				end
			else
				v32:addComment(v40, CollisionFlag.getFlagsStringFromMask(v39.mask, true))
				v32:setString(v40 .. ".mask#value", string.format("0x%x", v39.mask))
			end
			v38 = v38 + 1
		end
		v32:addComment("collisionMaskFlags", "Warning: This file is exported from script and should not be edited manually")
		v32:saveTo("shared/collisionMaskFlags.xml", true)
		v32:saveTo("../tools/editor/shared/collisionMaskFlags.xml", true)
		v32:saveTo("../tools/exporter/maya/collisionMaskFlags.xml", true)
		v32:saveTo("../tools/exporter/blender/exporter/io_export_i3d/collisionMaskFlags.xml", true)
		v32:delete()
	end
	addConsoleCommand("gsCollisionPresetsExport", "Export all collision presets to xml files", "exportToXML", CollisionPreset)
end

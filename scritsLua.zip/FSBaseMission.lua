FSBaseMission = {}
FSBaseMission.USER_STATE_LOADING = 1
FSBaseMission.USER_STATE_SYNCHRONIZING = 2
FSBaseMission.USER_STATE_CONNECTED = 3
FSBaseMission.USER_STATE_INGAME = 4
FSBaseMission.CONNECTION_LOST_DEFAULT = 0
FSBaseMission.CONNECTION_LOST_KICKED = 1
FSBaseMission.CONNECTION_LOST_BANNED = 2
FSBaseMission.LIMITED_OBJECT_TYPE_BALE = 1
FSBaseMission.INGAME_NOTIFICATION_OK = {
	0.305,
	0.521,
	0.0356,
	1
}
FSBaseMission.INGAME_NOTIFICATION_INFO = {
	1,
	1,
	1,
	1
}
FSBaseMission.INGAME_NOTIFICATION_GREATDEMAND = {
	1,
	1,
	1,
	1
}
FSBaseMission.INGAME_NOTIFICATION_CRITICAL = {
	1,
	0.305,
	0,
	1
}
FSBaseMission.RECORDING_DEVICE_CHECK_INTERVAL = 2500
local v_u_1 = math.random(900000, 1200000)
local v_u_2
if getEngineState == nil then
	v_u_2 = true
else
	v_u_2 = getEngineState()
	getEngineState = nil
end
local function v_u_3()
	openWebFile("fs2019Purchase.php?type=2", "")
end
source("dataS/scripts/events/SavegameSettingsEvent.lua")
source("dataS/scripts/events/BaseMissionFinishedLoadingEvent.lua")
source("dataS/scripts/events/BaseMissionReadyEvent.lua")
source("dataS/scripts/events/SetSplitShapesEvent.lua")
source("dataS/scripts/events/UpdateSplitShapesEvent.lua")
source("dataS/scripts/events/ConnectionRequestEvent.lua")
source("dataS/scripts/events/ConnectionRequestAnswerEvent.lua")
source("dataS/scripts/events/ChangeLoanEvent.lua")
source("dataS/scripts/events/GamePauseEvent.lua")
source("dataS/scripts/events/GamePauseRequestEvent.lua")
source("dataS/scripts/events/PlayerPermissionsEvent.lua")
source("dataS/scripts/events/FinanceStatsEvent.lua")
local v_u_4 = Class(FSBaseMission, BaseMission)
function FSBaseMission.new(p5, p6)
	-- upvalues: (copy) v_u_4
	local v7 = FSBaseMission:superClass().new(p5, p6 or v_u_4)
	g_inGameMenu:setClient(g_client)
	g_inGameMenu:setServer(g_server)
	g_shopMenu:setClient(g_client)
	g_shopMenu:setServer(g_server)
	v7.trainSystems = {}
	v7.objectsToCallOnMapFinished = {}
	v7:registerToLoadOnMapFinished(g_inGameMenu)
	v7:registerToLoadOnMapFinished(g_shopMenu)
	v7.mapDensityMapRevision = 1
	v7.mapTerrainTextureRevision = 1
	v7.mapTerrainLodTextureRevision = 1
	v7.mapSplitShapesRevision = 1
	v7.mapTipCollisionRevision = 1
	v7.mapPlacementCollisionRevision = 1
	v7.mapNavigationCollisionRevision = 1
	v7.densityMapSyncer = nil
	v7.fieldGroundSystem = FieldGroundSystem.new()
	v7.stoneSystem = StoneSystem.new()
	v7.weedSystem = WeedSystem.new()
	v7.playersToAccept = {}
	v7.playersLoading = {}
	v7.doSaveGameState = SavegameController.SAVE_STATE_NONE
	v7.currentDeviceHasNoSpace = false
	v7.dediEmptyPaused = false
	v7.userSigninPaused = false
	v7.isSynchronizingWithPlayers = false
	v7.playersSynchronizing = {}
	v7.userManager = UserManager.new(v7:getIsServer())
	v7.aiSystem = AISystem.new(v7:getIsServer(), v7)
	v7.aiJobTypeManager = AIJobTypeManager.new(v7:getIsServer())
	v7.aiMessageManager = AIMessageManager.new()
	v7.animalSystem = AnimalSystem.new(v7:getIsServer(), v7)
	v7.animalFoodSystem = AnimalFoodSystem.new(v7)
	v7.animalNameSystem = AnimalNameSystem.new(v7)
	v7.husbandrySystem = HusbandrySystem.new(v7:getIsServer(), v7)
	v7.navigationSystem = NavigationSystem.new()
	v7.worldAttributeManager = nil
	v7.wildlifeManager = nil
	v7.vineSystem = VineSystem.new(v7:getIsServer(), v7)
	v7.vehicleSaleSystem = VehicleSaleSystem.new(v7)
	v7.collectiblesSystem = CollectiblesSystem.new(v7:getIsServer())
	v7.indoorMask = IndoorMask.new(v7, v7:getIsServer())
	v7.snowSystem = SnowSystem.new(v7, v7:getIsServer())
	v7.growthSystem = GrowthSystem.new(v7, v7:getIsServer())
	v7.foliageSystem = FoliageSystem.new()
	v7.slotSystem = SlotSystem.new(v7, v7:getIsServer())
	v7.economyManager = EconomyManager.new()
	v7.treeMarkerSystem = TreeMarkerSystem.new(v7:getIsServer())
	v7.destructibleMapObjectSystem = DestructibleMapObjectSystem.new(v7, v7:getIsServer())
	v7.shipSystem = ShipSystem.new()
	v7.playerUserId = -1
	v7.playerNickname = g_gameSettings:getValue(GameSettings.SETTING.ONLINE_PRESENCE_NAME)
	v7.clientUserId = nil
	v7.terrainSize = 1
	v7.terrainDetailMapSize = 1
	v7.fruitMapSize = 1
	v7.dynamicFoliageLayers = {}
	v7.terrainDetailId = 0
	v7.mapsSplitShapeFileIds = {}
	v7.isMasterUser = false
	v7.connectionWasClosed = false
	v7.connectionWasAccepted = false
	v7.checkRecordingDeviceTimer = 0
	v7.lastRecordingDeviceState = not Platform.hasRecordingDeviceDetection
	v7.lastConstructionScreenOpenTime = -1
	v7.cameraPaths = {}
	v7.cullingWorldXZOffset = 0
	v7.cullingWorldMinY = -100
	v7.cullingWorldMaxY = 500
	v7.cullingClipDistanceThreshold1 = 150
	v7.cullingClipDistanceThreshold2 = 400
	v7.densityMapPercentageFraction = 0.7
	v7.splitShapesPercentageFraction = 0.2
	v7.restPercentageFraction = 1 - v7.densityMapPercentageFraction - v7.splitShapesPercentageFraction
	v7.doghouses = {}
	v7.tireTrackSystem = nil
	v7.liquidManureLoadingStations = {}
	v7.manureLoadingStations = {}
	v7.connectedToDedicatedServer = false
	if g_dedicatedServer == nil then
		v7.gameStatsInterval = 60000
	else
		v7.gameStatsInterval = g_dedicatedServer.gameStatsInterval
	end
	v7.gameStatsTime = 0
	v7.wasNetworkError = false
	v7.ambientSoundSystem = AmbientSoundSystem.new(g_soundPlayer)
	v7.environmentAreaSystem = EnvironmentAreaSystem.new()
	v7.reverbSystem = ReverbSystem.new(v7)
	v7.radioEvents = {}
	v7.moneyChanges = {}
	v7.introductionHelpSystem = IntroductionHelpSystem.new()
	if v7:getIsServer() and StartParams.getIsSet("debugCameraClone") then
		v7.debugCameraClone = DebugCameraClone.new(true, true)
		v7.debugCameraClone:register(false)
	end
	return v7
end
function FSBaseMission.initialize(p8)
	FSBaseMission:superClass().initialize(p8)
	g_treePlantManager:initialize()
	MoneyType.reset()
	p8.foliageBendingSystem = nil
	if Platform.supportsFoliageBending then
		p8.foliageBendingSystem = FoliageBendingSystem.new()
	end
	p8.accessHandler = AccessHandler.new()
	p8.storageSystem = StorageSystem.new(p8.accessHandler)
	p8:subscribeMessages()
	g_inGameMenu:setInGameMap(p8.hud:getIngameMap())
	g_inGameMenu:setHUD(p8.hud)
	p8.productionChainManager = ProductionChainManager.new(p8:getIsServer())
end
function FSBaseMission.delete(p9)
	p9.isExitingGame = true
	g_inGameMenu:reset()
	p9:pauseRadio()
	if p9.missionDynamicInfo ~= nil and p9.missionDynamicInfo.isMultiplayer then
		voiceChatCleanup()
	end
	if p9.mapOverlayGenerator ~= nil then
		p9.mapOverlayGenerator:delete()
	end
	if p9.receivingDensityMapEvent ~= nil then
		p9.receivingDensityMapEvent:delete()
		p9.receivingDensityMapEvent = nil
	end
	if p9.receivingSplitShapesEvent ~= nil then
		p9.receivingSplitShapesEvent:delete()
		p9.receivingSplitShapesEvent = nil
	end
	if p9.densityMapSyncer ~= nil then
		p9.densityMapSyncer:delete()
	end
	destroyLowResCollisionHandler()
	if p9.accessHandler ~= nil then
		p9.accessHandler:delete()
	end
	if p9.storageSystem ~= nil then
		p9.storageSystem:delete()
	end
	if p9.playerSystem ~= nil then
		p9.playerSystem:delete()
	end
	if p9.debugCameraClone ~= nil then
		p9.debugCameraClone:delete()
	end
	p9.growthSystem:delete()
	p9.snowSystem:delete()
	p9.indoorMask:delete()
	p9.collectiblesSystem:delete()
	p9.vehicleSaleSystem:delete()
	p9.reverbSystem:delete()
	p9.environmentAreaSystem:delete()
	p9.ambientSoundSystem:delete()
	p9.aiSystem:delete()
	p9.husbandrySystem:delete()
	p9.animalFoodSystem:delete()
	p9.animalNameSystem:delete()
	p9.animalSystem:delete()
	p9.fieldGroundSystem:delete()
	p9.stoneSystem:delete()
	p9.weedSystem:delete()
	p9.vineSystem:delete()
	p9.foliageSystem:delete()
	p9.slotSystem:delete()
	p9.aiJobTypeManager:delete()
	p9.aiMessageManager:delete()
	p9.introductionHelpSystem:delete()
	p9.navigationSystem:delete()
	p9.treeMarkerSystem:delete()
	p9.destructibleMapObjectSystem:delete()
	g_guidedTourManager:unloadMapData()
	g_farmManager:unloadMapData()
	g_helperManager:unloadMapData()
	g_npcManager:unloadMapData()
	g_farmlandManager:unloadMapData()
	g_missionManager:unloadMapData()
	g_fieldManager:unloadMapData()
	g_gameplayHintManager:unloadMapData()
	g_sprayTypeManager:unloadMapData()
	g_connectionHoseManager:unloadMapData()
	g_consumableManager:unloadMapData()
	g_densityMapHeightManager:unloadMapData()
	g_vehicleTypeManager:unloadMapData()
	g_placeableTypeManager:unloadMapData()
	g_constructionBrushTypeManager:unloadMapData()
	g_specializationManager:unloadMapData()
	g_placeableSpecializationManager:unloadMapData()
	g_treePlantManager:unloadMapData()
	g_materialManager:unloadMapData()
	g_particleSystemManager:unloadMapData()
	g_motionPathEffectManager:unloadMapData()
	g_effectManager:unloadMapData()
	g_animationManager:unloadMapData()
	g_tensionBeltManager:unloadMapData()
	g_groundTypeManager:unloadMapData()
	g_gui:unloadMapData()
	g_xmlManager:unloadMapData()
	g_debugManager:unloadMapData()
	g_noteManager:unloadMapData()
	g_fieldCourseManager:unloadMapData()
	FSBaseMission:superClass().delete(p9)
	if AIFieldWorker ~= nil then
		AIFieldWorker.deleteCollisionBox()
	end
	g_shopMenu:reset()
	FSDensityMapUtil.clearCache()
	DensityMapHeightUtil.clearCache()
	g_fillTypeManager:unloadMapData()
	g_fruitTypeManager:unloadMapData()
	g_baleManager:unloadMapData()
	g_vehicleMaterialManager:unloadMapData()
	g_licensePlateManager:unloadMapData()
	g_helpLineManager:unloadMapData()
	g_storeManager:unloadMapData()
	g_workAreaTypeManager:unloadMapData()
	g_vehicleConfigurationManager:unloadMapData()
	g_placeableConfigurationManager:unloadMapData()
	g_toolTypeManager:unloadMapData()
	g_splitShapeManager:unloadMapData()
	g_brandManager:unloadMapData()
	g_sleepManager:unloadMapData()
	if p9.productionChainManager ~= nil then
		p9.productionChainManager:unloadMapData()
	end
	if p9.tireTrackSystem ~= nil then
		p9.tireTrackSystem:delete()
	end
	if p9.foliageBendingSystem ~= nil then
		p9.foliageBendingSystem:delete()
	end
	if p9.economyManager ~= nil then
		p9.economyManager:delete()
		p9.economyManager = nil
	end
	if p9.shipSystem ~= nil then
		p9.shipSystem:delete()
		p9.shipSystem = nil
	end
	if g_soundPlayer ~= nil then
		g_soundPlayer:removeEventListener(p9)
		if not (GS_IS_CONSOLE_VERSION or GS_IS_MOBILE_VERSION) then
			g_soundPlayer:setStreamingAccessOwner(nil)
		end
	end
	removeConsoleCommand("gsMoneyAdd")
	removeConsoleCommand("gsStoreItemsExport")
	removeConsoleCommand("gsGreatDemandStart")
	removeConsoleCommand("gsTeleport")
	removeConsoleCommand("gsSaveDediXMLStatsFile")
	removeConsoleCommand("gsSaveGame")
	removeConsoleCommand("gsActivateCameraPath")
	removeConsoleCommand("gsDisplacementDebug")
	removeConsoleCommand("gsDisplacementReset")
	removeConsoleCommand("gsUnloadTriggersValidate")
	for _, v10 in pairs(p9.cameraPaths) do
		v10:delete()
	end
	if p9.wildlifeManager ~= nil then
		p9.wildlifeManager:delete()
	end
	if p9.worldAttributeManager ~= nil then
		p9.worldAttributeManager:delete()
	end
	g_gui:setClient(nil)
	g_gui:setServer(nil)
	g_inGameMenu:setInGameMap(nil)
	g_inGameMenu:setHUD(nil)
	g_inGameMenu:setPlayerFarm(nil)
	g_shopMenu:setPlayerFarm(nil)
	p9.userManager:delete()
end
function FSBaseMission.load(p11)
	p11:startLoadingTask()
	if p11:getIsServer() then
		if g_addCheatCommands then
			addConsoleCommand("gsTeleport", "Teleports to given field or x/z-position", "consoleCommandTeleport", p11, "farmlandId or xPos; [zPos]; [useWorldCoords]")
		end
		if g_addTestCommands then
			addConsoleCommand("gsStoreItemsExport", "Exports storeItem data", "consoleCommandExportStoreItems", p11)
			addConsoleCommand("gsGreatDemandStart", "Starts a great demand", "consoleStartGreatDemand", p11)
			addConsoleCommand("gsSaveDediXMLStatsFile", "Saves dedi XML stats file", "consoleCommandSaveDediXMLStatsFile", p11)
			addConsoleCommand("gsSaveGame", "Saves the current savegame", "consoleCommandSaveGame", p11)
			addConsoleCommand("gsDisplacementDebug", "Opens the displacement debug dialog", "consoleCommandDisplacementDebug", p11)
			addConsoleCommand("gsDisplacementReset", "Resets the displacement", "consoleCommandDisplacementReset", p11)
			addConsoleCommand("gsUnloadTriggersValidate", "Validate the height of unload triggers to detect if they are below the terrain", "consoleCommandValidateUnloadTriggers", p11)
			addConsoleCommand("gsRunFSDensityMapUtilBenchmark", "Runs a benchmark on FS Density Map Util", "consoleCommandRunDSDensityMapUtil", p11)
		end
	end
	if g_isDevelopmentVersion then
		addConsoleCommand("gsActivateCameraPath", "Activate camera path", "consoleActivateCameraPath", p11)
	end
	p11.economyManager:init(p11)
	FSBaseMission:superClass().load(p11)
	g_inGameMenu:setTerrainSize(p11.terrainSize)
	local v12 = Platform.gameplay.harvestScaleRation
	p11:setHarvestScaleRatio(unpack(v12))
	p11:finishLoadingTask()
end
function FSBaseMission.setHarvestScaleRatio(p13, p14, p15, p16, p17, p18, p19)
	p13.harvestSprayScaleRatio = p14
	p13.harvestPlowScaleRatio = p15
	p13.harvestLimeScaleRatio = p16
	p13.harvestWeedScaleRatio = p17
	p13.harvestStubbleScaleRatio = p18
	p13.harvestRollerRatio = p19
end
function FSBaseMission.getHarvestScaleMultiplier(p20, _, p21, p22, p23, p24, p25, p26, p27)
	return 1 + p20.harvestSprayScaleRatio * p21 + p20.harvestPlowScaleRatio * p22 + p20.harvestLimeScaleRatio * p23 + p20.harvestWeedScaleRatio * p24 + p20.harvestStubbleScaleRatio * p25 + p20.harvestRollerRatio * p26 + (p27 or 0)
end
function FSBaseMission.onStartMission(p28)
	FSBaseMission:superClass().onStartMission(p28)
	g_asyncTaskManager:setAllowedTimePerFrame(nil)
	if g_client ~= nil then
		if p28:getIsServer() then
			local v29 = g_server.clientConnections[NetworkNode.LOCAL_STREAM_ID]
			local v30 = p28.userManager:getUserByConnection(v29)
			local v31 = g_farmManager:getFarmByUserId(v30:getId())
			local v32 = FarmManager.SPECTATOR_FARM_ID
			if v31 ~= nil then
				v32 = v31.farmId
			end
			Player.createServerInstance(true, true, v29, v30:getId(), v32, p28.userManager)
			v30:setState(FSBaseMission.USER_STATE_INGAME)
		else
			g_client:getServerConnection():sendEvent(ClientStartMissionEvent.new())
		end
		if g_dedicatedServer == nil and Platform.hasAdjustableFrameLimit then
			setFramerateLimiter(true, g_gameSettings:getValue(SettingsModel.SETTING.FRAME_LIMIT))
		end
		if not g_gameSettings:getValue(GameSettings.SETTING.RADIO_VEHICLE_ONLY) then
			p28:playRadio()
		end
		g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.RADIO, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_RADIO))
		g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.VEHICLE, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_VEHICLE))
		g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.ENVIRONMENT, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_ENVIRONMENT))
		g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.GUI, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_GUI))
		g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.CHARACTER, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_CHARACTER))
	end
	if p28.missionInfo ~= nil then
		Logging.info("Savegame Setting \'dirtInterval\': %d", p28.missionInfo.dirtInterval)
		Logging.info("Savegame Setting \'snowEnabled\': %s", p28.missionInfo.isSnowEnabled)
		Logging.info("Savegame Setting \'growthMode\': %d", p28.missionInfo.growthMode)
		Logging.info("Savegame Setting \'fuelUsage\': %d", p28.missionInfo.fuelUsage)
		Logging.info("Savegame Setting \'plowingRequiredEnabled\': %s", p28.missionInfo.plowingRequiredEnabled)
		Logging.info("Savegame Setting \'weedsEnabled\': %s", p28.missionInfo.weedsEnabled)
		Logging.info("Savegame Setting \'limeRequired\': %s", p28.missionInfo.limeRequired)
		Logging.info("Savegame Setting \'stonesEnabled\': %s", p28.missionInfo.stonesEnabled)
		Logging.info("Savegame Setting \'economicDifficulty\': %s", EconomicDifficulty.getName(p28.missionInfo.economicDifficulty))
		Logging.info("Savegame Setting \'fixedSeasonalVisuals\': %s", p28.missionInfo.fixedSeasonalVisuals)
		Logging.info("Savegame Setting \'plannedDaysPerPeriod\': %s", p28.missionInfo.plannedDaysPerPeriod)
		if p28:getIsServer() then
			local v33 = p28.missionInfo.saveDate
			if v33 ~= nil then
				local v34 = getDate("%Y-%m-%d")
				local v35, v36, _ = v33:match("(%d%d%d%d)-(%d%d)-(%d%d)")
				local v37, v38, _ = v34:match("(%d%d%d%d)-(%d%d)-(%d%d)")
				local v39 = tonumber(v35)
				local v40 = tonumber(v36)
				local v41 = tonumber(v37)
				local v42 = tonumber(v38)
				if v39 ~= nil and (v40 ~= nil and (v41 ~= nil and (v42 ~= nil and (v39 < v41 or v40 <= v42)))) then
					if v42 < v40 then
						v41 = v41 - 1
						v40 = v40 - 12
					end
					local v43 = v42 - v40 + (v41 - v39) * 12
					g_achievementManager:tryUnlock("LoadedOldSavegame", v43)
				end
			end
		end
		p28.introductionHelpSystem:loadHelpElementsFromXML()
		p28.introductionHelpSystem:loadShownElements()
	end
	p28:updateGameStatsXML()
	if p28.helpIconsBase ~= nil then
		p28.helpIconsBase:showHelpIcons(g_gameSettings:getValue(GameSettings.SETTING.SHOW_HELP_ICONS))
	end
	p28:notifyPlayerFarmChanged(g_localPlayer)
	if p28.missionDynamicInfo.isMultiplayer and g_dedicatedServer == nil then
		voiceChatAddLocalUser(p28:getIsServer())
	end
	p28.slotSystem:updateSlotUsage()
end
function FSBaseMission.getClientPosition(_)
	return getWorldTranslation(g_cameraManager:getActiveCamera())
end
function FSBaseMission.getClientGuiVisibility(_)
	return g_gui:getIsGuiVisible()
end
function FSBaseMission.setLoadingScreen(p44, p45)
	p44.loadingScreen = p45
end
function FSBaseMission.onConnectionOpened(_, _) end
function FSBaseMission.onConnectionAccepted(p46, _)
	p46.connectionWasAccepted = true
	if p46.loadingScreen ~= nil then
		p46.loadingScreen:onWaitingForAccept()
	end
	local v47 = g_gameSettings:getValue(GameSettings.SETTING.MP_LANGUAGE)
	local v48 = g_gameSettings:getValue(GameSettings.SETTING.ONLINE_PRESENCE_NAME)
	g_client:getServerConnection():sendEvent(ConnectionRequestEvent.new(v47, p46.missionDynamicInfo.password, getUniqueUserId(), getUserId(), getPlatformId(), v48, p46.missionDynamicInfo.platformSessionId), nil, true)
end
function FSBaseMission.onConnectionRequest(p49, p50, p51, p52, p53, p54, p55, p56, p57)
	if p50.streamId == NetworkNode.LOCAL_STREAM_ID then
		local v58 = p49.userManager:getNextUserId()
		local v59 = v58 == 1
		assert(v59)
		p49.playerUserId = 1
		local v60 = User.new()
		v60:setId(v58)
		v60:setConnection(p50)
		v60:setUniqueUserId(p53)
		v60:setPlatformUserId(p54)
		v60:setPlatformId(p55)
		v60:setIsMasterUser(true)
		v60:setLanguageIndex(p51)
		v60:setConnectedTime(p49.time)
		v60:setState(FSBaseMission.USER_STATE_CONNECTED)
		v60:setNickname(p56)
		p49.playerNickname = p56
		local v61 = p49.playerSystem:getHasPlayerWithUniqueId(p53)
		p49.userManager:addUser(v60)
		p49.userManager:addMasterUserByConnection(p50)
		p49:sendNumPlayersToMasterServer(1)
		p50:sendEvent(ConnectionRequestAnswerEvent.new(ConnectionRequestAnswerEvent.ANSWER_OK, p49.missionInfo.economicDifficulty, p49.missionInfo.timeScale, g_dedicatedServer ~= nil, p49.playerUserId, p56, v61), nil, true)
		p49.slotSystem:updateSlotLimit()
		return
	end
	local v62 = p49.userManager:getNumberOfUsers()
	if g_dedicatedServer ~= nil then
		v62 = v62 - 1
	end
	if v62 + #p49.playersToAccept >= p49.missionDynamicInfo.capacity then
		p50:sendEvent(ConnectionRequestAnswerEvent.new(ConnectionRequestAnswerEvent.ANSWER_FULL), nil, true)
		g_server:closeConnection(p50)
		return
	end
	if getIsUserBlocked(p53, p54, p55) then
		p50:sendEvent(ConnectionRequestAnswerEvent.new(ConnectionRequestAnswerEvent.ANSWER_ALWAYS_DENIED), nil, true)
		g_server:closeConnection(p50)
		return
	end
	local v63 = p49.userManager:getUserByUniqueId(p53)
	local v64 = v63 ~= nil
	if not v64 then
		for _, v65 in ipairs(p49.playersToAccept) do
			if v65.uniqueUserId == p53 then
				v64 = true
				break
			end
		end
	end
	if v64 then
		if not Platform.isConsole then
			p50:sendEvent(ConnectionRequestAnswerEvent.new(ConnectionRequestAnswerEvent.ALREADY_IN_USE), nil, true)
			g_server:closeConnection(p50)
			return
		end
		local v66 = v63:getConnection()
		g_server:closeConnection(v66)
	end
	if p49.slotSystem:getCanConnect(p53, p55) then
		if p49.missionDynamicInfo.password == p52 then
			local v67 = p49.playersToAccept
			table.insert(v67, {
				["connection"] = p50,
				["playerName"] = p56,
				["language"] = p51,
				["platformUserId"] = p54,
				["platformId"] = p55,
				["uniqueUserId"] = p53,
				["platformSessionId"] = p57
			})
		else
			p50:sendEvent(ConnectionRequestAnswerEvent.new(ConnectionRequestAnswerEvent.ANSWER_WRONG_PASSWORD), nil, true)
			g_server:closeConnection(p50)
		end
	else
		p50:sendEvent(ConnectionRequestAnswerEvent.new(ConnectionRequestAnswerEvent.SLOT_LIMIT_REACHED), nil, true)
		g_server:closeConnection(p50)
		return
	end
end
function FSBaseMission.canPlayerChangeNickname(p68, p69, p70)
	if utf8Strlen(p70) < 3 then
		return false
	end
	local v71 = string.trim(p70)
	if v71 ~= filterText(v71, true, true) then
		return false
	end
	local v72 = p68.userManager:getUserByNickname(p70, true)
	local v73 = p70
	local v74 = 1
	while v72 ~= nil and v72.id ~= p69.userId do
		p70 = v73 .. " (" .. v74 .. ")"
		v72 = p68.userManager:getUserByNickname(p70, true)
		v74 = v74 + 1
	end
	return true, p70
end
function FSBaseMission.setPlayerNickname(p75, p76, p77, p78, p79)
	if p75:getIsServer() then
		local v80, v81 = p75:canPlayerChangeNickname(p76, p77)
		if v80 then
			local v82 = p75.userManager:getUserByUserId(p76.userId)
			v82:setNickname(v81)
			if g_localPlayer == p76 then
				p75.playerNickname = v81
			end
			g_messageCenter:publish(MessageType.PLAYER_NICKNAME_CHANGED, p76)
			local v83 = g_farmManager:getFarmByUserId(p76.userId)
			if v83 ~= nil then
				v83:updateLastNickname(p76.userId, v82)
			end
			if p79 == nil or p79 == false then
				g_server:broadcastEvent(PlayerSetNicknameEvent.new(p76, v81, p76.userId), false, nil, p76)
				return
			end
		end
	else
		if p79 == nil or p79 == false then
			g_client:getServerConnection():sendEvent(PlayerSetNicknameEvent.new(p76, p77, p76.userId))
			return
		end
		if p79 == true then
			local v84 = p75.userManager:getUserByUserId(p78)
			if v84 ~= nil then
				v84:setNickname(p77)
			end
			if g_localPlayer == p76 then
				p75.playerNickname = p77
			end
			g_messageCenter:publish(MessageType.PLAYER_NICKNAME_CHANGED, p76)
		end
	end
end
function FSBaseMission.onConnectionDenyAccept(p85, p86, p87, p88)
	local v89 = nil
	for v90 = 1, #p85.playersToAccept do
		local v91 = p85.playersToAccept[v90]
		if v91.connection == p86 then
			table.remove(p85.playersToAccept, v90)
			v89 = v91
			break
		end
	end
	if v89 == nil then
		return
	else
		local v92 = ""
		local v93 = nil
		local v94 = false
		local v95 = ConnectionRequestAnswerEvent.ANSWER_OK
		if p88 then
			setIsUserBlocked(v89.uniqueUserId, v89.platformUserId, v89.platformId, true, v89.playerName)
			g_messageCenter:publish(MessageType.BLOCK_LIST_CHANGED)
			v95 = ConnectionRequestAnswerEvent.ANSWER_ALWAYS_DENIED
		elseif p87 then
			v95 = ConnectionRequestAnswerEvent.ANSWER_DENIED
		else
			v92 = v89.playerName
			local v96 = v89.language
			local v97 = v89.uniqueUserId
			local v98 = v89.platformUserId
			local v99 = v89.platformId
			local v100 = v89.platformSessionId
			v94 = p85.playerSystem:getHasPlayerWithUniqueId(v97)
			local v101 = p85.userManager:getUserByNickname(v92, true)
			local v102 = v92
			local v103 = 1
			while v101 ~= nil do
				v92 = v102 .. " (" .. v103 .. ")"
				v101 = p85.userManager:getUserByNickname(v92, true)
				v103 = v103 + 1
			end
			local v104 = p85.time
			local v105 = math.random() * 300 + 400
			local v106 = v104 + math.floor(v105)
			v93 = User.new()
			v93:setId(p85.userManager:getNextUserId())
			v93:setNickname(v92)
			v93:setConnection(p86)
			v93:setUniqueUserId(v97)
			v93:setPlatformUserId(v98)
			v93:setPlatformId(v99)
			v93:setPlatformSessionId(v100)
			v93:setLanguageIndex(v96)
			v93:setConnectedTime(p85.time)
			v93:setState(FSBaseMission.USER_STATE_LOADING)
			v93:setFinanceUpdateSendTime(v106)
			p85.userManager:addUser(v93)
			p85:sendNumPlayersToMasterServer(p85.userManager:getNumberOfUsers())
			p85:sendPlatformSessionIdsToMasterServer(p85.userManager:getAllPlatformSessionIds())
			voiceChatAddConnection(p86.streamId, v89.uniqueUserId, v89.platformUserId, v89.platformId)
			p85.playersLoading[p86] = {
				["connection"] = p86,
				["user"] = v93
			}
			p85.slotSystem:updateSlotLimit()
		end
		local v107 = g_farmManager:getFarmForUniqueUserId(v89.uniqueUserId)
		local v108
		if v93 == nil then
			v108 = nil
		else
			v108 = v93:getId() or nil
		end
		p86:sendEvent(ConnectionRequestAnswerEvent.new(v95, p85.missionInfo.economicDifficulty, p85.missionInfo.timeScale, g_dedicatedServer ~= nil, v108, v92, v94), nil, true)
		if v95 == ConnectionRequestAnswerEvent.ANSWER_OK then
			Player.createServerInstance(g_client ~= nil, false, p86, v93:getId(), v107.farmId, p85.userManager)
		else
			g_server:closeConnection(p86)
		end
	end
end
function FSBaseMission.onConnectionRequestAnswer(p109, p110, p111, p112, p113, p114, p115, p116, p117)
	if p111 == ConnectionRequestAnswerEvent.ANSWER_OK then
		p109.missionInfo.economicDifficulty = p112
		p109.missionInfo.timeScale = p113
		p109.connectedToDedicatedServer = p114
		p109:onConnectionRequestAccepted(p110, p117)
		p109.playerUserId = p115
		p109.playerNickname = p116
	else
		p109.connectionWasClosed = true
		local v118 = g_i18n:getText("ui_serverDeniedAccess")
		if p111 == ConnectionRequestAnswerEvent.ANSWER_WRONG_PASSWORD then
			v118 = g_i18n:getText("ui_wrongPassword")
		elseif p111 == ConnectionRequestAnswerEvent.ANSWER_ALWAYS_DENIED then
			v118 = g_i18n:getText("ui_banned")
		elseif p111 == ConnectionRequestAnswerEvent.ANSWER_FULL then
			v118 = g_i18n:getText("ui_gameFull")
		elseif p111 == ConnectionRequestAnswerEvent.ALREADY_IN_USE then
			v118 = g_i18n:getText("ui_connectionLostKeyInUse")
		elseif p111 == ConnectionRequestAnswerEvent.SLOT_LIMIT_REACHED then
			v118 = g_i18n:getText("ui_serverDeniedSlotLimitReached")
		elseif p111 == ConnectionRequestAnswerEvent.MATCH_IN_PROGRESS then
			v118 = g_i18n:getText("ui_serverDeniedMatchInProgress")
		end
		InfoDialog.show(v118, p109.onConnectionRequestAnswerOk, p109)
	end
end
function FSBaseMission.onConnectionRequestAnswerOk(_)
	OnInGameMenuMenu()
	if masterServerConnectFront ~= nil then
		g_multiplayerScreen:initJoinGameScreen()
		g_gui:showGui("ConnectToMasterServerScreen")
		if g_masterServerConnection.lastBackServerIndex >= 0 then
			g_connectToMasterServerScreen:connectToBack(g_masterServerConnection.lastBackServerIndex)
			return
		end
		g_connectToMasterServerScreen:connectToFront()
	end
end
function FSBaseMission.onConnectionRequestAccepted(p119, p120, p121)
	if p119.loadingScreen ~= nil then
		p119.loadingScreen:loadWithConnection(p120, p121)
	end
end
function FSBaseMission.onConnectionRequestAcceptedLoad(p122, p123)
	p122.loadingConnection = p123
	simulatePhysics(false)
	p122:load()
end
function FSBaseMission.onFinishedLoading(p124)
	FSBaseMission:superClass().onFinishedLoading(p124)
	local v125 = p124.loadingConnection
	if p124:getIsServer() then
		p124.pressStartPaused = true
		p124:pauseGame()
		if p124.loadingScreen ~= nil then
			p124.loadingScreen:onFinishedReceivingDynamicData()
		end
	else
		g_cameraManager:setDefaultCamera()
		local v126, v127, v128 = p124:getClientPosition()
		if p124.loadingScreen ~= nil then
			p124.loadingScreen:onWaitingForDynamicData()
		end
		p124.pressStartPaused = true
		p124:pauseGame()
		v125:sendEvent(BaseMissionFinishedLoadingEvent.new(v126, v127, v128, getViewDistanceCoeff()), nil, true)
	end
end
function FSBaseMission.getAllowsGuiDisplay(p129)
	if p129.isSynchronizingWithPlayers and g_localPlayer ~= nil then
		return false
	else
		return not g_sleepManager:getIsSleeping()
	end
end
function FSBaseMission.onConnectionFinishedLoading(p130, p131, p132, p133, p134, p135)
	local v136 = not p131:getIsLocal()
	assert(v136, "No local connection allowed in BaseMission:onConnectionFinishedLoading")
	if p130.playersSynchronizing[p131] == nil and p130.playersLoading[p131] ~= nil then
		local v137 = p130.playersLoading[p131].user
		p130.playersLoading[p131] = nil
		addSplitShapeConnection(p131.streamId, v137:getPlatformId())
		if p130.densityMapSyncer ~= nil then
			p130.densityMapSyncer:addConnection(p131.streamId)
		end
		addTerrainUpdateConnection(g_terrainNode, p131.streamId)
		p131:setIsReadyForEvents(true)
		v137:setState(FSBaseMission.USER_STATE_SYNCHRONIZING)
		local v138 = {
			["connection"] = p131,
			["user"] = v137
		}
		p130.playersSynchronizing[p131] = v138
		if g_dedicatedServer ~= nil then
			g_dedicatedServer:raiseFramerate()
			p130.dediEmptyPaused = false
		end
		p130.isSynchronizingWithPlayers = true
		p130:pauseGame()
		g_farmManager:playerJoinedGame(v137:getUniqueUserId(), v137:getId(), v137, p131)
		g_server:sendEventIds(p131)
		g_server:sendObjectClassIds(p131)
		p131:sendEvent(OnCreateLoadedObjectEvent.new())
		p131:sendEvent(PlaceablePreplacedInfoEvent.new())
		g_server:sendObjects(p131, p132, p133, p134, p135)
		p131:sendEvent(SavegameSettingsEvent.new())
		p131:sendEvent(SlotSystemUpdateEvent.new(p130.slotSystem.slotLimit))
		p130:sendInitialClientState(p131, v137, (g_farmManager:getFarmForUniqueUserId(v137:getUniqueUserId())))
		g_server:broadcastEvent(UserEvent.new(p130.userManager:getUsers(), {}, p130.missionDynamicInfo.capacity))
		local v139 = SetSplitShapesEvent.new()
		v138.splitShapesEvent = v139
		p131:sendEvent(v139, false)
	else
		g_server:closeConnection(p131)
	end
end
function FSBaseMission.sendInitialClientState(p140, p141, p142, p143)
	p141:sendEvent(EnvironmentTimeEvent.new(p140.environment.currentMonotonicDay, p140.environment.currentDay, p140.environment.dayTime, p140.environment.daysPerPeriod))
	p140.environment.weather:sendInitialState(p141)
	p141:sendEvent(FarmsInitialStateEvent.new(p143.farmId))
	if p143.farmId ~= 0 then
		p141:sendEvent(ChangeLoanEvent.new(p143.loan, p143.farmId))
		for v144 = 0, 4 do
			p141:sendEvent(FinanceStatsEvent.new(v144, p143.farmId))
		end
		p142:setFinancesVersionCounter(p143.stats.financesVersionCounter)
	end
	p141:sendEvent(FarmlandInitialStateEvent.new())
	p141:sendEvent(GreatDemandsEvent.new(p140.economyManager.greatDemands))
	p141:sendEvent(PricingHistoryInitialEvent.new())
	p140.vehicleSaleSystem:sendAllToClient(p141)
	p140.collectiblesSystem:onClientJoined(p141)
	p140.aiSystem:onClientJoined(p141)
	p140.destructibleMapObjectSystem:onClientJoined(p141)
	p140.treeMarkerSystem:onClientJoined(p141)
end
function FSBaseMission.onSplitShapesProgress(p145, p146, p147)
	if p147 >= 1 and p145:getIsServer() then
		local v148 = p145.playersSynchronizing[p146]
		if v148 ~= nil then
			if v148.splitShapesEvent ~= nil then
				v148.splitShapesEvent:delete()
				v148.splitShapesEvent = nil
			end
			p146:sendEvent(BaseMissionReadyEvent.new(), nil, true)
		end
	end
end
function FSBaseMission.onFinishedReceivingDynamicData(p149, p150)
	if p149.loadingScreen ~= nil then
		p149.loadingScreen:onFinishedReceivingDynamicData()
		p150:sendEvent(BaseMissionReadyEvent.new(), nil, true)
	end
end
function FSBaseMission.onConnectionReady(p151, p152)
	local v153 = p151.playersSynchronizing[p152]
	if v153 == nil then
		g_server:closeConnection(p152)
	else
		if v153.densityMapEvent ~= nil then
			v153.densityMapEvent:delete()
			v153.densityMapEvent = nil
		end
		if v153.splitShapesEvent ~= nil then
			v153.splitShapesEvent:delete()
			v153.splitShapesEvent = nil
		end
		p152:setIsReadyForObjects(true)
		v153.user:setState(FSBaseMission.USER_STATE_CONNECTED)
		p151.playersSynchronizing[p152] = nil
		if next(p151.playersSynchronizing) == nil then
			p151.isSynchronizingWithPlayers = false
			p151:tryUnpauseGame()
			p151:showPauseDisplay(p151.paused)
		end
	end
end
function FSBaseMission.onConnectionClosed(p154, p155)
	if p154:getIsServer() then
		removeSplitShapeConnection(p155.streamId)
		if p154.densityMapSyncer ~= nil then
			p154.densityMapSyncer:removeConnection(p155.streamId)
		end
		removeTerrainUpdateConnection(g_terrainNode, p155.streamId)
		for v156 = 1, #p154.playersToAccept do
			if p154.playersToAccept[v156].connection == p155 then
				table.remove(p154.playersToAccept, v156)
				break
			end
		end
		p154.playersLoading[p155] = nil
		local v157 = p154.userManager:getUserByConnection(p155)
		if v157 ~= nil then
			g_farmManager:playerQuitGame(v157:getId())
		end
		p154.userManager:removeUserByConnection(p155)
		voiceChatRemoveConnection(p155.streamId)
		local v158 = p154.playersSynchronizing[p155]
		if v158 ~= nil then
			if v158.densityMapEvent ~= nil then
				v158.densityMapEvent:delete()
			end
			if v158.splitShapesEvent ~= nil then
				v158.splitShapesEvent:delete()
			end
			p154.playersSynchronizing[p155] = nil
			if next(p154.playersSynchronizing) == nil then
				p154.isSynchronizingWithPlayers = false
				p154:tryUnpauseGame()
				p154:showPauseDisplay(p154.paused)
			end
		end
		if p154.connectionsToPlayer[p155] ~= nil then
			p154.connectionsToPlayer[p155]:delete()
			p154.connectionsToPlayer[p155] = nil
		end
		local v159 = p154.userManager:getNumberOfUsers()
		p154:sendNumPlayersToMasterServer(v159)
		p154:sendPlatformSessionIdsToMasterServer(p154.userManager:getAllPlatformSessionIds())
		g_server:broadcastEvent(UserEvent.new({}, { v157 }, p154.missionDynamicInfo.capacity))
		p154.slotSystem:updateSlotLimit()
		if v159 == 1 and g_dedicatedServer ~= nil then
			g_dedicatedServer:lowerFramerate()
			if g_dedicatedServer.pauseGameIfEmpty then
				p154.dediEmptyPaused = true
				p154:pauseGame()
			end
		end
	else
		if p154.receivingDensityMapEvent ~= nil then
			p154.receivingDensityMapEvent:delete()
			p154.receivingDensityMapEvent = nil
		end
		if p154.receivingSplitShapesEvent ~= nil then
			p154.receivingSplitShapesEvent:delete()
			p154.receivingSplitShapesEvent = nil
		end
		p154:pauseGame()
		if not p154.connectionWasClosed then
			p154.isSynchronizingWithPlayers = false
			p154.connectionWasClosed = true
			setPresenceMode(PresenceModes.PRESENCE_IDLE)
			if p154.cleanServerShutDown == nil or not p154.cleanServerShutDown then
				local v160 = g_i18n:getText("ui_failedToConnectToGame")
				if p154.connectionWasAccepted then
					if p154.connectionLostState == FSBaseMission.CONNECTION_LOST_KICKED then
						v160 = g_i18n:getText("ui_connectionLostKicked")
					elseif p154.connectionLostState == FSBaseMission.CONNECTION_LOST_BANNED then
						v160 = g_i18n:getText("ui_connectionLostBanned")
					else
						v160 = g_i18n:getText("ui_connectionLost")
					end
				end
				if g_gui:getIsGuiVisible() and g_gui.currentGuiName == "ChatDialog" then
					g_gui:showGui("")
				end
				InfoDialog.show(v160, OnInGameMenuMenu)
			end
			p154.cleanServerShutDown = false
			p154.connectionLostState = nil
			return
		end
	end
end
function FSBaseMission.cancelPlayersSynchronizing(p161)
	for v162, _ in pairs(p161.playersSynchronizing) do
		g_server:closeConnection(v162)
	end
end
function FSBaseMission.onConnectionsUpdateTick(p163, p164)
	if p163:getIsServer() and #g_server.clients > 0 then
		prepareSplitShapesServerWriteUpdateStream(p164)
		if startWriteSplitShapesServerEvents() then
			for v165, v166 in pairs(g_server.clientConnections) do
				if v165 ~= NetworkNode.LOCAL_STREAM_ID then
					v166:sendEvent(UpdateSplitShapesEvent.new())
				end
			end
			finishWriteSplitShapesServerEvents()
		end
	end
end
function FSBaseMission.onConnectionWriteUpdateStream(p167, p168, p169, p170)
	if not p168:getIsServer() then
		local v171 = p169 * 0.3
		local v172 = p169 * 0.2
		local v173 = p169 * 0.2
		local v174, v175, v176 = g_server:getClientPosition(p168.streamId)
		local v177 = g_server:getClientClipDistCoeff(p168.streamId)
		local v178 = streamGetWriteOffset(p168.streamId)
		if p170 then
			streamWriteInt32(p168.streamId, 0)
		end
		writeSplitShapesServerUpdateToStream(p168.streamId, p168.streamId, v174, v175, v176, v177, v171)
		local v179 = streamGetWriteOffset(p168.streamId)
		local v180 = v179 - v178
		local v181 = v171 - v180
		local v182 = math.max(v181, 0)
		g_server:addPacketSize(p168, NetworkNode.PACKET_SPLITSHAPES, v180 / 8)
		if p170 then
			streamSetWriteOffset(p168.streamId, v178)
			streamWriteInt32(p168.streamId, v179 - (v178 + 32))
			streamSetWriteOffset(p168.streamId, v179)
		end
		if p167.densityMapSyncer ~= nil then
			local v183 = v172 + v182
			local v184 = v183 - p167.densityMapSyncer:writeUpdateStream(p168, v183, v174, v175, v176, v177, p170)
			v182 = math.max(v184, 0)
		end
		local v185 = streamGetWriteOffset(p168.streamId)
		if p170 then
			streamWriteInt32(p168.streamId, 0)
		end
		local v186 = v173 + v182
		writeTerrainUpdateStream(g_terrainNode, p168.streamId, p168.streamId, v186, v174, v175, v176)
		local v187 = streamGetWriteOffset(p168.streamId)
		local v188 = v187 - v185
		g_server:addPacketSize(p168, NetworkNode.PACKET_TERRAIN_DEFORM, v188 / 8)
		if p170 then
			streamSetWriteOffset(p168.streamId, v185)
			streamWriteInt32(p168.streamId, v187 - (v185 + 32))
			streamSetWriteOffset(p168.streamId, v187)
		end
		local v189 = streamGetWriteOffset(p168.streamId)
		if p170 then
			streamWriteInt32(p168.streamId, 0)
		end
		voiceChatWriteServerUpdateToStream(p168.streamId, p168.streamId, p168.lastSeqSent)
		local v190 = streamGetWriteOffset(p168.streamId)
		local v191 = v190 - v189
		g_server:addPacketSize(p168, NetworkNode.PACKET_VOICE_CHAT, v191 / 8)
		if p170 then
			streamSetWriteOffset(p168.streamId, v189)
			streamWriteInt32(p168.streamId, v190 - (v189 + 32))
			streamSetWriteOffset(p168.streamId, v190)
		end
	end
end
function FSBaseMission.onConnectionReadUpdateStream(p192, p193, p194)
	if p193:getIsServer() then
		local v195, v196
		if p194 then
			v195 = streamGetReadOffset(p193.streamId)
			v196 = streamReadInt32(p193.streamId)
		else
			v196 = 0
			v195 = 0
		end
		readSplitShapesServerUpdateFromStream(p193.streamId, g_clientInterpDelay, g_packetPhysicsNetworkTime, g_client.tickDuration)
		if p194 then
			g_client:checkObjectUpdateDebugReadSize(p193.streamId, v196, v195, "splitshape")
		end
		if p192.densityMapSyncer ~= nil then
			p192.densityMapSyncer:readUpdateStream(p193, p194)
		end
		local v197, v198
		if p194 then
			v197 = streamGetReadOffset(p193.streamId)
			v198 = streamReadInt32(p193.streamId)
		else
			v198 = 0
			v197 = 0
		end
		readTerrainUpdateStream(g_terrainNode, p193.streamId)
		if p194 then
			g_client:checkObjectUpdateDebugReadSize(p193.streamId, v198, v197, "terrainmods")
		end
		local v199, v200
		if p194 then
			v199 = streamGetReadOffset(p193.streamId)
			v200 = streamReadInt32(p193.streamId)
		else
			v200 = 0
			v199 = 0
		end
		voiceChatReadServerUpdateFromStream(p193.streamId, g_clientInterpDelay, p193.lastSeqSent)
		if p194 then
			g_client:checkObjectUpdateDebugReadSize(p193.streamId, v200, v199, "voicechat")
		end
	end
end
function FSBaseMission.onFinishedClientsWriteUpdateStream(_) end
function FSBaseMission.onConnectionPacketSent(_, _, p201)
	voiceChatNotifyPacketSent(p201)
end
function FSBaseMission.onConnectionPacketLost(p202, p203, p204)
	voiceChatNotifyPacketLost(p204)
	if not p203:getIsServer() and p202.densityMapSyncer ~= nil then
		p202.densityMapSyncer:onPacketLost(p203, p204)
	end
end
function FSBaseMission.onShutdownEvent(p205, p206)
	if p205:getIsServer() then
		local v207 = p205.userManager:getUserByConnection(p206)
		p205.userManager:removeUserByConnection(p206)
		voiceChatRemoveConnection(p206.streamId)
		p205:sendNumPlayersToMasterServer(p205.userManager:getNumberOfUsers())
		p205:sendPlatformSessionIdsToMasterServer(p205.userManager:getAllPlatformSessionIds())
		g_server:broadcastEvent(UserEvent.new({}, { v207 }, p205.missionDynamicInfo.capacity))
	else
		g_gui:closeAllDialogs()
		p205.cleanServerShutDown = true
		setPresenceMode(PresenceModes.PRESENCE_IDLE)
		InfoDialog.show(g_i18n:getText("ui_serverWasShutdown"), p205.onShutdownEventOk, p205)
	end
end
function FSBaseMission.onShutdownEventOk(_)
	OnInGameMenuMenu()
end
function FSBaseMission.onMasterServerConnectionReady(_) end
function FSBaseMission.onMasterServerConnectionFailed(p208, p209)
	if p208.isMissionStarted then
		g_gui:showGui("InGameMenu")
		g_inGameMenu:setMasterServerConnectionFailed(p209)
	else
		OnInGameMenuMenu(false, true)
	end
end
function FSBaseMission.getServerUserId(_)
	return 1
end
function FSBaseMission.getFarmId(p210, p211)
	if p210:getIsServer() then
		if g_localPlayer == nil or p211 ~= nil then
			if p211 == nil then
				return nil
			else
				local v212 = p210:getPlayerByConnection(p211)
				if v212 == nil then
					return nil
				else
					return v212.farmId
				end
			end
		else
			return g_localPlayer.farmId
		end
	else
		return g_localPlayer == nil and 0 or g_localPlayer.farmId
	end
end
function FSBaseMission.farmStats(_, p213)
	if p213 == nil then
		p213 = g_localPlayer.farmId
	end
	local v214 = g_farmManager:getFarmById(p213)
	if v214 ~= nil then
		return v214.stats
	end
	printError("Error: Farm not found for stats")
	return FarmStats.new()
end
function FSBaseMission.getPlayerByConnection(p215, p216)
	return p215.connectionsToPlayer[p216]
end
function FSBaseMission.kickUser(p217, p218)
	assert(p217:getIsServer())
	local v219 = p218:getConnection()
	v219:sendEvent(KickBanNotificationEvent.new(true))
	g_server:closeConnection(v219)
end
function FSBaseMission.banUser(p220, p221)
	p221:block()
	if p220:getIsServer() then
		local v222 = p221:getConnection()
		v222:sendEvent(KickBanNotificationEvent.new(false))
		g_server:closeConnection(v222)
	end
end
function FSBaseMission.getObjectByUniqueId(p223, p224)
	local v225 = p223.vehicleSystem:getVehicleByUniqueId(p224)
	if v225 == nil then
		local v226 = p223.placeableSystem:getPlaceableByUniqueId(p224)
		if v226 == nil then
			local v227 = p223.itemSystem:getItemByUniqueId(p224)
			if v227 == nil then
				local v228 = p223.handToolSystem:getHandToolByUniqueId(p224)
				if v228 == nil then
					local v229 = p223.handToolSystem:getHandToolHolderByUniqueId(p224)
					if v229 == nil then
						local v230 = p223.playerSystem:getPlayerByUniqueId(p224)
						if v230 == nil then
							return nil
						else
							return v230
						end
					else
						return v229
					end
				else
					return v228
				end
			else
				return v227
			end
		else
			return v226
		end
	else
		return v225
	end
end
function FSBaseMission.onObjectCreated(p231, p232)
	FSBaseMission:superClass().onObjectCreated(p231, p232)
	if p231.slotSystem:getIsCountableObject(p232) then
		p231.slotSystem:updateSlotUsage()
	end
end
function FSBaseMission.onObjectDeleted(p233, p234)
	FSBaseMission:superClass().onObjectDeleted(p233, p234)
	if p233.slotSystem:getIsCountableObject(p234) then
		p233.slotSystem:updateSlotUsage()
	end
end
function FSBaseMission.addOwnedItem(p235, p236)
	FSBaseMission:superClass().addOwnedItem(p235, p236)
	local v237 = g_localPlayer ~= nil and g_localPlayer.farmId or AccessHandler.EVERYONE
	g_shopController:setOwnedFarmItems(p235.ownedItems, v237)
end
function FSBaseMission.removeOwnedItem(p238, p239)
	FSBaseMission:superClass().removeOwnedItem(p238, p239)
	local v240 = g_localPlayer ~= nil and g_localPlayer.farmId or AccessHandler.EVERYONE
	g_shopController:setOwnedFarmItems(p238.ownedItems, v240)
end
function FSBaseMission.addLeasedItem(p241, p242)
	FSBaseMission:superClass().addLeasedItem(p241, p242)
	local v243 = g_localPlayer ~= nil and g_localPlayer.farmId or AccessHandler.EVERYONE
	g_shopController:setLeasedFarmItems(p241.leasedItems, v243)
end
function FSBaseMission.removeLeasedItem(p244, p245)
	FSBaseMission:superClass().removeLeasedItem(p244, p245)
	local v246 = g_localPlayer ~= nil and g_localPlayer.farmId or AccessHandler.EVERYONE
	g_shopController:setLeasedFarmItems(p244.leasedItems, v246)
end
function FSBaseMission.loadMap(p247, p248, p249, p250, p251, p252)
	local v253 = p247.missionInfo.mapsSplitShapeFileIds == nil and -1 or Utils.getNoNil(p247.missionInfo.mapsSplitShapeFileIds[#p247.mapsSplitShapeFileIds + 1], -1)
	setSplitShapesLoadingFileId(v253)
	local v254 = setSplitShapesNextFileId()
	local v255 = p247.mapsSplitShapeFileIds
	table.insert(v255, v254)
	FSBaseMission:superClass().loadMap(p247, p248, p249, p250, p251, p252)
end
function FSBaseMission.registerToLoadOnMapFinished(p256, p257)
	local v258 = p256.objectsToCallOnMapFinished
	table.insert(v258, p257)
end
function FSBaseMission.loadMapFinished(p_u_259, p260, p261, p262, p263)
	local v264 = startFrameRepeatMode()
	FSBaseMission:superClass().loadMapFinished(p_u_259, p260, p261, p262, false)
	local v265 = p262.asyncCallbackFunction
	local v266 = p262.asyncCallbackObject
	local v267 = p262.asyncCallbackArguments
	if not p_u_259.missionDynamicInfo.isMultiplayer and (p_u_259.trafficSystem ~= nil and (p_u_259.trafficSystem.trafficSystemId ~= nil and (p_u_259.pedestrianSystem ~= nil and p_u_259.pedestrianSystem.pedestrianSystemId ~= nil))) then
		setPedestrianSystemTrafficSystem(p_u_259.pedestrianSystem.pedestrianSystemId, p_u_259.trafficSystem.trafficSystemId)
	end
	if g_dedicatedServer == nil then
		p_u_259.mapOverlayGenerator = MapOverlayGenerator.new(g_i18n, g_fruitTypeManager, g_fillTypeManager, g_farmlandManager, g_farmManager, p_u_259.weedSystem)
		p_u_259.mapOverlayGenerator:setColorBlindMode(Utils.getNoNil(g_gameSettings:getValue(GameSettings.SETTING.USE_COLORBLIND_MODE), false))
		p_u_259.mapOverlayGenerator:setFieldColor(p_u_259.mapFieldColor, p_u_259.mapGrassFieldColor)
	end
	if p260 ~= 0 then
		local v268 = 0
		for v269 = 0, getNumOfChildren(p260) - 1 do
			local v270 = getChildAt(p260, v269)
			if getHasClassId(v270, ClassIds.TERRAIN_TRANSFORM_GROUP) then
				v268 = v270
				break
			end
		end
		if v268 ~= 0 then
			p_u_259:initTerrain(v268, p262.filename)
		end
	end
	if p_u_259.trafficSystem ~= nil and (p_u_259.trafficSystem.trafficSystemId ~= nil and (p_u_259.aiSystem ~= nil and p_u_259.aiSystem.navigationMap ~= nil)) then
		setTrafficSystemVehicleNavigationMap(p_u_259.trafficSystem.trafficSystemId, p_u_259.aiSystem.navigationMap)
		setVehicleNavigationMapTrafficSystem(p_u_259.aiSystem.navigationMap, p_u_259.trafficSystem.trafficSystemId)
	end
	if (p263 == nil or p263) and v265 ~= nil then
		v265(v266, p260, v267)
	end
	if v264 then
		endFrameRepeatMode()
	end
	if not p_u_259.cancelLoading then
		if g_dedicatedServer == nil then
			p_u_259.worldAttributeManager = WorldAttributeManager.new(p_u_259, p_u_259.environmentAreaSystem, p_u_259.aiSystem, p_u_259.placeableSystem, p_u_259.mapWidth, p_u_259.mapHeight)
			p_u_259.wildlifeManager = WildlifeManager.new(p_u_259.worldAttributeManager)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_259
				p_u_259.wildlifeManager:loadMapData(p_u_259.xmlFile, p_u_259.baseDirectory)
			end)
		end
		for _, v271 in pairs(p_u_259.objectsToCallOnMapFinished) do
			v271:onLoadMapFinished()
		end
		g_inGameMenu:setManureTriggers(p_u_259.manureLoadingStations, p_u_259.liquidManureLoadingStations)
		g_inGameMenu:setConnectedUsers(p_u_259.userManager:getUsers())
	end
	p_u_259.objectsToCallOnMapFinished = {}
end
function FSBaseMission.initTerrain(p272, p273, p274)
	local v275 = p272.missionDynamicInfo.isMultiplayer
	p272.terrainRootNode = p273
	g_terrainNode = p273
	local v276 = getCollisionFilterMask(p273)
	local v277
	if CollisionFlag.getHasGroupFlagSet(p273, CollisionFlag.TERRAIN) then
		v277 = v276
	else
		v277 = bitOR(v276, CollisionFlag.TERRAIN)
		Logging.warning("Missing collision mask bit \'%d\'. Automatically added bit to terrain node \'%s\'", CollisionFlag.getBit(CollisionFlag.TERRAIN), getName(p273))
	end
	if CollisionFlag.getHasGroupFlagSet(p273, CollisionFlag.AI_BLOCKING) then
		v277 = bitAND(v277, bitNOT(CollisionFlag.AI_BLOCKING))
		Logging.warning("Terrain node \'%s\' has bit \'%d\' activated. Automatically removed this bit from collision mask", getName(p273), CollisionFlag.getBit(CollisionFlag.AI_BLOCKING))
	end
	if v276 ~= v277 then
		setCollisionFilterMask(p273, v277)
	end
	p272.terrainSize = getTerrainSize(p273)
	g_inGameMenu:setTerrainSize(p272.terrainSize)
	local v278 = CollisionFlag.STATIC_OBJECT + CollisionFlag.TREE + CollisionFlag.BUILDING + CollisionFlag.PRECIPITATION_BLOCKING + CollisionFlag.DYNAMIC_OBJECT + CollisionFlag.WATER
	createLowResCollisionHandler(Platform.lowResCollisionHandlerGridSize, Platform.lowResCollisionHandlerGridSize, 1, v278, Platform.lowResCollisionHandlerCellRaysPerFrame, v278, 5)
	addLowResCollisionHandlerLOD(2, Platform.lowResCollisionHandlerCellRaysPerFrame / 2)
	addLowResCollisionHandlerLOD(2, Platform.lowResCollisionHandlerCellRaysPerFrame / 2)
	setLowResCollisionHandlerTerrainRootNode(p273)
	local v279, v280, v281 = getWorldTranslation(p273)
	if math.abs(v279) > 0.1 or (math.abs(v281) > 0.1 or v280 < 0) then
		printWarning("Warning: the terrain node needs to be a x=0 and z=0 and y >= 0")
	end
	p272.areaCompressionParams = NetworkUtil.createWorldPositionCompressionParams(p272.terrainSize, 0.5 * p272.terrainSize, 0.02)
	p272.areaRelativeCompressionParams = NetworkUtil.createWorldPositionCompressionParams(100, 50, 0.02)
	p272.vehicleXZPosCompressionParams = NetworkUtil.createWorldPositionCompressionParams(p272.terrainSize + 500, 0.5 * (p272.terrainSize + 500), 0.005)
	p272.vehicleYPosCompressionParams = NetworkUtil.createWorldPositionCompressionParams(1500, 0, 0.005)
	p272.vehicleXZPosHighPrecisionCompressionParams = NetworkUtil.createWorldPositionCompressionParams(p272.terrainSize + 500, 0.5 * (p272.terrainSize + 500), 0.0001)
	p272.vehicleYPosHighPrecisionCompressionParams = NetworkUtil.createWorldPositionCompressionParams(1500, 0, 0.0001)
	setSplitShapesWorldCompressionParams(p272.terrainSize, 0.5 * p272.terrainSize, 0.005, 1700, 200, 0.005, p272.terrainSize, 0.5 * p272.terrainSize, 0.005)
	local v282 = 0.5 * p272.terrainSize + p272.cullingWorldXZOffset
	local v283 = p272.cullingWorldMinY
	local v284 = p272.cullingWorldMaxY
	local v285 = p272.cullingClipDistanceThreshold1
	local v286 = p272.cullingClipDistanceThreshold2
	setAudioCullingWorldProperties(-v282, v283, -v282, v282, v284, v282, 16, v285, v286)
	setLightCullingWorldProperties(-v282, v283, -v282, v282, v284, v282, 16, v285, v286)
	setShapeCullingWorldProperties(-v282, v283, -v282, v282, v284, v282, 64, v285, v286)
	local v287 = getFoliageViewDistanceCoeff()
	local v288, v289 = getTerrainLodBlendDynamicDistances(p273)
	setTerrainLodBlendDynamicDistances(p273, v288 * v287, v289 * v287)
	setGroundFogTerrainEntityId(p273)
	if p272.foliageBendingSystem then
		p272.foliageBendingSystem:setTerrainTransformGroup(p273)
	end
	local v290, _ = getTerrainDataPlaneByName(p273, "terrainDetail")
	p272.terrainDetailId = v290
	if p272.terrainDetailId ~= 0 then
		p272.terrainDetailMapSize = getDensityMapSize(p272.terrainDetailId)
	end
	p272.fieldGroundSystem:initTerrain(p272, p273, p272.terrainDetailId)
	p272.stoneSystem:initTerrain(p272, p273, p272.terrainDetailId)
	p272.weedSystem:initTerrain(p272, p273, p272.terrainDetailId)
	p272.vineSystem:initTerrain(p272.terrainSize, p272.terrainDetailMapSize)
	p272.foliageSystem:initTerrain(p272, p273, p272.terrainDetailId)
	p272.treeMarkerSystem:initTerrain()
	p272.environmentAreaSystem:initTerrain(p273)
	if v275 then
		p272.densityMapSyncer = DensityMapSyncer.new(p273, 32)
		for _, v291 in pairs(p272.dynamicFoliageLayers) do
			p272.densityMapSyncer:addDensityMap(v291)
		end
		p272.fieldGroundSystem:addDensityMapSyncer(p272.densityMapSyncer)
		p272.stoneSystem:addDensityMapSyncer(p272.densityMapSyncer)
		p272.weedSystem:addDensityMapSyncer(p272.densityMapSyncer)
		p272.foliageSystem:addDensityMapSyncer(p272.densityMapSyncer)
	end
	local v292 = {}
	for _, v293 in ipairs(g_fruitTypeManager:getFruitTypes()) do
		local v294 = v293:getLayerName()
		local v295 = getFoliageTransformGroupIdByFoliageName(p273, v294)
		local v296, v297 = getTerrainDataPlaneByName(p273, v294)
		local v298
		if v296 == 0 then
			v298 = false
		else
			v298 = true
			v293:setTerrainDataPlane(v296)
			v293:setTerrainDataPlaneIndex(v297)
			v293:setFoliageTransformGroup(v295)
			g_fruitTypeManager:addTerrainDataPlane(v296)
			g_fruitTypeManager:setTerrainDataPlaneIndex(v293, v297)
			local v299 = p272.fruitMapSize
			local v300 = getDensityMapSize
			p272.fruitMapSize = math.max(v299, v300(v296))
			if p272:getIsServer() then
				local v301 = getDensityMapFilename(v296)
				local v302 = Utils.getFilenameInfo(v301)
				p272.growthSystem:setFruitLayer(v302, v293, v294, v296)
			end
			if v275 then
				p272.densityMapSyncer:addDensityMap(v296)
			end
		end
		local v303 = v293:getHaulmLayerName()
		if v303 ~= nil then
			local v304, v305 = getTerrainDataPlaneByName(p273, v303)
			if v304 ~= 0 then
				v298 = true
				g_fruitTypeManager:addTerrainDataPlane(v304)
				v293:setTerrainDataPlaneHaulm(v304)
				v293:setTerrainDataPlaneHaulmIndex(v305)
				if v275 then
					p272.densityMapSyncer:addDensityMap(v304)
				end
			end
		end
		if v298 then
			table.insert(v292, v293)
		end
	end
	if p272.mapOverlayGenerator ~= nil then
		p272.mapOverlayGenerator:setMissionFruitTypes(v292)
	end
	p272.growthSystem:onTerrainLoad(p273)
	if p272.terrainDetailId ~= 0 then
		p272.fieldCropsQuery = FieldCropsQuery.new(p272.terrainDetailId)
	end
	p272.terrainDetailHeightId = getTerrainDataPlaneByName(p273, "terrainDetailHeight")
	p272.terrainDetailHeightTGId = getTerrainDetailByName(p273, "terrainDetailHeight")
	p272.terrainDetailHeightMapSize = p272.fruitMapSize
	if p272.terrainDetailHeightId ~= 0 then
		p272.terrainDetailHeightMapSize = getDensityMapSize(p272.terrainDetailHeightId)
		g_densityMapHeightManager:loadFromXMLFile(p272.missionInfo.densityMapHeightXMLLoad)
		local v306 = getInfoLayerFromTerrain(p273, "tipCollisionGenerated")
		local v307 = getInfoLayerFromTerrain(p273, "placementCollisionGenerated")
		g_densityMapHeightManager:initialize(p272:getIsServer(), v306, v307)
		if g_densityMapHeightManager:getTerrainDetailHeightUpdater() ~= nil and v275 then
			p272.densityMapSyncer:addDensityMap(p272.terrainDetailHeightId)
		end
	end
	p272.indoorMask:onTerrainLoad(p273)
	p272.snowSystem:onTerrainLoad(p273)
	p272.aiSystem:onTerrainLoad(p273, p274)
	if p272.shallowWaterSimulation ~= nil then
		p272.shallowWaterSimulation:onTerrainLoad(p273)
	end
	g_groundTypeManager:initTerrain(p273)
	DensityMapHeightUtil.initTerrain(p272, p272.terrainDetailId, p272.terrainDetailHeightId)
	g_mpLoadingScreen:hitLoadingTarget(MPLoadingScreen.LOAD_TARGETS.TERRAIN)
end
function FSBaseMission.addTrainSystem(p308, p309)
	p308.trainSystems[p309] = p309
end
function FSBaseMission.removeTrainSystem(p310, p311)
	p310.trainSystems[p311] = nil
end
function FSBaseMission.setTrainSystemTabbable(p312, p313)
	for v314, _ in pairs(p312.trainSystems) do
		v314:setIsTrainTabbable(p313)
	end
end
function FSBaseMission.mouseEvent(p315, p316, p317, p318, p319, p320)
	FSBaseMission:superClass().mouseEvent(p315, p316, p317, p318, p319, p320)
	p315.hud:mouseEvent(p316, p317, p318, p319, p320)
end
function FSBaseMission.updatePauseInputContext(p321)
	local v322 = g_inputBinding
	local v323 = v322:getContextName() == BaseMission.INPUT_CONTEXT_PAUSE and true or v322:getContextName() == BaseMission.INPUT_CONTEXT_SYNCHRONIZING
	local v324 = p321.gameStarted and p321.paused
	if v324 then
		v324 = not g_gui:getIsGuiVisible() or p321.isSynchronizingWithPlayers
	end
	local v325 = p321.gameStarted
	if v325 then
		v325 = not p321.paused
	end
	if not p321.isSynchronizingWithPlayers and v322:getContextName() == BaseMission.INPUT_CONTEXT_SYNCHRONIZING then
		v322:revertContext()
	end
	if v324 and not v323 then
		v322:setContext(BaseMission.INPUT_CONTEXT_PAUSE)
	elseif v325 and v323 then
		v322:revertContext()
	end
	if v324 and (p321.isSynchronizingWithPlayers and v322:getContextName() ~= BaseMission.INPUT_CONTEXT_SYNCHRONIZING) then
		v322:setContext(BaseMission.INPUT_CONTEXT_SYNCHRONIZING, true)
	end
end
local function v345(p326, p327)
	-- upvalues: (ref) v_u_2, (ref) v_u_1, (copy) v_u_3
	FSBaseMission:superClass().update(p326, p327)
	if not v_u_2 and (p326.isRunning and Utils.getNoNil(g_farmManager:getFarmById(g_localPlayer.farmId).stats:getTotalValue("playTime"), 0) / 60 > 4) then
		v_u_1 = v_u_1 - p327
		if v_u_1 < 0 and not g_gui:getIsGuiVisible() then
			InfoDialog.show(g_i18n:getText("dialog_getFullVersion"), v_u_3)
			v_u_1 = math.random(1200000, 1800000)
		end
	end
	p326.hud:updateMessage(p327)
	p326.hud:updateMap(p327)
	p326.introductionHelpSystem:update(p327)
	p326.aiSystem:update(p327)
	p326.environmentAreaSystem:update(p327)
	p326.reverbSystem:update(p327)
	p326.ambientSoundSystem:update(p327)
	p326.vineSystem:update(p327)
	p326.userManager:update(p327)
	p326.snowSystem:update(p327)
	if p326.economyManager ~= nil then
		p326.economyManager:update(p327)
	end
	g_densityMapHeightManager:update(p327)
	if p326.worldAttributeManager ~= nil then
		p326.worldAttributeManager:update(p327)
	end
	if p326.wildlifeManager ~= nil then
		p326.wildlifeManager:update(p327)
	end
	p326:updatePauseInputContext()
	if p326.isRunning or g_dedicatedServer ~= nil then
		if #p326.playersToAccept > 0 then
			if p326.missionDynamicInfo.autoAccept then
				p326:onConnectionDenyAccept(p326.playersToAccept[1].connection, false, false)
			elseif p326:getCanAcceptPlayers() then
				local v328 = p326.playersToAccept[1]
				DenyAcceptDialog.show(p326.onConnectionDenyAccept, p326, v328.connection, v328.playerName, v328.platformId, getIsSplitShapeConnectionWithinLimits(v328.platformId))
			end
		end
		g_effectManager:update(p327)
		g_animationManager:update(p327)
		g_guidedTourManager:update(p327)
		p326.growthSystem:update(p327)
		g_npcManager:update(p327)
		if p326.mapOverlayGenerator ~= nil then
			p326.mapOverlayGenerator:update(p327)
		end
		if p326:getIsServer() then
			for v329, v330 in ipairs(p326.userManager:getUsers()) do
				if v329 > 1 then
					local v331 = g_farmManager:getFarmByUserId(v330:getId())
					if v330:getState() == FSBaseMission.USER_STATE_INGAME and v330:getFinanceUpdateSendTime() < p326.time then
						local v332 = p326.time
						local v333 = math.random() * 300 + 5000
						v330:setFinanceUpdateSendTime(v332 + math.floor(v333))
						if v331.stats.financesVersionCounter ~= v330:getFinancesVersionCounter() then
							v330:setFinancesVersionCounter(v331.stats.financesVersionCounter)
							v330:getConnection():sendEvent(FinanceStatsEvent.new(0, v331.farmId))
						end
					end
				end
			end
			if g_dedicatedServer ~= nil and p326.gameStatsTime <= p326.time then
				p326:updateGameStatsXML()
			end
			g_treePlantManager:updateTrees(p327, p327 * p326:getEffectiveTimeScale())
		end
		if p326:getIsClient() then
			if not g_gui:getIsGuiVisible() then
				if g_soundPlayer ~= nil then
					local v334 = g_localPlayer:getCurrentVehicle()
					local v335 = v334 ~= nil and v334.supportsRadio or not g_gameSettings:getValue(GameSettings.SETTING.RADIO_VEHICLE_ONLY)
					g_inputBinding:setActionEventActive(g_localPlayer.inputComponent.radioActionId, v335)
				end
				p326.hud:updateVehicleName(p327)
			end
			p326:updateSaving()
			p326:checkRecordingDeviceState(p327)
		end
		local v336
		if p326.missionDynamicInfo.isMultiplayer then
			if p326:getIsServer() then
				local v337 = 0
				local v338 = false
				for _, v339 in ipairs(p326.userManager:getUsers()) do
					local v340 = v339:getConnection()
					if v339:getState() == FSBaseMission.USER_STATE_INGAME and (v340 ~= nil and p326.connectionsToPlayer[v340] ~= nil) then
						v337 = v337 + 1
						if v339:getId() ~= p326.playerUserId and not getPlatformIdsAreCompatible(v339:getPlatformId(), getPlatformId()) then
							v338 = true
						end
					end
				end
				if v337 > 1 then
					if v338 then
						v336 = PresenceModes.PRESENCE_MULTIPLAYER_CROSSPLAY
					else
						v336 = PresenceModes.PRESENCE_MULTIPLAYER
					end
				else
					v336 = PresenceModes.PRESENCE_MULTIPLAYER_ALONE
				end
			else
				local v341 = false
				for _, v342 in ipairs(p326.userManager:getUsers()) do
					if v342:getId() ~= p326.playerUserId and not getPlatformIdsAreCompatible(v342:getPlatformId(), getPlatformId()) then
						v341 = true
					end
				end
				if v341 then
					v336 = PresenceModes.PRESENCE_MULTIPLAYER_CROSSPLAY
				else
					v336 = PresenceModes.PRESENCE_MULTIPLAYER
				end
			end
		else
			v336 = PresenceModes.PRESENCE_CAREER
		end
		if p326.wasNetworkError and GS_PLATFORM_PLAYSTATION then
			v336 = PresenceModes.PRESENCE_IDLE
		end
		if p326.presenceMode ~= v336 then
			if p326.presenceMode == PresenceModes.PRESENCE_MULTIPLAYER or p326.presenceMode == PresenceModes.PRESENCE_MULTIPLAYER_CROSSPLAY then
				setPresenceMode(v336)
				p326.presenceMode = v336
			elseif not g_gui:getIsGuiVisible() or p326:getIsServer() then
				setPresenceMode(v336)
				p326.presenceMode = v336
			end
		end
		if GS_PLATFORM_PLAYSTATION and p326.missionDynamicInfo.isMultiplayer then
			local v343 = getNetworkError()
			if v343 and not p326.wasNetworkError then
				local v344 = string.gsub(v343, "Network", "dialog_network")
				p326.wasNetworkError = true
				ConnectionFailedDialog.show(g_i18n:getText(v344), g_connectionFailedDialog.onOkCallback, g_connectionFailedDialog, { g_gui.currentGuiName })
			elseif not v343 and p326.wasNetworkError then
				p326.wasNetworkError = false
			end
			if getMultiplayerAvailability() == MultiplayerAvailability.NOT_AVAILABLE then
				OnInGameMenuMenu()
			end
		end
		if p326.isExitingGame then
			OnInGameMenuMenu()
		end
		if Platform.supportsGameRating then
			p326:testForGameRating()
		end
	else
		if p326.paused and (not p326.isSynchronizingWithPlayers and (not g_gui:getIsGuiVisible() and GS_PLATFORM_PLAYSTATION)) then
			setPresenceMode(PresenceModes.PRESENCE_IDLE)
			p326.presenceMode = PresenceModes.PRESENCE_IDLE
		end
		p326:updateSaving()
	end
end
FSBaseMission.update = v345
function FSBaseMission.checkRecordingDeviceState(p346, p347)
	if p346.missionDynamicInfo.isMultiplayer and Platform.hasRecordingDeviceDetection then
		p346.checkRecordingDeviceTimer = p346.checkRecordingDeviceTimer + p347
		if p346.checkRecordingDeviceTimer >= FSBaseMission.RECORDING_DEVICE_CHECK_INTERVAL then
			p346.checkRecordingDeviceTimer = 0
			local v348 = VoiceChatUtil.getHasRecordingDevice()
			if v348 ~= p346.lastRecordingDeviceState then
				p346.lastRecordingDeviceState = v348
				if v348 then
					p346:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, g_i18n:getText("ui_microphoneDetected"))
					return
				end
				p346:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, g_i18n:getText("ui_microphoneRemoved"))
			end
		end
	end
end
function FSBaseMission.testForGameRating(p349)
	if g_gui:getIsGuiVisible() then
		return
	elseif not p349.introductionHelpSystem:getIsHelpVisible() then
		local v350 = g_lifetimeStats
		local v351 = v350:getTotalRuntime()
		local v352 = v350.gameRateMessagesShown
		local v353
		if v352 < 4 then
			v353 = v352 * 3 + 1 <= v351
		else
			v353 = false
		end
		if v353 then
			v350.gameRateMessagesShown = v352 + 1
			v350:save()
			GameRateDialog.show()
		end
	end
end
function FSBaseMission.updateSaving(p354)
	if p354.doSaveGameState == SavegameController.SAVE_STATE_NONE then
		return
	else
		local v355 = g_inGameMenu
		if p354.doSaveGameState == SavegameController.SAVE_STATE_VALIDATE_LIST then
			if g_savegameController:isStorageDeviceUnavailable() then
				p354.doSaveGameState = SavegameController.SAVE_STATE_VALIDATE_LIST_DIALOG_WAIT
				if g_dedicatedServer == nil then
					v355:notifyValidateSavegameList(p354.currentDeviceHasNoSpace, p354.onYesNoSavegameSelectDevice, p354)
				else
					Logging.error("The device no space to save the game.")
				end
			else
				p354.doSaveGameState = SavegameController.SAVE_STATE_OVERWRITE_DIALOG
				return
			end
		elseif p354.doSaveGameState == SavegameController.SAVE_STATE_OVERWRITE_DIALOG then
			local v356, _ = saveGetInfoById(p354.missionInfo.savegameIndex)
			if v356 == "" then
				p354.doSaveGameState = SavegameController.SAVE_STATE_NOP_WRITE
				return
			else
				p354.doSaveGameState = SavegameController.SAVE_STATE_OVERWRITE_DIALOG_WAIT
				if g_dedicatedServer == nil then
					v355:notifyOverwriteSavegame(p354.onYesNoSavegameOverwrite, p354)
				else
					p354:onYesNoSavegameOverwrite(true)
				end
			end
		elseif p354.doSaveGameState == SavegameController.SAVE_STATE_NOP_WRITE then
			p354.doSaveGameState = SavegameController.SAVE_STATE_WRITE
			return
		elseif p354.doSaveGameState == SavegameController.SAVE_STATE_WRITE then
			if g_dedicatedServer == nil then
				v355:notifyStartSaving()
			end
			p354.doSaveGameState = SavegameController.SAVE_STATE_WRITE_WAIT
			p354.savingMinEndTime = getTimeSec() + SavegameController.SAVING_DURATION
			p354:saveSavegame(p354.doSaveGameBlocking)
		elseif p354.doSaveGameState == SavegameController.SAVE_STATE_WRITE_WAIT and not g_savegameController:getIsSaving() then
			local v357 = g_savegameController:getSavingErrorCode()
			if v357 == Savegame.ERROR_OK then
				p354.doSaveGameState = SavegameController.SAVE_STATE_NONE
				if g_dedicatedServer == nil then
					v355:notifySaveComplete()
				end
			elseif v357 == Savegame.ERROR_SAVE_NO_SPACE and not GS_PLATFORM_PLAYSTATION then
				p354.currentDeviceHasNoSpace = true
				if g_dedicatedServer == nil then
					v355:notifySaveFailedNoSpace(p354.onYesNoSavegameSelectDevice, p354)
					return
				end
			else
				p354.doSaveGameState = SavegameController.SAVE_STATE_NONE
				p354.savingMinEndTime = 0
				g_savegameController:resetStorageDeviceSelection()
				if g_dedicatedServer == nil then
					v355:notifySavegameNotSaved()
					return
				end
			end
		end
	end
end
function FSBaseMission.onYesNoSavegameSelectDevice(p358, p359)
	if p359 then
		p358.doSaveGameState = SavegameController.SAVE_STATE_VALIDATE_LIST_WAIT
		g_savegameController:resetStorageDeviceSelection()
		g_savegameController:updateSavegames()
	else
		p358.doSaveGameState = SavegameController.SAVE_STATE_NONE
		p358.savingMinEndTime = 0
		g_inGameMenu:notifySavegameNotSaved()
	end
end
function FSBaseMission.onSaveGameUpdateComplete(p360, p361)
	if p360.doSaveGameState == SavegameController.SAVE_STATE_VALIDATE_LIST_WAIT then
		if p361 == Savegame.ERROR_OK or p361 == Savegame.ERROR_DATA_CORRUPT then
			p360.currentDeviceHasNoSpace = false
			p360.doSaveGameState = SavegameController.SAVE_STATE_OVERWRITE_DIALOG
			return
		end
		p360.doSaveGameState = SavegameController.SAVE_STATE_NONE
		g_savegameController:resetStorageDeviceSelection()
		g_inGameMenu:notifySavegameNotSaved(p361)
	end
end
function FSBaseMission.onYesNoSavegameOverwrite(p362, p363)
	if p363 then
		p362.doSaveGameState = InGameMenu.SAVE_STATE_NOP_WRITE
	else
		p362.doSaveGameState = InGameMenu.SAVE_STATE_NONE
		p362.savingMinEndTime = 0
		g_inGameMenu:notifySavegameNotSaved()
	end
end
function FSBaseMission.getSynchronizingPercentage(p364)
	local v365 = 0
	local v366 = 0
	for _, v367 in pairs(p364.playersSynchronizing) do
		v365 = v365 + p364.restPercentageFraction
		if v367.densityMapEvent ~= nil then
			v365 = v365 + v367.densityMapEvent.percentage * p364.densityMapPercentageFraction
		end
		if v367.splitShapesEvent ~= nil then
			v365 = v365 + v367.splitShapesEvent.percentage * p364.splitShapesPercentageFraction
		end
		v366 = v366 + 1
	end
	if v366 > 0 then
		v365 = v365 / v366
	end
	local v368 = v365 * 100
	return math.floor(v368)
end
function FSBaseMission.showPauseDisplay(p369, p370)
	local v371
	if p370 then
		v371 = g_i18n:getText("ui_gamePaused")
		if GS_IS_CONSOLE_VERSION and p369:getIsServer() then
			v371 = v371 .. " " .. g_i18n:getText("ui_continueGame")
		end
	else
		v371 = ""
	end
	if p369.hud ~= nil then
		p369.hud:onPauseGameChange(p370, v371)
	end
end
function FSBaseMission.draw(p372)
	if p372.paused then
		if p372.isSynchronizingWithPlayers then
			local v373 = not p372:getIsServer() and "" or string.format(" %i%%", p372:getSynchronizingPercentage())
			local v374 = g_i18n:getText("ui_synchronizingWithOtherPlayers") .. v373
			p372.hud:onPauseGameChange(nil, v374)
		end
		local v375 = g_gui:getIsGuiVisible()
		if v375 then
			v375 = not g_gui:getIsOverlayGuiVisible()
		end
		if not v375 or p372.isSynchronizingWithPlayers then
			local v376 = p372.hud
			local v377 = not p372.isMissionStarted
			if v377 then
				v377 = not v375
			end
			v376:drawGamePaused(v377)
		end
	end
	if not p372.paused and p372.introductionHelpSystem ~= nil then
		p372.introductionHelpSystem:draw()
	end
	local v378 = not g_gui:getIsMenuVisible()
	if v378 and (g_gui:getIsDialogVisible() and not Platform.ui.drawHudOnDialog) then
		v378 = false
	end
	if p372.isRunning and (v378 or g_gui:getIsOverlayGuiVisible()) and not p372.hud:getIsFading() then
		if p372.hud:getIsVisible() then
			p372.hud:drawBaseHUD()
			p372.hud:drawVehicleName()
		end
		g_guidedTourManager:draw()
	end
	FSBaseMission:superClass().draw(p372)
	if not p372.hud:getIsFading() then
		p372.hud:drawInGameMessageAndIcon()
	end
end
function FSBaseMission.addMoneyChange(p379, p380, p381, p382, p383)
	if p379:getIsServer() then
		if p379.moneyChanges[p382.id] == nil then
			p379.moneyChanges[p382.id] = {}
		end
		local v384 = p379.moneyChanges[p382.id]
		if v384[p381] == nil then
			v384[p381] = 0
		end
		v384[p381] = v384[p381] + p380
		if p379:getFarmId() == p381 then
			p379.hud:addMoneyChange(p382, p380)
		end
		if p383 then
			p379:broadcastNotifications(p382, p381)
			return
		end
	else
		Logging.error("addMoneyChange() called on client")
		printCallstack()
	end
end
function FSBaseMission.showMoneyChange(p385, p386, p387, p388, p389)
	if p385:getIsServer() then
		if p388 then
			for _, v390 in ipairs(g_farmManager:getFarms()) do
				p385:broadcastNotifications(p386, v390.farmId, p387)
			end
		else
			p385:broadcastNotifications(p386, p389 or p385:getFarmId(), p387)
		end
	else
		g_client:getServerConnection():sendEvent(RequestMoneyChangeEvent.new(p386))
		return
	end
end
function FSBaseMission.broadcastNotifications(p391, p392, p393, p394)
	if p392 == nil then
		printCallstack()
	end
	local v395 = p391.moneyChanges[p392.id]
	local v396 = v395 and v395[p393]
	if v396 then
		p391:broadcastEventToFarm(MoneyChangeEvent.new(v396, p392, p393, p394), p393, false)
		if p393 == p391:getFarmId() then
			if p394 ~= nil then
				p394 = g_i18n:getText(p394)
			end
			p391.hud:showMoneyChange(p392, p394)
		end
		v395[p393] = nil
	end
end
function FSBaseMission.showAttachContext(p397, p398)
	p397.hud:showAttachContext(p398:getUppercaseName())
end
function FSBaseMission.showTipContext(p399, p400)
	local v401 = g_fillTypeManager:getFillTypeByIndex(p400)
	p399.hud:showTipContext(v401.title)
end
function FSBaseMission.showFuelContext(p402, p403)
	p402.hud:showFuelContext(p403:getUppercaseName())
end
function FSBaseMission.showFillDogBowlContext(p404, p405)
	p404.hud:showFillDogBowlContext(p405)
end
function FSBaseMission.addIngameNotification(p406, p407, p408)
	p406.hud:addSideNotification(p407, p408)
end
function FSBaseMission.getIsAutoSaveSupported(_)
	return true
end
function FSBaseMission.doPauseGame(p409)
	FSBaseMission:superClass().doPauseGame(p409)
	g_inGameMenu:setIsGamePaused(true)
	g_shopMenu:setIsGamePaused(true)
	if p409.growthSystem ~= nil then
		p409.growthSystem:setIsGamePaused(true)
	end
end
function FSBaseMission.canUnpauseGame(p410)
	local v411 = FSBaseMission:superClass().canUnpauseGame(p410) and not (p410.isSynchronizingWithPlayers or p410.dediEmptyPaused)
	if v411 then
		v411 = not p410.userSigninPaused
	end
	return v411
end
function FSBaseMission.doUnpauseGame(p412)
	FSBaseMission:superClass().doUnpauseGame(p412)
	g_inGameMenu:setIsGamePaused(false)
	g_shopMenu:setIsGamePaused(false)
	p412.growthSystem:setIsGamePaused(false)
	if g_dedicatedServer ~= nil then
		g_dedicatedServer:raiseFramerate()
	end
end
function FSBaseMission.getCanAcceptPlayers(_)
	local v413 = not (g_gui:getIsDialogVisible() or g_sleepManager:getIsSleeping())
	if v413 then
		v413 = not g_savegameController:getIsSaving()
	end
	return v413
end
function FSBaseMission.onEndMissionCallback(p414)
	if p414.state == BaseMission.STATE_FINISHED or p414.state == BaseMission.STATE_FAILED then
		p414.isExitingGame = true
	end
end
function FSBaseMission.setMissionInfo(p_u_415, p_u_416, p_u_417)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_415
		resetSplitShapes()
		Logging.info("resetSplitShapes()")
		setUseKinematicSplitShapes(not p_u_415:getIsServer())
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_416, (copy) p_u_415
		if p_u_416.isValid then
			local v418 = TerrainLoadFlags.TEXTURE_CACHE + TerrainLoadFlags.NORMAL_MAP_CACHE + TerrainLoadFlags.OCCLUDER_CACHE
			if p_u_416:getIsDensityMapValid(p_u_415) then
				v418 = v418 + TerrainLoadFlags.DENSITY_MAPS_USE_LOAD_DIR
			else
				Logging.warning("density map is not valid, ignoring density map from savegame")
			end
			if not GS_IS_MOBILE_VERSION then
				v418 = v418 + TerrainLoadFlags.HEIGHT_MAP_USE_LOAD_DIR + TerrainLoadFlags.NORMAL_MAP_CACHE_USE_LOAD_DIR + TerrainLoadFlags.OCCLUDER_CACHE_USE_LOAD_DIR
				if p_u_416:getIsTerrainLodTextureValid(p_u_415) then
					v418 = v418 + TerrainLoadFlags.TEXTURE_CACHE_USE_LOAD_DIR
					if p_u_416:getIsTerrainLodTextureValid(p_u_415) and (g_densityMapHeightManager ~= nil and g_densityMapHeightManager:checkTypeMappings()) then
						v418 = v418 + TerrainLoadFlags.LOD_TEXTURE_CACHE
					end
				end
			end
			setTerrainLoadDirectory(p_u_416.savegameDirectory, v418)
		else
			setTerrainLoadDirectory("", TerrainLoadFlags.GAME_DEFAULT)
		end
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_416, (copy) p_u_415
		if p_u_416:getAreSplitShapesValid(p_u_415) then
			local v419 = p_u_416.savegameDirectory .. "/splitShapes.gmss"
			if fileExists(v419) and not loadSplitShapesFromFile(v419) then
				Logging.error("Unable to load split shapes from \'%s\'", v419)
				return
			end
		elseif p_u_416.isValid then
			Logging.warning("splitshapes are not valid, ignoring splitshapes from savegame")
		end
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_415, (copy) p_u_416, (copy) p_u_417
		FSBaseMission:superClass().setMissionInfo(p_u_415, p_u_416, p_u_417)
	end)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_415
		if g_soundPlayer ~= nil then
			g_soundPlayer:addEventListener(p_u_415)
			if not (GS_IS_CONSOLE_VERSION or GS_IS_MOBILE_VERSION) then
				g_soundPlayer:setStreamingAccessOwner(p_u_415)
			end
		end
		p_u_415:updateMaxNumHirables()
		p_u_415.hud:setIngameMapSize(g_gameSettings:getValue(GameSettings.SETTING.INGAME_MAP_STATE))
	end)
end
function FSBaseMission.updateMaxNumHirables(p420)
	if p420.missionDynamicInfo.isMultiplayer then
		if p420.missionDynamicInfo.capacity ~= nil then
			local v421 = p420.missionDynamicInfo.capacity
			local v422 = g_helperManager
			local v423 = math.min(v421, v422:getNumOfHelpers())
			p420.maxNumHirables = math.max(4, v423)
			return
		end
	else
		local v424 = Platform.gameplay.maxNumHirables
		local v425 = g_helperManager
		p420.maxNumHirables = math.min(v424, v425:getNumOfHelpers())
	end
end
function FSBaseMission.addLiquidManureLoadingStation(p426, p427)
	if not table.addElement(p426.liquidManureLoadingStations, p427) then
		printError("Error: Liquid manure loading station already added")
	end
end
function FSBaseMission.removeLiquidManureLoadingStation(p428, p429)
	table.removeElement(p428.liquidManureLoadingStations, p429)
end
function FSBaseMission.addManureLoadingStation(p430, p431)
	if not table.addElement(p430.manureLoadingStations, p431) then
		printError("Error: Manure loading station already added")
	end
end
function FSBaseMission.removeManureLoadingStation(p432, p433)
	table.removeElement(p432.manureLoadingStations, p433)
end
function FSBaseMission.addMoney(p434, p435, p436, p437, p438, p439)
	if p434:getIsServer() then
		if p436 == 0 then
			printError("Error: Can\'t change money of spectator farm")
			printCallstack()
			return
		end
		local v440 = g_farmManager:getFarmById(p436)
		if v440 == nil then
			return
		end
		v440:changeBalance(p435, p437)
		if p438 then
			p434:addMoneyChange(p435, p436, p437, p439)
			return
		end
	else
		printError("Error: FSBaseMission:addMoney is only allowed on a server")
		printCallstack()
	end
end
function FSBaseMission.addPurchasedMoney(p441, p442)
	if p441:getIsServer() then
		local v443 = g_farmManager:getFarmById(FarmManager.SINGLEPLAYER_FARM_ID)
		if v443 ~= nil then
			v443:addPurchasedCoins(p442)
		end
	else
		printError("Error: FSBaseMission:addPurchasedMoney is only allowed on a server")
		printCallstack()
		return
	end
end
function FSBaseMission.getMoney(p444, p445)
	if p445 == nil then
		p445 = g_localPlayer == nil and FarmManager.SINGLEPLAYER_FARM_ID or g_localPlayer.farmId
	end
	local v446 = g_farmManager:getFarmById(p445)
	if v446 == nil then
		return 0
	end
	p444.cacheFarm = v446
	return v446.money
end
function FSBaseMission.setPlayerPermission(p447, p448, p449, p450)
	if p447:getIsServer() then
		g_farmManager:getFarmByUserId(p448).userIdToPlayer[p448].permissions[p449] = p450
	end
end
function FSBaseMission.setPlayerPermissions(p451, p452, p453)
	if p451:getIsServer() then
		local v454 = g_farmManager:getFarmByUserId(p452).userIdToPlayer[p452]
		for _, v455 in ipairs(Farm.PERMISSIONS) do
			if p453[v455] ~= nil then
				v454.permissions[v455] = p453[v455]
			end
		end
	end
end
function FSBaseMission.getHasPlayerPermission(p456, p457, p458, p459, p460)
	if p460 == nil or not p460 then
		if p456:getIsServer() then
			if p458 == nil or (p458:getIsLocal() or (p458:getIsServer() or p456.userManager:getIsConnectionMasterUser(p458))) then
				return true
			end
		elseif p456.isMasterUser then
			return true
		end
		if p458 ~= nil and p458:getIsServer() then
			return true
		end
	end
	local v461
	if p458 == nil then
		v461 = p456.userManager:getUserByUserId(p456.playerUserId)
	else
		v461 = p456.userManager:getUserByConnection(p458)
	end
	if v461 == nil then
		return false
	else
		local v462 = g_farmManager:getFarmByUserId(v461:getId())
		local v463 = v462.userIdToPlayer[v461:getId()]
		if p459 == nil or v462.farmId == p459 then
			if v463 == nil then
				return false
			else
				return v463.isFarmManager or Utils.getNoNil(v463.permissions[p457], false)
			end
		else
			return false
		end
	end
end
function FSBaseMission.getTerrainDetailPixelsToSqm(p464)
	local v465 = p464.terrainSize / p464.terrainDetailMapSize
	return v465 * v465
end
function FSBaseMission.getFruitPixelsToSqm(p466)
	local v467 = p466.terrainSize / p466.fruitMapSize
	return v467 * v467
end
function FSBaseMission.getIngameMap(p468)
	return p468.hud:getIngameMap()
end
function FSBaseMission.sendNumPlayersToMasterServer(p469, p470)
	if p469.missionDynamicInfo.isMultiplayer then
		if g_dedicatedServer ~= nil then
			p470 = p470 - 1
		end
		masterServerSetServerNumPlayers(p470)
	end
end
function FSBaseMission.sendPlatformSessionIdsToMasterServer(p471, p472)
	if p471.missionDynamicInfo.isMultiplayer then
		masterServerSetServerPlatformSessionIds(p472)
	end
end
function FSBaseMission.setTimeScale(p473, p474, p475)
	if p474 ~= p473.missionInfo.timeScale then
		p473.missionInfo.timeScale = p474
		g_messageCenter:publish(MessageType.TIMESCALE_CHANGED)
		SavegameSettingsEvent.sendEvent(p475)
		if g_server ~= nil then
			EnvironmentTimeEvent.broadcastEvent()
		end
	end
end
function FSBaseMission.setTimeScaleMultiplier(p476, p477)
	if p477 ~= p476.missionInfo.timeScaleMultiplier then
		p476.missionInfo.timeScaleMultiplier = p477
		g_messageCenter:publish(MessageType.TIMESCALE_CHANGED)
	end
end
function FSBaseMission.getEffectiveTimeScale(p478)
	return p478.missionInfo:getEffectiveTimeScale()
end
function FSBaseMission.setEconomicDifficulty(p479, p480, p481)
	if p480 ~= p479.missionInfo.economicDifficulty then
		p479.missionInfo.economicDifficulty = p480
		SavegameSettingsEvent.sendEvent(p481)
		Logging.info("Savegame Setting \'economicDifficulty\': %s", EconomicDifficulty.getName(p480))
	end
end
function FSBaseMission.setSnowEnabled(p482, p483, p484)
	if p483 ~= p482.missionInfo.isSnowEnabled then
		p482.missionInfo.isSnowEnabled = p483
		SavegameSettingsEvent.sendEvent(p484)
		if not p483 then
			p482.snowSystem:removeAll()
		end
		Logging.info("Savegame Setting \'snowEnabled\': %s", p483)
	end
end
function FSBaseMission.setSavegameName(p485, p486, p487)
	if p486 ~= p485.missionInfo.savegameName then
		p485.missionInfo.savegameName = p486
		SavegameSettingsEvent.sendEvent(p487)
	end
end
function FSBaseMission.startSaveCurrentGame(p488, _, p489)
	p488.currentDeviceHasNoSpace = false
	if g_dedicatedServer == nil then
		p488.doSaveGameState = InGameMenu.SAVE_STATE_WRITE
		p488.doSaveGameBlocking = p489
		g_inGameMenu:startSavingGameDisplay()
	else
		p488:saveSavegame(p489)
	end
	g_gameSettings:save()
end
function FSBaseMission.saveSavegame(p490, p491)
	if not g_sleepManager:getIsSleeping() then
		if GS_IS_CONSOLE_VERSION or GS_IS_MOBILE_VERSION then
			p490.isSaving = true
			p490:pauseGame()
		end
		g_savegameController:saveSavegame(p490.missionInfo, p491)
	end
end
function FSBaseMission.setGrowthMode(p492, p493, p494)
	p492.growthSystem:setGrowthMode(p493, p494)
	g_inGameMenu:onGrowthModeChanged()
end
function FSBaseMission.setFixedSeasonalVisuals(p495, p496, p497)
	if p496 ~= p495.missionInfo.fixedSeasonalVisuals then
		p495.environment:setFixedPeriod(p496)
		SavegameSettingsEvent.sendEvent(p497)
		Logging.info("Savegame Setting \'fixedSeasonalVisuals\': %s", p496)
	end
end
function FSBaseMission.setPlannedDaysPerPeriod(p498, p499, p500)
	local v501 = Environment.MAX_DAYS_PER_PERIOD
	local v502 = math.clamp(p499, 1, v501)
	if v502 ~= p498.missionInfo.plannedDaysPerPeriod then
		p498.environment:setPlannedDaysPerPeriod(v502)
		SavegameSettingsEvent.sendEvent(p500)
		Logging.info("Savegame Setting \'plannedDaysPerPeriod\': %s", v502)
	end
end
function FSBaseMission.setFruitDestructionEnabled(p503, p504, p505)
	if p504 ~= p503.missionInfo.fruitDestruction then
		p503.missionInfo.fruitDestruction = p504
		SavegameSettingsEvent.sendEvent(p505)
		Logging.info("Savegame Setting \'fruitDesctructionEnabled\': %s", p504)
	end
end
function FSBaseMission.setPlowingRequiredEnabled(p506, p507, p508)
	if p507 ~= p506.missionInfo.plowingRequiredEnabled then
		p506.missionInfo.plowingRequiredEnabled = p507
		SavegameSettingsEvent.sendEvent(p508)
		Logging.info("Savegame Setting \'plowingRequiredEnabled\': %s", p507)
		g_inGameMenu:onSoilSettingChanged()
	end
end
function FSBaseMission.setStonesEnabled(p509, p510, p511)
	if p510 ~= p509.missionInfo.stonesEnabled then
		p509.missionInfo.stonesEnabled = p510
		SavegameSettingsEvent.sendEvent(p511)
		Logging.info("Savegame Setting \'stonesEnabled\': %s", p510)
		g_inGameMenu:onSoilSettingChanged()
	end
end
function FSBaseMission.setLimeRequired(p512, p513, p514)
	if p513 ~= p512.missionInfo.limeRequired then
		p512.missionInfo.limeRequired = p513
		SavegameSettingsEvent.sendEvent(p514)
		Logging.info("Savegame Setting \'limeRequired\': %s", p513)
		g_inGameMenu:onSoilSettingChanged()
	end
end
function FSBaseMission.setWeedsEnabled(p515, p516, p517)
	if p516 ~= p515.missionInfo.weedsEnabled then
		p515.missionInfo.weedsEnabled = p516
		p515.growthSystem:onWeedGrowthChanged()
		SavegameSettingsEvent.sendEvent(p517)
		Logging.info("Savegame Setting \'weedsEnabled\': %s", p516)
		g_inGameMenu:onSoilSettingChanged()
	end
end
function FSBaseMission.setStopAndGoBraking(p518, p519, p520)
	if p519 ~= p518.missionInfo.stopAndGoBraking then
		p518.missionInfo.stopAndGoBraking = p519
		SavegameSettingsEvent.sendEvent(p520)
	end
end
function FSBaseMission.setTrailerFillLimit(p521, p522, p523)
	if p522 ~= p521.missionInfo.trailerFillLimit then
		p521.missionInfo.trailerFillLimit = p522
		SavegameSettingsEvent.sendEvent(p523)
	end
end
function FSBaseMission.setDisasterDestructionState(p524, p525, p526)
	if p525 ~= p524.missionInfo.disasterDestructionState then
		p524.missionInfo.disasterDestructionState = p525
		SavegameSettingsEvent.sendEvent(p526)
	end
end
function FSBaseMission.setAutoSaveInterval(_, p527, p528)
	if p527 ~= g_autoSaveManager:getInterval() then
		g_autoSaveManager:setInterval(p527)
		SavegameSettingsEvent.sendEvent(p528)
	end
end
function FSBaseMission.setTrafficEnabled(p529, p530, p531)
	if p530 ~= p529.missionInfo.trafficEnabled then
		p529.missionInfo.trafficEnabled = p530
		SavegameSettingsEvent.sendEvent(p531)
		if p529.trafficSystem ~= nil then
			p529.trafficSystem:setEnabled(p529.missionInfo.trafficEnabled)
			if not p529.missionInfo.trafficEnabled then
				p529.trafficSystem:reset()
			end
		end
	end
end
function FSBaseMission.setDirtInterval(p532, p533, p534)
	if p533 ~= p532.missionInfo.dirtInterval then
		p532.missionInfo.dirtInterval = p533
		SavegameSettingsEvent.sendEvent(p534)
		Logging.info("Savegame Setting \'dirtInterval\': %d", p533)
	end
end
function FSBaseMission.setFuelUsage(p535, p536, p537)
	if p536 ~= p535.missionInfo.fuelUsage then
		p535.missionInfo.fuelUsage = p536
		SavegameSettingsEvent.sendEvent(p537)
		Logging.info("Savegame Setting \'fuelUsage\': %d", p536)
	end
end
function FSBaseMission.setHelperBuyFuel(p538, p539, p540)
	if p539 ~= p538.missionInfo.helperBuyFuel then
		p538.missionInfo.helperBuyFuel = p539
		SavegameSettingsEvent.sendEvent(p540)
	end
end
function FSBaseMission.setHelperBuySeeds(p541, p542, p543)
	if p542 ~= p541.missionInfo.helperBuySeeds then
		p541.missionInfo.helperBuySeeds = p542
		SavegameSettingsEvent.sendEvent(p543)
	end
end
function FSBaseMission.setHelperBuyFertilizer(p544, p545, p546)
	if p545 ~= p544.missionInfo.helperBuyFertilizer then
		p544.missionInfo.helperBuyFertilizer = p545
		SavegameSettingsEvent.sendEvent(p546)
	end
end
function FSBaseMission.setHelperSlurrySource(p547, p548, p549)
	if p548 ~= p547.missionInfo.helperSlurrySource then
		local v550 = p547.liquidManureLoadingStations[p548 - 2]
		if v550 == nil then
			if p548 == 2 then
				Logging.devInfo("Set Helper Slurry Source to \'Buy\'")
			elseif p548 == 1 then
				Logging.devInfo("Set Helper Slurry Source to \'None\'")
			end
		else
			Logging.devInfo("Set Helper Slurry Source to \'%s\'", v550:getName())
		end
		p547.missionInfo.helperSlurrySource = p548
		SavegameSettingsEvent.sendEvent(p549)
	end
end
function FSBaseMission.setHelperManureSource(p551, p552, p553)
	if p552 ~= p551.missionInfo.helperManureSource then
		p551.missionInfo.helperManureSource = p552
		local v554 = p551.manureLoadingStations[p552 - 2]
		if v554 == nil then
			if p552 == 2 then
				Logging.devInfo("Set Helper Manure Source to \'Buy\'")
			elseif p552 == 1 then
				Logging.devInfo("Set Helper Manure Source to \'None\'")
			end
		else
			Logging.devInfo("Set Helper Manure Source to %s", v554:getName())
		end
		SavegameSettingsEvent.sendEvent(p553)
	end
end
function FSBaseMission.setAutomaticMotorStartEnabled(p555, p556, p557)
	if p556 ~= p555.missionInfo.automaticMotorStartEnabled then
		p555.missionInfo.automaticMotorStartEnabled = p556
		SavegameSettingsEvent.sendEvent(p557)
	end
end
function FSBaseMission.addKnownSplitShape(_, _) end
function FSBaseMission.removeKnownSplitShape(_, _) end
function FSBaseMission.getDoghouse(p558, p559)
	for _, v560 in pairs(p558.doghouses) do
		if v560:getOwnerFarmId() == p559 then
			return v560
		end
	end
	return nil
end
function FSBaseMission.onDayChanged(_) end
function FSBaseMission.onHourChanged(p561)
	if p561:getIsServer() then
		p561:showMoneyChange(MoneyType.AI, nil, true)
	end
end
function FSBaseMission.onMinuteChanged(_) end
function FSBaseMission.pauseRadio(p562)
	if g_soundPlayer ~= nil then
		p562:setRadioActionEventsState(false)
		if p562.hud ~= nil then
			p562.hud:hideTopNotification()
		end
		g_soundPlayer:pause()
	end
end
function FSBaseMission.playRadio(p563)
	if g_soundPlayer ~= nil and g_gameSettings:getValue(GameSettings.SETTING.RADIO_IS_ACTIVE) then
		p563:setRadioActionEventsState((g_soundPlayer:play()))
	end
end
function FSBaseMission.getIsRadioPlaying(_)
	if g_soundPlayer == nil then
		return false
	else
		return g_soundPlayer:getIsPlaying()
	end
end
function FSBaseMission.onSoundPlayerChange(p564, p565, p566, p567, p568)
	if not GS_IS_MOBILE_VERSION then
		p564:addGameNotification(p565, p566, not p567 and "" or g_i18n:getText("ui_radioRating"), p568, 4000)
	end
	g_messageCenter:publish(MessageType.RADIO_CHANNEL_CHANGE, p565, p566, p567)
end
function FSBaseMission.onSoundPlayerStreamAccess(p569)
	if g_gameSettings:getValue(GameSettings.SETTING.IS_SOUND_PLAYER_STREAM_ACCESS_ALLOWED) then
		p569:onStreamAccessAllowed(true)
	else
		YesNoDialog.show(p569.onStreamAccessAllowed, p569, g_i18n:getText("ui_radioRating") .. "\n\n" .. g_i18n:getText("ui_continueQuestion"))
	end
end
function FSBaseMission.onStreamAccessAllowed(_, p570)
	if g_soundPlayer ~= nil then
		if p570 then
			g_gameSettings:setValue(GameSettings.SETTING.IS_SOUND_PLAYER_STREAM_ACCESS_ALLOWED, true, true)
		end
		g_soundPlayer:setStreamAccessAllowed(p570)
	end
end
function FSBaseMission.setMoneyUnit(p571, p572)
	FSBaseMission:superClass().setMoneyUnit(p571, p572)
	p571.hud:setMoneyUnit(p572)
end
function FSBaseMission.teleportVehicle(_, p_u_573, p574, p575, p576)
	local v_u_577 = {}
	local v_u_578 = {}
	local v_u_579 = {}
	local function v_u_600(p580)
		-- upvalues: (copy) p_u_573, (copy) v_u_578, (copy) v_u_600, (copy) v_u_579, (copy) v_u_577
		local v581, v582, v583 = getWorldTranslation(p580.rootNode)
		local v584, v585, v586 = getWorldRotation(p580.rootNode)
		local v587, v588, v589 = worldToLocal(p_u_573.rootNode, v581, v582, v583)
		local v590, v591, v592 = worldRotationToLocal(p_u_573.rootNode, v584, v585, v586)
		local v593 = v_u_578
		table.insert(v593, {
			["vehicle"] = p580,
			["offset"] = { v587, v588, v589 },
			["rotationOffset"] = { v590, v591, v592 }
		})
		if p580.getAttachedImplements ~= nil then
			local v594 = p580:getAttachedImplements()
			for _, v595 in ipairs(v594) do
				if not v595.object:getIsAdditionalAttachment() then
					v_u_600(v595.object)
					local v596 = v_u_579
					local v597 = v595.object
					table.insert(v596, v597)
					local v598 = v_u_577
					local v599 = {
						["vehicle"] = p580,
						["object"] = v595.object,
						["jointDescIndex"] = v595.jointDescIndex,
						["inputAttacherJointDescIndex"] = v595.object:getActiveInputAttacherJointDescIndex()
					}
					table.insert(v598, v599)
				end
			end
		end
	end
	v_u_600(p_u_573)
	for _, v601 in ipairs(v_u_579) do
		local v602 = v601:getAttacherVehicle()
		if v602 ~= nil then
			v602:detachImplementByObject(v601, true)
		end
	end
	for _, v603 in pairs(v_u_578) do
		v603.vehicle:removeFromPhysics()
	end
	for v604, v605 in pairs(v_u_578) do
		local v606, v607, v608, v609, v610
		if v604 > 1 then
			local v611 = localToWorld
			local v612 = p_u_573.rootNode
			local v613 = v605.offset
			local v614
			v606, v614, v607 = v611(v612, unpack(v613))
			local v615 = localRotationToWorld
			local v616 = p_u_573.rootNode
			local v617 = v605.rotationOffset
			v608, v609, v610 = v615(v616, unpack(v617))
		else
			v609 = p576
			v607 = p575
			v606 = p574
			v608 = 0
			v610 = 0
		end
		local v618 = getTerrainHeightAtWorldPos(g_terrainNode, v606, 300, v607)
		v605.vehicle:setAbsolutePosition(v606, v618 + 0.5, v607, v608, v609, v610)
	end
	for _, v619 in pairs(v_u_578) do
		v619.vehicle:addToPhysics()
	end
	for _, v620 in pairs(v_u_577) do
		v620.vehicle:attachImplement(v620.object, v620.inputAttacherJointDescIndex, v620.jointDescIndex, true)
	end
end
function FSBaseMission.consoleCommandCheatMoney(p621, p622, p623)
	if not (p621:getIsServer() or p621.isMasterUser) then
		return "gsMoneyAdd is only available for server and/or admins"
	end
	local v624 = tonumber(p622) or 10000000
	local v625 = tonumber(p623) or g_localPlayer.farmId
	if g_farmManager:getFarmById(v625) == nil then
		return string.format("No farm for id \'%s\'", v625)
	end
	if p621:getIsServer() then
		p621:addMoney(v624, v625, MoneyType.OTHER, true, true)
	else
		g_client:getServerConnection():sendEvent(CheatMoneyEvent.new(v624, v625))
	end
	return string.format("Added money %d. Use \'gsMoneyAdd <amount> <farmId>\' to add or remove a custom amount to a specific farm", v624)
end
function FSBaseMission.consoleCommandExportStoreItems(_)
	local v626 = getUserProfileAppPath() .. "storeItems.csv"
	local v627 = g_storeManager:getSpecTypes()
	local v628 = io.open(v626, "w")
	if v628 == nil then
		printError(string.format("Error: Unable to create csv file \'%s\'", v626))
	else
		local v629 = "xmlFilename;category;brand;brandTitle;name;price;lifetime;dailyUpkeep;showInStore;brushType;brushCategory;brushTab;"
		for _, v630 in pairs(v627) do
			v629 = v629 .. v630.name .. ";"
		end
		v628:write(v629 .. "\n")
		local v631 = g_storeManager:getItems()
		for _, v632 in pairs(v631) do
			local v633 = g_brandManager:getBrandByIndex(v632.brandIndex)
			local v634, v635, v636
			if v632.brush == nil then
				v634 = ""
				v635 = ""
				v636 = ""
			else
				v634 = v632.brush.type
				v635 = v632.brush.category.name
				v636 = v632.brush.tab.name
			end
			local v637 = string.format("%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;", v632.xmlFilename, v632.categoryName, v633.name, v633.title, v632.name, v632.price, v632.lifetime, v632.dailyUpkeep, v632.showInStore, v634, v635, v636)
			StoreItemUtil.loadSpecsFromXML(v632)
			for _, v638 in pairs(v627) do
				local v639
				if v638.species == v632.species then
					v639 = v638.getValueFunc(v632, nil)
				else
					v639 = nil
				end
				local v640 = (v639 == nil or type(v639) == "table") and "" or v639
				if v638.name == "placeableSlots" then
					v640 = string.gsub(v640, " %$SLOTS%$", "")
				end
				v637 = v637 .. string.trim((tostring(v640))) .. ";"
			end
			v628:write(v637 .. "\n")
		end
		printf("Exported %i store items to \'%s\'", #v631, v626)
		v628:close()
	end
end
function FSBaseMission.consoleStartGreatDemand(p641)
	for _, v642 in pairs(p641.economyManager.greatDemands) do
		p641.economyManager:stopGreatDemand(v642)
	end
	for _, v643 in pairs(p641.economyManager.greatDemands) do
		v643:setUpRandomDemand(true, p641.economyManager.greatDemands, p641)
		v643.demandStart.day = g_currentMission.environment.currentDay
		v643.demandStart.hour = g_currentMission.environment.currentHour + 1
	end
	return "Great demand starts in the next hour..."
end
function FSBaseMission.consoleCommandTeleport(p644, p645, p646, p647)
	local v648 = tonumber(p645)
	local v649 = tonumber(p646)
	local v650 = Utils.stringToBoolean(p647)
	if v648 == nil then
		return "Error: Invalid farmland-id or x-position\nUsage: gsTeleport xPos|farmland [zPos] [useWorldCoords]\n  if zPos is not given first parameter is used as field id.\n  set useWorldCoords to true if given coordinates are in 3D/world (0 0 = map center) instead of minimap (0 0 = map corner) space."
	end
	if v649 == nil then
		local v651 = g_farmlandManager:getFarmlandById(v648)
		if v651 == nil then
			return string.format("Error: Invalid farmland id \'%s\'\n%s", v648, "Usage: gsTeleport xPos|farmland [zPos] [useWorldCoords]\n  if zPos is not given first parameter is used as field id.\n  set useWorldCoords to true if given coordinates are in 3D/world (0 0 = map center) instead of minimap (0 0 = map corner) space.")
		end
		v648, v649 = v651:getTeleportPosition()
	elseif not v650 then
		local v652 = p644.terrainSize
		local v653 = p644.terrainSize
		v648 = math.clamp(v648, 0, v652) - v652 * 0.5
		v649 = math.clamp(v649, 0, v653) - v653 * 0.5
	end
	local v654 = g_localPlayer:getCurrentVehicle()
	if v654 == nil then
		local v655 = getTerrainHeightAtWorldPos(g_terrainNode, v648, 0, v649)
		g_localPlayer:teleportTo(v648, v655 + 0.1, v649)
	else
		p644.isTeleporting = true
		local _, v656, _ = getWorldRotation(v654.rootNode)
		p644:teleportVehicle(v654, v648, v649, v656)
		p644.isTeleporting = false
	end
	return string.format("Teleported to world coordinates x=%d z=%d", v648, v649)
end
function FSBaseMission.consoleActivateCameraPath(p_u_657, p658)
	local v659 = tonumber(p658)
	if v659 == nil or (v659 < 1 or #p_u_657.cameraPaths < v659) then
		return "Invalid argument. Argument: cameraPathIndex"
	end
	if p_u_657.currentCameraPath ~= nil then
		p_u_657.currentCameraPath:deactivate()
	end
	p_u_657.currentCameraPath = p_u_657.cameraPaths[v659]
	function p_u_657.currentCameraPath.finishedCallback()
		-- upvalues: (copy) p_u_657
		print("camera path finished")
		p_u_657.currentCameraPath:deactivate()
	end
	p_u_657.currentCameraPath:activate()
	p_u_657:addUpdateable(p_u_657.currentCameraPath)
	return "Camera path activated"
end
function FSBaseMission.consoleCommandSaveDediXMLStatsFile(p660)
	p660:updateGameStatsXML()
end
function FSBaseMission.consoleCommandSaveGame(p661)
	p661:saveSavegame(true)
end
function FSBaseMission.consoleCommandDisplacementDebug(_)
	DebugDisplacementDialog.show()
end
function FSBaseMission.consoleCommandDisplacementReset(p662)
	local v663 = g_terrainNode
	local v664 = p662.fieldGroundSystem
	local v665, v666, v667 = v664:getDisplacementData()
	DensityMapModifier.new(v665, v666, v667, v663):executeSet((v664:getDisplacementResetValue()))
end
function FSBaseMission.consoleCommandValidateUnloadTriggers(_)
	I3DUtil.iterateRecursively(getRootNode(), function(p_u_668)
		if getHasClassId(p_u_668, ClassIds.SHAPE) and (getRigidBodyType(p_u_668) ~= RigidBodyType.DYNAMIC and (getHasCollision(p_u_668) and CollisionFlag.getHasGroupFlagSet(p_u_668, CollisionFlag.FILLABLE))) then
			local v669 = g_currentMission:getNodeObject(p_u_668)
			if v669 ~= nil and (v669.isa ~= nil and v669:isa(Vehicle)) then
				return
			end
			local v_u_670, v_u_671, v_u_672 = getWorldTranslation(p_u_668)
			local v673 = {}
			local v_u_674 = 0.03
			local v_u_675 = 0.2
			function v673.onRaycastHit(_, p676, _, p677, _)
				-- upvalues: (copy) p_u_668, (copy) v_u_670, (copy) v_u_672, (copy) v_u_671, (copy) v_u_674, (copy) v_u_675
				if p676 == g_terrainNode then
					Logging.error("Terrain is above trigger/unloadFillNode %q at %d %d", I3DUtil.getNodePath(p_u_668), v_u_670, v_u_672)
					return false
				end
				if p676 ~= p_u_668 then
					return true
				end
				local v678 = getTerrainHeightAtWorldPos(g_terrainNode, v_u_670, v_u_671, v_u_672)
				if p677 - v678 < 0.03 then
					Logging.warning("Terrain very close to trigger %q (trigger top face %.4f, terrain %.4f) at %d %d", I3DUtil.getNodePath(p_u_668), p677, v678, v_u_670, v_u_672)
					return false
				end
				local v679, _, v680 = RaycastUtil.raycastClosest(v_u_670, v_u_671 + 3, v_u_672, 0, -1, 0, 5, CollisionFlag.STATIC_OBJECT + CollisionFlag.ROAD + CollisionFlag.AI_DRIVABLE + CollisionFlag.TERRAIN)
				if v680 == nil or (v679 == p_u_668 or p677 - v680 <= 0.2) then
					return false
				end
				Logging.warning("trigger %q too far from terrain (trigger top face %.4f, col %s %.4f) at %d %d", I3DUtil.getNodePath(p_u_668), p677, getName(v679), v678, v_u_670, v_u_672)
				return false
			end
			raycastAll(v_u_670, v_u_671 + 3, v_u_672, 0, -1, 0, 5, "onRaycastHit", v673, CollisionFlag.FILLABLE + CollisionFlag.TERRAIN)
		end
	end)
end
function FSBaseMission.consoleCommandRunDSDensityMapUtil(_)
	FSDensityMapUtil.runBenchmark()
end
function FSBaseMission.updateFoundHelpIcons(p681)
	if p681.helpIconsBase ~= nil then
		local v682 = p681.missionInfo.foundHelpIcons
		for v683 = 1, string.len(v682) do
			local v684 = p681.missionInfo.foundHelpIcons
			if string.sub(v684, v683, v683) == "1" then
				p681.helpIconsBase:deleteHelpIcon(v683)
			end
		end
	end
end
function FSBaseMission.removeAllHelpIcons(p685)
	if p685.helpIconsBase ~= nil then
		local v686 = p685.missionInfo.foundHelpIcons
		for v687 = 1, string.len(v686) do
			p685.helpIconsBase:deleteHelpIcon(v687)
		end
	end
end
function FSBaseMission.playerOwnsAllFields(_)
	for v688, _ in pairs(g_farmlandManager:getFarmlands()) do
		g_client:getServerConnection():sendEvent(FarmlandStateEvent.new(v688, 1, 0))
	end
end
function FSBaseMission.broadcastEventToMasterUser(p689, p690, p691)
	for _, v692 in pairs(p689.userManager:getMasterUsers()) do
		local v693 = v692:getConnection()
		if v693 ~= p691 then
			v693:sendEvent(p690)
		end
	end
	p690:delete()
end
function FSBaseMission.broadcastMissionDynamicInfo(p694, p695)
	local v696 = p694:getIsServer()
	assert(v696, "broadcastMissionDynamicInfo call is only allowed on Server")
	p694:broadcastEventToMasterUser(MissionDynamicInfoEvent.new(), p695)
end
function FSBaseMission.updateMissionDynamicInfo(p697, p698, p699, p700, p701, p702, p703)
	if p698 ~= "" and g_dedicatedServer == nil then
		p697.missionDynamicInfo.serverName = p698
	end
	if g_dedicatedServer == nil then
		p697.missionDynamicInfo.capacity = p699
	end
	p697.missionDynamicInfo.password = p700
	p697.missionDynamicInfo.autoAccept = p701 or g_dedicatedServer ~= nil
	p697.missionDynamicInfo.allowOnlyFriends = p702
	p697.missionDynamicInfo.allowCrossPlay = p703
	p697:updateMaxNumHirables()
	if g_dedicatedServer ~= nil then
		p697:updateDedicatedServerXML()
	end
end
function FSBaseMission.updateMasterServerInfo(p704, p705)
	if p704:getIsServer() then
		local v706 = p704.userManager:getNumberOfUsers()
		if g_dedicatedServer ~= nil then
			v706 = v706 - 1
		end
		masterServerSetServerInfo(g_currentMission.missionDynamicInfo.serverName, g_currentMission.missionDynamicInfo.password, g_currentMission.missionDynamicInfo.capacity, v706, g_currentMission.missionDynamicInfo.allowOnlyFriends)
		p704:broadcastMissionDynamicInfo(p705)
	end
end
function FSBaseMission.updateDedicatedServerXML(p707)
	if g_dedicatedServer ~= nil then
		local v708 = p707.missionDynamicInfo
		g_dedicatedServer:updateServerInfo(v708.serverName, v708.password, v708.capacity)
	end
end
function FSBaseMission.updateGameStatsXML(p709)
	if g_dedicatedServer ~= nil then
		local v710 = g_dedicatedServer.gameStatsPath
		local v711 = createXMLFile("serverStatsFile", v710, "Server")
		if v711 == 0 then
			Logging.error("Failed to create serverStats xml file")
			return
		end
		local v712 = p709.missionDynamicInfo.serverName or ""
		local v713 = g_mapManager:getMapById(p709.missionInfo.mapId)
		local v714 = v713 == nil and "Unknown" or v713.title
		local v715 = p709.environment == nil and 0 or p709.environment.dayTime
		local v716 = p709.terrainSize or 2048
		local v717 = p709.userManager:getNumberOfUsers()
		if g_dedicatedServer ~= nil then
			v717 = v717 - 1
		end
		local v718 = p709.missionDynamicInfo.capacity or 0
		setXMLString(v711, "Server#game", g_gameTitle)
		setXMLString(v711, "Server#version", g_gameVersionDisplay .. g_gameVersionDisplayExtra)
		setXMLString(v711, "Server#name", HTMLUtil.encodeToHTML(v712))
		setXMLString(v711, "Server#mapName", HTMLUtil.encodeToHTML(v714))
		setXMLInt(v711, "Server#dayTime", v715)
		setXMLString(v711, "Server#mapOverviewFilename", NetworkUtil.convertToNetworkFilename(p709.mapImageFilename))
		setXMLInt(v711, "Server#mapSize", v716)
		setXMLInt(v711, "Server.Slots#capacity", v718)
		setXMLInt(v711, "Server.Slots#numUsed", v717)
		local v719 = 0
		for _, v720 in ipairs(p709.userManager:getUsers()) do
			local v721 = v720:getConnection()
			local v722
			if v721 == nil then
				v722 = nil
			else
				v722 = p709.connectionsToPlayer[v721]
			end
			if v720:getId() ~= p709:getServerUserId() or g_dedicatedServer == nil then
				local v723 = string.format("%s.Slots.Player(%d)", "Server", v719)
				local v724 = (p709.time - v720:getConnectedTime()) / 60000
				local v725 = math.round(v724)
				setXMLBool(v711, v723 .. "#isUsed", true)
				setXMLBool(v711, v723 .. "#isAdmin", v720:getIsMasterUser())
				setXMLInt(v711, v723 .. "#uptime", v725)
				if v722 ~= nil and (v722.isControlled and (v722.rootNode ~= nil and v722.rootNode ~= 0)) then
					local v726, v727, v728 = getWorldTranslation(v722.rootNode)
					setXMLFloat(v711, v723 .. "#x", v726)
					setXMLFloat(v711, v723 .. "#y", v727)
					setXMLFloat(v711, v723 .. "#z", v728)
				end
				setXMLString(v711, v723, HTMLUtil.encodeToHTML(v720:getNickname(), true))
				v719 = v719 + 1
			end
		end
		for _ = v717 + 1, v718 do
			local v729 = string.format("%s.Slots.Player(%d)", "Server", v719)
			setXMLBool(v711, v729 .. "#isUsed", false)
			v719 = v719 + 1
		end
		local v730 = 0
		for _, v731 in pairs(p709.vehicleSystem.vehicles) do
			if v731:saveStatsToXMLFile(v711, (string.format("%s.Vehicles.Vehicle(%d)", "Server", v730))) then
				v730 = v730 + 1
			end
		end
		local v732 = 0
		for _, v733 in pairs(p709.missionDynamicInfo.mods) do
			local v734 = string.format("%s.Mods.Mod(%d)", "Server", v732)
			setXMLString(v711, v734 .. "#name", HTMLUtil.encodeToHTML(v733.modName))
			setXMLString(v711, v734 .. "#author", HTMLUtil.encodeToHTML(v733.author))
			setXMLString(v711, v734 .. "#version", HTMLUtil.encodeToHTML(v733.version))
			setXMLString(v711, v734, HTMLUtil.encodeToHTML(v733.title, true))
			if v733.fileHash ~= nil then
				setXMLString(v711, v734 .. "#hash", HTMLUtil.encodeToHTML(v733.fileHash))
			end
			v732 = v732 + 1
		end
		local v735 = 0
		for _, v736 in pairs(g_farmlandManager:getFarmlands()) do
			local v737 = string.format("%s.Farmlands.Farmland(%d)", "Server", v735)
			local v738 = setXMLString
			local v739 = v737 .. "#name"
			local v740 = v736.name
			v738(v711, v739, (tostring(v740)))
			setXMLInt(v711, v737 .. "#id", v736.id)
			setXMLInt(v711, v737 .. "#owner", g_farmlandManager:getFarmlandOwner(v736.id))
			setXMLFloat(v711, v737 .. "#area", v736.areaInHa)
			setXMLInt(v711, v737 .. "#area", v736.price)
			setXMLFloat(v711, v737 .. "#x", v736.xWorldPos)
			setXMLFloat(v711, v737 .. "#z", v736.zWorldPos)
			v735 = v735 + 1
		end
		local v741 = 0
		for _, v742 in pairs(g_fieldManager:getFields()) do
			local v743 = string.format("%s.Fields.Field(%d)", "Server", v741)
			setXMLString(v711, v743 .. "#id", (tostring(v742:getId())))
			setXMLFloat(v711, v743 .. "#x", v742.posX)
			setXMLFloat(v711, v743 .. "#z", v742.posZ)
			setXMLBool(v711, v743 .. "#isOwned", v742:getHasOwner())
			v741 = v741 + 1
		end
		saveXMLFile(v711)
		delete(v711)
	end
	p709.gameStatsTime = p709.time + p709.gameStatsInterval
end
function FSBaseMission.setConnectionLostState(p744, p745)
	p744.connectionLostState = p745
end
function FSBaseMission.addMapHotspot(p746, p747)
	return p746.hud:addMapHotspot(p747)
end
function FSBaseMission.removeMapHotspot(p748, p749)
	if p748.hud ~= nil then
		p748.hud:removeMapHotspot(p749)
	end
end
function FSBaseMission.onShowHelpIconsChanged(p750, p751)
	if p750.helpIconsBase ~= nil then
		p750.helpIconsBase:showHelpIcons(p751)
	end
end
function FSBaseMission.onRadioVehicleOnlyChanged(p752, p753)
	local v754 = g_gameSettings:getValue(GameSettings.SETTING.RADIO_IS_ACTIVE)
	local v755 = g_localPlayer:getCurrentVehicle()
	local v756 = not p753
	if v756 then
		p753 = v756
	elseif p753 then
		if v755 == nil then
			p753 = false
		else
			p753 = v755.supportsRadio
		end
	end
	if v754 then
		if p753 then
			if not p752:getIsRadioPlaying() then
				p752:playRadio()
				return
			end
		else
			p752:pauseRadio()
		end
	end
end
function FSBaseMission.onRadioIsActiveChanged(p757, p758)
	if p758 then
		local v759 = g_gameSettings:getValue(GameSettings.SETTING.RADIO_VEHICLE_ONLY)
		local v760 = g_localPlayer:getCurrentVehicle()
		if not v759 or v759 and (v760 ~= nil and v760.supportsRadio) then
			p757:playRadio()
		end
	else
		p757:pauseRadio()
	end
end
function FSBaseMission.setRadioActionEventsState(p761, p762)
	for _, v763 in pairs(p761.radioEvents) do
		g_inputBinding:setActionEventActive(v763, p762)
	end
end
function FSBaseMission.subscribeMessages(p764)
	g_messageCenter:subscribe(SaveEvent, p764.startSaveCurrentGame, p764)
	g_messageCenter:subscribe(MessageType.PLAYER_FARM_CHANGED, p764.notifyPlayerFarmChanged, p764)
	g_messageCenter:subscribe(MessageType.USER_ADDED, p764.onUserAdded, p764)
	g_messageCenter:subscribe(MessageType.USER_REMOVED, p764.onUserRemoved, p764)
	g_messageCenter:subscribe(MessageType.MASTERUSER_ADDED, p764.onMasterUserAdded, p764)
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.IS_TRAIN_TABBABLE], p764.setTrainSystemTabbable, p764)
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.SHOW_HELP_ICONS], p764.onShowHelpIconsChanged, p764)
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.RADIO_VEHICLE_ONLY], p764.onRadioVehicleOnlyChanged, p764)
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.RADIO_IS_ACTIVE], p764.onRadioIsActiveChanged, p764)
	g_messageCenter:subscribe(MessageType.APP_SUSPENDED, p764.onAppSuspended, p764)
	g_messageCenter:subscribe(MessageType.APP_RESUMED, p764.onAppResumed, p764)
	g_messageCenter:subscribe(MessageType.WINDOW_SIZE_CHANGED, p764.onWindowSizeChanged, p764)
	g_messageCenter:subscribe(MessageType.GUIDED_TOUR_STARTED, p764.onGuidedTourStarted, p764)
	g_messageCenter:subscribe(MessageType.GUIDED_TOUR_FINISHED, p764.onGuidedTourFinished, p764)
	g_messageCenter:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.USE_COLORBLIND_MODE], p764.setColorBlindMode, p764)
end
function FSBaseMission.onWindowSizeChanged(p765)
	if p765.isLoaded then
		if GS_IS_MOBILE_VERSION and not g_savegameController:getIsSaving() then
			p765:saveSavegame(true)
		end
	end
end
function FSBaseMission.onAppSuspended(p766)
	if p766.isLoaded then
		if GS_IS_MOBILE_VERSION and not g_savegameController:getIsSaving() then
			p766:saveSavegame(true)
		end
	end
end
function FSBaseMission.onAppResumed(_)
	if not g_gui:getIsGuiVisible() then
		g_autoSaveManager:resetTime()
		if not g_sleepManager:getIsSleeping() then
			g_gui:changeScreen(nil, InGameMenu)
			if GS_IS_MOBILE_VERSION then
				g_inGameMenu:goToPage(g_inGameMenu.pageMain)
			end
		end
	end
end
function FSBaseMission.getCanShowHelpTriggers(p767)
	if g_guidedTourManager:getIsTourRunning() then
		return false
	else
		return FSBaseMission:superClass().getCanShowHelpTriggers(p767)
	end
end
function FSBaseMission.onGuidedTourStarted(_) end
function FSBaseMission.onGuidedTourFinished(_) end
function FSBaseMission.setColorBlindMode(p768, p769)
	if p768.mapOverlayGenerator ~= nil then
		p768.mapOverlayGenerator:setColorBlindMode(p769)
	end
end
function FSBaseMission.notifyPlayerFarmChanged(p770, p771)
	local v772 = g_localPlayer
	if v772 ~= nil and p771 == v772 then
		if p770:getIsClient() and v772:getIsInVehicle() then
			v772:leaveVehicle()
		end
		local v773 = g_farmManager:getFarmById(v772:getFarmId())
		g_inGameMenu:setPlayerFarm(v773)
		g_shopMenu:setPlayerFarm(v773)
		g_shopController:setOwnedFarmItems(p770.ownedItems, v772.farmId)
		g_shopController:setLeasedFarmItems(p770.leasedItems, v772.farmId)
		g_inGameMenu:onMoneyChanged(v773.farmId, v773:getBalance())
		g_shopMenu:onMoneyChanged(v773.farmId, v773:getBalance())
	end
end
function FSBaseMission.onUserAdded(p774, p775)
	p774:updateMaxNumHirables()
	if p775:getId() == p774.playerUserId then
		g_inGameMenu:setCurrentUserId(p774.playerUserId)
		g_shopMenu:setCurrentUserId(p774.playerUserId)
	end
	if p775:getId() ~= p774:getServerUserId() and p775:getId() ~= p774.playerUserId then
		print(p775:getNickname() .. " joined the game")
		g_currentMission:addChatMessage(p775:getNickname(), g_i18n:getText("ui_serverUserJoin"), FarmManager.SPECTATOR_FARM_ID)
	end
	p774:updateGameStatsXML()
	g_inGameMenu:setConnectedUsers(p774.userManager:getUsers())
	p774.userManager:setUserBlockDataDirty()
end
function FSBaseMission.onUserRemoved(p776, p777)
	p776:updateMaxNumHirables()
	if p777:getId() ~= p776:getServerUserId() and p777:getId() ~= p776.playerUserId then
		print(p777:getNickname() .. " left the game")
		g_currentMission:addChatMessage(p777:getNickname(), g_i18n:getText("ui_serverUserLeave"), FarmManager.SPECTATOR_FARM_ID)
	end
	p776:updateGameStatsXML()
	g_inGameMenu:setConnectedUsers(p776.userManager:getUsers())
end
function FSBaseMission.onMasterUserAdded(p778, p779)
	if p779:getId() == p778.playerUserId then
		p778.isMasterUser = true
		if g_addCheatCommands then
			addConsoleCommand("gsMoneyAdd", "Add a lot of money", "consoleCommandCheatMoney", p778, "[amount]; [farmId]")
		end
	end
	if p778:getIsServer() then
		g_server:broadcastEvent(UserDataEvent.new({ p779 }))
	end
end
function FSBaseMission.broadcastEventToFarm(p780, p781, p782, p783, p784, p785, p786)
	local v787 = {}
	for v788, v789 in pairs(g_server.clientConnections) do
		local v790 = p780.connectionsToPlayer[v789]
		if v790 ~= nil and v790.farmId == p782 then
			v787[v788] = v789
		end
	end
	g_server:broadcastEvent(p781, p783, p784, p785, p786, v787)
end
function FSBaseMission.getDefaultServerName(_)
	local v791 = g_gameSettings:getValue(GameSettings.SETTING.ONLINE_PRESENCE_NAME)
	if g_languageShort == "pl" then
		return v791 .. " - " .. g_i18n:getText("ui_serverNameGame")
	elseif v791:endsWith("s") then
		return v791 .. "\' " .. g_i18n:getText("ui_serverNameGame")
	elseif v791:endsWith("\'") then
		return v791 .. "s " .. g_i18n:getText("ui_serverNameGame")
	else
		return v791 .. "\'s " .. g_i18n:getText("ui_serverNameGame")
	end
end
function FSBaseMission.setLastCreatedLicensePlate(_, p792)
	if p792 ~= nil and p792.placementIndex ~= LicensePlateManager.PLATE_POSITION.NONE then
		local v793 = {
			["variation"] = p792.variation,
			["colorIndex"] = p792.colorIndex,
			["placementIndex"] = p792.placementIndex,
			["characters"] = table.clone(p792.characters),
			["xmlFilename"] = g_licensePlateManager.xmlFilename
		}
		g_gameSettings.lastCreatedLicensePlate = v793
		g_gameSettings:save()
	end
end
function FSBaseMission.getLastCreatedLicensePlate(_)
	local v794 = g_gameSettings.lastCreatedLicensePlate
	if v794 == nil then
		return nil
	elseif v794.xmlFilename == g_licensePlateManager.xmlFilename then
		return v794.characters ~= nil and {
			["variation"] = v794.variation,
			["colorIndex"] = v794.colorIndex,
			["placementIndex"] = v794.placementIndex,
			["characters"] = table.clone(v794.characters)
		} or nil
	else
		return nil
	end
end

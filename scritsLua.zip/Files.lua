Files = {}
local v_u_1 = Class(Files)
function Files.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1
	local v4 = setmetatable({}, v3)
	v4.path = p2
	v4.files = {}
	getFiles(p2, "fileCallbackFunction", v4)
	return v4
end
function Files.fileCallbackFunction(p5, p6, p7)
	local v8 = {
		["path"] = p5.path .. "/" .. p6,
		["filename"] = p6,
		["isDirectory"] = p7
	}
	local v9 = p5.files
	table.insert(v9, v8)
end
function Files.getFilesRecursive(p10)
	local v11 = Files.new(p10).files
	for v12 = #v11, 1, -1 do
		local v13 = v11[v12]
		if v13.isDirectory then
			local v14 = Files.getFilesRecursive(v13.path)
			for _, v15 in ipairs(v14) do
				table.insert(v11, v15)
			end
		end
	end
	return v11
end

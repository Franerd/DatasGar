io = {}
local v_u_1 = Class(io)
function io.open(p2, p3)
	-- upvalues: (copy) v_u_1
	if p3 ~= "w" then
		printWarning("Warning: io.open, only write mode (\'w\') is allowed")
	end
	local v4 = createFile(p2, FileAccess.WRITE)
	if v4 == 0 then
		return nil
	end
	local v5 = v_u_1
	local v6 = setmetatable({}, v5)
	v6.fileId = v4
	return v6
end
function io.close(p7)
	delete(p7.fileId)
	p7.fileId = 0
end
function io.write(p8, ...)
	for v9 = 1, select("#", ...) do
		local v10 = fileWrite
		local v11 = p8.fileId
		local v12 = select
		v10(v11, (tostring(v12(v9, ...))))
	end
end
function io.flush(_) end

XMLFile = {}
local v_u_1 = Class(XMLFile)
function XMLFile.load(p2, p3, p4)
	local v5 = loadXMLFile(p2, p3)
	if v5 == 0 then
		return nil
	else
		return XMLFile.new(p2, p3, v5, p4)
	end
end
function XMLFile.loadIfExists(p6, p7, p8)
	if p7 == nil or not fileExists(p7) then
		return nil
	else
		return XMLFile.load(p6, p7, p8)
	end
end
function XMLFile.create(p9, p10, p11, p12)
	local v13 = createXMLFile(p9, p10, p11)
	if v13 ~= 0 then
		return XMLFile.new(p9, p10, v13, p12)
	end
	Logging.error("Failed to create \'%s\' xml file", p9)
	return nil
end
function XMLFile.new(p14, p15, p16, p17)
	-- upvalues: (copy) v_u_1
	local v18 = v_u_1
	local v19 = setmetatable({}, v18)
	v19.objectName = p14
	v19.filename = p15
	v19.schema = p17
	v19.handle = p16
	v19:initInheritance()
	if g_xmlManager ~= nil then
		g_xmlManager:addFile(v19)
	end
	return v19
end
function XMLFile.wrap(p20, p21)
	local v22 = XMLFile.new(getName(p20) .. "<wrapped>", getXMLFilename(p20), p20, p21)
	v22.noDeletion = true
	return v22
end
function XMLFile.delete(p23)
	if not p23.noDeletion then
		delete(p23.handle)
	end
	if g_xmlManager ~= nil then
		g_xmlManager:removeFile(p23)
	end
end
function XMLFile.getHandle(p24)
	return p24.handle
end
function XMLFile.getFilename(p25)
	return p25.filename
end
function XMLFile.getAsString(p26)
	return saveXMLFileToMemory(p26.handle)
end
function XMLFile.hasProperty(p27, p28)
	local v29, v30 = hasXMLProperty(p27.handle, p28)
	return v29, v30
end
function XMLFile.getNumOfChildren(p31, p32)
	return getXMLNumOfChildren(p31.handle, p32)
end
function XMLFile.getNumOfElements(p33, p34)
	return getXMLNumOfElements(p33.handle, p34)
end
function XMLFile.getElementName(p35, p36)
	return getXMLElementName(p35.handle, p36)
end
function XMLFile.save(p37, p38, p39)
	if saveXMLFile(p37.handle) then
		if p38 then
			Logging.info("Saved xml file \'%s\' to \'%s\'", p37.objectName, p37.filename)
		end
		return true
	else
		if not p39 then
			Logging.error("Could not save xml file \'%s\' to \'%s\'", p37.objectName, p37.filename)
		end
		return false
	end
end
function XMLFile.saveTo(p40, p41, p42, p43)
	if saveXMLFileTo(p40.handle, p41) then
		if p42 then
			Logging.info("Saved xml file \'%s\' to \'%s\'", p40.objectName, p41)
		end
		return true
	else
		if not p43 then
			Logging.error("Could not save xml file \'%s\' to \'%s\'", p40.objectName, p41)
		end
		return false
	end
end
function XMLFile.removeProperty(p44, p45)
	removeXMLProperty(p44.handle, p45)
end
function XMLFile.setString(p46, p47, p48)
	setXMLString(p46.handle, p47, p48)
end
function XMLFile.setFloat(p49, p50, p51)
	setXMLFloat(p49.handle, p50, p51)
end
function XMLFile.setInt(p52, p53, p54)
	setXMLInt(p52.handle, p53, p54)
end
function XMLFile.setUInt(p55, p56, p57)
	setXMLUInt(p55.handle, p56, p57)
end
function XMLFile.setBool(p58, p59, p60)
	setXMLBool(p58.handle, p59, p60)
end
function XMLFile.addComment(p61, p62, p63)
	addXMLComment(p61.handle, p62, p63)
end
function XMLFile.getString(p64, p65, p66)
	return getXMLString(p64.handle, p65) or p66
end
function XMLFile.getFloat(p67, p68, p69)
	return getXMLFloat(p67.handle, p68) or p69
end
function XMLFile.getInt(p70, p71, p72)
	return getXMLInt(p70.handle, p71) or p72
end
function XMLFile.getUInt(p73, p74, p75)
	return getXMLUInt(p73.handle, p74) or p75
end
function XMLFile.getBool(p76, p77, p78)
	local v79 = getXMLBool(p76.handle, p77)
	if v79 == nil then
		return p78
	else
		return v79
	end
end
function XMLFile.getNode(p80, p81, p82, p83, p84)
	local v85 = getXMLString(p80.handle, p81)
	local v86, v87 = I3DUtil.indexToObject(p83, v85, p84)
	return v86 or p82, v87
end
function XMLFile.getRootName(p88)
	return getXMLRootName(p88.handle)
end
function XMLFile.getValue(p89, p90, p91, ...)
	local v92 = XMLFile.getValueType(p89, p90)
	if v92 == nil then
		return nil
	elseif v92.isBasicFunction then
		local v93 = v92.get(p89.handle, p90)
		if v93 == nil then
			return p91
		else
			return v93
		end
	else
		return v92.get(p89.handle, p90, p91, ...)
	end
end
function XMLFile.setValue(p94, p95, ...)
	local v96 = XMLFile.getValueType(p94, p95)
	if v96 ~= nil then
		v96.set(p94.handle, p95, ...)
	end
end
function XMLFile.iterate(p97, p98, p99)
	for v100 = 0, getXMLNumOfElements(p97.handle, p98) - 1 do
		if p99(v100 + 1, p98 .. "(" .. v100 .. ")") == false then
			break
		end
	end
end
function XMLFile.iterator(p101, p_u_102)
	local v_u_103 = 0
	local v_u_104 = getXMLNumOfElements(p101.handle, p_u_102)
	return function()
		-- upvalues: (ref) v_u_103, (copy) v_u_104, (copy) p_u_102
		if v_u_104 <= v_u_103 then
			return nil
		end
		v_u_103 = v_u_103 + 1
		return v_u_103, p_u_102 .. "(" .. v_u_103 - 1 .. ")"
	end
end
function XMLFile.iterateRecursively(p105, p106, p107, p108)
	local v109 = p108 or 0
	for v110 = 0, getXMLNumOfChildren(p105.handle, p106) - 1 do
		local v111 = getXMLElementName(p105.handle, p106 .. ".*(" .. v110 .. ")")
		local v112 = p106 .. ".*(" .. v110 .. ")"
		if p107(v111, v112, v110 + 1, v109) == false then
			return false
		end
		if getXMLNumOfChildren(p105.handle, v112) > 0 and p105:iterateRecursively(v112, p107, v109 + 1) == false then
			return false
		end
	end
	return true
end
function XMLFile.iteratorChildren(p_u_113, p114)
	local v_u_115 = 0
	local v_u_116 = getXMLNumOfChildren(p_u_113.handle, p114)
	local v_u_117 = nil
	local v_u_118 = p114 .. ".*"
	return function()
		-- upvalues: (ref) v_u_115, (copy) v_u_116, (ref) v_u_117, (ref) v_u_118, (copy) p_u_113
		if v_u_116 <= v_u_115 then
			return nil
		end
		v_u_115 = v_u_115 + 1
		v_u_117 = v_u_118 .. "(" .. v_u_115 - 1 .. ")"
		return v_u_115, v_u_117, getXMLElementName(p_u_113.handle, v_u_117)
	end
end
function XMLFile.setTable(_, p119, p120, p121)
	local v122 = p119 .. "("
	local v123 = 0
	for v124, v125 in pairs(p120) do
		local v126 = p121(v122 .. v123 .. ")", v125, v124)
		if v126 == false then
			break
		end
		if v126 ~= 0 then
			v123 = v123 + 1
		end
	end
	return v123
end
function XMLFile.setSortedTable(_, p127, p128, p129)
	local v130 = p127 .. "("
	local v131 = 0
	for v132, v133 in ipairs(p128) do
		local v134 = p129(v130 .. v131 .. ")", v133, v132)
		if v134 == false then
			break
		end
		if v134 ~= 0 then
			v131 = v131 + 1
		end
	end
	return v131
end
function XMLFile.getValueType(p135, p136)
	local v137 = p135.schema
	if v137 == nil then
		Logging.xmlError(p135, "Unable to get schema for xml file.")
		printCallstack()
		return
	elseif p136 == nil then
		Logging.xmlError(p135, "Unable to get value from unknown path.")
		printCallstack()
	else
		local v138 = p136:gsub("%(%d*%)", "(?)")
		local v139 = v137.paths[v138]
		if v139 == nil then
			local v140 = v138:gsub("%d+%.", "%?%."):gsub("%d+#", "%?#"):gsub("%d+$", "%?")
			v139 = v137.paths[v140]
		end
		if v139 ~= nil then
			return XMLValueType.TYPES[v139.valueTypeId]
		end
		Logging.xmlError(p135, "Failed to validate xml path \'%s\' for schema \'%s\'. Path not registered.", p136, v137.name)
		printCallstack()
	end
end
function XMLFile.setVector(p141, p142, p143)
	setXMLString(p141.handle, p142, table.concat(p143, " "))
end
function XMLFile.getVector(p144, p145, p146, p147)
	local v148 = getXMLString(p144.handle, p145)
	if v148 == nil then
		return p146
	else
		return string.getVector(v148, p147)
	end
end
function XMLFile.getRadiansVector(p149, p150, p151, p152)
	local v153 = getXMLString(p149.handle, p150)
	if v153 == nil then
		return p151
	else
		return string.getRadians(v153, p152)
	end
end
function XMLFile.getI18NValue(p154, p155, p156, p157, p158)
	return XMLUtil.getXMLI18NValue(p154.handle, p155, getXMLString, nil, p156, p157, p158)
end
function XMLFile.initInheritance(p_u_159)
	local v160 = p_u_159:getRootName()
	local v161 = p_u_159:getString(v160 .. ".parentFile#xmlFilename")
	if v161 ~= nil then
		if string.contains(v161, "$pdlcdir") or string.contains(v161, "$moddir") then
			Logging.xmlError(p_u_159, "Overwriting of dlc or mod files is not allowed!")
			return
		end
		local _, v162 = Utils.getModNameAndBaseDirectory(p_u_159.filename)
		local v163 = Utils.getFilename(v161, v162)
		local v_u_164 = loadXMLFile(p_u_159.objectName, v163)
		if v_u_164 ~= 0 then
			p_u_159:iterate(v160 .. ".parentFile.attributes.remove", function(_, p165)
				-- upvalues: (copy) p_u_159, (copy) v_u_164
				local v166 = p_u_159:getString(p165 .. "#path")
				removeXMLProperty(v_u_164, v166)
			end)
			p_u_159:iterate(v160 .. ".parentFile.attributes.set", function(_, p167)
				-- upvalues: (copy) p_u_159, (copy) v_u_164
				local v168 = p_u_159:getString(p167 .. "#path")
				local v169 = p_u_159:getString(p167 .. "#value")
				setXMLString(v_u_164, v168, v169)
			end)
			p_u_159:iterate(v160 .. ".parentFile.attributes.clearList", function(_, p170)
				-- upvalues: (copy) p_u_159, (copy) v_u_164
				local v171 = p_u_159:getString(p170 .. "#path")
				local v172 = p_u_159:getInt(p170 .. "#keepIndex")
				local v173 = 0
				while hasXMLProperty(v_u_164, string.format(v171 .. "(%d)", v173)) do
					v173 = v173 + 1
				end
				for v174 = v173, 1, -1 do
					if v174 ~= v172 then
						removeXMLProperty(v_u_164, string.format(v171 .. "(%d)", v174 - 1))
					end
				end
			end)
			delete(p_u_159.handle)
			p_u_159.handle = v_u_164
			return
		end
		Logging.xmlWarning(p_u_159, "Failed to load parent xml file \'%s\'", v163)
	end
end
function XMLFile.copyTree(p175, p176, p177, p178, p179)
	if not p178 then
		for v180 = 1, getXMLNumOfAttributes(p175.handle, p176) do
			local v181 = getXMLAttributeName(p175.handle, p176, v180 - 1)
			setXMLString(p175.handle, p177 .. "#" .. v181, getXMLString(p175.handle, p176 .. "#" .. v181))
		end
	end
	local v182 = {}
	for v183 = 1, getXMLNumOfChildren(p175.handle, p176) do
		local v184 = getXMLElementName(p175.handle, string.format("%s.*(%d)", p176, v183 - 1))
		if v182[v184] == nil then
			v182[v184] = true
			for v185 = 1, getXMLNumOfElements(p175.handle, p176 .. "." .. v184) do
				local v186 = string.format(".%s(%d)", v184, v185 - 1)
				if (p179 == nil or not string.endsWith(p176 .. "." .. v184, p179)) and true or false then
					p175:copyTree(p176 .. "." .. v184, p177 .. "." .. v184, false, p179)
					p175:copyTree(p176 .. v186, p177 .. v186, false, p179)
				end
			end
		end
	end
end

TestXML = {}
function TestXML.init()
	local v1 = nil
	local v2 = nil
	local v3 = nil
	v1 = XMLFile.load("testXml", "../tools/studio/Farming_Simulator_25_Dev.xml")
	v2 = 0
	v3 = {}
	local v4 = v2
	local v_u_5 = v1
	local v_u_6 = v3
	for _ = 0, 200 do
		local v7 = openIntervalTimer()
		v_u_5:iterate("scriptBinding.function", function(_, p8)
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v9 = v_u_6
			local v10 = v_u_5
			local v11 = p8 .. "#name"
			table.insert(v9, v10:getString(v11))
			v_u_5:iterate(p8 .. ".input.param", function(_, p12)
				-- upvalues: (ref) v_u_6, (ref) v_u_5
				local v13 = v_u_6
				local v14 = v_u_5
				local v15 = p12 .. "#type"
				table.insert(v13, v14:getString(v15))
			end)
		end)
		v2 = v4 + readIntervalTimerMs(v7)
		closeIntervalTimer(v7)
		v4 = v2
	end
	log(v4, "closure", "numOuputs", #v_u_6)
	v_u_5:delete()
	v1 = XMLFile.load("testXml", "../tools/studio/Farming_Simulator_25_Dev.xml")
	v2 = 0
	v3 = {}
	local v16 = v2
	local v17 = v3
	local v18 = v1
	for _ = 0, 200 do
		local v19 = openIntervalTimer()
		for _, v20 in v18:iterator("scriptBinding.function") do
			local v21 = v20 .. "#name"
			table.insert(v17, v18:getString(v21))
			for _, v22 in v18:iterator(v20 .. ".input.param") do
				local v23 = v22 .. "#type"
				table.insert(v17, v18:getString(v23))
			end
		end
		v2 = v16 + readIntervalTimerMs(v19)
		closeIntervalTimer(v19)
		v16 = v2
	end
	log(v16, "iterator", "numOuputs", #v17)
	v18:delete()
	v1 = XMLFile.load("testXml", "../tools/studio/Farming_Simulator_25_Dev.xml")
	v2 = 0
	v3 = {}
	local v24 = v2
	local v25 = v3
	local v26 = v1
	for _ = 0, 200 do
		local v27 = openIntervalTimer()
		for _, v28, v29 in v26:iteratorChildren("scriptBinding") do
			if v29 == "function" then
				local v30 = v28 .. "#name"
				table.insert(v25, v26:getString(v30))
				for _, v31, _ in v26:iteratorChildren(v28 .. ".input") do
					local v32 = v31 .. "#type"
					table.insert(v25, v26:getString(v32))
				end
			end
		end
		v2 = v24 + readIntervalTimerMs(v27)
		closeIntervalTimer(v27)
		v24 = v2
	end
	log(v24, "iteratorChildren", "numOuputs", #v25)
	v26:delete()
end
function TestXML.update(_) end
function TestXML.draw() end
function TestXML.mouseEvent(_, _, _, _, _) end
function TestXML.keyEvent(_, _, _, _) end

XMLManager = {}
local v_u_1 = Class(XMLManager)
function XMLManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.schemas = {}
	v4.files = {}
	v4.earlyCreateSchemaFunctions = {}
	v4.earlyInitSchemaFunctions = {}
	v4.createSchemaFunctions = {}
	v4.initSchemaFunctions = {}
	return v4
end
function XMLManager.unloadMapData(p5)
	p5.schemas = {}
end
function XMLManager.addSchema(p6, p7)
	local v8 = p6.schemas
	table.insert(v8, p7)
end
function XMLManager.addFile(p9, p10)
	p9.files[p10.handle] = p10
end
function XMLManager.removeFile(p11, p12)
	p11.files[p12.handle] = nil
end
function XMLManager.getFileByHandle(p13, p14)
	return p13.files[p14]
end
function XMLManager.addEarlyCreateSchemaFunction(p15, p16)
	local v17 = p15.earlyCreateSchemaFunctions
	table.insert(v17, p16)
end
function XMLManager.addCreateSchemaFunction(p18, p19)
	local v20 = p18.createSchemaFunctions
	table.insert(v20, p19)
end
function XMLManager.earlyCreateSchemas(p21)
	for _, v22 in ipairs(p21.earlyCreateSchemaFunctions) do
		v22()
	end
end
function XMLManager.createSchemas(p23)
	for _, v24 in ipairs(p23.createSchemaFunctions) do
		v24()
	end
end
function XMLManager.addEarlyInitSchemaFunction(p25, p26)
	local v27 = p25.earlyInitSchemaFunctions
	table.insert(v27, p26)
end
function XMLManager.addInitSchemaFunction(p28, p29)
	local v30 = p28.initSchemaFunctions
	table.insert(v30, p29)
end
function XMLManager.earlyInitSchemas(p31)
	for _, v_u_32 in ipairs(p31.earlyInitSchemaFunctions) do
		g_asyncTaskManager:addSubtask(function()
			-- upvalues: (copy) v_u_32
			v_u_32()
		end)
	end
end
function XMLManager.initSchemas(p33)
	for _, v_u_34 in ipairs(p33.initSchemaFunctions) do
		g_asyncTaskManager:addSubtask(function()
			-- upvalues: (copy) v_u_34
			v_u_34()
		end)
	end
end
function XMLManager.consoleCommandGenerateSchemas()
	if g_xmlManager ~= nil then
		local v35 = {}
		for v36 = 1, #g_xmlManager.schemas do
			local v37 = g_xmlManager.schemas[v36]
			v37:generateSchema()
			v37:generateHTML()
			table.insert(v35, v37)
		end
		table.sort(v35, function(p38, p39)
			return p38.name < p39.name
		end)
		local v40 = string.format("shared/xml/documentation/overview.html")
		local v41 = io.open(v40, "w")
		v41:write("<!DOCTYPE html>\n")
		v41:write("<html>\n")
		v41:write("  <head>\n")
		v41:write("    <title>XML Documentation (v" .. g_gameVersionDisplay .. ")</title>\n")
		v41:write("  </head>\n")
		v41:write("  <style>\n")
		v41:write("    li {\n")
		v41:write("      margin: 5px;\n")
		v41:write("    }\n")
		v41:write("    a {\n")
		v41:write("      text-decoration:none;\n")
		v41:write("      font-size: 15pt;\n")
		v41:write("      color: #000000;\n")
		v41:write("    }\n")
		v41:write("  </style>\n")
		v41:write("<body>\n")
		v41:write("  <h1>Schema Overview</h1>\n")
		v41:write("  <ul>\n")
		for _, v42 in ipairs(v35) do
			v41:write("   <li><a href=\"" .. v42.name .. ".html\">" .. v42.name .. "</a></li>\n")
		end
		v41:write("  </ul>\n")
		v41:write("</body>\n")
		v41:write("</html>\n")
		v41:close()
	end
end
addConsoleCommand("gsXMLGenerateSchemas", "Generates xml schemas", "XMLManager.consoleCommandGenerateSchemas", nil)
g_xmlManager = XMLManager.new()

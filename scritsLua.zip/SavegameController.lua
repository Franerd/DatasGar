SavegameController = {}
local v_u_1 = Class(SavegameController)
if GS_PLATFORM_PC then
	SavegameController.NUM_SAVEGAMES = 20
	SavegameController.SAVING_DURATION = 0.5
elseif GS_IS_MOBILE_VERSION then
	SavegameController.NUM_SAVEGAMES = 3
	SavegameController.SAVING_DURATION = 1
else
	SavegameController.NUM_SAVEGAMES = 10
	SavegameController.SAVING_DURATION = 3
end
SavegameController.SAVE_STATE_NONE = 0
SavegameController.SAVE_STATE_VALIDATE_LIST = 1
SavegameController.SAVE_STATE_VALIDATE_LIST_DIALOG_WAIT = 2
SavegameController.SAVE_STATE_VALIDATE_LIST_WAIT = 3
SavegameController.SAVE_STATE_OVERWRITE_DIALOG = 4
SavegameController.SAVE_STATE_OVERWRITE_DIALOG_WAIT = 5
SavegameController.SAVE_STATE_NOP_WRITE = 6
SavegameController.SAVE_STATE_WRITE = 7
SavegameController.SAVE_STATE_WRITE_WAIT = 8
SavegameController.SAVE_TASK_DENSITY_MAP = 0
SavegameController.SAVE_TASK_TERRAIN_HEIGHT_MAP = 1
SavegameController.SAVE_TASK_TERRAIN_LOD_TYPE_MAP = 2
SavegameController.SAVE_TASK_COLLISION_MAP = 3
SavegameController.SAVE_TASK_PLACEMENT_BLOCKING_MAP = 4
SavegameController.SAVE_TASK_SPLIT_SHAPES = 5
SavegameController.SAVE_TASK_BITVECTOR_MAP = 6
SavegameController.SAVE_TASK_NAVIGATION_MAP = 7
SavegameController.UPLOAD_STATE_OK = 0
SavegameController.UPLOAD_STATE_BAD_INDEX = 4
SavegameController.UPLOAD_STATE_LOAD_FAILED = 9
SavegameController.UPLOAD_STATE_PROGRESS = 11
SavegameController.INFO_INVALID_USER = "invalidUser"
SavegameController.INFO_CORRUPT_FILE = "corrupt"
SavegameController.NO_SAVEGAME = {}
local v_u_2 = {
	["NO_CALLBACK"] = function() end
}
function SavegameController.new(p3)
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.savegames = {}
	v5.isSavingGame = false
	v5.waitingForSaveGameInfo = false
	v5.savingErrorCode = Savegame.ERROR_OK
	v5.onDeleteCallback = v_u_2.NO_CALLBACK
	v5.onDeleteCallbackTarget = v_u_2
	v5.onSaveCompleteCallback = v_u_2.NO_CALLBACK
	v5.onSaveCompleteCallbackTarget = v_u_2
	v5.onUpdateCompleteCallback = v_u_2.NO_CALLBACK
	v5.onUpdateCompleteTarget = v_u_2
	saveSetCloudErrorCallback("onCloudError", v5)
	return v5
end
function SavegameController.loadSavegames(p6)
	for v7, v8 in pairs(p6.savegames) do
		v8:delete()
		p6.savegames[v7] = nil
	end
	local v9 = Files.new(getUserProfileAppPath())
	for v10 = 1, SavegameController.NUM_SAVEGAMES do
		local v11 = FSCareerMissionInfo.new("", nil, v10)
		if not Platform.isConsole then
			for _, v12 in ipairs(v9.files) do
				if v12.filename == "savegame" .. v10 .. ".zip" and not v12.isDirectory then
					Logging.warning("Savegame %d is loaded from a ZIP file, but saving happens in a directory.", v10)
					break
				end
			end
		end
		v11:loadDefaults()
		local v14, v14, _, v15 = saveGetInfoById(v10)
		local v16 = nil
		if v14 ~= "" then
			v11.hasConflict = v14 ~= ""
			v11.isSoftConflict = v15
			v11.conflictedMetadata = v14
			v11.uploadState = saveGetUploadState(v10)
			if v11.hasConflict then
				local _ = v11.isSoftConflict
			end
			if v14 == SavegameController.INFO_INVALID_USER then
				v11.isInvalidUser = true
			elseif v14 == SavegameController.INFO_CORRUPT_FILE then
				v11.isCorruptFile = true
			else
				v16 = loadXMLFileFromMemory("careerSavegameXML", v14)
			end
		end
		if v16 ~= nil then
			if not v11:loadFromXML(v16) then
				v11:loadDefaults()
			end
			delete(v16)
		end
		local v17 = p6.savegames
		table.insert(v17, v11)
	end
	g_messageCenter:publish(MessageType.SAVEGAMES_LOADED)
end
function SavegameController.resetStorageDeviceSelection(_)
	saveResetStorageDeviceSelection()
end
function SavegameController.onBrokenSavegameUploadProgress(p18, p19, p20)
	if p18.brokenSavegameUploadCallback ~= nil then
		p18.brokenSavegameUploadCallback(p18.brokenSavegameUploadTarget, p19, p20)
	end
end
function SavegameController.uploadBrokenSavegame(p21, p22, p23, p24, p25)
	if saveUploadSavegameDebugInfo == nil then
		return false
	end
	p21.brokenSavegameUploadCallback = p24
	p21.brokenSavegameUploadTarget = p25
	saveUploadSavegameDebugInfo(p22, p23, "onBrokenSavegameUploadProgress", p21)
	return true
end
function SavegameController.updateSavegames(p26, p27, p28)
	-- upvalues: (copy) v_u_2
	if not p26.waitingForSaveGameInfo then
		p26.waitingForSaveGameInfo = true
		p26.onUpdateCompleteCallback = p27 or v_u_2.NO_CALLBACK
		p26.onUpdateCompleteTarget = p28 or v_u_2
		saveUpdateList("onSaveGameUpdateComplete", p26)
	end
end
function SavegameController.cancelSavegameUpdate(_)
	saveCancelUpdateList()
end
function SavegameController.onSaveGameUpdateComplete(p29, p30)
	p29.waitingForSaveGameInfo = false
	p29.onUpdateCompleteCallback(p29.onUpdateCompleteTarget, p30)
end
function SavegameController.onSaveGameUpdateCompleteCloudError(p31, _)
	p31.waitingForSaveGameInfo = false
	p31:loadSavegames()
	p31:tryToResolveConflict(p31.cloudErrorConflictedSavegame)
	p31.cloudErrorConflictedSavegame = nil
end
function SavegameController.onCloudError(p32, p33, p34)
	local v35 = tonumber(p34)
	if p33 == Savegame.ERROR_CLOUD_CONFLICT then
		p32:updateSavegames(p32.onSaveGameUpdateCompleteCloudError, p32)
		p32.cloudErrorConflictedSavegame = v35
	end
end
function SavegameController.tryToResolveConflict(p36, p37, p38, p39, p40)
	local v41 = p36:getSavegame(p37)
	if v41 ~= SavegameController.NO_SAVEGAME and v41.hasConflict then
		if v41.isSoftConflict then
			p36:resolveConflict(p37, SaveGameResolvePolicy.KEEP_REMOTE)
			v41.hasConflict = false
			return
		end
		SavegameConflictDialog.show(p38, p39, v41, p37, p40)
	end
end
function SavegameController.resolveConflict(p42, p43, p44)
	if p44 == SaveGameResolvePolicy.KEEP_BOTH and p42:getNumValidSavegames() == SavegameController.NUM_SAVEGAMES then
		InfoDialog.show(g_i18n:getText("ui_savegameConflictResolveKeepBothFailed"), p42.savegameConflictResolveKeepBothFailed, p42, nil, nil, nil, {
			["savegameId"] = p43
		})
		return false
	end
	if g_currentMission ~= nil then
		if p44 == SaveGameResolvePolicy.KEEP_BOTH then
			p42:executeResolveConflict(p43, p44)
			p42:returnToSavegameSelection()
			return true
		end
		if p44 == SaveGameResolvePolicy.KEEP_REMOTE then
			local v45 = g_i18n:getText("ui_savegameConflictKeepRemoteYesNo")
			local v46 = p42.onYesNoConflictKeepRemote
			local v47 = g_i18n:getText("button_continue")
			local v48 = g_i18n:getText("button_cancel")
			YesNoDialog.show(v46, p42, v45, nil, v47, v48, nil, nil, nil, {
				["savegameId"] = p43
			})
			return true
		end
	end
	p42:executeResolveConflict(p43, p44)
	return true
end
function SavegameController.onYesNoConflictKeepRemote(p49, p50, p51)
	if p50 then
		p49:executeResolveConflict(p51.savegameId, SaveGameResolvePolicy.KEEP_REMOTE)
		p49:returnToSavegameSelection()
	else
		p49:tryToResolveConflict(p51.savegameId)
	end
end
function SavegameController.savegameConflictResolveKeepBothFailed(p52, p53)
	p52:tryToResolveConflict(p53.savegameId, nil, nil, false)
end
function SavegameController.executeResolveConflict(p54, p55, p56)
	p54.currentSavegameToResolve = p55
	saveResolveConflict(p55, p56, "onResolveConflictComplete", p54)
end
function SavegameController.onResolveConflictComplete(p57, p58, _)
	local v59 = p57.currentSavegameToResolve
	p57.currentSavegameToResolve = nil
	if p58 == Savegame.ERROR_RESOLVE_FAILED then
		InfoDialog.show(g_i18n:getText("ui_savegameConflictResolveFailed"), p57.returnToSavegameSelection, p57)
	elseif v59 ~= nil then
		local v60 = p57:getSavegame(v59)
		if v60 ~= SavegameController.NO_SAVEGAME then
			v60.hasConflict = false
		end
	end
end
function SavegameController.returnToSavegameSelection(_)
	OnInGameMenuMenu()
	if g_gui.currentGuiName == "MainScreen" then
		g_mainScreen:onCareerClick(g_mainScreen.careerButton)
	end
end
function SavegameController.locateBackups(_, p61, p62)
	local v63 = Files.new(p61)
	local v64 = {}
	for _, v65 in pairs(v63.files) do
		if v65.isDirectory and v65.filename:startsWith(p62) then
			local v66, v67, v68, v69, v70 = v65.filename:sub(p62:len() + 1):match("^(%d%d%d%d)-(%d%d)-(%d%d)_(%d%d)-(%d%d)$")
			local v71 = tonumber(v66)
			local v72 = tonumber(v67)
			local v73 = tonumber(v68)
			local v74 = tonumber(v69)
			local v75 = tonumber(v70)
			if v71 ~= nil and (v72 ~= nil and (v73 ~= nil and (v74 ~= nil and v75 ~= nil))) then
				local v76 = {
					["filename"] = v65.filename,
					["toDelete"] = true,
					["time"] = {
						v71,
						v72,
						v73,
						v74,
						v75
					}
				}
				table.insert(v64, v76)
			end
		end
	end
	return v64
end
function SavegameController.assignBackupDeleteFlags(p77, p78, p79)
	table.sort(p79, SavegameController.backupSortFunction)
	local v80 = #p79
	for v81 = 1, math.min(4, v80) do
		p79[v81].toDelete = false
	end
	local v82, v83, v84, v85, _ = p78:match("(%d%d%d%d)-(%d%d)-(%d%d)_(%d%d)-(%d%d)")
	local v86 = tonumber(v82)
	local v87 = tonumber(v83)
	local v88 = tonumber(v84)
	local v89 = tonumber(v85)
	for _, v90 in pairs(p77.BACKUP_DATE_OFFSETS) do
		local v91, v92, v93, v94, v95 = getDateAt("%Y-%m-%d_%H-%M", v86, v87, v88, v89, 0, 0, -v90[1] * 60 * 60, v90[2] * 60 * 60):match("(%d%d%d%d)-(%d%d)-(%d%d)_(%d%d)-(%d%d)")
		local v96 = tonumber(v91)
		local v97 = tonumber(v92)
		local v98 = tonumber(v93)
		local v99 = tonumber(v94)
		local v100 = tonumber(v95)
		local v101 = nil
		local v102 = 0
		for _, v103 in pairs(p79) do
			local v104 = getDateDiffSeconds(v103.time[1], v103.time[2], v103.time[3], v103.time[4], v103.time[5], 0, v96, v97, v98, v99, v100, 0)
			local v105 = math.abs(v104)
			if v101 == nil or v105 < v102 then
				v102 = v105
				v101 = v103
			end
		end
		if v101 ~= nil then
			v101.toDelete = false
		end
	end
end
function SavegameController.createBackup(_, p106, p107, p108, p109)
	createFolder(p107)
	createFolder(p108)
	local v110 = Files.new(p106.savegameDirectory)
	for _, v111 in pairs(v110.files) do
		if not v111.isDirectory then
			copyFile(p106.savegameDirectory .. "/" .. v111.filename, p108 .. "/" .. v111.filename, true)
		end
	end
	local v112 = io.open(p107 .. "/" .. p106:getSavegameAutoBackupLatestFilename(p106.savegameIndex), "w")
	if v112 ~= nil then
		v112:write("Latest auto backup directory: " .. p109)
		v112:close()
	end
end
function SavegameController.backupSavegame(p113, p114)
	if p114.isValid then
		local v115 = getDate("%Y-%m-%d_%H-%M")
		local v116 = p114:getSavegameAutoBackupBasePath()
		local v117 = p114:getSavegameAutoBackupDirectoryBase(p114.savegameIndex)
		local v118 = v117 .. v115
		local v119 = v116 .. "/" .. v118
		local v120 = p113:locateBackups(v116, v117)
		if #v120 > 0 then
			p113:assignBackupDeleteFlags(v115, v120)
			for _, v121 in pairs(v120) do
				if v121.toDelete then
					deleteFolder(v116 .. "/" .. v121.filename)
				end
			end
		end
		p113:createBackup(p114, v116, v119, v118)
	end
end
function SavegameController.addSaveTask(p122, p123, p124)
	local v125 = p122.saveTasks
	table.insert(v125, {
		["type"] = p123,
		["param"] = p124
	})
end
function SavegameController.executeSaveTask(p126)
	if p126.currentSaveTask > #p126.saveTasks then
		p126:onSaveTaskComplete(true)
		return
	else
		local v127 = p126.saveTasks[p126.currentSaveTask]
		p126.currentSaveTask = p126.currentSaveTask + 1
		if v127.type == SavegameController.SAVE_TASK_DENSITY_MAP then
			savePreparedDensityMapToFile(v127.param, "onSaveTaskComplete", p126)
			return
		elseif v127.type == SavegameController.SAVE_TASK_TERRAIN_LOD_TYPE_MAP then
			savePreparedTerrainLodTypeMap(v127.param, "onSaveTaskComplete", p126)
			return
		elseif v127.type == SavegameController.SAVE_TASK_TERRAIN_HEIGHT_MAP then
			savePreparedTerrainHeightMap(v127.param, "onSaveTaskComplete", p126)
			return
		elseif v127.type == SavegameController.SAVE_TASK_COLLISION_MAP then
			g_densityMapHeightManager:savePreparedCollisionMap("onSaveTaskComplete", p126)
			return
		elseif v127.type == SavegameController.SAVE_TASK_PLACEMENT_BLOCKING_MAP then
			g_densityMapHeightManager:savePreparedPlacementCollisionMap("onSaveTaskComplete", p126)
			return
		elseif v127.type == SavegameController.SAVE_TASK_SPLIT_SHAPES then
			savePreparedSplitShapesToFile("onSaveTaskComplete", p126)
			return
		elseif v127.type == SavegameController.SAVE_TASK_BITVECTOR_MAP then
			savePreparedBitVectorMapToFile(v127.param, "onSaveTaskComplete", p126)
		elseif v127.type == SavegameController.SAVE_TASK_NAVIGATION_MAP then
			savePreparedVehicleNavigationCostMapToFile(v127.param, "onSaveTaskComplete", p126)
		end
	end
end
function SavegameController.onSaveTaskComplete(p128, _)
	if p128.currentSaveTask > #p128.saveTasks then
		saveWriteSavegameFinish(p128.savegameMetadata, p128.savegameDisplayDesc, "onSaveComplete", p128)
	else
		p128:executeSaveTask()
	end
end
function SavegameController.onSaveStartComplete(p_u_129, p130, p131)
	p_u_129.savingErrorCode = p130
	if p130 == Savegame.ERROR_OK and p131 ~= nil then
		local v132
		if p_u_129.isSavingBlocking then
			v132 = startFrameRepeatMode()
		else
			v132 = false
		end
		p_u_129.saveTasks = {}
		p_u_129.currentSaveTask = 1
		local v_u_133 = p_u_129.currentSavegame
		v_u_133:setSavegameDirectory(p131)
		v_u_133:saveToXMLFile()
		local v134 = v_u_133.playTime / 60 + 0.0001
		local v135 = math.floor(v134)
		local v136 = (v134 - v135) * 60
		local v137 = math.floor(v136)
		p_u_129.savegameDisplayDesc = v_u_133.map.title .. "\n" .. g_i18n:formatMoney(0) .. "\n" .. string.format("%02d:%02d", v135, v137)
		local v_u_138 = v_u_133.savegameDirectory
		local v139 = {}
		for _, v140 in pairs(g_fruitTypeManager:getFruitTypes()) do
			local v_u_141 = v140.terrainDataPlaneId
			local v_u_142 = v140.terrainDataPlaneIdHaulm
			if v_u_141 ~= nil then
				local v_u_143 = getDensityMapFilename(v_u_141)
				if v139[v_u_143] == nil then
					v139[v_u_143] = true
					if p_u_129.isSavingBlocking then
						saveDensityMapToFile(v_u_141, v_u_138 .. "/" .. v_u_143)
					else
						g_asyncTaskManager:addTask(function()
							-- upvalues: (copy) v_u_141, (copy) v_u_138, (copy) v_u_143, (copy) p_u_129
							prepareSaveDensityMapToFile(v_u_141, v_u_138 .. "/" .. v_u_143)
							p_u_129:addSaveTask(SavegameController.SAVE_TASK_DENSITY_MAP, v_u_141)
						end)
					end
				end
			end
			if v_u_142 ~= nil then
				local v_u_144 = getDensityMapFilename(v_u_142)
				if v139[v_u_144] == nil then
					v139[v_u_144] = true
					if p_u_129.isSavingBlocking then
						saveDensityMapToFile(v_u_142, v_u_138 .. "/" .. v_u_144)
					else
						g_asyncTaskManager:addTask(function()
							-- upvalues: (copy) v_u_142, (copy) v_u_138, (copy) v_u_144, (copy) p_u_129
							prepareSaveDensityMapToFile(v_u_142, v_u_138 .. "/" .. v_u_144)
							p_u_129:addSaveTask(SavegameController.SAVE_TASK_DENSITY_MAP, v_u_142)
						end)
					end
				end
			end
		end
		local v_u_145 = g_currentMission.weedSystem:getDensityMapData()
		if v_u_145 ~= nil then
			local v146 = getDensityMapFilename(v_u_145)
			local v_u_147 = v_u_138 .. "/" .. v146
			if v139[v146] == nil then
				v139[v146] = true
				if p_u_129.isSavingBlocking then
					saveDensityMapToFile(v_u_145, v_u_147)
				else
					g_asyncTaskManager:addTask(function()
						-- upvalues: (copy) v_u_145, (copy) v_u_147, (copy) p_u_129
						prepareSaveDensityMapToFile(v_u_145, v_u_147)
						p_u_129:addSaveTask(SavegameController.SAVE_TASK_DENSITY_MAP, v_u_145)
					end)
				end
			end
		end
		local v_u_148 = g_currentMission.weedSystem:getInfoLayer()
		if v_u_148 ~= nil then
			local v149 = v_u_148.filename
			local v_u_150 = v_u_138 .. "/" .. v149
			if v139[v149] == nil then
				v139[v149] = true
				if p_u_129.isSavingBlocking then
					saveBitVectorMapToFile(v_u_148.map, v_u_150)
				else
					g_asyncTaskManager:addTask(function()
						-- upvalues: (copy) v_u_148, (copy) v_u_150, (copy) p_u_129
						prepareSaveBitVectorMapToFile(v_u_148.map, v_u_150)
						p_u_129:addSaveTask(SavegameController.SAVE_TASK_BITVECTOR_MAP, v_u_148.map)
					end)
				end
			end
		end
		local v_u_151 = g_currentMission.aiSystem:getNavigationMap()
		if v_u_151 ~= nil then
			local v152 = g_currentMission.aiSystem:getNavigationMapFilename()
			local v_u_153 = v_u_138 .. "/" .. v152
			if v139[v152] == nil then
				v139[v152] = true
				if p_u_129.isSavingBlocking then
					saveVehicleNavigationCostMapToFile(v_u_151, v_u_153)
				else
					g_asyncTaskManager:addTask(function()
						-- upvalues: (copy) v_u_151, (copy) v_u_153, (copy) p_u_129
						prepareSaveVehicleNavigationCostMapToFile(v_u_151, v_u_153)
						p_u_129:addSaveTask(SavegameController.SAVE_TASK_NAVIGATION_MAP, v_u_151)
					end)
				end
			end
		end
		local v_u_154 = g_currentMission.stoneSystem:getDensityMapData()
		if v_u_154 ~= nil then
			local v_u_155 = getDensityMapFilename(v_u_154)
			if v139[v_u_155] == nil then
				v139[v_u_155] = true
				if p_u_129.isSavingBlocking then
					saveDensityMapToFile(v_u_154, v_u_138 .. "/" .. v_u_155)
				else
					g_asyncTaskManager:addTask(function()
						-- upvalues: (copy) v_u_154, (copy) v_u_138, (copy) v_u_155, (copy) p_u_129
						prepareSaveDensityMapToFile(v_u_154, v_u_138 .. "/" .. v_u_155)
						p_u_129:addSaveTask(SavegameController.SAVE_TASK_DENSITY_MAP, v_u_154)
					end)
				end
			end
		end
		local v156 = g_currentMission.fieldGroundSystem:getDensityMaps()
		for _, v_u_157 in pairs(v156) do
			local v158 = v_u_157.filename
			local v_u_159 = v_u_138 .. "/" .. v158
			if v139[v158] == nil then
				v139[v158] = true
				if p_u_129.isSavingBlocking then
					if v_u_157.isBitVector then
						saveBitVectorMapToFile(v_u_157.map, v_u_159)
					else
						saveDensityMapToFile(v_u_157.map, v_u_159)
					end
				else
					g_asyncTaskManager:addTask(function()
						-- upvalues: (copy) v_u_157, (copy) v_u_159, (copy) p_u_129
						if v_u_157.isBitVector then
							prepareSaveBitVectorMapToFile(v_u_157.map, v_u_159)
							p_u_129:addSaveTask(SavegameController.SAVE_TASK_BITVECTOR_MAP, v_u_157.map)
						else
							prepareSaveDensityMapToFile(v_u_157.map, v_u_159)
							p_u_129:addSaveTask(SavegameController.SAVE_TASK_DENSITY_MAP, v_u_157.map)
						end
					end)
				end
			end
		end
		local v160 = g_currentMission.foliageSystem:getDecoFoliages()
		for _, v161 in pairs(v160) do
			local v_u_162 = v161.terrainDataPlaneId
			if v_u_162 ~= nil then
				local v_u_163 = getDensityMapFilename(v_u_162)
				if v139[v_u_163] == nil then
					v139[v_u_163] = true
					if p_u_129.isSavingBlocking then
						saveDensityMapToFile(v_u_162, v_u_138 .. "/" .. v_u_163)
					else
						g_asyncTaskManager:addTask(function()
							-- upvalues: (copy) v_u_162, (copy) v_u_138, (copy) v_u_163, (copy) p_u_129
							prepareSaveDensityMapToFile(v_u_162, v_u_138 .. "/" .. v_u_163)
							p_u_129:addSaveTask(SavegameController.SAVE_TASK_DENSITY_MAP, v_u_162)
						end)
					end
				end
			end
		end
		for v164 = 1, #g_currentMission.dynamicFoliageLayers do
			local v_u_165 = g_currentMission.dynamicFoliageLayers[v164]
			local v_u_166 = getDensityMapFilename(v_u_165)
			if v139[v_u_166] == nil then
				v139[v_u_166] = true
				if p_u_129.isSavingBlocking then
					saveDensityMapToFile(v_u_165, v_u_138 .. "/" .. v_u_166)
				else
					g_asyncTaskManager:addTask(function()
						-- upvalues: (copy) v_u_165, (copy) v_u_138, (copy) v_u_166, (copy) p_u_129
						prepareSaveDensityMapToFile(v_u_165, v_u_138 .. "/" .. v_u_166)
						p_u_129:addSaveTask(SavegameController.SAVE_TASK_DENSITY_MAP, v_u_165)
					end)
				end
			end
		end
		local v_u_167 = getDensityMapFilename(g_currentMission.terrainDetailHeightId)
		if v_u_167 ~= nil and v139[v_u_167] == nil then
			v139[v_u_167] = true
			if p_u_129.isSavingBlocking then
				saveDensityMapToFile(g_currentMission.terrainDetailHeightId, v_u_138 .. "/" .. v_u_167)
			else
				g_asyncTaskManager:addTask(function()
					-- upvalues: (copy) v_u_138, (copy) v_u_167, (copy) p_u_129
					prepareSaveDensityMapToFile(g_currentMission.terrainDetailHeightId, v_u_138 .. "/" .. v_u_167)
					p_u_129:addSaveTask(SavegameController.SAVE_TASK_DENSITY_MAP, g_currentMission.terrainDetailHeightId)
				end)
			end
		end
		if p_u_129.isSavingBlocking then
			g_currentMission.growthSystem:saveState(v_u_138)
			g_currentMission.snowSystem:saveState(v_u_138)
		else
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) v_u_138
				g_currentMission.growthSystem:saveState(v_u_138)
			end)
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) v_u_138
				g_currentMission.snowSystem:saveState(v_u_138)
			end)
		end
		if p_u_129.isSavingBlocking then
			saveSplitShapesToFile(v_u_138 .. "/splitShapes.gmss")
		else
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) v_u_138, (copy) p_u_129
				prepareSaveSplitShapesToFile(v_u_138 .. "/splitShapes.gmss")
				p_u_129:addSaveTask(SavegameController.SAVE_TASK_SPLIT_SHAPES, 0)
			end)
		end
		if not GS_IS_MOBILE_VERSION then
			if p_u_129.isSavingBlocking then
				g_densityMapHeightManager:saveCollisionMap(v_u_138)
			else
				g_asyncTaskManager:addTask(function()
					-- upvalues: (copy) v_u_138, (copy) p_u_129
					g_densityMapHeightManager:prepareSaveCollisionMap(v_u_138)
					p_u_129:addSaveTask(SavegameController.SAVE_TASK_COLLISION_MAP, 0)
				end)
			end
			if p_u_129.isSavingBlocking then
				g_densityMapHeightManager:savePlacementCollisionMap(v_u_138)
			else
				g_asyncTaskManager:addTask(function()
					-- upvalues: (copy) v_u_138, (copy) p_u_129
					g_densityMapHeightManager:prepareSavePlacementCollisionMap(v_u_138)
					p_u_129:addSaveTask(SavegameController.SAVE_TASK_PLACEMENT_BLOCKING_MAP, 0)
				end)
			end
			if p_u_129.isSavingBlocking then
				saveTerrainLodTypeMap(g_terrainNode, v_u_138 .. "/" .. getTerrainLodTypeMapFilename(g_terrainNode))
			else
				g_asyncTaskManager:addTask(function()
					-- upvalues: (copy) v_u_138, (copy) p_u_129
					prepareSaveTerrainLodTypeMap(g_terrainNode, v_u_138 .. "/" .. getTerrainLodTypeMapFilename(g_terrainNode))
					p_u_129:addSaveTask(SavegameController.SAVE_TASK_TERRAIN_LOD_TYPE_MAP, g_terrainNode)
				end)
			end
			if p_u_129.isSavingBlocking then
				saveTerrainLodNormalMap(g_terrainNode, v_u_138 .. "/" .. getTerrainLodNormalMapFilename(g_terrainNode))
			else
				g_asyncTaskManager:addTask(function()
					-- upvalues: (copy) v_u_138
					saveTerrainLodNormalMap(g_terrainNode, v_u_138 .. "/" .. getTerrainLodNormalMapFilename(g_terrainNode))
				end)
			end
			if p_u_129.isSavingBlocking then
				saveTerrainHeightMap(g_terrainNode, v_u_138 .. "/" .. getTerrainHeightMapFilename(g_terrainNode))
			else
				g_asyncTaskManager:addTask(function()
					-- upvalues: (copy) v_u_138, (copy) p_u_129
					prepareSaveTerrainHeightMap(g_terrainNode, v_u_138 .. "/" .. getTerrainHeightMapFilename(g_terrainNode))
					p_u_129:addSaveTask(SavegameController.SAVE_TASK_TERRAIN_HEIGHT_MAP, g_terrainNode)
				end)
			end
			if p_u_129.isSavingBlocking then
				saveTerrainOccludersCache(g_terrainNode, v_u_138 .. "/" .. getTerrainOccludersCacheFilename(g_terrainNode))
			else
				g_asyncTaskManager:addTask(function()
					-- upvalues: (copy) v_u_138
					saveTerrainOccludersCache(g_terrainNode, v_u_138 .. "/" .. getTerrainOccludersCacheFilename(g_terrainNode))
				end)
			end
		end
		if p_u_129.isSavingBlocking then
			p_u_129.savegameMetadata = saveXMLFileToMemory(v_u_133.xmlFile)
		else
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_129, (copy) v_u_133
				p_u_129.savegameMetadata = saveXMLFileToMemory(v_u_133.xmlFile)
			end)
		end
		if p_u_129.isSavingBlocking and #p_u_129.saveTasks > 0 then
			printWarning("Warning: Blocking saving has async tasks")
		end
		if p_u_129.isSavingBlocking then
			p_u_129:executeSaveTask()
		else
			g_asyncTaskManager:addTask(function()
				-- upvalues: (copy) p_u_129
				p_u_129:executeSaveTask()
			end)
		end
		if v132 then
			endFrameRepeatMode()
			return
		end
	else
		p_u_129:onSaveComplete(p130)
	end
end
function SavegameController.onSaveComplete(p168, p169)
	p168.savingErrorCode = p169
	p168.isSavingGame = false
	if p169 == Savegame.ERROR_OK then
		print("Game saved successfully.")
	else
		printError("Game save failed. Error: " .. tostring(p169))
	end
	leaveCpuBoostMode()
	g_asyncTaskManager:setAllowedTimePerFrame(nil)
	p168.onSaveCompleteCallback(p168.onSaveCompleteCallbackTarget, p169)
end
function SavegameController.onSavegameDeleted(p170, p171)
	p170.onDeleteCallback(p170.onDeleteCallbackTarget, p171)
end
function SavegameController.deleteSavegame(p172, p173, p174, p175)
	-- upvalues: (copy) v_u_2
	p172.onDeleteCallback = p174 or v_u_2.NO_CALLBACK
	p172.onDeleteCallbackTarget = p175 or v_u_2
	local v176 = p172.savegames[p173]
	saveDeleteSavegame(v176.savegameIndex, "onSavegameDeleted", p172)
end
function SavegameController.saveSavegame(p177, p178, p179)
	if p178.supportsSaving == false then
		printWarning("Warning: Saving not supported by savegame/mission")
		p177.onSaveCompleteCallback(p177.onSaveCompleteCallbackTarget, Savegame.ERROR_OK)
		return
	elseif p177.isSavingGame then
		printWarning("Warning: Saving while already saving")
		p177.onSaveCompleteCallback(p177.onSaveCompleteCallbackTarget, Savegame.ERROR_OPERATION_IN_PROGRESS)
	else
		p177.isSavingGame = true
		p177.isSavingBlocking = p179
		enterCpuBoostMode()
		g_asyncTaskManager:setAllowedTimePerFrame(33.333333333333336)
		if p178.isValid and not (GS_IS_CONSOLE_VERSION or GS_IS_MOBILE_VERSION) then
			p177:backupSavegame(p178)
		end
		p178.isValid = true
		p178.densityMapRevision = g_densityMapRevision
		p178.terrainTextureRevision = g_terrainTextureRevision
		p178.terrainLodTextureRevision = g_terrainLodTextureRevision
		p178.splitShapesRevision = g_splitShapesRevision
		p178.tipCollisionRevision = g_tipCollisionRevision
		p178.placementCollisionRevision = g_placementCollisionRevision
		p178.navigationCollisionRevision = g_navigationCollisionRevision
		p178.resetVehicles = false
		p178:loadFromMission(g_currentMission)
		p177.currentSavegame = p178
		saveWriteSavegameStart(p178.savegameIndex, p178.displayName, FSCareerMissionInfo.MaxSavegameSize, "onSaveStartComplete", p177)
	end
end
function SavegameController.getCanStartGame(p180, p181, p182)
	local v183 = p180:getSavegame(p181)
	if p182 or (v183 == SavegameController.NO_SAVEGAME or not v183.hasConflict) then
		if v183 == SavegameController.NO_SAVEGAME or (not v183.isValid or v183.map ~= nil) then
			return p181 > 0
		else
			return false
		end
	else
		return false
	end
end
function SavegameController.getIsSavegameConflicted(p184, p185)
	local v186 = p184:getSavegame(p185)
	return v186 ~= SavegameController.NO_SAVEGAME and v186.hasConflict and true or false
end
function SavegameController.getCanDeleteGame(p187, p188)
	if p188 > 0 and p187.savegames[p188] ~= nil then
		return p187.savegames[p188].isValid or (p187.savegames[p188].isInvalidUser or p187.savegames[p188].isCorruptFile)
	else
		return false
	end
end
function SavegameController.getSavegame(p189, p190)
	return p189.savegames[p190] or SavegameController.NO_SAVEGAME
end
function SavegameController.getNumValidSavegames(p191)
	local v192 = 0
	for v193 = 1, SavegameController.NUM_SAVEGAMES do
		local v194 = p191:getSavegame(v193)
		if v194 ~= SavegameController.NO_SAVEGAME and v194.isValid then
			v192 = v192 + 1
		end
	end
	return v192
end
function SavegameController.getIsSaving(p195)
	return p195.isSavingGame
end
function SavegameController.getSavingErrorCode(p196)
	return p196.savingErrorCode
end
function SavegameController.getIsWaitingForSavegameInfo(p197)
	return p197.waitingForSaveGameInfo
end
function SavegameController.getNumberOfSavegames(_)
	return saveGetNumOfSaveGames()
end
function SavegameController.getMaxNumberOfSavegames(_)
	return SavegameController.NUM_SAVEGAMES
end
function SavegameController.isStorageDeviceUnavailable(_)
	return saveGetNumOfSaveGames() < 0
end
function SavegameController.backupSortFunction(p198, p199)
	if p198.time[1] == p199.time[1] then
		if p198.time[2] == p199.time[2] then
			if p198.time[3] == p199.time[3] then
				if p198.time[4] == p199.time[4] then
					return p198.time[5] > p199.time[5]
				else
					return p198.time[4] > p199.time[4]
				end
			else
				return p198.time[3] > p199.time[3]
			end
		else
			return p198.time[2] > p199.time[2]
		end
	else
		return p198.time[1] > p199.time[1]
	end
end
SavegameController.BACKUP_DATE_OFFSETS = {
	{ 1, 1 },
	{ 2, 1 },
	{ 3, 1 },
	{ 4, 1 },
	{ 5, 1 },
	{ 6, 6 },
	{ 12, 12 },
	{ 24, 24 },
	{ 48, 48 },
	{ 96, 96 },
	{ 192, 192 }
}

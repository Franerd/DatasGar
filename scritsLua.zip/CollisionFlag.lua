CollisionFlag = {}
local v_u_1 = {}
local v_u_2 = {}
local v_u_3 = {}
local v_u_4 = 255
local v_u_5 = 0
local function v13(p6, p7, p8, p9)
	-- upvalues: (copy) v_u_1, (ref) v_u_5, (ref) v_u_4, (copy) v_u_3, (copy) v_u_2
	if v_u_1[p6] ~= nil then
		Logging.error("CollisionFlag.registerFlag: Given bit \'%d\' is already in use.", p6)
		return nil
	end
	local v10 = p7:upper()
	if CollisionFlag[v10] ~= nil then
		Logging.error("CollisionFlag.registerFlag: Given  name \'%s\' is already in use", v10)
		return nil
	end
	local v11 = {
		["name"] = v10,
		["description"] = p8 or "",
		["bit"] = p6,
		["flag"] = 2 ^ p6,
		["isActive"] = p9 or p6 < 8,
		["isDeprecated"] = not p9
	}
	if v11.isActive then
		v_u_5 = bitOR(v_u_5, v11.flag)
	end
	v_u_4 = bitOR(v_u_4, v11.flag)
	v_u_1[p6] = true
	CollisionFlag[v10] = v11.flag
	v_u_3[v11.flag] = v11
	local v12 = v_u_2
	table.insert(v12, v11)
	return v11.flag
end
function CollisionFlag.iteratorFlags()
	-- upvalues: (copy) v_u_3
	local v_u_14 = 0
	local v_u_15 = 31
	return function()
		-- upvalues: (ref) v_u_14, (ref) v_u_3, (copy) v_u_15
		if v_u_14 > 31 then
			return nil
		end
		v_u_14 = v_u_14 + 1
		while v_u_3[2 ^ (v_u_14 - 1)] == nil do
			v_u_14 = v_u_14 + 1
		end
		local v16 = v_u_3[2 ^ (v_u_14 - 1)]
		return v16.name, v16.bit, v16.flag, v16
	end
end
function CollisionFlag.getHasMaskFlagSet(p17, p18)
	local v19 = getCollisionFilterMask(p17)
	return bit32.btest(v19, p18)
end
function CollisionFlag.getHasGroupFlagSet(p20, p21)
	local v22 = getCollisionFilterGroup(p20)
	return bit32.btest(v22, p21)
end
function CollisionFlag.setMaskFlag(p23, p24)
	local v25 = getCollisionFilterMask(p23)
	local v26 = bitOR(v25, p24)
	setCollisionFilterMask(p23, v26)
end
function CollisionFlag.setGroupFlag(p27, p28)
	local v29 = getCollisionFilterGroup(p27)
	local v30 = bitOR(v29, p28)
	setCollisionFilterGroup(p27, v30)
end
function CollisionFlag.getBit(p31)
	-- upvalues: (copy) v_u_3
	local v32 = v_u_3[p31]
	if v32 == nil then
		printCallstack()
	end
	return v32.bit
end
function CollisionFlag.getBitAndName(p33)
	-- upvalues: (copy) v_u_3
	local v34 = v_u_3[p33]
	if v34 == nil then
		printCallstack()
	end
	return string.format("bit %d (%s)", v34.bit, v34.name)
end
function CollisionFlag.getFlagsFromMask(p35)
	-- upvalues: (copy) v_u_3
	local v36 = {}
	local v37 = {}
	for v38 = 0, 31 do
		local v39 = 2 ^ v38
		local v40 = v_u_3[v39]
		if v40 ~= nil then
			if bit32.btest(v39, p35) then
				table.insert(v36, v40)
			else
				table.insert(v37, v40)
			end
		end
	end
	return v36, v37
end
function CollisionFlag.getFlagsStringFromMask(p41, p42)
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v43 = {}
	local v44 = MathUtil.getNumOfSetBits(p41)
	local v45
	if p42 and table.size(v_u_1) * 0.5 < v44 then
		p41 = bitNOT(p41)
		v45 = true
	else
		v45 = false
	end
	for _, v46 in ipairs(MathUtil.numberToSetBits(p41)) do
		local v47 = v_u_3[2 ^ v46]
		if v47 ~= nil then
			local v48 = v47.name
			table.insert(v43, v48)
		end
	end
	if p42 and v44 == table.size(v_u_1) then
		return "ALL registered Bits"
	elseif v45 then
		return "ALL except " .. table.concat(v43, ", ")
	else
		return table.concat(v43, ", ")
	end
end
local function v56(p49)
	-- upvalues: (ref) v_u_4, (ref) v_u_5
	local v50 = false
	if getHasClassId(p49, ClassIds.SHAPE) then
		local v51 = getCollisionFilterMask(p49)
		if v51 > 0 and v51 ~= 255 then
			local v52 = bitAND(v51, bitNOT(v_u_4))
			if v52 ~= 0 then
				local v53 = MathUtil.numberToSetBitsStr(v52)
				print(string.format("    CollisionFlag-Check: Node \'%s\' uses undefined bits \'%s\'!", I3DUtil.getNodePath(p49), v53))
				v50 = true
			end
			local v54 = bitAND(v51, bitNOT(v_u_5))
			if v54 ~= 0 then
				local v55 = MathUtil.numberToSetBitsStr(v54)
				print(string.format("    CollisionFlag-Check: Node \'%s\' uses deprecated bits \'%s\'!", I3DUtil.getNodePath(p49), v55))
				v50 = true
			end
		end
	end
	return v50
end
CollisionFlag.checkCollisionMask = v56
function CollisionFlag.checkCollisionMaskRec(p57)
	local v58 = false
	if p57 ~= nil and p57 ~= 0 then
		v58 = v58 or CollisionFlag.checkCollisionMask(p57)
		for v59 = 0, getNumOfChildren(p57) - 1 do
			v58 = v58 or CollisionFlag.checkCollisionMaskRec(getChildAt(p57, v59))
		end
	end
	return v58
end
addConsoleCommand("gsCollisionFlagShowAll", "Shows all available collision flags", "consoleCommandShowAll", CollisionFlag)
function CollisionFlag.consoleCommandShowAll()
	-- upvalues: (copy) v_u_2
	table.sort(v_u_2, function(p60, p61)
		if p60.isDeprecated and p61.isDeprecated or not (p60.isDeprecated or p61.isDeprecated) then
			return p60.bit < p61.bit
		else
			return not p60.isDeprecated
		end
	end)
	print("Defined collision flags:")
	local v62 = false
	for _, v63 in ipairs(v_u_2) do
		if v63.isDeprecated and not v62 then
			print("\nDeprecated:")
			v62 = true
		end
		print(string.format("Bit %02d: %s - %s", v63.bit, v63.name, v63.description))
	end
	print("\n\nPredefined collision masks:")
	for v64, v65 in pairs(CollisionMask) do
		print(string.format("Mask %010d: %s", v65, v64))
	end
end
CollisionFlag.DEFAULT = v13(0, "DEFAULT", "The default bit", true)
CollisionFlag.STATIC_OBJECT = v13(1, "STATIC_OBJECT", "Static object", true)
CollisionFlag.CAMERA_BLOCKING = v13(2, "CAMERA_BLOCKING", "Blocks the player camera from being inside", true)
CollisionFlag.GROUND_TIP_BLOCKING = v13(3, "GROUND_TIP_BLOCKING", "Blocks tipping on the ground beneath/above", true)
CollisionFlag.PLACEMENT_BLOCKING = v13(4, "PLACEMENT_BLOCKING", "Blocks placing objects via construction", true)
CollisionFlag.AI_BLOCKING = v13(5, "AI_BLOCKING", "Blocks vehicle navigation map beneath/above", true)
CollisionFlag.PRECIPITATION_BLOCKING = v13(6, "PRECIPITATION_BLOCKING", "Masks all precipitation inside and below the collision", true)
CollisionFlag.TERRAIN = v13(8, "TERRAIN", "Terrain without tip any or displacement", true)
CollisionFlag.TERRAIN_DELTA = v13(9, "TERRAIN_DELTA", "Tip anything", true)
CollisionFlag.TERRAIN_DISPLACEMENT = v13(10, "TERRAIN_DISPLACEMENT", "Terrain displacement (tiretrack deformation)", true)
CollisionFlag.TREE = v13(11, "TREE", "A tree", true)
CollisionFlag.BUILDING = v13(12, "BUILDING", "A building", true)
CollisionFlag.ROAD = v13(13, "ROAD", "A road", true)
CollisionFlag.AI_DRIVABLE = v13(14, "AI_DRIVABLE", "Blocks vehicle navigation map at the vertical faces of the mesh if they are above the terrain", true)
CollisionFlag.VEHICLE = v13(16, "VEHICLE", "A vehicle", true)
CollisionFlag.VEHICLE_FORK = v13(17, "VEHICLE_FORK", "A vehicle fork tip for pallets or bales", true)
CollisionFlag.DYNAMIC_OBJECT = v13(18, "DYNAMIC_OBJECT", "A dynamic object", true)
CollisionFlag.TRAFFIC_VEHICLE = v13(19, "TRAFFIC_VEHICLE", "A AI traffic vehicle", true)
CollisionFlag.PLAYER = v13(20, "PLAYER", "A player", true)
CollisionFlag.ANIMAL = v13(21, "ANIMAL", "An Animal", true)
CollisionFlag.ANIMAL_POSITIONING = v13(22, "ANIMAL_POSITIONING", "For animal to walk on (position is raycast from above)", true)
CollisionFlag.ANIMAL_NAV_MESH_BLOCKING = v13(23, "ANIMAL_NAV_MESH_BLOCKING", "Area of the collision is excluded from generated nav meshes", true)
CollisionFlag.TRAFFIC_VEHICLE_BLOCKING = v13(24, "TRAFFIC_VEHICLE_BLOCKING", "Blocks AI traffic vehicles", true)
CollisionFlag.INTERACTABLE_TARGET = v13(28, "INTERACTABLE_TARGET", "An interactable trigger that the player can target", true)
CollisionFlag.TRIGGER = v13(29, "TRIGGER", "A trigger", true)
CollisionFlag.FILLABLE = v13(30, "FILLABLE", "A fillable node. For trailer fillNodes and unload triggers", true)
CollisionFlag.WATER = v13(31, "WATER", "A water plane", true)
local v_u_66 = {}
local v_u_67 = {}
CollisionFlag.colMaskMappingVerbose = true
addConsoleCommand("gsCollisionMaskMappingReload", "", "consoleCommandReloadCollisionMaskMapping", CollisionFlag)
addConsoleCommand("gsCollisionMaskMappingVerbose", "", "consoleCommandToggleVerbose", CollisionFlag)
function CollisionFlag.consoleCommandReloadCollisionMaskMapping()
	CollisionFlag.loadCollisionMaskMapping()
	CollisionFlag.printMapping()
	return "reloaded mapping"
end
function CollisionFlag.consoleCommandToggleVerbose()
	CollisionFlag.colMaskMappingVerbose = not CollisionFlag.colMaskMappingVerbose
	local v68 = CollisionFlag.colMaskMappingVerbose
	return "CollisionFlag.colMaskMappingVerbose=" .. tostring(v68)
end
local function v100()
	-- upvalues: (ref) v_u_66, (ref) v_u_67
	local v_u_69 = XMLFile.load("collisionMaskConversionRules", "shared/collisionMaskConversionRules.xml")
	if v_u_69 ~= nil then
		Logging.info("Loading collision mask conversion rules from %q", v_u_69:getFilename())
		v_u_66 = {}
		v_u_67 = {}
		local function v85(p70, p71)
			-- upvalues: (copy) v_u_69
			local v72 = v_u_69:getString(p70 .. "#value")
			local v73
			if v72 == nil then
				v73 = p71 or 0
			else
				local v74 = string.gsub(v72, "_", "")
				v73 = tonumber(v74)
				if v73 == nil then
					Logging.xmlError(v_u_69, "Unable to parse %q as a number for %q", v74, p70 .. "#value")
					return nil
				end
			end
			for _, v75 in v_u_69:iterator(p70 .. ".flag") do
				local v76 = v_u_69:getString(v75 .. "#name")
				if v76 == nil then
					local v77 = v_u_69:getInt(v75 .. "#bit")
					if v77 ~= nil then
						if v77 < 0 or v77 > 31 then
							Logging.xmlError(v_u_69, "Invalid bit number %q at %q, needs to be between 0 and 31", v77, v75)
						else
							local v78 = 2 ^ v77
							v73 = bitOR(v73, v78)
						end
					end
				else
					local v79 = CollisionFlag[v76]
					if v79 == nil then
						Logging.xmlError(v_u_69, "Unable to find CollisionFlag %q for %q", v76, v75)
					else
						v73 = bitOR(v73, v79)
					end
				end
			end
			for _, v80 in v_u_69:iterator(p70 .. ".withoutFlag") do
				local v81 = v_u_69:getString(v80 .. "#name")
				if v81 == nil then
					local v82 = v_u_69:getInt(v80 .. "#bit")
					if v82 ~= nil then
						if v82 < 0 or v82 > 31 then
							Logging.xmlError(v_u_69, "Invalid bit number %q at %q, needs to be between 0 and 31", v82, v80)
						else
							local v83 = 2 ^ v82
							v73 = bitXOR(v73, v83)
						end
					end
				else
					local v84 = CollisionFlag[v81]
					if v84 == nil then
						Logging.xmlError(v_u_69, "Unable to find CollisionFlag %q for %q", v81, v80)
					else
						v73 = bitXOR(v73, v84)
					end
				end
			end
			return v73
		end
		for _, v86 in v_u_69:iterator("collisionMaskUpdater.presets.preset") do
			local v87 = v_u_69:getString(v86 .. "#name")
			if v_u_67[v87] == nil then
				v_u_67[v87] = {
					["group"] = v85(v86 .. ".group"),
					["mask"] = v85(v86 .. ".mask")
				}
			else
				Logging.xmlError(v_u_69, "Preset name %q at %q already in use", v87, v86)
			end
		end
		for _, v88 in v_u_69:iterator("collisionMaskUpdater.conversionRules.rule") do
			local v89 = v88 .. "#maskOld"
			local v90 = tonumber(v_u_69:getString(v89))
			if v_u_66[v90] == nil then
				for _, v91 in v_u_69:iterator(v88 .. ".output") do
					local v92 = nil
					local v93 = nil
					local v94 = v_u_69:getString(v91 .. "#preset")
					if v94 ~= nil then
						local v95 = CollisionPreset[v94] or v_u_67[v94]
						if v95 == nil then
							Logging.xmlError(v_u_69, "Unknown preset %q in %q", v94, v91)
						else
							v92 = v95.group
							v93 = v95.mask
						end
					end
					local v96 = v85(v91 .. ".group", v92)
					local v97 = v85(v91 .. ".mask", v93)
					if v96 == 0 then
						Logging.xmlError(v_u_69, "Incomplete conversion rule for old mask %q at %q, no new group filter defined", v90, v91)
					elseif v97 == 0 then
						Logging.xmlError(v_u_69, "Incomplete conversion rule for old mask %q at %q, no new mask defined", v90, v91)
					else
						v_u_66[v90] = v_u_66[v90] or {}
						local v98 = v_u_66[v90]
						local v99 = {
							["group"] = v96,
							["mask"] = v97,
							["isTrigger"] = v_u_69:getBool(v91 .. "#isTrigger")
						}
						table.insert(v98, v99)
					end
				end
			else
				Logging.warning("duplicate mask %q", v90)
			end
		end
		v_u_69:delete()
	end
end
CollisionFlag.loadCollisionMaskMapping = v100
local function v107()
	-- upvalues: (ref) v_u_67, (ref) v_u_66
	setFileLogPrefixTimestamp(false)
	print("Presets")
	for v101, v102 in pairs(v_u_67) do
		print(string.format("    %s", v101))
		print(string.format("        => group: Dec:%s  Hex:%x  Flags:%s", v102.group, v102.group, CollisionFlag.getFlagsStringFromMask(v102.group)))
		print(string.format("        => mask: Dec:%s  Hex:%x  Flags:%s", v102.mask, v102.mask, CollisionFlag.getFlagsStringFromMask(v102.mask, true)))
	end
	print("\nRules")
	for v103, v104 in pairs(v_u_66) do
		print(string.format("Old: Dec:%s Hex:%x Bits:%s", v103, v103, MathUtil.numberToSetBitsStr(v103)))
		for v105, v106 in ipairs(v104) do
			if #v104 > 1 then
				print(string.format("    output %d - isTrigger=%s", v105, v106.isTrigger))
			end
			print(string.format("        => group: Dec:%s  Hex:%x  Flags:%s", v106.group, v106.group, CollisionFlag.getFlagsStringFromMask(v106.group)))
			print(string.format("        => mask: Dec:%s  Hex:%x  Flags:%s", v106.mask, v106.mask, CollisionFlag.getFlagsStringFromMask(v106.mask, true)))
		end
	end
	setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
end
CollisionFlag.printMapping = v107
if I3DManager ~= nil then
	I3DManager.addDebugLoadingCheck("check col group / mask", function(_, p108)
		local v109 = false
		if getHasClassId(p108, ClassIds.SHAPE) or getHasClassId(p108, ClassIds.TERRAIN_TRANSFORM_GROUP) then
			local v110 = getCollisionFilterMask(p108)
			if v110 == 0 then
				return
			end
			if v110 ~= getCollisionFilterGroup(p108) then
				return
			end
			if CollisionFlag.colMaskMappingVerbose then
				printWarning(string.format("Warning: outdated mask for %q Dec:%s Hex:%x Bits: %s", I3DUtil.getNodePath(p108), v110, v110, v110 == 4294967295 and "ALL" or MathUtil.numberToSetBitsStr(v110)))
			end
		end
		return v109
	end)
end

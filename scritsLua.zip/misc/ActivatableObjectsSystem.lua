ActivatableObjectsSystem = {}
local v_u_1 = Class(ActivatableObjectsSystem)
function ActivatableObjectsSystem.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.mission = p2
	v5.objects = {}
	v5.currentActivatableObject = nil
	v5.inputContext = nil
	v5.actionEventId = nil
	return v5
end
function ActivatableObjectsSystem.activate(p6, p7)
	p6.inputContext = p7
	p6.isActive = true
	p6:updateObjects()
end
function ActivatableObjectsSystem.deactivate(p8, p9)
	p8:removeInput(p9)
	if p8.currentActivatableObject ~= nil and p8.currentActivatableObject.deactivate ~= nil then
		p8.currentActivatableObject:deactivate()
	end
	p8.currentActivatableObject = nil
	p8.isActive = false
end
function ActivatableObjectsSystem.setPosition(p10, p11, p12, p13)
	p10.posX = p11
	p10.posY = p12
	p10.posZ = p13
end
function ActivatableObjectsSystem.setDirection(p14, p15, p16, p17)
	p14.dirX = p15
	p14.dirY = p16
	p14.dirZ = p17
end
function ActivatableObjectsSystem.update(p18, p19)
	if p18.isActive then
		p18:updateObjects(p19)
	end
end
function ActivatableObjectsSystem.updateObjects(p20, p21)
	local v22 = g_currentMission:getFarmId()
	local v23 = nil
	local v24 = (1 / 0)
	for _, v25 in pairs(p20.objects) do
		if (v25.getIsActivatable == nil or v25:getIsActivatable(p20.dirX, p20.dirY, p20.dirZ)) and (v25.getHasAccess == nil or v25:getHasAccess(v22)) then
			local v26 = (v25.getDistance == nil or p20.posX == nil) and (1 / 0) or v25:getDistance(p20.posX, p20.posY, p20.posZ)
			if v23 == nil or v26 < v24 then
				v24 = v26
				v23 = v25
			end
		end
	end
	if v23 ~= p20.currentActivatableObject then
		p20:removeInput(p20.inputContext)
		if p20.currentActivatableObject ~= nil and p20.currentActivatableObject.deactivate ~= nil then
			p20.currentActivatableObject:deactivate()
		end
		p20.currentActivatableObject = v23
		if v23 ~= nil then
			if v23.activate ~= nil then
				v23:activate()
			end
			p20:registerInput(p20.inputContext)
		end
	end
	if v23 ~= nil then
		if p20.actionEventId ~= nil then
			g_inputBinding:setActionEventText(p20.actionEventId, v23.activateText)
		end
		if v23.update ~= nil then
			v23:update(p21)
		end
	end
end
function ActivatableObjectsSystem.removeInput(p27, p28)
	if p28 ~= nil then
		g_inputBinding:beginActionEventsModification(p28)
	end
	if p27.currentActivatableObject ~= nil and p27.currentActivatableObject.removeCustomInput ~= nil then
		p27.currentActivatableObject:removeCustomInput()
	end
	if p27.actionEventId ~= nil then
		g_inputBinding:removeActionEvent(p27.actionEventId)
		p27.actionEventId = nil
	end
	if p28 ~= nil then
		g_inputBinding:endActionEventsModification()
	end
end
function ActivatableObjectsSystem.registerInput(p29, p30)
	local v31 = p29.currentActivatableObject
	if v31 ~= nil then
		if p30 ~= nil then
			g_inputBinding:beginActionEventsModification(p30)
		end
		if v31.registerCustomInput == nil or Platform.isMobile then
			local _, v32 = g_inputBinding:registerActionEvent(InputAction.ACTIVATE_OBJECT, p29, p29.onActivateObjectInput, false, true, false, true)
			g_inputBinding:setActionEventText(v32, v31.activateText)
			g_inputBinding:setActionEventTextPriority(v32, GS_PRIO_VERY_HIGH)
			g_inputBinding:setActionEventTextVisibility(v32, true)
			p29.actionEventId = v32
		else
			v31:registerCustomInput(p30)
		end
		if p30 ~= nil then
			g_inputBinding:endActionEventsModification()
		end
	end
end
function ActivatableObjectsSystem.getActivatable(p33)
	return p33.currentActivatableObject
end
function ActivatableObjectsSystem.addActivatable(p34, p35)
	if p35.activateText == nil then
		Logging.error("Given activatable object has no activateText")
		printCallstack()
	elseif p34.objects[p35] == nil then
		p34.objects[p35] = p35
	end
end
function ActivatableObjectsSystem.removeActivatable(p36, p37)
	if p37 ~= nil then
		p36.objects[p37] = nil
		if p37 == p36.currentActivatableObject then
			if p37.deactivate ~= nil then
				p37:deactivate()
			end
			p36:removeInput(p36.inputContext)
			p36.currentActivatableObject = nil
		end
	end
end
function ActivatableObjectsSystem.onActivateObjectInput(p38, _, _, _, _)
	if p38.currentActivatableObject ~= nil then
		p38.currentActivatableObject:run()
	end
end

Color = {}
local v_u_1 = Class(Color)
function v_u_1.__index(p2, p3)
	local v4 = rawget(p2, p3)
	if v4 == nil then
		local v5 = Color[p3]
		if v5 == nil then
			if type(p3) == "number" and (p3 > 0 and p3 <= 4) then
				if p3 == 1 then
					return p2.r
				elseif p3 == 2 then
					return p2.g
				elseif p3 == 3 then
					return p2.b
				else
					return p2.a
				end
			else
				return Color.swizzle(p2, p3)
			end
		else
			return v5
		end
	else
		return v4
	end
end
function v_u_1.__mul(p6, p7)
	if type(p6) == "table" and type(p7) == "table" then
		for v8 = 1, 3 do
			if p6[v8] == nil or p7[v8] == nil then
				Assert.fail("Cannot multiply between two tables that do not both have indices 1, 2, and 3!")
			end
		end
		local v9 = p6[1] * p7[1]
		local v10 = math.clamp(v9, 0, 1)
		local v11 = p6[2] * p7[2]
		local v12 = math.clamp(v11, 0, 1)
		local v13 = p6[3] * p7[3]
		local v14 = math.clamp(v13, 0, 1)
		local v15
		if p6[4] == nil or p7[4] == nil then
			v15 = p6[4] or p7[4] or 1
		else
			local v16 = p6[4] * p7[4]
			v15 = math.clamp(v16, 0, 1)
		end
		return Color.new(v10, v12, v14, v15)
	end
	if type(p6) == "number" then
		local v17 = Color.new
		local v18 = p7[1] * p6
		local v19 = math.clamp(v18, 0, 1)
		local v20 = p7[2] * p6
		local v21 = math.clamp(v20, 0, 1)
		local v22 = p7[3] * p6
		local v23 = math.clamp(v22, 0, 1)
		local v24 = (p7[4] or 1) * p6
		return v17(v19, v21, v23, (math.clamp(v24, 0, 1)))
	end
	if type(p7) ~= "number" then
		Assert.fail("attempt to perform arithmetic (mul) on %s and %s", type(p6), (type(p7)))
		return nil
	end
	local v25 = Color.new
	local v26 = p6[1] * p7
	local v27 = math.clamp(v26, 0, 1)
	local v28 = p6[2] * p7
	local v29 = math.clamp(v28, 0, 1)
	local v30 = p6[3] * p7
	local v31 = math.clamp(v30, 0, 1)
	local v32 = (p6[4] or 1) * p7
	return v25(v27, v29, v31, (math.clamp(v32, 0, 1)))
end
function Color.new(p33, p34, p35, p36)
	-- upvalues: (copy) v_u_1
	local v37 = v_u_1
	local v38 = setmetatable({}, v37)
	v38.r = p33 or 0
	v38.g = p34 or 0
	v38.b = p35 or 0
	v38.a = p36 or 1
	return v38
end
function Color.copy(p39)
	return Color.new(p39.r, p39.g, p39.b, p39.a)
end
function Color.copyTo(p40, p41)
	local v42 = p40.r
	local v43 = p40.g
	local v44 = p40.b
	local v45 = p40.a
	p41.r = v42
	p41.g = v43
	p41.b = v44
	p41.a = v45
end
function Color.parseFromString(p46, p47)
	if type(p46) == "string" then
		if string.startsWith(p46, "#") then
			return Color.fromHex(p46)
		else
			local v48 = Color.fromPackedValue(p46)
			if v48 == nil then
				local v49 = string.split(p46, " ", tonumber)
				if #v49 >= 3 then
					if p47 then
						return Color.new(v49[1], v49[2], v49[3])
					else
						return Color.new(v49[1], v49[2], v49[3], v49[4])
					end
				else
					if g_vehicleMaterialManager ~= nil then
						local v50 = Color.fromVector(g_vehicleMaterialManager:getMaterialTemplateColorByName(p46), nil, 3)
						if v50 ~= nil then
							if p47 then
								v50.a = 1
							end
							return v50
						end
					end
					local v51 = Color.fromPresetName(p46)
					if v51 == nil then
						return nil
					end
					if p47 then
						v51.a = 1
					end
					return v51
				end
			else
				if p47 then
					v48.a = 1
				end
				return v48
			end
		end
	else
		return nil
	end
end
function Color.fromPresetName(p52)
	if type(p52) == "string" then
		return Color.PRESETS[string.upper(p52)]
	else
		return nil
	end
end
function Color.fromPackedValue(p53)
	if type(p53) == "string" then
		p53 = tonumber(p53)
	end
	if type(p53) ~= "number" then
		return nil
	end
	local v54 = bitAND(p53, 255) / 255
	local v55 = bitShiftRight(bitAND(p53, 65280), 8) / 255
	local v56 = bitShiftRight(bitAND(p53, 16711680), 16) / 255
	local v57 = bitShiftRight(bitAND(p53, 4278190080), 24) / 255
	return Color.new(v54, v55, v56, v57)
end
function Color.toPackedValue(p58)
	local v59 = p58.r * 255
	local v60 = math.ceil(v59)
	local v61 = bitOR
	local v62 = bitShiftLeft
	local v63 = p58.g * 255
	local v64 = v61(v60, v62(math.ceil(v63), 8))
	local v65 = bitOR
	local v66 = bitShiftLeft
	local v67 = p58.b * 255
	local v68 = v65(v64, v66(math.ceil(v67), 16))
	local v69 = bitOR
	local v70 = bitShiftLeft
	local v71 = p58.a * 255
	return v69(v68, v70(math.ceil(v71), 24))
end
function Color.fromHex(p72)
	if type(p72) == "string" then
		if type(p72) == "string" and string.startsWith(p72, "#") then
			p72 = string.sub(p72, 2)
		end
		local v73 = tonumber(p72, 16)
		if v73 == nil then
			return nil
		else
			return Color.fromPackedValue(v73)
		end
	else
		return nil
	end
end
function Color.toHex(p74, p75)
	local v76 = p74:toPackedValue()
	return string.format("%s%x", p75 and "#" or "", v76)
end
function Color.fromVector(p77, p78, p79)
	if type(p77) ~= "table" or p78 ~= nil and #p77 < p78 then
		return nil
	end
	local v80 = p79 or #p77
	return Color.new(v80 >= 1 and (p77[1] or 0) or 0, v80 >= 2 and (p77[2] or 0) or 0, v80 >= 3 and (p77[3] or 0) or 0, v80 >= 4 and p77[4] or 1)
end
function Color.unpack(p81)
	return p81.r, p81.g, p81.b, p81.a
end
function Color.unpack3(p82)
	return p82.r, p82.g, p82.b
end
function Color.toVector3(p83)
	return { p83.r, p83.g, p83.b }
end
function Color.toVector4(p84)
	return {
		p84.r,
		p84.g,
		p84.b,
		p84.a
	}
end
function Color.fromRGBA(p85, p86, p87, p88)
	return Color.new((p85 or 0) / 255, (p86 or 0) / 255, (p87 or 0) / 255, (p88 or 255) / 255)
end
function Color.unpackRGBA(p89)
	local v90 = p89.r * 255
	local v91 = math.ceil(v90)
	local v92 = p89.g * 255
	local v93 = math.ceil(v92)
	local v94 = p89.b * 255
	local v95 = math.ceil(v94)
	local v96 = p89.a * 255
	return v91, v93, v95, math.ceil(v96)
end
function Color.fromVectorRGBA(p97, p98, p99)
	if type(p97) ~= "table" or p98 ~= nil and #p97 < p98 then
		return nil
	end
	local v100 = p99 or #p97
	return Color.fromRGBA(v100 >= 1 and (p97[1] or 0) or 0, v100 >= 2 and (p97[2] or 0) or 0, v100 >= 3 and (p97[3] or 0) or 0, v100 >= 4 and p97[4] or 255)
end
function Color.toVectorRGB(p101)
	local v102 = {}
	local v103 = p101.r * 255
	local v104 = math.ceil(v103)
	local v105 = p101.g * 255
	local v106 = math.ceil(v105)
	local v107 = p101.b * 255
	__set_list(v102, 1, {v104, v106, (math.ceil(v107))})
	return v102
end
function Color.toVectorRGBA(p108)
	local v109 = {}
	local v110 = p108.r * 255
	local v111 = math.ceil(v110)
	local v112 = p108.g * 255
	local v113 = math.ceil(v112)
	local v114 = p108.b * 255
	local v115 = math.ceil(v114)
	local v116 = p108.a * 255
	__set_list(v109, 1, {v111, v113, v115, (math.ceil(v116))})
	return v109
end
function Color.blend(p117, p118, p119)
	return Color.new(MathUtil.lerp(p117.r, p118.r, p119), MathUtil.lerp(p117.g, p118.g, p119), MathUtil.lerp(p117.b, p118.b, p119), MathUtil.lerp(p117.a, p118.a, p119))
end
function Color.swizzle(p120, p121)
	if type(p121) ~= "string" then
		return nil
	end
	local v122 = string.len(p121)
	if v122 > 4 or v122 <= 0 then
		return nil
	end
	local v123 = {}
	for v124 = 1, v122 do
		local v125 = string.sub(p121, v124, v124)
		local v126 = rawget(p120, v125)
		if v126 == nil then
			return nil
		end
		v123[v124] = v126
	end
	return v123
end
function Color.writeStreamRGB(p127, p128, p129, p130)
	streamWriteUIntN(p127, math.clamp(p128, 0, 1) * 1023, 10)
	streamWriteUIntN(p127, math.clamp(p129, 0, 1) * 1023, 10)
	streamWriteUIntN(p127, math.clamp(p130, 0, 1) * 1023, 10)
end
function Color.readStreamRGB(p131)
	return streamReadUIntN(p131, 10) / 1023, streamReadUIntN(p131, 10) / 1023, streamReadUIntN(p131, 10) / 1023
end
Color.PRESETS = {
	["TRANSPARENT"] = Color.fromPackedValue(0),
	["ALICEBLUE"] = Color.fromPackedValue(4294965488),
	["ANTIQUEWHITE"] = Color.fromPackedValue(4292340730),
	["AQUA"] = Color.fromPackedValue(4294967040),
	["AQUAMARINE"] = Color.fromPackedValue(4292149119),
	["AZURE"] = Color.fromPackedValue(4294967280),
	["BEIGE"] = Color.fromPackedValue(4292670965),
	["BISQUE"] = Color.fromPackedValue(4291093759),
	["BLACK"] = Color.fromPackedValue(4278190080),
	["BLANCHEDALMOND"] = Color.fromPackedValue(4291685375),
	["BLUE"] = Color.fromPackedValue(4294901760),
	["BLUEVIOLET"] = Color.fromPackedValue(4293012362),
	["BROWN"] = Color.fromPackedValue(4280953509),
	["BURLYWOOD"] = Color.fromPackedValue(4287084766),
	["CADETBLUE"] = Color.fromPackedValue(4288716383),
	["CHARTREUSE"] = Color.fromPackedValue(4278255487),
	["CHOCOLATE"] = Color.fromPackedValue(4280183250),
	["CORAL"] = Color.fromPackedValue(4283465727),
	["CORNFLOWERBLUE"] = Color.fromPackedValue(4293760356),
	["CORNSILK"] = Color.fromPackedValue(4292671743),
	["CRIMSON"] = Color.fromPackedValue(4282127580),
	["CYAN"] = Color.fromPackedValue(4294967040),
	["DARKBLUE"] = Color.fromPackedValue(4287299584),
	["DARKCYAN"] = Color.fromPackedValue(4287335168),
	["DARKGOLDENROD"] = Color.fromPackedValue(4278945464),
	["DARKGRAY"] = Color.fromPackedValue(4289309097),
	["DARKGREEN"] = Color.fromPackedValue(4278215680),
	["DARKKHAKI"] = Color.fromPackedValue(4285249469),
	["DARKMAGENTA"] = Color.fromPackedValue(4287299723),
	["DARKOLIVEGREEN"] = Color.fromPackedValue(4281297749),
	["DARKORANGE"] = Color.fromPackedValue(4278226175),
	["DARKORCHID"] = Color.fromPackedValue(4291572377),
	["DARKRED"] = Color.fromPackedValue(4278190219),
	["DARKSALMON"] = Color.fromPackedValue(4286224105),
	["DARKSEAGREEN"] = Color.fromPackedValue(4287347855),
	["DARKSLATEBLUE"] = Color.fromPackedValue(4287315272),
	["DARKSLATEGRAY"] = Color.fromPackedValue(4283387695),
	["DARKTURQUOISE"] = Color.fromPackedValue(4291939840),
	["DARKVIOLET"] = Color.fromPackedValue(4292018324),
	["DEEPPINK"] = Color.fromPackedValue(4287829247),
	["DEEPSKYBLUE"] = Color.fromPackedValue(4294950656),
	["DIMGRAY"] = Color.fromPackedValue(4285098345),
	["DODGERBLUE"] = Color.fromPackedValue(4294938654),
	["FIREBRICK"] = Color.fromPackedValue(4280427186),
	["FLORALWHITE"] = Color.fromPackedValue(4293982975),
	["FORESTGREEN"] = Color.fromPackedValue(4280453922),
	["FUCHSIA"] = Color.fromPackedValue(4294902015),
	["GAINSBORO"] = Color.fromPackedValue(4292664540),
	["GHOSTWHITE"] = Color.fromPackedValue(4294965496),
	["GOLD"] = Color.fromPackedValue(4278245375),
	["GOLDENROD"] = Color.fromPackedValue(4280329690),
	["GRAY"] = Color.fromPackedValue(4286611584),
	["GREEN"] = Color.fromPackedValue(4278222848),
	["GREENYELLOW"] = Color.fromPackedValue(4281335725),
	["HONEYDEW"] = Color.fromPackedValue(4293984240),
	["HOTPINK"] = Color.fromPackedValue(4290013695),
	["INDIANRED"] = Color.fromPackedValue(4284243149),
	["INDIGO"] = Color.fromPackedValue(4286709835),
	["IVORY"] = Color.fromPackedValue(4293984255),
	["KHAKI"] = Color.fromPackedValue(4287424240),
	["LAVENDER"] = Color.fromPackedValue(4294633190),
	["LAVENDERBLUSH"] = Color.fromPackedValue(4294308095),
	["LAWNGREEN"] = Color.fromPackedValue(4278254716),
	["LEMONCHIFFON"] = Color.fromPackedValue(4291689215),
	["LIGHTBLUE"] = Color.fromPackedValue(4293318829),
	["LIGHTCORAL"] = Color.fromPackedValue(4286611696),
	["LIGHTCYAN"] = Color.fromPackedValue(4294967264),
	["LIGHTGOLDENRODYELLOW"] = Color.fromPackedValue(4292016890),
	["LIGHTGRAY"] = Color.fromPackedValue(4292072403),
	["LIGHTGREEN"] = Color.fromPackedValue(4287688336),
	["LIGHTPINK"] = Color.fromPackedValue(4290885375),
	["LIGHTSALMON"] = Color.fromPackedValue(4286226687),
	["LIGHTSEAGREEN"] = Color.fromPackedValue(4289376800),
	["LIGHTSKYBLUE"] = Color.fromPackedValue(4294626951),
	["LIGHTSLATEGRAY"] = Color.fromPackedValue(4288252023),
	["LIGHTSTEELBLUE"] = Color.fromPackedValue(4292789424),
	["LIGHTYELLOW"] = Color.fromPackedValue(4292935679),
	["LIME"] = Color.fromPackedValue(4278255360),
	["LIMEGREEN"] = Color.fromPackedValue(4281519410),
	["LINEN"] = Color.fromPackedValue(4293325050),
	["MAGENTA"] = Color.fromPackedValue(4294902015),
	["MAROON"] = Color.fromPackedValue(4278190208),
	["MEDIUMAQUAMARINE"] = Color.fromPackedValue(4289383782),
	["MEDIUMBLUE"] = Color.fromPackedValue(4291624960),
	["MEDIUMORCHID"] = Color.fromPackedValue(4292040122),
	["MEDIUMPURPLE"] = Color.fromPackedValue(4292571283),
	["MEDIUMSEAGREEN"] = Color.fromPackedValue(4285641532),
	["MEDIUMSLATEBLUE"] = Color.fromPackedValue(4293814395),
	["MEDIUMSPRINGGREEN"] = Color.fromPackedValue(4288346624),
	["MEDIUMTURQUOISE"] = Color.fromPackedValue(4291613000),
	["MEDIUMVIOLETRED"] = Color.fromPackedValue(4286911943),
	["MIDNIGHTBLUE"] = Color.fromPackedValue(4285536537),
	["MINTCREAM"] = Color.fromPackedValue(4294639605),
	["MISTYROSE"] = Color.fromPackedValue(4292994303),
	["MOCCASIN"] = Color.fromPackedValue(4290110719),
	["NAVAJOWHITE"] = Color.fromPackedValue(4289584895),
	["NAVY"] = Color.fromPackedValue(4286578688),
	["OLDLACE"] = Color.fromPackedValue(4293326333),
	["OLIVE"] = Color.fromPackedValue(4278222976),
	["OLIVEDRAB"] = Color.fromPackedValue(4280520299),
	["ORANGE"] = Color.fromPackedValue(4278232575),
	["ORANGERED"] = Color.fromPackedValue(4278207999),
	["ORCHID"] = Color.fromPackedValue(4292243674),
	["PALEGOLDENROD"] = Color.fromPackedValue(4289390830),
	["PALEGREEN"] = Color.fromPackedValue(4288215960),
	["PALETURQUOISE"] = Color.fromPackedValue(4293848751),
	["PALEVIOLETRED"] = Color.fromPackedValue(4287852763),
	["PAPAYAWHIP"] = Color.fromPackedValue(4292210687),
	["PEACHPUFF"] = Color.fromPackedValue(4290370303),
	["PERU"] = Color.fromPackedValue(4282353101),
	["PINK"] = Color.fromPackedValue(4291543295),
	["PLUM"] = Color.fromPackedValue(4292714717),
	["POWDERBLUE"] = Color.fromPackedValue(4293320880),
	["PURPLE"] = Color.fromPackedValue(4286578816),
	["RED"] = Color.fromPackedValue(4278190335),
	["ROSYBROWN"] = Color.fromPackedValue(4287598524),
	["ROYALBLUE"] = Color.fromPackedValue(4292962625),
	["SADDLEBROWN"] = Color.fromPackedValue(4279453067),
	["SALMON"] = Color.fromPackedValue(4285694202),
	["SANDYBROWN"] = Color.fromPackedValue(4284523764),
	["SEAGREEN"] = Color.fromPackedValue(4283927342),
	["SEASHELL"] = Color.fromPackedValue(4293850623),
	["SIENNA"] = Color.fromPackedValue(4281160352),
	["SILVER"] = Color.fromPackedValue(4290822336),
	["SKYBLUE"] = Color.fromPackedValue(4293643911),
	["SLATEBLUE"] = Color.fromPackedValue(4291648106),
	["SLATEGRAY"] = Color.fromPackedValue(4287660144),
	["SNOW"] = Color.fromPackedValue(4294638335),
	["SPRINGGREEN"] = Color.fromPackedValue(4286578432),
	["STEELBLUE"] = Color.fromPackedValue(4290019910),
	["TAN"] = Color.fromPackedValue(4287411410),
	["TEAL"] = Color.fromPackedValue(4286611456),
	["THISTLE"] = Color.fromPackedValue(4292394968),
	["TOMATO"] = Color.fromPackedValue(4282868735),
	["TURQUOISE"] = Color.fromPackedValue(4291878976),
	["VIOLET"] = Color.fromPackedValue(4293821166),
	["WHEAT"] = Color.fromPackedValue(4289978101),
	["WHITE"] = Color.fromPackedValue(4294967295),
	["WHITESMOKE"] = Color.fromPackedValue(4294309365),
	["YELLOW"] = Color.fromPackedValue(4278255615),
	["YELLOWGREEN"] = Color.fromPackedValue(4281519514)
}

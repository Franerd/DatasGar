ConnectionHoseType = nil
ConnectionHoseManager = {}
ConnectionHoseManager.DEFAULT_HOSES_FILENAME = "data/shared/connectionHoses/connectionHoses.xml"
ConnectionHoseManager.xmlSchema = nil
local v_u_1 = Class(ConnectionHoseManager, AbstractManager)
function ConnectionHoseManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AbstractManager.new(p2 or v_u_1)
	v3:initDataStructures()
	ConnectionHoseManager.xmlSchema = XMLSchema.new("connectionHoses")
	ConnectionHoseManager:registerXMLPaths(ConnectionHoseManager.xmlSchema)
	return v3
end
function ConnectionHoseManager.initDataStructures(p4)
	p4.xmlFiles = {}
	p4.typeByName = {}
	ConnectionHoseType = p4.typeByName
	p4.basicHoses = {}
	p4.sockets = {}
	p4.sharedLoadRequestIds = {}
	p4.modConnectionHosesToLoad = {}
end
function ConnectionHoseManager.loadMapData(p5, _, _, p6)
	ConnectionHoseManager:superClass().loadMapData(p5)
	p5.baseDirectory = p6
	p5:loadConnectionHosesFromXML(ConnectionHoseManager.DEFAULT_HOSES_FILENAME, nil, p5.baseDirectory)
	for v7 = #p5.modConnectionHosesToLoad, 1, -1 do
		local v8 = p5.modConnectionHosesToLoad[v7]
		p5:loadConnectionHosesFromXML(v8.xmlFilename, v8.customEnvironment, v8.baseDirectory)
		p5.modConnectionHosesToLoad[v7] = nil
	end
end
function ConnectionHoseManager.unloadMapData(p9)
	for _, v10 in ipairs(p9.basicHoses) do
		delete(v10.node)
	end
	for _, v11 in pairs(p9.typeByName) do
		for _, v12 in pairs(v11.adapters) do
			delete(v12.node)
			delete(v12.detachedNode)
		end
		for _, v13 in pairs(v11.hoses) do
			delete(v13.materialNode)
		end
	end
	for _, v14 in pairs(p9.sockets) do
		delete(v14.node)
	end
	for v15 = 1, #p9.sharedLoadRequestIds do
		local v16 = p9.sharedLoadRequestIds[v15]
		g_i3DManager:releaseSharedI3DFile(v16)
	end
	for v17, _ in pairs(p9.xmlFiles) do
		p9.xmlFiles[v17] = nil
		v17:delete()
	end
	ConnectionHoseManager:superClass().unloadMapData(p9)
end
function ConnectionHoseManager.addModConnectionHoses(p18, p19, p20, p21)
	local v22 = p18.modConnectionHosesToLoad
	table.insert(v22, {
		["xmlFilename"] = p19,
		["customEnvironment"] = p20,
		["baseDirectory"] = p21
	})
end
function ConnectionHoseManager.loadConnectionHosesFromXML(p23, p24, p25, p26)
	Logging.info("Loading ConnectionHoses from \'%s\'", p24)
	local v27 = XMLFile.load("TempHoses", p24, ConnectionHoseManager.xmlSchema)
	if v27 ~= nil then
		p23.xmlFiles[v27] = true
		v27.references = 1
		local v28 = 0
		while true do
			local v29 = string.format("connectionHoses.basicHoses.basicHose(%d)", v28)
			if not v27:hasProperty(v29) then
				break
			end
			local v30 = v27:getValue(v29 .. "#filename")
			if v30 ~= nil then
				v27.references = v27.references + 1
				local v31 = Utils.getFilename(v30, p26)
				local v32 = g_i3DManager:loadSharedI3DFileAsync(v31, false, false, p23.basicHoseI3DFileLoaded, p23, {
					["xmlFile"] = v27,
					["hoseKey"] = v29
				})
				local v33 = p23.sharedLoadRequestIds
				table.insert(v33, v32)
			end
			v28 = v28 + 1
		end
		local v34 = 0
		while true do
			local v35 = string.format("connectionHoses.connectionHoseTypes.connectionHoseType(%d)", v34)
			if not v27:hasProperty(v35) then
				break
			end
			local v36 = v27:getValue(v35 .. "#name")
			if v36 ~= nil then
				local v37
				if p23.typeByName[v36:upper()] == nil then
					if p25 ~= nil then
						v36 = p25 .. "." .. v36
					end
					v37 = {
						["name"] = v36,
						["adapters"] = {},
						["hoses"] = {}
					}
					p23.typeByName[v36:upper()] = v37
				else
					v37 = p23.typeByName[v36:upper()]
				end
				local v38 = 0
				while true do
					local v39 = string.format("%s.adapter(%d)", v35, v38)
					if not v27:hasProperty(v39) then
						break
					end
					local v40 = v27:getValue(v39 .. "#name", "DEFAULT")
					if p25 ~= nil then
						v40 = p25 .. "." .. v40
					end
					local v41 = v27:getValue(v39 .. "#filename")
					if v41 ~= nil then
						v27.references = v27.references + 1
						local v42 = Utils.getFilename(v41, p26)
						local v43 = g_i3DManager:loadSharedI3DFileAsync(v42, false, false, p23.adapterI3DFileLoaded, p23, {
							["hoseType"] = v37,
							["adapterName"] = v40,
							["xmlFile"] = v27,
							["adapterKey"] = v39
						})
						local v44 = p23.sharedLoadRequestIds
						table.insert(v44, v43)
					end
					v38 = v38 + 1
				end
				local v45 = 0
				while true do
					local v46 = string.format("%s.material(%d)", v35, v45)
					if not v27:hasProperty(v46) then
						break
					end
					local v47 = v27:getValue(v46 .. "#name", "DEFAULT")
					if p25 ~= nil then
						v47 = p25 .. "." .. v47
					end
					local v48 = v27:getValue(v46 .. "#filename")
					if v48 ~= nil then
						v27.references = v27.references + 1
						local v49 = Utils.getFilename(v48, p26)
						local v50 = g_i3DManager:loadSharedI3DFileAsync(v49, false, false, p23.materialI3DFileLoaded, p23, {
							["hoseType"] = v37,
							["hoseName"] = v47,
							["xmlFile"] = v27,
							["hoseKey"] = v46
						})
						local v51 = p23.sharedLoadRequestIds
						table.insert(v51, v50)
					end
					v45 = v45 + 1
				end
			end
			v34 = v34 + 1
		end
		local v52 = 0
		while true do
			local v53 = string.format("connectionHoses.sockets.socket(%d)", v52)
			if not v27:hasProperty(v53) then
				break
			end
			local v54 = v27:getValue(v53 .. "#name")
			if p25 ~= nil then
				v54 = p25 .. "." .. v54
			end
			local v55 = v27:getValue(v53 .. "#filename")
			if v54 ~= nil and v55 ~= nil then
				v27.references = v27.references + 1
				local v56 = Utils.getFilename(v55, p26)
				local v57 = g_i3DManager:loadSharedI3DFileAsync(v56, false, false, p23.socketI3DFileLoaded, p23, {
					["name"] = v54,
					["xmlFile"] = v27,
					["socketKey"] = v53
				})
				local v58 = p23.sharedLoadRequestIds
				table.insert(v58, v57)
			end
			v52 = v52 + 1
		end
		v27.references = v27.references - 1
		if v27.references == 0 then
			p23.xmlFiles[v27] = nil
			v27:delete()
		end
	end
end
function ConnectionHoseManager.basicHoseI3DFileLoaded(p59, p60, _, p61)
	local v62 = p61.xmlFile
	local v63 = p61.hoseKey
	if p60 ~= nil and p60 ~= 0 then
		local v64 = v62:getValue(v63 .. "#node", nil, p60)
		if v64 ~= nil then
			unlink(v64)
			local v65 = {
				["node"] = v64,
				["startStraightening"] = v62:getValue(v63 .. "#startStraightening", 2),
				["endStraightening"] = v62:getValue(v63 .. "#endStraightening", 2),
				["minCenterPointAngle"] = v62:getValue(v63 .. "#minCenterPointAngle", 90)
			}
			local v66 = v62:getValue(v63 .. "#length")
			if v66 == nil then
				printWarning(string.format("Warning: Missing length attribute in \'%s\'", v63))
			end
			local v67 = v62:getValue(v63 .. "#realLength")
			if v67 == nil then
				printWarning(string.format("Warning: Missing realLength attribute in \'%s\'", v63))
			end
			local v68 = v62:getValue(v63 .. "#diameter")
			if v68 == nil then
				printWarning(string.format("Warning: Missing diameter attribute in \'%s\'", v63))
			end
			if v66 ~= nil and (v67 ~= nil and v68 ~= nil) then
				v65.length = v66
				v65.realLength = v67
				v65.diameter = v68
				local v69 = p59.basicHoses
				table.insert(v69, v65)
			end
		end
		delete(p60)
	end
	v62.references = v62.references - 1
	if v62.references == 0 then
		p59.xmlFiles[v62] = nil
		v62:delete()
	end
end
function ConnectionHoseManager.adapterI3DFileLoaded(p70, p71, _, p72)
	local v73 = p72.hoseType
	local v74 = p72.adapterName
	local v75 = p72.xmlFile
	local v76 = p72.adapterKey
	if p71 ~= nil and p71 ~= 0 then
		local v77 = v75:getValue(v76 .. "#node", nil, p71)
		local v78 = getChildAt(v77, 0)
		unlink(v77)
		local v79 = v75:getValue(v76 .. "#detachedNode", nil, p71)
		if v79 ~= nil then
			unlink(v79)
		end
		if v78 == 0 then
			printWarning(string.format("Warning: Missing hose reference node as child from adapter \'%s\' in connection type \'%s\'", v74, v73.name))
		else
			v73.adapters[v74:upper()] = {
				["node"] = v77,
				["detachedNode"] = v79,
				["hoseReferenceNode"] = v78
			}
		end
		delete(p71)
	end
	v75.references = v75.references - 1
	if v75.references == 0 then
		p70.xmlFiles[v75] = nil
		v75:delete()
	end
end
function ConnectionHoseManager.materialI3DFileLoaded(p80, p81, _, p82)
	local v83 = p82.hoseType
	local v84 = p82.hoseName
	local v85 = p82.xmlFile
	local v86 = p82.hoseKey
	if p81 ~= nil and p81 ~= 0 then
		local v87 = v85:getValue(v86 .. "#materialNode", nil, p81)
		unlink(v87)
		if v87 ~= nil then
			local v88 = {
				["materialNode"] = v87,
				["uvMinMax"] = v85:getValue(v86 .. "#uvMinMax", nil, true),
				["uvLengthScale"] = v85:getValue(v86 .. "#uvLengthScale", 1),
				["uvRandomOffset"] = v85:getValue(v86 .. "#uvRandomOffset", "0 0", true),
				["materialTemplate"] = v85:getValue(v86 .. "#materialTemplateName")
			}
			v83.hoses[v84:upper()] = v88
		end
		delete(p81)
	end
	v85.references = v85.references - 1
	if v85.references == 0 then
		p80.xmlFiles[v85] = nil
		v85:delete()
	end
end
function ConnectionHoseManager.socketI3DFileLoaded(p89, p90, _, p91)
	local v92 = p91.name
	local v93 = p91.xmlFile
	local v94 = p91.socketKey
	if p90 ~= nil and p90 ~= 0 then
		local v95 = v93:getValue(v94 .. "#node", nil, p90)
		if v95 ~= nil then
			unlink(v95)
			local v96 = {
				["node"] = v95,
				["referenceNode"] = v93:getValue(v94 .. "#referenceNode"),
				["caps"] = {}
			}
			local v97 = 0
			while true do
				local v98 = string.format(v94 .. ".cap(%d)", v97)
				if not v93:hasProperty(v98) then
					break
				end
				local v99 = {
					["node"] = v93:getValue(v98 .. "#node")
				}
				if v99.node ~= nil then
					v99.openedRotation = v93:getValue(v98 .. "#openedRotation", nil, true)
					v99.closedRotation = v93:getValue(v98 .. "#closedRotation", nil, true)
					v99.openedVisibility = v93:getValue(v98 .. "#openedVisibility", true)
					v99.closedVisibility = v93:getValue(v98 .. "#closedVisibility", true)
					local v100 = v96.caps
					table.insert(v100, v99)
				end
				v97 = v97 + 1
			end
			if p89.sockets[v92:upper()] == nil then
				p89.sockets[v92:upper()] = v96
			else
				Logging.xmlError(v93, "Socket \'%s\' already exists", v92)
			end
		end
		delete(p90)
	end
	v93.references = v93.references - 1
	if v93.references == 0 then
		p89.xmlFiles[v93] = nil
		v93:delete()
	end
end
function ConnectionHoseManager.getHoseTypeByName(p101, p102, p103)
	if p102 == nil then
		return nil
	end
	if p103 ~= nil then
		local v104 = (p103 .. "." .. p102):upper()
		if p101.typeByName[v104] ~= nil then
			return p101.typeByName[v104]
		end
	end
	return p101.typeByName[p102:upper()]
end
function ConnectionHoseManager.getHoseAdapterByName(_, p105, p106, p107)
	if p105 == nil or p106 == nil then
		return nil
	end
	if p107 ~= nil then
		local v108 = (p107 .. "." .. p106):upper()
		if p105.adapters[v108] ~= nil then
			return p105.adapters[v108]
		end
	end
	return p105.adapters[p106:upper()]
end
function ConnectionHoseManager.getHoseMaterialByName(_, p109, p110, p111)
	if p109 == nil or p110 == nil then
		return nil
	end
	if p111 ~= nil then
		local v112 = (p111 .. "." .. p110):upper()
		if p109.hoses[v112] ~= nil then
			return p109.hoses[v112]
		end
	end
	return p109.hoses[p110:upper()]
end
function ConnectionHoseManager.getSocketByName(p113, p114, p115)
	if p114 == nil then
		return nil
	end
	if p115 ~= nil then
		local v116 = (p115 .. "." .. p114):upper()
		if p113.sockets[v116] ~= nil then
			return p113.sockets[v116]
		end
	end
	return p113.sockets[p114:upper()]
end
function ConnectionHoseManager.getClonedAdapterNode(p117, p118, p119, p120, p121)
	local v122 = p117:getHoseTypeByName(p118, p120)
	if v122 ~= nil then
		local v123 = p117:getHoseAdapterByName(v122, p119, p120)
		if v123 ~= nil then
			if not p121 then
				local v124 = clone(v123.node, true)
				setTranslation(v124, 0, 0, 0)
				setRotation(v124, 0, 0, 0)
				return v124, getChildAt(v124, 0)
			end
			if v123.detachedNode ~= nil then
				local v125 = clone(v123.detachedNode, true)
				setTranslation(v125, 0, 0, 0)
				setRotation(v125, 0, 0, 0)
				return v125
			end
		end
	end
	return nil
end
function ConnectionHoseManager.getClonedHoseNode(p126, p127, p128, p129, p130, p131, p132)
	local v133 = p126:getHoseTypeByName(p127, p132)
	if v133 ~= nil then
		local v134 = p126:getHoseMaterialByName(v133, p128, p132)
		if v134 ~= nil then
			local v135, v136, v137, v138, v139, v140 = p126:getClonedBasicHose(p129, p130)
			if v135 ~= nil then
				local v141 = getMaterial(v134.materialNode, 0)
				setMaterial(v135, v141, 0)
				if v134.materialTemplate ~= nil then
					v134.materialTemplate:apply(v135)
				end
				if p131 ~= nil then
					local v142 = setMaterialDiffuseMapFromFile(v141, "data/shared/detailLibrary/metallic/clear_diffuse.dds", true, true, false)
					setMaterial(v135, v142, 0)
					p131:apply(v135)
				end
				setShaderParameter(v135, "lengthAndDiameter", v136, p130 / v140, nil, nil, false)
				if v134.uvMinMax ~= nil then
					local v143 = v134.uvMinMax[2] - v134.uvMinMax[1]
					setShaderParameter(v135, "uvScale", p129 / v136 * v134.uvLengthScale, v143, nil, nil, false)
					local v144 = v134.uvRandomOffset[1]
					local v145 = v134.uvRandomOffset[2]
					if v144 ~= 0 then
						v144 = math.random() * v144
					end
					if v145 ~= 0 then
						v145 = math.random() * v145
					end
					setShaderParameter(v135, "offsetUV", v144, v134.uvMinMax[1] + v145, nil, nil, false)
				end
				return v135, v137, v138, v139
			end
		end
	end
	return nil, nil, nil, nil
end
function ConnectionHoseManager.getClonedBasicHose(p146, p147, p148)
	local v149 = (1 / 0)
	local v150 = (1 / 0)
	for _, v151 in pairs(p146.basicHoses) do
		local v152 = v151.diameter - p148
		local v153 = math.abs(v152)
		if v153 < v149 then
			v150 = v151.diameter
			v149 = v153
		end
	end
	local v154 = {}
	for _, v155 in pairs(p146.basicHoses) do
		local v156 = v155.diameter - v150
		if math.abs(v156) <= 0.0001 then
			table.insert(v154, v155)
		end
	end
	local v157 = (1 / 0)
	local v158 = nil
	for _, v159 in pairs(v154) do
		local v160 = v159.length - p147
		local v161 = math.abs(v160)
		if v161 < v157 then
			v158 = v159
			v157 = v161
		end
	end
	if v158 == nil then
		return nil
	else
		return clone(v158.node, true), v158.realLength, v158.startStraightening, v158.endStraightening, v158.minCenterPointAngle, v150
	end
end
function ConnectionHoseManager.linkSocketToNode(p162, p163, p164, p165, p166)
	local v167 = p162:getSocketByName(p163, p165)
	if v167 == nil or p164 == nil then
		return nil
	end
	local v168 = {
		["node"] = clone(v167.node, true)
	}
	setTranslation(v168.node, 0, 0, 0)
	setRotation(v168.node, 0, 0, 0)
	v168.referenceNode = I3DUtil.indexToObject(v168.node, v167.referenceNode)
	v168.caps = {}
	for _, v169 in ipairs(v167.caps) do
		local v170 = {}
		for v171, v172 in pairs(v169) do
			v170[v171] = v172
		end
		v170.node = I3DUtil.indexToObject(v168.node, v170.node)
		local v173 = v168.caps
		table.insert(v173, v170)
	end
	if p166 ~= nil then
		p166:apply(v168.node, "connector_color_mat")
	end
	link(p164, v168.node)
	p162:closeSocket(v168)
	return v168
end
function ConnectionHoseManager.getSocketTarget(_, p174, p175)
	if p174 == nil or p174.referenceNode == nil then
		return p175
	else
		return p174.referenceNode
	end
end
function ConnectionHoseManager.openSocket(_, p176)
	if p176 ~= nil and #p176.caps > 0 then
		for _, v177 in ipairs(p176.caps) do
			if v177.openedRotation ~= nil then
				local v178 = setRotation
				local v179 = v177.node
				local v180 = v177.openedRotation
				v178(v179, unpack(v180))
			end
			setVisibility(v177.node, v177.openedVisibility)
		end
	end
end
function ConnectionHoseManager.closeSocket(_, p181)
	if p181 ~= nil and #p181.caps > 0 then
		for _, v182 in ipairs(p181.caps) do
			if v182.openedRotation ~= nil then
				local v183 = setRotation
				local v184 = v182.node
				local v185 = v182.closedRotation
				v183(v184, unpack(v185))
			end
			setVisibility(v182.node, v182.closedVisibility)
		end
	end
end
function ConnectionHoseManager.registerXMLPaths(_, p186)
	p186:register(XMLValueType.STRING, "connectionHoses.basicHoses.basicHose(?)#filename", "I3d filename")
	p186:register(XMLValueType.NODE_INDEX, "connectionHoses.basicHoses.basicHose(?)#node", "Path to hose node")
	p186:register(XMLValueType.FLOAT, "connectionHoses.basicHoses.basicHose(?)#startStraightening", "Straightening factor on start side", 2)
	p186:register(XMLValueType.FLOAT, "connectionHoses.basicHoses.basicHose(?)#endStraightening", "Straightening factor on end side", 2)
	p186:register(XMLValueType.ANGLE, "connectionHoses.basicHoses.basicHose(?)#minCenterPointAngle", "Min. bending angle at the center of the hose", 90)
	p186:register(XMLValueType.FLOAT, "connectionHoses.basicHoses.basicHose(?)#length", "Reference length of hose")
	p186:register(XMLValueType.FLOAT, "connectionHoses.basicHoses.basicHose(?)#realLength", "Real length of hose in i3d")
	p186:register(XMLValueType.FLOAT, "connectionHoses.basicHoses.basicHose(?)#diameter", "Diameter of hose")
	p186:register(XMLValueType.STRING, "connectionHoses.connectionHoseTypes.connectionHoseType(?)#name", "Name of type")
	p186:register(XMLValueType.STRING, "connectionHoses.connectionHoseTypes.connectionHoseType(?).adapter(?)#name", "Name of adapter")
	p186:register(XMLValueType.STRING, "connectionHoses.connectionHoseTypes.connectionHoseType(?).adapter(?)#filename", "Path to i3d file")
	p186:register(XMLValueType.NODE_INDEX, "connectionHoses.connectionHoseTypes.connectionHoseType(?).adapter(?)#node", "Adapter node in i3d file")
	p186:register(XMLValueType.NODE_INDEX, "connectionHoses.connectionHoseTypes.connectionHoseType(?).adapter(?)#detachedNode", "Detached adapter node in i3d file")
	p186:register(XMLValueType.STRING, "connectionHoses.connectionHoseTypes.connectionHoseType(?).material(?)#name", "Name of material")
	p186:register(XMLValueType.STRING, "connectionHoses.connectionHoseTypes.connectionHoseType(?).material(?)#filename", "Path to i3d file")
	p186:register(XMLValueType.NODE_INDEX, "connectionHoses.connectionHoseTypes.connectionHoseType(?).material(?)#materialNode", "Material node in i3d file")
	p186:register(XMLValueType.VECTOR_2, "connectionHoses.connectionHoseTypes.connectionHoseType(?).material(?)#uvMinMax", "Min. and max. range of uv\'s in Y")
	p186:register(XMLValueType.FLOAT, "connectionHoses.connectionHoseTypes.connectionHoseType(?).material(?)#uvLengthScale", "Scale factor of the UV in X axis", 1)
	p186:register(XMLValueType.VECTOR_2, "connectionHoses.connectionHoseTypes.connectionHoseType(?).material(?)#uvRandomOffset", "Random offset range on x and y axis", "0 0")
	p186:register(XMLValueType.VEHICLE_MATERIAL, "connectionHoses.connectionHoseTypes.connectionHoseType(?).material(?)#materialTemplateName", "Material template to be applied by default")
	p186:register(XMLValueType.STRING, "connectionHoses.sockets.socket(?)#name", "Socket name")
	p186:register(XMLValueType.STRING, "connectionHoses.sockets.socket(?)#filename", "Path to i3d file")
	p186:register(XMLValueType.NODE_INDEX, "connectionHoses.sockets.socket(?)#node", "Socket node in i3d")
	p186:register(XMLValueType.STRING, "connectionHoses.sockets.socket(?)#referenceNode", "Index of reference node inside socket")
	p186:register(XMLValueType.STRING, "connectionHoses.sockets.socket(?).cap(?)#node", "Index of cap node inside socket")
	p186:register(XMLValueType.VECTOR_ROT, "connectionHoses.sockets.socket(?).cap(?)#openedRotation", "Opened rotation")
	p186:register(XMLValueType.VECTOR_ROT, "connectionHoses.sockets.socket(?).cap(?)#closedRotation", "Closed rotation")
	p186:register(XMLValueType.BOOL, "connectionHoses.sockets.socket(?).cap(?)#openedVisibility", "Opened visibility", true)
	p186:register(XMLValueType.BOOL, "connectionHoses.sockets.socket(?).cap(?)#closedVisibility", "Closed visibility", true)
end
g_connectionHoseManager = ConnectionHoseManager.new()

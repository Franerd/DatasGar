NoteManager = {}
NoteManager.NOTES_DIRECTORY = getUserProfileAppPath() .. "notes/"
local v_u_1 = Class(NoteManager, AbstractManager)
function NoteManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function NoteManager.initDataStructures(p3)
	p3.sessionDirectory = nil
	p3.sessionTimestamp = nil
	p3.mapTitle = nil
	p3.currentNoteIndex = 1
	local v4 = {
		1,
		1,
		1,
		1
	}
	p3.colors = {}
	local v5 = p3.colors
	table.insert(v5, {
		["color"] = v4
	})
	for _, v6 in ipairs(DebugUtil.COLORS) do
		local v7 = p3.colors
		local v8 = {
			["color"] = {
				v6[1],
				v6[2],
				v6[3],
				1
			}
		}
		table.insert(v7, v8)
	end
	p3.lastColor = v4
	if not p3.initialized then
		addConsoleCommand("gsNoteExport", "Exports currently created note nodes as i3d file", "consoleCommandExportNotes", p3)
		addConsoleCommand("gsNoteList", "Lists currently created note nodes in console/log", "consoleCommandListNotes", p3)
		p3.initialized = true
	end
end
function NoteManager.registerInputActionEvent(p9)
	if g_currentMission ~= nil then
		local _, v10 = g_inputBinding:registerActionEvent(InputAction.ADD_NOTE, p9, p9.onAddNote, false, true, false, true)
		g_inputBinding:setActionEventTextVisibility(v10, false)
	end
end
function NoteManager.unloadMapData(p11)
	p11:exportNotes()
	p11:resetNotes()
end
function NoteManager.resetNotes(p12)
	if p12.notesRoot ~= nil and entityExists(p12.notesRoot) then
		delete(p12.notesRoot)
	end
	p12.notesRoot = nil
	p12.sessionDirectory = nil
	p12.currentNoteIndex = 1
end
function NoteManager.loadNotes(_) end
function NoteManager.onAddNote(p13)
	if p13.sessionDirectory == nil then
		createFolder(NoteManager.NOTES_DIRECTORY)
		p13.mapTitle = string.gsub(g_currentMission.missionInfo.mapTitle, " ", "")
		p13.sessionTimestamp = getDate("%Y_%m_%d__%H_%M")
		p13.sessionDirectory = NoteManager.NOTES_DIRECTORY .. p13.sessionTimestamp .. "_" .. p13.mapTitle .. "/"
		createFolder(p13.sessionDirectory)
	end
	local v14 = string.format("note_%d.jpg", p13.currentNoteIndex)
	p13.lastNoteScreenshotFilepath = p13.sessionDirectory .. v14
	saveScreenshot(p13.lastNoteScreenshotFilepath)
	TextInputDialog.show(p13.onNoteTextEntered, p13, nil, "Enter note text", false, nil, "Add Note", 200, nil, false)
end
function NoteManager.onNoteTextEntered(p15, p16, p17)
	if p17 then
		local v18 = string.trim(p16)
		if v18 ~= "" then
			ColorPickerDialog.show(p15.onNotePickColor, p15, {
				["text"] = v18,
				["colors"] = p15.colors
			}, p15.colors, p15.lastColor)
			return
		end
	end
	p15:cancelCurrentNote()
end
function NoteManager.onNotePickColor(p19, p20, p21)
	if p20 == nil then
		p19:cancelCurrentNote()
	else
		if p19.notesRoot == nil then
			p19.notesRoot = createTransformGroup("noteNodes")
			link(getRootNode(), p19.notesRoot)
		end
		local v22 = p21.colors[p20].color
		p19.lastColor = v22
		local v23 = createNoteNode(p19.notesRoot, string.format("[%d] %s", p19.currentNoteIndex, p21.text), v22[1], v22[2], v22[3], false)
		setName(v23, string.format("note_%d", p19.currentNoteIndex))
		if g_isDevelopmentVersion and p19.currentNoteIndex == 1 then
			executeConsoleCommand("enableNoteRendering true", true)
		end
		p19.currentNoteIndex = p19.currentNoteIndex + 1
		Logging.info("created note \'%s\' at %.1f %.1f %.1f", getNoteNodeText(v23), getWorldTranslation(v23))
		p19.lastNoteScreenshotFilepath = nil
	end
end
function NoteManager.cancelCurrentNote(p24)
	if p24.lastNoteScreenshotFilepath ~= nil and fileExists(p24.lastNoteScreenshotFilepath) then
		deleteFile(p24.lastNoteScreenshotFilepath)
	end
end
function NoteManager.exportNotes(p25)
	if p25.notesRoot == nil then
		return 0
	end
	local v26 = string.format("notes_%s_%s.i3d", p25.sessionTimestamp, p25.mapTitle)
	local v27 = p25.sessionDirectory .. v26
	Logging.info("Exporting notes to %s", v27)
	exportNoteNodes(v27)
	return getNumOfChildren(p25.notesRoot)
end
function NoteManager.consoleCommandExportNotes(p28)
	return p28.notesRoot == nil and "Error: No notes to export, add notes first" or string.format("Exported %d notes", p28:exportNotes())
end
function NoteManager.consoleCommandListNotes(p29)
	if p29.notesRoot == nil then
		return "No existing notes"
	end
	local v30 = getNumOfChildren(p29.notesRoot)
	for v31 = 0, v30 - 1 do
		local v32 = getChildAt(p29.notesRoot, v31)
		local v33, v34, v35 = getWorldTranslation(v32)
		print(string.format("%s [Pos: %.1f %1.f %1.f]", getNoteNodeText(v32), v33, v34, v35))
	end
	return string.format("Listed %d notes", v30)
end
g_noteManager = NoteManager.new()

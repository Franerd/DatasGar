BeaconLightManager = {}
BeaconLightManager.MASK_ALL = 4294967295
BeaconLightManager.MODE = {}
BeaconLightManager.MODE.ROTATE_LEFT = 0
BeaconLightManager.MODE.ROTATE_RIGHT = 1
BeaconLightManager.MODE.BLINK = 2
BeaconLightManager.MODE.ROTATE_LEFT_RIGHT = 3
BeaconLightManager.MODE.DOUBLE_ROTATE_CROSS = 4
BeaconLightManager.MODE.DOUBLE_ROTATE_LEFT = 5
BeaconLightManager.MODE.DOUBLE_ROTATE_RIGHT = 6
BeaconLightManager.MODE.DOUBLE_BLINK_TRIPLE_WAIT = 7
local v_u_1 = Class(BeaconLightManager, AbstractManager)
function BeaconLightManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.nextBeaconLightId = 1
	v4.beaconLights = {}
	v4.maxNumBeaconLights = 1
	v4.lastBrightnessScale = nil
	return v4
end
function BeaconLightManager.getNumOfLights(_)
	return getNumOfBeaconLights()
end
function BeaconLightManager.activateBeaconLight(p5, p6, p7, p8, p9)
	if #p5.beaconLights >= p5.maxNumBeaconLights then
		return nil
	end
	local v10 = BeaconLightManager.MASK_ALL
	local v11 = g_gameSettings:getValue(GameSettings.SETTING.REAL_BEACON_LIGHT_BRIGHTNESS)
	if v11 > 0 then
		setBeaconLights(v10, p6, p7, p8, p9 * v11)
	end
	local v12 = p5.nextBeaconLightId
	p5.nextBeaconLightId = p5.nextBeaconLightId + 1
	local v13 = p5.beaconLights
	table.insert(v13, {
		["id"] = v12,
		["mask"] = v10,
		["mode"] = p6,
		["numLEDs"] = p7,
		["rpm"] = p8,
		["brightness"] = p9,
		["brightnessScale"] = v11
	})
	return v12
end
function BeaconLightManager.deactivateBeaconLight(p14, p15)
	if p15 ~= nil then
		local v16 = g_gameSettings:getValue(GameSettings.SETTING.REAL_BEACON_LIGHT_BRIGHTNESS)
		for v17, v18 in ipairs(p14.beaconLights) do
			if v18.id == p15 then
				if v16 > 0 then
					setBeaconLights(v18.mask, 0, 0, 100, 0)
				end
				table.remove(p14.beaconLights, v17)
				return
			end
		end
	end
end
function BeaconLightManager.updateBeaconLights(p19)
	if #p19.beaconLights > 0 then
		local v20 = g_gameSettings:getValue(GameSettings.SETTING.REAL_BEACON_LIGHT_BRIGHTNESS)
		for _, v21 in ipairs(p19.beaconLights) do
			if v20 > 0 then
				setBeaconLights(v21.mask, v21.mode, v21.numLEDs, v21.rpm, v21.brightness * v20)
				v21.brightnessScale = v20
			elseif v20 == 0 and v21.brightnessScale > 0 then
				setBeaconLights(v21.mask, 0, 0, 100, 0)
				v21.brightnessScale = 0
			end
		end
	end
end
function BeaconLightManager.getModeByName(p22)
	if p22 == nil then
		return nil
	end
	local v23 = p22:upper()
	return BeaconLightManager.MODE[v23]
end
function BeaconLightManager.registerXMLPaths(p24, p25)
	p24:register(XMLValueType.STRING, p25 .. "#mode", "Real beacon light mode")
	p24:register(XMLValueType.FLOAT, p25 .. "#rpm", "Real beacon rpm")
	p24:register(XMLValueType.FLOAT, p25 .. "#numLEDScale", "Real beacon num led factor (0-1)")
	p24:register(XMLValueType.FLOAT, p25 .. "#brightnessScale", "Real beacon brightness factor (0-1)")
end
function BeaconLightManager.loadDeviceFromXML(p26, p27)
	local v28 = p26:getValue(p27 .. "#mode")
	if v28 ~= nil then
		local v29 = BeaconLightManager.getModeByName(v28)
		if v29 ~= nil then
			return {
				["mode"] = v29,
				["rpm"] = p26:getValue(p27 .. "#rpm", 100),
				["numLEDScale"] = p26:getValue(p27 .. "#numLEDScale", 1),
				["brightnessScale"] = p26:getValue(p27 .. "#brightnessScale", 1)
			}
		end
	end
	return nil
end
g_beaconLightManager = BeaconLightManager.new()

DepthOfFieldManager = {}
DepthOfFieldManager.DEFAULT_VALUES = {
	0.8,
	0.5,
	0.2,
	1000,
	1400,
	false
}
local v_u_1 = Class(DepthOfFieldManager, AbstractManager)
function DepthOfFieldManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AbstractManager.new(p2 or v_u_1)
	v3.defaultState = table.clone(DepthOfFieldManager.DEFAULT_VALUES)
	v3:reset()
	v3.areaStack = {
		{
			-1,
			-1,
			-1,
			-1,
			false
		}
	}
	return v3
end
function DepthOfFieldManager.reset(p4)
	p4:setManipulatedParams(nil, nil, nil, nil, nil, nil)
end
function DepthOfFieldManager.setManipulatedParams(p5, p6, p7, p8, p9, p10, p11)
	local v12 = p6 or p5.defaultState[1]
	local v13 = p7 or p5.defaultState[2]
	local v14 = p8 or p5.defaultState[3]
	local v15 = p9 or p5.defaultState[4]
	local v16 = p10 or p5.defaultState[5]
	local v17 = Utils.getNoNil(p11, p5.defaultState[6])
	setDoFparams(v12, v13, v14, v15, v16, v17)
end
function DepthOfFieldManager.applyInfo(p18, p19)
	p18:setManipulatedParams(p19.nearCoCRadius, p19.nearBlurEnd, p19.farCoCRadius, p19.farBlurStart, p19.farBlurEnd, p19.applyToSky)
end
function DepthOfFieldManager.createInfo(_, p20, p21, p22, p23, p24, p25)
	return {
		["nearCoCRadius"] = p20,
		["nearBlurEnd"] = p21,
		["farCoCRadius"] = p22,
		["farBlurStart"] = p23,
		["farBlurEnd"] = p24,
		["applyToSky"] = p25
	}
end
function DepthOfFieldManager.pushArea(p26, p27, p28, p29, p30)
	local v31 = p26.areaStack
	local v32 = {
		p27,
		p28,
		p27 + p29,
		p28 + p30,
		true
	}
	table.insert(v31, 1, v32)
	p26:updateArea()
end
function DepthOfFieldManager.popArea(p33)
	if #p33.areaStack > 1 then
		table.remove(p33.areaStack, 1)
	elseif g_isDevelopmentVersion then
		Logging.devWarning("Try to pop last blur area")
		printCallstack()
	end
	p33:updateArea()
end
function DepthOfFieldManager.updateArea(p34)
	if #p34.areaStack > 0 then
		local v35 = 1
		local v36 = 1
		local v37 = 0
		local v38 = 0
		local v39 = false
		for _, v40 in ipairs(p34.areaStack) do
			if v40[5] then
				local v41, v42, v43, v44 = unpack(v40)
				v35 = math.min(v35, v41)
				v36 = math.min(v36, v42)
				v37 = math.max(v37, v43)
				v38 = math.max(v38, v44)
				v39 = true
			end
		end
		if not v39 then
			v35 = -1
			v36 = -1
			v37 = -1
			v38 = -1
		end
		setDoFBlurArea(v35, v36, v37, v38)
	end
end
function DepthOfFieldManager.consoleCommandFarParams(p45, p46, p47, p48)
	local v49 = tonumber(p46)
	local v50 = tonumber(p47)
	local v51 = tonumber(p48)
	p45.defaultState[3] = v49 or p45.defaultState[3]
	p45.defaultState[4] = v50 or p45.defaultState[4]
	p45.defaultState[5] = v51 or p45.defaultState[5]
	p45:setManipulatedParams(nil, nil, nil, nil, nil, nil)
	Logging.info("Set far depth of field parameters: farCoC=%.2f, farStart=%d, farEnd=%d", p45.defaultState[3], p45.defaultState[4], p45.defaultState[5])
end
function DepthOfFieldManager.consoleCommandNearParams(p52, p53, p54, p55)
	local v56 = string.lower(p53) == "true"
	local v57 = tonumber(p54)
	local v58 = tonumber(p55)
	setAllowNearDofForMarketingCamera(v56)
	p52.defaultState[1] = v57 or p52.defaultState[1]
	p52.defaultState[2] = v58 or p52.defaultState[2]
	p52:setManipulatedParams(nil, nil, nil, nil, nil, nil)
	Logging.info("Set near depth of field parameters: enabled=%s, nearCoC=%.2f, nearEnd=%.2f", tostring(v56), p52.defaultState[1], p52.defaultState[2])
end
g_depthOfFieldManager = DepthOfFieldManager.new()
addConsoleCommand("gsDepthOfFieldSetFarParams", "Set far depth of field parameters", "consoleCommandFarParams", g_depthOfFieldManager, "farCoC; farStart; farEnd")
addConsoleCommand("gsDepthOfFieldSetNearParams", "Set far depth of field parameters", "consoleCommandNearParams", g_depthOfFieldManager, "enabled; nearCoC; nearEnd")

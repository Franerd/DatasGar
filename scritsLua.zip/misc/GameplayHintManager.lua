GameplayHintManager = {}
local v_u_1 = Class(GameplayHintManager, AbstractManager)
function GameplayHintManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function GameplayHintManager.initDataStructures(p3)
	p3.gameplayHints = {}
	p3.isLoaded = false
end
function GameplayHintManager.loadMapData(p4, p5, _)
	GameplayHintManager:superClass().loadMapData(p4)
	local v6 = getXMLString(p5, "map.gameplayHints#filename")
	if v6 == nil then
		Logging.xmlInfo(p5, "No gameplay hints defined for map")
		return false
	end
	local v7 = Utils.getFilename(v6, g_currentMission.baseDirectory)
	if v7 == nil or (v7 == "" or not fileExists(v7)) then
		Logging.xmlError(p5, "Could not load gameplayHint config file \'" .. tostring(v6) .. "\'!")
		return false
	end
	local v8, _ = Utils.getModNameAndBaseDirectory(v7)
	local v9 = loadXMLFile("gameplayHints", v7)
	if v9 ~= 0 then
		local v10 = 0
		while true do
			local v11 = string.format("gameplayHints.gameplayHint(%d)", v10)
			if not hasXMLProperty(v9, v11) then
				break
			end
			local v12 = getXMLString(v9, v11)
			if v12:sub(1, 6) == "$l10n_" then
				v12 = g_i18n:getText(v12:sub(7), v8)
			end
			local v13 = p4.gameplayHints
			table.insert(v13, v12)
			v10 = v10 + 1
		end
		delete(v9)
	end
	p4.isLoaded = true
	return true
end
function GameplayHintManager.getRandomGameplayHint(p14, p15)
	local v16 = {}
	local v17 = {}
	if #p14.gameplayHints <= p15 then
		return p14.gameplayHints
	end
	local v18 = #p14.gameplayHints
	while #v16 < p15 do
		local v19 = math.random(1, v18)
		if v17[v19] == nil then
			local v20 = p14.gameplayHints[v19]
			table.insert(v16, v20)
			v17[v19] = v19
		end
	end
	return v16
end
function GameplayHintManager.getIsLoaded(p21)
	return p21.isLoaded
end
g_gameplayHintManager = GameplayHintManager.new()

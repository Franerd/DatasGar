SprayType = nil
SprayTypeManager = {}
local v_u_1 = Class(SprayTypeManager, AbstractManager)
function SprayTypeManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function SprayTypeManager.initDataStructures(p3)
	p3.numSprayTypes = 0
	p3.sprayTypes = {}
	p3.nameToSprayType = {}
	p3.nameToIndex = {}
	p3.indexToName = {}
	p3.fillTypeIndexToSprayType = {}
	SprayType = p3.nameToIndex
end
function SprayTypeManager.loadDefaultTypes(p4)
	local v5 = loadXMLFile("sprayTypes", "data/maps/maps_sprayTypes.xml")
	p4:loadSprayTypes(v5, nil, true)
	delete(v5)
end
function SprayTypeManager.loadMapData(p6, p7, p8, p9)
	SprayTypeManager:superClass().loadMapData(p6)
	p6:loadDefaultTypes()
	return XMLUtil.loadDataFromMapXML(p7, "sprayTypes", p9, p6, p6.loadSprayTypes, p8)
end
function SprayTypeManager.loadSprayTypes(p10, p11, _, p12)
	local v13 = 0
	while true do
		local v14 = string.format("map.sprayTypes.sprayType(%d)", v13)
		if not hasXMLProperty(p11, v14) then
			break
		end
		p10:addSprayType(getXMLString(p11, v14 .. "#name"), getXMLFloat(p11, v14 .. "#litersPerSecond"), getXMLString(p11, v14 .. "#type"), FieldSprayType.getValueByName(getXMLString(p11, v14 .. "#sprayGroundType")), p12)
		v13 = v13 + 1
	end
	return true
end
function SprayTypeManager.addSprayType(p15, p16, p17, p18, p19, p20)
	if not ClassUtil.getIsValidIndexName(p16) then
		printWarning("Warning: \'" .. tostring(p16) .. "\' is not a valid name for a sprayType. Ignoring sprayType!")
		return nil
	end
	local v21 = p16:upper()
	local v22 = g_fillTypeManager:getFillTypeByName(v21)
	if v22 ~= nil then
		if p20 and p15.nameToSprayType[v21] ~= nil then
			printWarning("Warning: SprayType \'" .. tostring(v21) .. "\' already exists. Ignoring sprayType!")
			return nil
		end
		local v23 = p15.nameToSprayType[v21]
		if v23 == nil then
			p15.numSprayTypes = p15.numSprayTypes + 1
			v23 = {
				["name"] = v21,
				["index"] = p15.numSprayTypes,
				["fillType"] = v22,
				["litersPerSecond"] = Utils.getNoNil(p17, 0)
			}
			local v24 = p18:upper()
			v23.isFertilizer = v24 == "FERTILIZER"
			v23.isLime = v24 == "LIME"
			v23.isHerbicide = v24 == "HERBICIDE"
			if not (v23.isFertilizer or (v23.isLime or v23.isHerbicide)) then
				printWarning("Warning: SprayType \'" .. tostring(v21) .. "\' type \'" .. tostring(v24) .. "\' is invalid. Possible values are \'FERTILIZER\', \'HERBICIDE\' or \'LIME\'. Ignoring sprayType!")
				return nil
			end
			local v25 = p15.sprayTypes
			table.insert(v25, v23)
			p15.nameToSprayType[v21] = v23
			p15.nameToIndex[v21] = p15.numSprayTypes
			p15.indexToName[p15.numSprayTypes] = v21
			p15.fillTypeIndexToSprayType[v22.index] = v23
		end
		v23.litersPerSecond = p17 or (v23.litersPerSecond or 0)
		v23.sprayGroundType = p19 or (v23.sprayGroundType or 1)
		return v23
	end
	printWarning("Warning: Missing fillType \'" .. tostring(v21) .. "\' for sprayType definition. Ignoring sprayType!")
end
function SprayTypeManager.getSprayTypeByIndex(p26, p27)
	if p27 == nil then
		return nil
	else
		return p26.sprayTypes[p27]
	end
end
function SprayTypeManager.getSprayTypeByName(p28, p29)
	if p29 == nil then
		return nil
	end
	local v30 = p29:upper()
	return p28.nameToSprayType[v30]
end
function SprayTypeManager.getFillTypeNameByIndex(p31, p32)
	if p32 == nil then
		return nil
	else
		return p31.indexToName[p32]
	end
end
function SprayTypeManager.getFillTypeIndexByName(p33, p34)
	if p34 == nil then
		return nil
	end
	local v35 = p34:upper()
	return p33.nameToIndex[v35]
end
function SprayTypeManager.getFillTypeByName(p36, p37)
	if p37 == nil then
		return nil
	end
	local v38 = p37:upper()
	return p36.nameToSprayType[v38]
end
function SprayTypeManager.getSprayTypeByFillTypeIndex(p39, p40)
	if p40 == nil then
		return nil
	else
		return p39.fillTypeIndexToSprayType[p40]
	end
end
function SprayTypeManager.getSprayTypeIndexByFillTypeIndex(p41, p42)
	if p42 ~= nil then
		local v43 = p41.fillTypeIndexToSprayType[p42]
		if v43 ~= nil then
			return v43.index
		end
	end
	return nil
end
function SprayTypeManager.getSprayTypes(p44)
	return p44.sprayTypes
end
g_sprayTypeManager = SprayTypeManager.new()

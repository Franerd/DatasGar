BezierCurve = {}
local v_u_1 = Class(BezierCurve)
function BezierCurve.new(p2, p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = v_u_1
	local v7 = setmetatable({}, v6)
	v7.positionX1 = math.clamp(p2, 0, 1)
	v7.positionY1 = p3
	v7.positionX2 = math.clamp(p4, 0, 1)
	v7.positionY2 = p5
	v7.cx = 0
	v7.bx = 0
	v7.ax = 0
	v7.cy = 0
	v7.by = 0
	v7.ay = 0
	v7:recalculateCoefficients()
	return v7
end
function BezierCurve.recalculateCoefficients(p8)
	p8.cx = 3 * p8.positionX1
	p8.bx = 3 * (p8.positionX2 - p8.positionX1) - p8.cx
	p8.ax = 1 - p8.cx - p8.bx
	p8.cy = 3 * p8.positionY1
	p8.by = 3 * (p8.positionY2 - p8.positionY1) - p8.cy
	p8.ay = 1 - p8.cy - p8.by
end
function BezierCurve.setPositionX1(p9, p10)
	p9.positionX1 = math.clamp(p10, 0, 1)
	p9:recalculateCoefficients()
end
function BezierCurve.setPositionY1(p11, p12)
	p11.positionY1 = math.clamp(p12, 0, 1)
	p11:recalculateCoefficients()
end
function BezierCurve.setPositionX2(p13, p14)
	p13.positionX2 = math.clamp(p14, 0, 1)
	p13:recalculateCoefficients()
end
function BezierCurve.setPositionY2(p15, p16)
	p15.positionY2 = math.clamp(p16, 0, 1)
	p15:recalculateCoefficients()
end
function BezierCurve.sampleX(p17, p18)
	return ((p17.ax * p18 + p17.bx) * p18 + p17.cx) * p18
end
function BezierCurve.sampleY(p19, p20)
	return ((p19.ay * p20 + p19.by) * p20 + p19.cy) * p20
end
function BezierCurve.sampleDerivativeX(p21, p22)
	return (3 * p21.ax * p22 + 2 * p21.bx) * p22 + p21.cx
end
function BezierCurve.solveX(p23, p24, p25)
	local v26 = p24
	local v27 = p25 or 1e-6
	for _ = 1, 8 do
		local v28 = p23:sampleX(p24) - v26
		if math.abs(v28) < v27 then
			return p24
		end
		local v29 = p23:sampleDerivativeX(p24)
		if math.abs(v29) < v27 then
			break
		end
		p24 = p24 - v28 / v29
	end
	local v30 = 0
	local v31 = 1
	if v26 < v30 then
		return v30
	end
	if v31 < v26 then
		return v31
	end
	local v32 = v26
	while v30 < v31 do
		local v33 = p23:sampleX(v26)
		local v34 = v33 - v32
		if math.abs(v34) < v27 then
			return v26
		end
		if v33 < v32 then
			v30 = v26
			v26 = v31
		end
		local v35 = (v26 - v30) * 0.5 + v30
		v31 = v26
		v26 = v35
	end
	return v26
end
function BezierCurve.solve(p36, p37, p38)
	return p36:sampleY(p36:solveX(p37, p38))
end

MapManager = {}
local v_u_1 = Class(MapManager, AbstractManager)
function MapManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function MapManager.initDataStructures(p3)
	p3.maps = {}
	p3.idToMap = {}
end
function MapManager.addMapItem(p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21)
	if p4.idToMap[p5] ~= nil then
		Logging.warning("Duplicate map id \'%s\'. Ignoring this map definition.", p5)
		return false
	end
	local v22 = {
		["id"] = tostring(p5),
		["scriptFilename"] = p6,
		["mapXMLFilename"] = p8,
		["className"] = p7,
		["defaultVehiclesXMLFilename"] = p9,
		["defaultHandToolsXMLFilename"] = p10,
		["defaultPlaceablesXMLFilename"] = p11,
		["defaultItemsXMLFilename"] = p12,
		["title"] = p13,
		["description"] = p14,
		["iconFilename"] = p15,
		["baseDirectory"] = p16,
		["customEnvironment"] = p17,
		["isMultiplayerSupported"] = p18,
		["isModMap"] = p19,
		["prohibitOtherMods"] = p20,
		["isSelectable"] = p21
	}
	local v23 = p4.maps
	table.insert(v23, v22)
	p4.idToMap[p5] = v22
	return true
end
function MapManager.loadMapFromXML(p24, p25, p26, p27, p28, p29, p30, p31, p32)
	local v33 = p25:getString(p26 .. "#id", "")
	if v33 == "" then
		Logging.error("Failed to load map \'%s\'. Missing attribute \'%s#id\'.", p28 or "Basemap", p26)
		return false
	end
	local v34
	if p28 == nil then
		v34 = nil
	else
		v34 = p28
	end
	local v35 = p25:getString(p26 .. "#defaultVehiclesXMLFilename", "")
	local v36 = p25:getString(p26 .. "#defaultHandToolsXMLFilename", "")
	local v37 = p25:getString(p26 .. "#defaultPlaceablesXMLFilename", "")
	local v38 = p25:getString(p26 .. "#defaultItemsXMLFilename", "")
	local v39 = p25:getI18NValue(p26 .. ".title", "", v34, true)
	local v40 = p25:getI18NValue(p26 .. ".description", "", v34, true)
	local v41 = p25:getString(p26 .. "#className", "Mission00")
	local v42 = p25:getString(p26 .. "#filename", "$dataS/scripts/mission00.lua")
	local v43 = p25:getString(p26 .. "#configFilename", "")
	local v44 = p25:getI18NValue(p26 .. ".iconFilename", "", v34, true)
	local v45
	if p28 == nil then
		v45 = v33
	else
		v45 = v33 .. " " .. v33
	end
	if v41:find("[^%w_]") ~= nil then
		Logging.error("Failed to load map \'%s\'. Invalid map class name: \'%s\'. No whitespaces allowed.", v45, v41)
		return false
	end
	if v41 == "" then
		Logging.error("Failed to load map \'%s\'. Missing attribute \'%s#className\'.", v45, p26)
		return false
	end
	if v39 == "" then
		Logging.error("Failed to load map \'%s\'. Missing element \'%s.title\'.", v45, p26)
		return false
	end
	if v42 == "" then
		Logging.error("Failed to load map \'%s\'. Missing attribute \'%s#filename\'.", v45, p26)
		return false
	end
	if v35 == "" then
		Logging.error("Failed to load map \'%s\'. Missing attribute \'%s#defaultVehiclesXMLFilename\'.", v45, p26)
		return false
	end
	if v36 == "" then
		Logging.error("Failed to load map \'%s\'. Missing attribute \'%s#defaultHandToolsXMLFilename\'.", v45, p26)
		return false
	end
	if v37 == "" then
		Logging.error("Failed to load map \'%s\'. Missing attribute \'%s#defaultPlaceablesXMLFilename\'.", v45, p26)
		return false
	end
	if v38 == "" then
		Logging.error("Failed to load map \'%s\'. Missing attribute \'%s#defaultItemsXMLFilename\'.", v45, p26)
		return false
	end
	if v44 == "" then
		Logging.error("Failed to load map \'%s\'. Missing element \'%s.iconFilename\'.", v45, p26)
		return false
	end
	local v46, v47 = Utils.getFilename(v42, p27)
	if v47 then
		v41 = p28 .. "." .. v41
	end
	local v48
	if p30 or p32 then
		v48 = p25:getBool(p26 .. ".prohibitOtherMods", nil) or nil
	else
		v48 = nil
	end
	local v49 = true
	if p30 or p32 then
		v49 = p25:getBool(p26 .. ".isSelectable", v49)
	end
	local v50 = Utils.getFilename(v43, p27)
	local v51, _ = Utils.getModNameAndBaseDirectory(v50)
	if p28 ~= nil then
		v33 = p28 .. "." .. v33
	end
	local v52 = Utils.getFilename(v44, p27)
	local v53 = Utils.getFilename(v35, p27)
	local v54 = Utils.getFilename(v36, p27)
	local v55 = Utils.getFilename(v37, p27)
	local v56 = Utils.getFilename(v38, p27)
	if not GS_IS_CONSOLE_VERSION or (p30 or (not v47 or p32)) then
		return p24:addMapItem(v33, v46, v41, v43, v53, v54, v55, v56, v39, v40, v52, p27, v51, p29, p31, v48, v49)
	end
	Logging.error("Can\'t register map \'%s\' with scripts on consoles.", v33)
	return false
end
function MapManager.getModNameFromMapId(_, p57)
	local v58 = string.split(p57, ".")
	if #v58 > 1 then
		return v58[1]
	else
		return nil
	end
end
function MapManager.getMapById(p59, p60)
	return p59.idToMap[p60]
end
function MapManager.removeMapItem(p61, p62)
	local v63 = p61.maps[p62]
	if v63 ~= nil then
		p61.idToMap[v63.id] = nil
		table.remove(p61.maps, p62)
	end
end
function MapManager.getNumOfMaps(p64)
	return #p64.maps
end
function MapManager.getMapDataByIndex(p65, p66)
	return p65.maps[p66]
end
function MapManager.getMapByConfigFilename(p67, p68)
	for _, v69 in ipairs(p67.maps) do
		if v69.mapXMLFilename == p68 then
			return v69
		end
	end
	return nil
end
g_mapManager = MapManager.new()

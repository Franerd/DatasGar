ToolType = nil
ToolTypeManager = {}
local v_u_1 = Class(ToolTypeManager, AbstractManager)
function ToolTypeManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function ToolTypeManager.initDataStructures(p3)
	p3.indexToName = {}
	p3.nameToInt = {}
	ToolType = p3.nameToInt
end
function ToolTypeManager.loadMapData(p4)
	ToolTypeManager:superClass().loadMapData(p4)
	p4:addToolType("undefined")
	p4:addToolType("dischargeable")
	p4:addToolType("pallet")
	p4:addToolType("trigger")
	p4:addToolType("bale")
	return true
end
function ToolTypeManager.addToolType(p5, p6)
	local v7 = string.upper(p6)
	if ClassUtil.getIsValidIndexName(v7) then
		if ToolType[v7] == nil then
			local v8 = p5.indexToName
			table.insert(v8, v7)
			p5.nameToInt[v7] = #p5.indexToName
		end
		return ToolType[v7]
	else
		printWarning("Warning: \'" .. tostring(v7) .. "\' is not a valid name for a toolType. Ignoring toolType!")
		return nil
	end
end
function ToolTypeManager.getToolTypeNameByIndex(p9, p10)
	return p9.indexToName[p10] == nil and "UNDEFINED" or p9.indexToName[p10]
end
function ToolTypeManager.getToolTypeIndexByName(p11, p12)
	local v13 = p12:upper()
	if p11.nameToInt[v13] == nil then
		return ToolType.UNDEFINED
	else
		return p11.nameToInt[v13]
	end
end
function ToolTypeManager.getNumberOfToolTypes(p14)
	return #p14.indexToName
end
g_toolTypeManager = ToolTypeManager.new()

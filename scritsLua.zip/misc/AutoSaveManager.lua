AutoSaveManager = {}
AutoSaveManager.DEFAULT_INTERVAL = 15
AutoSaveManager.INTERVAL_OPTIONS = {}
AutoSaveManager.INTERVAL_OPTIONS[1] = 0
AutoSaveManager.INTERVAL_OPTIONS[2] = 5
AutoSaveManager.INTERVAL_OPTIONS[3] = 10
AutoSaveManager.INTERVAL_OPTIONS[4] = 15
local v_u_1 = Class(AutoSaveManager, AbstractManager)
function AutoSaveManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AbstractManager.new(p2 or v_u_1)
	v3.interval = 60000 * AutoSaveManager.DEFAULT_INTERVAL
	v3.time = v3.interval
	v3.isPending = false
	v3.isActive = true
	v3.saveNextFrame = false
	return v3
end
function AutoSaveManager.loadFinished(p4)
	g_messageCenter:subscribe(MessageType.GUI_INGAME_OPEN, p4.onOpenIngameMenu, p4)
	g_messageCenter:subscribe(MessageType.SAVEGAME_LOADED, p4.onSavegameLoaded, p4)
	if g_currentMission:getIsServer() then
		addConsoleCommand("gsAutoSave", "Enables/disables auto save", "consoleCommandAutoSave", p4)
		addConsoleCommand("gsAutoSaveInterval", "Sets the auto save interval", "consoleCommandAutoSaveInterval", p4)
	end
end
function AutoSaveManager.unloadMapData(p5)
	g_messageCenter:unsubscribeAll(p5)
	if g_currentMission:getIsServer() then
		removeConsoleCommand("gsAutoSaveInterval")
		removeConsoleCommand("gsAutoSave")
	end
end
function AutoSaveManager.update(p6, _)
	if p6:getIsAutoSaveAllowed() and (g_currentMission:getIsServer() and (g_currentMission.gameStarted and p6.time < g_time)) then
		p6.isPending = true
		if g_dedicatedServer ~= nil then
			p6:runAutoSaveIfPending(true)
		end
	end
	if p6.saveNextFrame then
		p6:runAutoSaveIfPending()
		p6.saveNextFrame = false
	end
end
function AutoSaveManager.runAutoSaveIfPending(p7, p8)
	if p7.isPending then
		p7.isPending = false
		g_currentMission:startSaveCurrentGame(p8)
		p7.time = g_time + p7.interval
	end
end
function AutoSaveManager.onMissionStarted(p9, _)
	p9.time = g_time + p9.interval
	p9.isPending = false
end
function AutoSaveManager.onOpenIngameMenu(p10)
	p10.saveNextFrame = true
end
function AutoSaveManager.onSavegameLoaded(p11)
	if g_dedicatedServer == nil then
		local v12 = 0
		if g_currentMission ~= nil then
			if g_currentMission.missionInfo ~= nil and g_currentMission.missionInfo.autoSaveInterval ~= nil then
				v12 = g_currentMission.missionInfo.autoSaveInterval
			end
			g_messageCenter:subscribeOneshot(MessageType.CURRENT_MISSION_START, AutoSaveManager.onMissionStarted, p11)
		end
		if not GS_IS_MOBILE_VERSION then
			p11:setInterval(v12)
		end
	end
end
function AutoSaveManager.setInterval(p13, p14)
	if p14 > 0 then
		p13.interval = p14 * 60 * 1000
		p13.time = g_time + p13.interval
		p13:setIsActive(true)
	else
		p13:setIsActive(false)
	end
end
function AutoSaveManager.getInterval(p15)
	return not p15.isActive and 0 or p15.interval / 60 / 1000
end
function AutoSaveManager.getIntervalFromIndex(_, p16)
	local v17 = AutoSaveManager.INTERVAL_OPTIONS[p16]
	return v17 == nil and 0 or v17
end
function AutoSaveManager.getIndexFromInterval(_, p18)
	for v19, v20 in ipairs(AutoSaveManager.INTERVAL_OPTIONS) do
		if v20 == p18 then
			return v19
		end
	end
	return 1
end
function AutoSaveManager.getIntervalOptions(_)
	return AutoSaveManager.INTERVAL_OPTIONS
end
function AutoSaveManager.setIsActive(p21, p22)
	p21.isActive = p22
	if p22 then
		p21.time = g_time + p21.interval
	end
end
function AutoSaveManager.getIsActive(p23)
	return p23.isActive
end
function AutoSaveManager.resetTime(p24)
	p24.time = g_time + p24.interval
end
function AutoSaveManager.getIsAutoSaveAllowed(p25)
	if g_currentMission == nil or not g_currentMission:getIsAutoSaveSupported() then
		return false
	elseif g_appIsSuspended then
		return false
	elseif Profiler.IS_INITIALIZED then
		return false
	else
		return p25.isActive
	end
end
function AutoSaveManager.consoleCommandAutoSaveInterval(_, p26)
	if g_currentMission:getIsServer() then
		local v27 = tonumber(p26)
		if v27 == nil then
			return "AutoSaveInterval = " .. string.format("%1.3f", g_autoSaveManager:getInterval() / 60 / 1000) .. ". Arguments: interval[minutes]"
		end
		local v28 = math.max(v27, 1)
		g_autoSaveManager:setInterval(v28)
		return "AutoSaveInterval minutes = " .. v28
	end
	printError("This is a server-only command")
end
function AutoSaveManager.consoleCommandAutoSave(_, p29)
	if g_currentMission:getIsServer() then
		if p29 == nil or p29 == "" then
			local v30 = g_autoSaveManager
			return "AutoSave = " .. tostring(v30:getIsActive()) .. ". Arguments: enabled[true|false]"
		end
		local v31 = tostring(p29):lower()
		g_autoSaveManager:setIsActive(v31 == "true")
		local v32 = g_autoSaveManager
		return "AutoSave = " .. tostring(v32:getIsActive())
	end
	printError("This is a server-only command")
end

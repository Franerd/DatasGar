GroundTypeManager = {}
local v_u_1 = Class(GroundTypeManager, AbstractManager)
function GroundTypeManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function GroundTypeManager.initDataStructures(p3)
	p3.groundTypes = {}
	p3.groundTypeMappings = {}
	p3.terrainLayerMapping = {}
end
function GroundTypeManager.loadGroundTypes(p4)
	p4.groundTypes = {}
	local v5 = loadXMLFile("fuitTypes", "data/maps/groundTypes.xml")
	local v6 = 0
	while true do
		local v7 = string.format("groundTypes.groundType(%d)", v6)
		if not hasXMLProperty(v5, v7) then
			break
		end
		local v8 = getXMLString(v5, v7 .. "#name")
		if v8 == nil then
			Logging.xmlWarning(v5, "Missing groundType name for \'%s\'", v7)
		else
			local v9 = {}
			local v10 = getXMLString(v5, v7 .. "#fallbacks")
			if not string.isNilOrWhitespace(v10) then
				v9.fallbacks = string.split(v10, " ")
			end
			p4.groundTypes[v8] = v9
		end
		v6 = v6 + 1
	end
	delete(v5)
end
function GroundTypeManager.loadMapData(p11, p12, p13, p14)
	GroundTypeManager:superClass().loadMapData(p11)
	p11:loadGroundTypes()
	return XMLUtil.loadDataFromMapXML(p12, "groundTypeMappings", p14, p11, p11.loadGroundTypeMappings, p13)
end
function GroundTypeManager.loadGroundTypeMappings(p15, p16, _)
	local v17 = 0
	while true do
		local v18 = string.format("map.groundTypeMappings.groundTypeMapping(%d)", v17)
		if not hasXMLProperty(p16, v18) then
			break
		end
		local v19 = getXMLString(p16, v18 .. "#type")
		if v19 == nil then
			Logging.xmlWarning(p16, "Missing groudTypeMapping type for \'%s\'", v18)
		else
			local v20 = getXMLString(p16, v18 .. "#layer")
			if v20 == nil then
				Logging.xmlWarning(p16, "Missing groudTypeMapping layerName for \'%s\'", v18)
			else
				local v21 = getXMLString(p16, v18 .. "#title")
				if v21 == nil then
					Logging.xmlWarning(p16, "Missing groudTypeMapping title for \'%s\'", v18)
				else
					local v22 = {
						["typeName"] = v19,
						["layerName"] = v20,
						["title"] = v21
					}
					p15.groundTypeMappings[v22.typeName] = v22
				end
			end
		end
		v17 = v17 + 1
	end
	return true
end
function GroundTypeManager.initTerrain(p23, p24)
	p23.terrainLayerMapping = {}
	for v25 = 0, getTerrainNumOfLayers(p24) - 1 do
		local v26 = getTerrainLayerName(p24, v25)
		p23.terrainLayerMapping[v26] = v25
	end
end
function GroundTypeManager.getTerrainTitleByType(p27, p28)
	return p27.groundTypeMappings[p28].title
end
function GroundTypeManager.getTerrainLayerByType(p29, p30)
	local v31
	if p30 == nil or p29.groundTypeMappings[p30] == nil then
		v31 = nil
	else
		v31 = p29.groundTypeMappings[p30].layerName
	end
	if v31 ~= nil then
		local v32 = p29.terrainLayerMapping[v31]
		if v32 ~= nil then
			return v32
		end
	end
	local v33 = p29.groundTypes[p30]
	if v33 ~= nil and v33.fallbacks ~= nil then
		for _, v34 in pairs(v33.fallbacks) do
			if p29.groundTypeMappings[v34] == nil then
				Logging.warning("Unknown fallback layer \'%s\' for ground type \'%s\'", v34, p30)
			else
				local v35 = p29.groundTypeMappings[v34].layerName
				if v35 ~= nil then
					local v36 = p29.terrainLayerMapping[v35]
					if v36 ~= nil then
						return v36
					end
				end
			end
		end
	end
	return 0
end
g_groundTypeManager = GroundTypeManager.new()

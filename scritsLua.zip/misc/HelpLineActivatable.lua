HelpLineActivatable = {}
local v_u_1 = Class(HelpLineActivatable)
function HelpLineActivatable.new()
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3.activateText = g_i18n:getText("helpLine_open")
	return v3
end
function HelpLineActivatable.getIsActivatable(_)
	if g_gui.currentGui == nil then
		if g_helpLineManager.helpData == nil then
			return false
		else
			return g_currentMission:getCanShowHelpTriggers() and true or false
		end
	else
		return false
	end
end
function HelpLineActivatable.run(_)
	local v4 = g_helpLineManager.helpData
	if v4 ~= nil then
		g_gui:showGui("InGameMenu")
		g_messageCenter:publishDelayed(MessageType.GUI_INGAME_OPEN_HELP_SCREEN, v4.categoryIndex, v4.pageIndex)
	end
end
function HelpLineActivatable.getDistance(_, p5, p6, p7)
	local v8 = g_helpLineManager.helpData
	if v8 == nil or v8.triggerNode == nil then
		return (1 / 0)
	end
	local v9, v10, v11 = getWorldTranslation(v8.triggerNode)
	return MathUtil.vector3Length(p5 - v9, p6 - v10, p7 - v11)
end

AbstractManager = {}
local v_u_1 = Class(AbstractManager)
function AbstractManager.new(p2)
	-- upvalues: (copy) v_u_1
	if p2 ~= nil and type(p2) ~= "table" then
		printCallstack()
	end
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4:initDataStructures()
	v4.loadedMapData = false
	return v4
end
function AbstractManager.initDataStructures(_) end
function AbstractManager.load(_)
	return true
end
function AbstractManager.loadMapData(p5)
	if g_isDevelopmentVersion and p5.loadedMapData then
		Logging.error("Manager map-data already loaded or not deleted after last game load!")
		printCallstack()
	end
	p5.loadedMapData = true
	return true
end
function AbstractManager.unloadMapData(p6)
	p6.loadedMapData = false
	p6:initDataStructures()
end

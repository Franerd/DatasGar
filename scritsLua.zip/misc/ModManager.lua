ModManager = {}
local v_u_1 = Class(ModManager, AbstractManager)
function ModManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function ModManager.initDataStructures(p3)
	p3.hashToMod = {}
	p3.nameToMod = {}
	p3.validMods = {}
	p3.multiplayerMods = {}
	p3.mods = {}
	p3.numMods = 0
end
function ModManager.addMod(p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24)
	if p15 ~= nil and p4.hashToMod[p15] ~= nil then
		printError("Error: Adding mod with same file hash twice. Title is " .. p5 .. " filehash: " .. p15)
		return nil
	end
	p4.numMods = p4.numMods + 1
	local v25 = {
		["id"] = p4.numMods,
		["title"] = p5,
		["description"] = p6,
		["version"] = p7,
		["modDescVersion"] = p8,
		["author"] = p9,
		["iconFilename"] = p10,
		["isDLC"] = p18,
		["fileHash"] = p15,
		["modName"] = p11,
		["modDir"] = p12,
		["modFile"] = p13,
		["absBaseFilename"] = p16,
		["isDirectory"] = p17,
		["isMultiplayerSupported"] = p14,
		["isSelectable"] = p22,
		["hasScripts"] = p19,
		["isInternalScriptMod"] = p24,
		["dependencies"] = p20,
		["multiplayerOnly"] = p21,
		["uniqueType"] = p23
	}
	local v26 = p4.mods
	table.insert(v26, v25)
	p4.nameToMod[p11] = v25
	if p15 ~= nil then
		local v27 = p4.validMods
		table.insert(v27, v25)
		p4.hashToMod[p15] = v25
		if p14 then
			local v28 = p4.multiplayerMods
			table.insert(v28, v25)
		end
	end
	return v25
end
function ModManager.removeMod(p29, p30)
	if p30 == nil then
		return false
	end
	p29.nameToMod[p30.modName] = nil
	if p30.fileHash ~= nil then
		p29.hashToMod[p30.fileHash] = nil
	end
	for v31, v32 in ipairs(p29.mods) do
		if v32 == p30 then
			table.remove(p29.mods, v31)
			break
		end
	end
	for v33, v34 in ipairs(p29.validMods) do
		if v34 == p30 then
			table.remove(p29.validMods, v33)
			break
		end
	end
	for v35, v36 in ipairs(p29.multiplayerMods) do
		if v36 == p30 then
			table.remove(p29.multiplayerMods, v35)
			break
		end
	end
	return true
end
function ModManager.getModByFileHash(p37, p38)
	return p37.hashToMod[p38]
end
function ModManager.getModByName(p39, p40)
	return p39.nameToMod[p40]
end
function ModManager.getModIconByName(p41, p42)
	local v43 = p41.nameToMod[p42]
	if v43 == nil then
		return nil
	else
		return v43.iconFilename
	end
end
function ModManager.getModByIndex(p44, p45)
	return p44.mods[p45]
end
function ModManager.getMods(p46)
	return p46.mods
end
function ModManager.getMultiplayerMods(p47)
	return p47.multiplayerMods
end
function ModManager.getActiveMods(p48)
	local v49 = {}
	for _, v50 in ipairs(p48.mods) do
		if g_modIsLoaded[v50.modName] then
			table.insert(v49, v50)
		end
	end
	return v49
end
function ModManager.getNumOfMods(p51)
	return #p51.mods
end
function ModManager.getHasSelectableMod(p52)
	for _, v53 in ipairs(p52.mods) do
		if v53.isSelectable then
			return true
		end
	end
	return false
end
function ModManager.getNumOfValidMods(p54)
	return #p54.validMods
end
function ModManager.getHasSelectableValidMod(p55)
	for _, v56 in ipairs(p55.validMods) do
		if v56.isSelectable then
			return true
		end
	end
	return false
end
function ModManager.getAreAllModsAvailable(p57, p58)
	for _, v59 in pairs(p58) do
		if not p57:getIsModAvailable(v59) then
			return false
		end
	end
	return true
end
function ModManager.getIsModAvailable(p60, p61)
	local v62 = p60.hashToMod[p61]
	return v62 ~= nil and v62.isMultiplayerSupported and true or false
end
function ModManager.isModMap(_, p63)
	for v64, _ in pairs(g_mapManager.idToMap) do
		if g_mapManager:getModNameFromMapId(v64) == p63 then
			return true
		end
	end
	return false
end
g_modManager = ModManager.new()

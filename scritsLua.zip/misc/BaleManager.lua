BaleManager = {}
BaleManager.baleXMLSchema = nil
BaleManager.mapBalesXMLSchema = nil
local v_u_1 = Class(BaleManager, AbstractManager)
function BaleManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AbstractManager.new(p2 or v_u_1)
	BaleManager.baleXMLSchema = XMLSchema.new("bale")
	BaleManager.registerBaleXMLPaths(BaleManager.baleXMLSchema)
	BaleManager.mapBalesXMLSchema = XMLSchema.new("mapBales")
	BaleManager.registerMapBalesXMLPaths(BaleManager.mapBalesXMLSchema)
	return v3
end
function BaleManager.initDataStructures(p4)
	p4.bales = {}
	p4.modBalesToLoad = {}
	p4.fermentations = {}
end
function BaleManager.loadMapData(p5, p6, _, p7)
	BaleManager:superClass().loadMapData(p5)
	local v8 = getXMLString(p6, "map.bales#filename")
	if v8 == nil then
		Logging.xmlInfo(p6, "No bales xml defined in map")
		return false
	end
	local v9 = Utils.getFilename(v8, p7)
	local v10 = XMLFile.load("TempBales", v9, BaleManager.mapBalesXMLSchema)
	if v10 ~= nil then
		p5:loadBales(v10, p7)
		v10:delete()
	end
	for v11 = #p5.modBalesToLoad, 1, -1 do
		local v12 = p5.modBalesToLoad[v11]
		local v13 = XMLFile.load("TempBale", v12.xmlFilename, BaleManager.baleXMLSchema)
		if v13 ~= nil then
			if p5:loadBaleDataFromXML(v12, v13, v12.baseDirectory) then
				local v14 = p5.bales
				table.insert(v14, v12)
			end
			v13:delete()
		end
		table.remove(p5.modBalesToLoad, v11)
	end
	BaleManager.SEND_NUM_BITS = MathUtil.getNumRequiredBits(#p5.bales)
	for _, v15 in ipairs(p5.bales) do
		v15.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(v15.i3dFilename, false, true, p5.baleLoaded, p5, v15)
	end
	if g_addCheatCommands then
		addConsoleCommand("gsBaleAdd", "Adds a bale", "consoleCommandAddBale", p5, "[fillTypeName]; [isRoundbale]; [width]; [height]; [length]; [wrapState]; [modName]")
		addConsoleCommand("gsBaleAddAll", "Adds a bale", "consoleCommandAddBaleAll", p5, "[drawSizeBox]")
		addConsoleCommand("gsBaleList", "List available bale types", "consoleCommandListBales", p5)
	end
	return true
end
function BaleManager.baleLoaded(_, p16, _, p17)
	if p16 ~= 0 then
		p17.sharedRoot = p16
		local v18 = CollisionPreset.BALE
		local v19 = getChildAt(p16, 0)
		if getCollisionFilterGroup(v19) ~= v18.group then
			Logging.error("Bale \'%s\' has wrong collision group mask. Expected: %d, got: %d", p17.xmlFilename, v18.group, getCollisionFilterGroup(v19))
		end
		if getCollisionFilterMask(v19) ~= v18.mask then
			Logging.error("Bale \'%s\' has wrong collision mask. Expected: %d, got: %d", p17.xmlFilename, v18.mask, getCollisionFilterMask(v19))
		end
		removeFromPhysics(p16)
	end
end
function BaleManager.unloadMapData(p20)
	p20:unloadBaleData()
	if g_addCheatCommands then
		removeConsoleCommand("gsBaleAdd")
		removeConsoleCommand("gsBaleList")
	end
	BaleManager:superClass().unloadMapData(p20)
end
function BaleManager.unloadBaleData(p21)
	for _, v22 in ipairs(p21.bales) do
		if v22.sharedLoadRequestId ~= nil then
			g_i3DManager:releaseSharedI3DFile(v22.sharedLoadRequestId)
			v22.sharedLoadRequestId = nil
		end
		if v22.sharedRoot ~= nil then
			delete(v22.sharedRoot)
			v22.sharedRoot = nil
		end
	end
end
function BaleManager.loadBales(p_u_23, p_u_24, p_u_25)
	p_u_24:iterate("map.bales.bale", function(_, p26)
		-- upvalues: (copy) p_u_23, (copy) p_u_24, (copy) p_u_25
		p_u_23:loadBaleFromXML(p_u_24, p26, p_u_25)
	end)
	return true
end
function BaleManager.loadBaleFromXML(p27, p28, p29, p30)
	if type(p28) ~= "table" then
		p28 = XMLFile.wrap(p28)
	end
	local v31 = p28:getString(p29 .. "#filename")
	if v31 ~= nil then
		local v32 = {
			["xmlFilename"] = Utils.getFilename(v31, p30),
			["isAvailable"] = p28:getBool(p29 .. "#isAvailable", true)
		}
		local v33 = XMLFile.load("TempBale", v32.xmlFilename, BaleManager.baleXMLSchema)
		if v33 ~= nil then
			local v34 = p27:loadBaleDataFromXML(v32, v33, p30)
			v33:delete()
			if v34 then
				local v35 = p27.bales
				table.insert(v35, v32)
				return true
			end
		end
	end
	Logging.xmlError(p28, "Failed to load bale from xml \'%s\'", p29)
	return false
end
function BaleManager.loadModBaleFromXML(p36, p37, p38, p39, p40)
	if type(p37) ~= "table" then
		p37 = XMLFile.wrap(p37)
	end
	local v41 = p37:getString(p38 .. "#filename")
	if v41 == nil then
		Logging.xmlError(p37, "Failed to load bale from xml \'%s\'", p38)
		return false
	end
	local v42 = {
		["xmlFilename"] = Utils.getFilename(v41, p39),
		["baseDirectory"] = p39,
		["customEnvironment"] = p40,
		["isAvailable"] = p37:getBool(p38 .. "#isAvailable", true)
	}
	local v43 = p36.modBalesToLoad
	table.insert(v43, v42)
	return true
end
function BaleManager.loadBaleDataFromXML(_, p_u_44, p_u_45, p46)
	local v47 = p_u_45:getValue("bale.filename")
	if v47 == nil then
		Logging.xmlError(p_u_45, "No i3D file defined in bale xml.")
		return false
	end
	p_u_44.i3dFilename = Utils.getFilename(v47, p46)
	if not fileExists(p_u_44.i3dFilename) then
		Logging.xmlError(p_u_45, "Bale i3d file could not be found \'%s\'", p_u_44.i3dFilename)
		return false
	end
	p_u_44.isRoundbale = p_u_45:getValue("bale.size#isRoundbale", true)
	p_u_44.width = MathUtil.round(p_u_45:getValue("bale.size#width", 0), 2)
	p_u_44.height = MathUtil.round(p_u_45:getValue("bale.size#height", 0), 2)
	p_u_44.length = MathUtil.round(p_u_45:getValue("bale.size#length", 0), 2)
	p_u_44.diameter = MathUtil.round(p_u_45:getValue("bale.size#diameter", 0), 2)
	p_u_44.maxStackHeight = p_u_45:getValue("bale.size#maxStackHeight", p_u_44.isRoundbale and 2 or 3)
	p_u_44.visualWidth = p_u_45:getValue("bale.size#visualWidth", p_u_44.width)
	p_u_44.visualHeight = p_u_45:getValue("bale.size#visualHeight", p_u_44.height)
	p_u_44.visualLength = p_u_45:getValue("bale.size#visualLength", p_u_44.length)
	p_u_44.visualDiameter = p_u_45:getValue("bale.size#visualDiameter", p_u_44.diameter)
	if p_u_44.isRoundbale and (p_u_44.diameter == 0 or p_u_44.width == 0) then
		Logging.xmlError(p_u_45, "Missing size attributes for round bale. Requires width and diameter.")
		return false
	end
	if not p_u_44.isRoundbale and (p_u_44.width == 0 or (p_u_44.height == 0 or p_u_44.length == 0)) then
		Logging.xmlError(p_u_45, "Missing size attributes for square bale. Requires width, height and length.")
		return false
	end
	p_u_44.fillTypes = {}
	p_u_45:iterate("bale.fillTypes.fillType", function(_, p48)
		-- upvalues: (copy) p_u_45, (copy) p_u_44
		local v49 = p_u_45:getValue(p48 .. "#name")
		local v50 = g_fillTypeManager:getFillTypeIndexByName(v49)
		if v50 == nil then
			Logging.xmlWarning(p_u_45, "Unknown fill type \'%s\' for bale in \'%s\'", v49, p48)
		else
			local v51 = {
				["fillTypeIndex"] = v50,
				["capacity"] = p_u_45:getValue(p48 .. "#capacity", 0)
			}
			local v52 = p_u_44.fillTypes
			table.insert(v52, v51)
		end
	end)
	p_u_44.variations = {}
	p_u_45:iterate("bale.variations.variation", function(_, p53)
		-- upvalues: (copy) p_u_45, (copy) p_u_44
		local v54 = p_u_45:getValue(p53 .. "#id")
		if v54 ~= nil then
			local v55 = p_u_44.variations
			table.insert(v55, {
				["id"] = v54
			})
		end
	end)
	if #p_u_44.variations == 0 then
		local v56 = p_u_44.variations
		table.insert(v56, {
			["id"] = "DEFAULT"
		})
	end
	return true
end
function BaleManager.update(p57, p58)
	if g_server ~= nil then
		local v59 = #p57.fermentations
		if v59 > 0 then
			local v60 = g_currentMission:getEffectiveTimeScale()
			for v61 = v59, 1, -1 do
				local v62 = p57.fermentations[v61]
				v62.time = v62.time + p58 * v60
				if v62.time >= v62.maxTime then
					v62.bale:onFermentationUpdate(1)
					v62.bale:onFermentationEnd()
					table.remove(p57.fermentations, v61)
				else
					local v63 = v62.time / v62.maxTime
					local v64 = v63 * 100
					local v65 = math.floor(v64)
					local v66 = v62.percentageSend * 100
					if v65 ~= math.floor(v66) then
						v62.bale:onFermentationUpdate(v63)
						v62.percentageSend = v63
					end
				end
			end
		end
	end
end
function BaleManager.registerFermentation(p67, p68, p69, p70)
	local v71 = {
		["bale"] = p68,
		["time"] = p69,
		["percentageSend"] = 0,
		["maxTime"] = (not Platform.gameplay.hasBaleFermentation and 0 or p70) * g_currentMission.missionInfo.economicDifficulty
	}
	local v72 = p67.fermentations
	table.insert(v72, v71)
end
function BaleManager.getFermentationTime(p73, p74)
	for v75 = 1, #p73.fermentations do
		if p73.fermentations[v75].bale == p74 then
			return p73.fermentations[v75].time
		end
	end
	return 0
end
function BaleManager.removeFermentation(p76, p77)
	for v78 = #p76.fermentations, 1, -1 do
		if p76.fermentations[v78].bale == p77 then
			table.remove(p76.fermentations, v78)
		end
	end
end
function BaleManager.getBaleDescByIndex(p79, p80)
	return p79.bales[p80]
end
function BaleManager.getBaleIndex(p81, p82, p83, p84, p85, p86, p87, p88)
	if p88 ~= nil then
		for v89 = 1, #p81.bales do
			local v90 = p81.bales[v89]
			if v90.isAvailable and (p88 == v90.customEnvironment and p81:getIsBaleMatching(v90, p82, p83, p84, p85, p86, p87)) then
				return v89
			end
		end
	end
	for v91 = 1, #p81.bales do
		local v92 = p81.bales[v91]
		if v92.isAvailable and (v92.customEnvironment == nil and p81:getIsBaleMatching(v92, p82, p83, p84, p85, p86, p87)) then
			return v91
		end
	end
	return nil
end
function BaleManager.getBaleInfoByXMLFilename(p93, p94, p95)
	for v96 = 1, #p93.bales do
		local v97 = p93.bales[v96]
		if v97.xmlFilename == p94 then
			if p95 == true then
				return v97.isRoundbale, v97.visualWidth, v97.visualHeight, v97.visualLength, v97.visualDiameter, v97.maxStackHeight
			else
				return v97.isRoundbale, v97.width, v97.height, v97.length, v97.diameter, v97.maxStackHeight
			end
		end
	end
	return false, 0, 0, 0, 0, 1
end
function BaleManager.getIsBaleMatching(_, p98, p99, p100, p101, p102, p103, p104)
	if p98.isRoundbale == p100 then
		local v105 = false
		for v106 = 1, #p98.fillTypes do
			if p98.fillTypes[v106].fillTypeIndex == p99 then
				v105 = true
				break
			end
		end
		if v105 then
			local v107
			if p100 then
				if p101 == nil or MathUtil.round(p101, 2) == p98.width then
					v107 = p104 == nil and true or MathUtil.round(p104, 2) == p98.diameter
				else
					v107 = false
				end
			elseif (p101 == nil or MathUtil.round(p101, 2) == p98.width) and (p102 == nil or MathUtil.round(p102, 2) == p98.height) then
				v107 = p103 == nil and true or MathUtil.round(p103, 2) == p98.length
			else
				v107 = false
			end
			if v107 then
				return true
			end
		end
	end
	return false
end
function BaleManager.getBaleXMLFilename(p108, p109, p110, p111, p112, p113, p114, p115)
	local v116 = p108:getBaleIndex(p109, p110, p111, p112, p113, p114, p115)
	if v116 == nil then
		return nil
	else
		return p108.bales[v116].xmlFilename, v116
	end
end
function BaleManager.getBaleTypeIndexByXMLFilename(p117, p118)
	for v119 = 1, #p117.bales do
		if p117.bales[v119].xmlFilename == p118 then
			return v119
		end
	end
	return nil
end
function BaleManager.getBaleXMLFilenameByIndex(p120, p121)
	if p121 == nil or p120.bales[p121] == nil then
		return nil
	else
		return p120.bales[p121].xmlFilename
	end
end
function BaleManager.getIsRoundBale(p122, p123)
	if p123 == nil or p122.bales[p123] == nil then
		return nil
	else
		return p122.bales[p123].isRoundbale
	end
end
function BaleManager.getBaleCapacityByBaleIndex(p124, p125, p126)
	if p125 ~= nil then
		local v127 = p124.bales[p125]
		if v127 ~= nil then
			for v128 = 1, #v127.fillTypes do
				if v127.fillTypes[v128].fillTypeIndex == p126 then
					return v127.fillTypes[v128].capacity
				end
			end
		end
	end
	return 0
end
function BaleManager.getPossibleCapacitiesForFillType(p129, p130)
	local v131 = {}
	for _, v132 in ipairs(p129.bales) do
		for _, v133 in ipairs(v132.fillTypes) do
			if v133.fillTypeIndex == p130 then
				local v134 = v133.capacity
				table.insert(v131, v134)
			end
		end
	end
	return v131
end
function BaleManager.consoleCommandAddBale(p135, p136, p137, p138, p139, p140, p141, p142)
	if g_currentMission:getIsServer() then
		local v143 = Utils.getNoNil(p136, "STRAW")
		local v144 = Utils.stringToBoolean(p137)
		local v145
		if p138 == nil then
			v145 = nil
		else
			v145 = tonumber(p138) or nil
		end
		local v146
		if p139 == nil then
			v146 = nil
		else
			v146 = tonumber(p139) or nil
		end
		local v147
		if p140 == nil then
			v147 = nil
		else
			v147 = tonumber(p140) or nil
		end
		if p141 == nil or tonumber(p141) ~= nil then
			local v148 = tonumber(p141 or 0)
			local v149 = g_fillTypeManager:getFillTypeIndexByName(v143)
			if v149 == nil then
				Logging.error("Invalid fillTypeName \'%s\' (e.g. STRAW).\nUsage: %s", v143, "gsBaleAdd fillTypeName isRoundBale [width] [height/diameter] [length] [wrapState] [modName]")
			else
				local v150, _ = p135:getBaleXMLFilename(v149, v144, v145, v146, v147, v146, p142)
				if v150 ~= nil then
					local v151, v152, v153 = g_localPlayer:getPosition()
					local v154, v155 = g_localPlayer:getCurrentFacingDirection()
					local v156 = v151 + v154 * 4
					local v157 = v153 + v155 * 4
					local v158 = v152 + 5
					local v159 = MathUtil.getYRotationFromDirection(v154, v155)
					local v160 = g_currentMission:getFarmId()
					local v161 = (v160 == FarmManager.SPECTATOR_FARM_ID or not v160) and 1 or v160
					local v162 = Bale.new(g_currentMission:getIsServer(), g_currentMission:getIsClient())
					if v162:loadFromConfigXML(v150, v156, v158, v157, 0, v159, 0) then
						v162:setFillType(v149, true)
						v162:setWrappingState(v148)
						v162:setOwnerFarmId(v161, true)
						v162:register()
					end
					return string.format("Created bale at (%.2f, %.2f, %.2f). For specific bales use: %s", v156, v158, v157, "gsBaleAdd fillTypeName isRoundBale [width] [height/diameter] [length] [wrapState] [modName]")
				end
				Logging.error("Could not find bale for given size attributes!\nUsage: %s", "gsBaleAdd fillTypeName isRoundBale [width] [height/diameter] [length] [wrapState] [modName]")
				p135:consoleCommandListBales()
			end
		else
			Logging.error("Invalid wrapState \'%s\', number expected.\nUsage: %s", p141, "gsBaleAdd fillTypeName isRoundBale [width] [height/diameter] [length] [wrapState] [modName]")
			return
		end
	else
		Logging.error("Command only allowed on server!")
		return
	end
end
function BaleManager.consoleCommandAddBaleAll(p_u_163, p164)
	local v_u_165 = string.lower(p164 or "") == "true"
	local v_u_166, v_u_167, v_u_168, v_u_169
	if p_u_163.debugLoadPosition == nil then
		local v170, v171, v172 = g_localPlayer:getPosition()
		v_u_166 = v170
		v_u_167 = v172
		local v173, v174 = g_localPlayer:getCurrentFacingDirection()
		v_u_168 = v173
		v_u_169 = v174
		p_u_163.debugLoadPosition = {
			v_u_166,
			v171,
			v_u_167,
			v_u_168,
			v_u_169
		}
	else
		v_u_166 = p_u_163.debugLoadPosition[1]
		local _ = p_u_163.debugLoadPosition[2]
		v_u_167 = p_u_163.debugLoadPosition[3]
		v_u_168 = p_u_163.debugLoadPosition[4]
		v_u_169 = p_u_163.debugLoadPosition[5]
	end
	if p_u_163.debugBales ~= nil then
		for _, v175 in ipairs(p_u_163.debugBales) do
			v175:delete()
		end
	end
	if p_u_163.debugElements ~= nil then
		for _, v176 in ipairs(p_u_163.debugElements) do
			g_debugManager:removeElement(v176)
		end
	end
	p_u_163.debugBales = {}
	p_u_163.debugElements = {}
	p_u_163:unloadBaleData()
	g_i3DManager:clearEntireSharedI3DFileCache()
	p_u_163.bales = {}
	local v177 = Utils.getFilename("data/maps/maps_bales.xml")
	local v178 = XMLFile.load("TempBales", v177, BaleManager.mapBalesXMLSchema)
	if v178 ~= nil then
		p_u_163:loadBales(v178)
		v178:delete()
	end
	local function v_u_206()
		-- upvalues: (ref) v_u_166, (ref) v_u_167, (ref) v_u_168, (ref) v_u_169, (copy) p_u_163, (ref) v_u_165
		local v179 = Color.new(0.2, 0.2, 0.2, 1)
		local v180 = v_u_166 + v_u_168 * 4
		local v181 = v_u_167 + v_u_169 * 4
		v_u_166 = v180
		v_u_167 = v181
		local v182 = MathUtil.getYRotationFromDirection(v_u_168, v_u_169)
		local v183 = 0
		for _, v184 in ipairs(p_u_163.bales) do
			for _, v185 in ipairs(v184.fillTypes) do
				local v186 = (v184.isRoundbale and v184.width or v184.length) * 0.5
				for v187, v188 in ipairs(v184.variations) do
					local v189 = v_u_166 + v_u_168 * v186 - v_u_169 * v183
					local v190 = v_u_167 + v_u_169 * v186 + v_u_168 * v183
					local v191 = v184.isRoundbale and v184.diameter or v184.height
					local v192 = getTerrainHeightAtWorldPos(g_terrainNode, v189, 0, v190) + v191 * 0.5
					local v193 = Bale.new(g_currentMission:getIsServer(), g_currentMission:getIsClient())
					if v193:loadFromConfigXML(v184.xmlFilename, v189, v192, v190, 0, v182, 0) then
						v193:setFillType(v185.fillTypeIndex, true)
						v193:setVariationIndex(v187)
						v193:setOwnerFarmId(g_currentMission:getFarmId(), true)
						v193:register()
						v193:removeFromPhysics()
						local v194 = string.format("%s (%s - %s)", Utils.getFilenameFromPath(v184.xmlFilename), g_fillTypeManager:getFillTypeNameByIndex(v185.fillTypeIndex), v188.id)
						local v195, v196, v197 = localRotationToWorld(v193.nodeId, 0, 3.141592653589793, 0)
						local v198 = DebugText3D.new():createWithWorldPos(v189, v192 + v191 * 0.5 + 0.25, v190, v195, v196, v197, v194, 0.07)
						g_debugManager:addElement(v198, nil, nil, (1 / 0))
						local v199 = p_u_163.debugElements
						table.insert(v199, v198)
						if v_u_165 then
							local v200, v201, v202
							if v184.isRoundbale then
								v200 = v184.diameter
								v201 = v184.diameter
								v202 = v184.width
							else
								v200 = v184.width
								v201 = v184.height
								v202 = v184.length
							end
							local v203 = DebugBox.new():createWithWorldPosAndRot(v189, v192, v190, v195, v196, v197, v200, v201, v202)
							v203.color = v179
							g_debugManager:addElement(v203, nil, nil, (1 / 0))
							local v204 = p_u_163.debugElements
							table.insert(v204, v203)
						end
						local v205 = p_u_163.debugBales
						table.insert(v205, v193)
					end
					v186 = v186 + (v184.isRoundbale and v184.width or v184.length) + 1
				end
				v183 = v183 + 2.5
			end
			v183 = v183 + 5
		end
	end
	local v_u_207 = #p_u_163.bales
	local function v212(p208, p209, p210, p211)
		-- upvalues: (ref) v_u_207, (copy) v_u_206
		p208.baleLoaded(p209, p210, p211)
		v_u_207 = v_u_207 - 1
		if v_u_207 == 0 then
			v_u_206()
		end
	end
	for _, v213 in ipairs(p_u_163.bales) do
		v213.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(v213.i3dFilename, false, true, v212, p_u_163, v213)
	end
end
function BaleManager.consoleCommandListBales(p214)
	print("Available bale types:")
	for _, v215 in ipairs(p214.bales) do
		local v216 = { v215.xmlFilename }
		local v217 = string.format
		local v218 = v215.isRoundbale
		table.insert(v216, v217("isRoundbale=%s", v218))
		for _, v219 in ipairs({
			"width",
			"height",
			"length",
			"diameter"
		}) do
			if v215[v219] ~= nil and v215[v219] ~= 0 then
				local v220 = string.format
				local v221 = v215[v219]
				table.insert(v216, v220("%s=%s", v219, v221))
			end
		end
		log(table.concat(v216, "  "))
		local v222 = {}
		for _, v223 in ipairs(v215.fillTypes) do
			local v224 = g_fillTypeManager
			local v225 = v223.fillTypeIndex
			table.insert(v222, v224:getFillTypeNameByIndex(v225))
		end
		log("    fillTypes: ", table.concat(v222, "  "))
	end
end
function BaleManager.registerBaleXMLPaths(p226)
	p226:register(XMLValueType.STRING, "bale.filename", "Path to i3d file")
	p226:register(XMLValueType.BOOL, "bale.size#isRoundbale", "Bale is a roundbale", true)
	p226:register(XMLValueType.FLOAT, "bale.size#width", "Bale Width", 0)
	p226:register(XMLValueType.FLOAT, "bale.size#height", "Bale Height", 0)
	p226:register(XMLValueType.FLOAT, "bale.size#length", "Bale Length", 0)
	p226:register(XMLValueType.FLOAT, "bale.size#diameter", "Bale Diameter", 0)
	p226:register(XMLValueType.INT, "bale.size#maxStackHeight", "Max. stack height for automatic spawning of bales", "2 or round bales and 3 for square bales")
	p226:register(XMLValueType.FLOAT, "bale.size#visualWidth", "Bale Width (Real size of the visuals if different)", "Same as #width")
	p226:register(XMLValueType.FLOAT, "bale.size#visualHeight", "Bale Height (Real size of the visuals if different)", "Same as #height")
	p226:register(XMLValueType.FLOAT, "bale.size#visualLength", "Bale Length (Real size of the visuals if different)", "Same as #length")
	p226:register(XMLValueType.FLOAT, "bale.size#visualDiameter", "Bale Diameter (Real size of the visuals if different)", "Same as #diameter")
	p226:register(XMLValueType.NODE_INDEX, "bale.mountableObject#triggerNode", "Trigger node")
	p226:register(XMLValueType.FLOAT, "bale.mountableObject#forceAcceleration", "Acceleration force", 4)
	p226:register(XMLValueType.FLOAT, "bale.mountableObject#forceLimitScale", "Force limit scale", 1)
	p226:register(XMLValueType.BOOL, "bale.mountableObject#axisFreeY", "Joint is free in Y direction", false)
	p226:register(XMLValueType.BOOL, "bale.mountableObject#axisFreeX", "Joint is free in X direction", false)
	p226:register(XMLValueType.STRING, "bale.uvId", "Specify that this bale model has a custom UV. This will result in baleWrapper to replace the bale if the UV is different to the defined one in the baleWrapper. So the baleWrapper will always use a bale with a UV that matches the wrapping texture.", "DEFAULT")
	p226:register(XMLValueType.NODE_INDEX, "bale.baleMeshes.baleMesh(?)#node", "Path to mesh node")
	p226:register(XMLValueType.BOOL, "bale.baleMeshes.baleMesh(?)#supportsWrapping", "Defines if the mesh is hidden while wrapping or not")
	p226:register(XMLValueType.STRING, "bale.baleMeshes.baleMesh(?)#fillTypes", "If defined this mesh is only visible if any of this fillTypes is set")
	p226:register(XMLValueType.BOOL, "bale.baleMeshes.baleMesh(?)#isTensionBeltMesh", "Defines if this mesh is detected for tension belt calculation", false)
	p226:register(XMLValueType.BOOL, "bale.baleMeshes.baleMesh(?)#isAlphaMesh", "Defines if the mesh is a alpha mesh (different material will be applied)", false)
	p226:register(XMLValueType.STRING, "bale.fillTypes.fillType(?)#name", "Name of fill type")
	p226:register(XMLValueType.FLOAT, "bale.fillTypes.fillType(?)#capacity", "Fill level of bale with this fill type")
	p226:register(XMLValueType.FLOAT, "bale.fillTypes.fillType(?)#mass", "Mass of bale with this fill type", 500)
	p226:register(XMLValueType.FLOAT, "bale.fillTypes.fillType(?)#forceAcceleration", "Force acceleration value of bale with this fill type", "bale.mountableObject#forceAcceleration")
	p226:register(XMLValueType.BOOL, "bale.fillTypes.fillType(?)#supportsWrapping", "Wrapping is allowed while this type is used")
	p226:register(XMLValueType.STRING, "bale.fillTypes.fillType(?)#materialName", "Bale material to use")
	p226:register(XMLValueType.STRING, "bale.fillTypes.fillType(?)#alphaMaterialName", "Bale material to use on alpha mesh parts")
	BaleManager.registerBaleTextureXMLPaths(p226, "bale.fillTypes.fillType(?)")
	p226:register(XMLValueType.STRING, "bale.variations.variation(?)#id", "Variation identifier")
	BaleManager.registerBaleTextureXMLPaths(p226, "bale.variations.variation(?)")
	p226:register(XMLValueType.STRING, "bale.fillTypes.fillType(?).fermenting#outputFillType", "Output fill type after fermenting")
	p226:register(XMLValueType.BOOL, "bale.fillTypes.fillType(?).fermenting#requiresWrapping", "Wrapping is required to start fermenting", true)
	p226:register(XMLValueType.FLOAT, "bale.fillTypes.fillType(?).fermenting#time", "Fermenting time in ingame days which represent months", 1)
	p226:register(XMLValueType.STRING, "bale.packedBale#singleBale", "Path to single bale xml filename")
	p226:register(XMLValueType.NODE_INDEX, "bale.packedBale.singleBale(?)#node", "Single bale spawn node")
end
function BaleManager.registerBaleTextureXMLPaths(p227, p228)
	p227:register(XMLValueType.FILENAME, p228 .. ".diffuse#filename", "Diffuse texture to apply to all mesh nodes")
	p227:register(XMLValueType.BOOL, p228 .. ".diffuse#useFillTypeArray", "Use the fill type array texture for diffuse", false)
	p227:register(XMLValueType.FILENAME, p228 .. ".normal#filename", "Normal texture to apply to all mesh nodes")
	p227:register(XMLValueType.BOOL, p228 .. ".normal#useFillTypeArray", "Use the fill type array texture for normal", false)
	p227:register(XMLValueType.FILENAME, p228 .. ".alpha#filename", "Alpha texture to apply to all mesh nodes")
	p227:register(XMLValueType.FILENAME, p228 .. ".baleNormal#filename", "Bale normal texture to apply to all mesh nodes")
	p227:register(XMLValueType.FILENAME, p228 .. ".netWrapDiffuse#filename", "Net wrap diffuse texture to apply to all mesh nodes")
	p227:register(XMLValueType.FILENAME, p228 .. ".netWrapNormal#filename", "Net Wrap normal texture to apply to all mesh nodes")
end
function BaleManager.registerMapBalesXMLPaths(p229)
	p229:register(XMLValueType.STRING, "map.bales.bale(?)#filename", "Path to bale xml")
	p229:register(XMLValueType.STRING, "map.bales.bale(?)#isAvailable", "Bale is available for all balers to spawn")
end
g_baleManager = BaleManager.new()

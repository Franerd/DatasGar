SplitShapeManager = {}
local v_u_1 = Class(SplitShapeManager, AbstractManager)
function SplitShapeManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function SplitShapeManager.initDataStructures(p3)
	p3.typesByIndex = {}
	p3.typesByName = {}
	p3.activeYarders = {}
end
function SplitShapeManager.loadMapData(p4)
	SplitShapeManager:superClass().loadMapData(p4)
	p4:addSplitType("SPRUCE", "treeType_spruce", 1, 0.7, 3, true, nil, 1000)
	p4:addSplitType("PINE", "treeType_pine", 2, 0.7, 3, true, nil, 1000)
	p4:addSplitType("LARCH", "treeType_larch", 3, 0.7, 3, true, nil, 1000)
	p4:addSplitType("BIRCH", "treeType_birch", 4, 0.85, 3.2, true, nil, 1000)
	p4:addSplitType("BEECH", "treeType_beech", 5, 0.9, 3.4, true, nil, 1000)
	p4:addSplitType("MAPLE", "treeType_maple", 6, 0.9, 3.4, true, nil, 1000)
	p4:addSplitType("OAK", "treeType_oak", 7, 0.9, 3.4, true, nil, 1000)
	p4:addSplitType("ASH", "treeType_ash", 8, 0.9, 3.4, true, nil, 1000)
	p4:addSplitType("LOCUST", "treeType_locust", 9, 1, 3.8, true, nil, 1000)
	p4:addSplitType("MAHOGANY", "treeType_mahogany", 10, 1.1, 3, true, nil, 1000)
	p4:addSplitType("POPLAR", "treeType_poplar", 11, 0.7, 7.5, true, nil, 1000)
	p4:addSplitType("AMERICANELM", "treeType_americanElm", 12, 0.7, 3.5, true, nil, 1000)
	p4:addSplitType("CYPRESS", "treeType_cypress", 13, 0.7, 3.5, true, nil, 1000)
	p4:addSplitType("DOWNYSERVICEBERRY", "treeType_downyServiceberry", 14, 0.7, 3.5, false, nil, 1000)
	p4:addSplitType("PAGODADOGWOOD", "treeType_pagodaDogwood", 15, 0.7, 3.5, true, nil, 1000)
	p4:addSplitType("SHAGBARKHICKORY", "treeType_shagbarkHickory", 16, 0.7, 3.5, true, nil, 1000)
	p4:addSplitType("STONEPINE", "treeType_stonePine", 17, 0.7, 3.5, true, nil, 1000)
	p4:addSplitType("WILLOW", "treeType_willow", 18, 0.7, 3.5, true, nil, 1000)
	p4:addSplitType("OLIVETREE", "treeType_oliveTree", 19, 0.6, 3.5, true, nil, 1000)
	p4:addSplitType("GIANTSEQUOIA", "treeType_giantSequoia", 20, 0.3, 0.3, true, nil, 1000)
	p4:addSplitType("LODGEPOLEPINE", "treeType_lodgepolePine", 21, 1, 3.7, true, nil, 1000)
	p4:addSplitType("PONDEROSAPINE", "treeType_ponderosaPine", 22, 1, 3.7, true, nil, 1000)
	p4:addSplitType("DEADWOOD", "treeType_deadwood", 23, 0.1, 0.5, true, nil, 1000)
	p4:addSplitType("TRANSPORT", "treeType_transport", 24, 0.1, 0.3, true, nil, 10)
	p4:addSplitType("ASPEN", "treeType_aspen", 25, 1.2, 3.3, true, nil, 1000)
	p4:addSplitType("APPLE", "treeType_apple", 26, 0.8, 1.2, false, nil, 1000)
	p4:addSplitType("BETULAERMANII", "treeType_betulaErmanii", 27, 0.6, 3.5, true, nil, 1000)
	p4:addSplitType("BOXELDER", "treeType_boxelder", 28, 0.9, 3.4, true, nil, 1000)
	p4:addSplitType("CHERRY", "treeType_cherry", 29, 1, 3.8, false, nil, 1000)
	p4:addSplitType("CHINESEELM", "treeType_chineseElm", 30, 0.7, 3.5, false, nil, 1000)
	p4:addSplitType("GOLDENRAIN", "treeType_goldenRain", 31, 0.6, 3.5, true, nil, 1000)
	p4:addSplitType("JAPANESEZELKOVA", "treeType_japaneseZelkova", 32, 0.7, 3.5, true, nil, 1000)
	p4:addSplitType("NORTHERNCATALPA", "treeType_northernCatalpa", 33, 0.7, 3, false, nil, 1000)
	p4:addSplitType("TILIAAMURENSIS", "treeType_tiliaAmurensis", 34, 0.9, 3.4, false, nil, 1000)
	p4:addSplitType("RAVAGED", "treeType_ravaged", 35, 0.1, 0.3, true, nil, 10)
	p4:addSplitType("PINUSTABULIFORMIS", "treeType_pinusTabuliformis", 36, 0.9, 3.5, true, nil, 1000)
	p4:addSplitType("PINUSSYLVESTRIS", "treeType_pinusSylvestris", 37, 0.8, 3.3, true, nil, 1000)
	return true
end
function SplitShapeManager.addSplitType(p5, p6, p7, p8, p9, p10, p11, p12, p13)
	if p5.typesByIndex[p8] == nil then
		local v14 = p6:upper()
		if p5.typesByName[v14] == nil then
			local v15 = {
				["name"] = v14,
				["title"] = g_i18n:getText(p7, p12),
				["splitTypeIndex"] = p8,
				["pricePerLiter"] = p9,
				["woodChipsPerLiter"] = p10,
				["allowsWoodHarvester"] = p11,
				["volumeToLiter"] = p13 or 1000
			}
			p5.typesByIndex[p8] = v15
			p5.typesByName[v14] = v15
		else
			Logging.error("SplitShapeManager:addSplitType(): SplitType name \'%s\' is already in use", v14)
		end
	else
		Logging.error("SplitShapeManager:addSplitType(): SplitTypeIndex \'%d\' is already in use for \'%s\'", p8, p6)
		return
	end
end
function SplitShapeManager.getSplitTypeByIndex(p16, p17)
	return p16.typesByIndex[p17]
end
function SplitShapeManager.getSplitTypeNameByIndex(p18, p19)
	local v20 = p18.typesByIndex[p19]
	return v20 == nil and "<NO_SPLIT_TYPE>" or v20.name
end
function SplitShapeManager.getSplitTypeIndexByName(p21, p22)
	if p22 == nil then
		return nil
	else
		local v23 = string.upper(p22)
		local v24 = p21.typesByName[v23]
		if v24 == nil then
			return nil
		else
			return v24.splitTypeIndex
		end
	end
end
function SplitShapeManager.getIsShapeCutAllowed(p25, p26, p27, p28, p29, p30)
	local v31 = g_missionManager:getIsShapeCutAllowed(p28, p26, p27, p29)
	if v31 ~= nil then
		return v31
	end
	if Platform.gameplay.treeCutFarmlandRestrictions and not g_currentMission.accessHandler:canFarmAccessLand(p29, p26, p27) then
		return false
	end
	for v32, _ in pairs(p25.activeYarders) do
		local v33 = NetworkUtil.getObject(v32)
		if v33 == nil then
			p25.activeYarders[v32] = nil
		elseif v33:getIsTreeShapeUsedForYarderSetup(p28) then
			return false
		end
	end
	return g_currentMission:getHasPlayerPermission("cutTrees", p30)
end
function SplitShapeManager.addActiveYarder(p34, p35)
	local v36 = NetworkUtil.getObjectId(p35)
	p34.activeYarders[v36] = true
end
function SplitShapeManager.removeActiveYarder(p37, p38)
	local v39 = NetworkUtil.getObjectId(p38)
	p37.activeYarders[v39] = nil
end
function SplitShapeManager.getSplitShapeAllowsHarvester(_, p40)
	local v41 = getSplitType(p40)
	local v42 = g_splitShapeManager:getSplitTypeByIndex(v41)
	if v42 ~= nil and v42.allowsWoodHarvester then
		local _, v43, v44, _, _ = getSplitShapeStats(p40)
		local v45 = v43 * v44
		if v45 > 0.01 and v45 < 3 then
			return true
		end
	end
	return false
end
g_splitShapeManager = SplitShapeManager.new()
g_splitTypeManager = {}
local v46 = g_splitTypeManager
setmetatable(v46, {
	["__index"] = function(_, p47)
		Logging.error("\'g_splitTypeManager\' no longer exists, use \'g_splitShapeManager\' instead!")
		printCallstack()
		return g_splitShapeManager[p47]
	end
})

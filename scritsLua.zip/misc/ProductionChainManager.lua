ProductionChainManager = {}
ProductionChainManager.NUM_MAX_PRODUCTION_POINTS = 60
local v_u_1 = Class(ProductionChainManager, AbstractManager)
function ProductionChainManager.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = AbstractManager.new(p3 or v_u_1)
	v4.isServer = p2
	addConsoleCommand("gsProductionPointsList", "List all production points on map", "commandListProductionPoints", v4)
	addConsoleCommand("gsProductionPointsPrintAutoDeliverMapping", "Prints which fillTypes are required by which production points", "commandPrintAutoDeliverMapping", v4)
	addConsoleCommand("gsProductionPointSetOwner", "", "commandSetOwner", v4)
	addConsoleCommand("gsProductionPointSetProductionState", "", "commandSetProductionState", v4)
	addConsoleCommand("gsProductionPointSetOutputMode", "", "commandSetOutputMode", v4)
	addConsoleCommand("gsProductionPointSetFillLevel", "", "commandSetFillLevel", v4)
	if v4.isServer then
		g_messageCenter:subscribe(MessageType.HOUR_CHANGED, v4.hourChanged, v4)
	end
	return v4
end
function ProductionChainManager.initDataStructures(p5)
	p5.productionPoints = {}
	p5.reverseProductionPoint = {}
	p5.factories = {}
	p5.reverseFactory = {}
	p5.farmIds = {}
	p5.currentUpdateIndex = 1
	p5.hourChangedDirty = false
	p5.hourChangeUpdating = false
end
function ProductionChainManager.unloadMapData(p6)
	removeConsoleCommand("gsProductionPointsList")
	removeConsoleCommand("gsProductionPointsPrintAutoDeliverMapping")
	removeConsoleCommand("gsProductionPointSetOwner")
	removeConsoleCommand("gsProductionPointSetProductionState")
	removeConsoleCommand("gsProductionPointSetOutputMode")
	removeConsoleCommand("gsProductionPointSetFillLevel")
	if p6.isServer then
		g_messageCenter:unsubscribe(MessageType.HOUR_CHANGED, p6)
	end
	ProductionChainManager:superClass().unloadMapData(p6)
end
function ProductionChainManager.addProductionPoint(p7, p8)
	if p7.reverseProductionPoint[p8] then
		Logging.warning("Production point \'%s\' already registered.", p8:tableId())
		return false
	end
	if #p7.productionPoints >= ProductionChainManager.NUM_MAX_PRODUCTION_POINTS then
		printf("Maximum number of %i Production Points reached.", ProductionChainManager.NUM_MAX_PRODUCTION_POINTS)
		return false
	end
	if #p7.productionPoints == 0 and p7.isServer then
		g_currentMission:addUpdateable(p7)
	end
	p7.reverseProductionPoint[p8] = true
	local v9 = p7.productionPoints
	table.insert(v9, p8)
	local v10 = p8:getOwnerFarmId()
	if v10 ~= AccessHandler.EVERYONE then
		if not p7.farmIds[v10] then
			p7.farmIds[v10] = {}
		end
		p7:addProductionPointToFarm(p8, p7.farmIds[v10])
	end
	return true
end
function ProductionChainManager.addProductionPointToFarm(_, p11, p12)
	if not p12.productionPoints then
		p12.productionPoints = {}
	end
	local v13 = p12.productionPoints
	table.insert(v13, p11)
	if not p12.inputTypeToProductionPoints then
		p12.inputTypeToProductionPoints = {}
	end
	for v14 in pairs(p11.inputFillTypeIds) do
		if not p12.inputTypeToProductionPoints[v14] then
			p12.inputTypeToProductionPoints[v14] = {}
		end
		local v15 = p12.inputTypeToProductionPoints[v14]
		table.insert(v15, p11)
	end
end
function ProductionChainManager.addFactory(p16, p17)
	if p16.reverseFactory[p17] then
		Logging.warning("Factory \'%s\' already registered.", p17:tableId())
		return false
	end
	p16.reverseFactory[p17] = true
	local v18 = p16.factories
	table.insert(v18, p17)
	local v19 = p17:getOwnerFarmId()
	if v19 ~= AccessHandler.EVERYONE then
		if not p16.farmIds[v19] then
			p16.farmIds[v19] = {}
		end
		p16:addFactoryToFarm(p17, p16.farmIds[v19])
	end
	return true
end
function ProductionChainManager.addFactoryToFarm(_, p20, p21)
	if not p21.factories then
		p21.factories = {}
	end
	local v22 = p21.factories
	table.insert(v22, p20)
end
function ProductionChainManager.removeProductionPoint(p23, p24)
	p23.reverseProductionPoint[p24] = nil
	if table.removeElement(p23.productionPoints, p24) then
		local v25 = p24:getOwnerFarmId()
		if v25 ~= AccessHandler.EVERYONE then
			p23.farmIds[v25] = p23:removeProductionPointFromFarm(p24, p23.farmIds[v25])
		end
	end
	if #p23.productionPoints == 0 and p23.isServer then
		g_currentMission:removeUpdateable(p23)
	end
end
function ProductionChainManager.removeProductionPointFromFarm(_, p26, p27)
	if p27.productionPoints == nil then
		return p27
	end
	table.removeElement(p27.productionPoints, p26)
	local v28 = p27.inputTypeToProductionPoints
	for v29 in pairs(p26.inputFillTypeIds) do
		if v28[v29] then
			if not table.removeElement(v28[v29], p26) then
				printError("Error: ProductionChainManager:removeProductionPoint(): Unable to remove production point from input type mapping")
			end
			if #v28[v29] == 0 then
				v28[v29] = nil
			end
		end
	end
	if #p27.productionPoints == 0 and p27.factories == nil then
		p27 = nil
	end
	return p27
end
function ProductionChainManager.removeFactory(p30, p31)
	p30.reverseFactory[p31] = nil
	if table.removeElement(p30.factories, p31) then
		local v32 = p31:getOwnerFarmId()
		if v32 ~= AccessHandler.EVERYONE and p30.farmIds[v32] ~= nil then
			p30.farmIds[v32] = p30:removeFactoryFromFarm(p31, p30.farmIds[v32])
		end
	end
end
function ProductionChainManager.removeFactoryFromFarm(_, p33, p34)
	if p34.factories == nil then
		return p34
	end
	table.removeElement(p34.factories, p33)
	if #p34.factories == 0 and p34.productionPoints == nil then
		p34 = nil
	end
	return p34
end
function ProductionChainManager.getProductionPointsForFarmId(p35, p36)
	return p35.farmIds[p36] and p35.farmIds[p36].productionPoints or {}
end
function ProductionChainManager.getFactoriesForFarmId(p37, p38)
	return p37.farmIds[p38] and p37.farmIds[p38].factories or {}
end
function ProductionChainManager.getNumOfProductionPoints(p39)
	return #p39.productionPoints
end
function ProductionChainManager.getUnownedProductionPoints(p40)
	local v41 = {}
	for _, v42 in pairs(p40.productionPoints) do
		if v42:getOwnerFarmId() == AccessHandler.EVERYONE then
			table.insert(v41, v42)
		end
	end
	return v41
end
function ProductionChainManager.getUnownedFactories(p43)
	local v44 = {}
	for _, v45 in pairs(p43.factories) do
		if v45:getOwnerFarmId() == AccessHandler.EVERYONE then
			table.insert(v44, v45)
		end
	end
	return v44
end
function ProductionChainManager.getHasFreeSlots(p46)
	return #p46.productionPoints < ProductionChainManager.NUM_MAX_PRODUCTION_POINTS
end
function ProductionChainManager.update(p47)
	if #p47.productionPoints ~= 0 then
		if p47.currentUpdateIndex > #p47.productionPoints then
			p47.currentUpdateIndex = 1
			if p47.hourChangedDirty then
				p47.hourChangeUpdating = true
				p47.hourChangedDirty = false
			elseif p47.hourChangeUpdating then
				p47.hourChangeUpdating = false
				p47:distributeGoods()
			end
		end
		local v48 = p47.productionPoints[p47.currentUpdateIndex]
		if v48 then
			v48:updateProduction()
			if p47.hourChangeUpdating and (p47.isServer and v48.isOwned) then
				v48:claimProductionCosts()
				v48:directlySellOutputs()
				v48:updateBalaceDirectlySoldOutputs()
			end
		end
		p47.currentUpdateIndex = p47.currentUpdateIndex + 1
	end
end
function ProductionChainManager.hourChanged(p49)
	p49.hourChangedDirty = true
end
function ProductionChainManager.distributeGoods(p50)
	if p50.isServer then
		for _, v51 in pairs(p50.farmIds) do
			if v51.productionPoints ~= nil then
				for v52 = 1, #v51.productionPoints do
					local v53 = v51.productionPoints[v52]
					for v54 in pairs(v53.outputFillTypeIdsAutoDeliver) do
						local v55 = v53.storage:getFillLevel(v54)
						if v55 > 0 then
							local v56 = v51.inputTypeToProductionPoints[v54] or {}
							local v57 = 0
							for v58 = 1, #v56 do
								v57 = v57 + v56[v58].storage:getFreeCapacity(v54, true)
							end
							if v57 > 0 then
								for v59 = 1, #v56 do
									local v60 = v56[v59]
									local v61 = v60.storage:getFreeCapacity(v54, true)
									if v61 > 0 then
										local v62 = v55 * (v61 / v57)
										local v63 = math.min(v61, v62)
										local v64 = v63 * calcDistanceFrom(v53.owningPlaceable.rootNode, v60.owningPlaceable.rootNode) * ProductionPoint.DIRECT_DELIVERY_PRICE
										g_currentMission:addMoney(-v64, v60.ownerFarmId, MoneyType.PRODUCTION_COSTS, true)
										v60.storage:setFillLevel(v60.storage:getFillLevel(v54) + v63, v54)
										v53.storage:setFillLevel(v53.storage:getFillLevel(v54) - v63, v54)
									end
								end
							end
						end
					end
				end
			end
		end
	end
end
function ProductionChainManager.updateBalance(_) end
function ProductionChainManager.commandListProductionPoints(p65)
	if #p65.productionPoints <= 0 then
		return "no productions points available"
	end
	print("available production points:")
	for v66 = 1, #p65.productionPoints do
		local v67 = p65.productionPoints[v66]
		print(string.format("%i: %s", v66, v67:toString()))
	end
	return string.format("listed %i production points", #p65.productionPoints)
end
function ProductionChainManager.commandPrintAutoDeliverMapping(p68)
	print("AutoDeliverMapping")
	for v69, v70 in pairs(p68.farmIds) do
		printf("  Farm %i", v69)
		for v71, v72 in pairs(v70.inputTypeToProductionPoints) do
			print(string.format("    FillType %s distributed to", g_fillTypeManager:getFillTypeNameByIndex(v71)))
			for _, v73 in pairs(v72) do
				print(string.format("      %s", v73:toString()))
			end
		end
	end
end
function ProductionChainManager.commandSetOwner(p74, p75, p76)
	local v77 = p74:getProductionPointsFromString(p75)
	local v78 = tonumber(p76)
	if v77 == false then
		return "Error: no production point given\nUsage: gsProductionPointSetOwner ppIdentifier farmId"
	end
	if v78 == nil then
		return "Error: no farmId given\nUsage: gsProductionPointSetOwner ppIdentifier farmId"
	end
	local v79 = table.clone(v77)
	for _, v80 in pairs(v79) do
		v80:setOwnerFarmId(v78, true)
	end
	return string.format("Updated owner for %d production points", table.size(v79))
end
function ProductionChainManager.commandSetProductionState(p81, p82, p83, p84)
	local v85 = p81:getProductionPointsFromString(p82)
	local v86 = Utils.stringToBoolean(p84)
	if v85 == false then
		return "Error: no production point given\nUsage: gsProductionPointSetProductionState ppIdentifier productionIdentifier|all state"
	end
	if p83 == nil then
		return "Error: no production identifier given\nUsage: gsProductionPointSetProductionState ppIdentifier productionIdentifier|all state"
	end
	if v86 == nil then
		return "Error: no valid state given\nUsage: gsProductionPointSetProductionState ppIdentifier productionIdentifier|all state"
	end
	local v87 = {}
	for _, v88 in pairs(v85) do
		if p83:lower() == "all" then
			for _, v89 in pairs(v88.productions) do
				table.insert(v87, { v88, v89 })
			end
		else
			local v90 = v88.productionsIdToObj[p83]
			if v90 then
				table.insert(v87, { v88, v90 })
			end
		end
	end
	if #v87 == 0 then
		return string.format("Error: no productions found for identifier \'%s\'\n%s", p83, "Usage: gsProductionPointSetProductionState ppIdentifier productionIdentifier|all state")
	end
	for _, v91 in pairs(v87) do
		local v92 = v91[1]
		local v93 = v91[2]
		v92:setProductionState(v93.id, v86)
		print(string.format("%s (%s): %s = %s", v92:getName(), v92:tableId(), v93.id, v86))
	end
	return string.format("Updated state for %d productions", table.size(v87))
end
function ProductionChainManager.commandSetOutputMode(p94, p95, p96, p97)
	local function v102()
		local v98 = {}
		for v99, v100 in pairs(ProductionPoint.OUTPUT_MODE) do
			local v101 = v100 .. "=" .. v99
			table.insert(v98, v101)
		end
		return table.concat(v98, "\n")
	end
	local v103 = p94:getProductionPointsFromString(p95)
	if v103 == false then
		return "Error: no production point given\nUsage: gsProductionPointSetOutputMode ppIdentifier outputFillType|all outputMode"
	end
	if not p96 then
		return "Error: Missing argument outputFillType.\nUsage: gsProductionPointSetOutputMode ppIdentifier outputFillType|all outputMode"
	end
	if not table.hasElement(ProductionPoint.OUTPUT_MODE, (tonumber(p97))) then
		return string.format("Error: Invalid output mode \'%s\'. Available modes:\n%s", p97, v102())
	end
	if p96:lower() == "all" then
		for _, v104 in pairs(v103) do
			for v105 in pairs(v104.outputFillTypeIds) do
				v104:setOutputDistributionMode(v105, p97)
			end
		end
	else
		local v106 = g_fillTypeManager:getFillTypeIndexByName(p96)
		for _, v107 in pairs(v103) do
			if v107.outputFillTypeIds[v106] then
				v107:setOutputDistributionMode(v106, p97)
			end
		end
	end
	return "Updated production points"
end
function ProductionChainManager.commandSetFillLevel(p108, p109, p110, p111)
	local v112 = p108:getProductionPointsFromString(p109)
	if v112 == false then
		return "Error: no production point given\nUsage: gsProductionPointSetFillLevel ppIdentifier fillTypeName|all fillLevel"
	end
	local v113 = g_fillTypeManager:getFillTypeIndexByName(p110)
	if not p110 or p110:lower() ~= "all" and not v113 then
		return "Error: no valid fillType given\nUsage: gsProductionPointSetFillLevel ppIdentifier fillTypeName|all fillLevel"
	end
	local v114 = tonumber(p111)
	if not v114 then
		return "Error: no fillLevel given\nUsage: gsProductionPointSetFillLevel ppIdentifier fillTypeName|all fillLevel"
	end
	local v115 = 0
	for _, v116 in pairs(v112) do
		if p110:lower() == "all" then
			for v117 in pairs(v116.storage:getSupportedFillTypes()) do
				v116.storage:setFillLevel(v114, v117)
				v115 = v115 + 1
			end
		elseif v113 and v116.storage:getIsFillTypeSupported(v113) then
			v116.storage:setFillLevel(v114, v113)
			v115 = v115 + 1
		end
	end
	return string.format("Filled %i storage spaces", v115)
end
function ProductionChainManager.consoleCommandToggleProdPointDebug(p118)
	p118.debugEnabled = not p118.debugEnabled
	if g_currentMission ~= nil then
		for _, v119 in pairs(p118.productionPoints) do
			if p118.debugEnabled then
				g_currentMission:addDrawable(v119)
			else
				g_currentMission:removeDrawable(v119)
			end
		end
	end
	local v120 = p118.debugEnabled
	return "ProductionChainManager.debugEnabled=" .. tostring(v120)
end
function ProductionChainManager.getProductionPointsFromString(p121, p122)
	if not p122 or p122 == "" then
		return false
	end
	local v123 = {}
	if p122:lower() == "all" then
		return p121.productionPoints
	end
	local v124 = p121.productionPoints[tonumber(p122)]
	if not v124 and string.len(p122) >= 4 then
		for _, v125 in pairs(p121.productionPoints) do
			if string.find(v125:tableId(), p122) then
				if v124 ~= nil then
					printError(string.format("Error: Multiple production points for index/identifier \'%s\'. Please provide a longer identifier.", p122))
					p121:commandListProductionPoints()
					return false
				end
				v124 = v125
			end
		end
	end
	if v124 then
		table.insert(v123, v124)
		return v123
	end
	printError(string.format("Error: No Production Point for index/identifier \'%s\'", p122))
	p121:commandListProductionPoints()
	return false
end

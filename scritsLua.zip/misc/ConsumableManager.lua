ConsumableManager = {}
ConsumableManager.DEFAULT_FILENAME = "data/objects/consumables/consumables.xml"
ConsumableManager.NUM_VARIATION_BITS = 9
ConsumableManager.MAX_NUM_VARIATIONS = 2 ^ ConsumableManager.NUM_VARIATION_BITS - 1
ConsumableManager.xmlSchemaConsumable = nil
ConsumableManager.xmlSchemaConsumables = nil
local v_u_1 = Class(ConsumableManager, AbstractManager)
function ConsumableManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AbstractManager.new(p2 or v_u_1)
	v3.types = {}
	v3.typesByName = {}
	v3.variations = {}
	v3.variationsByName = {}
	v3.sharedLoadRequestIds = {}
	v3.modConsumablesToLoad = {}
	ConsumableManager.xmlSchemaConsumable = XMLSchema.new("consumable")
	ConsumableManager.registerConsumableXMLPaths(ConsumableManager.xmlSchemaConsumable)
	ConsumableManager.xmlSchemaConsumables = XMLSchema.new("consumables")
	ConsumableManager.registerConsumablesXMLPaths(ConsumableManager.xmlSchemaConsumables)
	return v3
end
function ConsumableManager.loadMapData(p4, _, _, p5)
	ConsumableManager:superClass().loadMapData(p4)
	p4.baseDirectory = p5
	local v6 = XMLFile.load("consumables", ConsumableManager.DEFAULT_FILENAME, ConsumableManager.xmlSchemaConsumables)
	if v6 ~= nil then
		for _, v7 in v6:iterator("consumables.types.type") do
			local v8 = {
				["name"] = v6:getValue(v7 .. "#name"),
				["title"] = v6:getValue(v7 .. "#title")
			}
			if v8.name == nil or v8.title == nil then
				Logging.xmlWarning(v6, "Failed to load consumable type from xml. (%s)", v7)
			else
				v8.name = v8.name:upper()
				local v9 = p4.types
				table.insert(v9, v8)
				p4.typesByName[v8.name] = v8
			end
		end
		for _, v10 in v6:iterator("consumables.consumable") do
			local v11 = v6:getValue(v10 .. "#filename")
			if v11 ~= nil then
				p4:loadConsumableVariationsFromXML(Utils.getFilename(v11, p5), nil, p5)
			end
		end
		v6:delete()
	end
	for v12 = #p4.modConsumablesToLoad, 1, -1 do
		local v13 = p4.modConsumablesToLoad[v12]
		p4:loadConsumableVariationsFromXML(v13.xmlFilename, v13.customEnvironment, v13.baseDirectory)
		p4.modConsumablesToLoad[v12] = nil
	end
end
function ConsumableManager.unloadMapData(p14)
	for _, v15 in ipairs(p14.variations) do
		if v15.node ~= nil then
			delete(v15.node)
		end
		if v15.consumingNode ~= nil then
			delete(v15.consumingNode)
		end
		if v15.tensionBeltNode ~= nil then
			delete(v15.tensionBeltNode)
		end
	end
	p14.variations = {}
	for v16 = 1, #p14.sharedLoadRequestIds do
		local v17 = p14.sharedLoadRequestIds[v16]
		g_i3DManager:releaseSharedI3DFile(v17)
	end
	p14.sharedLoadRequestIds = {}
	ConsumableManager:superClass().unloadMapData(p14)
end
function ConsumableManager.addModConsumable(p18, p19, p20, p21)
	local v22 = p18.modConsumablesToLoad
	table.insert(v22, {
		["xmlFilename"] = p19,
		["customEnvironment"] = p20,
		["baseDirectory"] = p21
	})
end
function ConsumableManager.loadConsumableVariationsFromXML(p23, p24, p25, p26)
	Logging.devInfo("Loading Consumable from \'%s\'", p24)
	local v27 = XMLFile.load("Consumable", p24, ConsumableManager.xmlSchemaConsumable)
	if v27 ~= nil then
		for _, v28 in v27:iterator("consumable.consumableVariation") do
			if #p23.variations >= ConsumableManager.MAX_NUM_VARIATIONS then
				Logging.xmlWarning(v27, "Max. num consumables variations reached, skip loading of \'%s\'", v28)
			else
				local v29 = {
					["type"] = v27:getValue(v28 .. "#type")
				}
				if v29.type == nil then
					Logging.xmlWarning(v27, "Missing type in \'%s\'", v28)
				else
					v29.name = v27:getValue(v28 .. "#name")
					if v29.name == nil then
						Logging.xmlWarning(v27, "Missing name in \'%s\'", v28)
					else
						if p25 ~= nil then
							v29.name = p25 .. "." .. v29.name
						end
						v29.price = v27:getValue(v28 .. "#price", 0)
						v29.title = v27:getValue(v28 .. "#title", nil, p25)
						if v29.title == nil then
							Logging.xmlWarning(v27, "Missing title in \'%s\'", v28)
						else
							v29.unitText = v27:getValue(v28 .. "#unitText", nil, p25, false)
							v29.capacity = v27:getValue(v28 .. "#capacity", 1)
							v29.filename = v27:getValue(v28 .. ".object#filename")
							if v29.filename ~= nil then
								v29.filename = Utils.getFilename(v29.filename, p26)
								if v29.filename ~= nil then
									local v30 = v27:getValue(v28 .. ".object#node")
									if v30 ~= nil then
										local v31 = g_i3DManager:loadSharedI3DFileAsync(v29.filename, false, false, p23.consumableI3DFileLoaded, p23, { v29, v30, "node" })
										local v32 = p23.sharedLoadRequestIds
										table.insert(v32, v31)
									end
								end
							end
							v29.consumingFilename = v27:getValue(v28 .. ".consumingObject#filename")
							if v29.consumingFilename ~= nil then
								v29.consumingFilename = Utils.getFilename(v29.consumingFilename, p26)
								if v29.consumingFilename ~= nil then
									local v33 = v27:getValue(v28 .. ".consumingObject#node")
									if v33 ~= nil then
										local v34 = g_i3DManager:loadSharedI3DFileAsync(v29.consumingFilename, false, false, p23.consumableI3DFileLoaded, p23, { v29, v33, "consumingNode" })
										local v35 = p23.sharedLoadRequestIds
										table.insert(v35, v34)
									end
								end
							end
							v29.tensionBeltFilename = v27:getValue(v28 .. ".tensionBeltObject#filename")
							if v29.tensionBeltFilename ~= nil then
								v29.tensionBeltFilename = Utils.getFilename(v29.tensionBeltFilename, p26)
								if v29.tensionBeltFilename ~= nil then
									local v36 = v27:getValue(v28 .. ".tensionBeltObject#node")
									if v36 ~= nil then
										local v37 = g_i3DManager:loadSharedI3DFileAsync(v29.tensionBeltFilename, false, false, p23.consumableI3DFileLoaded, p23, { v29, v36, "tensionBeltNode" })
										local v38 = p23.sharedLoadRequestIds
										table.insert(v38, v37)
									end
								end
							end
							v29.metaData = {}
							for _, v39 in v27:iterator(v28 .. ".metaData.value") do
								local v40 = v27:getValue(v39 .. "#name")
								if v40 == nil then
									Logging.xmlWarning(v27, "Missing name in \'%s\'", v39)
								else
									local v41 = v27:getValue(v39 .. "#value")
									if v41 ~= nil then
										local v42
										if v41:contains(" ") then
											v42 = string.getVector(v41)
										else
											v42 = tonumber(v41) or v41
										end
										if v42 == nil then
											Logging.xmlWarning(v27, "Invalid value in \'%s\'", v39)
										else
											v29.metaData[v40] = v42
										end
									end
								end
							end
							v29.shaderParameters = {}
							for _, v43 in v27:iterator(v28 .. ".shaderParameter") do
								local v44 = v27:getValue(v43 .. "#name")
								if v44 == nil then
									Logging.xmlWarning(v27, "Missing name in \'%s\'", v43)
								else
									local v45 = {
										["name"] = v44,
										["materialSlotName"] = v27:getValue(v43 .. "#materialSlotName"),
										["value"] = v27:getValue(v43 .. "#value", nil, true)
									}
									if v45.value == nil then
										Logging.xmlWarning(v27, "Invalid value in \'%s\'", v43)
									else
										local v46 = v29.shaderParameters
										table.insert(v46, v45)
									end
								end
							end
							if p23.variationsByName[v29.name] == nil then
								local v47 = p23.variations
								table.insert(v47, v29)
								v29.index = #p23.variations
								p23.variationsByName[v29.name] = v29
							else
								Logging.xmlWarning(v27, "Consumable with name \'%s\' already registered", v29.name)
							end
						end
					end
				end
			end
		end
		v27:delete()
	end
end
function ConsumableManager.consumableI3DFileLoaded(_, p48, _, p49)
	local v50 = p49[1]
	local v51 = p49[2]
	local v52 = p49[3]
	if p48 ~= nil and p48 ~= 0 then
		local v53 = I3DUtil.indexToObject(p48, v51, nil, nil)
		if v53 == nil then
			printWarning(string.format("Warning: Unable to find consumable object \'%s\' for \'%s\'", v51, v50.name))
		else
			setTranslation(v53, 0, 0, 0)
			setRotation(v53, 0, 0, 0)
			unlink(v53)
			v50[v52] = v53
		end
		delete(p48)
	end
end
function ConsumableManager.getConsumableMeshByIndex(p54, p55, p56)
	local v57 = p54.variations[p55]
	if v57 == nil then
		return nil
	end
	if v57.node == nil then
		return nil, nil
	end
	local v58 = clone(v57.node, false, false, false)
	if not p56 or v57.tensionBeltNode == nil then
		return v58, nil
	end
	local v59 = clone(v57.tensionBeltNode, false, false, false)
	link(v58, v59)
	return v58, v59
end
function ConsumableManager.getConsumableConsumingMeshByIndex(p60, p61)
	local v62 = p60.variations[p61]
	if v62 == nil then
		return nil
	end
	if v62.node == nil then
		return nil
	end
	local v63 = clone(v62.consumingNode or v62.node, false, false, false)
	for _, v64 in ipairs(v62.shaderParameters) do
		if v64.materialSlotName == nil then
			I3DUtil.setShaderParameterRec(v63, v64.name, v64.value[1], v64.value[2], v64.value[3], v64.value[4])
		else
			I3DUtil.setMaterialSlotShaderParameterRec(v63, v64.materialSlotName, v64.name, v64.value[1], v64.value[2], v64.value[3], v64.value[4])
		end
	end
	return v63
end
function ConsumableManager.getConsumableVariationIndexByName(p65, p66, p67)
	local v68
	if p67 == nil then
		v68 = nil
	else
		v68 = p65.variationsByName[p67 .. "." .. p66]
	end
	if v68 == nil then
		v68 = p65.variationsByName[p66]
	end
	return v68 == nil and 0 or v68.index
end
function ConsumableManager.getConsumableVariationNameByIndex(p69, p70)
	local v71 = p69.variations[p70]
	return v71 == nil and "UNKNOWN" or v71.name
end
function ConsumableManager.getConsumableVariationCapacityAndUnitByIndex(p72, p73)
	local v74 = p72.variations[p73]
	if v74 == nil then
		return nil, nil
	else
		return v74.capacity, v74.unitText
	end
end
function ConsumableManager.getConsumableVariationShaderParameterByIndex(p75, p76)
	local v77 = p75.variations[p76]
	if v77 == nil then
		return nil
	else
		return v77.shaderParameters
	end
end
function ConsumableManager.getConsumableVariationMetaDataByIndex(p78, p79)
	local v80 = p78.variations[p79]
	if v80 == nil then
		return nil
	else
		return v80.metaData
	end
end
function ConsumableManager.getConsumableVariationsByType(p81, p82)
	local v83 = {}
	local v84 = {}
	for v85, v86 in ipairs(p81.variations) do
		if v86.type == p82 then
			local v87 = v86.title
			table.insert(v83, v87)
			v84[#v83] = v85
		end
	end
	return v83, v84
end
function ConsumableManager.getConsumableVariationPriceByIndex(p88, p89)
	local v90 = p88.variations[p89]
	if v90 == nil then
		return nil
	else
		return v90.price
	end
end
function ConsumableManager.getTypeTitle(p91, p92)
	local v93 = p91.typesByName[p92]
	if v93 == nil then
		return nil
	else
		return v93.title or p92
	end
end
function ConsumableManager.registerConsumableXMLPaths(p94)
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?)#type", "Name of the consumable type")
	p94:register(XMLValueType.FLOAT, "consumable.consumableVariation(?)#price", "Price per unit", 0)
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?)#name", "Name of the consumable itself (to be refered on vehicles)")
	p94:register(XMLValueType.L10N_STRING, "consumable.consumableVariation(?)#title", "Name of the consumable itself (to be shown in the UI)")
	p94:register(XMLValueType.FLOAT, "consumable.consumableVariation(?)#capacity", "Capacity of one unit from this type (to be shown in the UI)", 1)
	p94:register(XMLValueType.L10N_STRING, "consumable.consumableVariation(?)#unitText", "Unit text for the UI")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).object#filename", "Path to i3d file which contains the object")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).object#node", "Path to the object node inside of the i3d file")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).consumingObject#filename", "Path to i3d file which contains the object (in consuming state)")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).consumingObject#node", "Path to the object node inside of the i3d file (in consuming state)")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).tensionBeltObject#filename", "Path to i3d file which contains the object (tension belt mesh)")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).tensionBeltObject#node", "Path to the object node inside of the i3d file (tension belt mesh)")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).metaData.value(?)#name", "Name of the value")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).metaData.value(?)#value", "Value")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).shaderParameter(?)#name", "Name of the shader parameter to so on the objects")
	p94:register(XMLValueType.STRING, "consumable.consumableVariation(?).shaderParameter(?)#materialSlotName", "Material slot name which should receive the shader parameter (if not set, it will be applied to all materials)")
	p94:register(XMLValueType.VECTOR_4, "consumable.consumableVariation(?).shaderParameter(?)#value", "Value")
end
function ConsumableManager.registerConsumablesXMLPaths(p95)
	p95:register(XMLValueType.STRING, "consumables.types.type(?)#name", "Name of the consumable type")
	p95:register(XMLValueType.L10N_STRING, "consumables.types.type(?)#title", "Name of the type to be shown in the UI")
	p95:register(XMLValueType.STRING, "consumables.consumable(?)#filename", "Path to consumable xml file")
end
g_consumableManager = ConsumableManager.new()

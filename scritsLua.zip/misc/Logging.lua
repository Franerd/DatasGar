Logging = {}
local function v_u_3(p1)
	local v2 = type(p1)
	if v2 == "number" then
		return getXMLFilename(p1)
	elseif v2 == "table" and (p1.isa ~= nil and p1:isa(XMLFile)) then
		return p1:getFilename()
	elseif v2 == "string" and string.endsWith(p1, ".xml") then
		return p1
	else
		return nil
	end
end
function Logging.xmlWarning(p4, p5, ...)
	-- upvalues: (copy) v_u_3
	local v6 = v_u_3(p4)
	printWarning(string.format("  Warning (%s): " .. p5, v6, ...))
end
function Logging.xmlError(p7, p8, ...)
	-- upvalues: (copy) v_u_3
	local v9 = v_u_3(p7)
	printError(string.format("  Error (%s): " .. p8, v9, ...))
end
function Logging.xmlInfo(p10, p11, ...)
	-- upvalues: (copy) v_u_3
	local v12 = v_u_3(p10)
	print(string.format("  Info (%s): " .. p11, v12, ...))
end
function Logging.i3dWarning(p13, p14, ...)
	local v15 = I3DUtil.getNodeNameAndIndexPath(p13)
	printWarning(string.format("  Warning (%s): " .. p14, v15, ...))
end
function Logging.i3dError(p16, p17, ...)
	local v18 = I3DUtil.getNodeNameAndIndexPath(p16)
	printError(string.format("  Error (%s): " .. p17, v18, ...))
end
function Logging.i3dInfo(p19, p20, ...)
	local v21 = I3DUtil.getNodeNameAndIndexPath(p19)
	print(string.format("  Info (%s): " .. p20, v21, ...))
end
function Logging.xmlDevWarning(p22, p23, ...)
	-- upvalues: (copy) v_u_3
	if g_isDevelopmentVersion then
		local v24 = v_u_3(p22)
		printWarning(string.format("  DevWarning (%s): " .. p23, v24, ...))
	end
end
function Logging.xmlDevError(p25, p26, ...)
	-- upvalues: (copy) v_u_3
	if g_isDevelopmentVersion then
		local v27 = v_u_3(p25)
		printError(string.format("  DevError (%s): " .. p26, v27, ...))
	end
end
function Logging.xmlDevInfo(p28, p29, ...)
	-- upvalues: (copy) v_u_3
	if g_showDevelopmentWarnings then
		local v30 = v_u_3(p28)
		print(string.format("  DevInfo (%s): " .. p29, v30, ...))
	end
end
function Logging.warning(p31, ...)
	printWarning(string.format("  Warning: " .. p31, ...))
end
function Logging.error(p32, ...)
	printError(string.format("  Error: " .. p32, ...))
end
function Logging.info(p33, ...)
	print(string.format("  Info: " .. p33, ...))
end
function Logging.fatal(p34, ...)
	local v35 = string.format("  Fatal Error: " .. p34, ...)
	printCallstack()
	requestExit()
	error(v35)
end
function Logging.devWarning(p36, ...)
	if g_showDevelopmentWarnings then
		printWarning(string.format("  DevWarning: " .. p36, ...))
	end
end
function Logging.devError(p37, ...)
	if g_showDevelopmentWarnings then
		printError(string.format("  DevError: " .. p37, ...))
	end
end
function Logging.devInfo(p38, ...)
	if g_showDevelopmentWarnings then
		print(string.format("  DevInfo: " .. p38, ...))
	end
end

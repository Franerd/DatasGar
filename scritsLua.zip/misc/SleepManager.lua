SleepManager = {}
SleepManager.INPUT_CONTEXT_NAME = "SLEEPING"
SleepManager.SLEEPING_TIME_SCALE = 5000
SleepManager.TIME_TO_ANSWER_REQUEST = 20000
SleepManager.TIME_TO_NEXT_REQUEST = 20000
SleepManager.NUM_SLEEP_ANIMATION_STATES = 16
SleepManager.ANIMATION_SLICE_ID = "gui.sleep"
local v_u_1 = Class(SleepManager, AbstractManager)
function SleepManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AbstractManager.new(p2 or v_u_1)
	v3.isSleeping = false
	v3.wakeUpTime = 0
	v3.previousCamera = nil
	v3.previousInputContext = nil
	v3.fallbackCamera = nil
	v3.isRequestPending = false
	v3.requestAnswer = true
	v3.requestedTime = 0
	v3.requestedTargetTime = 0
	v3.curerntSleepAnimationState = SleepManager.NUM_SLEEP_ANIMATION_STATES
	return v3
end
function SleepManager.loadMapData(p4, _, _, _)
	local v5, v6 = getNormalizedScreenValues(128, 128)
	p4.animationNumFrames = 16
	p4.animationTimer = 0
	p4.animationSpeed = 50
	p4.animationOffset = 0
	p4.animationFrameSize = 128
	p4.animationRefSize = { 2048, 128 }
	local v7, v8 = getNormalizedScreenValues(-4, 0)
	p4.animationOverlay = g_overlayManager:createOverlay(SleepManager.ANIMATION_SLICE_ID, 0.5 + v7, 0.5 + v8, v5, v6)
	p4.animationOverlay:setAlignment(Overlay.ALIGN_VERTICAL_MIDDLE, Overlay.ALIGN_HORIZONTAL_CENTER)
	p4.animationOverlay:setColor(0.22323, 0.40724, 0.00368, 1)
	local v9, v10 = getNormalizedScreenValues(200, 200)
	p4.animationBackgroundOverlay = Overlay.new("dataS/menu/hud/ui_elements.png", 0.5, 0.5, v9, v10)
	p4.animationBackgroundOverlay:setAlignment(Overlay.ALIGN_VERTICAL_MIDDLE, Overlay.ALIGN_HORIZONTAL_CENTER)
	p4.animationBackgroundOverlay:setUVs(GuiUtils.getUVs({
		294,
		390,
		100,
		100
	}, { 1024, 1024 }))
	p4.animationBackgroundOverlay:setColor(0, 0, 0, 0.75)
	g_messageCenter:subscribe(MessageType.USER_REMOVED, p4.onUserRemoved, p4)
end
function SleepManager.unloadMapData(p11)
	g_messageCenter:unsubscribeAll(p11)
	if p11.fallbackCamera ~= nil then
		g_cameraManager:removeCamera(p11.fallbackCamera)
		delete(p11.fallbackCamera)
		p11.fallbackCamera = nil
	end
	if p11.animationOverlay ~= nil then
		p11.animationOverlay:delete()
		p11.animationOverlay = nil
	end
	if p11.animationBackgroundOverlay ~= nil then
		p11.animationBackgroundOverlay:delete()
		p11.animationBackgroundOverlay = nil
	end
end
function SleepManager.update(p12, p13)
	if g_currentMission:getIsServer() then
		if p12.wakeUpTime < g_currentMission.time and p12.isSleeping then
			p12:stopSleep()
		end
		if p12.isRequestPending then
			if #p12.userRequestIds == 0 then
				if p12.requestAnswer then
					p12:startSleep(p12.requestedTargetTime)
					p12:resetRequest()
				else
					g_server:broadcastEvent(SleepRequestDeniedEvent.new(p12.requestDeniedUserId), g_dedicatedServer == nil)
					p12:resetRequest()
				end
			elseif p12.requestedTime + SleepManager.TIME_TO_ANSWER_REQUEST < g_currentMission.time then
				g_server:broadcastEvent(SleepRequestTimeoutEvent.new(), false)
				p12:resetRequest()
			end
		end
	end
	if p12.isSleeping then
		p12.animationTimer = p12.animationTimer - p13
		if p12.animationTimer < 0 then
			p12.animationTimer = p12.animationSpeed
			p12.animationOffset = p12.animationOffset + 1
			if p12.animationOffset > p12.animationNumFrames - 1 then
				p12.animationOffset = 0
			end
			p12.curerntSleepAnimationState = p12.curerntSleepAnimationState + 1
			if p12.curerntSleepAnimationState > SleepManager.NUM_SLEEP_ANIMATION_STATES then
				p12.curerntSleepAnimationState = 1
			end
			local v14 = SleepManager.ANIMATION_SLICE_ID
			if p12.curerntSleepAnimationState < 10 then
				v14 = v14 .. "0" .. p12.curerntSleepAnimationState
			elseif p12.curerntSleepAnimationState < SleepManager.NUM_SLEEP_ANIMATION_STATES then
				v14 = v14 .. p12.curerntSleepAnimationState
			end
			p12.animationOverlay:setSliceId(v14)
		end
	end
end
function SleepManager.draw(p15)
	if p15.isSleeping and not g_currentMission.paused then
		if p15.animationBackgroundOverlay ~= nil then
			p15.animationBackgroundOverlay:render()
		end
		if p15.animationOverlay ~= nil then
			p15.animationOverlay:render()
		end
	end
end
function SleepManager.onUserRemoved(p16, p17)
	if p16.isRequestPending then
		for v18, v19 in ipairs(p16.userRequestIds) do
			if v19 == p17:getId() then
				table.remove(p16.userRequestIds, v18)
				return
			end
		end
	end
end
function SleepManager.getCanSleep(p20)
	return not p20.isSleeping
end
function SleepManager.getIsSleeping(p21)
	return p21.isSleeping
end
function SleepManager.onSleepNotAllowed(p22)
	InfoDialog.cancel()
	InfoDialog.show(g_i18n:getText("ui_inGameSleepNotAllowed"), nil, p22, DialogElement.TYPE_WARNING)
end
function SleepManager.onSleepRequestDenied(p23, p24)
	local v25 = ""
	if p24 > 0 then
		local v26 = g_currentMission.userManager:getUserByUserId(p24)
		if v26 ~= nil then
			v25 = string.format(" (%s)", v26:getNickname())
		end
	end
	InfoDialog.cancel()
	InfoDialog.show(g_i18n:getText("ui_inGameSleepRequestDenied") .. v25, nil, p23, DialogElement.TYPE_WARNING)
end
function SleepManager.onSleepRequestTimeout(p27)
	if p27.isSleepRequestAnswerPending then
		YesNoDialog.cancel()
	end
	InfoDialog.show(g_i18n:getText("ui_inGameSleepRequestTimeout"), nil, p27, DialogElement.TYPE_WARNING)
end
function SleepManager.onSleepRequestPending(p28)
	InfoDialog.cancel()
	InfoDialog.show(g_i18n:getText("ui_inGameSleepRequestPending"), nil, p28, DialogElement.TYPE_WARNING)
end
function SleepManager.onSleepRequest(p29, p30, _)
	local v31 = g_currentMission.userManager:getUserByUserId(p30)
	local v32 = v31 == nil and "Unknown" or v31:getNickname()
	p29.isSleepRequestAnswerPending = true
	YesNoDialog.show(p29.onSleepRequestYesNo, p29, string.format(g_i18n:getText("ui_inGameSleepRequest"), v32))
end
function SleepManager.onSleepRequestYesNo(p33, p34)
	p33.isSleepRequestAnswerPending = false
	g_client:getServerConnection():sendEvent(SleepResponseEvent.new(p34))
end
function SleepManager.onSleepResponse(p35, p36, p37)
	local v38 = g_currentMission:getIsServer()
	assert(v38, "SleepManager:onSleepResponse is a server-only function")
	if p35.isRequestPending then
		p35.requestAnswer = p35.requestAnswer and p37
		local v39 = g_currentMission.userManager:getUserIdByConnection(p36)
		if not p37 and p35.requestDeniedUserId == nil then
			p35.requestDeniedUserId = v39
		end
		if v39 ~= nil then
			for v40, v41 in ipairs(p35.userRequestIds) do
				if v41 == v39 then
					table.remove(p35.userRequestIds, v40)
					return
				end
			end
		end
	end
end
function SleepManager.showDialog(p42)
	if p42:getCanSleep() then
		local v43 = g_i18n:getText("ui_inGameSleepTargetTime") .. "\n" .. g_i18n:getText("ui_currentTime") .. ": " .. g_i18n:formatCurrentTime()
		SleepDialog.show(v43, p42.sleepDialogYesNo, p42)
	else
		InfoDialog.cancel()
		InfoDialog.show(g_i18n:getText("ui_inGameSleepWrongTime"), nil, nil, DialogElement.TYPE_WARNING)
	end
end
function SleepManager.sleepDialogYesNo(p44, p45, p46)
	if p45 then
		if g_currentMission:getIsServer() then
			p44:startSleepRequest(g_currentMission.playerUserId, p46)
			return
		end
		g_client:getServerConnection():sendEvent(SleepRequestEvent.new(g_currentMission.playerUserId, p46))
	end
end
function SleepManager.startSleepRequest(p47, p48, p49)
	local v50 = g_currentMission:getIsServer()
	assert(v50, "SleepManager:startSleepRequest is a server-only function")
	local v51 = g_currentMission.userManager:getUserByUserId(p48)
	local v52
	if v51 == nil then
		v52 = nil
	else
		v52 = v51:getConnection()
	end
	if p47.isRequestPending then
		if v52 ~= nil then
			v52:sendEvent(SleepRequestPendingEvent.new())
		end
		return
	else
		local _ = p47.requestedTime + SleepManager.TIME_TO_NEXT_REQUEST > g_currentMission.time
		if p47:getCanSleep() then
			p47.isRequestPending = true
			p47.requestedTime = g_currentMission.time
			p47.requestedTargetTime = p49
			p47.requestAnswer = true
			p47.userRequestIds = {}
			local v53 = {}
			for _, v54 in ipairs(g_currentMission.userManager:getUsers()) do
				if v54:getId() ~= p48 and (g_dedicatedServer == nil or v54:getId() ~= g_currentMission:getServerUserId()) and v54:getState() == FSBaseMission.USER_STATE_INGAME then
					local v55 = p47.userRequestIds
					table.insert(v55, v54:getId())
					table.insert(v53, v54:getConnection())
				end
			end
			g_server:broadcastEvent(SleepRequestEvent.new(p48, p49), g_dedicatedServer == nil, v52, nil, nil, v53)
		elseif v52 ~= nil then
			v52:sendEvent(SleepNotAllowedEvent.new())
		end
	end
end
function SleepManager.resetRequest(p56)
	p56.isRequestPending = false
	p56.requestedTargetTime = 0
	p56.requestAnswer = true
	p56.requestDeniedUserId = nil
end
function SleepManager.startSleep(p57, p58)
	g_currentMission.environment.weather.cloudUpdater:setSlowModeEnabled(true)
	if g_currentMission:getIsServer() then
		local v59 = p58 * 1000 * 60 * 60
		local v60 = (v59 - (g_currentMission.environment.dayTime + 1)) % 86400000
		p57.wakeUpTime = g_currentMission.time + v60 / SleepManager.SLEEPING_TIME_SCALE
		p57.startTimeScale = g_currentMission.missionInfo.timeScale
		g_currentMission:setTimeScale(SleepManager.SLEEPING_TIME_SCALE)
		g_currentMission:setTimeScaleMultiplier(1)
		g_server:broadcastEvent(StartSleepStateEvent.new(v59), false)
	end
	p57.isSleeping = true
	g_currentMission.hud:setIsVisible(false)
	g_currentMission.isPlayerFrozen = true
	g_inputBinding:setContext(SleepManager.INPUT_CONTEXT_NAME, true)
	p57.previousCamera = g_cameraManager:getActiveCamera()
	local v61 = p57:getSleepCamera()
	if v61 ~= nil then
		local v62, v63, v64 = getWorldTranslation(v61)
		local v65 = getTerrainHeightAtWorldPos(g_terrainNode, v62, v63, v64) + 60
		local v66 = math.max(v65, v63)
		setWorldTranslation(v61, v62, v66, v64)
		setWorldRotation(v61, 1.3962634015954636, 0, 0)
		g_cameraManager:setActiveCamera(v61)
	end
	g_messageCenter:publish(MessageType.SLEEPING, true)
end
function SleepManager.stopSleep(p67)
	g_currentMission.environment.weather.cloudUpdater:setSlowModeEnabled(false)
	if g_currentMission:getIsServer() then
		g_currentMission:setTimeScale(p67.startTimeScale)
		g_server:broadcastEvent(StopSleepStateEvent.new(), false)
	end
	local v68 = g_localPlayer
	if p67.previousCamera == nil or not entityExists(p67.previousCamera) then
		if v68 ~= nil then
			g_cameraManager:setActiveCamera(v68:getCurrentCameraNode())
		end
	else
		g_cameraManager:setActiveCamera(p67.previousCamera)
	end
	p67.previousCamera = nil
	if g_inputBinding:getContextName() == SleepManager.INPUT_CONTEXT_NAME then
		g_inputBinding:revertContext(true)
	end
	g_currentMission.isPlayerFrozen = false
	g_currentMission.hud:setIsVisible(true)
	p67.isSleeping = false
	g_messageCenter:publish(MessageType.SLEEPING, false)
end
function SleepManager.getSleepCamera(p69)
	return g_farmManager:getSleepCamera(g_localPlayer:getFarmId()) or p69:getFallbackCamera()
end
function SleepManager.getFallbackCamera(p70)
	if p70.fallbackCamera == nil then
		p70.fallbackCamera = createCamera("sleepingFallbackCamera", 1.0471975511965976, 1, 10000)
		link(getRootNode(), p70.fallbackCamera)
		g_cameraManager:addCamera(p70.fallbackCamera, nil, false)
	end
	return p70.fallbackCamera
end
g_sleepManager = SleepManager.new()

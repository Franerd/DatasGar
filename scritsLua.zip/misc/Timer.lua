Timer = {}
local v_u_1 = Class(Timer)
function Timer.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1
	local v4 = setmetatable({}, v3)
	v4.duration = p2
	v4.callback = nil
	v4.isRunning = false
	v4.timeLeft = p2
	return v4
end
function Timer.delete(p5)
	p5:reset()
end
function Timer.reset(p6)
	g_currentMission:removeUpdateable(p6)
	p6.isRunning = false
end
function Timer.start(p7, p8)
	if p7.duration == nil then
		Logging.error("Timer duration not set")
		printCallstack()
	else
		p7.isRunning = true
		if p8 == nil or not p8 then
			p7.timeLeft = p7.duration
		end
		g_currentMission:addUpdateable(p7)
	end
end
function Timer.startIfNotRunning(p9)
	if not p9.isRunning then
		p9:start()
	end
end
function Timer.stop(p10)
	g_currentMission:removeUpdateable(p10)
	p10.isRunning = false
end
function Timer.finish(p11)
	g_currentMission:removeUpdateable(p11)
	p11.timeLeft = 0
	p11.isRunning = false
	if p11.callback ~= nil then
		p11.callback(p11)
	end
end
function Timer.getIsRunning(p12)
	return p12.isRunning
end
function Timer.setFinishCallback(p13, p14)
	p13.callback = p14
	return p13
end
function Timer.getTimePassed(p15)
	return p15.duration - p15.timeLeft
end
function Timer.getTimeLeft(p16)
	return p16.timeLeft
end
function Timer.setTimeLeft(p17, p18)
	p17.timeLeft = p18
end
function Timer.update(p19, p20)
	if p19.isRunning then
		local v21 = p19.scaleFunc == nil and 1 or p19.scaleFunc()
		p19.timeLeft = p19.timeLeft - p20 * v21
		if p19.timeLeft <= 0 then
			p19:finish()
		end
	end
end
function Timer.setScaleFunction(p22, p23)
	p22.scaleFunc = p23
end
function Timer.createOneshot(p24, p_u_25, p26)
	local v_u_27 = Timer.new(p24)
	v_u_27:setFinishCallback(function()
		-- upvalues: (copy) v_u_27, (copy) p_u_25
		v_u_27:delete()
		return p_u_25()
	end)
	v_u_27:setScaleFunction(p26)
	v_u_27:start()
	return v_u_27
end
function Timer.getDuration(p28)
	return p28.duration
end
function Timer.setDuration(p29, p30)
	p29.duration = p30
	return p29
end
function Timer.writeUpdateStream(p31, p32)
	streamWriteInt32(p32, p31.timeLeft)
end
function Timer.readUpdateStream(p33, p34)
	p33.timeLeft = streamReadInt32(p34)
end

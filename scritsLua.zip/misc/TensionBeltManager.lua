TensionBeltManager = {}
local v_u_1 = Class(TensionBeltManager)
function TensionBeltManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4:initDataStructures()
	return v4
end
function TensionBeltManager.initDataStructures(p5)
	p5.belts = {}
	p5.defaultBeltData = nil
end
function TensionBeltManager.unloadMapData(p6)
	p6:initDataStructures()
end
function TensionBeltManager.onCreateTensionBelt(_, p7)
	local v8 = g_tensionBeltManager
	local v9 = Utils.getNoNil(getUserAttribute(p7, "name"), "default")
	local v10 = Utils.getNoNil(getUserAttribute(p7, "width"), 0.15)
	local v11 = v8:getType(v9)
	if v8.belts[v11] == nil then
		local v12 = {
			["width"] = v10
		}
		for v13 = 0, getNumOfChildren(p7) - 1 do
			local v14 = getChildAt(p7, v13)
			if getUserAttribute(v14, "isMaterial") then
				v12.material = {
					["materialId"] = getMaterial(v14, 0),
					["uvScale"] = Utils.getNoNil(getUserAttribute(v14, "uvScale"), 0.1)
				}
			elseif getUserAttribute(v14, "isDummyMaterial") then
				v12.dummyMaterial = {
					["materialId"] = getMaterial(v14, 0),
					["uvScale"] = Utils.getNoNil(getUserAttribute(v14, "uvScale"), 0.1)
				}
			elseif getUserAttribute(v14, "isHook") then
				if v12.hook == nil then
					local _, _, v15 = getTranslation(getChildAt(v14, 0))
					v12.hook = {
						["node"] = v14,
						["sizeRatio"] = v15
					}
				else
					local _, _, v16 = getTranslation(getChildAt(v14, 0))
					v12.hook2 = {
						["node"] = v14,
						["sizeRatio"] = v16
					}
				end
			elseif getUserAttribute(v14, "isRatchet") then
				local _, _, v17 = getTranslation(getChildAt(v14, 0))
				v12.ratchet = {
					["node"] = v14,
					["sizeRatio"] = v17
				}
			end
		end
		if v12.material == nil then
			printWarning("Warning: No material defined for tension belt type \'" .. v9 .. "\'!")
			return
		elseif v12.dummyMaterial == nil then
			printWarning("Warning: No material defined for tension belt type \'" .. v9 .. "\'!")
		else
			v8.belts[v11] = v12
			if v8.defaultBeltData == nil then
				v8.defaultBeltData = v12
			end
		end
	else
		printWarning("Warning: Tension belt type \'" .. v9 .. "\' already exists!")
		return
	end
end
function TensionBeltManager.getType(_, p18)
	return "BELT_TYPE_" .. string.upper(p18)
end
function TensionBeltManager.getBeltData(p19, p20)
	if p20 == nil then
		return p19.defaultBeltData
	else
		local v21 = p19:getType(p20)
		local v22 = p19.belts[v21]
		if v22 == nil then
			return p19.defaultBeltData
		else
			return v22
		end
	end
end
g_tensionBeltManager = TensionBeltManager.new()

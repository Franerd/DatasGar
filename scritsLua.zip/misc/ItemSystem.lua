ItemSystem = {}
ItemSystem.UNIQUE_ID_PREFIX = "item"
local v_u_1 = Class(ItemSystem)
g_xmlManager:addCreateSchemaFunction(function()
	ItemSystem.xmlSchemaSavegame = XMLSchema.new("savegame_items")
end)
g_xmlManager:addInitSchemaFunction(function()
	local v2 = ItemSystem.xmlSchemaSavegame
	v2:register(XMLValueType.BOOL, "items#loadAnyFarmInSingleplayer", "Load any farm in singleplayer", false)
	v2:register(XMLValueType.STRING, "items.item(?)#className", "Class name")
	v2:register(XMLValueType.BOOL, "items.item(?)#defaultFarmProperty", "Is property of default farm", false)
	v2:register(XMLValueType.INT, "items.item(?)#farmId", "Farm id")
	v2:register(XMLValueType.STRING, "items.item(?)#modName", "Name of mod")
end)
function ItemSystem.new(p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = p4 or v_u_1
	local v6 = setmetatable({}, v5)
	v6.mission = p3
	v6.itemsToSave = {}
	v6.sortedItemsToSave = {}
	v6.itemByUniqueId = {}
	if v6.mission:getIsServer() and g_addTestCommands then
		addConsoleCommand("gsItemRemoveAll", "Removes all items from current mission", "consoleCommandItemRemoveAll", v6, nil, true)
	end
	return v6
end
function ItemSystem.delete(p7)
	for _, v8 in pairs(p7.itemsToSave) do
		v8.item:delete()
	end
end
function ItemSystem.deleteAll(p9)
	local v10 = 0
	for _, v11 in pairs(p9.itemsToSave) do
		v11.item:delete()
		v10 = v10 + 1
	end
	return v10
end
function ItemSystem.loadItems(p12, p13, p14, p15, p16, p17, p18, p19)
	p12:loadItemsFromXML(XMLFile.load("ItemsXMLFile", p13, ItemSystem.xmlSchemaSavegame), p13, p14, p15, p16, p17, p18, p19)
end
function ItemSystem.loadItemsFromXML(p20, p21, p22, p23, p24, p25, p26, p27, p28)
	local v29 = {
		["xmlFile"] = p21,
		["xmlFilename"] = p22,
		["resetItems"] = p23,
		["missionInfo"] = p24,
		["missionDynamicInfo"] = p25,
		["index"] = 0,
		["asyncCallbackFunction"] = p26,
		["asyncCallbackObject"] = p27,
		["asyncCallbackArguments"] = p28
	}
	if not p20:loadNextItemsFromSavegame(v29) then
		p20:loadItemsFromSavegameFinished(v29)
	end
end
function ItemSystem.loadNextItemsFromSavegame(p30, p31)
	if g_currentMission.cancelLoading then
		return false
	end
	local v32 = p31.xmlFile
	local v33 = p31.missionInfo
	local v34 = p31.missionDynamicInfo
	local v35 = p31.resetItems
	local v36 = v32:getValue("items#loadAnyFarmInSingleplayer", false)
	local v37 = p31.index
	p31.index = p31.index + 1
	local v38 = string.format("items.item(%d)", v37)
	if not v32:hasProperty(v38) then
		return false
	end
	local v39 = v32:getValue(v38 .. "#className")
	if v39 == nil then
		Logging.xmlError(v32, "No className given for item \'%s\'", v38)
		p30:loadItemsFromSavegameStepFinished(nil, false, p31)
		return true
	end
	local v40 = v32:getValue(v38 .. "#defaultFarmProperty")
	local v41 = v32:getValue(v38 .. "#farmId")
	local v42 = v40 and v33.isCompetitiveMultiplayer
	if v42 then
		v42 = g_farmManager:getFarmById(v41) ~= nil
	end
	local v43 = v40 and (v33.loadDefaultFarm and not v34.isMultiplayer)
	if v43 then
		v43 = v41 == FarmManager.SINGLEPLAYER_FARM_ID and true or v36
	end
	local v44 = v33.isValid or (not v40 or (v43 or v42))
	local v45 = v32:getValue(v38 .. "#modName")
	if v45 ~= nil and not g_modIsLoaded[v45] then
		Logging.xmlError(v32, "Could not load item because mod \'%s\' is not available or loaded for \'%s\'", v45, v38)
		p30:loadItemsFromSavegameStepFinished(nil, false, p31)
		return true
	end
	if not v44 then
		Logging.xmlInfo(v32, "Item is not allowed to be loaded", v38)
		p30:loadItemsFromSavegameStepFinished(nil, false, p31)
		return true
	end
	local v46 = ClassUtil.getClassObject(v39)
	if v46 == nil or v46.new == nil then
		Logging.xmlError(v32, "Class \'%s\' not defined  for item \'%s\'", v39, v38)
		p30:loadItemsFromSavegameStepFinished(nil, false, p31)
		return true
	end
	local v47 = v46.new(p30.mission:getIsServer(), p30.mission:getIsClient())
	p31.key = v38
	p31.className = v39
	p31.loadDefaultProperty = v43
	p31.defaultItemsToSPFarm = v36
	p31.farmId = v41
	if v47.loadAsyncFromXMLFile == nil then
		if v47.loadFromXMLFile ~= nil then
			p30:loadItemsFromSavegameStepFinished(v47, v47:loadFromXMLFile(v32, v38, v35), p31)
		end
	else
		v47:loadAsyncFromXMLFile(v32, v38, v35, p30.loadItemsFromSavegameStepFinished, p30, p31)
	end
	return true
end
function ItemSystem.loadItemsFromSavegameStepFinished(p48, p49, p50, p51)
	if g_currentMission.cancelLoading then
		p48:loadItemsFromSavegameFinished(p51)
	else
		if p49 ~= nil then
			if p50 then
				if p51.loadDefaultProperty and (p51.defaultItemsToSPFarm and p51.farmId ~= FarmManager.SINGLEPLAYER_FARM_ID) then
					p49:setOwnerFarmId(FarmManager.SINGLEPLAYER_FARM_ID)
				end
				p49:register()
				p48:addItem(p49)
			else
				Logging.xmlError(p51.xmlFile, "Item \'%s\' could not be loaded correctly", p49.configFileName)
				p49:delete()
			end
		end
		if not p48:loadNextItemsFromSavegame(p51) then
			p48:loadItemsFromSavegameFinished(p51)
		end
	end
end
function ItemSystem.loadItemsFromSavegameFinished(_, p_u_52)
	g_asyncTaskManager:addTask(function()
		-- upvalues: (copy) p_u_52
		p_u_52.xmlFile:delete()
		if p_u_52.asyncCallbackFunction ~= nil then
			p_u_52.asyncCallbackFunction(p_u_52.asyncCallbackObject, p_u_52.asyncCallbackArguments)
		end
	end)
end
function ItemSystem.getItemByUniqueId(p53, p54)
	return p53.itemByUniqueId[p54]
end
function ItemSystem.save(p55, p56, p57)
	local v58 = XMLFile.create("itemsXMLFile", p56, "items", ItemSystem.xmlSchemaSavegame)
	if v58 ~= nil then
		p55:saveToXML(v58, p57)
		v58:delete()
	end
end
function ItemSystem.saveToXML(p59, p60, p61)
	if p60 ~= nil then
		local v62 = 0
		for _, v63 in pairs(p59.itemsToSave) do
			if v63.item.getNeedsSaving == nil or v63.item:getNeedsSaving() then
				local v64 = string.format("%s.item(%d)", "items", v62)
				p60:setValue(v64 .. "#className", v63.className)
				local v65 = v63.item.customEnvironment
				local v66 = ClassUtil.getClassModName(v63.className)
				if v65 == nil then
					v65 = v66
				end
				if v65 ~= nil then
					if p61 ~= nil then
						p61[v65] = v65
					end
					p60:setValue(v64 .. "#modName", v65)
				end
				if v66 ~= nil and p61 ~= nil then
					p61[v66] = v66
				end
				v63.item:saveToXMLFile(p60, v64, p61)
				v62 = v62 + 1
			end
		end
		p60:save()
	end
end
function ItemSystem.addItem(p67, p68)
	if p68.saveToXMLFile == nil then
		Logging.error("Adding item which does not have a saveToXMLFile function")
		return
	elseif p68.getUniqueId == nil then
		Logging.error("Adding item which does not have a getUniqueId function")
		return
	elseif p67.mission.objectsToClassName[p68] == nil then
		Logging.error("Adding item which does not have a className registered. Use registerObjectClassName(object,className)")
		return
	elseif p67.itemsToSave[p68] == nil then
		p67.itemsToSave[p68] = {
			["item"] = p68,
			["className"] = p67.mission.objectsToClassName[p68]
		}
		if p68:getUniqueId() == nil or p67.itemByUniqueId[p68:getUniqueId()] == nil then
			if p68:getUniqueId() == nil then
				p68:setUniqueId(Utils.getUniqueId(p68, p67.itemByUniqueId, ItemSystem.UNIQUE_ID_PREFIX))
			end
			p67.itemByUniqueId[p68:getUniqueId()] = p68
			table.addElement(p67.sortedItemsToSave, p67.itemsToSave[p68])
		else
			local v69 = Logging.warning
			local v70 = p68:getUniqueId()
			local v71 = p67.itemByUniqueId[p68:getUniqueId()]
			v69("Tried to add existing item with unique id of %s! Existing: %s, new: %s", v70, tostring(v71), (tostring(p68)))
		end
	else
		return
	end
end
function ItemSystem.removeItem(p72, p73)
	local v74 = p72.itemsToSave[p73]
	if v74 == nil then
		Logging.devInfo("ItemSystem: Trying to remove item that was never added before. Ignoring it.")
		printCallstack()
	else
		table.removeElement(p72.sortedItemsToSave, v74)
		p72.itemsToSave[p73] = nil
		p72.itemByUniqueId[p73:getUniqueId()] = nil
	end
end
function ItemSystem.consoleCommandItemRemoveAll(p75)
	local v76 = p75:deleteAll() + p75.mission.vehicleSystem:deleteAllPallets()
	return string.format("Deleted %i item(s)!", v76)
end

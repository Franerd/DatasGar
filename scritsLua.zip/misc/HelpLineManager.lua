HelpLineManager = {}
source("dataS/scripts/misc/HelpLineActivatable.lua")
local v_u_1 = Class(HelpLineManager, AbstractManager)
HelpLineManager.ITEM_TYPE = {
	["TEXT"] = "text",
	["IMAGE"] = "image"
}
HelpLineManager.SLICE_PREFIX = "helpline"
HelpLineManager.CUSTOMENV_BASEGAME = ""
function HelpLineManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function HelpLineManager.initDataStructures(p3)
	p3.customEnvironmentNames = { HelpLineManager.CUSTOMENV_BASEGAME }
	p3.customEnvironmentToCategory = {}
	p3.customEnvironmentToCategory[HelpLineManager.CUSTOMENV_BASEGAME] = {}
	p3.idToCategoryPageIndex = {}
	p3.categoryNames = {}
	p3.triggers = {}
	p3.triggerNodeToData = {}
	p3.zones = {}
	p3.sharedLoadingIds = {}
	p3.helpData = nil
	p3.idToIndices = {}
end
function HelpLineManager.loadMapData(p_u_4, p5, p6)
	HelpLineManager:superClass().loadMapData(p_u_4)
	local v7 = getXMLString(p5, "map.helpline#filename")
	if v7 == nil then
		Logging.xmlInfo(p5, "No helpline defined for map")
		return false
	end
	local v8 = Utils.getFilename(v7, g_currentMission.baseDirectory)
	if v8 == nil or (v8 == "" or not fileExists(v8)) then
		Logging.xmlError(p5, "Could not load helpline config file \'" .. tostring(v7) .. "\'!")
		return false
	end
	p_u_4:loadFromXML(v8, p6)
	local v9 = getXMLString(p5, "map.helpline#additionalFilename")
	if v9 ~= nil then
		p_u_4:loadFromXML(Utils.getFilename(v9, g_currentMission.baseDirectory), p6)
	end
	for v10, v11 in pairs(p_u_4.customEnvironmentToCategory) do
		local v12 = string.isNilOrWhitespace(v10) and "" or v10 .. "."
		for v13, v14 in ipairs(v11) do
			local v15 = v14.id
			if v15 ~= nil then
				local v16 = v12 .. v15
				if p_u_4.idToCategoryPageIndex[v16] == nil then
					p_u_4.idToCategoryPageIndex[v16] = {
						["customEnvironment"] = v10,
						["categoryIndex"] = v13,
						["pageIndex"] = 0
					}
				else
					Logging.xmlWarning(p5, "Category Id \'%s\' already used. Ignoring id for category name \'%s\'!", v16, v14.title)
				end
			end
			for v17, v18 in ipairs(v14.pages) do
				local v19 = v18.id
				if v19 ~= nil then
					local v20 = v12 .. v19
					if p_u_4.idToCategoryPageIndex[v20] == nil then
						p_u_4.idToCategoryPageIndex[v20] = {
							["customEnvironment"] = v10,
							["categoryIndex"] = v13,
							["pageIndex"] = v17
						}
					else
						Logging.xmlWarning(p5, "Page Id \'%s\' already used. Ignoring id for page name \'%s\'!", v20, v18.title)
					end
				end
			end
		end
	end
	local v21 = XMLFile.wrap(p5, nil)
	local function v32(p22, p23)
		-- upvalues: (copy) p_u_4
		local v24 = p22:getFilename()
		local v25, _ = Utils.getModNameAndBaseDirectory(v24)
		local v26 = p22:getString(p23 .. "#helpId")
		if v26 ~= nil then
			local v27 = p_u_4.idToCategoryPageIndex[v26]
			if v27 == nil and v25 ~= nil then
				local v28 = v25 .. "." .. v26
				v27 = p_u_4.idToCategoryPageIndex[v28]
			end
			if v27 ~= nil then
				return v27.categoryIndex, v27.pageIndex, v25
			end
			Logging.xmlWarning(p22, "No help line item defined for helpId \'%s\'", v26)
			return 1, 1
		end
		local v29 = p22:getString(p23 .. "#categoryId")
		if v29 == nil then
			return p22:getInt(p23 .. "#categoryIndex", 1), p22:getInt(p23 .. "#pageIndex", 1), v25
		end
		local v30 = p_u_4.idToCategoryPageIndex[v29]
		if v30 == nil and v25 ~= nil then
			local v31 = v25 .. "." .. v29
			v30 = p_u_4.idToCategoryPageIndex[v31]
		end
		if v30 ~= nil then
			return v30.categoryIndex, v30.pageIndex, v25
		end
		Logging.xmlWarning(p22, "No help line item defined for categoryId \'%s\'", v29)
		return 1, 1
	end
	for _, v33 in v21:iterator("map.helpline.trigger") do
		local v34 = v21:getVector(v33 .. "#position", nil, 3)
		if v34 == nil then
			Logging.xmlWarning(v21, "Missing helpline trigger position for \'%s\'", v33)
		else
			local v35, v36, v37 = v32(v21, v33)
			local v38 = {
				["position"] = v34,
				["categoryIndex"] = v35,
				["pageIndex"] = v36
			}
			local v39 = p_u_4.customEnvironmentToCategory[v37]
			if v39 == nil then
				Logging.xmlWarning(v21, "No categories found for custom environment \'%s\' for \'%s\'", v37, v33)
			else
				local v40 = v39[v38.categoryIndex]
				if v40 == nil then
					Logging.xmlWarning(v21, "Invalid helpline trigger category index \'%d\' for \'%s\'", v35, v33)
				elseif v40.pages[v38.pageIndex] == nil then
					Logging.xmlWarning(v21, "Invalid helpline trigger page index \'%d\' for category \'%d\' for \'%s\'", v38.pageIndex, v35, v33)
				else
					local v41 = g_i3DManager:loadSharedI3DFileAsync("data/objects/helpIcon/icon.i3d", false, false, HelpLineManager.onIconLoaded, p_u_4, v38)
					local v42 = p_u_4.sharedLoadingIds
					table.insert(v42, v41)
				end
			end
		end
	end
	for _, v43 in v21:iterator("map.helpline.zone") do
		local v44 = v21:getVector(v43 .. "#position", nil, 3)
		if v44 ~= nil then
			local v45, v46, v47 = v32(v21, v43)
			local v48 = {
				["position"] = v44,
				["radius"] = v21:getFloat(v43 .. "#radius", 50),
				["categoryIndex"] = v45,
				["pageIndex"] = v46,
				["customEnvironment"] = v47
			}
			local v49 = p_u_4.zones
			table.insert(v49, v48)
		end
	end
	v21:delete()
	p_u_4.activatable = HelpLineActivatable.new()
	return true
end
function HelpLineManager.unloadMapData(p50)
	p50.helpData = nil
	g_currentMission.activatableObjectsSystem:removeActivatable(p50.activatable)
	for _, v51 in ipairs(p50.sharedLoadingIds) do
		g_i3DManager:releaseSharedI3DFile(v51)
	end
	for _, v52 in ipairs(p50.triggers) do
		g_currentMission:removeHelpTrigger(v52.node)
		removeTrigger(v52.triggerNode)
		delete(v52.node)
	end
	HelpLineManager:superClass().unloadMapData(p50)
end
function HelpLineManager.onIconLoaded(p53, p54, _, p55)
	if p54 ~= 0 then
		p55.node = p54
		p55.triggerNode = getChildAt(getChildAt(p54, 0), 0)
		p53.triggerNodeToData[p55.triggerNode] = p55
		link(getRootNode(), p54)
		addTrigger(p55.triggerNode, "onIconTrigger", p53)
		setWorldTranslation(p54, p55.position[1], p55.position[2], p55.position[3])
		addToPhysics(p54)
		local v56 = p53.triggers
		table.insert(v56, p55)
		g_currentMission:addHelpTrigger(p55.node)
	end
end
function HelpLineManager.onIconTrigger(p57, p58, _, p59, p60, _)
	local v61 = p57.triggerNodeToData[p58]
	if v61 ~= nil then
		if p59 then
			p57.helpData = v61
			g_currentMission.activatableObjectsSystem:addActivatable(p57.activatable)
			return
		end
		if p60 then
			p57.helpData = nil
			g_currentMission.activatableObjectsSystem:removeActivatable(p57.activatable)
		end
	end
end
function HelpLineManager.loadFromXML(p62, p63, p64)
	local v65, v66 = Utils.getModNameAndBaseDirectory(p63)
	local v67 = XMLFile.load("helpLineViewContentXML", p63)
	if v67 ~= nil then
		for _, v68 in v67:iterator("helpLines.category") do
			local v69 = p62:loadCategory(v67, v68, p64, v65, v66)
			if v69 ~= nil then
				v65 = v65 or HelpLineManager.CUSTOMENV_BASEGAME
				local v70 = p62.customEnvironmentToCategory[v65]
				if v70 == nil then
					v70 = {}
					p62.customEnvironmentToCategory[v65] = v70
					local v71 = p62.customEnvironmentNames
					table.insert(v71, v65)
				end
				table.insert(v70, v69)
			end
		end
		v67:delete()
	end
end
function HelpLineManager.addModCategory(p72, p73, p74, p75, p76)
	local v77 = p72:loadCategory(p73, p74, nil, p76, p75)
	if v77 ~= nil then
		local v78 = p72.customEnvironmentToCategory[p76]
		if v78 == nil then
			v78 = {}
			p72.customEnvironmentToCategory[p76] = v78
			local v79 = p72.customEnvironmentNames
			table.insert(v79, p76)
		end
		table.insert(v78, v77)
	end
end
function HelpLineManager.loadCategory(p80, p81, p82, p83, p84, p85)
	local v86 = {
		["title"] = p81:getString(p82 .. "#title"),
		["customEnvironment"] = p84,
		["pages"] = {}
	}
	local v87 = p81:getString(p82 .. "#id")
	if v87 ~= nil then
		if not string.isNilOrWhitespace(p84) then
			v87 = p84 .. "." .. v87
		end
		v86.id = v87
	end
	for _, v88 in p81:iterator(p82 .. ".page") do
		local v89 = p80:loadPage(p81, v88, p83, p84, p85)
		local v90 = v86.pages
		table.insert(v90, v89)
	end
	return v86
end
function HelpLineManager.loadPage(_, p91, p92, _, p93, p94)
	local v95 = {
		["title"] = p91:getString(p92 .. "#title"),
		["customEnvironment"] = p93,
		["baseDirectory"] = p94,
		["iconFilename"] = p91:getString(p92 .. "#iconFilename")
	}
	local v96 = p91:getString(p92 .. "#iconSliceId")
	if v96 ~= nil and v96 ~= "" then
		v95.iconSliceId = HelpLineManager.SLICE_PREFIX .. "." .. v96
	end
	local v97 = p91:getString(p92 .. "#id")
	if v97 ~= nil then
		if p93 ~= nil then
			v97 = p93 .. "." .. v97
		end
		v95.id = v97
	end
	v95.paragraphs = {}
	for _, v98 in p91:iterator(p92 .. ".paragraph") do
		local v99 = {
			["title"] = p91:getString(v98 .. ".title#text"),
			["text"] = p91:getString(v98 .. ".text#text"),
			["alignToImage"] = p91:getBool(v98 .. ".text#alignToImage"),
			["customEnvironment"] = p93,
			["noSpacing"] = p91:getBool(v98 .. "#noSpacing")
		}
		local v100 = p91:getString(v98 .. ".image#filename")
		if v100 ~= nil then
			local v101 = p91:getFloat(v98 .. ".image#heightScale", 1)
			local v102 = p91:getFloat(v98 .. ".image#aspectRatio", 1)
			local v103 = string.getVector(p91:getString(v98 .. ".image#size"), 2) or { 1024, 1024 }
			v99.image = {
				["filename"] = v100,
				["uvs"] = GuiUtils.getUVs(p91:getString(v98 .. ".image#uvs", "0 0 1 1"), v103),
				["size"] = v103,
				["heightScale"] = v101,
				["aspectRatio"] = v102,
				["displaySize"] = GuiUtils.getNormalizedScreenValues(p91:getString(v98 .. ".image#displaySize"))
			}
		end
		local v104 = v95.paragraphs
		table.insert(v104, v99)
	end
	return v95
end
function HelpLineManager.convertText(_, p105, p106)
	local v107 = g_i18n:convertText(p105, p106)
	return string.gsub(v107, "$CURRENCY_SYMBOL", g_i18n:getCurrencySymbol(true))
end
function HelpLineManager.getCategories(p108, p109)
	local v110 = p109 or HelpLineManager.CUSTOMENV_BASEGAME
	return p108.customEnvironmentToCategory[v110]
end
function HelpLineManager.getCustomEnvironmentNames(p111)
	return p111.customEnvironmentNames
end
function HelpLineManager.getCategory(p112, p113, p114)
	if p114 == nil then
		return nil
	else
		local v115 = p113 or HelpLineManager.CUSTOMENV_BASEGAME
		local v116 = p112.customEnvironmentToCategory[v115]
		if v116 == nil then
			return nil
		else
			return v116[p114]
		end
	end
end
function HelpLineManager.getContextBasedHelp(p117, p118, p119, p120)
	local v121 = (1 / 0)
	local v122 = nil
	local v123 = nil
	for _, v124 in ipairs(p117.zones) do
		local v125 = v124.position
		local v126, v127, v128 = unpack(v125)
		local v129 = MathUtil.vector3Length(v126 - p118, v127 - p119, v128 - p120)
		if v129 <= v124.radius and v129 < v121 then
			v122 = v124.categoryIndex
			v123 = v124.pageIndex
		end
	end
	return v122, v123
end
function HelpLineManager.getIsContextBasedHelpAvailable(p130, p131, p132, p133)
	local v134, _ = p130:getContextBasedHelp(p131, p132, p133)
	return v134 ~= nil
end
function HelpLineManager.openContextBasedHelp(p135, p136, p137, p138)
	local v139, v140 = p135:getContextBasedHelp(p136, p137, p138)
	g_gui:showGui("InGameMenu")
	g_messageCenter:publish(MessageType.GUI_INGAME_OPEN_HELP_SCREEN, v139, v140)
end
g_helpLineManager = HelpLineManager.new()

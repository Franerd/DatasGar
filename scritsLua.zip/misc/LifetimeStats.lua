LifetimeStats = {}
LifetimeStats.MS_TO_HOUR = 2.7777777777777776e-7
LifetimeStats.SAVE_PERIOD = 60000
local v_u_1 = Class(LifetimeStats)
function LifetimeStats.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1 or p2
	local v4 = setmetatable({}, v3)
	v4.xmlFilename = Utils.getFilename("lifetimeStats.xml", getUserProfileAppPath())
	v4.saveTimer = LifetimeStats.SAVE_PERIOD
	v4.totalRuntimeUpToStart = 0
	v4.gameRateMessagesShown = 0
	v4.runtimeSinceLoad = 0
	return v4
end
function LifetimeStats.delete(_) end
function LifetimeStats.load(p5)
	if GS_PLATFORM_PHONE then
		if fileExists(p5.xmlFilename) then
			local v6 = loadXMLFile("lifetimeStats", p5.xmlFilename)
			p5.totalRuntimeUpToStart = Utils.getNoNil(getXMLFloat(v6, "lifetimeStats.totalRuntime"), p5.totalRuntimeUpToStart)
			p5.gameRateMessagesShown = Utils.getNoNil(getXMLInt(v6, "lifetimeStats.gameRateMessagesShown"), p5.gameRateMessagesShown)
			p5.runtimeSinceLoad = g_time
			delete(v6)
		end
	end
end
function LifetimeStats.save(p7)
	if GS_PLATFORM_ID == PlatformId.IOS or GS_PLATFORM_ID == PlatformId.ANDROID then
		local v8 = createXMLFile("lifetimeStats", p7.xmlFilename, "lifetimeStats")
		if v8 == 0 then
			Logging.error("Failed to create lifetimeStats xml file")
		else
			setXMLFloat(v8, "lifetimeStats.totalRuntime", p7:getTotalRuntime())
			setXMLInt(v8, "lifetimeStats.gameRateMessagesShown", p7.gameRateMessagesShown)
			saveXMLFile(v8)
			delete(v8)
			p7.saveTimer = LifetimeStats.SAVE_PERIOD
		end
	else
		return
	end
end
function LifetimeStats.reload(p9)
	p9.totalRuntimeUpToStart = 0
	p9.gameRateMessagesShown = 0
	p9:load()
end
function LifetimeStats.update(p10, p11)
	p10.saveTimer = p10.saveTimer - p11
	if p10.saveTimer < 0 then
		p10.saveTimer = LifetimeStats.SAVE_PERIOD
		p10:save()
	end
end
function LifetimeStats.getTotalRuntime(p12)
	return g_time * LifetimeStats.MS_TO_HOUR + p12.totalRuntimeUpToStart - p12.runtimeSinceLoad
end

TreePlantManager = {}
TreePlantManager.DECAY_INTERVAL = 60000
TreePlantManager.DECAY_DURATION = 7200000
TreePlantManager.DECAY_DURATION_INV = 1 / TreePlantManager.DECAY_DURATION
TreePlantManager.MAX_NUM_TYPES = 255
TreePlantManager.STAGE_NUM_BITS = 5
TreePlantManager.MAX_NUM_STAGES = TreePlantManager.STAGE_NUM_BITS ^ 2 - 1
TreePlantManager.VARIATION_NUM_BITS = 3
TreePlantManager.MAX_NUM_VARIATIONS_PER_STAGE = TreePlantManager.VARIATION_NUM_BITS ^ 2 - 1
local v_u_1 = Class(TreePlantManager, AbstractManager)
g_xmlManager:addInitSchemaFunction(function()
	local v2 = Mission00.xmlSchema
	v2:register(XMLValueType.STRING, "map.treeTypes#filename", "")
	v2:register(XMLValueType.INT, "map.treeTypes#maxNumTrees", "", 8000)
end)
function TreePlantManager.new(p3)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p3 or v_u_1)
end
function TreePlantManager.initDataStructures(p4)
	p4.treeTypes = {}
	p4.indexToTreeType = {}
	p4.splitTypeIndexToTreeType = {}
	p4.nameToTreeType = {}
	p4.treeFileCache = {}
	p4.loadTreeTrunkDatas = {}
	p4.numTreesWithoutSplits = 0
	p4.activeDecayingSplitShapes = {}
	p4.updateDecayDtGame = 0
end
function TreePlantManager.initialize(p5)
	local v6 = createTransformGroup("trees")
	link(getRootNode(), v6)
	p5.treesData = {}
	p5.treesData.rootNode = v6
	p5.treesData.growingTrees = {}
	p5.treesData.splitTrees = {}
	p5.treesData.clientTrees = {}
	p5.treesData.updateDtGame = 0
	p5.treesData.treeCutJoints = {}
	p5.treesData.numTreesWithoutSplits = 0
end
function TreePlantManager.deleteTreesData(p7)
	if p7.treesData ~= nil then
		delete(p7.treesData.rootNode)
		local v8 = p7.numTreesWithoutSplits - p7.treesData.numTreesWithoutSplits
		p7.numTreesWithoutSplits = math.max(v8, 0)
		p7:initDataStructures()
	end
end
function TreePlantManager.loadDefaultTypes(p9, p10, p11)
	local v12 = loadXMLFile("treeTypes", "data/maps/maps_treeTypes.xml")
	p9:loadTreeTypes(v12, p10, p11, true)
	delete(v12)
end
function TreePlantManager.loadMapData(p13, p14, p15, p16)
	TreePlantManager:superClass().loadMapData(p13)
	if g_server ~= nil and g_addCheatCommands then
		addConsoleCommand("gsTreeCut", "Cut all trees around a given radius", "consoleCommandCutTrees", p13)
		addConsoleCommand("gsTreeAdd", "Load a loose tree trunk", "consoleCommandLoadTree", p13, "length; treeType; [growthState]; [delimb]")
		addConsoleCommand("gsTreePlant", "Plant given number of trees of a specified type", "consoleCommandPlantTrees", p13, "treeType; number; growthState; variationIndex; isGrowing")
		addConsoleCommand("gsTreeLoadAll", "Spawn all trees in front of player", "consoleCommandLoadAll", p13)
		addConsoleCommand("gsTreeDebug", "Toggle tree/splitshape debug mode", "consoleCommandDebug", p13)
	end
	local v17 = getXMLInt(p14, "map.treeTypes#maxNumTrees") or 8000
	p13.maxNumTrees = math.clamp(v17, 1, 30000)
	g_messageCenter:subscribeOneshot(MessageType.CURRENT_MISSION_START, TreePlantManager.onMissionStarted, p13)
	p13:loadDefaultTypes(p15, p16)
	return XMLUtil.loadDataFromMapXML(p14, "treeTypes", p16, p13, p13.loadTreeTypes, p15, p16)
end
function TreePlantManager.unloadMapData(p18)
	for v19, v20 in pairs(p18.treeFileCache) do
		g_i3DManager:releaseSharedI3DFile(v20)
		p18.treeFileCache[v19] = true
	end
	removeConsoleCommand("gsTreeCut")
	removeConsoleCommand("gsTreeAdd")
	removeConsoleCommand("gsTreePlant")
	removeConsoleCommand("gsTreeDebug")
	p18:deleteTreesData()
	g_messageCenter:unsubscribe(MessageType.CURRENT_MISSION_START, p18)
	TreePlantManager:superClass().unloadMapData(p18)
end
function TreePlantManager.onMissionStarted(p21, _)
	local v22, _ = getNumOfSplitShapes()
	Logging.devInfo("TreePlantManager - NumTrees %d / MaxNumTrees: %d", v22, p21.maxNumTrees)
end
function TreePlantManager.loadTreeTypes(p23, p24, _, p25, p26, p27)
	if type(p24) == "number" then
		p24 = XMLFile.wrap(p24)
	end
	for _, v28 in p24:iterator("map.treeTypes.treeType") do
		local v29 = p24:getString(v28 .. "#name")
		local v30 = p24:getString(v28 .. "#title")
		local v31 = p24:getString(v28 .. "#growthTimeHours")
		local v32 = p24:getString(v28 .. "#splitType")
		local v33 = p24:getFloat(v28 .. "#saplingPrice", 0)
		if v29 == nil then
			Logging.xmlWarning(p24, "Missing \'name\' attribute for treeType %q", v28)
		elseif v30 == nil then
			Logging.xmlWarning(p24, "Missing \'title\' attribute for treeType %q", v28)
		elseif v31 == nil then
			Logging.xmlWarning(p24, "Missing \'growthTimeHours\' attribute for treeType %q", v28)
		elseif v32 == nil then
			Logging.xmlWarning(p24, "Missing \'splitType\' attribute for treeType %q", v28)
		else
			local v34 = g_splitShapeManager:getSplitTypeIndexByName(v32)
			if v34 == nil then
				Logging.xmlWarning(p24, "SplitType \'%s\' not defined for treeType %q", v32, v28)
			else
				local v35 = {}
				for _, v36 in p24:iterator(v28 .. ".stage") do
					local v37 = p24:getString(v36 .. "#filename")
					if v37 == nil then
						local v38 = {}
						for _, v39 in p24:iterator(v36 .. ".variation") do
							local v40 = p24:getString(v39 .. "#filename")
							if v40 ~= nil then
								if #v38 >= TreePlantManager.MAX_NUM_VARIATIONS_PER_STAGE then
									Logging.xmlWarning(p24, "Unable to add variation %q for tree %q, max number of variations per stage (%d) reached", v40, v29, TreePlantManager.MAX_NUM_VARIATIONS_PER_STAGE)
									break
								end
								local v41 = {
									["name"] = p24:getString(v39 .. "#name"),
									["filename"] = Utils.getFilename(v40, p25)
								}
								local v42 = p24:getString(v39 .. ".pallet#filename")
								if v42 ~= nil then
									v41.palletFilename = Utils.getFilename(v42, p25)
								end
								local v43 = p24:getString(v39 .. ".pallet#storeItem")
								if v43 ~= nil then
									v41.palletStoreItemFilename = Utils.getFilename(v43, p25)
								end
								local v44 = p24:getString(v39 .. ".planter#filename")
								if v44 ~= nil then
									v41.planterFilename = Utils.getFilename(v44, p25)
								end
								table.insert(v38, v41)
							end
						end
						if #v35 >= TreePlantManager.MAX_NUM_STAGES then
							Logging.xmlWarning(p24, "Unable to add stage %q for tree %q, max number of stages (%d) reached", v36, v29, TreePlantManager.MAX_NUM_STAGES)
						end
						table.insert(v35, v38)
					else
						local v45 = {
							["filename"] = Utils.getFilename(v37, p25)
						}
						local v46 = p24:getString(v36 .. ".pallet#filename")
						if v46 ~= nil then
							v45.palletFilename = Utils.getFilename(v46, p25)
						end
						local v47 = p24:getString(v36 .. ".pallet#storeItem")
						if v47 ~= nil then
							v45.palletStoreItemFilename = Utils.getFilename(v47, p25)
						end
						local v48 = p24:getString(v36 .. ".planter#filename")
						if v48 ~= nil then
							v45.planterFilename = Utils.getFilename(v48, p25)
						end
						table.insert(v35, { v45 })
					end
				end
				if #v35 == 0 then
					Logging.xmlWarning(p24, "A treetype %q (%s) has no valid stages defined\'", v29, v28)
				else
					p23:registerTreeType(v29, g_i18n:convertText(v30, p27), v35, v31, p26, v34, v33)
				end
			end
		end
	end
	return true
end
function TreePlantManager.registerTreeType(p49, p50, p51, p52, p53, p54, p55, p56)
	local v57 = string.upper(p50)
	if #p49.treeTypes >= TreePlantManager.MAX_NUM_TYPES then
		Logging.warning("Unable to register tree type %q, maximum number of tree types (%d) reached", v57, TreePlantManager.MAX_NUM_TYPES)
		return nil
	end
	if p54 and p49.nameToTreeType[v57] ~= nil then
		Logging.warning("TreeType %q already exists. Ignoring treeType!", v57)
		return nil
	end
	local v58 = p49.nameToTreeType[v57]
	if v58 == nil then
		v58 = {
			["name"] = v57,
			["title"] = p51,
			["index"] = #p49.treeTypes + 1,
			["splitTypeIndex"] = p55
		}
		local v59 = p49.treeTypes
		table.insert(v59, v58)
		p49.indexToTreeType[v58.index] = v58
		p49.nameToTreeType[v57] = v58
		p49.splitTypeIndexToTreeType[p55] = v58
	end
	v58.stages = p52
	v58.growthTimeHours = p53
	v58.saplingPrice = p56
	return v58
end
function TreePlantManager.getTreeTypeFilename(_, p60, p61)
	if p60 == nil then
		return nil
	end
	local v62 = p60.stages
	local v63 = #p60.stages
	local v64 = v62[math.min(p61, v63)]
	return v64[math.random(1, #v64)].filename
end
function TreePlantManager.canPlantTree(p65)
	local v66, v67 = getNumOfSplitShapes()
	return v66 - v67 + p65.numTreesWithoutSplits < p65.maxNumTrees
end
function TreePlantManager.plantTree(p68, p69, p70, p71, p72, p73, p74, p75, p76, p77, p78, p79, p80)
	local v81 = p68.indexToTreeType[p69]
	if v81 == nil then
		return nil
	end
	local v82, v83 = p68:loadTreeNode(v81, p70, p71, p72, p73, p74, p75, p76, p77, p80)
	if v82 == 0 then
		return nil
	end
	local v84 = p68.treesData
	local v85 = {
		["node"] = v82,
		["growthStateI"] = p76,
		["variationIndex"] = p77 or 1
	}
	local v86 = Utils.getNoNil(p78, true)
	if v86 then
		v86 = p76 < #v81.stages
	end
	v85.isGrowing = v86
	v85.x = p70
	v85.y = p71
	v85.z = p72
	v85.rx = p73
	v85.ry = p74
	v85.rz = p75
	v85.treeType = p69
	v85.splitShapeFileId = v83
	v85.hasSplitShapes = getFileIdHasSplitShapes(v83)
	if v85.isGrowing then
		v85.origSplitShape = getChildAt(v82, 0)
		if p79 == nil then
			v85.nextGrowthTargetHour = g_currentMission.environment:getMonotonicHour() + v81.growthTimeHours
		else
			v85.nextGrowthTargetHour = p79
		end
		local v87 = v84.growingTrees
		table.insert(v87, v85)
	else
		local v88 = v84.splitTrees
		table.insert(v88, v85)
	end
	if not v85.hasSplitShapes then
		p68.numTreesWithoutSplits = p68.numTreesWithoutSplits + 1
		v84.numTreesWithoutSplits = v84.numTreesWithoutSplits + 1
	end
	g_server:broadcastEvent(TreePlantEvent.new(p69, p70, p71, p72, p73, p74, p75, p76, v85.variationIndex, v83, v85.isGrowing))
	return v82
end
function TreePlantManager.loadTreeNode(p89, p_u_90, p91, p92, p93, p94, p95, p96, p97, p98, p99)
	local v100 = p89.treesData
	local v101 = #p_u_90.stages
	local v102 = math.min(p97, v101)
	local v103 = p_u_90.stages[v102]
	if v103 == nil then
		Logging.error("TreePlantManager:loadTreeNode failed due to invalid stage index (stage %d of %d)", v102, #p_u_90.stages)
		return 0
	end
	local v104 = v103[p98]
	if v104 == nil then
		Logging.error("TreePlantManager:loadTreeNode failed due to invalid variation index (index %d of %d)", p98, #v103)
		return 0
	end
	local v_u_105 = v104.filename
	if p89.treeFileCache[v_u_105] == nil then
		setSplitShapesLoadingFileId(-1)
		setSplitShapesNextFileId(true)
		local v106, v107 = g_i3DManager:loadSharedI3DFile(v_u_105, false, false)
		if v106 ~= 0 then
			delete(v106)
			p89.treeFileCache[v_u_105] = v107
		end
	end
	setSplitShapesLoadingFileId(p99 or -1)
	local v108 = setSplitShapesNextFileId()
	local v109, v110 = g_i3DManager:loadSharedI3DFile(v_u_105, false, false)
	g_i3DManager:releaseSharedI3DFile(v110)
	if v109 ~= 0 then
		link(v100.rootNode, v109)
		setTranslation(v109, p91, p92, p93)
		setRotation(v109, p94, p95, p96)
		for v111 = 0, getNumOfChildren(v109) - 1 do
			local v112 = getChildAt(v109, v111)
			if getHasClassId(v112, ClassIds.MESH_SPLIT_SHAPE) and getIsSplitShapeSplit(v112) then
				setWorldRotation(v112, getRotation(v112))
				setWorldTranslation(v112, getTranslation(v112))
			end
		end
		I3DUtil.iterateRecursively(v109, function(p113, _)
			-- upvalues: (copy) p_u_90, (copy) v_u_105
			if getHasClassId(p113, ClassIds.MESH_SPLIT_SHAPE) then
				local v114 = getSplitType(p113)
				if v114 ~= p_u_90.splitTypeIndex then
					Logging.warning("Tree has wrong splitType \'%s\' assigned. Should be \'%s\'. File: \'%s\'", v114, p_u_90.splitTypeIndex, v_u_105)
				end
			end
			return true
		end)
		addToPhysics(v109)
	end
	g_densityMapHeightManager:setCollisionMapAreaDirty(p91 - 2, p93 - 2, p91 + 2, p93 + 2, true)
	g_currentMission.aiSystem:setAreaDirty(p91 - 2, p91 + 2, p93 - 2, p93 + 2)
	return v109, v108
end
function TreePlantManager.loadTreeTrunk(p115, p116, p117, p118, p119, p120, p121, p122, p123, p124, p125, p126, p127)
	local v128, v129 = g_treePlantManager:loadTreeNode(p116, p117, p118, p119, 0, 0, 0, p124, p125)
	if v128 ~= 0 then
		if getFileIdHasSplitShapes(v129) then
			local v130 = {
				["node"] = v128,
				["growthStateI"] = p124,
				["variationIndex"] = p125,
				["x"] = p117,
				["y"] = p118,
				["z"] = p119,
				["rx"] = 0,
				["ry"] = 0,
				["rz"] = 0,
				["treeType"] = p116.index,
				["splitShapeFileId"] = v129,
				["hasSplitShapes"] = getFileIdHasSplitShapes(v129)
			}
			local v131 = p115.treesData.splitTrees
			table.insert(v131, v130)
			local v132 = {
				["framesLeft"] = 2,
				["shape"] = v128 + 2,
				["x"] = p117,
				["y"] = p118,
				["z"] = p119,
				["length"] = p123,
				["offset"] = 0.5,
				["dirX"] = p120,
				["dirY"] = p121,
				["dirZ"] = p122,
				["delimb"] = p126,
				["useOnlyStump"] = p127,
				["cutTreeTrunkCallback"] = TreePlantManager.cutTreeTrunkCallback
			}
			local v133 = p115.loadTreeTrunkDatas
			table.insert(v133, v132)
			return
		end
		delete(v128)
	end
end
function TreePlantManager.cutTreeTrunkCallback(p134, p135, p136, p137, p138, p139, p140, p141)
	g_treePlantManager:addingSplitShape(p135, p134.shapeBeingCut)
	local v142 = p134.parts
	table.insert(v142, {
		["shape"] = p135,
		["isBelow"] = p136,
		["isAbove"] = p137,
		["minY"] = p138,
		["maxY"] = p139,
		["minZ"] = p140,
		["maxZ"] = p141
	})
end
function TreePlantManager.updateTrees(p143, _, p144)
	local v145 = p143.treesData
	v145.updateDtGame = v145.updateDtGame + p144
	if v145.updateDtGame > 3600000 then
		p143:cleanupDeletedTrees()
		v145.updateDtGame = 0
		local v146 = g_currentMission.environment:getMonotonicHour()
		local v147 = #v145.growingTrees
		local v148 = 1
		while v148 <= v147 do
			local v149 = v145.growingTrees[v148]
			if getChildAt(v149.node, 0) == v149.origSplitShape then
				local v150 = p143.indexToTreeType[v149.treeType]
				local v151 = #v150.stages
				if v149.nextGrowthTargetHour < v146 then
					local v152 = v149.growthStateI + 1
					local v153 = #v150.stages
					local v154 = math.min(v152, v153)
					if p143.debugActive then
						Logging.info("growing tree %s from stage %d to %d", v150.name, v149.growthStateI, v154)
					end
					v149.growthStateI = v154
					if v151 <= v149.growthStateI then
						v149.nextGrowthTargetHour = nil
					else
						v149.nextGrowthTargetHour = v146 + v150.growthTimeHours
					end
					delete(v149.node)
					if not v149.hasSplitShapes then
						local v155 = p143.numTreesWithoutSplits - 1
						p143.numTreesWithoutSplits = math.max(v155, 0)
						local v156 = v145.numTreesWithoutSplits - 1
						v145.numTreesWithoutSplits = math.max(v156, 0)
					end
					local v157 = v150.stages[v149.growthStateI]
					local v158 = math.random(1, #v157)
					local v159, v160 = p143:loadTreeNode(v150, v149.x, v149.y, v149.z, v149.rx, v149.ry, v149.rz, v149.growthStateI, v158, -1)
					g_server:broadcastEvent(TreeGrowEvent.new(v149.treeType, v149.x, v149.y, v149.z, v149.rx, v149.ry, v149.rz, v149.growthStateI, v158, v160, v149.splitShapeFileId))
					v149.origSplitShape = getChildAt(v159, 0)
					v149.splitShapeFileId = v160
					v149.hasSplitShapes = getFileIdHasSplitShapes(v160)
					v149.node = v159
					local v161, _, v162 = getWorldTranslation(v159)
					g_densityMapHeightManager:setCollisionMapAreaDirty(v161 - 2.5, v162 - 2.5, v161 + 2.5, v162 + 2.5, true)
					g_currentMission.aiSystem:setAreaDirty(v161 - 2.5, v161 + 2.5, v162 - 2.5, v162 + 2.5)
					if not v149.hasSplitShapes then
						p143.numTreesWithoutSplits = p143.numTreesWithoutSplits + 1
						v145.numTreesWithoutSplits = v145.numTreesWithoutSplits + 1
					end
				end
				if v151 <= v149.growthStateI then
					if p143.debugActive then
						Logging.info("Removing fully grown tree %d (%s stage %d) from growth", v149.node, v150.name, v149.growthStateI)
					end
					table.remove(v145.growingTrees, v148)
					v147 = v147 - 1
					v149.origSplitShape = nil
					local v163 = v145.splitTrees
					table.insert(v163, v149)
				else
					v148 = v148 + 1
				end
			else
				if p143.debugActive then
					Logging.info("Removing cut tree %d from growing trees", v149.node)
				end
				table.remove(v145.growingTrees, v148)
				v147 = v147 - 1
				v149.origSplitShape = nil
				local v164 = v145.splitTrees
				table.insert(v164, v149)
			end
		end
	end
	local v165 = g_currentMission.time
	for v166 in pairs(v145.treeCutJoints) do
		if v166.destroyTime <= v165 or not entityExists(v166.shape) then
			removeJoint(v166.jointIndex)
			v145.treeCutJoints[v166] = nil
		else
			local v167, v168, v169 = localDirectionToWorld(v166.shape, v166.lnx, v166.lny, v166.lnz)
			if v167 * v166.nx + v168 * v166.ny + v169 * v166.nz < v166.maxCosAngle then
				removeJoint(v166.jointIndex)
				v145.treeCutJoints[v166] = nil
			end
		end
	end
	if #p143.loadTreeTrunkDatas > 0 then
		for v170 = #p143.loadTreeTrunkDatas, 1, -1 do
			local v171 = p143.loadTreeTrunkDatas[v170]
			v171.framesLeft = v171.framesLeft - 1
			if v171.framesLeft == 1 then
				local v172 = v171.x + 1
				local v173 = v171.y
				local v174 = v171.z - 1
				v171.parts = {}
				local v175 = v171.shape
				if v175 ~= nil and v175 ~= 0 then
					v171.shapeBeingCut = v175
					splitShape(v175, v172, v173 + v171.length + v171.offset, v174, 0, 1, 0, -1, 0, 0, 4, 4, "cutTreeTrunkCallback", v171)
					p143:removingSplitShape(v175)
					for _, v176 in pairs(v171.parts) do
						if v176.isAbove then
							delete(v176.shape)
						else
							v171.shape = v176.shape
						end
					end
				end
			elseif v171.framesLeft == 0 then
				local v177 = v171.x + 1
				local v178 = v171.y
				local v179 = v171.z - 1
				v171.parts = {}
				local v180 = v171.shape
				if v180 ~= nil and v180 ~= 0 then
					splitShape(v180, v177, v178 + v171.offset, v179, 0, 1, 0, -1, 0, 0, 5, 5, "cutTreeTrunkCallback", v171)
					if v171.useOnlyStump then
						for _, v181 in pairs(v171.parts) do
							if not v181.isBelow then
								delete(v181.shape)
							end
						end
					else
						local v182 = nil
						for _, v183 in pairs(v171.parts) do
							if v183.isBelow then
								delete(v183.shape)
							else
								v182 = v183.shape
							end
						end
						if v182 == nil then
							Logging.error("Unable to cut tree trunk with length \'%s\'. Try using a different value", v171.length)
						else
							if v171.delimb then
								removeSplitShapeAttachments(v182, v177, v178 + v171.offset, v179, 0, 1, 0, -1, 0, 0, v171.length, 4, 4)
							end
							removeFromPhysics(v182)
							setDirection(v182, 0, -1, 0, v171.dirX, v171.dirY, v171.dirZ)
							addToPhysics(v182)
						end
					end
				end
				table.remove(p143.loadTreeTrunkDatas, v170)
			end
		end
	end
	if p143.commandCutTreeData ~= nil then
		if #p143.commandCutTreeData.trees > 0 then
			local v184 = p143.commandCutTreeData.trees[1]
			local v185, v186, v187 = getWorldTranslation(v184)
			local v188, v189, v190 = worldToLocal(v184, v185, v186 + 0.5, v187)
			local v191, v192, v193 = localToWorld(v184, v188 - 2, v189, v190 - 2)
			local v194, v195, v196 = localDirectionToWorld(v184, 0, 1, 0)
			local v197, v198, v199 = localDirectionToWorld(v184, 0, 0, 1)
			p143.commandCutTreeData.shapeBeingCut = v184
			Logging.info("Cut tree \'%s\' (%d left)", getName(v184), #p143.commandCutTreeData.trees - 1)
			splitShape(v184, v191, v192, v193, v194, v195, v196, v197, v198, v199, 4, 4, "onTreeCutCommandSplitCallback", p143)
			table.remove(p143.commandCutTreeData.trees, 1)
		else
			p143.commandCutTreeData = nil
		end
	end
	p143.updateDecayDtGame = p143.updateDecayDtGame + p144
	if p143.updateDecayDtGame > TreePlantManager.DECAY_INTERVAL then
		for v200, v201 in pairs(p143.activeDecayingSplitShapes) do
			if entityExists(v200) then
				if v201.state > 0 then
					local v202 = v201.state - TreePlantManager.DECAY_DURATION_INV * p143.updateDecayDtGame
					local v203 = math.max(v202, 0)
					p143:setSplitShapeLeafScaleAndVariation(v200, v203, v201.variation)
					p143.activeDecayingSplitShapes[v200].state = v203
				end
			else
				p143.activeDecayingSplitShapes[v200] = nil
			end
		end
		p143.updateDecayDtGame = 0
	end
end
function TreePlantManager.drawDebug(p204)
	if p204.treesData ~= nil and p204.treesData.growingTrees ~= nil then
		for v205, v206 in ipairs(p204.treesData.growingTrees) do
			local v207 = p204.indexToTreeType[v206.treeType]
			DebugText.renderAtNode(v206.node, string.format("growingTree #%d\ntype %s\ngrowthStateI %d\nvariation %d\nnextGrowthTargetHour %.2f", v205, v207.name, v206.growthStateI, v206.variationIndex, v206.nextGrowthTargetHour), Color.PRESETS.GREEN, 0.01)
		end
		for v208, v209 in ipairs(p204.treesData.splitTrees) do
			local v210 = p204.indexToTreeType[v209.treeType]
			DebugText.renderAtNode(v209.node, string.format("splitTree #%d\ntype %s\ngrowthStateI %d\nvariation %d\n", v208, v210.name, v209.growthStateI, v209.variationIndex), nil, 0.01)
		end
	end
end
function TreePlantManager.addTreeCutJoint(p211, p212, p213, p214, p215, p216, p217, p218)
	local v219 = p211.treesData
	local v220, v221, v222 = worldDirectionToLocal(p213, p214, p215, p216)
	local v223 = {
		["jointIndex"] = p212,
		["shape"] = p213,
		["nx"] = p214,
		["ny"] = p215,
		["nz"] = p216,
		["lnx"] = v220,
		["lny"] = v221,
		["lnz"] = v222,
		["maxCosAngle"] = math.cos(p217),
		["destroyTime"] = g_currentMission.time + p218
	}
	v219.treeCutJoints[v223] = v223
end
function TreePlantManager.cleanupDeletedTrees(p224)
	local v225 = p224.treesData
	local v226 = #v225.growingTrees
	local v227 = 1
	while v227 <= v226 do
		local v228 = v225.growingTrees[v227]
		if getNumOfChildren(v228.node) == 0 then
			table.remove(v225.growingTrees, v227)
			v226 = v226 - 1
			delete(v228.node)
			if not v228.hasSplitShapes then
				local v229 = p224.numTreesWithoutSplits - 1
				p224.numTreesWithoutSplits = math.max(v229, 0)
				local v230 = v225.numTreesWithoutSplits - 1
				v225.numTreesWithoutSplits = math.max(v230, 0)
			end
		else
			v227 = v227 + 1
		end
	end
	local v231 = #v225.splitTrees
	local v232 = 1
	while v232 <= v231 do
		local v233 = v225.splitTrees[v232]
		if getNumOfChildren(v233.node) == 0 then
			table.remove(v225.splitTrees, v232)
			v231 = v231 - 1
			delete(v233.node)
			if not v233.hasSplitShapes then
				local v234 = p224.numTreesWithoutSplits - 1
				p224.numTreesWithoutSplits = math.max(v234, 0)
				local v235 = v225.numTreesWithoutSplits - 1
				v225.numTreesWithoutSplits = math.max(v235, 0)
			end
		else
			v232 = v232 + 1
		end
	end
end
function TreePlantManager.loadFromXMLFile(p236, p237)
	if p237 == nil then
		return false
	end
	local v238 = loadXMLFile("treePlantXML", p237)
	if v238 == 0 then
		return false
	end
	local v239 = 0
	while true do
		local v240 = string.format("treePlant.tree(%d)", v239)
		if not hasXMLProperty(v238, v240) then
			break
		end
		local v241 = getXMLString(v238, v240 .. "#treeType")
		local v242 = p236.nameToTreeType[v241]
		local v243 = string.getVector(getXMLString(v238, v240 .. "#position"), 3)
		local v244 = string.getRadians(getXMLString(v238, v240 .. "#rotation"), 3)
		if #v243 == 3 and (#v244 == 3 and v242 ~= nil) then
			local v245 = getXMLInt(v238, v240 .. "#growthStateI")
			local v246 = getXMLInt(v238, v240 .. "#variationIndex") or 1
			local v247 = getXMLFloat(v238, v240 .. "#nextGrowthTargetHour")
			local v248 = Utils.getNoNil(getXMLBool(v238, v240 .. "#isGrowing"), true)
			local v249 = getXMLInt(v238, v240 .. "#splitShapeFileId")
			p236:plantTree(v242.index, v243[1], v243[2], v243[3], v244[1], v244[2], v244[3], v245, v246, v248, v247, v249)
		end
		v239 = v239 + 1
	end
	delete(v238)
	return true
end
function TreePlantManager.saveToXMLFile(p_u_250, p251)
	p_u_250:cleanupDeletedTrees()
	local v_u_252 = createXMLFile("treePlantXML", p251, "treePlant")
	if v_u_252 == 0 then
		Logging.error("Failed to create xml file %q", p251)
		return false
	end
	local function v268(p253, p254)
		-- upvalues: (copy) p_u_250, (copy) v_u_252
		local v255 = p_u_250:getTreeTypeDescFromIndex(p253.treeType).name
		local v256 = getChildAt(p253.node, 0) == p253.origSplitShape
		local v257 = p253.splitShapeFileId or -1
		local v258 = string.format("treePlant.tree(%d)", p254)
		setXMLString(v_u_252, v258 .. "#treeType", v255)
		setXMLString(v_u_252, v258 .. "#position", string.format("%.4f %.4f %.4f", p253.x, p253.y, p253.z))
		local v259 = setXMLString
		local v260 = v_u_252
		local v261 = v258 .. "#rotation"
		local v262 = string.format
		local v263 = p253.rx
		local v264 = math.deg(v263)
		local v265 = p253.ry
		local v266 = math.deg(v265)
		local v267 = p253.rz
		v259(v260, v261, v262("%.4f %.4f %.4f", v264, v266, (math.deg(v267))))
		setXMLInt(v_u_252, v258 .. "#growthStateI", p253.growthStateI)
		if p253.variationIndex ~= 1 then
			setXMLInt(v_u_252, v258 .. "#variationIndex", p253.variationIndex)
		end
		if p253.nextGrowthTargetHour ~= nil then
			setXMLFloat(v_u_252, v258 .. "#nextGrowthTargetHour", p253.nextGrowthTargetHour)
		end
		setXMLBool(v_u_252, v258 .. "#isGrowing", v256)
		setXMLInt(v_u_252, v258 .. "#splitShapeFileId", v257)
	end
	local v269 = 0
	for _, v270 in ipairs(p_u_250.treesData.growingTrees) do
		v268(v270, v269)
		v269 = v269 + 1
	end
	for _, v271 in ipairs(p_u_250.treesData.splitTrees) do
		v268(v271, v269)
		v269 = v269 + 1
	end
	saveXMLFile(v_u_252)
	delete(v_u_252)
	return true
end
function TreePlantManager.readFromServerStream(p272, p273)
	local v274 = p272.treesData
	for _ = 1, streamReadInt32(p273) do
		local v275 = streamReadUInt8(p273)
		local v276 = streamReadFloat32(p273)
		local v277 = streamReadFloat32(p273)
		local v278 = streamReadFloat32(p273)
		local v279 = streamReadFloat32(p273)
		local v280 = streamReadFloat32(p273)
		local v281 = streamReadFloat32(p273)
		local v282 = streamReadUIntN(p273, TreePlantManager.STAGE_NUM_BITS)
		local v283 = streamReadUIntN(p273, TreePlantManager.VARIATION_NUM_BITS)
		local v284 = streamReadInt32(p273)
		local v285 = p272.indexToTreeType[v275]
		if v285 ~= nil then
			local v286, v287 = p272:loadTreeNode(v285, v276, v277, v278, v279, v280, v281, v282, v283, -1)
			setSplitShapesFileIdMapping(v287, v284)
			v274.clientTrees[v284] = v286
		end
	end
end
function TreePlantManager.writeToClientStream(p288, p289)
	local v290 = p288.treesData
	p288:cleanupDeletedTrees()
	local v291 = #v290.growingTrees + #v290.splitTrees
	streamWriteInt32(p289, v291)
	for _, v292 in ipairs(v290.growingTrees) do
		streamWriteUInt8(p289, v292.treeType)
		streamWriteFloat32(p289, v292.x)
		streamWriteFloat32(p289, v292.y)
		streamWriteFloat32(p289, v292.z)
		streamWriteFloat32(p289, v292.rx)
		streamWriteFloat32(p289, v292.ry)
		streamWriteFloat32(p289, v292.rz)
		streamWriteUIntN(p289, v292.growthStateI, TreePlantManager.STAGE_NUM_BITS)
		streamWriteUIntN(p289, v292.variationIndex, TreePlantManager.VARIATION_NUM_BITS)
		streamWriteInt32(p289, v292.splitShapeFileId)
	end
	for _, v293 in ipairs(v290.splitTrees) do
		streamWriteUInt8(p289, v293.treeType)
		streamWriteFloat32(p289, v293.x)
		streamWriteFloat32(p289, v293.y)
		streamWriteFloat32(p289, v293.z)
		streamWriteFloat32(p289, v293.rx)
		streamWriteFloat32(p289, v293.ry)
		streamWriteFloat32(p289, v293.rz)
		streamWriteUIntN(p289, v293.growthStateI, TreePlantManager.STAGE_NUM_BITS)
		streamWriteUIntN(p289, v293.variationIndex, TreePlantManager.VARIATION_NUM_BITS)
		streamWriteInt32(p289, v293.splitShapeFileId)
	end
end
function TreePlantManager.getTreeTypeDescFromIndex(p294, p295)
	if p294.treeTypes == nil then
		return nil
	else
		return p294.treeTypes[p295]
	end
end
function TreePlantManager.getTreeTypeNameFromIndex(p296, p297)
	if p296.treeTypes == nil or p296.treeTypes[p297] == nil then
		return nil
	else
		return p296.treeTypes[p297].name
	end
end
function TreePlantManager.getTreeTypeDescFromName(p298, p299)
	if p298.nameToTreeType == nil or p299 == nil then
		return nil
	end
	local v300 = p299:upper()
	return p298.nameToTreeType[v300]
end
function TreePlantManager.getTreeTypeIndexAndVariationFromName(p301, p302, p303, p304)
	if p301.nameToTreeType ~= nil and p302 ~= nil then
		local v305 = p302:upper()
		local v306 = p301.nameToTreeType[v305]
		if v306 ~= nil then
			local v307 = v306.stages[p303]
			if v307 ~= nil then
				local v308 = nil
				for v309, v310 in ipairs(v307) do
					if string.lower(v310.name or "DEFAULT") == string.lower(p304 or "DEFAULT") then
						v308 = v309
						break
					end
				end
				return v306.index, v308
			end
		end
	end
	return nil, nil
end
function TreePlantManager.getTreeTypeNameAndVariationByIndex(p311, p312, p313, p314)
	if p311.treeTypes ~= nil then
		local v315 = p311.treeTypes[p312]
		if v315 ~= nil then
			local v316 = v315.stages[p313 or 1]
			if v316 ~= nil then
				local v317 = v316[p314] or v316[1]
				if v317 ~= nil then
					return v315.name, v317.name or "DEFAULT"
				end
			end
		end
	end
	return nil, nil
end
function TreePlantManager.getPalletStoreItemFilenameByIndex(p318, p319, p320, p321)
	if p318.treeTypes ~= nil then
		local v322 = p318.treeTypes[p319]
		if v322 ~= nil then
			local v323 = v322.stages[p320 or 1]
			if v323 ~= nil then
				local v324 = v323[p321] or v323[1]
				if v324 ~= nil then
					return v324.palletStoreItemFilename
				end
			end
		end
	end
	return nil
end
function TreePlantManager.getTreeTypeDescFromSplitType(p325, p326)
	if p325.splitTypeIndexToTreeType == nil or p326 == nil then
		return nil
	else
		return p325.splitTypeIndexToTreeType[p326]
	end
end
function TreePlantManager.getTreeTypeIndexFromName(p327, p328)
	if p327.nameToTreeType ~= nil and p328 ~= nil then
		local v329 = p328:upper()
		if p327.nameToTreeType[v329] ~= nil then
			return p327.nameToTreeType[v329].index
		end
	end
	return nil
end
function TreePlantManager.addClientTree(p330, p331, p332)
	if p330.treesData ~= nil then
		p330.treesData.clientTrees[p331] = p332
	end
end
function TreePlantManager.removeClientTree(p333, p334)
	if p333.treesData ~= nil then
		p333.treesData.clientTrees[p334] = nil
	end
end
function TreePlantManager.getClientTree(p335, p336)
	if p335.treesData == nil then
		return nil
	else
		return p335.treesData.clientTrees[p336]
	end
end
function TreePlantManager.addingSplitShape(p337, p338, p339, p340)
	local v341, v342
	if p339 == nil or p337.activeDecayingSplitShapes[p339] == nil then
		if p340 then
			local v343, v344, v345 = getWorldTranslation(p338)
			v341 = math.abs(v343) + math.abs(v344) + math.abs(v345)
			v342 = 1
		else
			v342 = 0
			v341 = 80
		end
	else
		v342 = p337.activeDecayingSplitShapes[p339].state
		v341 = p337.activeDecayingSplitShapes[p339].variation
	end
	if v342 ~= nil and getNumOfChildren(p338) > 0 then
		p337.activeDecayingSplitShapes[p338] = {
			["state"] = v342,
			["variation"] = v341
		}
		p337:setSplitShapeLeafScaleAndVariation(p338, v342, v341)
	end
	g_messageCenter:publish(MessageType.TREE_SHAPE_CUT, p339, p338)
end
function TreePlantManager.removingSplitShape(p346, p347)
	p346.activeDecayingSplitShapes[p347] = nil
end
function TreePlantManager.replaceWithTreeType(p348, p349, p350)
	local v351 = p348:getTreeTypeDescFromIndex(p350)
	if v351 == nil then
		return nil
	end
	local v352, v353, v354 = getWorldTranslation(p349)
	local v355, v356, v357 = getWorldRotation(p349)
	local v358 = p348:plantTree(v351.index, v352, v353, v354, v355, v356, v357, 1, 1, false)
	if v358 ~= nil then
		delete(p349)
	end
	return v358
end
function TreePlantManager.setSplitShapeLeafScaleAndVariation(_, p359, p360, p361)
	I3DUtil.setShaderParameterRec(p359, "windSnowLeafScale", 0, 0, p360, p361)
end
function TreePlantManager.consoleCommandCutTrees(p362, p363)
	local v364 = tonumber(p363 or "50")
	p362.commandCutTreeData = {}
	p362.commandCutTreeData.trees = {}
	local v365, v366, v367 = getWorldTranslation(g_cameraManager:getActiveCamera())
	overlapSphere(v365, v366, v367, v364, "onTreeCutCommandOverlapCallback", p362, CollisionFlag.TREE, false, false, true, false)
	return string.format("Found %d trees to cut", #p362.commandCutTreeData.trees)
end
function TreePlantManager.onTreeCutCommandOverlapCallback(p368, p369, ...)
	if getHasClassId(p369, ClassIds.MESH_SPLIT_SHAPE) and (getSplitType(p369) ~= 0 and (getRigidBodyType(p369) == RigidBodyType.STATIC and not getIsSplitShapeSplit(p369))) then
		local v370 = p368.commandCutTreeData.trees
		table.insert(v370, p369)
	end
end
function TreePlantManager.onTreeCutCommandSplitCallback(p371, p372, _, _, _, _, _, _)
	rotate(p372, 0.1, 0, 0)
	g_currentMission:addKnownSplitShape(p372)
	p371:addingSplitShape(p372, p371.commandCutTreeData.shapeBeingCut, true)
end
function TreePlantManager.consoleCommandLoadTree(p373, p374, p375, p376, p377)
	local v378, v379, v380 = g_localPlayer:getPosition()
	local v381, v382 = g_localPlayer:getCurrentFacingDirection()
	local v383 = v378 + v381 * 4
	local v384 = v380 + v382 * 4
	local v385 = v379 + 1
	if Platform.isMobile then
		local v386 = tonumber(p374)
		if v386 == nil then
			return "No amount given. (gsTreeAdd amount)"
		end
		WoodHarvesterLight.spawnLogs("data/maps/trees/logs/pineLog.i3d", v386, v383, v385, v384, MathUtil.getYRotationFromDirection(v381, v382), 0.4, 5, p373:getFarmId())
		return "Spawned log(s)"
	end
	local v387 = tonumber(p374)
	local v388 = "gsTreeAdd length [type (available: " .. table.concatKeys(p373.nameToTreeType, " ") .. ")] [growthStage] [delimb true/false]"
	if v387 == nil then
		return "No length given. " .. v388
	end
	if p375 == nil then
		p375 = "beech"
		p376 = 7
	end
	local v389 = p373:getTreeTypeDescFromName(p375)
	if v389 == nil then
		return "Invalid tree type. " .. v388
	end
	local v390 = tonumber(p376) or #v389.stages
	local v391 = #v389.stages
	local v392 = math.clamp(v390, 1, v391)
	p373:loadTreeTrunk(v389, v383, v385, v384, v381, 0, v382, v387, v392, math.random(1, #v389.stages[v392]), (p377 or "true"):lower() == "true")
	return "Loaded tree"
end
function TreePlantManager.consoleCommandPlantTrees(p393, p394, p395, p396, p397, p398)
	local v399 = "Usage: gsTreePlant treeType number growthState variationIndex isGrowing"
	local v400 = p393:getTreeTypeDescFromName(p394)
	if p394 ~= nil and v400 == nil then
		printError(string.format("Error: unknown tree type %q", p394))
		print("Available types:\n" .. table.concatKeys(g_treePlantManager.nameToTreeType, ", "))
		return v399
	end
	local v401 = v400 or p393:getTreeTypeDescFromName("lodgepolePine") or (p393:getTreeTypeDescFromName("aspen") or p393.treeTypes[1])
	local v402 = tonumber(p395) or 1
	local v403 = tonumber(p396) or #v401.stages
	local v404 = #v401.stages
	local v405 = math.clamp(v403, 1, v404)
	local v406 = tonumber(p397) or math.random(1, #v401.stages[v405])
	local v407 = #v401.stages[v405]
	local v408 = math.clamp(v406, 1, v407)
	local v409 = Utils.stringToBoolean(p398)
	local v410, v411, v412 = g_localPlayer:getPosition()
	local v413, v414 = g_localPlayer:getCurrentFacingDirection()
	local v415 = v410 + v413 * 5
	local v416 = v412 + v414 * 5
	local v417 = 0
	for v418 = 0, v402 - 1 do
		local v419 = v415 + v413 * v418 * 5
		local v420 = v416 + v414 * v418 * 5
		local v421 = getTerrainHeightAtWorldPos(g_terrainNode, v419, v411, v420)
		local v422 = math.random() * 2 * 3.141592653589793
		p393.plantTreeCommandHasCollision = false
		overlapBox(v419, v421, v420, 0, 0, 0, 0.5, 1, 0.5, "onTreeOverlapCheckCallback", p393, CollisionFlag.TREE)
		if p393.plantTreeCommandHasCollision then
			printWarning("Warning: skipped tree due to overlap with existing tree")
		elseif p393:plantTree(v401.index, v419, v421, v420, 0, v422, 0, v405, v408, v409) then
			v417 = v417 + 1
		end
	end
	return string.format("Planted %d trees of type %s", v417, v401.name)
end
function TreePlantManager.consoleCommandLoadAll(p423, _, _, _, _, _)
	g_debugManager:removeGroup("treeLoadAll")
	local v424, _, v425 = g_localPlayer:getPosition()
	local v426, v427 = g_localPlayer:getCurrentFacingDirection()
	local v428 = MathUtil.getYRotationFromDirection(-v426, -v427)
	local v429 = v424 + v426 * 5
	local v430 = v425 + v427 * 5
	local v431 = 0
	for v432, v433 in ipairs(p423.treeTypes) do
		local v434 = v429 + v427 * v432 * 10
		local v435 = v430 - v426 * v432 * 10
		for v436, v437 in ipairs(v433.stages) do
			for v438, v439 in ipairs(v437) do
				local v440 = getTerrainHeightAtWorldPos(g_terrainNode, v434, 0, v435)
				local v441 = p423:plantTree(v433.index, v434, v440, v435, 0, math.random() * 3.141592653589793, 0, v436, v438, false)
				if v441 ~= nil and v441 ~= 0 then
					local v442 = getChildAt(getChildAt(v441, 0), 0)
					local v443, v444, v445, v446, v447, v448, v449, v450
					if v442 == 0 or not getHasClassId(v442, ClassIds.MESH_SPLIT_SHAPE) then
						v443 = nil
						v444 = false
						v445 = nil
						v446 = nil
						v447 = nil
						v448 = -1
						v449 = "<NO_SPLIT_TYPE>"
						v450 = nil
					else
						v448 = getSplitType(v442)
						v449 = g_splitShapeManager:getSplitTypeNameByIndex(v448)
						v444 = g_splitShapeManager:getSplitShapeAllowsHarvester(v442)
						v450, v445, v443, v446, v447 = getSplitShapeStats(v442)
					end
					local v451 = v450 == nil and "" or string.format("\nSplit Shape Size: Height: %.2f | Width: %.2f | Length: %.2f | Area: %.2f m\194\178 | convexes: %d | attachments: %d", v450, v445, v443, v445 * v443, v446, v447)
					local v452 = DebugText3D.new():createWithWorldPos(v434 - v426, v440 + 0.5, v435 - v427, 0, v428, 0, string.format("%s : %s\nsplitType: %s / %s%s%s", v433.name, Utils.getFilenameInfo(v439.filename, true), v448, v449, v451, v444 and "\n\nSupports Wood Harvester" or ""), 0.07)
					if v444 then
						v452:setColor(Color.PRESETS.GREEN)
					end
					g_debugManager:addElement(v452, "treeLoadAll")
					p423:loadTreeTrunk(v433, v434 + v427 * 2, v440, v435 - v426 * 2, v426, 0, v427, 0.25, v436, v438, true, true)
					v431 = v431 + 1
					v434 = v434 + v426 * 10
					v435 = v435 + v427 * 10
				end
			end
		end
	end
	return string.format("Planted %d trees", v431)
end
function TreePlantManager.onTreeOverlapCheckCallback(p453, p454, ...)
	if getHasClassId(p454, ClassIds.SHAPE) and getHasClassId(p454, ClassIds.MESH_SPLIT_SHAPE) then
		p453.plantTreeCommandHasCollision = true
	end
end
function TreePlantManager.consoleCommandDebug(p455)
	p455.debugActive = not p455.debugActive
	if p455.debugActive then
		g_debugManager:addDrawable(p455)
	else
		g_debugManager:removeDrawable(p455)
	end
	local v456 = p455.debugActive
	return "Tree/Splitshape debug = " .. tostring(v456)
end
g_treePlantManager = TreePlantManager.new()

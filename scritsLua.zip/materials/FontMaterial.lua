FontMaterial = {}
local v_u_1 = Class(FontMaterial)
function FontMaterial.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	return setmetatable({}, v3)
end
function FontMaterial.loadFromXML(p4, p5, p6, p7, p8, p9)
	local v10 = p5:getValue(p6 .. "#name")
	local v11 = p5:getValue(p6 .. "#filename")
	local v12 = p5:getValue(p6 .. "#node")
	local v13 = p5:getValue(p6 .. "#noNormalNode")
	local v14 = p5:getValue(p6 .. "#characterShape")
	if v10 == nil or (v11 == nil or v12 == nil) then
		if p9 ~= nil then
			p9(false)
		end
	else
		if p7 ~= nil and p7 ~= "" then
			v10 = p7 .. "." .. v10
		end
		p4.name = v10
		p4.node = v12
		p4.noNormalNode = v13
		p4.characterShapePath = v14
		local v15 = Utils.getFilename(v11, p8)
		p4.callback = p9
		p4.sharedLoadRequestId = g_i3DManager:loadSharedI3DFileAsync(v15, false, false, p4.onI3DFileLoaded, p4, {
			["xmlFile"] = p5,
			["key"] = p6
		})
	end
end
function FontMaterial.onI3DFileLoaded(p_u_16, p17, _, p18, _)
	local v_u_19 = p18.xmlFile
	local v20 = p18.key
	if p17 ~= 0 then
		local v21 = I3DUtil.indexToObject(p17, p_u_16.node)
		if v21 ~= nil then
			p_u_16.materialId = getMaterial(v21, 0)
			p_u_16.materialNode = v21
			if p_u_16.noNormalNode ~= nil then
				p_u_16.materialNodeNoNormal = I3DUtil.indexToObject(p17, p_u_16.noNormalNode)
				p_u_16.materialIdNoNormal = getMaterial(p_u_16.materialNodeNoNormal, 0)
			end
			if p_u_16.characterShapePath ~= nil then
				p_u_16.characterShape = I3DUtil.indexToObject(p17, p_u_16.characterShapePath)
			end
			unlink(p_u_16.materialNodeNoNormal)
			unlink(p_u_16.characterShape)
			unlink(v21)
			p_u_16.spacingX = v_u_19:getValue(v20 .. ".spacing#x", 0)
			p_u_16.spacingY = v_u_19:getValue(v20 .. ".spacing#y", 0)
			p_u_16.charToCharSpace = v_u_19:getValue(v20 .. ".spacing#charToChar", 0.05)
			p_u_16.characters = {}
			p_u_16.charactersByType = {}
			p_u_16.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.NUMERICAL] = {}
			p_u_16.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.ALPHABETICAL] = {}
			p_u_16.charactersByType[MaterialManager.FONT_CHARACTER_TYPE.SPECIAL] = {}
			v_u_19:iterate(v20 .. ".character", function(_, p22)
				-- upvalues: (copy) v_u_19, (copy) p_u_16
				local v23 = {
					["uvIndex"] = v_u_19:getValue(p22 .. "#uvIndex", 0),
					["value"] = v_u_19:getValue(p22 .. "#value")
				}
				local v24 = v_u_19:getValue(p22 .. "#type", "alphabetical")
				v23.type = MaterialManager.FONT_CHARACTER_TYPE[v24:upper()] or MaterialManager.FONT_CHARACTER_TYPE.ALPHABETICAL
				local v25 = v_u_19:getValue(p22 .. "#spacingX", p_u_16.spacingX)
				v23.spacingX = math.max(v25, 0.0001)
				local v26 = v_u_19:getValue(p22 .. "#spacingY", p_u_16.spacingY)
				v23.spacingY = math.max(v26, 0.0001)
				v23.offsetX = v_u_19:getValue(p22 .. "#offsetX", 0)
				v23.offsetY = v_u_19:getValue(p22 .. "#offsetY", 0)
				local v27 = v_u_19:getValue(p22 .. "#realSpacingX", v23.spacingX)
				v23.realSpacingX = math.max(v27, 0.0001)
				if v23.value ~= nil then
					local v28 = p_u_16.characters
					table.insert(v28, v23)
					local v29 = p_u_16.charactersByType[v23.type]
					table.insert(v29, v23)
				end
			end)
		end
		delete(p17)
	end
	if p_u_16.callback ~= nil then
		p_u_16.callback(p_u_16.materialNode ~= nil)
	end
end
function FontMaterial.getCharacterIndexByCharacter(p30, p31)
	for v32 = 1, #p30.characters do
		if p30.characters[v32].value:lower() == p31:lower() then
			return v32
		end
	end
	return 0
end
function FontMaterial.getCharacterByCharacterIndex(p33, p34)
	local v35 = p33.characters[p34]
	if v35 == nil then
		return nil
	else
		return v35.value
	end
end
function FontMaterial.assignFontMaterialToNode(p36, p37, p38)
	if p37 ~= nil then
		local v39 = p36.materialId
		if p38 == false then
			v39 = p36.materialIdNoNormal or v39
		end
		setMaterial(p37, v39, 0)
		setShaderParameter(p37, "spacing", p36.spacingX, p36.spacingY, 0, 0, false)
	end
end
function FontMaterial.setFontCharacter(p40, p41, p42, p43, p44)
	if p41 == nil then
		return nil
	end
	if p44 ~= nil then
		if p42 == " " then
			p40:setFontCharacterColor(p41, p44[1], p44[2], p44[3])
			p42 = "0"
		else
			p40:setFontCharacterColor(p41, p43[1], p43[2], p43[3])
		end
	end
	local v45 = nil
	for v46 = 1, #p40.characters do
		local v47 = p40.characters[v46]
		if v47.value == p42 then
			v45 = v47
			break
		end
	end
	if v45 == nil then
		for v48 = 1, #p40.characters do
			local v49 = p40.characters[v48]
			if v49.value:lower() == p42:lower() then
				v45 = v49
				break
			end
		end
	end
	if v45 == nil then
		setVisibility(p41, false)
		return v45
	end
	setVisibility(p41, true)
	setShaderParameter(p41, "index", v45.uvIndex, 0, 0, 0, false)
	setShaderParameter(p41, "spacing", v45.spacingX or p40.spacingX, v45.spacingY or p40.spacingY, 0, 0, false)
	return v45
end
function FontMaterial.setFontCharacterColor(_, p50, p51, p52, p53, p54, p55)
	if p50 ~= nil then
		setShaderParameter(p50, "colorScale", p51, p52, p53, p54, false)
		if p55 ~= nil then
			setShaderParameter(p50, "lightControl", p55, nil, nil, nil, false)
		end
	end
end
function FontMaterial.getFontMaxWidthRatio(p56, p57, p58, p59)
	local v60 = 0
	for v61 = 1, #p56.characters do
		local v62 = p56.characters[v61]
		if v62.type == MaterialManager.FONT_CHARACTER_TYPE.ALPHABETICAL and p57 ~= false or (v62.type == MaterialManager.FONT_CHARACTER_TYPE.NUMERICAL and p58 ~= false or v62.type == MaterialManager.FONT_CHARACTER_TYPE.SPECIAL and p59 ~= false) then
			local v63 = v62.spacingX or p56.spacingX
			local v64 = v62.spacingY or p56.spacingY
			local v65 = (1 - v63 * 2) / (1 - v64 * 2)
			v60 = math.max(v65, v60)
		end
	end
	return v60
end
function FontMaterial.getClonedShape(p66, p67, p68)
	local v69 = clone(p66.characterShape, false, false, false)
	link(p67, v69)
	p66:assignFontMaterialToNode(v69, p68)
	return v69
end
function FontMaterial.registerXMLPaths(p70)
	p70:register(XMLValueType.STRING, "fonts.font(?)#name", "Name if font")
	p70:register(XMLValueType.STRING, "fonts.font(?)#filename", "Path to i3d file")
	p70:register(XMLValueType.STRING, "fonts.font(?)#node", "Path to material node")
	p70:register(XMLValueType.STRING, "fonts.font(?)#characterShape", "Path to character mesh")
	p70:register(XMLValueType.STRING, "fonts.font(?)#noNormalNode", "Path to material node without normal map")
	p70:register(XMLValueType.FLOAT, "fonts.font(?).spacing#x", "X Spacing", 0)
	p70:register(XMLValueType.FLOAT, "fonts.font(?).spacing#y", "Y Spacing", 0)
	p70:register(XMLValueType.FLOAT, "fonts.font(?).spacing#charToChar", "Spacing from character to character in percentage", 0.1)
	p70:register(XMLValueType.INT, "fonts.font(?).character(?)#uvIndex", "Index on uv map", 0)
	p70:register(XMLValueType.STRING, "fonts.font(?).character(?)#value", "Character value")
	p70:register(XMLValueType.STRING, "fonts.font(?).character(?)#type", "Character type", "alphabetical")
	p70:register(XMLValueType.FLOAT, "fonts.font(?).character(?)#spacingX", "Custom spacing X")
	p70:register(XMLValueType.FLOAT, "fonts.font(?).character(?)#spacingY", "Custom spacing Y")
	p70:register(XMLValueType.FLOAT, "fonts.font(?).character(?)#offsetX", "Custom X offset for created char lines (percentage)", 0)
	p70:register(XMLValueType.FLOAT, "fonts.font(?).character(?)#offsetY", "Custom Y offset for created char lines (percentage)", 0)
	p70:register(XMLValueType.FLOAT, "fonts.font(?).character(?)#realSpacingX", "Real spacing from border to visual beginning")
end

MaterialManager = {}
MaterialManager.fontMaterialXMLSchema = nil
MaterialManager.DEFAULT_FONT_MATERIAL_XML = "data/shared/alphabet/fonts.xml"
MaterialManager.FONT_CHARACTER_TYPE = {}
MaterialManager.FONT_CHARACTER_TYPE.NUMERICAL = 0
MaterialManager.FONT_CHARACTER_TYPE.ALPHABETICAL = 1
MaterialManager.FONT_CHARACTER_TYPE.SPECIAL = 2
MaterialType = nil
local v_u_1 = Class(MaterialManager, AbstractManager)
function MaterialManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = AbstractManager.new(p2 or v_u_1)
	MaterialManager.fontMaterialXMLSchema = XMLSchema.new("fontMaterials")
	FontMaterial.registerXMLPaths(MaterialManager.fontMaterialXMLSchema)
	return v3
end
function MaterialManager.initDataStructures(p4)
	p4.nameToIndex = {}
	p4.materialTypes = {}
	p4.materials = {}
	p4.particleMaterials = {}
	p4.modMaterialHoldersToLoad = {}
	p4.fontMaterials = {}
	p4.fontMaterialsByName = {}
	p4.baseMaterials = {}
	p4.baseMaterialsByName = {}
	p4.loadedMaterialHolderNodes = {}
end
function MaterialManager.loadMapData(p5, _, _, _, p6, p7)
	MaterialManager:superClass().loadMapData(p5)
	p5:addMaterialType("fillplane")
	p5:addMaterialType("icon")
	p5:addMaterialType("unloading")
	p5:addMaterialType("smoke")
	p5:addMaterialType("straw")
	p5:addMaterialType("chopper")
	p5:addMaterialType("soil")
	p5:addMaterialType("sprayer")
	p5:addMaterialType("spreader")
	p5:addMaterialType("pipe")
	p5:addMaterialType("mower")
	p5:addMaterialType("belt")
	p5:addMaterialType("belt_cropDirt")
	p5:addMaterialType("belt_cropClean")
	p5:addMaterialType("leveler")
	p5:addMaterialType("washer")
	p5:addMaterialType("pickup")
	MaterialType = p5.nameToIndex
	p5.finishedLoadingCallback = p6
	p5.callbackTarget = p7
	p5:loadFontMaterialsXML(MaterialManager.DEFAULT_FONT_MATERIAL_XML, nil, p5.baseDirectory)
	return true
end
function MaterialManager.unloadMapData(p8)
	for _, v9 in ipairs(p8.loadedMaterialHolderNodes) do
		delete(v9)
	end
	if p8.xmlFile ~= nil then
		p8.xmlFile:delete()
		p8.xmlFile = nil
	end
	for _, v10 in ipairs(p8.fontMaterials) do
		delete(v10.materialNode)
		if v10.materialNodeNoNormal ~= nil then
			delete(v10.materialNodeNoNormal)
		end
		if v10.characterShape ~= nil then
			delete(v10.characterShape)
		end
		if v10.sharedLoadRequestId ~= nil then
			g_i3DManager:releaseSharedI3DFile(v10.sharedLoadRequestId)
		end
	end
	MaterialManager:superClass().unloadMapData(p8)
end
function MaterialManager.addMaterialType(p11, p12)
	if not ClassUtil.getIsValidIndexName(p12) then
		printWarning("Warning: \'" .. tostring(p12) .. "\' is not a valid name for a materialType. Ignoring it!")
		return nil
	end
	local v13 = p12:upper()
	if p11.nameToIndex[v13] == nil then
		local v14 = p11.materialTypes
		table.insert(v14, v13)
		p11.nameToIndex[v13] = #p11.materialTypes
	end
	return nil
end
function MaterialManager.getMaterialTypeByName(p15, p16)
	if p16 ~= nil then
		local v17 = p16:upper()
		if p15.nameToIndex[v17] ~= nil then
			return v17
		end
	end
	return nil
end
function MaterialManager.addBaseMaterial(p18, p19, p20)
	p18.baseMaterialsByName[p19:upper()] = p20
	local v21 = p18.baseMaterials
	table.insert(v21, p20)
end
function MaterialManager.getBaseMaterialByName(p22, p23)
	if p23 == nil then
		return nil
	else
		return p22.baseMaterialsByName[p23:upper()]
	end
end
function MaterialManager.addMaterial(p24, p25, p26, p27, p28)
	p24:addMaterialToTarget(p24.materials, p25, p26, p27, p28)
end
function MaterialManager.addParticleMaterial(p29, p30, p31, p32, p33)
	p29:addMaterialToTarget(p29.particleMaterials, p30, p31, p32, p33)
end
function MaterialManager.addMaterialToTarget(_, p34, p35, p36, p37, p38)
	if p35 ~= nil and (p36 ~= nil and (p37 ~= nil and p38 ~= nil)) then
		if p34[p35] == nil then
			p34[p35] = {}
		end
		local v39 = p34[p35]
		if v39[p36] == nil then
			v39[p36] = {}
		end
		local v40 = v39[p36]
		if g_showDevelopmentWarnings and v40[p37] ~= nil then
			local v41 = g_fillTypeManager:getFillTypeByIndex(p35)
			local v42 = Logging.devWarning
			local v43 = tostring(p36)
			local v44 = v41.name
			v42("Material type \'%s\' already exists for fillType \'%s\'. It will be overwritten!", v43, (tostring(v44)))
		end
		v40[p37] = p38
	end
end
function MaterialManager.getMaterial(p45, p46, p47, p48)
	return p45:getMaterialFromTarget(p45.materials, p46, p47, p48)
end
function MaterialManager.getParticleMaterial(p49, p50, p51, p52)
	return p49:getMaterialFromTarget(p49.particleMaterials, p50, p51, p52)
end
function MaterialManager.getMaterialFromTarget(p53, p54, p55, p56, p57)
	if p55 == nil or (p56 == nil or p57 == nil) then
		return nil
	else
		local v58 = p53:getMaterialTypeByName(p56)
		if v58 == nil then
			return nil
		else
			local v59 = p54[p55]
			if v59 == nil then
				return nil
			else
				local v60 = v59[v58]
				if v60 == nil then
					return nil
				else
					return v60[p57]
				end
			end
		end
	end
end
function MaterialManager.addModMaterialHolder(p61, p62)
	p61.modMaterialHoldersToLoad[p62] = p62
end
function MaterialManager.loadModMaterialHolders(p63)
	for v64, _ in pairs(p63.modMaterialHoldersToLoad) do
		g_i3DManager:loadI3DFileAsync(v64, true, true, MaterialManager.materialHolderLoaded, p63, nil)
	end
end
function MaterialManager.materialHolderLoaded(p65, p66, _, _)
	if p66 ~= 0 then
		for v67 = getNumOfChildren(p66) - 1, 0, -1 do
			local v68 = getChildAt(p66, v67)
			unlink(v68)
			local v69 = p65.loadedMaterialHolderNodes
			table.insert(v69, v68)
		end
		delete(p66)
	end
end
function MaterialManager.getFontMaterial(p70, p71, p72)
	if p72 ~= nil and p72 ~= "" then
		local v73 = p72 .. "." .. p71
		if p70.fontMaterialsByName[v73] ~= nil then
			return p70.fontMaterialsByName[v73]
		end
	end
	return p70.fontMaterialsByName[p71]
end
function MaterialManager.loadFontMaterialsXML(p_u_74, p75, p_u_76, p_u_77)
	p_u_74.xmlFile = XMLFile.load("TempFonts", p75, MaterialManager.fontMaterialXMLSchema)
	if p_u_74.xmlFile ~= nil then
		p_u_74.xmlFile.references = 0
		p_u_74.xmlFile:iterate("fonts.font", function(_, p78)
			-- upvalues: (copy) p_u_74, (copy) p_u_76, (copy) p_u_77
			p_u_74.xmlFile.references = p_u_74.xmlFile.references + 1
			local v_u_79 = FontMaterial.new()
			v_u_79:loadFromXML(p_u_74.xmlFile, p78, p_u_76, p_u_77, function(p80)
				-- upvalues: (ref) p_u_74, (copy) v_u_79
				p_u_74.xmlFile.references = p_u_74.xmlFile.references - 1
				if p_u_74.xmlFile.references == 0 then
					p_u_74.xmlFile:delete()
					p_u_74.xmlFile = nil
					if p_u_74.finishedLoadingCallback ~= nil then
						p_u_74.finishedLoadingCallback(p_u_74.callbackTarget)
						p_u_74.finishedLoadingCallback = nil
						p_u_74.callbackTarget = nil
					end
				end
				if p80 then
					local v81 = p_u_74.fontMaterials
					local v82 = v_u_79
					table.insert(v81, v82)
					p_u_74.fontMaterialsByName[v_u_79.name] = v_u_79
				end
			end)
		end)
	end
	if p_u_74.xmlFile == nil or p_u_74.xmlFile.references == 0 then
		if p_u_74.xmlFile ~= nil then
			p_u_74.xmlFile:delete()
			p_u_74.xmlFile = nil
		end
		if p_u_74.finishedLoadingCallback ~= nil then
			p_u_74.finishedLoadingCallback(p_u_74.callbackTarget)
			p_u_74.finishedLoadingCallback = nil
			p_u_74.callbackTarget = nil
		end
	end
end
function MaterialManager.consoleCommandDebug(_)
	if MaterialManager.debugRootNode == nil then
		MaterialManager.debugRootNode = createTransformGroup("MaterialManager_DebugRootNode")
		link(getRootNode(), MaterialManager.debugRootNode)
		local v83, v84, v85 = g_localPlayer:getPosition()
		local v86, v87 = g_localPlayer:getCurrentFacingDirection()
		local v88 = v83 + v86 * 10
		local v89 = v85 + v87 * 10
		local v90 = MathUtil.getYRotationFromDirection(v86, v87)
		setWorldTranslation(MaterialManager.debugRootNode, v88, v84 + 2, v89)
		setWorldRotation(MaterialManager.debugRootNode, 0, v90, 0)
		local v91 = loadI3DFile("data/effects/debug/effectDebugMesh.i3d", false, false, false)
		MaterialManager.debugMesh = getChildAt(v91, 0)
		unlink(MaterialManager.debugMesh)
		delete(v91)
	else
		for _ = 1, getNumOfChildren(MaterialManager.debugRootNode) do
			local v92 = getChildAt(MaterialManager.debugRootNode, 0)
			delete(v92)
		end
	end
	local v93 = 0
	for _, v94 in pairs(g_fillTypeManager.fillTypes) do
		v94:reloadData()
		local v95 = g_fillTypeManager:getTextureArrayIndexByFillTypeIndex(v94.index)
		if v95 ~= nil then
			local v96 = clone(MaterialManager.debugMesh, false, false, false)
			link(MaterialManager.debugRootNode, v96)
			setTranslation(v96, v93 * 3, 0, 0)
			local v97 = g_materialManager:getBaseMaterialByName("belt")
			if v97 ~= nil then
				setMaterial(v96, v97, 0)
				local v98 = getMaterialCustomShaderFilename(v97)
				local v99
				if v98 == nil then
					v99 = false
				else
					v99 = v98:contains("grainUnloadingSmokeShader") or v98:contains("grainUnloadingBeltShader") or (v98:contains("grainUnloadingShader") or v98:contains("levelerShader"))
				end
				if v99 then
					if v98 == nil or v98:find("grainUnloadingSmokeShader") == nil then
						g_fillTypeManager:assignFillTypeTextureArraysFromTerrain(v96, g_terrainNode, true, true, true)
					else
						g_fillTypeManager:assignFillTypeTextureArraysFromTerrain(v96, g_terrainNode, true, false, false)
					end
					setShaderParameter(v96, "fillTypeId", v95 - 1, 0, 0, 0, false)
					setShaderParameter(v96, "alphaClipScale", v94:getBeltEffectAlphaClipScale(), nil, nil, nil, false)
				end
			end
			local v100, v101, v102 = getWorldTranslation(v96)
			local v103, v104, v105 = localRotationToWorld(v96, 0, 3.141592653589793, 0)
			g_debugManager:addElement(DebugText3D.new():createWithWorldPos(v100, v101 + 0.25, v102, v103, v104, v105, v94.name, 0.15), nil, nil, (1 / 0))
			v93 = v93 + 1
		end
	end
end
g_materialManager = MaterialManager.new()
addConsoleCommand("gsMaterialManagerDebug", "Debug particle effect", "consoleCommandDebug", g_materialManager)

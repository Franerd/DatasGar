MaterialUtil = {}
function MaterialUtil.onCreateBaseMaterial(_, p1)
	local v2 = getUserAttribute(p1, "materialName")
	if v2 == nil then
		Logging.i3dWarning(p1, "Missing \'materialName\' user attribute for MaterialUtil.onCreateBaseMaterial")
	else
		g_materialManager:addBaseMaterial(v2, getMaterial(p1, 0))
	end
end
function MaterialUtil.validateMaterialAttributes(p3, p4)
	local v5 = getUserAttribute(p3, "fillType")
	if v5 == nil then
		Logging.i3dWarning(p3, "Missing \'fillType\' user attribute for %q", p4)
		return false
	end
	local v6 = g_fillTypeManager:getFillTypeIndexByName(v5)
	if v6 == nil then
		Logging.i3dWarning(p3, "Unknown fillType %q in user attribute \'fillType\' for %q", v5, p4)
		return false
	end
	local v7 = getUserAttribute(p3, "materialType")
	if v7 == nil then
		Logging.i3dWarning(p3, "Missing \'materialType\' user attribute for %q", p4)
		return false
	end
	local v8 = g_materialManager:getMaterialTypeByName(v7)
	if v8 == nil then
		Logging.i3dWarning(p3, "Unknown materialType %q for %q", v7, p4)
		return false
	end
	local v9 = Utils.getNoNil(getUserAttribute(p3, "materialIndex"), 1)
	local v10 = tonumber(v9)
	if v10 ~= nil then
		return true, v6, v8, v10
	end
	Logging.i3dWarning(p3, "Invalid materialIndex %q for %q", v9, p4)
	return false
end
function MaterialUtil.onCreateMaterial(_, p11)
	local v12, v13, v14, v15 = MaterialUtil.validateMaterialAttributes(p11, "MaterialUtil.onCreateMaterial")
	if v12 then
		g_materialManager:addMaterial(v13, v14, v15, getMaterial(p11, 0))
	end
end
function MaterialUtil.onCreateParticleMaterial(_, p16)
	local v17, v18, v19, v20 = MaterialUtil.validateMaterialAttributes(p16, "MaterialUtil.onCreateParticleMaterial")
	if v17 then
		g_materialManager:addParticleMaterial(v18, v19, v20, getMaterial(p16, 0))
	end
end
function MaterialUtil.onCreateParticleSystem(_, p21)
	local v22 = getUserAttribute(p21, "particleType")
	if v22 == nil then
		Logging.i3dWarning(p21, "Missing \'particleType\' user attribute for MaterialUtil.onCreateParticleSystem")
		return
	else
		local v23 = g_particleSystemManager:getParticleSystemTypeByName(v22)
		if v23 == nil then
			Logging.i3dWarning(p21, "Unknown particleType \'%s\' given in \'particleType\' user attribute for MaterialUtil.onCreateParticleSystem", v22)
			print(string.format("Available types: %s", table.concat(g_particleSystemManager.particleTypes, " ")))
		else
			local v24 = Utils.getNoNil(getUserAttribute(p21, "defaultEmittingState"), false)
			local v25 = Utils.getNoNil(getUserAttribute(p21, "worldSpace"), true)
			local v26 = Utils.getNoNil(getUserAttribute(p21, "forceFullLifespan"), false)
			local v27 = {}
			ParticleUtil.loadParticleSystemFromNode(p21, v27, v24, v25, v26)
			g_particleSystemManager:addParticleSystem(v23, v27)
		end
	end
end
function MaterialUtil.getMaterialBySlotName(p28, p29)
	if getHasClassId(p28, ClassIds.SHAPE) then
		for v30 = 1, getNumOfMaterials(p28) do
			if getMaterialSlotName(p28, v30 - 1) == p29 then
				return getMaterial(p28, v30 - 1)
			end
		end
	end
	for v31 = 1, getNumOfChildren(p28) do
		local v32 = getChildAt(p28, v31 - 1)
		local v33 = MaterialUtil.getMaterialBySlotName(v32, p29)
		if v33 ~= nil then
			return v33
		end
	end
	return nil
end
function MaterialUtil.replaceMaterialRec(p34, p35, p36)
	if getHasClassId(p34, ClassIds.SHAPE) then
		for v37 = 1, getNumOfMaterials(p34) do
			if getMaterial(p34, v37 - 1) == p35 then
				setMaterial(p34, p36, v37 - 1)
			end
		end
	end
	local v38 = getNumOfChildren(p34)
	if v38 > 0 then
		for v39 = 0, v38 - 1 do
			MaterialUtil.replaceMaterialRec(getChildAt(p34, v39), p35, p36)
		end
	end
end

ParticleSystemManager = {}
ParticleType = nil
local v_u_1 = Class(ParticleSystemManager, AbstractManager)
function ParticleSystemManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function ParticleSystemManager.initDataStructures(p3)
	p3.nameToIndex = {}
	p3.particleTypes = {}
	p3.particleSystems = {}
end
function ParticleSystemManager.loadMapData(p4)
	ParticleSystemManager:superClass().loadMapData(p4)
	p4:addParticleType("unloading")
	p4:addParticleType("smoke")
	p4:addParticleType("smoke_chimney")
	p4:addParticleType("chopper")
	p4:addParticleType("straw")
	p4:addParticleType("cutter_chopper")
	p4:addParticleType("soil")
	p4:addParticleType("soil_smoke")
	p4:addParticleType("soil_chunks")
	p4:addParticleType("soil_big_chunks")
	p4:addParticleType("soil_harvesting")
	p4:addParticleType("spreader")
	p4:addParticleType("spreader_smoke")
	p4:addParticleType("windrower")
	p4:addParticleType("tedder")
	p4:addParticleType("weeder")
	p4:addParticleType("crusher_wood")
	p4:addParticleType("crusher_dust")
	p4:addParticleType("prepare_fruit")
	p4:addParticleType("cleaning_soil")
	p4:addParticleType("cleaning_dust")
	p4:addParticleType("washer_water")
	p4:addParticleType("chainsaw_wood")
	p4:addParticleType("chainsaw_dust")
	p4:addParticleType("pickup")
	p4:addParticleType("pickup_falling")
	p4:addParticleType("sowing")
	p4:addParticleType("loading")
	p4:addParticleType("wheel_dust")
	p4:addParticleType("wheel_dry")
	p4:addParticleType("wheel_wet")
	p4:addParticleType("wheel_snow")
	p4:addParticleType("bees")
	p4:addParticleType("horse_step_slow")
	p4:addParticleType("horse_step_fast")
	p4:addParticleType("spraycan_paint")
	p4:addParticleType("HYDRAULIC_HAMMER")
	p4:addParticleType("HYDRAULIC_HAMMER_DEBRIS")
	p4:addParticleType("STONE")
	ParticleType = p4.nameToIndex
	return true
end
function ParticleSystemManager.unloadMapData(p5)
	for _, v6 in pairs(p5.particleSystems) do
		ParticleUtil.deleteParticleSystem(v6)
	end
	ParticleSystemManager:superClass().unloadMapData(p5)
end
function ParticleSystemManager.addParticleType(p7, p8)
	if not ClassUtil.getIsValidIndexName(p8) then
		printWarning("Warning: \'" .. tostring(p8) .. "\' is not a valid name for a particleType. Ignoring it!")
		return nil
	end
	local v9 = p8:upper()
	if p7.nameToIndex[v9] == nil then
		local v10 = p7.particleTypes
		table.insert(v10, v9)
		p7.nameToIndex[v9] = #p7.particleTypes
	end
	return nil
end
function ParticleSystemManager.getParticleSystemTypeByName(p11, p12)
	if p12 ~= nil then
		local v13 = p12:upper()
		if p11.nameToIndex[v13] ~= nil then
			return v13
		end
	end
	return nil
end
function ParticleSystemManager.addParticleSystem(p14, p15, p16)
	if p14.particleSystems[p15] ~= nil then
		ParticleUtil.deleteParticleSystem(p14.particleSystems[p15])
	end
	p14.particleSystems[p15] = p16
end
function ParticleSystemManager.getParticleSystem(p17, p18)
	local v19 = p17:getParticleSystemTypeByName(p18)
	if v19 == nil then
		return nil
	else
		return p17.particleSystems[v19]
	end
end
function ParticleSystemManager.consoleCommandDebug(p20)
	if ParticleSystemManager.debugRootNode == nil then
		ParticleSystemManager.debugRootNode = createTransformGroup("ParticleSystemManager_DebugRootNode")
		link(getRootNode(), ParticleSystemManager.debugRootNode)
		local v21, v22, v23 = g_localPlayer:getPosition()
		local v24, v25 = g_localPlayer:getCurrentFacingDirection()
		local v26 = v21 + v24 * 10
		local v27 = v23 + v25 * 10
		local v28 = MathUtil.getYRotationFromDirection(v24, v25)
		setWorldTranslation(ParticleSystemManager.debugRootNode, v26, v22 + 2, v27)
		setWorldRotation(ParticleSystemManager.debugRootNode, 0, v28, 0)
	else
		for _ = 1, getNumOfChildren(ParticleSystemManager.debugRootNode) do
			local v29 = getChildAt(ParticleSystemManager.debugRootNode, 0)
			delete(v29)
		end
	end
	if ParticleSystemManager.debugParticleSystems == nil then
		ParticleSystemManager.debugParticleSystems = {}
	else
		for _, v30 in pairs(ParticleSystemManager.debugParticleSystems) do
			ParticleUtil.deleteParticleSystem(v30)
		end
	end
	local v31 = 0
	for _, v32 in pairs(g_fillTypeManager.fillTypes) do
		v32:reloadData()
		if v32.prioritizedEffectType == "ParticleEffect" then
			local v33 = p20:getParticleSystem("unloading")
			if v33 ~= nil then
				local v34 = clone(v33.shape, true, false, true)
				local v35 = clone(v33.emitterShape, true, false, false)
				link(ParticleSystemManager.debugRootNode, v35)
				setTranslation(v35, v31 * 3, 0, 0)
				local v36 = {}
				ParticleUtil.loadParticleSystemFromNode(v34, v36, false, true, v33.forceFullLifespan)
				ParticleUtil.setEmitterShape(v36, v35)
				v32:setParticleSystemFillType(v36, "unloading", "unloadingParticle", false, 1)
				ParticleUtil.setEmittingState(v36, true)
				local v37 = ParticleSystemManager.debugParticleSystems
				table.insert(v37, v36)
				local v38, v39, v40 = getWorldTranslation(v35)
				local v41, v42, v43 = localRotationToWorld(v35, 0, 3.141592653589793, 0)
				g_debugManager:addElement(DebugText3D.new():createWithWorldPos(v38, v39 + 1.3, v40, v41, v42, v43, v32.name, 0.15), nil, nil, (1 / 0))
				v31 = v31 + 1
			end
		end
	end
end
g_particleSystemManager = ParticleSystemManager.new()
addConsoleCommand("gsParticleSystemDebug", "Debug particle effect", "consoleCommandDebug", g_particleSystemManager)

CharacterLine = {}
local v_u_1 = Class(CharacterLine)
function CharacterLine.new(p2, p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = p5 or v_u_1
	local v7 = setmetatable({}, v6)
	v7.fontMaterial = p3
	v7.rootNode = createTransformGroup("characterLine")
	link(p2, v7.rootNode)
	v7.characters = {}
	for _ = 1, p4 do
		local v8 = p3:getClonedShape(v7.rootNode)
		setShapeCastShadowmap(v8, false)
		local v9 = v7.characters
		table.insert(v9, v8)
	end
	v7.textSize = 1
	v7.scaleX = 1
	v7.scaleY = 1
	v7.textAlignment = RenderText.ALIGN_RIGHT
	v7.textVerticalAlignment = RenderText.VERTICAL_ALIGN_BOTTOM
	v7.fontThickness = 1
	v7.fontThicknessShader = (v7.fontThickness - 1) / 8 + 1
	v7.useNormalMap = true
	v7.textColor = nil
	v7.hiddenColor = nil
	v7.textEmissiveScale = 0
	v7.hiddenAlpha = 0
	v7:setText("")
	return v7
end
function CharacterLine.setSizeAndScale(p10, p11, p12, p13)
	p10.textSize = p11 or p10.textSize
	p10.scaleX = p12 or p10.scaleX
	p10.scaleY = p13 or p10.scaleY
end
function CharacterLine.setTextAlignment(p14, p15)
	p14.textAlignment = p15 or p14.textAlignment
end
function CharacterLine.setTextVerticalAlignment(p16, p17)
	p16.textVerticalAlignment = p17 or p16.textVerticalAlignment
end
function CharacterLine.setFontThickness(p18, p19)
	p18.fontThickness = p19 or p18.fontThickness
	p18.fontThicknessShader = (p18.fontThickness - 1) / 8 + 1
	for _, v20 in ipairs(p18.characters) do
		setShaderParameter(v20, "alphaErosion", 1 - p18.fontThicknessShader, 0, 0, 0, false)
	end
end
function CharacterLine.setColor(p21, p22, p23, p24, p25)
	p21.textColor = p22 or p21.textColor
	p21.hiddenColor = p23 or p21.hiddenColor
	p21.textEmissiveScale = p24 or p21.textEmissiveScale
	p21.hiddenAlpha = p25 or p21.hiddenAlpha
	local v26, v27, v28
	if p21.textColor == nil then
		v26 = nil
		v27 = nil
		v28 = nil
	else
		v26 = p21.textColor[1]
		v27 = p21.textColor[2]
		v28 = p21.textColor[3]
	end
	for _, v29 in ipairs(p21.characters) do
		p21.fontMaterial:setFontCharacterColor(v29, v26, v27, v28, 1, p21.textEmissiveScale)
	end
end
function CharacterLine.setDecalLayer(p30, p31)
	for _, v32 in ipairs(p30.characters) do
		setShapeDecalLayer(v32, p31 or 0)
	end
end
function CharacterLine.setCastShadowmap(p33, p34)
	for _, v35 in ipairs(p33.characters) do
		setShapeCastShadowmap(v35, p34)
	end
end
function CharacterLine.setUseNormalMap(p36, p37)
	p36.useNormalMap = Utils.getNoNil(p37, p36.useNormalMap)
	for _, v38 in ipairs(p36.characters) do
		p36.fontMaterial:assignFontMaterialToNode(v38, p36.useNormalMap)
	end
end
function CharacterLine.setText(p39, p40)
	local v41 = p40:len()
	local v42 = 0
	local v43 = 0
	local v44 = 0
	for v45, v46 in ipairs(p39.characters) do
		local v47 = p40:sub(v41 - (v45 - 1), v41 - (v45 - 1)) or " "
		local v48 = p39.fontMaterial:setFontCharacter(v46, v47, p39.textColor, p39.hiddenColor)
		local v49 = p39.fontMaterial.spacingX
		local v50 = p39.fontMaterial.spacingY
		local v51 = p39.fontMaterial.spacingX
		local v52, v53
		if v48 == nil then
			v52 = 0
			v53 = 0
		else
			v49 = v48.spacingX or v49
			v50 = v48.spacingY or v50
			v51 = v48.realSpacingX or v50
			v52 = v48.offsetX
			v53 = v48.offsetY
		end
		local v54 = (1 - v49 * 2) / (1 - v50 * 2)
		local v55 = p39.textSize * v54 * p39.scaleX
		local v56 = p39.textSize * p39.scaleY
		setScale(v46, v55, v56, 1)
		local v57 = v55 + p39.textSize * p39.fontMaterial.charToCharSpace * (v49 / v51)
		setTranslation(v46, v43 - v57 * 0.5 + v57 * v52, v56 * 0.5 + v56 * v53, 0)
		v43 = v43 - v57
		v42 = math.max(v42, v56)
		if v47 ~= " " and v47 ~= "" then
			v44 = v43
		end
	end
	local v58 = 0
	local v59 = 0
	if p39.textAlignment == RenderText.ALIGN_LEFT then
		v58 = -v44
	elseif p39.textAlignment == RenderText.ALIGN_CENTER then
		v58 = -v44 * 0.5
	end
	if p39.textVerticalAlignment == RenderText.VERTICAL_ALIGN_MIDDLE then
		v59 = -v42 * 0.5
	elseif p39.textVerticalAlignment == RenderText.VERTICAL_ALIGN_TOP then
		v59 = -v42
	end
	setTranslation(p39.rootNode, v58, v59, 0)
end

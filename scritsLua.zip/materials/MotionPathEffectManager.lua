MotionPathEffectManager = {}
MotionPathEffectManager.MOTION_PATH_SHADER_PARAMS = {
	"scrollPos",
	"fadeProgress",
	"visibilityCut",
	"density",
	"verticalOffset",
	"subUVspeed",
	"subUVelements",
	"sizeScale"
}
local v_u_1 = Class(MotionPathEffectManager, AbstractManager)
function MotionPathEffectManager.new(p2)
	-- upvalues: (copy) v_u_1
	return AbstractManager.new(p2 or v_u_1)
end
function MotionPathEffectManager.initDataStructures(p3)
	p3.xmlFiles = {}
	p3.sharedLoadRequestIds = {}
	p3.effectsByType = {}
	p3.effects = {}
end
function MotionPathEffectManager.loadMapData(p4, p5, p6, p7)
	MotionPathEffectManager:superClass().loadMapData(p4, p5, p6, p7)
	p4.baseDirectory = p7
	local v8, _ = Utils.getModNameAndBaseDirectory(p7)
	MotionPathEffectManager.createMotionPathEffectXMLSchema()
	p4:loadMotionPathEffects(p5, "map.motionPathEffects.motionPathEffect", p7, v8)
	local v9 = getXMLString(p5, "map.motionPathEffects#filename")
	if v9 ~= nil then
		local v10 = Utils.getFilename(v9, p7)
		local v11 = XMLFile.load("motionPathXML", v10)
		if v11 ~= nil then
			p4:loadMotionPathEffects(v11.handle, "motionPathEffects.motionPathEffect", p7, v8)
			v11:delete()
		end
	end
	return true
end
function MotionPathEffectManager.loadMotionPathEffects(p12, p13, p14, p15, p16)
	local v17 = 0
	while true do
		local v18 = string.format("%s(%d)", p14, v17)
		if not hasXMLProperty(p13, v18) then
			break
		end
		local v19 = getXMLString(p13, v18 .. "#filename")
		if v19 ~= nil then
			p12:loadMotionPathEffectsXML(v19, p15, p16)
		end
		v17 = v17 + 1
	end
end
function MotionPathEffectManager.loadMotionPathEffectsXML(p20, p21, p22, p23)
	local v24 = Utils.getFilename(p21, p22)
	local v25 = XMLFile.load("mapMotionPathEffects", v24, MotionPathEffectManager.xmlSchema)
	if v25 ~= nil then
		p20.xmlFiles[v25] = true
		v25.xmlReferences = 0
		local v26 = 0
		while true do
			local v27 = string.format("motionPathEffects.motionPathEffect(%d)", v26)
			if not v25:hasProperty(v27) then
				break
			end
			local v28 = {}
			local v29 = v25:getValue(v27 .. "#effectClass", "MotionPathEffect")
			if v29 ~= nil then
				local v30 = g_effectManager:getEffectClass(v29)
				if v30 == nil then
					if p23 ~= nil and p23 ~= "" then
						v30 = g_effectManager:getEffectClass(p23 .. "." .. v29)
					end
					if v30 == nil then
						v30 = ClassUtil.getClassObject(v29)
					end
				end
				if v30 == nil then
					Logging.xmlError(v25, "Unknown motion path effect class \'%s\' in \'%s\'", v29, v27)
				else
					v30.loadEffectDefinitionFromXML(v28, v25, v27 .. ".typeDefinition")
					v28.effectClass = v30
					v28.effectClassName = v29
					v28.effectTypes = {}
					v28.effectTypeStr = v25:getValue(v27 .. "#effectType", "DEFAULT")
					local v31 = v28.effectTypeStr:split(" ")
					for v32 = 1, #v31 do
						local v33 = v28.effectTypes
						local v34 = v31[v32]
						table.insert(v33, v34:upper())
					end
					v28.filename = v25:getValue(v27 .. "#filename")
					if v28.filename == nil then
						Logging.xmlError(v25, "Missing filename for motion path effect \'%s\'", v27)
					else
						v25.xmlReferences = v25.xmlReferences + 1
						v28.filename = Utils.getFilename(v28.filename, p22)
						local v35 = g_i3DManager:loadSharedI3DFileAsync(v28.filename, false, false, p20.motionPathEffectI3DFileLoaded, p20, {
							["motionPathEffect"] = v28,
							["xmlFile"] = v25,
							["motionPathEffectKey"] = v27,
							["baseDirectory"] = p22
						})
						local v36 = p20.sharedLoadRequestIds
						table.insert(v36, v35)
					end
				end
			end
			v26 = v26 + 1
		end
		if v25.xmlReferences == 0 then
			p20.xmlFiles[v25] = nil
			v25:delete()
		end
	end
end
function MotionPathEffectManager.motionPathEffectI3DFileLoaded(p_u_37, p_u_38, _, p39)
	local v_u_40 = p39.motionPathEffect
	local v_u_41 = p39.xmlFile
	local v42 = p39.motionPathEffectKey
	local v_u_43 = p39.baseDirector
	if p_u_38 ~= nil and p_u_38 ~= 0 then
		local v_u_44 = {}
		v_u_40.effectMeshes = {}
		v_u_41:iterate(v42 .. ".effectMeshes.effectMesh", function(_, p45)
			-- upvalues: (copy) v_u_41, (copy) p_u_38, (copy) v_u_44, (copy) v_u_40, (copy) p_u_37
			local v46 = v_u_41:getValue(p45 .. "#node", nil, p_u_38)
			if v46 == nil or v_u_44[v46] ~= nil then
				if v46 == nil then
					Logging.xmlError(v_u_41, "Failed to load effect mesh node from xml (%s)", p45)
				else
					Logging.xmlError(v_u_41, "Failed to load effect mesh node from xml. Node already used. (%s)", p45)
				end
			else
				local v47 = {
					["node"] = v46,
					["rowLength"] = v_u_41:getValue(p45 .. "#rowLength", 30),
					["numRows"] = v_u_41:getValue(p45 .. "#numRows", 12),
					["skipPositions"] = v_u_41:getValue(p45 .. "#skipPositions", 0),
					["numVariations"] = v_u_41:getValue(p45 .. "#numVariations", 1)
				}
				if v47.numVariations > 1 then
					v47.usedVariations = {}
					for v48 = 1, v47.numVariations do
						v47.usedVariations[v48] = false
					end
				end
				v47.parent = v_u_40
				p_u_37:loadCustomShaderSettingsFromXML(v47, v_u_41, p45)
				v_u_40.effectClass.loadEffectMeshFromXML(v47, v_u_41, p45)
				v47.growthStates = v_u_40.growthStates
				local v49 = v_u_40.effectMeshes
				table.insert(v49, v47)
				v_u_44[v46] = true
				return
			end
		end)
		v_u_40.effectMaterials = {}
		v_u_41:iterate(v42 .. ".effectMaterials.effectMaterial", function(_, p50)
			-- upvalues: (copy) v_u_41, (copy) p_u_38, (copy) v_u_40, (copy) v_u_43, (copy) p_u_37
			local v51 = v_u_41:getValue(p50 .. "#node", nil, p_u_38)
			if v51 == nil then
				Logging.xmlError(v_u_41, "Failed to load effect material from xml (%s)", p50)
			else
				local v_u_52 = {
					["node"] = v51,
					["materialId"] = getMaterial(v51, 0),
					["parent"] = v_u_40,
					["lod"] = {}
				}
				v_u_41:iterate(p50 .. ".lod", function(_, p53)
					-- upvalues: (ref) v_u_41, (ref) p_u_38, (copy) v_u_52
					local v54 = v_u_41:getValue(p53 .. "#node", nil, p_u_38)
					if v54 ~= nil then
						local v55 = v_u_52.lod
						local v56 = getMaterial
						table.insert(v55, v56(v54, 0))
					end
				end)
				v_u_52.customDiffuse = v_u_41:getValue(p50 .. ".textures#diffuse")
				if v_u_52.customDiffuse ~= nil then
					v_u_52.customDiffuse = Utils.getFilename(v_u_52.customDiffuse, v_u_43)
					v_u_52.materialId = setMaterialDiffuseMapFromFile(v_u_52.materialId, v_u_52.customDiffuse, true, true, false)
				end
				v_u_52.customNormal = v_u_41:getValue(p50 .. ".textures#normal")
				if v_u_52.customNormal ~= nil then
					v_u_52.customNormal = Utils.getFilename(v_u_52.customNormal, v_u_43)
					v_u_52.materialId = setMaterialNormalMapFromFile(v_u_52.materialId, v_u_52.customDiffuse, true, false, false)
				end
				v_u_52.customSpecular = v_u_41:getValue(p50 .. ".textures#specular")
				if v_u_52.customSpecular ~= nil then
					v_u_52.customSpecular = Utils.getFilename(v_u_52.customSpecular, v_u_43)
					v_u_52.materialId = setMaterialGlossMapFromFile(v_u_52.materialId, v_u_52.customSpecular, true, true, false)
				end
				setMaterial(v51, v_u_52.materialId, 0)
				p_u_37:loadCustomShaderSettingsFromXML(v_u_52, v_u_41, p50)
				v_u_40.effectClass.loadEffectMaterialFromXML(v_u_52, v_u_41, p50)
				local v57 = v_u_40.effectMaterials
				table.insert(v57, v_u_52)
			end
		end)
		p_u_37:loadCustomShaderSettingsFromXML(v_u_40, v_u_41, v42 .. ".customShaderDefaults")
		for v58 = 1, #v_u_40.effectMeshes do
			unlink(v_u_40.effectMeshes[v58].node)
		end
		for v59 = 1, #v_u_40.effectMaterials do
			unlink(v_u_40.effectMaterials[v59].node)
		end
		for v60 = 1, #v_u_40.effectTypes do
			local v61 = v_u_40.effectTypes[v60]
			if p_u_37.effectsByType[v61] == nil then
				p_u_37.effectsByType[v61] = {}
			end
			local v62 = p_u_37.effectsByType[v61]
			table.insert(v62, v_u_40)
		end
		local v63 = p_u_37.effects
		table.insert(v63, v_u_40)
		delete(p_u_38)
	end
	v_u_41.xmlReferences = v_u_41.xmlReferences - 1
	if v_u_41.xmlReferences == 0 then
		p_u_37.xmlFiles[v_u_41] = nil
		v_u_41:delete()
	end
end
function MotionPathEffectManager.loadCustomShaderSettingsFromXML(p_u_64, p_u_65, p_u_66, p67)
	p_u_65.customShaderVariation = p_u_66:getValue(p67 .. ".customShaderVariation#name")
	p_u_65.customShaderMaps = {}
	p_u_66:iterate(p67 .. ".customShaderMap", function(_, p68)
		-- upvalues: (copy) p_u_66, (copy) p_u_64, (copy) p_u_65
		local v69 = {
			["name"] = p_u_66:getValue(p68 .. "#name"),
			["filename"] = p_u_66:getValue(p68 .. "#filename")
		}
		v69.filename = Utils.getFilename(v69.filename, p_u_64.baseDirectory)
		if v69.name == nil or v69.filename == nil then
			Logging.xmlError(p_u_66, "Failed to load custom shader map from \'%s\'", p68)
		else
			v69.texture = createMaterialTextureFromFile(v69.filename, true, false)
			if v69.texture ~= nil then
				local v70 = p_u_65.customShaderMaps
				table.insert(v70, v69)
				return
			end
		end
	end)
	p_u_65.customShaderParameters = {}
	p_u_66:iterate(p67 .. ".customShaderParameter", function(_, p71)
		-- upvalues: (copy) p_u_66, (copy) p_u_65
		local v72 = {
			["name"] = p_u_66:getValue(p71 .. "#name"),
			["value"] = p_u_66:getValue(p71 .. "#value", "0 0 0 0", true)
		}
		if v72.name == nil or v72.value == nil then
			Logging.xmlError(p_u_66, "Failed to load custom shader parameter from \'%s\'", p71)
		else
			local v73 = p_u_65.customShaderParameters
			table.insert(v73, v72)
		end
	end)
end
function MotionPathEffectManager.unloadMapData(p74)
	for v75 = 1, #p74.effects do
		local v76 = p74.effects[v75]
		p74:deleteCustomShaderMaps(v76)
		for v77 = 1, #v76.effectMeshes do
			local v78 = v76.effectMeshes[v77]
			delete(v78.node)
			p74:deleteCustomShaderMaps(v78)
		end
		for v79 = 1, #v76.effectMaterials do
			local v80 = v76.effectMaterials[v79]
			delete(v80.node)
			p74:deleteCustomShaderMaps(v80)
		end
	end
	for v81 = 1, #p74.sharedLoadRequestIds do
		local v82 = p74.sharedLoadRequestIds[v81]
		g_i3DManager:releaseSharedI3DFile(v82)
	end
	for v83, _ in pairs(p74.xmlFiles) do
		p74.xmlFiles[v83] = nil
		v83:delete()
	end
	MotionPathEffectManager:superClass().unloadMapData(p74)
end
function MotionPathEffectManager.deleteCustomShaderMaps(_, p84)
	for _, v85 in ipairs(p84.customShaderMaps) do
		if v85.texture ~= nil then
			delete(v85.texture)
			v85.texture = nil
		end
	end
end
function MotionPathEffectManager.getSharedMotionPathEffect(p86, p87)
	for v88 = 1, #p86.effects do
		local v89 = p86.effects[v88]
		if p87:getIsSharedEffectMatching(v89, false) then
			return v89
		end
	end
	for v90 = 1, #p86.effects do
		local v91 = p86.effects[v90]
		if p87:getIsSharedEffectMatching(v91, true) then
			return v91
		end
	end
	return nil
end
function MotionPathEffectManager.getMotionPathEffectMesh(_, p92, p93)
	for v94 = 1, #p92.effectMeshes do
		local v95 = p92.effectMeshes[v94]
		if p93:getIsEffectMeshMatching(v95, false) then
			return v95
		end
	end
	for v96 = 1, #p92.effectMeshes do
		local v97 = p92.effectMeshes[v96]
		if p93:getIsEffectMeshMatching(v97, true) then
			return v97
		end
	end
	return nil
end
function MotionPathEffectManager.getMotionPathEffectMaterial(_, p98, p99)
	for v100 = 1, #p98.effectMaterials do
		local v101 = p98.effectMaterials[v100]
		if p99:getIsEffectMaterialMatching(v101, false) then
			return v101
		end
	end
	for v102 = 1, #p98.effectMaterials do
		local v103 = p98.effectMaterials[v102]
		if p99:getIsEffectMaterialMatching(v103, true) then
			return v103
		end
	end
	return nil
end
function MotionPathEffectManager.applyEffectConfiguration(p104, p105, p106, p107, p108, p109, p110)
	if p105 == nil or p108 == nil then
		return p110 or 1
	end
	p104:applyShaderSettingsParameters(p108, p105)
	if p106 ~= nil then
		p104:applyShaderSettingsParameters(p108, p106)
	end
	if p107 ~= nil then
		p104:applyShaderSettingsParameters(p108, p107)
	end
	p104:setEffectCustomMap(p108, "shapeArray", p109)
	local v111 = p105.speedScale or 0.5
	local v112 = p106.speedScale or v111
	if p107 ~= nil then
		v112 = p107.speedScale or v112
	end
	return p110 or v112
end
function MotionPathEffectManager.applyShaderSettingsParameters(p113, p114, p115)
	for v116 = 1, #p115.customShaderMaps do
		local v117 = p115.customShaderMaps[v116]
		p113:setEffectCustomMap(p114, v117.name, v117.texture)
	end
	if p115.customShaderVariation ~= nil then
		p113:setEffectCustomShaderVariation(p114, p115.customShaderVariation)
	end
	for v118 = 1, #p115.customShaderParameters do
		local v119 = p115.customShaderParameters[v118]
		p113:setEffectShaderParameter(p114, v119.name, v119.value[1], v119.value[2], v119.value[3], v119.value[4], false)
	end
end
function MotionPathEffectManager.setEffectShaderParameter(_, p120, p121, p122, p123, p124, p125, p126)
	if getHasClassId(p120, ClassIds.SHAPE) then
		setShaderParameter(p120, p121, p122, p123, p124, p125, p126)
	end
	for v127 = 1, getNumOfChildren(p120) do
		local v128 = getChildAt(p120, v127 - 1)
		if getHasClassId(v128, ClassIds.SHAPE) then
			setShaderParameter(v128, p121, p122, p123, p124, p125, p126)
		end
	end
end
function MotionPathEffectManager.getEffectShaderParameter(_, p129, p130)
	if getHasClassId(p129, ClassIds.SHAPE) then
		return getShaderParameter(p129, p130)
	end
	for v131 = 1, getNumOfChildren(p129) do
		local v132 = getChildAt(p129, v131 - 1)
		if getHasClassId(v132, ClassIds.SHAPE) then
			return getShaderParameter(v132, p130)
		end
	end
	return 0, 0, 0, 0
end
function MotionPathEffectManager.setEffectCustomShaderVariation(_, p133, p134)
	if getHasClassId(p133, ClassIds.SHAPE) then
		local v135 = getMaterial(p133, 0)
		local v136 = setMaterialCustomShaderVariation(v135, p134, false)
		if v136 ~= v135 then
			setMaterial(p133, v136, 0)
		end
	end
	local v137 = getNumOfChildren(p133)
	if v137 > 0 then
		for v138 = 1, v137 do
			local v139 = getChildAt(p133, v138 - 1)
			if getHasClassId(v139, ClassIds.SHAPE) then
				local v140 = getMaterial(v139, 0)
				local v141 = setMaterialCustomShaderVariation(v140, p134, false)
				if v141 ~= v140 then
					setMaterial(v139, v141, 0)
				end
			end
		end
	end
end
function MotionPathEffectManager.setEffectCustomMapOnNode(_, p142, p143, p144)
	local v145 = getMaterial(p142, 0)
	if p144 ~= nil then
		local v146 = setMaterialCustomMap(v145, p143, p144, false)
		if v146 ~= v145 then
			setMaterial(p142, v146, 0)
		end
	end
end
function MotionPathEffectManager.setEffectCustomMap(p147, p148, p149, p150)
	if getHasClassId(p148, ClassIds.SHAPE) then
		p147:setEffectCustomMapOnNode(p148, p149, p150)
	end
	local v151 = getNumOfChildren(p148)
	if v151 > 0 then
		for v152 = 1, v151 do
			local v153 = getChildAt(p148, v152 - 1)
			if getHasClassId(v153, ClassIds.SHAPE) then
				p147:setEffectCustomMapOnNode(v153, p149, p150)
			end
		end
	end
end
function MotionPathEffectManager.setEffectMaterial(_, p154, p155)
	if getHasClassId(p154, ClassIds.SHAPE) then
		setMaterial(p154, p155.materialId, 0)
	end
	local v156 = getNumOfChildren(p154)
	if v156 > 0 then
		for v157 = 1, v156 do
			local v158 = getChildAt(p154, v157 - 1)
			if getHasClassId(v158, ClassIds.SHAPE) then
				local v159 = p155.materialId
				if v157 > 1 and p155.lod[v157] ~= nil then
					v159 = p155.lod[v157]
				end
				setMaterial(v158, v159, 0)
			end
		end
	end
end
function MotionPathEffectManager.createMotionPathEffectXMLSchema()
	if MotionPathEffectManager.xmlSchema == nil then
		local v160 = XMLSchema.new("mapMotionPathEffects")
		v160:register(XMLValueType.STRING, "motionPathEffects.motionPathEffect(?)#effectClass", "Effect class name")
		v160:register(XMLValueType.STRING, "motionPathEffects.motionPathEffect(?)#effectType", "Effect type name (can be multiple)")
		v160:register(XMLValueType.STRING, "motionPathEffects.motionPathEffect(?)#filename", "Path to effects i3d file")
		v160:register(XMLValueType.NODE_INDEX, "motionPathEffects.motionPathEffect(?).effectGeneration#rootNode", "(Only for automatic mesh generation) Mesh root node in maya file which has sub shapes")
		v160:register(XMLValueType.VECTOR_ROT, "motionPathEffects.motionPathEffect(?).effectGeneration#minRot", "(Only for automatic mesh generation) Min. random rotation")
		v160:register(XMLValueType.VECTOR_ROT, "motionPathEffects.motionPathEffect(?).effectGeneration#maxRot", "(Only for automatic mesh generation) Max. random rotation")
		v160:register(XMLValueType.VECTOR_SCALE, "motionPathEffects.motionPathEffect(?).effectGeneration#minScale", "(Only for automatic mesh generation) Min. random scale")
		v160:register(XMLValueType.VECTOR_SCALE, "motionPathEffects.motionPathEffect(?).effectGeneration#maxScale", "(Only for automatic mesh generation) Max. random scale")
		v160:register(XMLValueType.STRING, "motionPathEffects.motionPathEffect(?).effectGeneration#useFoliage", "(Only for automatic mesh generation) Name of foliage")
		v160:register(XMLValueType.INT, "motionPathEffects.motionPathEffect(?).effectGeneration#useFoliageStage", "(Only for automatic mesh generation) Foliage growth state")
		v160:register(XMLValueType.INT, "motionPathEffects.motionPathEffect(?).effectGeneration#useFoliageLOD", "(Only for automatic mesh generation) LOD to use")
		MotionPathEffect.registerEffectDefinitionXMLPaths(v160, "motionPathEffects.motionPathEffect(?).typeDefinition")
		TypedMotionPathEffect.registerEffectDefinitionXMLPaths(v160, "motionPathEffects.motionPathEffect(?).typeDefinition")
		CutterMotionPathEffect.registerEffectDefinitionXMLPaths(v160, "motionPathEffects.motionPathEffect(?).typeDefinition")
		CultivatorMotionPathEffect.registerEffectDefinitionXMLPaths(v160, "motionPathEffects.motionPathEffect(?).typeDefinition")
		PlowMotionPathEffect.registerEffectDefinitionXMLPaths(v160, "motionPathEffects.motionPathEffect(?).typeDefinition")
		WindrowerMotionPathEffect.registerEffectDefinitionXMLPaths(v160, "motionPathEffects.motionPathEffect(?).typeDefinition")
		v160:register(XMLValueType.NODE_INDEX, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)#node", "Index path in effect i3d")
		v160:register(XMLValueType.NODE_INDEX, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)#sourceNode", "(Only for automatic mesh generation) Index path to source object in maya file")
		v160:register(XMLValueType.INT, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)#rowLength", "Number of meshes on X axis (on effect texture)", 30)
		v160:register(XMLValueType.INT, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)#numRows", "Number of meshes on Y axis (on effect texture)", 12)
		v160:register(XMLValueType.INT, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)#skipPositions", "Number of skipped meshes on X axis", 0)
		v160:register(XMLValueType.INT, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)#numVariations", "Number of sub random variations", 1)
		v160:register(XMLValueType.VECTOR_SCALE, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)#boundingBox", "(Only for automatic mesh generation) Size of bounding box")
		v160:register(XMLValueType.VECTOR_TRANS, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)#boundingBoxCenter", "(Only for automatic mesh generation) Center of bounding box")
		v160:register(XMLValueType.NODE_INDEX, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?).lod(?)#sourceNode", "(Only for automatic mesh generation) Custom node for LOD")
		v160:register(XMLValueType.FLOAT, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?).lod(?)#distance", "(Only for automatic mesh generation) Distance of LOD")
		v160:register(XMLValueType.INT, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?).lod(?)#skipPositions", "(Only for automatic mesh generation) Custom skip positions")
		MotionPathEffectManager.registerCustomShaderSettingXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)")
		MotionPathEffect.registerEffectMeshXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)")
		TypedMotionPathEffect.registerEffectMeshXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)")
		CutterMotionPathEffect.registerEffectMeshXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)")
		CultivatorMotionPathEffect.registerEffectMeshXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)")
		PlowMotionPathEffect.registerEffectMeshXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)")
		WindrowerMotionPathEffect.registerEffectMeshXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMeshes.effectMesh(?)")
		v160:register(XMLValueType.NODE_INDEX, "motionPathEffects.motionPathEffect(?).effectMaterials#rootNode", "(Only for automatic mesh generation) Node which will be copied over the effect i3d file (position index in i3d is then \'0|1\')")
		v160:register(XMLValueType.NODE_INDEX, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?)#node", "Material node")
		v160:register(XMLValueType.NODE_INDEX, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?).lod(?)#node", "LOD node")
		v160:register(XMLValueType.STRING, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?).textures#diffuse", "Path to custom diffuse map to apply")
		v160:register(XMLValueType.STRING, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?).textures#normal", "Path to custom normal map to apply")
		v160:register(XMLValueType.STRING, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?).textures#specular", "Path to custom specular map to apply")
		MotionPathEffectManager.registerCustomShaderSettingXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?)")
		MotionPathEffect.registerEffectMaterialXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?)")
		TypedMotionPathEffect.registerEffectMaterialXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?)")
		CutterMotionPathEffect.registerEffectMaterialXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?)")
		CultivatorMotionPathEffect.registerEffectMaterialXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?)")
		PlowMotionPathEffect.registerEffectMaterialXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?)")
		WindrowerMotionPathEffect.registerEffectMaterialXMLPaths(v160, "motionPathEffects.motionPathEffect(?).effectMaterials.effectMaterial(?)")
		MotionPathEffectManager.registerCustomShaderSettingXMLPaths(v160, "motionPathEffects.motionPathEffect(?).customShaderDefaults")
		MotionPathEffectManager.xmlSchema = v160
	end
end
function MotionPathEffectManager.registerCustomShaderSettingXMLPaths(p161, p162)
	p161:register(XMLValueType.STRING, p162 .. ".customShaderVariation#name", "Shader variation to apply")
	p161:register(XMLValueType.STRING, p162 .. ".customShaderParameter(?)#name", "Name of shader parameter")
	p161:register(XMLValueType.VECTOR_4, p162 .. ".customShaderParameter(?)#value", "Value of shader parameter")
	p161:register(XMLValueType.STRING, p162 .. ".customShaderMap(?)#name", "Name of custom shader map")
	p161:register(XMLValueType.STRING, p162 .. ".customShaderMap(?)#filename", "Path to texture file")
end
g_motionPathEffectManager = MotionPathEffectManager.new()

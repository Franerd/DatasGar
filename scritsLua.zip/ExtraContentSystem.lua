ExtraContentSystem = {}
ExtraContentSystem.PROFILE_FILENAME = "extraContent.xml"
ExtraContentSystem.VALID_CHARS_STRING = "ABCDEFHJKLMNPQRSTWXYZ123456789"
ExtraContentSystem.VALID_CHARS_PATTERN = "[" .. ExtraContentSystem.VALID_CHARS_STRING .. "]"
ExtraContentSystem.VALID_CHARS_NOT_PATTERN = "[^" .. ExtraContentSystem.VALID_CHARS_STRING .. "]"
ExtraContentSystem.VALID_CHARS = string.split(ExtraContentSystem.VALID_CHARS_STRING, "")
ExtraContentSystem.KEY_LENGTH = 8
ExtraContentSystem.NUM_ITEM_CHARACTERS = 3
ExtraContentSystem.ITEM_INDEX_1 = 1
ExtraContentSystem.ITEM_INDEX_2 = 4
ExtraContentSystem.ITEM_INDEX_3 = 6
ExtraContentSystem.UNLOCKED = 0
ExtraContentSystem.ERROR_KEY_INVALID = 1
ExtraContentSystem.ERROR_ALREADY_UNLOCKED = 2
ExtraContentSystem.ERROR_KEY_INVALID_FORMAT = 3
local v_u_1 = Class(ExtraContentSystem)
function ExtraContentSystem.new(_, p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4.items = {}
	v4.idToItem = {}
	if g_isDevelopmentVersion then
		addConsoleCommand("gsExtraContentSystemCreateKeys", "Create keys for a given item code", "consoleCommandCreateKeys", v4)
		addConsoleCommand("gsExtraContentSystemCreateKeysAll", "Create keys for all items", "consoleCommandCreateKeysAll", v4)
		addConsoleCommand("gsExtraContentSystemUnlockAll", "Unlocks all items", "consoleCommandUnlockAll", v4)
		return v4
	end
	ExtraContentSystem.consoleCommandCreateKeys = nil
	ExtraContentSystem.consoleCommandCreateKeysAll = nil
	ExtraContentSystem.consoleCommandUnlockAll = nil
	ExtraContentSystem.createKeyItem = nil
	v4.consoleCommandCreateKeys = nil
	v4.consoleCommandCreateKeysAll = nil
	v4.consoleCommandUnlockAll = nil
	v4.createKeyItem = nil
	return v4
end
function ExtraContentSystem.delete(p5)
	p5.items = {}
	p5.idToItem = {}
	removeConsoleCommand("gsExtraContentSystemCreateKeys")
	removeConsoleCommand("gsExtraContentSystemCreateKeysAll")
	removeConsoleCommand("gsExtraContentSystemUnlockAll")
end
function ExtraContentSystem.loadFromXML(p_u_6, p7)
	local v_u_8 = XMLFile.load("extraContentSystem", p7, nil)
	if v_u_8 ~= nil then
		v_u_8:iterate("extraContent.item", function(_, p9)
			-- upvalues: (copy) v_u_8, (copy) p_u_6
			local v10 = v_u_8:getString(p9 .. "#id")
			local v11 = v_u_8:getString(p9 .. "#code")
			local v12 = v_u_8:getString(p9 .. ".title")
			local v13 = v_u_8:getString(p9 .. ".description")
			local v14 = v_u_8:getString(p9 .. ".imageFilename")
			local v15 = v_u_8:getBool(p9 .. "#isAutoUnlocked", false)
			if v10 == nil then
				Logging.xmlWarning(v_u_8, "Extra content item id is missing for \'%s\'", p9)
				return
			elseif v11 == nil then
				Logging.xmlWarning(v_u_8, "Extra content item code is missing for \'%s\'", p9)
				return
			else
				local v16 = v11:upper()
				local v17, v18 = p_u_6:getStringHasValidCharacters(v16)
				if v17 then
					local v19 = string.split(v16, "")
					if #v19 == ExtraContentSystem.NUM_ITEM_CHARACTERS then
						if v14 == nil then
							Logging.xmlWarning(v_u_8, "Extra content item imageFilename is missing for \'%s\'", p9)
							return
						elseif v12 == nil then
							Logging.xmlWarning(v_u_8, "Extra content item title is missing for \'%s\'", p9)
							return
						elseif v13 == nil then
							Logging.xmlWarning(v_u_8, "Extra content item description is missing for \'%s\'", p9)
						else
							p_u_6:addItem(v10, g_i18n:convertText(v12), g_i18n:convertText(v13), v14, v19, v15)
						end
					else
						Logging.xmlWarning(v_u_8, "Extra content item code needs to have %d characters for \'%s\'", ExtraContentSystem.NUM_ITEM_CHARACTERS, p9)
						return
					end
				else
					Logging.xmlWarning(v_u_8, "Extra content item code contains invalid charater \'%s\' for \'%s\'!", v18, p9)
					return
				end
			end
		end)
		v_u_8:delete()
	end
end
function ExtraContentSystem.addItem(p20, p21, p22, p23, p24, p25, p26)
	if p20.idToItem[p21] ~= nil then
		Logging.warning("Extra content item with id \'%s\' already exists!", p21)
		return
	end
	table.sort(p25, function(p27, p28)
		return p27 < p28
	end)
	local v29 = table.concat(p25, "")
	local v30 = true
	for _, v31 in ipairs(p20.items) do
		for v32, v33 in ipairs(v31.charList) do
			if v33 ~= p25[v32] then
				v30 = false
				break
			end
		end
	end
	if #p20.items > 0 and v30 then
		Logging.warning("Extra content code for \'%s\' is already used!", p21)
	else
		local v34 = {
			["id"] = p21,
			["title"] = p22,
			["description"] = p23,
			["imageFilename"] = p24,
			["charList"] = p25,
			["code"] = v29,
			["isAutoUnlocked"] = p26,
			["isUnlocked"] = false,
			["unlockedByDLC"] = false
		}
		local v35 = p20.items
		table.insert(v35, v34)
		p20.idToItem[p21] = v34
	end
end
function ExtraContentSystem.loadFromProfile(p_u_36)
	local v37 = getUserProfileAppPath() .. ExtraContentSystem.PROFILE_FILENAME
	if fileExists(v37) then
		local v_u_38 = false
		local v_u_39 = XMLFile.load("extraContentProfile", v37, nil)
		if v_u_39 ~= nil then
			v_u_39:iterate("extraContent.usedKey", function(_, p40)
				-- upvalues: (copy) v_u_39, (ref) v_u_38, (copy) p_u_36
				local v41 = v_u_39:getString(p40)
				local v42 = v_u_39:getBool(p40 .. "#unlockedByDLC")
				if v42 == nil then
					v_u_38 = true
				end
				if v41 ~= nil and v42 == false then
					local v43, _ = p_u_36:unlockItem(v41, v42)
					if v43 ~= nil then
						print("Extra Content: Unlocked \'" .. v43.id .. "\'")
					end
				end
			end)
			v_u_39:delete()
		end
		if v_u_38 then
			p_u_36:saveToProfile()
		end
	end
end
function ExtraContentSystem.saveToProfile(p44)
	local v45 = getUserProfileAppPath() .. ExtraContentSystem.PROFILE_FILENAME
	local v46 = XMLFile.create("extraContentProfile", v45, "extraContent", nil)
	local v47 = 0
	for _, v48 in ipairs(p44.items) do
		if v48.isUnlocked and v48.usedKey ~= nil then
			v46:setString(string.format("extraContent.usedKey(%d)", v47), v48.usedKey)
			v46:setBool(string.format("extraContent.usedKey(%d)#unlockedByDLC", v47), Utils.getNoNil(v48.unlockedByDLC, false))
			v47 = v47 + 1
		end
	end
	v46:save()
	v46:delete()
	syncProfileFiles()
end
function ExtraContentSystem.reset(p49)
	for _, v50 in ipairs(p49.items) do
		v50.isUnlocked = false
		v50.unlockedByDLC = false
		v50.usedKey = nil
	end
end
function ExtraContentSystem.getItemByKey(p51, p52)
	if p52 == nil or p52:len() ~= ExtraContentSystem.KEY_LENGTH then
		return nil, ExtraContentSystem.ERROR_KEY_INVALID_FORMAT
	else
		local v53, _ = p51:getStringHasValidCharacters(p52)
		if v53 then
			local v54 = string.split(p52, "")
			if #v54 == ExtraContentSystem.KEY_LENGTH then
				local v55 = { v54[ExtraContentSystem.ITEM_INDEX_1], v54[ExtraContentSystem.ITEM_INDEX_2], v54[ExtraContentSystem.ITEM_INDEX_3] }
				table.sort(v55, function(p56, p57)
					return p56 < p57
				end)
				local v58 = p51:getItemByCode(v55)
				if v58 == nil then
					return nil, ExtraContentSystem.ERROR_KEY_INVALID
				elseif v54[ExtraContentSystem.KEY_LENGTH] == p51:getChecksumChar(v54) then
					return v58
				else
					return nil, ExtraContentSystem.ERROR_KEY_INVALID
				end
			else
				return nil, ExtraContentSystem.ERROR_KEY_INVALID_FORMAT
			end
		else
			return nil, ExtraContentSystem.ERROR_KEY_INVALID
		end
	end
end
function ExtraContentSystem.getItemByCode(p59, p60)
	local v61 = nil
	for _, v62 in ipairs(p59.items) do
		local v63 = true
		for v64, v65 in ipairs(v62.charList) do
			if v65 ~= p60[v64] then
				v63 = false
				break
			end
		end
		if v63 then
			return v62
		end
	end
	return v61
end
function ExtraContentSystem.unlockItem(p66, p67, p68)
	local v69, v70 = p66:getItemByKey(p67)
	if v69 == nil then
		return nil, v70
	end
	if v69.isUnlocked then
		return v69, ExtraContentSystem.ERROR_ALREADY_UNLOCKED
	end
	v69.isUnlocked = true
	v69.usedKey = p67
	v69.unlockedByDLC = p68
	p66:saveToProfile()
	return v69, ExtraContentSystem.UNLOCKED
end
function ExtraContentSystem.getIsItemIdUnlocked(p71, p72)
	local v73 = p71.idToItem[p72]
	if v73 ~= nil then
		return p71:getIsItemUnlocked(v73)
	end
	Logging.warning("ExtraContent item \'%s\' does not exist!", (tostring(p72)))
	return false
end
function ExtraContentSystem.getIsItemUnlocked(_, p74)
	if p74 == nil then
		return false
	else
		return p74.isAutoUnlocked and true or p74.isUnlocked
	end
end
function ExtraContentSystem.getUnlockedItems(p75)
	local v76 = {}
	for _, v77 in ipairs(p75.items) do
		if p75:getIsItemUnlocked(v77) then
			table.insert(v76, v77)
		end
	end
	return v76
end
function ExtraContentSystem.getHasLockedItems(p78)
	for _, v79 in ipairs(p78.items) do
		if not p78:getIsItemUnlocked(v79) then
			return true
		end
	end
	return false
end
function ExtraContentSystem.getStringHasValidCharacters(_, p80)
	local v81 = p80:match(ExtraContentSystem.VALID_CHARS_NOT_PATTERN)
	return v81 == nil, v81
end
function ExtraContentSystem.getChecksumChar(_, p82)
	local v83 = 0
	for _ = 1, ExtraContentSystem.KEY_LENGTH - 1 do
		local v84 = p82[1]
		v83 = v83 + string.byte(v84)
	end
	local v85 = v83 % #ExtraContentSystem.VALID_CHARS + 1
	return ExtraContentSystem.VALID_CHARS[v85]
end
function ExtraContentSystem.consoleCommandUnlockAll(p86)
	for _, v87 in ipairs(p86.items) do
		p86:unlockItem((p86:createItemKey(v87, (table.copyIndex(v87.charList)))))
	end
end
function ExtraContentSystem.consoleCommandCreateKeysAll(p88, p89)
	local v90 = tonumber(p89) or 1
	setFileLogPrefixTimestamp(false)
	for _, v91 in ipairs(p88.items) do
		print(string.format("Generating keys for item \'%s\':", g_i18n:convertText(v91.title)))
		local v92 = table.copyIndex(v91.charList)
		local v93 = v90
		local v94 = {}
		while v90 > 0 do
			local v95 = p88:createItemKey(v91, v92)
			if v95 == nil then
				return
			end
			if v94[v95] == nil then
				print("    " .. v95)
				v94[v95] = true
				v90 = v90 - 1
			end
		end
		v90 = v93
	end
	setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
	return "Finished"
end
function ExtraContentSystem.consoleCommandCreateKeys(p96, p97, p98, p99)
	local v100 = tonumber(p98) or 1
	if p97 == nil then
		return "Invalid item code"
	end
	local v_u_101 = {}
	if p99 ~= nil then
		local v_u_102 = XMLFile.load("keys", p99)
		if v_u_102 == nil then
			return "Could not load given existing key file"
		end
		local v_u_103 = 0
		v_u_102:iterate("keys.key", function(_, p104)
			-- upvalues: (copy) v_u_102, (copy) v_u_101, (ref) v_u_103
			local v105 = v_u_102:getString(p104)
			if v105 ~= nil then
				v_u_101[string.trim(v105)] = true
				v_u_103 = v_u_103 + 1
			end
		end)
		print(string.format("Loaded %d existing keys from file...", v_u_103))
	end
	local v106 = p97:upper()
	local v107, _ = p96:getStringHasValidCharacters(v106)
	if not v107 then
		return "Invalid item code"
	end
	local v108 = string.split(v106, "")
	if #v108 ~= ExtraContentSystem.NUM_ITEM_CHARACTERS then
		return "Invalid item code"
	end
	table.sort(v108, function(p109, p110)
		return p109 < p110
	end)
	local v111 = p96:getItemByCode(v108)
	if v111 == nil then
		return "Item not found in extra content system"
	end
	setFileLogPrefixTimestamp(false)
	print(string.format("Generating keys for item \'%s\':", g_i18n:convertText(v111.title)))
	while v100 > 0 do
		local v112 = p96:createItemKey(v111, v108)
		if v112 == nil then
			return
		end
		if v_u_101[v112] == nil then
			print("    " .. v112)
			v_u_101[v112] = true
			v100 = v100 - 1
		end
	end
	setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
	return "Finished"
end
function ExtraContentSystem.createItemKey(p113, p114, p115)
	local v116 = #ExtraContentSystem.VALID_CHARS
	local v117 = {}
	for _ = 1, ExtraContentSystem.KEY_LENGTH - ExtraContentSystem.NUM_ITEM_CHARACTERS - 1 do
		local v118 = math.random(1, v116)
		local v119 = ExtraContentSystem.VALID_CHARS[v118]
		table.insert(v117, v119)
	end
	Utils.shuffle(p115)
	local v120 = ExtraContentSystem.ITEM_INDEX_1
	local v121 = p115[1]
	table.insert(v117, v120, v121)
	local v122 = ExtraContentSystem.ITEM_INDEX_2
	local v123 = p115[2]
	table.insert(v117, v122, v123)
	local v124 = ExtraContentSystem.ITEM_INDEX_3
	local v125 = p115[3]
	table.insert(v117, v124, v125)
	local v126 = p113:getChecksumChar(v117)
	table.insert(v117, v126)
	local v127 = table.concat(v117, "")
	local v128, v129 = p113:getItemByKey(v127)
	if v128 ~= nil and p114 == v128 then
		return v127
	end
	Logging.error("Created invalid product key (error code: %s) - %s", tostring(v129), v127)
	return nil
end

function mouseEvent(p1, p2, p3, p4, p5)
	if g_currentTest == nil then
		Input.updateMouseButtonState(p5, p3)
		g_inputBinding:mouseEvent(p1, p2, p3, p4, p5)
		if Platform.hasTouchInput then
			if p5 == Input.MOUSE_BUTTON_WHEEL_UP or p5 == Input.MOUSE_BUTTON_WHEEL_DOWN then
				if g_currentMission == nil or g_currentMission:getAllowsGuiDisplay() then
					g_gui:mouseEvent(p1, p2, p3, p4, p5)
				end
			else
				touchEvent(p1, p2, p3, p4, TouchHandler.MOUSE_TOUCH_ID)
			end
		else
			if g_currentMission == nil or g_currentMission:getAllowsGuiDisplay() then
				g_gui:mouseEvent(p1, p2, p3, p4, p5)
			end
			if g_currentMission ~= nil and g_currentMission.isLoaded then
				g_currentMission:mouseEvent(p1, p2, p3, p4, p5)
			end
		end
		g_lastMousePosX = p1
		g_lastMousePosY = p2
	else
		g_currentTest.mouseEvent(p1, p2, p3, p4, p5)
	end
end
function touchEvent(p6, p7, p8, p9, p10)
	if g_touchHandler ~= nil then
		g_touchHandler:onTouchEvent(p6, p7, p8, p9, p10)
	end
	if g_touchHandler.contextName == nil then
		if g_currentMission == nil or g_currentMission:getAllowsGuiDisplay() then
			g_gui:touchEvent(p6, p7, p8, p9, p10)
		end
		if g_inputBinding ~= nil then
			g_inputBinding:touchEvent(p6, p7, p8, p9, p10)
		end
	end
end
function keyEvent(p11, p12, p13, p14)
	if g_currentTest == nil then
		Input.updateKeyState(p12, p14)
		g_inputBinding:keyEvent(p11, p12, p13, p14)
		if g_currentMission == nil or g_currentMission:getAllowsGuiDisplay() then
			g_gui:keyEvent(p11, p12, p13, p14)
		end
		if g_currentMission ~= nil and g_currentMission.isLoaded then
			g_currentMission:keyEvent(p11, p12, p13, p14)
		end
	else
		g_currentTest.keyEvent(p11, p12, p13, p14)
	end
end
function onUserSignedOut()
	g_isSignedIn = false
	g_gamepadSigninScreen.forceShowSigninGui = true
	forceEndFrameRepeatMode()
	if g_currentMission == nil then
		g_masterServerConnection:disconnectFromMasterServer()
		g_connectionManager:shutdownAll()
		g_gui:showGui("GamepadSigninScreen")
		return
	elseif g_currentMission.isMissionStarted then
		g_currentMission:pauseGame()
		g_masterServerConnection:disconnectFromMasterServer()
		g_gui:showGui("GamepadSigninScreen")
	else
		OnInGameMenuMenu(true)
	end
end
function finishedUserProfileSync()
	if GS_PLATFORM_XBOX then
		loadUserSettings(g_gameSettings)
		g_messageCenter:publish(MessageType.USER_PROFILE_CHANGED)
	elseif GS_IS_NETFLIX_VERSION and getLanguage() ~= g_language then
		doRestart(false, "")
	end
end
function onWaitForPendingGameSession()
	if g_currentMission == nil then
		if g_startupScreen == nil then
			g_skipStartupScreen = true
		else
			g_startupScreen:onStartupEnd()
		end
	end
	InfoDialog.show(g_i18n:getText("ui_waitForPendingGameSession"), nil, nil, g_i18n:getText("button_cancel"))
end
function onMultiplayerInviteSent()
	local v15 = g_currentMission
	if v15 == nil then
		onMultiplayerInviteStartSavegame()
		return true
	end
	if v15.missionDynamicInfo.isMultiplayer then
		return false
	end
	Logging.info("Switching to multiplayer game")
	g_savegameController:saveSavegame(v15.missionInfo)
	g_savegameController.onSaveCompleteCallback = onMultiplayerInviteSaveCompleteCallback
	g_inGameMenu:startSavingGameDisplay()
	g_multiplayerInviteSentData = {
		["savegameIndex"] = v15.missionInfo.savegameIndex
	}
	return true
end
function onMultiplayerInviteSaveCompleteCallback(_, p16)
	function g_savegameController.onSaveCompleteCallback() end
	g_inGameMenu:notifySaveComplete()
	MessageDialog.hide()
	if p16 == Savegame.ERROR_OK then
		OnInGameMenuMenu()
		onMultiplayerInviteStartSavegame(g_multiplayerInviteSentData.savegameIndex)
		g_multiplayerInviteSentData = nil
	else
		YesNoDialog.show(function(p17)
			if p17 then
				onMultiplayerInviteStartSavegame(nil)
			end
		end, nil, g_i18n:getText("ui_savingFailedContinueWithoutSaving"), nil, g_i18n:getText("button_continue"), g_i18n:getText("button_cancel"))
	end
end
function onMultiplayerInviteStartSavegame(p18)
	g_gui:setIsMultiplayer(true)
	g_gui:showGui("CareerScreen")
	if p18 ~= nil then
		g_careerScreen.selectedIndex = p18
		local v19 = g_savegameController:getSavegame(g_careerScreen.selectedIndex)
		g_careerScreen.currentSavegame = v19
		g_careerScreen:onStartAction()
		if v19 == SavegameController.NO_SAVEGAME or not v19.isValid then
			return
		end
		if g_gui.currentGuiName == "ModSelectionScreen" then
			g_modSelectionScreen:onClickOk()
		end
	end
end
function onRemovedFromInvite()
	if g_currentMission ~= nil then
		Logging.info("You have been uninvited by the host")
		OnInGameMenuMenu()
		InfoDialog.show(g_i18n:getText("ui_uninvited"))
	end
end
local function v_u_20()
	g_gamepadSigninScreen.forceShowSigninGui = true
	g_gui:showGui("GamepadSigninScreen")
end
function acceptedGameInvite(p21, p22)
	-- upvalues: (copy) v_u_20
	g_gui:closeDialogByName("InfoDialog")
	resetMultiplayerChecks()
	if g_currentMission ~= nil then
		g_invitePlatformServerId = p21
		g_inviteRequestUserName = p22
		OnInGameMenuMenu()
		if g_pendingRestartData ~= nil then
			return
		end
		g_invitePlatformServerId = nil
		g_inviteRequestUserName = nil
	end
	if Platform.isXbox and (g_gui.currentGuiName == "GamepadSigninScreen" or not g_isSignedIn) then
		g_tempDeepLinkingInfo = {}
		g_tempDeepLinkingInfo.platformServerId = p21
		g_tempDeepLinkingInfo.requestUserName = p22
		return
	elseif Platform.isXbox and (p22 ~= "" and g_gameSettings:getValue(GameSettings.SETTING.ONLINE_PRESENCE_NAME) ~= p22) then
		g_tempDeepLinkingInfo = {}
		g_tempDeepLinkingInfo.platformServerId = p21
		g_tempDeepLinkingInfo.requestUserName = p22
		InfoDialog.show(string.format(g_i18n:getText("dialog_signinWithUserToAcceptInvite"), p22), v_u_20)
	elseif Platform.isXbox or Platform.isPlaystation then
		if PlatformPrivilegeUtil.checkMultiplayer(acceptedGameInvitePerformConnect, nil, p21, 30000) then
			acceptedGameInvitePerformConnect(p21)
			return
		end
	else
		acceptedGameInvitePerformConnect(p21)
	end
end
function acceptedGameInvitePerformConnect(p23)
	connectToServer(p23)
end
function acceptedGameCreate()
	if g_currentMission ~= nil then
		OnInGameMenuMenu()
	end
	g_createGameScreen.usePendingInvites = true
	g_gui:setIsMultiplayer(true)
	g_gui:showGui("CareerScreen")
end
function onDeepLinkingFailed()
	g_deepLinkingInfo = nil
	g_showDeeplinkingFailedMessage = true
end
function onFriendListChanged()
	g_masterServerConnection:reconnectToMasterServer()
end
function onBlockedListChanged()
	if g_messageCenter ~= nil then
		g_messageCenter:publish(MessageType.BLOCK_LIST_CHANGED)
	end
end
local v_u_24 = true
function notifyWindowGainedFocus()
	-- upvalues: (ref) v_u_24
	v_u_24 = true
	if g_messageCenter ~= nil then
		g_messageCenter:publish(MessageType.APP_WINDOW_FOCUS_CHANGED, v_u_24)
	end
end
function notifyWindowLostFocus()
	-- upvalues: (ref) v_u_24
	v_u_24 = false
	if g_messageCenter ~= nil then
		g_messageCenter:publish(MessageType.APP_WINDOW_FOCUS_CHANGED, v_u_24)
	end
end
function getHasWindowFocus()
	-- upvalues: (ref) v_u_24
	return v_u_24
end
function notifyAppSuspended()
	g_appIsSuspended = true
	if g_messageCenter ~= nil then
		g_messageCenter:publish(MessageType.APP_SUSPENDED)
	end
end
function notifyAppResumed()
	g_appIsSuspended = false
	if g_messageCenter ~= nil then
		g_messageCenter:publish(MessageType.APP_RESUMED)
	end
end
function notifyWindowSizeChanged()
	Logging.info("Window size changed. Restarting application")
	g_messageCenter:publish(MessageType.APP_SUSPENDED)
	if g_currentMission == nil then
		RestartManager:setStartScreen(RestartManager.START_SCREEN_MAIN)
		doRestart(false, "")
	else
		OnInGameMenuMenu()
	end
end
function notifyDebugModeChanged(p25)
	if g_messageCenter ~= nil then
		g_messageCenter:publish(MessageType.DEBUG_MODE_CHANGED, p25)
	end
end

InputDevice = {}
local v_u_1 = Class(InputDevice)
InputDevice.CATEGORY = {
	["UNKNOWN"] = GamepadCategories.CATEGORY_UNKNOWN,
	["GAMEPAD"] = GamepadCategories.CATEGORY_GAMEPAD,
	["WHEEL"] = GamepadCategories.CATEGORY_WHEEL,
	["JOYSTICK"] = GamepadCategories.CATEGORY_JOYSTICK,
	["FARMWHEEL"] = GamepadCategories.CATEGORY_FARMWHEEL,
	["FARMPANEL"] = GamepadCategories.CATEGORY_FARMSIDEPANEL,
	["FARMWHEEL_HORI"] = GamepadCategories.CATEGORY_FARMWHEEL_HORI,
	["FARMPANEL_HORI"] = GamepadCategories.CATEGORY_FARMSIDEPANEL_HORI,
	["FARMJOYSTICK_THRUSTMASTER"] = GamepadCategories.CATEGORY_FARMJOYSTICK_THRUSTMASTER,
	["KEYBOARD_MOUSE"] = 253,
	["WHEEL_AND_PANEL"] = 254,
	["FARMWHEEL_AND_PANEL"] = 255
}
InputDevice.DEFAULT_DEVICE_NAMES = {
	["KB_MOUSE_DEFAULT"] = "KB_MOUSE_DEFAULT",
	["GAMEPAD_DEFAULT"] = "GAMEPAD_DEFAULT",
	["JOYSTICK_DEFAULT"] = "JOYSTICK_DEFAULT",
	["WHEEL_DEFAULT"] = "WHEEL_DEFAULT",
	["FARM_WHEEL_DEFAULT"] = "FARM_WHEEL_DEFAULT",
	["PANEL_DEFAULT"] = "PANEL_DEFAULT",
	["FARM_WHEEL_HORI_DEFAULT"] = "FARM_WHEEL_HORI_DEFAULT",
	["FARM_PANEL_HORI_DEFAULT"] = "FARM_PANEL_HORI_DEFAULT",
	["FARM_JOYSTICK_THRUSTMASTER_DEFAULT"] = "FARM_JOYSTICK_THRUSTMASTER_DEFAULT"
}
InputDevice.NAMES = {
	["SAITEK_WHEEL"] = "Saitek Heavy Eqpt. Wheel & Pedal",
	["SAITEK_PANEL"] = "Saitek Side Panel Control Deck",
	["HORI_WHEEL"] = "HORI FARMING CONTROLLER STEERING",
	["HORI_PANEL"] = "HORI FARMING CONTROLLER PANEL",
	["XINPUT_GAMEPAD"] = "XINPUT_GAMEPAD",
	["XBOX_GAMEPAD"] = "Xbox Gamepad",
	["PS_GAMEPAD"] = "DUALSHOCK(R)4",
	["PS5_GAMEPAD"] = "DualSense Wireless Controller",
	["STADIA_GAMEPAD"] = "Stadia Controller",
	["SWITCH_GAMEPAD"] = "Nintendo Controller"
}
InputDevice.DEFAULT_DEVICE_CATEGORIES = {
	[InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT] = InputDevice.CATEGORY.KEYBOARD_MOUSE,
	[InputDevice.DEFAULT_DEVICE_NAMES.GAMEPAD_DEFAULT] = InputDevice.CATEGORY.GAMEPAD,
	[InputDevice.DEFAULT_DEVICE_NAMES.JOYSTICK_DEFAULT] = InputDevice.CATEGORY.JOYSTICK,
	[InputDevice.DEFAULT_DEVICE_NAMES.WHEEL_DEFAULT] = InputDevice.CATEGORY.WHEEL,
	[InputDevice.DEFAULT_DEVICE_NAMES.FARM_WHEEL_DEFAULT] = InputDevice.CATEGORY.FARMWHEEL,
	[InputDevice.DEFAULT_DEVICE_NAMES.PANEL_DEFAULT] = InputDevice.CATEGORY.FARMPANEL,
	[InputDevice.DEFAULT_DEVICE_NAMES.FARM_WHEEL_HORI_DEFAULT] = InputDevice.CATEGORY.FARMWHEEL_HORI,
	[InputDevice.DEFAULT_DEVICE_NAMES.FARM_PANEL_HORI_DEFAULT] = InputDevice.CATEGORY.FARMPANEL_HORI,
	[InputDevice.DEFAULT_DEVICE_NAMES.FARM_JOYSTICK_THRUSTMASTER_DEFAULT] = InputDevice.CATEGORY.FARMJOYSTICK_THRUSTMASTER
}
function InputDevice.new(p2, p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = v_u_1
	local v7 = setmetatable({}, v6)
	v7.internalId = p2
	v7.deviceId = p3
	v7.deviceName = p4
	v7.category = p5
	v7.deadzones = {}
	v7.sensitivities = {}
	v7.isActive = false
	v7.forceFeedbackState = {}
	for v8 = 0, Input.MAX_NUM_AXES do
		v7.forceFeedbackState[v8] = {
			["isSupported"] = nil,
			["force"] = 0,
			["position"] = 0
		}
	end
	return v7
end
function InputDevice.loadSettingsFromXML(p9, p10, p11)
	p9.deadzones = {}
	p9.sensitivities = {}
	local v12 = 0
	while true do
		local v13 = string.format(p11 .. ".attributes(%d)", v12)
		if not hasXMLProperty(p10, v13) then
			break
		end
		local v14 = getXMLInt(p10, v13 .. "#axis")
		if v14 then
			local v15 = getXMLFloat(p10, v13 .. "#deadzone")
			p9.deadzones[v14] = v15 or getGamepadDefaultDeadzone()
			local v16 = getXMLFloat(p10, v13 .. "#sensitivity")
			p9.sensitivities[v14] = v16 or 1
		end
		v12 = v12 + 1
	end
end
function InputDevice.saveSettingsToXML(p17, p18, p19)
	setXMLString(p18, p19 .. "#id", p17.deviceId)
	setXMLString(p18, p19 .. "#name", p17.deviceName)
	setXMLInt(p18, p19 .. "#category", p17.category)
	local v20 = p19 .. ".attributes(0)"
	while hasXMLProperty(p18, v20) do
		removeXMLProperty(p18, v20)
	end
	local v21 = 0
	for v22 = 0, Input.MAX_NUM_AXES - 1 do
		local v23
		if p17.internalId >= 0 then
			v23 = getHasGamepadAxis(v22, p17.internalId)
		else
			v23 = p17.deadzones[v22] ~= nil and true or p17.sensitivities[v22] ~= nil
		end
		if v23 then
			local v24 = string.format(p19 .. ".attributes(%d)", v21)
			setXMLInt(p18, v24 .. "#axis", v22)
			setXMLFloat(p18, v24 .. "#deadzone", p17:getDeadzone(v22))
			setXMLFloat(p18, v24 .. "#sensitivity", p17:getSensitivity(v22))
			v21 = v21 + 1
		end
	end
end
function InputDevice.isController(p25)
	local v26 = p25.category
	if v26 then
		v26 = p25.category ~= InputDevice.CATEGORY.KEYBOARD_MOUSE
	end
	return v26
end
function InputDevice.setDeadzone(p27, p28, p29)
	p27.deadzones[p28] = p29
end
function InputDevice.getDeadzone(p30, p31)
	if p30.deadzones[p31] == nil then
		return getGamepadDefaultDeadzone()
	else
		return p30.deadzones[p31]
	end
end
function InputDevice.setSensitivity(p32, p33, p34)
	p32.sensitivities[p33] = p34
end
function InputDevice.getSensitivity(p35, p36)
	return p35.sensitivities[p36] == nil and 1 or p35.sensitivities[p36]
end
function InputDevice.updateForceFeedbackState(p37, p38)
	local v39 = p37.forceFeedbackState[p38]
	if v39 ~= nil and v39.isSupported == nil then
		v39.isSupported = getHasGamepadAxisForceFeedback(p37.internalId, p38)
	end
	return false
end
function InputDevice.getIsForceFeedbackSupported(p40, p41)
	local v42 = p40.forceFeedbackState[p41]
	if v42 == nil or v42.isSupported == nil then
		return false
	else
		return v42.isSupported
	end
end
function InputDevice.setForceFeedback(p43, p44, p45, p46)
	local v47 = p43.forceFeedbackState[p44]
	if v47 ~= nil then
		v47.force = p45
		v47.position = p46
		setGamepadAxisForceFeedback(p43.internalId, p44, p45, p46)
	end
end
function InputDevice.loadIdFromXML(p48, p49)
	return getXMLString(p48, p49 .. "#id") or ""
end
function InputDevice.loadNameFromXML(p50, p51)
	return getXMLString(p50, p51 .. "#name") or ""
end
function InputDevice.loadCategoryFromXML(p52, p53)
	return getXMLInt(p52, p53 .. "#category") or InputDevice.CATEGORY.UNKNOWN
end
function InputDevice.getDeviceIdPrefix(p54)
	local v55, v56 = string.match(p54, "^(-?%d+)_(.+)$")
	return not (v55 and tonumber(v55)) and -1 or tonumber(v55), v56
end
function InputDevice.getPrefixedDeviceId(p57, p58)
	return string.format("%d_%s", p58, p57)
end
function InputDevice.getIsDeviceSupported(_, p59)
	return p59 ~= IgnitionLockManager.DEVICE_NAME
end
function InputDevice.toString(p60)
	local v61 = string.format
	local v62 = p60.deviceName
	local v63 = tostring(v62)
	local v64 = p60.isActive
	local v65 = tostring(v64)
	local v66 = p60.internalId
	local v67 = tostring(v66)
	local v68 = p60.deviceId
	local v69 = tostring(v68)
	local v70 = p60.category
	return v61("[%s (active: %s), internalId: %s, deviceId: %s, category: %s]", v63, v65, v67, v69, (tostring(v70)))
end
v_u_1.__tostring = InputDevice.toString

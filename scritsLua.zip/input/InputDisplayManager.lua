InputDisplayManager = {}
local v_u_1 = Class(InputDisplayManager)
source("dataS/scripts/input/DisplayActionBinding.lua")
source("dataS/scripts/input/InputHelpElement.lua")
InputDisplayManager.CONTROLLER_SYMBOLS_PATH = "dataS/controllerSymbols.xml"
InputDisplayManager.AXIS_ICON_DEFINITIONS_PATH = "dataS/axisIcons.xml"
InputDisplayManager.SYMBOLS_TEXTURE_CONFIG_PATH = "dataS/menu/controllerSymbols.xml"
InputDisplayManager.AXIS_ICON_BASE_SIZE = 40
InputDisplayManager.SYMBOL_PREFIX_XBOX = "xbox_"
InputDisplayManager.SYMBOL_PREFIX_PS4 = "ps4_"
InputDisplayManager.SYMBOL_PREFIX_PS5 = "ps5_"
InputDisplayManager.SYMBOL_PREFIX_MOUSE = "mouse_"
InputDisplayManager.SYMBOL_PREFIX_SWITCH = "switch_"
InputDisplayManager.SYMBOL_PREFIX_MOBILE = "mobile_"
InputDisplayManager.SYMBOL_PREFIX_STADIA = "stadia_"
InputDisplayManager.AXIS_NAME_X = "X"
InputDisplayManager.AXIS_NAME_Y = "Y"
InputDisplayManager.AXIS_NAME_MOUSE_X = InputBinding.MOUSE_AXIS_NAMES[Input.AXIS_X]
InputDisplayManager.AXIS_NAME_MOUSE_Y = InputBinding.MOUSE_AXIS_NAMES[Input.AXIS_Y]
InputDisplayManager.AXIS_AFFIX_POSITIVE = "(+)"
InputDisplayManager.AXIS_AFFIX_NEGATIVE = "(-)"
InputDisplayManager.MODIFIER_BUTTON_CONCAT = " + "
InputDisplayManager.PLUS_OVERLAY_NAME = "PLUS"
InputDisplayManager.OR_OVERLAY_NAME = "OR"
InputDisplayManager.NO_HELP_ELEMENT = InputHelpElement.new()
function InputDisplayManager.new(p2, p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = v_u_1
	local v_u_7 = setmetatable({}, v6)
	v_u_7.messageCenter = p2
	v_u_7.inputManager = p3
	v_u_7.modManager = p4
	v_u_7.isConsoleVersion = p5
	v_u_7.isMobileVersion = GS_IS_MOBILE_VERSION
	p2:subscribe(MessageType.INPUT_BINDINGS_CHANGED, v_u_7.onActionBindingsChanged, v_u_7)
	p3:setEventChangeCallback(function(p8)
		-- upvalues: (copy) v_u_7
		v_u_7:onActionEventsChanged(p8)
	end)
	v_u_7.actionList = p3:getActionList()
	v_u_7.actionBindings = p3:getActionBindings()
	v_u_7.eventHelpElements = {
		[GS_INPUT_HELP_MODE_GAMEPAD] = {},
		[GS_INPUT_HELP_MODE_KEYBOARD] = {},
		[GS_INPUT_HELP_MODE_TOUCH] = {}
	}
	v_u_7.eventComboButtons = {
		[GS_INPUT_HELP_MODE_GAMEPAD] = {},
		[GS_INPUT_HELP_MODE_KEYBOARD] = {},
		[GS_INPUT_HELP_MODE_TOUCH] = {}
	}
	v_u_7.controllerSymbols = {}
	v_u_7.plusOverlay = nil
	v_u_7.orOverlay = nil
	v_u_7.keyboardKeyOverlay = nil
	v_u_7.axisIconOverlays = {}
	v_u_7.buttonIconSize = 45
	v_u_7.uiScale = 1
	g_overlayManager:addTextureConfigFile(InputDisplayManager.SYMBOLS_TEXTURE_CONFIG_PATH, "controllerSymbols")
	v_u_7.debugControllerSymbols = false
	return v_u_7
end
function InputDisplayManager.load(p9)
	p9.uiScale = g_gameSettings:getValue(GameSettings.SETTING.UI_SCALE)
	p9:setDevGamepadLabelMapping()
	p9:loadControllerSymbolsAndOverlays()
	local v10 = loadXMLFile("AxisIcons", InputDisplayManager.AXIS_ICON_DEFINITIONS_PATH)
	p9:loadAxisIcons(v10)
	delete(v10)
	p9:loadModAxisIcons()
	addConsoleCommand("gsInputDebugControllerSymbols", "", "consoleCommandShowInputControllerSymbols", p9)
end
function InputDisplayManager.delete(p11)
	g_messageCenter:unsubscribeAll(p11)
	for _, v12 in pairs(p11.controllerSymbols) do
		v12.overlay:delete()
	end
	for _, v13 in pairs(p11.axisIconOverlays) do
		v13:delete()
	end
	p11.keyboardKeyOverlay:delete()
end
function InputDisplayManager.setDevGamepadLabelMapping(_)
	if GS_PLATFORM_PLAYSTATION and g_isDevelopmentVersion then
		local v_u_14 = {
			["A"] = "Cross",
			["B"] = "Circle",
			["X"] = "Square",
			["Y"] = "Triangle",
			["LB"] = "L1",
			["RB"] = "R1",
			["Back"] = "Options",
			["Start"] = "Touch",
			["LS"] = "L3",
			["RS"] = "R3"
		}
		local v_u_15 = {
			["LT"] = "L2",
			["RT"] = "R2"
		}
		local v_u_16 = getGamepadButtonLabel
		function getGamepadButtonLabel(p17, p18)
			-- upvalues: (copy) v_u_16, (copy) v_u_14
			local v19 = v_u_16(p17, p18)
			return Utils.getNoNil(v_u_14[v19], v19)
		end
		local v_u_20 = getGamepadAxisLabel
		function getGamepadAxisLabel(p21, p22)
			-- upvalues: (copy) v_u_20, (copy) v_u_15
			local v23 = v_u_20(p21, p22)
			return Utils.getNoNil(v_u_15[v23], v23)
		end
	end
end
function InputDisplayManager.loadControllerSymbolsAndOverlays(p24)
	local v25 = g_overlayManager:getConfigMetaData("controllerSymbols")
	if v25 == nil then
		Logging.warning("No texture config for controller symbols found")
	else
		local v26 = loadXMLFile("ControllerSymbolsBinding", InputDisplayManager.CONTROLLER_SYMBOLS_PATH)
		local v27 = v25.filename
		local v28 = 0
		while true do
			local v29 = string.format("controllerSymbols.controllerSymbol(%d)", v28)
			if not hasXMLProperty(v26, v29) then
				break
			end
			local v30 = getXMLString(v26, v29 .. "#prefix") or ""
			local v31 = getXMLString(v26, v29 .. "#name")
			local v32 = "controllerSymbols." .. getXMLString(v26, v29 .. "#sliceId")
			if v31 ~= nil then
				local v33 = v31:trim():split(" ")
				local v34 = ""
				for _, v35 in pairs(v33) do
					if v35 ~= "" then
						v34 = v34 .. v30 .. v35
					end
				end
				if p24.controllerSymbols[v34] then
					printWarning("Warning: controller symbol name \'" .. v34 .. "\' already exists!")
				else
					p24:createButtonOverlay(v34, v27, v32)
				end
			end
			v28 = v28 + 1
		end
		p24.keyboardKeyOverlay = ButtonOverlay.new()
		delete(v26)
	end
end
function InputDisplayManager.createButtonOverlay(p36, p37, p38, p39)
	local v40, v41 = getNormalizedScreenValues(p36.buttonIconSize * p36.uiScale, p36.buttonIconSize * p36.uiScale)
	local v42 = g_overlayManager:createOverlay(p39, 0, 0, v40, v41)
	v42:setAlignment(Overlay.ALIGN_VERTICAL_MIDDLE, Overlay.ALIGN_HORIZONTAL_LEFT)
	p36.controllerSymbols[p37] = {
		["name"] = p37,
		["filename"] = p38,
		["overlay"] = v42
	}
	if p37 == InputDisplayManager.PLUS_OVERLAY_NAME then
		p36.plusOverlay = v42
		v42.width = v40 * 0.5
		v42.defaultWidth = v40 * 0.5
		v42.height = v41 * 0.5
		v42.defaultHeight = v41 * 0.5
	elseif p37 == InputDisplayManager.OR_OVERLAY_NAME then
		p36.orOverlay = v42
		v42.width = v40 * 0.5
		v42.defaultWidth = v40 * 0.5
		v42.height = v41 * 0.5
		v42.defaultHeight = v41 * 0.5
	end
end
function InputDisplayManager.loadAxisIcons(p43, p44, p45)
	local v46, v47, v48
	if p45 then
		v46, v47 = Utils.getModNameAndBaseDirectory(p45)
		v48 = "modDesc.axisIcons"
	else
		v48 = "axisIcons"
		v46 = ""
		v47 = ""
	end
	local v49 = 0
	while true do
		local v50 = string.format("%s.icon(%d)", v48, v49)
		if not hasXMLProperty(p44, v50) then
			break
		end
		local v51 = v46 .. getXMLString(p44, v50 .. "#name") or ""
		local v52 = getXMLString(p44, v50 .. "#filename")
		if v51 and v52 then
			local v53 = Utils.getFilename(v52, v47)
			local v54 = InputDisplayManager.AXIS_ICON_BASE_SIZE * p43.uiScale
			local v55, v56 = getNormalizedScreenValues(v54, v54)
			local v57 = Overlay.new(v53, 0, 0, v55, v56)
			v57:setAlignment(Overlay.ALIGN_VERTICAL_MIDDLE, Overlay.ALIGN_HORIZONTAL_LEFT)
			p43.axisIconOverlays[v51] = v57
		end
		v49 = v49 + 1
	end
end
function InputDisplayManager.loadModAxisIcons(p58)
	for _, v59 in ipairs(p58.modManager:getMods()) do
		local v60 = loadXMLFile("ModFile", v59.modFile)
		p58:loadAxisIcons(v60, v59.modFile)
		delete(v60)
	end
end
function InputDisplayManager.addContextBindings(p61, p62, p63, p64, p65)
	local v66 = p61.actionBindings[p63]
	local v67 = -1
	local v68 = nil
	for _, v69 in pairs(v66) do
		if v69.isActive then
			local v70 = false
			if not p65 then
				for _, v71 in pairs(p62) do
					if v69.internalDeviceId == v71.internalDeviceId and v69.unmodifiedAxis == v71.unmodifiedAxis then
						v70 = true
						break
					end
				end
			end
			if not v70 then
				local v72 = not p64
				if v72 then
					v72 = v69.isMouse
				end
				local v73
				if p64 then
					v73 = v69.isGamepad
				else
					v73 = p64
				end
				local v74
				if v73 then
					if v68 == nil then
						v74 = false
					else
						v74 = v69.index < v68.index
					end
				else
					v74 = v73
				end
				if v74 or p61.inputManager:getDeviceByInternalId(v69.internalDeviceId).category == InputDevice.CATEGORY.GAMEPAD and p65 then
					table.remove(p62, v67)
					v68 = nil
				end
				if v72 or v73 and v68 == nil then
					table.insert(p62, v69)
					if v73 then
						v67 = #p62
						v68 = v69
					end
				end
			end
		end
	end
end
function InputDisplayManager.getActionBindingsForContext(p75, p76, p77, p78, p79)
	local v80 = {}
	p75:addContextBindings(v80, p76, p78, p79)
	if p77 then
		p75:addContextBindings(v80, p77, p78)
	end
	return v80
end
local v_u_81 = {}
function InputDisplayManager.getKeyboardBindings(p82, p83, p84)
	-- upvalues: (copy) v_u_81
	for v85 in pairs(v_u_81) do
		v_u_81[v85] = nil
	end
	local v86 = p82.actionBindings[p83]
	if p84 then
		p84 = p82.actionBindings[p84]
	end
	local v87 = v_u_81
	table.insert(v87, v86)
	if p84 ~= nil then
		local v88 = v_u_81
		table.insert(v88, p84)
	end
	local v89 = {}
	for _, v90 in ipairs(v_u_81) do
		for _, v91 in ipairs(v90) do
			if v91.isKeyboard then
				table.insert(v89, v91)
			end
		end
	end
	return v89
end
function InputDisplayManager.resolveModifierSymbols(p92, p93, p94, p95, p96)
	for v97 = 1, #p96.axisNames - 1 do
		local v98 = p96.axisNames[v97]
		local v99 = p92:getGamepadInputSymbolName(p96.internalDeviceId, v98, false)
		local v100 = p92.controllerSymbols[v99]
		if v100 ~= nil then
			local v101 = v100.overlay
			table.insert(p93, v101)
			table.insert(p95, true)
			local v102 = InputHelpElement.SEPARATOR.COMBO_INPUT
			table.insert(p94, v102)
		end
	end
end
function InputDisplayManager.resolveAccumulatedSymbolPermutations(p103, p104, p105, p106, p107)
	if p107 == 0 then
		local v108 = ""
		for _, v109 in ipairs(p106) do
			v108 = v108 .. v109
		end
		local v110 = p103.controllerSymbols[v108]
		if v110 ~= nil then
			local v111 = v110.overlay
			table.insert(p104, v111)
			table.insert(p105, false)
			return
		end
	else
		for v112 = 1, p107 do
			local v113 = p106[v112]
			local v114 = p106[p107]
			p106[p107] = v113
			p106[v112] = v114
			p103:resolveAccumulatedSymbolPermutations(p104, p105, p106, p107 - 1)
			local v115 = p106[v112]
			local v116 = p106[p107]
			p106[p107] = v115
			p106[v112] = v116
		end
	end
end
function InputDisplayManager.resolveUnmodifiedSymbols(p117, p118, p119, p120, p121, p122)
	local v123 = nil
	for _, v124 in pairs(p120) do
		local v125
		if p121 then
			local v126 = v124.isAnalog
			v125 = p117:getGamepadInputSymbolName(v124.internalDeviceId, v124.unmodifiedAxis, v126)
		else
			v125 = p117:getMouseInputSymbolName(v124.axisNames)
		end
		if p122 and v125 ~= nil then
			if v123 == nil then
				v123 = { v125 }
			else
				local v127 = false
				for _, v128 in ipairs(v123) do
					if v128 == v125 then
						v127 = true
						break
					end
				end
				if not v127 then
					table.insert(v123, v125)
				end
			end
		else
			local v129 = p117.controllerSymbols[v125]
			if v129 ~= nil then
				local v130 = v129.overlay
				table.insert(p118, v130)
				table.insert(p119, false)
			end
		end
	end
	if p122 and v123 ~= nil then
		p117:resolveAccumulatedSymbolPermutations(p118, p119, v123, #v123)
	end
end
function InputDisplayManager.addRegularSymbols(p131, p132, p133, p134, p135, p136, p137, p138)
	if #p136 > 0 then
		if not p138 and p137 then
			p131:resolveModifierSymbols(p132, p133, p134, p136[1])
		end
		local v139 = #p132
		p131:resolveUnmodifiedSymbols(p132, p134, p136, p137, p135)
		local v140 = #p132
		if v139 ~= v140 then
			for _ = 1, v140 - v139 - 1 do
				local v141 = InputHelpElement.SEPARATOR.ANY_INPUT
				table.insert(p133, v141)
			end
		end
	end
end
function InputDisplayManager.addComboSymbols(p142, p143, p144, p145, p146, p147)
	local v148 = #p146 == 1
	assert(v148, "Number of bindings for a combo action must always be 1, check code and configuration!")
	local v149 = p146[1]
	if p147 then
		for _, v150 in ipairs(v149.axisNames) do
			local v151 = p142:getGamepadInputSymbolName(v149.internalDeviceId, v150, false)
			local v152 = p142.controllerSymbols[v151]
			if v152 ~= nil then
				local v153 = v152.overlay
				table.insert(p143, v153)
				table.insert(p145, true)
			end
		end
	else
		local v154 = p142:getMouseInputSymbolName(v149.axisNames, false)
		local v155 = p142.controllerSymbols[v154].overlay
		table.insert(p143, v155)
		table.insert(p145, true)
	end
	for _ = 1, #p143 - 1 do
		local v156 = InputHelpElement.SEPARATOR.COMBO_INPUT
		table.insert(p144, v156)
	end
end
function InputDisplayManager.getControllerSymbolOverlays(p157, p158, p159, p160, p161, p162)
	local v163 = p157.inputManager:getActionByName(p158)
	local v164 = p157.inputManager:getActionByName(p159)
	local v165 = InputBinding.GAMEPAD_COMBOS[p158] ~= nil
	local v166 = InputBinding.MOUSE_COMBOS[p158] ~= nil
	local v167 = v165 or v166
	local v168 = p157.isConsoleVersion or (p157.isMobileVersion or (p157.inputManager:getInputHelpMode() == GS_INPUT_HELP_MODE_GAMEPAD and true or v165))
	if p162 ~= nil then
		return p157:makeHelpElementForBinding(v163, p162)
	end
	if v168 then
		v168 = not v166
	end
	return p157:makeHelpElement(v163, v164, p160, v167, v168, p161)
end
function InputDisplayManager.requireSymbolAccumulation(p169, p170, p171)
	local v172 = p169:isFullAxis() and not p170
	if v172 then
		p170 = v172
	elseif p170 then
		p170 = p170:isFullAxis()
	end
	if not p170 then
		local v173 = true
		for _, v174 in pairs(p171) do
			if v173 then
				v173 = InputBinding.getIsDPadInput(v174.axisNames)
			end
		end
		p170 = p170 or v173
	end
	if not p170 then
		local v175 = true
		for _, v176 in pairs(p171) do
			if v175 then
				v175 = InputBinding.getIsMouseWheelInput(v176.axisNames)
			end
		end
		p170 = p170 or v175
	end
	return p170
end
function InputDisplayManager.makeHelpElement(p177, p178, p179, p180, p181, p182, p183, p184, p185)
	local v186 = p177:getActionBindingsForContext(p178, p179, p182, p181)
	local v187 = {}
	local v188 = {}
	local v189 = {}
	if #v186 > 0 then
		if p181 then
			p177:addComboSymbols(v188, v187, v189, v186, p182)
		else
			p177:addRegularSymbols(v188, v187, v189, InputDisplayManager.requireSymbolAccumulation(p178, p179, v186), v186, p182, p183)
		end
	end
	local v190 = {}
	if #v188 < 1 and not p182 then
		local v191 = p177:getKeyboardBindings(p178, p179)
		local v192 = {}
		for _, v193 in ipairs(v191) do
			for _, v194 in ipairs(v193.axisNames) do
				local v195 = v193.modifierAxisSet[v194] ~= nil
				if not (v195 and v192[v194]) then
					local v196 = KeyboardHelper.getDisplayKeyName
					local v197 = Input[v194]
					table.insert(v190, v196(v197))
					if v195 then
						v192[v194] = true
					end
				end
			end
		end
	end
	local v198 = InputDisplayManager.NO_HELP_ELEMENT
	if #v188 > 0 or #v190 > 0 then
		local v199 = p179 == nil and "" or (p179.name or "")
		v198 = InputHelpElement.new(p178.name, v199, v188, v190, v187, v189, p180, not p183, p184, p185)
	end
	return v198
end
function InputDisplayManager.makeHelpElementForBinding(p200, p201, p202)
	local v203 = { p202 }
	local v204 = {}
	local v205 = {}
	local v206 = {}
	if not p202.isKeyboard then
		p200:addRegularSymbols(v205, v204, v206, InputDisplayManager.requireSymbolAccumulation(p201, nil, v203), v203, p202.isGamepad)
	end
	local v207 = {}
	if #v205 < 1 then
		local v208 = {}
		for _, v209 in ipairs(p202.axisNames) do
			local v210 = p202.modifierAxisSet[v209] ~= nil
			if not (v210 and v208[v209]) then
				local v211 = KeyboardHelper.getDisplayKeyName
				local v212 = Input[v209]
				table.insert(v207, v211(v212))
				if v210 then
					v208[v209] = true
				end
			end
		end
	end
	local v213 = InputDisplayManager.NO_HELP_ELEMENT
	if #v205 > 0 or #v207 > 0 then
		v213 = InputHelpElement.new(p201.name, nil, v205, v207, v204, v206)
	end
	return v213
end
function InputDisplayManager.onActionEventsChanged(p214, p215)
	p214:storeEventHelpElements(p215)
	p214:storeComboHelpElements(p215)
end
function InputDisplayManager.sortEventHelpElements(p216, p217)
	if p216.priority == p217.priority then
		if p216.actionName == "" or p217.actionName == "" then
			return p217.actionName == ""
		else
			local v218 = g_inputBinding:getActionByName(p216.actionName)
			local v219 = g_inputBinding:getActionByName(p217.actionName)
			if v218.primaryKeyboardInput == nil then
				return p216.text < p217.text
			elseif v219.primaryKeyboardInput == nil then
				return false
			else
				return v218.primaryKeyboardInput < v219.primaryKeyboardInput
			end
		end
	else
		return p216.priority < p217.priority
	end
end
function InputDisplayManager.sortEventHelpElementsGamepad()
	-- failed to decompile
end
function InputDisplayManager.storeEventHelpElements(p220, p221)
	p220.eventHelpElements = {
		[GS_INPUT_HELP_MODE_GAMEPAD] = {},
		[GS_INPUT_HELP_MODE_KEYBOARD] = {},
		[GS_INPUT_HELP_MODE_TOUCH] = {}
	}
	for v222, v223 in pairs(p220.eventHelpElements) do
		local v224 = v222 == GS_INPUT_HELP_MODE_GAMEPAD
		for _, v225 in ipairs(p221) do
			local v226 = v225.action
			local v227 = v225.event
			local v228 = v225.inlineModifierButtons or v222 == GS_INPUT_HELP_MODE_KEYBOARD
			local v229 = 0
			if v224 then
				if not v228 then
					v229 = v226.comboMaskGamepad
				end
			else
				v229 = v226.comboMaskMouse
			end
			local v230 = v223[v229]
			if not v230 then
				v230 = {}
				v223[v229] = v230
			end
			local v231 = not v227.contextDisplayIconName or p220.axisIconOverlays[v227.contextDisplayIconName]
			if not v231 then
				printWarning("Warning: Could not resolve axis icon name \'" .. v227.contextDisplayIconName .. "\'. Check vehicle and axis icon configurations.")
			end
			local v232 = p220:makeHelpElement(v226, nil, v227.contextDisplayText, false, v224, v228, v231, v227.displayPriority)
			if v232 ~= InputDisplayManager.NO_HELP_ELEMENT then
				table.insert(v230, v232)
			end
		end
		local v233 = InputDisplayManager.sortEventHelpElements
		if v224 then
			v233 = InputDisplayManager.sortEventHelpElementsGamepad
		end
		for _, v234 in pairs(v223) do
			table.sort(v234, v233)
		end
	end
end
function InputDisplayManager.storeComboHelpElements(p235, p236)
	p235.eventComboButtons = {
		[GS_INPUT_HELP_MODE_GAMEPAD] = {},
		[GS_INPUT_HELP_MODE_KEYBOARD] = {},
		[GS_INPUT_HELP_MODE_TOUCH] = {}
	}
	for v237, _ in pairs(p235.eventHelpElements) do
		local v238 = v237 == GS_INPUT_HELP_MODE_GAMEPAD
		for _, v239 in ipairs(p236) do
			local v240 = v239.action
			for _, v241 in pairs(p235.actionBindings[v240]) do
				local v242 = v238 and v241.isActive
				if v242 then
					v242 = v241.isGamepad
				end
				local v243 = not v238
				if v243 then
					v243 = v241.isMouse
				end
				if v242 and not v239.inlineModifierButtons or v243 then
					local v244 = p235.inputManager:getComboActionNameForAxisSet(v241.modifierAxisSet)
					if v244 then
						p235.eventComboButtons[v237][v244] = true
					end
				end
			end
		end
	end
end
function InputDisplayManager.getEventHelpElementForAction(p245, p246)
	local v247 = p245.inputManager:getInputHelpMode()
	local v248 = p245.eventHelpElements[v247]
	local v249 = nil
	for _, v250 in pairs(v248) do
		for _, v251 in pairs(v250) do
			if v251.actionName == p246 then
				v249 = v251
				break
			end
		end
	end
	return v249
end
function InputDisplayManager.getEventHelpElements(p252, p253, p254)
	local v255 = p254 and GS_INPUT_HELP_MODE_GAMEPAD or GS_INPUT_HELP_MODE_KEYBOARD
	return p252.eventHelpElements[v255][p253]
end
function InputDisplayManager.getComboHelpElements(p256, p257)
	local v258 = p257 and GS_INPUT_HELP_MODE_GAMEPAD or GS_INPUT_HELP_MODE_KEYBOARD
	return p256.eventComboButtons[v258]
end
function InputDisplayManager.getPrefix(_, p259)
	local v260 = ""
	if GS_PLATFORM_XBOX then
		return InputDisplayManager.SYMBOL_PREFIX_XBOX
	end
	if GS_PLATFORM_SWITCH then
		return InputDisplayManager.SYMBOL_PREFIX_SWITCH
	end
	if GS_PLATFORM_PLAYSTATION then
		if p259 == 0 and GS_PLATFORM_ID == PlatformId.PS5 then
			return InputDisplayManager.SYMBOL_PREFIX_PS5
		end
	else
		if GS_IS_MOBILE_VERSION then
			v260 = InputDisplayManager.SYMBOL_PREFIX_MOBILE
		end
		if p259 ~= nil then
			local v261 = getGamepadName(p259)
			if v261 == InputDevice.NAMES.XBOX_GAMEPAD or v261 == InputDevice.NAMES.XINPUT_GAMEPAD then
				return InputDisplayManager.SYMBOL_PREFIX_XBOX
			end
			if v261 == InputDevice.NAMES.PS_GAMEPAD then
				return InputDisplayManager.SYMBOL_PREFIX_PS4
			end
			if v261 == InputDevice.NAMES.PS5_GAMEPAD then
				return InputDisplayManager.SYMBOL_PREFIX_PS5
			end
			if v261 == InputDevice.NAMES.STADIA_GAMEPAD then
				return InputDisplayManager.SYMBOL_PREFIX_STADIA
			end
			if v261 == InputDevice.NAMES.SWITCH_GAMEPAD then
				v260 = InputDisplayManager.SYMBOL_PREFIX_SWITCH
			end
		end
	end
	return v260
end
function InputDisplayManager.getPlusOverlay(p262)
	return p262.plusOverlay
end
function InputDisplayManager.getOrOverlay(p263)
	return p263.orOverlay
end
function InputDisplayManager.getKeyboardKeyOverlay(p264)
	return p264.keyboardKeyOverlay
end
function InputDisplayManager.getFirstBindingAxisAndDeviceForActionName(p265, p266, p267, p268)
	local v269 = p267 or Binding.AXIS_COMPONENT.POSITIVE
	local v270 = p265.inputManager:getActionByName(p266)
	local v271 = nil
	local v272 = nil
	local v273 = p265.actionBindings[v270]
	local v274 = (1 / 0)
	if v273 == nil then
		return "", -1
	else
		for _, v275 in ipairs(v273) do
			local v276
			if v275.isGamepad and p268 then
				v276 = p268
			else
				v276 = v275.isKeyboard
				if v276 then
					v276 = not p268
				end
			end
			if v275.isActive and (v275.index < v274 and (v276 and v275.axisComponent == v269)) then
				v272 = v275.internalDeviceId
				v274 = v275.index
				v271 = v275
			end
		end
		if v271 then
			return v271.axisNames[1], v272
		else
			return "", -1
		end
	end
end
function InputDisplayManager.getGamepadInputActionOverlay(p277, p278, p279)
	local v280, v281 = p277:getFirstBindingAxisAndDeviceForActionName(p278, p279, true)
	local v282 = p277:getGamepadInputSymbolName(v281, v280, false)
	if v282 == nil or v282 == "" then
		return nil
	end
	if p277.controllerSymbols[v282] == nil then
		Logging.devWarning("Controller symbol name \'%s\' is not defined in controllerSymbols.xml", v282)
		return nil
	end
	local v283 = p277.controllerSymbols[v282].overlay
	local v284 = {
		["uvs"] = v283.uvs,
		["color"] = {
			v283.r,
			v283.g,
			v283.b,
			v283.a
		},
		["filename"] = v283.filename
	}
	GuiOverlay.createOverlay(v284)
	return v284
end
function InputDisplayManager.getKeyboardInputActionKey(p285, p286, p287)
	local v288 = p285:getFirstBindingAxisAndDeviceForActionName(p286, p287, false)
	if v288 == "" then
		return nil
	end
	local v289 = Input[v288]
	return KeyboardHelper.getDisplayKeyName(v289)
end
function InputDisplayManager.getGamepadInputSymbolName(_, p290, p291, p292)
	local v293 = ""
	if p290 ~= nil and p290 >= 0 then
		local v294 = InputDisplayManager:getPrefix(p290)
		if p292 then
			local v295 = Input.axisIdNameToId[p291]
			if v295 ~= nil then
				return v294 .. string.gsub(getGamepadAxisLabel(v295, p290), " ", "")
			end
		else
			local v296 = Input.buttonIdNameToId[p291]
			if v296 ~= nil then
				local v297 = getGamepadButtonLabel(v296, p290)
				v293 = v294 .. string.gsub(v297, " ", "")
			end
		end
	end
	return v293
end
function InputDisplayManager.getMouseInputSymbolName(_, p298)
	local v299 = ""
	for _, v300 in pairs(p298) do
		if InputBinding.MOUSE_BUTTONS[v300] then
			v299 = v299 .. InputDisplayManager.SYMBOL_PREFIX_MOUSE .. v300
		elseif v300:sub(1, #InputDisplayManager.AXIS_NAME_MOUSE_X) == InputDisplayManager.AXIS_NAME_MOUSE_X then
			v299 = v299 .. InputDisplayManager.SYMBOL_PREFIX_MOUSE .. "AxisX"
		elseif v300:sub(1, #InputDisplayManager.AXIS_NAME_MOUSE_Y) == InputDisplayManager.AXIS_NAME_MOUSE_Y then
			v299 = v299 .. InputDisplayManager.SYMBOL_PREFIX_MOUSE .. "AxisY"
		end
	end
	return v299
end
function InputDisplayManager.onActionBindingsChanged(p301, p302)
	p301.actionBindings = p302
end
function InputDisplayManager.draw(p303)
	if p303.debugControllerSymbols then
		p303:debugRenderControllerSymbols()
	end
end
function InputDisplayManager.debugRenderControllerSymbols(p304)
	new2DLayer()
	setOverlayColor(GuiElement.debugOverlay, 0, 0, 0, 0.99)
	renderOverlay(GuiElement.debugOverlay, 0, 0, 1, 1)
	local v305 = p304.controllerSymbolsSorted
	local v306, v307 = getNormalizedScreenValues(30, 30)
	local v308, _ = getNormalizedScreenValues(5, 0)
	local v309, v310 = getNormalizedScreenValues(20, -45)
	local v311 = getCorrectTextSize(0.007)
	local v312 = getNormalizedScreenValues(120, 0)
	setTextWrapWidth(v312, true)
	setTextColor(1, 1, 1, 1)
	setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_MIDDLE)
	local v313 = 0.005
	local v314 = 0.97
	local v315 = 0
	for _, v316 in ipairs(v305) do
		local v317 = v316.overlay
		v317:setPosition(v313, v314)
		v317:setDimension(v306, v307)
		v317:render()
		v317:resetDimensions()
		local v318 = getTextWidth
		local v319 = v316.name
		v315 = math.max(v315, v318(v311, v319))
		renderText(v313 + v308 + v306, v314, v311, v316.name)
		v314 = v314 + v310
		if v314 < 0 then
			v313 = v313 + v306 + v309 + v315
			v314 = 0.97
			v315 = 0
		end
	end
	setTextWrapWidth(0)
	setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE)
end
function InputDisplayManager.consoleCommandShowInputControllerSymbols(p320)
	p320.debugControllerSymbols = not p320.debugControllerSymbols
	if p320.debugControllerSymbols then
		if p320.controllerSymbolsSorted == nil then
			p320.controllerSymbolsSorted = {}
			for _, v321 in pairs(p320.controllerSymbols) do
				local v322 = p320.controllerSymbolsSorted
				table.insert(v322, v321)
			end
			table.sort(p320.controllerSymbolsSorted, function(p323, p324)
				return p323.name < p324.name
			end)
			return
		end
	else
		p320.controllerSymbolsSorted = nil
	end
end

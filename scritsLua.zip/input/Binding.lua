Binding = {}
local v_u_1 = Class(Binding)
Binding.AXIS_COMPONENT = {
	["POSITIVE"] = "+",
	["NEGATIVE"] = "-"
}
Binding.INPUT_COMPONENT = {
	["POSITIVE"] = "+",
	["NEGATIVE"] = "-"
}
Binding.MAX_ALTERNATIVES_KB_MOUSE = 3
Binding.MAX_ALTERNATIVES_GAMEPAD = 2
Binding.PRESSED_MAGNITUDE_THRESHOLD = 0.1
Binding.PS_JAPAN_BUTTON_SWAP_MAP = {
	["BUTTON_2"] = "BUTTON_3",
	["BUTTON_3"] = "BUTTON_2"
}
function Binding.new(p2, p3, p4, p5, p6, p7)
	-- upvalues: (copy) v_u_1
	local v8 = v_u_1
	local v9 = setmetatable({}, v8)
	v9.axisComponent = p4
	v9.index = p7
	if v9.axisComponent == Binding.AXIS_COMPONENT.POSITIVE then
		v9.axisDirection = 1
	else
		v9.axisDirection = -1
	end
	v9.id = nil
	v9.comboMask = 0
	v9.deviceId = nil
	v9.deviceCategory = InputDevice.CATEGORY.UNKNOWN
	v9.internalDeviceId = nil
	v9.axisNameSet = nil
	v9.inputString = ""
	v9.unmodifiedAxis = nil
	v9.modifierAxisSet = nil
	v9.axisNames = {}
	v9.inputComponent = nil
	v9.inputDirection = 0
	v9.neutralInput = p6
	v9.isMouse = false
	v9.isKeyboard = false
	v9.isGamepad = false
	v9.isPrimary = false
	v9:updateData(p2, nil, p3, p5, true)
	v9.isAnalog = false
	v9.inputValue = 0
	v9.isInputActive = false
	v9.isDownFlank = false
	v9.isUpFlank = false
	v9.recievedDownFlankInCurrentContext = false
	v9.enteredNewContextThisFrame = false
	v9.isPressed = false
	v9.isShadowed = false
	v9.isActive = true
	v9.hasFrameTriggered = false
	return v9
end
function Binding.createFromXML(p10, p11)
	local v12 = getXMLString(p10, p11 .. "#device")
	local v13 = (getXMLString(p10, p11 .. "#input") or ""):split(" ")
	local v14 = getXMLString(p10, p11 .. "#axisComponent")
	if v14 ~= Binding.AXIS_COMPONENT.POSITIVE and v14 ~= Binding.AXIS_COMPONENT.NEGATIVE then
		v14 = Binding.AXIS_COMPONENT.POSITIVE
	end
	local v15 = getXMLString(p10, p11 .. "#inputComponent")
	if v15 ~= Binding.INPUT_COMPONENT.POSITIVE and v15 ~= Binding.INPUT_COMPONENT.NEGATIVE then
		v15 = Binding.INPUT_COMPONENT.POSITIVE
		if #v13 > 0 and v13[#v13]:sub(v13[#v13]:len()) == "-" then
			v15 = Binding.INPUT_COMPONENT.NEGATIVE
		end
	end
	local v16 = getXMLInt(p10, p11 .. "#neutralInput") or 0
	local v17 = getXMLInt(p10, p11 .. "#index") or -1
	return Binding.new(v12, v13, v14, v15, v16, v17)
end
function Binding.saveToXMLFile(p18, p19, p20)
	setXMLString(p19, p20 .. "#device", p18.deviceId)
	local v21 = table.concat(p18.axisNames, " ")
	setXMLString(p19, p20 .. "#input", v21)
	setXMLString(p19, p20 .. "#axisComponent", p18.axisComponent)
	setXMLInt(p19, p20 .. "#neutralInput", p18.neutralInput)
	setXMLInt(p19, p20 .. "#index", p18.index)
end
function Binding.updateData(p22, p23, p24, p25, p26, _)
	if p25 ~= nil then
		p22.axisNames = {}
		for _, v27 in ipairs(p25) do
			local v28 = p22.axisNames
			table.insert(v28, v27)
		end
	end
	local v29 = p26 or p22.inputComponent
	if v29 and v29 ~= Binding.INPUT_COMPONENT.POSITIVE then
		p22.inputComponent = Binding.INPUT_COMPONENT.NEGATIVE
		p22.inputDirection = -1
	else
		p22.inputComponent = Binding.INPUT_COMPONENT.POSITIVE
		p22.inputDirection = 1
	end
	if #p22.axisNames > 0 then
		local v30 = p22.axisNames[#p22.axisNames]
		local v31 = v30:sub(v30:len())
		if v31 == "-" or v31 == "+" then
			v30 = v30:sub(1, v30:len() - 1)
		end
		if p22.inputComponent == Binding.INPUT_COMPONENT.NEGATIVE then
			v30 = v30 .. "-"
		elseif InputBinding.getIsPhysicalFullAxis(v30) then
			v30 = v30 .. "+"
		end
		p22.axisNames[#p22.axisNames] = v30
	end
	p22.deviceId = p23 or p22.deviceId
	p22.deviceCategory = p24 or p22.deviceCategory
	p22.axisNameSet = table.toSet(p22.axisNames)
	p22.inputString = table.concat(p22.axisNames, " ")
	p22.unmodifiedAxis = p22.axisNames[#p22.axisNames]
	p22.modifierAxisSet = {}
	for v32 = 1, #p22.axisNames - 1 do
		local v33 = p22.axisNames[v32]
		p22.modifierAxisSet[v33] = v33
	end
	local v34 = p22.deviceId == InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT
	local v35
	if v34 then
		v35 = p22.index == Binding.MAX_ALTERNATIVES_KB_MOUSE
	else
		v35 = v34
	end
	p22.isMouse = v35
	local v36
	if v34 then
		v36 = not p22.isMouse
	else
		v36 = v34
	end
	p22.isKeyboard = v36
	local v37
	if p22.deviceId == nil then
		v37 = false
	else
		v37 = not v34
	end
	p22.isGamepad = v37
	p22.isPrimary = p22.index == 1
end
function Binding.updateInput(p38, p39, p40)
	local v41
	if p38.axisDirection >= 0 then
		p38.inputValue = math.max(p39, 0)
		v41 = Binding.PRESSED_MAGNITUDE_THRESHOLD <= p39
	else
		p38.inputValue = math.min(p39, 0)
		v41 = p39 <= -Binding.PRESSED_MAGNITUDE_THRESHOLD
	end
	p38.isShadowed = false
	p38.hasFrameTriggered = false
	local v42 = v41 and not p38.isPressed
	if v42 then
		v42 = not p38.enteredNewContextThisFrame
	end
	local v43 = not v41
	if v43 then
		v43 = p38.isPressed
	end
	p38.isDownFlank = v42
	p38.isUpFlank = v43
	p38.isPressed = v41
	p38.enteredNewContextThisFrame = false
	if p38.recievedDownFlankInCurrentContext or v42 then
		v42 = v41 or v43
	end
	p38.recievedDownFlankInCurrentContext = v42
	p38.isInputActive = p40 or v43
end
function Binding.setIsAnalog(p44, p45)
	p44.isAnalog = p45
end
function Binding.setIndex(p46, p47)
	p46.index = p47
	p46.isPrimary = p47 == 1
	local v48 = p46.deviceId == InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT
	if v48 then
		v48 = p46.index == Binding.MAX_ALTERNATIVES_KB_MOUSE
	end
	p46.isMouse = v48
end
function Binding.setActive(p49, p50)
	p49.isActive = p50
end
function Binding.setFrameTriggered(p51, p52)
	p51.hasFrameTriggered = p52
end
function Binding.getFrameTriggered(p53)
	return p53.hasFrameTriggered
end
function Binding.setComboMask(p54, p55)
	p54.comboMask = p55
end
function Binding.getComboMask(p56)
	return p56.comboMask
end
function Binding.hasCollisionWith(p57, p58)
	if p57 == p58 then
		return false
	else
		return p57.deviceId == p58.deviceId and table.equalLists(p57.axisNames, p58.axisNames, true)
	end
end
function Binding.hasEventCollision(p59, p60)
	if p59 == p60 then
		return true
	end
	local v61 = p59.deviceId == p60.deviceId
	local v62 = table.equalLists(p59.axisNames, p60.axisNames, true)
	local v63 = p59.inputComponent == p60.inputComponent
	if v61 then
		if not v62 then
			v63 = v62
		end
	else
		v63 = v61
	end
	return v63
end
function Binding.clone(p64)
	local v65 = Binding.new(p64.deviceId, p64.axisNames, p64.axisComponent, p64.inputComponent, p64.neutralInput, p64.index)
	v65:updateData(p64.deviceId, p64.deviceCategory, p64.axisNames, p64.inputComponent, false)
	v65.internalDeviceId = p64.internalDeviceId
	v65.isAnalog = p64.isAnalog
	v65.comboMask = p64.comboMask
	v65.isActive = p64.isActive
	return v65
end
function Binding.copyInputStateFrom(p66, p67)
	p66.isDownFlank = p67.isDownFlank
	p66.isUpFlank = p67.isUpFlank
	p66.isPressed = p67.isPressed
	p66.isInputActive = p67.isInputActive
	p66.recievedDownFlankInCurrentContext = p67.recievedDownFlankInCurrentContext
	p66.enteredNewContextThisFrame = p67.enteredNewContextThisFrame
end
function Binding.resetInputState(p68)
	p68.enteredNewContextThisFrame = true
	p68.recievedDownFlankInCurrentContext = false
end
function Binding.isSameSlot(p69, p70)
	local v71 = p69.axisComponent == p70.axisComponent
	local v72 = not (p69.isKeyboard and p70.isKeyboard) and (not (p69.isMouse and p70.isMouse) and p69.isGamepad)
	if v72 then
		v72 = p70.isGamepad
	end
	local v73 = p69.index == p70.index
	local v74 = p69.deviceId == p70.deviceId
	if v71 then
		if v72 then
			if not v73 then
				v74 = v73
			end
		else
			v74 = v72
		end
	else
		v74 = v71
	end
	return v74
end
function Binding.isSameSlotWithParams(p75, p76, p77, p78)
	local v79 = p75.axisComponent == p76
	local v80 = (p75.isKeyboard or p75.isMouse) == p77
	local v81 = p75.index == p78
	if v79 then
		if not v80 then
			v81 = v80
		end
	else
		v81 = v79
	end
	return v81
end
function Binding.getOppositeAxisComponent(p82)
	if p82 == Binding.AXIS_COMPONENT.POSITIVE then
		return Binding.AXIS_COMPONENT.NEGATIVE
	elseif p82 == Binding.AXIS_COMPONENT.NEGATIVE then
		return Binding.AXIS_COMPONENT.POSITIVE
	else
		return nil
	end
end
function Binding.getOppositeInputComponent(p83)
	if p83 == Binding.INPUT_COMPONENT.POSITIVE then
		return Binding.INPUT_COMPONENT.NEGATIVE
	elseif p83 == Binding.INPUT_COMPONENT.NEGATIVE then
		return Binding.INPUT_COMPONENT.POSITIVE
	else
		return nil
	end
end
function Binding.makeId(p84)
	if p84.id == nil then
		p84.id = string.format("%s|%s|%s|%s|%s", p84.deviceId, table.concat(p84.axisNames, ";"), p84.axisComponent, p84.neutralInput, p84.index)
	end
end
function Binding.toString(p85)
	return string.format("[(%s), deviceId: %s, axisComponent: %s, index: %s, isActive: %s, isShadowed: %s isInverted: %s, isDown: %s, isUp: %s, inputValue: %s]", table.concat(p85.axisNames, ", "), p85.deviceId, p85.axisComponent, p85.index, p85.isActive, p85.isShadowed, p85.isInverted, p85.isDownFlank, p85.isUpFlank, p85.inputValue)
end
v_u_1.__tostring = Binding.toString

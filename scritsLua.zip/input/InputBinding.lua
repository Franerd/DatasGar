InputBinding = {}
local v_u_1 = Class(InputBinding)
source("dataS/scripts/input/InputAction.lua")
source("dataS/scripts/input/InputDevice.lua")
source("dataS/scripts/input/Binding.lua")
source("dataS/scripts/input/InputEvent.lua")
InputBinding.version = 4
InputBinding.currentBindingVersion = 1
InputBinding.PATHS = {
	["DEFAULT_BINDINGS_KB_MOUSE"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_KeyboardMouse.xml",
	["DEFAULT_BINDINGS_GAMEPAD"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_Gamepad.xml",
	["DEFAULT_BINDINGS_JOYSTICK"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_Joystick.xml",
	["DEFAULT_BINDINGS_WHEEL"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_Wheel.xml",
	["DEFAULT_BINDINGS_WHEEL_AND_PANEL"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_WheelAndPanel.xml",
	["DEFAULT_BINDINGS"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_Gamepad.xml",
	["DEFAULT_BINDINGS_XBOX"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_Gamepad.xml",
	["DEFAULT_BINDINGS_IOS"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_Mobile.xml",
	["DEFAULT_BINDINGS_ANDROID"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_Mobile.xml",
	["DEFAULT_BINDINGS_SWITCH"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_Switch.xml",
	["DEFAULT_BINDINGS_SAITEK_WHEEL_AND_PANEL"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_SaitekWheelAndPanel.xml",
	["DEFAULT_BINDINGS_SAITEK_WHEEL"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_SaitekWheel.xml",
	["DEFAULT_BINDINGS_SAITEK_PANEL"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_SaitekPanel.xml",
	["DEFAULT_BINDINGS_HORI_WHEEL"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_HoriFarmingControllerWheel.xml",
	["DEFAULT_BINDINGS_HORI_PANEL"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_HoriFarmingControllerPanel.xml",
	["DEFAULT_BINDINGS_THURSTMASTER_FARMJOYSTICK"] = getAppBasePath() .. "profileTemplate/inputBindingDefault_ThrustmasterFarmJoystick.xml",
	["ACTION_DEFINITIONS"] = getAppBasePath() .. "dataS/inputActions.xml",
	["USER_BINDINGS"] = getUserProfileAppPath() .. "inputBinding.xml"
}
InputBinding.DEVICE_CATEGORY_DEFAULTS_PATHS = {
	[InputDevice.CATEGORY.GAMEPAD] = InputBinding.PATHS.DEFAULT_BINDINGS_GAMEPAD,
	[InputDevice.CATEGORY.JOYSTICK] = InputBinding.PATHS.DEFAULT_BINDINGS_JOYSTICK,
	[InputDevice.CATEGORY.WHEEL] = InputBinding.PATHS.DEFAULT_BINDINGS_WHEEL,
	[InputDevice.CATEGORY.FARMWHEEL] = InputBinding.PATHS.DEFAULT_BINDINGS_SAITEK_WHEEL,
	[InputDevice.CATEGORY.FARMPANEL] = InputBinding.PATHS.DEFAULT_BINDINGS_SAITEK_PANEL,
	[InputDevice.CATEGORY.UNKNOWN] = InputBinding.PATHS.DEFAULT_BINDINGS_GAMEPAD,
	[InputDevice.CATEGORY.WHEEL_AND_PANEL] = InputBinding.PATHS.DEFAULT_BINDINGS_WHEEL_AND_PANEL,
	[InputDevice.CATEGORY.FARMWHEEL_AND_PANEL] = InputBinding.PATHS.DEFAULT_BINDINGS_SAITEK_WHEEL_AND_PANEL,
	[InputDevice.CATEGORY.FARMWHEEL_HORI] = InputBinding.PATHS.DEFAULT_BINDINGS_HORI_WHEEL,
	[InputDevice.CATEGORY.FARMPANEL_HORI] = InputBinding.PATHS.DEFAULT_BINDINGS_HORI_PANEL,
	[InputDevice.CATEGORY.FARMJOYSTICK_THRUSTMASTER] = InputBinding.PATHS.DEFAULT_BINDINGS_THURSTMASTER_FARMJOYSTICK
}
InputBinding.DEVICE_CATEGORY_DEFAULT_LOAD_ORDER = {
	InputDevice.CATEGORY.FARMWHEEL_AND_PANEL,
	InputDevice.CATEGORY.WHEEL_AND_PANEL,
	InputDevice.CATEGORY.FARMWHEEL,
	InputDevice.CATEGORY.FARMWHEEL_HORI,
	InputDevice.CATEGORY.WHEEL,
	InputDevice.CATEGORY.GAMEPAD,
	InputDevice.CATEGORY.JOYSTICK,
	InputDevice.CATEGORY.FARMPANEL,
	InputDevice.CATEGORY.FARMPANEL_HORI,
	InputDevice.CATEGORY.FARMJOYSTICK_THRUSTMASTER
}
InputBinding.INPUTTYPE_NONE = 0
InputBinding.INPUTTYPE_KEYBOARD = 1
InputBinding.INPUTTYPE_MOUSE_BUTTON = 2
InputBinding.INPUTTYPE_MOUSE_WHEEL = 3
InputBinding.INPUTTYPE_MOUSE_AXIS = 4
InputBinding.INPUTTYPE_GAMEPAD = 5
InputBinding.INPUTTYPE_GAMEPAD_AXIS = 6
InputBinding.MOUSE_AXIS_NONE = 0
InputBinding.MOUSE_AXIS_X = 1
InputBinding.MOUSE_AXIS_Y = 2
InputBinding.SYMBOL_AFFIX_POSITIVE = "_1"
InputBinding.SYMBOL_AFFIX_NEGATIVE = "_2"
InputBinding.MOUSE_AXES = {
	["AXIS_X"] = Input.AXIS_X,
	["AXIS_Y"] = Input.AXIS_Y,
	["AXIS_X+"] = Input.AXIS_X,
	["AXIS_Y+"] = Input.AXIS_Y,
	["AXIS_X-"] = Input.AXIS_X,
	["AXIS_Y-"] = Input.AXIS_Y
}
InputBinding.MOUSE_AXIS_NAMES = {
	[Input.AXIS_X] = "AXIS_X",
	[Input.AXIS_Y] = "AXIS_Y"
}
InputBinding.MOUSE_BUTTONS = {
	["MOUSE_BUTTON_LEFT"] = Input.MOUSE_BUTTON_LEFT,
	["MOUSE_BUTTON_RIGHT"] = Input.MOUSE_BUTTON_RIGHT,
	["MOUSE_BUTTON_MIDDLE"] = Input.MOUSE_BUTTON_MIDDLE,
	["MOUSE_BUTTON_WHEEL_UP"] = Input.MOUSE_BUTTON_WHEEL_UP,
	["MOUSE_BUTTON_WHEEL_DOWN"] = Input.MOUSE_BUTTON_WHEEL_DOWN,
	["MOUSE_BUTTON_X1"] = Input.MOUSE_BUTTON_X1,
	["MOUSE_BUTTON_X2"] = Input.MOUSE_BUTTON_X2
}
InputBinding.MOUSE_WHEEL = {
	[Input.MOUSE_BUTTON_WHEEL_UP] = true,
	[Input.MOUSE_BUTTON_WHEEL_DOWN] = true
}
InputBinding.MOUSE_BUTTON_NAMES = {
	[Input.MOUSE_BUTTON_LEFT] = "MOUSE_BUTTON_LEFT",
	[Input.MOUSE_BUTTON_RIGHT] = "MOUSE_BUTTON_RIGHT",
	[Input.MOUSE_BUTTON_MIDDLE] = "MOUSE_BUTTON_MIDDLE",
	[Input.MOUSE_BUTTON_WHEEL_UP] = "MOUSE_BUTTON_WHEEL_UP",
	[Input.MOUSE_BUTTON_WHEEL_DOWN] = "MOUSE_BUTTON_WHEEL_DOWN",
	[Input.MOUSE_BUTTON_X1] = "MOUSE_BUTTON_X1",
	[Input.MOUSE_BUTTON_X2] = "MOUSE_BUTTON_X2"
}
InputBinding.GAMEPAD_DPAD = {
	[Input.BUTTON_16] = true,
	[Input.BUTTON_17] = true,
	[Input.BUTTON_18] = true,
	[Input.BUTTON_19] = true
}
InputBinding.COMBO_MASK_CONSOLE_COMMAND_1 = 1
InputBinding.COMBO_MASK_CONSOLE_COMMAND_2 = 2
InputBinding.COMBO_MASK_CONSOLE_COMMAND_3 = 4
InputBinding.COMBO_MASK_MOUSE_COMMAND_1 = 1
InputBinding.COMBO_MASK_MOUSE_COMMAND_2 = 2
InputBinding.COMBO_MASK_MOUSE_COMMAND_3 = 4
InputBinding.COMBO_MASK_MOUSE_COMMAND_4 = 8
InputBinding.GAMEPAD_COMBOS = {
	[InputAction.CONSOLE_ALT_COMMAND_BUTTON] = {
		["mask"] = InputBinding.COMBO_MASK_CONSOLE_COMMAND_1,
		["controls"] = InputAction.CONSOLE_ALT_COMMAND_BUTTON
	},
	[InputAction.CONSOLE_ALT_COMMAND2_BUTTON] = {
		["mask"] = InputBinding.COMBO_MASK_CONSOLE_COMMAND_2,
		["controls"] = InputAction.CONSOLE_ALT_COMMAND2_BUTTON
	},
	[InputAction.CONSOLE_ALT_COMMAND3_BUTTON] = {
		["mask"] = InputBinding.COMBO_MASK_CONSOLE_COMMAND_3,
		["controls"] = InputAction.CONSOLE_ALT_COMMAND3_BUTTON
	}
}
InputBinding.ORDERED_GAMEPAD_COMBOS = { InputBinding.GAMEPAD_COMBOS[InputAction.CONSOLE_ALT_COMMAND_BUTTON], InputBinding.GAMEPAD_COMBOS[InputAction.CONSOLE_ALT_COMMAND3_BUTTON], InputBinding.GAMEPAD_COMBOS[InputAction.CONSOLE_ALT_COMMAND2_BUTTON] }
InputBinding.MOUSE_COMBOS = {
	[InputAction.MOUSE_ALT_COMMAND_BUTTON] = {
		["mask"] = InputBinding.COMBO_MASK_MOUSE_COMMAND_1,
		["controls"] = InputAction.MOUSE_ALT_COMMAND_BUTTON
	},
	[InputAction.MOUSE_ALT_COMMAND2_BUTTON] = {
		["mask"] = InputBinding.COMBO_MASK_MOUSE_COMMAND_2,
		["controls"] = InputAction.MOUSE_ALT_COMMAND2_BUTTON
	},
	[InputAction.MOUSE_ALT_COMMAND3_BUTTON] = {
		["mask"] = InputBinding.COMBO_MASK_MOUSE_COMMAND_3,
		["controls"] = InputAction.MOUSE_ALT_COMMAND3_BUTTON
	},
	[InputAction.MOUSE_ALT_COMMAND4_BUTTON] = {
		["mask"] = InputBinding.COMBO_MASK_MOUSE_COMMAND_4,
		["controls"] = InputAction.MOUSE_ALT_COMMAND4_BUTTON
	}
}
InputBinding.ORDERED_MOUSE_COMBOS = {
	InputBinding.MOUSE_COMBOS[InputAction.MOUSE_ALT_COMMAND_BUTTON],
	InputBinding.MOUSE_COMBOS[InputAction.MOUSE_ALT_COMMAND3_BUTTON],
	InputBinding.MOUSE_COMBOS[InputAction.MOUSE_ALT_COMMAND4_BUTTON],
	InputBinding.MOUSE_COMBOS[InputAction.MOUSE_ALT_COMMAND2_BUTTON]
}
InputBinding.ALL_COMBOS = { InputBinding.GAMEPAD_COMBOS, InputBinding.MOUSE_COMBOS }
InputBinding.GAMEPAD_COMBO_BINDINGS = {
	[InputAction.CONSOLE_ALT_COMMAND_BUTTON] = { Input.buttonIdToIdName[Input.BUTTON_5] },
	[InputAction.CONSOLE_ALT_COMMAND2_BUTTON] = { Input.buttonIdToIdName[Input.BUTTON_6] },
	[InputAction.CONSOLE_ALT_COMMAND3_BUTTON] = { Input.buttonIdToIdName[Input.BUTTON_5], Input.buttonIdToIdName[Input.BUTTON_6] }
}
InputBinding.GAMEPAD_COMBO_AXIS_NAMES = {
	[Input.buttonIdToIdName[Input.BUTTON_5]] = true,
	[Input.buttonIdToIdName[Input.BUTTON_6]] = true
}
InputBinding.MOUSE_COMBO_BINDINGS = {
	[InputAction.MOUSE_ALT_COMMAND_BUTTON] = { InputBinding.MOUSE_BUTTON_NAMES[Input.MOUSE_BUTTON_LEFT] },
	[InputAction.MOUSE_ALT_COMMAND2_BUTTON] = { InputBinding.MOUSE_BUTTON_NAMES[Input.MOUSE_BUTTON_RIGHT] },
	[InputAction.MOUSE_ALT_COMMAND3_BUTTON] = { InputBinding.MOUSE_BUTTON_NAMES[Input.MOUSE_BUTTON_MIDDLE] },
	[InputAction.MOUSE_ALT_COMMAND4_BUTTON] = { InputBinding.MOUSE_BUTTON_NAMES[Input.MOUSE_BUTTON_LEFT], InputBinding.MOUSE_BUTTON_NAMES[Input.MOUSE_BUTTON_RIGHT] }
}
InputBinding.MOUSE_COMBO_AXIS_NAMES = {
	[InputBinding.MOUSE_BUTTON_NAMES[Input.MOUSE_BUTTON_LEFT]] = true,
	[InputBinding.MOUSE_BUTTON_NAMES[Input.MOUSE_BUTTON_RIGHT]] = true,
	[InputBinding.MOUSE_BUTTON_NAMES[Input.MOUSE_BUTTON_MIDDLE]] = true
}
InputBinding.MOUSE_MOVE_BASE_FACTOR = 75
InputBinding.MOUSE_MOVE_LIMIT = 4
InputBinding.MOUSE_MOTION_SCALE_X_DEFAULT = 1
InputBinding.MOUSE_MOTION_SCALE_Y_DEFAULT = 1
InputBinding.MOUSE_WHEEL_INPUT_FACTOR = 3
InputBinding.INPUT_MODE_CHANGE_THRESHOLD = 0.2
InputBinding.INPUT_MODE_CHANGE_MIN_INTERVAL = GS_IS_MOBILE_VERSION and 0 or 5000
InputBinding.KB_MOUSE_INTERNAL_ID = 255
InputBinding.ROOT_CONTEXT_NAME = "ROOT"
InputBinding.NO_REGISTRATION_CONTEXT = {
	["actionEvents"] = {},
	["name"] = "",
	["previousContextName"] = "",
	["eventOrderCounter"] = 0
}
InputBinding.NO_ACTION_EVENTS = {}
InputBinding.MESSAGE_PARAM_INPUT_MODE = {
	[GS_INPUT_HELP_MODE_KEYBOARD] = { GS_INPUT_HELP_MODE_KEYBOARD },
	[GS_INPUT_HELP_MODE_GAMEPAD] = { GS_INPUT_HELP_MODE_GAMEPAD },
	[GS_INPUT_HELP_MODE_TOUCH] = { GS_INPUT_HELP_MODE_TOUCH }
}
function InputBinding.new(p2, p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = v_u_1
	local v6 = setmetatable({}, v5)
	v6.debugEnabled = false
	v6.debugContextEnabled = false
	v6.debugRegisteredActions = false
	v6.modManager = p2
	v6.messageCenter = p3
	v6.isConsoleVersion = p4
	v6.devicesByInternalId = {}
	v6.devicesByCategory = {}
	v6.deviceIdToInternal = {}
	v6.internalToDeviceId = {}
	v6.engineDeviceIdCounts = {}
	v6.internalIdToEngineDeviceId = {}
	v6.newlyConnectedDevices = {}
	v6.missingDevices = {}
	v6.actions = {}
	v6.nameActions = {}
	v6.originalActionBindings = nil
	v6.activeDeviceBindingsBuffer = {}
	v6.mouseMovementX = 0
	v6.mouseMovementY = 0
	v6.accumMouseMovementX = 0
	v6.accumMouseMovementY = 0
	v6.actionEvents = {}
	v6.displayActionEvents = {}
	v6.events = {}
	v6.eventOrder = {}
	v6.loadedBindings = {}
	v6.activeBindings = {}
	v6.eventBindings = {}
	v6.linkedBindings = {}
	v6.currentContextName = InputBinding.ROOT_CONTEXT_NAME
	v6.contexts = {
		[InputBinding.ROOT_CONTEXT_NAME] = {
			["previousContextName"] = "",
			["actionEvents"] = {},
			["eventOrderCounter"] = 0
		}
	}
	v6.registrationContext = InputBinding.NO_REGISTRATION_CONTEXT
	v6.comboInputAxisMasks = {}
	v6.comboInputActions = {}
	v6.comboInputBindings = {}
	v6.pressedMouseComboMask = 0
	v6.pressedGamepadComboMask = 0
	v6.needUpdateAbort = false
	v6.eventChangeCallback = nil
	v6.wrapMousePositionEnabled = false
	v6.saveCursorX = 0.5
	v6.saveCursorY = 0.5
	v6.mouseMotionScaleX = 0.75
	v6.mouseMotionScaleY = 0.75
	v6.devicesToMigrateCategory = {}
	v6.isInputCapturing = false
	v6.gatherInputStoredMouseEvent = nil
	v6.gatherInputStoredKeyEvent = nil
	v6.gatherInputStoredUpdate = nil
	v6.gamepadInputState = {}
	v6.timeSinceLastInputHelpModeChange = InputBinding.INPUT_MODE_CHANGE_MIN_INTERVAL
	v6.lastInputHelpMode = GS_INPUT_HELP_MODE_KEYBOARD
	if p4 then
		v6.lastInputHelpMode = GS_INPUT_HELP_MODE_GAMEPAD
	end
	v6.lastInputMode = v6.lastInputHelpMode
	v6.inputHelpModeSetting = g_gameSettings:getValue(GameSettings.SETTING.INPUT_HELP_MODE)
	v6.isGamepadEnabled = p4 or g_gameSettings:getValue(GameSettings.SETTING.IS_GAMEPAD_ENABLED)
	p3:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.INPUT_HELP_MODE], v6.onInputHelpModeSettingChange, v6)
	p3:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.IS_GAMEPAD_ENABLED], v6.onGamepadEnabledSettingChanged, v6)
	v6.settingsPath = nil
	v6:assignPlatformBindingPaths()
	addConsoleCommand("gsInputDebug", "", "consoleCommandEnableInputDebug", v6)
	addConsoleCommand("gsInputContextPrint", "", "consoleCommandPrintInputContext", v6)
	addConsoleCommand("gsInputContextShow", "", "consoleCommandShowInputContext", v6)
	addConsoleCommand("gsInputRegisteredActionsShow", "", "consoleCommandShowRegisteredActions", v6)
	return v6
end
function InputBinding.delete(p7)
	g_messageCenter:unsubscribeAll(p7)
end
function InputBinding.load(p8)
	p8:clearState()
	local v9 = loadXMLFile("ActionDefinitions", InputBinding.PATHS.ACTION_DEFINITIONS)
	p8:loadActions(v9)
	delete(v9)
	p8:loadModActions()
	local v10 = loadXMLFile("InputBindings", p8.settingsPath)
	p8.version = getXMLInt(v10, "inputBinding#version") or 1
	p8.mouseMotionScaleX = (getXMLFloat(v10, "inputBinding#mouseSensitivityScaleX") or 1) * p8.MOUSE_MOTION_SCALE_X_DEFAULT
	p8.mouseMotionScaleY = (getXMLFloat(v10, "inputBinding#mouseSensitivityScaleY") or 1) * p8.MOUSE_MOTION_SCALE_Y_DEFAULT
	p8:initializeGamepadMapping(v10)
	p8:loadActionBindingsFromXML(v10, false, nil, nil, nil, true)
	p8:upgradeBindingVersion(v10)
	p8:resolveBindingDevices()
	p8:migrateDevicesCategory()
	delete(v10)
	p8:loadDefaultBindings()
	p8:validateAndRepairComboActionBindings()
	p8:storeComboInputMappings()
	p8:assignComboMasks()
	p8:assignActionPrimaryBindings()
	p8:storeLinkedBindings()
	p8:restoreInputContexts()
	p8:notifyBindingChanges()
	p8:refreshEventCollections()
	for v11 in pairs(p8.newlyConnectedDevices) do
		p8.newlyConnectedDevices[v11] = nil
	end
	p8:checkDefaultInputExclusiveActionBindings()
end
function InputBinding.loadDefaultBindings(p12)
	if p12.inputBindingPathTemplate ~= nil then
		local v13 = loadXMLFile("DefaultKeyboardMouseBindings", p12.inputBindingPathTemplate)
		p12:loadActionBindingsFromXML(v13, true, nil, nil, true, false)
		delete(v13)
	end
	if p12.numGamepads > 0 then
		local v14 = p12:getBindingCategorySet(p12:getAllDeviceIdsWithBindings())
		local v15 = p12:getAllDeviceIdsWithoutBindings()
		for _, v16 in ipairs(InputBinding.DEVICE_CATEGORY_DEFAULT_LOAD_ORDER) do
			if v14[v16] then
				local v17 = InputBinding.DEVICE_CATEGORY_DEFAULTS_PATHS[v16]
				local v18 = loadXMLFile("ControllerTemplate", v17)
				if v18 ~= 0 then
					p12:loadActionBindingsFromXML(v18, true, nil, v15, true, false)
					delete(v18)
				end
			end
		end
		local v19 = p12:getBindingCategorySet(v15)
		for _, v20 in ipairs(InputBinding.DEVICE_CATEGORY_DEFAULT_LOAD_ORDER) do
			if v19[v20] then
				local v21 = InputBinding.DEVICE_CATEGORY_DEFAULTS_PATHS[v20]
				local v22 = loadXMLFile("ControllerTemplate", v21)
				if v22 ~= 0 then
					p12:loadActionBindingsFromXML(v22, true, nil, p12:getAllDevicesWithBindings(), false, false)
					delete(v22)
				end
			end
		end
	end
	p12:loadModBindingDefaults()
end
function InputBinding.onInputHelpModeSettingChange(p23, p24)
	p23.inputHelpModeSetting = p24
end
function InputBinding.onGamepadEnabledSettingChanged(p25, p26)
	p25.isGamepadEnabled = p26
end
function InputBinding.getBindingCategorySet(p27, p28)
	local v29 = {}
	for v30, _ in pairs(p28) do
		v29[p27.devicesByInternalId[v30].category] = true
	end
	local v31 = v29[InputDevice.CATEGORY.WHEEL] ~= nil
	local v32 = v29[InputDevice.CATEGORY.FARMWHEEL] ~= nil
	if (v31 or v32) and v29[InputDevice.CATEGORY.FARMPANEL] ~= nil then
		v29[InputDevice.CATEGORY.WHEEL] = nil
		v29[InputDevice.CATEGORY.FARMWHEEL] = nil
		v29[InputDevice.CATEGORY.FARMPANEL] = nil
		if v32 then
			v29[InputDevice.CATEGORY.FARMWHEEL_AND_PANEL] = true
			return v29
		end
		v29[InputDevice.CATEGORY.WHEEL_AND_PANEL] = true
	end
	return v29
end
function InputBinding.getDeviceHasAnyBindings(p33, p34)
	for _, v35 in pairs(p33.actions) do
		if InputBinding.GAMEPAD_COMBO_BINDINGS[v35.name] == nil then
			for _, v36 in pairs(v35.bindings) do
				if v36.deviceId == p34.deviceId then
					return true
				end
			end
		end
	end
	return false
end
function InputBinding.getAllDevicesWithBindings(p37)
	local v38 = {}
	for _, v39 in pairs(p37.actions) do
		if InputBinding.GAMEPAD_COMBO_BINDINGS[v39.name] == nil then
			for _, v40 in pairs(v39.bindings) do
				v38[v40.deviceId] = true
			end
		end
	end
	return v38
end
function InputBinding.getAllDeviceIdsWithoutBindings(p41)
	local v42 = 0
	local v43 = p41.devicesByInternalId[v42]
	local v44 = {}
	while v43 ~= nil do
		if not p41:getDeviceHasAnyBindings(v43) then
			v44[v42] = true
		end
		v42 = v42 + 1
		v43 = p41.devicesByInternalId[v42]
	end
	return v44
end
function InputBinding.getAllDeviceIdsWithBindings(p45)
	local v46 = 0
	local v47 = p45.devicesByInternalId[v46]
	local v48 = {}
	while v47 ~= nil do
		if p45:getDeviceHasAnyBindings(v47) then
			v48[v46] = true
		end
		v46 = v46 + 1
		v47 = p45.devicesByInternalId[v46]
	end
	return v48
end
function InputBinding.reloadModActions(p49)
	p49:load()
end
function InputBinding.loadModActions(p50)
	for _, v51 in ipairs(p50.modManager:getMods()) do
		local v52 = loadXMLFile("InputBinding ModActions ModFile", v51.modFile)
		p50:loadActions(v52, v51.modName)
		delete(v52)
	end
end
function InputBinding.loadModBindingDefaults(p53)
	for _, v54 in ipairs(p53.modManager:getMods()) do
		local v55 = loadXMLFile("InputBinding BindingDefaults ModFile", v54.modFile)
		p53:loadActionBindingsFromXML(v55, true, v54.modName, nil, true, false)
		delete(v55)
	end
end
function InputBinding.assignPlatformBindingPaths(p56)
	if GS_PLATFORM_PLAYSTATION then
		p56.settingsPath = InputBinding.PATHS.DEFAULT_BINDINGS
		return
	elseif GS_PLATFORM_XBOX then
		p56.settingsPath = InputBinding.PATHS.DEFAULT_BINDINGS_XBOX
		return
	elseif GS_PLATFORM_ID == PlatformId.IOS then
		p56.settingsPath = InputBinding.PATHS.DEFAULT_BINDINGS_IOS
		return
	elseif GS_PLATFORM_ID == PlatformId.ANDROID then
		p56.settingsPath = InputBinding.PATHS.DEFAULT_BINDINGS_ANDROID
		return
	elseif GS_PLATFORM_SWITCH then
		p56.settingsPath = InputBinding.PATHS.DEFAULT_BINDINGS_SWITCH
	else
		p56.settingsPath = InputBinding.PATHS.USER_BINDINGS
		p56.inputBindingPathTemplate = InputBinding.PATHS.DEFAULT_BINDINGS_KB_MOUSE
		p56:overwriteSettingsWithDefault(false)
		if not p56:checkSettingsIntegrity(p56.settingsPath, p56.inputBindingPathTemplate) then
			p56:overwriteSettingsWithDefault(true)
		end
	end
end
function InputBinding.overwriteSettingsWithDefault(p57, p58)
	copyFile(p57.inputBindingPathTemplate, p57.settingsPath, p58)
end
function InputBinding.restoreInputContexts(p59)
	for v60, v61 in pairs(p59.contexts) do
		local v62 = v61.actionEvents
		local v63 = {}
		for v64, v65 in pairs(v62) do
			v63[p59.nameActions[v64.name]] = v65
		end
		if v60 == p59.currentContextName then
			p59.actionEvents = v63
		end
		v61.actionEvents = v63
	end
end
function InputBinding.setShowMouseCursor(p66, p67, p68)
	p66.saveCursorX = p68 and (p66.mousePosXLast or 0.5) or 0.5
	p66.saveCursorY = p68 and (p66.mousePosYLast or 0.5) or 0.5
	p66.mousePosXLast = nil
	p66.mousePosYLast = nil
	setShowMouseCursor(p67)
	p66.wrapMousePositionEnabled = not p67
end
function InputBinding.getShowMouseCursor(p69)
	return not p69.wrapMousePositionEnabled
end
function InputBinding.getInputHelpMode(p70)
	local v71 = GS_INPUT_HELP_MODE_GAMEPAD
	local v72 = GS_IS_MOBILE_VERSION and GS_INPUT_HELP_MODE_TOUCH or GS_INPUT_HELP_MODE_KEYBOARD
	if p70.isConsoleVersion then
		v72 = v71
	elseif p70.isGamepadEnabled then
		if p70.inputHelpModeSetting == GS_INPUT_HELP_MODE_AUTO then
			return p70.lastInputHelpMode
		elseif p70.numGamepads > 0 and p70.inputHelpModeSetting == GS_INPUT_HELP_MODE_GAMEPAD then
			return GS_INPUT_HELP_MODE_GAMEPAD
		else
			return v72
		end
	end
	return v72
end
function InputBinding.getLastInputMode(p73)
	if Platform.isMobile and p73.lastInputMode == GS_INPUT_HELP_MODE_KEYBOARD then
		return GS_INPUT_HELP_MODE_TOUCH
	else
		return p73.lastInputMode
	end
end
function InputBinding.validateActionEventParameters(p74, p75, _, p76, p77, p78, p79)
	if p75 == nil then
		Logging.devWarning("Tried registering an unknown action")
		printCallstack()
		return false
	elseif InputAction[p75] == nil then
		Logging.devWarning("Tried registering an event for an unknown action: %s", p75)
		return false
	elseif p76 then
		if p77 or (p78 or p79) then
			local v80 = p74.nameActions[p75]
			return (v80 == nil or v80:getIsSupportedOnCurrentPlatform()) and true or false
		else
			Logging.devWarning("Tried registering an action event without any active trigger flags.")
			return false
		end
	else
		Logging.devWarning("Tried registering an action event without an event callback.")
		return false
	end
end
function InputBinding.registerActionEvent(p81, p82, p83, p84, p85, p86, p87, p88, p89, p90, p91)
	local v92 = p81:validateActionEventParameters(p82, p83, p84, p85, p86, p87)
	local v93 = p81.actionEvents
	local v94 = p81.contexts[p81.currentContextName].eventOrderCounter
	if p81.registrationContext ~= InputBinding.NO_REGISTRATION_CONTEXT then
		v93 = p81.registrationContext.actionEvents
		v94 = p81.registrationContext.eventOrderCounter
	end
	if p88 and v92 then
		local v95, v96 = p81:checkEventCollision(p82, p90, p91)
		if v92 then
			v92 = not v95
		end
		if v95 then
			return false, "", v93[v96]
		end
	end
	local v97 = ""
	if v92 then
		local v98 = InputEvent.new
		if p85 == nil then
			p85 = false
		end
		if p86 == nil then
			p86 = false
		end
		if p87 == nil then
			p87 = false
		end
		if p88 == nil then
			p88 = false
		end
		local v99 = v98(p82, p83, p84, p85, p86, p87, p88, p89, v94)
		local v100 = p81.nameActions[p82]
		local v101 = v93[v100]
		if v101 == nil then
			v101 = {}
			v93[v100] = v101
		end
		local v102 = #v101 == 0
		for _, v103 in ipairs(v101) do
			if v103.actionName == v99.actionName and v103:getTriggerCode() == v99:getTriggerCode() then
				return false, v97, { v103 }
			end
		end
		table.insert(v101, v99)
		p81.events[v99.id] = v99
		v97 = v99.id
		v99.displayIsVisible = v102
		v99:initializeDisplayText(v100)
		v99:setIgnoreComboMask(v100:getIgnoreComboMask())
		if p81.registrationContext == InputBinding.NO_REGISTRATION_CONTEXT then
			p81:refreshEventCollections()
			p81.contexts[p81.currentContextName].eventOrderCounter = v94 + 1
		else
			p81.registrationContext.eventOrderCounter = v94 + 1
		end
	end
	return v92, v97, nil
end
function InputBinding.checkEventCollision(p104, p105, p106, p107)
	local v108 = p104.nameActions[p105]
	if v108 == nil then
		Logging.error("Unknown action name %q", p105)
		return false, nil
	end
	local v109 = v108:getBindings()
	local v110 = p104.actionEvents
	if p104.registrationContext ~= InputBinding.NO_REGISTRATION_CONTEXT then
		v110 = p104.registrationContext.actionEvents
	end
	local v111 = {}
	local v112 = nil
	for v113, v114 in pairs(v110) do
		local v115 = table.hasSetIntersection(v108.categories, v113.categories)
		local v116 = v108 == v113
		local v117 = v108.isLocked or v113.isLocked
		local v118 = not v116
		if v118 then
			if v115 then
				v115 = not v117
			end
		else
			v115 = v118
		end
		local v119 = false
		for _, v120 in pairs(v114) do
			if v120.isActive then
				v119 = true
				break
			end
		end
		if v115 and v119 then
			local v121 = v113:getActiveBindings()
			for _, v122 in pairs(v109) do
				for _, v123 in pairs(v121) do
					if v122:hasEventCollision(v123) then
						if not p106 then
							return true, v113
						end
						v108:disableBinding(v122)
						table.insert(v111, v122)
						v112 = v113
					end
				end
			end
		end
	end
	local v124
	if #v111 > 0 then
		if p107 == true then
			return true, v112
		end
		if #v108:getBindings() > 0 then
			v124 = v108:getNumActiveBindings() == 0
		else
			v124 = false
		end
		if v124 then
			for _, v125 in pairs(v111) do
				v108:enableBinding(v125)
			end
		end
	else
		v124 = false
	end
	return v124, v112
end
function InputBinding.beginActionEventsModification(p126, p127, p128)
	if p127 == nil or p127 == InputBinding.NO_REGISTRATION_CONTEXT.name then
		Logging.devWarning("Cannot begin action event registration with an empty context name.")
		printCallstack()
	else
		local v129 = p126.contexts[p127]
		local v130
		if v129 == nil or p128 then
			v129 = p126:createContext(p127)
			v130 = true
		else
			v130 = false
		end
		if p126.debugEnabled then
			Logging.devInfo("[InputBinding] Beginning action events modification in context [%s]", p127)
		end
		p126.registrationContext = v129
		if v130 then
			registerGlobalActionEvents(p126)
		end
	end
end
function InputBinding.endActionEventsModification(p131, p132)
	if p132 or p131.registrationContext ~= InputBinding.NO_REGISTRATION_CONTEXT then
		if p131.debugEnabled then
			Logging.devInfo("[InputBinding] Ended action events modification in context [%s]", p131.registrationContext.name)
		end
		p131.registrationContext = InputBinding.NO_REGISTRATION_CONTEXT
		p131:refreshEventCollections()
	else
		Logging.devWarning("Called InputBinding:endActionEventsModification() when the registration context is already reset. Check call order.")
		printCallstack()
	end
end
function InputBinding.refreshEventCollections(p133)
	p133.needsRefresh = true
	if p133.markIt then
		p133.markIt = false
	end
end
function InputBinding.storeDisplayActionEvents(p134)
	p134.displayActionEvents = {}
	for v135, v136 in pairs(p134.actionEvents) do
		for _, v137 in ipairs(v136) do
			local v138 = v135:getActiveBindings()
			if v137.isActive and (v137.displayIsVisible and #v138 > 0) then
				local v139 = Binding.MAX_ALTERNATIVES_GAMEPAD + 1
				local v140 = Binding.MAX_ALTERNATIVES_GAMEPAD + 1
				for _, v141 in pairs(v138) do
					local v142 = p134.devicesByInternalId[v141.internalDeviceId]
					if v141.isActive and v142.category ~= InputDevice.CATEGORY.KEYBOARD_MOUSE then
						if v142.category == InputDevice.CATEGORY.GAMEPAD and v141.index < v140 then
							v140 = v141.index
						elseif v141.index < v139 then
							v139 = v141.index
						end
					end
				end
				local v143 = v139 < v140
				local v144 = p134.displayActionEvents
				table.insert(v144, {
					["action"] = v135,
					["event"] = v137,
					["inlineModifierButtons"] = v143
				})
				break
			end
		end
	end
end
local function v_u_147(p145, p146)
	if p145.orderValue == p146.orderValue then
		return p145.id < p146.id
	else
		return p145.orderValue < p146.orderValue
	end
end
function InputBinding.storeEventBindings(p148)
	-- upvalues: (copy) v_u_147
	for v149 in pairs(p148.activeBindings) do
		p148.activeBindings[v149] = nil
	end
	for v150 in pairs(p148.eventBindings) do
		p148.eventBindings[v150] = nil
	end
	for v151 in pairs(p148.eventOrder) do
		p148.eventOrder[v151] = nil
	end
	for v152, v153 in pairs(p148.actionEvents) do
		local v154 = v152:getActiveBindings()
		for _, v155 in pairs(v153) do
			if v155.isActive then
				local v156 = p148.eventBindings[v155]
				if not v156 then
					v156 = {}
					p148.eventBindings[v155] = v156
				end
				for _, v157 in ipairs(v154) do
					if v157.isActive then
						table.insert(v156, v157)
						p148.activeBindings[v157] = v157
					end
				end
				local v158 = p148.eventOrder
				table.insert(v158, v155)
			end
		end
	end
	table.sort(p148.eventOrder, v_u_147)
	p148.needUpdateAbort = true
end
function InputBinding.iterateEvents(p159, p160)
	local v161 = p159.actionEvents
	if p159.registrationContext ~= InputBinding.NO_REGISTRATION_CONTEXT then
		v161 = p159.registrationContext.actionEvents
	end
	for v162, v163 in pairs(v161) do
		for v164 = #v163, 1, -1 do
			if p160(v163[v164], v162.name, v163, v164) then
				return
			end
		end
	end
end
function InputBinding.removeEventInternal(p165, p166, p167, p168)
	if p166.triggerAlways then
		local v169 = p165.eventBindings[p166]
		if v169 ~= nil then
			for _, v170 in pairs(v169) do
				p165:neutralizeEventBindingInput(p166, v170)
			end
		end
	end
	p165.events[p166.id] = nil
	table.remove(p167, p168)
end
function InputBinding.removeActionEvent(p_u_171, p_u_172)
	local v_u_173 = false
	p_u_171:iterateEvents(function(p174, _, p175, p176)
		-- upvalues: (copy) p_u_172, (copy) p_u_171, (ref) v_u_173
		if p174.id == p_u_172 then
			p_u_171:removeEventInternal(p174, p175, p176)
			v_u_173 = true
			return true
		end
	end)
	if v_u_173 then
		p_u_171:refreshEventCollections()
	end
end
function InputBinding.removeActionEventsByActionName(p_u_177, p_u_178)
	local v_u_179 = false
	p_u_177:iterateEvents(function(p180, _, p181, p182)
		-- upvalues: (copy) p_u_178, (copy) p_u_177, (ref) v_u_179
		if p180.actionName == p_u_178 then
			p_u_177:removeEventInternal(p180, p181, p182)
			v_u_179 = true
		end
	end)
	if v_u_179 then
		p_u_177:refreshEventCollections()
	end
end
function InputBinding.removeActionEventsByTarget(p_u_183, p_u_184)
	local v_u_185 = false
	p_u_183:iterateEvents(function(p186, _, p187, p188)
		-- upvalues: (copy) p_u_184, (copy) p_u_183, (ref) v_u_185
		if p186.targetObject == p_u_184 then
			p_u_183:removeEventInternal(p186, p187, p188)
			v_u_185 = true
		end
	end)
	if v_u_185 then
		p_u_183:refreshEventCollections()
	end
end
function InputBinding.getActionEventsHasBinding(p189, p190)
	local v191 = p189.events[p190]
	if p189.events[p190] ~= nil then
		local v192 = p189.eventBindings[v191]
		if v192 ~= nil then
			return #v192 > 0
		end
	end
	return false
end
function InputBinding.getDisplayActionEvents(p193)
	return p193.displayActionEvents
end
function InputBinding.setActionEventText(p194, p195, p196)
	local v197 = p194.events[p195]
	local v198
	if v197 then
		v198 = v197.contextDisplayText ~= p196
		v197.contextDisplayText = p196
	else
		v198 = false
	end
	if v198 then
		p194:refreshEventCollections()
	end
end
function InputBinding.setActionEventIcon(p199, p200, p201)
	local v202 = p199.events[p200]
	local v203
	if v202 then
		v203 = v202.contextDisplayIconName ~= p201
		v202.contextDisplayIconName = p201
	else
		v203 = false
	end
	if v203 then
		p199:refreshEventCollections()
	end
end
function InputBinding.setActionEventTextVisibility(p204, p205, p206)
	local v207 = p204.events[p205]
	local v208
	if v207 then
		v208 = v207.displayIsVisible ~= p206
		v207.displayIsVisible = p206
	else
		v208 = false
	end
	if v208 then
		p204:refreshEventCollections()
	end
end
function InputBinding.setActionEventTextPriority(p209, p210, p211)
	local v212 = p209.events[p210]
	local v213
	if v212 and type(p211) == "number" then
		v213 = v212.displayPriority ~= p211
		v212.displayPriority = p211
	else
		v213 = false
	end
	if v213 then
		p209:refreshEventCollections()
	end
end
function InputBinding.setActionEventActive(p214, p215, p216)
	p214:setEventActive(p214.events[p215], p216)
end
function InputBinding.setEventActive(p217, p218, p219)
	local v220
	if p218 then
		v220 = p218.isActive ~= p219
		p218.isActive = p219
		if v220 then
			if p219 then
				p217:checkEventCollision(p218.actionName, true)
			else
				p217.nameActions[p218.actionName]:resetActiveBindings()
			end
		end
	else
		v220 = false
	end
	if v220 then
		p217:refreshEventCollections()
	end
end
function InputBinding.setActionEventsActiveByTarget(p_u_221, p_u_222, p_u_223)
	local v_u_224 = false
	p_u_221:iterateEvents(function(p225)
		-- upvalues: (copy) p_u_222, (ref) v_u_224, (copy) p_u_223, (copy) p_u_221
		if p225.targetObject == p_u_222 then
			v_u_224 = p225.isActive ~= p_u_223
			p225.isActive = p_u_223
			if v_u_224 then
				if p_u_223 then
					p_u_221:checkEventCollision(p225.actionName, true)
					return
				end
				p_u_221.nameActions[p225.actionName]:resetActiveBindings()
			end
		end
	end)
	if v_u_224 then
		p_u_221:refreshEventCollections()
	end
end
function InputBinding.getComboCommandPressedMask(p226)
	local v227 = 0
	local v228 = 0
	if p226.numGamepads > 0 then
		for v229, v230 in pairs(InputBinding.GAMEPAD_COMBOS) do
			local v231 = p226.comboInputBindings[v229]
			if v231 ~= nil and (v231.isPressed and v227 < v230.mask) then
				v227 = v230.mask
			end
		end
	end
	if not p226.isConsoleVersion then
		for v232, v233 in pairs(InputBinding.MOUSE_COMBOS) do
			if p226.comboInputBindings[v232].isPressed and v228 < v233.mask then
				v228 = v233.mask
			end
		end
	end
	return v227, v228
end
function InputBinding.getComboActionNameForAxisSet(p234, p235)
	for v236, v237 in pairs(p234.comboInputActions) do
		if table.equalSets(v236, p235) then
			return v237
		end
	end
	return nil
end
function InputBinding.getInternalIdByDeviceId(p238, p239)
	return p238.deviceIdToInternal[p239]
end
function InputBinding.getDeviceByInternalId(p240, p241)
	return p240.devicesByInternalId[p241]
end
function InputBinding.getDeviceById(p242, p243)
	local v244 = p242.deviceIdToInternal[p243]
	local v245
	if v244 == nil then
		v245 = nil
	else
		v245 = p242.devicesByInternalId[v244]
	end
	return v245
end
function InputBinding.getMissingDeviceById(p246, p247)
	return p246.missingDevices[p247]
end
function InputBinding.getHasMissingDevices(p248)
	return next(p248.missingDevices) ~= nil
end
function InputBinding.assignLastInputHelpMode(p249, p250, p251)
	local v252 = p249.lastInputMode ~= p250 and true or p251
	p249.lastInputMode = p250
	if v252 then
		p249:notifyInputModeChange(p250, false)
	end
	if p250 == GS_INPUT_HELP_MODE_KEYBOARD or p249.timeSinceLastInputHelpModeChange >= InputBinding.INPUT_MODE_CHANGE_MIN_INTERVAL then
		local v253 = p249.lastInputHelpMode ~= p250 and true or p251
		p249.lastInputHelpMode = p250
		if v253 then
			p249:notifyInputModeChange(p250, true)
		end
		if v253 or p250 == GS_INPUT_HELP_MODE_KEYBOARD then
			p249.timeSinceLastInputHelpModeChange = 0
		end
	end
	if GS_IS_MOBILE_VERSION and p249.lastInputHelpMode == GS_INPUT_HELP_MODE_KEYBOARD then
		p249.lastInputHelpMode = GS_INPUT_HELP_MODE_TOUCH
	end
end
function InputBinding.keyEvent(p254, _, _, _, _)
	p254:assignLastInputHelpMode(GS_INPUT_HELP_MODE_KEYBOARD)
end
function InputBinding.mouseEvent(p255, p256, p257, p258, p259, p260)
	if p258 then
		p255:assignLastInputHelpMode(GS_IS_MOBILE_VERSION and GS_INPUT_HELP_MODE_TOUCH or GS_INPUT_HELP_MODE_KEYBOARD)
	end
	if p255.mousePosXLast == nil or p255.mousePosYLast == nil then
		p255.mousePosXLast = p256
		p255.mousePosYLast = p257
	end
	p255.mouseMovementX = p255.mouseMotionScaleX * (p256 - p255.mousePosXLast)
	p255.mouseMovementY = p255.mouseMotionScaleY * (p257 - p255.mousePosYLast) / g_screenAspectRatio
	p255.mousePosXLast = p256
	p255.mousePosYLast = p257
	p255.accumMouseMovementX = p255.accumMouseMovementX + p255.mouseMovementX
	p255.accumMouseMovementY = p255.accumMouseMovementY + p255.mouseMovementY
	if p258 then
		p255.mouseButtonLast = p260
		p255.mouseButtonStateLast = true
	elseif p259 then
		p255.mouseButtonLast = Input.MOUSE_BUTTON_NONE
		p255.mouseButtonStateLast = false
	end
end
function InputBinding.touchEvent(p261, _, _, _, _, _)
	p261:assignLastInputHelpMode(GS_INPUT_HELP_MODE_TOUCH)
end
function InputBinding.getMousePosition(p262)
	return p262.mousePosXLast or p262.saveCursorX, p262.mousePosYLast or p262.saveCursorY
end
function InputBinding.getMouseButtonState(p263)
	return p263.mouseButtonLast, p263.mouseButtonStateLast
end
function InputBinding.startBindingChanges(p264)
	p264.originalActionBindings = {}
	for _, v265 in pairs(p264.actions) do
		local v266 = v265:getBindings()
		local v267 = {}
		for _, v268 in pairs(v266) do
			table.insert(v267, v268:clone())
		end
		p264.originalActionBindings[v265] = v267
	end
end
function InputBinding.commitBindingChanges(p269)
	p269.originalActionBindings = nil
	p269:assignComboMasks()
	p269:assignActionPrimaryBindings()
	p269:notifyBindingChanges()
	p269:refreshEventCollections()
end
function InputBinding.rollbackBindingChanges(p270)
	local v271 = {}
	for _, v272 in pairs(p270.originalActionBindings) do
		for _, v275 in pairs(v272) do
			v275:makeId()
			local v274 = v271[v275.id]
			if v274 == nil then
				v271[v275.id] = v275
			else
				local v275 = v274
			end
			local v276 = p270.loadedBindings[v275.id]
			if v276 ~= nil then
				v275:copyInputStateFrom(v276)
			end
		end
	end
	p270.loadedBindings = v271
	for v277, v278 in pairs(p270.originalActionBindings) do
		v277:clearBindings()
		for _, v279 in pairs(v278) do
			v277:addBinding(p270.loadedBindings[v279.id])
		end
	end
	p270:storeEventBindings()
end
function InputBinding.startInputCapture(p280, p281, p282, p_u_283, p_u_284, p_u_285, p_u_286, p_u_287)
	p280.isInputCapturing = true
	p280.gatherInputStoredMouseEvent = mouseEvent
	p280.gatherInputStoredKeyEvent = keyEvent
	p280.gatherInputStoredUpdate = update
	local function v292(p288, p289, p290, p291)
		-- upvalues: (copy) p_u_283, (copy) p_u_285, (copy) p_u_284
		if p_u_283 then
			p_u_285(p_u_283, p288, p289, p290, p291, p_u_284)
		else
			p_u_285(p289, p288, p290, p291, p_u_284)
		end
	end
	local function v293()
		-- upvalues: (copy) p_u_283, (copy) p_u_286
		if p_u_283 then
			p_u_286(p_u_283)
		else
			p_u_286()
		end
	end
	local function v294()
		-- upvalues: (copy) p_u_283, (copy) p_u_287, (copy) p_u_284
		if p_u_283 then
			p_u_287(p_u_283, p_u_284)
		else
			p_u_287(p_u_284)
		end
	end
	if p281 then
		p280:captureKeyboardInput(v293, v294, v292)
		function mouseEvent() end
		function update()
			setTextWidthScale(g_textWidthScale)
		end
		return
	elseif p282 then
		p280:captureKeyboardInput(v293, v294)
		p280:captureMouseInput(v292)
		function update()
			setTextWidthScale(g_textWidthScale)
		end
	else
		p280:captureKeyboardInput(v293, v294)
		p280:captureGamepadInput(v292)
		function mouseEvent() end
	end
end
function InputBinding.captureKeyboardInput(_, p_u_295, p_u_296, p_u_297)
	local v_u_298 = InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT
	function keyEvent(_, p299, _, p300)
		-- upvalues: (copy) p_u_295, (copy) p_u_296, (copy) p_u_297, (copy) v_u_298
		local v301 = Input.keyIdToIdName[p299]
		if p_u_295 and p299 == Input.KEY_esc then
			p_u_295()
			return
		elseif p_u_296 and p299 == Input.KEY_backspace then
			p_u_296()
		elseif p_u_297 and v301 then
			p_u_297(v_u_298, v301, p300 and 1 or 0)
		end
	end
end
function InputBinding.captureMouseInput(p302, p_u_303)
	local v_u_304 = nil
	local v_u_305 = nil
	local v_u_306 = nil
	local v_u_307 = p302.mousePosXLast
	local v_u_308 = p302.mousePosYLast
	local v_u_309 = InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT
	local v_u_310 = InputBinding.MOUSE_AXIS_NAMES[Input.AXIS_X]
	local v_u_311 = InputBinding.MOUSE_AXIS_NAMES[Input.AXIS_Y]
	p_u_303(v_u_309, v_u_310, false, 0)
	p_u_303(v_u_309, v_u_311, false, 0)
	function mouseEvent(p312, p313, p314, p315, p316)
		-- upvalues: (ref) v_u_306, (ref) v_u_304, (ref) v_u_305, (copy) p_u_303, (copy) v_u_309, (copy) v_u_310, (copy) v_u_311, (ref) v_u_307, (ref) v_u_308
		local v317 = Input.mouseButtonIdToIdName[p316]
		if p316 == Input.MOUSE_BUTTON_WHEEL_UP or p316 == Input.MOUSE_BUTTON_WHEEL_DOWN then
			p_u_303(v_u_309, v317, 1)
			p_u_303(v_u_309, v317, 0)
		elseif p314 then
			if v_u_306 == nil then
				v_u_306 = p316
				v_u_304 = p312
				v_u_305 = p313
				p_u_303(v_u_309, v_u_310, 0)
				p_u_303(v_u_309, v_u_311, 0)
			end
			p_u_303(v_u_309, v317, 1)
		elseif p315 then
			local v318 = p316 == v_u_306
			p_u_303(v_u_309, v317, 0)
			if v318 then
				v_u_306 = nil
				v_u_304 = nil
				v_u_305 = nil
			end
		end
		if v_u_306 ~= nil then
			v_u_307 = p312
			v_u_308 = p313
		end
		local v319 = v_u_307
		local v320 = v_u_308
		if v_u_306 ~= nil then
			v319 = v_u_304
			v320 = v_u_305
		end
		local v321 = p312 - v319
		local v322 = p313 - v320
		p_u_303(v_u_309, v_u_310, v321)
		p_u_303(v_u_309, v_u_311, v322)
	end
end
function InputBinding.captureGamepadInput(p_u_323, p_u_324)
	local v_u_325 = {}
	function update(_)
		-- upvalues: (copy) v_u_325, (copy) p_u_323, (copy) p_u_324
		setTextWidthScale(g_textWidthScale)
		local v326 = getNumOfGamepads()
		if v326 ~= #v_u_325 then
			for v327, _ in pairs(v_u_325) do
				v_u_325[v327] = nil
			end
			for v328 = 1, v326 do
				local v329 = {
					["axes"] = {},
					["buttons"] = {}
				}
				local v330 = v_u_325
				table.insert(v330, v329)
				for v331 = 1, Input.MAX_NUM_BUTTONS do
					if getInputButton(v331 - 1, v328 - 1) > 0 then
						v329.buttons[v331] = true
					end
				end
				for v332 = 1, Input.MAX_NUM_AXES do
					v329.axes[v332] = getInputAxis(v332 - 1, v328 - 1)
					if Input.isHalfAxis(v332 - 1) then
						v329.axes[v332] = (1 - v329.axes[v332]) * 0.5
					end
				end
			end
		end
		for v333 = 1, v326 do
			local v334 = v333 - 1
			local v335 = p_u_323.internalToDeviceId[v334]
			if v335 ~= nil then
				local v336 = v_u_325[v333]
				local v337 = {}
				for v338 = 1, Input.MAX_NUM_AXES do
					local v339 = getInputAxis(v338 - 1, v334)
					local v340 = v336.axes[v338]
					if Input.isHalfAxis(v338 - 1) then
						v339 = (1 - v339) * 0.5
					end
					p_u_324(v335, Input.axisIdToIdName[v338 - 1], v339, v340)
				end
				for v341 = 1, Input.MAX_NUM_BUTTONS do
					local v342 = Input.buttonIdToIdName[v341 - 1]
					if getInputButton(v341 - 1, v334) > 0 then
						if not v336.buttons[v341] then
							v337[v341 - 1] = true
							p_u_324(v335, v342, 1, 0)
						end
					else
						v336.buttons[v341] = nil
						p_u_324(v335, v342, 0, 0)
					end
				end
			end
		end
	end
end
function InputBinding.stopInputGathering(p343)
	if p343.isInputCapturing then
		mouseEvent = p343.gatherInputStoredMouseEvent
		keyEvent = p343.gatherInputStoredKeyEvent
		update = p343.gatherInputStoredUpdate
		p343.gatherInputCallbackFunction = nil
		p343.gatherInputCallbackObject = nil
		p343.gatherInputStoredMouseEvent = nil
		p343.gatherInputStoredKeyEvent = nil
		p343.gatherInputStoredUpdate = nil
		p343.isInputCapturing = false
	end
end
function InputBinding.restoreDefaultBindings(p344)
	copyFile(p344.inputBindingPathTemplate, p344.settingsPath, true)
	p344:load()
	p344:refresh()
end
function InputBinding.clearState(p345)
	p345.loadedBindings = {}
	p345.eventBindings = {}
	p345.nameActions = {}
	p345.actions = {}
	p345.missingDevices = {}
	p345.gamepadInputState = {}
	local v346 = GS_INPUT_HELP_MODE_KEYBOARD
	if p345.isConsoleVersion then
		v346 = GS_INPUT_HELP_MODE_GAMEPAD
	elseif GS_IS_MOBILE_VERSION then
		v346 = GS_INPUT_HELP_MODE_TOUCH
	end
	p345.lastInputMode = v346
	p345.lastInputHelpMode = v346
end
function InputBinding.loadActions(p347, p348, p349)
	local v350 = g_i18n
	local v351
	if p349 then
		v350 = _G[p349].g_i18n
		v351 = "modDesc.actions"
	else
		v351 = "actions"
	end
	p347:loadActionsFromXMLPath(p348, v351, v350, p349)
end
function InputBinding.loadActionsFromXMLPath(p352, p353, p354, p355, p356)
	local v357 = 0
	while true do
		local v358 = p354 .. string.format(".action(%d)", v357)
		if not hasXMLProperty(p353, v358) then
			return
		end
		local v359 = InputAction.createFromXML(p353, v358)
		if v359 ~= nil then
			local v360 = string.format("input_%s", v359.name)
			local v361 = p356 and (string.format(" in mod \'%s\'", p356) or "") or ""
			if p356 ~= nil then
				v359.displayCategory = g_modManager:getModByName(p356).title
			end
			v359.displayNamePositive = v359.name
			v359.displayNameNegative = v359.name
			local v362
			if InputBinding.MOUSE_COMBOS[v359.name] == nil then
				v362 = false
			else
				v362 = InputBinding.GAMEPAD_COMBOS[v359.name] ~= nil
			end
			local v363 = v359.isLocked
			local v364 = not v362
			if v364 then
				v364 = not v363
			end
			if v359.axisType == InputAction.AXIS_TYPE.FULL then
				local v365 = v360 .. InputBinding.SYMBOL_AFFIX_POSITIVE
				local v366 = v360 .. InputBinding.SYMBOL_AFFIX_NEGATIVE
				if p355:hasText(v365) then
					v359.displayNamePositive = p355:getText(v365)
				elseif v364 then
					Logging.warning("Missing l10n \'%s\'%s", v365, v361)
				end
				if p355:hasText(v366) then
					v359.displayNameNegative = p355:getText(v366)
				elseif v364 then
					Logging.warning("Missing l10n \'%s\'%s", v366, v361)
				end
			elseif p355:hasText(v360) then
				v359.displayNamePositive = p355:getText(v360)
			elseif v364 then
				Logging.warning("Missing l10n \'%s\'%s", v360, v361)
			end
			if p352.nameActions[v359.name] == nil then
				local v367 = p352.actions
				table.insert(v367, v359)
			else
				for v368 = 1, #p352.actions do
					local v369 = p352.actions[v368]
					if v369.name == v359.name then
						v359.bindings = v369.bindings
						v359:resetActiveBindings()
						p352.actions[v368] = v359
						break
					end
				end
			end
			p352.nameActions[v359.name] = v359
		end
		v357 = v357 + 1
	end
end
function InputBinding.resetDeviceInformation(p370)
	local v371 = p370.devicesByInternalId
	p370.devicesByInternalId = {}
	p370.devicesByCategory = {}
	p370.deviceIdToInternal = {}
	p370.internalToDeviceId = {}
	return v371
end
function InputBinding.createDefaultDevices(p372)
	local v373 = InputDevice.new(InputBinding.KB_MOUSE_INTERNAL_ID, InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT, InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT, InputDevice.CATEGORY.KEYBOARD_MOUSE)
	v373.isActive = not p372.isConsoleVersion
	p372.devicesByInternalId[InputBinding.KB_MOUSE_INTERNAL_ID] = v373
	p372.devicesByCategory[InputDevice.CATEGORY.KEYBOARD_MOUSE] = { v373 }
	p372.deviceIdToInternal[v373.deviceId] = InputBinding.KB_MOUSE_INTERNAL_ID
end
function InputBinding.enumerateGamepadDevices(p374, p375)
	p374.engineDeviceIdCounts = {}
	p374.numGamepads = getNumOfGamepads()
	p374.numActiveGamepads = 0
	p374.internalIdToEngineDeviceId = {}
	g_ignitionLockManager:reset()
	for v376 = 0, p374.numGamepads - 1 do
		local v377 = getGamepadId(v376)
		local v378 = getGamepadName(v376)
		p374.internalIdToEngineDeviceId[v376] = v377
		if InputDevice.getIsDeviceSupported(v377, v378) then
			local v379, v380 = InputDevice.getDeviceIdPrefix(v377)
			if v379 < 0 then
				v380 = v377
			end
			local v381 = p374.engineDeviceIdCounts[v380] or 0
			p374.engineDeviceIdCounts[v380] = v381 + 1
			local v382
			if v379 >= 0 then
				v382 = v377
			else
				v382 = InputDevice.getPrefixedDeviceId(v380, v381)
			end
			p374.deviceIdToInternal[v382] = v376
			p374.internalToDeviceId[v376] = v382
			p374.numActiveGamepads = p374.numActiveGamepads + 1
			local v383 = InputBinding.getDeviceCategory(v376)
			local v384 = InputDevice.new(v376, v382, v378, v383)
			p374.devicesByInternalId[v376] = v384
			if not p374.devicesByCategory[v383] then
				p374.devicesByCategory[v383] = {}
			end
			local v385 = p374.devicesByCategory[v383]
			table.insert(v385, v384)
		end
		g_ignitionLockManager:tryToAddDevice(v376, v377, v378)
	end
	for _, v386 in pairs(p375) do
		if not p374.deviceIdToInternal[v386.deviceId] then
			v386.internalId = -1
			p374.missingDevices[v386.deviceId] = v386
		end
	end
end
function InputBinding.getGamepadDevices(p387)
	local v388 = {}
	for _, v389 in pairs(p387.devicesByInternalId) do
		if v389:isController() then
			local v390 = {
				["deviceId"] = v389.deviceId,
				["name"] = v389.deviceName
			}
			table.insert(v388, v390)
		end
	end
	return v388
end
function InputBinding.loadDeviceSettingsFromXML(p391, p392)
	local v393 = 0
	local v394 = {}
	while true do
		local v395 = string.format("inputBinding.devices.device(%d)", v393)
		if not hasXMLProperty(p392, v395) then
			break
		end
		local v396 = InputDevice.loadIdFromXML(p392, v395)
		v394[v396] = true
		local v397 = p391.deviceIdToInternal[v396]
		if v397 then
			local v398 = p391.devicesByInternalId[v397]
			v398:loadSettingsFromXML(p392, v395)
			local v399 = InputDevice.loadCategoryFromXML(p392, v395)
			if v399 == InputDevice.CATEGORY.UNKNOWN and v399 ~= v398.category then
				p391.devicesToMigrateCategory[v396] = v398
			end
		elseif v396 and v396 ~= "" then
			local v400 = InputDevice.loadCategoryFromXML(p392, v395)
			local v401 = InputDevice.loadNameFromXML(p392, v395)
			local v402 = InputDevice.new(-1, v396, v401, v400)
			v402:loadSettingsFromXML(p392, v395)
			p391.missingDevices[v396] = v402
		end
		v393 = v393 + 1
	end
	for v403 in pairs(p391.deviceIdToInternal) do
		if not v394[v403] then
			p391.newlyConnectedDevices[v403] = true
		end
	end
end
function InputBinding.applyGamepadDeadzones(p404)
	if GS_PLATFORM_PC then
		for _, v405 in pairs(p404.devicesByInternalId) do
			if v405:isController() then
				for v406 = 0, Input.MAX_NUM_AXES - 1 do
					setGamepadDeadzone(0, v405.internalId, v406)
				end
			end
		end
	end
end
function InputBinding.initializeGamepadMapping(p407, p408)
	local v409 = p407:resetDeviceInformation()
	p407:createDefaultDevices()
	p407:enumerateGamepadDevices(v409)
	if p408 ~= nil then
		p407:loadDeviceSettingsFromXML(p408)
	end
	p407:applyGamepadDeadzones()
end
function InputBinding.validateAndRepairComboActionBindings(p410)
	for _, v411 in pairs(p410.actions) do
		local v412 = v411:getBindings()
		local v413 = nil
		local v414 = 1
		local v415 = nil
		local v416 = InputDevice.CATEGORY.UNKNOWN
		if p410.numGamepads > 0 and InputBinding.GAMEPAD_COMBO_BINDINGS[v411.name] then
			v413 = InputBinding.GAMEPAD_COMBO_BINDINGS[v411.name]
			v415 = InputDevice.DEFAULT_DEVICE_NAMES.GAMEPAD_DEFAULT
		elseif not p410.isConsoleVersion and InputBinding.MOUSE_COMBO_BINDINGS[v411.name] then
			v413 = InputBinding.MOUSE_COMBO_BINDINGS[v411.name]
			v414 = Binding.MAX_ALTERNATIVES_KB_MOUSE
			v415 = InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT
		end
		if v413 then
			local v417 = table.clone(v413)
			for v418 in pairs(v412) do
				v412[v418] = nil
			end
			local v419 = Binding.new(v415, v417, Binding.AXIS_COMPONENT.POSITIVE, Binding.INPUT_COMPONENT.POSITIVE, 0, v414)
			table.insert(v412, v419)
			local v420 = v412[1]
			local v421 = p410.deviceIdToInternal[v420.deviceId]
			if v421 ~= nil then
				v415 = v420.deviceId
				v416 = p410.devicesByInternalId[v421].category
			end
			v420:setIndex(v414)
			v420:updateData(v415, v416, v417, Binding.INPUT_COMPONENT.POSITIVE)
			v420:setActive((p410:resolveBindingDefaultDevice(v420, nil)))
			v420:makeId()
		end
	end
end
function InputBinding.loadActionBindingsFromXML(p422, p423, p424, p425, p426, p427, p428)
	p422:loadActionBindingsFromXMLPath(p423, p425 and "modDesc.inputBinding" or "inputBinding", p424, p426, p427, p428)
end
function InputBinding.loadActionBindingsFromXMLPath(p429, p430, p431, p432, p433, p434, p435)
	local v436 = 0
	while true do
		local v437 = string.format("%s.actionBinding(%d)", p431, v436)
		if not hasXMLProperty(p430, v437) then
			break
		end
		local v438 = getXMLString(p430, v437 .. "#action")
		if v438 and v438 ~= "" then
			local v439 = p429.nameActions[v438]
			if v439 and not (v439.bindingsKnown and p434) then
				if p435 then
					v439.bindingsKnown = true
				end
				p429:loadBindingsFromXML(p430, v437, v439, p432, p433)
			end
		end
		v436 = v436 + 1
	end
end
function InputBinding.loadBindingsFromXML(p440, p441, p442, p443, p444, p445)
	local v446 = 0
	while true do
		local v447 = p442 .. string.format(".binding(%d)", v446)
		if not hasXMLProperty(p441, v447) then
			break
		end
		local v448 = Binding.createFromXML(p441, v447)
		if p440:resolveBindingDefaultDevice(v448, p445) then
			p440:addBinding(p443, v448, p444)
		end
		v446 = v446 + 1
	end
end
function InputBinding.storeComboInputMappings(p449)
	p449.comboInputAxisMasks = {}
	p449.comboInputActions = {}
	p449.comboInputBindings = {}
	local v450 = { InputBinding.GAMEPAD_COMBOS }
	local v451 = not p449.isConsoleVersion and { InputBinding.GAMEPAD_COMBOS, InputBinding.MOUSE_COMBOS } or v450
	for _, v452 in pairs(v451) do
		for v453, v454 in pairs(v452) do
			local v455 = p449.nameActions[v453]
			if v455 then
				local v456 = nil
				for _, v457 in ipairs(v455:getBindings()) do
					if v457.isActive and (p449.devicesByInternalId[v457.internalDeviceId].category == InputDevice.CATEGORY.GAMEPAD or v457.isMouse) then
						v456 = v457
						break
					end
				end
				if v456 ~= nil then
					p449.comboInputAxisMasks[v456.axisNameSet] = v454.mask
					p449.comboInputActions[v456.axisNameSet] = v453
					p449.comboInputBindings[v453] = v456
				end
			end
		end
	end
end
function InputBinding.getBindingComboMask(p458, p459)
	for v460, v461 in pairs(p458.comboInputAxisMasks) do
		if table.equalSets(v460, p459.modifierAxisSet) then
			return v461
		end
	end
	return 0
end
function InputBinding.assignComboMasks(p462)
	for _, v463 in pairs(p462.actions) do
		local v464 = v463:getActiveBindings()
		v463.comboMaskMouse = 0
		v463.comboMaskGamepad = 0
		for _, v465 in pairs(v464) do
			local v466 = p462:getBindingComboMask(v465)
			if v465.isMouse then
				if InputBinding.MOUSE_COMBOS[v463.name] == nil then
					v463.comboMaskMouse = v466
					v465:setComboMask(v466)
				end
			elseif v465.isActive then
				local v467
				if p462.devicesByInternalId[v465.internalDeviceId].category == InputDevice.CATEGORY.GAMEPAD then
					v467 = v465.isGamepad
				else
					v467 = false
				end
				if v467 and InputBinding.GAMEPAD_COMBOS[v463.name] == nil then
					v463.comboMaskGamepad = v466
					v465:setComboMask(v466)
				end
			end
		end
	end
end
function InputBinding.storeLinkedBindings(p468)
	for _, v469 in pairs(p468.actions) do
		local v470 = InputAction.LINKED_ACTIONS[v469.name]
		if v470 ~= nil then
			local v471 = p468.nameActions[v470]
			for _, v472 in pairs(v469:getBindings()) do
				local v473 = p468.linkedBindings[v472]
				if v473 == nil then
					v473 = {}
					p468.linkedBindings[v472] = v473
				end
				local v474 = v471:getBindings()
				for _, v475 in pairs(v474) do
					if v475.deviceId == v472.deviceId and v475.index == v472.index then
						table.insert(v473, v475)
					end
				end
			end
		end
	end
end
function InputBinding.assignActionPrimaryBindings(p476)
	for _, v477 in pairs(p476.actions) do
		local v478 = v477:getActiveBindings()
		for _, v479 in pairs(v478) do
			if v479.deviceId == InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT and v479.index == 1 then
				v477:setPrimaryKeyboardBinding(v479)
			end
		end
	end
end
function InputBinding.adjustBindingSlotIndex(_, p480, p481)
	if p480.index >= 1 then
		return true
	end
	local v482 = p480.deviceId == InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT
	if v482 and InputBinding.getIsMouseInput(p480.axisNames) then
		if p481:getBindingAtSlot(p480.axisComponent, v482, Binding.MAX_ALTERNATIVES_KB_MOUSE) == nil then
			p480:setIndex(Binding.MAX_ALTERNATIVES_KB_MOUSE)
			return true
		end
	else
		local v483
		if v482 then
			v483 = Binding.MAX_ALTERNATIVES_KB_MOUSE - 1
		else
			v483 = Binding.MAX_ALTERNATIVES_GAMEPAD
		end
		for v484 = 1, v483 do
			if p481:getBindingAtSlot(p480.axisComponent, v482, v484) == nil then
				p480:setIndex(v484)
				return true
			end
		end
	end
	return false
end
function InputBinding.upgradeBindingVersion(p485, p486)
	if (getXMLInt(p486, "inputBinding#bindingVersion") or 0) == 0 then
		for _, v487 in pairs(p485.actions) do
			local v488 = {}
			for v489, v490 in pairs(v487.bindings) do
				v488[v489] = v490
			end
			for _, v491 in pairs(v488) do
				if v491.isGamepad then
					local v492 = p485.deviceIdToInternal[v491.deviceId]
					local v493
					if v492 then
						v493 = p485.devicesByInternalId[v492]
					else
						v493 = nil
					end
					local v494 = v493 or p485.missingDevices[v491.deviceId]
					if v494 and v494.category == InputDevice.CATEGORY.UNKNOWN then
						local v495 = {}
						local v496 = false
						for _, v500 in ipairs(v491.axisNames) do
							local v498 = v500:sub(v500:len())
							local v499
							if v498 == "+" or v498 == "-" then
								v499 = v500:sub(1, v500:len() - 1)
							else
								v499 = v500
								v498 = ""
							end
							local v500
							if v499 == "HALF_AXIS_1" or v499 == "AXIS_11" then
								v500 = "AXIS_2-"
								v496 = true
							elseif v499 == "HALF_AXIS_2" or v499 == "AXIS_12" then
								v500 = "AXIS_2+"
								v496 = true
							elseif v499 == "AXIS_2" then
								v500 = "AXIS_7" .. v498
								v496 = true
							elseif v499 == "AXIS_7" then
								v500 = "AXIS_8" .. v498
								v496 = true
							elseif v499 == "BUTTON_21" then
								v500 = "BUTTON_25"
								v496 = true
							elseif v499 == "BUTTON_22" then
								v500 = "BUTTON_26"
								v496 = true
							elseif v499 == "BUTTON_23" then
								v500 = "BUTTON_27"
								v496 = true
							elseif v499 == "BUTTON_24" then
								v500 = "BUTTON_28"
								v496 = true
							elseif v499 == "BUTTON_25" then
								v500 = "BUTTON_29"
								v496 = true
							elseif v499 == "BUTTON_26" then
								v500 = "BUTTON_30"
								v496 = true
							elseif v499 == "BUTTON_27" then
								v500 = "BUTTON_31"
								v496 = true
							elseif v499 == "BUTTON_28" then
								v500 = "BUTTON_32"
								v496 = true
							end
							table.insert(v495, v500)
						end
						if v496 and #v495 > 0 then
							local v501 = v495[#v495]
							local v502 = Binding.INPUT_COMPONENT.POSITIVE
							if v501:sub(v501:len()) == "-" then
								v502 = Binding.INPUT_COMPONENT.NEGATIVE
							end
							v487:removeBinding(v491)
							p485:addBinding(v487, (Binding.new(v491.deviceId, v495, v491.axisComponent, v502, v491.neutralInput, v491.index)))
						end
					end
				end
			end
		end
	end
end
function InputBinding.resolveBindingDevice(p503, p504, p505)
	if p504.category == InputDevice.CATEGORY.UNKNOWN and p504.category ~= p505.category then
		p503.devicesToMigrateCategory[p505.deviceId] = p505
	end
	for _, v506 in pairs(p503.actions) do
		for _, v507 in pairs(v506.bindings) do
			if v507.deviceId == p504.deviceId then
				v507.deviceId = p505.deviceId
				v507.internalDeviceId = p505.internalId
				v507:setActive(true)
				v507:makeId()
			end
		end
	end
end
function InputBinding.resolveBindingDevices(p508)
	local v509 = p508:getAllDevicesWithBindings()
	for v510, v511 in pairs(p508.missingDevices) do
		if v509[v510] then
			for _, v512 in pairs(p508.devicesByInternalId) do
				if v512.deviceName == v511.deviceName and not v509[v512.deviceId] then
					p508:resolveBindingDevice(v511, v512)
					v509[v512.deviceId] = true
					p508.missingDevices[v510] = nil
					break
				end
			end
		end
	end
	for v513, v514 in pairs(p508.missingDevices) do
		if v509[v513] and v514.category ~= InputDevice.CATEGORY.UNKNOWN then
			for _, v515 in pairs(p508.devicesByInternalId) do
				if v515.category == v514.category and not v509[v515.deviceId] then
					p508:resolveBindingDevice(v514, v515)
					v509[v515.deviceId] = true
					p508.missingDevices[v513] = nil
					break
				end
			end
		end
	end
	for v516 in pairs(p508.missingDevices) do
		if not v509[v516] then
			p508.missingDevices[v516] = nil
		end
	end
end
function InputBinding.resolveBindingDefaultDevice(p517, p518, p519)
	if not InputDevice.DEFAULT_DEVICE_NAMES[p518.deviceId] then
		return true
	end
	local v520 = InputDevice.DEFAULT_DEVICE_CATEGORIES[p518.deviceId]
	for _, v521 in pairs(p517.devicesByInternalId) do
		if v521.category == v520 and (p519 == nil or not p519[v521.deviceId]) then
			p518.deviceId = v521.deviceId
			p518.internalDeviceId = v521.internalId
			return true
		end
	end
	return false
end
function InputBinding.migrateDevicesCategory(p522)
	if GS_PLATFORM_PC then
		for v523, v524 in pairs(p522.devicesToMigrateCategory) do
			local v525 = p522.deviceIdToInternal[v524.deviceId]
			if v525 == nil or p522.numGamepads <= v525 then
				p522.devicesToMigrateCategory[v523] = nil
			elseif getIsGamepadMappingReliable(v525) then
				local v526 = {}
				local v527 = {}
				for v528 = 0, Input.MAX_NUM_AXES - 1 do
					local v529, v530 = getGamepadMappedUnknownAxis(v528, v525, 1)
					v526[v528] = { v529, v530 }
					local v531, v532 = getGamepadMappedUnknownAxis(v528, v525, -1)
					v527[v528] = { v531, v532 }
				end
				local v533 = {}
				for v534 = 0, Input.MAX_NUM_BUTTONS - 1 do
					v533[v534] = getGamepadMappedUnknownButton(v534, v525)
				end
				for _, v535 in pairs(p522.actions) do
					local v536 = {}
					for v537, v538 in pairs(v535.bindings) do
						v536[v537] = v538
					end
					for _, v539 in pairs(v536) do
						if v539.deviceId == v524.deviceId then
							local v540 = {}
							for v541, v544 in ipairs(v539.axisNames) do
								local v543 = Input.axisIdNameToId[v544]
								local v544
								if v543 then
									local v545 = v544:sub(v544:len())
									local v546 = v541 == #v539.axisNames and (not Input.isHalfAxis(v543) and v539.neutralInput ~= 0) and (v539.neutralInput == 1 and "-" or "+") or v545
									local v547 = (v546 == "-" and v527 and v527 or v526)[v543]
									if v547 and v547[1] < Input.MAX_NUM_AXES then
										local v548 = Input.isHalfAxis(v547[1]) and "" or (v547[2] and (v546 == "-" and "+" or "-") or v546)
										v544 = Input.axisIdToIdName[v547[1]] .. v548
									end
								else
									local v549 = Input.buttonIdNameToId[v544]
									if v549 then
										local v550 = v533[v549]
										if v550 and v550 < Input.MAX_NUM_BUTTONS then
											v544 = Input.buttonIdToIdName[v550]
										end
									end
								end
								table.insert(v540, v544)
							end
							if #v540 > 0 then
								local v551 = v540[#v540]
								local v552 = Binding.INPUT_COMPONENT.POSITIVE
								if v551:sub(v551:len()) == "-" then
									v552 = Binding.INPUT_COMPONENT.NEGATIVE
								end
								local v553 = v539.neutralInput
								local v554 = Input.axisIdNameToId[v551] and Input.isHalfAxis(Input.axisIdNameToId[v551]) and 0 or v553
								v535:removeBinding(v539)
								p522:addBinding(v535, (Binding.new(v539.deviceId, v540, v539.axisComponent, v552, v554, v539.index)))
							end
						end
					end
				end
				p522.devicesToMigrateCategory[v523] = nil
			end
		end
	elseif next(p522.devicesToMigrateCategory) then
		p522.devicesToMigrateCategory = {}
	end
end
function InputBinding.checkBindings(p555, _, p556)
	local v557 = {}
	for _, v558 in pairs(p555.actions) do
		local v559 = v558:getBindings()
		for _, v560 in pairs(v559) do
			for _, v561 in pairs(p556) do
				local v562, v563 = v561(v560, v558)
				if v562 then
					v557[v561] = v563
				end
			end
		end
	end
	return v557
end
function InputBinding.validateBinding(p564, p_u_565, p_u_566)
	local v567 = false
	local v568 = false
	local v569 = Binding.MAX_ALTERNATIVES_GAMEPAD
	if p_u_565.deviceId == InputDevice.DEFAULT_DEVICE_NAMES.KB_MOUSE_DEFAULT then
		v569 = Binding.MAX_ALTERNATIVES_KB_MOUSE
		if p_u_565.index == v569 then
			v567 = true
		else
			v568 = true
		end
	end
	local v570
	if v567 then
		v570 = InputBinding.getIsMouseInput(p_u_565.axisNames)
	elseif v568 then
		if p_u_565.index > 0 and p_u_565.index <= v569 then
			v570 = InputBinding.getIsKeyboardInput(p_u_565.axisNames)
		else
			v570 = false
		end
	elseif p_u_565.index > 0 and p_u_565.index <= v569 then
		v570 = InputBinding.getIsGamepadInput(p_u_565.axisNames)
	else
		v570 = false
	end
	local function v573(p571, p572)
		-- upvalues: (copy) p_u_565
		if p_u_565:hasCollisionWith(p571) then
			return true, {
				["collisionBinding"] = p571,
				["collisionAction"] = p572
			}
		else
			return false, nil
		end
	end
	local function v576(p574, p575)
		-- upvalues: (copy) p_u_566, (copy) p_u_565
		if p_u_566 == p575 and p_u_565.id == p574.id then
			return true, true
		else
			return false, nil
		end
	end
	local function v579(p577, p578)
		-- upvalues: (copy) p_u_566, (copy) p_u_565
		if p578 == p_u_566 and p_u_565:isSameSlot(p577) then
			return true, true
		else
			return false, nil
		end
	end
	local v580 = p564:checkBindings(p_u_566, { v573, v576, v579 })
	local v581 = v580[v576] and true or false
	local v582 = v580[v579] and true or false
	local v583 = v580[v573]
	return v570, v581, v582, v583 and true or false, v583
end
function InputBinding.addBinding(p584, p585, p586, p587)
	if not p584:adjustBindingSlotIndex(p586, p585) then
		if not p587 then
			local v588 = Logging.warning
			local v589 = tostring(p586)
			local v590 = p585.name
			v588("Tried to add additional alternative binding %s to %s. The maximum alternative count has been reached. The new binding has been ignored.", v589, (tostring(v590)))
		end
		return false, nil
	end
	local v591 = false
	local v592, v593, v594, _, v595 = p584:validateBinding(p586, p585)
	if v592 then
		v592 = not v593
		if v592 then
			v592 = not v594
		end
	end
	if not v592 then
		if v593 then
			if not p587 then
				local v596 = Logging.warning
				local v597 = tostring(p586)
				local v598 = p585.name
				v596("Tried to add duplicate binding %s to %s. The new binding has been ignored.", v597, (tostring(v598)))
				return v591, v595
			end
		elseif v594 and not p587 then
			local v599 = Logging.warning
			local v600 = tostring(p586)
			local v601 = p585.name
			v599("Tried assigning the binding %s to %s to an occupied slot. The new binding has been ignored", v600, (tostring(v601)))
		end
		return v591, v595
	end
	p586.internalDeviceId = p584.deviceIdToInternal[p586.deviceId]
	p586:setIsAnalog(InputBinding.getIsAnalogInput(p586.unmodifiedAxis))
	p586:setActive(p586.internalDeviceId ~= nil)
	local v602 = p584.devicesByInternalId[p586.internalDeviceId]
	if v602 ~= nil then
		p586:updateData(nil, v602.category)
	end
	p586:makeId()
	local v603 = p584.loadedBindings[p586.id]
	if v603 == nil or not v603.isActive then
		p584.loadedBindings[p586.id] = p586
	else
		p586 = v603
	end
	p585:addBinding(p586)
	return true, v595
end
function InputBinding.updateBinding(p604, p605, p606, p607, p608, p609, p610, p611, p612)
	local v613 = nil
	local v614 = p604.nameActions[p606]
	if v614 ~= nil then
		local v615 = v614:getBindings()
		for _, v616 in pairs(v615) do
			if v616.deviceId == p605 and (v616.index == p607 and v616.axisComponent == p608) then
				v613 = v616
			end
		end
	end
	local v617, v618
	if v613 == nil then
		v617 = false
		v618 = nil
	else
		v614:removeBinding(v613)
		v617, v618 = p604:addBinding(v614, Binding.new(p609, p610, p608, p611, p612, p607), true)
		if not v617 then
			p604:addBinding(v614, v613, true)
		end
	end
	return v617, v618
end
function InputBinding.deleteBinding(p619, p620, p621, p622, p623)
	local v624 = p619.nameActions[p621]
	if v624 ~= nil then
		local v625 = v624:getBindings()
		for v626, v627 in pairs(v625) do
			if v627.deviceId == p620 and (v627.index == p622 and v627.axisComponent == p623) then
				table.remove(v625, v626)
				return
			end
		end
	end
end
function InputBinding.getKeyboardMouseInputActiveAndValue(p628, p629, p630, p631)
	if not next(p629) then
		return false, 0
	end
	local v632 = 0
	local v633 = true
	for _, v634 in pairs(p629) do
		local v635 = Input[v634]
		if not v635 then
			return false, v632
		end
		if InputBinding.MOUSE_AXES[v634] and v635 == Input.AXIS_X then
			v632 = p628.inputMouseXAxisValue
			if p630 ~= p631 then
				v632 = -v632
			end
		elseif InputBinding.MOUSE_AXES[v634] and v635 == Input.AXIS_Y then
			v632 = p628.inputMouseYAxisValue
			if p630 ~= p631 then
				v632 = -v632
			end
		else
			if not (InputBinding.MOUSE_BUTTONS[v634] and Input.isMouseButtonPressed(v635) or Input.isKeyPressed(v635)) then
				return false, 0
			end
			v632 = p630
		end
	end
	return v633, v632
end
function InputBinding.getGamepadInputActiveAndValue(p636, p637, p638, p639, p640)
	local v641 = #p638
	if v641 == 0 then
		return false, 0
	end
	for v642 = 1, v641 - 1 do
		if p636:getGamepadAxisOrButtonValue(p637, p638[v642], p639) < Binding.PRESSED_MAGNITUDE_THRESHOLD then
			return false, 0
		end
	end
	local v643, v644 = p636:getGamepadAxisOrButtonValue(p637, p638[v641], p639)
	if not v644 and v643 < Binding.PRESSED_MAGNITUDE_THRESHOLD then
		return false, 0
	end
	if p640 < 0 then
		v643 = -v643
	end
	return true, v643
end
function InputBinding.getGamepadAxisOrButtonValue(p645, p646, p647, p648)
	local v649 = Input.buttonIdNameToId[p647]
	if v649 == nil then
		local v650 = Input.axisIdNameToId[p647]
		if v650 == nil then
			return 0, false
		else
			return p645:getGamepadAxisValue(p646, v650, p647, p648), true
		end
	else
		return getInputButton(v649, p646), false
	end
end
function InputBinding.getGamepadAxisValue(p651, p652, p653, p654, p655, p656)
	local v657
	if Input.isHalfAxis(p653) then
		v657 = (1 - getInputAxis(p653, p652)) * 0.5
	else
		v657 = getInputAxis(p653, p652)
		if p655 ~= 0 then
			v657 = (v657 - p655) * 0.5
		end
		if p654:sub(p654:len()) == "-" then
			v657 = -v657
		end
	end
	local v658 = p651.devicesByInternalId[p652]
	if v658 then
		if v657 ~= 0 then
			v658:updateForceFeedbackState(p653)
		end
		if GS_PLATFORM_PC then
			local v659 = v658:getDeadzone(p653)
			if p656 == nil then
				p656 = v659
			end
			if p656 > 0.999 or math.abs(v657) < p656 then
				return 0
			end
			if v657 > 0 then
				return (v657 - p656) / (1 - p656)
			end
			v657 = (v657 + p656) / (1 - p656)
		end
	end
	return v657
end
function InputBinding.update(p660, p661)
	p660.needUpdateAbort = false
	p660.timeSinceLastInputHelpModeChange = p660.timeSinceLastInputHelpModeChange + p661
	p660:checkGamepadsChanged()
	p660:checkGamepadsCategoryChanged()
	p660:checkGamepadActive(p660.numGamepads)
	p660:updateMouseInput()
	p660:updateInput()
	p660:finalizeMouseInput()
end
function InputBinding.refresh(p662, p663)
	if p662.needsRefresh or p663 then
		p662.needsRefresh = false
		p662:storeEventBindings()
		p662:storeDisplayActionEvents()
		p662:notifyEventChanges()
		p662.markIt = true
	end
end
function InputBinding.draw(p664)
	if p664.debugEnabled then
		p664:updateDebugDisplay()
	end
	if p664.debugContextEnabled then
		p664:debugRenderInputContext()
	end
	if p664.debugRegisteredActions then
		p664:debugRenderRegisteredActions()
	end
end
function InputBinding.checkGamepadsChanged(p665)
	local v666 = getNumOfGamepads()
	local v667 = v666 ~= p665.numGamepads
	if not v667 then
		for v668 = 0, v666 - 1 do
			if getGamepadId(v668) ~= p665.internalIdToEngineDeviceId[v668] then
				v667 = true
				break
			end
		end
	end
	if v667 then
		p665.numGamepads = v666
		p665:load()
		p665:refresh(true)
		p665.messageCenter:publish(MessageType.INPUT_DEVICES_CHANGED)
	end
end
function InputBinding.checkGamepadsCategoryChanged(p669)
	if GS_PLATFORM_PC then
		for v670 = 0, p669.numGamepads - 1 do
			local v671 = p669.devicesByInternalId[v670]
			if v671 and (v671.category == InputDevice.CATEGORY.UNKNOWN and getGamepadCategory(v670) ~= v671.category) then
				p669.devicesToMigrateCategory[v671.deviceId] = v671
			end
		end
		for v672, v673 in pairs(p669.devicesToMigrateCategory) do
			local v674 = p669.deviceIdToInternal[v673.deviceId]
			if v674 then
				if getIsGamepadMappingReliable(v674) then
					p669:load()
					return
				end
			else
				p669.devicesToMigrateCategory[v672] = nil
			end
		end
	end
end
function InputBinding.checkGamepadActive(p675, p676)
	local v677 = false
	if p676 > 0 and p675.lastInputHelpMode ~= GS_INPUT_HELP_MODE_GAMEPAD then
		local v678 = InputBinding.INPUT_MODE_CHANGE_THRESHOLD
		for v679 = 0, p676 - 1 do
			local v680 = p675.gamepadInputState[v679]
			if v680 == nil then
				v680 = {
					["buttons"] = {},
					["axes"] = {}
				}
				p675.gamepadInputState[v679] = v680
			end
			local v681 = v680.buttons
			local v682 = v680.axes
			for v683 = 0, Input.MAX_NUM_BUTTONS - 1 do
				local v684 = v681[v683] or 0
				local v685 = getInputButton(v683, v679)
				if not v677 then
					local v686 = v685 - v684
					v677 = v678 < math.abs(v686)
				end
				v681[v683] = v685
			end
			for v687 = 0, Input.MAX_NUM_AXES - 1 do
				local v688 = Input.isHalfAxis(v687) and 1 or 0
				local v689 = v682[v687] or v688
				local v690 = getInputAxis(v687, v679)
				if not v677 then
					local v691 = v690 - v689
					v677 = v678 < math.abs(v691)
				end
				v682[v687] = v690
			end
		end
	end
	if v677 then
		p675:assignLastInputHelpMode(GS_INPUT_HELP_MODE_GAMEPAD)
	end
end
function InputBinding.updateMouseInput(p692)
	local v693 = p692.accumMouseMovementX
	local v694 = -p692.accumMouseMovementY
	local v695 = -InputBinding.MOUSE_MOVE_LIMIT
	local v696 = InputBinding.MOUSE_MOVE_LIMIT
	p692.inputMouseXAxisValue = math.clamp(v693, v695, v696) * InputBinding.MOUSE_MOVE_BASE_FACTOR
	local v697 = -InputBinding.MOUSE_MOVE_LIMIT
	local v698 = InputBinding.MOUSE_MOVE_LIMIT
	p692.inputMouseYAxisValue = math.clamp(v694, v697, v698) * InputBinding.MOUSE_MOVE_BASE_FACTOR
	local v699 = p692.inputMouseXAxisValue
	if math.abs(v699) <= 0.001 then
		local v700 = p692.inputMouseYAxisValue
		if math.abs(v700) <= 0.001 then
			::l3::
			return
		end
	end
	p692:assignLastInputHelpMode(GS_INPUT_HELP_MODE_KEYBOARD)
	goto l3
end
function InputBinding.finalizeMouseInput(p701)
	if p701.wrapMousePositionEnabled then
		wrapMousePosition(p701.saveCursorX, p701.saveCursorY)
		p701.mousePosXLast = p701.saveCursorX
		p701.mousePosYLast = p701.saveCursorY
	end
	p701.accumMouseMovementX = 0
	p701.accumMouseMovementY = 0
	p701.inputMouseXAxisValue = 0
	p701.inputMouseYAxisValue = 0
end
function InputBinding.clearActiveBindingBuffer(p702, p703)
	for v704 in pairs(p702.devicesByInternalId) do
		local v705 = p703[v704]
		if v705 then
			table.clear(v705)
		else
			p703[v704] = {}
		end
	end
end
function InputBinding.updateEventBindings(p706, p707)
	for v708 in pairs(p706.activeBindings) do
		if v708.isActive then
			p706:updateBindingInput(v708)
			local v709 = p707[v708.internalDeviceId]
			local v710 = v708.isUpFlank or v708.inputValue ~= 0
			for _, v711 in ipairs(v709) do
				if v711 ~= v708 then
					if v710 and (not v711.isShadowed and table.isSubset(v711.axisNameSet, v708.axisNameSet)) then
						v711.isShadowed = true
					end
					if (v711.isUpFlank or v711.inputValue ~= 0) and (not v708.isShadowed and table.isSubset(v708.axisNameSet, v711.axisNameSet)) then
						v708.isShadowed = true
					end
				end
			end
			v709[#v709 + 1] = v708
		end
	end
end
function InputBinding.hasBindingForPressedMouseComboMask(p712, p713)
	for v714 in pairs(p712.activeBindings) do
		if v714.isMouse and v714:getComboMask() == p713 then
			return true
		end
	end
	return false
end
function InputBinding.shadowLinkedBindings(p715)
	for v716, v717 in pairs(p715.linkedBindings) do
		if v716.isShadowed then
			for _, v718 in pairs(v717) do
				v718.isShadowed = true
			end
		end
	end
end
function InputBinding.updateComboBindings(p719)
	for _, v720 in pairs(InputBinding.ALL_COMBOS) do
		for v721 in pairs(v720) do
			local v722 = p719.comboInputBindings[v721]
			if v722 and v722.isActive then
				p719:updateBindingInput(v722)
			end
		end
	end
end
function InputBinding.updateInput(p723)
	p723.needUpdateAbort = false
	local v724, v725 = p723:getComboCommandPressedMask()
	if v724 ~= p723.pressedGamepadComboMask or v725 ~= p723.pressedMouseComboMask then
		p723:resetContinuousEventBindings(true, p723.pressedGamepadComboMask, p723.pressedMouseComboMask)
	end
	p723.pressedGamepadComboMask = v724
	p723.pressedMouseComboMask = v725
	p723:clearActiveBindingBuffer(p723.activeDeviceBindingsBuffer)
	p723:updateEventBindings(p723.activeDeviceBindingsBuffer)
	p723:shadowLinkedBindings()
	local v726 = p723:hasBindingForPressedMouseComboMask(v725)
	for _, v727 in ipairs(p723.eventOrder) do
		if p723.needUpdateAbort then
			p723.needUpdateAbort = false
			break
		end
		local v728 = p723.eventBindings[v727]
		local v729 = nil
		local v730 = 0
		for _, v731 in pairs(v728) do
			local v732 = true
			local v733 = v726 and v731.isMouse
			if v733 then
				v733 = InputBinding.MOUSE_AXES[v731.unmodifiedAxis]
			end
			if not v727:getIgnoreComboMask() or v733 then
				if v731.isMouse then
					v732 = v731.comboMask == v725 and true or InputBinding.MOUSE_COMBO_AXIS_NAMES[v731.unmodifiedAxis]
				else
					v732 = v731.comboMask == v724 and true or InputBinding.GAMEPAD_COMBO_AXIS_NAMES[v731.unmodifiedAxis]
				end
			end
			if v732 and (v731.isInputActive and not (v731.isShadowed or v731:getFrameTriggered())) then
				if v729 then
					local v734 = v731.inputValue
					if v730 < math.abs(v734) or v731.isUpFlank and v730 == 0 then
						goto l28
					end
				else
					::l28::
					local v735 = v731.inputValue
					v730 = math.abs(v735)
					v729 = v731
				end
			end
		end
		if v729 ~= nil then
			v727:notifyInput(v729)
		end
	end
	p723:updateComboBindings()
	for v736, _ in pairs(p723.eventBindings) do
		v736:frameReset()
	end
end
function InputBinding.updateBindingInput(p737, p738)
	local v739 = p737.devicesByInternalId[p738.internalDeviceId]
	if v739 ~= nil then
		local v740 = false
		local v741 = 0
		if v739.category == InputDevice.CATEGORY.KEYBOARD_MOUSE then
			v740, v741 = p737:getKeyboardMouseInputActiveAndValue(p738.axisNames, p738.axisDirection, p738.inputDirection)
		elseif p737.isGamepadEnabled then
			v740, v741 = p737:getGamepadInputActiveAndValue(p738.internalDeviceId, p738.axisNames, p738.neutralInput, p738.axisDirection)
			if v741 ~= 0 then
				v741 = v741 * (v739.sensitivities[Input[p738.unmodifiedAxis]] or 1)
			end
		end
		p738:updateInput(v741, v740)
	end
end
function InputBinding.resetContinuousEventBindings(p742, p743, p744, p745)
	for v746, v747 in pairs(p742.eventBindings) do
		if v746.triggerAlways and not v746:getIgnoreComboMask() then
			for _, v748 in pairs(v747) do
				local v749
				if p743 then
					v749 = ((not v748.isGamepad or v748.comboMask ~= p744) and true or false) and v748.isMouse
					if v749 then
						v749 = v748.comboMask == p745
					end
				else
					v749 = true
				end
				if v749 then
					p742:neutralizeEventBindingInput(v746, v748)
				end
			end
		end
	end
end
function InputBinding.resetBindingInputStates(p750)
	for _, v751 in pairs(p750.eventBindings) do
		for _, v752 in pairs(v751) do
			v752:resetInputState()
		end
	end
end
function InputBinding.neutralizeEventBindingInput(_, p753, p754)
	p754:updateInput(0, true)
	p753:frameReset()
	p753:notifyInput(p754, true)
end
function InputBinding.updateDebugDisplay(p755)
	local v756 = 0.02
	for v757 = 0, p755.numGamepads - 1 do
		setTextColor(1, 1, 1, 1)
		local v758 = 0.95
		setTextBold(true)
		renderText(v756, v758, getCorrectTextSize(0.012), getGamepadName(v757))
		setTextBold(false)
		local v759 = v758 - 0.015
		for v760 = 0, Input.MAX_NUM_BUTTONS - 1 do
			renderText(v756, v759, getCorrectTextSize(0.012), "- " .. v760)
			renderText(v756 + 0.05, v759, getCorrectTextSize(0.012), getGamepadButtonLabel(v760, v757) or "n/a")
			local v761 = renderText
			local v762 = v756 + 0.1
			local v763 = getCorrectTextSize(0.012)
			local v764 = getInputButton(v760, v757) > 0
			v761(v762, v759, v763, (tostring(v764)))
			v759 = v759 - 0.015
		end
		for v765 = 0, Input.MAX_NUM_AXES - 1 do
			renderText(v756, v759, getCorrectTextSize(0.012), "+ " .. v765)
			renderText(v756 + 0.05, v759, getCorrectTextSize(0.012), getGamepadAxisLabel(v765, v757) or "n/a")
			renderText(v756 + 0.1, v759, getCorrectTextSize(0.012), string.format("%.4f", getInputAxis(v765, v757)))
			v759 = v759 - 0.015
		end
		setTextColor(1, 0, 0, 1)
		local v766 = 0.95 + 0.5 * g_pixelSizeY
		local v767 = v756 - 0.5 * g_pixelSizeX
		setTextBold(true)
		renderText(v767, v766, getCorrectTextSize(0.012), getGamepadName(v757))
		setTextBold(false)
		local v768 = v766 - 0.015
		for v769 = 0, Input.MAX_NUM_BUTTONS - 1 do
			renderText(v767, v768, getCorrectTextSize(0.012), "- " .. v769)
			renderText(v767 + 0.05, v768, getCorrectTextSize(0.012), getGamepadButtonLabel(v769, v757) or "n/a")
			local v770 = renderText
			local v771 = v767 + 0.1
			local v772 = getCorrectTextSize(0.012)
			local v773 = getInputButton(v769, v757) > 0
			v770(v771, v768, v772, (tostring(v773)))
			v768 = v768 - 0.015
		end
		for v774 = 0, Input.MAX_NUM_AXES - 1 do
			renderText(v767, v768, getCorrectTextSize(0.012), "+ " .. v774)
			renderText(v767 + 0.05, v768, getCorrectTextSize(0.012), getGamepadAxisLabel(v774, v757) or "n/a")
			renderText(v767 + 0.1, v768, getCorrectTextSize(0.012), string.format("%.4f", getInputAxis(v774, v757)))
			v768 = v768 - 0.015
		end
		v756 = v767 + 0.15
	end
	setTextColor(1, 1, 1, 1)
end
function InputBinding.saveToXMLFile(p775)
	if p775.settingsPath == InputBinding.PATHS.USER_BINDINGS then
		local v776 = loadXMLFile("InputBindings", p775.settingsPath)
		local v777 = 1
		local v778 = {}
		while true do
			local v779 = string.format("inputBinding.actionBinding(%d)", v777 - 1)
			if not hasXMLProperty(v776, v779) then
				break
			end
			local v780 = getXMLString(v776, v779 .. "#action")
			if v780 and InputAction[v780] then
				if p775.nameActions[v780] ~= nil then
					local v781 = string.format("%s.binding(0)", v779)
					while hasXMLProperty(v776, v781) do
						removeXMLProperty(v776, v781)
					end
					local v782 = p775.nameActions[v780]:getBindings()
					for v783, v784 in ipairs(v782) do
						v784:saveToXMLFile(v776, (string.format("%s.binding(%d)", v779, v783 - 1)))
					end
				end
				v778[v780] = true
			end
			v777 = v777 + 1
		end
		for _, v785 in ipairs(p775.actions) do
			if not v778[v785.name] then
				local v786 = string.format("inputBinding.actionBinding(%d)", v777 - 1)
				setXMLString(v776, v786 .. "#action", v785.name)
				local v787 = v785:getBindings()
				for v788, v789 in ipairs(v787) do
					v789:saveToXMLFile(v776, (string.format("%s.binding(%d)", v786, v788 - 1)))
				end
				v777 = v777 + 1
			end
		end
		p775:saveDeviceSettings(v776)
		setXMLFloat(v776, "inputBinding#mouseSensitivityScaleX", p775.mouseMotionScaleX)
		setXMLFloat(v776, "inputBinding#mouseSensitivityScaleY", p775.mouseMotionScaleY)
		setXMLInt(v776, "inputBinding#bindingVersion", InputBinding.currentBindingVersion)
		saveXMLFile(v776)
		delete(v776)
		syncProfileFiles()
	end
end
function InputBinding.saveDeviceSettings(p790, p791)
	while hasXMLProperty(p791, "inputBinding.devices.device(0)") do
		removeXMLProperty(p791, "inputBinding.devices.device(0)")
	end
	local v792 = 0
	for _, v793 in pairs(p790.devicesByInternalId) do
		if not InputDevice.DEFAULT_DEVICE_NAMES[v793.deviceId] then
			v793:saveSettingsToXML(p791, (string.format("inputBinding.devices.device(%d)", v792)))
			v792 = v792 + 1
		end
	end
	for _, v794 in pairs(p790.missingDevices) do
		if not InputDevice.DEFAULT_DEVICE_NAMES[v794.deviceId] then
			v794:saveSettingsToXML(p791, (string.format("inputBinding.devices.device(%d)", v792)))
			v792 = v792 + 1
		end
	end
end
function InputBinding.getActionList(p795)
	local v796 = {}
	for _, v797 in ipairs(p795.actions) do
		local v798 = v797:clone()
		table.insert(v796, v798)
	end
	return v796
end
function InputBinding.getActionByName(p799, p800)
	return p799.nameActions[p800]
end
function InputBinding.disableAlternateBindingsForAction(p801, p802)
	local v803 = p801.nameActions[p802]
	local v804 = p801.actionEvents[v803]
	if v804 ~= nil then
		for _, v805 in pairs(v804) do
			local v806 = p801.eventBindings[v805]
			if v806 ~= nil then
				for v807 = #v806, 1, -1 do
					if v806[v807].index > 1 then
						table.remove(v806, v807)
					end
				end
			end
		end
	end
end
function InputBinding.resetActiveActionBindings(p808)
	for _, v809 in pairs(p808.nameActions) do
		v809:resetActiveBindings()
	end
end
function InputBinding.createContext(p810, p811)
	p810:deleteContext(p811)
	local v812 = {
		["actionEvents"] = {},
		["name"] = p811,
		["previousContextName"] = "",
		["eventOrderCounter"] = 1
	}
	p810.contexts[p811] = v812
	return v812
end
function InputBinding.deleteContext(p813, p814)
	local v815 = p813.contexts[p814]
	if v815 ~= nil then
		for _, v816 in pairs(v815.actionEvents) do
			for v817 = #v816, 1, -1 do
				p813:removeEventInternal(v816[v817], v816, v817)
			end
		end
	end
	p813.contexts[p814] = nil
end
function InputBinding.replaceContextInStack(p818, p819, p820)
	for _, v821 in pairs(p818.contexts) do
		if v821.previousContextName == p819 then
			v821.previousContextName = p820
		end
	end
end
function InputBinding.setContext(p822, p823, p824, p825)
	local v826 = p822.contexts[p823]
	local v827
	if v826 == nil or p824 then
		v826 = p822:createContext(p823)
		v827 = true
	else
		v827 = false
	end
	if p825 and p822.currentContextName ~= InputBinding.ROOT_CONTEXT_NAME then
		p822:deleteContext(p822.currentContextName)
	end
	if p822.debugEnabled then
		local v828 = Logging.devInfo
		local v829 = p822.currentContextName
		v828("[InputBinding] Set input context from [%s] to [%s], createNew=%s, deletePrevious=%s", tostring(v829), tostring(p823), tostring(p824 or false), (tostring(p825 or false)))
	end
	if p823 ~= p822.currentContextName then
		v826.previousContextName = p822.currentContextName
		p822.currentContextName = p823
	end
	p822:resetContinuousEventBindings(false)
	p822:resetBindingInputStates()
	p822.actionEvents = v826.actionEvents
	if v827 then
		registerGlobalActionEvents(p822)
	end
	p822:refreshEventCollections()
end
function InputBinding.revertContext(p830, p831)
	if p830.currentContextName == InputBinding.ROOT_CONTEXT_NAME then
		Logging.devWarning("Tried reverting input context when at root level.")
		return
	else
		local v832 = p830.contexts[p830.currentContextName].previousContextName
		local v833 = p830.contexts[v832]
		if v833 then
			if p831 then
				p830:deleteContext(p830.currentContextName)
			end
			if p830.debugEnabled then
				local v834 = Logging.devInfo
				local v835 = p830.currentContextName
				v834("[InputBinding] Reverting input context from [%s] to [%s], deleteCurrent=%s", tostring(v835), tostring(v832), (tostring(p831 or false)))
			end
			p830.currentContextName = v832
			p830.actionEvents = v833.actionEvents
			p830:refreshEventCollections()
			p830:resetBindingInputStates()
		else
			Logging.warning("Tried reverting to input context [%s] which is not defined. Current context [%s]", tostring(v832), p830.currentContextName)
			printCallstack()
		end
	end
end
function InputBinding.setPreviousContext(p836, p837, p838)
	local v839 = p836.contexts[p837]
	if v839 ~= nil and p836.contexts[p838] ~= nil then
		v839.previousContextName = p838
	end
end
function InputBinding.clearAllContexts(p840)
	for v841 in pairs(p840.contexts) do
		if v841 ~= InputBinding.ROOT_CONTEXT_NAME then
			p840:deleteContext(v841)
		end
	end
	if p840.debugEnabled then
		Logging.devInfo("[InputBinding] Cleared all contexts")
	end
	p840:setContext(InputBinding.ROOT_CONTEXT_NAME, false, false)
end
function InputBinding.getContextName(p842)
	return p842.currentContextName
end
function InputBinding.getActionBindingsCopy(p843, p844)
	local v845 = {}
	for _, v846 in ipairs(p843.actions) do
		if not p844 or p844 and not v846.isLocked then
			local v847 = v846:getBindings()
			local v848 = {}
			local v849 = {
				["action"] = v846:clone(),
				["bindings"] = v848
			}
			table.insert(v845, v849)
			for _, v850 in ipairs(v847) do
				table.insert(v848, v850:clone())
			end
		end
	end
	return v845
end
function InputBinding.getActionBindings(p851)
	local v852 = {}
	for _, v853 in pairs(p851.actions) do
		v852[v853] = v853:getActiveBindings()
	end
	return v852
end
function InputBinding.getEventsForActionName(p854, p855)
	local v856 = p854.nameActions[p855]
	if v856 ~= nil then
		local v857 = p854.actionEvents[v856]
		if v857 ~= nil then
			return { unpack(v857) }
		end
	end
	return InputBinding.NO_ACTION_EVENTS
end
function InputBinding.getFirstActiveEventForActionName(p858, p859)
	local v860 = p858.nameActions[p859]
	if v860 ~= nil then
		local v861 = p858.actionEvents[v860]
		if v861 ~= nil then
			for _, v862 in ipairs(v861) do
				if v862.isActive then
					return v862
				end
			end
		end
	end
	return InputEvent.NO_EVENT
end
function InputBinding.setMouseMotionScale(p863, p864)
	p863.mouseMotionScaleX = InputBinding.MOUSE_MOTION_SCALE_X_DEFAULT * p864
	p863.mouseMotionScaleY = InputBinding.MOUSE_MOTION_SCALE_Y_DEFAULT * p864
end
function InputBinding.getMouseMotionScale(p865)
	return p865.mouseMotionScaleX, p865.mouseMotionScaleY
end
function InputBinding.setEventChangeCallback(p866, p867)
	p866.eventChangeCallback = p867
end
function InputBinding.notifyBindingChanges(p868)
	p868.messageCenter:publish(MessageType.INPUT_BINDINGS_CHANGED, p868:getActionBindings())
end
function InputBinding.notifyEventChanges(p869)
	if p869.eventChangeCallback then
		p869.eventChangeCallback(p869.displayActionEvents)
	end
end
function InputBinding.notifyInputModeChange(p870, p871, p872)
	if not p870.isConsoleVersion then
		local v873 = MessageType.INPUT_MODE_CHANGED
		if p872 then
			v873 = MessageType.INPUT_HELP_MODE_CHANGED
		end
		p870.messageCenter:publish(v873, InputBinding.MESSAGE_PARAM_INPUT_MODE[p871])
	end
end
function InputBinding.checkSettingsIntegrity(_, p874, p875)
	local v876 = loadXMLFile("InputBindings1", p874)
	local v877 = getXMLRootName(v876)
	local v878 = not v877 or v877 == ""
	if v878 then
		Logging.error("User input bindings corrupted. Replacing with defaults...")
	end
	local v879 = loadXMLFile("InputBindings2", p875)
	local v880 = getXMLInt(v876, "inputBinding#version") or 1
	local v881 = getXMLInt(v879, "inputBinding#version") or 1
	delete(v876)
	delete(v879)
	local v882 = not v878
	if v882 then
		v882 = v880 == v881
	end
	return v882
end
function InputBinding.checkDefaultInputExclusiveActionBindings(p883)
	for v884, v885 in pairs(InputAction.EXCLUSIVE_ACTION_GROUPS) do
		for v886, v887 in ipairs(v885) do
			local v888 = p883.nameActions[v887]
			for v889 = v886 + 1, #v885 do
				local v890 = p883.nameActions[v885[v889]]
				for _, v891 in ipairs(v888.bindings) do
					for _, v892 in ipairs(v890.bindings) do
						local v893
						if v891.index == 1 then
							v893 = v892.index == 1
						else
							v893 = false
						end
						if v893 and v891.inputString == v892.inputString then
							Logging.devError("Currently loaded input bindings have conflicting primary bindings in action group \'%s\' for actions [%s] and [%s], both bound to [%s]", v884, v888.name, v890.name, v892.inputString)
						end
					end
				end
			end
		end
	end
end
function InputBinding.getBindingForceFeedbackInfo(_, p894)
	if p894 == nil then
		return false, nil, 0
	else
		local v895 = g_inputBinding:getDeviceById(p894.deviceId)
		local v896 = nil
		for v897 = 1, #p894.axisNames do
			v896 = Input.axisIdNameToId[p894.axisNames[v897]]
		end
		if v895 == nil or v896 == nil then
			return false, nil, 0
		else
			return v895:getIsForceFeedbackSupported(v896), v895, v896
		end
	end
end
function InputBinding.getNumActiveBindings(p898, p899)
	local v900 = p898.nameActions[p899]
	return v900 == nil and 0 or v900:getNumActiveBindings()
end
function InputBinding.setContextEventsActive(p901, p902, p903, p904)
	local v905 = p901.contexts[p902] or {}
	local v906 = p901.nameActions[p903]
	local v907 = v905.actionEvents[v906]
	for _, v908 in ipairs(v907) do
		p901:setEventActive(v908, p904)
	end
end
function InputBinding.getIsPhysicalFullAxis(p909)
	local v910 = InputBinding.MOUSE_AXES[p909] ~= nil
	local v911 = Input.axisIdNameToId[p909]
	if not v910 then
		if v911 == nil then
			v910 = false
		else
			v910 = not Input.isHalfAxis(v911)
		end
	end
	return v910
end
function InputBinding.getIsHalfAxis(p912)
	local v913 = Input.axisIdNameToId[p912]
	return Input.isHalfAxis(v913)
end
function InputBinding.getIsAnalogInput(p914)
	return InputBinding.MOUSE_AXES[p914] and true or false or (Input.axisIdNameToId[p914] and true or false)
end
function InputBinding.getIsKeyboardInput(p915)
	if not p915 or #p915 == 0 then
		return false
	end
	local v916 = true
	for _, v917 in pairs(p915) do
		if v916 then
			v916 = Input.keyIdToIdName[Input[v917]]
		end
	end
	return v916
end
function InputBinding.getIsMouseInput(p918)
	if not p918 or #p918 == 0 then
		return false
	end
	local v919 = true
	for _, v920 in pairs(p918) do
		if v919 then
			v919 = InputBinding.MOUSE_AXES[v920] or InputBinding.MOUSE_BUTTONS[v920]
		end
	end
	return v919
end
function InputBinding.getIsMouseWheelInput(p921)
	if not p921 or #p921 == 0 then
		return false
	end
	local v922 = InputBinding.MOUSE_BUTTONS[p921[1]] or ""
	return InputBinding.MOUSE_WHEEL[v922]
end
function InputBinding.getIsGamepadInput(p923)
	if not p923 or #p923 == 0 then
		return false
	end
	local v924 = true
	for _, v925 in pairs(p923) do
		if v924 then
			v924 = Input.axisIdNameToId[v925] ~= nil and true or Input.buttonIdNameToId[v925] ~= nil
		end
	end
	return v924
end
function InputBinding.getIsDPadInput(p926)
	if p926 and #p926 ~= 0 then
		local v927 = Input.buttonIdNameToId[p926[1]]
		if v927 == nil then
			return false
		else
			return InputBinding.GAMEPAD_DPAD[v927]
		end
	else
		return false
	end
end
function InputBinding.isAxisZero(p928)
	return p928 == nil and true or math.abs(p928) < 0.0001
end
function InputBinding.getDeviceCategory(p929)
	if p929 == InputBinding.KB_MOUSE_INTERNAL_ID then
		return InputDevice.CATEGORY.KEYBOARD_MOUSE
	else
		return getGamepadCategory(p929)
	end
end
function InputBinding.printAll(p930)
	for _, v931 in pairs(p930.actionEvents) do
		for v932 = #v931, 1, -1 do
			local v933 = v931[v932]
			log(nil, p930.currentContextName, "EventTable:", p930.actionEvents, v933)
		end
	end
	for _, v934 in pairs(p930.contexts) do
		for _, v935 in pairs(v934.actionEvents) do
			for v936 = #v935, 1, -1 do
				local v937 = v935[v936]
				log(v934, v934.name, "EventTable:", v934.actionEvents, v937)
			end
		end
	end
end
function InputBinding.debugPrintInputContext(p938, p939)
	local v940 = p939 or p938.currentContextName
	local v941 = p938.contexts[v940] or {}
	printf("Context [%s]: previousContextName=%s, eventOrderCounter=%s", v940, v941.previousContextName, v941.eventOrderCounter)
	for v942, v943 in pairs(v941.actionEvents) do
		printf("  Action %s", v942)
		printf("    Bindings:")
		for _, v944 in ipairs(v942:getBindings()) do
			printf("      %s", v944)
		end
		printf("    Events:")
		for _, v945 in ipairs(v943) do
			printf("      %s", v945)
		end
	end
end
function InputBinding.debugRenderRegisteredActions(p946)
	local v947 = {}
	local v948 = 0.01
	local v949 = 0.98
	for _, v950 in ipairs(p946.actions) do
		table.insert(v947, v950)
	end
	table.sort(v947, function(p951, p952)
		return p951.name < p952.name
	end)
	for _, v953 in ipairs(v947) do
		local v954 = v953:getBindings()
		local v955 = string.format("%s (%d Bindings)", v953.name, #v954)
		setTextBold(true)
		setTextColor(0, 0, 0, 1)
		renderText(v948, v949, 0.012, v955)
		setTextColor(1, 1, 1, 1)
		renderText(v948 + g_pixelSizeX, v949 + g_pixelSizeY, 0.012, string.format("%s (%d Bindings)", v953.name, #v954))
		v949 = v949 - 0.012 - 0.0005
		if v949 < 0 then
			v948 = v948 + 0.2
			v949 = 0.98
		end
	end
	setTextColor(1, 1, 1, 1)
end
function InputBinding.debugRenderInputContext(p956, p957)
	local v958 = p957 or p956.currentContextName
	local v959 = p956.contexts[v958] or {}
	setTextBold(false)
	setTextAlignment(RenderText.ALIGN_LEFT)
	renderText(0.01, 0.98, 0.015, string.format("Context [%s]: previousContextName=%s, eventOrderCounter=%s", v958, v959.previousContextName, v959.eventOrderCounter))
	p956.debugActionEvents = p956.debugActionEvents or {}
	table.clear(p956.debugActionEvents)
	local v960 = 0.96
	local v961 = 0.01
	local v962 = 1
	for v963, v964 in pairs(v959.actionEvents) do
		local v965 = p956.debugActionEvents
		table.insert(v965, { v963, v964 })
	end
	table.sort(p956.debugActionEvents, function(p966, p967)
		return p966[1].name < p967[1].name
	end)
	for _, v968 in ipairs(p956.debugActionEvents) do
		local v969 = v968[1]
		local v970 = v968[2]
		if v960 - (1 + #v969:getBindings() + #v970) * 0.013 < 0 then
			v960 = 0.96
			v961 = v961 + 0.35
			v962 = v962 + 1
			if v962 > 2 then
				new2DLayer()
			end
		end
		setTextColor(1, 0.3, 0.3, 1)
		renderText(v961, v960, 0.01, "Action " .. v969.name .. " (" .. tostring(v969) .. ")")
		local v971 = v960 - 0.013
		for _, v972 in ipairs(v969:getBindings()) do
			setTextColor(1, 1, 1, 1)
			if v972.isShadowed then
				setTextColor(1, 0, 0, 1)
			elseif v972.inputValue ~= 0 then
				setTextColor(0, 1, 0, 1)
			end
			local v973 = renderText
			local v974 = v961 + 0.005
			local v975 = v972.isActive
			v973(v974, v971, 0.01, "B: Active: " .. tostring(v975))
			local v976 = renderText
			local v977 = v961 + 0.05
			local v978 = v972.isShadowed
			v976(v977, v971, 0.01, "Shadowed: " .. tostring(v978))
			renderText(v961 + 0.105, v971, 0.01, "Value: " .. string.format("%.4f", v972.inputValue))
			local v979 = renderText
			local v980 = v961 + 0.16
			local v981 = table.concat(v972.axisNames, ", ")
			local v982 = v972.axisComponent
			local v983 = tostring(v982)
			local v984 = v972.deviceId
			local v985 = tostring(v984)
			local v986 = v972.index
			v979(v980, v971, 0.01, "[" .. v981 .. "] " .. v983 .. " | " .. v985 .. " | " .. tostring(v986))
			v971 = v971 - 0.011
		end
		setTextColor(1, 1, 1, 1)
		for _, v987 in ipairs(v970) do
			local v988 = renderText
			local v989 = v961 + 0.005
			local v990 = v987.isActive
			v988(v989, v971, 0.01, "E: Active: " .. tostring(v990))
			local v991 = renderText
			local v992 = v961 + 0.05
			local v993 = v987.displayIsVisible
			v991(v992, v971, 0.01, "Visible: " .. tostring(v993))
			local v994 = renderText
			local v995 = v961 + 0.105
			local v996 = v987.hasFrameTriggered
			v994(v995, v971, 0.01, "Triggered: " .. tostring(v996))
			local v997 = renderText
			local v998 = v961 + 0.16
			local v999 = v987.targetObject
			v997(v998, v971, 0.01, "Target: " .. tostring(v999))
			v971 = v971 - 0.011
		end
		v960 = v971 - 0.005
	end
end
function InputBinding.consoleCommandEnableInputDebug(p1000)
	p1000.debugEnabled = not p1000.debugEnabled
	local v1001 = p1000.debugEnabled
	return "InputBinding.debugEnabled = " .. tostring(v1001)
end
function InputBinding.consoleCommandPrintInputContext(p1002, _)
	p1002:debugPrintInputContext()
end
function InputBinding.consoleCommandShowInputContext(p1003, _)
	p1003.debugContextEnabled = not p1003.debugContextEnabled
end
function InputBinding.consoleCommandShowRegisteredActions(p1004, _)
	p1004.debugRegisteredActions = not p1004.debugRegisteredActions
end

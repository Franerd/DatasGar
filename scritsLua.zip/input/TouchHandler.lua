TouchHandler = {}
local v_u_1 = Class(TouchHandler)
TouchHandler.DRAW_DEBUG = false
TouchHandler.TRIGGER_DOWN = 1
TouchHandler.TRIGGER_ALWAYS = 2
TouchHandler.TRIGGER_UP = 3
TouchHandler.GESTURE_AXIS_X = 1
TouchHandler.GESTURE_AXIS_Y = 2
TouchHandler.GESTURE_DOUBLE_TAP = 3
TouchHandler.GESTURE_PINCH = 4
TouchHandler.DOUBLE_TAP_TIME = 250
TouchHandler.MOUSE_TOUCH_ID = -1
function TouchHandler.new()
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3.areas = {}
	v3.gestureListener = {}
	v3.pinchGesture = {}
	v3.toTrigger = {}
	v3.lastDownTime = 0
	v3.lastUpTime = 0
	local v4, v5 = getNormalizedScreenValues(1.5, 1.5)
	v3.debugLineWidth = v4
	v3.debugLineHeight = v5
	local v6, v7 = getNormalizedScreenValues(3, 3)
	v3.debugPointWidth = v6
	v3.debugPointHeight = v7
	v3.debugPoints = {}
	v3.contextName = nil
	v3.isActiveOnTopOfGUI = false
	return v3
end
function TouchHandler.onTouchEvent(p8, p9, p10, p11, p12, p13)
	if TouchHandler.DRAW_DEBUG and p11 then
		p8:addDebugPoint(p9, p10)
	end
	local v14 = p8.toTrigger
	local v15 = false
	for v16 = 1, #p8.areas do
		local v17 = p8.areas[v16]
		if v17.lastTouchId == nil or v17.lastTouchId == p13 then
			p8:updateAreaPosition(v17)
			local v18, v19, v20, v21 = p8:getAreaDimensions(v17)
			local v22
			if v18 < p9 and (p9 < v18 + v20 and v19 < p10) then
				v22 = p10 < v19 + v21
			else
				v22 = false
			end
			local v23 = false
			local v24 = false
			local v25 = false
			if v22 and (v17.visibility and (v17.contextName == p8.contextName and (p8.isActiveOnTopOfGUI or not g_gui:getIsGuiVisible()))) then
				if p12 then
					if v17.isPressed then
						v17.isPressed = false
						v17.lastTouchId = nil
						v25 = true
					end
				elseif p11 then
					v17.isPressed = true
					v17.lastTouchId = p13
					v23 = true
				elseif v17.isPressed then
					v24 = true
				end
				local v26 = v17.lastTouchPosition
				local v27 = v17.lastTouchPosition
				v26[1] = p9
				v27[2] = p10
				v15 = true
			elseif v17.isPressed then
				v17.isPressed = false
				v17.lastTouchId = nil
				v17.isCancel = true
				v25 = true
			end
			if v23 and v17.triggerType == TouchHandler.TRIGGER_DOWN or (v24 and v17.triggerType == TouchHandler.TRIGGER_ALWAYS or v25 and v17.triggerType == TouchHandler.TRIGGER_UP) then
				v14[#v14 + 1] = v17
			end
		end
	end
	for v28 = 1, #v14 do
		p8:raiseCallback(v14[v28], p9, p10)
		v14[v28].isCancel = false
		v14[v28] = nil
	end
	if v15 then
		p8:onPinchUpEvent(p13)
	else
		if p11 then
			p8.lastPositionX = p9
			p8.lastPositionY = p10
			p8.lastDownTime = g_time
		elseif p12 then
			p8.lastPositionX = nil
			p8.lastPositionY = nil
			if p8.lastUpTime ~= nil and (p8.lastDownTime > p8.lastUpTime and g_time - p8.lastUpTime < TouchHandler.DOUBLE_TAP_TIME) then
				p8:raiseGestureEvent(TouchHandler.GESTURE_DOUBLE_TAP)
			end
			p8.lastUpTime = g_time
			p8.lastUpId = p13
		end
		local v29 = false
		if p11 then
			p8:onPinchDownEvent(p13)
		elseif p12 then
			p8:onPinchUpEvent(p13)
		else
			v29 = p8:onPinchUpdateEvent(p9, p10, p13)
		end
		if v29 then
			p8.lastPositionX = nil
			p8.lastPositionY = nil
			return
		end
		if p8.lastPositionX ~= nil then
			local v30 = p9 - p8.lastPositionX
			p8:raiseGestureEvent(TouchHandler.GESTURE_AXIS_X, v30)
			p8.lastPositionX = p9
		end
		if p8.lastPositionY ~= nil then
			local v31 = p10 - p8.lastPositionY
			p8:raiseGestureEvent(TouchHandler.GESTURE_AXIS_Y, v31)
			p8.lastPositionY = p10
			return
		end
	end
end
function TouchHandler.onPinchDownEvent(p32, p33)
	if p32.lastPositionId ~= nil and p32.lastPositionId ~= p33 then
		p32.pinchGesture[1] = {
			["touchId"] = p33
		}
		p32.pinchGesture[2] = {
			["touchId"] = p32.lastPositionId
		}
	end
	p32.lastPositionId = p33
end
function TouchHandler.onPinchUpdateEvent(p34, p35, p36, p37)
	local v38 = p34.pinchGesture[1]
	local v39 = p34.pinchGesture[2]
	if v38 == nil or v39 == nil then
		return false
	end
	if v38.touchId == p37 and (v38.lastX ~= nil and v39.lastX ~= nil) then
		local v40 = MathUtil.vector2Length(v38.lastX - v39.lastX, v38.lastY - v39.lastY)
		local v41 = (v38.lastDistance or v40) - v40
		local v42 = v39.lastX + (v38.lastX - v39.lastX) * 0.5
		local v43 = v39.lastY + (v38.lastY - v39.lastY) * 0.5
		p34:raiseGestureEvent(TouchHandler.GESTURE_PINCH, v41, v42, v43, v40)
		v38.lastDistance = v40
	end
	if v38.touchId == p37 then
		v39 = v38 or v39
	end
	v39.lastX = p35
	v39.lastY = p36
	return true
end
function TouchHandler.onPinchUpEvent(p44, p45)
	for v46 = 1, 2 do
		if p44.pinchGesture[v46] == nil then
			p44.lastPositionId = nil
		elseif p44.pinchGesture[v46].touchId == p45 then
			if v46 == 1 then
				p44.lastPositionId = p44.pinchGesture[2].touchId
			else
				p44.lastPositionId = p44.pinchGesture[1].touchId
			end
			p44.pinchGesture[1] = nil
			p44.pinchGesture[2] = nil
			return
		end
	end
end
function TouchHandler.registerGestureListener(p47, p48, p49, p50)
	local v51 = {
		["gestureType"] = p48,
		["callback"] = p49,
		["callbackTarget"] = p50,
		["contextName"] = p47.contextName
	}
	local v52 = p47.gestureListener
	table.insert(v52, v51)
	return v51
end
function TouchHandler.removeGestureListener(p53, p54)
	table.removeElement(p53.gestureListener, p54)
end
function TouchHandler.raiseGestureEvent(p55, p56, ...)
	for _, v57 in ipairs(p55.gestureListener) do
		if v57.contextName == p55.contextName and v57.gestureType == p56 then
			v57.callback(v57.callbackTarget, ...)
		end
	end
end
function TouchHandler.registerTouchArea(p58, p59, p60, p61, p62, p63, p64, p65, p66, p67, p68)
	local v69 = {
		["posX"] = p59,
		["posY"] = p60,
		["sizeX"] = p61,
		["sizeY"] = p62,
		["areaOffsetX"] = p63
	}
	if type(p63) == "number" then
		v69.areaOffsetX = { p63 / 2, p63 / 2 }
	end
	v69.areaOffsetY = p64
	if type(p64) == "number" then
		v69.areaOffsetY = { p64 / 2, p64 / 2 }
	end
	v69.isPressedSizeGain = 1
	v69.isPressedSizeGained = v69.isPressedSizeGain - 1
	v69.absoluteDimensions = {
		0,
		0,
		0,
		0
	}
	v69.absoluteDimensionsPressed = {
		0,
		0,
		0,
		0
	}
	p58:updateDimensions(v69)
	v69.visibility = true
	v69.isPressed = false
	v69.lastTouchPosition = { p59 + p61 * 0.5, p60 + p62 * 0.5 }
	v69.triggerType = p65
	v69.callback = p66
	v69.callbackTarget = p67
	v69.extraArguments = p68 or {}
	v69.contextName = p58.contextName
	local v70 = p58.areas
	table.insert(v70, v69)
	return v69
end
function TouchHandler.registerTouchAreaOverlay(p71, p72, p73, p74, p75, p76, p77, p78)
	local v79 = p71:registerTouchArea(p72.x, p72.y, p72.width, p72.height, p73, p74, p75, p76, p77, p78)
	v79.overlay = p72
	return v79
end
function TouchHandler.resetPendingTouchAreaInput(p80, p81)
	if p81.triggerType == TouchHandler.TRIGGER_UP and p81.isPressed then
		p80:raiseCallback(p81, p81.lastTouchPosition[1], p81.lastTouchPosition[2])
		p81.isPressed = false
		p81.lastTouchId = nil
	end
end
function TouchHandler.removeTouchArea(p82, p83)
	p82:resetPendingTouchAreaInput(p83)
	table.removeElement(p82.areas, p83)
end
function TouchHandler.setCustomContext(p84, p85, p86)
	if p85 ~= p84.contextName then
		for v87 = 1, #p84.areas do
			if p84.areas[v87].contextName == p84.contextName then
				p84:resetPendingTouchAreaInput(p84.areas[v87])
			end
		end
	end
	p84.contextName = p85
	p84.isActiveOnTopOfGUI = Utils.getNoNil(p86, false)
end
function TouchHandler.revertCustomContext(p88)
	p88:setCustomContext(nil, false)
end
function TouchHandler.getAreaDimensions(_, p89, p90)
	if p90 == nil then
		p90 = p89.isPressed
	end
	if p90 then
		local v91 = p89.absoluteDimensionsPressed
		return unpack(v91)
	else
		local v92 = p89.absoluteDimensions
		return unpack(v92)
	end
end
function TouchHandler.removeAllTouchAreas(p93)
	p93.areas = {}
end
function TouchHandler.setAreaPosition(p94, p95, p96, p97, p98, p99)
	p95.posX = p96
	p95.posY = p97
	p95.sizeX = p98
	p95.sizeY = p99
	p94:updateDimensions(p95)
end
function TouchHandler.setAreaPressedSizeGain(p100, p101, p102)
	p101.isPressedSizeGain = p102
	p101.isPressedSizeGained = p102 - 1
	p100:updateDimensions(p101)
end
function TouchHandler.updateDimensions(_, p103)
	local v104 = p103.posX - p103.areaOffsetX[1] * p103.sizeX
	local v105 = p103.posY - p103.areaOffsetY[1] * p103.sizeY
	local v106 = p103.sizeX + (p103.sizeX * p103.areaOffsetX[1] + p103.sizeX * p103.areaOffsetX[2])
	local v107 = p103.sizeY + (p103.sizeY * p103.areaOffsetY[1] + p103.sizeY * p103.areaOffsetY[2])
	p103.absoluteDimensions[1] = v104
	p103.absoluteDimensions[2] = v105
	p103.absoluteDimensions[3] = v106
	p103.absoluteDimensions[4] = v107
	local v108 = v106 * p103.isPressedSizeGained * 0.5
	local v109 = v107 * p103.isPressedSizeGained * 0.5 * g_screenAspectRatio
	local v110 = math.min(v108, v109)
	local v111 = v106 * p103.isPressedSizeGain - v106
	local v112 = (v107 * p103.isPressedSizeGain - v107) * g_screenAspectRatio
	local v113 = math.min(v111, v112)
	p103.absoluteDimensionsPressed[1] = v104 - v110 / g_screenAspectRatio
	p103.absoluteDimensionsPressed[2] = v105 - v110
	p103.absoluteDimensionsPressed[3] = v106 + v113 / g_screenAspectRatio
	p103.absoluteDimensionsPressed[4] = v107 + v113
end
function TouchHandler.updateAreaPosition(p114, p115)
	if p115.overlay ~= nil then
		local v116 = p115.overlay
		p114:setAreaPosition(p115, v116.x, v116.y, v116.width, v116.height)
	end
end
function TouchHandler.setTouchAreaVisibility(_, p117, p118)
	p117.visibility = p118
end
function TouchHandler.raiseCallback(_, p119, p120, p121)
	local v122 = p119.callback
	local v123 = p119.callbackTarget
	local v124 = p119.isCancel
	local v125 = p119.extraArguments
	v122(v123, p120, p121, v124, unpack(v125))
end
function TouchHandler.update(p126, p127)
	if TouchHandler.DRAW_DEBUG then
		for v128, v129 in pairs(p126.debugPoints) do
			v129.time = v129.time - p127
			if v129.time < 0 then
				table.remove(p126.debugPoints, v128)
			end
		end
	end
end
function TouchHandler.draw(p130)
	if TouchHandler.DRAW_DEBUG then
		if not g_gui:getIsGuiVisible() then
			for v131 = 1, #p130.areas do
				local v132 = p130.areas[v131]
				if v132.visibility and v132.contextName == p130.contextName then
					local v133, v134, v135, v136 = p130:getAreaDimensions(v132, false)
					drawOutlineRect(v133, v134, v135, v136, p130.debugLineWidth, p130.debugLineHeight, 1, 0, 0, 1)
					if v132.isPressed then
						local v137, v138, v139, v140 = p130:getAreaDimensions(v132, true)
						drawOutlineRect(v137, v138, v139, v140, p130.debugLineWidth, p130.debugLineHeight, 0, 1, 0, 1)
					end
				end
			end
		end
		for _, v141 in pairs(p130.debugPoints) do
			drawPoint(v141.x, v141.y, p130.debugPointWidth, p130.debugPointHeight, 0, 1, 0, 1)
		end
	end
end
function TouchHandler.addDebugPoint(p142, p143, p144)
	local v145 = p142.debugPoints
	table.insert(v145, {
		["time"] = 5000,
		["x"] = p143,
		["y"] = p144
	})
end

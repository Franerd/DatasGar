DisplayActionBinding = {}
local v_u_1 = Class(DisplayActionBinding)
function DisplayActionBinding.new(p2, p3, p4, _)
	-- upvalues: (copy) v_u_1
	local v5 = v_u_1
	local v6 = setmetatable({}, v5)
	v6.action = p2
	v6.displayName = p3
	v6.isPositive = p4
	v6.columnTexts = {}
	v6.columnBindings = {}
	return v6
end
function DisplayActionBinding.setBindingDisplay(p7, p8, p9, p10)
	p7.columnTexts[p10] = p9
	p7.columnBindings[p10] = p8
end
function DisplayActionBinding.toString(p11)
	local v12 = ""
	for v13, v14 in pairs(p11.columnBindings) do
		v12 = v12 .. "(" .. tostring(v13) .. ": " .. tostring(v14) .. ")"
	end
	local v15 = string.format
	local v16 = p11.displayName
	local v17 = tostring(v16)
	local v18 = p11.action
	local v19 = tostring(v18)
	local v20 = p11.isPositive
	return v15("[DisplayActionBinding: displayName=%s, action=%s, isPositive=%s, columnTexts=%s, columnBindings=%s]", v17, v19, tostring(v20), table.concat(p11.columnTexts, "|"), v12)
end
v_u_1.__tostring = DisplayActionBinding.toString

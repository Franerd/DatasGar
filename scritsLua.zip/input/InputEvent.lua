InputEvent = {}
local v_u_1 = Class(InputEvent)
function InputEvent.new(p2, p3, p4, p5, p6, p7, p8, p9, p10)
	-- upvalues: (copy) v_u_1
	local v11 = v_u_1
	local v12 = setmetatable({}, v11)
	v12.actionName = p2
	v12.targetObject = p3
	v12.callback = p4
	v12.triggerDown = p6
	v12.triggerUp = p5
	v12.triggerAlways = p7
	v12.callbackState = p9
	v12.orderValue = p10
	v12.id = v12:makeId()
	v12.ignoreComboMask = false
	v12.isActive = p8
	v12.contextDisplayText = nil
	v12.contextDisplayIconName = nil
	v12.displayIsVisible = true
	v12.displayPriority = GS_PRIO_VERY_LOW
	v12.hasFrameTriggered = false
	return v12
end
function InputEvent.setIgnoreComboMask(p13, p14)
	p13.ignoreComboMask = p14
end
function InputEvent.getIgnoreComboMask(p15)
	return p15.ignoreComboMask
end
function InputEvent.notifyInput(p16, p17, p18)
	local v19 = p16.triggerUp and p17.isUpFlank
	if v19 then
		v19 = p17.recievedDownFlankInCurrentContext
	end
	local v20 = p16.triggerDown and (p17.isDownFlank and not p16.triggerAlways)
	if v20 then
		v20 = not p17.enteredNewContextThisFrame
	end
	local v21 = p16.triggerDown and (p16.triggerAlways and p17.isPressed)
	if v21 then
		v21 = p17.recievedDownFlankInCurrentContext
	end
	local v22 = not p16.triggerDown
	if v22 then
		v22 = p16.triggerAlways
	end
	if not p16.hasFrameTriggered and (v19 or (v20 or (v21 or v22))) then
		p16.hasFrameTriggered = true
		p17:setFrameTriggered(not v22)
		p16.callback(p16.targetObject, p16.actionName, p17.inputValue, p16.callbackState, p17.isAnalog, p17.isMouse, p17.deviceCategory, p17, p18)
	end
end
function InputEvent.frameReset(p23)
	p23.hasFrameTriggered = false
end
function InputEvent.makeId(p24)
	local v25 = string.format
	local v26 = p24.actionName
	local v27 = tostring(v26)
	local v28 = p24.targetObject
	return v25("%s|%s|%d", v27, tostring(v28), p24:getTriggerCode())
end
function InputEvent.getTriggerCode(p29)
	local v30 = p29.triggerDown and 1 or 0
	local v31 = p29.triggerUp and 2 or 0
	local v32 = p29.triggerAlways and 4 or 0
	return v30 + v31 + v32
end
function InputEvent.initializeDisplayText(p33, p34)
	p33.contextDisplayText = p34.displayNamePositive
end
function InputEvent.toString(p35)
	return string.format("[%s: target=%s, triggerUp=%s, triggerDown=%s, triggerAlways=%s, isActive=%s, isVisible=%s, hasFrameTriggered=%s]", p35.actionName, p35.targetObject, p35.triggerUp, p35.triggerDown, p35.triggerAlways, p35.isActive, p35.displayIsVisible, p35.hasFrameTriggered)
end
v_u_1.__tostring = InputEvent.toString
InputEvent.NO_EVENT = InputEvent.new("", {}, function() end, false, false, false, false, 0, 0)

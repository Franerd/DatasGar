MouseHelper = {}
KeyboardHelper = {}
GamepadHelper = {}
function MouseHelper.getButtonName(p1)
	return getMouseButtonName(p1)
end
function MouseHelper.getButtonNames(p2)
	local v3 = ""
	for v4, v5 in ipairs(p2) do
		local v6 = getMouseButtonName(v5)
		if v6 then
			if v4 ~= 1 then
				v3 = v3 .. " "
			end
			v3 = v3 .. v6
		end
	end
	return v3
end
function MouseHelper.getInputDisplayText(p7)
	local v8 = {}
	for _, v9 in ipairs(p7) do
		local v10 = InputBinding.MOUSE_AXES[v9]
		if v10 then
			local v11 = v10 == Input.AXIS_Y and "Y" or "X"
			table.insert(v8, v11)
		else
			local v12 = InputBinding.MOUSE_BUTTONS[v9]
			if v12 then
				local v13 = getMouseButtonName
				table.insert(v8, v13(v12))
			end
		end
	end
	return table.concat(v8, ", ")
end
function MouseHelper.getButtonsXMLString(p14)
	local v15 = ""
	for v16, v17 in ipairs(p14) do
		local v18 = Input.mouseButtonIdToIdName[v17]
		if v18 ~= nil then
			if v16 ~= 1 then
				v15 = v15 .. " "
			end
			v15 = v15 .. v18
		end
	end
	return v15
end
KeyboardHelper.KEY_GLYPHS = {
	[13] = "keyGlyph_return",
	[271] = "keyGlyph_enter",
	[8] = "keyGlyph_backspace",
	[27] = "keyGlyph_escape",
	[32] = "keyGlyph_space",
	[273] = "keyGlyph_up",
	[274] = "keyGlyph_down",
	[275] = "keyGlyph_right",
	[276] = "keyGlyph_left",
	[306] = "keyGlyph_ctrl",
	[308] = "keyGlyph_alt"
}
function KeyboardHelper.getDisplayKeyName(p19)
	local v20 = KeyboardHelper.KEY_GLYPHS[p19]
	local v21
	if v20 == nil then
		v21 = nil
	else
		v21 = g_i18n:getText(v20)
	end
	if v21 == nil then
		v21 = getKeyName(p19)
	end
	return v21
end
function KeyboardHelper.getKeyNames(p22)
	local v23 = ""
	for v24, v25 in ipairs(p22) do
		if v24 ~= 1 then
			v23 = v23 .. " "
		end
		v23 = v23 .. KeyboardHelper.getDisplayKeyName(v25)
	end
	return v23
end
function KeyboardHelper.getKeyNameTable(p26)
	local v27 = {}
	for _, v28 in ipairs(p26) do
		local v29 = KeyboardHelper.getDisplayKeyName
		table.insert(v27, v29(v28))
	end
	return v27
end
function KeyboardHelper.getInputDisplayText(p30)
	local v31 = {}
	for _, v32 in ipairs(p30) do
		local v33 = Input[v32]
		local v34 = KeyboardHelper.getDisplayKeyName
		table.insert(v31, v34(v33))
	end
	return table.concat(v31, ", ")
end
function KeyboardHelper.getKeysXMLString(p35)
	if p35 == nil or p35 == -1 then
		return ""
	end
	local v36 = ""
	for v37, v38 in ipairs(p35) do
		local v39 = Input.keyIdToIdName[v38]
		if v39 ~= nil then
			if v37 ~= 1 then
				v36 = v36 .. " "
			end
			v36 = v36 .. v39
		end
	end
	return v36
end
function GamepadHelper.getGamepadInputCombinedName(p40)
	local v41 = {}
	local v42 = {}
	for v43, v44 in pairs(p40) do
		table.insert(v41, v43)
		v42[v43] = {}
		v42[v43].buttonsList = {}
		v42[v43].axesList = {}
		for v45, _ in pairs(v44.buttons) do
			local v46 = v42[v43].buttonsList
			table.insert(v46, v45)
		end
		for v47, _ in pairs(v44.axes) do
			local v48 = v42[v43].axesList
			table.insert(v48, v47)
		end
		table.sort(v42[v43].buttonsList)
		table.sort(v42[v43].axesList)
	end
	table.sort(v41)
	local v49 = ""
	local v50 = ""
	for _, v51 in ipairs(v41) do
		for v52, v53 in ipairs(v42[v51].buttonsList) do
			v49 = v49 .. (v52 == 1 and "" or ", ") .. GamepadHelper.getButtonName(v53, v51)
		end
		for v54, v55 in ipairs(v42[v51].axesList) do
			v50 = v50 .. (v54 == 1 and "" or ", ") .. GamepadHelper.getAxisName(v55, v51)
		end
	end
	return (v49 == "" and "" or (g_i18n:getText("ui_button") .. " " .. v49 .. " " or "")) .. (v50 == "" and "" or (g_i18n:getText("ui_axis") .. " " .. v50 or ""))
end
function GamepadHelper.getButtonName(p56, p57)
	if p56 == nil then
		return ""
	end
	local v58 = p57 == nil and 0 or p57
	return getGamepadButtonLabel(p56, v58)
end
function GamepadHelper.getAxisName(p59, p60)
	return p59 == nil and "" or getGamepadAxisLabel(p59, p60)
end
function GamepadHelper.getButtonNames(p61, p62)
	if p61 == nil then
		return ""
	end
	local v63 = #p61
	local v64 = ""
	for v65, v66 in ipairs(p61) do
		local v67 = GamepadHelper.getButtonName(v66, (v65 == v63 or not p62) and 0 or p62)
		v64 = v64 .. (v65 == 1 and "" or " ") .. v67
	end
	local v68 = ""
	if v63 == 1 then
		v68 = g_i18n:getText("ui_button") .. " "
	elseif v63 > 1 then
		v68 = g_i18n:getText("ui_buttons") .. " "
	end
	return v68 .. v64
end
function GamepadHelper.getButtonAndAxisNames(p69, p70, p71)
	local v72 = GamepadHelper.getButtonNames(p69)
	local v73 = GamepadHelper.getAxisName(p70, p71)
	local v74 = "(\'" .. GamepadHelper.getLocalizedGamepadName(p71) .. "\' " .. GamepadHelper.getDeviceString(p71) .. ")"
	return v72 .. ((v72 == "" or v73 == "") and "" or ", ") .. ((v73 == "" or not v73) and "" or v73) .. (v72 == "" and v73 == "" and "" or (" " .. v74 or ""))
end
function GamepadHelper.getLocalizedGamepadName(p75)
	local v76 = getGamepadName(p75)
	if g_i18n:hasText(v76) then
		v76 = g_i18n:getText(v76)
	end
	return v76
end
function GamepadHelper.getInputDisplayText(p77, p78)
	local v79 = {}
	for _, v80 in ipairs(p77) do
		if Input.buttonIdNameToId[v80] then
			local v81 = Input.buttonIdNameToId[v80]
			local v82 = GamepadHelper.getButtonName
			table.insert(v79, v82(v81, p78))
		elseif Input.axisIdNameToId[v80] then
			local v83 = Input.axisIdNameToId[v80]
			local v84 = GamepadHelper.getAxisName
			table.insert(v79, v84(v83, p78))
		end
	end
	local v85 = GamepadHelper.getLocalizedGamepadName(p78)
	return string.format("%s [%s]", table.concat(v79, ", "), v85)
end
function GamepadHelper.getDeviceString(p86)
	return "[" .. p86 + 1 .. "]"
end
function GamepadHelper.getButtonsXMLString(p87)
	if p87 == nil then
		return ""
	end
	local v88 = ""
	for v89, v90 in ipairs(p87) do
		v88 = v88 .. (v89 == 1 and "" or " ") .. "BUTTON" .. "_" .. v90 + 1
	end
	return v88
end
function GamepadHelper.getAxisXMLString(p91)
	return (p91 == nil or p91 == -1) and "" or "AXIS_" .. p91 + 1
end
function GamepadHelper.getDeviceXMLInt(p92)
	return (p92 == nil or p92 == -1) and 0 or p92
end

RestartManager = {}
RestartManager.START_SCREEN_MAIN = 1
RestartManager.START_SCREEN_JOIN_GAME = 2
RestartManager.START_SCREEN_MULTIPLAYER = 3
RestartManager.START_SCREEN_SETTINGS = 5
RestartManager.START_SCREEN_SETTINGS_ADVANCED = 6
RestartManager.START_SCREEN_GAMEPAD_SIGNIN = 7
function RestartManager.init(p1, p2)
	p1.restarting = string.find(p2, "-restart") ~= nil
end
function RestartManager.handleRestart(p3)
	local v4 = getStartMode()
	if v4 == RestartManager.START_SCREEN_MAIN then
		g_gui:showGui("MainScreen")
	elseif v4 == RestartManager.START_SCREEN_JOIN_GAME then
		g_multiplayerScreen:onJoinGameClick()
	elseif v4 == RestartManager.START_SCREEN_MULTIPLAYER then
		g_gui:showGui("MainScreen")
		g_mainScreen:onMultiplayerClickPerform()
	elseif v4 == RestartManager.START_SCREEN_SETTINGS then
		g_gui:showGui("SettingsScreen")
		g_settingsScreen:showGeneralSettings()
	elseif v4 == RestartManager.START_SCREEN_SETTINGS_ADVANCED then
		g_gui:showGui("SettingsScreen")
		g_settingsScreen:showDisplaySettings()
	elseif v4 == RestartManager.START_SCREEN_GAMEPAD_SIGNIN then
		g_gui:showGui("GamepadSigninScreen")
	end
	if promptUserConfirmScreenMode() then
		p3.restartDisplayTime = 15000
		local v5 = YesNoDialog.show
		local v6 = p3.restartDisplayOk
		local v7 = g_i18n:getText("dialog_keepDisplayProperties")
		local v8 = p3.restartDisplayTime / 1000
		p3.dialog = v5(v6, p3, v7 .. "\n" .. tostring(v8))
		p3.restartDisplayTimerId = addTimer(1000, "restartDisplayTimeUpdate", p3)
	end
end
function RestartManager.setStartScreen(_, p9)
	setStartMode(p9)
end
function RestartManager.restartDisplayTimeUpdate(p10)
	p10.restartDisplayTime = p10.restartDisplayTime - 1000
	if p10.restartDisplayTime <= 0 then
		p10.restartDisplayTime = nil
		p10.restartDisplayTimerId = nil
		p10:restartDisplayNotOk()
		return false
	end
	local v11 = p10.dialog
	local v12 = g_i18n:getText("dialog_keepDisplayProperties")
	local v13 = p10.restartDisplayTime / 1000
	v11:setText(v12 .. "\n" .. tostring(v13))
	setTimerTime(p10.restartDisplayTimerId, 1000)
	return true
end
function RestartManager.restartDisplayOk(p14, p15)
	removeTimer(p14.restartDisplayTimerId)
	p14.restartDisplayTime = nil
	p14.restartDisplayTimerId = nil
	if p15 then
		setUserConfirmScreenMode(true)
	else
		p14:restartDisplayNotOk()
	end
end
function RestartManager.restartDisplayNotOk(_)
	setUserConfirmScreenMode(false)
	doRestart(true, "")
end

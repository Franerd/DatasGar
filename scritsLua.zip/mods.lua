g_modDescSchema = nil
g_uniqueDlcNamePrefix = "pdlc_"
g_modEventListeners = {}
g_dlcsDirectories = {}
g_forceNeedsDlcsAndModsReload = false
g_lastCheckDlcPaths = {}
g_modIsLoaded = {}
g_globalMods = {}
g_modNameToDirectory = {}
local v_u_1 = false
g_dlcModNameHasPrefix = {}
g_internalModsDirectory = "internalMods/"
local v_u_2 = {}
local v_u_3 = {}
local v_u_4 = {}
modOnCreate = {}
function loadDlcs()
	storeHaveDlcsChanged()
	local v5 = {}
	for v6 = 1, #g_dlcsDirectories do
		local v7 = g_dlcsDirectories[v6]
		if v7.isLoaded then
			loadDlcsFromDirectory(v7.path, v5)
		end
	end
end
function loadDlcsFromDirectory(p8, _)
	local v9 = getAppBasePath()
	if isAbsolutePath(p8) and (v9:len() == 0 or not string.startsWith(p8, v9)) then
		createFolder(p8)
	end
	local v10 = Files.new(p8)
	for _, v11 in pairs(v10.files) do
		local v12 = false
		local v13 = nil
		local v14 = nil
		local v15 = nil
		if v11.isDirectory then
			if g_isDevelopmentVersion or not GS_PLATFORM_PC then
				v14 = v11.filename
				v15 = "dlcDesc.xml"
				v12 = true
				if not GS_PLATFORM_PC then
					v13 = getFileMD5(p8 .. v11.filename, v14)
				end
				if v13 == nil and g_isDevelopmentVersion then
					v13 = getMD5("Dev_" .. v11.filename)
				end
			end
		else
			local v16 = v11.filename:len()
			if v16 > 4 then
				local v17 = v11.filename:sub(v16 - 3)
				if v17 == ".dlc" then
					v14 = v11.filename:sub(1, v16 - 4)
					v13 = getFileMD5(p8 .. v11.filename, v14)
					v15 = "dlcDesc.xml"
					v12 = true
				elseif v17 == ".zip" or v17 == ".gar" then
					v14 = v11.filename:sub(1, v16 - 4)
					v13 = getFileMD5(p8 .. v11.filename, v14)
					v15 = "modDesc.xml"
					v12 = false
				end
			end
		end
		if v14 ~= nil and (v15 ~= nil and g_dlcModNameHasPrefix[v14] == nil) then
			local v18 = p8 .. v14 .. "/"
			local v19 = v18 .. v15
			g_dlcModNameHasPrefix[v14] = v12
			loadModDesc(v14, v18, v19, v13, p8 .. v11.filename, v11.isDirectory, v12, false)
		end
	end
end
function loadMods()
	haveModsChanged()
	local v20 = g_modsDirectory
	g_showIllegalActivityInfo = false
	g_modDescSchema = g_modDescSchema or createModDescSchema()
	local v21 = Files.new(v20)
	local v22 = {}
	for _, v23 in pairs(v21.files) do
		local v24 = nil
		local v25 = nil
		if v23.isDirectory then
			v25 = v23.filename
			if g_isDevelopmentVersion then
				v24 = getMD5("DevMod_" .. v23.filename)
			end
		else
			local v26 = v23.filename:len()
			if v26 > 4 then
				local v27 = v23.filename:sub(v26 - 3)
				if v27 == ".zip" or v27 == ".gar" then
					v25 = v23.filename:sub(1, v26 - 4)
					v24 = getFileMD5(v20 .. v23.filename, v25)
				end
			end
		end
		if v25 ~= nil then
			local v28 = v20 .. v25 .. "/"
			local v29 = v28 .. "modDesc.xml"
			if v22[v29] == nil then
				loadModDesc(v25, v28, v29, v24, v20 .. v23.filename, v23.isDirectory, false, false)
				v22[v29] = true
			end
		end
	end
	if g_showIllegalActivityInfo then
		print("Info: This game protects you from illegal activity")
	end
	g_showIllegalActivityInfo = nil
end
function loadInternalMods()
	-- upvalues: (copy) v_u_2
	haveModsChanged()
	for _, v30 in pairs(v_u_2) do
		local v31 = v30.name
		local v32 = g_internalModsDirectory .. v31 .. "/"
		local v33 = v32 .. "modDesc.xml"
		local v34 = nil
		local v35 = g_internalModsDirectory .. v31 .. ".gar"
		if fileExists(v35) then
			v34 = getFileMD5(v35, v31)
		elseif (g_isDevelopmentVersion or GS_IS_CONSOLE_VERSION) and fileExists(v33) then
			v34 = getFileMD5(v33, v31)
		end
		if v34 ~= nil then
			loadModDesc(v31, v32, v33, v34, g_internalModsDirectory .. v31, true, false, true)
		end
	end
end
function postInitMods()
	for _, v36 in pairs(g_modEventListeners) do
		if v36.onPostInit ~= nil then
			v36:onPostInit()
		end
	end
end
local function v_u_38(p37)
	if p37:len() == 0 then
		return false
	elseif string.startsWith(p37, g_uniqueDlcNamePrefix) then
		return false
	elseif p37:find("%d") == 1 then
		return false
	else
		return p37:find("[^%w_]") == nil
	end
end
local function v_u_42(p39)
	-- upvalues: (copy) v_u_3
	for v40 = 1, #v_u_3 do
		local v41 = v_u_3[v40]
		if p39 == v41 or p39 == v41 .. "_update" then
			return true
		end
	end
	return false
end
local function v_u_46(p43)
	-- upvalues: (copy) v_u_2
	for _, v44 in ipairs(v_u_2) do
		local v45 = v44.name
		if p43 == v45 or p43 == v45 .. "_update" then
			return true
		end
	end
	return false
end
local function v_u_50(p47)
	-- upvalues: (copy) v_u_2
	for _, v48 in ipairs(v_u_2) do
		local v49 = v48.name
		if p47 == v49 or p47 == v49 .. "_update" then
			return v48
		end
	end
	return nil
end
local function v_u_56(p51, p52, p53)
	-- upvalues: (copy) v_u_3
	if p51:sub(1, p53:len()) == p53 then
		for v54 = 1, #v_u_3 do
			local v55 = v_u_3[v54]
			if (p52 == v55 or p52 == v55 .. "_update") and (not fileExists(p51) or GS_IS_CONSOLE_VERSION) then
				return "dataS/scripts/internalMods/" .. v55 .. "/" .. p51:sub(p53:len() + 1)
			end
		end
	end
	return p51
end
function loadModDesc(p_u_57, p_u_58, p59, p60, p61, p62, p63, p_u_64)
	-- upvalues: (copy) v_u_38, (copy) v_u_50, (ref) v_u_1, (copy) v_u_4, (copy) v_u_56, (copy) v_u_42
	if not v_u_38(p_u_57) then
		printError("Error: Invalid mod name \'" .. p_u_57 .. "\'! Characters allowed: (_, A-Z, a-z, 0-9). The first character must not be a digit")
		return
	end
	local v65 = p_u_57
	if p63 then
		p_u_57 = g_uniqueDlcNamePrefix .. p_u_57
	end
	if g_modNameToDirectory[p_u_57] ~= nil then
		Logging.error("Mod name \'" .. p_u_57 .. "\' already in use. Ignore it!")
		return
	end
	g_modNameToDirectory[p_u_57] = p_u_58
	local v66
	if string.endsWith(p59, "dlcDesc.xml") then
		if not fileExists(p59) then
			if GS_IS_EPIC_VERSION and string.startsWith(p_u_58, getAppBasePath() .. "pdlc/") then
				print("Info: No license for dlc " .. p_u_57 .. ".")
			else
				printError("Error: No license for dlc " .. p_u_57 .. ". Please reinstall.")
			end
			return
		end
		v66 = true
	else
		v66 = false
	end
	setModInstalled(p61, p63)
	local v67 = XMLFile.load("ModFile", p59, g_modDescSchema)
	if v67 == nil then
		return
	end
	local v68 = v67:getString("modDesc.version")
	local v69 = (v68 == nil or v68 == "") and "" or " (Version: " .. v68 .. ")"
	if p_u_64 and v68 ~= v_u_50(p_u_57).version then
		printError("Error: Outdated mod version in mod " .. p_u_57)
		v67:delete()
		return
	end
	local v70 = p60 == nil and "" or "(Hash: " .. p60 .. ")"
	if v66 then
		print("Available dlc: " .. v70 .. v69 .. " " .. p_u_57)
	else
		print("Available mod: " .. v70 .. v69 .. " " .. p_u_57)
	end
	local v71 = v67:getInt("modDesc#descVersion")
	if v71 == nil then
		printError("Error: Missing descVersion attribute in mod " .. p_u_57)
		v67:delete()
		return
	end
	if v71 < g_minModDescVersion or g_maxModDescVersion < v71 then
		printError("Error: Unsupported mod description version in mod " .. p_u_57)
		v67:delete()
		return
	end
	if _G[p_u_57] ~= nil and not v_u_1 then
		printError("Error: Invalid mod name \'" .. p_u_57 .. "\'")
		v67:delete()
		return
	end
	local v72 = v_u_4[p_u_57]
	if v72 ~= nil then
		local v73 = string.split(v68, ".")
		local v74 = true
		for v75, v76 in ipairs(v73) do
			if v75 > 4 then
				break
			end
			local v77 = tonumber(v76) or 0
			if v77 ~= nil and (v72[v75] ~= nil and v72[v75] < v77) then
				v74 = false
				break
			end
		end
		if v74 then
			printError("Error: Mod \'" .. p_u_57 .. "\' in version \'" .. v68 .. "\' and lower is not supported anymore. Please update the mod!")
			v67:delete()
			return
		end
	end
	if v66 then
		local v78 = v67:getString("modDesc.multiplayer#requiredModName")
		if v78 ~= nil and v78 ~= v65 then
			printError("Error: Do not rename dlcs. Name: \'" .. v65 .. "\'. Expect: \'" .. v78 .. "\'")
			v67:delete()
			return
		end
	end
	local v79 = v67:getBool("modDesc.isSelectable", true)
	local v_u_80 = {}
	if GS_IS_CONSOLE_VERSION then
		v_u_80 = Utils.getNoNil(_G[p_u_57], v_u_80)
	end
	g_globalsNameCheckDisabled = true
	_G[p_u_57] = v_u_80
	g_globalsNameCheckDisabled = false
	local v81 = {
		["__index"] = _G
	}
	setmetatable(v_u_80, v81)
	if not (v66 or p_u_64) then
		v_u_80._G = v_u_80
	end
	local v_u_82 = _G
	local v_u_83 = getfenv
	function v_u_80.getfenv(p84)
		-- upvalues: (copy) v_u_83, (copy) v_u_82, (ref) v_u_80
		local v85 = v_u_83(p84)
		if v85 == v_u_82 then
			return v_u_80
		else
			return v85
		end
	end
	v_u_80.g_i18n = g_i18n:addModI18N(p_u_57)
	function v_u_80.loadstring(p86, p87)
		-- upvalues: (ref) p_u_57
		local v88 = "setfenv(1," .. p_u_57 .. "); " .. p86
		return loadstring(v88, p87)
	end
	function v_u_80.source(p89, _)
		-- upvalues: (copy) p_u_64, (ref) v_u_56, (ref) p_u_57, (copy) p_u_58
		if isAbsolutePath(p89) or p_u_64 then
			local v90 = v_u_56(p89, p_u_57, p_u_58)
			source(v90, p_u_57)
		else
			source(p89)
		end
	end
	function v_u_80.InitEventClass(p91, p92)
		-- upvalues: (ref) p_u_57
		InitEventClass(p91, p_u_57 .. "." .. p92)
	end
	function v_u_80.InitObjectClass(p93, p94)
		-- upvalues: (ref) p_u_57
		InitObjectClass(p93, p_u_57 .. "." .. p94)
	end
	function v_u_80.registerObjectClassName(p95, p96)
		-- upvalues: (ref) p_u_57
		registerObjectClassName(p95, p_u_57 .. "." .. p96)
	end
	v_u_80.g_constructionBrushTypeManager = {}
	local function v101(_, p97, p98, p99, p100)
		-- upvalues: (copy) p_u_64, (ref) v_u_56, (ref) p_u_57, (copy) p_u_58
		if isAbsolutePath(p99) or p_u_64 then
			p99 = v_u_56(p99, p_u_57, p_u_58)
			p100 = p_u_57
			p97 = p_u_57 .. "." .. p97
			p98 = p_u_57 .. "." .. p98
		end
		g_constructionBrushTypeManager:addBrushType(p97, p98, p99, p100)
	end
	v_u_80.g_constructionBrushTypeManager.addBrushType = v101
	function v_u_80.g_constructionBrushTypeManager.getClassObjectByTypeName(_, p102)
		-- upvalues: (ref) p_u_57
		local v103 = g_constructionBrushTypeManager:getClassObjectByTypeName(p102)
		if v103 == nil then
			v103 = g_constructionBrushTypeManager:getClassObjectByTypeName(p_u_57 .. "." .. p102)
		end
		return v103
	end
	local v104 = v_u_80.g_constructionBrushTypeManager
	local v105 = {
		["__index"] = g_constructionBrushTypeManager
	}
	setmetatable(v104, v105)
	v_u_80.g_specializationManager = {}
	local function v111(p106, p107, p108, p109, p110, ...)
		-- upvalues: (copy) p_u_64, (ref) v_u_56, (ref) p_u_57, (copy) p_u_58
		if type(p106) ~= "table" then
			Logging.error("Invalid self object given for (Vehicle) SpecializationManager.addSpecialization. Usage: \'g_specializationManager:addSpecialization(name, className, filename, customEnvironment)\'")
			printCallstack()
		end
		if p110 ~= nil and type(p110) ~= "string" then
			Logging.error("Invalid customEnvironment given for (Vehicle) SpecializationManager.addSpecialization. Should be a string or nil.")
			printCallstack()
		end
		if select("#", ...) > 0 then
			Logging.error("Too many arguments for (Vehicle) SpecializationManager.addSpecialization. (Arguments should be: name, className, filename, customEnvironment)")
			printCallstack()
		end
		if isAbsolutePath(p109) or p_u_64 then
			p109 = v_u_56(p109, p_u_57, p_u_58)
			p110 = p_u_57
			p107 = p_u_57 .. "." .. p107
			p108 = p_u_57 .. "." .. p108
		end
		g_specializationManager:addSpecialization(p107, p108, p109, p110)
	end
	v_u_80.g_specializationManager.addSpecialization = v111
	function v_u_80.g_specializationManager.getSpecializationByName(_, p112)
		-- upvalues: (ref) p_u_57
		local v113 = g_specializationManager:getSpecializationByName(p112)
		if v113 == nil then
			v113 = g_specializationManager:getSpecializationByName(p_u_57 .. "." .. p112)
		end
		return v113
	end
	function v_u_80.g_specializationManager.getSpecializationObjectByName(_, p114)
		-- upvalues: (ref) p_u_57
		local v115 = g_specializationManager:getSpecializationObjectByName(p114)
		if v115 == nil then
			v115 = g_specializationManager:getSpecializationObjectByName(p_u_57 .. "." .. p114)
		end
		return v115
	end
	local v116 = v_u_80.g_specializationManager
	local v117 = {
		["__index"] = g_specializationManager
	}
	setmetatable(v116, v117)
	v_u_80.g_placeableSpecializationManager = {}
	local function v123(p118, p119, p120, p121, p122, ...)
		-- upvalues: (copy) p_u_64, (ref) v_u_56, (ref) p_u_57, (copy) p_u_58
		if type(p118) ~= "table" then
			Logging.error("Invalid self object given for (Placeable) SpecializationManager.addSpecialization. Usage: \'g_placeableSpecializationManager:addSpecialization(name, className, filename, customEnvironment)\'")
			printCallstack()
		end
		if p122 ~= nil and type(p122) ~= "string" then
			Logging.error("Invalid customEnvironment given for (Placeable) SpecializationManager.addSpecialization. Should be a string or nil.")
			printCallstack()
		end
		if select("#", ...) > 0 then
			Logging.error("Too many arguments for (Placeable) SpecializationManager.addSpecialization. (Arguments should be: name, className, filename, customEnvironment)")
			printCallstack()
		end
		if isAbsolutePath(p121) or p_u_64 then
			p121 = v_u_56(p121, p_u_57, p_u_58)
			p122 = p_u_57
			p119 = p_u_57 .. "." .. p119
			p120 = p_u_57 .. "." .. p120
		end
		g_placeableSpecializationManager:addSpecialization(p119, p120, p121, p122)
	end
	v_u_80.g_placeableSpecializationManager.addSpecialization = v123
	function v_u_80.g_placeableSpecializationManager.getSpecializationByName(_, p124)
		-- upvalues: (ref) p_u_57
		local v125 = g_placeableSpecializationManager:getSpecializationByName(p124)
		if v125 == nil then
			v125 = g_placeableSpecializationManager:getSpecializationByName(p_u_57 .. "." .. p124)
		end
		return v125
	end
	local v126 = v_u_80.g_placeableSpecializationManager
	local v127 = {
		["__index"] = g_placeableSpecializationManager
	}
	setmetatable(v126, v127)
	v_u_80.g_handToolSpecializationManager = {}
	local function v133(p128, p129, p130, p131, p132, ...)
		-- upvalues: (copy) p_u_64, (ref) v_u_56, (ref) p_u_57, (copy) p_u_58
		if type(p128) ~= "table" then
			Logging.error("Invalid self object given for SpecializationManager.addSpecialization. Usage: \'g_handToolSpecializationManager:addSpecialization(name, className, filename, customEnvironment)\'")
			printCallstack()
		end
		if p132 ~= nil and type(p132) ~= "string" then
			Logging.error("Invalid customEnvironment given for (HandTool) SpecializationManager.addSpecialization. Should be a string or nil.")
			printCallstack()
		end
		if select("#", ...) > 0 then
			Logging.error("Too many arguments for (HandTool) SpecializationManager.addSpecialization. (Arguments should be: name, className, filename, customEnvironment)")
			printCallstack()
		end
		if isAbsolutePath(p131) or p_u_64 then
			p131 = v_u_56(p131, p_u_57, p_u_58)
			p132 = p_u_57
			p129 = p_u_57 .. "." .. p129
			p130 = p_u_57 .. "." .. p130
		end
		g_handToolSpecializationManager:addSpecialization(p129, p130, p131, p132)
	end
	v_u_80.g_handToolSpecializationManager.addSpecialization = v133
	function v_u_80.g_handToolSpecializationManager.getSpecializationByName(_, p134)
		-- upvalues: (ref) p_u_57
		local v135 = g_handToolSpecializationManager:getSpecializationByName(p134)
		if v135 == nil then
			v135 = g_handToolSpecializationManager:getSpecializationByName(p_u_57 .. "." .. p134)
		end
		return v135
	end
	local v136 = v_u_80.g_handToolSpecializationManager
	local v137 = {
		["__index"] = g_handToolSpecializationManager
	}
	setmetatable(v136, v137)
	v_u_80.g_vehicleTypeManager = {}
	local function v142(_, p138, p139, p140, p141)
		-- upvalues: (copy) p_u_64, (ref) v_u_56, (ref) p_u_57, (copy) p_u_58
		if isAbsolutePath(p140) or p_u_64 then
			p140 = v_u_56(p140, p_u_57, p_u_58)
			p141 = p_u_57
			p138 = p_u_57 .. "." .. p138
			p139 = p_u_57 .. "." .. p139
		end
		g_vehicleTypeManager:addType(p138, p139, p140, p141)
	end
	v_u_80.g_vehicleTypeManager.addType = v142
	function v_u_80.g_vehicleTypeManager.addSpecialization(_, p143, p144)
		-- upvalues: (ref) p_u_57
		if g_specializationManager:getSpecializationByName(p144) == nil and g_specializationManager:getSpecializationByName(p_u_57 .. "." .. p144) ~= nil then
			p144 = p_u_57 .. "." .. p144
		end
		g_vehicleTypeManager:addSpecialization(p143, p144)
	end
	local v145 = v_u_80.g_vehicleTypeManager
	local v146 = {
		["__index"] = g_vehicleTypeManager
	}
	setmetatable(v145, v146)
	v_u_80.g_placeableTypeManager = {}
	local function v151(_, p147, p148, p149, p150)
		-- upvalues: (copy) p_u_64, (ref) v_u_56, (ref) p_u_57, (copy) p_u_58
		if isAbsolutePath(p149) or p_u_64 then
			p149 = v_u_56(p149, p_u_57, p_u_58)
			p150 = p_u_57
			p147 = p_u_57 .. "." .. p147
			p148 = p_u_57 .. "." .. p148
		end
		g_placeableTypeManager:addType(p147, p148, p149, p150)
	end
	v_u_80.g_placeableTypeManager.addType = v151
	function v_u_80.g_placeableTypeManager.addSpecialization(_, p152, p153)
		-- upvalues: (ref) p_u_57
		if g_placeableSpecializationManager:getSpecializationByName(p153) == nil and g_placeableSpecializationManager:getSpecializationByName(p_u_57 .. "." .. p153) ~= nil then
			p153 = p_u_57 .. "." .. p153
		end
		g_placeableTypeManager:addSpecialization(p152, p153)
	end
	local v154 = v_u_80.g_placeableTypeManager
	local v155 = {
		["__index"] = g_placeableTypeManager
	}
	setmetatable(v154, v155)
	v_u_80.g_handToolTypeManager = {}
	local function v160(_, p156, p157, p158, p159)
		-- upvalues: (copy) p_u_64, (ref) v_u_56, (ref) p_u_57, (copy) p_u_58
		if isAbsolutePath(p158) or p_u_64 then
			p158 = v_u_56(p158, p_u_57, p_u_58)
			p159 = p_u_57
			p156 = p_u_57 .. "." .. p156
			p157 = p_u_57 .. "." .. p157
		end
		g_handToolTypeManager:addType(p156, p157, p158, p159)
	end
	v_u_80.g_handToolTypeManager.addType = v160
	function v_u_80.g_handToolTypeManager.addSpecialization(_, p161, p162)
		-- upvalues: (ref) p_u_57
		if g_handToolSpecializationManager:getSpecializationByName(p162) == nil and g_handToolSpecializationManager:getSpecializationByName(p_u_57 .. "." .. p162) ~= nil then
			p162 = p_u_57 .. "." .. p162
		end
		g_handToolTypeManager:addSpecialization(p161, p162)
	end
	local v163 = v_u_80.g_handToolTypeManager
	local v164 = {
		["__index"] = g_handToolTypeManager
	}
	setmetatable(v163, v164)
	v_u_80.g_effectManager = {}
	function v_u_80.g_effectManager.registerEffectClass(_, p165, p166)
		-- upvalues: (ref) p_u_57
		if ClassUtil.getIsValidClassName(p165) then
			_G.g_effectManager:registerEffectClass(p_u_57 .. "." .. p165, p166)
		else
			printError("Error: Invalid effect class name: " .. p165)
		end
	end
	function v_u_80.g_effectManager.getEffectClass(_, p167)
		-- upvalues: (ref) p_u_57
		local v168 = _G.g_effectManager:getEffectClass(p167)
		if v168 == nil then
			v168 = _G.g_effectManager:getEffectClass(p_u_57 .. "." .. p167)
		end
		return v168
	end
	local v169 = v_u_80.g_effectManager
	local v170 = {
		["__index"] = _G.g_effectManager
	}
	setmetatable(v169, v170)
	local v_u_171 = getUserProfileAppPath()
	local v_u_172 = string.sub
	local v_u_173 = string.len
	local function v177(p_u_174)
		-- upvalues: (copy) v_u_171, (ref) p_u_57, (copy) v_u_173, (copy) v_u_172
		return function(p175)
			-- upvalues: (ref) v_u_171, (ref) p_u_57, (ref) v_u_173, (ref) v_u_172, (copy) p_u_174
			local v176 = v_u_171 .. "modSettings/" .. p_u_57
			if v_u_172(p175, 1, (v_u_173(v176))) == v176 then
				p_u_174(p175)
			else
				printError(string.format("Error: No access to folder \'%s\'", p175))
				print(string.format("Info: Mod has full access in \'%s\'", v176))
				printCallstack()
			end
		end
	end
	v_u_80.g_adsSystem = {}
	v_u_80.InitStaticEventClass = ""
	v_u_80.InitStaticObjectClass = ""
	v_u_80.loadMod = ""
	v_u_80.loadModDesc = ""
	v_u_80.loadDlcs = ""
	v_u_80.loadDlcsFromDirectory = ""
	v_u_80.loadMods = ""
	v_u_80.reloadDlcsAndMods = ""
	v_u_80.verifyDlcs = ""
	v_u_80.deleteFile = v177(deleteFile)
	v_u_80.deleteFolder = v177(deleteFolder)
	v_u_80.isAbsolutePath = isAbsolutePath
	v_u_80.g_isDevelopmentVersion = g_isDevelopmentVersion
	v_u_80.GS_IS_CONSOLE_VERSION = GS_IS_CONSOLE_VERSION
	if not (v66 or p_u_64) then
		v_u_80.ClassUtil = {}
		function v_u_80.ClassUtil.getClassModName(_, p178)
			-- upvalues: (ref) p_u_57
			local v179 = _G.ClassUtil.getClassModName(p178)
			if v179 == nil then
				v179 = _G.ClassUtil.getClassModName(p_u_57 .. "." .. p178)
			end
			return v179
		end
	end
	local v_u_180 = {
		["onCreateFunctions"] = {}
	}
	v_u_80.g_onCreateUtil = v_u_180
	function v_u_180.addOnCreateFunction(p181, p182)
		-- upvalues: (copy) v_u_180
		v_u_180.onCreateFunctions[p181] = p182
	end
	function v_u_180.activateOnCreateFunctions()
		-- upvalues: (copy) v_u_180
		for v183, v_u_184 in pairs(v_u_180.onCreateFunctions) do
			modOnCreate[v183] = function(_, p185)
				-- upvalues: (copy) v_u_184
				v_u_184(p185)
			end
		end
	end
	function v_u_180.deactivateOnCreateFunctions()
		-- upvalues: (copy) v_u_180
		for v186, _ in pairs(v_u_180.onCreateFunctions) do
			modOnCreate[v186] = nil
		end
	end
	for _, v187 in v67:iterator("modDesc.l10n.text") do
		local v188 = v67:getString(v187 .. "#name")
		local v189 = v67:getString(v187 .. "." .. g_languageShort)
		if v189 == nil then
			v189 = v67:getString(v187 .. ".en")
			if v189 == nil then
				v189 = v67:getString(v187 .. ".de")
			end
		end
		if v189 == nil or v188 == nil then
			printWarning("Warning: No l10n text found for entry \'" .. v188 .. "\' in mod \'" .. p_u_57 .. "\'")
		elseif v_u_80.g_i18n:hasModText(v188) then
			printWarning("Warning: Duplicate l10n entry \'" .. v188 .. "\' in mod \'" .. p_u_57 .. "\'. Ignoring this definition.")
		else
			v_u_80.g_i18n:setText(v188, v189)
		end
	end
	local v190 = v67:getString("modDesc.l10n#filenamePrefix")
	if v190 ~= nil then
		local v191 = Utils.getFilename(v190, p_u_58)
		local v192 = { g_languageShort, "en", "de" }
		local v193 = nil
		local v194 = nil
		for _, v195 in ipairs(v192) do
			v194 = v191 .. "_" .. v195 .. ".xml"
			if fileExists(v194) then
				v193 = loadXMLFile("modL10n", v194)
				break
			end
		end
		if v193 == nil then
			printWarning("Warning: No l10n file found for \'" .. v190 .. "\' in mod \'" .. p_u_57 .. "\'")
		else
			local v196 = 0
			while true do
				local v197 = string.format("l10n.texts.text(%d)", v196)
				if not hasXMLProperty(v193, v197) then
					break
				end
				local v198 = getXMLString(v193, v197 .. "#name")
				local v199 = getXMLString(v193, v197 .. "#text")
				if v198 ~= nil and v199 ~= nil then
					if v_u_80.g_i18n:hasModText(v198) then
						printWarning("Warning: Duplicate l10n entry \'" .. v198 .. "\' in \'" .. v194 .. "\'. Ignoring this definition.")
					else
						v_u_80.g_i18n:setText(v198, v199:gsub("\r\n", "\n"))
					end
				end
				v196 = v196 + 1
			end
			local v200 = 0
			while true do
				local v201 = string.format("l10n.elements.e(%d)", v200)
				if not hasXMLProperty(v193, v201) then
					break
				end
				local v202 = getXMLString(v193, v201 .. "#k")
				local v203 = getXMLString(v193, v201 .. "#v")
				if v202 ~= nil and v203 ~= nil then
					if v_u_80.g_i18n:hasModText(v202) then
						printWarning("Warning: Duplicate l10n entry \'" .. v202 .. "\' in \'" .. v194 .. "\'. Ignoring this definition.")
					else
						v_u_80.g_i18n:setText(v202, v203:gsub("\r\n", "\n"))
					end
				end
				v200 = v200 + 1
			end
			delete(v193)
		end
	end
	local v204 = v67:getI18NValue("modDesc.title", "", p_u_57, true)
	local v205 = v67:getI18NValue("modDesc.description", "", p_u_57, true)
	local v206 = v67:getI18NValue("modDesc.iconFilename", "", p_u_57, true)
	if v204 == "" then
		printError("Error: Missing title in mod " .. p_u_57)
		v67:delete()
		return
	elseif v205 == "" then
		printError("Error: Missing description in mod " .. p_u_57)
		v67:delete()
		return
	else
		local v207 = v67:getBool("modDesc.multiplayer#supported", false)
		local v208 = v67:getBool("modDesc.multiplayer#only", false)
		if p60 == nil then
			if v207 then
				printWarning("Warning: Only zip mods are supported in multiplayer. You need to zip the mod " .. p_u_57 .. " to use it in multiplayer.")
				v207 = false
			else
				v207 = false
			end
		end
		if v207 or not v208 then
			if v207 and v206 == "" then
				printError("Error: Missing icon filename in mod " .. p_u_57)
				v67:delete()
			else
				for _, v209 in v67:iterator("modDesc.maps.map") do
					g_mapManager:loadMapFromXML(v67, v209, p_u_58, p_u_57, v207, v66, true, p_u_64)
				end
				local v210 = v67:getI18NValue("modDesc.author", "", p_u_57, true)
				if v66 then
					local v211 = v67:getString("modDesc.productId")
					if v211 == nil or v68 == nil then
						printError("Error: invalid product id or version in DLC " .. p_u_57)
					else
						addNotificationFilter(v211, v68)
					end
				end
				local v212 = v67:hasProperty("modDesc.extraSourceFiles.sourceFile(0)") or v67:hasProperty("modDesc.specializations.specialization(0)")
				local v213
				if v67:hasProperty("modDesc.dependencies.dependency(0)") then
					v213 = {}
					for _, v214 in v67:iterator("modDesc.dependencies.dependency") do
						local v215 = v67:getString(v214)
						if v215 ~= nil and v215:len() > 0 then
							v213[#v213 + 1] = v215
						end
					end
				else
					v213 = nil
				end
				local v216 = v67:getString("modDesc.uniqueType")
				for _, v217 in v67:iterator("modDesc.extraContent.key") do
					local v218 = v67:getString(v217)
					if v218 ~= nil then
						local v219, v220 = g_extraContentSystem:unlockItem(v218, true)
						if v219 ~= nil and v220 == ExtraContentSystem.UNLOCKED then
							print("ExtraContent: Unlocked \'" .. v219.id .. "\'")
							g_extraContentSystem:saveToProfile()
						end
					end
				end
				if p_u_64 then
					g_currentModDirectory = p_u_58
					g_currentModName = p_u_57
					for _, v221 in v67:iterator("modDesc.preLoadSourceFiles.sourceFile") do
						local v222 = v67:getString(v221 .. "#filename")
						if v222 ~= nil then
							v_u_80.source(p_u_58 .. v222, p_u_57)
						end
					end
				end
				local v223 = Utils.getFilename(v206, p_u_58)
				g_modManager:addMod(v204, v205, v68, v71, v210, v223, p_u_57, p_u_58, p59, v207, p60, p61, p62, v66, v212, v213, v208, v79, v216, v_u_42(p_u_57))
				v67:delete()
			end
		else
			printError("Error: Both multiplayer and singleplayer are unsupported in mod " .. p_u_57)
			v67:delete()
			return
		end
	end
end
function resetModOnCreateFunctions()
	modOnCreate = {}
end
function loadMod(p224, p225, p226, p227)
	-- upvalues: (copy) v_u_42, (copy) v_u_46
	if g_modIsLoaded[p224] then
		return
	else
		g_modIsLoaded[p224] = true
		g_modNameToDirectory[p224] = p225
		local v228 = _G[p224]
		if v228 ~= nil then
			local v229 = XMLFile.load("ModFile", p226, g_modDescSchema)
			local v230 = string.endsWith(p226, "dlcDesc.xml") and true or false
			if v230 then
				print("  Load dlc: " .. p224)
			else
				print("  Load mod: " .. p224)
			end
			local v231 = not GS_IS_CONSOLE_VERSION or (v230 or g_isDevelopmentConsoleScriptModTesting) or (v_u_42(p224) or v_u_46(p224))
			g_currentModDirectory = p225
			g_currentModName = p224
			if g_modSettingsDirectory ~= nil then
				g_currentModSettingsDirectory = g_modSettingsDirectory .. p224 .. "/"
			end
			if v231 then
				for _, v232 in v229:iterator("modDesc.extraSourceFiles.sourceFile") do
					local v233 = v229:getString(v232 .. "#filename")
					if v233 ~= nil then
						v228.source(p225 .. v233, p224)
					end
				end
			end
			for _, v234 in v229:iterator("modDesc.brands.brand") do
				local v235 = v229:getString(v234 .. "#name")
				local v236 = v229:getString(v234 .. "#title")
				local v237 = v229:getString(v234 .. "#image")
				local v238 = v229:getFloat(v234 .. "#imageOffset")
				g_brandManager:addBrand(v235, v236, v237, p225, true, nil, v238)
			end
			for _, v239 in v229:iterator("modDesc.helpLines.category") do
				g_helpLineManager:addModCategory(v229, v239, p225, p224)
			end
			if v230 then
				for _, v240 in v229:iterator("modDesc.storeCategories.storeCategory") do
					g_storeManager:loadCategoryFromXML(v229, v240, p225, p224)
				end
			end
			for _, v241 in v229:iterator("modDesc.specializations.specialization") do
				local v242 = v229:getString(v241 .. "#name")
				local v243 = v229:getString(v241 .. "#className")
				local v244 = v229:getString(v241 .. "#filename")
				if v242 ~= nil and (v243 ~= nil and v244 ~= nil) then
					local v245 = p225 .. v244
					if v231 then
						v228.g_specializationManager:addSpecialization(v242, v243, v245, p224)
					else
						printError("Error: Can\'t register specialization " .. v242 .. " with scripts on consoles.")
					end
				end
			end
			for _, v246 in v229:iterator("modDesc.vehicleTypes.type") do
				g_vehicleTypeManager:loadTypeFromXML(v229.handle, v246, v230, p225, p224)
			end
			for _, v247 in v229:iterator("modDesc.placeableSpecializations.specialization") do
				local v248 = v229:getString(v247 .. "#name")
				local v249 = v229:getString(v247 .. "#className")
				local v250 = v229:getString(v247 .. "#filename")
				if v248 ~= nil and (v249 ~= nil and v250 ~= nil) then
					local v251 = p225 .. v250
					if v231 then
						v228.g_placeableSpecializationManager:addSpecialization(v248, v249, v251, p224)
					else
						printError("Error: Can\'t register placeable specialization " .. v248 .. " with scripts on consoles.")
					end
				end
			end
			for _, v252 in v229:iterator("modDesc.placeableTypes.type") do
				g_placeableTypeManager:loadTypeFromXML(v229.handle, v252, v230, p225, p224)
			end
			for _, v253 in v229:iterator("modDesc.handToolSpecializations.specialization") do
				local v254 = v229:getString(v253 .. "#name")
				local v255 = v229:getString(v253 .. "#className")
				local v256 = v229:getString(v253 .. "#filename")
				if v254 ~= nil and (v255 ~= nil and v256 ~= nil) then
					local v257 = p225 .. v256
					if v231 then
						v228.g_handToolSpecializationManager:addSpecialization(v254, v255, v257, p224)
					else
						printError("Error: Can\'t register handTool specialization " .. v254 .. " with scripts on consoles.")
					end
				end
			end
			for _, v258 in v229:iterator("modDesc.handToolTypes.type") do
				g_handToolTypeManager:loadTypeFromXML(v229.handle, v258, v230, p225, p224)
			end
			for _, v259 in v229:iterator("modDesc.bales.bale") do
				g_baleManager:loadModBaleFromXML(v229, v259, p225, p224)
			end
			for _, v260 in v229:iterator("modDesc.jointTypes.jointType") do
				local v261 = v229:getString(v260 .. "#name")
				if v261 ~= nil then
					AttacherJoints.registerJointType(v261)
				end
			end
			for _, v262 in v229:iterator("modDesc.materialHolders.materialHolder") do
				local v263 = v229:getString(v262 .. "#filename")
				if v263 ~= nil then
					local v264 = Utils.getFilename(v263, g_currentModDirectory)
					g_materialManager:addModMaterialHolder(v264)
				end
			end
			g_vehicleMaterialManager:addModMaterialTemplatesToLoad(p226, "modDesc.materialTemplates", g_currentModDirectory, p224)
			for _, v265 in v229:iterator("modDesc.connectionHoses.connectionHose") do
				local v266 = v229:getString(v265 .. "#xmlFilename")
				if v266 ~= nil then
					local v267 = Utils.getFilename(v266, g_currentModDirectory)
					g_connectionHoseManager:addModConnectionHoses(v267, p224, g_currentModDirectory)
				end
			end
			for _, v268 in v229:iterator("modDesc.consumables.consumable") do
				local v269 = v229:getString(v268 .. "#xmlFilename")
				if v269 ~= nil then
					local v270 = Utils.getFilename(v269, g_currentModDirectory)
					g_consumableManager:addModConsumable(v270, p224, g_currentModDirectory)
				end
			end
			for _, v271 in v229:iterator("modDesc.storeItems.storeItem") do
				local v272 = v229:getString(v271 .. "#xmlFilename")
				if v272 ~= nil then
					g_storeManager:addModStoreItem(v272, p225, p224, not v230, false, p227)
				end
			end
			for _, v273 in v229:iterator("modDesc.storePacks.storePack") do
				local v274 = v229:getString(v273 .. "#name")
				local v275 = v229:getString(v273 .. "#title")
				local v276 = v229:getString(v273 .. "#image")
				if v275 ~= nil and v275:sub(1, 6) == "$l10n_" then
					v275 = g_i18n:getText(v275:sub(7))
				end
				local v277 = {}
				for _, v278 in v229:iterator(v273 .. ".storeItem") do
					local v279 = v229:getString(v278)
					local v280 = Utils.getFilename(v279, g_currentModDirectory)
					if fileExists(v280) then
						table.insert(v277, v280)
					else
						Logging.xmlWarning(v229, "StoreItem \'%s\' not found for storepack \'%s\'", v279, v274)
					end
				end
				g_storeManager:addModStorePack(v274, v275, v276, p225, v277)
			end
			local v281 = v229:getString("modDesc.fillTypes#filename")
			if v281 ~= nil then
				local v282, _ = Utils.getFilename(v281, g_currentModDirectory)
				g_fillTypeManager:addModWithFillTypes(v282, g_currentModDirectory, p224)
			end
			local v283 = v229:getString("modDesc.densityMapHeightTypes#filename")
			if v283 ~= nil then
				local v284 = Utils.getFilename(v283, g_currentModDirectory)
				g_densityMapHeightManager:addModDensityMapHeightTypes(v284)
			end
			if v230 then
				for _, v285 in v229:iterator("modDesc.foliageTypes.foliageType") do
					local v286 = v229:getString(v285 .. "#name")
					local v287 = v229:getString(v285 .. "#filename")
					if v286 ~= nil and v287 ~= nil then
						local v288 = Utils.getFilename(v287, g_currentModDirectory)
						g_fruitTypeManager:addModFoliageType(v286, v288)
					end
				end
			end
			local v289 = v229:getString("modDesc.missionVehicles#filename")
			if v289 ~= nil then
				local v290 = Utils.getFilename(v289, g_currentModDirectory)
				g_missionManager:addPendingMissionVehiclesFile(v290, g_currentModDirectory)
			end
			local v291 = v229:getString("modDesc.wildlife#filename")
			if v291 ~= nil then
				WildlifeManager.registerWildlifeFile(v291, g_currentModDirectory, p224)
			end
			v229:delete()
			g_currentModDirectory = nil
			g_currentModName = nil
		end
	end
end
function reloadDlcsAndMods()
	-- upvalues: (ref) v_u_1
	if g_currentMission == nil then
		for v292 = g_mapManager:getNumOfMaps(), 1, -1 do
			if g_mapManager:getMapDataByIndex(v292).isModMap then
				g_mapManager:removeMapItem(v292)
			end
		end
		while g_modManager:getNumOfMods() > 0 do
			g_modManager:removeMod(g_modManager:getModByIndex(1))
		end
		g_modIsLoaded = {}
		g_modNameToDirectory = {}
		g_dlcModNameHasPrefix = {}
		g_globalMods = {}
		v_u_1 = true
		startUpdatePendingMods()
		loadDlcsDirectories()
		loadDlcs()
		if isModUpdateRunning() then
			local v293 = startFrameRepeatMode()
			while isModUpdateRunning() do
				usleep(16000)
			end
			if v293 then
				endFrameRepeatMode()
			end
		end
		if Platform.supportsMods then
			loadInternalMods()
			loadMods()
		end
		g_inputBinding:reloadModActions()
		v_u_1 = false
	else
		print("Dlc reloading is not supported during gameplay")
	end
end
function verifyDlcs()
	local v294 = {}
	for _, v295 in ipairs(g_modManager:getMods()) do
		if not fileExists(v295.modFile) then
			table.insert(v294, v295)
		end
	end
	return #v294 == 0, v294
end
function checkForNewDlcs()
	if not Platform.isXbox then
		return true
	end
	local v296 = {}
	local v297 = false
	for v298 = 0, getNumDlcPaths() - 1 do
		local v299 = getDlcPath(v298)
		if v299 ~= nil then
			v296[v299] = true
			if g_lastCheckDlcPaths[v299] == nil then
				v297 = true
			end
		end
	end
	g_lastCheckDlcPaths = v296
	return v297
end
checkForNewDlcs()
function loadDlcsDirectories()
	g_dlcsDirectories = {}
	for v300 = 0, getNumDlcPaths() - 1 do
		local v301 = getDlcPath(v300)
		if v301 ~= nil then
			local v302 = g_dlcsDirectories
			table.insert(v302, {
				["path"] = v301,
				["isLoaded"] = true
			})
			if v301 == getAppBasePath() .. "pdlc/" then
				local v303 = g_dlcsDirectories
				table.insert(v303, {
					["path"] = "pdlc/",
					["isLoaded"] = false
				})
			end
		end
	end
end
loadDlcsDirectories()
function addModEventListener(p304)
	local v305 = g_modEventListeners
	table.insert(v305, p304)
end
function removeModEventListener(p306)
	for v307, v308 in ipairs(g_modEventListeners) do
		if v308 == p306 then
			table.remove(g_modEventListeners, v307)
			return
		end
	end
end
function createModDescSchema()
	local v309 = XMLSchema.new("modDesc")
	v309:register(XMLValueType.INT, "modDesc#descVersion", "Version of the modDesc, can be used to enforce a specific game version or patch level for a mod to load", nil, true)
	v309:register(XMLValueType.STRING, "modDesc.author", "Author(s) of the mod", nil, true)
	v309:register(XMLValueType.STRING, "modDesc.version", "Version number of the mod, format \'a.b.c.d\'", nil, true)
	for v310 = 0, getNumOfLanguages() - 1 do
		local v311 = getLanguageCode(v310)
		v309:register(XMLValueType.STRING, string.format("modDesc.title.%s", v311), "localized title", nil, false)
		v309:register(XMLValueType.STRING, string.format("modDesc.description.%s", v311), "localized description", nil, false)
	end
	v309:register(XMLValueType.STRING, "modDesc.iconFilename", "Path to the icon used for the whole mod", nil, true)
	v309:register(XMLValueType.STRING, "modDesc.storeItems.storeItem(?)#xmlFilename", "Path to xml file of a individual store item", nil, false)
	v309:register(XMLValueType.BOOL, "modDesc.multiplayer#supported", "Mod supports multiplayer", false, false)
	v309:register(XMLValueType.STRING, "modDesc.extraSourceFiles.sourceFile(?)#filename", "additional lua file to source", nil, false)
	SpecializationManager.registerXMLPaths(v309, "modDesc.placeableSpecializations.specialization(?)")
	SpecializationManager.registerXMLPaths(v309, "modDesc.handToolSpecializations.specialization(?)")
	TypeManager.registerTypeXMLPath(v309, "modDesc.placeableTypes.type(?)")
	TypeManager.registerTypeXMLPath(v309, "modDesc.handToolTypes.type(?)")
	VehicleMaterialManager.registerXMLPaths(v309, "modDesc.materialTemplates")
	return v309
end

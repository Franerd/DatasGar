GameSettings = {}
local v_u_1 = Class(GameSettings)
g_xmlManager:addEarlyCreateSchemaFunction(function()
	GameSettings.xmlSchema = XMLSchema.new("gameSettings")
	GameSettings.registerXMLPaths(GameSettings.xmlSchema)
end)
GameSettings.SETTING = {
	["DEFAULT_SERVER_PORT"] = "defaultServerPort",
	["MAX_NUM_MIRRORS"] = "maxNumMirrors",
	["LIGHTS_PROFILE"] = "lightsProfile",
	["REAL_BEACON_LIGHTS"] = "realBeaconLights",
	["MP_LANGUAGE"] = "mpLanguage",
	["CAMERA_BOBBING"] = "cameraBobbing",
	["INPUT_HELP_MODE"] = "inputHelpMode",
	["GAMEPAD_ENABLED_SET_BY_USER"] = "gamepadEnabledSetByUser",
	["IS_GAMEPAD_ENABLED"] = "isGamepadEnabled",
	["HEAD_TRACKING_ENABLED_SET_BY_USER"] = "headTrackingEnabledSetByUser",
	["IS_HEAD_TRACKING_ENABLED"] = "isHeadTrackingEnabled",
	["FORCE_FEEDBACK"] = "forceFeedback",
	["IS_SOUND_PLAYER_STREAM_ACCESS_ALLOWED"] = "isSoundPlayerStreamAccessAllowed",
	["MOTOR_STOP_TIMER_DURATION"] = "motorStopTimerDuration",
	["HORSE_ABANDON_TIMER_DURATION"] = "horseAbandonTimerDuration",
	["FOV_Y"] = "fovY",
	["FOV_Y_PLAYER_FIRST_PERSON"] = "fovYPlayerFirstPerson",
	["FOV_Y_PLAYER_THIRD_PERSON"] = "fovYPlayerThirdPerson",
	["UI_SCALE"] = "uiScale",
	["ONLINE_PRESENCE_NAME"] = "onlinePresenceName",
	["LAST_PLAYER_STYLE_MALE"] = "lastPlayerStyleMale",
	["IS_TRAIN_TABBABLE"] = "isTrainTabbable",
	["RADIO_VEHICLE_ONLY"] = "radioVehicleOnly",
	["RADIO_IS_ACTIVE"] = "radioIsActive",
	["USE_COLORBLIND_MODE"] = "useColorblindMode",
	["EASY_ARM_CONTROL"] = "easyArmControl",
	["USE_MILES"] = "useMiles",
	["USE_FAHRENHEIT"] = "useFahrenheit",
	["USE_ACRE"] = "useAcre",
	["SHOW_TRIGGER_MARKER"] = "showTriggerMarker",
	["SHOW_HELP_TRIGGER"] = "showHelpTrigger",
	["SHOW_FIELD_INFO"] = "showFieldInfo",
	["RESET_CAMERA"] = "resetCamera",
	["USE_WORLD_CAMERA"] = "useWorldCamera",
	["ACTIVE_SUSPENSION_CAMERA"] = "activeSuspensionCamera",
	["CAMERA_CHECK_COLLISION"] = "cameraCheckCollision",
	["INVERT_Y_LOOK"] = "invertYLook",
	["STEERING_ASSIST_LINES"] = "steeringAssistLines",
	["DIRECTION_CHANGE_MODE"] = "directionChangeMode",
	["GEAR_SHIFT_MODE"] = "gearShiftMode",
	["HUD_SPEED_GAUGE"] = "hudSpeedGauge",
	["WOOD_HARVESTER_AUTO_CUT"] = "woodHarvesterAutoCut",
	["SHOW_HELP_ICONS"] = "showHelpIcons",
	["SHOW_HELP_MENU"] = "showHelpMenu",
	["VOLUME_RADIO"] = "radioVolume",
	["VOLUME_VEHICLE"] = "vehicleVolume",
	["VOLUME_ENVIRONMENT"] = "environmentVolume",
	["VOLUME_CHARACTER"] = "characterVolume",
	["VOLUME_GUI"] = "volumeGUI",
	["VOLUME_NO_FOCUS"] = "volumeNoFocus",
	["VOLUME_VOICE"] = "volumeVoice",
	["VOLUME_VOICE_INPUT"] = "volumeVoiceInput",
	["VOICE_MODE"] = "voiceMode",
	["VOICE_INPUT_SENSITIVITY"] = "voiceInputThreshold",
	["CAMERA_SENSITIVITY"] = "cameraSensitivity",
	["CAMERA_ZOOM_SENSITIVITY"] = "cameraZoomSensitivity",
	["JOYSTICK_DEADZONE"] = "joystickDeadzone",
	["VEHICLE_ARM_SENSITIVITY"] = "vehicleArmSensitivity",
	["REAL_BEACON_LIGHT_BRIGHTNESS"] = "realBeaconLightBrightness",
	["STEERING_BACK_SPEED"] = "steeringBackSpeed",
	["STEERING_SENSITIVITY"] = "steeringSensitivity",
	["INGAME_MAP_STATE"] = "ingameMapState",
	["INGAME_MAP_FILTER"] = "ingameMapFilter",
	["MONEY_UNIT"] = "moneyUnit",
	["VOLUME_MASTER"] = "masterVolume",
	["VOLUME_MUSIC"] = "musicVolume",
	["JOYSTICK_VIBRATION_ENABLED"] = "joystickVibrationEnabled",
	["GYROSCOPE_STEERING"] = "gyroscopeSteering",
	["CAMERA_TILTING"] = "cameraTilting",
	["HINTS"] = "hints",
	["SHOW_ALL_MODS"] = "showAllMods",
	["SHOWN_FREEMODE_WARNING"] = "shownFreemodeWarning",
	["SHOW_MULTIPLAYER_NAMES"] = "showMultiplayerNames",
	["INGAME_MAP_GROWTH_FILTER"] = "ingameMapGrowthFilter",
	["INGAME_MAP_SOIL_FILTER"] = "ingameMapSoilFilter",
	["INGAME_MAP_FRUIT_FILTER"] = "ingameMapFruitFilter",
	["INGAME_MAP_HOTSPOT_FILTER"] = "ingameMapHotspotFilter",
	["FRAME_LIMIT"] = "frameLimit",
	["CREATE_GAME"] = "createGame",
	["JOIN_GAME"] = "joinGame"
}
GameSettings.PERFORMANCE_CLASS_PRESETS = {
	{
		["lightsProfile"] = GS_PROFILE_VERY_LOW,
		["maxNumMirrors"] = 0,
		["realBeaconLights"] = false
	},
	{
		["lightsProfile"] = GS_PROFILE_LOW,
		["maxNumMirrors"] = 0,
		["realBeaconLights"] = false
	},
	{
		["lightsProfile"] = GS_PROFILE_MEDIUM,
		["maxNumMirrors"] = 3,
		["realBeaconLights"] = false
	},
	{
		["lightsProfile"] = GS_PROFILE_HIGH,
		["maxNumMirrors"] = 4,
		["realBeaconLights"] = false
	},
	{
		["lightsProfile"] = GS_PROFILE_VERY_HIGH,
		["maxNumMirrors"] = 5,
		["realBeaconLights"] = false
	},
	{
		["lightsProfile"] = GS_PROFILE_ULTRA,
		["maxNumMirrors"] = 6,
		["realBeaconLights"] = true
	}
}
function GameSettings.registerXMLPaths(p2)
	PlayerStyle.registerSavegameXMLPaths(p2, "gameSettings.lastPlayerStyle")
end
function GameSettings.new(p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.notifyOnChange = false
	v5.joinGame = {}
	v5.createGame = {}
	v5.frameLimitValues = Platform.frameLimits
	v5:setDefault()
	v5.printedSettingsChanges = {
		[GameSettings.SETTING.VOLUME_MASTER] = "Setting \'Master Volume\': %.3f",
		[GameSettings.SETTING.VOLUME_MUSIC] = "Setting \'Music Volume\': %.3f",
		[GameSettings.SETTING.VOLUME_VEHICLE] = "Setting \'Vehicle Volume\': %.3f",
		[GameSettings.SETTING.VOLUME_ENVIRONMENT] = "Setting \'Environment Volume\': %.3f",
		[GameSettings.SETTING.VOLUME_CHARACTER] = "Setting \'Character Volume\': %.3f",
		[GameSettings.SETTING.VOLUME_RADIO] = "Setting \'Radio Volume\': %.3f",
		[GameSettings.SETTING.VOLUME_GUI] = "Setting \'GUI Volume\': %.3f",
		[GameSettings.SETTING.VOLUME_NO_FOCUS] = "Setting \'Game Volume While Not In Focus\': %.3f",
		[GameSettings.SETTING.SHOW_TRIGGER_MARKER] = "Setting \'Show Trigger Marker\': %s",
		[GameSettings.SETTING.SHOW_HELP_TRIGGER] = "Setting \'Show Help Trigger\': %s",
		[GameSettings.SETTING.IS_TRAIN_TABBABLE] = "Setting \'Is Train Tabbable\': %s",
		[GameSettings.SETTING.RADIO_IS_ACTIVE] = "Setting \'Radio Active\': %s",
		[GameSettings.SETTING.RADIO_VEHICLE_ONLY] = "Setting \'Radio Vehicle Only\': %s",
		[GameSettings.SETTING.SHOW_HELP_ICONS] = "Setting \'Show Help Icons\': %s",
		[GameSettings.SETTING.USE_COLORBLIND_MODE] = "Setting \'Use Colorblind Mode\': %s",
		[GameSettings.SETTING.EASY_ARM_CONTROL] = "Setting \'Easy Arm Control\': %s",
		[GameSettings.SETTING.INVERT_Y_LOOK] = "Setting \'Invert Y-Look\': %s",
		[GameSettings.SETTING.SHOW_FIELD_INFO] = "Setting \'Show Field-Info\': %s"
	}
	return v5
end
function GameSettings.setDefault(p6)
	p6.joinGame = {}
	p6.createGame = {}
	p6[GameSettings.SETTING.FRAME_LIMIT] = Platform.defaultFrameLimit
	p6[GameSettings.SETTING.DEFAULT_SERVER_PORT] = 10823
	p6[GameSettings.SETTING.MAX_NUM_MIRRORS] = Platform.maxNumMirrors
	p6[GameSettings.SETTING.LIGHTS_PROFILE] = GS_PROFILE_VERY_HIGH
	p6[GameSettings.SETTING.REAL_BEACON_LIGHTS] = false
	p6[GameSettings.SETTING.MP_LANGUAGE] = getSystemLanguage()
	p6[GameSettings.SETTING.CAMERA_BOBBING] = true
	p6[GameSettings.SETTING.INPUT_HELP_MODE] = GS_INPUT_HELP_MODE_AUTO
	p6[GameSettings.SETTING.IS_SOUND_PLAYER_STREAM_ACCESS_ALLOWED] = false
	p6[GameSettings.SETTING.GAMEPAD_ENABLED_SET_BY_USER] = false
	p6[GameSettings.SETTING.IS_GAMEPAD_ENABLED] = true
	p6[GameSettings.SETTING.JOYSTICK_VIBRATION_ENABLED] = false
	p6[GameSettings.SETTING.GYROSCOPE_STEERING] = Platform.gameplay.defaultGyroscopeSteering
	p6[GameSettings.SETTING.HEAD_TRACKING_ENABLED_SET_BY_USER] = false
	p6[GameSettings.SETTING.IS_HEAD_TRACKING_ENABLED] = true
	p6[GameSettings.SETTING.FORCE_FEEDBACK] = 0.5
	p6[GameSettings.SETTING.MOTOR_STOP_TIMER_DURATION] = 30000
	p6[GameSettings.SETTING.HORSE_ABANDON_TIMER_DURATION] = 30000
	p6[GameSettings.SETTING.FOV_Y] = g_fovYDefault
	p6[GameSettings.SETTING.FOV_Y_PLAYER_FIRST_PERSON] = 1.0471975511965976
	p6[GameSettings.SETTING.FOV_Y_PLAYER_THIRD_PERSON] = 0.6981317007977318
	p6[GameSettings.SETTING.UI_SCALE] = 1
	p6[GameSettings.SETTING.HINTS] = true
	p6[GameSettings.SETTING.CAMERA_TILTING] = Platform.gameplay.defaultCameraTilt
	p6[GameSettings.SETTING.SHOW_ALL_MODS] = true
	p6[GameSettings.SETTING.ONLINE_PRESENCE_NAME] = string.trim(getUserName())
	p6[GameSettings.SETTING.LAST_PLAYER_STYLE_MALE] = true
	p6[GameSettings.SETTING.INVERT_Y_LOOK] = false
	p6[GameSettings.SETTING.STEERING_ASSIST_LINES] = true
	p6[GameSettings.SETTING.VOLUME_MASTER] = 1
	p6[GameSettings.SETTING.VOLUME_MUSIC] = 0.45
	p6[GameSettings.SETTING.VOLUME_VEHICLE] = 1
	p6[GameSettings.SETTING.VOLUME_CHARACTER] = 0.7
	p6[GameSettings.SETTING.VOLUME_ENVIRONMENT] = 0.7
	p6[GameSettings.SETTING.VOLUME_RADIO] = 0.6
	p6[GameSettings.SETTING.VOLUME_GUI] = 0.5
	p6[GameSettings.SETTING.VOLUME_NO_FOCUS] = 1
	p6[GameSettings.SETTING.VOLUME_VOICE] = 1
	p6[GameSettings.SETTING.VOLUME_VOICE_INPUT] = 1
	p6[GameSettings.SETTING.VOICE_MODE] = VoiceChatUtil.MODE.VOICE_ACTIVITY
	p6[GameSettings.SETTING.VOICE_INPUT_SENSITIVITY] = 1
	p6[GameSettings.SETTING.RADIO_IS_ACTIVE] = false
	p6[GameSettings.SETTING.RADIO_VEHICLE_ONLY] = true
	p6[GameSettings.SETTING.SHOW_HELP_ICONS] = true
	p6[GameSettings.SETTING.USE_COLORBLIND_MODE] = false
	p6[GameSettings.SETTING.EASY_ARM_CONTROL] = true
	p6[GameSettings.SETTING.MONEY_UNIT] = GS_MONEY_EURO
	if GS_IS_MOBILE_VERSION then
		p6[GameSettings.SETTING.MONEY_UNIT] = GS_MONEY_DOLLAR
	end
	p6[GameSettings.SETTING.USE_MILES] = false
	p6[GameSettings.SETTING.USE_FAHRENHEIT] = false
	p6[GameSettings.SETTING.USE_ACRE] = false
	p6[GameSettings.SETTING.SHOW_TRIGGER_MARKER] = true
	p6[GameSettings.SETTING.SHOW_HELP_TRIGGER] = true
	p6[GameSettings.SETTING.SHOW_FIELD_INFO] = true
	p6[GameSettings.SETTING.RESET_CAMERA] = false
	p6[GameSettings.SETTING.USE_WORLD_CAMERA] = true
	p6[GameSettings.SETTING.ACTIVE_SUSPENSION_CAMERA] = false
	p6[GameSettings.SETTING.CAMERA_CHECK_COLLISION] = true
	p6[GameSettings.SETTING.SHOW_HELP_MENU] = true
	p6[GameSettings.SETTING.IS_TRAIN_TABBABLE] = true
	p6[GameSettings.SETTING.CAMERA_SENSITIVITY] = 1
	p6[GameSettings.SETTING.CAMERA_ZOOM_SENSITIVITY] = 1
	p6[GameSettings.SETTING.JOYSTICK_DEADZONE] = 0.05
	p6[GameSettings.SETTING.VEHICLE_ARM_SENSITIVITY] = 1
	p6[GameSettings.SETTING.REAL_BEACON_LIGHT_BRIGHTNESS] = 1
	p6[GameSettings.SETTING.STEERING_BACK_SPEED] = 7
	p6[GameSettings.SETTING.STEERING_SENSITIVITY] = GS_IS_MOBILE_VERSION and 0.8 or 1
	p6[GameSettings.SETTING.DIRECTION_CHANGE_MODE] = VehicleMotor.DIRECTION_CHANGE_MODE_AUTOMATIC
	p6[GameSettings.SETTING.GEAR_SHIFT_MODE] = VehicleMotor.SHIFT_MODE_AUTOMATIC
	p6[GameSettings.SETTING.HUD_SPEED_GAUGE] = SpeedMeterDisplay.GAUGE_MODE_RPM
	p6[GameSettings.SETTING.WOOD_HARVESTER_AUTO_CUT] = true
	p6[GameSettings.SETTING.INGAME_MAP_FILTER] = 0
	p6[GameSettings.SETTING.INGAME_MAP_SOIL_FILTER] = bitNOT(0)
	p6[GameSettings.SETTING.INGAME_MAP_GROWTH_FILTER] = bitNOT(0)
	p6[GameSettings.SETTING.INGAME_MAP_HOTSPOT_FILTER] = bitNOT(0)
	p6[GameSettings.SETTING.INGAME_MAP_FRUIT_FILTER] = ""
	p6[GameSettings.SETTING.INGAME_MAP_STATE] = GS_IS_MOBILE_VERSION and IngameMapState.OFF or IngameMapState.MINIMAP_ROUND
	p6[GameSettings.SETTING.SHOWN_FREEMODE_WARNING] = false
	p6[GameSettings.SETTING.SHOW_MULTIPLAYER_NAMES] = true
	if GS_IS_CONSOLE_VERSION then
		p6[GameSettings.SETTING.IS_GAMEPAD_ENABLED] = true
		p6[GameSettings.SETTING.IS_HEAD_TRACKING_ENABLED] = false
		p6[GameSettings.SETTING.INPUT_HELP_MODE] = GS_INPUT_HELP_MODE_GAMEPAD
	end
end
function GameSettings.getTableValue(p7, p8, p9)
	if p8 == nil then
		Logging.error("GameSetting table name missing or nil!")
		return false
	end
	if p9 ~= nil then
		return p7[p8][p9]
	end
	Logging.error("GameSetting table tableKey missing or nil!")
	return false
end
function GameSettings.setTableValue(p10, p11, p12, p13, p14)
	if p11 == nil then
		printError("Error: GameSetting table name missing or nil!")
		return false
	end
	if p12 == nil then
		printError("Error: GameSetting tableKey missing or nil!")
		return false
	end
	if p13 == nil then
		printError("Error: GameSetting table value missing or nil for index \'" .. p12 .. "\'!")
		return false
	end
	if p10[p11] == nil then
		printError("Error: GameSetting table \'" .. p11 .. "\' not found!")
		return false
	end
	p10[p11][p12] = p13
	if p14 then
		p10:save()
	end
	return true
end
function GameSettings.getValue(p15, p16)
	if p16 ~= nil then
		return p15[p16]
	end
	Logging.error("GameSetting %s missing or nil!", p16)
	printCallstack()
	return false
end
function GameSettings.setValue(p17, p18, p19, p20)
	if p18 == nil then
		Logging.error("GameSetting %s missing or nil!", p18)
		printCallstack()
		return false
	end
	if p19 == nil then
		Logging.error("GameSetting value missing or nil for setting \'%s\'!", p18)
		printCallstack()
		return false
	end
	if p17[p18] == nil then
		Logging.error("GameSetting \'" .. p18 .. "\' not found!")
		return false
	end
	p17[p18] = p19
	if p17.printedSettingsChanges[p18] ~= nil then
		print("  " .. string.format(p17.printedSettingsChanges[p18], p19))
	end
	if p17.notifyOnChange then
		local v21 = MessageType.SETTING_CHANGED[p18]
		g_messageCenter:publish(v21, p19)
	end
	if p20 then
		p17:save()
	end
	return true
end
function GameSettings.loadFromXML(p22, p23)
	if p23 ~= nil then
		if GS_PLATFORM_PC then
			local v24 = GameSettings.SETTING.DEFAULT_SERVER_PORT
			local v25 = getXMLInt(p23, "gameSettings.defaultMultiplayerPort") or 10823
			p22:setValue(v24, (math.clamp(v25, 0, 65535)))
			local v26 = GameSettings.PERFORMANCE_CLASS_PRESETS[Utils.getPerformanceClassId()]
			local v27 = GameSettings.SETTING.MAX_NUM_MIRRORS
			local v28 = getXMLInt(p23, "gameSettings.maxNumMirrors") or v26.maxNumMirrors
			p22:setValue(v27, (math.clamp(v28, 0, 7)))
			local v29 = GameSettings.SETTING.LIGHTS_PROFILE
			local v30 = getXMLInt(p23, "gameSettings.lightsProfile") or v26.lightsProfile
			local v31 = GS_PROFILE_LOW
			local v32 = GS_PROFILE_ULTRA
			p22:setValue(v29, (math.clamp(v30, v31, v32)))
			local v33 = getXMLBool(p23, "gameSettings.isHeadTrackingEnabled")
			if v33 ~= nil then
				p22:setValue(GameSettings.SETTING.HEAD_TRACKING_ENABLED_SET_BY_USER, true)
				p22:setValue(GameSettings.SETTING.IS_HEAD_TRACKING_ENABLED, v33)
			end
			p22:setValue(GameSettings.SETTING.IS_SOUND_PLAYER_STREAM_ACCESS_ALLOWED, Utils.getNoNil(getXMLBool(p23, "gameSettings.soundPlayer#allowStreams"), p22[GameSettings.SETTING.IS_SOUND_PLAYER_STREAM_ACCESS_ALLOWED]))
			local v34 = getXMLInt(p23, "gameSettings.motorStopTimerDuration")
			if v34 ~= nil then
				p22:setValue(GameSettings.SETTING.MOTOR_STOP_TIMER_DURATION, v34 * 1000)
			end
			local v35 = getXMLInt(p23, "gameSettings.horseAbandonTimerDuration")
			if v35 ~= nil then
				p22:setValue(GameSettings.SETTING.HORSE_ABANDON_TIMER_DURATION, v35 * 1000)
			end
			local v36 = getXMLBool(p23, "gameSettings.isGamepadEnabled")
			if v36 ~= nil then
				p22:setValue(GameSettings.SETTING.GAMEPAD_ENABLED_SET_BY_USER, true)
				p22:setValue(GameSettings.SETTING.IS_GAMEPAD_ENABLED, v36)
			end
		end
		p22:setValue(GameSettings.SETTING.REAL_BEACON_LIGHTS, Utils.getNoNil(getXMLBool(p23, "gameSettings.realBeaconLights"), p22[GameSettings.SETTING.REAL_BEACON_LIGHTS]))
		if GS_PLATFORM_PC then
			local v37 = getXMLInt(p23, "gameSettings.mpLanguage")
			if v37 ~= nil and (v37 >= 0 and v37 <= getNumOfLanguages() - 1) then
				p22:setValue(GameSettings.SETTING.MP_LANGUAGE, v37)
			end
			local v38 = getXMLInt(p23, "gameSettings.inputHelpMode")
			if v38 ~= nil then
				if v38 == GS_INPUT_HELP_MODE_AUTO or (v38 == GS_INPUT_HELP_MODE_GAMEPAD or v38 == GS_INPUT_HELP_MODE_KEYBOARD) then
					p22:setValue(GameSettings.SETTING.INPUT_HELP_MODE, v38)
					if not getGamepadEnabled() and v38 == GS_INPUT_HELP_MODE_GAMEPAD then
						p22:setValue(GameSettings.SETTING.INPUT_HELP_MODE, GS_INPUT_HELP_MODE_AUTO)
					end
				else
					printWarning("Warning: Invalid input help mode")
				end
			end
		end
		local v39 = getXMLFloat(p23, "gameSettings.fovY")
		if v39 ~= nil then
			local v40 = GameSettings.SETTING.FOV_Y
			local v41 = math.rad(v39)
			local v42 = g_fovYMin
			local v43 = g_fovYMax
			p22:setValue(v40, (math.clamp(v41, v42, v43)))
		end
		local v44 = getXMLFloat(p23, "gameSettings.fovY#playerFirstPerson")
		if v44 ~= nil then
			local v45 = GameSettings.SETTING.FOV_Y_PLAYER_FIRST_PERSON
			local v46 = math.rad(v44)
			local v47 = g_fovYMin
			local v48 = g_fovYMax
			p22:setValue(v45, (math.clamp(v46, v47, v48)))
		end
		local v49 = getXMLFloat(p23, "gameSettings.fovY#playerThirdPerson")
		if v49 ~= nil then
			local v50 = GameSettings.SETTING.FOV_Y_PLAYER_THIRD_PERSON
			local v51 = math.rad(v49)
			local v52 = g_fovYMin
			local v53 = g_fovYMax
			p22:setValue(v50, (math.clamp(v51, v52, v53)))
		end
		local v54 = getXMLFloat(p23, "gameSettings.uiScale")
		if v54 ~= nil then
			p22:setValue(GameSettings.SETTING.UI_SCALE, (math.clamp(v54, 0.5, 1.5)))
		end
		local v55 = getXMLBool(p23, "gameSettings.showAllMods")
		if v55 ~= nil then
			p22:setValue(GameSettings.SETTING.SHOW_ALL_MODS, v55)
		end
		if not GS_IS_CONSOLE_VERSION then
			local v56 = getXMLString(p23, "gameSettings.onlinePresenceName")
			if v56 ~= nil then
				if v56 == "" then
					v56 = string.trim(getUserName())
				end
				p22:setValue(GameSettings.SETTING.ONLINE_PRESENCE_NAME, v56)
			end
		end
		p22:setValue(GameSettings.SETTING.LAST_PLAYER_STYLE_MALE, Utils.getNoNil(getXMLBool(p23, "gameSettings.player#lastPlayerStyleMale"), p22[GameSettings.SETTING.LAST_PLAYER_STYLE_MALE]))
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "password", getXMLString, p23, "gameSettings.joinGame#password")
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "includePasswordProtected", getXMLBool, p23, "gameSettings.joinGame#includePasswordProtected")
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "includeFullGames", getXMLBool, p23, "gameSettings.joinGame#includeFullGames")
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "onlyWithAllModsAvailable", getXMLBool, p23, "gameSettings.joinGame#onlyWithAllModsAvailable")
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "serverName", getXMLString, p23, "gameSettings.joinGame#serverName")
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "mapId", getXMLString, p23, "gameSettings.joinGame#mapId")
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "language", getXMLInt, p23, "gameSettings.joinGame#language")
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "capacity", getXMLInt, p23, "gameSettings.joinGame#capacity")
		p22:setTableValueFromXML(GameSettings.SETTING.JOIN_GAME, "allowCrossPlay", getXMLBool, p23, "gameSettings.joinGame#allowCrossPlay")
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "password", getXMLString, p23, "gameSettings.createGame#password")
		if not GS_IS_CONSOLE_VERSION then
			p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "serverName", getXMLString, p23, "gameSettings.createGame#name")
		end
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "port", getXMLInt, p23, "gameSettings.createGame#port")
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "autoAccept", getXMLBool, p23, "gameSettings.createGame#autoAccept")
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "autoSave", getXMLBool, p23, "gameSettings.createGame#autoSave")
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "allowOnlyFriends", getXMLBool, p23, "gameSettings.createGame#allowOnlyFriends")
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "allowCrossPlay", getXMLBool, p23, "gameSettings.createGame#allowCrossPlay")
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "capacity", getXMLInt, p23, "gameSettings.createGame#capacity")
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "bandwidth", getXMLInt, p23, "gameSettings.createGame#bandwidth")
		p22:setTableValueFromXML(GameSettings.SETTING.CREATE_GAME, "allowCrossPlay", getXMLBool, p23, "gameSettings.createGame#allowCrossPlay")
		p22:setValue(GameSettings.SETTING.IS_TRAIN_TABBABLE, Utils.getNoNil(getXMLBool(p23, "gameSettings.isTrainTabbable"), p22[GameSettings.SETTING.IS_TRAIN_TABBABLE]))
		p22:setValue(GameSettings.SETTING.RADIO_VEHICLE_ONLY, Utils.getNoNil(getXMLBool(p23, "gameSettings.radioVehicleOnly"), p22[GameSettings.SETTING.RADIO_VEHICLE_ONLY]))
		p22:setValue(GameSettings.SETTING.RADIO_IS_ACTIVE, Utils.getNoNil(getXMLBool(p23, "gameSettings.radioIsActive"), p22[GameSettings.SETTING.RADIO_IS_ACTIVE]))
		p22:setValue(GameSettings.SETTING.USE_COLORBLIND_MODE, Utils.getNoNil(getXMLBool(p23, "gameSettings.useColorblindMode"), p22[GameSettings.SETTING.USE_COLORBLIND_MODE]))
		p22:setValue(GameSettings.SETTING.EASY_ARM_CONTROL, Utils.getNoNil(getXMLBool(p23, "gameSettings.easyArmControl"), p22[GameSettings.SETTING.EASY_ARM_CONTROL]))
		p22:setValue(GameSettings.SETTING.SHOW_TRIGGER_MARKER, Utils.getNoNil(getXMLBool(p23, "gameSettings.showTriggerMarker"), p22[GameSettings.SETTING.SHOW_TRIGGER_MARKER]))
		p22:setValue(GameSettings.SETTING.SHOW_HELP_TRIGGER, Utils.getNoNil(getXMLBool(p23, "gameSettings.showHelpTrigger"), p22[GameSettings.SETTING.SHOW_HELP_TRIGGER]))
		p22:setValue(GameSettings.SETTING.SHOW_FIELD_INFO, Utils.getNoNil(getXMLBool(p23, "gameSettings.showFieldInfo"), p22[GameSettings.SETTING.SHOW_FIELD_INFO]))
		p22:setValue(GameSettings.SETTING.RESET_CAMERA, Utils.getNoNil(getXMLBool(p23, "gameSettings.resetCamera"), p22[GameSettings.SETTING.RESET_CAMERA]))
		p22:setValue(GameSettings.SETTING.ACTIVE_SUSPENSION_CAMERA, Utils.getNoNil(getXMLBool(p23, "gameSettings.activeSuspensionCamera"), p22[GameSettings.SETTING.ACTIVE_SUSPENSION_CAMERA]))
		p22:setValue(GameSettings.SETTING.CAMERA_CHECK_COLLISION, Utils.getNoNil(getXMLBool(p23, "gameSettings.cameraCheckCollision"), p22[GameSettings.SETTING.CAMERA_CHECK_COLLISION]))
		p22:setValue(GameSettings.SETTING.USE_WORLD_CAMERA, Utils.getNoNil(getXMLBool(p23, "gameSettings.useWorldCamera"), p22[GameSettings.SETTING.USE_WORLD_CAMERA]))
		p22:setValue(GameSettings.SETTING.INVERT_Y_LOOK, Utils.getNoNil(getXMLBool(p23, "gameSettings.invertYLook"), p22[GameSettings.SETTING.INVERT_Y_LOOK]))
		p22:setValue(GameSettings.SETTING.STEERING_ASSIST_LINES, Utils.getNoNil(getXMLBool(p23, "gameSettings.steeringAssistLines"), p22[GameSettings.SETTING.STEERING_ASSIST_LINES]))
		p22:setValue(GameSettings.SETTING.SHOW_HELP_ICONS, Utils.getNoNil(getXMLBool(p23, "gameSettings.showHelpIcons"), p22[GameSettings.SETTING.SHOW_HELP_ICONS]))
		p22:setValue(GameSettings.SETTING.SHOW_HELP_MENU, Utils.getNoNil(getXMLBool(p23, "gameSettings.showHelpMenu"), p22[GameSettings.SETTING.SHOW_HELP_MENU]))
		p22:setValue(GameSettings.SETTING.VOLUME_RADIO, Utils.getNoNil(getXMLFloat(p23, "gameSettings.volume.radio"), p22[GameSettings.SETTING.VOLUME_RADIO]))
		p22:setValue(GameSettings.SETTING.VOLUME_VEHICLE, Utils.getNoNil(getXMLFloat(p23, "gameSettings.volume.vehicle"), p22[GameSettings.SETTING.VOLUME_VEHICLE]))
		p22:setValue(GameSettings.SETTING.VOLUME_ENVIRONMENT, Utils.getNoNil(getXMLFloat(p23, "gameSettings.volume.environment"), p22[GameSettings.SETTING.VOLUME_ENVIRONMENT]))
		p22:setValue(GameSettings.SETTING.VOLUME_CHARACTER, Utils.getNoNil(getXMLFloat(p23, "gameSettings.volume.character"), p22[GameSettings.SETTING.VOLUME_CHARACTER]))
		p22:setValue(GameSettings.SETTING.VOLUME_GUI, Utils.getNoNil(getXMLFloat(p23, "gameSettings.volume.gui"), p22[GameSettings.SETTING.VOLUME_GUI]))
		p22:setValue(GameSettings.SETTING.VOLUME_NO_FOCUS, getInactiveWindowAudioVolume())
		p22:setValue(GameSettings.SETTING.VOLUME_MASTER, getMasterVolume())
		p22:setValue(GameSettings.SETTING.VOLUME_MUSIC, Utils.getNoNil(getXMLFloat(p23, "gameSettings.volume.music"), p22[GameSettings.SETTING.VOLUME_MUSIC]))
		p22:setValue(GameSettings.SETTING.VOLUME_VOICE, Utils.getNoNil(getXMLFloat(p23, "gameSettings.volume.voice"), p22[GameSettings.SETTING.VOLUME_VOICE]))
		p22:setValue(GameSettings.SETTING.VOLUME_VOICE_INPUT, Utils.getNoNil(getXMLFloat(p23, "gameSettings.volume.voiceInput"), p22[GameSettings.SETTING.VOLUME_VOICE_INPUT]))
		p22:setValue(GameSettings.SETTING.VOICE_MODE, Utils.getNoNil(getXMLInt(p23, "gameSettings.voice#mode"), p22[GameSettings.SETTING.VOICE_MODE]))
		p22:setValue(GameSettings.SETTING.VOICE_INPUT_SENSITIVITY, Utils.getNoNil(getXMLInt(p23, "gameSettings.voice#inputSensitivity"), p22[GameSettings.SETTING.VOICE_INPUT_SENSITIVITY]))
		p22:setValue(GameSettings.SETTING.FORCE_FEEDBACK, Utils.getNoNil(getXMLFloat(p23, "gameSettings.forceFeedback"), p22[GameSettings.SETTING.FORCE_FEEDBACK]))
		p22:setValue(GameSettings.SETTING.SHOWN_FREEMODE_WARNING, Utils.getNoNil(getXMLBool(p23, "gameSettings.shownFreemodeWarning"), p22[GameSettings.SETTING.SHOWN_FREEMODE_WARNING]))
		p22:setValue(GameSettings.SETTING.SHOW_MULTIPLAYER_NAMES, Utils.getNoNil(getXMLBool(p23, "gameSettings.showMultiplayerNames"), p22[GameSettings.SETTING.SHOW_MULTIPLAYER_NAMES]))
		p22:setValue(GameSettings.SETTING.CAMERA_SENSITIVITY, Utils.getNoNil(getXMLFloat(p23, "gameSettings.cameraSensitivity"), p22[GameSettings.SETTING.CAMERA_SENSITIVITY]))
		p22:setValue(GameSettings.SETTING.CAMERA_ZOOM_SENSITIVITY, Utils.getNoNil(getXMLFloat(p23, "gameSettings.cameraZoomSensitivity"), p22[GameSettings.SETTING.CAMERA_ZOOM_SENSITIVITY]))
		p22:setValue(GameSettings.SETTING.VEHICLE_ARM_SENSITIVITY, Utils.getNoNil(getXMLFloat(p23, "gameSettings.vehicleArmSensitivity"), p22[GameSettings.SETTING.VEHICLE_ARM_SENSITIVITY]))
		p22:setValue(GameSettings.SETTING.REAL_BEACON_LIGHT_BRIGHTNESS, Utils.getNoNil(getXMLFloat(p23, "gameSettings.realBeaconLightBrightness"), p22[GameSettings.SETTING.REAL_BEACON_LIGHT_BRIGHTNESS]))
		p22:setValue(GameSettings.SETTING.STEERING_BACK_SPEED, Utils.getNoNil(getXMLFloat(p23, "gameSettings.steeringBackSpeed"), p22[GameSettings.SETTING.STEERING_BACK_SPEED]))
		p22:setValue(GameSettings.SETTING.STEERING_SENSITIVITY, Utils.getNoNil(getXMLFloat(p23, "gameSettings.steeringSensitivity"), p22[GameSettings.SETTING.STEERING_SENSITIVITY]))
		p22:setValue(GameSettings.SETTING.DIRECTION_CHANGE_MODE, Utils.getNoNil(getXMLFloat(p23, "gameSettings.directionChangeMode"), p22[GameSettings.SETTING.DIRECTION_CHANGE_MODE]))
		p22:setValue(GameSettings.SETTING.GEAR_SHIFT_MODE, Utils.getNoNil(getXMLFloat(p23, "gameSettings.gearShiftMode"), p22[GameSettings.SETTING.GEAR_SHIFT_MODE]))
		p22:setValue(GameSettings.SETTING.HUD_SPEED_GAUGE, Utils.getNoNil(getXMLFloat(p23, "gameSettings.hudSpeedGauge"), p22[GameSettings.SETTING.HUD_SPEED_GAUGE]))
		p22:setValue(GameSettings.SETTING.WOOD_HARVESTER_AUTO_CUT, Utils.getNoNil(getXMLBool(p23, "gameSettings.woodHarvesterAutoCut"), p22[GameSettings.SETTING.WOOD_HARVESTER_AUTO_CUT]))
		p22:setValue(GameSettings.SETTING.INGAME_MAP_STATE, Utils.getNoNil(IngameMapState.getByName(getXMLString(p23, "gameSettings.ingameMapState")), p22[GameSettings.SETTING.INGAME_MAP_STATE]))
		p22:setValue(GameSettings.SETTING.INGAME_MAP_FILTER, Utils.getNoNil(getXMLUInt(p23, "gameSettings.ingameMapFilters"), p22[GameSettings.SETTING.INGAME_MAP_FILTER]))
		p22:setValue(GameSettings.SETTING.INGAME_MAP_GROWTH_FILTER, Utils.getNoNil(getXMLUInt(p23, "gameSettings.ingameMapGrowthFilter"), p22[GameSettings.SETTING.INGAME_MAP_GROWTH_FILTER]))
		p22:setValue(GameSettings.SETTING.INGAME_MAP_SOIL_FILTER, Utils.getNoNil(getXMLUInt(p23, "gameSettings.ingameMapSoilFilter"), p22[GameSettings.SETTING.INGAME_MAP_SOIL_FILTER]))
		p22:setValue(GameSettings.SETTING.INGAME_MAP_HOTSPOT_FILTER, Utils.getNoNil(getXMLUInt(p23, "gameSettings.ingameMapHotspotFilter"), p22[GameSettings.SETTING.INGAME_MAP_HOTSPOT_FILTER]))
		p22:setValue(GameSettings.SETTING.INGAME_MAP_FRUIT_FILTER, Utils.getNoNil(getXMLString(p23, "gameSettings.ingameMapFruitFilter"), p22[GameSettings.SETTING.INGAME_MAP_FRUIT_FILTER]))
		p22:setValue(GameSettings.SETTING.MONEY_UNIT, Utils.getNoNil(getXMLInt(p23, "gameSettings.units.money"), p22[GameSettings.SETTING.MONEY_UNIT]))
		p22:setValue(GameSettings.SETTING.USE_MILES, Utils.getNoNil(getXMLBool(p23, "gameSettings.units.miles"), p22[GameSettings.SETTING.USE_MILES]))
		p22:setValue(GameSettings.SETTING.USE_FAHRENHEIT, Utils.getNoNil(getXMLBool(p23, "gameSettings.units.fahrenheit"), p22[GameSettings.SETTING.USE_FAHRENHEIT]))
		p22:setValue(GameSettings.SETTING.USE_ACRE, Utils.getNoNil(getXMLBool(p23, "gameSettings.units.acre"), p22[GameSettings.SETTING.USE_ACRE]))
		p22:setValue(GameSettings.SETTING.GYROSCOPE_STEERING, Utils.getNoNil(getXMLBool(p23, "gameSettings.gyroscopeSteering"), p22[GameSettings.SETTING.GYROSCOPE_STEERING]))
		p22:setValue(GameSettings.SETTING.HINTS, Utils.getNoNil(getXMLBool(p23, "gameSettings.hints"), p22[GameSettings.SETTING.HINTS]))
		p22:setValue(GameSettings.SETTING.CAMERA_TILTING, Utils.getNoNil(getXMLBool(p23, "gameSettings.cameraTilting"), p22[GameSettings.SETTING.CAMERA_TILTING]))
		p22:setValue(GameSettings.SETTING.CAMERA_BOBBING, Utils.getNoNil(getXMLBool(p23, "gameSettings.cameraBobbing"), p22[GameSettings.SETTING.CAMERA_BOBBING]))
		if Platform.hasAdjustableFrameLimit then
			local v57 = getXMLInt(p23, "gameSettings.frameLimit") or p22[GameSettings.SETTING.FRAME_LIMIT]
			local v58 = false
			for _, v59 in ipairs(p22.frameLimitValues) do
				if v59 == v57 then
					v58 = true
					break
				end
			end
			if not v58 then
				v57 = p22[GameSettings.SETTING.FRAME_LIMIT]
			end
			p22:setValue(GameSettings.SETTING.FRAME_LIMIT, v57)
		end
		local v60 = XMLFile.wrap(p23, GameSettings.xmlSchema)
		p22.lastCreatedLicensePlate = g_licensePlateManager.loadLicensePlateDataFromXML(v60, "gameSettings.lastCreatedLicensePlate", true)
		if v60:hasProperty("gameSettings.lastPlayerStyle") then
			local v61 = PlayerStyle.new()
			if v61:loadFromXMLFile(v60, "gameSettings.lastPlayerStyle") then
				p22.lastPlayerStyle = v61
			else
				v61:delete()
			end
		end
		v60:delete()
		p22.notifyOnChange = true
	end
end
function GameSettings.setTableValueFromXML(p62, p63, p64, p65, p66, p67)
	local v68 = p65(p66, p67)
	if v68 ~= nil then
		p62:setTableValue(p63, p64, v68)
	end
end
function GameSettings.save(p69)
	p69:saveToXMLFile(g_savegameXML)
end
function GameSettings.saveToXMLFile(p70, p71)
	if p71 ~= nil then
		setXMLBool(p71, "gameSettings.invertYLook", p70[GameSettings.SETTING.INVERT_Y_LOOK])
		setXMLBool(p71, "gameSettings.isHeadTrackingEnabled", p70[GameSettings.SETTING.IS_HEAD_TRACKING_ENABLED])
		setXMLFloat(p71, "gameSettings.forceFeedback", p70[GameSettings.SETTING.FORCE_FEEDBACK])
		setXMLBool(p71, "gameSettings.isGamepadEnabled", p70[GameSettings.SETTING.IS_GAMEPAD_ENABLED])
		setXMLFloat(p71, "gameSettings.cameraSensitivity", p70[GameSettings.SETTING.CAMERA_SENSITIVITY])
		setXMLFloat(p71, "gameSettings.vehicleArmSensitivity", p70[GameSettings.SETTING.VEHICLE_ARM_SENSITIVITY])
		setXMLFloat(p71, "gameSettings.realBeaconLightBrightness", p70[GameSettings.SETTING.REAL_BEACON_LIGHT_BRIGHTNESS])
		setXMLFloat(p71, "gameSettings.steeringBackSpeed", p70[GameSettings.SETTING.STEERING_BACK_SPEED])
		setXMLFloat(p71, "gameSettings.steeringSensitivity", p70[GameSettings.SETTING.STEERING_SENSITIVITY])
		setXMLInt(p71, "gameSettings.inputHelpMode", p70[GameSettings.SETTING.INPUT_HELP_MODE])
		setXMLBool(p71, "gameSettings.easyArmControl", p70[GameSettings.SETTING.EASY_ARM_CONTROL])
		setXMLBool(p71, "gameSettings.gyroscopeSteering", p70[GameSettings.SETTING.GYROSCOPE_STEERING])
		setXMLBool(p71, "gameSettings.hints", p70[GameSettings.SETTING.HINTS])
		setXMLBool(p71, "gameSettings.cameraTilting", p70[GameSettings.SETTING.CAMERA_TILTING])
		if Platform.hasAdjustableFrameLimit then
			setXMLInt(p71, "gameSettings.frameLimit", p70[GameSettings.SETTING.FRAME_LIMIT])
		end
		setXMLBool(p71, "gameSettings.showAllMods", p70[GameSettings.SETTING.SHOW_ALL_MODS])
		setXMLString(p71, "gameSettings.onlinePresenceName", p70[GameSettings.SETTING.ONLINE_PRESENCE_NAME])
		setXMLBool(p71, "gameSettings.player#lastPlayerStyleMale", p70[GameSettings.SETTING.LAST_PLAYER_STYLE_MALE])
		setXMLInt(p71, "gameSettings.mpLanguage", p70[GameSettings.SETTING.MP_LANGUAGE])
		p70:setXMLValue(p71, setXMLString, "gameSettings.createGame#password", p70.createGame.password)
		p70:setXMLValue(p71, setXMLString, "gameSettings.createGame#name", p70.createGame.serverName)
		p70:setXMLValue(p71, setXMLInt, "gameSettings.createGame#port", p70.createGame.port)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.createGame#autoAccept", p70.createGame.autoAccept)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.createGame#autoSave", p70.createGame.autoSave)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.createGame#allowOnlyFriends", p70.createGame.allowOnlyFriends)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.createGame#allowCrossPlay", p70.createGame.allowCrossPlay)
		p70:setXMLValue(p71, setXMLInt, "gameSettings.createGame#capacity", p70.createGame.capacity)
		p70:setXMLValue(p71, setXMLInt, "gameSettings.createGame#bandwidth", p70.createGame.bandwidth)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.createGame#allowCrossPlay", p70.createGame.allowCrossPlay)
		p70:setXMLValue(p71, setXMLString, "gameSettings.joinGame#password", p70.joinGame.password)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.joinGame#includePasswordProtected", p70.joinGame.includePasswordProtected)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.joinGame#includeFullGames", p70.joinGame.includeFullGames)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.joinGame#onlyWithAllModsAvailable", p70.joinGame.onlyWithAllModsAvailable)
		p70:setXMLValue(p71, setXMLString, "gameSettings.joinGame#serverName", p70.joinGame.serverName)
		p70:setXMLValue(p71, setXMLString, "gameSettings.joinGame#mapId", p70.joinGame.mapId)
		p70:setXMLValue(p71, setXMLInt, "gameSettings.joinGame#language", p70.joinGame.language)
		p70:setXMLValue(p71, setXMLInt, "gameSettings.joinGame#capacity", p70.joinGame.capacity)
		p70:setXMLValue(p71, setXMLBool, "gameSettings.joinGame#allowCrossPlay", p70.joinGame.allowCrossPlay)
		setXMLFloat(p71, "gameSettings.volume.music", p70[GameSettings.SETTING.VOLUME_MUSIC])
		setXMLFloat(p71, "gameSettings.volume.vehicle", p70[GameSettings.SETTING.VOLUME_VEHICLE])
		setXMLFloat(p71, "gameSettings.volume.environment", p70[GameSettings.SETTING.VOLUME_ENVIRONMENT])
		setXMLFloat(p71, "gameSettings.volume.character", p70[GameSettings.SETTING.VOLUME_CHARACTER])
		setXMLFloat(p71, "gameSettings.volume.radio", p70[GameSettings.SETTING.VOLUME_RADIO])
		setXMLFloat(p71, "gameSettings.volume.gui", p70[GameSettings.SETTING.VOLUME_GUI])
		setXMLFloat(p71, "gameSettings.volume.noFocus", p70[GameSettings.SETTING.VOLUME_NO_FOCUS])
		setXMLFloat(p71, "gameSettings.volume.voice", p70[GameSettings.SETTING.VOLUME_VOICE])
		setXMLFloat(p71, "gameSettings.volume.voiceInput", p70[GameSettings.SETTING.VOLUME_VOICE_INPUT])
		setXMLBool(p71, "gameSettings.soundPlayer#allowStreams", p70[GameSettings.SETTING.IS_SOUND_PLAYER_STREAM_ACCESS_ALLOWED])
		setXMLBool(p71, "gameSettings.radioIsActive", p70[GameSettings.SETTING.RADIO_IS_ACTIVE])
		setXMLBool(p71, "gameSettings.radioVehicleOnly", p70[GameSettings.SETTING.RADIO_VEHICLE_ONLY])
		setXMLInt(p71, "gameSettings.voice#mode", p70[GameSettings.SETTING.VOICE_MODE])
		setXMLInt(p71, "gameSettings.voice#inputSensitivity", p70[GameSettings.SETTING.VOICE_INPUT_SENSITIVITY])
		setXMLInt(p71, "gameSettings.units.money", p70[GameSettings.SETTING.MONEY_UNIT])
		setXMLBool(p71, "gameSettings.units.miles", p70[GameSettings.SETTING.USE_MILES])
		setXMLBool(p71, "gameSettings.units.fahrenheit", p70[GameSettings.SETTING.USE_FAHRENHEIT])
		setXMLBool(p71, "gameSettings.units.acre", p70[GameSettings.SETTING.USE_ACRE])
		setXMLBool(p71, "gameSettings.isTrainTabbable", p70[GameSettings.SETTING.IS_TRAIN_TABBABLE])
		setXMLBool(p71, "gameSettings.showTriggerMarker", p70[GameSettings.SETTING.SHOW_TRIGGER_MARKER])
		setXMLBool(p71, "gameSettings.showHelpTrigger", p70[GameSettings.SETTING.SHOW_HELP_TRIGGER])
		setXMLBool(p71, "gameSettings.showFieldInfo", p70[GameSettings.SETTING.SHOW_FIELD_INFO])
		setXMLBool(p71, "gameSettings.showHelpIcons", p70[GameSettings.SETTING.SHOW_HELP_ICONS])
		setXMLBool(p71, "gameSettings.showHelpMenu", p70[GameSettings.SETTING.SHOW_HELP_MENU])
		setXMLBool(p71, "gameSettings.resetCamera", p70[GameSettings.SETTING.RESET_CAMERA])
		setXMLBool(p71, "gameSettings.activeSuspensionCamera", p70[GameSettings.SETTING.ACTIVE_SUSPENSION_CAMERA])
		setXMLBool(p71, "gameSettings.cameraCheckCollision", p70[GameSettings.SETTING.CAMERA_CHECK_COLLISION])
		setXMLBool(p71, "gameSettings.useWorldCamera", p70[GameSettings.SETTING.USE_WORLD_CAMERA])
		setXMLString(p71, "gameSettings.ingameMapState", IngameMapState.getName(p70[GameSettings.SETTING.INGAME_MAP_STATE]))
		setXMLUInt(p71, "gameSettings.ingameMapFilters", p70[GameSettings.SETTING.INGAME_MAP_FILTER])
		setXMLInt(p71, "gameSettings.directionChangeMode", p70[GameSettings.SETTING.DIRECTION_CHANGE_MODE])
		setXMLInt(p71, "gameSettings.gearShiftMode", p70[GameSettings.SETTING.GEAR_SHIFT_MODE])
		setXMLInt(p71, "gameSettings.hudSpeedGauge", p70[GameSettings.SETTING.HUD_SPEED_GAUGE])
		setXMLBool(p71, "gameSettings.woodHarvesterAutoCut", p70[GameSettings.SETTING.WOOD_HARVESTER_AUTO_CUT])
		setXMLBool(p71, "gameSettings.shownFreemodeWarning", p70[GameSettings.SETTING.SHOWN_FREEMODE_WARNING])
		setXMLBool(p71, "gameSettings.showMultiplayerNames", p70[GameSettings.SETTING.SHOW_MULTIPLAYER_NAMES])
		setXMLUInt(p71, "gameSettings.ingameMapGrowthFilter", p70[GameSettings.SETTING.INGAME_MAP_GROWTH_FILTER])
		setXMLUInt(p71, "gameSettings.ingameMapSoilFilter", p70[GameSettings.SETTING.INGAME_MAP_SOIL_FILTER])
		setXMLUInt(p71, "gameSettings.ingameMapHotspotFilter", p70[GameSettings.SETTING.INGAME_MAP_HOTSPOT_FILTER])
		setXMLString(p71, "gameSettings.ingameMapFruitFilter", p70[GameSettings.SETTING.INGAME_MAP_FRUIT_FILTER])
		setXMLBool(p71, "gameSettings.useColorblindMode", p70[GameSettings.SETTING.USE_COLORBLIND_MODE])
		setXMLInt(p71, "gameSettings.maxNumMirrors", p70[GameSettings.SETTING.MAX_NUM_MIRRORS])
		setXMLInt(p71, "gameSettings.lightsProfile", p70[GameSettings.SETTING.LIGHTS_PROFILE])
		local v72 = setXMLFloat
		local v73 = p70[GameSettings.SETTING.FOV_Y]
		v72(p71, "gameSettings.fovY", (math.deg(v73)))
		local v74 = setXMLFloat
		local v75 = p70[GameSettings.SETTING.FOV_Y_PLAYER_FIRST_PERSON]
		v74(p71, "gameSettings.fovY#playerFirstPerson", (math.deg(v75)))
		local v76 = setXMLFloat
		local v77 = p70[GameSettings.SETTING.FOV_Y_PLAYER_THIRD_PERSON]
		v76(p71, "gameSettings.fovY#playerThirdPerson", (math.deg(v77)))
		setXMLFloat(p71, "gameSettings.uiScale", p70[GameSettings.SETTING.UI_SCALE])
		setXMLBool(p71, "gameSettings.realBeaconLights", p70[GameSettings.SETTING.REAL_BEACON_LIGHTS])
		setXMLBool(p71, "gameSettings.cameraBobbing", p70[GameSettings.SETTING.CAMERA_BOBBING])
		setXMLBool(p71, "gameSettings.steeringAssistLines", p70[GameSettings.SETTING.STEERING_ASSIST_LINES])
		local v78 = XMLFile.wrap(p71, GameSettings.xmlSchema)
		g_licensePlateManager.saveLicensePlateDataToXML(v78, "gameSettings.lastCreatedLicensePlate", p70.lastCreatedLicensePlate, true)
		if p70.lastPlayerStyle ~= nil then
			p70.lastPlayerStyle:saveToXMLFile(v78, "gameSettings.lastPlayerStyle")
		end
		v78:delete()
		saveXMLFile(p71)
		syncProfileFiles()
	end
end
function GameSettings.setXMLValue(_, p79, p80, p81, p82)
	if p82 ~= nil then
		p80(p79, p81, p82)
	end
end
function GameSettings.setLastPlayerStyle(p83, p84)
	if p83.lastPlayerStyle == nil then
		p83.lastPlayerStyle = PlayerStyle.new()
	end
	p83.lastPlayerStyle:copySelectionFrom(p84)
end

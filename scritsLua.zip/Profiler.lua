Profiler = {}
Profiler.IS_INITIALIZED = false
Profiler.IS_READY = false
Profiler.IS_GRID_INITIALIZED = false
Profiler.IS_GRID_FINISHED = false
Profiler.IS_FINISHED = false
Profiler.IS_GPU_BENCHMARK_MODE = false
Profiler.MAP = ""
Profiler.OUTPUT_FILENAME = ""
Profiler.SAMPLING_GRID_SIZE = -1
Profiler.SAMPLING_CUSTOM_NODE = ""
Profiler.MAP_ROOT_NODE = {}
Profiler.PROFILING_ROOT_NODE = {}
Profiler.CURRENT_NODE_ID = 0
Profiler.NUM_NODES = 0
Profiler.GRID_CURRENT_X = 0
Profiler.GRID_CURRENT_Z = 0
Profiler.GRID_CURRENT_ROTATION = 0
Profiler.GRID_ROTATION_DELTA = 1.5707963267948966
Profiler.GRID_ROTATION_NUM_STEPS = 4
Profiler.CAMERA = nil
Profiler.FRAME_COUNT = 0
Profiler.INITIAL_FRAMES_PAUSED = 0
Profiler.STARTUP_FRAME_PAUSE = 500
Profiler.FRAMES_BETWEEN_SAMPLES = 20
Profiler.SAVEGAME_NUMBER = 3
Profiler.MAP_SIZE = 0
function Profiler.init()
	if Profiler.IS_INITIALIZED then
		return
	end
	if not StartParams.getIsSet("profilerStatsMap") then
		return
	end
	if not StartParams.getIsSet("profilerStatsOutputPath") then
		return
	end
	local v1 = Profiler
	if StartParams.getIsSet("profilerStatsSavegameSlot") then
		local v2 = StartParams.getValue
		v3 = tonumber(v2("profilerStatsSavegameSlot"))
		if v3 then
			goto l9
		end
	end
	local v3 = Profiler.SAVEGAME_NUMBER
	::l9::
	v1.SAVEGAME_NUMBER = v3
	Profiler.OUTPUT_DIRECTORY = StartParams.getValue("profilerStatsOutputPath")
	Profiler.IS_GPU_BENCHMARK_MODE = StartParams.getIsSet("profilerGpuBenchmarkMode")
	if Profiler.IS_GPU_BENCHMARK_MODE then
		Profiler.GRID_ROTATION_DELTA = 0.02617993877991494
		Profiler.GRID_ROTATION_NUM_STEPS = 240
		local v4 = StartParams.getValue("gpuBenchmarkOutputFile")
		Profiler.OUTPUT_FILENAME = Profiler.OUTPUT_DIRECTORY .. "/" .. v4
		if StartParams.getIsSet("profilerGpuBenchmarOnly6GBVram") then
			local v5 = profilerGetCurrentGpuVRAM()
			if v5 > 0 and v5 < 5120 then
				Logging.info("Skip benchmark, " .. getGPUName() .. " do not have 6GB ore more VRAM ")
				profilerWriteGpuBenchmarkStats(Profiler.OUTPUT_FILENAME)
				g_pendingExit = true
			end
		end
		if StartParams.getIsSet("gpuBenchmarkMinSpecsGpu") and profilerGetGpuPerformanceRating(getGPUName()) < profilerGetGpuPerformanceRating(StartParams.getValue("gpuBenchmarkMinSpecsGpu")) then
			Logging.info("Skip benchmark, " .. getGPUName() .. " is bellow the min specs GPU " .. StartParams.getValue("gpuBenchmarkMinSpecsGpu"))
			profilerWriteGpuBenchmarkStats(Profiler.OUTPUT_FILENAME)
			g_pendingExit = true
			return
		end
	end
	if folderExists(Profiler.OUTPUT_DIRECTORY) then
		Profiler.MAP = StartParams.getValue("profilerStatsMap")
		local v6
		if StartParams.getIsSet("profilerStatsSamplingGridSize") then
			local v7 = StartParams.getValue
			local v8 = tonumber(v7("profilerStatsSamplingGridSize"))
			if v8 == nil or v8 <= 0 then
				Logging.error("Invalid \'profilerStatsSamplingGridSize\' parameter")
				return
			end
			local v9 = (1 / 0)
			local v10 = nil
			for v11 = 4, 15 do
				local v12 = math.pow(2, v11)
				local v13 = v8 - v12
				local v14 = math.abs(v13)
				if v14 < v9 then
					v10 = v12
					v9 = v14
				end
			end
			if v9 ~= 0 then
				Logging.warning("Grid size \'%s\' was not a power of 2, changed to \'%s\'!", v8, v10)
			end
			Profiler.SAMPLING_GRID_SIZE = v10
			v6 = true
		else
			v6 = false
		end
		if StartParams.getIsSet("profilerStatsSamplingCustomNode") then
			Profiler.SAMPLING_CUSTOM_NODE = StartParams.getValue("profilerStatsSamplingCustomNode")
			v6 = true
		end
		if v6 then
			Profiler.CAMERA = createCamera("cameraProfiler", 1.0471975511965976, 1, 10000)
			g_cameraManager:addCamera(Profiler.CAMERA, nil, false)
			link(getRootNode(), Profiler.CAMERA)
			Logging.info("Profiler initialized successfully")
			Profiler.IS_INITIALIZED = true
		else
			Logging.error("Profiler needs \'profilerStatsSamplingGridSize\' or \'profilerStatsSamplingCustomNode\' parameter set")
		end
	else
		Logging.error("Unable to write to profilerStatsOutputPath %q. Is it an absolute path and does the directory exist?", getAppBasePath() .. Profiler.OUTPUT_DIRECTORY)
		return
	end
end
function Profiler.delete()
	if Profiler.CAMERA ~= nil then
		if g_cameraManager:getActiveCamera() == Profiler.CAMERA then
			g_cameraManager:setDefaultCamera()
		end
		g_cameraManager:removeCamera(Profiler.CAMERA)
		delete(Profiler.CAMERA)
		Profiler.CAMERA = nil
	end
end
function Profiler.startProfiler()
	if Profiler.IS_INITIALIZED then
		Logging.info("######################### Starting Profiler #########################")
		g_gui:setIsMultiplayer(false)
		g_gui:showGui("CareerScreen")
	end
end
function Profiler.setMapRootNode(p15)
	Profiler.MAP_ROOT_NODE = p15
	if Profiler.SAMPLING_CUSTOM_NODE ~= "" then
		Profiler.PROFILING_ROOT_NODE = getChild(p15, Profiler.SAMPLING_CUSTOM_NODE)
		if Profiler.PROFILING_ROOT_NODE == 0 then
			Profiler.IS_INITIALIZED = false
			Logging.error("Profiler SamplingCustomNode \'%s\' not found", Profiler.SAMPLING_CUSTOM_NODE)
			return
		end
		Profiler.NUM_NODES = getNumOfChildren(Profiler.PROFILING_ROOT_NODE)
	end
	if Profiler.IS_GPU_BENCHMARK_MODE or not Profiler.IS_INITIALIZED then
		return
	elseif profilerStatsExportInit() then
		local v16
		if g_currentMission == nil or g_currentMission.missionInfo == nil then
			v16 = ""
		else
			local v17 = g_currentMission.missionInfo.mapId
			v16 = tostring(v17)
		end
		local v18 = Utils.getDirectoryName(getUserProfileAppPath())
		profilerStatsExportAddMetadata("map", v16)
		local v19 = profilerStatsExportAddMetadata
		local v20 = g_currentMission.mapWidth
		v19("mapWidth", (tostring(v20)))
		local v21 = profilerStatsExportAddMetadata
		local v22 = g_currentMission.mapHeight
		v21("mapHeight", (tostring(v22)))
		profilerStatsExportAddMetadata("date", getDate("%Y-%m-%dT%H:%M:%SZ"))
		profilerStatsExportAddMetadata("revision", getEngineRevision())
		profilerStatsExportAddMetadata("defaultNodeType", "grid")
		profilerStatsExportAddMetadata("appName", v18)
		Profiler.OUTPUT_FILENAME = Profiler.OUTPUT_DIRECTORY .. "/" .. getDate("%Y-%m-%d_%H-%M-%S") .. "_" .. v18 .. "_" .. v16 .. ".json"
	else
		Logging.error("Profiler stats export could not be initialized engine side")
		Profiler.IS_INITIALIZED = false
	end
end
function Profiler.setIsReady()
	Profiler.IS_READY = true
end
function Profiler.update(_)
	if Profiler.IS_READY then
		setFramerateLimiter(false, Platform.defaultFrameLimit)
		if Profiler.IS_GRID_INITIALIZED then
			if Profiler.INITIAL_FRAMES_PAUSED <= Profiler.STARTUP_FRAME_PAUSE then
				Profiler.INITIAL_FRAMES_PAUSED = Profiler.INITIAL_FRAMES_PAUSED + 1
				return
			end
			if Profiler.IS_GRID_FINISHED or (Profiler.FRAME_COUNT <= Profiler.FRAMES_BETWEEN_SAMPLES or Profiler.SAMPLING_GRID_SIZE <= 0) then
				if Profiler.FRAME_COUNT > Profiler.FRAMES_BETWEEN_SAMPLES and Profiler.NUM_NODES > 0 then
					if Profiler.CURRENT_NODE_ID == Profiler.NUM_NODES then
						Profiler.finish()
					else
						if Profiler.CURRENT_NODE_ID > 0 and not Profiler.IS_GPU_BENCHMARK_MODE then
							local v23, v24, v25 = getRotation(Profiler.CAMERA)
							profilerStatsExportAddSampleBegin()
							local v26 = profilerStatsExportAddSampleData
							local v27 = v23 * 180 / 3.141592653589793
							v26("rotX", (tostring(v27)))
							local v28 = profilerStatsExportAddSampleData
							local v29 = v24 * 180 / 3.141592653589793
							v28("rotY", (tostring(v29)))
							local v30 = profilerStatsExportAddSampleData
							local v31 = v25 * 180 / 3.141592653589793
							v30("rotZ", (tostring(v31)))
							profilerStatsExportAddSampleData("type", "custom")
							profilerStatsExportAddSampleEnd()
						end
						local v32 = getChildAt(Profiler.PROFILING_ROOT_NODE, Profiler.CURRENT_NODE_ID)
						local v33, v34, v35 = getWorldTranslation(v32)
						local v36, v37, v38 = getWorldRotation(v32)
						setTranslation(Profiler.CAMERA, v33, v34, v35)
						setRotation(Profiler.CAMERA, v36, v37, v38)
						Profiler.CURRENT_NODE_ID = Profiler.CURRENT_NODE_ID + 1
						Profiler.FRAME_COUNT = 0
					end
				elseif Profiler.IS_GRID_FINISHED and Profiler.NUM_NODES == 0 then
					Profiler.finish()
				else
					Profiler.FRAME_COUNT = Profiler.FRAME_COUNT + 1
				end
			end
			if not Profiler.IS_GPU_BENCHMARK_MODE then
				profilerStatsExportAddSampleBegin()
				local v39 = profilerStatsExportAddSampleData
				local v40 = Profiler.GRID_CURRENT_ROTATION * 90
				v39("rotY", (tostring(v40)))
				profilerStatsExportAddSampleEnd()
			end
			local v41 = Profiler.GRID_CURRENT_X - Profiler.MAP_SIZE * 0.5
			local v42 = Profiler.GRID_CURRENT_Z - Profiler.MAP_SIZE * 0.5
			local v43 = Profiler.GRID_CURRENT_ROTATION * Profiler.GRID_ROTATION_DELTA
			if Profiler.IS_GPU_BENCHMARK_MODE then
				v41 = v41 + 5 * Profiler.GRID_CURRENT_ROTATION / Profiler.GRID_ROTATION_NUM_STEPS
				v42 = v42 + 5 * Profiler.GRID_CURRENT_ROTATION / Profiler.GRID_ROTATION_NUM_STEPS
				profilerGpuBenchmarkSample()
			end
			local v44 = getTerrainHeightAtWorldPos(g_terrainNode, v41, 0, v42) + 1.8
			setTranslation(Profiler.CAMERA, v41, v44, v42)
			setRotation(Profiler.CAMERA, 0, v43, 0)
			Profiler.GRID_CURRENT_ROTATION = Profiler.GRID_CURRENT_ROTATION + 1
			if Profiler.GRID_CURRENT_ROTATION == Profiler.GRID_ROTATION_NUM_STEPS then
				Profiler.GRID_CURRENT_ROTATION = 0
				Profiler.GRID_CURRENT_X = Profiler.GRID_CURRENT_X + Profiler.SAMPLING_GRID_SIZE
				if Profiler.GRID_CURRENT_X > Profiler.MAP_SIZE then
					Profiler.GRID_CURRENT_X = Profiler.SAMPLING_GRID_SIZE * 0.5
					Profiler.GRID_CURRENT_Z = Profiler.GRID_CURRENT_Z + Profiler.SAMPLING_GRID_SIZE
					if Profiler.GRID_CURRENT_Z > Profiler.MAP_SIZE then
						if not Profiler.IS_GPU_BENCHMARK_MODE then
							profilerStatsExportAddSampleBegin()
							local v45 = profilerStatsExportAddSampleData
							local v46 = Profiler.GRID_CURRENT_ROTATION * 90
							v45("rotY", (tostring(v46)))
							profilerStatsExportAddSampleEnd()
						end
						Profiler.IS_GRID_FINISHED = true
					end
				end
				if Profiler.IS_GPU_BENCHMARK_MODE then
					Profiler.FRAME_COUNT = 0
					g_currentMission.environment:consoleCommandSetDayTime(8, true)
				end
			end
			if not Profiler.IS_GPU_BENCHMARK_MODE then
				Profiler.FRAME_COUNT = 0
				return
			end
		else
			g_cameraManager:setActiveCamera(Profiler.CAMERA)
			Profiler.MAP_SIZE = g_currentMission.mapHeight
			if Profiler.IS_GPU_BENCHMARK_MODE then
				Profiler.MAP_SIZE = Profiler.MAP_SIZE * 0.666
			end
			if Profiler.SAMPLING_GRID_SIZE > 0 then
				Profiler.GRID_CURRENT_X = Profiler.SAMPLING_GRID_SIZE * 0.5
				Profiler.GRID_CURRENT_Z = Profiler.SAMPLING_GRID_SIZE * 0.5
				local v47 = Profiler.GRID_CURRENT_X - Profiler.MAP_SIZE * 0.5
				local v48 = Profiler.GRID_CURRENT_Z - Profiler.MAP_SIZE * 0.5
				local v49 = getTerrainHeightAtWorldPos(g_terrainNode, v47, 0, v48) + 1.8
				setTranslation(Profiler.CAMERA, v47, v49, v48)
				setRotation(Profiler.CAMERA, 0, 0, 0)
				Profiler.IS_GRID_INITIALIZED = true
			end
			Profiler.IS_READY = true
		end
	end
end
function Profiler.finish()
	Profiler.IS_FINISHED = true
	if not Profiler.IS_GPU_BENCHMARK_MODE and profilerStatsExportFinalize(Profiler.OUTPUT_FILENAME) then
		Logging.info("saved profiler output to %q", getAppBasePath() .. Profiler.OUTPUT_FILENAME)
	end
	if Profiler.IS_GPU_BENCHMARK_MODE and profilerWriteGpuBenchmarkStats(Profiler.OUTPUT_FILENAME) then
		Logging.info("saved GPU benchmark output to %q", getAppBasePath() .. Profiler.OUTPUT_FILENAME)
	end
	Logging.info("######################### Profiler Finished #########################")
	g_pendingExit = true
end

source("dataS/scripts/std.lua")
source("dataS/scripts/StartParams.lua")
source("dataS/scripts/testing.lua")
source("dataS/scripts/events.lua")
source("dataS/scripts/menu.lua")
newGetSafeFrameInsets = getSafeFrameInsets
function getSafeFrameInsets()
	return 0, 0, 0, 0
end
AutoLoadParams = {
	["enable"] = false,
	["x"] = 0,
	["y"] = 0,
	["z"] = 0
}
local _ = debug
debug = nil
GS_PROFILE_VERY_LOW = 1
GS_PROFILE_LOW = 2
GS_PROFILE_MEDIUM = 3
GS_PROFILE_HIGH = 4
GS_PROFILE_VERY_HIGH = 5
GS_PROFILE_ULTRA = 6
g_gameVersion = 3
g_gameVersionNotification = "1.2.1.0"
g_gameVersionDisplay = "1.2.1.0"
g_gameVersionDisplayExtra = ""
g_isDevelopmentConsoleScriptModTesting = false
g_minModDescVersion = 90
g_maxModDescVersion = 92
g_language = 0
g_languageShort = "en"
g_languageSuffix = "_en"
g_showSafeFrame = false
g_noHudModeEnabled = false
g_woodCuttingMarkerEnabled = true
g_isDevelopmentVersion = false
g_isServerStreamingVersion = false
g_addTestCommands = false
g_addCheatCommands = false
g_showDevelopmentWarnings = false
g_appIsSuspended = false
g_networkDebug = false
g_networkDebugPrints = false
g_gameRevision = "000"
g_buildName = ""
g_buildTypeParam = ""
g_showDeeplinkingFailedMessage = false
g_isSignedIn = false
g_settingsLanguageGUI = 0
g_availableLanguageNamesTable = {}
g_availableLanguagesTable = {}
g_fovYDefault = 1.0471975511965976
g_fovYMin = 0.6981317007977318
g_fovYMax = 2.0943951023931953
g_uiDebugEnabled = false
g_uiFocusDebugEnabled = false
g_logFilePrefixTimestamp = true
g_densityMapRevision = 4
g_terrainTextureRevision = 1
g_terrainLodTextureRevision = 2
g_splitShapesRevision = 2
g_tipCollisionRevision = 2
g_placementCollisionRevision = 2
g_navigationCollisionRevision = 2
g_menuMusic = nil
g_menuMusicIsPlayingStarted = false
g_clientInterpDelay = 100
g_clientInterpDelayMin = 60
g_clientInterpDelayMax = 150
g_clientInterpDelayBufferOffset = 30
g_clientInterpDelayBufferScale = 0.5
g_clientInterpDelayBufferMin = 45
g_clientInterpDelayBufferMax = 60
g_clientInterpDelayAdjustDown = 0.002
g_clientInterpDelayAdjustUp = 0.08
g_time = 0
g_currentDt = 16.666666666666668
g_updateLoopIndex = 0
g_physicsTimeLooped = 0
g_physicsDt = 16.666666666666668
g_physicsDtUnclamped = 16.666666666666668
g_physicsDtNonInterpolated = 16.666666666666668
g_physicsDtLastValidNonInterpolated = 16.666666666666668
g_packetPhysicsNetworkTime = 0
g_networkTime = netGetTime()
g_physicsNetworkTime = g_networkTime
g_analogStickHTolerance = 0.45
g_analogStickVTolerance = 0.45
g_referenceScreenWidth = 1920
g_referenceScreenHeight = 1080
g_maxUploadRate = 30.72
g_maxUploadRatePerClient = 393.216
g_drawGuiHelper = false
g_guiHelperSteps = 0.1
g_lastMousePosX = 0
g_lastMousePosY = 0
g_screenWidth = 800
g_screenHeight = 600
g_pixelSizeX = 1 / g_screenWidth
g_pixelSizeY = 1 / g_screenHeight
g_screenAspectRatio = g_screenWidth / g_screenHeight
g_presentedScreenAspectRatio = g_screenAspectRatio
g_aspectScaleX = 1
g_aspectScaleY = 1
g_dedicatedServer = nil
g_joinServerMaxCapacity = 16
g_serverMaxClientCapacity = 16
g_serverMinCapacity = 2
g_nextModRecommendationTime = 0
g_maxNumLoadingBarSteps = 35
g_curNumLoadingBarStep = 0
g_updateDownloadFinished = false
g_updateDownloadFinishedDialogShown = false
g_skipStartupScreen = false
function initPlatform()
	local v_u_1 = nil
	if StartParams.getIsSet("platform") then
		local v2 = string.upper(string.trim(StartParams.getValue("platform") or ""))
		if PlatformId[v2] == nil then
			if v2 == "STEAM" then
				v_u_1 = PlatformId.WIN
				GS_IS_STEAM_VERSION = true
			elseif v2 == "EPIC" then
				v_u_1 = PlatformId.WIN
				GS_IS_EPIC_VERSION = true
			elseif v2 == "MSSTORE" then
				v_u_1 = PlatformId.WIN
				GS_IS_MSSTORE_VERSION = true
			elseif v2 == "NETFLIX" then
				v_u_1 = PlatformId.ANDROID
				GS_IS_NETFLIX_VERSION = true
			else
				printError(string.format("Error: Invalid platform \'%s\'", v2))
			end
		else
			v_u_1 = PlatformId[v2]
		end
	end
	if v_u_1 ~= nil then
		function getPlatformId()
			-- upvalues: (ref) v_u_1
			return v_u_1
		end
	end
	local v3 = getPlatformId()
	GS_PLATFORM_ID = v3
	GS_PLATFORM_PC = v3 == PlatformId.WIN and true or v3 == PlatformId.MAC
	GS_PLATFORM_XBOX = v3 == PlatformId.XBOX_SERIES
	GS_PLATFORM_PLAYSTATION = v3 == PlatformId.PS5
	GS_PLATFORM_SWITCH = v3 == PlatformId.SWITCH
	GS_PLATFORM_PHONE = v3 == PlatformId.ANDROID and true or v3 == PlatformId.IOS
	GS_IS_CONSOLE_VERSION = GS_PLATFORM_XBOX or GS_PLATFORM_PLAYSTATION
	GS_IS_MOBILE_VERSION = GS_PLATFORM_PHONE or GS_PLATFORM_SWITCH
end
function init(p4)
	StartParams.init(p4)
	initPlatform()
	source("dataS/scripts/game.lua")
	getClipboard = nil
	addFoliageTypeFromXML = nil
	setReflectionMapCustomCamera = nil
	if not initTesting() then
		local v5 = XMLFile.load("SettingsFile", "dataS/settings.xml")
		local v6 = v5:getString("settings#developmentLevel", "release"):lower()
		g_buildName = v5:getString("settings#buildName", g_buildName)
		g_buildTypeParam = v5:getString("settings#buildTypeParam", g_buildTypeParam)
		g_gameRevision = v5:getString("settings#revision", g_gameRevision)
		g_gameRevision = g_gameRevision .. getGameRevisionExtraText()
		g_isDevelopmentVersion = false
		if v6 == "internal" then
			print("INTERNAL VERSION")
			g_addTestCommands = true
		elseif v6 == "development" then
			print("DEVELOPMENT VERSION")
			g_isDevelopmentVersion = true
			g_addTestCommands = true
			enableDevelopmentControls()
		end
		if g_isDevelopmentVersion then
			g_networkDebug = true
			print(string.format("UniqueUserId: %s", getUniqueUserId()))
		end
		if g_addTestCommands or StartParams.getIsSet("cheats") then
			g_addCheatCommands = true
		end
		if g_addTestCommands or StartParams.getIsSet("devWarnings") then
			g_showDevelopmentWarnings = true
		end
		if g_isDevelopmentVersion then
			if StartParams.getIsSet("consoleSimulator") then
				ConsoleSimulator.init()
				ImeSimulator.init()
			end
			if StartParams.getIsSet("imeSimulator") then
				ImeSimulator.init()
			end
			if StartParams.getIsSet("iapSimulator") then
				IAPSimulator.init()
			end
			if StartParams.getIsSet("mobileSimulator") then
				MobileSimulator.init()
			end
			if StartParams.getIsSet("gameLoadingCancelSimulator") then
				GameLoadingCancelSimulator.init()
			end
			Profiler.init()
		end
		g_serverMaxCapacity = GS_IS_CONSOLE_VERSION and 6 or 16
		AudioGroup.loadGroups()
		g_i3DManager:init()
		updateLoadingBarProgress()
		g_messageCenter = MessageCenter.new()
		updateLoadingBarProgress()
		g_soundMixer = SoundMixer.new()
		g_soundMixer:loadFromXML("dataS/soundMixer.xml")
		updateLoadingBarProgress()
		g_autoSaveManager = AutoSaveManager.new()
		updateLoadingBarProgress()
		local v7 = KioskMode.new()
		if v7:load() then
			g_kioskMode = v7
		end
		g_lifetimeStats = LifetimeStats.new()
		g_lifetimeStats:load()
		local v8 = StartParams.getIsSet("server") or StartParams.getIsSet("serverWithGui")
		local v9 = StartParams.getValue("autoStartSavegameId")
		local v10 = StartParams.getValue("autoLoadURI")
		local v11 = StartParams.getValue("devStartServer")
		local v12 = StartParams.getValue("devStartClient")
		local v13 = g_isDevelopmentVersion and StartParams.getValue("uniqueUserId") or nil
		if Platform.isPlaystation then
			g_unsafeScreenWidth = 1920
			g_unsafeScreenHeight = 1080
		else
			local v14, v15 = getScreenModeInfo(getScreenMode())
			g_unsafeScreenWidth = v14
			g_unsafeScreenHeight = v15
		end
		g_safeFrameScreenOffsetX = 0
		g_safeFrameScreenOffsetY = 0
		g_screenWidth = g_unsafeScreenWidth - g_safeFrameScreenOffsetX * 2
		g_screenHeight = g_unsafeScreenHeight - g_safeFrameScreenOffsetY * 2
		g_safeFrameRatioX = g_screenWidth / g_unsafeScreenWidth
		g_safeFrameRatioY = g_screenHeight / g_unsafeScreenHeight
		g_pixelSizeX = 1 / g_unsafeScreenWidth
		g_pixelSizeY = 1 / g_unsafeScreenHeight
		g_baseUIFilename = "dataS/menu/hud/ui_elements.png"
		g_baseUIPostfix = ""
		g_iconsUIFilename = "dataS/menu/hud/ui_icons.png"
		g_baseHUDFilename = "dataS/menu/hud/hud_elements.png"
		g_controlHUDFilename = "dataS/menu/hud/hud_elements2.png"
		if g_isDevelopmentVersion then
			print(string.format(" Loading UI-textures: \'%s\' \'%s\' \'%s\'", g_baseUIFilename, g_baseHUDFilename, g_iconsUIFilename))
		end
		g_screenAspectRatio = g_screenWidth / g_screenHeight
		g_presentedScreenAspectRatio = getScreenAspectRatio()
		updateAspectRatio(g_screenAspectRatio)
		local v16, v17 = getNormalizedScreenValues(1, 1)
		g_pixelSizeScaledX = v16
		g_pixelSizeScaledY = v17
		g_colorBgUVs = GuiUtils.getUVs({
			10,
			1010,
			4,
			4
		})
		local v18 = Platform.safeFrameOffsetX
		local v19 = Platform.safeFrameOffsetY
		local v20, v21 = getNormalizedScreenValues(v18, v19)
		g_safeFrameOffsetX = v20
		g_safeFrameOffsetY = v21
		local v22 = Platform.safeFrameMajorOffsetX
		local v23 = Platform.safeFrameMajorOffsetY
		local v24, v25 = getNormalizedScreenValues(v22, v23)
		g_safeFrameMajorOffsetX = v24
		g_safeFrameMajorOffsetY = v25
		local v26, v27 = getNormalizedScreenValues(30, 30)
		g_hudAnchorLeft = v26
		g_hudAnchorRight = 1 - v26
		g_hudAnchorBottom = v27
		g_hudAnchorTop = 1 - v27
		registerProfileFile("gameSettings.xml")
		registerProfileFile("extraContent.xml")
		g_textWidthScale = 0.95
		setTextWidthScale(g_textWidthScale)
		g_xmlManager:earlyCreateSchemas()
		g_xmlManager:earlyInitSchemas()
		PlayerSystem.loadStyleConfigurationsXML("dataS/character/playerModels.xml")
		updateLoadingBarProgress()
		g_gameSettings = GameSettings.new()
		loadUserSettings(g_gameSettings)
		updateLoadingBarProgress()
		loadLanguageSettings(v5)
		local v28 = "Available Languages:"
		for _, v29 in ipairs(g_availableLanguagesTable) do
			v28 = v28 .. " " .. getLanguageCode(v29)
		end
		v5:delete()
		g_gameTitle = "Farming Simulator 25"
		if GS_IS_MOBILE_VERSION then
			g_gameTitle = "Farming Simulator 26"
		end
		CaptionUtil.addText(g_gameTitle)
		if Platform.isPlaystation then
			CaptionUtil.addText("- PlayStation 5")
		elseif Platform.isXbox then
			CaptionUtil.addText("- Xbox Series")
		elseif Platform.isSwitch then
			CaptionUtil.addText("- Switch")
		elseif Platform.isAndroid then
			CaptionUtil.addText("- Android")
		elseif Platform.isIOS then
			CaptionUtil.addText("- iOS")
		end
		if g_isDevelopmentVersion then
			local v30 = g_gameVersionDisplay .. g_gameVersionDisplayExtra .. " (" .. getEngineRevision() .. "/" .. g_gameRevision .. ")"
			CaptionUtil.addText("- DevelopmentVersion " .. v30 .. " - " .. getAppBasePath() .. " - " .. getUserProfileAppPath())
		elseif g_addTestCommands then
			CaptionUtil.addText("- InternalVersion")
		end
		addNotificationFilter(GS_PRODUCT_ID, g_gameVersionNotification)
		updateLoadingBarProgress()
		local v31 = ""
		if g_buildTypeParam ~= "" then
			v31 = v31 .. " " .. g_buildTypeParam
		end
		if GS_IS_STEAM_VERSION then
			v31 = v31 .. " (Steam)"
		end
		if GS_IS_EPIC_VERSION then
			v31 = v31 .. " (Epic)"
		end
		if GS_IS_MSSTORE_VERSION then
			v31 = v31 .. " (MSStore)"
		end
		if GS_IS_MAC_APP_STORE_VERSION then
			v31 = v31 .. " (Mac App Store)"
		end
		if v8 then
			v31 = v31 .. " (Server)"
		end
		print(g_gameTitle .. v31)
		print("  Version: " .. g_gameVersionDisplay .. g_gameVersionDisplayExtra .. " " .. g_buildName)
		print("  " .. v28)
		print("  Language: " .. g_languageShort)
		print("  Time: " .. getDate("%Y-%m-%d %H:%M:%S"))
		print("  ModDesc Version: " .. g_maxModDescVersion)
		if Platform.isPC then
			local v32 = getUserProfileAppPath() .. "screenshots/"
			g_screenshotsDirectory = v32
			createFolder(v32)
			local v33 = getUserProfileAppPath() .. "modSettings/"
			g_modSettingsDirectory = v33
			createFolder(v33)
		end
		g_adsSystem = AdsSystem.new()
		local v34 = getModInstallPath()
		local v35 = getModDownloadPath()
		updateLoadingBarProgress()
		if Platform.allowsModDirectoryOverride and Utils.getNoNil(getXMLBool(g_savegameXML, "gameSettings.modsDirectoryOverride#active"), false) then
			local v36 = getXMLString(g_savegameXML, "gameSettings.modsDirectoryOverride#directory")
			if v36 ~= nil and v36 ~= "" then
				v34 = v36:gsub("\\", "/")
				if v34:sub(1, 2) == "//" then
					v34 = "\\\\" .. v34:sub(3)
				end
				if v34:sub(v34:len(), v34:len()) ~= "/" then
					v34 = v34 .. "/"
				end
			end
		end
		updateLoadingBarProgress()
		if v34 then
			print("  Mod Directory: " .. v34)
			createFolder(v34)
		end
		if v35 then
			createFolder(v35)
		end
		g_modsDirectory = v34
		if g_addTestCommands then
			print("  Testing Commands: Enabled")
		elseif g_addCheatCommands then
			print("  Cheats: Enabled")
		end
		updateLoadingBarProgress()
		g_i18n = I18N.new()
		g_i18n:load()
		if Platform.hasExtraContent then
			g_extraContentSystem = ExtraContentSystem.new()
			g_extraContentSystem:loadFromXML("dataS/extraContent.xml")
			g_extraContentSystem:loadFromProfile()
		end
		updateLoadingBarProgress()
		math.randomseed(getTime())
		math.random()
		math.random()
		math.random()
		updateLoadingBarProgress()
		g_splitShapeManager:load()
		addSplitShapesShaderParameterOverwrite("windSnowLeafScale", 0, 0, 0, 80)
		local v_u_37 = XMLFile.load("MapsXML", "dataS/maps.xml")
		v_u_37:iterate("maps.map", function(_, p38)
			-- upvalues: (copy) v_u_37
			g_mapManager:loadMapFromXML(v_u_37, p38, "", nil, true, true, false)
		end)
		v_u_37:delete()
		updateLoadingBarProgress()
		g_animCache = AnimationCache.new()
		g_animCache:load(AnimationCache.CHARACTER, "dataS/character/playerAnimations/animations.i3d")
		updateLoadingBarProgress()
		g_animCache:load(AnimationCache.VEHICLE_CHARACTER, "dataS/character/playerAnimations/animationsVehicleCharacter.i3d")
		if Platform.supportsPedestrians then
			g_animCache:load(AnimationCache.PEDESTRIAN, "dataS/character/playerAnimations/animationsPedestrians.i3d")
		end
		g_achievementManager = AchievementManager.new()
		g_achievementManager:load()
		updateLoadingBarProgress()
		if g_modsDirectory then
			initModDownloadManager(g_modsDirectory, v35, g_minModDescVersion, g_maxModDescVersion, g_isDevelopmentVersion)
		end
		startUpdatePendingMods()
		updateLoadingBarProgress()
		loadDlcs()
		updateLoadingBarProgress()
		local v39 = startFrameRepeatMode()
		while isModUpdateRunning() do
			usleep(16000)
		end
		if v39 then
			endFrameRepeatMode()
		end
		if Platform.supportsMods then
			loadInternalMods()
			loadMods()
		end
		if not Platform.isConsole then
			copyFile(getAppBasePath() .. "VERSION", getUserProfileAppPath() .. "VERSION", true)
		end
		updateLoadingBarProgress()
		g_inputBinding = InputBinding.new(g_modManager, g_messageCenter, GS_IS_CONSOLE_VERSION)
		g_inputBinding:load()
		g_overlayManager = OverlayManager.new()
		g_overlayManager:addTextureConfigFile("dataS/menu/ui_elements.xml", "ui_elements")
		g_overlayManager:addTextureConfigFile("dataS/menu/gui.xml", "gui")
		g_overlayManager:addTextureConfigFile("dataS/menu/hud/mapHotspots.xml", "mapHotspots")
		g_overlayManager:addTextureConfigFile("dataS/menu/helpline/helplineAtlasSmall.xml", HelpLineManager.SLICE_PREFIX)
		g_gui = Gui.new()
		g_gui:loadProfiles("dataS/guiProfiles.xml")
		updateLoadingBarProgress()
		g_inputDisplayManager = InputDisplayManager.new(g_messageCenter, g_inputBinding, g_modManager, GS_IS_CONSOLE_VERSION)
		g_inputDisplayManager:load()
		if Platform.isMobile then
			g_touchHandler = TouchHandler.new()
		end
		simulatePhysics(false)
		if v8 then
			g_dedicatedServer = DedicatedServer.new()
			g_dedicatedServer:load(getUserProfileAppPath() .. "dedicated_server/dedicatedServerConfig.xml")
			g_dedicatedServer:setGameStatsPath(getUserProfileAppPath() .. "dedicated_server/gameStats.xml")
		end
		updateLoadingBarProgress()
		g_connectionManager = ConnectionManager.new()
		g_masterServerConnection = MasterServerConnection.new()
		g_startMissionInfo = StartMissionInfo.new()
		g_savegameController = SavegameController.new()
		g_inAppPurchaseController = InAppPurchaseController.new()
		g_shopController = ShopController.new()
		g_modHubController = ModHubController.new()
		g_settingsModel = SettingsModel.new()
		updateLoadingBarProgress()
		AchievementsScreen.register()
		if Platform.isMobile then
			MobileSettingsScreen.register()
		end
		g_animalScreen = AnimalScreen.register()
		g_careerScreen = CareerScreen.register()
		if Platform.hasContruction then
			g_constructionScreen = ConstructionScreen.register()
		end
		g_createGameScreen = CreateGameScreen.register()
		updateLoadingBarProgress()
		CreditsScreen.register()
		g_connectToMasterServerScreen = ConnectToMasterServerScreen.register()
		if Platform.needsSignIn then
			g_gamepadSigninScreen = GamepadSigninScreen.register()
		end
		if GS_IS_NETFLIX_VERSION then
			g_netflixSigninScreen = NetflixSigninScreen.register()
		end
		g_joinGameScreen = JoinGameScreen.register()
		g_mainScreen = MainScreen.register()
		updateLoadingBarProgress()
		if Platform.supportsMods then
			g_modHubScreen = ModHubScreen.register()
		end
		g_modSelectionScreen = ModSelectionScreen.register()
		g_newGameScreen = NewGameScreen.register()
		g_mpLoadingScreen = MPLoadingScreen.register()
		g_multiplayerScreen = MultiplayerScreen.register()
		g_serverDetailScreen = ServerDetailScreen.register()
		updateLoadingBarProgress()
		g_settingsScreen = SettingsScreen.register()
		updateLoadingBarProgress()
		g_shopConfigScreen = ShopConfigScreen.register()
		g_shopMenu = ShopMenu.register()
		updateLoadingBarProgress()
		if Platform.showStartupScreen and g_skipStartupScreen == false then
			g_startupScreen = StartupScreen.register()
		end
		if Platform.hasWardrobe then
			g_wardrobeScreen = WardrobeScreen.register()
		end
		g_workshopScreen = WorkshopScreen.register()
		updateLoadingBarProgress()
		g_inGameMenu = InGameMenu.register()
		updateLoadingBarProgress()
		if Platform.hasAnimalTradingDialog then
			AnimalTradingDialog.register()
		end
		ChatDialog.register()
		ColorPickerDialog.register()
		g_connectionFailedDialog = ConnectionFailedDialog.register()
		DenyAcceptDialog.register()
		EditFarmDialog.register()
		updateLoadingBarProgress()
		GameRateDialog.register()
		InfoDialog.register()
		LeaseYesNoDialog.register()
		LicensePlateDialog.register()
		MessageDialog.register()
		ConnectionPendingDialog.register()
		ModHubScreenshotDialog.register()
		ModHubDownloadDialog.register()
		updateLoadingBarProgress()
		OptionDialog.register()
		PasswordDialog.register()
		PlaceableInfoDialog.register()
		RefillDialog.register()
		RiceFieldDialog.register()
		SellItemDialog.register()
		PalletShopDialog.register()
		AISettingsDialog.register()
		updateLoadingBarProgress()
		SavegameConflictDialog.register()
		SavegameUploadDialog.register()
		SavegameUploadProgressDialog.register()
		ServerSettingsDialog.register()
		SiloDialog.register()
		ObjectStorageDialog.register()
		SleepDialog.register()
		FieldStateDialog.register()
		ToneMappingDialog.register()
		DebugPhysicsCollisionGroupDialog.register()
		DebugDisplacementDialog.register()
		updateLoadingBarProgress()
		TextInputDialog.register()
		if Platform.hasTourDialog then
			TourDialog.register()
		end
		TransferMoneyDialog.register()
		UnBanDialog.register()
		if Platform.supportsMods then
			VoteDialog.register()
		end
		YesNoDialog.register()
		ConversationDialog.register()
		updateLoadingBarProgress()
		if g_kioskMode ~= nil then
			g_kioskMode:initializedGUIClasses()
		end
		updateLoadingBarProgress()
		g_menuMusic = createStreamedSample("menuMusic", true)
		loadStreamedSample(g_menuMusic, "data/music/menu.ogg")
		setStreamedSampleGroup(g_menuMusic, AudioGroup.MENU_MUSIC)
		setStreamedSampleVolume(g_menuMusic, 1)
		g_soundMixer:addVolumeChangedListener(AudioGroup.MENU_MUSIC, function(_, _, p40)
			if g_menuMusicIsPlayingStarted then
				if p40 > 0 then
					resumeStreamedSample(g_menuMusic)
					return
				end
				pauseStreamedSample(g_menuMusic)
			end
		end, nil)
		if Platform.preShaderContentFiles ~= nil then
			g_preShaderContents = {}
			for _, v41 in ipairs(Platform.preShaderContentFiles) do
				local v42 = g_i3DManager:loadI3DFile(v41, false, false)
				local v43 = g_preShaderContents
				table.insert(v43, {
					["step"] = 0,
					["node"] = v42
				})
			end
			g_preShaderContentStepIndex = 1
			if #g_preShaderContents == 0 then
				g_preShaderContents = nil
			end
		end
		updateLoadingBarProgress(true)
		if g_kioskMode ~= nil then
			g_kioskMode:init()
		end
		if Platform.showStartupScreen and g_skipStartupScreen == false then
			g_gui:showGui("StartupScreen")
		else
			g_gui:showGui("MainScreen")
		end
		g_inputBinding:setShowMouseCursor(true)
		local v44 = getCamera()
		g_cameraManager:addCamera(v44, nil, true)
		g_cameraManager:setActiveCamera(v44)
		if g_dedicatedServer == nil then
			local v45 = getAppBasePath() .. "data/music/"
			local v46 = getAppBasePath() .. "profileTemplate/streamingInternetRadios.xml"
			local v47 = getAppBasePath() .. "profileTemplate/ReadmeMusic.txt"
			local v48, v49
			if Platform.supportsCustomInternetRadios then
				v48 = getUserProfileAppPath() .. "music/"
				v49 = v48 .. "streamingInternetRadios.xml"
				local v50 = v48 .. "ReadmeMusic.txt"
				createFolder(v48)
				copyFile(v46, v49, false)
				copyFile(v47, v50, false)
			else
				v48 = v45
				v49 = v46
			end
			g_soundPlayer = SoundPlayer.new(getAppBasePath(), "https://www.farming-simulator.com/feed/fs2025-radio-station-feed.xml", v49, v45, v48, g_languageShort, AudioGroup.RADIO)
		end
		RestartManager:init(p4)
		if RestartManager.restarting then
			g_gui:showGui("MainScreen")
			RestartManager:handleRestart()
		end
		SystemConsoleCommands.init()
		if g_dedicatedServer ~= nil then
			g_dedicatedServer:start()
		end
		if v11 ~= nil then
			startDevServer(v11, v13)
		end
		if v12 ~= nil then
			startDevClient(v12, v13)
		end
		if v9 == nil then
			if v10 ~= nil then
				autoLoadByURI(v10)
				return
			end
		elseif StartParams.getIsSet("restart") and not GameLoadingCancelSimulator.ACTIVE then
			Logging.info("Ignored \'autoStartSavegame\' start parameter after game restart")
		else
			autoStartLocalSavegame(v9)
		end
		if GS_PLATFORM_PC then
			registerGlobalActionEvents(g_inputBinding)
		elseif GS_IS_CONSOLE_VERSION and g_isDevelopmentVersion then
			local v51, v52 = g_inputBinding:registerActionEvent(InputAction.CONSOLE_DEBUG_TOGGLE_FPS, nil, toggleShowFPS, false, true, false, true)
			if v51 then
				g_inputBinding:setActionEventTextVisibility(v52, false)
			end
			local v53, v54 = g_inputBinding:registerActionEvent(InputAction.CONSOLE_DEBUG_TOGGLE_STATS, nil, toggleStatsOverlay, false, true, false, true)
			if v53 then
				g_inputBinding:setActionEventTextVisibility(v54, false)
			end
		end
		if Platform.supportsMods then
			postInitMods()
		end
		g_logFilePrefixTimestamp = true
		setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
		if StartParams.getIsSet("invitePlatformServerId") then
			g_invitePlatformServerId = StartParams.getValue("invitePlatformServerId")
			local v55 = StartParams.getValue("inviteRequestUserName")
			g_inviteRequestUserName = base64Decode(v55)
			g_handleInviteRequest = true
		end
		if StartParams.getIsSet("restart") and Platform.needsSignIn then
			if StartParams.getIsSet("autoSignIn") and g_gui.currentGuiName ~= "GamepadSigninScreen" then
				g_autoSignIn = true
			else
				g_gui:showGui("GamepadSigninScreen")
			end
		end
		if Platform.hasAdjustableFrameLimit then
			setFramerateLimiter(true, Platform.defaultFrameLimit)
		end
		Profiler.startProfiler()
		return true
	end
end
function update(p56)
	if Platform.isMobile then
		checkInsets()
	end
	if g_preShaderContents ~= nil then
		local v57 = g_preShaderContents[g_preShaderContentStepIndex]
		local v58 = v57.step
		v57.step = v57.step + 1
		if v58 == 0 then
			link(getRootNode(), v57.node)
			setTranslation(g_cameraManager:getActiveCamera(), 0, 0, 5)
			Logging.devInfo("PreShaderContent (%d/%d): render default", g_preShaderContentStepIndex, #g_preShaderContents)
		elseif v58 == 1 then
			setTranslation(g_cameraManager:getActiveCamera(), 0, 0, 30 * getViewDistanceCoeff() + 2)
			Logging.devInfo("PreShaderContent (%d/%d): render blended", g_preShaderContentStepIndex, #g_preShaderContents)
		elseif v58 == 2 then
			Logging.devInfo("PreShaderContent (%d/%d): compiling done", g_preShaderContentStepIndex, #g_preShaderContents)
			g_preShaderContentStepIndex = g_preShaderContentStepIndex + 1
		end
		if g_preShaderContentStepIndex > #g_preShaderContents then
			Logging.devInfo("PreShaderContent: finished shader compilation")
			for _, v59 in ipairs(g_preShaderContents) do
				delete(v59.node)
			end
			g_preShaderContents = nil
			setTranslation(g_cameraManager:getActiveCamera(), 0, 0, 0)
		end
	end
	if g_autoSignIn then
		g_autoSignIn = nil
		g_gamepadSigninScreen:signIn()
	end
	if g_handleInviteRequest then
		local v60 = g_invitePlatformServerId
		local v61 = g_inviteRequestUserName
		g_invitePlatformServerId = nil
		g_inviteRequestUserName = nil
		g_handleInviteRequest = nil
		acceptedGameInvite(v60, v61)
	end
	g_time = g_time + p56
	g_currentDt = p56
	g_physicsDt = getPhysicsDt()
	g_physicsDtUnclamped = getPhysicsDtUnclamped()
	g_physicsDtNonInterpolated = getPhysicsDtNonInterpolated()
	if g_physicsDtNonInterpolated > 0 then
		g_physicsDtLastValidNonInterpolated = g_physicsDtNonInterpolated
	end
	g_networkTime = netGetTime()
	g_physicsNetworkTime = g_physicsNetworkTime + g_physicsDtUnclamped
	g_physicsTimeLooped = (g_physicsTimeLooped + g_physicsDt * 10) % 65535
	g_updateLoopIndex = g_updateLoopIndex + 1
	if g_updateLoopIndex > 1073741824 then
		g_updateLoopIndex = 0
	end
	local v62 = g_physicsDt
	g_physicsDt = math.max(v62, 0.001)
	local v63 = g_physicsDtUnclamped
	g_physicsDtUnclamped = math.max(v63, 0.001)
	if g_currentTest == nil then
		setTextWidthScale(g_textWidthScale)
		g_ignitionLockManager:update(p56)
		g_debugManager:update(p56)
		g_lifetimeStats:update(p56)
		g_soundMixer:update(p56)
		g_asyncTaskManager:update(p56)
		g_asyncEngineManager:update()
		g_messageCenter:update(p56)
		Profiler.update(p56)
		if g_nextModRecommendationTime < g_time and (g_currentMission == nil and (g_dedicatedServer == nil and g_modHubController ~= nil)) then
			g_modHubController:updateRecommendationSystem()
			g_nextModRecommendationTime = g_time + 1800000
		end
		g_inputBinding:update(p56)
		if g_currentMission ~= nil and (g_currentMission.isLoaded and g_gui.currentGuiName ~= "GamepadSigninScreen") then
			g_currentMission:preUpdate(p56)
		end
		if Platform.hasFriendInvitation and (g_showDeeplinkingFailedMessage == true and g_gui.currentGuiName ~= "GamepadSigninScreen") then
			g_showDeeplinkingFailedMessage = false
			if GS_PLATFORM_XBOX then
				if PlatformPrivilegeUtil.checkMultiplayer(onShowDeepLinkingErrorMsg, nil, nil, 30000) then
					onShowDeepLinkingErrorMsg()
				end
			else
				onShowDeepLinkingErrorMsg()
			end
		end
		if g_currentMission == nil or g_currentMission:getAllowsGuiDisplay() then
			g_gui:update(p56)
		end
		if g_currentMission ~= nil and (g_currentMission.isLoaded and g_gui.currentGuiName ~= "GamepadSigninScreen") then
			g_currentMission:update(p56)
		end
		if g_soundPlayer ~= nil then
			g_soundPlayer:update(p56)
		end
		if g_gui.currentGuiName == "MainScreen" then
			g_achievementManager:update(p56)
		end
		g_soundManager:update(p56)
		if g_kioskMode ~= nil then
			g_kioskMode:update(p56)
		end
		Input.updateFrameEnd()
		if GS_PLATFORM_PC and g_dedicatedServer == nil then
			if getIsUpdateDownloadFinished() then
				g_updateDownloadFinished = true
			end
			if g_updateDownloadFinished and (not g_updateDownloadFinishedDialogShown and (g_gui.currentGuiName == "MainScreen" or g_currentMission ~= nil and g_currentMission.gameStarted)) then
				g_updateDownloadFinishedDialogShown = true
				InfoDialog.show(g_i18n:getText("ui_updateDownloadFinishedText"))
			end
		end
		g_inputBinding:refresh()
		if g_pendingRestartData ~= nil then
			performRestart()
		end
		if g_pendingExit == true then
			OnInGameMenuMenu()
			doExit()
		end
	else
		g_currentTest.update(p56)
	end
end
function draw()
	if g_currentTest == nil then
		if g_dedicatedServer == nil then
			g_debugManager:drawPreUI()
			if g_currentMission == nil or g_currentMission:getAllowsGuiDisplay() then
				g_gui:draw()
			end
			if g_currentMission ~= nil and (g_currentMission.isLoaded and g_gui.currentGuiName ~= "GamepadSigninScreen") then
				g_currentMission:draw()
			end
			if g_inputBinding ~= nil then
				g_inputBinding:draw()
			end
			if g_inputDisplayManager ~= nil then
				g_inputDisplayManager:draw()
			end
			if g_kioskMode ~= nil then
				g_kioskMode:draw()
			end
			if g_isDevelopmentConsoleScriptModTesting then
				renderText(0.2, 0.85, getCorrectTextSize(0.05), "CONSOLE SCRIPTS. DEVELOPMENT USE ONLY")
			end
			g_debugManager:drawPostUI()
			if g_showSafeFrame then
				if g_safeFrameOverlay == nil then
					g_safeFrameOverlay = createImageOverlay("dataS/menu/base/graph_pixel.png")
					setOverlayColor(g_safeFrameOverlay, 1, 0, 0, 0.4)
				end
				renderOverlay(g_safeFrameOverlay, g_safeFrameOffsetX, 0, 1 - 2 * g_safeFrameOffsetX, g_safeFrameOffsetY)
				renderOverlay(g_safeFrameOverlay, g_safeFrameOffsetX, 1 - g_safeFrameOffsetY, 1 - 2 * g_safeFrameOffsetX, g_safeFrameOffsetY)
				renderOverlay(g_safeFrameOverlay, 0, 0, g_safeFrameOffsetX, 1)
				renderOverlay(g_safeFrameOverlay, 1 - g_safeFrameOffsetX, 0, g_safeFrameOffsetX, 1)
				if g_safeFrameMajorOverlay == nil then
					g_safeFrameMajorOverlay = createImageOverlay("dataS/menu/base/graph_pixel.png")
					setOverlayColor(g_safeFrameMajorOverlay, 1, 0, 0, 0.4)
				end
				renderOverlay(g_safeFrameMajorOverlay, g_safeFrameMajorOffsetX, 0, 1 - 2 * g_safeFrameMajorOffsetX, g_safeFrameMajorOffsetY)
				renderOverlay(g_safeFrameMajorOverlay, g_safeFrameMajorOffsetX, 1 - g_safeFrameMajorOffsetY, 1 - 2 * g_safeFrameMajorOffsetX, g_safeFrameMajorOffsetY)
				renderOverlay(g_safeFrameMajorOverlay, 0, 0, g_safeFrameMajorOffsetX, 1)
				renderOverlay(g_safeFrameMajorOverlay, 1 - g_safeFrameMajorOffsetX, 0, g_safeFrameMajorOffsetX, 1)
			end
			if g_drawGuiHelper then
				if g_guiHelperOverlay == nil then
					g_guiHelperOverlay = createImageOverlay("dataS/menu/base/graph_pixel.png")
				end
				if g_guiHelperOverlay ~= 0 then
					setTextColor(1, 1, 1, 1)
					local v64, v65 = getScreenModeInfo(getScreenMode())
					for v66 = g_guiHelperSteps, 1, g_guiHelperSteps do
						renderOverlay(g_guiHelperOverlay, v66, 0, 1 / v64, 1)
						renderOverlay(g_guiHelperOverlay, 0, v66, 1, 1 / v65)
					end
					for v67 = 0.05, 1, 0.05 do
						renderText(v67, 0.97, getCorrectTextSize(0.02), string.format("%.2f", v67))
						renderText(0.01, v67, getCorrectTextSize(0.02), string.format("%.2f", v67))
					end
					local v68 = getCorrectTextSize(0.016)
					setTextAlignment(RenderText.ALIGN_RIGHT)
					setTextColor(0, 0, 0, 0.9)
					renderText(g_lastMousePosX - 0.005, g_lastMousePosY - 0.01 - 0.002, v68, string.format("y %1.4f", g_lastMousePosY))
					setTextColor(1, 1, 1, 1)
					renderText(g_lastMousePosX - 0.005, g_lastMousePosY - 0.01, v68, string.format("y %1.4f", g_lastMousePosY))
					setTextAlignment(RenderText.ALIGN_CENTER)
					setTextColor(0, 0, 0, 0.9)
					renderText(g_lastMousePosX, g_lastMousePosY + 0.01 - 0.002, v68, string.format("x %1.4f", g_lastMousePosX))
					setTextColor(1, 1, 1, 1)
					renderText(g_lastMousePosX, g_lastMousePosY + 0.01, v68, string.format("x %1.4f", g_lastMousePosX))
					setTextAlignment(RenderText.ALIGN_LEFT)
					local v69 = 5 / v64
					local v70 = 5 / v65
					renderOverlay(g_guiHelperOverlay, g_lastMousePosX - v69, g_lastMousePosY, 2 * v69, 1 / v65)
					renderOverlay(g_guiHelperOverlay, g_lastMousePosX, g_lastMousePosY - v70, 1 / v64, 2 * v70)
				end
			end
			if Platform.requiresConnectedGamepad and (getNumOfGamepads() == 0 and (g_gui.currentGuiName ~= "StartupScreen" and g_gui.currentGuiName ~= "GamepadSigninScreen")) then
				if Platform.isXbox then
					requestGamepadSignin(Input.BUTTON_2, true, false)
				end
				setTextBold(true)
				setTextAlignment(RenderText.ALIGN_CENTER)
				setTextColor(0, 0, 0, 1)
				local v71 = getCorrectTextSize(0.05)
				local v72 = g_i18n:getText("ui_pleaseReconnectController")
				renderText(0.497, 0.6053333333333333, v71, v72)
				renderText(0.5, 0.6053333333333333, v71, v72)
				renderText(0.503, 0.6053333333333333, v71, v72)
				renderText(0.497, 0.6, v71, v72)
				renderText(0.503, 0.6, v71, v72)
				renderText(0.497, 0.5946666666666667, v71, v72)
				renderText(0.5, 0.5946666666666667, v71, v72)
				renderText(0.503, 0.5946666666666667, v71, v72)
				setTextColor(1, 1, 1, 1)
				renderText(0.5, 0.6, v71, v72)
				setTextBold(false)
				setTextColor(1, 1, 1, 1)
				setTextAlignment(RenderText.ALIGN_LEFT)
				drawFilledRect(0, 0, 1, 1, 1, 1, 1, 0.3)
			end
			if g_showRawInput then
				setOverlayColor(GuiElement.debugOverlay, 0, 0, 0, 0.9)
				renderOverlay(GuiElement.debugOverlay, 0, 0, 1, 1)
				setTextAlignment(RenderText.ALIGN_LEFT)
				local v73 = getNumOfGamepads()
				local v74 = 0.95
				for v75 = 0, v73 - 1 do
					local v76 = 0
					for v77 = 0, Input.MAX_NUM_BUTTONS - 1 do
						if getHasGamepadButton(Input.BUTTON_1 + v77, v75) then
							v76 = v76 + 1
						end
					end
					local v78 = 0
					for v79 = 0, Input.MAX_NUM_AXES - 1 do
						if getHasGamepadAxis(v79, v75) then
							v78 = v78 + 1
						end
					end
					local v80 = getGamepadVersionId(v75)
					local v81 = v80 >= 65535 and "" or string.format("Version: %04X ", v80)
					local v82 = v74 - 0.025
					renderText(0.02, v82, 0.025, string.format("Index: %d Name: %s PID: %04X VID: %04X %s#Buttons: %d #Axes: %d", v75, getGamepadName(v75), getGamepadProductId(v75), getGamepadVendorId(v75), v81, v76, v78))
					for v83 = 0, Input.MAX_NUM_AXES - 1 do
						if getHasGamepadAxis(v83, v75) then
							local v84 = getGamepadAxisPhysicalName(v83, v75)
							v82 = v82 - 0.016
							renderText(0.025, v82, 0.016, string.format("%s->%d: \'%s\' %1.2f", v84, v83, getGamepadAxisLabel(v83, v75), getInputAxis(v83, v75)))
						end
					end
					for v85 = 0, Input.MAX_NUM_BUTTONS - 1 do
						if getInputButton(v85, v75) > 0 then
							local v86 = getGamepadButtonPhysicalName(v85, v75)
							v82 = v82 - 0.025
							renderText(0.025, v82, 0.025, string.format("%s->%d: \'%s\'", v86, v85, getGamepadButtonLabel(v85, v75)))
						end
					end
					v74 = v82 - 0.016
				end
				if v73 == 0 then
					renderText(0.025, v74, 0.025, "No gamepads found")
				end
			end
		end
	else
		g_currentTest.draw()
		return
	end
end
function postAnimationUpdate(p87)
	for _, v88 in pairs(g_postAnimationUpdateCallbacks) do
		v88.callbackFunc(v88.callbackTarget, p87, v88.callbackArguments)
	end
end
function cleanUp()
	if g_safeFrameOverlay ~= nil then
		delete(g_safeFrameOverlay)
	end
	if g_safeFrameMajorOverlay ~= nil then
		delete(g_safeFrameMajorOverlay)
	end
	if g_guiHelperOverlay ~= nil then
		delete(g_guiHelperOverlay)
	end
	if GuiElement.debugOverlay ~= nil then
		delete(GuiElement.debugOverlay)
	end
	deleteDrawingOverlays()
	g_masterServerConnection:disconnectFromMasterServer()
	g_connectionManager:shutdownAll()
	g_inputDisplayManager:delete()
	g_inputBinding:delete()
	g_modHubController:delete()
	g_shopController:delete()
	g_gui:delete()
	g_i18n:delete()
	g_adsSystem:delete()
	g_asyncEngineManager:delete()
	delete(g_menuMusic)
	delete(g_savegameXML)
	Profiler.delete()
	g_lifetimeStats:save()
	if g_soundPlayer ~= nil then
		g_soundPlayer:delete()
		g_soundPlayer = nil
	end
	if g_soundMixer ~= nil then
		g_soundMixer:delete()
		g_soundMixer = nil
	end
	g_animCache:delete()
	g_i3DManager:clearEntireSharedI3DFileCache(g_isDevelopmentVersion)
	g_soundManager:delete()
	if g_isDevelopmentVersion then
		setFileLogPrefixTimestamp(false)
		printActiveEntities()
		print("\nScenegraph:")
		I3DUtil.printChildren(getRootNode())
		setFileLogPrefixTimestamp(g_logFilePrefixTimestamp)
	end
	g_messageCenter:delete()
	SystemConsoleCommands.delete()
end
function doExit()
	if g_didExit == nil then
		g_didExit = true
		g_pendingExit = false
		cleanUp()
		print("Application quit")
		requestExit()
	end
end
function doRestart(p89, p90)
	if g_invitePlatformServerId ~= nil then
		local v91 = base64Encode(g_inviteRequestUserName)
		p90 = p90 .. "-invitePlatformServerId " .. g_invitePlatformServerId .. " -inviteRequestUserName " .. v91
	end
	g_pendingRestartData = {
		["restartProcess"] = p89,
		["args"] = p90
	}
end
function checkInsets()
	local v92, v93, v94, v95 = getSafeFrameInsets()
	if g_insetLeft == nil then
		g_insetLeft = v92
		g_insetRight = v93
		g_insetTop = v94
		g_insetBottom = v95
	end
	if v92 ~= g_insetLeft or (v93 ~= g_insetRight or (v94 ~= g_insetTop or v95 ~= g_insetBottom)) then
		g_insetLeft = v92
		g_insetRight = v93
		g_insetTop = v94
		g_insetBottom = v95
		g_messageCenter:publish(MessageType.INSETS_CHANGED)
	end
end
function performRestart()
	if g_pendingRestartData ~= nil then
		local v96 = g_pendingRestartData
		if Platform.needsSignIn and (g_isSignedIn and getStartMode() ~= RestartManager.START_SCREEN_GAMEPAD_SIGNIN) then
			v96.args = v96.args .. " -autoSignIn"
		end
		cleanUp()
		local v97 = v96.restartProcess and "" or "(soft restart)"
		print("Application restart " .. v97)
		restartApplication(v96.restartProcess, v96.args)
	end
end
function loadLanguageSettings(p_u_98)
	local v99 = getNumOfLanguages()
	local v_u_100 = {}
	for v101 = 0, v99 - 1 do
		v_u_100[getLanguageCode(v101)] = v101
	end
	local v_u_102 = getLanguage()
	local v_u_103 = false
	local v_u_104 = {}
	p_u_98:iterate("settings.languages.language", function(_, p105)
		-- upvalues: (copy) p_u_98, (copy) v_u_100, (copy) v_u_102, (ref) v_u_103, (copy) v_u_104
		local v106 = p_u_98:getString(p105 .. "#code")
		local v107 = p_u_98:getString(p105 .. "#short")
		local v108 = p_u_98:getString(p105 .. "#suffix")
		local v109 = v_u_100[v106]
		if v109 ~= nil then
			if v109 == v_u_102 or not v_u_103 then
				v_u_103 = true
				g_language = v109
				g_languageShort = v107
				g_languageSuffix = v108
			end
			if getIsLanguageEnabled(v109) then
				v_u_104[v109] = true
			end
		end
	end)
	g_availableLanguagesTable = {}
	g_availableLanguageNamesTable = {}
	for v110 = 0, v99 - 1 do
		if v_u_104[v110] or v110 == g_language then
			local v111 = g_availableLanguagesTable
			table.insert(v111, v110)
			if getLanguageNativeName == nil then
				local v112 = g_availableLanguageNamesTable
				local v113 = getLanguageName
				table.insert(v112, v113(v110))
			else
				local v114 = g_availableLanguageNamesTable
				local v115 = getLanguageNativeName
				table.insert(v114, v115(v110))
			end
			if v110 == g_language then
				g_settingsLanguageGUI = #g_availableLanguagesTable - 1
			end
		end
	end
	if GS_IS_CONSOLE_VERSION then
		g_gameSettings:setValue(GameSettings.SETTING.MP_LANGUAGE, getSystemLanguage())
	end
end
function loadUserSettings(p116)
	local v117 = getUserName():trim()
	local v118 = (v117 == nil or v117 == "") and "Player" or v117
	p116:setValue(GameSettings.SETTING.ONLINE_PRESENCE_NAME, v118)
	p116:setValue(GameSettings.SETTING.VOLUME_MASTER, getMasterVolume())
	p116:setValue("joystickVibrationEnabled", getGamepadVibrationEnabled())
	if g_savegameXML ~= nil then
		delete(g_savegameXML)
	end
	local v119 = getAppBasePath() .. "profileTemplate/gameSettingsTemplate.xml"
	g_savegamePath = getUserProfileAppPath() .. "gameSettings.xml"
	copyFile(v119, g_savegamePath, false)
	g_savegameXML = loadXMLFile("savegameXML", g_savegamePath)
	syncProfileFiles()
	local v120 = getXMLInt(g_savegameXML, "gameSettings#revision")
	local v121 = loadXMLFile("GameSettingsTemplate", v119)
	local v122 = getXMLInt(v121, "gameSettings#revision")
	delete(v121)
	if v120 == nil or v120 ~= v122 then
		copyFile(v119, g_savegamePath, true)
		delete(g_savegameXML)
		g_savegameXML = loadXMLFile("savegameXML", g_savegamePath)
	end
	p116:setDefault()
	p116:loadFromXML(g_savegameXML)
	if g_settingsModel ~= nil then
		g_settingsModel:refresh()
	end
	g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.RADIO, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_RADIO))
	g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.VEHICLE, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_VEHICLE))
	g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.MENU_MUSIC, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_MUSIC))
	g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.ENVIRONMENT, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_ENVIRONMENT))
	g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.GUI, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_GUI))
	g_soundMixer:setAudioGroupVolumeFactor(AudioGroup.CHARACTER, g_gameSettings:getValue(GameSettings.SETTING.VOLUME_CHARACTER))
	g_soundMixer:setMasterVolume(g_gameSettings:getValue(GameSettings.SETTING.VOLUME_MASTER))
	g_soundMixer:immediateUpdate()
	VoiceChatUtil.setOutputVolume(g_gameSettings:getValue(GameSettings.SETTING.VOLUME_VOICE))
	VoiceChatUtil.setInputVolume(g_gameSettings:getValue(GameSettings.SETTING.VOLUME_VOICE_INPUT))
	VoiceChatUtil.setInputMode(g_gameSettings:getValue(GameSettings.SETTING.VOICE_MODE))
	g_lifetimeStats:reload()
	if g_extraContentSystem ~= nil then
		g_extraContentSystem:reset()
		g_extraContentSystem:loadFromProfile()
	end
end
function takeScreenshot()
	if g_screenshotsDirectory == nil then
		printError("Error: Screenshot directory not defined!")
	else
		local v123 = g_screenshotsDirectory .. "fsScreen_" .. getDate("%Y_%m_%d_%H_%M_%S") .. ".png"
		print("Saving screenshot: " .. v123)
		if not saveScreenshot(v123) then
			printError(string.format("Error while saving screenshot \'%s\'", v123))
		end
	end
end
function registerGlobalActionEvents(_)
	if g_addTestCommands and Platform.isPC then
		g_noteManager:registerInputActionEvent()
	end
	if g_kioskMode ~= nil then
		g_kioskMode:registerGlobalInputActionEvents()
	end
end
function updateAspectRatio(p124)
	local v125 = g_referenceScreenWidth / g_referenceScreenHeight
	if v125 < p124 then
		g_aspectScaleX = v125 / p124
		g_aspectScaleY = 1
	else
		g_aspectScaleX = 1
		g_aspectScaleY = p124 / v125
	end
	g_aspectScaleX = g_aspectScaleX * g_safeFrameRatioX
	g_aspectScaleY = g_aspectScaleY * g_safeFrameRatioY
end
g_postAnimationUpdateCallbacks = {}
function addPostAnimationCallback(p126, p127, p128)
	local v129 = {
		["callbackFunc"] = p126,
		["callbackTarget"] = p127,
		["callbackArguments"] = p128
	}
	local v130 = g_postAnimationUpdateCallbacks
	table.insert(v130, v129)
	return v129
end
function removePostAnimationCallback(p131)
	for v132, v133 in pairs(g_postAnimationUpdateCallbacks) do
		if v133 == p131 then
			table.remove(g_postAnimationUpdateCallbacks, v132)
		end
	end
end
function updateLoadingBarProgress(p134)
	g_curNumLoadingBarStep = g_curNumLoadingBarStep + 1
	local v135 = g_curNumLoadingBarStep / g_maxNumLoadingBarSteps
	if p134 and v135 < 1 or v135 > 1 then
		printError("Error: Invalid g_maxNumLoadingBarSteps. Last step number is " .. g_curNumLoadingBarStep)
	end
	updateLoadingBar(v135)
end
function onShowDeepLinkingErrorMsg()
	g_deepLinkingInfo = nil
	ConnectionFailedDialog.show(g_i18n:getText("ui_failedToConnectToGame"), OnInGameMenuMenu)
	g_showDeeplinkingFailedMessage = false
end
function startDevServer(p136, _)
	if StartParams.getIsSet("restart") then
		print("Skipping server auto start due to restart")
		return
	else
		g_savegameController:updateSavegames()
		g_savegameController:loadSavegames()
		print("Start developer mp server (Savegame-Id: " .. tostring(p136) .. ")")
		g_mainScreen:onMultiplayerClick()
		g_multiplayerScreen:onClickCreateGame()
		local v137 = g_savegameController:getSavegame((tonumber(p136)))
		if v137 == SavegameController.NO_SAVEGAME or not v137.isValid then
			printWarning("    Savegame not found! Please select savegame manually!")
		else
			g_careerScreen.savegameList.selectedIndex = tonumber(p136)
			g_careerScreen:onStartAction()
			if g_gui.currentGuiName == "ModSelectionScreen" then
				g_modSelectionScreen:onClickOk()
			end
			g_autoDevMP = {
				["serverName"] = "InternalTest_" .. getUserName()
			}
			g_createGameScreen.serverNameElement:setText(g_autoDevMP.serverName)
			g_createGameScreen.autoAccept = true
			g_createGameScreen:onClickOk()
		end
	end
end
function startDevClient(p138, _)
	if StartParams.getIsSet("restart") then
		print("Skipping client auto join due to restart")
	else
		print("Start developer mp client")
		g_mainScreen:onMultiplayerClick()
		if p138 == nil or p138 == "" then
			p138 = "InternalTest_" .. getUserName()
		end
		g_autoDevMP = {
			["serverName"] = p138
		}
		g_multiplayerScreen:onClickJoinGame()
	end
end
function autoStartLocalSavegame(p139)
	print("Auto start local savegame (Id: " .. tostring(p139) .. ")")
	g_gui:setIsMultiplayer(false)
	g_gui:showGui("CareerScreen")
	g_careerScreen.savegameList:setSelectedIndex(tonumber(p139), true)
	local v140 = g_savegameController:getSavegame((tonumber(p139)))
	if v140 == SavegameController.NO_SAVEGAME or not v140.isValid then
		printWarning("    Savegame not found! Please select savegame manually!")
	else
		g_careerScreen.currentSavegame = v140
		g_careerScreen:onStartAction()
		if g_gui.currentGuiName == "ModSelectionScreen" then
			g_modSelectionScreen:onClickOk()
		end
	end
end
function autoLoadByURI(p141)
	local v142 = string.split(p141, ":")
	local v143 = string.split(v142[2], "&")
	local v144 = {}
	for _, v145 in ipairs(v143) do
		local v146 = string.split(v145, "=")
		v144[v146[1]] = v146[2]
	end
	if v144.map == nil then
		printError("Error: URI Parameter \'map\' not set! Cannot auto load from URI.")
	else
		local v147 = v144.map
		local v148 = v144.x
		local v149 = v144.z
		local v150 = v144.savegameIndex
		local v151 = tonumber(v150) or 1
		AutoLoadParams.enable = true
		AutoLoadParams.x = tonumber(v148)
		AutoLoadParams.z = tonumber(v149)
		g_gui:setIsMultiplayer(false)
		g_gui:showGui("CareerScreen")
		g_savegameController:deleteSavegame(v151)
		g_careerScreen.savegameList:setSelectedIndex(v151, true)
		local v152 = g_savegameController:getSavegame(v151)
		g_careerScreen.currentSavegame = v152
		g_startMissionInfo.mapId = v147
		g_startMissionInfo.canStart = true
		g_careerScreen:startSavegame(v152)
		g_gui:changeScreen(nil, CareerScreen)
		if g_gui.currentGuiName == "ModSelectionScreen" then
			g_modSelectionScreen:onClickOk()
		end
	end
end
function connectToServer(p153)
	if storeHaveDlcsChanged() or (haveModsChanged() or g_forceNeedsDlcsAndModsReload) then
		g_forceNeedsDlcsAndModsReload = false
		reloadDlcsAndMods()
	end
	if storeAreDlcsCorrupted() then
		InfoDialog.show(g_i18n:getText("ui_dlcsCorruptRedownload"), g_mainScreen.onDlcCorruptClick, g_mainScreen)
	else
		g_deepLinkingInfo = {}
		g_deepLinkingInfo.platformServerId = p153
		g_masterServerConnection:disconnectFromMasterServer()
		g_connectionManager:shutdownAll()
		g_gui:changeScreen(nil, CareerScreen)
		g_mainScreen:onMultiplayerClick()
		g_multiplayerScreen:onClickJoinGame()
	end
end

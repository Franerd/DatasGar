ObjectMask = {}
local v_u_1 = {}
local v_u_2 = {}
local v_u_3 = {}
local function v10(p4, p5, p6)
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_2
	if v_u_1[p4] ~= nil then
		Logging.error("ObjectMask.registerFlag: Given bit \'%d\' is already in use.", p4)
		return nil
	end
	local v7 = p5:upper()
	if ObjectMask[v7] ~= nil then
		Logging.error("ObjectMask.registerFlag: Given  name \'%s\' is already in use", v7)
		return nil
	end
	local v8 = {
		["name"] = v7,
		["description"] = p6 or "",
		["bit"] = p4,
		["flag"] = 2 ^ p4
	}
	v_u_1[p4] = true
	ObjectMask[v7] = v8.flag
	v_u_3[v8.flag] = v8
	local v9 = v_u_2
	table.insert(v9, v8)
	return v8.flag
end
function ObjectMask.getBitAndName(p11)
	-- upvalues: (copy) v_u_3
	local v12 = v_u_3[p11]
	if v12 ~= nil then
		return string.format("bit %d (%s)", v12.bit, v12.name)
	end
	printCallstack()
	return string.format("<no ObjectMask flag for \'0x%x\'>", p11)
end
function ObjectMask.getFlagsFromMask(p13)
	-- upvalues: (copy) v_u_3
	local v14 = {}
	for _, v15 in ipairs(MathUtil.numberToSetBits(p13)) do
		local v16 = v_u_3[2 ^ v15]
		if v16 ~= nil then
			local v17 = v16.name
			table.insert(v14, v17)
		end
	end
	return table.concat(v14, " ")
end
ObjectMask.SHAPE_VIS_MIRROR = v10(7, "SHAPE_VIS_MIRROR")
ObjectMask.SHAPE_VIS_WATER_REFL_VERYHIGH = v10(8, "SHAPE_VIS_WATER_REFL_VERYHIGH")
ObjectMask.SHAPE_VIS_WATER_REFL = v10(9, "SHAPE_VIS_WATER_REFL")
ObjectMask.SHAPE_VIS_MIRROR_ONLY = v10(15, "SHAPE_VIS_MIRROR_ONLY", "shape only visible in mirror but not main view")
ObjectMask.LIGHT_VIS_WATER_REFL_VERYHIGH = v10(24, "LIGHT_VIS_WATER_REFL_VERYHIGH")
ObjectMask.LIGHT_VIS_WATER_REFL = v10(25, "LIGHT_VIS_WATER_REFL")
ObjectMask.LIGHT_VIS_MIRROR = v10(31, "LIGHT_VIS_MIRROR")
ObjectMask.SHAPE_DEFAULT = 255
ObjectMask.LIGHT_DEFAULT = 16711680
function ObjectMask.iteratorFlags()
	-- upvalues: (copy) v_u_3
	local v_u_18 = 0
	local v_u_19 = 31
	return function()
		-- upvalues: (ref) v_u_18, (ref) v_u_3, (copy) v_u_19
		if v_u_18 > 31 then
			return nil
		end
		v_u_18 = v_u_18 + 1
		while v_u_3[2 ^ (v_u_18 - 1)] == nil do
			v_u_18 = v_u_18 + 1
		end
		local v20 = v_u_3[2 ^ (v_u_18 - 1)]
		return v20.name, v20.bit, v20.flag, v20
	end
end
function ObjectMask.exportToXML()
	local v21 = XMLFile.create("ObjectMaskFlags", "", "objectMaskFlags")
	v21:addComment("objectMaskFlags", "Warning: This file is exported from script and should not be edited manually")
	local v22 = 0
	for v23, v24, _, v25 in ObjectMask.iteratorFlags() do
		local v26 = string.format("objectMaskFlags.flag(%d)", v22)
		v21:setInt(v26 .. "#bit", v24)
		v21:setString(v26 .. "#name", v23)
		v21:setString(v26 .. "#desc", v25.description)
		v22 = v22 + 1
	end
	v21:addComment("objectMaskFlags", "Warning: This file is exported from script and should not be edited manually")
	v21:saveTo("shared/objectMaskFlags.xml", true)
	v21:saveTo("../tools/editor/shared/objectMaskFlags.xml", true)
	v21:delete()
end
addConsoleCommand("gsObjectMaskPresetsExport", "Export all object mask presets to xml files", "exportToXML", ObjectMask)

source("dataS/scripts/events/VehicleRemoveEvent.lua")
source("dataS/scripts/events/OnCreateLoadedObjectEvent.lua")
BaseMission = {}
local v_u_1 = Class(BaseMission)
BaseMission.STATE_INTRO = 0
BaseMission.STATE_READY = 1
BaseMission.STATE_RUNNING = 2
BaseMission.STATE_FINISHED = 3
BaseMission.STATE_FAILED = 5
BaseMission.STATE_CONTINUED = 6
BaseMission.INPUT_CONTEXT_VEHICLE = "VEHICLE"
BaseMission.INPUT_CONTEXT_PAUSE = "PAUSE"
BaseMission.INPUT_CONTEXT_SYNCHRONIZING = "MP_SYNC"
function BaseMission.new(p2, p3)
	-- upvalues: (copy) v_u_1
	local v4 = p3 or v_u_1
	local v5 = setmetatable({}, v4)
	v5.baseDirectory = p2
	v5.server = g_server
	v5.client = g_client
	v5.hud = nil
	v5.playerSystem = PlayerSystem.new()
	v5.placeableSystem = PlaceableSystem.new(v5)
	v5.vehicleSystem = VehicleSystem.new(v5)
	v5.itemSystem = ItemSystem.new(v5)
	v5.handToolSystem = HandToolSystem.new()
	v5.onCreateObjectSystem = OnCreateObjectSystem.new(v5)
	v5.beehiveSystem = BeehiveSystem.new(v5)
	if Platform.hasShallowWaterSimulation then
		v5.shallowWaterSimulation = ShallowWaterSimulation.new()
		v5.shallowWaterSimulation:load()
	end
	v5.cancelLoading = false
	v5.vertexBufferMemoryUsage = 0
	v5.indexBufferMemoryUsage = 0
	v5.textureMemoryUsage = 0
	v5.waitForDLCVerification = false
	v5.waitForCorruptDlcs = false
	v5.finishedFirstUpdate = false
	v5.players = {}
	v5.connectionsToPlayer = {}
	v5.updateables = {}
	v5.sortedUpdateables = {}
	v5.nonUpdateables = {}
	v5.drawables = {}
	v5.triggerMarkers = {}
	v5.triggerMarkersAreVisible = true
	v5.helpTriggers = {}
	v5.helpTriggersAreVisible = true
	v5.dynamicallyLoadedObjects = {}
	v5.isPlayerFrozen = false
	v5.environment = nil
	v5.state = BaseMission.STATE_INTRO
	v5.isRunning = false
	v5.isLoaded = false
	v5.numLoadingTasks = 0
	v5.isMissionStarted = false
	v5.isToggleVehicleAllowed = true
	v5.ownedItems = {}
	v5.leasedItems = {}
	v5.loadSpawnPlaces = {}
	v5.storeSpawnPlaces = {}
	v5.restrictedZones = {}
	v5.usedLoadPlaces = {}
	v5.usedStorePlaces = {}
	v5.nodeToObject = {}
	v5.maps = {}
	v5.surfaceSounds = {}
	v5.cuttingSounds = {}
	v5.preSimulateTime = 4000
	v5.snapAIDirection = true
	v5.maxNumHirables = Platform.gameplay.maxNumHirables
	v5.time = 0
	v5.activatableObjectsSystem = ActivatableObjectsSystem.new(v5)
	v5.pauseListeners = {}
	v5.paused = false
	v5.pressStartPaused = false
	v5.manualPaused = false
	v5.suspendPaused = false
	v5.lastNonPauseGameState = GameState.PLAY
	v5.isLoadingMap = false
	v5.numLoadingMaps = 0
	v5.loadingMapBaseDirectory = ""
	v5.objectsToClassName = {}
	v5.lastInteractionTime = -1
	v5.isExitingGame = false
	return v5
end
function BaseMission.initialize(p6)
	p6:subscribeSettingsChangeMessages()
	p6:subscribeGuiOpenCloseMessages()
	g_messageCenter:subscribe(MessageType.GAME_STATE_CHANGED, p6.onGameStateChange, p6)
	p6.hud = p6:createHUD()
	p6.placementManager = PlacementManager.new()
end
function BaseMission.createHUD(p7)
	if Platform.isMobile then
		return MobileHUD.new(g_server ~= nil, g_client ~= nil, GS_IS_CONSOLE_VERSION, g_messageCenter, g_i18n, g_inputBinding, g_inputDisplayManager, g_modManager, g_fillTypeManager, g_fruitTypeManager, g_gui.guiSoundPlayer, p7, g_farmManager, g_farmlandManager)
	else
		return HUD.new()
	end
end
function BaseMission.delete(p8)
	g_messageCenter:unsubscribeAll(p8)
	PlatformNodeRemover.reset()
	p8.isExitingGame = true
	p8.isRunning = false
	p8:setMapTargetHotspot(nil)
	if p8:getIsClient() and (g_localPlayer ~= nil and g_localPlayer:getIsInVehicle()) then
		g_localPlayer:leaveVehicle()
	end
	for v9, v10 in pairs(p8.nonUpdateables) do
		v10:delete()
		p8.nonUpdateables[v9] = nil
	end
	if g_server ~= nil then
		g_server:delete()
		g_server = nil
	end
	if g_client ~= nil then
		g_client:delete()
		g_client = nil
	end
	g_cameraManager:setDefaultCamera()
	if p8.placementManager ~= nil then
		p8.placementManager:delete()
	end
	if g_localPlayer ~= nil then
		g_localPlayer:delete()
	end
	if p8.trafficSystem ~= nil then
		p8.trafficSystem:setEnabled(false)
		p8.trafficSystem:reset()
	end
	if p8.pedestrianSystem ~= nil then
		p8.pedestrianSystem:delete()
		p8.pedestrianSystem = nil
	end
	if p8.shallowWaterSimulation ~= nil then
		p8.shallowWaterSimulation:delete()
		p8.shallowWaterSimulation = nil
	end
	g_terrainDeformationQueue:cancelAllJobs()
	p8.leasedItems = {}
	p8.ownedItems = {}
	p8.placeableSystem:delete()
	p8.vehicleSystem:delete()
	p8.itemSystem:delete()
	p8.onCreateObjectSystem:delete()
	p8.handToolSystem:delete()
	p8.beehiveSystem:delete()
	for _, v11 in pairs(p8.dynamicallyLoadedObjects) do
		delete(v11)
	end
	if p8.environment ~= nil then
		g_inGameMenu:setEnvironment(nil)
		p8.environment:delete()
		p8.environment = nil
	end
	for v12, v13 in pairs(p8.updateables) do
		if v13.delete ~= nil then
			v13:delete()
		end
		table.removeElement(p8.sortedUpdateables, v13)
		p8.updateables[v12] = nil
	end
	for v14 = #g_modEventListeners, 1, -1 do
		if g_modEventListeners[v14].deleteMap ~= nil then
			g_modEventListeners[v14]:deleteMap()
		end
	end
	if p8.hud ~= nil then
		g_messageCenter:unsubscribeAll(p8.hud)
		p8.hud:delete()
		p8.hud = nil
	end
	g_terrainNode = nil
	for _, v15 in pairs(p8.maps) do
		delete(v15)
	end
	for _, v16 in pairs(p8.surfaceSounds) do
		g_soundManager:deleteSample(v16.sample)
	end
	p8.surfaceSounds = {}
	for _, v17 in pairs(p8.cuttingSounds) do
		g_soundManager:deleteSample(v17)
	end
	p8.cuttingSounds = {}
	removeConsoleCommand("gsRender360Screenshot")
	removeConsoleCommand("gsShaderParamsSet")
	g_inputBinding:clearAllContexts()
	g_gui:setCurrentMission(nil)
	g_gui:setClient(nil)
end
function BaseMission.load(p18)
	p18:startLoadingTask()
	if p18:getIsServer() and g_addTestCommands then
		addConsoleCommand("gsRender360Screenshot", "Renders 360 screenshots from current camera position", "consoleCommandRender360Screenshot", p18)
		addConsoleCommand("gsShaderParamsSet", "Sets shader parameters for given nodeName and shader parameter name", "consoleCommandSetShaderParameter", p18, "nodeName; shaderParameterName; x; y; z; w; shared")
	end
	p18:finishLoadingTask()
end
function BaseMission.startLoadingTask(p19)
	p19.numLoadingTasks = p19.numLoadingTasks + 1
	if p19.numLoadingTasks == 1 then
		setStreamLowPriorityI3DFiles(false)
		if p19.missionDynamicInfo.isMultiplayer then
			netSetIsEventProcessingEnabled(false)
		end
	end
end
function BaseMission.finishLoadingTask(p20)
	p20.numLoadingTasks = p20.numLoadingTasks - 1
	if p20.numLoadingTasks <= 0 then
		if not p20.isLoaded then
			p20:onFinishedLoading()
		end
		setStreamLowPriorityI3DFiles(true)
		if p20.missionDynamicInfo.isMultiplayer then
			netSetIsEventProcessingEnabled(true)
		end
	end
end
function BaseMission.onFinishedLoading(p21)
	p21.isLoaded = true
	g_gui:setCurrentMission(p21)
	g_gui:setClient(g_client)
end
function BaseMission.canStartMission(p22)
	if p22.vehicleSystem:canStartMission() then
		if p22.placeableSystem:canStartMission() then
			if p22.handToolSystem:canStartMission() then
				return p22:getIsServer() and true or g_localPlayer ~= nil
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end
end
function BaseMission.onStartMission(p23)
	p23:fadeScreen(-1, 1500, nil)
	p23.isMissionStarted = true
	p23:setShowTriggerMarker(g_gameSettings:getValue(GameSettings.SETTING.SHOW_TRIGGER_MARKER))
	p23:setShowHelpTrigger(g_gameSettings:getValue(GameSettings.SETTING.SHOW_HELP_TRIGGER))
	if Profiler.IS_INITIALIZED then
		g_guidedTourManager:abortTour()
	end
end
function BaseMission.onObjectCreated(p24, p25)
	if p25:isa(Player) then
		p24.players[p25.rootNode] = p25
		if p25.isOwner then
			g_inGameMenu:setPlayer(p25)
			p24.hud:setPlayer(p25)
		end
		if p24:getIsServer() then
			p24.connectionsToPlayer[p25.connection] = p25
		end
		g_messageCenter:publish(MessageType.PLAYER_CREATED, p25)
	elseif p25:isa(Farm) then
		g_farmManager:onFarmObjectCreated(p25)
	end
end
function BaseMission.onObjectDeleted(p26, p27)
	if p27:isa(Player) then
		if g_localPlayer == p27 then
			g_localPlayer = nil
		end
		p26.players[p27.rootNode] = nil
		if p26:getIsServer() then
			p26.connectionsToPlayer[p27.connection] = nil
			return
		end
	elseif p27:isa(Farm) then
		g_farmManager:onFarmObjectDeleted(p27)
	end
end
function BaseMission.loadMap(p28, p29, p30, p31, p32, p33)
	local v34 = p30 == nil and true or p30
	local v35, v36 = Utils.getModNameAndBaseDirectory(p29)
	if p28.numLoadingMaps == 0 then
		p28.loadingMapModName = v35
		p28.loadingMapBaseDirectory = v36
		p28.loadedMapBaseDirectory = v36
		resetModOnCreateFunctions()
		for v37, v38 in pairs(g_modIsLoaded) do
			if v38 and not g_modManager:isModMap(v37) then
				_G[v37].g_onCreateUtil.activateOnCreateFunctions()
			end
		end
		if v35 ~= nil then
			_G[v35].g_onCreateUtil.activateOnCreateFunctions()
		end
		p28.isLoadingMap = true
	elseif p28.loadingMapBaseDirectory ~= v36 then
		printWarning("Warning: Asynchronous map loading from different mods. onCreate functions will not work correctly")
	end
	p28.numLoadingMaps = p28.numLoadingMaps + 1
	if p31 == nil then
		Logging.error("Loading the map in sync is not allowed anymore! Please call loadMap with a async callback.")
		printCallstack()
	else
		g_i3DManager:loadI3DFileAsync(p29, true, v34, p28.loadMapFinished, p28, {
			["filename"] = p29,
			["asyncCallbackFunction"] = p31,
			["asyncCallbackObject"] = p32,
			["asyncCallbackArguments"] = p33
		})
	end
end
function BaseMission.loadMapFinished(p39, p40, _, p41, p42)
	g_mpLoadingScreen:hitLoadingTarget(MPLoadingScreen.LOAD_TARGETS.MAP)
	local v43 = p41.filename
	local v44 = p41.asyncCallbackFunction
	local v45 = p41.asyncCallbackObject
	local v46 = p41.asyncCallbackArguments
	if p40 ~= 0 then
		p39:findDynamicObjects(p40)
		PlatformNodeRemover.removeNodes()
	end
	if Profiler.IS_INITIALIZED then
		Profiler.setMapRootNode(p40)
	end
	p39.numLoadingMaps = p39.numLoadingMaps - 1
	if p39.numLoadingMaps == 0 then
		p39.isLoadingMap = false
		resetModOnCreateFunctions()
		p39.loadingMapModName = nil
		p39.loadingMapBaseDirectory = ""
	end
	if p40 ~= 0 and not p39.cancelLoading then
		local v47 = p39.maps
		table.insert(v47, p40)
		link(getRootNode(), p40)
	end
	for _, v48 in pairs(g_modEventListeners) do
		if v48.loadMap ~= nil then
			v48:loadMap(v43)
		end
	end
	if not p39.cancelLoading then
		p39:setShowFieldInfo(g_gameSettings:getValue(GameSettings.SETTING.SHOW_FIELD_INFO))
	end
	if (p42 == nil or p42) and v44 ~= nil then
		v44(v45, p40, v46)
	end
end
function BaseMission.loadEnvironment(p49, p50)
	local v51 = Utils.getFilename(getXMLString(p50, "map.environment#filename"), p49.baseDirectory)
	p49.environment = Environment.new(p49)
	p49.environment:load(v51)
	if p49.missionInfo.environmentXMLLoad ~= nil and p49:getIsServer() then
		local v52 = loadXMLFile("environmentXML", p49.missionInfo.environmentXMLLoad)
		p49.environment:loadFromXMLFile(v52, "environment")
		delete(v52)
	end
	g_inGameMenu:setEnvironment(p49.environment)
end
function BaseMission.findDynamicObjects(p53, p54)
	for v55 = 1, getNumOfChildren(p54) do
		local v56 = getChildAt(p54, v55 - 1)
		if RigidBodyType.DYNAMIC == getRigidBodyType(v56) then
			if (not getHasClassId(v56, ClassIds.SHAPE) or getSplitType(v56) == 0) and p53.missionDynamicInfo.isMultiplayer then
				local v57 = Utils.getNoNil(getUserAttribute(v56, "mpCreatePhysicsObject"), false)
				local v58 = Utils.getNoNil(getUserAttribute(v56, "mpRemoveRigidBody"), true)
				if v57 then
					local v59 = PhysicsObject.new(p53:getIsServer(), p53:getIsClient())
					p53.onCreateObjectSystem:add(v59)
					v59:loadOnCreate(v56)
					v59:register(true)
				elseif v58 then
					setRigidBodyType(v56, RigidBodyType.NONE)
				end
			end
		else
			p53:findDynamicObjects(v56)
		end
	end
end
function BaseMission.loadMapSounds(p60, p61, p62)
	if p60:getIsClient() then
		local v63 = loadXMLFile("mapSoundXML", p61)
		if v63 ~= 0 then
			p60.surfaceSounds = {}
			local v64 = 0
			while true do
				local v65 = string.format("sound.surface.material(%d)", v64)
				if not hasXMLProperty(v63, v65) then
					break
				end
				local v66 = {}
				local v67 = AudioGroup.ENVIRONMENT
				v66.type = Utils.getNoNil(getXMLString(v63, v65 .. "#type"), "wheel")
				if v66.type == "wheel" then
					v67 = AudioGroup.VEHICLE
				end
				v66.materialId = getXMLInt(v63, v65 .. "#materialId")
				v66.name = getXMLString(v63, v65 .. "#name")
				local v68 = getXMLInt(v63, v65 .. "#loopCount") or 0
				v66.sample = g_soundManager:loadSampleFromXML(v63, "sound.surface", string.format("material(%d)", v64), p62, getRootNode(), v68, v67, nil, nil)
				if v66.sample ~= nil then
					local v69 = p60.surfaceSounds
					table.insert(v69, v66)
				end
				v64 = v64 + 1
			end
			p60.cuttingSounds = {}
			local v70 = 0
			while true do
				local v71 = string.format("sound.cutting.sample(%d)", v70)
				if not hasXMLProperty(v63, v71) then
					break
				end
				local v72 = getXMLString(v63, v71 .. "#name")
				local v73 = g_soundManager:loadSampleFromXML(v63, "sound.cutting", string.format("sample(%d)", v70), p62, getRootNode(), 1, AudioGroup.ENVIRONMENT, nil, nil)
				if v72 == nil then
					printWarning("Warning: a cutting sound does not have a name")
				else
					p60.cuttingSounds[v72] = v73
				end
				v70 = v70 + 1
			end
			delete(v63)
		end
	else
		return
	end
end
function BaseMission.loadObjectAtPlace(p74, p75, p76, p77, p78, p79)
	local v80 = StoreItemUtil.getSizeValues(p75, "object", p78)
	local v81, v82, v83, v84, v85, _ = PlacementUtil.getPlace(p76, v80, p77, true, true, false, true)
	if v81 == nil then
		return nil, true, false
	end
	local v86 = nil
	local v87 = MathUtil.getYRotationFromDirection(v84.dirPerpX, v84.dirPerpZ) + p78
	local v88 = loadXMLFile("tempObjectXML", p75)
	local v89 = Utils.getNoNil(getXMLString(v88, "object.className"), "")
	local v90 = getXMLString(v88, "object.filename")
	local v91 = ClassUtil.getClassObject(v89)
	if v91 == nil then
		printWarning("Warning: Class \'" .. tostring(v89) .. "\' not found!")
	elseif v90 == nil then
		printWarning("Warning: File \'" .. tostring(v90) .. "\' not found!")
	else
		v86 = v91.new(p74:getIsServer(), p74:getIsClient())
		v86:setOwnerFarmId(p79, true)
		if v86:load(Utils.getFilename(v90, p74.baseDirectory), v81, v82, v83, 0, v87, 0, p75) then
			v86:register()
			v86:setFillLevel(v86.capacity, false)
		else
			v86:delete()
			v86 = nil
		end
	end
	delete(v88)
	if v86 == nil then
		return nil, false, false
	end
	PlacementUtil.markPlaceUsed(p77, v84, v85)
	return v86, false, false
end
function BaseMission.addOwnedItem(p92, p93)
	BaseMission.addItemToList(p92.ownedItems, p93)
end
function BaseMission.removeOwnedItem(p94, p95)
	BaseMission.removeItemFromList(p94.ownedItems, p95)
end
function BaseMission.getNumOwnedItems(p96, p97, p98)
	return BaseMission.getNumListItems(p96.ownedItems, p97, p98)
end
function BaseMission.addLeasedItem(p99, p100)
	BaseMission.addItemToList(p99.leasedItems, p100)
end
function BaseMission.removeLeasedItem(p101, p102)
	BaseMission.removeItemFromList(p101.leasedItems, p102)
end
function BaseMission.getNumLeasedItems(p103, p104, p105)
	return BaseMission.getNumListItems(p103.leasedItems, p104, p105)
end
function BaseMission.getNumListItems(p106, p107, p108)
	local v109 = 0
	if p107.bundleInfo == nil then
		if p106[p107] ~= nil then
			if p108 == nil then
				return p106[p107].numItems
			end
			local v110 = 0
			for _, v111 in pairs(p106[p107].items) do
				if v111:getOwnerFarmId() == p108 then
					v110 = v110 + 1
				end
			end
			return v110
		end
	else
		v109 = (1 / 0)
		for _, v112 in pairs(p107.bundleInfo.bundleItems) do
			local v113 = BaseMission.getNumListItems
			local v114 = v112.item
			v109 = math.min(v109, v113(p106, v114, p108))
		end
	end
	return v109
end
function BaseMission.addItemToList(p115, p116)
	if p115 ~= nil and p116 ~= nil then
		local v117 = g_storeManager:getItemByXMLFilename(p116.configFileName)
		if v117 ~= nil then
			if p115[v117] == nil then
				p115[v117] = {
					["storeItem"] = v117,
					["numItems"] = 0,
					["items"] = {}
				}
			end
			if p115[v117].items[p116] == nil then
				p115[v117].numItems = p115[v117].numItems + 1
				p115[v117].items[p116] = p116
			end
		end
	end
end
function BaseMission.removeItemFromList(p118, p119)
	if p118 ~= nil and p119 ~= nil then
		local v120 = g_storeManager:getItemByXMLFilename(p119.configFileName)
		if v120 ~= nil and (p118[v120] ~= nil and p118[v120].items[p119] ~= nil) then
			p118[v120].numItems = p118[v120].numItems - 1
			p118[v120].items[p119] = nil
			if p118[v120].numItems == 0 then
				p118[v120] = nil
			end
		end
	end
end
function BaseMission.addUpdateable(p121, p122, p123)
	local v124 = p122.isa == nil and true or not p122:isa(Object)
	assert(v124, "No network objects allowed in addUpdateable")
	if p122.update == nil then
		Logging.error("Given updateable has no update function")
		printCallstack()
	else
		local v125 = p121.updateables[p123 or p122]
		if v125 ~= nil then
			table.removeElement(p121.sortedUpdateables, v125)
		end
		p121.updateables[p123 or p122] = p122
		table.addElement(p121.sortedUpdateables, p122)
	end
end
function BaseMission.removeUpdateable(p126, p127)
	if p126.updateables[p127] ~= nil then
		table.removeElement(p126.sortedUpdateables, p126.updateables[p127])
	end
	p126.updateables[p127] = nil
end
function BaseMission.getHasUpdateable(p128, p129)
	return p128.updateables[p129] ~= nil
end
function BaseMission.getHasDrawable(p130, p131)
	return p130.drawables[p131] ~= nil
end
function BaseMission.addDrawable(p132, p133, p134)
	p132.drawables[p134 or p133] = p133
end
function BaseMission.removeDrawable(p135, p136)
	p135.drawables[p136] = nil
end
function BaseMission.addNonUpdateable(p137, p138)
	local v139 = p138.isa == nil and true or not p138:isa(Object)
	assert(v139, "No network objects allowed in addNonUpdateable")
	p137.nonUpdateables[p138] = p138
end
function BaseMission.removeNonUpdateable(p140, p141)
	p140.nonUpdateables[p141] = nil
end
function BaseMission.addNodeObject(p142, p143, p144)
	if p142.nodeToObject[p143] == nil then
		p142.nodeToObject[p143] = p144
	else
		Logging.error("Node \'%s\' already has a node-object mapping \'%s\'", getName(p143), (tostring(p144)))
		printCallstack()
	end
end
function BaseMission.removeNodeObject(p145, p146)
	p145.nodeToObject[p146] = nil
end
function BaseMission.getNodeObject(p147, p148)
	return p147.nodeToObject[p148]
end
function BaseMission.pauseGame(p149)
	if not p149.paused then
		p149:doPauseGame()
		if p149:getIsServer() then
			GamePauseEvent.sendEvent()
		end
	end
end
function BaseMission.tryUnpauseGame(p150)
	if not p150:canUnpauseGame() then
		return false
	end
	p150:doUnpauseGame()
	if p150:getIsServer() then
		GamePauseEvent.sendEvent()
	end
	return true
end
function BaseMission.canUnpauseGame(p151)
	local v152 = p151.paused and not (p151.manualPaused or p151.suspendPaused)
	if v152 then
		v152 = not p151.pressStartPaused
	end
	return v152
end
function BaseMission.setManualPause(p153, p154)
	if (p153:getIsServer() or p153.isMasterUser) and p154 ~= p153.manualPaused then
		p153.manualPaused = p154
		if p153:getIsServer() then
			if p154 then
				p153:pauseGame()
			else
				p153:tryUnpauseGame()
			end
		end
		g_client:getServerConnection():sendEvent(GamePauseRequestEvent.new(p154))
	end
end
function BaseMission.doPauseGame(p155)
	p155.paused = true
	p155.isRunning = false
	simulatePhysics(false)
	simulateParticleSystems(false)
	p155:resetGameState()
	if p155.hud ~= nil and not g_gameSettings:getValue(GameSettings.SETTING.SHOW_HELP_MENU) then
		p155.hud:setInputHelpVisible(true)
	end
	for v156, v157 in pairs(p155.pauseListeners) do
		v157(v156, p155.paused)
	end
	g_messageCenter:publish(MessageType.PAUSE, true)
	if p155.trafficSystem ~= nil then
		p155.trafficSystem:setEnabled(false)
	end
	if p155.pedestrianSystem ~= nil then
		p155.pedestrianSystem:setEnabled(false)
	end
end
function BaseMission.doUnpauseGame(p158)
	p158.paused = false
	p158.isRunning = true
	simulatePhysics(true)
	simulateParticleSystems(true)
	if p158.hud ~= nil and not g_gameSettings:getValue(GameSettings.SETTING.SHOW_HELP_MENU) then
		p158.hud:setInputHelpVisible(g_gameSettings:getValue(GameSettings.SETTING.SHOW_HELP_MENU))
	end
	local v159 = p158.lastNonPauseGameState
	if v159 == GameState.MENU_INGAME and g_gui.currentGuiName ~= "InGameMenu" then
		v159 = GameState.PLAY
	end
	g_gameStateManager:setGameState(v159)
	for v160, v161 in pairs(p158.pauseListeners) do
		v161(v160, p158.paused)
	end
	g_messageCenter:publish(MessageType.PAUSE, false)
	if p158.trafficSystem ~= nil then
		p158.trafficSystem:setEnabled(p158.missionInfo.trafficEnabled)
	end
	if p158.pedestrianSystem ~= nil then
		p158.pedestrianSystem:setEnabled(true)
	end
end
function BaseMission.addPauseListeners(p162, p163, p164)
	p162.pauseListeners[p163] = p164
end
function BaseMission.removePauseListeners(p165, p166)
	p165.pauseListeners[p166] = nil
end
function BaseMission.resetGameState(p167)
	if p167.pressStartPaused then
		g_gameStateManager:setGameState(GameState.LOADING)
		return
	elseif p167.paused then
		g_gameStateManager:setGameState(GameState.PAUSED)
	else
		g_gameStateManager:setGameState(GameState.PLAY)
	end
end
function BaseMission.toggleVehicle(p168, p169)
	if p168.isToggleVehicleAllowed then
		local v170 = p168.vehicleSystem:getNextEnterableVehicle(g_localPlayer:getCurrentVehicle(), p169)
		if v170 ~= nil then
			g_localPlayer:requestToEnterVehicle(v170)
		end
	end
end
function BaseMission.getIsClient(_)
	return g_client ~= nil
end
function BaseMission.getIsServer(_)
	return g_server ~= nil
end
function BaseMission.mouseEvent(_, p171, p172, p173, p174, p175)
	for _, v176 in pairs(g_modEventListeners) do
		if v176.mouseEvent ~= nil then
			v176:mouseEvent(p171, p172, p173, p174, p175)
		end
	end
end
function BaseMission.keyEvent(_, p177, p178, p179, p180)
	for _, v181 in pairs(g_modEventListeners) do
		if v181.keyEvent ~= nil then
			v181:keyEvent(p177, p178, p179, p180)
		end
	end
end
function BaseMission.preUpdate(p182, _)
	if not p182.waitForCorruptDlcs then
		if p182.waitForDLCVerification and (verifyDlcs() and (g_gui:getIsGuiVisible() and g_gui.currentGuiName == "InfoDialog")) then
			g_gui:showGui("")
			p182.waitForDLCVerification = false
		end
		if storeAreDlcsCorrupted() then
			p182.waitForCorruptDlcs = true
			local v183 = g_gui:showGui("InfoDialog")
			v183.target:setText(g_i18n:getText("dialog_dlcsCorruptQuit"))
			v183.target:setButtonText(g_i18n:getText("button_quit"))
			v183.target:setCallbacks(p182.dlcProblemOnQuitOk, p182, true)
			return
		end
		if not p182.waitForDLCVerification and storeHaveDlcsChanged() then
			g_forceNeedsDlcsAndModsReload = true
			if not verifyDlcs() then
				p182.waitForDLCVerification = true
				local v184 = g_gui:showGui("InfoDialog")
				v184.target:setText(g_i18n:getText("dialog_reinsertDlcMedia"))
				v184.target:setButtonText(g_i18n:getText("button_quit"))
				v184.target:setCallbacks(p182.dlcProblemOnQuitOk, p182, true)
				return
			end
			if checkForNewDlcs() then
				p182.hud:showInGameMessage(g_i18n:getText("message_newDlcsRestartTitle"), g_i18n:getText("message_newDlcsRestartText"), -1)
			end
		end
	end
end
function BaseMission.dlcProblemOnQuitOk(_)
	OnInGameMenuMenu()
end
function BaseMission.update(p185, p186)
	if p185.waitForDLCVerification or p185.waitForCorruptDlcs then
		return
	else
		if p185:getIsServer() then
			g_server:update(p186, p185.isRunning)
		end
		if p185:getIsClient() then
			g_client:update(p186, p185.isRunning)
		end
		if p185.gameStarted and g_appIsSuspended ~= p185.suspendPaused then
			p185.suspendPaused = g_appIsSuspended
			if g_appIsSuspended then
				p185:pauseGame()
			else
				p185:tryUnpauseGame()
			end
		end
		p185.activatableObjectsSystem:update(p186)
		g_achievementManager:update(p186)
		p185.hud:update(p186)
		if p185.isRunning then
			for v187 in pairs(p185.usedStorePlaces) do
				p185.usedStorePlaces[v187] = nil
			end
			for v188 in pairs(p185.usedLoadPlaces) do
				p185.usedLoadPlaces[v188] = nil
			end
			p185.time = p185.time + p186
			if p185:getIsClient() then
				if not g_gui:getIsGuiVisible() then
					p185.hud:updateBlinkingWarning(p186)
					if p185.currentMapTargetHotspot ~= nil then
						local v189, _, v190 = getWorldTranslation(g_cameraManager:getActiveCamera())
						local v191, v192 = p185.currentMapTargetHotspot:getWorldPosition()
						if MathUtil.vector2Length(v189 - v191, v190 - v192) < 10 then
							p185:setMapTargetHotspot(nil)
						end
					end
				end
				p185.interactiveVehicleInRange = p185:getInteractiveVehicleInRange()
			end
			if p185.environment ~= nil then
				p185.environment:update(p186)
			end
			for v193 = #p185.sortedUpdateables, 1, -1 do
				p185.sortedUpdateables[v193]:update(p186)
			end
			p185.vehicleSystem:update(p186)
			for _, v194 in pairs(g_modEventListeners) do
				if v194.update ~= nil then
					v194:update(p186)
				end
			end
			g_sleepManager:update(p186)
			g_baleManager:update(p186)
			g_fieldCourseManager:update(p186)
			p185.beehiveSystem:update(p186)
			if p185.shallowWaterSimulation ~= nil then
				p185.shallowWaterSimulation:update(p186)
			end
			p185.finishedFirstUpdate = true
			if g_touchHandler ~= nil then
				g_touchHandler:update(p186)
			end
			if g_inAppPurchaseController ~= nil and g_inAppPurchaseController:getIsAvailable() then
				g_inAppPurchaseController:update(p186)
			end
			p185.vehicleSystem:deleteMarkedVehicles()
			p185.placeableSystem:deleteMarkedPlaceables()
			p185.handToolSystem:deleteMarkedHandTools()
		end
	end
end
function BaseMission.draw(p195)
	local v196 = not p195.hud:getIsFading()
	g_sleepManager:draw()
	local v197 = not g_gui:getIsMenuVisible()
	if v197 and (g_gui:getIsDialogVisible() and not Platform.ui.drawHudOnDialog) then
		v197 = false
	end
	if p195:getIsClient() and (p195.isRunning and (v197 and v196)) then
		p195.hud:drawControlledEntityHUD()
		p195.vehicleSystem:draw()
		p195.playerSystem:draw()
		g_soundManager:draw()
	end
	if not g_gui:getIsGuiVisible() and v196 then
		new2DLayer()
		if p195.isRunning or p195.paused then
			p195.hud:drawInputHelp()
		end
		if p195.isRunning then
			for _, v198 in pairs(g_modEventListeners) do
				if v198.draw ~= nil then
					v198:draw()
				end
			end
			for _, v199 in pairs(p195.drawables) do
				v199:draw()
			end
			p195.hud:drawTopNotification()
			p195.hud:drawBlinkingWarning()
		end
	end
	if p195.paused and not (p195.isMissionStarted or g_gui:getIsGuiVisible()) then
		p195.hud:drawGamePaused(true)
	end
	p195.hud:drawFading()
	if g_touchHandler ~= nil then
		g_touchHandler:draw()
	end
end
function BaseMission.setTrafficSystem(p200, p201)
	if p201 == nil or p200.trafficSystem == nil then
		p200.trafficSystem = p201
		return true
	else
		Logging.error("BaseMission: Traffic system already set")
		return false
	end
end
function BaseMission.getTrafficSystem(p202)
	return p202.trafficSystem
end
function BaseMission.setPedestrianSystem(p203, p204)
	if p204 == nil or p203.pedestrianSystem == nil then
		p203.pedestrianSystem = p204
		return true
	else
		Logging.error("BaseMission: Pedestrian system already set")
		return false
	end
end
function BaseMission.getPedestrianSystem(p205)
	return p205.pedestrianSystem
end
function BaseMission.enterVehicleWithPlayer(_, p206, p207, p208)
	local v209 = p206.spec_enterable
	if p206 ~= nil and (v209 ~= nil and v209.isControlled == false) then
		local v210 = p207.connection
		p206:setOwnerConnection(v210)
		p206.controllerFarmId = p207.farmId
		g_server:broadcastEvent(VehicleEnterResponseEvent.new(NetworkUtil.getObjectId(p206), false, p207:getStyle(), p207.farmId, p208), true, v210, p206, false, nil, true)
		v210:sendEvent(VehicleEnterResponseEvent.new(NetworkUtil.getObjectId(p206), true, p207:getStyle(), p207.farmId, p208))
	end
end
function BaseMission.getTrailerInTipRange(_, _, _)
	Logging.warning("BaseMission.getTrailerInTipRange() is deprecated")
	return false
end
function BaseMission.getIsTrailerInTipRange(_)
	Logging.warning("BaseMission.getIsTrailerInTipRange() is deprecated")
	return false
end
function BaseMission.getInteractiveVehicleInRange(p211)
	if g_localPlayer == nil or g_localPlayer:getAreHandsHoldingObject() then
		return nil
	end
	local v212 = (1 / 0)
	local v213 = nil
	for _, v214 in pairs(p211.vehicleSystem.interactiveVehicles) do
		if v214.getIsInteractive ~= nil and v214:getIsInteractive() then
			local v215 = v214:getDistanceToNode(g_localPlayer.rootNode)
			if v215 < v212 then
				v213 = v214
				v212 = v215
			end
		end
	end
	return v213
end
function BaseMission.setMissionInfo(p216, p217, p218)
	p216.missionInfo = p217
	p216.missionDynamicInfo = p218
	p216:setMoneyUnit(g_gameSettings:getValue(GameSettings.SETTING.MONEY_UNIT))
	p216:setUseMiles(g_gameSettings:getValue(GameSettings.SETTING.USE_MILES))
	p216:setUseFahrenheit(g_gameSettings:getValue(GameSettings.SETTING.USE_FAHRENHEIT))
	p216:setUseAcre(g_gameSettings:getValue(GameSettings.SETTING.USE_ACRE))
	p216.hud:setMissionInfo(p217)
	g_inGameMenu:setMissionInfo(p217, p218, p216.baseDirectory)
end
function BaseMission.onCreateTriggerMarker(_, p219)
	g_currentMission:addTriggerMarker(p219)
end
function BaseMission.addTriggerMarker(p220, p221)
	setVisibility(p221, p220.triggerMarkersAreVisible)
	table.addElement(p220.triggerMarkers, p221)
end
function BaseMission.removeTriggerMarker(p222, p223)
	table.removeElement(p222.triggerMarkers, p223)
	setVisibility(p223, false)
end
function BaseMission.setShowTriggerMarker(p224, p225)
	p224.triggerMarkersAreVisible = p225
	for _, v226 in ipairs(p224.triggerMarkers) do
		setVisibility(v226, p225)
	end
end
function BaseMission.addHelpTrigger(p227, p228)
	setVisibility(p228, p227.helpTriggersAreVisible)
	table.addElement(p227.helpTriggers, p228)
end
function BaseMission.removeHelpTrigger(p229, p230)
	table.removeElement(p229.helpTriggers, p230)
end
function BaseMission.setShowHelpTrigger(p231, p232)
	p231.helpTriggersAreVisible = p232
	p231:updateHelpTriggerVisibility()
end
function BaseMission.updateHelpTriggerVisibility(p233)
	local v234 = p233:getCanShowHelpTriggers()
	for _, v235 in ipairs(p233.helpTriggers) do
		setVisibility(v235, v234)
		if v234 then
			addToPhysics(v235)
		else
			removeFromPhysics(v235)
		end
	end
end
function BaseMission.getCanShowHelpTriggers(p236)
	return p236.helpTriggersAreVisible
end
function BaseMission.setShowFieldInfo(p237, p238)
	p237.hud:setInfoVisible(p238)
end
function BaseMission.addHelpButtonText(_)
	Logging.error("BaseMission:addHelpButtonText() is deprecated, use InputBinding:setActionEventText() instead")
	printCallstack()
end
function BaseMission.addHelpAxis(_)
	Logging.error("BaseMission:addHelpAxis() is deprecated")
	printCallstack()
end
function BaseMission.addExtraPrintText(p239, p240)
	p239.hud:addExtraPrintText(p240)
end
function BaseMission.addGameNotification(p241, p242, p243, p244, p245, p246)
	return p241.hud:addTopNotification(p242, p243, p244, p245, p246)
end
function BaseMission.showBlinkingWarning(p247, p248, p249, p250)
	p247.hud:showBlinkingWarning(p248, p249, p250)
end
function BaseMission.setMoneyUnit(_, _) end
function BaseMission.setUseMiles(_, _) end
function BaseMission.setUseAcre(_, _) end
function BaseMission.setUseFahrenheit(_, _) end
function BaseMission.fadeScreen(p251, p252, p253, p254, p255, p256)
	p251.hud:fadeScreen(p252, p253, p254, p255, p256)
end
function BaseMission.getNumOfItems(p257, p258, p259)
	local v260 = 0
	if p257.ownedItems[p258] ~= nil then
		if p259 == nil then
			v260 = v260 + p257.ownedItems[p258].numItems
		elseif p257.ownedItems[p258].numItems > 0 then
			for _, v261 in pairs(p257.ownedItems[p258].items) do
				if v261:getOwnerFarmId() == p259 then
					v260 = v260 + 1
				end
			end
		end
	end
	if p257.leasedItems[p258] ~= nil then
		if p259 == nil then
			return v260 + p257.leasedItems[p258].numItems
		end
		if p257.leasedItems[p258].numItems > 0 then
			for _, v262 in pairs(p257.leasedItems[p258].items) do
				if v262:getOwnerFarmId() == p259 then
					v260 = v260 + 1
				end
			end
		end
	end
	return v260
end
function BaseMission.spawnCollisionTestCallback(p263, p264)
	if p263.nodeToObject[p264] ~= nil then
		p263.spawnCollisionsFound = true
	end
end
function BaseMission.setMapTargetHotspot(p265, p266)
	if p265.currentMapTargetHotspot ~= nil then
		p265.currentMapTargetHotspot:setBlinking(false)
		p265.currentMapTargetHotspot:setPersistent(false)
		g_currentMission.economyManager:updateGreatDemandsPDASpots()
	end
	g_currentMission.navigationSystem:stop()
	if p266 ~= nil then
		p266:setBlinking(true)
		p266:setPersistent(Platform.ingameMap.taggedHotspotsArePersistent)
		local v267, v268 = p266:getWorldPosition()
		local v269 = getTerrainHeightAtWorldPos(g_terrainNode, v267, 0, v268) + 0.25
		g_currentMission.navigationSystem:navigateTo(v267, v269, v268)
	end
	p265.currentMapTargetHotspot = p266
end
function BaseMission.onCreateLoadSpawnPlace(_, p270)
	local v271 = PlacementUtil.loadPlaceFromNode(p270)
	local v272 = g_currentMission.loadSpawnPlaces
	table.insert(v272, v271)
end
function BaseMission.onCreateStoreSpawnPlace(_, p273)
	local v274 = PlacementUtil.loadPlaceFromNode(p273)
	local v275 = g_currentMission.storeSpawnPlaces
	table.insert(v275, v274)
end
function BaseMission.onCreateRestrictedZone(_, p276)
	local v277 = PlacementUtil.createRestrictedZone(p276)
	local v278 = g_currentMission.restrictedZones
	table.insert(v278, v277)
end
function BaseMission.getResetPlaces(p279)
	if #p279.loadSpawnPlaces > 0 then
		return p279.loadSpawnPlaces
	else
		return p279.storeSpawnPlaces
	end
end
function BaseMission.consoleCommandRender360Screenshot(_, p280, p281)
	local v282 = g_screenshotsDirectory
	local v283
	if p281 == nil then
		v283 = v282 .. "fsScreen_" .. getDate("%Y_%m_%d_%H_%M_%S") .. "/"
	else
		v283 = v282 .. p281 .. "/"
	end
	createFolder(v283)
	local v284 = v283 .. "fsScreen360"
	local v285 = tonumber(p280) or 512
	render360Screenshot(v284, v285, "hdr_raw", 1, 0, 0, 0, 0, 5, true, 5)
end
function BaseMission.consoleCommandSetShaderParameter(_, p286, p_u_287, p288, p289, p290, p291, p292)
	if p286 == nil then
		return "Error: no nodeName given\nUsage: gsShaderParamsSet nodeName shaderParameterName [x] [y] [z] [w] [shared]\nNodeName is case insensitive"
	end
	if p_u_287 == nil then
		return "Error: no shaderParameterName given\nUsage: gsShaderParamsSet nodeName shaderParameterName [x] [y] [z] [w] [shared]\nNodeName is case insensitive"
	end
	local v_u_293 = tonumber(p288)
	local v_u_294 = tonumber(p289)
	local v_u_295 = tonumber(p290)
	local v_u_296 = tonumber(p291)
	local v_u_297 = Utils.stringToBoolean(p292)
	local v_u_298 = p286:upper()
	local v_u_299 = 0
	local v_u_300 = 0
	local function v306(p301)
		-- upvalues: (ref) v_u_299, (copy) v_u_298, (copy) p_u_287, (ref) v_u_293, (ref) v_u_294, (ref) v_u_295, (ref) v_u_296, (ref) v_u_297, (ref) v_u_300
		v_u_299 = v_u_299 + 1
		if getName(p301):upper() == v_u_298 and getHasClassId(p301, ClassIds.SHAPE) then
			if not getHasShaderParameter(p301, p_u_287) then
				return true
			end
			local v302, v303, v304, v305 = getShaderParameter(p301, p_u_287)
			setShaderParameter(p301, p_u_287, v_u_293 or v302, v_u_294 or v303, v_u_295 or v304, v_u_296 or v305, v_u_297)
			Logging.info("set shader parameter \'%s\' for node \'%s\' to x=%.3f y=%.3f z=%.3f w=%.3f shared=%s", p_u_287, I3DUtil.getNodePath(p301), v_u_293 or v302, v_u_294 or v303, v_u_295 or v304, v_u_296 or v305, v_u_297)
			v_u_300 = v_u_300 + 1
		end
	end
	I3DUtil.iterateRecursively(getRootNode(), v306)
	return string.format("Finished traversal of %d nodes, %d nodes affected", v_u_299, v_u_300)
end
function BaseMission.setLastInteractionTime(p307, _)
	p307.lastInteractionTime = g_time
end
function BaseMission.subscribeSettingsChangeMessages(p308)
	local v309 = g_messageCenter
	v309:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.MONEY_UNIT], p308.setMoneyUnit, p308)
	v309:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.USE_MILES], p308.setUseMiles, p308)
	v309:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.USE_ACRE], p308.setUseAcre, p308)
	v309:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.USE_FAHRENHEIT], p308.setUseFahrenheit, p308)
	v309:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.SHOW_TRIGGER_MARKER], p308.setShowTriggerMarker, p308)
	v309:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.SHOW_HELP_TRIGGER], p308.setShowHelpTrigger, p308)
	v309:subscribe(MessageType.SETTING_CHANGED[GameSettings.SETTING.SHOW_FIELD_INFO], p308.setShowFieldInfo, p308)
end
function BaseMission.subscribeGuiOpenCloseMessages(p310)
	g_messageCenter:subscribe(MessageType.GUI_BEFORE_OPEN, p310.onBeforeMenuOpen, p310)
	g_messageCenter:subscribe(MessageType.GUI_AFTER_CLOSE, p310.onAfterMenuClose, p310)
end
function BaseMission.onBeforeMenuOpen(_) end
function BaseMission.onAfterMenuClose(_) end
function BaseMission.onGameStateChange(p311, p312, _)
	if p312 ~= GameState.PAUSED then
		p311.lastNonPauseGameState = p312
	end
end

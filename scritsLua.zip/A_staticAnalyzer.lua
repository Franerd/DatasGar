Logging.warning("static analyzer helper lua file should not be sourced/loaded")

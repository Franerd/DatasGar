MissionInfo = {}
local v_u_1 = Class(MissionInfo)
function MissionInfo.new(p2, p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = p4 or v_u_1
	local v6 = setmetatable({}, v5)
	v6.baseDirectory = p2
	v6.customEnvironment = p3
	return v6
end
function MissionInfo.loadDefaults(p7)
	p7.id = "invalid"
	p7.scriptFilename = ""
	p7.scriptClass = ""
end
function MissionInfo.isValidMissionId(_, p8)
	if p8 == nil or p8:len() == 0 then
		return false
	else
		return p8:find("[^%w_]") == nil
	end
end

IgnitionLockManager = {}
IgnitionLockManager.DEVICE_NAME = "Ignition Lock"
IgnitionLockManager.DEBUG_ENABLED = false
local v_u_1 = Class(IgnitionLockManager, AbstractManager)
function IgnitionLockManager.new(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 or v_u_1
	local v4 = setmetatable({}, v3)
	v4:reset()
	addConsoleCommand("gsIgnitionLockDebug", "Toggles the iginition lock debug view", "consoleCommandToggleDebug", v4, nil, false)
	v4.state = IgnitionLockState.UNKNOWN
	return v4
end
function IgnitionLockManager.reset(p5)
	p5.ignitionLocks = {}
end
function IgnitionLockManager.tryToAddDevice(p6, p7, p8, p9)
	if p9 ~= IgnitionLockManager.DEVICE_NAME then
		return false
	end
	local v10 = {
		["internalId"] = p7,
		["engineDeviceId"] = p8
	}
	setGamepadDeadzone(0, p7, 0)
	if #p6.ignitionLocks == 0 then
		local v11 = getInputAxis(0, v10.internalId)
		if math.sign(v11) < 0 then
			p6:setState(IgnitionLockState.OFF)
		elseif v11 < 0.01 then
			p6:setState(IgnitionLockState.IGNITION)
		elseif v11 >= 0.01 then
			p6:setState(IgnitionLockState.START)
		end
	end
	local v12 = p6.ignitionLocks
	table.insert(v12, v10)
	return true
end
function IgnitionLockManager.update(p13, _)
	local v14 = p13.ignitionLocks[1]
	if v14 ~= nil then
		local v15 = getInputButton(0, v14.internalId) > 0
		local v16 = getInputButton(1, v14.internalId) > 0
		local v17 = getInputButton(2, v14.internalId) > 0
		if v15 or getInputButton(3, v14.internalId) > 0 then
			p13:setState(IgnitionLockState.IGNITION)
			return
		end
		if v16 then
			p13:setState(IgnitionLockState.OFF)
			return
		end
		if v17 then
			p13:setState(IgnitionLockState.START)
		end
	end
end
function IgnitionLockManager.setState(p18, p19)
	if p19 ~= p18.state then
		p18.state = p19
	end
end
function IgnitionLockManager.getState(p20)
	return p20.state
end
function IgnitionLockManager.getIsAvailable(p21)
	return #p21.ignitionLocks > 0
end
function IgnitionLockManager.drawDebug(p22)
	setTextAlignment(RenderText.ALIGN_LEFT)
	setTextBold(true)
	renderText(0.025, 0.93, 0.015, string.format("Ignition Lock - Global State: %s", IgnitionLockState.getName(p22.state)))
	setTextBold(false)
	local v23 = 0.91
	local function v34(p24, p25, p26, p27, p28)
		local v29 = getInputButton(p28, p27)
		local v30 = getGamepadButtonPhysicalName(p28, p27)
		local v31 = renderText
		local v32 = string.format
		local v33 = v29 > 0
		v31(p24, p25, p26, v32("Button %d: %s | %s", p28, v30, (tostring(v33))))
	end
	for _, v35 in ipairs(p22.ignitionLocks) do
		renderText(0.025, v23 - 0, 0.012, string.format("Ignition Lock %s", v35.engineDeviceId))
		v34(0.03, v23 - 0.016, 0.012, v35.internalId, 0)
		v34(0.03, v23 - 0.032, 0.012, v35.internalId, 1)
		v34(0.03, v23 - 0.048, 0.012, v35.internalId, 2)
		v34(0.03, v23 - 0.064, 0.012, v35.internalId, 3)
		renderText(0.03, v23 - 0.08 - 0.002, 0.012, string.format("Axis 0: %1.4f", getInputAxis(0, v35.internalId)))
		v23 = v23 - 0.12
	end
end
function IgnitionLockManager.consoleCommandToggleDebug(p36)
	IgnitionLockManager.DEBUG_ENABLED = not IgnitionLockManager.DEBUG_ENABLED
	if IgnitionLockManager.DEBUG_ENABLED then
		g_debugManager:addDrawable(p36)
	else
		g_debugManager:removeDrawable(p36)
	end
end
g_ignitionLockManager = IgnitionLockManager.new()

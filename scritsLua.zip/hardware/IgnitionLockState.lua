IgnitionLockState = {}
IgnitionLockState.UNKNOWN = 1
IgnitionLockState.OFF = 2
IgnitionLockState.IGNITION = 3
IgnitionLockState.START = 4
Enum(IgnitionLockState)

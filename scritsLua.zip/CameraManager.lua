CameraManager = {}
local v_u_1 = Class(CameraManager)
local v_u_2 = setCamera
function setCamera(p3)
	Logging.warning("Use g_cameraManager:setActiveCamera(cameraNode) instead of setCamera(cameraNode)!")
	g_cameraManager:setActiveCamera(p3)
end
function CameraManager.new(p4)
	-- upvalues: (copy) v_u_1
	local v5 = p4 or v_u_1
	local v6 = setmetatable({}, v5)
	v6.cameraInfo = {}
	v6.activeCameraNode = nil
	v6.defaultCameraNode = nil
	v6.lowResColHandlerHighPrioActive = false
	addConsoleCommand("gsCameraFovSet", "Sets camera field of view angle", "consoleCommandSetFOV", v6)
	addConsoleCommand("gsCameraManagerDebug", "Toggle camera manager debug mode", "consoleCommandToggleDebug", v6)
	return v6
end
function CameraManager.addCamera(p7, p8, p9, p10, p11, p12)
	if p7.cameraInfo[p8] == nil then
		if p10 then
			if p7.defaultCameraNode == nil then
				p7.defaultCameraNode = p8
			elseif g_showDevelopmentWarnings then
				Logging.devWarning("Try to set an already existing default camera")
				printCallstack()
			end
		end
		p7.cameraInfo[p8] = {
			["node"] = p8,
			["shadowFocusBoxNode"] = p9,
			["isDefaultCamera"] = p10,
			["colHandlerHighPrio"] = p11,
			["dofInfo"] = p12
		}
	elseif g_showDevelopmentWarnings then
		Logging.devWarning("Try to add an already existing camera")
		printCallstack()
	end
end
function CameraManager.removeCamera(p13, p14)
	local v15 = p13.cameraInfo[p14]
	if v15 == nil then
		if g_showDevelopmentWarnings then
			Logging.devWarning("Try to remove an undefined camera")
			printCallstack()
		end
		return
	elseif v15.isDefaultCamera then
		if g_showDevelopmentWarnings then
			Logging.devWarning("Cannot remove default camera")
			printCallstack()
		end
	else
		p13.cameraInfo[p14] = nil
	end
end
function CameraManager.setDefaultCamera(p16)
	if p16.defaultCameraNode == nil then
		if g_showDevelopmentWarnings then
			Logging.devWarning("No default camera set")
			printCallstack()
		end
	else
		p16:setActiveCamera(p16.defaultCameraNode)
	end
end
function CameraManager.setActiveCamera(p17, p18)
	-- upvalues: (copy) v_u_2
	if p18 == nil then
		if g_showDevelopmentWarnings then
			Logging.devWarning("Try to set nil as a camera")
			printCallstack()
		end
		return
	else
		local v19 = p17.cameraInfo[p18]
		if v19 == nil then
			if g_showDevelopmentWarnings then
				Logging.devWarning("Try to set an undefined camera \'%s\'", getName(p18))
				printCallstack()
			end
			return
		elseif p17.activeCameraNode == p18 then
			Logging.devWarning("Try to set the active camera \'%s\' again", getName(p18))
		else
			local v20 = v19.shadowFocusBoxNode or 0
			v_u_2(p18)
			setShadowFocusBox(v20)
			if v19.colHandlerHighPrio then
				setLowResCollisionHandlerHighPrioriyUpdateArea(2)
				p17.lowResColHandlerHighPrioActive = true
			else
				setLowResCollisionHandlerHighPrioriyUpdateArea(0)
				p17.lowResColHandlerHighPrioActive = false
			end
			if v19.dofInfo == nil then
				g_depthOfFieldManager:reset()
			else
				g_depthOfFieldManager:applyInfo(v19.dofInfo)
			end
			p17.activeCameraNode = p18
		end
	end
end
function CameraManager.getActiveCamera(p21)
	return p21.activeCameraNode
end
function CameraManager.drawDebug(p22)
	local v23 = p22.cameraInfo[p22.activeCameraNode]
	if v23 then
		v23 = p22.cameraInfo[p22.activeCameraNode].shadowFocusBoxNode
	end
	if v23 ~= nil then
		DebugSphere.renderShapeBoundingSphere(v23, nil, nil, nil, getName(v23) .. " (BV)")
	end
	renderText(0.5, 0.02, 0.01, string.format("shadowFocusBox: %s", v23 and getName(v23) or "None"))
	renderText(0.5, 0.01, 0.01, string.format("lowResColHandlerHighPrio: %s", p22.lowResColHandlerHighPrioActive))
end
function CameraManager.consoleCommandToggleDebug(p24)
	if g_debugManager:hasDrawable(p24) then
		g_debugManager:removeDrawable(p24)
		return "CameraManager debug mode: disabled"
	else
		g_debugManager:addDrawable(p24)
		return "CameraManager debug mode: enabled"
	end
end
function CameraManager.consoleCommandSetFOV(p25, p26)
	local v27 = tonumber(p26)
	if v27 == nil then
		return "Error: Command needs number argument. gsCameraFovSet fieldOfViewAngle (-1 to reset to default)"
	end
	local v28 = p25.activeCameraNode
	local v29 = p25.cameraInfo[v28]
	if v29 == nil then
		return "Error: current camera not registered in camera manager"
	end
	if v27 >= 0 then
		if v29.fovBackup == nil then
			local v30
			if g_currentMission and g_localPlayer:getCurrentVehicle() ~= nil then
				local v31 = g_localPlayer:getCurrentVehicle():getActiveCamera()
				if v31 == nil then
					v30 = nil
				else
					v30 = v31.fovY
				end
			else
				v30 = nil
			end
			v29.fovBackup = v30 or getFovY(v28)
		end
		setFovY(v28, (math.rad(v27)))
		return string.format("Set camera %q fov to %.1f\194\176", getName(v28), v27)
	end
	local v32
	if g_currentMission and g_localPlayer:getCurrentVehicle() ~= nil then
		local v33 = g_localPlayer:getCurrentVehicle():getActiveCamera()
		if v33 == nil then
			v32 = nil
		else
			v32 = v33.fovY
		end
	else
		v32 = nil
	end
	local v34 = v32 or v29.fovBackup
	v29.fovBackup = nil
	local v35 = getFovY(v28)
	if v34 == nil or v34 == v35 then
		return string.format("Camera %q still on original fov %.1f\194\176", getName(v28), (math.deg(v35)))
	end
	setFovY(v28, v34)
	return string.format("Reset camera %q fov to original %.1f\194\176", getName(v28), (math.deg(v34)))
end
g_cameraManager = CameraManager.new()

CameraFlightManager = {}
local v_u_1 = Class(CameraFlightManager)
function CameraFlightManager.new()
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3.cameraFlightIsActive = false
	v3.abortCameraFlight = false
	return v3
end
function CameraFlightManager.load(p_u_4, p5)
	p_u_4.cameraFlights = {}
	local v6 = 0
	while true do
		local v7 = string.format("map.cameraFlights.cameraFlight(%d)", v6)
		if not hasXMLProperty(p5, v7) then
			break
		end
		local v8 = getXMLString(p5, v7 .. "#type")
		local v9 = getXMLFloat(p5, v7 .. "#speedScale")
		local v10 = getXMLString(p5, v7 .. "#filename")
		local v11 = Utils.getFilename(v10, p_u_4.baseDirectory)
		local v12 = createCamera("cameraFlight_" .. v8, 1.0471975511965976, 1, 10000)
		local v13 = CameraPath.createFromI3D(v11, v9, v12)
		if p_u_4.cameraFlights[v8] == nil then
			p_u_4.cameraFlights[v8] = v13
		end
		v6 = v6 + 1
	end
	g_inputBinding:registerActionEvent(InputAction.MENU, p_u_4, function()
		-- upvalues: (copy) p_u_4
		p_u_4.abortCameraFlight = true
		g_inputBinding:removeActionEventsByTarget(p_u_4)
	end, false, true, false, true)
end
function CameraFlightManager.delete(p14)
	for _, v15 in pairs(p14.cameraFlights) do
		v15:delete()
	end
end
function CameraFlightManager.update(p16, p17)
	if g_server ~= nil and (g_client ~= nil and (p16.cameraFlights.careerStart ~= nil and not p16.careerStartFlightPlayed)) then
		local v18 = p16.cameraFlights.careerStart
		if g_localPlayer:getCurrentVehicle() ~= nil then
			p16.abortCameraFlight = true
		end
		if p16.abortCameraFlight then
			v18:deactivate()
			p16.careerStartFlightPlayed = true
			g_localPlayer.walkingIsLocked = false
			return
		end
		if not g_gui:getIsGuiVisible() then
			if v18.time == 0 then
				v18:activate()
			end
			v18:update(p17)
			g_localPlayer.walkingIsLocked = true
			if v18.time >= v18.maxTime then
				p16.careerStartFlightPlayed = true
				v18:deactivate()
				g_localPlayer.walkingIsLocked = false
			end
		end
	end
end

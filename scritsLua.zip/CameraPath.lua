CameraPath = {}
local v_u_1 = Class(CameraPath)
function CameraPath.new(p2, p3, p4, p5, p6, p7, p8)
	-- upvalues: (copy) v_u_1
	local v9 = v_u_1
	local v10 = setmetatable({}, v9)
	v10.posAnimCurve = p2
	v10.rotAnimCurve = p3
	v10.speedAnimCurve = p4
	v10.speedScale = p5
	v10.time = 0
	v10.camera = p6
	v10.overriddenCamera = nil
	v10.maxTime = p7
	v10.finishedCallback = p8
	g_cameraManager:addCamera(p6, nil, false)
	return v10
end
function CameraPath.delete(p11)
	g_cameraManager:removeCamera(p11.camera)
	delete(p11.camera)
end
function CameraPath.createFromI3D(p12, p13, p14)
	local v15 = g_i3DManager:loadI3DFile(p12, false, false)
	local v16 = getChild(v15, "positions")
	if v16 == 0 then
		printError("Error: failed to load camera path: " .. p12 .. ". No positions found.")
		return nil
	end
	local v17 = AnimCurve.new(catmullRomInterpolator3, 3)
	local v18 = AnimCurve.new(quaternionInterpolator2, 3)
	local v19 = AnimCurve.new(catmullRomInterpolator1, 3)
	local v20 = nil
	local v21 = nil
	local v22 = nil
	local v23 = 0
	for v24 = 0, getNumOfChildren(v16) - 1 do
		local v25 = getChildAt(v16, v24)
		local v26, v27, v28 = getTranslation(v25)
		local v29, v30, v31 = getRotation(v25)
		local v32, _, _ = getScale(v25)
		if v24 > 0 then
			v23 = v23 + MathUtil.vector3Length(v26 - v20, v27 - v21, v28 - v22)
		end
		v17:addKeyframe({
			["time"] = v23,
			["x"] = v26,
			["y"] = v27,
			["z"] = v28
		})
		local v33, v34, v35, v36 = mathEulerToQuaternion(v29, v30, v31)
		v18:addKeyframe({
			["time"] = v23,
			["x"] = v33,
			["y"] = v34,
			["z"] = v35,
			["w"] = v36
		})
		v19:addKeyframe({
			["time"] = v23,
			["v"] = v32
		})
		v22 = v28
		v21 = v27
		v20 = v26
	end
	local v37 = {}
	local v38 = 0
	local v39 = 32
	for v40 = 1, #v17.keyframes - 1 do
		local v41 = v17.keyframes[v40]
		local v42 = v17.keyframes[v40 + 1]
		local v43, v44, v45 = v17:getFromKeyframes(v41, v42, v40, v40 + 1, 1)
		local v46 = (v40 - 1) * 33 + 1
		v37[v46] = 0
		local v47 = 0
		for v48 = 1, 32 do
			local v49, v50, v51 = v17:getFromKeyframes(v41, v42, v40, v40 + 1, 1 - v48 / 32)
			v47 = v47 + MathUtil.vector3Length(v49 - v43, v50 - v44, v51 - v45)
			v37[v46 + v48] = v47
			v45 = v51
			v44 = v50
			v43 = v49
		end
		v38 = v38 + v47
		v17.keyframes[v40 + 1].time = v38
		v18.keyframes[v40 + 1].time = v38
		v19.keyframes[v40 + 1].time = v38
	end
	v17.segmentTimes = v37
	v17.numTimesPerKeyframe = v39
	v18.segmentTimes = v37
	v18.numTimesPerKeyframe = v39
	v19.segmentTimes = v37
	v19.numTimesPerKeyframe = v39
	v17.maxTime = v38
	v18.maxTime = v38
	v19.maxTime = v38
	delete(v15)
	return CameraPath.new(v17, v18, v19, p13, p14, v38)
end
function CameraPath.update(p52, p53)
	local v54 = p52.speedScale
	if p52.speedAnimCurve ~= nil then
		v54 = v54 * p52.speedAnimCurve:get(p52.time)
	end
	p52.time = p52.time + p53 * v54
	p52:placeCamera()
	local v55 = g_cameraManager:getActiveCamera()
	if v55 ~= p52.camera then
		p52.overriddenCamera = v55
		g_cameraManager:setActiveCamera(p52.camera)
	end
	if p52.finishedCallback ~= nil and p52.time > p52.maxTime then
		p52.finishedCallback()
	end
end
function CameraPath.placeCamera(p56)
	local v57, v58, v59 = p56.posAnimCurve:get(p56.time)
	local v60, v61, v62, v63 = p56.rotAnimCurve:get(p56.time)
	setTranslation(p56.camera, v57, v58, v59)
	setQuaternion(p56.camera, v60, v61, v62, v63)
end
function CameraPath.activate(p64)
	p64:placeCamera()
	p64.overriddenCamera = g_cameraManager:getActiveCamera()
	g_cameraManager:setActiveCamera(p64.camera)
end
function CameraPath.deactivate(p65)
	p65.time = 0
	if p65.overriddenCamera ~= nil then
		g_cameraManager:setActiveCamera(p65.overriddenCamera)
	end
	g_currentMission:removeUpdateable(p65)
end

AnimCurve = {}
function linearInterpolator1(p1, p2, p3)
	return p2[1] + p3 * (p1[1] - p2[1])
end
function linearInterpolator2(p4, p5, p6)
	local v7 = 1 - p6
	return p4[1] * p6 + p5[1] * v7, p4[2] * p6 + p5[2] * v7
end
function linearInterpolator3(p8, p9, p10)
	local v11 = 1 - p10
	return p8[1] * p10 + p9[1] * v11, p8[2] * p10 + p9[2] * v11, p8[3] * p10 + p9[3] * v11
end
function linearInterpolator4(p12, p13, p14)
	local v15 = 1 - p14
	return p12[1] * p14 + p13[1] * v15, p12[2] * p14 + p13[2] * v15, p12[3] * p14 + p13[3] * v15, p12[4] * p14 + p13[4] * v15
end
function linearInterpolatorN(p16, p17, p18, p19)
	for v20 = 1, #p16 do
		if p16[v20] ~= nil and p17[v20] ~= nil then
			p19[v20] = p16[v20] * p18 + p17[v20] * (1 - p18)
		end
	end
	return unpack(p19)
end
function linearInterpolatorTransRot(p21, p22, p23)
	local v24 = 1 - p23
	return p21.x * p23 + p22.x * v24, p21.y * p23 + p22.y * v24, p21.z * p23 + p22.z * v24, p21.rx * p23 + p22.rx * v24, p21.ry * p23 + p22.ry * v24, p21.rz * p23 + p22.rz * v24
end
function linearInterpolatorTransRotScale(p25, p26, p27)
	local v28 = 1 - p27
	return p25.x * p27 + p26.x * v28, p25.y * p27 + p26.y * v28, p25.z * p27 + p26.z * v28, p25.rx * p27 + p26.rx * v28, p25.ry * p27 + p26.ry * v28, p25.rz * p27 + p26.rz * v28, p25.sx * p27 + p26.sx * v28, p25.sy * p27 + p26.sy * v28, p25.sz * p27 + p26.sz * v28
end
function catmullRomInterpolator1(p29, p30, p31, p32, p33)
	local v34 = 1 - p33
	local v35 = v34 * v34
	local v36 = v35 * v34
	local v37
	if p31 == nil then
		v37 = 2 * p29.v - p30.v
	else
		v37 = p31.v
	end
	local v38
	if p32 == nil then
		v38 = 2 * p30.v - p29.v
	else
		v38 = p32.v
	end
	return 0.5 * (2 * p29.v + (-v37 + p30.v) * v34 + (2 * v37 - 5 * p29.v + 4 * p30.v - v38) * v35 + (-v37 + 3 * p29.v - 3 * p30.v + v38) * v36)
end
function catmullRomInterpolator3(p39, p40, p41, p42, p43)
	local v44 = 1 - p43
	local v45 = v44 * v44
	local v46 = v45 * v44
	local v47, v48, v49
	if p41 == nil then
		v47 = 2 * p39.x - p40.x
		v48 = 2 * p39.y - p40.y
		v49 = 2 * p39.z - p40.z
	else
		v47 = p41.x
		v48 = p41.y
		v49 = p41.z
	end
	local v50, v51, v52
	if p42 == nil then
		v50 = 2 * p40.x - p39.x
		v51 = 2 * p40.y - p39.y
		v52 = 2 * p40.z - p39.z
	else
		v50 = p42.x
		v51 = p42.y
		v52 = p42.z
	end
	return 0.5 * (2 * p39.x + (-v47 + p40.x) * v44 + (2 * v47 - 5 * p39.x + 4 * p40.x - v50) * v45 + (-v47 + 3 * p39.x - 3 * p40.x + v50) * v46), 0.5 * (2 * p39.y + (-v48 + p40.y) * v44 + (2 * v48 - 5 * p39.y + 4 * p40.y - v51) * v45 + (-v48 + 3 * p39.y - 3 * p40.y + v51) * v46), 0.5 * (2 * p39.z + (-v49 + p40.z) * v44 + (2 * v49 - 5 * p39.z + 4 * p40.z - v52) * v45 + (-v49 + 3 * p39.z - 3 * p40.z + v52) * v46)
end
function quaternionInterpolator(p53, p54, p55)
	return MathUtil.nlerpQuaternionShortestPath(p54.x, p54.y, p54.z, p54.w, p53.x, p53.y, p53.z, p53.w, p55)
end
function quaternionInterpolator2(p56, p57, p58, p59, p60)
	local v61 = 1 - p60
	local v62 = (1 - v61) * 0.6
	local v63 = v61 * 0.6
	if p58 == nil then
		p58 = p56
		v62 = 0
	end
	if p59 == nil then
		p59 = p57
		v63 = 0
	end
	local v64 = 1 - v61 + v63
	local v65 = v61 + v62
	local v66 = p58.x * v62
	local v67 = p58.y * v62
	local v68 = p58.z * v62
	local v69 = p58.w * v62
	local v70, v71, v72, v73 = MathUtil.quaternionMadShortestPath(v66, v67, v68, v69, p56.x, p56.y, p56.z, p56.w, v64)
	local v74, v75, v76, v77 = MathUtil.quaternionMadShortestPath(v70, v71, v72, v73, p57.x, p57.y, p57.z, p57.w, v65)
	local v78, v79, v80, v81 = MathUtil.quaternionMadShortestPath(v74, v75, v76, v77, p59.x, p59.y, p59.z, p59.w, v63)
	return MathUtil.quaternionNormalized(v78, v79, v80, v81)
end
local v_u_82 = Class(AnimCurve)
function AnimCurve.new(p83, p84)
	-- upvalues: (copy) v_u_82
	local v85 = v_u_82
	local v86 = setmetatable({}, v85)
	v86.keyframes = {}
	v86.interpolator = p83
	v86.interpolatorDegree = p84 or 2
	v86.currentTime = 0
	v86.maxTime = 0
	v86.numKeyframes = 0
	return v86
end
function AnimCurve.delete(_) end
function AnimCurve.reset(p87)
	table.clear(p87.keyframes)
	p87.numKeyframes = 0
	p87.currentTime = 0
	p87.maxTime = 0
end
function AnimCurve.addKeyframe(p88, p89, p90, p91)
	local v92 = p88.numKeyframes
	if v92 > 0 and p89.time < p88.keyframes[v92].time then
		if p90 == nil then
			printError("Error: keyframes not strictly monotonic increasing")
		else
			if type(p90) == "number" then
				p90 = g_xmlManager:getFileByHandle(p90)
			end
			if p90 == nil then
				Logging.error("keyframes not strictly monotonic increasing at %s (%.3f)", p91, p89.time)
			else
				Logging.xmlError(p90, "keyframes not strictly monotonic increasing at %s (%.3f)", p91, p89.time)
			end
		end
	end
	if p88.interpolator == linearInterpolatorN and v92 == 0 then
		p88.curValues = table.create(#p89)
	end
	local v93 = p88.keyframes
	table.insert(v93, p89)
	p88.maxTime = p89.time
	p88.numKeyframes = v92 + 1
end
function AnimCurve.removeKeyframe(p94, p95)
	if p95 == nil or p95 >= 1 and #p94.keyframes >= p95 then
		for v96 = #p94.keyframes - 1, p95, -1 do
			p94.keyframes[v96 + 1].time = p94.keyframes[v96].time
		end
		table.remove(p94.keyframes, p95)
		p94.maxTime = p94.keyframes[#p94.keyframes] and (p94.keyframes[#p94.keyframes].time or 0) or 0
		p94.numKeyframes = p94.numKeyframes - 1
	end
end
function AnimCurve.getMaximum(p97)
	local v98 = #p97.keyframes
	if v98 == 0 then
		return 0, 0
	end
	if v98 == 1 then
		return p97:getFromKeyframes(p97.keyframes[1], p97.keyframes[1], 1, 1, 0), p97.keyframes[1].time
	end
	local v99 = p97:getFromKeyframes(p97.keyframes[1], p97.keyframes[2], 1, 2, 0)
	local v100 = p97.keyframes[1].time
	for v101 = 1, v98 - 1 do
		local v102 = p97:getFromKeyframes(p97.keyframes[v101], p97.keyframes[v101 + 1], v101, v101 + 1, 1)
		if v99 < v102 then
			v100 = p97.keyframes[v101 + 1].time
			v99 = v102
		end
	end
	return v99, v100
end
function AnimCurve.get(p103, p104)
	local v105 = p103.numKeyframes
	if v105 == 0 then
		return
	end
	local v106 = nil
	local v107 = nil
	local v108 = nil
	local v109 = nil
	if v105 >= 2 and p103.keyframes[1].time <= p104 then
		if p104 < p103.maxTime then
			for v110 = 2, v105 do
				v107 = p103.keyframes[v110]
				if p104 <= v107.time then
					v106 = p103.keyframes[v110 - 1]
					v108 = v110 - 1
					v109 = v110
					break
				end
				v109 = v110
			end
		else
			v106 = p103.keyframes[v105]
			v109 = v105
			v108 = v109
			v107 = v106
			local v111 = v109
			v109 = v108
			v111 = v108
			v108 = v109
		end
	else
		v106 = p103.keyframes[1]
		v107 = v106
	end
	local v112 = v106.time
	local v113 = v107.time
	local v114 = v112 >= v113 and 0 or (v113 - p104) / (v113 - v112)
	if p103.segmentTimes ~= nil and v108 < v105 then
		local v115 = (v108 - 1) * (p103.numTimesPerKeyframe + 1) + 1
		local v116 = p104 - v106.time
		local v117, v118 = p103:getInterval(v116, p103.segmentTimes, v115, p103.numTimesPerKeyframe + 1)
		local v119 = p103.segmentTimes[v118 + v115] - p103.segmentTimes[v117 + v115]
		if v119 > 0 then
			v117 = v117 + (v116 - p103.segmentTimes[v117 + v115]) / v119
		end
		v114 = 1 - v117 / p103.numTimesPerKeyframe
	end
	return p103:getFromKeyframes(v106, v107, v108, v109, v114)
end
function AnimCurve.getFromKeyframes(p120, p121, p122, p123, p124, p125)
	if p120.interpolatorDegree == 2 then
		if p120.interpolator == linearInterpolatorN then
			return p120.interpolator(p121, p122, p125, p120.curValues)
		else
			return p120.interpolator(p121, p122, p125)
		end
	elseif p120.interpolatorDegree == 3 then
		local v126
		if p123 > 1 then
			v126 = p120.keyframes[p123 - 1]
		else
			v126 = nil
		end
		local v127
		if p124 < #p120.keyframes then
			v127 = p120.keyframes[p124 + 1]
		else
			v127 = nil
		end
		if p120.interpolator == linearInterpolatorN then
			return p120.interpolator(p121, p122, v126, p120.curValues)
		else
			return p120.interpolator(p121, p122, v126, v127, p125)
		end
	else
		return nil
	end
end
function AnimCurve.getInterval(_, p128, p129, p130, p131)
	local v132 = 0
	while p131 - v132 > 1 do
		local v133 = (p131 + v132) / 2
		local v134 = math.floor(v133)
		if p128 < p129[v134 + p130] then
			p131 = v134
			v134 = v132
		end
		v132 = v134
	end
	return v132, p131
end
function AnimCurve.loadCurveFromXML(p135, p136, p137, p138)
	local v139 = 0
	while true do
		local v140 = string.format("%s.key(%d)", p137, v139)
		if not hasXMLProperty(p136, v140) then
			break
		end
		local v141 = p138(p136, v140)
		if v141 ~= nil then
			p135:addKeyframe(v141)
		end
		v139 = v139 + 1
	end
end
function loadInterpolator1Curve(p142, p143)
	local v144 = getXMLFloat(p142, p143 .. "#time")
	local v145 = getXMLFloat(p142, p143 .. "#value")
	return v145 ~= nil and {
		v145,
		["time"] = v144
	} or nil
end
function loadInterpolator2Curve(p146, p147)
	local v148 = getXMLFloat(p146, p147 .. "#time")
	local v149 = string.getVector(getXMLString(p146, p147 .. "#values"), 2)
	if v149 == nil then
		return nil
	end
	v149.time = v148
	return v149
end
function loadInterpolator3Curve(p150, p151)
	local v152 = getXMLFloat(p150, p151 .. "#time")
	local v153 = string.getVector(getXMLString(p150, p151 .. "#values"), 3)
	if v153 == nil then
		return nil
	end
	v153.time = v152
	return v153
end
function loadInterpolator4Curve(p154, p155)
	local v156 = getXMLFloat(p154, p155 .. "#time")
	local v157 = string.getVector(getXMLString(p154, p155 .. "#values"), 4)
	if v157 == nil then
		return nil
	end
	v157.time = v156
	return v157
end
function getLoadNamedInterpolatorCurve(p_u_158)
	return function(p159, p160)
		-- upvalues: (copy) p_u_158
		local v161 = getXMLString(p159, p160 .. "#time")
		local v162 = {}
		for _, v163 in ipairs(p_u_158) do
			local v164 = getXMLString(p159, p160 .. "#" .. v163)
			if v164 == nil then
				return nil
			end
			local v165 = tonumber(v164)
			table.insert(v162, v165)
		end
		v162.time = tonumber(v161)
		return v162
	end
end
